

# Generated at 2022-06-17 15:04:10.124854
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('50%', 10, min_value=10) == 10
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50', 100, min_value=10) == 50
    assert pct_to_int('50', 10) == 50
    assert pct_to_int('50', 10, min_value=10) == 50
    assert pct_to_int('50.5', 10) == 5
    assert pct_to_int('50.5', 10, min_value=10) == 10
   

# Generated at 2022-06-17 15:04:20.839248
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=20) == 20
    assert pct_to_int('10%', 100, min_value=21) == 21
    assert pct_to_int('10%', 100, min_value=30) == 30

# Generated at 2022-06-17 15:04:30.862589
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:04:41.087785
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100, min_value=1) == 1
    assert pct_to_int('100%', 100) == 100

# Generated at 2022-06-17 15:04:51.495749
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=15) == 10
    assert pct_to_int('10%', 100, min_value=20) == 20
    assert pct_to_int('10%', 100, min_value=25) == 25
    assert pct_to_int('10%', 100, min_value=30) == 30

# Generated at 2022-06-17 15:05:00.402365
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:05:12.356539
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('101%', 100, min_value=5) == 100
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to

# Generated at 2022-06-17 15:05:22.805583
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=15) == 10
    assert pct_to_int('10%', 100, min_value=20) == 20
    assert pct_to_int('10%', 100, min_value=25) == 25
    assert pct_to_int('10%', 100, min_value=30) == 30
    assert pct_to_int('10%', 100, min_value=35) == 35
    assert pct_

# Generated at 2022-06-17 15:05:34.412361
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0.1%', 100, min_value=2) == 2
    assert pct_to_int('0.9%', 100, min_value=2) == 2
    assert pct_to_int('1.1%', 100, min_value=2) == 3
    assert pct_to_int('1.9%', 100, min_value=2)

# Generated at 2022-06-17 15:05:38.926663
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10

# Generated at 2022-06-17 15:05:50.249919
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5

    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 3

# Generated at 2022-06-17 15:06:01.772807
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26



# Generated at 2022-06-17 15:06:13.095241
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4, 1, 2, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 2]) == [1, 2]

# Generated at 2022-06-17 15:06:22.420691
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:31.383761
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:43.390523
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = "test_attr1"
            self.test_attr2 = "test_attr2"
            self.test_attr3 = "test_attr3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == "test_attr1"
    assert test_dict['test_attr2'] == "test_attr2"
    assert test_dict['test_attr3'] == "test_attr3"

    test_dict = object_to_dict(test_obj, exclude=['test_attr1', 'test_attr2'])
    assert 'test_attr1' not in test_dict

# Generated at 2022-06-17 15:06:52.129302
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_value'
            self.test_attr2 = 'test_value2'
            self._test_attr3 = 'test_value3'
            self.test_attr4 = 'test_value4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4'])
    assert test_dict['test_attr'] == 'test_value'
    assert test_dict['test_attr2'] == 'test_value2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:06:58.960704
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:09.895110
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:20.798527
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:33.602547
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:46.567615
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr1'])
    assert 'test_attr1' not in test_dict

# Generated at 2022-06-17 15:07:57.739057
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:08:09.921025
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:08:20.786659
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:33.400630
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:47.316870
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:56.828883
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'

# Generated at 2022-06-17 15:09:01.956410
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-17 15:09:11.769601
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:25.827844
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:09:34.709880
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:45.380275
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self.test_property3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict
    assert test_dict['test_property3'] == 'test_value3'

# Generated at 2022-06-17 15:09:54.374038
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_value = "test"
            self.test_value2 = "test2"
            self._test_value3 = "test3"
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_value'] == "test"
    assert test_dict['test_value2'] == "test2"
    assert '_test_value3' not in test_dict
    test_dict = object_to_dict(test_obj, exclude=['test_value2'])
    assert test_dict['test_value'] == "test"
    assert 'test_value2' not in test_dict
    assert '_test_value3' not in test_dict

# Generated at 2022-06-17 15:10:03.883996
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26



# Generated at 2022-06-17 15:10:12.830101
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3', 'test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:10:19.798983
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:10:28.506616
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2', 'test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr3'] == 'test_attr3'
    assert 'test_attr2' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:10:33.646217
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = TestClass()
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(obj, exclude=['b']) == {'a': 1, 'c': 3}

# Generated at 2022-06-17 15:10:44.682855
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['c', 'e'])
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert 'c' not in test_dict
    assert test_dict['d'] == 4
    assert 'e' not in test_dict

# Generated at 2022-06-17 15:11:04.294453
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test'
            self.test_attr2 = 'test2'
            self._test_attr3 = 'test3'
    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'test_attr': 'test', 'test_attr2': 'test2'}
    assert object_to_dict(test_obj, exclude=['test_attr']) == {'test_attr2': 'test2'}

# Generated at 2022-06-17 15:11:09.949386
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 2, 3, 4, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 2, 3, 4, 5, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 2, 3, 4, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:19.635850
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:11:27.752601
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:11:34.413828
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    obj = TestClass()
    assert object_to_dict(obj) == {'test_attr': 'test_attr', 'test_attr2': 'test_attr2', 'test_attr3': 'test_attr3'}
    assert object_to_dict(obj, exclude=['test_attr2']) == {'test_attr': 'test_attr', 'test_attr3': 'test_attr3'}

# Generated at 2022-06-17 15:11:36.627106
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['b', 'd'])
    assert test_dict == {'a': 'a', 'c': 'c'}

# Generated at 2022-06-17 15:11:44.340377
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'a', 'b', 'd', 'e', 'e', 'f', 'g', 'g', 'g', 'h']
    expected_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == expected_list

# Generated at 2022-06-17 15:11:49.588093
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['c'])
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert 'c' not in test_dict
    assert test_dict['d'] == 'd'

# Generated at 2022-06-17 15:11:59.483915
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'
            self._test_attr4 = '_test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict
    assert '_test_attr4' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])

# Generated at 2022-06-17 15:12:10.147676
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8, 5, 6, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8, 5, 6, 7, 8, 9, 10, 11, 12, 9, 10, 11, 12]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

# Generated at 2022-06-17 15:12:34.097530
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:46.717301
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:12:53.470356
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self._test_property3 = 'test_value3'
            self.test_property4 = 'test_value4'
            self.test_property5 = 'test_value5'

    test_object = TestClass()
    test_dict = object_to_dict(test_object, exclude=['test_property4', 'test_property5'])
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'
    assert 'test_property3' not in test_dict
    assert 'test_property4' not in test_dict

# Generated at 2022-06-17 15:13:02.629772
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_key3'])
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert 'test_key3' not in test_dict


# Generated at 2022-06-17 15:13:07.270499
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 4, 6, 7, 8, 9, 8, 7, 6]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 4, 6, 7, 8, 9, 8, 7, 6, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:13:09.409359
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:13:20.259489
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:27.890726
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:37.268266
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:46.964061
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'
            self.test_key4 = 'test_value4'
            self.test_key5 = 'test_value5'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, exclude=['test_key2', 'test_key4'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict
    assert test_dict['test_key3'] == 'test_value3'
    assert 'test_key4' not in test_dict
    assert test_dict