

# Generated at 2022-06-17 15:04:09.787553
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('0.1%', 100, min_value=10) == 10
    assert pct_to_int('0.5%', 100, min_value=10) == 10
    assert pct_to_int('0.9%', 100, min_value=10) == 10
    assert pct_to_int('0.99%', 100, min_value=10)

# Generated at 2022-06-17 15:04:20.451388
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101

# Generated at 2022-06-17 15:04:27.889744
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0%', 100, min_value=1) == 1
    assert pct_to_int('100%', 100, min_value=1) == 100
    assert pct_to_int('101%', 100, min_value=1) == 100

# Generated at 2022-06-17 15:04:40.186654
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 1000, min_value=10) == 100
    assert pct_to_int('10%', 1000, min_value=101) == 101
    assert pct_to_int('10%', 1000, min_value=110) == 110
    assert pct_to_int('10%', 1000, min_value=111) == 111
    assert pct_to_int('10%', 1000, min_value=120) == 120
    assert pct_to_int('10%', 1000, min_value=121) == 121
    assert pct_to_int('10%', 1000, min_value=130) == 130
    assert pct

# Generated at 2022-06-17 15:04:51.061812
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:04:59.613587
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=3) == 10
    assert pct_

# Generated at 2022-06-17 15:05:12.119126
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('0.1%', 100, min_value=5) == 5
    assert pct_to_int('0.9%', 100, min_value=5) == 5
    assert pct_to_int('0.5%', 100, min_value=5) == 5
    assert pct_to_int('0.4%', 100, min_value=5)

# Generated at 2022-06-17 15:05:14.939228
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    test_class = TestClass()
    test_dict = object_to_dict(test_class)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

# Generated at 2022-06-17 15:05:22.522675
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to_int(1, 100, min_value=5) == 5

# Generated at 2022-06-17 15:05:33.921443
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('10%', 100, min_value=15) == 15
    assert pct_to_int('10%', 0) == 0
    assert pct_to_int('10%', 0, min_value=5) == 5
    assert pct_to_int('10%', 0, min_value=15) == 15
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to_int(10, 100, min_value=15) == 15
    assert pct_to_int(10, 0)

# Generated at 2022-06-17 15:05:43.733966
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:05:49.167062
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:05:54.879201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 5, 1, 2, 3]) == [1, 2, 3, 4, 5]
   

# Generated at 2022-06-17 15:06:05.636794
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test

# Generated at 2022-06-17 15:06:14.105038
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:06:20.104532
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:25.281226
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:33.108806
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:06:43.735230
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['test_attr3', 'test_attr5'])
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict

# Generated at 2022-06-17 15:06:53.607450
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:09.307069
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:07:20.455070
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'

    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'test_attr': 'test_attr', 'test_attr2': 'test_attr2'}
    assert object_to_dict(test_obj, exclude=['test_attr']) == {'test_attr2': 'test_attr2'}
    assert object_to_dict(test_obj, exclude=['test_attr', 'test_attr2']) == {}

# Generated at 2022-06-17 15:07:28.961167
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'c', 'c', 'd', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(['a', 'b', 'c', 'd', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(['a', 'b', 'c', 'd', 'e', 'e', 'e'])

# Generated at 2022-06-17 15:07:37.310438
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:07:43.858586
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:07:53.712733
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = "test_attr"
            self.test_attr2 = "test_attr2"
            self._test_attr3 = "test_attr3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == "test_attr"
    assert 'test_attr2' not in test_dict
    assert '_test_attr3' not in test_dict



# Generated at 2022-06-17 15:07:57.841284
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert test_dict['test_key3'] == 'test_value3'

    test_dict = object_to_dict(test_obj, exclude=['test_key2'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict
    assert test

# Generated at 2022-06-17 15:08:05.840014
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['a', 'b', 'c'])
    assert test_dict == {'d': 4, 'e': 5, 'f': 6}

# Generated at 2022-06-17 15:08:16.909389
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:24.315207
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:08:47.315136
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5
    assert test_dict['f'] == 6
    assert test_dict['g'] == 7
    assert test_dict['h'] == 8

# Generated at 2022-06-17 15:08:58.197054
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:03.086891
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test'
            self.test_value2 = 'test2'
            self._test_value3 = 'test3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_value'] == 'test'
    assert test_dict['test_value2'] == 'test2'
    assert '_test_value3' not in test_dict
    test_dict = object_to_dict(test_obj, exclude=['test_value2'])
    assert test_dict['test_value'] == 'test'
    assert 'test_value2' not in test_dict
    assert '_test_value3' not in test_dict

# Generated at 2022-06-17 15:09:09.816932
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['a', 'c'])
    assert test_dict['b'] == 2
    assert test_dict['d'] == 4
    assert 'a' not in test_dict
    assert 'c' not in test_dict

# Generated at 2022-06-17 15:09:20.305651
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 3

    test_dict = object_to_dict(test_obj, ['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 2


# Generated at 2022-06-17 15:09:31.780055
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:09:37.702594
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:44.860397
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['c', 'e'])
    assert test_dict == {'a': 1, 'b': 2, 'd': 4}

# Generated at 2022-06-17 15:09:53.140639
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:58.966356
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7

    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7}
    assert object_to_dict(test_obj, exclude=['a', 'b', 'c']) == {'d': 4, 'e': 5, 'f': 6, 'g': 7}

# Generated at 2022-06-17 15:10:21.814242
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:29.982407
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self._test_property3 = 'test_value3'

    test_object = TestClass()
    test_dict = object_to_dict(test_object)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'
    assert '_test_property3' not in test_dict

    test_dict = object_to_dict(test_object, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict

# Generated at 2022-06-17 15:10:39.288580
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:10:48.584699
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:10:58.907759
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 4, 4, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 1, 2]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 1, 2, 3]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:11:06.124706
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:11:14.599572
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:11:24.480610
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict

# Generated at 2022-06-17 15:11:30.046725
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test'
            self.test_attr2 = 'test2'
            self._test_attr3 = 'test3'

    obj = TestClass()
    result = object_to_dict(obj)
    assert result['test_attr'] == 'test'
    assert result['test_attr2'] == 'test2'
    assert '_test_attr3' not in result

    result = object_to_dict(obj, exclude=['test_attr2'])
    assert result['test_attr'] == 'test'
    assert 'test_attr2' not in result
    assert '_test_attr3' not in result

# Generated at 2022-06-17 15:11:40.204835
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = "test"
            self.test_attr2 = "test2"
            self.test_attr3 = "test3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == "test"
    assert test_dict['test_attr2'] == "test2"
    assert test_dict['test_attr3'] == "test3"
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == "test"
    assert 'test_attr2' not in test_dict
    assert test_dict['test_attr3'] == "test3"

# Generated at 2022-06-17 15:12:13.126922
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:12:22.499693
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:29.818140
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test'
            self.test_attr2 = 'test2'
            self._test_attr3 = 'test3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test'
    assert test_dict['test_attr2'] == 'test2'
    assert '_test_attr3' not in test_dict



# Generated at 2022-06-17 15:12:38.839110
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:48.369956
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:12:59.194098
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3', 'test_attr4'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict
    assert test_dict

# Generated at 2022-06-17 15:13:11.081210
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7])

# Generated at 2022-06-17 15:13:20.867133
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:13:28.447727
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 6]) != [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 6]) != [1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 6]

# Generated at 2022-06-17 15:13:39.678690
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4', 'test_attr5'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict