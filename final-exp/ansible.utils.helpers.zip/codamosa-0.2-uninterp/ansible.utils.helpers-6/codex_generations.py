

# Generated at 2022-06-17 15:04:05.427589
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2

# Generated at 2022-06-17 15:04:13.269111
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=10) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=10) == 101

# Generated at 2022-06-17 15:04:24.529798
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('50%', 100, min_value=51) == 51
    assert pct_to_int('50%', 100, min_value=100) == 100
    assert pct_to_int('50%', 100, min_value=101) == 101
    assert pct_to_int('50%', 100, min_value=0) == 50
    assert pct_to_int('50%', 100, min_value=-1) == 50
    assert pct_to_int('50%', 100, min_value=-100) == 50

# Generated at 2022-06-17 15:04:33.885200
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('10%', 10000) == 1000
    assert pct_to_int('10%', 100000) == 10000
    assert pct_to_int('10%', 1000000) == 100000
    assert pct_to_int('10%', 10000000) == 1000000
    assert pct_to_int('10%', 100000000) == 10000000
    assert pct_to_int('10%', 1000000000) == 100000000
    assert pct_to_int('10%', 10000000000) == 1000000000
    assert pct_to_int('10%', 100000000000) == 100

# Generated at 2022-06-17 15:04:46.829314
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:04:59.493144
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:05:12.004296
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=0) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('101%', 100) == 100

# Generated at 2022-06-17 15:05:19.577393
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 10, min_value=5) == 5
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10', 100, min_value=5) == 10
    assert pct_to_int('10', 10) == 10
    assert pct_to_int('10', 10, min_value=5) == 10

# Generated at 2022-06-17 15:05:27.574212
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10', 100, min_value=2) == 10
   

# Generated at 2022-06-17 15:05:37.473750
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 3

    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 1

# Generated at 2022-06-17 15:05:48.997817
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 8, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 8, 8, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 8, 8, 9, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:05:54.746329
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 4, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:06:05.560587
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:14.105449
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 4, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:06:18.915578
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_value'
            self.test_attr2 = 'test_value2'
            self._test_attr3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_value'
    assert test_dict['test_attr2'] == 'test_value2'
    assert '_test_attr3' not in test_dict

# Generated at 2022-06-17 15:06:27.617347
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self.test_property3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict
    assert test_dict['test_property3'] == 'test_value3'

# Generated at 2022-06-17 15:06:33.195467
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, exclude=['a', 'c'])
    assert test_dict['b'] == 'b'
    assert test_dict['d'] == 'd'
    assert 'a' not in test_dict
    assert 'c' not in test_dict


# Generated at 2022-06-17 15:06:43.846090
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self._test_property3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'
    assert '_test_property3' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict

# Generated at 2022-06-17 15:06:55.301991
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'
    assert test_dict['test_attr4'] == 'test_attr4'

# Generated at 2022-06-17 15:07:06.464360
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 1, 2, 3, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 1, 2, 3, 3, 4, 5, 5, 5, 6, 1, 2, 3, 3, 4, 5, 5, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:20.792571
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:29.643949
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:07:38.068303
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:48.125471
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:07:58.475406
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:08:06.194571
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['a', 'b'])
    assert test_dict == {'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 15:08:10.388759
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:20.290756
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:33.363580
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4, 7, 8, 9, 8, 7]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:08:45.062485
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['test_attr3'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict

# Generated at 2022-06-17 15:08:59.567776
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:09:10.224549
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:17.542225
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['b'])
    assert test_dict['a'] == 'a'
    assert 'b' not in test_dict
    assert test_dict['c'] == 'c'

# Generated at 2022-06-17 15:09:26.355326
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 5, 6, 7, 8, 5, 6, 7, 8]) == [1, 2, 3, 5, 6, 7, 8]
    assert deduplicate_list([1, 2, 3, 1, 2, 5, 6, 7, 8, 5, 6, 7, 8, 1, 2, 3, 1, 2, 5, 6, 7, 8, 5, 6, 7, 8]) == [1, 2, 3, 5, 6, 7, 8]

# Generated at 2022-06-17 15:09:30.927250
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:09:36.961136
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:49.192562
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:55.755830
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'

    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict



# Generated at 2022-06-17 15:10:01.025096
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'
            self.test_value2 = 'test_value2'
            self.test_value3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_value'] == 'test_value'
    assert test_dict['test_value2'] == 'test_value2'
    assert test_dict['test_value3'] == 'test_value3'

    test_dict = object_to_dict(test_obj, exclude=['test_value2'])
    assert test_dict['test_value'] == 'test_value'
    assert 'test_value2' not in test_dict
    assert test

# Generated at 2022-06-17 15:10:08.373102
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:10:29.645716
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:37.633470
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)

    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr1', 'test_attr3'])

    assert 'test_attr1' not in test_dict

# Generated at 2022-06-17 15:10:48.068700
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-17 15:10:53.984590
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'

# Generated at 2022-06-17 15:11:02.440434
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:11:10.660859
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'd', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 15:11:20.066929
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:11:28.044858
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:11:35.654399
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 1, 1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list(None) == []

# Generated at 2022-06-17 15:11:42.730136
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:15.567505
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    obj = TestClass()
    result = object_to_dict(obj, exclude=['test_attr4'])
    assert result['test_attr'] == 'test_attr'
    assert result['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in result
    assert 'test_attr4' not in result

# Generated at 2022-06-17 15:12:24.030060
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:33.082553
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 6, 7, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 6, 7, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-17 15:12:46.517070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:53.347405
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_obj_dict = object_to_dict(test_obj)
    assert test_obj_dict['test_attr'] == 'test_attr'
    assert test_obj_dict['test_attr2'] == 'test_attr2'
    assert test_obj_dict['test_attr3'] == 'test_attr3'

    test_obj_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_obj_dict['test_attr'] == 'test_attr'

# Generated at 2022-06-17 15:13:04.916838
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 3, 2, 1, 4, 5, 6, 5, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:15.918358
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'c', 'b', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'b', 'a', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list([1, 2, 3, 2, 1, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:24.493362
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 6, 4, 5]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 6, 4, 5, 1, 2, 3, 1, 2, 4, 5, 6, 4, 5]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 5, 6, 4, 5, 1, 2, 3, 1, 2, 4, 5, 6, 4, 5, 1, 2, 3, 1, 2, 4, 5, 6, 4, 5]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:13:36.009032
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5

    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 3

# Generated at 2022-06-17 15:13:46.846088
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]