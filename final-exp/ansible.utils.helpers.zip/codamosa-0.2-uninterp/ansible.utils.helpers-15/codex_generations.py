

# Generated at 2022-06-17 15:04:09.556665
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26



# Generated at 2022-06-17 15:04:15.516614
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-17 15:04:25.250828
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0.1%', 100, min_value=2) == 2
    assert pct_to_int('0.9%', 100, min_value=2) == 2
    assert pct_to_int('1.0%', 100, min_value=2) == 2
    assert pct_to_int('1.1%', 100, min_value=2)

# Generated at 2022-06-17 15:04:29.177114
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100, min_value=5) == 10
    assert pct_to_int(10, 100, min_value=5) == 10

# Generated at 2022-06-17 15:04:40.254588
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('0.1%', 100, min_value=5) == 5
    assert pct_to_int('0.5%', 100, min_value=5) == 5
    assert pct_to_int('0.9%', 100, min_value=5) == 5
    assert pct_to_int('1%', 100, min_value=5) == 5

# Generated at 2022-06-17 15:04:49.032206
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:04:59.673286
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10', 100) == 10
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=12) == 12
    assert pct_to_int('10%', 100, min_value=13) == 13

# Generated at 2022-06-17 15:05:12.117704
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('0.1%', 100, min_value=2) == 2
    assert pct_to_int('0.9%', 100, min_value=2) == 2
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('1.1%', 100, min_value=2) == 3

# Generated at 2022-06-17 15:05:22.633959
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=10) == 20
    assert pct_to_int('20%', 100, min_value=20) == 20
    assert pct_to_int('20%', 100, min_value=21) == 21
    assert pct_to_int('20%', 100, min_value=30) == 30
    assert pct_to_int('20%', 100, min_value=40) == 40
    assert pct_to_int('20%', 100, min_value=50) == 50
    assert pct_to_int('20%', 100, min_value=60) == 60

# Generated at 2022-06-17 15:05:34.407555
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101
    assert pct_to_int('-1%', 100) == -1

# Generated at 2022-06-17 15:05:47.556728
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:05:58.287230
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:07.682778
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'd', 'a', 'b', 'c']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 15:06:17.490371
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:27.861966
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'
    test_dict = object_to_dict(test_obj, ['test_property'])
    assert 'test_property' not in test_dict
    assert test_dict['test_property2'] == 'test_value2'

# Generated at 2022-06-17 15:06:34.919581
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:45.479099
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:06:55.847320
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,4,5,1,2,3,4,5]) == [1,2,3,4,5]
    assert deduplicate_list([1,2,3,4,5,1,2,3,4,5,6]) == [1,2,3,4,5,6]
    assert deduplicate_list([1,2,3,4,5,1,2,3,4,5,6,1,2,3,4,5,6]) == [1,2,3,4,5,6]

# Generated at 2022-06-17 15:07:07.330131
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:07:14.113045
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:07:28.620082
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:07:38.560492
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:07:48.291072
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr1'] == 'test_attr1'
    assert 'test_attr2' not in test

# Generated at 2022-06-17 15:07:58.027307
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4

# Generated at 2022-06-17 15:08:09.451505
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key1 = 'test_value1'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'
            self.test_key4 = 'test_value4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_key1', 'test_key2'])
    assert test_dict['test_key3'] == 'test_value3'
    assert test_dict['test_key4'] == 'test_value4'
    assert 'test_key1' not in test_dict
    assert 'test_key2' not in test_dict

# Generated at 2022-06-17 15:08:19.701390
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:27.907731
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_property = 'test_value'
            self.test_property2 = 'test_value2'
            self.test_property3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_property'] == 'test_value'
    assert test_dict['test_property2'] == 'test_value2'
    assert test_dict['test_property3'] == 'test_value3'

    test_dict = object_to_dict(test_obj, exclude=['test_property2'])
    assert test_dict['test_property'] == 'test_value'
    assert 'test_property2' not in test_dict
    assert test

# Generated at 2022-06-17 15:08:35.806232
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22
            self.w = 23
            self.x = 24
            self.y = 25
            self.z = 26


# Generated at 2022-06-17 15:08:48.259347
# Unit test for function deduplicate_list

# Generated at 2022-06-17 15:08:58.420066
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:15.132834
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 1, 2, 3]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:22.859986
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:33.013309
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:46.202304
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert len(test_dict) == 2

    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict
    assert test_dict['test_attr2'] == 'test_attr2'
    assert len(test_dict) == 1

# Generated at 2022-06-17 15:09:52.340383
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self._d = 4
            self.e = 5
            self.f = 6

    obj = TestObject()
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 3, 'e': 5, 'f': 6}
    assert object_to_dict(obj, exclude=['a', 'c']) == {'b': 2, 'e': 5, 'f': 6}

# Generated at 2022-06-17 15:09:59.024044
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:04.674798
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.test_prop = 'test'
            self.test_prop2 = 'test2'
            self.test_prop3 = 'test3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['test_prop'])
    assert test_dict['test_prop2'] == 'test2'
    assert 'test_prop' not in test_dict

# Generated at 2022-06-17 15:10:08.496413
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 5, 6, 7, 8, 9, 9, 8, 7]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:10:19.974627
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:10:29.206879
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'
            self.test_attr4 = 'test_attr4'
            self.test_attr5 = 'test_attr5'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4', 'test_attr5'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:10:50.128032
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 1, 1, 1]) == [1]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:10:59.759810
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 1, 2, 3, 4, 1, 2, 3, 3, 2, 1, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:11:09.218185
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'
    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert test_dict['test_key3'] == 'test_value3'
    test_dict = object_to_dict(test_obj, exclude=['test_key2'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict
    assert test

# Generated at 2022-06-17 15:11:19.392746
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:11:27.555780
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:38.846670
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert test_dict['test_key3'] == 'test_value3'
    test_dict = object_to_dict(test_obj, exclude=['test_key2'])
    assert test_dict['test_key'] == 'test_value'
    assert 'test_key2' not in test_dict
    assert test

# Generated at 2022-06-17 15:11:47.461966
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:11:58.742102
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])

# Generated at 2022-06-17 15:12:08.359316
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_prop = 'test_value'
            self.test_prop2 = 'test_value2'
            self._test_prop3 = 'test_value3'
            self.test_prop4 = 'test_value4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_prop4'])
    assert test_dict['test_prop'] == 'test_value'
    assert test_dict['test_prop2'] == 'test_value2'
    assert '_test_prop3' not in test_dict
    assert 'test_prop4' not in test_dict

# Generated at 2022-06-17 15:12:17.326618
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:59.551468
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = '_test_attr3'
            self._test_attr4 = '_test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert 'test_attr' in test_dict
    assert 'test_attr2' in test_dict
    assert '_test_attr3' not in test_dict
    assert '_test_attr4' not in test_dict

    test_dict = object_to_dict(test_obj, exclude=['test_attr'])
    assert 'test_attr' not in test_dict

# Generated at 2022-06-17 15:13:11.373244
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:16.726982
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:19.221260
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = TestClass()
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(obj, exclude=['a']) == {'b': 2, 'c': 3}

# Generated at 2022-06-17 15:13:25.952200
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:13:36.269604
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:13:42.871238
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
    expected_list = [1, 2, 3, 4, 5, 6]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-17 15:13:55.475280
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]