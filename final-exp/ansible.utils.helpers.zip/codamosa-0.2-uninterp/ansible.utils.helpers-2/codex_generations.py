

# Generated at 2022-06-17 15:04:08.551736
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 100) == 20
    assert pct_to_int('20%', 100, min_value=10) == 10
    assert pct_to_int('20%', 100, min_value=20) == 20
    assert pct_to_int('20%', 100, min_value=30) == 20
    assert pct_to_int('20%', 100, min_value=40) == 20
    assert pct_to_int('20%', 100, min_value=50) == 20
    assert pct_to_int('20%', 100, min_value=60) == 20
    assert pct_to_int('20%', 100, min_value=70) == 20

# Generated at 2022-06-17 15:04:19.472750
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=5) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=5) == 101

# Generated at 2022-06-17 15:04:27.157340
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=20) == 20
    assert pct_to_int('10%', 100, min_value=21) == 21
    assert pct_to_int('10%', 100, min_value=30) == 30
    assert pct_to_int('10%', 100, min_value=31) == 31
    assert pct_

# Generated at 2022-06-17 15:04:35.130334
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:04:47.351071
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:04:59.530369
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=1) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=3) == 10
    assert pct_

# Generated at 2022-06-17 15:05:12.079920
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:05:22.633814
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101
    assert pct_to_int('-1%', 100) == 1
    assert pct_to_int('-1%', 100, min_value=2)

# Generated at 2022-06-17 15:05:34.406570
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=20) == 20
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=5) == 5
    assert pct_to_int('1%', 100, min_value=10) == 10

# Generated at 2022-06-17 15:05:43.147715
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int('0%', 100) == 0
    assert pct_to_int('0%', 100, min_value=2) == 2
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 100, min_value=2) == 100
    assert pct_to_int('101%', 100) == 101
    assert pct_to_int('101%', 100, min_value=2) == 101

# Generated at 2022-06-17 15:05:55.004859
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_value = 'test'
            self.test_value2 = 'test2'
            self.test_value3 = 'test3'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, exclude=['test_value3'])
    assert test_dict['test_value'] == 'test'
    assert test_dict['test_value2'] == 'test2'
    assert 'test_value3' not in test_dict

# Generated at 2022-06-17 15:06:00.448042
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'

    obj = TestClass()
    assert object_to_dict(obj) == {'test_attr': 'test_attr', 'test_attr2': 'test_attr2'}
    assert object_to_dict(obj, exclude=['test_attr']) == {'test_attr2': 'test_attr2'}

# Generated at 2022-06-17 15:06:07.437543
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict

# Generated at 2022-06-17 15:06:15.277193
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]

# Generated at 2022-06-17 15:06:22.479955
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = "test_attr"
            self.test_attr2 = "test_attr2"
            self.test_attr3 = "test_attr3"
            self.test_attr4 = "test_attr4"
            self.test_attr5 = "test_attr5"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr3'] == 'test_attr3'
    assert test_dict['test_attr4'] == 'test_attr4'

# Generated at 2022-06-17 15:06:29.412282
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

# Generated at 2022-06-17 15:06:39.786046
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:06:49.193081
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4

    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4



# Generated at 2022-06-17 15:06:58.554022
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 8, 9, 9, 9, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:07:09.535576
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:23.536834
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:07:31.662726
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:07:38.896362
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:07:48.380064
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    assert test_dict['test_key3'] == 'test_value3'
    test_dict = object_to_dict(test_obj, exclude=['test_key'])
    assert 'test_key' not in test_dict
    assert test_dict['test_key2'] == 'test_value2'
    assert test

# Generated at 2022-06-17 15:07:58.630724
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 1, 2, 3]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 1, 2, 3, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:08:10.896637
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:21.384653
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:33.400365
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 5, 4, 3, 2, 1, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:08:45.424297
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'

    test = Test()
    assert object_to_dict(test) == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}
    assert object_to_dict(test, exclude=['a', 'b', 'c']) == {'d': 'd', 'e': 'e'}

# Generated at 2022-06-17 15:08:56.794395
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:09:14.037142
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test'
            self.test_attr2 = 'test2'
            self._test_attr3 = 'test3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test'
    assert test_dict['test_attr2'] == 'test2'
    assert '_test_attr3' not in test_dict


# Generated at 2022-06-17 15:09:25.506590
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:09:33.568778
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'
            self.test_value2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_value'] == 'test_value'
    assert test_dict['test_value2'] == 'test_value2'

    test_dict = object_to_dict(test_obj, exclude=['test_value'])
    assert 'test_value' not in test_dict
    assert test_dict['test_value2'] == 'test_value2'

# Generated at 2022-06-17 15:09:46.733371
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:09:54.892759
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 5, 6, 5, 5, 5]) == [1, 2, 3, 5, 6]
    assert deduplicate_list([1, 2, 3, 2, 1, 5, 6, 5, 5, 5]) != [1, 2, 3, 5, 6, 5]
    assert deduplicate_list([1, 2, 3, 2, 1, 5, 6, 5, 5, 5]) != [1, 2, 3, 5, 6, 5, 5]
    assert deduplicate_list([1, 2, 3, 2, 1, 5, 6, 5, 5, 5]) != [1, 2, 3, 5, 6, 5, 5, 5]

# Generated at 2022-06-17 15:10:04.228403
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 7, 8, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 7, 8, 9, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:10:09.237585
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 4, 1, 2, 3, 2, 1, 4, 5, 4]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:20.671697
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test'
            self.test_value_2 = 'test2'
            self._test_value_3 = 'test3'
    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'test_value': 'test', 'test_value_2': 'test2'}
    assert object_to_dict(test_obj, exclude=['test_value']) == {'test_value_2': 'test2'}
    assert object_to_dict(test_obj, exclude=['test_value', 'test_value_2']) == {}

# Generated at 2022-06-17 15:10:29.573600
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:10:37.631432
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5
    assert test_dict['f'] == 6

    test_dict = object_to_dict(test_obj, exclude=['a', 'b', 'c'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict

# Generated at 2022-06-17 15:11:08.904381
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:11:19.353198
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'

    obj = TestClass()
    assert object_to_dict(obj) == {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    assert object_to_dict(obj, ['a', 'b']) == {'c': 'c', 'd': 'd'}
    assert object_to_dict(obj, ['a', 'b', 'c']) == {'d': 'd'}
    assert object_to_dict(obj, ['a', 'b', 'c', 'd']) == {}

# Generated at 2022-06-17 15:11:27.519556
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = "test_attr"
            self.test_attr2 = "test_attr2"
            self.test_attr3 = "test_attr3"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == "test_attr"
    assert test_dict['test_attr2'] == "test_attr2"
    assert test_dict['test_attr3'] == "test_attr3"

    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == "test_attr"
    assert 'test_attr2' not in test_dict
    assert test

# Generated at 2022-06-17 15:11:38.104317
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr4'])

    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert 'test_attr4' not in test_dict



# Generated at 2022-06-17 15:11:49.930383
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'

    test_class = TestClass()
    test_dict = object_to_dict(test_class)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 3

    test_dict = object_to_dict(test_class, exclude=['a'])
    assert test_dict['a'] is None
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert len(test_dict) == 3



# Generated at 2022-06-17 15:11:59.855354
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5
    assert test_dict['f'] == 6

    test_dict = object_to_dict(test_obj, ['a', 'b', 'c'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
   

# Generated at 2022-06-17 15:12:10.429536
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:12:18.538717
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:12:30.554774
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:12:39.510394
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 7, 8, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 7, 8, 9, 9]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 9]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 6, 7, 8, 9, 9]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9]
    assert deduplicate_

# Generated at 2022-06-17 15:13:46.341260
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:13:56.353772
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:14:01.829092
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c'])