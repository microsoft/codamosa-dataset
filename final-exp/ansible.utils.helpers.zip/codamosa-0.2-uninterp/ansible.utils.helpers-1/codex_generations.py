

# Generated at 2022-06-17 15:04:07.666847
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3'])
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict

# Generated at 2022-06-17 15:04:18.716216
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:04:26.571824
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10', 100, min_value=5) == 10
    assert pct_to_int('10', 100, min_value=10) == 10
    assert pct_to_int('10', 100, min_value=11) == 11
    assert pct_to_int('0%', 100) == 1

# Generated at 2022-06-17 15:04:32.862770
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestClass()
    assert object_to_dict(test_obj) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert object_to_dict(test_obj, exclude=['a', 'b']) == {'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 15:04:44.847316
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, min_value=2) == 50
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('1%', 100, min_value=2) == 2
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(50, 100, min_value=2) == 50
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(1, 100, min_value=2) == 2

# Generated at 2022-06-17 15:04:52.539050
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100) == 50
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50', 100) == 50
    assert pct_to_int('50%', 100, min_value=10) == 50
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('5%', 100, min_value=10) == 10
    assert pct_to_int('1%', 100, min_value=10) == 10
    assert pct_to_int('0%', 100, min_value=10) == 10
    assert pct_to_int('0.1%', 100, min_value=10) == 10

# Generated at 2022-06-17 15:05:00.988854
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5
    assert pct_to_int('10%', 100, min_value=15) == 15
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=-5) == 10
    assert pct_to_int('10%', 100, min_value=-15) == 10
    assert pct_to_int('10%', 100, min_value=-10) == 10

# Generated at 2022-06-17 15:05:12.840466
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=2) == 10
    assert pct_to_int(10, 100, min_value=11) == 11
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=2) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('10.5%', 100, min_value=2) == 11
    assert pct_to_int('10.5%', 100, min_value=12) == 12

# Generated at 2022-06-17 15:05:23.000606
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=0) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('10%', 100, min_value=5) == 10
    assert pct_to_int('10%', 100, min_value=11) == 11
    assert pct_to_int('10%', 100, min_value=12) == 12
    assert pct_to_int('10%', 100, min_value=13) == 13
    assert pct_to_

# Generated at 2022-06-17 15:05:34.414686
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('10.5', 100) == 10
    assert pct_to_int('0%', 100) == 1
    assert pct_to_int('0', 100) == 0
    assert pct_to_int('0%', 100, min_value=0) == 0
    assert pct_to_int('0', 100, min_value=0) == 0
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100', 100) == 100

# Generated at 2022-06-17 15:05:40.356008
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 2, 3, 1, 4, 5, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:05:45.825680
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'

# Generated at 2022-06-17 15:05:58.192312
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 3, 2]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 15:06:06.941749
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr3'])
    assert test_dict['test_attr1'] == 'test_attr1'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert 'test_attr3' not in test_dict
    assert test_dict['test_attr4'] == 'test_attr4'

# Generated at 2022-06-17 15:06:16.939888
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 4, 4, 5, 6, 6, 7, 8, 8, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:06:29.484932
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'
            self.test_key3 = 'test_value3'
            self.test_key4 = 'test_value4'
            self.test_key5 = 'test_value5'
            self.test_key6 = 'test_value6'
            self.test_key7 = 'test_value7'
            self.test_key8 = 'test_value8'
            self.test_key9 = 'test_value9'
            self.test_key10 = 'test_value10'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)


# Generated at 2022-06-17 15:06:39.881237
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'
            self.f = 'f'

    test_object = TestObject()
    test_dict = object_to_dict(test_object)
    assert test_dict['a'] == 'a'
    assert test_dict['b'] == 'b'
    assert test_dict['c'] == 'c'
    assert test_dict['d'] == 'd'
    assert test_dict['e'] == 'e'
    assert test_dict['f'] == 'f'


# Generated at 2022-06-17 15:06:49.663182
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:06:58.957767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:07:09.888366
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-17 15:07:23.116826
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self._d = 4
            self._e = 5
            self._f = 6

    test_obj = TestClass()
    result = object_to_dict(test_obj)
    assert result == {'a': 1, 'b': 2, 'c': 3}

    result = object_to_dict(test_obj, exclude=['a', 'b'])
    assert result == {'c': 3}

    result = object_to_dict(test_obj, exclude=['a', 'b', '_d', '_e'])
    assert result == {'c': 3}


# Generated at 2022-06-17 15:07:29.542201
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict
    assert test_dict['test_attr3'] == 'test_attr3'

# Generated at 2022-06-17 15:07:35.001162
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = "a"
            self.b = "b"
            self.c = "c"
            self.d = "d"
            self.e = "e"

    obj = TestObject()
    result = object_to_dict(obj, exclude=["c", "e"])
    assert result == {'a': 'a', 'b': 'b', 'd': 'd'}

# Generated at 2022-06-17 15:07:45.838439
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = 'e'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['a', 'c'])
    assert test_dict['b'] == 'b'
    assert test_dict['d'] == 'd'
    assert test_dict['e'] == 'e'
    assert 'a' not in test_dict
    assert 'c' not in test_dict

# Generated at 2022-06-17 15:07:57.387969
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:08:09.498726
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:08:19.754656
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5
    test_dict = object_to_dict(test_obj, exclude=['c', 'd'])
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert 'c' not in test_dict
    assert 'd' not in test_

# Generated at 2022-06-17 15:08:24.252192
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5]
    expected_list = [1, 2, 3, 4, 5]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-17 15:08:29.543489
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert ded

# Generated at 2022-06-17 15:08:36.596716
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_var1 = 'test_var1'
            self.test_var2 = 'test_var2'
            self.test_var3 = 'test_var3'
            self.test_var4 = 'test_var4'
            self.test_var5 = 'test_var5'
            self.test_var6 = 'test_var6'
            self.test_var7 = 'test_var7'
            self.test_var8 = 'test_var8'
            self.test_var9 = 'test_var9'
            self.test_var10 = 'test_var10'
            self.test_var11 = 'test_var11'
            self.test_var12 = 'test_var12'
            self

# Generated at 2022-06-17 15:08:50.641787
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:08:58.194438
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'
    test_dict = object_to_dict(test_obj, exclude=['test_key'])
    assert 'test_key' not in test_dict
    assert test_dict['test_key2'] == 'test_value2'



# Generated at 2022-06-17 15:09:09.311286
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:09:20.036954
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    assert test_dict['e'] == 5
    test_dict = object_to_dict(test_obj, exclude=['a', 'c'])
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

# Generated at 2022-06-17 15:09:32.757742
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6]
    assert deduplicate_

# Generated at 2022-06-17 15:09:46.384487
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'
            self.quux = 'corge'
            self.grault = 'garply'
            self.waldo = 'fred'
            self.plugh = 'xyzzy'
            self.thud = 'wibble'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['foo'] == 'bar'
    assert test_dict['baz'] == 'qux'
    assert test_dict['quux'] == 'corge'
    assert test_dict['grault'] == 'garply'
    assert test_dict['waldo'] == 'fred'

# Generated at 2022-06-17 15:09:54.257959
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_key = 'test_value'
            self.test_key2 = 'test_value2'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_key'] == 'test_value'
    assert test_dict['test_key2'] == 'test_value2'

    test_dict = object_to_dict(test_obj, exclude=['test_key'])
    assert 'test_key' not in test_dict
    assert test_dict['test_key2'] == 'test_value2'



# Generated at 2022-06-17 15:10:00.258434
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'c', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'c', 'b', 'd', 'a', 'b', 'c', 'a', 'c', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'c', 'a', 'c', 'b', 'd', 'a', 'b', 'c', 'a', 'c', 'b', 'd', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 15:10:07.598742
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = 'test_attr1'
            self.test_attr2 = 'test_attr2'
            self.test_attr3 = 'test_attr3'
            self.test_attr4 = 'test_attr4'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr1', 'test_attr3'])
    assert test_dict['test_attr2'] == 'test_attr2'
    assert test_dict['test_attr4'] == 'test_attr4'
    assert 'test_attr1' not in test_dict
    assert 'test_attr3' not in test_dict

# Generated at 2022-06-17 15:10:15.578297
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:10:37.605074
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 6, 6, 5, 4, 7, 8, 9, 9, 8, 7]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:10:46.802316
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = "a"
            self.b = "b"
            self.c = "c"
            self.d = "d"
            self.e = "e"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['c', 'e'])
    assert test_dict['a'] == "a"
    assert test_dict['b'] == "b"
    assert 'c' not in test_dict
    assert test_dict['d'] == "d"
    assert 'e' not in test_dict

# Generated at 2022-06-17 15:10:56.719276
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:08.904705
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5])

# Generated at 2022-06-17 15:11:19.354033
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:11:27.519391
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'c', 'd', 'e', 'e', 'e', 'f', 'g', 'g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'c', 'd', 'e', 'f', 'g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']

# Generated at 2022-06-17 15:11:38.808041
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-17 15:11:45.868844
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['c', 'e'])
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert 'c' not in test_dict
    assert test_dict['d'] == 4
    assert 'e' not in test_dict
    assert test_dict['f'] == 6

# Generated at 2022-06-17 15:11:52.120498
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:00.518075
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 3, 2, 1, 4, 5, 5, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 15:12:32.725911
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr1 = "test_attr1"
            self.test_attr2 = "test_attr2"
            self.test_attr3 = "test_attr3"
            self.test_attr4 = "test_attr4"

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, exclude=['test_attr2', 'test_attr4'])
    assert test_dict['test_attr1'] == "test_attr1"
    assert 'test_attr2' not in test_dict
    assert test_dict['test_attr3'] == "test_attr3"
    assert 'test_attr4' not in test_dict

# Generated at 2022-06-17 15:12:46.422902
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert deduplicate_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-17 15:12:51.591696
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_prop = 'test_value'
            self.test_prop2 = 'test_value2'
            self.test_prop3 = 'test_value3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj, ['test_prop2'])
    assert test_dict['test_prop'] == 'test_value'
    assert 'test_prop2' not in test_dict
    assert test_dict['test_prop3'] == 'test_value3'

# Generated at 2022-06-17 15:13:00.331229
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4
    test_dict = object_to_dict(test_obj, exclude=['a', 'b'])
    assert 'a' not in test_dict
    assert 'b' not in test_dict
    assert test_dict['c'] == 3
    assert test_dict['d'] == 4

# Generated at 2022-06-17 15:13:11.892150
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'
            self.test_attr2 = 'test_attr2'
            self._test_attr3 = 'test_attr3'

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['test_attr'] == 'test_attr'
    assert test_dict['test_attr2'] == 'test_attr2'
    assert '_test_attr3' not in test_dict
    test_dict = object_to_dict(test_obj, exclude=['test_attr2'])
    assert test_dict['test_attr'] == 'test_attr'
    assert 'test_attr2' not in test_dict

# Generated at 2022-06-17 15:13:20.122342
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    deduplicated_list = deduplicate_list(original_list)
    assert dedupl

# Generated at 2022-06-17 15:13:26.297750
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 15:13:36.404373
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5])

# Generated at 2022-06-17 15:13:46.369107
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    test_obj = TestClass()
    test_dict = object_to_dict(test_obj)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert len(test_dict) == 3

    test_dict = object_to_dict(test_obj, exclude=['a'])
    assert 'a' not in test_dict
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert len(test_dict) == 2

# Generated at 2022-06-17 15:13:56.392019
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_