

# Generated at 2022-06-11 17:55:31.235957
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['test', 'test', 'test', 'pass', 'test', 'pass', 'test', 'pass', 'pass', 'fail']
    assert deduplicate_list(test_list) == ['test', 'pass', 'fail']

# Generated at 2022-06-11 17:55:35.555504
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 10
    assert pct_to_int('5%', num_items) == 1
    assert pct_to_int('5%', num_items, min_value=2) == 2
    assert pct_to_int('95%', num_items) == 9

# Generated at 2022-06-11 17:55:43.555435
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(95.5, 10) == 10
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 10, min_value=5) == 5
    assert pct_to_int('10.5%', 10) == 1
    assert pct_to_int('10.5%', 10, min_value=5) == 5



# Generated at 2022-06-11 17:55:46.219443
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('20%', 10) == 2
    assert pct_to_int(40, 10) == 40
    assert pct_to_int('40%', 0, 1) == 1

# Generated at 2022-06-11 17:55:52.339712
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test:
        arg1 = 'b'
        arg2 = 'c'

    result = object_to_dict(Test())
    assert result.has_key('arg1')
    assert not result.has_key('arg2')
    assert result.has_key('arg3')
    assert result['arg3'] == 'd'

# Generated at 2022-06-11 17:55:56.198447
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 10) == 10
    assert pct_to_int(50, 10) == 5
    assert pct_to_int(50, 10, 5) >= 5
    assert pct_to_int('10%', 10) == 1
    assert pct_to_int('10%', 1000) == 100

# Generated at 2022-06-11 17:56:00.572575
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 100) == 1
    assert pct_to_int(50, 100) == 50
    assert pct_to_int(100, 100) == 100

    assert pct_to_int(50, 100, 20) == 50
    assert pct_to_int(1, 100, 20) == 20
    assert pct_to_int(0.5, 100) == 1
    assert pct_to_int(-1, 100) == 1
    
    assert pct_to_int(100, 100, 20) == 100

# Generated at 2022-06-11 17:56:07.695435
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int("100%", 100, 1) == 100

    assert pct_to_int("100%", 50, 1) == 50

    assert pct_to_int("100%", 10, 1) == 10

    assert pct_to_int("10%", 10, 1) == 1

    assert pct_to_int("10%", 100, 1) == 10

    assert pct_to_int("1%", 1000, 1) == 10

    assert pct_to_int("0.1%", 1000, 1) == 1

# Generated at 2022-06-11 17:56:13.556504
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_orig_list = ['a', 'b', 'b', 'a', 'c', 'c', 'c', 'c', 'c']
    test_result = ['a', 'b', 'c']
    assert test_result == deduplicate_list(test_orig_list)



# Generated at 2022-06-11 17:56:21.727301
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    assert object_to_dict(TestClass(a="test_a")) == {'a': 'test_a'}
    assert object_to_dict(TestClass(a="test_a", b="test_b")) == {'a': 'test_a', 'b': 'test_b'}

    assert object_to_dict(TestClass(a="test_a", b="test_b"), exclude=["a"]) == {'b': 'test_b'}
    assert object_to_dict(TestClass(a="test_a"), exclude=["a"]) == {}
    assert object_to_dict(TestClass(a="test_a"), exclude=["a"]) == {}

# Generated at 2022-06-11 17:56:25.198680
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible.module_utils.nxos import deduplicate_list
    new_list = deduplicate_list([1, 2, 3, 4, 3, 2, 4, 1])
    assert(new_list == [1, 2, 3, 4])



# Generated at 2022-06-11 17:56:35.045751
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 2, 3, 2, 3, 2, 3, 2, 3]
    expected_list_1 = [1, 2, 3]
    expected_list_2 = [1, 3, 2]
    result_1 = deduplicate_list(original_list)
    result_2 = deduplicate_list(original_list[::-1])
    for expected_list in [expected_list_1, expected_list_2]:
        assert sorted(expected_list) == sorted(result_1)
        assert sorted(expected_list) == sorted(result_2)



# Generated at 2022-06-11 17:56:41.979201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1,2]) == [1,2]
    assert deduplicate_list([1,1,2]) == [1,2]
    assert deduplicate_list([1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1]) == [1,2]

# Generated at 2022-06-11 17:56:45.133088
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = ['b', 'a', 'a', 'b', 'c', 'c', 'a']
    assert deduplicate_list(sample_list) == ['b', 'a', 'c']

# Generated at 2022-06-11 17:56:55.994034
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    A function to test function deduplicate_list
    """

# Generated at 2022-06-11 17:57:00.731808
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['B', 'A', 'C', 'A', 'B', 'C', 'D']
    deduplicated_list = ['B', 'A', 'C', 'D']

    assert deduplicated_list == deduplicate_list(original_list)


# Generated at 2022-06-11 17:57:05.401661
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['test', 'testing', 'test', 'test']) == ['test', 'testing']
    assert deduplicate_list(['test', 'testing', 'test', 'test', 'testing']) == ['test', 'testing']

# Generated at 2022-06-11 17:57:10.197589
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 2, 1, 4, 5, 6, 5, 4]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 5, 2, 4, 5, 5, 6, 5, 4]) == [1, 2, 5, 4, 6]

# Generated at 2022-06-11 17:57:18.197889
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ["a", "b", "a", "b", "c", "d", "d"]
    list2 = ["a", "b", "c", "d"]
    list3 = ["a", "a", "a", "a", "a", "a"]
    list4 = ["a"]
    list5 = []
    assert deduplicate_list(list1) == list2
    assert deduplicate_list(list3) == list4
    assert deduplicate_list(list5) == list5

# Generated at 2022-06-11 17:57:28.781836
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'd']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b', 'd', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list(['a', 'b', 'b', 'a', 'c', 'b', 'd', 'b']) == ['a', 'b', 'c', 'd']
    assert deduplicate_list([]) == []
    assert deduplicate_list([2]) == [2]
    assert dedupl

# Generated at 2022-06-11 17:57:41.759222
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        def __init__(self):
            self.var1 = 1
            self.var2 = 2
            self.var3 = 3

        def method1(self):
            return 'method1'

    result = object_to_dict(TestClass())
    assert result['var1'] == 1
    assert result['var2'] == 2
    assert result['var3'] == 3
    assert 'method1' not in result

    result = object_to_dict(TestClass(), exclude=['var1', 'var3'])
    assert result['var2'] == 2
    assert 'var1' not in result
    assert 'var3' not in result



# Generated at 2022-06-11 17:57:49.968087
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,3,1,2,4,4,4,4,4,4]) == [1, 2, 3, 4]
    assert deduplicate_list(['1','2','3','3','3','3','3','3','3','3','2','2','2','2']) == ['1', '2', '3']
    assert deduplicate_list(['1','2','3','1','2','3','1','2','3','3','3','3','3','3']) == ['1', '2', '3']

# Generated at 2022-06-11 17:58:00.950980
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_1 = [1, 2, 3, 4, 5]
    assert deduplicate_list(list_1) == list_1

    list_2 = [1, 2, 2, 3, 4, 5, 5]
    assert deduplicate_list(list_2) == list(set(list_2))

    list_3 = [1, 2, 2, 3, 3, 3, 4, 5, 5]
    assert deduplicate_list(list_3) == list(set(list_3))

    list_4 = [4, 3, 2, 5, 2, 1, 2, 3, 3, 5]
    assert deduplicate_list(list_4) == list(set(list_4))


# Generated at 2022-06-11 17:58:05.060200
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test to ensure the deduplicate_list function works
    """
    new_list = deduplicate_list([1, 2, 5, 4, 3, 3, 5, 1, 6])
    assert new_list == [1, 2, 5, 4, 3, 6]

# Generated at 2022-06-11 17:58:10.812012
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestObj(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    t = TestObj()
    assert object_to_dict(t) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(t, ['b']) == {'a': 1, 'c': 3}

# Generated at 2022-06-11 17:58:17.740624
# Unit test for function object_to_dict
def test_object_to_dict():
    duplicate_keys = [
        'active',
        'description',
        'diff_ignore_lines',
        'failing',
        'inject',
        'module_defaults',
        'module_rules',
        'tags',
        'name',
        'no_log',
        'skip_tags',
        'start',
        'start_at_task',
        'static',
        'stops',
        'tags',
        'test_name',
    ]
    class Test(object):
        def __init__(self):
            pass
        def __setattr__(self, key, value):
            object.__setattr__(self, key, value)
        def __getattr__(self, item):
            return getattr(self, item)
    obj = Test()


# Generated at 2022-06-11 17:58:22.283053
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'a', 'a', 'a', 'c', 'd']
    dedup_list = deduplicate_list(original_list)
    assert dedup_list == ['b', 'a', 'c', 'd']

test_deduplicate_list()

# Generated at 2022-06-11 17:58:24.603689
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3, 1]) == [1, 2, 3]


# Generated at 2022-06-11 17:58:32.375683
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_attr1 = 'foo'
        test_attr2 = 'bar'
        test_attr3 = 'baz'

    obj = TestClass()
    obj.test_attr1 = 'updateme'
    obj.foo = 'bar'
    obj.bleh = 'blah'

    dict_obj = object_to_dict(obj)

    assert dict_obj['test_attr1'] == 'updateme'
    assert dict_obj['test_attr2'] == 'bar'
    assert dict_obj['test_attr3'] == 'baz'
    assert dict_obj['foo'] == 'bar'
    assert dict_obj['bleh'] == 'blah'


# Generated at 2022-06-11 17:58:37.957335
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the function deduplicate_list
    """
    list_input = ['A', 'A', 'A', 'B', 'B', 'C', 'C', 'C', 'C', 'D', 'D', 'A']
    list_expected = ['A', 'B', 'C', 'D', 'A']
    list_actual = deduplicate_list(list_input)
    assert list_expected == list_actual

# Generated at 2022-06-11 17:58:45.664393
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 4]) == [1, 2, 3, 4]
    assert deduplicate_list(('a', 'b', 'c', 'b', 'd')) == ['a', 'b', 'c', 'd']
    assert deduplicate_list([]) == []


# Generated at 2022-06-11 17:58:56.781025
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,1]) == [1,2,3]
    assert deduplicate_list([1,2,3,1,5,1,5,5]) == [1,2,3,5]
    assert deduplicate_list([1,1,2,2,3,3]) == [1,2,3]
    assert deduplicate_list([1,1,1,1]) == [1]
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'c', 'c', 'a']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:59:02.870567
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 2, 4]
    expected_list = [1, 2, 3, 4]
    assert deduplicate_list(original_list) == expected_list
    original_list = []
    expected_list = []
    assert deduplicate_list(original_list) == expected_list

if __name__ == '__main__':
    # Run unit test for function deduplicate_list when this file is run directly
    test_deduplicate_list()

# Generated at 2022-06-11 17:59:04.756214
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test = deduplicate_list(["foo","foo"])
    assert test==["foo"]

# Generated at 2022-06-11 17:59:08.311718
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ["e1", "e2", "e1", "e3"]
    deduped_list = deduplicate_list(test_list)
    assert deduped_list == ['e1', 'e2', 'e3']

# Generated at 2022-06-11 17:59:14.045376
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 4, 3, 2, 5, 6]
    deduplicated_list = deduplicate_list(test_list)
    assert sorted(deduplicated_list) == [1, 2, 3, 4, 5, 6]
    assert deduplicated_list == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-11 17:59:19.750213
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        var = 1

        def give_one(self):
            return 1

    test_object = TestClass()
    test_dict = object_to_dict(test_object)

    assert 'var' in test_dict
    assert test_dict['var'] == 1
    assert 'give_one' in test_dict
    assert test_dict['give_one']() == 1



# Generated at 2022-06-11 17:59:25.394450
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for function deduplicate_list
    """
    result = deduplicate_list([
        'one',
        'two',
        'three',
        'two',
        'three',
        'three',
        'four',
    ])
    assert result == ['one', 'two', 'three', 'four']



# Generated at 2022-06-11 17:59:31.863448
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(["10.0.2.4", "10.0.2.4", "10.0.2.4"]) == ["10.0.2.4"]
    assert deduplicate_list(["10.0.2.4", "10.0.2.4", "10.0.2.5", "10.0.2.5"]) == ["10.0.2.4", "10.0.2.5"]



# Generated at 2022-06-11 17:59:36.440396
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        var1 = 'test1'
        var2 = 'test2'
    exclude = ['var1']
    test_instance = TestClass()
    dictionary = object_to_dict(test_instance, exclude=exclude)
    assert 'var1' not in dictionary
    assert 'var2' in dictionary
    assert dictionary['var2'] == 'test2'



# Generated at 2022-06-11 17:59:52.054658
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_with_duplicates = ['alice', 'bob', 'bob', 'alice', 'rob', 'alice', 'alice', 'fletch', 'zach',
                            'bob', 'shawn', 'alice', 'shawn', 'bob', 'alice', 'bob', 'zach', 'alice']
    deduplicated_list = deduplicate_list(list_with_duplicates)
    assert len(deduplicated_list) == 7



# Generated at 2022-06-11 17:59:57.612988
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible.module_utils import basic
    original_list = ['a', 'b', 'b', 'c', 'd', 'd', 'd', 'e']
    new_list = deduplicate_list(original_list)
    basic.assert_equal(new_list, ['a', 'b', 'c', 'd', 'e'])



# Generated at 2022-06-11 18:00:03.156677
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 7, 8, 9, 1, 2, 3]
    dedup_list = deduplicate_list(original_list)
    if dedup_list != [1, 2, 3, 4, 5, 6, 7, 8, 9]:
        raise AssertionError("Test deduplicate_list failed")

# Generated at 2022-06-11 18:00:10.837266
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list_input = ['test1', 'test2', 'test3', 'test2', 'test3', 'test3', 'test1']
    deduplicate_list_expected_output = ['test1', 'test2', 'test3']

    deduplicate_list_output = deduplicate_list(deduplicate_list_input)
    assert deduplicate_list_output == deduplicate_list_expected_output


# Generated at 2022-06-11 18:00:15.232679
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    data = object_to_dict(TestClass())
    assert data['c'] == 3


# Generated at 2022-06-11 18:00:20.917569
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        attr1 = 'value1'
        attr2 = 'value1'
        attr3 = 'value1'

    class TestObjectWithExclude:
        attr1 = 'foo'
        attr2 = 'bar'
        attr3 = 'baz'

    obj = TestObject()
    test_dict = {'attr1': 'value1', 'attr2': 'value1', 'attr3': 'value1'}

    assert object_to_dict(obj) == test_dict

    obj = TestObjectWithExclude()
    exclude = ['attr2', 'attr3']

    assert object_to_dict(obj, exclude=exclude) == {'attr1': 'foo'}

# Generated at 2022-06-11 18:00:27.491140
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = ['one', 'two', 'three', 'one', 'two', 'four', 'three', 'one']
    assert deduplicate_list(list1) == ['one', 'two', 'three', 'four']
    list2 = ['1', '2', '3', '4', '5', '6']
    assert deduplicate_list(list2) == ['1', '2', '3', '4', '5', '6']

# Generated at 2022-06-11 18:00:33.477648
# Unit test for function object_to_dict
def test_object_to_dict():
    class SampleClass:
        def __init__(self):
            self.prop1 = 'value1'
            self.prop2 = 'value2'
            self.prop3 = 'value3'

    sample_class = SampleClass()

    assert object_to_dict(sample_class) == {
        'prop1': 'value1',
        'prop2': 'value2',
        'prop3': 'value3',
    }



# Generated at 2022-06-11 18:00:36.785350
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = MockObject(foo=1, bar=2, baz='three')
    result = object_to_dict(obj)
    assert result == {'foo': 1, 'bar': 2, 'baz': 'three'}



# Generated at 2022-06-11 18:00:42.429948
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list1 = ['1', '1', '2', '3', '3', '4', '5', '2']
    print("test_list1: ", test_list1)
    assert deduplicate_list(test_list1) == ['1', '2', '3', '4', '5']



# Generated at 2022-06-11 18:01:09.525522
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass():
        def __init__(self):
            self.my_property = "my value"
            self._my_private_property = 'my secret'
            self.my_other_property = [1, 2, 3]
            self.my_method = lambda x: x
    obj = MyClass()
    # Test with no excludes
    obj_dict = object_to_dict(obj)
    assert obj_dict['my_property'] == 'my value'
    assert '_my_private_property' not in obj_dict
    # Test with excludes
    obj_dict = object_to_dict(obj, exclude=['my_method'])
    assert 'my_method' not in obj_dict

# Generated at 2022-06-11 18:01:15.361895
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.username = "John Doe"
            self.password = None
            self._secret = "Secret!"
    f = Foo()
    d = object_to_dict(f)
    assert d['username'] == "John Doe"
    assert 'secret' not in d
    assert 'password' in d
    assert '_secret' not in d



# Generated at 2022-06-11 18:01:19.324069
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','c','a','d','a','b','c','e']) == ['a','b','c','d','e']
    assert deduplicate_list(['a','a','a','a','a','a','a','a','a']) == ['a']

# Generated at 2022-06-11 18:01:25.518006
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list([1, 'a', 'a', 1, 1, 2, 'a', 2]) == [1, 'a', 2]

# Generated at 2022-06-11 18:01:30.194665
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list behavior for different input lists
    """
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1]) == [1, 2]
    assert deduplicate_list([1, 1, 2, 1, 2, 1,1]) == [1, 2]

# Generated at 2022-06-11 18:01:40.692664
# Unit test for function deduplicate_list
def test_deduplicate_list():
    import unittest
    class TestDeduplicateList(unittest.TestCase):
        #pylint: disable=missing-docstring
        def test_no_duplicates(self):
            self.assertEqual(deduplicate_list(['a', 'b', 'c']), ['a', 'b', 'c'])
        def test_one_duplicate(self):
            self.assertEqual(deduplicate_list(['a', 'a', 'b']), ['a', 'b'])
        def test_multiple_duplicates(self):
            self.assertEqual(deduplicate_list(['a', 'a', 'a', 'b']), ['a', 'b'])

# Generated at 2022-06-11 18:01:47.490579
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,1,1,1,1,1,1,1]) == [1,2,1]
    assert deduplicate_list(["a","b","c","a","b","c","b","b","c","c","a","a","a"]) == ["a","b","c","b","c","a"]



# Generated at 2022-06-11 18:01:55.812131
# Unit test for function object_to_dict
def test_object_to_dict():
    # Create a test class
    class Test2(object):
        def __init__(self):
            self._private = 'private'
            self.public = 'public'
            self.private2 = 'private2'

    # Create a test object
    obj = Test2()

    # Assert an object without excludes
    assert object_to_dict(obj) == {'_private': 'private', 'public': 'public', 'private2': 'private2'}

    # Assert an object with excludes
    assert object_to_dict(obj, exclude=['private2']) == {'_private': 'private', 'public': 'public'}

# Generated at 2022-06-11 18:01:59.490419
# Unit test for function object_to_dict
def test_object_to_dict():
    class Person(object):
        name = 'Jim'
        age = 15

    person = Person()
    exclude = ['name']
    answers = dict(age=person.age)
    assert object_to_dict(person, exclude=exclude) == answers


# Generated at 2022-06-11 18:02:06.075560
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Given an input list of [2, 3, 1, 2, 4, 1]
    # When deduplicate_list is called with that input
    # Then the output list should be [2, 3, 1, 4]
    list1 = [2, 3, 1, 2, 4, 1]
    result = deduplicate_list(list1)
    expected_result = [2, 3, 1, 4]
    assert result == expected_result

# Generated at 2022-06-11 18:02:42.339097
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_to_test = ['a', 'b', 'c', 'b', 'd', 'a', 'e']

# Generated at 2022-06-11 18:02:49.168602
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'a', 'b', 'c'])
    assert result == ['a', 'b', 'c']
    result = deduplicate_list(['a', 'b', 'a', 'b', 'c', 'a'])
    assert result == ['a', 'b', 'c']
    result = deduplicate_list(['a'])
    assert result == ['a']
    result = deduplicate_list([])
    assert result == []

# Generated at 2022-06-11 18:02:54.756153
# Unit test for function deduplicate_list
def test_deduplicate_list():
    d1 = [1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 3, 2, 4, 2, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]
    d2 = deduplicate_list(d1)
    assert d2 == [1, 2, 3, 4, 5, 6]
    d3 = [1, 2, 3, 4, 5, 6]
    d4 = deduplicate_list(d3)
    assert d4 == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-11 18:03:01.820663
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert (deduplicate_list(['A', 'B', 'A', 'C', 'A', 'A', 'D']) == ['A', 'B', 'C', 'D'])
    assert (deduplicate_list([]) == [])
    assert (deduplicate_list(['A', 'B', 'C', 'D']) == ['A', 'B', 'C', 'D'])

# Generated at 2022-06-11 18:03:06.323688
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 3, 1]) == [1, 2, 3]

# Generated at 2022-06-11 18:03:10.111160
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = False
            self.b = 2

    a = A()
    d = object_to_dict(a)
    assert d['a'] == False
    assert d['b'] == 2

    d = object_to_dict(a, exclude=['a'])
    assert 'a' not in d



# Generated at 2022-06-11 18:03:14.464767
# Unit test for function deduplicate_list
def test_deduplicate_list():
    a = ['a', 'b', 'c', 'a', 'b']
    b = deduplicate_list(a)
    assert b == ['a', 'b', 'c']

# Generated at 2022-06-11 18:03:19.841538
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['c', 'a', 'a', 'b', 'b', 'c', 'a']
    assert deduplicate_list(original_list) == ['c', 'a', 'b']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list(['a','a']) == ['a']
    assert deduplicate_list(['a','b','c','a','b','c']) == ['a','b','c']



# Generated at 2022-06-11 18:03:23.984516
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,4,2,2,2,2,3,4,1]) == [1,2,4,3]
    assert deduplicate_list([1,1,1,1]) == [1]
    assert deduplicate_list([]) == []


# Generated at 2022-06-11 18:03:30.346206
# Unit test for function object_to_dict
def test_object_to_dict():
    class example_class(object):
        def __init__(self):
            self.exclude_me = "exclude_me"

        def dont_exclude_me(self):
            pass

    assert {'exclude_me': "exclude_me", 'dont_exclude_me': example_class.dont_exclude_me} == object_to_dict(example_class(), exclude=['exclude_me'])



# Generated at 2022-06-11 18:04:48.571925
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_val_1 = 1
        test_val_2 = 2
        test_val_3 = 3

    obj = TestClass()
    result = object_to_dict(obj)

    assert result['test_val_1'] == 1
    assert result['test_val_2'] == 2
    assert result['test_val_3'] == 3



# Generated at 2022-06-11 18:05:00.027932
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_1 = ['a', 'b', 'c', 'd', 'c', 'a', 'a', 'b', 'e']
    deduplicated_list_1 = deduplicate_list(list_1)
    list_2 = [1, 4, 6, 2, 8, 7, 1, 4, 6, 7, 8, 1, 3, 7, 4, 3, 6, 7, 8, 4, 1, 7, 8, 1, 4, 7]
    deduplicated_list_2 = deduplicate_list(list_2)
    if deduplicated_list_1 != ['a', 'b', 'c', 'd', 'e']:
        print("Failed")

# Generated at 2022-06-11 18:05:05.654409
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 2, 2, 2, 3]) == [1, 2, 3]
    assert deduplicate_list(['a', 'a', 'b', 'c', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list([10, -10, 0, 5, 42]) == [10, -10, 0, 5, 42]

# Generated at 2022-06-11 18:05:08.255742
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 1, 3, 4, 2, 4, 1, 5, 7, 1, 2]) == [1, 2, 3, 4, 5, 7]

# Generated at 2022-06-11 18:05:17.761725
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 2, 3, 2, 3, 4, 3, 4, 5, 4, 5, 2, 3, 2, 1, 2, 6]) == [1, 2, 3, 4, 5, 6]
    assert deduplicate_list([1, 2, 1, 2, 3, 2, 3, 4, 3, 4, 5, 4, 5, 2, 3, 2, 1, 2, 6]) != [1, 2, 4, 4, 5, 6]
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a']) == ['a']

# Generated at 2022-06-11 18:05:21.685962
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.test_attribute = 'my_test_attribute'

    test_instance = TestClass()
    assert object_to_dict(test_instance) == {'test_attribute': 'my_test_attribute'}
    assert object_to_dict(test_instance, exclude=['test_attribute']) == {}


# Generated at 2022-06-11 18:05:28.418256
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        test_key = "test_value"

    test_object = TestClass()
    test_object.second_key = "second_value"

    test_clean_dict = object_to_dict(test_object, ['second_key'])
    assert 'test_key' in test_clean_dict
    assert 'second_key' not in test_clean_dict
    assert test_clean_dict['test_key'] == 'test_value'

