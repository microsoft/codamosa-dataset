

# Generated at 2022-06-11 17:55:35.013613
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100, min_value=5) == 10
    assert pct_to_int('10%', 100, min_value=5) == 5


if __name__ == '__main__':
    pass

# Generated at 2022-06-11 17:55:44.120452
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 2, 1, 'b', 'a', 'a', 'b']
    assert deduplicate_list(original_list) == [1, 2, 3, 'b', 'a']

    original_list = [1, 2, 3, 2, 1, 'b', 'a', 'a', 'b', 'c', [1, 2, 3], [1, 2, 3], 4]
    assert deduplicate_list(original_list) == [1, 2, 3, 'b', 'a', 'c', [1, 2, 3], 4]



# Generated at 2022-06-11 17:55:50.538217
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 100, min_value=0) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10%', 100, min_value=0) == 10
    assert pct_to_int('1%', 100) == 1
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('99%', 100) == 99
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('75%', 100) == 75
    assert pct_to_int('75%', 100, min_value=1) == 75

# Generated at 2022-06-11 17:55:54.355935
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'c', 'b', 'c']) == ['a', 'c', 'b']


# Generated at 2022-06-11 17:56:05.295534
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(50, 100, min_value=5) == 50
    assert pct_to_int(50, 100, min_value=5) == 50
    assert pct_to_int('20%', 100, min_value=5) == 20
    assert pct_to_int('0%', 100, min_value=5) == 5
    assert pct_to_int('100%', 100, min_value=5) == 100
    assert pct_to_int('120%', 100, min_value=5) == 100
    assert pct_to_int(0, 100, min_value=5) == 0
    assert pct_to_int(1, 100, min_value=5) == 1
    assert pct_to_int(10, 100, min_value=5)

# Generated at 2022-06-11 17:56:13.936578
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(5, 100) == 5
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('5%', 10, min_value=0) == 0
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('25%', 10) == 3
    assert pct_to_int('25%', 9) == 3
    assert pct_to_int('25%', 9, min_value=0) == 2


# Generated at 2022-06-11 17:56:21.929406
# Unit test for function pct_to_int
def test_pct_to_int():
    assert(pct_to_int(50, 100) == 50)
    assert(pct_to_int('50%', 100) == 50)
    assert(pct_to_int(1, 1) == 1)
    assert(pct_to_int('1%', 1) == 1)
    assert(pct_to_int(0, 1) == 1)
    assert(pct_to_int('0%', 1) == 1)
    assert(pct_to_int('-1%', 1) == 1)
    assert(pct_to_int(0, 0) == 0)
    assert(pct_to_int('0%', 0) == 0)
    assert(pct_to_int(1, 0) == 0)

# Generated at 2022-06-11 17:56:30.616620
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 20) == 10
    assert pct_to_int('10%', 20) == 2
    assert pct_to_int('50%', 20) == 10
    assert pct_to_int('100%', 20) == 20
    assert pct_to_int('1000%', 20) == 20
    assert pct_to_int('10%', 2) == 1
    assert pct_to_int(10, 2) == 1
    assert pct_to_int('10%', 2, min_value=2) == 2
    assert pct_to_int('10%', 2, min_value=3) == 3



# Generated at 2022-06-11 17:56:41.757680
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list([1, 1, 2, 1, 3, 2, 1, 2, 3, 4, 1]) == [1, 2, 3, 4]
    assert deduplicate_list((1, 1, 2, 1, 3, 2, 1, 2, 3, 4, 1)) == [1, 2, 3, 4]
    assert deduplicate_list("helloworld") == ['h', 'e', 'l', 'o', 'w', 'r', 'd']
    assert deduplicate_list([None, 0, False, True]) == [None, 0, False, True]

# Generated at 2022-06-11 17:56:47.218469
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['foo', 'bar', 'foo', 'baz', 'bar']
    deduplicated_list = deduplicate_list(original_list)
    assert len(deduplicated_list) == 3
    assert deduplicated_list[0] == 'foo'
    assert deduplicated_list[1] == 'bar'
    assert deduplicated_list[2] == 'baz'

# Generated at 2022-06-11 17:56:56.317192
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj:
        foo = 'bar'
        boop = 'beep'
        this = 'that'
        baz = None
    assert object_to_dict(obj) == {'foo': 'bar', 'boop': 'beep', 'this': 'that', 'baz': None}
    assert object_to_dict(obj, exclude=['baz']) == {'foo': 'bar', 'boop': 'beep', 'this': 'that'}


# Generated at 2022-06-11 17:57:03.742917
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'c', 'a', 'a']
    deduplicated_list = deduplicate_list(original_list)

    assert(deduplicated_list[0] == 'b')
    assert(deduplicated_list[1] == 'c')
    assert(deduplicated_list[2] == 'a')
    assert(len(deduplicated_list) == 3)

# Generated at 2022-06-11 17:57:06.204851
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:57:12.856074
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 3, 1, 2, 5]) == [1, 2, 3, 5]

# Generated at 2022-06-11 17:57:20.456364
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.x = "1"
            self.y = "2"
            self.z = "3"

        def _skip(self):
            return "nope"

    to = TestObject()
    to.xx = "testing"

    dict_to = object_to_dict(to, ['z'])

    assert dict_to['x'] == "1"
    assert dict_to['y'] == "2"
    assert 'z' not in dict_to
    assert dict_to['xx'] == "testing"
    assert dict_to['_skip'] is None

# Generated at 2022-06-11 17:57:25.062609
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['b', 'a', 'c', 'a', 'd', 'd', 'a', 'b']
    deduped_list = ['b', 'a', 'c', 'd']
    assert deduplicate_list(original_list) == deduped_list

# Generated at 2022-06-11 17:57:31.092130
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self._ignore_me = 'hidden'
    obj = TestObject()
    assert object_to_dict(obj) == {'b': 'b', 'c': 'c', 'd': 'd'}
    assert object_to_dict(obj, exclude=['d']) == {'b': 'b', 'c': 'c'}


# Generated at 2022-06-11 17:57:42.230361
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert (deduplicate_list([]) == [])
    assert (deduplicate_list([1, 2, 3]) == [1, 2, 3])
    assert (deduplicate_list([1, 1, 2, 3]) == [1, 2, 3])
    assert (deduplicate_list([1, 1, 2, 2, 3]) == [1, 2, 3])
    assert (deduplicate_list([1, 1, 2, 3, 2]) == [1, 2, 3])
    assert (deduplicate_list([1, 1, 2, 3, 1]) == [1, 2, 3])
    assert (deduplicate_list([1, 1, 2, 2, 3, 3]) == [1, 2, 3])

# Generated at 2022-06-11 17:57:47.643358
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['1', '1', 'a', 'b', '2', 'c', 'b', '1', 'a', '2']
    deduplicated_list = deduplicate_list(original_list)
    assert deduplicated_list == ['1', 'a', 'b', '2', 'c']

# Generated at 2022-06-11 17:57:50.827530
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 3, 5]
    result_list = [1, 2, 3, 5]

    assert deduplicate_list(original_list) == result_list

# Generated at 2022-06-11 17:58:00.674346
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 2, 5]) == [1, 2, 3, 5]
    assert deduplicate_list([3, 1, 2, 1, 2, 5]) == [3, 1, 2, 5]
    assert deduplicate_list(['a', 'a', 'b', 'c', 'b', 'e']) == ['a', 'b', 'c', 'e']


# Generated at 2022-06-11 17:58:05.351340
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict(MockObj()) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert object_to_dict(MockObj(exclude=['a'])) == {'b': 2, 'c': 3, 'd': 4}



# Generated at 2022-06-11 17:58:09.173452
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'd', 'd', 'a', 'b']
    result_list = deduplicate_list(test_list)
    assert result_list == ['a', 'b', 'c', 'd']



# Generated at 2022-06-11 17:58:13.690022
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['A','A','B','C','D','B','E','B','C','A','C','B','A','A','C','D','F','B','A']
    assert deduplicate_list(test_list) == ['A', 'B', 'C', 'D', 'E', 'F']



# Generated at 2022-06-11 17:58:18.488516
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'c', 'a', 'b', 'a', 'c']
    test_expected_list = ['a', 'b', 'c']
    assert deduplicate_list(test_list) == test_expected_list

# Generated at 2022-06-11 17:58:21.167427
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'c', 'a']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:58:26.102881
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,2,2,3,4,5,5,6,6,7,7,8,8,8,8,9,10,11,11,12,12,13,13,13]) == [1,2,3,4,5,6,7,8,9,10,11,12,13]


# Generated at 2022-06-11 17:58:31.537947
# Unit test for function deduplicate_list
def test_deduplicate_list():
    orig_list = [1, 2, 3, 1, 4, 3, 3, 3, 5, 1]
    new_list = deduplicate_list(orig_list)

    assert len(new_list) == 5
    assert new_list[0] == 1
    assert new_list[1] == 2
    assert new_list[2] == 3
    assert new_list[3] == 4
    assert new_list[4] == 5

    assert id(orig_list) != id(new_list)



# Generated at 2022-06-11 17:58:40.697369
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1,1,1,1,2,2,2,2,2,2,2,3]) == [1,2,3]
    assert deduplicate_list([1,1,3,3,3,3,3,3,3,3,2,2,2,2,2,2,2,2]) == [1,3,2]
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'b', 'a']) == ['a', 'b']

# Generated at 2022-06-11 17:58:48.609240
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        hello = 'world'
        foo = 'bar'
        hidden = 'hidden'
    class_obj = test_class()

    dict_rep = {'hello': 'world', 'foo': 'bar'}
    assert object_to_dict(class_obj) == dict_rep
    assert object_to_dict(class_obj, ['foo']) == {'hello': 'world'}
    assert object_to_dict(class_obj, ['foo', 'hello']) == {}
    assert object_to_dict(class_obj, ['hidden']) == dict_rep

# Generated at 2022-06-11 17:59:02.529337
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
            self.z = 1
    obj = TestClass(10, 20)
    ret = object_to_dict(obj)
    assert ret['x'] == 10 and ret['z'] == 1 and 'y' in ret and len(ret) == 3
    ret = object_to_dict(obj, ['y'])
    assert 'y' not in ret and len(ret) == 2


# Generated at 2022-06-11 17:59:13.396217
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.a = 'A'
            self.b = 'B'
            self.c = 'C'
            self.d = 'D'
            self.e = 'E'
            self.f = 'F'
    obj = A()
    d = object_to_dict(obj)
    assert obj.a == d.get('a') and obj.b == d.get('b') and obj.c == d.get('c') and obj.d == d.get('d') and obj.e == d.get('e') and obj.f == d.get('f')

    d = object_to_dict(obj, exclude=['a', 'b', 'c'])

# Generated at 2022-06-11 17:59:18.728994
# Unit test for function object_to_dict
def test_object_to_dict():

    class TestObject(object):
        def __init__(self, val1, val2):
            self.val1 = val1
            self.val2 = val2

    obj = TestObject(val1="foo", val2="bar")
    assert object_to_dict(obj, ['val1']) == dict(val2="bar")



# Generated at 2022-06-11 17:59:25.573132
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        attr1 = 'value1'
        attr2 = 'value2'
        attr3 = 'value3'

    obj = Obj()
    test_dict = object_to_dict(obj)

    assert test_dict['attr1'] == 'value1'
    assert test_dict['attr2'] == 'value2'
    assert test_dict['attr3'] == 'value3'



# Generated at 2022-06-11 17:59:29.863463
# Unit test for function deduplicate_list
def test_deduplicate_list():
    ordered_list = ['apple', 'banana', 'apple', 'banana', 'cherry']
    deduplicated_list = deduplicate_list(ordered_list)
    assert deduplicated_list == ['apple', 'banana', 'cherry']


# Generated at 2022-06-11 17:59:31.741700
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'a', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:59:39.152473
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 3, 4, 3, 2]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 1, 2, 1, 2, 1, 2]) == [1, 2]
    assert deduplicate_list([1, 2, 1, 2, 3, 4, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert deduplicate_list([1, 2, 1, 2, 3, 4, 1, 2, 3, 4, 3, 3, 3, 3, 3]) == [1, 2, 3, 4]

# Generated at 2022-06-11 17:59:42.068953
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['a', 'b', 'b', 'a', 'c']
    deduped_list = deduplicate_list(test_list)
    assert deduped_list == ['a', 'b', 'c']

# Generated at 2022-06-11 17:59:48.485569
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'b', 'z', 'c', 'd', 'z', 'a', 'e', 'b']
    deduped_list = deduplicate_list(original_list)
    assert deduped_list == ['a', 'b', 'z', 'c', 'd', 'e']


# Generated at 2022-06-11 17:59:52.401058
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def new_method(self):
            return 1
        _private_method = 2

    obj = TestObject()
    result = object_to_dict(obj, ['new_method', '_private_method'])
    assert result == {}

# Generated at 2022-06-11 18:00:10.006401
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test function to test the function deduplicate_list
    """
    from copy import deepcopy

    org_list = ['a', 'b', 'c', 'a', 'd', 'b', 'c', 'a']
    org_list_copy = deepcopy(org_list)

    new_list = deduplicate_list(org_list)

    assert new_list == ['a', 'b', 'c', 'd']
    assert org_list == org_list_copy

# Generated at 2022-06-11 18:00:16.554540
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.bar = 'bar'
            self._bar = '_bar'
        def _foo(self):
            return 'foo'

    test_obj = TestObj()
    d = object_to_dict(test_obj, exclude=['_foo'])
    assert d['bar'] == 'bar'
    assert '_bar' not in d
    assert '_foo' not in d


# Generated at 2022-06-11 18:00:22.481694
# Unit test for function object_to_dict
def test_object_to_dict():
    class fakeobj():
        def __init__(self):
            self.key1 = "one"
            self.key2 = "two"

    obj = fakeobj()
    test = object_to_dict(obj)
    assert test['key1'] == "one"
    assert test['key2'] == "two"


# Generated at 2022-06-11 18:00:33.162000
# Unit test for function object_to_dict
def test_object_to_dict():
    import ansible.module_utils.basic

    test_obj = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            hello=dict(),
            foo=dict(),
        )
    )
    test_dict = {
        'hello': None,
        'foo': None,
    }
    assert test_dict == object_to_dict(test_obj)

    test_dict = {
        'hello': None,
    }
    assert test_dict == object_to_dict(test_obj, exclude=['foo'])

    test_dict = {
        'hello': None,
        'foo': None,
        '_load_params': None,
        '_check_mode': False,
    }

# Generated at 2022-06-11 18:00:41.189111
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test module for function deduplicate_list
    """

    def deduplicate_list_test(original_list, expected_results):
        result = deduplicate_list(original_list)
        assert result == expected_results, \
            "deduplicate_list failed. Expected: '{0}' Got: '{1}'".format(expected_results, result)

    deduplicate_list_test([], [])
    deduplicate_list_test([1, 2, 3], [1, 2, 3])
    deduplicate_list_test([1, 2, 3, 2, 1], [1, 2, 3])
    deduplicate_list_test(['a', 'b', 'c', 'a'], ['a', 'b', 'c'])
   

# Generated at 2022-06-11 18:00:52.565564
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestingObject():
        attr_1 = "testing attribute one"
        attr_2 = "testing attribute two"
        attr_3 = "testing attribute three"

    obj = TestingObject()
    returned_dict = object_to_dict(obj)
    expected_dict = {"attr_1": "testing attribute one", "attr_2": "testing attribute two", "attr_3": "testing attribute three"}
    assert returned_dict == expected_dict, "Expected %s but result was %s" % (expected_dict, returned_dict)
    returned_dict = object_to_dict(obj, exclude=["attr_1"])
    expected_dict = {"attr_2": "testing attribute two", "attr_3": "testing attribute three"}

# Generated at 2022-06-11 18:00:57.651621
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['one', 'two', 'three', 'two', 'one', 'three']
    deduplicated_list = deduplicate_list(test_list)
    assert(len(deduplicated_list) == 3)
    assert(deduplicated_list[1] == 'two')
    assert(deduplicated_list[2] == 'three')



# Generated at 2022-06-11 18:01:06.034308
# Unit test for function object_to_dict
def test_object_to_dict():
    try:
        import collections
        class MyClass(object):
            def __init__(self):
                self.one = 1
                self.two = 2
                self.three = 3

        result = object_to_dict(MyClass(), ['one'])
        assert isinstance(result, collections.Mapping)
        assert result['two'] == 2
        assert result['three'] == 3
        assert 'one' not in result
    except ImportError:
        # Python 2.6 and below
        pass

# Generated at 2022-06-11 18:01:09.287988
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']



# Generated at 2022-06-11 18:01:11.912857
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['foo', 'foo', 'bar', 'and', 'bar']) == ['foo', 'bar', 'and']

# Generated at 2022-06-11 18:01:53.869842
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Tests if object_to_dict() fails if no parameters are provided.
    """

    class TestClass(object):
        """
        Test class
        """

        attr1 = 'attr1'
        attr2 = 'attr2'
        attr3 = 'attr3'

        def __init__(self, attr1, attr2, attr3):
            self.attr1 = attr1
            self.attr2 = attr2
            self.attr3 = attr3


    # Create instance of TestClass
    test_obj = TestClass('attr_val1', 'attr_val2', 'attr_val3')

    # Test Object to dict conversion
    result_dict = object_to_dict(test_obj)

    assert isinstance(result_dict, dict)

# Generated at 2022-06-11 18:01:56.839987
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,3,3,3,4,4,4,4,1,1,1,1,1,1,1,]) == [1,2,3,4]

# Generated at 2022-06-11 18:02:01.943618
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['1', '1', '2', '2', '3', '4', '4']
    expected_result = ['1', '2', '3', '4']
    result = deduplicate_list(original_list)
    assert result == expected_result, "Deduplicate list function did not return expected result."


# Generated at 2022-06-11 18:02:06.443263
# Unit test for function object_to_dict
def test_object_to_dict():
    class MockObject(object):
        attr_1 = 'foo'
        attr_2 = 'bar'
        _underscore_attr_3 = 'baz'

    obj = MockObject()
    assert object_to_dict(obj, exclude=['attr_2']) == {'attr_1': 'foo'}

# Generated at 2022-06-11 18:02:12.835951
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            pass
        field1 = 'field1'
        field2 = 'field2'
    test = Test()
    d = object_to_dict(test)
    assert d['field1'] == 'field1'
    assert d['field2'] == 'field2'
    d = object_to_dict(test, ['field1'])
    assert d['field1'] != 'field1'
    assert d['field2'] == 'field2'

# Generated at 2022-06-11 18:02:20.054778
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 11]
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    result_list = deduplicate_list(original_list)
    assert(result_list == expected_list)



# Generated at 2022-06-11 18:02:23.069252
# Unit test for function deduplicate_list
def test_deduplicate_list():
    mylist = ['a', 'b', 'c', 'd', 'a', 'c', 'f', 'a']
    assert deduplicate_list(mylist) == ['a', 'b', 'c', 'd', 'f']

# Generated at 2022-06-11 18:02:25.656512
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 4, 3, 5]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-11 18:02:29.017389
# Unit test for function deduplicate_list
def test_deduplicate_list():
    t_list = ['a', 'b', 'c', 'a', 'b', 'c', 'd']
    assert deduplicate_list(t_list) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-11 18:02:37.881651
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test case to unit test function deduplicate_list
    """
    assert deduplicate_list([1,1,2,3,4,4]) == [1,2,3,4]
    assert deduplicate_list(['1','1',2,3,4,4]) == ['1',2,3,4]
    assert deduplicate_list(['1','2',2,3,4,4]) == ['1','2',3,4]
    assert deduplicate_list(['1','1',2,3,4,4,10,1]) == ['1',2,3,4,10]


# Generated at 2022-06-11 18:03:51.947952
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [["a", "b", "c", "a"], ["a", "b", "d", "e", "a"], ["b", "c", "a"]]
    expected_list = ["a", "b", "c", "d", "e"]
    assert deduplicate_list(test_list) == expected_list

# Generated at 2022-06-11 18:03:56.862110
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        """
        Test class that has two properties
        """
        def __init__(self):
            self.a = 1
            self.b = 2

    tc = TestClass()
    result = object_to_dict(tc)
    assert result == {'a': 1, 'b': 2}



# Generated at 2022-06-11 18:04:06.424504
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 4, 5, 5, 5, 1, 2, 3, 4]) == [1, 2, 3, 4, 5]
    assert deduplicate_list(['a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a', 'a']) == ['a']
    assert deduplicate_list(['a']) == ['a']
    assert deduplicate_list([]) == []


# Generated at 2022-06-11 18:04:10.959201
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """ Unit tests for function deduplicate_list. """
    # Test case 1
    list_a = ['a', 'b', 'c', 'c', 'd', 'a', 'd', 'e']
    list_b = ['a', 'b', 'c', 'd', 'e']
    assert deduplicate_list(list_a) == list_b

# Generated at 2022-06-11 18:04:16.075588
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # list with duplicates
    input_list = [1, 2, 2, 3, 2, 1]
    assert deduplicate_list(input_list) == [1, 2, 3]

    # empty list
    input_list = []
    assert deduplicate_list(input_list) == []

    # list without duplicates
    input_list = [1, 2, 3, 4]
    assert deduplicate_list(input_list) == [1, 2, 3, 4]


# Generated at 2022-06-11 18:04:27.269827
# Unit test for function object_to_dict
def test_object_to_dict():
    class my_test:
        def __init__(self):
            self.my_one = 'test1'
            self.my_two = 'test2'
            self.my_three = 'test3'

        def my_four(self):
            return "test4"

        def my_five(self):
            return "test5"

    test_obj = my_test()

    my_dict = object_to_dict(test_obj, exclude=['my_two', 'my_five'])

    # Use assertIs just to show which function we are testing
    assert test_object_to_dict, "test_object_to_dict() failed"
    assert my_dict['my_one'] == 'test1'
    assert 'my_two' not in my_dict

# Generated at 2022-06-11 18:04:29.861812
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 1, 2, 3, 4, 4]
    assert deduplicate_list(original_list) == [1, 2, 3, 4]


# Generated at 2022-06-11 18:04:39.016094
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class1(object):
        value = "test_value"

    class test_class2(object):
        value = "test_value"

        def get_private(self):
            return self._private

        def _private(self):
            return "private"

    test1 = test_class1()
    test2 = test_class2()
    result1 = object_to_dict(test1)
    assert result1.get('value') == "test_value"
    try:
        result2 = object_to_dict(test2, exclude=['get_private'])
    except AttributeError:
        assert False, "attempting to get a private method should not throw an error"
    assert result2.get('get_private') is None, "the get_private method should be excluded"

# Generated at 2022-06-11 18:04:48.434645
# Unit test for function object_to_dict
def test_object_to_dict():
    """Tests various cases for converting obejcts to dictionaries"""
    # import python libraries for unit testing
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.eos.eos import Device
    from ansible.module_utils.network.common.ios.ios import Device
    from ansible.module_utils.network.common.iosxr.iosxr import Device

    class TestObj(object):
        """Creates a test object for testing the object_to_dict method"""
        def __init__(self):
            """Instantiates test object"""
            self._test_str = "testing"
            self._second = "second"
            self.other = "other"
            self.one = "one"
            self.key = "value"

# Generated at 2022-06-11 18:04:53.711121
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1]) == [1, 2, 3, 1]
    assert deduplicate_list([1, 1, 1, 2, 1, 1, 1, 2, 3, 2, 1, 4, 3, 2, 1]) == [1, 2, 3, 4]