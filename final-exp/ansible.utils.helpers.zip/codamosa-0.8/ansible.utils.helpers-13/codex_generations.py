

# Generated at 2022-06-11 17:55:34.586795
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(1, 300) == 1
    assert pct_to_int(1.1, 300) == 1
    assert pct_to_int('1', 300) == 1
    assert pct_to_int('1.1', 300) == 1
    assert pct_to_int(1.9, 300) == 1
    assert pct_to_int('1%', 300) == 3
    assert pct_to_int('10', 300) == 10
    assert pct_to_int('1', 300, 2) == 2



# Generated at 2022-06-11 17:55:39.933229
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int('10.5%', 100) == 11
    assert pct_to_int('10.5%', 100, 2) == 2


# Generated at 2022-06-11 17:55:46.487528
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 1, 3]) == [1, 2, 3]
    assert isinstance(deduplicate_list([1, 2, 2, 1, 3]), list)

    assert deduplicate_list(['a', 'a', 'b', 'b', 'c']) == ['a', 'b', 'c']
    assert isinstance(deduplicate_list(['a', 'a', 'b', 'b', 'c']), list)

# Generated at 2022-06-11 17:55:52.390469
# Unit test for function pct_to_int
def test_pct_to_int():
    num_items = 100
    assert pct_to_int(10, num_items) == 10
    assert pct_to_int(10.0, num_items) == 10
    assert pct_to_int("10", num_items) == 10
    assert pct_to_int("10%", num_items) == 10

# Generated at 2022-06-11 17:55:58.144515
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('0%', 10) == 0
    assert pct_to_int('5%', 10) == 1
    assert pct_to_int('50%', 10) == 5
    assert pct_to_int('100%', 10) == 10
    assert pct_to_int('500%', 10) == 10
    assert pct_to_int('20%', 10, min_value=0) == 2
    assert pct_to_int('20%', 10, min_value=3) == 3

# Generated at 2022-06-11 17:56:02.757079
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('5%', 100) == 5
    assert pct_to_int('5%', 200) == 10
    assert pct_to_int(5, 200) == 5
    assert pct_to_int('5%', 2) == 1

# Generated at 2022-06-11 17:56:10.220889
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list_with_duplicates = ["item1", "item1", "item2", "item1", "item3", "item2", "item3"]
    original_list_without_duplicates = ["item1", "item2", "item3"]

    deduplicated_list = deduplicate_list(original_list_with_duplicates)

    assert len(original_list_without_duplicates) == len(deduplicated_list)
    assert len(original_list_without_duplicates) == len(set(deduplicated_list))
    for i in original_list_without_duplicates:
        assert i in deduplicated_list

# Generated at 2022-06-11 17:56:15.198697
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int('10', 100) == 10
    assert pct_to_int('50%', 100) == 50
    assert pct_to_int('50%', 100, 1) == 50
    assert pct_to_int('50%', 50, 1) == 25

# Generated at 2022-06-11 17:56:22.546754
# Unit test for function pct_to_int
def test_pct_to_int():

    # Test percentage with x100 multiplier
    assert pct_to_int("50%", 100) == 50

    # Test percentage with x100 multiplier
    assert pct_to_int("75.5%", 100) == 76

    # Test percentage with x100 multiplier
    assert pct_to_int("101%", 100) == 101

    # Test percentage with x100 multiplier
    assert pct_to_int("101%", 100, 10) == 10

    # Test percentage with x1000 multiplier
    assert pct_to_int("10%", 1000) == 100

    # Test percentage with non-integer values
    assert pct_to_int("10%", 1000.0) == 100.0

    # Test integer value
    assert pct_to_int(50, 1000.0) == 50

    # Test integer value
    assert pct

# Generated at 2022-06-11 17:56:32.629002
# Unit test for function pct_to_int
def test_pct_to_int():
    '''Tests if the function converts as expected.'''

    min_value = 1
    num_items = 100
    value_converted = pct_to_int(50, num_items, min_value)
    value_expected = 50
    assert value_converted == value_expected

    num_items = 75
    value_converted = pct_to_int('25%', num_items, min_value)
    value_expected = 19
    assert value_converted == value_expected

    num_items = 75
    value_converted = pct_to_int('3%', num_items, min_value)
    value_expected = min_value
    assert value_converted == value_expected



# Generated at 2022-06-11 17:56:36.828604
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-11 17:56:44.554570
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'c', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['c', 'a', 'b', 'c', 'c']) == ['c', 'a', 'b']
    assert deduplicate_list(['c', 'c', 'c']) == ['c']
    assert deduplicate_list(['c', 'c', 'a', 'b', 'b']) == ['c', 'a', 'b']
    assert deduplicate_list(['c', 'c', 'a', 'a', 'b']) == ['c', 'a', 'b']

# Generated at 2022-06-11 17:56:49.449214
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestOptions(object):
        def __init__(self):
            self.host = None
            self.port = None

    # Test Options object
    test_options = TestOptions()
    test_options.host = 'localhost'
    test_options.port = 22
    assert object_to_dict(test_options) == {'host': 'localhost', 'port': 22}



# Generated at 2022-06-11 17:56:58.869857
# Unit test for function deduplicate_list
def test_deduplicate_list():
    '''
    Unit test for function deduplicate_list
    '''
    # Simple list of strings
    original_list = ["A", "A", "A", "B", "B", "C", "D"]
    seen = set()
    result = [x for x in original_list if x not in seen and not seen.add(x)]
    assert result == ["A", "B", "C", "D"]

    # List of Objects, using an object with two members, one with a list

# Generated at 2022-06-11 17:57:08.534290
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Unit test for object_to_dict

    This actually just tests this module works.
    """
    class Test(object):
        def __init__(self):
            self.foo = 'bar'
            self.forty_two = 42
            self._hidden = 'hidden'
            self._and_a_number = 1

    test = Test()
    ret = object_to_dict(test, exclude=['_hidden', '_and_a_number'])
    assert all(key in ['foo', 'forty_two'] for key in ret.keys())
    assert ret['foo'] == test.foo
    assert ret['forty_two'] == test.forty_two

# Generated at 2022-06-11 17:57:19.639212
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create list and check each item to guarantee it is only in the list once
    original_list = [1, 1, 3, 2, 1, 2, 3, 2]
    deduplicated_list = deduplicate_list(original_list)
    seen = set()
    for x in deduplicated_list:
        assert(x not in seen)
        seen.add(x)

    # Create list and check each item to guarantee it is only in the list once
    original_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    deduplicated_list = deduplicate_list(original_list)
    seen = set()
    for x in deduplicated_list:
        assert(x not in seen)
        seen.add(x)



# Generated at 2022-06-11 17:57:28.155561
# Unit test for function object_to_dict
def test_object_to_dict():
    class test(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
    obj = test()
    assert object_to_dict(obj) == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert object_to_dict(obj, exclude=['a', 'b']) == {'c': 'c'}
    assert object_to_dict(obj, exclude=['d']) == {'a': 'a', 'b': 'b', 'c': 'c'}

# Generated at 2022-06-11 17:57:30.785808
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = [1, 2, 3, 2, 4, 5, 1, 6, 7, 8, 9, 10, 6]
    print(deduplicate_list(list))

test_deduplicate_list()

# Generated at 2022-06-11 17:57:42.088115
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list1 = [1, 'a']
    list2 = list1 + [1]
    list3 = list2 + list2
    list4 = list3 + [2, 1, 'a']

    assert deduplicate_list(list1) == list1
    assert deduplicate_list(list2) == list1
    assert deduplicate_list(list3) == list1
    assert deduplicate_list(list4) == list1 + [2]

    list5 = ['a', 1, 2, 3, 1, 'b', 2, 1, 2, 'a', 1, 'a', 'c']
    assert deduplicate_list(list5) == ['a', 1, 2, 3, 'b', 'c']

    list6 = [1, 2, 3, 4]
    assert dedu

# Generated at 2022-06-11 17:57:49.719060
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_with_duplicates = ['duplicate', 'unique', 'duplicate', 'unique']
    list_without_duplicates = ['unique', 'duplicate']
    new_list = deduplicate_list(list_without_duplicates)
    assert len(new_list) == len(list_without_duplicates)

    new_list = deduplicate_list(list_with_duplicates)
    assert len(new_list) == len(list_without_duplicates)

    assert new_list == list_without_duplicates


# Generated at 2022-06-11 17:58:02.242838
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test with empty list
    list1 = []
    assert deduplicate_list(list1) == []

    # Test with no duplicates
    list2 = [1]
    assert deduplicate_list(list2) == [1]

    list3 = [1, 2, 3]
    assert deduplicate_list(list3) == [1, 2, 3]

    # Test with duplicates
    list4 = [1, 1, 2, 2, 2, 3]
    assert deduplicate_list(list4) == [1, 2, 3]

    # Test with duplicates but ordered correctly
    list5 = [1, 2, 2, 3, 2]
    assert deduplicate_list(list5) == [1, 2, 3]

# Generated at 2022-06-11 17:58:04.634411
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a']) == ['a', 'b', 'c']



# Generated at 2022-06-11 17:58:08.144177
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        pass

    obj = TestObject()
    obj.attribute_one = 'test1'
    obj.attribute_two = 'test2'
    obj.attribute_three = 'test3'

    obj_dict = object_to_dict(obj, ['attribute_three'])

    result = len(obj_dict) is 2
    assert result

    result = 'attribute_three' not in obj_dict
    assert result

# Generated at 2022-06-11 17:58:13.263989
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.a = "a"
            self.b = "b"

    obj = Test()
    assert object_to_dict(obj) == {'a': 'a', 'b': 'b'}
    assert object_to_dict(obj, exclude=['a']) == {'b': 'b'}



# Generated at 2022-06-11 17:58:17.548962
# Unit test for function deduplicate_list
def test_deduplicate_list():
    listA = ['a', 'b', 'c', 'c', 'b', 'a', 'e']
    expected = ['a', 'b', 'c', 'e']
    assert deduplicate_list(listA) == expected



# Generated at 2022-06-11 17:58:22.141134
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

    obj = TestObject()
    obj_dict = object_to_dict(obj)
    assert obj_dict == {'a': 'a', 'b': 'b'}

# Generated at 2022-06-11 17:58:24.881342
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a','b','c','c','d','a','f','g','b']) == ['a','b','c','d','f','g']

# Generated at 2022-06-11 17:58:31.165462
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        def __init__(self):
            self.test_prop1 = 'test_value1'
            self.test_prop2 = 'test_value2'

    test_obj = TestObject()
    test_dict = object_to_dict(test_obj)

    assert 'test_prop1' in test_dict.keys()
    assert 'test_prop2' in test_dict.keys()
    assert 'test_value1' == test_dict['test_prop1']
    assert 'test_value2' == test_dict['test_prop2']
    assert len(test_dict) == 2

# Generated at 2022-06-11 17:58:35.824387
# Unit test for function deduplicate_list
def test_deduplicate_list():
    my_list = [1, 2, 'duplicate', 'different', 3, 3, 3, 3]
    my_list_deduped = [1, 2, 'duplicate', 'different', 3]
    assert deduplicate_list(my_list) == my_list_deduped



# Generated at 2022-06-11 17:58:38.731450
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['b', 'a', 'c', 'a', 'c', 'b']) == ['b', 'a', 'c']



# Generated at 2022-06-11 17:58:47.940760
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 17:58:57.867256
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):

        def __init__(self):
            self.prop1 = None
            self.prop2 = None
            self.prop3 = None

    obj = TestObject()
    obj.prop1 = True
    obj.prop2 = False
    obj.prop3 = "prop3"

    obj_dict = object_to_dict(obj)
    assert len(obj_dict) == 3
    assert obj_dict['prop1'] == True
    assert obj_dict['prop2'] == False
    assert obj_dict['prop3'] == "prop3"

    obj_dict = object_to_dict(obj, exclude=['prop3'])
    assert len(obj_dict) == 2
    assert obj_dict['prop1'] == True
    assert obj_dict['prop2'] == False


# Unit test

# Generated at 2022-06-11 17:58:59.926729
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['red', 'green', 'blue', 'blue', 'green']) == ['red', 'green', 'blue']

# Generated at 2022-06-11 17:59:05.556689
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test for normal scenario
    duplicated_list = [1, 2, 3, 2, 4, 2, 1]
    deduplicated_list = deduplicate_list(duplicated_list)
    assert deduplicated_list == [1, 2, 3, 4]
    # Test for empty list
    deduplicated_list = deduplicate_list([])
    assert deduplicated_list == []
    # Test for a list that contains one item only
    deduplicated_list = deduplicate_list([1])
    assert deduplicated_list == [1]

# Generated at 2022-06-11 17:59:11.525231
# Unit test for function object_to_dict
def test_object_to_dict():
    obj_class = type('obj_class', (), {'key1': 'value1', 'key2': 'value2'})
    obj = obj_class()
    result = object_to_dict(obj)
    assert sorted(result.keys()) == sorted(['key1', 'key2'])
    assert result['key1'] == 'value1'
    assert result['key2'] == 'value2'


# Generated at 2022-06-11 17:59:13.647097
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'a', 'a', 'b']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:59:19.827682
# Unit test for function object_to_dict
def test_object_to_dict():
    from collections import namedtuple
    MyObject = namedtuple('MyObject', ['a', 'b', 'c'])
    x = MyObject(a=1, b=2, c=3)
    assert object_to_dict(x) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(x, exclude=['a']) == {'b': 2, 'c': 3}

# Generated at 2022-06-11 17:59:28.909249
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Verifies that the deduplicate_list function works as expected.
    """
    test_list = [
        "a",
        "b",
        "c",
        "a",
        "b",
        "c",
        "a",
        "b",
        "c",
        "a",
        "b",
        "c",
    ]
    test_expected_output = [
        "a",
        "b",
        "c",
    ]
    assert test_expected_output == deduplicate_list(test_list)

# Generated at 2022-06-11 17:59:35.314817
# Unit test for function object_to_dict
def test_object_to_dict():
    class SimpleObj(object):
        def __init__(self):
            self.one = 1
            self.two = 2
            self.three = 3
            self.four = 4

    obj = SimpleObj()

    assert object_to_dict(obj) == dict(
        one=1,
        two=2,
        three=3,
        four=4
    )

    assert object_to_dict(obj, exclude=['one', 'two']) == dict(
        three=3,
        four=4
    )

# Generated at 2022-06-11 17:59:39.709912
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'b', 'a', 'c']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'a', 'a', 'a', 'a']) == ['a']
    assert deduplicate_list(['a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:00:00.062768
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 2, 1, 4, 3]
    deduped_list = deduplicate_list(original_list)
    assert deduped_list == [1, 2, 3, 4]

if __name__ == '__main__':
    test_deduplicate_list()

# Generated at 2022-06-11 18:00:02.342609
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list_with_duplicates = ['test1', 'test2', 'test1', 'test3', 'test1']
    assert deduplicate_list(list_with_duplicates) == ['test1', 'test2', 'test3']

# Generated at 2022-06-11 18:00:11.081775
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 1, 2, 3, 3, 3, 3, 4, 5, 1]) == [1, 2, 3, 4, 5]
    assert deduplicate_list(('a', 'a', 'b', 'c', 'c', 'c', 'c', 'd', 'e')) == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-11 18:00:13.850170
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,3,3,3,3,2,2,1,1,4]) == [1,2,3,4]

# Generated at 2022-06-11 18:00:19.217279
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['one', 'two', 'one']) == ['one', 'two']
    assert deduplicate_list(['two', 'one', 'one']) == ['two', 'one']
    assert type(deduplicate_list([4, 5, 6])) == list
    assert deduplicate_list([]) == []
    assert deduplicate_list(['x', 'test', 'x', 'test']) == ['x', 'test']



# Generated at 2022-06-11 18:00:22.162810
# Unit test for function deduplicate_list
def test_deduplicate_list():
    sample_list = [1, 2, 3, 2, 1]
    assert deduplicate_list(sample_list) == [1, 2, 3]


# Generated at 2022-06-11 18:00:26.490370
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('obj', (object,), {'prop1':1, 'prop2':2, 'prop3':3})
    dictionary = object_to_dict(obj, exclude=['prop1', 'prop2'])

    assert dictionary == {'prop3': 3}


# Generated at 2022-06-11 18:00:29.308340
# Unit test for function object_to_dict
def test_object_to_dict():
    class obj:
        a = 1
        b = 2
        c = 3
    assert object_to_dict(obj, exclude=['a']) == {'b': 2, 'c': 3}



# Generated at 2022-06-11 18:00:36.412625
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyObj(object):
        prop1 = 'prop1'
        prop2 = 'prop2'

    expected_dict = {'prop1': 'prop1', 'prop2': 'prop2'}
    actual_dict = object_to_dict(MyObj())
    assert actual_dict == expected_dict
    expected_dict = {'prop1': 'prop1'}
    actual_dict = object_to_dict(MyObj(), exclude=['prop2'])
    assert actual_dict == expected_dict



# Generated at 2022-06-11 18:00:39.752381
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ["hi", "hi", "hi", "hello", "hi", "bye", "bye", "hello", "hello", "hello", "bye"]
    expected_list = ["hi", "hello", "bye"]
    assert deduplicate_list(original_list) == expected_list

# Generated at 2022-06-11 18:01:16.878954
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(original_list=[1,2,3,3,2,1]) == [1,2,3]
    assert deduplicate_list(original_list=['a','b','c','c','c','b','a']) == ['a','b','c']
    assert deduplicate_list(original_list=[1,2,3,3,2,1,3,5,5,5,5,5,5,5,5,5,5,5,5]) == [1,2,3,5]

# Generated at 2022-06-11 18:01:28.608355
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Create a list of duplicate strings,
    original_list = ['abc', 'abc', "def", 'abc', 'ghi', "jkl", "mno", "pqr", "stu", "vwx", "jkl", "mno", "pqr", "jkl", "mno", "pqr", "stu", "vwx", "jkl", "mno", "pqr", "stu", "vwx", "jkl", "mno", "pqr", "stu", "vwx", "jkl", "mno", "pqr", "stu", "vwx"]

    # create a list of unique strings,
    unique_list = ['abc', "def", 'ghi', "jkl", "mno", "pqr", "stu", "vwx"]

    #

# Generated at 2022-06-11 18:01:39.861612
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # When original_list contains duplicate items, deduplicate_list returns a list with the first item in each
    # occurrence of a duplicate item.
    original_list_with_duplicates = [1, 2, 3, 4, 3, 2, 5, 2, 6, 2]
    deduplicated_list = deduplicate_list(original_list_with_duplicates)
    assert deduplicated_list == [1, 2, 3, 4, 5, 6]

    # When original_list contains no duplicate items, deduplicate_list returns the original_list
    original_list_with_no_duplicates = [1, 2, 3, 4, 5, 6]
    deduplicated_list = deduplicate_list(original_list_with_no_duplicates)
    assert dedu

# Generated at 2022-06-11 18:01:49.443616
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.aaa = "AAA"
            self.bbb = "BBB"
            self._ccc = "CCC"

    r = object_to_dict(TestObject())
    assert r == {'aaa': 'AAA', 'bbb': 'BBB'}
    r = object_to_dict(TestObject(), exclude=["aaa"])
    assert r == {'bbb': 'BBB'}
    r = object_to_dict(TestObject(), exclude=["aaa","bbb"])
    assert r == {}
    r = object_to_dict(TestObject(), exclude=[])
    assert r == {'aaa': 'AAA', 'bbb': 'BBB'}

# Generated at 2022-06-11 18:01:58.052815
# Unit test for function object_to_dict
def test_object_to_dict():
    class SubObj:
        key1 = 'val1'
        key2 = 'val2'
        key3 = 'val3'

    class TestObj:
        key1 = 'val1'
        key2 = 'val2'
        key3 = SubObj()

    assert object_to_dict(TestObj, exclude=['key1']) == {
        'key2': 'val2',
        'key3': SubObj,
    }

    assert object_to_dict(TestObj.key3, exclude=['key1']) == {
        'key2': 'val2',
        'key3': 'val3',
    }

    assert object_to_dict(TestObj, exclude=['key1', 'key2']) == {
        'key3': SubObj,
    }

# Generated at 2022-06-11 18:02:00.318962
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'c', 'c', 'b', 'b']) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:02:11.190518
# Unit test for function object_to_dict
def test_object_to_dict():
    """ Test object_to_dict() """
    class TestObj(object):
        """ Test object """
        def __init__(self):
            self.a = 1
            self.b = "hello"
            self.f = lambda x: x*2
    OBJ = TestObj()
    DICT = object_to_dict(OBJ)

# Generated at 2022-06-11 18:02:16.628712
# Unit test for function object_to_dict
def test_object_to_dict():
    import collections
    obj = collections.namedtuple('dict_obj', ['key1', 'key2', 'key3'], verbose=False)
    d = object_to_dict(obj, exclude=['key3'])
    assert d['key1'] == 'key1'
    assert d['key2'] == 'key2'
    assert 'key3' not in d


# Generated at 2022-06-11 18:02:22.505513
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self):
            self.name = "test"
            self.test = "test"

    obj = TestClass()

    result = object_to_dict(obj)
    answer = dict(name="test", test="test")

    assert(result == answer)


# Generated at 2022-06-11 18:02:27.562721
# Unit test for function object_to_dict
def test_object_to_dict():
    class A:
        def __init__(self):
            self.foo = "Foo"
            self.bar = "Bar"
    a = A()
    dict_a = object_to_dict(a, exclude=["bar"])
    assert dict_a == {"foo": "Foo"}
    assert "bar" not in dict_a


# Generated at 2022-06-11 18:03:35.222709
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 1, 2, 2, 3, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-11 18:03:38.629999
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list(['a', 'b', 'a', 'c', 'c', 'b']) != ['a', 'c', 'b']



# Generated at 2022-06-11 18:03:45.276690
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 3]) == [1, 2, 3]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list([1, 1, 1, 2]) == [1, 2]



# Generated at 2022-06-11 18:03:52.808710
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.one = 1
            self.two = 2
            self.three = 3
            self.four = 4
            self.five = 5
            self.six = 6

    assert object_to_dict(Test()) == {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6}

    assert object_to_dict(Test(), exclude=['one', 'two', 'three']) == {'four': 4, 'five': 5, 'six': 6}



# Generated at 2022-06-11 18:04:02.920722
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.foo = 'bar'
            self.test = 'ing'
            self._hidden = 'test'
            self.alpha = 'beta'
            self.not_excluded = 'go me'

    test_excluded = ['test', 'not_excluded']
    test_obj = TestObject()
    test_dict = object_to_dict(test_obj, test_excluded)
    assert test_dict['foo'] == 'bar'
    assert 'test' not in test_dict
    assert test_dict['_hidden'] == 'test'
    assert test_dict['alpha'] == 'beta'
    assert 'not_excluded' not in test_dict



# Generated at 2022-06-11 18:04:07.125620
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['1', '2', '3', '4', '5', '2', '2', '3', '4', '3']
    assert deduplicate_list(original_list) == ['1', '2', '3', '4', '5']

# Generated at 2022-06-11 18:04:11.434815
# Unit test for function object_to_dict
def test_object_to_dict():
    class some_obj():
        name = 'test'
        desc = 'this is a test'

    assert object_to_dict(some_obj(), exclude=['name']) == {'desc': 'this is a test'}
    assert object_to_dict(some_obj()) == {'name': 'test', 'desc': 'this is a test'}

# Generated at 2022-06-11 18:04:15.860724
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list.
    """
    original_list = ["A", "B", "A", "C", "C", "D", "A"]
    deduplicated_list = deduplicate_list(original_list)
    if deduplicated_list != ["A", "B", "C", "D"]:
        raise AssertionError("The deduplicated list is incorrect")



# Generated at 2022-06-11 18:04:18.597891
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'b', 'c', 'a']) == ['a', 'b', 'c']



# Generated at 2022-06-11 18:04:24.650587
# Unit test for function object_to_dict
def test_object_to_dict():
    class Obj(object):
        def __init__(self):
            self.foo = 1
            self.bar = 'bar'
            self._foo = 'a'
    obj = Obj()
    assert object_to_dict(obj) == {'foo': 1, 'bar': 'bar'}
    assert object_to_dict(obj, exclude=['foo']) == {'bar': 'bar'}

