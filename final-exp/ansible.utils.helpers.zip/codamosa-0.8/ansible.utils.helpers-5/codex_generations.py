

# Generated at 2022-06-11 17:55:33.549178
# Unit test for function object_to_dict
def test_object_to_dict():
    class Test(object):
        def __init__(self):
            self.var1 = 'test'
            self.var2 = 'test2'

    var3 = 'test3'
    obj = Test()
    obj.var3 = var3
    assert object_to_dict(obj) == {'var1': 'test', 'var2': 'test2', 'var3': 'test3'}
    assert object_to_dict(obj, exclude=['var1']) == {'var2': 'test2', 'var3': 'test3'}


# Generated at 2022-06-11 17:55:39.884484
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('25%', 100) == 25
    assert pct_to_int(50, 100, min_value=10) == 50
    assert pct_to_int('10%', 100, min_value=10) == 10
    assert pct_to_int(10, 100, min_value=10) == 10


# Generated at 2022-06-11 17:55:42.437076
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 100) == 10
    assert pct_to_int(10, 100) == 10



# Generated at 2022-06-11 17:55:45.983086
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(10, 100) == 10
    assert pct_to_int(10, 1000) == 100
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int('5%', 100) == 5

# Generated at 2022-06-11 17:55:51.575046
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('10%', 1000) == 100
    assert pct_to_int(10, 1000) == 10
    assert pct_to_int('120%', 1000) == 1000
    assert pct_to_int('0%', 1000) == 1


# Generated at 2022-06-11 17:55:57.732858
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Arrange
    input_list = ["first", "second", "first", "third"]
    expected_result = ["first", "second", "third"]

    # Act
    result = deduplicate_list(input_list)

    # Assert
    result = result == expected_result
    # print("Result: " + str(result))
    # print("Expected: " + str(expected_result))

# Uncomment the line below the specific function to test
# test_deduplicate_list()

# Generated at 2022-06-11 17:56:07.245752
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int('3%', 100) == 3
    assert pct_to_int('3%', 1000) == 30
    assert pct_to_int('100%', 100) == 100
    assert pct_to_int('100%', 50) == 50
    assert pct_to_int(100, 100) == 100
    assert pct_to_int(100, 50) == 100
    assert pct_to_int('3', 100) == 3
    assert pct_to_int('3', 50) == 3
    assert pct_to_int(3, 100) == 3
    assert pct_to_int(3, 50) == 3

# Generated at 2022-06-11 17:56:10.676715
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3, 2, 5]) == [1, 2, 3, 5]

# Generated at 2022-06-11 17:56:11.303234
# Unit test for function pct_to_int
def test_pct_to_int():
    pass

# Generated at 2022-06-11 17:56:19.925987
# Unit test for function pct_to_int
def test_pct_to_int():
    assert pct_to_int(20, 20) == 4
    assert pct_to_int('20', 20) == 20
    assert pct_to_int(20, 20, min_value=0) == 4
    assert pct_to_int('20%', 20, min_value=0) == 4
    assert pct_to_int('20.5%', 20, min_value=0) == 5
    assert pct_to_int('20.5%', 20, min_value=1) == 5
    assert pct_to_int('20.5%', 20, min_value=5) == 5
    assert pct_to_int('20.5%', 20, min_value=6) == 6

# Generated at 2022-06-11 17:56:32.447757
# Unit test for function object_to_dict
def test_object_to_dict():
    """
    Creating a mock object to be converted to dict
    """
    class MockObject:
        def __init__(self):
            self.var1 = 'abc'
            self.var2 = 'xyz'

    mock_obj = MockObject()
    assert object_to_dict(mock_obj) ==  {'var1': 'abc', 'var2': 'xyz'}
    assert object_to_dict(mock_obj, exclude=['var1', 'var2']) == {}
    assert object_to_dict(mock_obj, exclude=['var1']) == {'var2': 'xyz'}
    assert object_to_dict(mock_obj, exclude=['var2']) == {'var1': 'abc'}

# Generated at 2022-06-11 17:56:41.864920
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 1, 3]) == [1, 2, 3]
    assert deduplicate_list([1]) == [1]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 1]) == [1]
    assert deduplicate_list(['a', 'a', 'a', 'b']) == ['a', 'b']
    assert deduplicate_list(['a', 'b', 'a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-11 17:56:44.290070
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 1, 5, 4, 2, 1, 4]) == [1, 2, 5, 4]



# Generated at 2022-06-11 17:56:47.502839
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit tests for deduplicate_list function
    """
    test_list = [1,1,3,3,3,3,6,8,6]
    assert deduplicate_list(test_list) == [1,3,6,8]


# Generated at 2022-06-11 17:56:52.128910
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_object:
        a = 'test'
        b = 'exclude'

    assert object_to_dict(test_object) == {'a': 'test', 'b': 'exclude'}
    assert object_to_dict(test_object, exclude=['b']) == {'a': 'test'}

# Generated at 2022-06-11 17:56:56.666788
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 3, 3, 3, 5, 2, 1, 2, 5, 2, 1, 2]
    expected_result = [1, 3, 5, 2]
    actual_result = deduplicate_list(original_list)
    assert sorted(actual_result) == sorted(expected_result)

# Generated at 2022-06-11 17:57:04.593899
# Unit test for function object_to_dict
def test_object_to_dict():
    obj = type('obj', (object,), {'a': 1, 'b': 2, 'c': 3})
    assert object_to_dict(obj) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(obj, exclude=['b']) == {'a': 1, 'c': 3}
    assert object_to_dict(obj, exclude=['b', 'c']) == {'a': 1}


# Generated at 2022-06-11 17:57:09.025952
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        a = 'A'
        b = 'B'
        c = 'C'

    assert object_to_dict(TestObject()) == {'a': 'A', 'b': 'B', 'c': 'C'}
    assert object_to_dict(TestObject(), exclude=['a', 'b']) == {'c': 'C'}

# Generated at 2022-06-11 17:57:19.713271
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list_test_data = [
        { "list": [ "a", "b", "c"], "expected_return_value": [ "a", "b", "c" ] },
        { "list": [ "c", "b", "c", "a" ], "expected_return_value": [ "c", "b", "a" ] },
        { "list": [ "b", "b", "c", "c" ], "expected_return_value": [ "b", "c" ] }
    ]
    for deduplicate_list_test in deduplicate_list_test_data:
        deduplicated_list = deduplicate_list(deduplicate_list_test[ "list" ])

# Generated at 2022-06-11 17:57:25.578110
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        a = 'b'
        c = 'd'
        e = 'f'

    foo = Foo()
    assert object_to_dict(foo) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert object_to_dict(foo, exclude=['a', 'c']) == {'e': 'f'}

# Generated at 2022-06-11 17:57:33.409974
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        property1 = 'test1'
        property2 = 'test2'
        property3 = 'test3'

    obj = TestObject()

    # Test standard usage, no exclusions
    assert object_to_dict(obj) == {'property1': 'test1', 'property2': 'test2', 'property3': 'test3'}

    # Test exluding properties
    assert object_to_dict(obj, exclude=['property2']) == {'property1': 'test1', 'property3': 'test3'}

# Generated at 2022-06-11 17:57:42.235932
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject:
        test1 = 'test1'
        test2 = 'test2'
        test3 = 'test3'

    test = TestObject()
    test_dict = object_to_dict(test)
    assert test.test1 == test_dict['test1']
    assert test.test2 == test_dict['test2']
    assert test.test3 == test_dict['test3']
    test_dict = object_to_dict(test, ['test1', 'test2'])
    assert 'test1' not in test_dict
    assert 'test2' not in test_dict
    assert test.test3 == test_dict['test3']

# Generated at 2022-06-11 17:57:51.379498
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.baz = 'baz'
    obj = Foo()
    result = object_to_dict(obj)

    assert(set(result.keys()) == set(['foo', 'bar', 'baz']))
    assert(result['foo'] == 'foo')
    assert(result['bar'] == 'bar')
    assert(result['baz'] == 'baz')

    result = object_to_dict(obj, exclude=['foo', 'baz'])

    assert(set(result.keys()) == set(['bar']))
    assert(result['bar'] == 'bar')

    result = object_to_dict(obj, exclude='foo')


# Generated at 2022-06-11 17:57:57.418749
# Unit test for function deduplicate_list
def test_deduplicate_list():

    list_with_duplicates = [1, 2, 2, 2, 3, 2, 1, 2, 3, 2, 1, 3, 4]
    list_deduped = deduplicate_list(list_with_duplicates)
    assert list_deduped == [1, 2, 3, 4]

# Generated at 2022-06-11 17:58:01.495830
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list
    """
    assert deduplicate_list(['A', 'B', 'A', 'C']) == ['A', 'B', 'C']

# Generated at 2022-06-11 17:58:07.525738
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Tests the deduplicate_list function
    """
    assert deduplicate_list([1, 2, 3, 3, 3, 4, 3, 1, 4, 5, 6, 7, 7, 6, 4]) == [1, 2, 3, 4, 5, 6, 7]
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 1, 1]) == [1]

# Generated at 2022-06-11 17:58:10.957547
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,2,2,2]) == [1,2]
    assert deduplicate_list([1,2,2,2,1]) == [1,2]

# Generated at 2022-06-11 17:58:16.057434
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    with patch('ansible_collections.ansible.community.tests.unit.compat.mock.set', return_value='set') as mock_set_class:
        x = deduplicate_list(['a', 'b', 'a', 'c', 'd', 'c'])
        mock_set_class.assert_called_with()
        assert x == ['a', 'b', 'c', 'd']

# Generated at 2022-06-11 17:58:21.489179
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'b', 'a', 'c', 'b']) == ['a', 'b', 'c']
    assert deduplicate_list([]) == []
    assert deduplicate_list(['a', 'b', 'a']) == ['a', 'b']
    assert deduplicate_list(['a']) == ['a']

# Generated at 2022-06-11 17:58:24.602753
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = [1, 2, 3, 1, 2]
    expected_list = [1, 2, 3]
    assert expected_list == deduplicate_list(original_list)


# Generated at 2022-06-11 17:58:32.534211
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass:
        one = 1
        two = 2
        three = 3
        four = 4
        five = 5

    test_dict = object_to_dict(TestClass)
    assert test_dict['one'] == 1
    assert test_dict['five'] == 5
    assert len(test_dict.keys()) == 5

    test_dict_excl = object_to_dict(TestClass, ['one', 'two', 'three', 'four'])
    assert len(test_dict_excl) == 1



# Generated at 2022-06-11 17:58:37.182299
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'c', 'a', 'c', 'e', 'b']
    expected_result = ['a', 'b', 'c', 'e']
    deduplicate_result = deduplicate_list(original_list)
    assert expected_result == deduplicate_result



# Generated at 2022-06-11 17:58:41.651238
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = ['1', '2', '3', '1', '4', '4']
    dedup_list = deduplicate_list(test_list)
    assert(dedup_list == ['1', '2', '3', '4'])



# Generated at 2022-06-11 17:58:48.695585
# Unit test for function object_to_dict
def test_object_to_dict():
    # pylint: disable=missing-docstring
    from ansible.module_utils.network.common.utils import to_list

    class MockObj:
        def __init__(self):
            self.attr1 = "value1"
            self._attr2 = "value2"
            self.__attr3 = "value3"

    obj = MockObj()
    obj_dict = object_to_dict(obj, exclude=['__attr3'])
    for k in ['attr1', 'attr2']:
        assert obj_dict[k] == to_list(getattr(obj, k, None))[0]
    assert '__attr3' not in obj_dict



# Generated at 2022-06-11 17:58:52.450363
# Unit test for function deduplicate_list
def test_deduplicate_list():
    deduplicate_list(["r1", "r2", "r3", "r2", "r3", "r2", "r3", "r2"]) == ["r1", "r2", "r3"]

# Generated at 2022-06-11 17:58:57.005928
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1,1,2,2,3,4,4,4,4,4,4,4,4,4,4]) == [1,2,3,4]
    assert deduplicate_list([1,2,2,1,3,4,4,4,4,4,4,4,4,4,4]) == [1,2,3,4]

# Generated at 2022-06-11 17:59:01.856356
# Unit test for function object_to_dict
def test_object_to_dict():
    class O(object):
        a = 1
        b = 2
    o = O()

    # Should include all
    assert object_to_dict(o) == {'a': 1, 'b': 2}

    # Should exclude items in exclude
    assert object_to_dict(o, exclude=['b']) == {'a': 1, 'b': 2}

# Generated at 2022-06-11 17:59:10.772566
# Unit test for function deduplicate_list
def test_deduplicate_list():
    list = [1,2,2,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]
    list = deduplicate_list(list)
    assert list == [1,2,4,3]

# Generated at 2022-06-11 17:59:13.730257
# Unit test for function deduplicate_list
def test_deduplicate_list():
    result = deduplicate_list(['a', 'b', 'c', 'c', 'd', 'd', 'd'])
    assert(result == ['a', 'b', 'c', 'd'])

# Generated at 2022-06-11 17:59:22.618824
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObj(object):
        def __init__(self):
            self.prop1 = 1
            self.prop2 = 2
            self._hidden_prop = 3    # pylint: disable=no-member

    test_obj1 = TestObj()
    test_obj2 = TestObj()
    test_obj2.prop2 = 1
    test_obj2.prop3 = 3
    test_obj3 = TestObj()

    assert(object_to_dict(test_obj1) == {'prop1': 1, 'prop2': 2, '_hidden_prop': 3})
    assert(object_to_dict(test_obj2) == {'prop1': 1, 'prop2': 1, '_hidden_prop': 3, 'prop3': 3})

# Generated at 2022-06-11 17:59:39.026866
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestObject(object):
        def __init__(self):
            self.foo = 'test'
            self.bar = 'test2'
            self.baz = 7

    test_obj = TestObject()
    test_obj_dict = object_to_dict(test_obj)
    assert test_obj_dict['foo'] == 'test'
    assert test_obj_dict['bar'] == 'test2'
    assert test_obj_dict['baz'] == 7

    test_obj_dict = object_to_dict(test_obj, ['foo'])
    assert 'foo' not in test_obj_dict
    assert test_obj_dict['bar'] == 'test2'
    assert test_obj_dict['baz'] == 7

# Generated at 2022-06-11 17:59:40.896127
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 4, 6, 2, 5, 1]) == [1, 4, 6, 2, 5]



# Generated at 2022-06-11 17:59:51.074519
# Unit test for function object_to_dict
def test_object_to_dict():
    class test_class:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

        def class_method(self):
            return "Test Class Method"

    test_obj = test_class('A', 'B', 'C')

    assert 'a' in object_to_dict(test_obj)
    assert 'b' in object_to_dict(test_obj)
    assert 'class_method' not in object_to_dict(test_obj)
    assert 'class_method' in object_to_dict(test_obj, exclude=['c'])



# Generated at 2022-06-11 17:59:56.051694
# Unit test for function object_to_dict
def test_object_to_dict():
    class Foo(object):
        bar = 'baz'

    obj = Foo()
    d = object_to_dict(obj)
    assert d['bar'] == 'baz'
    assert len(d) == 1

    d = object_to_dict(obj, exclude=['bar'])
    assert len(d) == 0

    obj.baz = 'bizzle'
    d = object_to_dict(obj)
    assert d['baz'] == 'bizzle'



# Generated at 2022-06-11 18:00:02.121538
# Unit test for function object_to_dict
def test_object_to_dict():
    class MyClass():
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'foo'
            self.secret = 'don not show me'

    obj = MyClass()
    result = object_to_dict(obj, exclude=['secret'])
    assert('bar' == result['foo'])
    assert('foo' == result['bar'])
    assert('don not show me' != result['secret'])
    assert('secret' not in result)

# Generated at 2022-06-11 18:00:06.600643
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [1, 2, 3, 1, 2, 5]
    assert deduplicate_list(test_list) == [1, 2, 3, 5], "list deduplication failed"

# Generated at 2022-06-11 18:00:11.433835
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        def __init__(self, test_attr=None):
            self.test_attr = test_attr

    test_obj = TestClass(test_attr='test')
    result = object_to_dict(test_obj)
    assert result == {'test_attr': 'test'}, 'object to dict returned: {0}'.format(result)

# Generated at 2022-06-11 18:00:17.833798
# Unit test for function deduplicate_list
def test_deduplicate_list():
    lst = [1,2,2,3,4,4,4,4,4,4,4,4]
    assert deduplicate_list(lst) == [1,2,3,4]
    lst = ["a","b","c","c","b","a","b","c","d","e","f","d","e","f","g","g","g","g"]
    assert deduplicate_list(lst) == ["a","b","c","d","e","f","g"]


# Generated at 2022-06-11 18:00:29.164625
# Unit test for function object_to_dict
def test_object_to_dict():
    assert(object_to_dict(Bunch(a=1, b=2, c=3), ['b']) == {'a': 1, 'c': 3})
    assert(object_to_dict(Bunch(1,2,3), []) == {'1': 1, '2': 2, '3': 3})
    assert(object_to_dict(Bunch(1,2,3), [2]) == {'1': 1, '2': 2, '3': 3})
    assert(object_to_dict(Bunch(1,2,3), [1]) == {'1': 1, '3': 3})
    assert(object_to_dict(Bunch(1,2,3), [1,2]) == {'1': 1, '3': 3})

# Generated at 2022-06-11 18:00:34.042599
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list = [
        'x',
        'y',
        'z',
        'z',
        'y',
        'x',
        'w',
        'x',
        'y',
        'z'
    ]

    assert ['x', 'y', 'z', 'w'] == deduplicate_list(test_list)

# Generated at 2022-06-11 18:01:11.441296
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Unit test for function deduplicate_list()
    """
    assert deduplicate_list([1, 2, 1, 2, 1, 2]) == [1, 2, 1, 2]
    assert deduplicate_list([1, 2, 3, 4, 5, 4, 5, 4, 5, 4, 5]) == [1, 2, 3, 4, 5]
    assert deduplicate_list([1, 2, 3, 2, 3, 2, 3, 2, 3, 2, 3]) == [1, 2, 3, 2, 3]
    assert deduplicate_list(['a', 'b', 'b', 'b', 'c', 'c', 'c', 'c', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:01:17.935796
# Unit test for function deduplicate_list
def test_deduplicate_list():
    from nose.tools import assert_equal
    test_list = [
        "test1",
        "test2",
        "test1",
        "test3",
        "test4",
        "test1",
        "test4",
    ]
    expected_result_list = [
        "test1",
        "test2",
        "test3",
        "test4",
    ]
    assert_equal(expected_result_list, deduplicate_list(test_list))



# Generated at 2022-06-11 18:01:23.575057
# Unit test for function deduplicate_list
def test_deduplicate_list():

    original_list = [
        'test',
        'test',
        'test1'
    ]

    deduped_list = [
        'test',
        'test1'
    ]

    assert deduplicate_list(original_list) == deduped_list



# Generated at 2022-06-11 18:01:26.662732
# Unit test for function object_to_dict
def test_object_to_dict():
    assert object_to_dict({"test": 1}) == {"test": 1}
    assert object_to_dict(None) == {}
    assert object_to_dict(object(), exclude=["__dict__"]) == {}

# Generated at 2022-06-11 18:01:31.434595
# Unit test for function object_to_dict
def test_object_to_dict():
    class test(object):
        def __init__(self):
            self.k1 = 'foo'
            self.k2 = 'bar'
            self.k3 = 'won'

    obj_dict = object_to_dict(test())
    assert isinstance(obj_dict, dict)
    assert len(obj_dict.keys()) == 3
    assert obj_dict['k1'] == 'foo'
    assert obj_dict['k2'] == 'bar'
    assert obj_dict['k3'] == 'won'

# Generated at 2022-06-11 18:01:38.821624
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list(['a', 'a', 'b', 'b', 'c', 'a', 'b', 'd', 'e']) == ['a', 'b', 'c', 'a', 'b', 'd', 'e']
    assert deduplicate_list(['a', 'a', 'b', 'b', 'c', 'a', 'b', 'd', 'e']) != ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-11 18:01:44.434014
# Unit test for function deduplicate_list
def test_deduplicate_list():
    """
    Test for deduplicate_list function
    """
    original_list = ['a', 'b', 'c', 'a', 'c', 'b', 'a']
    expected_result = ['a', 'b', 'c']
    assert deduplicate_list(original_list) == expected_result



# Generated at 2022-06-11 18:01:53.253499
# Unit test for function object_to_dict
def test_object_to_dict():
    dummyclass = object()
    setattr(dummyclass, 'a', 1)
    setattr(dummyclass, 'b', 2)
    setattr(dummyclass, 'c', 3)
    setattr(dummyclass, '_hideaway', 4)

    assert object_to_dict(dummyclass, exclude=['_hideaway']) == {'a': 1, 'b': 2, 'c': 3}
    assert object_to_dict(dummyclass, exclude=['a']) == {'b': 2, 'c': 3, '_hideaway': 4}
    assert object_to_dict(dummyclass, exclude=['c']) == {'a': 1, 'b': 2, '_hideaway': 4}

# Generated at 2022-06-11 18:01:57.296400
# Unit test for function object_to_dict
def test_object_to_dict():
    import collections
    DummyClass = collections.namedtuple('DummyClass', ['prop1', 'prop2'])
    dummy = DummyClass(prop1='foo', prop2='bar')
    result = object_to_dict(dummy)
    assert result == {'prop1': 'foo', 'prop2': 'bar'}

# Generated at 2022-06-11 18:02:01.612345
# Unit test for function object_to_dict
def test_object_to_dict():
    class testobj(object):
        a = "foo"
        b = "bar"
    # end class testobj
    tst = object_to_dict(testobj())
    assert tst['a'] == "foo"
    assert tst['b'] == "bar"

# Generated at 2022-06-11 18:02:54.536518
# Unit test for function object_to_dict
def test_object_to_dict():
    class Object(object):
        def __init__(self):
            self.attr1 = 'attr1'
            self.attr2 = 'attr2'
            self.attr3 = 'attr3'

    obj = Object()
    assert object_to_dict(obj) == {'attr3': 'attr3', 'attr2': 'attr2', 'attr1': 'attr1'}
    assert object_to_dict(obj, exclude=['attr1', 'attr2']) == {'attr3': 'attr3'}

    class OtherObject(object):
        def __init__(self):
            self.other_attr1 = 'other_attr1'
            self.other_attr2 = 'other_attr2'
            self.other_attr3 = 'other_attr3'

    other_obj = OtherObject()

# Generated at 2022-06-11 18:03:06.277409
# Unit test for function deduplicate_list
def test_deduplicate_list():
    test_list_1 = [1, 2, 3, 2]
    test_list_2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13]

# Generated at 2022-06-11 18:03:09.418556
# Unit test for function deduplicate_list
def test_deduplicate_list():
    initial_list = ['test', 'test1', 'test3', 'test1', 'test', 'test2']
    deduplicated_list = ['test', 'test1', 'test3', 'test2']
    assert deduplicate_list(initial_list) == deduplicated_list

# Generated at 2022-06-11 18:03:19.490942
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test with different orders of items
    original_list = ['foo', 'bar', 'foo', 'baz']
    expected_list = ['foo', 'bar', 'baz']
    assert deduplicate_list(original_list) == expected_list
    original_list = ['foo', 'bar', 'baz', 'foo']
    assert deduplicate_list(original_list) == expected_list
    original_list = ['foo', 'foo', 'foo', 'foo']
    assert deduplicate_list(original_list) == ['foo']
    original_list = ['foo', 'foo', 'bar', 'baz']
    assert deduplicate_list(original_list) == ['foo', 'bar', 'baz']
    original_list = ['foo', 'foo', 'foo', 'foo']

# Generated at 2022-06-11 18:03:26.547366
# Unit test for function object_to_dict
def test_object_to_dict():
    class Client(object):
        def __init__(self, id, name):
            self.id = id
            self.name = name
            self.excluded_prop = "Excluded"

    clients = []
    client = Client(1, "Client1")
    clients.append(client)
    clients_dict = object_to_dict(client, ["excluded_prop"])
    assert not "excluded_prop" in clients_dict
    assert clients_dict["id"] == 1
    assert clients_dict["name"] == "Client1"



# Generated at 2022-06-11 18:03:37.124657
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Test case 1 - simple string list
    original_list = ['test1','test2','test1','test3','test1','test4','test2','test5']
    expected_output = ['test1','test2','test3','test4','test5']
    assert deduplicate_list(original_list) == expected_output

    # Test case 2 - dictionaries
    original_list = [{'name':'test1','value':'1'},
                     {'name':'test2','value':'2'},
                      {'name':'test1','value':'1'},
                     {'name':'test3','value':'3'}]

# Generated at 2022-06-11 18:03:41.416871
# Unit test for function object_to_dict
def test_object_to_dict():
    class TestClass(object):
        test_attr1 = 'test_attr1_value'
        test_attr2 = 'test_attr2_value'

    result = object_to_dict(TestClass())
    assert result['test_attr1'] == 'test_attr1_value'
    assert result['test_attr2'] == 'test_attr2_value'


# Generated at 2022-06-11 18:03:51.986457
# Unit test for function deduplicate_list
def test_deduplicate_list():
    # Setup
    test_order = [1, 2, 3, 4, 5]
    test_duplicate_order = [2, 4, 1, 6, 7, 8, 10, 1, 2, 1, 2, 6, 7, 8, 10]
    test_duplicate_order2 = [2, 4, 1, 6, 7, 8, 10, 1, 2, 1, 4, 7, 8, 10]

    # Test
    result = deduplicate_list(test_order)
    result2 = deduplicate_list(test_duplicate_order)
    result3 = deduplicate_list(test_duplicate_order2)

    # Verify
    assert result == test_order, "Did not retuen original list"

# Generated at 2022-06-11 18:03:55.996676
# Unit test for function deduplicate_list
def test_deduplicate_list():
    original_list = ['a', 'b', 'a', 'c', 'b']
    expected_list = ['a', 'b', 'c']
    deduplicated_list = deduplicate_list(original_list)
    assert expected_list == deduplicated_list

# Generated at 2022-06-11 18:04:02.468155
# Unit test for function deduplicate_list
def test_deduplicate_list():
    assert deduplicate_list([1, 2, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 1, 2, 2, 3, 3]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert deduplicate_list([1, 2, 1, 2, 3, 3, 2, 1]) == [1, 2, 3]