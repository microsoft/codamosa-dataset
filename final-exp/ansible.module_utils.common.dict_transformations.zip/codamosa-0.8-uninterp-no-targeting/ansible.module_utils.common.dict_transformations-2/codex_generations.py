

# Generated at 2022-06-20 15:44:29.218535
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(dict(a=1, b=2, c=3, d=dict(a=1, b=2, c=3)),
                          dict(a=1, b=2, d=dict(b=2, c=3))) == \
                          ({'c': 3, 'd': {'a': 1}, 'b': 2}, {})
    assert recursive_diff(dict(a=1, b=2, c=3),
                          dict(a=1, b=2, c=4)) == \
                          ({'c': 3}, {'c': 4})

# Generated at 2022-06-20 15:44:40.379054
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"snake_cased": "value"}) == {"snakeCased": "value"}
    assert snake_dict_to_camel_dict({"snake_cased": "value"}, True) == {"SnakeCased": "value"}
    assert snake_dict_to_camel_dict({'tags': {'key': 'value'}}) == {"tags": {"key": "value"}}
    assert snake_dict_to_camel_dict({'entry': [{'key': 'value'}, {'key2': 'value2'}]}) == {'entry': [{'key': 'value'}, {'key2': 'value2'}]}

# Generated at 2022-06-20 15:44:50.024309
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': 'foobar', 'Foo_bar': {
            'fooBar': 'foobar', 'Foo_bar': [
                'foobar', 'FOO_BAR'], 'Foo_BAR': [
                'foobar', 'FOO_bar'], 'fooBar_fooBar': {
                    'fooBar': 'foobar'}, 'fooBar_foobar': {
                    'fooBar': 'foobar'}}, 'FooBar_fooBarFooBar': {
                        'fooBar': 'foobar'}, 'fooBar_fooBar_fooBar': {
                            'fooBar': 'foobar'}}


# Generated at 2022-06-20 15:45:01.583091
# Unit test for function dict_merge
def test_dict_merge():
    '''
    Test the dict_merge function with some known examples
    '''

    # Simple dictionary merge cases
    a = {"a": "a", "b": "b"}
    b = {"a": "b", "c": "c"}
    c = {"c": "d"}
    x = dict_merge(a, b)
    assert x == {"a": "b", "b": "b", "c": "c"}
    y = dict_merge(x, c)
    assert y == {"a": "b", "b": "b", "c": "d"}

    # Nested dictionaries
    d = {"a": {"d": "d", "e": "e"}, "f": "f"}
    e = {"a": {"d": "f"}}

# Generated at 2022-06-20 15:45:07.965349
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff."""
    dict1 = {'a': {'b': 1, 'c': 2}, 'b': 2}
    dict2 = {'a': {'b': 1, 'c': 2}, 'b': 3}
    assert recursive_diff(dict1, dict2) == ({'b': 2}, {'b': 3})

    with open('/dev/null', 'w') as null:
        null.flush()


# Generated at 2022-06-20 15:45:15.586192
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "AttributeName": "Name",
        "MaximumPageSize": 1,
        "ScanFilter": {
            "Attr1": {
                "ComparisonOperator": "EQ",
                "AttributeValueList": [
                    "Attr1Value"
                ]
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)
    assert snake_dict == {
        "attribute_name": "Name",
        "maximum_page_size": 1,
        "scan_filter": {
            "attr1": {
                "comparison_operator": "EQ",
                "attribute_value_list": [
                    "Attr1Value"
                ]
            }
        }
    }
    assert camel_dict_

# Generated at 2022-06-20 15:45:26.655510
# Unit test for function recursive_diff
def test_recursive_diff():
    import collections
    import unittest

    class TestRecursiveDiff(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_normal(self):
            dict1 = {"A": {"A1": 21, "A2": 32}, "B": {"B1": "B1", "B2": ["B21", "B22"]}}
            dict2 = {"A": {"A1": 21, "A2": 33}, "B": {"B1": "B1", "B2": ["B21", "B22", "B23"]}}
            result = recursive_diff(dict1, dict2)

# Generated at 2022-06-20 15:45:35.207216
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:45:47.455928
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_input_1 = {"Id": "an-id", "Type": "standard", "Attributes": {"foo": "bar"}}
    test_input_2 = {"ResourceRecords": [{"Id": "an-id", "Type": "standard", "Attributes": {"foo": "bar"}}]}
    camel_cases = ["Id", "Type", "Attributes", "foo", "ResourceRecords", "Id", "Type", "Attributes", "foo", "bar"]
    snake_cases = ["id", "type", "attributes", "foo", "resource_records", "id", "type", "attributes", "foo", "bar"]
    assert camel_dict_to_snake_dict(test_input_1) == {"id": "an-id", "type": "standard", "attributes": {"foo": "bar"}}
    assert camel

# Generated at 2022-06-20 15:45:54.372354
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = dict()
    assert ({} == camel_dict_to_snake_dict(camel_dict))

    camel_dict = {
        "CamelList": [
            [
                "item1",
                "item2"
            ],
            [
                "item3",
                "item4"
            ]
        ],
        "CamelDict": {
            "innerCamel": "innerCamelValue"
        }
    }

# Generated at 2022-06-20 15:46:12.328577
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test empty dict
    a = {}
    b = {}
    assert recursive_diff(a, b) is None

    # Test case_a: different values in leaf nodes
    a = {
      'Banana': {
        'Price': 1,
        'Stock': 10
      },
      'Apple': {
        'Price': 1,
        'Stock': 11
      }
    }
    b = {
      'Banana': {
        'Price': 1,
        'Stock': 10
      },
      'Apple': {
        'Price': 2,
        'Stock': 11
      }
    }
    left, right = recursive_diff(a, b)
    assert (left == {'Apple': {'Price': 1}}) == True
    assert (right == {'Apple': {'Price': 2}}) == True

# Generated at 2022-06-20 15:46:16.521894
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Test to confirm that snake_to_camel_dict works correctly
    """
    snake_dict = {
        "test_key_1": "test_value_1",
        "test_key_2": "test_value_2",
        "test_key_3": {
            "inner_value_1": True,
            "inner_value_2": True,
            "inner_list": [
                {"list_key_1": "list_value_1",
                 "list_key_2": "list_value_2",
                 "list_key_3": "list_value_3"}
            ]
        }
    }


# Generated at 2022-06-20 15:46:26.785779
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff"""

    left = {"key1": {"key2": {"key3": "value1"}}}
    right = {"key1": {"key2": {"key3": "value1", "key4": "value2"}}}
    expected = None

    right = {"key1": {"key2": {"key3": "value1", "key4": "value2"}}}
    left = {"key1": {"key2": {"key3": "value1"}}}
    expected = ({'key1': {'key2': {'key4'}}}, {'key1': {'key2': {'key4': 'value2'}}})

    right = {"key1": "value1"}
    left = {"key1": {"key2": {"key3": "value1", "key4": "value2"}}}

# Generated at 2022-06-20 15:46:38.024269
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:46:45.162130
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_string = {"tags": {"test_key": "value"}}
    output_string = {"Tags": {"test_key": "value"}}
    assert snake_dict_to_camel_dict(input_string) == output_string
    input_string = {"tags": {"test_key": "value"}, "another_test_key": "value_1"}
    output_string = {"Tags": {"test_key": "value"}, "AnotherTestKey": "value_1"}
    assert snake_dict_to_camel_dict(input_string) == output_string


# Generated at 2022-06-20 15:46:52.986351
# Unit test for function dict_merge
def test_dict_merge():
    # Test 1: nesting a dict inside another dict
    a = {'top': 1, 'middle': {'inner': 'a'}, 'bottom': 3}
    b = {'top': 'a', 'middle': {'inner': 'b'}, 'bottom': 6}
    c = {'top': 'a', 'middle': {'inner': 'b'}, 'bottom': 3}
    d = {'top': 1, 'middle': {'inner': 'a'}, 'bottom': 6}

    assert dict_merge(a, b) == c
    assert dict_merge(b, a) == d

    # Test 2: overriding a dict with a str
    e = {'top': {'inner': 'a'}}
    f = {'top': 'a'}

    assert dict_merge(e, f) == f

# Generated at 2022-06-20 15:47:02.397101
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': 'foobar',
        'HTTPEndpoint': 'http_endpoint',
        'subObject': {
            'fooBar': 'foobar',
            'HTTPEndpoint': 'http_endpoint'
        },
        'subObjectList': [{
            'fooBar': 'foobar',
            'HTTPEndpoint': 'http_endpoint'
        }]
    }

# Generated at 2022-06-20 15:47:12.035576
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        "name": "test",
        "data": {
            "key1": 1,
            "key2": "str",
            "key3": [1, 2, 3]
        }
    }
    right = {
        "name": "test",
        "data": {
            "key1": 4,
            "key2": "str",
            "key3": [1, 2, 3]
        }
    }
    result = recursive_diff(left, right)
    assert result == ({'data': {'key1': 1}}, {'data': {'key1': 4}})

# Generated at 2022-06-20 15:47:22.297828
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict(
        {
            'tags': {
                'Name': 'foo',
                'owner': 'bar'
            }
        }
    ) == {
        'Tags': {
            'Name': 'foo',
            'owner': 'bar'
        }
    }


# Generated at 2022-06-20 15:47:27.721178
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': '1', 'b': {'c': '2'}}
    b = {'a': '3', 'b': {'d': '4'}}
    expected = {'a': '3', 'b': {'c': '2', 'd': '4'}}
    assert dict_merge(a, b) == expected


# Generated at 2022-06-20 15:47:41.499083
# Unit test for function dict_merge
def test_dict_merge():
    '''
    Validate dict_merge()
    :return:
    '''
    a = {'key1': {'key2': 'value1', 'key3': 'value2'}, 'key6': 'value6'}
    b = {'key1': {'key2': 'value3', 'key4': 'value4'}, 'key5': 'value5'}
    c = dict_merge(a, b)
    assert c['key1']['key2'] == b['key1']['key2']
    assert 'key3' in c['key1']
    assert 'key4' in c['key1']
    assert c['key6'] == 'value6'
    assert c['key5'] == 'value5'



# Generated at 2022-06-20 15:47:49.836797
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test camel_dict_to_snake_dict"""

    alb_tags = [
        {
            "Value": "Test-ALB",
            "Key": "Name"
        },
        {
            "Value": "Ansible",
            "Key": "Role"
        },
        {
            "Value": "Yes",
            "Key": "Test"
        }
    ]

    alb_config = {
        "Internal": True,
        "Name": "Test-ALB",
        "IpAddressType": "ipv4",
        "SecurityGroups": [
            "sg-xxxxxxxx"
        ],
        "Subnets": [
            "subnet-xxxxxxxx",
            "subnet-xxxxxxxx"
        ],
        "Tags": alb_tags
    }


# Generated at 2022-06-20 15:47:54.517802
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:48:05.331329
# Unit test for function recursive_diff
def test_recursive_diff():
    import unittest
    import sys

    class TestRecursiveDiffFunction(unittest.TestCase):
        """
        This class will use the `unittest` framework to test the recursive_diff function.
        """
        def _arun(self, dict1, dict2, expected_results):
            """
            This function allows us to run the test for arbitrary dicts.
            """
            try:
                results = recursive_diff(dict1, dict2)
            except Exception as e:
                err_msg = "An exception was raised while testing this case:\n\t" \
                          "dict1: {}\n\t" \
                          "dict2: {}\n\t" \
                          "The exception was: {}\n" \
                          "".format(dict1, dict2, e)
                self.fail

# Generated at 2022-06-20 15:48:16.621891
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test positive case
    dict1 = {
              'a': 'value1',
              'b': {
                    'c': 'value3',
                    'd': {
                          'e': 'value5',
                          'f': 'value6',
                          'g': {
                                'foo': 'value7',
                                'baz': 'value8'
                                },
                          'h': 'value9'
                        }
                    },
              'i': 'value10'
            }


# Generated at 2022-06-20 15:48:28.229019
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TestDict': {'TestTest': 'asdf', 'TestTest2': 'qwerty'}}
    assert camel_dict_to_snake_dict(camel_dict) == {'test_dict': {'test_test': 'asdf', 'test_test2': 'qwerty'}}
    assert camel_dict_to_snake_dict(camel_dict_to_snake_dict(camel_dict)) == {'test_dict': {'test_test': 'asdf', 'test_test2': 'qwerty'}}
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == {'test_dict': {'test__test': 'asdf', 'test__test2': 'qwerty'}}
    assert camel_dict_to

# Generated at 2022-06-20 15:48:35.187262
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz'}) == {'fooBar': 'baz'}
    assert snake_dict_to_camel_dict({'foo_bar': [{'hello_world': 'quux'}]}) == {'fooBar': [{'helloWorld': 'quux'}]}
    assert snake_dict_to_camel_dict({'foo_bar': [{'hello_world': [{'hello_world': 'quux'}]}]}) == {'fooBar': [{'helloWorld': [{'helloWorld': 'quux'}]}]}

# Generated at 2022-06-20 15:48:47.115548
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {'a': 1, 'b': {'c': 2}, 'h': {'d': {'q': 4}}}
    d2 = {'a': 2, 'b': {'d': 3}, 'h': {'e': 5}}
    d3 = {}

    d1_and_2 = {'a': 2, 'b': {'c': 2, 'd': 3}, 'h': {'d': {'q': 4}, 'e': 5}}
    empty = {}

    assert d1_and_2 == dict_merge(d1, d2)
    assert d1_and_2 == dict_merge(d2, d1)
    assert empty == dict_merge(d3, d3)
    assert empty == dict_merge(d3, empty)
    assert empty == dict_

# Generated at 2022-06-20 15:48:58.392587
# Unit test for function recursive_diff
def test_recursive_diff():
    def check(d1, d2, expected):
        result = recursive_diff(d1, d2)
        if result != expected:
            raise AssertionError("Dictionaries d1=%s and d2=%s have diff %s but expected %s" %
                                 (d1, d2, result, expected))
    check({}, {}, None)
    check({}, {'a': 1}, ({'a': 1}, {}))
    check({'a': 1}, {}, ({}, {'a': 1}))
    check({'a': 1}, {'a': 2}, ({'a': 1}, {'a': 2}))
    check({'a': 1}, {'a': 1, 'b': 2}, ({'b': 2}, {}))

# Generated at 2022-06-20 15:49:08.340900
# Unit test for function dict_merge
def test_dict_merge():
    d1 = { "key1" : "old value",
           "key2" : "old value",
           "key3" : "old value"
    }

    d2 = { "key2" : "new value",
           "key3" : {
               "key5" : "old value",
           },
           "key4" : "new value"
    }

    d3 = { "key3" : {
               "key5" : "new value",
           }
    }

    result = dict_merge(d1, d2)
    assert result["key1"] == "old value"
    assert result["key2"] == "new value"
    assert result["key3"]["key5"] == "old value"
    assert result["key4"] == "new value"

    result = dict_merge

# Generated at 2022-06-20 15:49:17.268750
# Unit test for function recursive_diff
def test_recursive_diff():
    initial_dict = {
        'a': 'A',
        'b': {
            'c': ['C', 'D']
        },
        'e': 'E'
    }
    changed_dict = {
        'a': 'A',
        'b': {
            'c': ['C', 'F']
        }
    }
    diff_result = {
        'e': 'E',
        'b': {
            'c': [1, 'F']
        }
    }
    assert(recursive_diff(initial_dict, changed_dict) == (None, diff_result))

# Generated at 2022-06-20 15:49:21.430422
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "tags": [
            {
                "key": "foo",
                "value": "bar"
            }
        ],
        "public": True,
        "test_value": "test"
    }

    camel_dict = {
        "Tags": [
            {
                "Key": "foo",
                "Value": "bar"
            }
        ],
        "Public": True,
        "TestValue": "test"
    }

    assert snake_dict_to_camel_dict(snake_dict) == camel_dict


# Generated at 2022-06-20 15:49:31.840418
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """A simple test to find out if camel_dict_to_snake_dict is working as expected."""
    
    # Test CamelCase to snake_case

# Generated at 2022-06-20 15:49:43.196175
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar':'baz'}) == {'foo_bar':'baz'}
    assert camel_dict_to_snake_dict({'FooBar':'baz'}, reversible=True) == {'f_o_o_bar':'baz'}
    assert camel_dict_to_snake_dict({'FooBar':{'BamBaz':'foo'}}) == {'foo_bar':{'bam_baz':'foo'}}
    assert camel_dict_to_snake_dict({'FooBar':{'BamBaz':'foo'}}, reversible=True) == {'f_o_o_bar':{'b_a_m_baz':'foo'}}
    assert camel_dict_to_

# Generated at 2022-06-20 15:49:45.769965
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.common.dict_merge_test import test_dict_merge

    test_dict_merge()

# Generated at 2022-06-20 15:49:55.342218
# Unit test for function dict_merge
def test_dict_merge():
    one = {'a': {'b': 'c', 'd': 'e'}}
    two = {'a': {'b': 'f', 'g': 'h'}}
    merged = one.copy()
    merged['a'].update(two['a'])
    assert merged == {'a': {'b': 'f', 'd': 'e', 'g': 'h'}}
    assert dict_merge(one, two) == merged
    try:
        dict_merge(one, "foo")
    except TypeError:
        print("dict_merge correctly raises exception when given an argument that isn't a dict")
    else:
        print("dict_merge failed to raise exception when given an argument that isn't a dict")



# Generated at 2022-06-20 15:50:02.028655
# Unit test for function dict_merge
def test_dict_merge():
    target_dict = {
        'a':1,
        'b':2,
        'c':3,
        'd': {
            'e':4,
            'f':5
        }
    }
    merge_dict = {
        'a':1,
        'b':4,
        'd': {
            'e':4,
            'f':6
        }
    }
    result_dict = dict_merge(target_dict, merge_dict)
    assert result_dict['a'] == 1
    assert result_dict['b'] == 4
    assert result_dict['c'] == 3
    assert result_dict['d']['e'] == 4
    assert result_dict['d']['f'] == 6
    return

# Generated at 2022-06-20 15:50:11.968712
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:50:21.647183
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:50:31.304285
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'a1': 1, 'a2': 2}, 'b': 1, 'c': 5}
    d2 = {'a': {'a3': 3, 'a4': 4}, 'e': 7}
    d3 = {'a': {'a5': {'a6': 6}}, 'b': 1, 'f': 7}
    d4 = {'a': {'a1': 1, 'a2': 2}, 'b': 1, 'c': 6}
    d5 = {'a': {'a1': 1, 'a2': 2}, 'b': 1, 'c': 5, 'd': None}

# Generated at 2022-06-20 15:50:46.237789
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping

    # Test for merging two empty dicts
    a = {}
    b = {}
    assert dict_merge(a, b) == {}

    # Test for merging an empty dict and a non-empty dict
    a = {"key": {"subkey": "val"}}
    b = {}
    assert dict_merge(a, b) == a

    # Test for merging a non-empty dict and an empty dict
    a = {}
    b = {"key": {"subkey": "val"}}
    assert dict_merge(a, b) == b

    # Test for merging a non-empty dict and another non-empty dict with no overlap
    a = {"key1": {"subkey1": "val1"}}

# Generated at 2022-06-20 15:50:56.810591
# Unit test for function dict_merge
def test_dict_merge():

    assert dict_merge({}, {}) == {}

    assert dict_merge({'a': 1}, {}) == {'a': 1}
    assert dict_merge({}, {'a': 1}) == {'a': 1}

    assert dict_merge({'a': 1}, {'a': 1}) == {'a': 1}
    assert dict_merge({'a': 1}, {'a': 2}) == {'a': 2}

    assert dict_merge({'a': 1}, {'a': None}) == {'a': None}
    assert dict_merge({'a': None}, {'a': 1}) == {'a': 1}
    assert dict_merge({'a': None}, {'a': None}) == {'a': None}

# Generated at 2022-06-20 15:51:08.772808
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Tests for function recursive_diff.
    """
    # Test for simple case with key not in left and key not in right
    d1 = {'key1': 'val1', 'key2': 'val2'}
    d2 = {'key2': 'val2', 'key3': 'val3'}
    r = recursive_diff(d1, d2)
    assert r is not None
    assert len(r) == 2
    assert len(r[0]) == 1
    assert len(r[1]) == 1
    assert r[0]['key1'] == 'val1'
    assert r[1]['key3'] == 'val3'

    # Test for simple case with key in left and key in right with same value
    # but different types

# Generated at 2022-06-20 15:51:16.234811
# Unit test for function dict_merge
def test_dict_merge():
    a = {'B': {'C': 1, 'e': 3}, 'F': 5}
    b = {'B': {'c': 2, 'd': 4}, 'g': 6}
    c = {'B': {'C': 1, 'c': 2, 'e': 3, 'd': 4}, 'F': 5, 'g': 6}
    assert(dict_merge(a, b) == c)

# Generated at 2022-06-20 15:51:26.448965
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'key1': 'value1', 'key2': {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}}
    d2 = {'key1': 'value1', 'key2': {'subkey2': 'subvalue2', 'subkey3': 'subvalue3'}}
    d3 = dict_merge(d1, d2)

    assert d1 == {'key1': 'value1', 'key2': {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}}
    assert d2 == {'key1': 'value1', 'key2': {'subkey2': 'subvalue2', 'subkey3': 'subvalue3'}}

# Generated at 2022-06-20 15:51:32.896549
# Unit test for function dict_merge
def test_dict_merge():
    """ Simple dict_merge test """

    a = {'hello': 1, 'world': 1}
    b = {'world': 0, 'foo': 2}
    c = dict_merge(a, b)
    assert c == {'hello': 1, 'world': 0, 'foo': 2}

    a = {'hello': 1, 'world': 1}
    b = {'world': 0, 'foo': 2}
    c = dict_merge(b, a)
    assert c == {'hello': 1, 'world': 1, 'foo': 2}

    a = {'hello': [1, 2, 3], 'world': {'foo': 1, 'bar': 2}}
    b = {'hello': [4, 5, 6], 'world': {'foo': 0, 'bar': 1}}

# Generated at 2022-06-20 15:51:38.312975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test = {'fooBar': 42, 'bazQuux': {'fooBar': 42, 'baz': 42}}
    result = {'foo_bar': 42, 'baz_quux': {'foo_bar': 42, 'baz': 42}}
    assert camel_dict_to_snake_dict(test) == result


# Generated at 2022-06-20 15:51:46.109977
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    result = snake_dict_to_camel_dict({"one_two_three": 4, "another_key": 5}, capitalize_first=True)
    assert result == {"OneTwoThree": 4, "AnotherKey": 5}

    result = snake_dict_to_camel_dict({"one_two_three": 4, "another_key": 5}, capitalize_first=False)
    assert result == {"oneTwoThree": 4, "anotherKey": 5}

    result = snake_dict_to_camel_dict({"one_two_three": [{"four_five": 6}]}, capitalize_first=True)
    assert result == {"OneTwoThree": [{"FourFive": 6}]}


# Generated at 2022-06-20 15:51:55.707698
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 'string', 'b': 4, 'c': {'d': 'value'}}
    dict2 = {'a': 'string', 'c': {'e': 'value2'}, 'd': [1, 2]}
    dict3 = {'a': 'string1', 'b': 4, 'c': {'d': 'value'}}
    dict4 = {'a': 'string', 'b': 4, 'c': {'d': 'value', 'f': 'value3'}}
    dict5 = {'a': 'string', 'c': {'d': 'value', 'e': 'value2'}, 'd': [1, 2]}
    dict6 = {'a': 'string', 'b': 4, 'c': {'d': 'value'}, 'd': [1, 2]}
   

# Generated at 2022-06-20 15:52:06.859607
# Unit test for function recursive_diff
def test_recursive_diff():

    def test_result(dict1, dict2, expected_result):
        actual_result = recursive_diff(dict1, dict2)
        assert actual_result == expected_result, \
            "recursive_diff: Expected %s, got %s" % (expected_result, actual_result)

    # Check for exceptions
    try:
        result = recursive_diff("a", "b")
        assert result is None, \
            "recursive_diff: TypeError not raised"
    except TypeError:
        pass

    test_result({'a': 1, 'b': 2}, {'a': 1, 'b': 3}, ({}, {'b': 3}))

# Generated at 2022-06-20 15:52:24.455758
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'camelCase': {'dromedary': 'value'}} == snake_dict_to_camel_dict({'camel_case': {'dromedary': 'value'}})
    assert {'CamelCase': {'dromedary': 'value'}} == snake_dict_to_camel_dict({'camel_case': {'dromedary': 'value'}}, capitalize_first=True)
    assert {'camelCase': {'dromedary': [{'moreCamelCase': 'value'}]}} == snake_dict_to_camel_dict({'camel_case': {'dromedary': [{'more_camel_case': 'value'}]}})



# Generated at 2022-06-20 15:52:32.543789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'keyword1': 'value1',
        'Keyword2': 'value2',
        'URL': 'value3',
        'tag': {
            'name': 'tag1',
        },
        'ranDomization': False,
    }
    expected = {
        'keyword1': 'value1',
        'keyword2': 'value2',
        'url': 'value3',
        'tag': {
            'name': 'tag1',
        },
        'randomization': False,
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected


# Generated at 2022-06-20 15:52:43.937399
# Unit test for function dict_merge
def test_dict_merge():
    '''Returns a dictionary of lists of dictionaries used for unittests'''
    test_dict = dict()

    test_dict['dict1'] = dict()
    test_dict['dict1']['key1'] = 'value1'

    test_dict['dict2'] = dict()
    test_dict['dict2']['key1'] = 'value1'
    test_dict['dict2']['key2'] = 'value2'

    test_dict['dict3'] = dict()
    test_dict['dict3']['key1'] = 'value1'
    test_dict['dict3']['dict1'] = dict()
    test_dict['dict3']['dict1']['key1'] = 'value1'

    test_dict['dict4'] = dict()

# Generated at 2022-06-20 15:52:55.504404
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.common.collections import ImmutableDict
    a = ImmutableDict({'a': {'b': {'foo': 'foo'}}})
    b = ImmutableDict({'a': {'b': {'bar': 'bar', 'qux': 'qux'}}})
    c = ImmutableDict({'a': {'c': {'bar': 'bar', 'qux': 'qux'}}})
    d = ImmutableDict({'a': {'b': {'baz': 'baz'}}})
    e = ImmutableDict({'a': {'b': {'foo': 'bar'}}})

    # Merge dicts "a" and "b"
    result = dict_merge(a, b)

# Generated at 2022-06-20 15:53:07.659768
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:53:19.329735
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'foo_bar': {
            'baz_bing': 'hootie_hoo',
            'bazzing_bung': ['jack_hammer', 'cap_gun', 'ice_cream'],
            'cat_dog': [{'a_b': 'c_d'}]
        }
    }

    expected_output = {
        'FooBar': {
            'BazBing': 'hootie_hoo',
            'BazzingBung': ['jack_hammer', 'cap_gun', 'ice_cream'],
            'CatDog': [{'A_b': 'c_d'}]
        }
    }
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=True) == expected_output

    expected_output2

# Generated at 2022-06-20 15:53:26.127386
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {'a': 1, 'b': 2, 'c': {'d': {'e': 1}, 'f': [1,2,3]}, 'g': [1,2,3]}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': {'e': 3}, 'f': [1,3,3]}, 'g': [1,3,3]}

    # Test match
    test_dict1 = {'a': 1, 'b': 2}
    test_dict2 = {'b': 2, 'a': 1}

    # Test different values
    test_dict3 = {'a': 1, 'b': 2}
    test_dict4 = {'a': 1, 'b': 3}

    # Test different keys

# Generated at 2022-06-20 15:53:32.683631
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:53:42.585088
# Unit test for function dict_merge
def test_dict_merge():

    from pprint import pprint

    a = {
        'blue': 'red',
        'color': {
            'green': 'pink',
            'purple': 'yellow',
            'orange': 'brown'
        },
        'dog': {
            'black': 'white',
            'tan': 'grey'
        }
    }

    b = {
        'color': {
            'green': 'yellow',
            'purple': 'pink'
        },
        'dog': {
            'black': 'brown',
            'grey': 'tan'
        },
        'cat': 'dog'
    }

    # this is the expected result from merging dict a with dict b

# Generated at 2022-06-20 15:53:51.755900
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(one=1, two=dict(a='a0', b='b0'))
    b = dict(two=dict(b='b1', c='c1'), three=dict(a='a1', b='b1'))
    result = dict_merge(a, b)
    expected = dict(one=1, two=dict(a='a0', b='b1', c='c1'),
                    three=dict(a='a1', b='b1'))
    assert result == expected
    assert isinstance(result, dict)
    # if commented out, will fail test
    assert isinstance(result['two'], dict)
    assert isinstance(result['three'], dict)