

# Generated at 2022-06-20 15:44:22.275925
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'key_with_underscores': {'list_of_things': [{'a': 'b'}]}}) \
      == {'keyWithUnderscores': {'listOfThings': [{'a': 'b'}]}}
    assert snake_dict_to_camel_dict({'key_with_underscores': {'list_of_things': [{'a': 'b'}]}}, capitalize_first=True) \
      == {'KeyWithUnderscores': {'ListOfThings': [{'A': 'b'}]}}


# Generated at 2022-06-20 15:44:29.289255
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=1,b=dict(c=3,d=4))
    b = dict(a=2,b=dict(c=6,e=7))
    c = dict_merge(a,b)
    assert c == dict(a=2,b=dict(c=6,d=4,e=7))
    a = dict(a=1,b=dict(c=3,d=4))
    b = dict(a=2,b=dict(c=6,d=4,e=7))
    assert a == b

# Generated at 2022-06-20 15:44:40.377928
# Unit test for function dict_merge
def test_dict_merge():
    # Tests taken from https://github.com/SethMichaelLarson/ansible-merge-vars/blob/master/tests/test_merge.py
    d1 = {'a': 1, 'b': 2}
    d2 = {'b': 3, 'c': 4, 'd': 5}
    expected = {'a': 1, 'b': 3, 'c': 4, 'd': 5}
    merged = dict_merge(d1, d2)
    assert expected == merged, "Result of dict_merge incorrect. Expected %s, got %s" % (expected, merged)

    # test dict merging
    d1 = {'a': {'b': 1}}
    d2 = {'a': {'c': 2}, 'd': {'e': 3}}

# Generated at 2022-06-20 15:44:50.023896
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    cli_dict = {
                'tags': {'some-key': 'some-value'},
                'account_id': 123456789012,
                'name': 'test-flow-logs',
                'resource_type': 'VPC',
                'resource_ids': ['vpc-c9c9bbb8'],
                'traffic_type': 'ACCEPT',
                'log_destination': 'arn:aws:s3:::my-cloudwatch-logs',
                'log_destination_type': 's3'
            }

# Generated at 2022-06-20 15:44:54.535819
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}

    c = dict_merge(a, b)

    # Check that values in both a and b have been merged properly
    assert c['a'] == 1
    assert c['c'] == 3

    # Check that the merging has been recursive, not just simple a['key'] = b['key']
    assert c['b'][1] == 1
    assert c['b'][2] == 7

    # Check that the merging has been recursive, not just simple a['key'] = b['key']
    assert c['d']['z'][0] == 1

# Generated at 2022-06-20 15:45:04.037256
# Unit test for function dict_merge
def test_dict_merge():
    print("Testing dict_merge")

    a = {"a": {"x": 1, "y": 2}}
    b = {"a": {"z": 3}, "b": 4}
    c = {"a": [1, 2, 3]}

    assert dict_merge(a, b) == {'a': {'x': 1, 'y': 2, 'z': 3}, 'b': 4}
    assert dict_merge(a, c) == {'a': [1, 2, 3]}
    assert dict_merge(a, {}) == {'a': {'x': 1, 'y': 2}}
    assert dict_merge(a, b) != {'a': {'z': 3, 'y': 2, 'x': 1}, 'b': 4}



# Generated at 2022-06-20 15:45:12.919730
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict1 = {'a': {'b': 1, 'c': 2, 'd': None},
                  'e': {'f': {'g': 'a string', 'h': [1, 2]}}}
    test_dict2 = {'a': {'b': 1, 'c': 2},
                  'e': {'f': {'h': [1, 2], 'g': 'a string', 'i': 1}}}
    diff = recursive_diff(test_dict1, test_dict2)
    assert diff == ({'a': {'d': None}, 'e': {'f': {'i': 1}}},
                    {'a': {}, 'e': {}}), "Recursive diff failed."


# Generated at 2022-06-20 15:45:23.661409
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': {'x': 2, 'y': 4}, 'c': 6}
    d2 = {'a': 1, 'b': {'x': 2}, 'd': 9}
    d3 = {'a': 1, 'b': {'x': 2}, 'd': 9, 'e': {'f': 100}}

    assert dict_merge(d1, d2) == {'a': 1, 'b': {'x': 2}, 'c': 6, 'd': 9}
    assert dict_merge(d3, d2) == {'a': 1, 'b': {'x': 2}, 'd': 9, 'e': {'f': 100}}

# Generated at 2022-06-20 15:45:32.923285
# Unit test for function recursive_diff
def test_recursive_diff():

    dictionary_a = {'key_1': {'key_1_1': 'value_1_1',
                              'key_1_2': 'value_1_2'},
                    'key_2': 'value_2'}
    dictionary_b = {'key_1': {'key_1_1': 'value_1_1',
                              'key_1_2': 'value_1_2'},
                    'key_2': 'value_2_2'}
    result = recursive_diff(dictionary_a, dictionary_b)
    assert result == ({'key_2': 'value_2'}, {'key_2': 'value_2_2'})


# Generated at 2022-06-20 15:45:44.603107
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:45:54.391698
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': {
                'e': 1,
                'f': 3
            },
            'g': 2,
            'h': 4,
        },
        'i': [
            1,
            3
        ]
    }

    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': {
                'e': 1,
                'f': 5,
                'g': 2
            },
            'h': 4,
        },
        'i': [
            1,
            3
        ]
    }

    diff = recursive_diff(dict1, dict2)


# Generated at 2022-06-20 15:46:01.155328
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    b = {'f': 5, 'g': 6, 'c': {'h': 7, 'i': 8}}
    c = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 6, 'c': {'h': 7, 'i': 8}}
    assert dict_merge(a, b) == c


# Generated at 2022-06-20 15:46:12.693874
# Unit test for function recursive_diff
def test_recursive_diff():
    expected_1 = {'a': 'a', 'b': {'c': 'c', 'd': 'd'}, 'e': {'f': 'f', 'g': 'h'}}
    actual_1 = {'a': 'a', 'b': {'c': 'c', 'd': 'd'}, 'e': {'f': 'f', 'g': 'j'}}
    expected_2 = {'a': 'a', 'b': {'c': 'c', 'd': 'd'}, 'e': {'f': 'f', 'g': 'h'}}
    actual_2 = {'a': 'a', 'b': {'c': 'c', 'd': 'd'}, 'e': {'f': 'f', 'g': 'j', 'h': 'i'}}

# Generated at 2022-06-20 15:46:25.013607
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    from ansible.module_utils.six import string_types

    def assert_snake_to_camel(snake, camel):
        assert(isinstance(snake_dict_to_camel_dict(snake), dict))
        assert(isinstance(snake_dict_to_camel_dict(snake, capitalize_first=True), dict))
        assert(snake_dict_to_camel_dict(snake) == camel)
        assert(snake_dict_to_camel_dict(snake, capitalize_first=True) == camel)

    assert_snake_to_camel({}, {})
    assert_snake_to_camel({'a_': 'a_'}, {'a': 'a_'})


# Generated at 2022-06-20 15:46:35.164473
# Unit test for function recursive_diff
def test_recursive_diff():

    test_dict1 = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 4,
            'f': 5,
            'g': {
                'h': 6,
                'i': 7,
                'j': 8,
                'k': {
                    'l': {
                        'm': 9,
                        'n': 10,
                    }
                }
            }
        }
    }


# Generated at 2022-06-20 15:46:41.581273
# Unit test for function dict_merge
def test_dict_merge():

    a = {1: {2: 3}, 3: 4}
    b = {1: {4: 5}}
    assert dict_merge(a, b) == {1: {2: 3, 4: 5}, 3: 4}

    a = {1: {2: 3}, 3: 4}
    assert dict_merge(a, {}) == {1: {2: 3}, 3: 4}

    a = {1: {2: 3}, 3: 4}
    b = {1: {2: 3}, 3: 4}
    assert dict_merge(a, b) == a

    a = {1: {2: 3}, 3: 4}
    b = {1: {2: 3}, 3: 4, 5: 6}
    assert dict_merge(a, b) == b


# Generated at 2022-06-20 15:46:49.915306
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'a': 1,
        'b': {'x': 1, 'y': 2, 'z': 3},
        'c': 4,
    }
    b = {
        'a': {'g': 1, 'h': 2},
        'b': {'x': 1, 'y': 42, 'z': 3},
        'd': 5,
    }

    expected = {
        'a': {'g': 1, 'h': 2},
        'b': {'x': 1, 'y': 42, 'z': 3},
        'c': 4,
        'd': 5,
    }

    assert dict_merge(a, b) == expected

# Generated at 2022-06-20 15:47:00.001232
# Unit test for function dict_merge
def test_dict_merge():

    class CannedResponse(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    a_json_str = '''
        {
            "foo": "bar",
            "baz": {
                "qux": "quux"
            },
            "boop": 24,
            "array": [
                123, 456
            ],
            "dict_in_array": [
                {
                    "foo": "bar"
                },
                {
                    "foo": "baz"
                }
            ]
        }
    '''

# Generated at 2022-06-20 15:47:04.129186
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {1: 1, 2: 2},
             'b': {3: 3},
             'c': {4: 4}}
    dict2 = {'a': {1: 1, 2: 'f', 3: 3},
             'b': {3: 3},
             'd': {5: 5}}
    assert recursive_diff(dict1, dict2) == ({'a': {2: 2}, 'c': {4: 4}}, {'a': {2: 'f', 3: 3}, 'd': {5: 5}})

    dict1 = {'a': {1: 1, 2: 2}, 'b': {3: 3}, 'c': {4: 4}}

# Generated at 2022-06-20 15:47:15.959364
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.ec2 import snake_dict_to_camel_dict
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict
    test_dict1 = snake_dict_to_camel_dict({'test_key1': 'test_value1', 'test_key2': {'test_key3': 'test_value2', 'test_key4': 'test_value3'}, 'test_key5': [{'test_key1': 'test_value1'}]}, capitalize_first=True)

# Generated at 2022-06-20 15:47:29.986611
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}) == {'http_endpoint': 'value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'TestValue': 'value'}}) == {'http_endpoint': {'test_value': 'value'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': [{'TestValue': 'value'}]}) == {'http_endpoint': [{'test_value': 'value'}]}

# Generated at 2022-06-20 15:47:42.148461
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:47:49.297474
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:47:57.623811
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'internet_gateway_id': 'igw-7ec8c150', 'tags': [{'key': 'Key1', 'value': 'Value1'},
                                                                  {'key': 'Key2', 'value': 'Value2'}]}

    camel_dict_expected = {'InternetGatewayId': 'igw-7ec8c150', 'Tags': [{'key': 'Key1', 'value': 'Value1'},
                                                                         {'key': 'Key2', 'value': 'Value2'}]}


    camel_dict_actual = snake_dict_to_camel_dict(snake_dict)

    # Dicts get returned in arbitrary order, so we can't test for simple equality.
    for key, value in camel_dict_expected.items():
        assert camel_dict

# Generated at 2022-06-20 15:48:06.537233
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.aws.core import AnsibleAWSModule
    import json

    # Load a complex camelized aws response
    with open('./test/unit/plugins/modules/elasticache_test_data.json') as json_file:
        module = AnsibleAWSModule(argument_spec={}, supports_check_mode=True)
        camelized_response = module.from_json(json_file.read())

    # Call camel dict to snake dict, but pass back 'reversible=True'
    # (which means we can convert back to camel case with snake_dict_to_camel_dict)
    snake_response = camel_dict_to_snake_dict(camelized_response, reversible=True)

    # Test
    assert 'cache_nodes' in snake_response

# Generated at 2022-06-20 15:48:15.621308
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    testDict = {
        'this_is': {
            'really_cool': 'or',
            'not_really': 'for',
            'quite_a': {
                'big_old': [
                    'dict'
                ]
            }
        }
    }


    refDict = {
        'thisIs': {
            'reallyCool': 'or',
            'notReally': 'for',
            'quiteA': {
                'bigOld': [
                    'dict'
                ]
            }
        }
    }

    result = snake_dict_to_camel_dict(testDict)

    assert result == refDict

# Generated at 2022-06-20 15:48:24.983468
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(one=1, two=2, three=3)
    b = dict(four=4, five=5, six=6)

    # Simple merge
    result = dict_merge(a, b)
    assert result['one'] == 1
    assert result['four'] == 4

    # Update an existing value
    b['three'] = 4
    result = dict_merge(a, b)
    assert  result['three'] == 4

    # Nested dict
    a['dict'] = dict(one=1, two=2)
    b['dict'] = dict(two=3, three=3)
    result = dict_merge(a, b)
    assert result['dict']['two'] == 3

    # Nested dict with same values

# Generated at 2022-06-20 15:48:30.384127
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'some_key': 'value'}) == {'someKey': 'value'}
    assert snake_dict_to_camel_dict({'some_key': 'value'}, capitalize_first=True) == {'SomeKey': 'value'}
    assert snake_dict_to_camel_dict({'some_key': 'value', 'some_other_key': {'some_nested_key': 'nested_value'}}) == {'someKey': 'value', 'someOtherKey': {'someNestedKey': 'nested_value'}}



# Generated at 2022-06-20 15:48:41.970188
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_in = {"Prop1": True, "Prop2": False, "Prop3": None, "Prop4": 42, "Prop5": "a string",
               "Prop6": ["one", "two", "three"], "Prop7": {"a": 1, "b": 2, "c": 3},
               "HTTPEndpoint": "somewhere.org", "TargetGroupArns": ["1", "2", "3"]}

    dict_out = camel_dict_to_snake_dict(dict_in)

    assert dict_out["prop1"] is True
    assert dict_out["prop2"] is False
    assert dict_out["prop3"] is None
    assert dict_out["prop4"] == 42
    assert dict_out["prop5"] == "a string"

# Generated at 2022-06-20 15:48:45.936524
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(
        {"a": "1", "b": "2"},
        {"a": "1", "b": "5"}) == ({"b": "2"}, {"b": "5"})


# Generated at 2022-06-20 15:48:59.735803
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    instance_tags_dict = {
        'tags': [{
            'key': 'Name',
            'value': 'foobar'
        }],
        'key_name': 'MyKey',
        'instance_type': 't1.micro',
        'image_id': 'ami-123456'
    }

    camel_case_instance_tags_dict = {
        'Tags': [{
            'Key': 'Name',
            'Value': 'foobar'
        }],
        'KeyName': 'MyKey',
        'InstanceType': 't1.micro',
        'ImageId': 'ami-123456'
    }

    assert snake_dict_to_camel_dict(instance_tags_dict, capitalize_first=False) == camel_case_instance_tags_dict


# Generated at 2022-06-20 15:49:09.197968
# Unit test for function recursive_diff
def test_recursive_diff():
    # Two empty dictionaries.
    assert not recursive_diff({}, {})
    # Checking for None object.
    assert recursive_diff({"test":None}, {})
    assert recursive_diff({"test":{"test2":None}}, {"test":{"test2":None}})
    # Empty dictionary and dictionary with a key.
    assert recursive_diff({}, {"test":None}) == ({}, {"test":None})
    assert recursive_diff({"test":None}, {}) == ({"test":None}, {})
    assert recursive_diff({}, {"test":None}) == ({}, {"test":None})
    # Same.
    assert not recursive_diff({"test":None}, {"test":None})
    # Different.

# Generated at 2022-06-20 15:49:18.070546
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_camel_dict = dict(
        stringKey='this is a string',
        integerKey=42,
        camelCasedKey='camel cased string',
        HTTPEndpoint='http://www.google.com',
        Tags=[dict(value='foo', key='bar')],
        ListOfStrings=['foo', 'bar', 'baz'],
        ListOfDicts=[dict(foo='bar')],
        ListOfDictsWithTags=[dict(foo='bar', Tags=[dict(value='foo', key='bar')], bar='baz')],
        DictOfLists=dict(foo=['bar', 'baz']),
        DictOfDicts=dict(foo=dict(bar='baz'))
    )


# Generated at 2022-06-20 15:49:29.349733
# Unit test for function dict_merge

# Generated at 2022-06-20 15:49:39.963869
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.common.collections import Mapping

    assert dict_merge({"foo": 1}, {"bar": 2}) == {"foo": 1, "bar": 2}
    assert dict_merge({"foo": 1}, {"foo": 2}) == {"foo": 2}
    assert dict_merge({"foo": {"bar": 1}}, {"foo": {"bar": 2}}) == {"foo": {"bar": 2}}

    assert dict_merge({"foo": {"bar": 1}}, {"foo": {"baz": 2}}) == {"foo": {"bar": 1, "baz": 2}}
    assert dict_merge({"foo": Mapping()}, {"foo": {"bar": 2}}) == {"foo": {"bar": 2}}

# Generated at 2022-06-20 15:49:51.539878
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None

    assert recursive_diff({1: 3}, {2: 4}) == ({1: 3}, {2: 4})

    assert recursive_diff({1: 3, 2: 5}, {2: 4}) == ({1: 3}, {2: 4})

    assert recursive_diff({1: 3, 2: 4}, {2: 4, 1: 3}) is None

    assert recursive_diff({1: 3, 2: 4}, {2: 4, 1: 3, 3: 8}) == ({}, {3: 8})

    assert recursive_diff({1: 3, 2: 4}, {2: 4, 1: 3, 3: 8, 4: {1: 3}}) == ({}, {3: 8, 4: {1: 3}})


# Generated at 2022-06-20 15:49:59.864000
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test function recursive_diff"""

    # Simplest case: comparing two dictionaries with the same data
    dict1 = {"one": 1, "two": 2, "three": 3}
    dict2 = {"one": 1, "two": 2, "three": 3}
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Simplest case: one key is missing in one of the dictionaries
    dict1 = {"one": 1, "two": 2}
    dict2 = {"one": 1, "two": 2, "three": 3}
    result = recursive_diff(dict1, dict2)
    assert result[0] == {"three": 3}, "Should be the same"
    assert result[1] == {}, "Should be empty"

    # Simplest case: one key has a different value
   

# Generated at 2022-06-20 15:50:10.491167
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
          "a1": "value1",
          "b1": {
            "c1": "value1",
            "d1": "value1"
          },
          "e1": {
            "f1": {
              "g1": "value1",
              "h1": "value1"
            },
            "i1": "value1"
          },
          "j1": "value1"
        }

    d2 = {
          "a2": "value2",
          "b2": {
            "c2": "value2"
          },
          "e2": {
            "f2": {
              "g2": "value2"
            },
            "i2": "value2"
          },
          "j2": "value2"
        }

   

# Generated at 2022-06-20 15:50:16.421907
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {'id': 'test_string', 'tags': [{'key': 'value'}, {'key': 'value'}], 'test_key': {'test_key': 'test_value'}}
    test_dict_to_check = {'Id': 'test_string', 'Tags': [{'key': 'value'}, {'key': 'value'}], 'TestKey': {'test_key': 'test_value'}}
    assert snake_dict_to_camel_dict(test_dict, True) == test_dict_to_check



# Generated at 2022-06-20 15:50:21.914258
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : {
                                             'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }


# Generated at 2022-06-20 15:50:42.039663
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test recursive_diff
    # Test no difference
    assert recursive_diff({}, {}) == None
    # Test single value difference
    assert recursive_diff({"A": "a"}, {"A": "b"}) == ({"A": "a"}, {"A": "b"})
    assert recursive_diff({"A": "a"}, {"A": "a"}) == None
    # Test multiple value difference
    assert recursive_diff({"A": "a", "B": "b"}, {"A": "c", "B": "b"}) == ({"A": "a"}, {"A": "c"})

# Generated at 2022-06-20 15:50:53.764799
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {'a': {'b': 1, 'c': 2}, 'd': {'e': {'f': 4}}}
    right = {'a': {'b': 1, 'c': 3}, 'g': {'h': {'i': 6}}}
    result = recursive_diff(left, right)
    assert result == ({'a': {'c': 2}}, {'a': {'c': 3}, 'g': {'h': {'i': 6}}})

    left = {'a': {'b': 1, 'c': 2}, 'd': {'e': 3}}
    right = {'a': {'b': 1, 'c': 2}, 'd': {'e': 4}}
    result = recursive_diff(left, right)

# Generated at 2022-06-20 15:51:00.467892
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        'a': 1,
        'b': 'str',
        'c': False,
        'd': {
            'a1': 1,
            'a2': 'str1',
            'a3': True,
            'a4': {'a41': 1, 'a42': 'string'}
        }
    }

    right = {
        'a': 1,
        'b': 'str',
        'c': False,
        'd': {
            'a1': 1,
            'a2': 'str2',
            'a3': False,
            'a4': {'a41': 2, 'a42': 'new string'}
        }
    }


# Generated at 2022-06-20 15:51:12.949169
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test basic conversion of one key
    assert camel_dict_to_snake_dict({'FooBar': {}}) == {'foo_bar': {}}

    # Test conversion of multiple keys
    assert camel_dict_to_snake_dict({'FooBar': {}, 'BarBaz': {}}) == {'foo_bar': {}, 'bar_baz': {}}

    # Test conversion with a dictionary value
    assert camel_dict_to_snake_dict({'FooBar': {'Foo': 'Foo'}}) == {'foo_bar': {'foo': 'Foo'}}

    # Test conversion with a list

# Generated at 2022-06-20 15:51:24.537234
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Case 1
    camel_dict = {'FirstName': 'John', 'LastName': 'Doe'}
    snake_dict = {'first_name': 'John', 'last_name': 'Doe'}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    # Case 2
    camel_dict = {'FirstName': 'John', 'LastName': 'Doe', 'Age': '20'}
    snake_dict = {'first_name': 'John', 'last_name': 'Doe', 'age': '20'}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    # Case 3

# Generated at 2022-06-20 15:51:34.825701
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Tags': [
            {'Key': 'foo', 'Value': 'bar'},
            {'Key': 'baz', 'Value': 'qux'}
        ]
    }
    test_dict = deepcopy(camel_dict)
    camel_dict_to_snake_dict(test_dict, reversible=False, ignore_list=('Tags',))
    assert test_dict == {'tags': [{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'qux'}]}
    test_dict = deepcopy(camel_dict)
    camel_dict_to_snake_dict(test_dict, reversible=True, ignore_list=('Tags',))

# Generated at 2022-06-20 15:51:43.623841
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test for valid conversion
    test_dict = {'instance_id': 'i-0b3ca77c7f6b1d6a0'}
    assert snake_dict_to_camel_dict(test_dict) == {'instanceId': 'i-0b3ca77c7f6b1d6a0'}
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=True) == {'InstanceId': 'i-0b3ca77c7f6b1d6a0'}

    # Test for valid conversion with a nested dictionary
    test_dict = {
        'instance_id': 'i-0b3ca77c7f6b1d6a0',
        'tags': {
            'Name': 'test-instance',
        },
    }


# Generated at 2022-06-20 15:51:55.174327
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {"key1": "val1", "key2": "val2",
             "key3": {"nkey1": "nval1", "nkey2": "nval2", "nkey3": ["val1", "val2"]},
             "key4": ["nkey1", "nkey2"]}
    dict2 = {"key1": "val1", "key2": "val3",
             "key3": {"nkey1": "nval1", "nkey2": "nval3", "nkey3": ["val1", "val3"]},
             "key4": ["nkey1", "nkey2", "nkey3"]}

# Generated at 2022-06-20 15:52:06.520665
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "CamelCase": "value", "dictKey": {
            "CamelCase": "value",
            "dictKey": {
                "CamelCase": "value",
                "dictKey": {
                    "CamelCase": "value",
                    "dictKey": {
                        "CamelCase": "value",
                        "tags": {
                            "CamelCase": "value",
                            "dictKey": {
                                "CamelCase": "value"
                            }
                        }
                    }
                }
            }
        }
    }


# Generated at 2022-06-20 15:52:18.754766
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_1 = {'tooLong': {'KeyName': 'value', 'KeyName2': 'value1'},
              'tooLong2': {'KeyName3': 'value2', 'KeyName4': 'value3'},
              'ARN': "arn:aws:s3:::my_corporate_bucket/exampleobject.png",
              'Key': "test/test/test"}

    dict_2 = {'too_long': {'key_name': 'value', 'key_name2': 'value1'},
              'too_long2': {'key_name3': 'value2', 'key_name4': 'value3'},
              'arn': "arn:aws:s3:::my_corporate_bucket/exampleobject.png",
              'key': "test/test/test"}

    dict

# Generated at 2022-06-20 15:52:33.727182
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(
        {'my_snake_key': 'my_snake_key_value'}) == \
        {'mySnakeKey': 'my_snake_key_value'}
    assert snake_dict_to_camel_dict(
        {'my_snake_key': 'my_snake_key_value'},
        capitalize_first=True) == \
        {'MySnakeKey': 'my_snake_key_value'}
    assert snake_dict_to_camel_dict(
        {'my_nested': {'my_snake': 'value'}}) == \
        {'myNested': {'mySnake': 'value'}}

# Generated at 2022-06-20 15:52:43.856538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "http_endpoint": "http",
        "https_endpoint": "https",
        "https_port": 443,
        "tags": {
            "key1": "value1",
            "key2": "value2"
        }
    }

    snake_dict = {
        "http_endpoint": "http",
        "https_endpoint": "https",
        "https_port": 443,
        "tags": {
            "key1": "value1",
            "key2": "value2"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-20 15:52:54.783361
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {
        u'ARN': u'arn:aws:iam::444455556666:role/test-role',
        u'AssumeRolePolicyDocument': {
            u'Statement': [
                {
                    u'Action': 'sts:AssumeRole'
                }
            ]
        }
    }
    result = camel_dict_to_snake_dict(camel)
    assert(result == {
        u'arn': u'arn:aws:iam::444455556666:role/test-role',
        u'assume_role_policy_document': {
            u'statement': [
                {
                    u'action': 'sts:AssumeRole'
                }
            ]
        }
    })



# Generated at 2022-06-20 15:53:07.081663
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'a_key': 'a_value'}) == {'aKey': 'a_value'}
    assert snake_dict_to_camel_dict({'snake_cased': 'a_value'}) == {'snakeCased': 'a_value'}
    assert snake_dict_to_camel_dict({'camel_cased': 'a_value'}) == {'camelCased': 'a_value'}
    assert snake_dict_to_camel_dict({'camel_cased': 'a_value'}) == {'camelCased': 'a_value'}

# Generated at 2022-06-20 15:53:18.511997
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = dict(
        resource_type='HealthCheck',
        resource_id='hc-12345678',
        region='us-east-1',
        monitored_resource_arns=dict(
            add=[
                'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                'arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/my-load-balancer/50dc6c495c0c9188',
                'arn:aws:route53:::healthcheck/abcdefg'
            ]
        )
    )


# Generated at 2022-06-20 15:53:25.079083
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    print(dict_merge(a, b))
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, "Dictionary merge is broken"

# Generated at 2022-06-20 15:53:35.708831
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == \
        ({'b': 2}, {})
    assert recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == \
        ({}, {'b': 2})
    assert recursive_diff({'a': 1}, {'a': 2}) == \
        ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1, 'b': {'c': 3}}, {'a': 1, 'b': {'c': 4}}) == \
        ({'b': {'c': 3}}, {'b': {'c': 4}})

# Generated at 2022-06-20 15:53:44.866856
# Unit test for function dict_merge
def test_dict_merge():

    # Start with two dicts.
    dict1 = dict(
        x=1,
        y=dict(
            a=1,
            b=2,
            c=3
        )
    )
    dict2 = dict(
        x=4,
        y=dict(
            a=5,
            b=6,
            c=7,
            d=8
        ),
        z=9
    )

    # We should get the answer we expect.
    if dict_merge(dict1, dict2) != {'x': 4, 'y': {'a': 5, 'b': 6, 'c': 7, 'd': 8}, 'z': 9}:
        raise AssertionError('Unexpected result')

    # We should get the original dicts back if we do it in reverse.

# Generated at 2022-06-20 15:53:50.613864
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'id': '1', "not_snake_case": "2", "simply_snake_case": "3"}, True) == {'id': '1', "not_snake_case": "2",
                                                                                "simply_snake_case": "3"}
    assert camel_dict_to_snake_dict({'testCase1': {'testCase2': '2'}}) == {'test_case1': {'test_case2': '2'}}

# Generated at 2022-06-20 15:54:02.754064
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'Version': 123, 'KeyList':[{'KeyOne':1, 'KeyTwo':2},
                                            {'KeyThree':3, 'KeyFour':4}],
                 'Key':{'NestedKey': 'Value'},
                 'HTTPEndpoint': {'EndpointUrl': 'http://www.example.com/'},
                 'CommonTags': {'Tags': {'key': 'value'}},
                }