

# Generated at 2022-06-20 15:44:15.843265
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'x': {
            'foo': 1,
            'bar': 2
        },
        'y': 4
    }
    b = {
        'x': {
            'baz': 5
        },
        'y': 6,
        'z': 7
    }
    c = {
        'x': {
            'fiz': 8,
            'baz': 9
        },
        'z': 10,
        'f': 11
    }
    d = {
        'x': {
            'fizz': 12,
            'bizz': 13
        },
        'b': 14
    }


# Generated at 2022-06-20 15:44:26.640688
# Unit test for function dict_merge
def test_dict_merge():
    d1 = dict(a=1, b=dict(c=1, d=2, e=dict(p=1, q=2, r=3)), g=dict(h=1, i=2))
    d2 = dict(a=2, b=dict(c=3, d=4, e=dict(q=3, r=3, s=3)), f=dict(h=3, i=3))
    expected = dict(a=2, b=dict(c=3, d=4, e=dict(p=1, q=3, r=3, s=3)), f=dict(h=3, i=3), g=dict(h=1, i=2))
    assert dict_merge(d1, d2) == expected



# Generated at 2022-06-20 15:44:37.399965
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {"k1": "v1", "k2": "v2"}
    dict2 = {"k1": "v1", "k3": "v3"}
    dict3 = {"k1": "v1"}
    dict4 = {"k1": "v1", "k2": "v2", "k4": {"k4_1": "v4_1"}}
    dict5 = {"k1": "v1", "k2": "v2", "k4": {"k4_1": "v4_1", "k4_2": "v4_2"}}

# Generated at 2022-06-20 15:44:46.453610
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 'foo', 'b': 'bar', 'c': {'c1': 'foo1', 'c2': 'foo2'}, 'd': [1, 2, 3]}
    d2 = {'a': 'bar', 'b': 'bar', 'c': {'c2': 'foo2', 'c3': 'foo3'}, 'd': [4, 5]}
    d3 = dict_merge(d1, d2)

    assert d1 == {'a': 'foo', 'b': 'bar', 'c': {'c1': 'foo1', 'c2': 'foo2'}, 'd': [1, 2, 3]}

# Generated at 2022-06-20 15:44:58.868893
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Test recursive_diff.
    """

    class TestObject(object):
        pass
    # Test 1
    dict1 = dict()
    dict2 = dict()
    assert recursive_diff(dict1, dict2) is None

    # Test 2
    dict1 = dict(a=1)
    dict2 = dict(a=2)
    assert recursive_diff(dict1, dict2) == (dict1, dict2)

    # Test 3
    dict1 = dict(a=1, b=2)
    dict2 = dict(a=1)
    assert recursive_diff(dict1, dict2) == (dict(), dict(b=2))

    # Test 4
    dict1 = dict(a=1, b=dict(c=2))

# Generated at 2022-06-20 15:45:09.532256
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Test recursive_diff function """
    dict1 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': {
                'key5': 'value5'
            }
        }
    }
    dict2 = {
        'key1': 'changed_value1',
        'key2': {
            'key3': 'changed_value3',
            'key4': {
                'key5': 'value5'
            }
        }
    }
    result = recursive_diff(dict1, dict2)
    left = result[0]
    right = result[1]
    assert(left['key1'] == 'value1')
    assert(right['key1'] == 'changed_value1')

# Generated at 2022-06-20 15:45:16.430755
# Unit test for function recursive_diff
def test_recursive_diff():
    """Runs a series of unit tests for the recursive_diff function
    """

    # Test same dictionaries
    test_dict1 = {"Name": "Test_Name"}
    assert recursive_diff(test_dict1, test_dict1) is None
    test_dict1 = {"Name": "Test_Name", "Attributes": {"Name": "Test_Name"}}
    assert recursive_diff(test_dict1, test_dict1) is None

    # Test with differing dictionaries
    test_dict1 = {"Name": "Test_Name"}
    test_dict2 = {"Name": "Test_Name1"}
    assert recursive_diff(test_dict1, test_dict2) == ({"Name": "Test_Name"}, {"Name": "Test_Name1"})

# Generated at 2022-06-20 15:45:27.033003
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test that two empty dictionaries return None
    assert recursive_diff({},{}) == None

    # Test that two equivalent dictionaries return None
    assert recursive_diff(
        {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g' : 5}}},
        {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g' : 5}}}
    ) == None

    # Test "left" differences

# Generated at 2022-06-20 15:45:35.558922
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:45:47.982246
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit test for recursive_diff function
    returns a list of True/False
    """
    def test1():
        dict1 = dict(a=42, b=[1, 2, 3])
        dict2 = dict(a=42, b=[1, 2, 3])
        assert not recursive_diff(dict1, dict2)

    def test2():
        dict1 = dict(a=42, b=[1, 2, 3])
        dict2 = dict(a=42, b=[1, 2])
        assert recursive_diff(dict1, dict2) == (dict(b=[1, 2, 3]), dict(b=[1, 2]))

    def test3():
        dict1 = dict(a=dict(b=42))
        dict2 = dict(a=dict(b=42))

# Generated at 2022-06-20 15:45:58.453333
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'key2': 1}, 'key3': {'key4': 2, 'key5': 3}}
    b = {'key6': 4, 'key7': 5, 'key1': {'key2': 7}}
    expected = {'key6': 4, 'key7': 5, 'key1': {'key2': 7}, 'key3': {'key4': 2, 'key5': 3}}
    assert dict_merge(a, b) == expected

# Generated at 2022-06-20 15:46:05.129363
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': {'b': 'c'}}
    dict2 = {'w': 'x', 'a': {'y': 'z', 'b': 'd'}, 'c': 'd'}

    dict3 = dict_merge(dict1, dict2)
    assert dict3 == {'w': 'x', 'a': {'y': 'z', 'b': 'd'}, 'c': 'd'}

# Generated at 2022-06-20 15:46:15.505177
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'InstanceType': 't2.micro', 'IamInstanceProfile': 'default'},
        True
    ) == {'i_a_m_instance_profile': 'default', 'instance_type': 't2.micro'}
    assert camel_dict_to_snake_dict(
        {'VpcId': 'vpc-xxxxxxxx', 'Tags': {'Application': 'test-ansible'}}, True
    ) == {
        'vpc_i_d': 'vpc-xxxxxxxx', 'tags': {'Application': 'test-ansible'}
    }

# Generated at 2022-06-20 15:46:26.418864
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = dict(
        a_b_c="abc",
        a_b_c_d="abcd",
        a_b_c_d_e="abcde",
        a_b_c_d_e_f="abcdef",
        a_b_c_d_e_f_g="abcdefg",
        a_b_c_d_e_f_g_h="abcdefgh",
        a_b_c_d_e_f_g_h_i="abcdefghi",
    )


# Generated at 2022-06-20 15:46:35.398556
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test simple dictionaries
    assert recursive_diff({'a': 1, 'b': 2}, {}) == ({'a': 1, 'b': 2}, {})
    assert recursive_diff({}, {'a': 1, 'b': 2}) == ({}, {'a': 1, 'b': 2})
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'a': 1}) is None

    # Test nested dictionaries
    assert recursive_diff({'a': 1, 'b': {'c': 2}}, {}) == ({'a': 1, 'b': {'c': 2}}, {})

# Generated at 2022-06-20 15:46:41.626519
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': 'baz_qux'}) == {'fooBar': 'baz_qux'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz_qux'}, capitalize_first=True) == {'FooBar': 'baz_qux'}
    assert snake_dict_to_camel_dict({'foo_bar': [1, 2, 3]}) == {'fooBar': [1, 2, 3]}
    assert snake_dict_to_camel_dict({'foo_bar': {'foo_bar': 'baz_qux'}}) == {'fooBar': {'fooBar': 'baz_qux'}}

# Generated at 2022-06-20 15:46:49.998593
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'test_dict': {'test_key1': 'test_val1', 'test_key2': 'test_val2'}}
    dict2 = {'test_dict': {'test_key1': 'test_val1', 'test_key2': 'test_val2'}}
    dict3 = {'test_dict': {'test_key1': 'test_val1', 'test_key2': 'test_val2'}}
    dict4 = {'test_dict': {'test_key2': 'test_val2', 'test_key1': 'test_val1'}}
    dict5 = {'test_dict': {'test_key1': 'test_val2', 'test_key2': 'test_val2'}}

    assert recursive_diff(dict1, dict2) is None

# Generated at 2022-06-20 15:47:00.085467
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Key1': 'Value1',
        'Key2': 'Value2',
        'Key3': {
            'Key4': 'Value4',
            'Key5': 'Value5',
            'Key6': {
                'Key7': 'Value7',
                'Key8': 'Value8'
            }
        }
    }
    test_dict_result = {
        'key1': 'Value1',
        'key2': 'Value2',
        'key3': {
            'key4': 'Value4',
            'key5': 'Value5',
            'key6': {
                'key7': 'Value7',
                'key8': 'Value8'
            }
        }
    }

# Generated at 2022-06-20 15:47:10.757683
# Unit test for function dict_merge

# Generated at 2022-06-20 15:47:21.360253
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'tag_name': {'key': 'value'}, 'tag_list': [{'key': 'value', 'key2': 'value2'}]}
    camel_dict = snake_dict_to_camel_dict(snake_dict)

    # Basic checks
    assert isinstance(camel_dict, dict)
    assert isinstance(camel_dict['tagName']['key'], str)
    assert isinstance(camel_dict['tagName']['key'], str)
    assert isinstance(camel_dict['tagList'], list)
    assert isinstance(camel_dict['tagList'][0], dict)
    assert isinstance(camel_dict['tagList'][0]['key'], str)

# Generated at 2022-06-20 15:47:35.962764
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': 'some_string',
        'd': {
            'first': 'some_string',
            'second': 'another_string',
        },
    }
    dict2 = {
        'a': 1,
        'b': 6,
        'c': 'some_string',
        'd': {
            'first': 'some_string',
            'second': 'another_string',
        },
        'e': [1],
    }
    result = recursive_diff(dict1, dict2)
    assert result is not None
    assert result[0]['b'] == dict1['b']
    assert result[1]['b'] == dict2['b']

# Generated at 2022-06-20 15:47:46.342541
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test that a simple dictionary is turned into dromedaryCase
    snake_dict = {'snake_case': 'value'}
    res = snake_dict_to_camel_dict(snake_dict)
    assert res == {'snakeCase': 'value'}

    # Test that a nested dictionary is turned into dromedaryCase
    snake_dict = {'snake_case': {'inner_dict': {'inner_key': 'value'}}}
    res = snake_dict_to_camel_dict(snake_dict)
    assert res == {'snakeCase': {'innerDict': {'innerKey': 'value'}}}

    # Test that a list inside a dictionary is turned into dromedaryCase
    snake_dict = {'snake_case': {'inner_list': ['value']}}

# Generated at 2022-06-20 15:47:55.805319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'a': 1, 'b': 'c', 'd': {'e': 1, 'f': {'g': 1}, 'h': [{'i': 1, 'j': 2}]}}
    check_dict = {'a': 1, 'b': 'c', 'd': {'e': 1, 'f': {'g': 1}, 'h': [{'i': 1, 'j': 2}]}}
    assert camel_dict_to_snake_dict(test_dict) == check_dict

    test_dict = {'HTTPEndpoint': 1, 'b': 'c', 'd': {'e': 1, 'HTTPEndpoint': {'g': 1}, 'h': [{'i': 1, 'HTTPEndpoint': 2}]}}

# Generated at 2022-06-20 15:48:05.488009
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = {
        'id': 'one',
        'name': 'two',
        'tags': {
            'tag_one': 'three'
        },
        'found': True
    }
    camel_dict = {
        'Id': 'one',
        'Name': 'two',
        'Tags': {
            'tag_one': 'three'
        },
        'Found': True
    }

    simple_camel_dict = {
        'Key': 'one',
        'Value': 'two',
        'Found': True
    }

    simple_snake_dict = {
        'key': 'one',
        'value': 'two',
        'found': True
    }


# Generated at 2022-06-20 15:48:12.609960
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {'my_key': 'my_value', 'my_key2': ['one', 'two'], 'my_key3': {'a': 1, 'b': 2}}
    expected_dict = {'myKey': 'my_value', 'myKey2': ['one', 'two'], 'myKey3': {'a': 1, 'b': 2}}
    assert snake_dict_to_camel_dict(test_dict) == expected_dict



# Generated at 2022-06-20 15:48:22.942038
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'AccountId': '123456789012',
        'ResourceId': 'acctest-iam-role',
        'Tags': [
            {
                'Key': 'test',
                'Value': 'test'
            }
        ]
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {
        'account_id': '123456789012',
        'resource_id': 'acctest-iam-role',
        'tags': [
            {
                'Key': 'test',
                'Value': 'test'
            }
        ]
    }
    # now test that we can recamelize the tags
    camel_dict = snake_dict_to_camel_dict(snake_dict)
   

# Generated at 2022-06-20 15:48:29.895071
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {'test_dict': {'a_b': {'c_d_e': {'f_g': 'hij', 'k_l': 'mno'}, 'p_qr': {'st': 'uvw'}}}}
    expected_dict = {'testDict': {'aB': {'cDE': {'fG': 'hij', 'kL': 'mno'}, 'pQr': {'st': 'uvw'}}}}
    camel_dict = snake_dict_to_camel_dict(test_dict)
    assert camel_dict == expected_dict



# Generated at 2022-06-20 15:48:36.090124
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:48:47.843159
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': {
            'k3-1': 'v3-1',
            'k3-2': 'v3-2',
            'k3-3': {
                'k3-3-1': 'v3-3-1'
            }
        }
    }
    b = {
        'k1': 'v1b',
        'k2': 'v2b',
        'k3': {
            'k3-1': 'v3-1b',
            'k3-2': 'v3-2b',
            'k3-3': {
                'k3-3-1': 'v3-3-1b'
            }
        }
    }

    expected

# Generated at 2022-06-20 15:48:59.567762
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_test = {
        "HTTPEndpoint": {
            "Port": 80,
            "Protocol": "HTTP",
            "VpcEndpointId": "vpc-0123456789abcdef",
            "Tags": {
                "Name": "test-http-endpoint"
            }
        }
    }
    snake_dict_test = {
        "http_endpoint": {
            "port": 80,
            "protocol": "HTTP",
            "vpc_endpoint_id": "vpc-0123456789abcdef",
            "tags": {
                "Name": "test-http-endpoint"
            }
        }
    }

# Generated at 2022-06-20 15:49:14.272382
# Unit test for function dict_merge
def test_dict_merge():
    '''
    Unit test for function dict_merge
    '''

    d1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 5,
        },
        'g': {
            'h': 6,
            'i': {
                'j': 7
            }
        }
    }

    d2 = {
        'a': 1,
        'b': 21,
        'c': {
            'd': 3,
            'e': 4,
            'f': 51,
        },
        'g': {
            'h': 6,
            'i': {
                'j': 7
            }
        }
    }


# Generated at 2022-06-20 15:49:25.634974
# Unit test for function dict_merge
def test_dict_merge():

    a = dict(
        key1="value1",
        dict1=dict(
            key1="value1",
            dict1=dict(
                key1="value1",
                key2="value2",
            ),
            list1=["value1", "value2"],
        ),
        list1=["value1", "value2"],
    )

    b = dict(
        key2="value2",
        dict1=dict(
            key2="value2",
            dict1=dict(
                key3="value3",
            ),
            list1=["value3", "value4"],
        ),
        list1=["value3", "value4"],
    )


# Generated at 2022-06-20 15:49:33.405936
# Unit test for function dict_merge
def test_dict_merge():
    def compare(x, y):
        return all(
           v == y[k] for k, v in x.items()
        )

    a = {'a': 1, 'b': 2, 'c': {'a': 1}}
    b = {'c': {'a': 2}, 'd': 5}

    c = dict_merge(a, b)

    assert compare(c, {'a': 1, 'b': 2, 'c': {'a': 2}, 'd': 5})
    assert compare(a, {'a': 1, 'b': 2, 'c': {'a': 1}})
    assert compare(b, {'c': {'a': 2}, 'd': 5})

# Generated at 2022-06-20 15:49:44.680782
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:49:49.390872
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test basic function of function
    assert (camel_dict_to_snake_dict({'FooBar': {'FooBarBaz': 3}}) ==
            {'foo_bar': {'foo_bar_baz': 3}})

    # Test reversible option
    assert (camel_dict_to_snake_dict(
        {'FooBar': {'FooBarBaz': 3}}, reversible=True) ==
            {'f_o_o_bar': {'f_o_o_bar_baz': 3}})

    # Test ignore list for tags

# Generated at 2022-06-20 15:49:58.589496
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:50:09.706256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dictionary = {
        'MyString': 'foo',
        'MyArray': [
            'bar',
            'baz',
        ],
        'MyNestedDict': {
            'MyInnerDict': {
                'MyString': 'foo',
                'MyArray': [
                    'bar',
                    'baz',
                ],
            },
        },
        'Tags': {
            'Key1': {
                'Value': 'foo',
            },
            'Key2': {
                'Value': 'bar',
            },
        },
        'HTTPEndpoint': {
            'AB': {
                'c': 'd',
            },
        },
    }


# Generated at 2022-06-20 15:50:17.628578
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    example_dict = {'field_one': 'value_one', 'field_two': {'sub_field_one': 'sub_value_one'}, 'field_three': ['sub_value_one', 'sub_value_two']}
    example_dict_converted = snake_dict_to_camel_dict(example_dict)
    assert example_dict_converted['fieldOne'] == 'value_one'
    assert example_dict_converted['fieldTwo']['subFieldOne'] == 'sub_value_one'
    assert example_dict_converted['fieldThree'][0] == 'sub_value_one'
    assert example_dict_converted['fieldThree'][1] == 'sub_value_two'

    # Test pluralization

# Generated at 2022-06-20 15:50:26.793116
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'MyID': '123456789012',
        'MyStr': 'myStr',
        'myStr': 'xxxx',
        'str': 'yyyy',
        'MyHttpEndpoint': {
            'url': 'http://something.com/',
            'authority': 'something.com',
            'protocol': 'http'
        }
    }


# Generated at 2022-06-20 15:50:37.545510
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        "a": {
            "b": {
                "c1": "value1"
            },
            "d": {
                "e": {
                    "f": "value3",
                    "g": "value4"
                }
            },
            "i": "value10"
        },
        "h": "value9",
        "j": "value11"
    }

    b = {
        "a": {
            "b": {
                "c2": "value5"
            },
            "d": {
                "e": {
                    "f": "value6",
                    "g": "value7"
                }
            },
            "i": "value10"
        },
        "h": "value8",
        "j": "value11"
    }

   

# Generated at 2022-06-20 15:50:55.033979
# Unit test for function dict_merge
def test_dict_merge():

    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }

    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }

    assert dict_merge(a, b) == {'first': {'all_rows': {'pass': 'dog', 'number': '5', 'fail': 'cat'}}}

    c = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }

    assert dict_merge(b, c) == {'first': {'all_rows': {'fail': 'cat', 'number': '5'}}}



# Generated at 2022-06-20 15:51:07.196492
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:51:20.101835
# Unit test for function dict_merge
def test_dict_merge():
    # Test 1) Simple add
    a = {'key1': 'value1'}
    b = {'key2': 'value2'}
    c = dict_merge(a, b)
    assert(c['key1'] == 'value1')
    assert(c['key2'] == 'value2')
    # Test 2) Nested add
    a = {'key1': {'nestedkey1': 'value1'}}
    b = {'key2': 'value2'}
    c = dict_merge(a, b)
    assert(c['key1'] == {'nestedkey1': 'value1'})
    assert(c['key2'] == 'value2')
    # Test 3) Override
    a = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-20 15:51:28.432143
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Enabled': True,
        'OutputS3Region': 'us-east-1',
        'OutputS3BucketName': 'mybucket',
        'KMSMasterKeyID': 'arn:aws:kms:us-east-1:123456:key/abcd',
        'IncludeGlobalServiceEvents': True,
        'CloudWatchLogsLogGroupArn': 'aws:logs:us-east-1:123456:log-group:/aws/rds/cluster/mycluster:*',
        'CloudWatchLogsRoleArn': 'arn:aws:iam::123456:role/MyLogGroupRole',
    }

    result = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-20 15:51:34.774220
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"dictionary_item": {"camel_case": "item", "snake_case": "item"}}
    result = snake_dict_to_camel_dict(test_dict)
    assert result.get("dictionaryItem").get("camelCase") == "item"
    assert result.get("dictionaryItem").get("snakeCase") == "item"



# Generated at 2022-06-20 15:51:43.622978
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Unit test to ensure snake_dict_to_camel_dict returns dromedaryCase
    rather than true CamelCase. We have reverted back to dromedaryCase
    but we have added capitalize_first option to enable true CamelCase.
    """

# Generated at 2022-06-20 15:51:55.173458
# Unit test for function recursive_diff
def test_recursive_diff():

    class AWSObject(object):
        def __init__(self, d):
            self.__dict__ = d

    # From https://docs.aws.amazon.com/lambda/latest/dg/API_AddPermission.html
    add_permission_example = {
      u'FunctionName': u'MyFunction',
      u'StatementId': u'ID-1',
      u'Action': u'lambda:InvokeFunction',
      u'Principal': u'example.amazonaws.com',
      u'SourceArn': u'arn:aws:s3:::examplebucket/home/exampleuser',
      u'SourceAccount': u'111122223333',
      u'EventSourceToken': u'exampleTokenString',
      u'Qualifier': u'1'
    }

# Generated at 2022-06-20 15:52:06.521239
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict_sample = {
        "key1": "value1",
        "key2": {"key3": "value3"},
        "key4": [
            {"key4_1": "value4_1"},
            {
                "key4_2": "value4_2",
                "key5": [
                    {"key5_1": "value5_1"},
                    "value5_2",
                    {"key5_3": "value5_3"}
                ]
            }
        ]
    }


# Generated at 2022-06-20 15:52:12.568439
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict_all_snake = {"test_key_1": "test_val_1",
                            "test_key_2": 2,
                            "test_key_3": {"test_key_4": 4}}
    input_dict_mixed = {"test_key_1": "test_val_1",
                        "test_key_2": 2,
                        "Test_key_3": {"test_key_4": 4}}
    input_dict_mixed_2 = {"test_key_1": "test_val_1",
                          "Test_key_2": 2,
                          "Test_key_3": {"test_key_4": 4}}

# Generated at 2022-06-20 15:52:16.722656
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test case 1
    dict1 = {'a':'b', 'b':{'c':'d'}, 'c':[1,2,3], 'd':1}
    dict2 = {'a':'b', 'b':{'c':'d'}, 'c':[1,2,3]}
    expected = {'d':1}, None
    assert recursive_diff(dict1, dict2) == expected
    assert recursive_diff(dict2, dict1) == (None, expected[0])

    # Test case 2
    dict1 = {'a':'b', 'b':{'c':'d'}, 'd':1}

# Generated at 2022-06-20 15:52:44.142924
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'foo_bar': 1,
        'two_items': {
            'baz': 2,
            'qux': 3,
        },
        'list_item': [
            {
                'foo_bar': 1,
                'two_items': {
                    'baz': 2,
                    'qux': 3,
                }
            }
        ],
        'list_of_int': [1, 2, 3]
    }

    camel_dict = snake_dict_to_camel_dict(snake_dict)


# Generated at 2022-06-20 15:52:54.650874
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import os
    # Get path of the current directory
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    # Open file and load the json
    with open(os.path.join(cur_dir, "test_data/camel_dict.json"), 'r') as f:
        camel_dict = json.load(f)
        with open(os.path.join(cur_dir, "test_data/snake_dict.json"), 'r') as f2:
            snake_dict = json.load(f2)
            assert camel_dict_to_snake_dict(camel_dict) == snake_dict

# Generated at 2022-06-20 15:53:00.518751
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Test to verify that snake_dict_to_camel_dict function works as expected.
    """
    dromedary_case_snake = {u'abc': {u'abc_def': u'abc_def_value',
                                     u'def_ghi': {u'def_ghi_jkl': u'abc_def_value'},
                                     u'ghi_jkl': {u'ghi_jkl_mno': None, u'pqr_stu': u'pqr_stu_value'}
                                     },
                            u'pqr': u'pqr_value'
                            }

# Generated at 2022-06-20 15:53:10.357897
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test simple case
    input_camel_dict = {"originalString": "string", "newDict": {"a": 1, "b": 2}}
    expected_snake_dict = {"original_string": "string", "new_dict": {"a": 1, "b": 2}}
    actual_snake_dict = camel_dict_to_snake_dict(input_camel_dict)
    assert actual_snake_dict == expected_snake_dict
    # Test multiple words together
    input_camel_dict = {"originalString": "string", "newDict": {"HttpEndpoint": {"a": 1, "b": 2}}}
    expected_snake_dict = {"original_string": "string", "new_dict": {"h_t_t_p_endpoint": {"a": 1, "b": 2}}}


# Generated at 2022-06-20 15:53:13.753567
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'InstanceId': 'i-12345678', 'Tags': [{'Key': 'k1', 'Value': 'v1'}, {'Key': 'k2', 'Value': 'v2'}]}
    result_dict = {'instance_id': 'i-12345678', 'tags': [{'Key': 'k1', 'Value': 'v1'}, {'Key': 'k2', 'Value': 'v2'}]}
    assert camel_dict_to_snake_dict(camel_dict) == result_dict


# Generated at 2022-06-20 15:53:22.927698
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {'a': 1, 'b': 2, 'c': 3}) == ({}, {'a': 1, 'b': 2, 'c': 3})
    assert recursive_diff({'a': 1, 'b': 2, 'c': 3}, {}) == ({'a': 1, 'b': 2, 'c': 3}, {})
    assert recursive_diff({'a': 'b'}, {'a': 'b'}) is None
    assert recursive_diff({'a': 1, 'b': [1, 2, 3]}, {'a': 1, 'b': [1, 2, 4]}) == ({'b': [3]}, {'b': [4]})

# Generated at 2022-06-20 15:53:34.060825
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    camel_dict = {
                    'S3Location': {
                    'Bucket': 'mybucket',
                    'Key': 'mykey',
                    'Version': '1234'
                    },
                    'ArtifactIdentifier': 'test',
                    'TargetPlatform': 'test_platform',
                    'TargetPlatformVersion': '1.0',
                    'Description': 'test',
                    'AppVersion': '1.0',
                    'LicenseInfo': 'MIT',
                    'ExecutionRoleArn': 'arn:aws:iam::990123456789:role/service-role/CodeDeployDemo-EC2-S3-CodeDeployServiceRole-1QWMQJJBJ5K5Y',
                    'RevisionType': 'S3'
                }


# Generated at 2022-06-20 15:53:42.272846
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for method recursive_diff"""
    from pprint import pprint
    dict1 = dict(x=1, y=dict(a=True, b=False, c="Hello"))
    dict2 = dict(y=dict(a=True, b=True, d="World"))
    diff = recursive_diff(dict1, dict2)
    pprint(diff)
    dict1 = dict(x=1, y=dict(a=True, b=False, c="Hello"))
    dict2 = dict(z=dict(p="World"))
    diff = recursive_diff(dict1, dict2)
    pprint(diff)

# Generated at 2022-06-20 15:53:52.545852
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"foo_bar": "baz", "foo_baz": "bar"}) == {"fooBar": "baz", "fooBaz": "bar"}
    assert snake_dict_to_camel_dict({"foo_bar": "baz", "foo_baz": "bar"}, capitalize_first=True) == {"FooBar": "baz", "FooBaz": "bar"}
    assert snake_dict_to_camel_dict({"foo_bar": "baz", "foo_baz": "bar", "foo_baz_bar": "foo"}) == \
        {"fooBar": "baz", "fooBaz": "bar", "fooBazBar": "foo"}

# Generated at 2022-06-20 15:54:02.093525
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Test conversion of dictionary from snake case to camel case"""

    my_snake_dict = {'my_key': {'my_list': [1, 2, 3], 'my_int': 1}, 'my_int': 1, 'my_list': [1, 2, 3]}
    my_camel_dict = {'myKey': {'myList': [1, 2, 3], 'myInt': 1}, 'myInt': 1, 'myList': [1, 2, 3]}

    assert snake_dict_to_camel_dict(my_snake_dict) == my_camel_dict

