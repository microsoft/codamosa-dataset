

# Generated at 2022-06-20 15:44:23.875063
# Unit test for function dict_merge
def test_dict_merge():
    """
    This test runs through a list of test cases,
    rather than a single assertEqual.
    # TODO - convert to pytest (similar to other modules)
    """

# Generated at 2022-06-20 15:44:28.181273
# Unit test for function dict_merge
def test_dict_merge():
    # this test is not really exhaustive
    a = {'key1': {'key2': 'value1'}}
    b = {'key1': {'key2': 'value2'}}
    c = {'ckey1': 'cvalue1'}
    assert dict_merge(a, b) == {'key1': {'key2': 'value2'}}



# Generated at 2022-06-20 15:44:39.328359
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """This test asserts that snake_dict_to_camel_dict will
    recursively replace all snake_case with camelCase and
    return a dictionary that is unchanged if it is applied again
    """
    sample_dict = {
        "first_key": 1,
        "this_is_a_second_key": "second",
        "third_key": [
            "a",
            "b",
            "c"
        ],
        "fourth_key": {
            "this_is_another_key": "nested",
            "and_another": [
                "nested_list"
            ]
        },
        "fifth_key": None
    }

    camelized_dict = snake_dict_to_camel_dict(sample_dict)
    assert isinstance(camelized_dict, dict)
   

# Generated at 2022-06-20 15:44:47.554409
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'x': 1, 'y': 2}
    d2 = {'y': 3, 'z': 4}

    expected_result = {'x': 1, 'y': 3, 'z': 4}
    assert dict_merge(d1, d2) == expected_result

    d1 = {'x': 1, 'y': {'a': 1, 'b': 2}}
    d2 = {'y': {'b': 3, 'c': 4}}

    expected_result = {'x': 1, 'y': {'a': 1, 'b': 3, 'c': 4}}
    assert dict_merge(d1, d2) == expected_result

    d1 = {'x': 1, 'y': [{'a': 1, 'b': 2}]}

# Generated at 2022-06-20 15:45:00.135732
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'is_true': True,
        'is_false': False,
        'is_none': None,
        'int_value': 1,
        'string_value': 'something',
        'case_sensitive': 'CASE_SENSITIVE',
        'nested': {
            'is_true': True,
            'is_false': False,
            'is_none': None,
            'int_value': 1,
            'string_value': 'something',
            'case_sensitive': 'CASE_SENSITIVE'
        }
    }
    camel_dict = snake_dict_to_camel_dict(test_dict)

# Generated at 2022-06-20 15:45:07.696670
# Unit test for function dict_merge
def test_dict_merge():
    '''Unit test for function dict_merge'''

    # example data structure
    data = {'foo': {'bar': 'baz'}, 'baz': {'foo': 'bar'}}
    merged = dict_merge(data, dict(baz={'baz': 'foo'}))
    assert merged == {'foo': {'bar': 'baz'}, 'baz': {'foo': 'bar', 'baz': 'foo'}}
    assert data == {'foo': {'bar': 'baz'}, 'baz': {'foo': 'bar'}}

# Generated at 2022-06-20 15:45:15.437940
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'k1': 'v1', 'k2': {'k2sub1': 'v2sub1', 'k2sub2': 'v2sub2'}}
    dict2 = {'k1': 'v1', 'k2': {'k2sub1': 'v2sub1', 'k2sub2': 'v2sub2'}}
    diff = recursive_diff(dict1, dict2)
    assert diff == None, "recursive_diff() returned %s instead of None" % diff

    dict1 = {'k1': 'v1', 'k2': {'k2sub1': 'v2sub1', 'k2sub2': 'v2sub2'}}

# Generated at 2022-06-20 15:45:25.577185
# Unit test for function dict_merge
def test_dict_merge():
    dict_a = dict(
        foo=dict(
            bar=dict(
                baz='baz',
                fro='fro'
            )
        )
    )
    dict_b = dict(
        foo=dict(
            bar=dict(
                baz='newbaz',
                flob='flob'
            )
        )
    )
    dict_c = dict(
        foo=dict(
            bar=dict(
                baz='newbaz',
                fro='fro',
                flob='flob'
            )
        )
    )
    assert dict_merge(dict_a, dict_b) == dict_c



# Generated at 2022-06-20 15:45:33.675259
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {
                      'EndpointDescription': 'string',
                      'ContainerName': 'string',
                      'ContainerPort': 123,
                      'VpcEndpointId': 'string',
                      'VpcId': 'string',
                      'CreationTimestamp': 'string',
                      'ResourceArn': 'string'},
                  'ServiceName': 'string',
                  'NetworkConfiguration': {
                      'AwsvpcConfiguration': {
                          'Subnets': [
                              'string',
                          ],
                          'SecurityGroups': [
                              'string',
                          ],
                          'AssignPublicIp': 'ENABLED'}},
                  'DesiredStatus': 'string',
                  'Tags': [{
                      'Key': 'string',
                      'Value': 'string'}]}


# Generated at 2022-06-20 15:45:44.647596
# Unit test for function dict_merge
def test_dict_merge():
    """dict_merge unit test"""
    dict1 = {'k1': None, 'k2': 'v2', 'k3': {'k4': 1, 'k5': [1, 2, 3, 4]}}
    dict2 = {'k1': 'v1', 'k3': {'k6': 2}, 'k7': 1}
    dict3 = {'k1': 'v1', 'k2': 'v2', 'k3': {'k4': 1, 'k5': [1, 2, 3, 4], 'k6': 2}, 'k7': 1}
    assert dict_merge(dict1, dict2) == dict3
    assert dict_merge(dict2, dict1) == dict3


# Generated at 2022-06-20 15:46:00.470008
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.aws.core import AnsibleAWSModule
    from ansible.module_utils.ec2 import AWSRetry

    class Module(AnsibleAWSModule):
        pass

    module = Module()
    module.params = {
        'convert_param_case': 'snake',
        'convert_param_names': True
    }

    a = {'test_dict_merge': 'test', 'test_dict_merge_nested': {'test_dict_merge': 'test'}}
    b = {'test_dict_merge': 'test_override', 'test_dict_merge_nested': {'test_dict_merge': 'test_override'}}

# Generated at 2022-06-20 15:46:12.130151
# Unit test for function recursive_diff
def test_recursive_diff():
    # Arrange
    dict1 = {
        'level1': {
            'level2': {
                'level3a': 111,
                'level3b': {
                    'level4': 222
                },
                'level3c': '333'
            },
            'level2a': {
                'level3': 444,
                'level3a': 555
            }
        },
        'level1a': {
            'level2': {
                'level3': 666
            }
        }
    }


# Generated at 2022-06-20 15:46:23.755078
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'bar': [
                'HTTPEndpoint',
                'FooBar'
            ],
            'baz': {
                'tags': {
                    'key': 'value'
                }
            }
        },
        'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']
    }

# Generated at 2022-06-20 15:46:26.752814
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = dict_merge(a, b)
    assert c == { 'first' : { 'all_rows' : {
                              'pass' : 'dog',
                              'fail' : 'cat',
                              'number' : '5' } } }



# Generated at 2022-06-20 15:46:37.936729
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {
        'color': 'red',
        'size': 'large',
        'nested_list': [
            1,
            2,
            3
        ],
        'nested_dict': {
            'color': 'blue',
            'size': 'small'
        }
    }

    reference_camel = {
        'color': 'red',
        'size': 'large',
        'nestedList': [
            1,
            2,
            3
        ],
        'nestedDict': {
            'color': 'blue',
            'size': 'small'
        }
    }


# Generated at 2022-06-20 15:46:48.045055
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': 1, 'b': {'c': 2, 'd': 3}}, {}) == \
        {'a': 1, 'b': {'c': 2, 'd': 3}}
    assert dict_merge({}, {'a': 1, 'b': {'c': 2, 'd': 3}}) == \
        {'a': 1, 'b': {'c': 2, 'd': 3}}

# Generated at 2022-06-20 15:46:54.755052
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json

    camel_dict = json.loads(open('tests/unit/modules/cloudformation_create_stack/camel.json', 'r').read())
    snake_dict = json.loads(open('tests/unit/modules/cloudformation_create_stack/snake.json', 'r').read())

    result = camel_dict_to_snake_dict(camel_dict, ignore_list=['Tags'], reversible=True)
    assert snake_dict == result

    camel_dict = json.loads(open('tests/unit/modules/cloudformation_create_stack/camel_list.json', 'r').read())
    snake_dict = json.loads(open('tests/unit/modules/cloudformation_create_stack/snake_list.json', 'r').read())

    result = camel_dict_to_snake

# Generated at 2022-06-20 15:47:03.631532
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit tests for function recursive_diff"""
    a = {
        'foo': {
            'bar': 'baz',
            'fizz': {
                'buzz': 'taco',
                'baz': 'buzz',
                'nono': True,
                'nano': {
                    'nano1': 1,
                    'nano2': 2,
                    'nano3': {
                        'nano31': 31,
                        'nano32': 32,
                    },
                    'nano4': [
                        {
                            'nano41': 41,
                            'nano42': 42,
                        },
                        {
                            'nano51': 51,
                            'nano52': 52,
                        },
                    ],
                },
            },
        },
    }

# Generated at 2022-06-20 15:47:15.411881
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'key11': 'value1', 'key12': 'value2'}, 'key2': 'value3'}
    b = {'key1': {'key11': 'value4'}, 'key2': 'value5'}
    c = {'key1': {'key11': 'value4'}, 'key2': 'value3'}

    assert (dict_merge(a, b) == {'key1': {'key11': 'value4', 'key12': 'value2'}, 'key2': 'value5'})
    assert (dict_merge(a, c) == {'key1': {'key11': 'value4', 'key12': 'value2'}, 'key2': 'value3'})

# Generated at 2022-06-20 15:47:21.402101
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_input = {'foo_bar': 'baz', 'foo_bar_list': {'foo_bar_list': ['baz_bar', 'baz_bar_list']}}
    expected_output = {'fooBar': 'baz', 'fooBarList': {'fooBarList': ['bazBar', 'bazBarList']}}
    assert snake_dict_to_camel_dict(test_input) == expected_output



# Generated at 2022-06-20 15:47:39.047300
# Unit test for function dict_merge
def test_dict_merge():
    # Simple merge of two dicts
    print("Testing simple merge")
    a = {'foo': 1, 'bar': 2}
    b = {'foo': 3, 'baz': 4}
    c = dict_merge(a, b)
    assert c == {'foo': 3, 'bar': 2, 'baz': 4}
    print('.', end='')

    # Deep merge of two dicts
    print("Testing deep merge")
    c = {'foo': {'foo': 1, 'bar': 2}, 'baz': {'foo': 1, 'bar': 2}}
    d = {'foo': {'foo': 3, 'baz': 4}, 'baz': {'foo': 3, 'baz': 4}}
    e = dict_merge(c, d)

# Generated at 2022-06-20 15:47:48.004057
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'a': 1,
        'b': 5,
        'c': {
            'd': {
                'd1': 1,
                'd2': 2
            },
            'e': 3
        },
        'f': {
            'g': 1,
            'h': 2
        }
    }

    b = {
        'a': 2,
        'b': 5,
        'c': {
            'd': {
                'd2': 3
            },
            'e': 4
        },
        'f': {
            'h': 4
        }
    }


# Generated at 2022-06-20 15:47:56.923987
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "public_key": "MyPublicKey",
        "private_key": "MyPrivateKey",
        "other_key_with_underscore": "ThisIsATest",
        "my_list": [
            {"list_item": "test_item_1" },
            {"list_item": "test_item_2" }
        ]
    }
    camel_test_dict = snake_dict_to_camel_dict(test_dict)

# Generated at 2022-06-20 15:48:05.671213
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, 'simple nested merge failed'

    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'pass' : 'cat', 'number' : '5' } } }

# Generated at 2022-06-20 15:48:16.896439
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'k1': 'foo'}, {'k1': 'foo'}) is None
    assert recursive_diff({'k1': 'foo'}, {'k1': 'bar'}) == ({'k1': 'foo'}, {'k1': 'bar'})
    assert recursive_diff({'k1': 'foo'}, {'k2': 'foo'}) == ({'k1': 'foo'}, {'k2': 'foo'})
    assert recursive_diff({'k1': 'foo'}, {}) == ({'k1': 'foo'}, {})
    assert recursive_diff({}, {'k1': 'foo'}) == ({}, {'k1': 'foo'})

# Generated at 2022-06-20 15:48:28.302264
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 2}) is None
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 2}) == ({'a': 1}, {})
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 3}) == ({}, {'b': 3})
    assert recursive_diff({'a': 1, 'b': 2}, {'c': 3}) == ({'a': 1, 'b': 2}, {'c': 3})

# Generated at 2022-06-20 15:48:39.516966
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'nested': {'b': 2, 'c': 3}, 'd': 4, 'e': 5}
    b = {'d': 0, 'nested': {'f': 6}, 'g': 7, 'h': 8}
    c = {'a': 1, 'nested': {'b': 2, 'c': 3, 'f': 6}, 'd': 0, 'e': 5, 'g': 7, 'h': 8}
    assert dict_merge(a, b) == c
    assert dict_merge(b, a) == {'a': 1, 'nested': {'b': 2, 'c': 3, 'f': 6}, 'd': 4, 'e': 5, 'g': 7, 'h': 8}


# Generated at 2022-06-20 15:48:46.452228
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Foo': 'bar',
        'Blue': 'red',
        'Bar': {
            'Foo': 'bar',
            'Bar': 'foo',
            'Baz': 'quz',
            'Tags': {
                'Env': 'dev'
            }
        }
    }

    expected_dict = {
        'foo': 'bar',
        'blue': 'red',
        'bar': {
            'foo': 'bar',
            'bar': 'foo',
            'baz': 'quz',
            'tags': {
                'Env': 'dev'
            }
        }
    }

    result = camel_dict_to_snake_dict(test_dict)
    assert expected_dict == result

# Generated at 2022-06-20 15:48:54.430963
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:49:00.650937
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1}, {'a': 1}) == None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'a': {'b': 1}}) == ({'a': 1}, {'a': {'b': 1}})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'c': 1}}) == ({'a': {'b': 1}}, {'a': {'c': 1}})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}}) == ({'a': {'b': 1}}, {'a': {'b': 2}})
    assert recursive_diff

# Generated at 2022-06-20 15:49:15.619087
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'baz_bar': 'baz_bar_value',
        'nested_dict': {
            'foo_bar': 'foo_bar_value',
            'nested_list': [
                {'foo_bar': 'foo_bar_value'},
                {'baz_bar': 'baz_bar_value'},
            ],
            'nested_list_2': [
                'baz_bar',
                'foo_bar',
            ],
        },
    }

    camel_dict = snake_dict_to_camel_dict(snake_dict)


# Generated at 2022-06-20 15:49:25.811304
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    module = AnsibleModule({})
    params = {
        'list': [
            {
                'name': 'test-service',
                'tags': {
                    'Name': 'test-service',
                    'Env': 'prod',
                    'Test': 'test',
                    'foo': 'bar'
                }
            }
        ]
    }

    camel_dict = {'list': [{'Name': 'test-service', 'tags': {'Name': 'test-service', 'Env': 'prod', 'Test': 'test',
                                                            'foo': 'bar'}}]}
    assert module.snake_dict_to_camel_dict(params) == camel_dict

# Generated at 2022-06-20 15:49:34.149218
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit test for recursive_diff """

    # Test case 1: simple maps with no nested maps
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = {'a': 2, 'b': 2, 'c': 4}
    assert recursive_diff(dict1, dict2) == ({'a': 1}, {'a': 2, 'c': 4})

    # Test case 2: Simple maps with some nested maps
    dict1 = {'a': 1, 'b': {'c': 3, 'd': 6}, 'e':5}
    dict2 = {'a': 2, 'b': {'c': 5, 'd': 6}, 'e':5}

# Generated at 2022-06-20 15:49:38.972431
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = dict(a=1, b=2, c=dict(d=4, e=5))
    d2 = dict(a=1, c=dict(d=4, f=6))
    try:
        assert recursive_diff(None, None)
    except TypeError:
        pass
    else:
        raise AssertionError("Exception not raised.")

    assert recursive_diff(d1, d2) == (dict(b=2), dict(b=None, c=dict(e=None, f=6)))
    assert recursive_diff(d2, d1) == (dict(b=None, c=dict(e=5, f=None)), dict(b=2))
    assert recursive_diff(d1, d1) is None
    assert recursive_diff(d2, d2) is None

# Generated at 2022-06-20 15:49:48.846633
# Unit test for function dict_merge
def test_dict_merge():
    try:
        a = {'foo': 'bar', 'awesome': 'yes', 'fizz': 'buzz', 'nested': {'key': 'value', 'foo': 'bar'}}
        b = {'foo': 'baz', 'awesome': 'no', 'nested': {'key': 'value', 'foo': 'baz'}}
        c = dict_merge(a, b)
        assert c == {'foo': 'baz', 'awesome': 'no', 'fizz': 'buzz', 'nested': {'key': 'value', 'foo': 'baz'}}
    except:
        raise
    else:
        return True



# Generated at 2022-06-20 15:49:58.165778
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:50:04.199795
# Unit test for function dict_merge
def test_dict_merge():
    a = {'id': 1, 'foo': {'a': 1, 'b': 2}}
    b = {'id': 2, 'foo': {'b': 3, 'c': 4}}
    expect = {'id': 2, 'foo': {'a': 1, 'b': 3, 'c': 4}}
    assert dict_merge(a, b) == expect

# Generated at 2022-06-20 15:50:10.711216
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(a=dict(b=1, c=2))
    dict2 = dict(a=dict(b=3, d=4))
    assert dict_merge(dict1, dict2) == dict(a=dict(b=3, c=2, d=4))
    dict1 = dict(a=dict(b=1, c=2))
    dict2 = dict()
    assert dict_merge(dict1, dict2) == dict(a=dict(b=1, c=2))

# Generated at 2022-06-20 15:50:18.222999
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test empty and non-empty dictionaries
    assert recursive_diff({}, {'foo' : 'bar'}) == ({}, {'foo' : 'bar'})

    # Test non-empty and empty dictionaries
    assert recursive_diff({'foo' : 'bar'}, {}) == ({'foo' : 'bar'}, {})

    # Test no differences
    assert recursive_diff({'foo' : 'bar'}, {'foo' : 'bar'}) is None

    # Test different values
    assert recursive_diff({'foo' : 'bar'}, {'foo' : 'baz'}) == ({'foo' : 'bar'}, {'foo' : 'baz'})

    # Test different keys

# Generated at 2022-06-20 15:50:27.294259
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_case_dict = {
        'input_dict': {
            'first_name': 'Tom',
            'last_name': 'Smith',
            'age': 25,
            'address': {
                'street_address': '21 2nd Street',
                'city': 'New York',
                'state': 'NY',
                'postal_code': 10021
            },
            'phone_number': [
                {
                    'type': 'home',
                    'number': '212 555-1234'
                },
                {
                    'type': 'office',
                    'number': '646 555-4567'
                },
                {
                    'type': 'mobile',
                    'number': '123 456-7890'
                }
            ]
        }
    }



# Generated at 2022-06-20 15:50:57.708138
# Unit test for function dict_merge
def test_dict_merge():
    first_dict = {'foo': {'bar': 'baz'}}
    second_dict = {'foo': {'foobar': 'baz'}}
    expected = {'foo': {'bar': 'baz', 'foobar': 'baz'}}
    assert dict_merge(first_dict, second_dict) == expected
    assert dict_merge(second_dict, first_dict) == expected


# Generated at 2022-06-20 15:51:02.869908
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    sample_dict = {"VpcId": 123, "test_test": [{"testTets": {"testTets": [1, 2, 3]}}], "testTets": "test"}
    assert snake_dict_to_camel_dict(sample_dict) == sample_dict

# Generated at 2022-06-20 15:51:08.945074
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test cases
    test1 = {
        "Name": "app",
        "Tags": [{
            "Key": "env",
            "Value": "prod"
        }, {
            "Key": "stack",
            "Value": "17"
        }, {
            "Key": "version",
            "Value": "2.2.1"
        }],
        "DesiredCapacity": 1,
        "MaxSize": 1,
        "MinSize": 1
    }

# Generated at 2022-06-20 15:51:21.605494
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        'a': 'A',
        'b': 'B',
        'c': {'c1': 'C1', 'c2': 'C2'},
        'd': {'d1': 'D1', 'd2': ['d2a', 'd2b']},
    }

    d2 = {
        'b': 'b',
        'c': {'c2': 'c2', 'c3': 'C3'},
        'd': {'d2': 'd2', 'd3': ['d3a', 'd3b']},
    }


# Generated at 2022-06-20 15:51:30.814012
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 1, 'b': 2, 'c': 3, 'd': {'a': 1, 'b': 2, 'c': 3, 'e': 4}}
    d2 = {'a': 2, 'b': 2, 'd': {'a': 1, 'b': 20, 'c': 3, 'f': 5}}
    d3 = {'a': 2, 'b': 2, 'd': {'a': 1, 'b': 20, 'c': 3, 'f': 5, 'g': 6}}
    assert recursive_diff(d1, d2) == ({'a': 1, 'c': 3}, {'a': 2}), "Invalid result"
    assert recursive_diff(d2, d3) == ({'g': 6}, {'g': None}), "Invalid result"

# Generated at 2022-06-20 15:51:42.290927
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    >>> test_recursive_diff()
    """
    assert recursive_diff({}, {}) is None
    assert recursive_diff({}, {'key': 'value'}) == ({}, {'key': 'value'})
    assert recursive_diff({'key': 'value'}, {}) == ({'key': 'value'}, {})
    assert recursive_diff({'key': 'value'}, {'key': 'value'}) is None
    assert recursive_diff({'key': 'value'}, {'key': 'value2'}) == ({'key': 'value'}, {'key': 'value2'})

    assert recursive_diff({'key': 'value'}, {'key': 'value', 'key2': 'value2'}) == ({'key': 'value'}, {'key2': 'value2'})
    assert recursive

# Generated at 2022-06-20 15:51:54.061195
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        "foo": {"bar": "baz"},
        "list": [1, 2, 3],
        "set": set([1, 2, 3]),
        "a": 1,
        "b": 2,
        "c": 3
    }
    right = {
        "foo": {"bar": "qux"},
        "list": [1, 2, 3, 4],
        "set": set([1, 2, 3, 4, 5]),
        "a": 10,
        "c": 3,
        "d": 4
    }
    diff = recursive_diff(left, right)
    assert diff[0]["foo"]["bar"] == "baz", \
        "Difference for nested element 'foo.bar' is incorrect."

# Generated at 2022-06-20 15:52:05.687581
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:52:18.276649
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a':{'b':1}}, {'a':{'b':1}}) is None
    assert recursive_diff({'a':{'b':1}}, {'a':{'b':1, 'c':2}}) == ({}, {'a': {'c': 2}})
    assert recursive_diff({'a':{'b':1}}, {'a':{'b':2, 'c':2}}) == ({'a': {'b': 1}}, {'a': {'b': 2, 'c': 2}})
    try:
        recursive_diff({'a':{'b':1}}, {})
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-20 15:52:29.150827
# Unit test for function dict_merge
def test_dict_merge():

    # Test we get a deep copy back
    dict1 = {'a': {'b': {'c': 'y'}}}
    dict2 = dict_merge(dict1, {})
    assert dict2 == dict1
    assert id(dict1) != id(dict2)
    assert id(dict1['a']) != id(dict2['a'])
    assert id(dict1['a']['b']) != id(dict2['a']['b'])

    # Test a simple merge
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 5, 'b': 6}
    dict3 = {'c': {'d': 7, 'f': 8}}

# Generated at 2022-06-20 15:53:07.271245
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test for function with dict having dict within dict
    dict1 = {'l1_key1': 'l1_value1',
             'l1_key2': 'l1_value2',
             'l1_key3': 'l1_value3',
             'l1_key4': {'l2_key1': 'l2_value1',
                         'l2_key2': 'l2_value2',
                         'l2_key3': {'l3_key1': 'l3_value1',
                                     'l3_key2': 'l3_value2'}}}

# Generated at 2022-06-20 15:53:18.784678
# Unit test for function dict_merge
def test_dict_merge():
    # Tests for dict_merge

    # Test1:
    # Input: {"a": {"b": 1, "d": 2}, "e": 5}
    #        {"a": {"b": 3, "c": 4}, "e": 6, "f": 7}
    # Expected result: {"a": {"b": 3, "d": 2, "c": 4}, "e": 6, "f": 7}
    # Actual result: {"a": {"b": 3, "d": 2, "c": 4}, "e": 6, "f": 7}
    a = {"a": {"b": 1, "d": 2}, "e": 5}
    b = {"a": {"b": 3, "c": 4}, "e": 6, "f": 7}
    result = dict_merge(a, b)
    expected_

# Generated at 2022-06-20 15:53:29.962111
# Unit test for function dict_merge
def test_dict_merge():
    """Unit test for function dict_merge
    """
    try:
        import ict_dict
    except ImportError:
        return False

    dict1 = {'a': 1, 'b': {'B1': [1, 2, 3], 'B2': [4, 5, 6]}}
    dict2 = {'a': 2, 'b': {'B2': [7, 8, 9], 'B3': [10, 11, 12]}}
    dict3 = {'a': 1, 'b': {'B1': [1, 2, 3], 'B2': [7, 8, 9], 'B3': [10, 11, 12]}}

    dict_merge_test = dict_merge(dict1, dict2)
    dict_merge_test_expected = dict3

    return ict_dict

# Generated at 2022-06-20 15:53:37.799409
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel_dict = {
        "SubnetId": "subnet-12345678",
        "VpcId": "vpc-12345678",
        "Tags": [
            {
                "Key": "Name",
                "Value": "foo"
            },
            {
                "Key": "Environment",
                "Value": "dev"
            }
        ]
    }
    snake_dict = snake_dict_to_camel_dict(camel_dict)
    assert snake_dict['subnet_id'] == 'subnet-12345678'
    assert snake_dict['vpc_id'] == 'vpc-12345678'
    assert snake_dict['tags'][0]['key'] == 'Name'
    assert snake_dict['tags'][0]['value'] == 'foo'
    assert snake_

# Generated at 2022-06-20 15:53:46.884043
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test method for recursive_diff()."""
    a = {'x': 1, 'y': 2, 'z': {'a': 1, 'b': 2, 'c': 3}}
    b = {'x': 1, 'y': 2, 'z': {'a': 1, 'b': 45, 'c': 3}}

    assert recursive_diff(a, b) == ({'z': {'b': 2}}, {'z': {'b': 45}})
    assert recursive_diff(a, a) is None
    assert recursive_diff(a, {'x': 1, 'y': 2, 'w': 5}) == ({'z': {'a': 1, 'b': 2, 'c': 3}}, {'w': 5})

# Generated at 2022-06-20 15:53:53.808675
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1, 'c': 1}}
    d2 = {'a': {'b': 1, 'c': 2}}
    d1['a']['d'] = d1['a'].copy()
    d1['e'] = d1['a'].copy()
    d1['a']['b'] = 2
    d2['a']['c'] = 3
    assert d2 == dict_merge(d1, d2)



# Generated at 2022-06-20 15:54:03.958564
# Unit test for function dict_merge
def test_dict_merge():

    a = {
      'a': 'a',
      'b': 'b',
      'c': {
        'c1': 'c1',
        'c2': 'c2'
      },
      'd': 'd'
    }

    b = {
      'b': 'b_',
      'c': {
        'c1': 'c1_',
        'c3': 'c3'
      },
      'e': 'e'
    }

    c = {
      'a': 'a',
      'b': 'b_',
      'c': {
        'c1': 'c1_',
        'c2': 'c2',
        'c3': 'c3'
      },
      'd': 'd',
      'e': 'e'
    }
