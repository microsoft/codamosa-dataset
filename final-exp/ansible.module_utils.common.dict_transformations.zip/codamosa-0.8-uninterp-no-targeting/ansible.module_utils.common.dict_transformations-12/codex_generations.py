

# Generated at 2022-06-20 15:44:19.305936
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    with open('test_resources/camel_dict.yml') as f:
        cdict = yaml.load(f)
    with open('test_resources/snake_dict.yml') as f:
        sdict = yaml.load(f)
    assert (snake_dict_to_camel_dict(sdict) == cdict)


# Generated at 2022-06-20 15:44:26.812796
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        'foo': {
            'bar': {
                'baz': 1
            }
        }
    }

    b = {
        'foo': {
            'bar': {
                'baz': 2
            }
        }
    }

    expected = {
        'foo': {
            'bar': {
                'baz': 2
            }
        }
    }

    assert dict_merge(a, b) == expected, 'dict_merge failed to overwrite values in nested dictionaries'


# Generated at 2022-06-20 15:44:37.900690
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:44:46.690338
# Unit test for function dict_merge
def test_dict_merge():
    """
    Unit test for function dict_merge.
    """
    assert dict_merge({'foo': {'bar': 42}}, {'foo': {'baz': 77}}) == {'foo': {'baz': 77, 'bar': 42}}
    assert dict_merge({'foo': {'bar': 42}}, {'baz': 77}) == {'foo': {'bar': 42}, 'baz': 77}
    assert dict_merge({'x': 42}, {'foo': {'bar': 77}}) == {'foo': {'bar': 77}, 'x': 42}
    assert dict_merge({'foo': {'bar': 42}}, {'foo': {'baz': 77}}) == {'foo': {'baz': 77, 'bar': 42}}
    assert dict_merge

# Generated at 2022-06-20 15:44:52.131897
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(foo=dict(bar=dict(baz=42),
                          bam=dict(baz=53,
                                   bap='hello'),
                          bap='world'),
                 hello=1)
    dict2 = dict(foo=dict(bar=dict(baz=42,
                                    bat=43),
                          bam=dict(baz=53,
                                   bap='yeehaw')))
    dict3 = dict_merge(dict1, dict2)
    expected = dict(foo=dict(bar=dict(baz=42,
                                       bat=43),
                             bam=dict(baz=53,
                                      bap='yeehaw'),
                             bap='world'),
                    hello=1)
    assert dict3 == expected



# Generated at 2022-06-20 15:45:02.897157
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {'id': '123', 'cloud_provider_tags': [{'key': 'key', 'value': 'value'}, {'key': 'key2', 'value': 'value2'}],
                 'monitored': True, 'account': '123456', 'tags': {'key': 'value'}, 'location': 'us-east-1', 'name': 'test'}
    result = snake_dict_to_camel_dict(test_dict)
    assert result['id'] == '123'
    assert result['cloudProviderTags'] == [{'key': 'key', 'value': 'value'}, {'key': 'key2', 'value': 'value2'}]
    assert result['monitored'] == True
    assert result['account'] == '123456'

# Generated at 2022-06-20 15:45:12.842992
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:45:24.752586
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': '1',
        'b': {
            'c': '1',
            'd': {
                'e': '1',
                'f': '1',
                'g': '1'
            },
            'h': {
                'i': '1'
            },
            'j': '1'
        }
    }
    dict2 = {
        'a': '1',
        'b': {
            'c': '1',
            'd': {
                'e': '1',
                'f': '2',
                'g': '1'
            },
            'h': {
                'i': '2'
            },
            'j': '1'
        }
    }

# Generated at 2022-06-20 15:45:32.626554
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(
        k1 = dict(
            k1d1 = "1",
            k1d2 = "2",
        ),

        k2 = dict(
            k2d1 = dict(
                k2d1d1 = "hi"
            ),

            k2d2 = dict(
                k2d2d1 = "ho",
            )
        )
    )
    dict1_list = [dict1, ]
    dict2 = deepcopy(dict1)
    dict2_list = [dict2, ]

    assert recursive_diff(dict1, dict1) == None
    assert recursive_diff(dict1, dict2) == None

    # Change a string
    dict2["k1"]["k1d1"] = "one"

# Generated at 2022-06-20 15:45:44.136652
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({'snake_case': 'foo'}) == {'snakeCase': 'foo'}, \
        'snake_case to snakeCase failed'
    assert snake_dict_to_camel_dict({'snake_case': 'foo', 'snake_case_int': 1}) == {'snakeCase': 'foo', 'snakeCaseInt': 1}, \
        'SnakeCaseInt to snakeCaseInt failed'

# Generated at 2022-06-20 15:46:00.965619
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:46:12.328044
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    my_dict = {
        'test_test':'test',
        'test_test_dict_one':{
            'test_test_one': 'test_one'
        },
        'test_test_dict_two':{
            'test_test_two':'test_two'
        },
        'test_test_list':[{
            'test_test_three':'test_three'
        }],
        'test_token_key':'test_token_value',
        'token_key':'token_value',
        'key_with_numbers_and_letters':'value_with_numbers_and_letters',
        'another_key_with_numbers_and_letters':'another_value_with_numbers_and_letters'
    }


# Generated at 2022-06-20 15:46:19.498799
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'b':2, 'a': 1, 'c':{'x':5, 'y': [1,2,3,4,5]}}
    dict2 = {'b':3, 'a': 1, 'c':{'x':6, 'y': [1,2,3,6,5]}}
    diff = recursive_diff(dict1, dict2)

    assert diff
    assert diff[0] == {'b': 2}
    assert diff[1] == {'b': 3}
    assert 'c' in diff[0]
    assert 'c' in diff[1]
    assert diff[0]['c'] == {'x':5}
    assert diff[1]['c'] == {'x':6}
    assert 'y' in diff[0]['c']

# Generated at 2022-06-20 15:46:24.376575
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'HTTPEndpoint':"1"}) == {'http_endpoint':"1"})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint':[]}) == {'http_endpoint':[]})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint':{}}) == {'http_endpoint':{}})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint':None}) == {'http_endpoint':None})

# Generated at 2022-06-20 15:46:34.443255
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(key='value')
    dict2 = dict(key='value')
    result = recursive_diff(dict1, dict2)
    assert not result

    dict2['otherkey'] = 'othervalue'
    result = recursive_diff(dict1, dict2)
    assert result == ({'otherkey': 'othervalue'}, {})

    dict1['key'] = 'othervalue'
    result = recursive_diff(dict1, dict2)
    assert result == ({'key': 'othervalue'}, {'key': 'value'})

    dict1['key'] = dict(subkey='subvalue')
    dict2['key'] = dict(subkey='subvalue')
    result = recursive_diff(dict1, dict2)
    assert not result


# Generated at 2022-06-20 15:46:44.962139
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'A': 'A',
        'B': {
            'C': {
                'D': 'E'
            }
        }
    }

    b = {
        'B': {
            'C': {
                'F': 'G'
            },
            'H': 'I'
        }
    }

    c = {
        'B': {
            'C': {
                'D': 'L',
                'F': 'G'
            },
            'H': 'I'
        },
        'J': 'K'
    }

    assert dict_merge(a, b) == c

    assert a == {
        'A': 'A',
        'B': {
            'C': {
                'D': 'E'
            }
        }
    }



# Generated at 2022-06-20 15:46:52.986547
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'first_name': 'Michael',
        'last_name': 'Herman',
        'languages': [
            {
                'name': 'Python',
                'releases': [
                    {
                        'version': '3.6',
                        'date': '2016-12-23'
                    },
                    {
                        'version': '3.7',
                        'date': '2018-06-27'
                    }
                ]
            },
            {
                'name': 'JavaScript',
                'releases': [
                    {
                        'version': 'ES6',
                        'date': '2015-06-15'
                    },
                    {
                        'version': 'ES7',
                        'date': '2016-06-15'
                    }
                ]
            }
        ]
    }

# Generated at 2022-06-20 15:47:02.359920
# Unit test for function recursive_diff
def test_recursive_diff():
    import pytest
    def recursive_dict_in_list(tup):
        if isinstance(tup, tuple):
            for item in tup:
                for key, value in item.items():
                    if isinstance(value, dict):
                        var.append(key)
                        recursive_dict_in_list(value)
        else:
            return None
    var = []
    dict1 = {'A': 'a', 'B': {'X': 'x', 'Y': 'y'}, 'C': {'Z': 'z'}}
    dict2 = {'A': 'A', 'B': {'X': 'x', 'Y': 'y'}, 'C': {'Z': 'z'}}
    result = recursive_diff(dict1, dict2)
    recursive_dict_in_list(result)
   

# Generated at 2022-06-20 15:47:12.787138
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=1, b=2, c=dict(c1=1, c2=2, c3=3), d=dict(d1=1, d2=2))
    b = dict(a=1, b=2, c=dict(c3=3, c4=4), d=dict(d1=1, d3=3))
    c = dict(a=1, b=2, c=dict(c1=1, c2=2, c3=3, c4=4), d=dict(d1=1, d2=2, d3=3))
    assert dict_merge(a, b) == c



# Generated at 2022-06-20 15:47:22.861417
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'policies': [
            {
                'policyName': 'allow-get-bucket-location-eh',
                'policyDocument': {
                    'Version': '2012-10-17',
                    'Statement': [{
                        'Sid': 'allow-get-bucket-location',
                        'Effect': 'Allow',
                        'Principal': {
                            'AWS': 'arn:aws:iam::123456789012:user/Bob'
                        },
                        'Action': 's3:GetBucketLocation',
                        'Resource': 'arn:aws:s3:::mybucket'
                    }]
                }
            }
        ]
    }


# Generated at 2022-06-20 15:47:37.022220
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"test_key": "value"},
                                    capitalize_first=True) == {"TestKey": "value"}
    assert snake_dict_to_camel_dict({"test_key": "value"}) == {"testKey": "value"}
    assert snake_dict_to_camel_dict({"TestKey": {"test_key_2": "value"}}) == {"TestKey": {"testKey2": "value"}}



# Generated at 2022-06-20 15:47:46.993391
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test 1: General case
    camel_dict = {
        "foo": "bar",
        "baz": "qux",
        "list": [1, 2, 3],
        "dict": {
            "foo": "bar",
            "qux": "quux"
        }
    }
    test_snaked_dict = {
        "foo": "bar",
        "baz": "qux",
        "list": [1, 2, 3],
        "dict": {
            "foo": "bar",
            "qux": "quux"
        }
    }
    snaked_dict = camel_dict_to_snake_dict(camel_dict)
    assert(snaked_dict == test_snaked_dict)

    # Test 2: Case where a module returns a list of dictionaries

# Generated at 2022-06-20 15:47:56.081531
# Unit test for function dict_merge
def test_dict_merge():
    """Ensure dict_merge behaves as expected"""

    # Create some sample data
    dict1 = {
        'key1': 'val1',
        'key2': 'val2',
        'key3': {
            'dict1': 'val1',
            'dict2': 'val2',
            'dict3': {
                'dict1': 'val1',
                'dict2': 'val2',
                'list1': [
                    'val1',
                    {
                        'listdict1': 'val1',
                        'listdict2': 'val2',
                    },
                    'val3'
                ]
            }
        }
    }

# Generated at 2022-06-20 15:48:01.230585
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(
        {'my_string': 'string'}
    ) == {'myString': 'string'}

    assert snake_dict_to_camel_dict(
        {'my_string': 'string', 'my_int': 1, 'my_boolean': True, 'my_null': None}
    ) == {'myString': 'string', 'myInt': 1, 'myBoolean': True, 'myNull': None}

    assert snake_dict_to_camel_dict(
        {'my_list': ['a', 'b', 'c'], 'my_dict': {'my_sub_string': 'string'}}
    ) == {'myList': ['a', 'b', 'c'], 'myDict': {'mySubString': 'string'}}

# Generated at 2022-06-20 15:48:08.964444
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'k1': {'k11': [1, 2, 3]}, 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    dict2 = {'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    assert recursive_diff(dict1, dict2) == ({'k1': {'k11': [1, 2, 3]}}, {})

    dict3 = {'key1': 'value1'}
    dict4 = {'key2': 'value2'}
    assert recursive_diff(dict3, dict4) == ({'key1': 'value1'}, {'key2': 'value2'})


# Generated at 2022-06-20 15:48:17.144942
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'b1': 11, 'b2': 12}, 'c': 3}
    dict2 = {'a': 1, 'b': {'b1': 11, 'b2': 122}, 'c': 33}
    dict_result1_2 = recursive_diff(dict1, dict2)
    assert dict_result1_2[0] == {'b': {'b2': 12}, 'c': 3}
    assert dict_result1_2[1] == {'b': {'b2': 122}, 'c': 33}

# Generated at 2022-06-20 15:48:25.777510
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'snake_case': {'inner_snake': {'innermost_snake': 'value'}, 'test_test': 'value'}, 'snake_test': 'value', 'tag_test': 'value'}) == {'snakeCase': {'innerSnake': {'innermostSnake': 'value'}, 'testTest': 'value'}, 'snakeTest': 'value', 'tagTest': 'value'}

# Unit tests for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:48:33.812859
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = dict(my_key='my_value')
    result_dict = dict(myKey='my_value')
    assert(snake_dict_to_camel_dict(test_dict) == result_dict)

    test_dict = dict(mY_Key='my_value')
    result_dict = dict(mYKey='my_value')
    assert(snake_dict_to_camel_dict(test_dict) == result_dict)

    test_dict = dict(my_key='my_value', my_key2='my_value', my_key3='my_value')
    result_dict = dict(myKey='my_value', myKey2='my_value', myKey3='my_value')

# Generated at 2022-06-20 15:48:45.713255
# Unit test for function recursive_diff
def test_recursive_diff():
    # TODO: create a unit test using pytest
    # Example from https://docs.python.org/3/library/unittest.html
    import unittest
    class TestRecursiveDiff(unittest.TestCase):
        def setUp(self):
            pass

        def test_recursive_diff(self):
            # User has not specified any properties in playbook, and the API response is in Camel Case
            # They should result in no changes
            d1 = {"efgh": {"mnop": 4567, "qrst": 89}}
            d2 = {"efgh": {"mnop": 4567, "qrst": 89}}
            result = recursive_diff(d1, d2)
            self.assertEqual(result, None)

            # User wants to change property mnop in response and API response is in Camel Case

# Generated at 2022-06-20 15:48:51.368088
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'foo': {'bar': 1}}, {'foo': {'baz': 2}}) == {'foo': {'bar': 1, 'baz': 2}}
    assert dict_merge({'foo': {'bar': 1}}, {'foo': {'bar': {'baz': 2}}}) == {'foo': {'bar': {'baz': 2}}}
    assert dict_merge({'foo': {'bar': 1}}, {'foo': 2}) == {'foo': 2}


# Generated at 2022-06-20 15:49:03.470615
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:49:14.272416
# Unit test for function dict_merge
def test_dict_merge():

    class TestObj(object):
        def __init__(self):
            self.dict = {
                'foo': 'bar',
                'nest': {
                    'foo': 'bar',
                    'nest': {
                        'foo': 'bar',
                        'nest': {'foo': 'bar'},
                        'list': ['one', 'two', {'foo': 'bar'}]
                    },
                    'list': ['one', 'two', {'foo': 'bar'}]
                },
                'list': ['one', 'two', {'foo': 'bar'}]
            }

        def test_overwrite_values(self):
            merged = dict_merge(self.dict, {'foo': 'baz'})
            assert merged['foo'] == 'baz'

# Generated at 2022-06-20 15:49:25.635166
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:49:33.838908
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(foo='bar', spam=dict(eggs=list(range(10))))
    dict2 = dict(bar='baz', spam=dict(eggs=list(range(11))))
    dict3 = dict(foo='bar', spam=dict(eggs=list(range(11))))
    assert recursive_diff(dict1, dict2) == ({'foo': 'bar'}, {'bar': 'baz', 'spam': {'eggs': [10]}})
    assert recursive_diff(dict1, dict3) == ({'spam': {'eggs': [10]}}, {'spam': {'eggs': [10]}})
    assert recursive_diff(dict2, dict3) == ({'bar': 'baz'}, {'foo': 'bar'})

# Generated at 2022-06-20 15:49:45.078030
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == expected

    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'second' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }

# Generated at 2022-06-20 15:49:54.875756
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'FooBar': 1}
    assert(camel_dict_to_snake_dict(camel_dict) == {'foo_bar': 1})

    camel_dict = {'FooBarBaz': [1, 2, 3]}
    assert(camel_dict_to_snake_dict(camel_dict) == {'foo_bar_baz': [1, 2, 3]})

    camel_dict = {'FooBarBaz': {'BarBarBar': [1, 2, 3]}}
    assert(camel_dict_to_snake_dict(camel_dict) == {'foo_bar_baz': {'bar_bar_bar': [1, 2, 3]}})



# Generated at 2022-06-20 15:50:02.051960
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b=2, d=dict(f=0, g=110), e=dict(h=0, i=100))
    dict2 = dict(b=2, d=dict(f=30, g=110))
    assert recursive_diff(dict1, dict2) == ({'a': 1, 'e': {'h': 0, 'i': 100}}, {'d': {'f': 30}, 'e': {'h': 0, 'i': 100}})

    dict3 = dict(a=1, d=dict(f=1, g=110), e=dict(h=1, i=100))

# Generated at 2022-06-20 15:50:12.011343
# Unit test for function dict_merge
def test_dict_merge():
    # Simple merge
    dict1 = dict(a=dict(b=1, c=2), d=3)
    dict2 = dict(a=dict(b=4, d=5), e=6)
    res = dict(a=dict(b=4, c=2, d=5), d=3, e=6)
    assert dict_merge(dict1, dict2) == res

    # Merge with None
    dict1 = dict(a=dict(b=1, c=2), d=3)
    dict2 = dict(a=dict(b=4, c=None), e=6)
    res = dict(a=dict(b=4, c=2), d=3, e=6)
    assert dict_merge(dict1, dict2) == res


# Generated at 2022-06-20 15:50:21.683381
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "test_key_one": "test_value_one",
        "test_key_two": {
            "test_key_three": "test_value_two"
        }
    }

    camel_dict = {
        "TestKeyOne": "test_value_one",
        "TestKeyTwo": {
            "TestKeyThree": "test_value_two"
        }
    }

    camel_dict_no_cap = {
        "testKeyOne": "test_value_one",
        "testKeyTwo": {
            "testKeyThree": "test_value_two"
        }
    }

    assert snake_dict_to_camel_dict(snake_dict) == camel_dict_no_cap

# Generated at 2022-06-20 15:50:31.340952
# Unit test for function recursive_diff
def test_recursive_diff():
    import pytest

    # Test basic functionality
    dict1 = {'key1': 'value1', 'key2': {'key3': 'value3'}}
    dict2 = {'key1': 'value1', 'key2': {'key4': 'value4'}}
    expected = ({'key2': {'key3': 'value3'}}, {'key2': {'key4': 'value4'}})
    assert recursive_diff(dict1, dict2) == expected

    # Test empty dictionaries
    assert recursive_diff({}, {}) == None

    # Test that keys defined in only one dictionary are returned
    dict1 = {'key1': 'value1', 'key2': {'key3': 'value3'}}
    dict2 = {'key1': 'value1', 'key2': {}}
   

# Generated at 2022-06-20 15:50:46.606023
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:50:57.061403
# Unit test for function recursive_diff
def test_recursive_diff():

    input_dict1 = {
        "Name": "TEST_NAME",
        "Tags": {"KEY1": "VAL1"},
        "Parent": {
            "Name": "PARENT_NAME",
            "Tags": {"KEY1": "VAL1"},
            "Children": [
                {"Name": "CHILD_NAME",
                 "Tags": {"KEY1": "VAL1"},
                 }
            ],
        },
    }


# Generated at 2022-06-20 15:51:07.647998
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'first': 1,
        'second': {
            'one': 11,
            'two': 12,
        },
    }
    b = {
        'first': 2,
        'second': {
            'one': 21,
            'three': 13,
        },
    }
    assert dict_merge(a, b) == {
        'first': 2,
        'second': {
            'one': 21,
            'two': 12,
            'three': 13,
        },
    }
    assert dict_merge({'a': [1, 2]}, {'a': [3, 4]}) == {'a': [3, 4]}


# Generated at 2022-06-20 15:51:20.568710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    simple_dict = {'Key1': 'Value1', 'Key2': 'Value2'}
    expected_result = {'key1': 'Value1', 'key2': 'Value2'}
    assert camel_dict_to_snake_dict(simple_dict) == expected_result

    assert camel_dict_to_snake_dict(camel_dict_to_snake_dict(simple_dict)) == expected_result

    complex_dict = {'Key1': 'Value1', 'Key2': {'Key3': {'Key4': 'Value3', 'Key5': 'Value2'}}}
    expected_result2 = {'key1': 'Value1', 'key2': {'key3': {'key4': 'Value3', 'key5': 'Value2'}}}
    assert camel_dict_to_snake

# Generated at 2022-06-20 15:51:29.128339
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Tests whether snake_dict_to_camel_dict returns the expected dromedaryCase dict
    """
    snake_dict = dict(max_file_size=1, max_files_per_folder=2, ref_id='external_id')
    expected_camel_dict = dict(maxFileSize=1, maxFilesPerFolder=2, refId='external_id')
    recamelized_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=True)
    if recamelized_dict != expected_camel_dict:
        raise AssertionError("Expected snake_dict_to_camel_dict to return %s, but got %s" % (expected_camel_dict, recamelized_dict))


# Generated at 2022-06-20 15:51:41.021896
# Unit test for function recursive_diff
def test_recursive_diff():
    a = dict(a=dict(b=1, c=2, d=3), e=dict(f=4, g=5), h=dict(i=6, j=7), k=8)
    b = dict(a=dict(b=1, c=2, d=3), e=dict(g=5), h=9, k=dict(i=10, j=11, l=12))
    c = dict(a=dict(b=1, c=2, d=4), e=dict(g=5), h=9, k=dict(i=10, j=11, l=12))

# Generated at 2022-06-20 15:51:47.671220
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
      "to_camel": {
        "user_name": "test",
        "groups": [
          "admins",
          "users"
        ],
        "uid": 1
      },
      "skip_this": {
        "Tags": [
          {
            "Key": "environment",
            "Value": "test"
          }
        ],
        "a-b-c": 1
      },
      "override_this": {
        "user_name": "test",
        "groups": [
          "admins",
          "users"
        ],
        "uid": 1
      }
    }

# Generated at 2022-06-20 15:51:56.674085
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test scalar to scalar
    assert snake_dict_to_camel_dict({'camel_case': 'snake_case'})['camelCase'] == 'snake_case'

    # Test dictionary to dictionary
    assert snake_dict_to_camel_dict({'camel_case': {'inner_camel': 'inner_snake'}})['camelCase']['innerCamel'] == 'inner_snake'

    # Test list to list
    assert snake_dict_to_camel_dict({'camel_case': [{'inner_camel': 'inner_snake'}]})['camelCase'][0]['innerCamel'] == 'inner_snake'

    # Test if the root is not converted

# Generated at 2022-06-20 15:52:07.726560
# Unit test for function dict_merge
def test_dict_merge():

    dict1 = dict(a=dict(b=1, c=2), d=3)
    dict2 = dict(a=dict(b=4, d=4), e=5)

    dict3 = dict_merge(dict1, dict2)
    assert dict3 == dict(a=dict(b=4, c=2, d=4), d=3, e=5)

    dict3 = dict_merge(dict1, dict(a=dict(b=4, d=4), e=5))
    assert dict3 == dict(a=dict(b=4, c=2, d=4), d=3, e=5)

    dict3 = dict_merge(dict1, dict2, dict2)

# Generated at 2022-06-20 15:52:19.992991
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({'a': None}, {'a': 1})
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 2}, {'a': 1}) == ({'a': 2}, {'a': 1})
    assert recursive_diff({'a': [1, 2]}, {'a': [1, 2]}) is None
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 2, 'a': 1})

# Generated at 2022-06-20 15:52:30.904287
# Unit test for function recursive_diff
def test_recursive_diff():

    # Generate test lists
    #  - Dict and list in different order
    #  - Different values
    #  - One or both dict's missing key
    #  - Value is a dict/list
    #  - Both values are None
    #  - One value is None
    #  - Nested dicts

    # Test 1
    test_dict_1 = {u'attributes': {u'attr1': u'val1'},
                   u'key': u'value'}
    test_dict_2 = {u'key': u'value',
                   u'attributes': {u'attr1': u'val1'}}

    # Test 2

# Generated at 2022-06-20 15:52:37.788875
# Unit test for function recursive_diff
def test_recursive_diff():
    ret = recursive_diff(dict1={}, dict2={})
    assert not ret

    ret = recursive_diff(dict1={'a':1}, dict2={'a':2})
    assert ret == ({'a':1}, {'a':2})

    ret = recursive_diff(dict1={'a':1}, dict2={'b':1})
    assert ret == ({'a':1}, {'b':1})

    ret = recursive_diff(dict1={'a':1, 'b':2}, dict2={'a':1, 'b':3})
    assert ret == ({'b':2}, {'b':3})

    ret = recursive_diff(dict1={'a':{'b':1}}, dict2={'a':{'b':1}})
    assert not ret

    ret = recursive_diff

# Generated at 2022-06-20 15:52:49.613348
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(
        dict_with_dicts=dict(
            dict_dict1_1=dict(
                key1='value1',
                key2='value2',
                key3='value3'
            ),
            dict_dict1_2=dict(
                key1='value1',
                key2='value2',
                key3='value3'
            )
        ),
        dict1_key1='value1',
        dict1_key2=dict(
            dict1_key3='value3',
            dict1_key4='value4'
        )
    )

# Generated at 2022-06-20 15:52:56.524844
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a':1, 'b':2, 'c':{'a':3, 'b':4}}
    b = {'a':5, 'b':6, 'c':{'a':7, 'b':8}}
    result = {'a':5, 'b':6, 'c':{'a':7, 'b':8}}
    if dict_merge(a, b) != result:
        raise AssertionError("dict_merge() failed to merge dicts correctly")


# Generated at 2022-06-20 15:53:06.456622
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 1: {1: 1, 2: 2}}
    b = {'b': {2: 7, 3: 3}, 'c': 3, 1: {2: 7, 3: 3}}
    expected = {'a': 1, 'b': {1: 1, 2: 7, 3: 3}, 'c': 3, 1: {1: 1, 2: 7, 3: 3}}
    assert None is not recursive_diff(dict_merge(a, b), expected)

# Unit tests for function recursive_diff

# Generated at 2022-06-20 15:53:17.782473
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.common.dict_transformations import recursive_diff
    import unittest

    class TestRecursiveDiff(unittest.TestCase):

        def test_recursive_diff_dict(self):
            a = {
                'anemptydict': {},
                'asimpledict': {'k1': 'one', 'k2': 'two'},
                'nested': {
                    'k3': 'three',
                    'k4': {'k5': 'five', 'k6': 'six'}
                }
            }

# Generated at 2022-06-20 15:53:28.350158
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:53:37.523090
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit tests for function recursive_diff"""

    # base case - no differences
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None

    # simple differences
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})

    # nested dictionaries

# Generated at 2022-06-20 15:53:46.772314
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(dict(a=1), dict(b=2)) == dict(a=1, b=2)
    assert dict_merge(dict(a=1, b=1), dict(a=2, b=2)) == dict(a=2, b=2)
    assert dict_merge(dict(a=1, b=1), dict(a=2, c=3)) == dict(a=2, b=1, c=3)
    assert dict_merge(dict(a=1, b=1), dict(a=dict(b=2), c=3)) == dict(a=dict(b=2), b=1, c=3)

# Generated at 2022-06-20 15:53:55.811596
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test single strings and capitalization
    assert snake_dict_to_camel_dict({'a': 'b'}) == {'a': 'b'}
    assert snake_dict_to_camel_dict({'a': 'b'}, capitalize_first=True) == {'A': 'b'}

    # Test top-level lists
    assert snake_dict_to_camel_dict({'a': ['b', 'c']}) == {'a': ['b', 'c']}
    assert snake_dict_to_camel_dict({'a': ['b', 'c']}, capitalize_first=True) == {'A': ['b', 'c']}

    # Test top-level lists of dictionaries