

# Generated at 2022-06-20 15:44:25.030746
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    original_dict = {
        'foo_bar': {
            'baz_bam': [
                {'key_1': 'value_1'},
                {'key_2': 'value_2'}
            ],
            'baz_bom': 'bom_value'
        },
        'bar_baz': {
            'bam_baz': 'bam_baz_value'
        },
        'list': [
            {'key_1': 'value_1'},
            {'key_2': 'value_2'}
        ]
    }


# Generated at 2022-06-20 15:44:32.384664
# Unit test for function recursive_diff
def test_recursive_diff():
    import json


# Generated at 2022-06-20 15:44:43.378810
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_simple = {'VpcId': 'vpc-12345678', 'SubnetId': 'subnet-12345678', 'Tags': {'Name': 'test-vpc'}}
    test_dict_advanced = {
        'VpcConfig': {
            'VpcId': 'vpc-12345678',
            'SubnetIds': ['subnet-12345678', 'subnet-87654321'],
            'SecurityGroupIds': ['sg-12345678']
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict_ref_simple = {'vpc_id': 'vpc-12345678', 'subnet_id': 'subnet-12345678', 'tags': {'Name': 'test-vpc'}}



# Generated at 2022-06-20 15:44:54.362863
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    some_snake_dict = {'this_that': {'sneky': 1, 'snake_eyes': 2},
                       'here_there': {'abe': {'lincoln': 1, 'kennedy': 2}},
                       'now_then': [{'moses': 1, 'jesus': 2}, {'elvis': 3, 'kurt': 4}]
                       }

    some_camel_dict = {'ThisThat': {'sneky': 1, 'snakeEyes': 2},
                       'HereThere': {'abe': {'lincoln': 1, 'kennedy': 2}},
                       'NowThen': [{'moses': 1, 'jesus': 2}, {'elvis': 3, 'kurt': 4}]
                       }

    assert snake_dict_to_camel

# Generated at 2022-06-20 15:45:04.153431
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff
    """

    from ansible.module_utils.common._collections_compat import Mapping

    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 2, 'a': 1}) is None
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 1, 'a': 2})

# Generated at 2022-06-20 15:45:13.560861
# Unit test for function recursive_diff
def test_recursive_diff(): # pylint: disable=unused-variable
    """Test ``recursive_diff`` method."""

    def test_assert_equal(): # pylint: disable=unused-variable
        """Helper function to assert equality."""

        dict1 = dict(hello=[1, 2, dict(w=[True, False])], world=dict(a=None, b=1))
        dict2 = dict(hello=[1, 2, dict(w=[True, False])], world=dict(a=None, b=1))
        assert recursive_diff(dict1, dict2) is None

        dict1 = dict(hello=[1, 2, dict(w=[True, False])], world=dict(a=None, b=1))

# Generated at 2022-06-20 15:45:25.326245
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    case1 = {'HTTPEndpoint': 'https://localhost'}
    expected1 = {'h_t_t_p_endpoint': 'https://localhost'}
    case2 = {'HTTPEndpoint': 'https://localhost', 'DescribeEndpoints': {'HTTPEndpoint': 'https://localhost'}}
    expected2 = {'h_t_t_p_endpoint': 'https://localhost', 'describe_endpoints': {'h_t_t_p_endpoint': 'https://localhost'}}
    case3 = {'HTTPEndpoint': 'https://localhost', 'DescribeEndpoints': {'HTTPEndpoint': 'https://localhost'},
             'Tags': {'KEY': 'VALUE'}}

# Generated at 2022-06-20 15:45:33.427952
# Unit test for function dict_merge
def test_dict_merge():
    # Basic merging of scalars
    a = {'one': 2, 'two': {'a': 1, 'b': 2}}
    b = {'three': 3, 'two': {'c': 3, 'd': 4}}
    c = {'one': 2, 'three': 3, 'two': {'a': 1, 'b': 2, 'c': 3, 'd': 4}}
    assert(dict_merge(a, b) == c)

    # Test that if a key exists in both a and b, but the values are different
    # the value from b is returned
    a = {'one': 1}
    b = {'one': 2}
    c = {'one': 2}
    assert(dict_merge(a, b) == c)

    # Test for edge case when b is empty
    a

# Generated at 2022-06-20 15:45:45.225287
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=dict(b=1, c=2, d=3), e=dict(f=4, g=5, h=dict(i=6, j=7)), k=8)
    dict2 = dict(a=dict(b=1, c=3, e=4), e=dict(f=5, g=5, h=dict(i=7, m=8)), n=0)
    left, right = recursive_diff(dict1, dict2)
    assert left == dict(a=dict(c=2, d=3), e=dict(f=4, h=dict(j=7)), k=8)
    assert right == dict(a=dict(c=3, e=4), e=dict(f=5, h=dict(i=7, m=8)), n=0)

# Generated at 2022-06-20 15:45:53.559475
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:46:08.645600
# Unit test for function dict_merge
def test_dict_merge():

    class MockArgs(object):
        pass

    args = MockArgs()
    args.a = dict(one=1, two=dict(three=3, four=4), five=5)
    args.b = dict(six=6, two=dict(four=44444444, seven=7))

    result = dict_merge(args.a, args.b)

    assert result['one'] == 1
    assert result['five'] == 5
    assert result['two']['three'] == 3
    assert result['two']['four'] == 4444
    assert result['two']['seven'] == 7


# Generated at 2022-06-20 15:46:17.509323
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"Enabled": True}, "Tags": {"k": "v"}}, reversible=True) == \
        {"h_t_t_p_endpoint": {"enabled": True}, "tags": {"k": "v"}}

    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"Enabled": True}, "Tags": {"k": "v"}}, reversible=False) == \
        {"http_endpoint": {"enabled": True}, "tags": {"k": "v"}}

    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"Enabled": True}}, reversible=True) == \
        {"h_t_t_p_endpoint": {"enabled": True}}


# Generated at 2022-06-20 15:46:27.010247
# Unit test for function dict_merge
def test_dict_merge():

    # Simple merge test
    a = {'foo': 'bar', 'bing': 'baz'}
    b = {'foo': 'baz'}

    res = dict_merge(a, b)
    assert(res['foo'] == 'baz')
    assert(res['bing'] == 'baz')

    # Recursive merge test
    a = {'foo': 'bar', 'bing': {'baz': 'baz1'}}
    b = {'foo': 'bar', 'bing': {'baz': 'baz2'}}
    res = dict_merge(a, b)

    assert(res['foo'] == 'bar')
    assert('bing' in res)
    bing = res['bing']
    assert(bing['baz'] == 'baz2')

    # Ensure types are preserved


# Generated at 2022-06-20 15:46:35.878650
# Unit test for function dict_merge
def test_dict_merge():
    # Example 1
    a = {'d': 0, 'b': 1, 'c': 2, 'e': {'e1': 123, 'e2': 345, 'e3': 567}}
    b = {'a': 0, 'b': 456, 'c': 3, 'e': {'e1': 777, 'e3': 999}}
    expected = {'a': 0, 'b': 456, 'c': 3, 'd': 0, 'e': {'e1': 777, 'e2': 345, 'e3': 999}}
    result = dict_merge(a, b)

    assert result == expected

    # Example 2
    a = {'d': 0, 'b': 1, 'c': 2, 'e': {'e1': 123, 'e2': 345, 'e3': 567}}

# Generated at 2022-06-20 15:46:47.040773
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:46:56.417736
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: 1}, {1: 1}) is None
    assert recursive_diff({1: 1}, {1: 2}) == ({1: 1}, {1: 2})
    assert recursive_diff({1: 1}, {2: 1}) == ({1: 1}, {2: 1})
    assert recursive_diff({1: 1}, {1: 1, 2: 3}) == ({}, {2: 3})
    assert recursive_diff({1: 1, 2: 3}, {1: 1}) == ({2: 3}, {})
    assert recursive_diff({1: {2: 3}}, {1: {2: 4}}) == ({1: {2: 3}}, {1: {2: 4}})

# Generated at 2022-06-20 15:47:04.644012
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        'a': '1',
        'b': {
            'c': '2',
            'd': '3'
        }
    }
    d2 = {
        'a': '1',
        'b': {
            'c': '3',
            'e': '3'
        }
    }
    assert recursive_diff(d1, d2) == ({'a': '1', 'b': {'c': '2'}}, {'a': '1', 'b': {'c': '3', 'e': '3'}})

    d1 = {'a': '1', 'b': None}
    d2 = {'a': '2', 'b': {'c': '2'}}

# Generated at 2022-06-20 15:47:16.108870
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Unit test for function snake_dict_to_camel_dict"""
    assert snake_dict_to_camel_dict({
        "a_b_c_d_e_f": None,
        "g_h_i": {
            "j_k_l": None,
            "m_n_o": [
                {"p_q_r_s": None},
                {"t_u_v_w_x_y_z": None}
            ]
        }
    }) == {
        "aBcDeF": None,
        "gHi": {
            "jKl": None,
            "mNo": [
                {"pQrS": None},
                {"tUvWxYz": None}
            ]
        }
    }

# Generated at 2022-06-20 15:47:25.038261
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'name': 'myValue'}, False) == {'name': 'myValue'}
    assert camel_dict_to_snake_dict({'name': 'myValue'}, True) == {'name': 'myValue'}
    assert camel_dict_to_snake_dict({'SomeCamelCase': 'myValue'}, False) == {'some_camel_case': 'myValue'}
    assert camel_dict_to_snake_dict({'SomeCamelCase': 'myValue'}, True) == {'some_c_a_m_e_l_case': 'myValue'}

# Generated at 2022-06-20 15:47:37.176419
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test/example of how to use recursive_diff."""
    import pytest

    with pytest.raises(TypeError):
        recursive_dict_diff(None, {})

    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': {}}, {'a': {'b': 1}}) == ({'a': {}}, {'a': {'b': 1}})
    assert recursive_diff({'a': {'b': 1}}, {}) == ({'a': {'b': 1}}, {})
    assert recursive

# Generated at 2022-06-20 15:47:48.555047
# Unit test for function recursive_diff
def test_recursive_diff():
    import json
    import os

    def get_data(file):
        path = os.path.join(os.path.dirname(__file__), '..', 'unit', '_data', file)
        with open(path) as f:
            return json.load(f)


# Generated at 2022-06-20 15:47:57.274105
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'has_active_health_check': False,
                  'health_check_interval_seconds': 30,
                  'health_check_path': '/',
                  'health_check_port': 'traffic-port',
                  'health_check_protocol': 'HTTP',
                  'healthy_threshold_count': 5,
                  'matcher': {'http_code': '200'},
                  'unhealthy_threshold_count': 2,
                  'vpc_id': 'vpc-12345678'}

# Generated at 2022-06-20 15:48:04.300727
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    result = {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}
    assert result == dict_merge(a, b)
    assert a == {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}



# Generated at 2022-06-20 15:48:10.661613
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    def check_snake_to_camel(snake_dict):
        camel_dict = snake_dict_to_camel_dict(snake_dict)
        expected_camel_dict = {'checkSnakeToCamel': True}
        assert camel_dict == expected_camel_dict

    def check_snake_to_camel_with_capitalize_first(snake_dict):
        camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=True)
        expected_camel_dict = {'CheckSnakeToCamel': True}
        assert camel_dict == expected_camel_dict


# Generated at 2022-06-20 15:48:20.859811
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:48:29.984780
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': 'http://example.com',
        'HTTPHeaders': {
            'HTTPHeaderName': 'HTTPHeaderValue'
        },
        'Tags': {
            'key': 'value'
        },
        'Show': True,
        'Example_Names': ['Ansible'],
        'Example': {
            'HTTPEndpoint': 'http://example.com',
            'HTTPHeaders': {
                'HTTPHeaderName': 'HTTPHeaderValue'
            },
            'Tags': {
                'key': 'value'
            },
            'Show': True,
            'Example_Names': ['Ansible'],
        }
    }
    result = camel_dict_to_snake_dict(camel_dict)
    # dicts are unordered, so we need to

# Generated at 2022-06-20 15:48:41.513769
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "foo": "bar",
        "baz": {
            "fooBar": "bax",
            "barBaz": {
                "a": "1",
                "b": "2",
                "c": "3"
            },
            "qux": "qux"
        },
        "HTTPEndpoint": "foo",
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"
            ],
        "Tags": {
            "Key" : "Environment",
            "Value" : "Production"
            }
        }

    # Testing CamelCase to snake_case and then back to CamelCase
    result_dict

# Generated at 2022-06-20 15:48:50.162707
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "foo_foo": {
            "bar_bar": "baz",
            "list_list": [
                {
                    "foo_foo": {
                        "bar_bar": "baz"
                    }
                }
            ]
        }
    }
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {
        "fooFoo": {
            "barBar": "baz",
            "listList": [
                {
                    "fooFoo": {
                        "barBar": "baz"
                    }
                }
            ]
        }
    }
    reversed_camel_dict = snake_dict_to_camel_dict(snake_dict_to_camel_dict(snake_dict))


# Generated at 2022-06-20 15:49:01.031908
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test the single word case
    camel_dict = {"SingleWord": "value"}
    snake_dict = {"single_word": "value"}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # Test the single word case (reversible=True)
    camel_dict = {"SingleWord": "value"}
    snake_dict = {"s_i_n_g_l_e_w_o_r_d": "value"}
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == snake_dict

    # Test the single word case with a list value
    camel_dict = {"SingleWord": ["value1", "value2"]}
    snake_dict = {"single_word": ["value1", "value2"]}
    assert camel_dict_

# Generated at 2022-06-20 15:49:09.916173
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': 0, 'foobar': [{'foo_bar': 1}], 'foobar_x': {'foo_bar': 2}}) == {'fooBar': 0, 'foobar': [{'fooBar': 1}], 'foobarX': {'fooBar': 2}}
    assert snake_dict_to_camel_dict({'foo_bar': 0, 'foobar': [{'foo_bar': 1}], 'foobar_x': {'foo_bar': 2}}, capitalize_first=True) == {'FooBar': 0, 'foobar': [{'FooBar': 1}], 'foobarX': {'FooBar': 2}}

# Generated at 2022-06-20 15:49:20.690305
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict1_snake = {
        'string_value': "string",
        'int_value': 1,
        'list_of_strings': [
            'string1',
            'string2'
        ],
        'boolean_value': True,
        'dict_value': {
            'dict_key1': 'value1',
            'dict_key2': 'value2'
        }
    }

    expected_dict1_camel = {
        'stringValue': "string",
        'intValue': 1,
        'listOfStrings': [
            'string1',
            'string2'
        ],
        'booleanValue': True,
        'dictValue': {
            'dictKey1': 'value1',
            'dictKey2': 'value2'
        }
    }

    dict

# Generated at 2022-06-20 15:49:31.318748
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"a_b_c":{"d_e_f":{"a_b_c":1}}}) == {"aBC":{"dEF":{"aBC":1}}}
    assert snake_dict_to_camel_dict({"a_b_c":{"d_e_f":{"a_b_c":1}, "g_h_i":"s_s"}}) == {"aBC":{"dEF":{"aBC":1}, "gHI":"sS"}}
    assert snake_dict_to_camel_dict({"a_b_c":1}) == {"aBC":1}
    assert snake_dict_to_camel_dict([{"a_b_c":1}], True) == [{"ABC":1}]


# Generated at 2022-06-20 15:49:42.134916
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        "aws": {
            "region": "us-east-1",
            "ami": "ami-0123abcd",
            "security_groups": ["default", "test"],
            "vpc": {
                "id": "vpc-12345678",
                "subnet": {"public": ["subnet-1a2b3c4d", "subnet-1a2b3c4e"],
                           "private": ["subnet-2a2b3c4d", "subnet-2a2b3c4e"]}
            }
        },
        "environment": "test",
        "count": 2
    }


# Generated at 2022-06-20 15:49:49.622749
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'snake_dict': {'snake_list': [1, 2, 3], 'snake_key': 'snake_value'}}
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict['snakeDict']['snakeList'] == [1, 2, 3]
    assert camel_dict['snakeDict']['snakeKey'] == 'snake_value'

# Generated at 2022-06-20 15:49:58.692148
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Tests the snake_dict_to_camel_dict() function
    """
    snake_case_dict = {
        'key_one': 1,
        'key_two': 2,
        'nested_dict': {
            'inner_one': True
        },
        'tag_list': [
            {
                'key': 'foo',
                'value': 'bar'
            },
            {
                'key': 'baz',
                'value': 'qux'
            }
        ]
    }

    camel_case_dict = snake_dict_to_camel_dict(snake_case_dict)


# Generated at 2022-06-20 15:50:03.712789
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:50:13.344247
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'z': {'x': 1, 'y': 2, 'a': {'l1': 'v1', 'l2': 'v2'}}}
    b = {'w': 3, 'x': 4, 'y': 5, 'z': {'a': {'l1': 'v1', 'l2': 'v2', 'l3': 'v3'},
                                       'e': {'l1': 'v1', 'l2': 'v2'}}}

    c = dict_merge(a, b)


# Generated at 2022-06-20 15:50:20.794468
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'Users': ['user1', 'user2'],
                  'Tags': [{'Key': 'test', 'Value': 'test1'}],
                  'Name': 'test',
                  'HTTPEndpoint': {}}

    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == \
        {'users': ['user1', 'user2'],
         'tags': [{'key': 'test', 'value': 'test1'}],
         'name': 'test',
         'h_t_t_p_endpoint': {}}


# Generated at 2022-06-20 15:50:30.711393
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    A dictionary of test cases. Each test case is represented by a tuple.
    The first element of each tuple is the input value, the second is the expected output.
    """

# Generated at 2022-06-20 15:50:42.663737
# Unit test for function recursive_diff
def test_recursive_diff():
    # Method to compare the diffs
    def compare(expected_left, expected_right, left, right):
        assert left == expected_left, "The left diff is not expected but is {}".format(left)
        assert right == expected_right, "The right diff is not expected but is {}".format(right)

    # Dictionaries for test case
    dict1 = dict(a=dict(b=1, c=2), d=3, e=4)
    dict2 = dict(a=dict(b=1, c=3), d=3, f=5)

    diffs = recursive_diff(dict1, dict2)

    expected_left = dict(a=dict(c=2), e=4)
    expected_right = dict(a=dict(c=3), f=5)

# Generated at 2022-06-20 15:50:56.325353
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict.
    """


# Generated at 2022-06-20 15:51:07.167913
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'attribute_values': [
            'string',
        ],
        'attribute_name': 'string',
        'key': {
            'id': 'string',
            'type': 'string'
        },
        'target_arn': 'string',
    }

    camel_dict = {
        'attributeValues': [
            'string',
        ],
        'attributeName': 'string',
        'key': {
            'id': 'string',
            'type': 'string'
        },
        'targetArn': 'string',
    }

    assert(snake_dict_to_camel_dict(snake_dict) == camel_dict)



# Generated at 2022-06-20 15:51:20.066900
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        dromedaryCase="dromedary",
        HTTPEndpoint="http",
        Tags=["one", "two"],
        VPCName="vpc",
        TargetGroupARNs=["arn"],
        SomeList=[
            dict(
                Field1="one",
                Field2="two"
            )
        ]
    )
    expected = dict(
        dromedary_case="dromedary",
        h_t_t_p_endpoint="http",
        tags=["one", "two"],
        vpc_name="vpc",
        target_group_a_r_ns=["arn"],
        some_list=[
            dict(
                field1="one",
                field2="two"
            )
        ]
    )

    result = camel_dict

# Generated at 2022-06-20 15:51:29.031013
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = {'Tags': [{'Key': 'Project', 'Value': 'ALB'}], 'LoadBalancerArn': 'arn:aws:elasticloadbalancing:us-east-2:666938292606:loadbalancer/app/ana-lb/0f62c546f0debb2a', 'LoadBalancerName': 'ana-lb', 'DNSName': 'ana-lb-1102817103.us-east-2.elb.amazonaws.com'}

# Generated at 2022-06-20 15:51:40.982402
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    test_dict = {
        'hello': {
            'world': 'test_dict'
        },
        'random_list': [
            {
                'dict_in_list': {
                    'is_nested': True
                }
            },
            'foo',
            'bar'
        ],
        'list_with_ints': [
            1, 2, 3, 4
        ],
        'list_with_dicts': [
            {
                'hello': 'world'
            }
        ]
    }


# Generated at 2022-06-20 15:51:47.645272
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'vpc_id': 'vpc-abc1234'}) == {'vpcId': 'vpc-abc1234'}
    assert snake_dict_to_camel_dict({'vpc_id': 'vpc-abc1234'}, capitalize_first=True) == {'VpcId': 'vpc-abc1234'}
    assert snake_dict_to_camel_dict({'vpc_id': 'vpc-abc1234', 'tags': {'Name': 'my_name'}}) == {'vpcId': 'vpc-abc1234', 'tags': {'Name': 'my_name'}}

# Generated at 2022-06-20 15:51:56.649840
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:52:07.727206
# Unit test for function dict_merge
def test_dict_merge():

    a = {'a': 'a',
         'b': {'b': 'b',
               'c': {'c': 'c',
                     'd': 'd'},
               'e': {'e': 'e'}},
         'f': 'f'}
    b = {'x': 'x',
         'b': {'c': {'g': 'g'},
               'h': 'h'},
         'f': {'i': 'i'}}

    assert a == {'a': 'a',
                 'b': {'b': 'b',
                       'c': {'c': 'c',
                             'd': 'd'},
                       'e': {'e': 'e'}},
                 'f': 'f'}


# Generated at 2022-06-20 15:52:19.946345
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(dict1a="foo", dict2=dict(dict2a="bar", dict2b="baz"))
    dict2 = dict(dict1a="foo", dict2=dict(dict2b="baz"))
    assert recursive_diff(dict1, dict2) == ({'dict2': {'dict2a': 'bar'}}, {})
    dict1 = dict(dict1a="foo", dict2a="bar", dict2b="baz")
    dict2 = dict(dict1a="foo", dict2a="bar", dict2b="buzz")
    assert recursive_diff(dict1, dict2) == ({}, {'dict2b': 'buzz'})
    dict1 = dict(dict1a="foo", dict2=dict(dict2a="bar", dict2b="baz"))
   

# Generated at 2022-06-20 15:52:26.044336
# Unit test for function dict_merge
def test_dict_merge():
    ansible_dict = {"A": {"B": 1}, "C": 2}
    param_dict = {"A": {"B": {"C": 3}}, "D": 4}
    result_dict = {"A": {"B": {"C": 3}}, "C": 2, "D": 4}

    assert(dict_merge(ansible_dict, param_dict)==result_dict)


# Generated at 2022-06-20 15:52:36.148679
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'a': 1,
        'b': {
            'c': 1,
            'd': 2
        }
    }
    b = {
        'b': {
            'e': 3
        },
        'f': 4
    }

    expected_result = {
        'a': 1,
        'b': {
            'c': 1,
            'd': 2,
            'e': 3
        },
        'f': 4
    }
    assert dict_merge(a, b) == expected_result



# Generated at 2022-06-20 15:52:47.656764
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'b': 2}) == ({}, {'b': 2})
    assert recursive_diff({'a': 1}, {'b': 2}) == ({'a': 1}, {'b': 2})
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    assert recursive_diff({'a': {'b': 1}}, {}) == \
           ({'a': {'b': 1}}, {})
    assert recursive_diff({}, {'a': {'b': 1}}) == \
           ({}, {'a': {'b': 1}})

# Generated at 2022-06-20 15:52:57.735908
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    my_dict = {
        "HTTPEndpoint": {
            "EndpointStatus": "CREATING",
            "HTTPAuthCredential": {
                "SecretKey": "SECRET_KEY",
                "AccessKey": "ACCESS_KEY"
            },
            "ServiceId": "SERVICE_ID",
            "URL": "URL",
            "Id": "ENDPOINT_ID"
        },
        "Id": "IMAGE_ID",
        "Auth": {
            "Username": "USERNAME",
            "Password": "PASSWORD"
        }
    }

    # regular case
    snake_dict = camel_dict_to_snake_dict(my_dict)

    assert snake_dict.get("http_endpoint")

# Generated at 2022-06-20 15:53:09.466490
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = dict(A=1, B='A')
    dict_b = dict(A=2, B='B')
    dict_c = dict(A=1, B=dict(C=2, D=3))
    dict_d = dict(A=1, B=dict(C=2, D=2))
    dict_e = dict(A=1, B=list(range(3)))
    dict_f = dict(A=1, B=list(range(4)))

    assert recursive_diff(dict_a, dict_a) is None
    assert recursive_diff(dict_b, dict_a) == ({'B': 'A'}, {'B': 'B'})

# Generated at 2022-06-20 15:53:21.152862
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:53:32.417783
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:53:39.236351
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.common.dict_transformations import recursive_diff

    dict1 = {
        "a": "b",
        "c": {
            "d": "e",
            "f": "g",
            "h": {
                "i": "j",
                "k": {
                    "l": "m",
                    "n": "o"
                }
            }
        },
        "p": {
            "q": "r"
        }
    }


# Generated at 2022-06-20 15:53:45.359043
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = {'first': {'all_rows': {'pass': 'dog', 'fail': 'cat', 'number': '5'}}}
    assert(expected == dict_merge(a, b))



# Generated at 2022-06-20 15:53:54.923874
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Tests recursive_diff function with various mixed types """
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 1, 'c': 2}) == ({'a': 1, 'b': 2}, {'b': 1, 'c': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 1}) == ({'b': 2}, {'b': 1})

# Generated at 2022-06-20 15:54:00.909964
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'Arn': 'arn:aws:example',
                  'Tags': [{'Key': 'foo', 'Value': 'bar'}, {'Key': 'koi', 'Value': 'carp'}]}

    snake_dict = {'arn': 'arn:aws:example',
                  'tags': [{'key': 'foo', 'value': 'bar'}, {'key': 'koi', 'value': 'carp'}]}

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

