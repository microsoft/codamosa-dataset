

# Generated at 2022-06-20 15:44:20.703428
# Unit test for function dict_merge
def test_dict_merge():

    dict1 = {
        "foo": {1: 1, 2: 2, 3: 3},
        "bar": 2
    }

    dict2 = {
        "foo": {2: "two", 3: "three", 4: 4},
        "bar": "baz"
    }

    expected_dict = {
        "foo": {1: 1, 2: "two", 3: "three", 4: 4},
        "bar": "baz"
    }

    assert dict_merge(dict1, dict2) == expected_dict

# Unit tests for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:44:29.326208
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = { 'first_key' : { 'second_key' : [ ['list_value_1', 'list_value_2'] , {'nested_dictionary' : { 'deeply_nested_key' : 'deeply_nested_value'} } ]} }
    camel_dict = { 'FirstKey' : { 'SecondKey' : [ ['list_value_1', 'list_value_2'] , {'nested_dictionary' : { 'deeply_nested_key' : 'deeply_nested_value'} } ]} }
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == camel_dict



# Generated at 2022-06-20 15:44:34.025232
# Unit test for function dict_merge
def test_dict_merge():
    '''
    basic test for dict_merge:
    '''
    a = {'a': 1, 'b': {'x': 1, 'y': 2, 'z': 3}}
    b = {'a': 5, 'b': {'x': 4}}

    expected = {'a': 5, 'b': {'x': 4, 'y': 2, 'z': 3}}
    results = dict_merge(a, b)

    assert results == expected

# Generated at 2022-06-20 15:44:44.574844
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(
        var1='var1',
        var2='var2',
        var3=dict(
            var11='var11',
            var22='var22',
            var33='var33',
        )
    )
    dict2 = dict(
        var4='var4',
        var3=dict(
            var11='var11',
            var33='var55',
        )
    )
    dict3 = dict(
        var1='var1',
        var2='var2',
        var3=dict(
            var11='var11',
            var22='var22',
            var33='var55',
        ),
        var4='var4'
    )
    new_dict = dict_merge(dict1, dict2)
    print(new_dict)

# Generated at 2022-06-20 15:44:55.894868
# Unit test for function recursive_diff
def test_recursive_diff():
    from nose.tools import assert_equal

    assert_equal(None, recursive_diff({}, {}))
    assert_equal((None, {'a': 1}), recursive_diff({}, {'a': 1}))
    assert_equal((None, {'a': 1}), recursive_diff({'b': 2}, {'a': 1}))
    assert_equal((None, {'b': 2}), recursive_diff({'a': 1}, {'b': 2}))
    assert_equal((None, {'b': {'a': 1}}), recursive_diff({'b': {}}, {'b': {'a': 1}}))
    assert_equal((None, {'b': {'a': 1}}), recursive_diff({'b': {'c': 2}}, {'b': {'a': 1}}))

# Generated at 2022-06-20 15:45:02.228750
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key4": "value4",
            "key5": "value5"
        }
    }
    b = {
        "key3": {
            "key4": "value4"
        }
    }

    assert dict_merge(a, b) == a



# Generated at 2022-06-20 15:45:12.177409
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=dict(b=1), c=dict(d=2), e=3)
    dict2 = dict(c=dict(d=5), e=6, f=dict(g=7))

    left, right = recursive_diff(dict1, dict2)
    assert left == dict(a=dict(b=1), e=3)
    assert right == dict(e=6, f=dict(g=7))

    left, right = recursive_diff(dict2, dict1)
    assert left == dict(e=6, f=dict(g=7))
    assert right == dict(a=dict(b=1), e=3)

    dict1 = dict(a=dict(b=dict(c=1)))
    dict2 = dict(a=dict(b=dict(c=2)))

# Generated at 2022-06-20 15:45:23.867214
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Test recursive_diff() function.
    """

    # Two empty dictionaries
    dict1 = dict()
    dict2 = dict()
    assert recursive_diff(dict1, dict2) is None

    # Recursive dictionary
    dict1 = {'dict': {'key1': 'value1'}}
    dict2 = {'dict': {'key1': 'value1'}}
    assert recursive_diff(dict1, dict2) is None

    # Recursive dictionary with different values at same key
    dict1 = {'dict': {'key1': 'value1'}}
    dict2 = {'dict': {'key1': 'value2'}}

# Generated at 2022-06-20 15:45:33.104834
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:45:44.777865
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(
        dict1=dict(
            dict1='value1',
            dict2=dict(
                dict3='value3',
                dict4='value4',
            ),
        ),
        dict2=dict(
            dict1='value1',
            dict2=dict(
                dict3='value3',
                dict4='value4',
                dict5='value5',
            ),
        ),
    ) == (
        dict(),
        dict(
            dict2=dict(
                dict5='value5',
            ),
        ),
    )

# Generated at 2022-06-20 15:46:01.697375
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Key1': 'Value1',
        'Key2': {
            'SubKey1': 'SubValue1'
        },
        'Key3': {
            'SubKey1': {
                'SubSubKey1': 'SubSubValue1'
            }
        }
    }
    snake_dict = {
        'key1': 'Value1',
        'key2': {
            'sub_key1': 'SubValue1'
        },
        'key3': {
            'sub_key1': {
                'sub_sub_key1': 'SubSubValue1'
            }
        }
    }

    assert(camel_dict_to_snake_dict(camel_dict) == snake_dict)



# Generated at 2022-06-20 15:46:12.957792
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    reversable_camel_case = {
        "TestDictionary": {
            "TestList": [],
            "TestString": "This is a string",
            "TestInteger": 5
        }
    }

    expected_reversable_snake_case = {
        "test_dictionary": {
            "test_list": [],
            "test_string": "This is a string",
            "test_integer": 5
        }
    }

    reversable_snake_case = {
        "test_dictionary": {
            "test_list": [],
            "test_string": "This is a string",
            "test_integer": 5
        }
    }


# Generated at 2022-06-20 15:46:19.862024
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict1 = {
        "source_security_group_id": "g-1234",
        "source_security_group_name": "security_group_name",
        "source_security_group_owner_id": "12345",
        "destination_security_group_id": "g-5678",
        "destination_security_group_name": "security_group_name",
        "destination_security_group_owner_id": "67890",
        "ip_protocol": "tcp",
        "from_port": "80",
        "to_port": "80",
        "cidr_ip": "0.0.0.0/0"
    }

# Generated at 2022-06-20 15:46:23.622690
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = dict_merge(a,b)
    assert c == { 'first' : { 'all_rows' : {
                                              'pass' : 'dog',
                                              'fail' : 'cat',
                                              'number' : '5'
                                            }
                            }
                }

# Generated at 2022-06-20 15:46:27.878478
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'foo_bar': 'baz',
        'foo_baz': [
            {
                'foo_bar': 'baz',
                'foo_baz': 'bar',
                'foo': [
                    {
                        'bar_baz': 'foo_bar'
                    }
                ]
            }
        ],
        'foo_bar_baz': {
            'foo_bar_baz': 'foo_bar_baz'
        }
    }


# Generated at 2022-06-20 15:46:36.532053
# Unit test for function dict_merge
def test_dict_merge():

    class AWSObject(object):
        def __init__(self, module, results):
            self.module = module
            self.results = results
            self.changed = False

    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.exit_json = self._exit_json
            self.fail_json = self._fail_json
            self.user_agent_addon = None

        def _exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['changed'] = False

        def _fail_json(self, **kwargs):
            self.fail_args = kwargs
            self.exit_args = kwargs
            self.exit_args['failed'] = True



# Generated at 2022-06-20 15:46:47.464945
# Unit test for function recursive_diff
def test_recursive_diff():
    # pylint: disable=C0103
    # Test recursive_diff result
    '''
    test_the_function_recursive_diff is defined in many places in the AWS modules
    it was originally defined in ec2_asg_test_utils because ec2_asg is the most complex
    module in the AWS collection. It has since been copied to all of our integration
    tests.
    '''

    def test_the_function_recursive_diff(dict1, dict2, expected, message=None):
        result = recursive_diff(dict1, dict2)
        if result:
            assert result == expected, message
        else:
            assert not expected, "Expected result is None."
        return result

    # Test cases

# Generated at 2022-06-20 15:46:49.884399
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': {'bax_baz': 'foobar'}}) == {'fooBar': {'baxBaz': 'foobar'}}

# Generated at 2022-06-20 15:47:00.005373
# Unit test for function dict_merge
def test_dict_merge():
    test_dict = {
        'a': {
            'a1': 1,
            'a2': {
                'a2_1': 2,
                'a2_2': 3
            }
        },
        'b': 'b',
        'c': 'c'
    }

    test_dict_2 = {
        'a': {
            'a1': 2,
            'a2': 2
        },
        'd': 'd'
    }

    expected_result = {
        'a': {
            'a1': 2,
            'a2': 2
        },
        'b': 'b',
        'c': 'c',
        'd': 'd'
    }

    result = dict_merge(test_dict, test_dict_2)
    assert result == expected_

# Generated at 2022-06-20 15:47:10.574992
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:47:25.093610
# Unit test for function recursive_diff
def test_recursive_diff():
    from __main__ import recursive_diff

    # Test: empty dictionary
    result = recursive_diff({}, {})
    assert result == None, str(result)

    # Test: dictionary1 empty dictionary2 non-empty
    result = recursive_diff({}, {'a': 'b'})
    assert result == ({}, {'a': 'b'}), str(result)

    # Test: dictionary2 empty dictionary1 non-empty
    result = recursive_diff({'a': 'b'}, {})
    assert result == ({'a': 'b'}, {}), str(result)

    # Test: both dictionaries with keys not matching
    result = recursive_diff({'a': 'a'}, {'b': 'b'})
    assert result == ({'a': 'a'}, {'b': 'b'}), str(result)



# Generated at 2022-06-20 15:47:37.225783
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(helloWorld='test')
    assert camel_dict_to_snake_dict(camel_dict) == dict(hello_world='test')

    camel_dict = dict(HelloWorld='test')
    assert camel_dict_to_snake_dict(camel_dict) == dict(hello_world='test')

    camel_dict = dict(HelloWorlds='test')
    assert camel_dict_to_snake_dict(camel_dict) == dict(hello_worlds='test')

    camel_dict = dict(helloWorld='test', helloWorlds='test')
    assert camel_dict_to_snake_dict(camel_dict) == dict(hello_world='test', hello_worlds='test')

    camel_dict = dict(helloWorlds='test', helloWorld='test')
   

# Generated at 2022-06-20 15:47:47.127201
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'level1': {'level2': 'value1',
                        'level3': 'value2',
                        'level4': {'level5': 'value5'},
                        'level6': ['value6'],
                        'level7': True,
                        'level8': None}}
    dict2 = {'level1': {'level2': 'value1',
                        'level4': {'level5': 'value5'},
                        'level6': ['value6'],
                        'level7': False,
                        'level9': ['value9'],
                        'level8': None}}

# Generated at 2022-06-20 15:47:56.184582
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    dict2 = {'key2': 'value2'}
    # Validate function returns expected value
    assert recursive_diff(dict1, dict2) == ({'key1': 'value1', 'key3': 'value3'}, None)

    dict1 = {'key2': 'value2', 'key3': 'valueX'}
    dict2 = {'key2': 'value2', 'key3': 'value3'}
    # Validate function returns expected value
    assert recursive_diff(dict1, dict2) == ({'key3': 'valueX'}, {'key3': 'value3'})


# Generated at 2022-06-20 15:48:01.294308
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "not": "interesting",
        "changed": "value",
        "same": "value",
        "common": "key",
        "a": {
            "b": 1,
            "c": 2,
            "d": 3,
            "e": {
                "f": 4
            }
        }
    }
    dict2 = {
        "changed": "different_value",
        "same": "value",
        "common": "key",
        "a": {
            "b": 10,
            "c": 2,
            "d": 4,
            "e": {
                "f": 4
            }
        }
    }

    # Test positive, this should be the results of the diff:

# Generated at 2022-06-20 15:48:09.015118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(MyKey='foo', MyCamelizedKey='bar',
                      MyHttpEndpoint='baz', HTTPEndPoint='qux',
                      my_key='foo', My_http_Endpoint='baz')
    expected = dict(my_key='foo', my_camelized_key='bar',
                    my_h_t_t_p_endpoint='baz', h_t_t_p_end_point='qux',
                    my_key='foo', my_http_endpoint='baz')

    actual = camel_dict_to_snake_dict(camel_dict)
    assert actual == expected

    actual = camel_dict_to_snake_dict(camel_dict, reversible=True)
    assert actual == expected



# Generated at 2022-06-20 15:48:19.656595
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'snake_case': {
            'child_key': 'value',
            'ignored_plural': {
                'tags': [
                    'a',
                    'b',
                    'c'
                ]
            }
        },
        'CamelCase': 'camel',
        'CamelCase2': 'camel2',
        'CamelCaseAnd_snake': 'camel'
    }

    camel_dict = snake_dict_to_camel_dict(test_dict)

    assert camel_dict['snakeCase']['childKey'] == 'value'
    assert camel_dict['snakeCase']['ignoredPlural']['Tags'] == ['a', 'b', 'c']
    assert camel_dict['CamelCase'] == 'camel'

# Generated at 2022-06-20 15:48:28.982020
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test if method works
    assert recursive_diff(
        {
            'foo': 'bar',
            'nested': {
                'bar': 'foo',
                'moar': {
                    'nested': 'a'
                }
            },
            'same': 'yes'
        },
        {
            'foo': 'bar',
            'nested': {
                'bar': 'baz',
                'moar': {
                    'nested': 'a'
                }
            },
            'same': 'yes'
        }
    ) == ({}, {'nested': {'bar': 'baz'}})

    # Test if method works on empty dict
    assert recursive_diff({}, {}) is None

    # Test if method works with one empty dict

# Generated at 2022-06-20 15:48:40.563354
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test basic diff
    dict1 = {'a': 1, 'b': 2}
    dict2 = {'a': 2}
    assert recursive_diff(dict1, dict2) == ({'a': 1, 'b': 2}, {'a': 2})

    # Test recursive diff
    dict1 = {'a': 1, 'b': {'c': 3}}
    dict2 = {'a': 2, 'b': {'c': 3, 'd': 4}}
    assert recursive_diff(dict1, dict2) == ({'a': 1, 'b': {'d': 4}}, {'a': 2, 'b': {'d': 4}})

    # Test no diff
    dict1 = {'a': 1}
    dict2 = {'a': 1}

# Generated at 2022-06-20 15:48:47.963315
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_unreversible = {
        'HTTPEndpoint': {
            'Attributes': {
                'AuthenticationType': 'BasicAuth'
            },
            'EndpointUri': 'http://localhost/foo'
        }
    }
    test_reversible = {
        'HTTPEndpoint': {
            'Attributes': {
                'AuthenticationType': 'BasicAuth'
            },
            'EndpointUri': 'http://localhost/foo'
        }
    }

# Generated at 2022-06-20 15:49:00.450104
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected_result = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    result = dict_merge(a, b)
    assert result == expected_result

# Generated at 2022-06-20 15:49:09.651805
# Unit test for function recursive_diff
def test_recursive_diff():
    a = dict(a1="a1", a2="a2", a3="a3")
    b = dict(a1="a1", a2="a2", b3="b3")
    assert recursive_diff(a, b) == (dict(a3="a3"), dict(b3="b3"))
    a = dict(a1="a1", a2="a2", a3=dict(a4="a4", a5="a5", a6="a6"))
    b = dict(a1="a1", a2="a2", a3=dict(a4="a4", a5="a5", b6="b6"))
    assert recursive_diff(a, b) == (dict(a3=dict(a6="a6")), dict(a3=dict(b6="b6")))

# Generated at 2022-06-20 15:49:18.433038
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # test a simple camelCase
    assert camel_dict_to_snake_dict({'instanceId': 'i-0123456789abcdef0'}) == {'instance_id': 'i-0123456789abcdef0'}

    # test a simple PascalCase
    assert camel_dict_to_snake_dict({'InstanceId': 'i-0123456789abcdef0'}) == {'instance_id': 'i-0123456789abcdef0'}

    # test a multi-character camelCase
    assert camel_dict_to_snake_dict({'ipAddress': '192.168.0.1'}) == {'ip_address': '192.168.0.1'}

    # test a multi-word PascalCase

# Generated at 2022-06-20 15:49:29.684514
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {1: 1, 2: {1: 1, 2: 2}}
    d2 = {2: {2: 3}}
    assert dict_merge(d1, d2) == {1: 1, 2: {1: 1, 2: 3}}
    assert d1 == {1: 1, 2: {1: 1, 2: 2}}
    d1 = {1: 1, 2: 2}
    d2 = {2: 3}
    assert dict_merge(d1, d2) == {1: 1, 2: 3}
    d1 = {1: 1, 2: '2'}
    d2 = {2: 3}
    assert dict_merge(d1, d2) == {1: 1, 2: 3}

# Generated at 2022-06-20 15:49:40.492772
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'CreationDate': '2013-12-26T21:06:11.000Z',
        'TrafficPolicyVersion': 1,
        'TrafficPolicyId': 'TPM123EXAMPLE',
        'TTL': 0,
        'Document': '{"Comment": "This is an example traffic policy.","Version": "2008-04-17","Statement":[{"Effect": "Allow","Action": ["route53:ChangeResourceRecordSets"],"Resource": "arn:aws:route53:::hostedzone/Z1M58G0W56LTQA","Condition": {"IpAddress": {"aws:SourceIp": "54.240.143.0/24"}}}]}',
    }


# Generated at 2022-06-20 15:49:52.919785
# Unit test for function recursive_diff
def test_recursive_diff():
    #Let's create some dictionaries
    a = {"foo":"bar", "fubar":["bar1","bar2"]}
    b = {"foo":"baz", "fubar":["bar1"]}
    c = {"foo":"bar", "fubar":["bar1","bar3"]}
    d = {"foo":"bar", "fubar":["bar1","bar2"]}
    e = {"foo":"bar", "fubar":["bar1"],"fubar2":"bar2"}
    f = {"foo":"bar", "fubar":["bar1","bar2"],"fubar2":"bar3"}
    g = {"foo":"bar", "fubar":["bar1","bar2"],"fubar2":"bar3","fubar3":{"foo":"bar"}}

# Generated at 2022-06-20 15:49:58.519759
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    temp_dict = {"dict1": {"key1": "value1", "key2": "value2"},
                 "dict2": {"dict3": {"key1": 1, "key2": 2}}}
    temp_dict = snake_dict_to_camel_dict(temp_dict)
    assert temp_dict == {"Dict1": {"Key1": "value1", "Key2": "value2"},
                         "Dict2": {"Dict3": {"Key1": 1, "Key2": 2}}}



# Generated at 2022-06-20 15:50:09.706396
# Unit test for function dict_merge
def test_dict_merge():

    # base cases
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': 1}, {}) == {'a': 1}
    assert dict_merge({}, {'A': 1}) == {'A': 1}

    # multi-level dicts
    assert dict_merge({'a': {'b': {'c': 1}}}, {'a': {'b': {'c': 2}}}) == {'a': {'b': {'c': 2}}}
    assert dict_merge({'a': {'b': {'c': 1}}}, {'a': {'b': {'d': 2}}}) == {'a': {'b': {'c': 1, 'd': 2}}}

# Generated at 2022-06-20 15:50:15.393827
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"http_endpoint": "http://api.example.com", "tags": {"environment": "prod"}}
    expected = {"httpEndpoint": "http://api.example.com", "tags": {"environment": "prod"}}
    assert snake_dict_to_camel_dict(test_dict) == expected



# Generated at 2022-06-20 15:50:24.464262
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Test recursive_diff function
    """

    # Two empty dictionaries
    dict1 = {}
    dict2 = {}
    result = recursive_diff(dict1, dict2)
    assert result == None, "recursive_diff failed for empty dictionaries"

    # Two identical dictionaries
    dict1 = {
        'one': 'alpha',
        'two': 'beta',
        'three': {'four': 'delta'}
    }
    dict2 = {
        'three': {'four': 'delta'},
        'one': 'alpha',
        'two': 'beta'
    }
    result = recursive_diff(dict1, dict2)
    assert result == None, "recursive_diff failed for identical dictionaries"

    # Two different dictionaries

# Generated at 2022-06-20 15:50:35.790183
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict()
    dict2 = dict()
    dict1['key1'] = 'value1'
    dict1['key2'] = 'value2'
    dict1['key3'] = dict()
    dict1['key3']['dict1key1'] = 'dict1value1'
    dict1['key3']['dict1key2'] = 'dict2value2'
    dict2['key1'] = 'newvalue1'
    dict2['key3'] = dict()
    dict2['key3']['dict1key1'] = 'newdict1value1'

    dict_merge(dict1, dict2)

    assert dict1['key1'] == 'value1'
    assert dict1['key2'] == 'value2'
    assert dict1['key3']['dict1key1']

# Generated at 2022-06-20 15:50:47.375447
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Verify that the module will correctly convert a dictionary with nested dictionaries
    # and lists to camel case.
    nested_dict = {
        'a_string': "Test",
        'an_integer': 1,
        'dict_1': {
            'sub_string': 'sub_str',
            'sub_int': 2,
        },
        'list_1': [
            {
                'sub_sub_list_string_1': "sub_sub_list_string",
                'sub_sub_list_string_2': "sub_sub_list_string_2"
            },
        ],
    }


# Generated at 2022-06-20 15:50:57.609384
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    import unittest

    class TestSnakeDictToCamelDict(unittest.TestCase):
        def setUp(self):
            self.snake_dict = {'boolean_true': True,
                               'boolean_false': False,
                               'int_zero': 0,
                               'int_not_zero': 1,
                               'string': 'a string',
                               'dict': {'a_key': 'a value'},
                               'list': [{'a_key': 'a value'}, {'another_key': 'another value'}]}
            self.camel_dict = snake_dict_to_camel_dict(self.snake_dict)

        def test_type(self):
            self.assertEqual(isinstance(self.snake_dict, dict), True)

# Generated at 2022-06-20 15:51:09.481608
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'thisIsCamel': 1, 'thisIsCamel2': 2}) == {'this_is_camel': 1,
                                                                              'this_is_camel2': 2}

    assert camel_dict_to_snake_dict({'thisIsCamel': 1, 'tags': {'thisIsCamel2': 2}}) == {'this_is_camel': 1,
                                                                                         'tags': {'thisIsCamel2': 2}}


# Generated at 2022-06-20 15:51:22.138538
# Unit test for function recursive_diff
def test_recursive_diff():
    result = recursive_diff(
        {
            "sqs_configuration": {
                "redrive_policy": {
                    "dead_letter_target_arn": "arn:aws:sqs:us-east-1:123456789012:dead-letter-queue",
                    "max_receive_count": "10"
                }
            }
        },
        {
            "sqs_configuration": {
                "redrive_policy": {
                    "dead_letter_target_arn": "arn:aws:sqs:us-east-1:123456789012:dead-letter-queue",
                    "max_receive_count": "5"
                }
            }
        }
    )


# Generated at 2022-06-20 15:51:30.528507
# Unit test for function dict_merge
def test_dict_merge():
    a = {'one':1,'two':2}
    b = {'three':3,'four':4}
    c = dict_merge(a,b)
    assert c['one'] == 1
    assert c['two'] == 2
    assert c['three'] == 3
    assert c['four'] == 4
    a = {'one':1,'two':2,'three':{'a':'b','c':'d'}}
    b = {'two':7,'three':{'c':'f'},'four':4}
    c = dict_merge(a,b)
    assert c['one'] == 1
    assert c['two'] == 7
    assert c['three']['a'] == 'b'
    assert c['three']['c'] == 'f'

# Generated at 2022-06-20 15:51:42.059534
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:51:52.485776
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'aCamelCaseKey': 'hello_world',
        'aSubObject': {
            'anotherCamelCaseKey': 'world_hello',
            'aList': [1, 2, 3]
        }
    }

    expected_dict = {
        'a_camel_case_key': 'hello_world',
        'a_sub_object': {
            'another_camel_case_key': 'world_hello',
            'a_list': [1, 2, 3]
        }
    }

    assert expected_dict == camel_dict_to_snake_dict(camel_dict)



# Generated at 2022-06-20 15:51:57.599896
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dct = {
        'foo': 1,
        'bar': 2,
        'baz': {
            'fooBar': 3,
            'barBaz': 4,
            'bazBiz': [5, 6, 7],
            'firstElement': 'one',
            'secondElement': 'two',
            'thirdElement': 'three',
            'Tags': {
                'tag1': "value of tag1",
                'tag2': "value of tag2",
                'tag3': "value of tag3"
            },
            'tags': [
                {
                    'tag1': "value of tag1",
                    'tag2': "value of tag2",
                    'tag3': "value of tag3"
                }
            ]
        }
    }

# Generated at 2022-06-20 15:52:03.121844
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {
            'VpcId': 'vpc-123456789',
            'Subnets': [
                'subnet-123456789'
            ],
            'Tags': {
                'k1': 'v1',
                'k2': 'v2'
            }
        }
    ) == {
        'vpc_id': 'vpc-123456789',
        'subnets': [
            'subnet-123456789'
        ],
        'tags': {
            'k1': 'v1',
            'k2': 'v2'
        }
    }



# Generated at 2022-06-20 15:52:19.481715
# Unit test for function dict_merge
def test_dict_merge():
    '''Returns true if the test passes and false if it fails'''
    from collections import OrderedDict
    a = dict(x=1, y=2, z=OrderedDict(c=3, d=4), t=3)
    b = dict(x=1, w=7, z=OrderedDict(c=3, e=5), t=3)
    c = dict(x=1, w=7, y=2, z=OrderedDict(c=3, d=4, e=5), t=3)
    return c == dict_merge(a, b)

# Generated at 2022-06-20 15:52:30.318644
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test for singular camel word
    snake_dict = {'camel_dict': 'string'}
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {'CamelDict': 'string'}

    # Test for singular snake word
    snake_dict = {'snake_dict': 'string'}
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {'snakeDict': 'string'}

    # Test for singular snake word with underscore
    snake_dict = {'snake_dict_': 'string'}
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {'snakeDict_': 'string'}



# Generated at 2022-06-20 15:52:37.475694
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }

    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'empty' : { } }

# Generated at 2022-06-20 15:52:49.406308
# Unit test for function dict_merge
def test_dict_merge():
    """Runs tests for dict_merge"""

    # Test cases
    test_case_1 = ({}, {}, {})
    test_case_2 = ({'a': 'b'}, {}, {'a': 'b'})
    test_case_3 = ({}, {'a': 'b'}, {'a': 'b'})
    test_case_4 = ({'a': 'b'}, {'a': 'c'}, {'a': 'c'})
    test_case_5 = ({'a': {'b': 1}}, {'a': {'c': 2}}, {'a': {'b': 1, 'c': 2}})
    test_case_6 = ({'a': {'b': 1}}, {'a': 'c'}, {'a': 'c'})
    test_

# Generated at 2022-06-20 15:52:58.673409
# Unit test for function dict_merge
def test_dict_merge():

    from ansible.module_utils.six import PY3

    # A few examples of how the function should behave
    a = {'first': {'all_rows': {'pass': 'dog', 'number': '1'}}}

    b = {'first': {'all_rows': {'fail': 'cat', 'number': '5'}}}

    expected_merge = {'first': {'all_rows': {'pass': 'dog', 'fail': 'cat', 'number': '5'}}}

    c = {'first': {'all_rows': {'fail': {'fail_1': 'cat', 'fail_2': 'cat'},'pass': {'pass_1': 'dog', 'pass_2': 'dog'}}}}


# Generated at 2022-06-20 15:53:09.942095
# Unit test for function recursive_diff
def test_recursive_diff():
    import json
    test_a = {
        'key1': 'value1',
        'key2': 'value2',
        'level1': {
            'key1': 'value1',
            'key2': 'value2',
            'level2': {
                'key1': 'value1',
                'key2': 'value2',
            }
        }
    }
    test_b = {
        'key1': 'value1',
        'key2': 'diff_value2',
        'level1': {
            'key1': 'value1',
            'key2': 'diff_value2',
            'level2': {
                'key1': 'value1',
                'key2': 'diff_value2',
            }
        }
    }

# Generated at 2022-06-20 15:53:21.599181
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test with no differences
    assert recursive_diff({}, {}) is None

    # Test with simple differences
    assert recursive_diff({'a': '1'}, {'a': '2'}) == ({'a': '1'}, {'a': '2'})

    # Test with dictionary differences
    assert recursive_diff(
        {'a': {'x': '1'}},
        {'a': {'y': '2'}}
    ) == ({'a': {'x': '1'}}, {'a': {'y': '2'}})

    # Test with no differences in nested dictionaries
    assert recursive_diff(
        {'a': {'x': '1', 'y': '2'}},
        {'a': {'x': '1', 'y': '2'}}
    )

# Generated at 2022-06-20 15:53:32.838667
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        'key1' : 'val1',
        'key2' : {
            'key3' : 'val3',
            'key4' : 'val4'
        },
        'key5' : 'val5',
        'list1' : [
            'list1val1',
            'list1val2'
        ]
    }


# Generated at 2022-06-20 15:53:42.737166
# Unit test for function recursive_diff
def test_recursive_diff():
    test_1 = {'k1': 'v1',
              'k2': {
                  'k3': {
                      'k4': [1, 2],
                      'k5':'v5'
                      }
                  }
              }
    test_2 = {'k1': 'v1',
              'k2': {
                  'k3': {
                      'k4': [1]
                      }
                  }
              }
    test_3 = {'k1': 'v1',
              'k2': {
                  'k3': {
                      'k4': 'v4',
                      'k5': None
                      }
                  }
              }

# Generated at 2022-06-20 15:53:52.076742
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 'foo', 'b': {'c':'bar', 'd': 'baz'}},
                          {'a': 'foo', 'b': {'c':'bar', 'd': 'qux'}}) == ({'b': {'d': 'qux'}}, {'b': {'d': 'baz'}})
    assert recursive_diff({'a': 'foo'}, {'a': 'bar'}) == ({'a': 'foo'}, {'a': 'bar'})
    assert recursive_diff({'a': {'b': 'foo'}}, {'a': 'foo'}) == ({'a': {'b': 'foo'}}, {'a': 'foo'})