

# Generated at 2022-06-20 15:44:29.289476
# Unit test for function recursive_diff
def test_recursive_diff():
    # Make sure that no differences return None
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'x': 1}, {'x': 1}) is None

    # Make sure that simple differences are returned
    assert recursive_diff({'x': 1}, {'x': 2}) == ({'x': 1}, {'x': 2})
    assert recursive_diff({'x': 1}, {'y': 1}) == ({'x': 1}, {'y': 1})

    # Make sure that nested differences are returned
    assert recursive_diff({'x': {'y': 1}}, {'x': {'y': 2}}) == ({'x': {'y': 1}}, {'x': {'y': 2}})

    # Make sure that nested differences are returned and that
    # differences in non-nested properties are returned


# Generated at 2022-06-20 15:44:40.377723
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Test that snake_dict_to_camel_dict works as expected"""
    # test regular conversion
    regular_dict = {'test': 'hello world', 'testing': 'hello world'}
    expected_regular_dict = {'test': 'hello world', 'testing': 'hello world'}
    assert snake_dict_to_camel_dict(regular_dict) == expected_regular_dict
    # test conversion of a nested dict
    nested_dict = {'test': 'hello world', 'testing': 'hello world', 'nested_dict': {'test': 'hello world'}}
    expected_nested_dict = {'test': 'hello world', 'testing': 'hello world', 'nestedDict': {'test': 'hello world'}}
    assert snake_dict_to_camel_dict(nested_dict) == expected

# Generated at 2022-06-20 15:44:49.233986
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    data = {
        'tag_filters': [
            {'tag_key': 'string', 'tag_values': ['string']}],
        'availability_zones': ['us-east-1a'],
        'filters': [
            {'name': 'string', 'values': ['string']}]
    }

    expected = {
        'tagFilters': [
            {'tagKey': 'string', 'tagValues': ['string']}],
        'availabilityZones': ['us-east-1a'],
        'filters': [
            {'name': 'string', 'values': ['string']}]
    }

    camel_data = snake_dict_to_camel_dict(data)

    assert camel_data == expected

# Generated at 2022-06-20 15:45:00.945460
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'key1': 'value1', 'keyTwo': 'value2'}
    assert camel_dict_to_snake_dict(camel_dict) == {'key_one': 'value1', 'key_two': 'value2'}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict)) == camel_dict
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict, True)) != camel_dict

    camel_dict = {'key1': 'value1', 'keyTwo': {'innerKey': 'innerValue'}}

# Generated at 2022-06-20 15:45:11.095557
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = {'a': 1, 'b': {'a': 1, 'b': 2}, 'c': 1}
    dict_b = {'a': 1, 'b': {'a': 1, 'b': 3}, 'd': 2}
    dict_c = {'a': 1, 'b': {'a': 1, 'b': 2}, 'c': 1}
    dict_d = {'b': {'a': 1, 'b': 2}, 'c': 1}
    dict_e = {'a': 1, 'b': 2, 'c': 1}
    dict_f = {'b': {'a': 1, 'b': None}, 'c': 1}

# Generated at 2022-06-20 15:45:22.225343
# Unit test for function dict_merge

# Generated at 2022-06-20 15:45:28.567661
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'a', 'b': 'b', 'c': {'d': 'd', 'e': 'e'}}
    b = {'a': 'A', 'c': {'e': 'E', 'f': 'f'}}
    result = {'a': 'A', 'b': 'b', 'c': {'d': 'd', 'e': 'E', 'f': 'f'}}
    assert result == dict_merge(a, b)



# Generated at 2022-06-20 15:45:37.835712
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': 'value1', 'key2': 'value2', 'key3': {'key31': 'value31', 'key32': 'value32'},
             'key4': ['value4']}
    dict2 = {'key2': 'value2', 'key3': {'key31': 'value3', 'key33': 'value33'}, 'key4': ['value4']}
    print(dict1)
    print(dict2)
    diff = recursive_diff(dict1, dict2)
    print("\nDiff:")
    print("Left:\n", diff[0])
    print("Right:\n", diff[1])

# Generated at 2022-06-20 15:45:49.311292
# Unit test for function dict_merge
def test_dict_merge():

    from ansible.module_utils.ec2 import dict_merge

    test1 = dict(
        a=dict(
            one=1,
            two=2,
            three=3
        )
    )

    test2 = dict(
        a=dict(
            one=1,
            two=2,
            three=3
        )
    )

    result = dict_merge(test1, test2)
    assert result == dict(
        a=dict(
            one=1,
            two=2,
            three=3
        )
    )

    # test __opts__ merge

# Generated at 2022-06-20 15:46:00.389503
# Unit test for function recursive_diff
def test_recursive_diff():
    # Case one: One is empty, other has content
    dict1 = {}
    dict2 = {
        'key1': 'value1',
    }
    diff = recursive_diff(dict1, dict2)
    if diff != ({}, {'key1': 'value1'}):
        raise TypeError("Case 1 is not correct! Expected two empty dictionaries but got %s" % diff)

    # Case two: Dicts are identical

# Generated at 2022-06-20 15:46:15.469019
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({"a": 1}, {"a": 1}) is None
    assert recursive_diff({"a": 1}, {"a": 2}) == ({"a": 1}, {"a": 2})
    assert recursive_diff({"a": 1}, {"b": 1}) == ({'a': 1}, {'b': 1})
    assert recursive_diff({"a": 1, "b": 2}, {"a": 2, "b": 1}) == ({"a": 1, "b": 2}, {"a": 2, "b": 1})
    assert recursive_diff({"a": 1, "b": 2}, {"a": 1}) == ({"b": 2}, {"b": None})

# Generated at 2022-06-20 15:46:26.361578
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({"_a": 1}) == {"_a": 1}
    assert snake_dict_to_camel_dict({"a_b": 1}) == {"aB": 1}
    assert snake_dict_to_camel_dict({"a_b_c": 1}) == {"aBC": 1}
    assert snake_dict_to_camel_dict({"a_b_c": 1}, True) == {"aBC": 1}
    assert snake_dict_to_camel_dict({"a_b_c_d": 1}) == {"aBCD": 1}

# Generated at 2022-06-20 15:46:35.359777
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}}
    d2 = {'c': {'h': 'i', 'j': 'k'}, 'l': 'm'}
    d3 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'l': 'm'}
    d4 = d1  # Same reference

    assert recursive_diff(d1, d2) == ({}, {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'l': 'm'})
    assert recursive_diff(d2, d1) == ({'c': {'h': 'i', 'j': 'k'}, 'l': 'm'}, {})
    assert recursive_diff

# Generated at 2022-06-20 15:46:41.626414
# Unit test for function recursive_diff
def test_recursive_diff():

    assert recursive_diff({}, {}) is None

    a = {
        "a": 1,
        "b": 1,
        "c": {
            "a": 2,
            "b": 2,
            "c": {},
            "d": {
                "a": 1,
                "b": 2,
                "c": 3,
            },
            "e": {
                "a": 1,
                "b": 2,
                "c": 3,
            },
        },
        "d": 1,
        "e": {
            "a": 1,
            "b": 2,
        },
    }


# Generated at 2022-06-20 15:46:49.999145
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_case_dict = {'HTTPEndpoint': 'https://amazon.com', 'CamelCase': {'IAMRoleName': 'iam-role-name'},
                       'PluralCamelCase': [{'InstanceIds': ['i-111222333', 'i-123456789']},
                                           {'InstanceIds': ['i-345678901', 'i-555566666']}],
                       'TagFilters': [{'Key': 'Name', 'Values': ['a', 'b']}, {'Key': 'Project', 'Values': ['x', 'y']}],
                       'PluralCamelCaseCount': 2}

# Generated at 2022-06-20 15:46:55.852784
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': 1, 'c': 2}, 'd': 5, 'e': 6}
    b = {'a': {'b': 3, 'f': 4}, 'g': 7}

    c = dict_merge(a, b)
    assert c == {'a': {'b': 3, 'c': 2, 'f': 4}, 'd': 5, 'e': 6, 'g': 7}

# Generated at 2022-06-20 15:47:04.344439
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "StatusCode": 200,
        "StatusMessage": "Status message",
        "Protocol": "Protocol",
        "HTTPStatusCode": 200,
        "HTTPHeaders": {
            "HTTPHeader1": "Value1",
            "HTTPHeader2": "Value2"
        },
        "Tags": {
            "Tag1Key": "Tag1Value",
            "Tag2Key": "Tag2Value"
        },
        "HTTPEndpoint": "/"
    }


# Generated at 2022-06-20 15:47:16.244052
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'a': 'a', 'b': {'b': {'b': 'b'}, 'c': 'c'}, 'd': 'a'}
    b = {'a': 'a', 'b': {'b': {'b': 'b'}, 'c': 'c'}, 'd': 'd'}
    c = {'a': 'a', 'b': {'b': {'b': 'b'}, 'c': 'c'}, 'd': {'d': 'd'}}
    d = {'a': 'a', 'b': {'b': {'b': 'b'}, 'c': 'c'}, 'd': {'d': 'd'}, 'e': 'e'}

# Generated at 2022-06-20 15:47:25.098802
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'dict': {'a': 1, 'b': 2}, 'list': [1, 2, 3], 'int': 42}
    dict2 = {'dict': {'a': 13, 'b': 2}, 'list': [1, 2, 42], 'string': 'string'}
    assert recursive_diff(dict1, dict2) == ({'dict': {'a': 1}, 'list': [3], 'int': 42},
                                            {'dict': {'a': 13}, 'list': [42], 'string': 'string'})

    dict1 = {'a': 1}
    dict2 = {'a': 1}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 42}
    dict2 = {'a': 42}

# Generated at 2022-06-20 15:47:37.226341
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'name': 'my-name',
        'resourceType': 'my-type',
        'properties': {
            'availabilityZones': ['zone1', 'zone2'],
            'someResourceTagList': [{
                'key': 'service',
                'value': 'dev'
            }],
            'someS3Connection': {
                'connectionName': 'my-connection-name'
            },
            'someBool': 'true'
        }
    }
    result = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-20 15:47:47.942975
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(color='red', user={'name': 'user1', 'hobbies': ['hobby1']}, nochange=True)
    b = dict(color='blue', number=42, user={'name': 'user2', 'hobbies': ['hobby2']})
    #print "A: %s" % a
    #print "B: %s" % b
    result = dict_merge(a, b)
    #print "Result: %s" % result
    assert result['color'] == 'blue'
    assert result['number'] == 42
    assert result['nochange'] == True
    assert result['user']['name'] == 'user2'
    assert result['user']['hobbies'] == ['hobby2']


test_dict_merge()

# Generated at 2022-06-20 15:47:56.863070
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    from ansible_collections.amazon.aws.plugins.module_utils.core import camel_dict_to_snake_dict

# Generated at 2022-06-20 15:48:05.581734
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"test_key": "test_value"}) == {
        'testKey': 'test_value'
    }

    assert snake_dict_to_camel_dict({
        "test_key": {
            "test_key2": "test_value"
        }
    }) == {'testKey': {'testKey2': 'test_value'}}

    assert snake_dict_to_camel_dict({"test_key": "test_value"}, True) == {
        'TestKey': 'test_value'
    }


# Generated at 2022-06-20 15:48:16.852145
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # test for simple dictionary
    snake_dict = {'foo_bar': 'value'}
    assert snake_dict_to_camel_dict(snake_dict) == {'fooBar': 'value'}

    # test for nested dictionary
    snake_dict = {'foo_bar': {'bar_baz': 'value'}}
    assert snake_dict_to_camel_dict(snake_dict) == {'fooBar': {'barBaz': 'value'}}

    # test for nested list
    snake_dict = {'foo_bar': [{'bar_baz': 'value'}, {'bar_baz': 'value'}]}

# Generated at 2022-06-20 15:48:25.263509
# Unit test for function dict_merge
def test_dict_merge():
    a = {'apples': 1, 'bananas': {"green": 5, "yellow": 10}, 'carrots': 2}
    b = {'apples': 2, 'bananas': {"green": 6}, 'eggs': 3}
    c = dict_merge(a, b)
    assert c['apples'] == 2
    assert c['bananas']['green'] == 6
    assert c['bananas']['yellow'] == 10
    assert c['eggs'] == 3



# Generated at 2022-06-20 15:48:33.401549
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"FooBar": "foo", "Baz": {"Qux": "bar"}}) == {"foo_bar": "foo", "baz": {"qux": "bar"}}
    assert camel_dict_to_snake_dict({"FooBar": "Foo", "Baz": {"Qux": "Bar"}}) == {"foo_bar": "Foo", "baz": {"qux": "Bar"}}
    assert camel_dict_to_snake_dict({"FooBar": "foo", "Baz": {"Qux": "bar"}, "Tags": {"tag": "tag value"}}) == {"foo_bar": "foo", "baz": {"qux": "bar"}, "tags": {"tag": "tag value"}}



# Generated at 2022-06-20 15:48:44.966277
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Value expected from function
    expected = {
        'count': 123,
        'list': [
            {
                'itemName': 'foo',
                'itemValue': 123
            },
            {
                'itemName': 'bar',
                'itemValue': 123
            }
        ],
        'dictionary': {
            'foo': 'bar',
            'bar': 'foo'
        }
    }

    # Dictionary to be converted

# Generated at 2022-06-20 15:48:56.520604
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'test': 'test',
        'test2': {
            1: 'one'
        },
        'test3': {
            2: 'two',
            3: 'three'
        }
    }

    b = {
        'test2': {
            2: 'two'
        },
        'test3': {
            1: 'one',
            2: 'two'
        },
        'test4': 'test4'
    }

    c = {
        'test': 'test',
        'test2': {
            1: 'one',
            2: 'two'
        },
        'test3': {
            1: 'one',
            2: 'two',
            3: 'three'
        },
        'test4': 'test4'
    }


# Generated at 2022-06-20 15:49:06.321558
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'target_group_arns': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                              'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'],
        'ec2_instance_ids': ['i-0f76fade', 'i-0a12b3c4', 'i-0891023a'],
        'my_list': [{'nested_list': ['nested_list_value_1', 'nested_list_value_2']}, 'list_value']
    }

# Generated at 2022-06-20 15:49:13.169789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Standard case
    camel_dict = {'fooBar': 'baz', 'bazQux': 'quux'}
    expected = {'foo_bar': 'baz', 'baz_qux': 'quux'}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected

    # List case
    camel_dict = {'fooBar': ['baz', 'quux'], 'FOOBar': ['quuux', 'quuuux']}
    expected = {'foo_bar': ["baz", "quux"], 'foo_bar': ["quuux", "quuuux"]}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected

    # Dict case

# Generated at 2022-06-20 15:49:17.193525
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict = {"foo_bar_baz": 1}
    dict = snake_dict_to_camel_dict(dict)
    assert dict['fooBarBaz'] == 1


# Generated at 2022-06-20 15:49:28.590877
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"test_key": {"test_key2": "test_value2"}}
    new_test_dict = snake_dict_to_camel_dict(test_dict)
    assert new_test_dict == {"testKey": {"testKey2": "test_value2"}}
    new_test_dict = snake_dict_to_camel_dict(test_dict, capitalize_first=True)
    assert new_test_dict == {"TestKey": {"TestKey2": "test_value2"}}
    test_dict = {"test_key": {"test_key2": ["test_value2", {"test_key3": "test_value3"}]}}
    new_test_dict = snake_dict_to_camel_dict(test_dict)

# Generated at 2022-06-20 15:49:34.548707
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input = {
        "instance_name": "foo",
        "tags": {
            "Key": "Name",
            "Value": "Foo"
        }
    }
    expected = {
        "instanceName": "foo",
        "tags": {
            "Key": "Name",
            "Value": "Foo"
        }
    }
    result = snake_dict_to_camel_dict(input)
    assert result == expected

# Generated at 2022-06-20 15:49:44.261177
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(dict(foo="bar"), dict(ansible="awesome", foo="baz")) == dict(ansible="awesome", foo="baz")
    assert dict_merge(dict(foo="bar", dict1=dict(a="b")), dict(dict1=dict(a="c", b="d"))) == dict(
        foo="bar", dict1=dict(a="c", b="d"))
    assert dict_merge(dict(dict1=dict(a="c", b="d")), dict(foo="bar", dict1=dict(a="b"))) == dict(
        foo="bar", dict1=dict(a="b"))

# Generated at 2022-06-20 15:49:54.456118
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:50:01.802868
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({'foo': 'bar'}) == {'foo': 'bar'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz'}) == {'fooBar': 'baz'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz', 'foo': 'bar'}) == {'fooBar': 'baz', 'foo': 'bar'}

# Generated at 2022-06-20 15:50:11.800200
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:50:21.607419
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"TestMode": True, "EnvironmentVariables": [{"key": "AWS_ACCESS_KEY", "value": "secret"}, {"key": "AWS_SECRET_KEY", "value": "super_secret"}]}
    test_dict = {"TestMode": True, "EnvironmentVariables": [{"key": "AWS_ACCESS_KEY", "value": "secret"}, {"key": "AWS_SECRET_KEY", "value": "super_secret"}]}
    assert test_dict == camel_dict_to_snake_dict(camel_dict)
    camel_dict = {"TestMode": True, "EnvironmentVariables": [{"key": "AWS_ACCESS_KEY", "value": "secret"}, {"key": "AWS_SECRET_KEY", "value": "super_secret"}]}

# Generated at 2022-06-20 15:50:31.264752
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:50:43.152274
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key_1': 'value_1',
        'key_2': {
            'key_2_1': 'value_2_1',
            'key_2_2': 'value_2_2',
            'key_2_3': 'value_2_3',
        },
    }

    dict2 = {
        'key_1': 'value_1',
        'key_2': {
            'key_2_1': 'value_2_1',
            'key_2_2': 'value_2_2',
            'key_2_3': 'value_2_3_new',
        },
    }


# Generated at 2022-06-20 15:50:52.261866
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'my_snake_key': 'my_snake_value'}) == {'mySnakeKey': 'my_snake_value'}
    assert snake_dict_to_camel_dict({'mySnakeKey': 'my_snake_value'}, True) == {'MySnakeKey': 'my_snake_value'}
    return True


# Generated at 2022-06-20 15:50:59.930873
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = {
        'this_is_a_test': 'THIS IS A TEST',
        'this_is_an_embedded_dict': {
            'this_is_a_sub_test': 'this_is_a_sub_test!',
            'this_is_an_embedded_sub_list': [
                'sub_list_item1',
                'sub_list_item2',
                'sub_list_item3'
            ]
        }
    }

# Generated at 2022-06-20 15:51:12.443025
# Unit test for function dict_merge

# Generated at 2022-06-20 15:51:24.031423
# Unit test for function recursive_diff
def test_recursive_diff():
    result = recursive_diff({'a': 'b', 'c': {'d': 'e', 'f': 'g', 'h': {'i': 'j'}}},
                            {'a': 'b', 'c': {'d': 'm', 'f': 'g', 'h': {}}})
    assert result == ({'c': {'d': 'e'}}, {'c': {'d': 'm'}})
    result = recursive_diff({'a': 'b', 'c': {'d': 'e', 'f': 'g', 'h': {'i': 'j'}}},
                            {'a': 'b', 'c': {'d': 'm', 'f': 'g', 'h': {'i': 'j'}}})

# Generated at 2022-06-20 15:51:31.544839
# Unit test for function recursive_diff
def test_recursive_diff():
    from nose.tools import ok_, eq_

    def test_no_difference():
        x = {'a': 'foobar', 'b': {'c': {'d': 'blah'}, 'e': 'blech'}}
        y = {'a': 'foobar', 'b': {'c': {'d': 'blah'}, 'e': 'blech'}}
        eq_(recursive_diff(x, y), None)

    def test_simple_difference():
        x = {'a': 'foo', 'b': {'c': {'d': 'blah'}, 'e': 'blech'}}
        y = {'a': 'bar', 'b': {'c': {'d': 'blah'}, 'e': 'blech'}}

# Generated at 2022-06-20 15:51:42.890974
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}

# Generated at 2022-06-20 15:51:54.103690
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, \
        "dict_merge() failure"
    try:
        assert dict_merge(None, None)
        raise RuntimeError("dict_merge() should have failed when passed non-dict.")
    except TypeError as e:
        pass


# Generated at 2022-06-20 15:52:05.686020
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_values = {
        'hi': 'there',
        'next_is_dict': {
            'one': 1,
            'two': 2,
            'three': {
                'four': 4,
                'five': 5,
                'six': [1,2,3,4,5,6],
                'seven': [
                    {'eight': 8},
                    {'nine': 9}
                ]
            }
        },
        'next_is_list': [
            {'ten': 10},
            {'eleven': 11}
        ]
    }

    camelized = snake_dict_to_camel_dict(test_values, True)

    # Check that the value for 'hi' is unchanged
    assert 'there' == camelized['hi']

    # Check that 'next_is_dict'

# Generated at 2022-06-20 15:52:18.277301
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {"a_b_c": 3, "d_e_f": None, "x_y_z": {"i": 1, "j": 2, "k": 3},
                  "l_i_s_t": [{"a_b_c": 3}, {"d_e_f": 4}, {"x_y_z": [1, 2, 3]}], "t_a_g": {"a": "b"}}
    expected = {"aBC": 3, "dEF": None, "xYZ": {"i": 1, "j": 2, "k": 3},
                "lIST": [{"aBC": 3}, {"dEF": 4}, {"xYZ": [1, 2, 3]}], "tAG": {"a": "b"}}

# Generated at 2022-06-20 15:52:22.927936
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 5}) == {'h_t_t_p_endpoint': 5}
    assert camel_dict_to_snake_dict({'FooBar': 'Baz'}) == {'foo_bar': 'Baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'Baz', 'FizzBuzz': {'HTTPEndpoint': 5}}) == {'foo_bar': 'Baz', 'fizz_buzz': {'h_t_t_p_endpoint': 5}}
    assert camel_dict_to_snake_dict({'TargetGroupARNs': ['']}) == {'target_group_a_r_ns': ['']}

# Generated at 2022-06-20 15:52:35.093193
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test function recursive_diff"""
    assert not recursive_diff({}, {})
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': []}, {'a': [1]}) == ({'a': []}, {'a': [1]})
    assert recursive_diff({'a': {'b': 'c'}}, {'a': {'b': 'd'}}) == ({'a': {'b': 'c'}}, {'a': {'b': 'd'}})

# Generated at 2022-06-20 15:52:46.435749
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_input_dict = {
        'tags': {
            'tag1': 'val1',
            'tag2': 'val2'
        },
        'http_endpoint': {
            'ip_address': '10.0.0.1',
            'port': 80
        }
    }

    camel_output_dict = {
        'Tags': {
            'tag1': 'val1',
            'tag2': 'val2'
        },
        'HttpEndpoint': {
            'IpAddress': '10.0.0.1',
            'Port': 80
        }
    }


# Generated at 2022-06-20 15:52:51.606990
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:52:58.139178
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    payload = dict(
        a_property=1,
        another_property='value',
        nested_property=dict(
            nested_property_1='value1',
            nested_property_2='value2'),
        another_nested_property=dict(
            another_nested_property_1='value11',
            another_nested_property_2='value22',
            nested_property=dict(
                nested_property_1='value1',
                nested_property_2='value2')),
        another_list_property=[
            dict(a_property=1),
            dict(another_property=2)]
    )

    result = snake_dict_to_camel_dict(payload)


# Generated at 2022-06-20 15:53:06.983618
# Unit test for function recursive_diff
def test_recursive_diff():

    d1 = {"aaa": {"bbb": "ccc", "ddd": "eee"}, "fff": "ggg"}
    d2 = {"aaa": {"bbb": "cccc", "ddd": "eee"}, "hhh": "iii"}

    assert recursive_diff(d1, d2) == ({'aaa': {'bbb': 'ccc'}}, {'aaa': {'bbb': 'cccc'}, 'hhh': 'iii'}), 'Wrong diff'


test_recursive_diff()

# Generated at 2022-06-20 15:53:18.423274
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"fooBar": {'aBcDe': 12, 'defGhi': 34, 'tags': {'Key': 'Value'}}}) == {'foo_bar': {'abc_de': 12, 'def_ghi': 34, 'tags': {'Key': 'Value'}}}
    assert camel_dict_to_snake_dict({"fooBar": {'aBcDe': 12, 'defGhi': 34, 'tags': {'Key': 'Value'}}}, reversible=True) == {'foo_bar': {'a_b_c_de': 12, 'def_ghi': 34, 'tags': {'Key': 'Value'}}}

# Generated at 2022-06-20 15:53:29.603727
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:53:37.565295
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:53:46.770741
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2}
    b = {'y': 4, 'z': 5}
    c = {'y': {'a': 3}}
    d = {'x': 1, 'y': {'a': 3}, 'z': 5}
    e = {'x': {'a': 0}}
    f = {'x': {'a': 1}, 'y': 2}
    g = {'x': {'b': 2}, 'y': 2}
    h = {'x': {'a': 1, 'b': 2}, 'y': 2}
    i = {'x': {'a': 2}, 'y': 2}
    assert dict_merge(a, b) == {'x': 1, 'y': 4, 'z': 5}

# Generated at 2022-06-20 15:53:55.787591
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for function camel_dict_to_snake_dict
    """
    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("Test") == "test"

    assert _camel_to_snake("HTTPEndpoint", True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("Test", True) == "test"

    assert _snake_to_camel("h_t_t_p_endpoint", True) == "HTTPEndpoint"
    assert _snake_to_camel("test", True) == "Test"

    assert _snake_to_camel("h_t_t_p_endpoint") == "HttpEndpoint"
    assert _snake