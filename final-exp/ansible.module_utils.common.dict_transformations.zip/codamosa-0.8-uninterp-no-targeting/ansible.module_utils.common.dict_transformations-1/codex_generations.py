

# Generated at 2022-06-20 15:44:22.231920
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_case_input = {
        "a_list_of_items": [
            {"a_dictionary": {"of_values": "value"},
            "some_more_items": [
                "item1",
                "item2",
                {
                    "a_dictionary": {
                        "of_more_values": "value",
                    },
                },
            ],
        },
    ],
}
    dromedary_case_output = snake_dict_to_camel_dict(snake_case_input)

# Generated at 2022-06-20 15:44:31.119421
# Unit test for function recursive_diff
def test_recursive_diff():
    # Testing example from 'recursive_diff' docstring
    a = {'one': 'ONE', 'two': 'TWO', 'three': 'THREE'}
    b = {'two': 'TWO', 'three': 'THREE', 'four': 'FOUR'}
    result = recursive_diff(a, b)
    assert result == ({'one': 'ONE'}, {'four': 'FOUR'})

    # Testing empty dictionaries
    assert recursive_diff({}, {}) is None

    # Testing no differences
    a = {'hello': 'universe', 'foo': 'bar'}
    b = {'hello': 'universe', 'foo': 'bar'}
    assert recursive_diff(a, b) is None

    # Testing nested differences

# Generated at 2022-06-20 15:44:42.329505
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test that a simple camel dict is properly formatted
    test_dict = dict(ID='8a85f9894d03ce51014d03fbfba76d8r')
    expected_dict = dict(id='8a85f9894d03ce51014d03fbfba76d8r')
    output = camel_dict_to_snake_dict(test_dict)
    assert output == expected_dict

    # test that a complex camel dict is properly formatted

# Generated at 2022-06-20 15:44:53.181620
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': 2}
    d2 = {'c': 3, 'd': 4}
    assert dict_merge(d1, d2) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'b': 4, 'd': 5, 'e': 6}
    assert dict_merge(d1, d2) == {'a': 1, 'b': 4, 'c': 3, 'd': 5, 'e': 6}
    d1 = {'a': 1, 'b': {'ba': 2, 'bb': 3}, 'c': 4}

# Generated at 2022-06-20 15:45:03.441416
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'foo': 'bar'}, {'baz': 'quux'}) == {'foo': 'bar', 'baz': 'quux'}
    assert dict_merge({}, {'foo': 'bar'}) == {'foo': 'bar'}
    assert dict_merge({'foo': 'bar'}, {}) == {'foo': 'bar'}
    assert dict_merge({'foo': {'bar': 'baz'}}, {'foo': {'quux': 'corge'}}) == {'foo': {'quux': 'corge', 'bar': 'baz'}}

# Generated at 2022-06-20 15:45:13.320101
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'a': 1,
        'b': 2,
        'c': [1, 2],
        'd': {'a': 3, 'c': [1, 2], 'f': 'g'},
        'e': {'a': {'b': 'c'}, 'd': 'e'},
        'f': 'g'
    }
    b = {
        'a': 1,
        'b': 2,
        'c': [1, 2],
        'd': {'a': 3, 'b': 'c', 'c': [1, 2]},
        'e': {'a': {'b': 'd'}, 'd': 'e'},
        'f': 'h'
    }

# Generated at 2022-06-20 15:45:25.277916
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: 1}, {1: 1}) is None

    # Check example from doc-string.
    dict1 = dict(foo='bar', a=dict(b=dict(c=1, d=2)))
    dict2 = dict(foo='baz', a=dict(b=dict(c=1, e=3)))
    assert recursive_diff(dict1, dict2) == ({'foo': 'bar'}, {'foo': 'baz'})
    assert recursive_diff(dict1, dict2)[0]['a']['b']['d'] == 2
    assert recursive_diff(dict1, dict2)[1]['a']['b']['e'] == 3

    # Check that values that are dicts are recursed into.
    dict

# Generated at 2022-06-20 15:45:33.294190
# Unit test for function dict_merge
def test_dict_merge():
    '''
    Test dict_merge
    '''
    dict1 = dict(
        dicta=dict(
            dict1a='1',
            dict1b='2',
            dict1c='3',
        ),
        dictb=dict(
            dict2a='4',
            dict2b='5',
            dict2c='6',
        )
    )

    dict2 = dict(
        dicta=dict(
            dict1a='1',
            dict1b='2',
            dict1c='3',
        ),
        dictb=dict(
            dict2a='4',
            dict2b='5',
            dict2c='6',
        )
    )


# Generated at 2022-06-20 15:45:43.654038
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('HTTPEndpoint') == 'h_t_t_p_endpoint'
    assert _camel_to_snake('CamelCase') == 'camel_case'
    assert _camel_to_snake('DromedaryCase') == 'dromedary_case'
    assert _camel_to_snake('HTTPEndpoint', reversible=True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('CamelCase', reversible=True) == 'camel_case'
    assert _camel_to_snake('DromedaryCase', reversible=True) == 'dromedary_case'

# Generated at 2022-06-20 15:45:52.605906
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for recursive_diff()

    :return: ``True`` if unit test passes, ``False`` otherwise.
    :rtype: ``boolean``
    """

    result = recursive_diff({'a': 1, 'b': {'c': 1, 'd': 2, 'e': 3}, 'f': 4, 'g': 5, 'h': 6, 'i': 7},
                            {'a': 1, 'b': {'c': 1, 'd': 2, 'e': 3, 'f': 4}, 'g': 5, 'h': 6, 'i': 7, 'j': 8})
    if result == ({'b': {'f': 4}}, {'b': {'f': 4}, 'j': 8}):
        return True
    return False


# Generated at 2022-06-20 15:46:04.602200
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    sample_snake_dict = {
        "list_of_things": [
            {"thing_name": "thing1", "thing_id": "1"},
            {"thing_name": "thing2", "thing_id": "2"}
        ],
        "this_is_a_test": [
            {"test_name": "test1", "test_id": "1"},
            {"test_name": "test2", "test_id": "2"}
        ]
    }


# Generated at 2022-06-20 15:46:09.188903
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test cases for camel_dict_to_snake_dict
    class TestCase(object):

        def __init__(self, name, input_dict, output_dict, reversible=False, ignore_list=()):
            self.name = name
            self.input_dict = input_dict
            self.output_dict = output_dict
            self.reversible = reversible
            self.ignore_list = ignore_list


# Generated at 2022-06-20 15:46:17.837236
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Test recursive_diff function
    """

    new_dict = {'group1': {'a': '1', 'b': '2', 'c': '3'}}
    old_dict = {'group1': {'a': '1', 'b': '2', 'c': '30'}, 'group2': {'d': '40', 'e': '50'}}
    # diff should be =>
    # left: {'group1': {'c': '3'}}
    # right: {'group1': {'c': '30'}}
    (left, right) = recursive_diff(new_dict, old_dict)
    assert left == {'group1': {'c': '3'}} and right == {'group1': {'c': '30'}}


# Generated at 2022-06-20 15:46:23.243948
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict_test = {"tEsT": "test", "test_test": "test", "test_test_test": "test_test_test", "test__test": "test"}
    assert snake_dict_to_camel_dict(dict_test) == {'tEsT': 'test', 'testTest': 'test', 'testTestTest': 'test_test_test', 'testTest': 'test'}



# Generated at 2022-06-20 15:46:33.327284
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'test_a': 'test_a_value',
                  'test_b': {'test_c': 'test_c_value',
                             'test_d': {'test_e': 'test_e_value'}},
                  'test_f': ['test_f_value1', 'test_f_value2', {'test_g': 'test_g_value'}]}

    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict['testA'] == 'test_a_value'
    assert camel_dict['testB']['testC'] == 'test_c_value'
    assert camel_dict['testB']['testD']['testE'] == 'test_e_value'

# Generated at 2022-06-20 15:46:44.007776
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: {2: {3: 4}}}, {1: {2: {3: 4}}}) is None

    assert recursive_diff({1: {2: {3: 4}}}, {1: {2: {3: 5}}}) == ({1: {2: {3: 4}}}, {1: {2: {3: 5}}})
    assert recursive_diff({1: {2: {3: 4}}}, {1: {2: {5: 6}}}) == ({1: {2: {3: 4}}}, {1: {2: {5: 6}}})

# Generated at 2022-06-20 15:46:51.959935
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:46:57.279764
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': '1'}, {}) == ({'a': '1'}, {})
    assert recursive_diff({}, {'a': '1'}) == ({}, {'a': '1'})
    assert recursive_diff({'a': '1'}, {'a': '2'}) == ({'a': '1'}, {'a': '2'})
    assert recursive_diff({'a': '1'}, {'a': '1'}) is None
    assert recursive_diff({'a': {'b': '1'}}, {}) == ({'a': {'b': '1'}}, {})

# Generated at 2022-06-20 15:47:02.942208
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'a', 'b': 'b', 'c': {'d': 'd', 'e': 'e'}}
    b = {'a': 'A', 'b': 'B', 'c': {'f': 'f', 'e': 'E'}}
    c = dict_merge(a, b)
    assert c == {'a': 'A', 'b': 'B', 'c': {'d': 'd', 'f': 'f', 'e': 'E'}}



# Generated at 2022-06-20 15:47:15.141374
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.common._collections_compat import Mapping
    assert recursive_diff({}, {}) == None

    assert recursive_diff({'a': 1}, {'a': 1}) == None

    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, {})

    assert recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == ({}, {'b': 2})

    assert recursive_diff({'a': 1}, {'b': 2}) == ({'a': 1}, {'b': 2})


# Generated at 2022-06-20 15:47:34.631187
# Unit test for function dict_merge
def test_dict_merge():
    # Tests for nested merges that recognize that
    # lists are not mutable and should be replaced
    # if changed
    a = {'foo': ['bar', 'baz']}
    b = {'foo': ['qux', 'quux']}

    # Test if a new value can be added
    c = {'foo': 'bar'}
    expected_c = {'foo': 'bar'}
    assert dict_merge(c, {}) == expected_c

    # Test if a key can be replaced
    c = {'foo': 'bar', 'xyzzy': 'plugh'}
    expected_c = {'xyzzy': 'plugh'}
    assert dict_merge(c, {}) == expected_c

    # Test if a value can be replaced in a list

# Generated at 2022-06-20 15:47:45.559484
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"camel_case": "value",
                 "snake_case": ["value", "value",{"list_item":"value","list_item":"value"}],
                 "camelCase": {"camelCase":"value","snake_case":"value","camel_case":"value",
                               "camelCase": [{"camelCase": "value"}]}
                 }

    camelized_dict = snake_dict_to_camel_dict(test_dict)

    assert camelized_dict['camelCase'] == 'value'
    assert camelized_dict['snakeCase'] == ['value', 'value',{'listItem':'value','listItem':'value'}]
    assert camelized_dict['camelCase']['camelCase'] == 'value'

# Generated at 2022-06-20 15:47:55.061938
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 'A', 'b': 'B', 'c': {'d': 'D', 'e': {'i': 'I', 'j': 'J'}, 'f': 'F', 'g': 'G'}}
    d2 = {'a': 'A1', 'c': {'d': 'D2', 'e': {'k': 'K'}, 'f': 'F2'}, 'h': 'H'}
    d3 = dict_merge(d1, d2)
    assert d3['a'] == 'A1'
    assert d3['b'] == 'B'
    assert d3['c']['d'] == 'D2'
    assert d3['c']['e']['i'] == 'I'

# Generated at 2022-06-20 15:48:05.771593
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:48:16.896005
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    inp = {'auto_scaling_group_name': 'test', 'some_key': 123, 'tags': {'tags': [{'key': 'tag_one', 'value': 'tag_value'}]}}
    res = snake_dict_to_camel_dict(inp)
    assert res == {'AutoScalingGroupName': 'test', 'someKey': 123, 'tags': {'tags': [{'key': 'tag_one', 'value': 'tag_value'}]}}
    res2 = snake_dict_to_camel_dict(inp, True)
    assert res2 == {'AutoScalingGroupName': 'test', 'SomeKey': 123, 'Tags': {'Tags': [{'Key': 'tag_one', 'Value': 'tag_value'}]}}

# Generated at 2022-06-20 15:48:28.302197
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = {'a': {'b': {'c': 1, 'd': 2, 'e': 3}, 'f': 9}}
    dict_b = {'a': {'b': {'c': 1, 'd': 2, 'e': 4}, 'f': 9}}
    actual = recursive_diff(dict_a, dict_b)
    expected = ({'a': {'b': {'e': 3}}}, {'a': {'b': {'e': 4}}})
    assert actual == expected

    dict_a = {'a': {'b': {'c': 1, 'd': 2, 'e': {'f': {'h': 1, 'i': 2, 'j': 3}}}}}

# Generated at 2022-06-20 15:48:39.404197
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "vpc_id": "vpc-1234abcd",
        "tags": {
            "Environment": "prod,dev",
            "Name": "web-proxy-123"
        },
        "security_group_ids": [
            "sg-1a2b3c4d",
            "sg-5a5b5c5d"
        ]
    }
    expected = {
        "VpcId": "vpc-1234abcd",
        "Tags": {
            "Environment": "prod,dev",
            "Name": "web-proxy-123"
        },
        "SecurityGroupIds": [
            "sg-1a2b3c4d",
            "sg-5a5b5c5d"
        ]
    }
    assert snake

# Generated at 2022-06-20 15:48:49.378085
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:49:00.357512
# Unit test for function recursive_diff
def test_recursive_diff():

    # Two empty dict should be same
    assert recursive_diff({}, {}) is None

    # Dict with key not in another dict
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})

    # Dict with key not in another dict
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})

    # Simple values
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 2}, {'a': 1}) == ({'a': 2}, {'a': 1})

    # Nested dict
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 1}}) is None

# Generated at 2022-06-20 15:49:09.619619
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test for recursive_diff function"""


# Generated at 2022-06-20 15:49:20.814031
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert (dict_merge(a, b) == {'first': {'all_rows': {'pass': 'dog', 'fail': 'cat', 'number': '5'}}})


# Generated at 2022-06-20 15:49:31.627906
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'a_b': {'c_d': [1, 2]}}) == {'aB': {'cD': [1, 2]}}
    assert snake_dict_to_camel_dict({'a_b': {'c_d': [{'e_f': 1}, {'e_f': 2}]}}, capitalize_first=True) == {'AB': {'CD': [{'EF': 1}, {'EF': 2}]}}

# Generated at 2022-06-20 15:49:38.972441
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == {'first': {'all_rows': {'pass': 'dog', 'fail': 'cat', 'number': '5'}}}


# Generated at 2022-06-20 15:49:50.514712
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:49:57.365109
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.six import assertCountEqual

    # Test standard nested dictionary.
    dict1 = {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        },
        'fie': {
            'fum': {
                'foo': 'foo'
            }
        }
    }
    dict2 = {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        },
        'fie': {
            'fum': {
                'foo': 'foo'
            }
        }
    }
    assert recursive_diff(dict1, dict2) is None

    # Test simple key/value diff.

# Generated at 2022-06-20 15:50:02.920222
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'some_key': 'some_value'}
    assert(snake_dict_to_camel_dict(snake_dict) == {'SomeKey': 'some_value'})
    assert(snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == {'SomeKey': 'some_value'})



# Generated at 2022-06-20 15:50:06.085442
# Unit test for function dict_merge
def test_dict_merge():
    test_1 = {
        "key1": "value1",
        "key2": {
            "key3": "value3"
        }
    }
    test_2 = {
        "key1": "value1",
        "key2": {
            "key3": "value3",
            "key4": "value4"
        }
    }
    assert dict_merge(test_1, test_2) == test_2
    return True


# Generated at 2022-06-20 15:50:14.988829
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict_1 = {'a_b_c': 1}
    result = snake_dict_to_camel_dict(snake_dict_1)
    if result['aBC'] != 1:
        raise AssertionError("snake_dict_to_camel_dict is not working correctly.")

    snake_dict_2 = {'a': [1, 2, 3], 'b': {'c': 1, 'd': 2}}
    result = snake_dict_to_camel_dict(snake_dict_2)
    if result['b']['c'] != 1:
        raise AssertionError("snake_dict_to_camel_dict is not working correctly.")

    snake_dict_3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result

# Generated at 2022-06-20 15:50:21.801554
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_input = {'EnableSynthetics': True,
                  'Id': '51a6b8c617',
                  'Targets': [{'Id': 'i-00b7fb2c59d61a32b',
                               'Port': 80}]}

    expected_result = {'enable_synthetics': True,
                       'id': '51a6b8c617',
                       'targets': [{'id': 'i-00b7fb2c59d61a32b',
                                    'port': 80}]}

    assert camel_dict_to_snake_dict(test_input) == expected_result



# Generated at 2022-06-20 15:50:27.345602
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(alpha=dict(a=1, b=2), beta=dict(c=3, d=4))
    b = dict(alpha=dict(a=5, b=6), beta=dict(e=7))
    assert dict_merge(a, b) == dict(alpha=dict(a=5, b=6), beta=dict(c=3, d=4, e=7))



# Generated at 2022-06-20 15:50:48.550503
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # True Camel Case test
    true_camel_case_dict = { 'thisIsATest' : True }
    assert snake_dict_to_camel_dict({ 'this_is_a_test': True }) == true_camel_case_dict
    assert snake_dict_to_camel_dict({ 'this_is_a_test': True }, capitalize_first=True) == true_camel_case_dict
    # Dromedary Case test
    dromedary_case_dict = { 'this_is_a_test': True }
    assert snake_dict_to_camel_dict({ 'this_is_a_test': True }, capitalize_first=False) == dromedary_case_dict



# Generated at 2022-06-20 15:50:53.607613
# Unit test for function recursive_diff
def test_recursive_diff():

    one = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': [1, 2, 3], 'j': 'k'}
    two = {'h': [3, 1, 2], 'c': {'d': 'e', 'f': 'g'}, 'j': 'z'}
    assert recursive_diff(one, two) == ({'j': 'k'}, {'j': 'z'})

    one = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': [1, 2, 3]}
    two = {'h': [3, 1, 2], 'c': {'d': 'e', 'f': 'g'}}

# Generated at 2022-06-20 15:50:59.623503
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 'a', 'b': 'b', 'c': {'c1': 'c1', 'c2': 'c2'}, 'd': 'd'}
    d2 = {'b': 'B', 'c': {'c3': 'c3'}, 'e': 'e'}

    expected_dict = {'a': 'a', 'b': 'B', 'c': {'c1': 'c1', 'c3': 'c3', 'c2': 'c2'}, 'd': 'd', 'e': 'e'}
    assert dict_merge(d1, d2) == expected_dict



# Generated at 2022-06-20 15:51:11.978614
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test identity diff
    assert recursive_diff(dict(a=1, b=dict(c=2, d=3)), dict(a=1, b=dict(c=2, d=3))) is None

    # Test empty dict
    assert recursive_diff({}, {}) is None

    # Test diff at root level
    assert recursive_diff(dict(a=1), dict(a=1, b=2)) == ({}, dict(b=2))
    assert recursive_diff(dict(a=1, b=2), dict(a=1)) == (dict(b=2), {})

    # Test simple diff

# Generated at 2022-06-20 15:51:23.711691
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "URL": "https://myendpoint.com",
            "TimeoutSeconds": 20,
            "Authorization": {
                "BasicAuth": {
                    "Username": "Username",
                    "Password": "Password"
                }
            }
        },
        "Tags": {
            "Key1": "Value1",
            "Key2": "Value2"
        }
    }


# Generated at 2022-06-20 15:51:31.360647
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 2, 'b': 3}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': {'a': 1}}, {'a': {'a': 2}}) == ({'a': {'a': 1}}, {'a': {'a': 2}})

# Generated at 2022-06-20 15:51:42.752814
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}}
    b = {'b': {'c': 3, 'e': 5}, 'a': 2}
    expected = {'a': 2, 'b': {'c': 3, 'd': 3, 'e': 5}}
    actual = dict_merge(a, b)
    assert actual == expected
    actual = dict_merge(b, a)
    assert actual == expected
    a = {'a': 1, 'b': {'c': 2, 'd': 3}}
    b = {'b': {'c': 3, 'e': 5}, 'a': 2, 'f': 6}

# Generated at 2022-06-20 15:51:54.643201
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    SNAKE_DICT = {"foo_bar_baz": "snake"}
    CAMEL_DICT = {"fooBarBaz": "snake"}
    assert snake_dict_to_camel_dict(SNAKE_DICT) == CAMEL_DICT
    assert snake_dict_to_camel_dict(CAMEL_DICT, True) == CAMEL_DICT
    assert snake_dict_to_camel_dict(CAMEL_DICT) == CAMEL_DICT

    SNAKE_DICT = {"foo_bar_baz": {"foo_bar_baz": "snake", "foo_bar": "snake"}}
    CAMEL_DICT = {"fooBarBaz": {"fooBarBaz": "snake", "fooBar": "snake"}}
    assert snake_dict

# Generated at 2022-06-20 15:52:05.982691
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'foo': 1, 'Foo': {'bar': 2, 'Bar': {'baz': 3, 'Baz': {'BAR': 4, 'BAr': {'BAZ': 5}}}}}
    test_dict_2 = {'foo': 1, 'Foo': {'bar': 2, 'Bar': {'baz': 3, 'Baz': {'BAR': 4, 'BAr': {'BAZ': [1, {'FOO': True}]}}}}}

    # Test that the default conversion of camel case to snake case is working

# Generated at 2022-06-20 15:52:17.993438
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 1}) == {'foo_bar': 1}
    assert camel_dict_to_snake_dict({'fooBar': 1}) == {'foo_bar': 1}
    assert camel_dict_to_snake_dict({'FOOBar': 1}) == {'foo_bar': 1}
    assert camel_dict_to_snake_dict({'FoO_BAR': 1}) == {'fo_o_b_a_r': 1}
    assert camel_dict_to_snake_dict({'FoO_BAR': 1, 'FooBar': 2}) == {'foo_bar': 2, 'fo_o_b_a_r': 1}



# Generated at 2022-06-20 15:52:43.607634
# Unit test for function dict_merge
def test_dict_merge():
    # Input dictionaries
    dict1 = {'a': 'A', 'b': 'B', 'c': {'c1': 'C1', 'c2': 'C2', 'c3': 'C3'}, 'd': 'D'}
    dict2 = {'a': 'A', 'b': 'B', 'c': {'c1': 'C1', 'c3': 'C3-new'}, 'd': 'D-new'}
    dict3 = {'a': 'A', 'b': 'B', 'c': {'c1': 'C1', 'c2': 'C2-new', 'c3': 'C3', 'c4': 'C4'}, 'd': 'D'}

    # Target dictionary

# Generated at 2022-06-20 15:52:55.310094
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "AWSInstanceType": "t2.micro",
        "ImageId": "ami-0755e01b",
        "Monitoring": {
            "Enabled": False
        },
        "SubnetId": "subnet-12345678",
        "Tags": {
            "key": "value"
        }
    }

    expected_snake_dict = {
        "aws_instance_type": "t2.micro",
        "image_id": "ami-0755e01b",
        "monitoring": {
            "enabled": False
        },
        "subnet_id": "subnet-12345678",
        "tags": {
            "key": "value"
        }
    }


# Generated at 2022-06-20 15:53:07.658357
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'HTTPListenerArn': 'some_arn'}, reversible=True) == {'h_t_t_p_listener_arn': 'some_arn'}
    assert camel_dict_to_snake_dict({'HTTPListenerArn': 'some_arn'}) == {'httplistenerarn': 'some_arn'}

    assert camel_dict_to_snake_dict({'Tags': {'HTTPListenerArn': 'some_arn'}}, reversible=True) == {'tags': {'h_t_t_p_listener_arn': 'some_arn'}}

# Generated at 2022-06-20 15:53:19.331768
# Unit test for function recursive_diff
def test_recursive_diff():
    ''' Test recursive_diff on different input'''
    # Diff two identical dictionaries
    dict1 = {'key1': 'value1', 'key2': ['value2a', 'value2b']}
    dict2 = {'key1': 'value1', 'key2': ['value2a', 'value2b']}
    assert recursive_diff(dict1, dict2) is None

    # Diff two different dictionaries with different keys
    dict1 = {'key1': 'value1', 'key2': ['value2a', 'value2b']}
    dict2 = {'key3': 'value3', 'key4': ['value4a', 'value4b']}

# Generated at 2022-06-20 15:53:26.150781
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Check whether the function recursive_diff can detect all differences
    """
    # Cases with expected equal results

# Generated at 2022-06-20 15:53:30.294922
# Unit test for function dict_merge
def test_dict_merge():
    a = {'one': 1, 'two': 2, 'three': 3}
    b = {'one': 'something', 'four': 4}
    c = {'one': {'two': 'three'}, 'four': 4}
    d = {'one': {'two': 'three'}}
    e = {'one': {'two': 'three'}, 'four': 4}

    assert a == dict_merge(a, {})
    assert b == dict_merge({}, b)
    assert {'one': 'something', 'two': 2, 'three': 3, 'four': 4} == dict_merge(a, b)
    assert c == dict_merge(d, e)

# Generated at 2022-06-20 15:53:41.749167
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Unit test for snake_dict_to_camel_dict function."""

    assert snake_dict_to_camel_dict({'foo': 'FOO_BAR'}, capitalize_first=True) == {'Foo': 'FOO_BAR'}
    assert snake_dict_to_camel_dict({'foo': 'FOO_BAR'}, capitalize_first=False) == {'foo': 'FOO_BAR'}

    assert snake_dict_to_camel_dict({'foo_bar': 'FOO_BAR'}, capitalize_first=True) == {'FooBar': 'FOO_BAR'}

# Generated at 2022-06-20 15:53:52.959621
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    def deep_diff(dict1, dict2):
        return recursive_diff(dict1, dict2)

    # Testing normal scenarios

# Generated at 2022-06-20 15:54:03.868081
# Unit test for function recursive_diff
def test_recursive_diff():
    # Basic unit tests

    # Same dict
    dict1 = dict(a=0)
    dict2 = dict(a=0)
    assert recursive_diff(dict1, dict2) == None

    # Differing scalars, each key only in one dict
    dict1 = dict(a=0, b=1)
    dict2 = dict(a=1, c=1)
    assert recursive_diff(dict1, dict2) == ({'a': 0, 'b': 1}, {'a': 1, 'c': 1})

    # Same nested dict
    dict1 = dict(a=0, b=1, c=dict(d=2))
    dict2 = dict(a=0, b=1, c=dict(d=2))
    assert recursive_diff(dict1, dict2) == None

    # Same nested