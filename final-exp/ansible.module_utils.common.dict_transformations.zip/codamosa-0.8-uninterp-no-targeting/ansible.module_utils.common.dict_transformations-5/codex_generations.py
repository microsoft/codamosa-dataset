

# Generated at 2022-06-20 15:44:15.927401
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for recursive_diff()"""

    from nose.tools import assert_equal, assert_true


# Generated at 2022-06-20 15:44:24.210341
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    print(snake_dict_to_camel_dict({'key': 'value',
                                    'key_one': 'value-one',
                                    'key_two': 'value-two',
                                    'key_three': 'value-three',
                                    'key_four': 'value-four',
                                    'simple': True,
                                    'simple_int': 2,
                                    'simple_float': 3.0,
                                    'simple_string': 'abc'},
                                   capitalize_first=True))



# Generated at 2022-06-20 15:44:31.838436
# Unit test for function recursive_diff
def test_recursive_diff():
    # test the base case where two empty dictionaries are passed
    # to the function
    assert recursive_diff({}, {}) == None

    # test the base case where two simple dictionaries are
    # passed to the function
    assert recursive_diff({'x': 1}, {'x': 1}) == None

    # test the case where one of the key/value pairs being
    # compared is a dictionary
    d1 = {'x': {'y': {'z': 2}}}
    d2 = {'x': {'y': {'z': 3}}}
    d3 = {'x': {'y': {'z': 2}}}

    assert recursive_diff(d1, d2) == ({'x': {'y': {'z': 2}}}, {'x': {'y': {'z': 3}}})
    assert recursive_

# Generated at 2022-06-20 15:44:42.962323
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel_dict = {
        'Code': '404',
        'HttpEndpoint': 'https://example.com',
        'FooBar': 'Hello, world!',
        'BazTest': {
            'First': 'first',
            'Second': {
                'A': 'a',
                'B': 'b',
                'CDefG': 'cd'
            },
            'Third': [
                'a',
                'b',
                'c',
                {
                    'FooBar': 'Hello, world!'
                }
            ]
        }
    }
    snake_dict = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict))

    # Check if the dictionary is equal
    assert snake_dict == camel_dict



# Generated at 2022-06-20 15:44:49.680021
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

# Generated at 2022-06-20 15:45:01.345938
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': 1}
    dict2 = {'a': 2, 'b': {'d': 2, 'c': 1}, 'f': 3}
    assert recursive_diff(dict1, dict2) == (dict(a=1, e=1), dict(a=2, f=3))
    dict2 = dict(a=1, b=dict(c=2, d=2), e=1)
    assert recursive_diff(dict1, dict2) == (dict(b=dict(c=1)), dict(b=dict(c=2)))
    dict2 = dict(a=1, b=dict(c=2, e=1))

# Generated at 2022-06-20 15:45:03.115768
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}



# Generated at 2022-06-20 15:45:13.033405
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {u'x':1,u'y':2,u'z':3}
    b = {u'x':2,u'y':2,u'z':3}
    assert recursive_diff(a,b) == ({u'x': 1},{u'x': 2})

    a = {u'test_dict':{u'x':1,u'y':2,u'z':3}}
    b = {u'test_dict':{u'x':2,u'y':2,u'z':3}}
    assert recursive_diff(a,b) == ({u'test_dict': {u'x': 1}}, {u'test_dict': {u'x': 2}})


# Generated at 2022-06-20 15:45:24.951545
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'username' : 'joe.shmoe',
          'address' : '123 Street Street',
          'phones' : [
              '555-555-5555',
              '666-666-6666'
          ]
    }

    b = { 'username' : 'joe.schmoe',
          'address' : {
              'street' : '123 Street Street',
              'city' : 'Nowhere',
              'state' : 'WA'
          },
          'phones' : [
              '111-111-1111',
              '555-555-5555'
          ]
    }

    c = dict_merge(a, b)

    assert c['username'] == 'joe.schmoe'
    assert c['address']['street'] == '123 Street Street'

# Generated at 2022-06-20 15:45:31.616144
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': {'b': 3, 'c': 4}, 'd': 5, 'e': {'f': 6, 'g': 7}}
    dict2 = {'d': 0, 'a': {'b': 0, 'c': 1}, 'e': {'f': 8}, 'h': 9}
    dict3 = dict_merge(dict1, dict2)
    assert dict3['a']['c'] == 1
    assert dict3['d'] == 0
    assert dict3['h'] == 9
    assert dict3['a']['b'] == 0
    assert dict3['e']['g'] == 7
    assert dict3['e']['f'] == 8



# Generated at 2022-06-20 15:45:45.977252
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpointName': 'abc',
                 'HTTPEndpointDescription': 'def',
                 'Tags': {'Key': 'aws:cloudformation:logical-id',
                          'Value': {'Ref': 'HTTPEndpointLogicalID'}},
                 'VpcLinkId': {'Ref': 'VpcLink'}}

    expected = {'http_endpoint_name': 'abc',
                'http_endpoint_description': 'def',
                'tags': {'Key': 'aws:cloudformation:logical-id',
                         'Value': {'Ref': 'HTTPEndpointLogicalID'}},
                'vpc_link_id': {'Ref': 'VpcLink'}}
    snake_dict = camel_dict_to_snake_dict(test_dict, reversible=True)
   

# Generated at 2022-06-20 15:45:53.834910
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:46:03.346486
# Unit test for function dict_merge
def test_dict_merge():
    config = dict()

    config['a'] = {'a': 1, 'b': 2}
    config['b'] = {'b': [1, 2, 3], 'c': {}}

    assert config['a']['b'] == 2
    assert config['b']['b'][0] == 1
    assert isinstance(config['b']['c'], dict)

    # merge dicts that do not overlap
    config2 = dict()
    config2['b'] = {'d': 4}
    config2['c'] = {'e': 5}
    config = dict_merge(config, config2)

    assert config['b']['d'] == 4
    assert config['c']['e'] == 5

    # merge dicts that do overlap
    config2 = dict()

# Generated at 2022-06-20 15:46:14.306436
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({}, reversible=True) == {})
    assert(camel_dict_to_snake_dict({}) == {})
    assert(camel_dict_to_snake_dict({"HTTPEndpoint": 42}, reversible=True) == {"h_t_t_p_endpoint": 42})
    assert(camel_dict_to_snake_dict({"HTTPEndpoint": 42}) == {"http_endpoint": 42})

    assert(camel_dict_to_snake_dict({"TargetGroupARNs": ["foo", "bar"]}, reversible=True) == {"target_group_ar_ns": ["foo", "bar"]})

# Generated at 2022-06-20 15:46:25.762738
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:46:34.890565
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'TestString': 'camelCase',
        'TestString2': 'camelCase-again',
        'TestInt': 42,
        'testList': [
            {
                'test1': 'camelCase-list-item'
            }
        ],
        'tagList': [
            {
                'tagKey': 'TestKey',
                'tagValue': 'TestValue'
            }
        ],
        'Tags': {
            'TestKey': 'TestValue'
        },
        'targetGroups': [
            {
                'TargetGroupARN': 'target_group_arn',
                'TargetGroupName': 'target_group_name'
            }
        ]
    }


# Generated at 2022-06-20 15:46:40.433635
# Unit test for function dict_merge
def test_dict_merge():
    dict_a = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 4
        }
    }
    dict_b = {
        'a': 3,
        'b': 4,
        'c': {
            'e': 5
        }
    }
    dict_merged = dict_merge(dict_a, dict_b)
    assert dict_merged['a'] == 3
    assert dict_merged['b'] == 4
    assert dict_merged['c']['d'] == 4
    assert dict_merged['c']['e'] == 5

# Generated at 2022-06-20 15:46:50.003758
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:47:00.134307
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    string_key_camel_dict = {
        "stringKey": "stringValue",
        "nestedDict": {
            "nestedStringKey": "nestedStringValue"
        },
        "nestedList": [
            1,
            2,
            3,
            4,
            5
        ]
    }

    string_key_snake_dict = {
        "string_key": "stringValue",
        "nested_dict": {
            "nested_string_key": "nestedStringValue"
        },
        "nested_list": [
            1,
            2,
            3,
            4,
            5
        ]
    }


# Generated at 2022-06-20 15:47:10.896633
# Unit test for function recursive_diff
def test_recursive_diff():
    _test_dict1 = {
        'ec2': {
            'region': 'us-west-1',
            'security_group': {
                'name': 'ansible-sg',
                'rules': [
                    {
                        'proto': 'tcp',
                        'src': '0.0.0.0/0',
                        'port': 22
                    },
                    {
                        'proto': 'tcp',
                        'src': '0.0.0.0/0',
                        'port': 80
                    }
                ]
            }
        },
        'kms': {
            'region': 'us-west-1'
        },
        'vpc': {
            'id': 'vpc-1234'
        }
    }


# Generated at 2022-06-20 15:47:22.965485
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        'foo': {
            'bar': 1,
            'baz': 2,
            'foobar': 3
        },
        'bar': {
            'foo': 1,
            'bar': 2,
            'zip': 3
        }
    }
    dict2 = {
        'foo': {
            'bar': 1,
            'baz': 3,
            'foobarbaz': 4
        },
        'bar': {
            'foo': 1,
            'bar': 2,
            'zip': 3,
            'barzip': 4
        }
    }

# Generated at 2022-06-20 15:47:28.263964
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(
        foo=dict(
            bar=dict(baz='1', quux='2'),
            hoge=dict(piyo='3'),
        ),
    )
    b = dict(
        foo=dict(
            bar=dict(baz='4', quux='5'),
            hoge=dict(piyo='6', huga='7'),
        ),
        piyo='8',
    )
    c = dict(
        foo=dict(
            bar=dict(baz='4', quux='5'),
            hoge=dict(piyo='6', huga='7'),
        ),
        piyo='8',
    )
    d = dict_merge(a, b)
    assert d == c

# Generated at 2022-06-20 15:47:40.322604
# Unit test for function dict_merge
def test_dict_merge():
    # Simple dict
    a = dict(foo="0", bar="1", baz="2")
    b = dict(foo="3", bar="4")
    expected = dict(foo="3", bar="4", baz="2")
    actual = dict_merge(a, b)
    assert actual == expected
    # Nested dicts
    a = dict(foo="0", bar=dict(a="1", b="2", c="3"))
    b = dict(foo="3", bar=dict(a="4", b="5", z="9"))
    expected = dict(foo="3", bar=dict(a="4", b="5", c="3", z="9"))
    actual = dict_merge(a, b)
    assert actual == expected
    # Nested dicts, dups

# Generated at 2022-06-20 15:47:48.641447
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': 3, 'd': {'a': 1}, 'e': {'a': 1, 'b': 2}}
    dict2 = {'a': 1, 'b': 2, 'c': 4, 'd': {'a': 1}, 'e': {'a': 1, 'b': 2}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'c': 3}, {'c': 4})
    dict3 = {'a': 1, 'b': 2, 'c': 3, 'd': {'a': 1}, 'e': {'a': 1, 'b': 3}}
    result = recursive_diff(dict1, dict3)

# Generated at 2022-06-20 15:47:57.301458
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'snake_case': 'value'}) == {'snakeCase': 'value'}
    assert snake_dict_to_camel_dict({'snake_case': {'inner_dict': 'value'}}) == {'snakeCase': {'innerDict': 'value'}}
    assert snake_dict_to_camel_dict({'snake_case': [{'inner_list': 'value'}]}) == {'snakeCase': [{'innerList': 'value'}]}
    assert snake_dict_to_camel_dict({'snake_case': ['value']}) == {'snakeCase': ['value']}

# Generated at 2022-06-20 15:48:06.287084
# Unit test for function recursive_diff
def test_recursive_diff():
    a_test = {
        'test': {
            'test1': {
                'test2': 'test3'
            },
            'test4': 'test5'
        },
        'test6': 'test7',
        'test8': 'test9'
    }
    b_test = {
        'test': {
            'test1': {
                'test2': 'test3'
            },
            'test10': 'test11'
        },
        'test6': 'test7',
        'test8': 'test9',
    }

# Generated at 2022-06-20 15:48:17.308773
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test case 1:
    diff_dict1 = {'key1': 'value1', 'key2': {'key2.1': 'value2.1', 'key2.2': 'value2.2'}, 'key3': 'value3'}
    diff_dict2 = {'key1': 'value1', 'key2': {'key2.1': 'value2.1', 'key2.2': 'value2.2'}}

    result = recursive_diff(diff_dict1, diff_dict2)
    assert result == ({'key3': 'value3'}, {})

    # Test case 2:

# Generated at 2022-06-20 15:48:25.581523
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {
            'HTTPHeader': ('HTTPHeaderValue'),
            'Matcher': {'HttpCode': '200'},
            'PathPattern': 'PathPatternValue'
        },
        reversible=True
    ) == {
            'h_t_t_p_header': 'HTTPHeaderValue',
            'matcher': {'http_code': '200'},
            'path_pattern': 'PathPatternValue'
        }


# Generated at 2022-06-20 15:48:33.673743
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Functional tests for camel_dict_to_snake_dict.
    """

# Generated at 2022-06-20 15:48:38.378037
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(dict(foo_bar='baz', list_value=['item1', 'item2'])) == dict(fooBar='baz', listValue=['item1', 'item2'])



# Generated at 2022-06-20 15:48:44.908867
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    camel_dict = {'SnapshotWindow': '05:00-09:00',
                  'AvailabilityZones': ['us-east-1a',
                                        'us-east-1b'],
                  'DBInstanceIdentifier': 'mydbinstance',
                  'Engine': 'oracle-ee',
                  'DBInstanceClass': 'db.m1.small',
                  'PubliclyAccessible': False}

    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict)) == camel_dict



# Generated at 2022-06-20 15:48:52.957398
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit test for function recursive_diff """
    dict_a = {'health_check': {'interval': 20, 'healthy_threshold': 3, 'timeout': 5, 'unhealthy_threshold': 5, 'target': 'HTTP:8000/'},
              'target_group_attributes': [{'key': 'stickiness.enabled', 'value': 'false'}],
              'tags': [{'key': 'foo', 'value': 'bar'}, {'key': 'bar', 'value': 'foo'}]}


# Generated at 2022-06-20 15:49:03.131912
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {
            "ApplicationName": "application_name",
            "HTTPEndpoint": "http_endpoint"
        }
    ) == {
        "application_name": "application_name",
        'http_endpoint': "http_endpoint"
    }
    assert camel_dict_to_snake_dict(
        {
            "TargetGroupARNs": ["target_group_arns"],
            "HTTPEndpoint": "http_endpoint"
        }
    ) == {
        "target_group_arns": ["target_group_arns"],
        'http_endpoint': "http_endpoint"
    }

# Generated at 2022-06-20 15:49:13.977679
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'Tags': {'key': 'value'}, 'InstanceType': 'm4.large', 'SourceDestCheck': False} == snake_dict_to_camel_dict({'tags': {'key': 'value'}, 'instance_type': 'm4.large', 'source_dest_check': False})

# Generated at 2022-06-20 15:49:25.162153
# Unit test for function recursive_diff

# Generated at 2022-06-20 15:49:31.874050
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'snake_key': 'snake_value',
        'nested_dict': {
            'nested_key': 'nested_value'
        }
    }
    expected_camel_dict = {
        'snakeKey': 'snake_value',
        'nestedDict': {
            'nestedKey': 'nested_value'
        }
    }

    assert snake_dict_to_camel_dict(snake_dict) == expected_camel_dict



# Generated at 2022-06-20 15:49:43.233645
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({'a': 1}, {'a': 1}) == None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, {})
    assert recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == ({}, {'b': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 2, 'c': 3}) == ({}, {'c': 3})

# Generated at 2022-06-20 15:49:47.942026
# Unit test for function dict_merge
def test_dict_merge():
    # dict_merge test for simple dicts
    dict_a = {'key_a': 1}
    dict_b = {'key_b': 2}
    assert dict_merge(dict_a, dict_b) == dict_a.copy()
    dict_a.update(dict_b)
    assert dict_merge(dict_a, dict_b) == dict_a
    dict_c = {'key_c': 3}
    dict_a.update(dict_c)
    dict_d = {'key_d': 4}
    dict_e = {'key_e': 5}
    dict_a.update(dict_d)
    dict_a.update(dict_e)
    assert dict_merge(dict_a, dict_d) == dict_a
    assert dict_merge

# Generated at 2022-06-20 15:49:57.746010
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "Tags": {
            "Key": "value"
        },
        "HTTPEndpoint": {
            "URL": "http://www.example.com/",
        },
        "OutputArtifacts": [
            { "Name": "test", "Value": "test" }
        ]
    }
    expected_snake_dict = {
        "tags": {
            "Key": "value"
        },
        "h_t_t_p_endpoint": {
            "url": "http://www.example.com/",
        },
        "output_artifacts": [
            { "name": "test", "value": "test" }
        ]
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict, True)
    assert snake_dict

# Generated at 2022-06-20 15:50:04.394245
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'a', 'b': {'x': 'x', 'y': 'y'}}
    b = {'b': {'y': 'yy', 'z': 'z'}, 'c': 'c'}
    assert dict_merge(a, b) == {'a': 'a', 'b': {'x': 'x', 'y': 'yy', 'z': 'z'}, 'c': 'c'}

# Generated at 2022-06-20 15:50:18.208129
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit test for function recursive_diff """
    inputs = [
        ({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}},
         {'a': 1, 'b': 3, 'f': 5, 'c': {'d': 3, 'e': 5}}),
        ({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'g': 6},
         {'a': 1, 'b': 3, 'f': 5, 'c': {'d': 3, 'e': 5}})]
    results = [({'b': 2}, {'b': 3}),
               ({'b': 2, 'g': 6}, {'b': 3, 'f': 5})]

# Generated at 2022-06-20 15:50:22.751487
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(dict(one_value=dict(two_value=dict(three_value=dict(four_value=dict(five_value="snake")))))) == \
    {'oneValue': {'twoValue': {'threeValue': {'fourValue': {'fiveValue': 'snake'}}}}}



# Generated at 2022-06-20 15:50:32.128013
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {"HTTPEndpoint": "www.cloud-automation.com", "IP": "127.0.0.1"}
    snake_dict = {"http_endpoint": "www.cloud-automation.com", "ip": "127.0.0.1"}
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)

    camel_dict = {'aBcDeF': 'gHiJkLmNoPq', 'TargetGroupArns': ['arn:aws:elasticloadbalancing:us-west-2:123456789:targetgroup/example1',
                                                                'arn:aws:elasticloadbalancing:us-west-2:123456789:targetgroup/example2']}

# Generated at 2022-06-20 15:50:43.572677
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "list_second_elem": [
            {
                "list_top_elem": [
                    "list_top_elem"
                ]
            }
        ],
        "list_top_elem": [
            "list_top_elem"
        ]
    }
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {
        "listSecondElem": [
            {
                "listTopElem": [
                    "list_top_elem"
                ]
            }
        ],
        "listTopElem": [
            "list_top_elem"
        ]
    }

    # Check behaviour of list of different types

# Generated at 2022-06-20 15:50:55.237079
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"list_member_1" : "list_member",
        "key" : "value",
        "dict_member" : {
            "dict_member_1" : "dict_member_value"
        },
        "list_1" : [
            {
                "list_1_item_1" : "list_item_value",
                "list_item_2" : {
                    "list_item_2_1" : "list_item_2_value"
                }
            }
        ]
}


# Generated at 2022-06-20 15:51:07.324864
# Unit test for function recursive_diff
def test_recursive_diff():
    """Recursive diff test"""
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 'b'}, {}) == ({'a': 'b'}, {})
    assert recursive_diff({}, {'a': 'b'}) == ({}, {'a': 'b'})
    assert recursive_diff({'a': 'b'}, {'a': 'b'}) is None
    assert recursive_diff({'a': 'b'}, {'a': 'c'}) == ({'a': 'b'}, {'a': 'c'})
    assert recursive_diff({'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'e'}) == ({'c': 'd'}, {'c': 'e'})

# Generated at 2022-06-20 15:51:17.342448
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'test': {
            'testCase': 1,
            'testCase1': {
                'testCase2': 1,
            },
        },
    }

    expected_snake_dict = {
        'test': {
            'test_case': 1,
            'test_case1': {
                'test_case2': 1,
            },
        },
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict, 'camel_dict_to_snake_dict did not return the correct result'


# Generated at 2022-06-20 15:51:27.318546
# Unit test for function recursive_diff
def test_recursive_diff():
    import yaml


# Generated at 2022-06-20 15:51:38.554576
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {'test_dict1': {'test_dict1_1': "abc", 'test_dict1_2': "def"},
                 'test_dict2': {'test_dict2_1': "ghi", 'test_dict2_2': "jkl"}}
    test_dict_camel = {'TestDict1': {'TestDict1_1': "abc", 'TestDict1_2': "def"},
                       'TestDict2': {'TestDict2_1': "ghi", 'TestDict2_2': "jkl"}}

# Generated at 2022-06-20 15:51:45.100267
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': '1', 'b': '2'}
    dict2 = {'b': '3'}
    expected = {'a': '1', 'b': '3'}
    assert dict_merge(dict1, dict2) == expected

    dict1 = {'a': {'b': '1', 'c': '3'}, 'b': '2'}
    dict2 = {'a': {'b': '2'}}
    expected = {'a': {'b': '2', 'c': '3'}, 'b': '2'}
    assert dict_merge(dict1, dict2) == expected

# Generated at 2022-06-20 15:51:56.473605
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "foo_bar": 1,
        "foo_bar_baz": {
            "foo": {
                "bar": {
                    "foo_bar": 1
                },
                "foo_bar": 1
            }
        },
        "foo_bar_baz_list": [
            1,
            2,
            {
                "foo": {
                    "bar": {
                        "foo_bar": 1
                    },
                    "foo_bar": 1
                }
            }
        ]
    }
    result = snake_dict_to_camel_dict(test_dict)
    assert result['fooBar'] == 1
    assert result['fooBarBaz']['foo']['bar']['foo_bar'] == 1

# Generated at 2022-06-20 15:52:07.581502
# Unit test for function recursive_diff
def test_recursive_diff():
    def check(got, expected):
        if got != expected:
            raise AssertionError("Got {}, expected {}".format(got, expected))

    # Example 1
    boto = {'a': 1, 'b': 2}
    ansible = {'b': 2, 'a': 3}
    check(recursive_diff(boto, ansible), ({'a': 1}, {'a': 3}))

    # Example 2
    boto = {'a': 1, 'b': {'c': 2, 'd': 3}}
    ansible = {'a': 3, 'b': {'c': 2, 'd': 4}}
    check(recursive_diff(boto, ansible), ({'a': 1}, {'a': 3, 'b': {'d': 4}}))

    # Example 3
   

# Generated at 2022-06-20 15:52:19.822590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    base = {
        "Name": "myself",
        "LoginProfile": {
            "Password": "my_password",
            "PasswordResetRequired": True
        },
        "Groups": [
            {"GroupName": "admin"},
            "GroupList"
        ],
        "Tags": [
            {"Key": "Key1", "Value": "Value1"},
            {"Key": "Key2", "Value": "Value2"}
        ],
        "ManagedPolicyArns": ["arn:aws:iam::aws:policy/AdministratorAccess"]
    }
    with_type = base.copy()
    with_type["LoginProfile"]["CreateDate"] = "2018-01-01T00:00:00Z"


# Generated at 2022-06-20 15:52:30.658354
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """ test_camel_dict_to_snake_dict """

    # Simple conversion
    camel_dict = {"TestKey": "Value1", "AnotherKey": "Value2"}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=False)
    assert snake_dict == {"test_key": "Value1", "another_key": "Value2"}

    # Reversible conversion
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)
    assert snake_dict == {"test_key": "Value1", "another_key": "Value2"}

    # Conversion with nested lists
    camel_dict = {"TestKey": "Value1", "AnotherKey": "Value2", "ListKey": [3, {"AnotherKey": "Value3"}]}
    snake

# Generated at 2022-06-20 15:52:37.699262
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'x': {'a': 1, 'b': 2}, 'y': 2, 'foo': ['bar', 'baz'], 'alpha': {'beta': {'gama': 1, 'delta': 2}}}
    d2 = {'x': {'b': 5, 'c': 6}, 'y': 8, 'foo': ['test'], 'alpha': {'beta': {'gama': -1}}}
    result = {'alpha': {'beta': {'delta': 2, 'gama': -1}},
              'foo': ['bar', 'baz', 'test'],
              'x': {'a': 1, 'b': 5, 'c': 6},
              'y': 8}

# Generated at 2022-06-20 15:52:49.613631
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive dictionary diff function

    :raise AssertionError: When the function does not return the expected result.
    """

    def check_function(dict1, dict2, result):
        """Check that the function returns the expected results.

        :arg dict1: First dictionary.
        :arg dict2: Second dictionary.
        :arg result: Expected result or ``None`` if no results are expected.
        :raise AssertionError: When the function returns different results than the expected result.
        """
        function_result = recursive_diff(dict1, dict2)
        assert function_result == result, "dict1 %s and dict2 %s returned %s, expected %s" % (dict1, dict2, function_result, result)


# Generated at 2022-06-20 15:52:58.733012
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def test_with_type(complex_type, expected_type):
        assert complex_type is not None
        assert type(complex_type) == type(expected_type)

    # Test int and string
    test_object = {'TestInteger': 1, 'TestString': 'Hello'}
    result = camel_dict_to_snake_dict(test_object)
    assert result == {'test_integer': 1, 'test_string': 'Hello'}
    test_with_type(result, test_object)

    # Test array
    test_object = {'TestInteger': 1, 'TestString': 'Hello', 'TestArray': [1, 2, 3]}
    result = camel_dict_to_snake_dict(test_object)

# Generated at 2022-06-20 15:53:09.941058
# Unit test for function recursive_diff
def test_recursive_diff():

    def assert_expected_result(left, right, expected_result):
        """
        Utility function to make test code more readable.
        """
        assert recursive_diff(left, right) == expected_result

    left = {
        'name': 'test',
        'description': 'description',
        'tags': {
            'key': 'value'
        }
    }
    right = {
        'name': 'test',
        'description': 'description',
        'tags': {
            'key': 'value'
        }
    }
    assert_expected_result(left, right, None)

    left['tags']['key2'] = 'value2'
    right['tags']['key2'] = 'value2'
    assert_expected_result(left, right, None)


# Generated at 2022-06-20 15:53:20.618262
# Unit test for function dict_merge
def test_dict_merge():
    a = {'first': 'A', 'second': 'B', 'third': {'a': '1', 'b': '2', 'c': {'x': 5, 'y': 10}}}
    b = {'first': 'X', 'second': 'Y', 'third': {'a': '3', 'b': '4', 'd': {'x': 6, 'y': 20}}}
    c = {'first': 'X', 'second': 'Y', 'third': {'a': '3', 'b': '4', 'c': {'x': 5, 'y': 10}, 'd': {'x': 6, 'y': 20}}}
    assert dict_merge(a, b) == c


# Generated at 2022-06-20 15:53:31.864380
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {'foo_bar': 'baz', 'array_of_foo_bars': [{'foo_bar': 'baz'}]}
    snake_dict_with_camel_ignore = {'foo_bar': 'baz', 'array_of_foo_bars': [{'foo_bar': 'baz'}], 'tags': {'foo': 'bar'}}

    assert snake_dict_to_camel_dict(snake_dict) == {'fooBar': 'baz', 'arrayOfFooBars': [{'fooBar': 'baz'}]}

# Generated at 2022-06-20 15:53:44.865855
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_input1 = {'tags': [
        {'name': 'key1', 'value': 'value1'},
        {'name': 'key2', 'value': 'value2'}
    ]}
    test_expected_output1 = {'tags': [
        {'name': 'key1', 'value': 'value1'},
        {'name': 'key2', 'value': 'value2'}
    ]}
    assert camel_dict_to_snake_dict(test_input1) == test_expected_output1

    test_input2 = {'tags': [
        {'name': 'key1', 'value': 'value1'},
        {'HTTPEndpoint': 'key2', 'value': 'value2'}
    ]}

# Generated at 2022-06-20 15:53:54.600261
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    import json

    snake_dict = {
        'tags': [{'key': 'Name'}],
        'dns_config': {
            'name': 'Name',
            'failover_policy': 'PRIMARY_ONLY'
        }
    }

    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict['Tags'][0]['key'] == 'Name'
    assert camel_dict['DnsConfig']['name'] == 'Name'
    assert camel_dict['DnsConfig']['failoverPolicy'] == 'PRIMARY_ONLY'

    snake_dict_alt = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict_alt == snake_dict


# Generated at 2022-06-20 15:54:04.299463
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': 1}}
    dict2 = {'a': {'b': 2}}
    dict3 = {'a': {'b': 1}}
    dict4 = {}
    dict5 = {'a': {'b': {'c': 1}}}
    dict6 = {'a': {'b': {'c': 2}}}
    dict7 = {'a': {'b': {'c': 2, 'd': 3}}}
    assert recursive_diff(dict1, dict2) == ({'a': {'b': 1}}, {'a': {'b': 2}})
    assert recursive_diff(dict1, dict3) is None
    assert recursive_diff(dict1, dict4) == ({'a': {'b': 1}}, {})