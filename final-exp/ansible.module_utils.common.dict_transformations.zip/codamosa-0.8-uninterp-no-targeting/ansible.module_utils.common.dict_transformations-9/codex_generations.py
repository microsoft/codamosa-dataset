

# Generated at 2022-06-20 15:44:10.120627
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    return True


# Generated at 2022-06-20 15:44:21.960549
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Check that the function properly transforms a camel
    case dict to a snake case dict
    """
    import textwrap
    camel_dict = {
        "subnetIds": ['subnet-1234abcd', "subnet-4567efgh"],
        "subnetIps": {
            "subnetIp": "192.0.2.0",
            "subnetMask": "255.255.255.0"
        },
        "subnetId": "subnet-abcd1234",
        "subnet_id": "subnet-1234abcd",
        "subnet_IP": "192.0.2.0",
        "subnetIP": "192.0.2.0"
    }


# Generated at 2022-06-20 15:44:29.605363
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        'x': 1,
        'y': 2,
        'z': {
            'a': 1,
            'b': 2
        }
    }
    b = {
        'x': 99,
        'y': 99,
        'z': {
            'a': 99,
            'c': 3
        }
    }

    result = dict_merge(a, b)
    assert result == {
        'x': 99,
        'y': 99,
        'z': {
            'a': 99,
            'b': 2,
            'c': 3
        }
    }



# Generated at 2022-06-20 15:44:40.831140
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-20 15:44:44.722877
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = dict(
        some_key=dict(
            some_other_key=dict(
                some_other_deeper_key='some value',
                some_list=['value1', 'value2'],
            )
        )
    )

# Generated at 2022-06-20 15:44:48.324827
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import pprint
    data = json.load(open('/tmp/test.json'))
    pprint.pprint(data)
    pprint.pprint(camel_dict_to_snake_dict(data))

# Generated at 2022-06-20 15:45:00.396878
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    testcase_one = {'key_one': 'value_one',
                    'key_two': 'value_two',
                    'key_three': ['value_one', 'value_two'],
                    'key_four': {'key_one': {'key_one': 'value_one'}},
                    'key_five': None,
                    'key_six': True,
                    'key_seven': 1,
                    'key_eight': '1'
                    }

# Generated at 2022-06-20 15:45:10.503080
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    assert recursive_diff({'key': []}, {}) == ({'key': []}, {})
    assert recursive_diff({}, {'key': []}) == ({}, {'key': []})
    assert recursive_diff({'key': []}, {'key': []}) == None
    assert recursive_diff({'key': []}, {'key': [1]}) == ({'key': []}, {'key': [1]})
    assert recursive_diff({'key': [1]}, {'key': [1]}) == None
    assert recursive_diff({'key': [1]}, {'key': []}) == ({'key': [1]}, {'key': []})

# Generated at 2022-06-20 15:45:21.544398
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'status': '1',
        'HTTPEndpoint': {
            'HTTPPort': 1,
            'HTTPSPort': 2,
        },
        'tlsCertificateSummaries': [{
            'certificateName': 'a',
            'inUseCount': 1,
            'status': 'ok'
        }, {
            'certificateName': 'b',
            'inUseCount': 0,
            'status': 'ok'
        }]
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['status'] == '1'
    assert snake_dict['http_endpoint']['http_port'] == 1
    assert snake_dict['http_endpoint']['https_port'] == 2
    assert snake

# Generated at 2022-06-20 15:45:31.418460
# Unit test for function dict_merge
def test_dict_merge():
    a = {'simple_key': 'value1'}
    b = {'simple_key': 'value2'}
    assert {'simple_key': 'value2'} == dict_merge(a, b)

    a = {'simple_key': 'value1', 'dict1_key': {'dict1_key1': 'value1', 'dict1_key2': 'value2'}}
    b = {'simple_key': 'value2', 'dict1_key': {'dict1_key1': 'value3'}}
    assert {'simple_key': 'value2',
            'dict1_key': {'dict1_key1': 'value3', 'dict1_key2': 'value2'}} == dict_merge(a, b)


# Generated at 2022-06-20 15:45:47.019476
# Unit test for function dict_merge
def test_dict_merge():

    a = {'key1': {'key2': 'value1',
                  'key3': 'value2',
                  'key4': {'key5': 'value3'}}}

    b = {'key1': {'key2': 'value1',
                  'key3': 'value5',
                  'key6': 'value6'},
         'key7': 'value7'}

    expected_merge = {'key1': {'key2': 'value1',
                               'key3': 'value5',
                               'key4': {'key5': 'value3'},
                               'key6': 'value6'},
                      'key7': 'value7'}

    print("Merged output: ", dict_merge(a, b))
    assert dict_merge(a, b) == expected_mer

# Generated at 2022-06-20 15:45:52.338396
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'SomeKey': 'some_value', 'SomeOtherKey': 'some_other_value', 'SomeList': ['some_value', 'some_other_value']}
    snake_dict = camel_dict_to_snake_dict(camel_dict, True)
    assert snake_dict == {'some_key': 'some_value', 'some_other_key': 'some_other_value', 'some_list': ['some_value', 'some_other_value']}



# Generated at 2022-06-20 15:46:02.237878
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test function 'recursive_diff'
    """

    from ansible.module_utils.common._collections_compat import UserDict, MutableMapping
    class TestDict(UserDict):
        def __init__(self, initialdata=None):
            super(TestDict, self).__init__(initialdata)
            self.update(initialdata)

        def __getitem__(self, key):
            if isinstance(key, MutableMapping):
                raise TypeError("Unable to diff 'dict1' %s and 'dict2' %s. "
                    "Both must be a dictionary." % (type(key), type(self)))
            return self.data[key]

    # Create two dictionaries to compare.

# Generated at 2022-06-20 15:46:12.693307
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 3,
        'd': {
            'e': 1,
            'f': 2
        },
        'g': {
            'h': {
                'i': 1
            }
        }
    }

    dict2 = {
        'a': 1,
        'c': 2,
        'd': {
            'e': 1,
            'f': 3
        },
        'g': {
            'h': {
                'i': 1
            }
        }
    }

    result = recursive_diff(dict1, dict2)
    assert result == ({'b': 3}, {'c': 2, 'd': {'f': 3}})

# Generated at 2022-06-20 15:46:19.709238
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'tag': "tag",
        'tags': [{"key":"value"}, {"Key":"value"}],
        'bucketName': "aBucket",
        'configuration': {'id': 1, 'Name': 'configuration'},
        'HTTPEndpoint': {'Tags': [1, 2, 3], 'Name': 'aName'},
        'targetGroupARNs': ["targetGroupARN1", "targetGroupARN2"],
        'targetGroups': ["targetGroup1", "targetGroup2"],
        'targetGroupARN': "targetGroupARN"
    }


# Generated at 2022-06-20 15:46:29.222584
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None

    assert recursive_diff({1: 2}, {}) == ({1: 2}, {})
    assert recursive_diff({}, {1: 2}) == ({1: 2}, {})

    assert recursive_diff({1: 2}, {1: 3}) == ({1: 2}, {1: 3})

    assert recursive_diff({1: 2, 3: 4}, {1: 3, 3: 3}) == ({1: 2}, {1: 3})
    assert recursive_diff({1: 2, 3: 4}, {1: 2, 3: 4}) is None
    assert recursive_diff({1: 2, 3: 4}, {1: 3, 3: 4}) == ({1: 2}, {1: 3})

    # Test nested dicts

# Generated at 2022-06-20 15:46:37.377465
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_val = {
        "HTTPEndpoint": {
            "ContainerArn": "arn:aws:batch:us-east-1:000000000000:job-queue/job-queue-1",
            "HTTPPath": "",
            "HTTPMethod": "GET"
        },
        "Tags": {
            "Key" : "value"
        }
    }
    result = camel_dict_to_snake_dict(test_val)
    assert 'http_endpoint' in result
    assert 'h_t_t_p_endpoint' not in result
    assert 'tags' in result
    assert 'key' in result['tags']
    assert 'Key' not in result['tags']
    assert snake_dict_to_camel_dict(result) == test_val


# Generated at 2022-06-20 15:46:43.611155
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}
    assert(c == dict_merge(a, b))

# Generated at 2022-06-20 15:46:48.169858
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'a_b_c': 123, 'd_e_f': {'g_h_i': 456, 'j_k_l': [789, 101112]}}) == \
           {'aBC': 123, 'dEF': {'gHI': 456, 'jKL': [789, 101112]}}


# Generated at 2022-06-20 15:46:53.599842
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test = {
        "HTTPEndpoint": "http://www.example.com",
        "Name": "my.example.com",
        "Location": "East",
        "Tags": {
            "Department": "CloudOps",
        }
    }
    result = {
        "http_endpoint": "http://www.example.com",
        "name": "my.example.com",
        "location": "East",
        "tags": {
            "Department": "CloudOps",
        }
    }
    assert camel_dict_to_snake_dict(test) == result


# Generated at 2022-06-20 15:47:04.457059
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Test simple snake dict, convert to camel dict.
    snake_dict = {'key1': 'value1', 'key2': 'value2'}
    camel_dict = {'key1': 'value1', 'key2': 'value2'}
    camel_dict_returned = snake_dict_to_camel_dict(snake_dict)
    # Assert values match expected
    assert camel_dict == camel_dict_returned

    # Test simple snake dict, convert to camel dict, capitalize first letter.
    snake_dict = {'key1': 'value1', 'key2': 'value2'}
    camel_dict = {'Key1': 'value1', 'Key2': 'value2'}

# Generated at 2022-06-20 15:47:16.386999
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'key_1': 'value', 'key_2': {'key_3': 3, 'key_4': [1, 2, 3, 4]}, 'key_5': [{'key_6': 6}, {'key_7': 7}]}) == {'key1': 'value', 'key2': {'key3': 3, 'key4': [1, 2, 3, 4]}, 'key5': [{'key6': 6}, {'key7': 7}]}

# Generated at 2022-06-20 15:47:24.020802
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1}, 'c': 2}
    d2 = {'a': {'b': 3, 'c': 4}, 'd': 5}
    d3 = dict_merge(d1, d2)
    assert 'a' in d3
    assert 'b' in d3['a']
    assert 'c' in d3['a']
    assert d3['a']['b'] == 3
    assert d3['a']['c'] == 4
    assert 'c' in d3
    assert d3['c'] == 2
    assert 'd' in d3
    assert d3['d'] == 5



# Generated at 2022-06-20 15:47:36.015549
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for recursive_diff()"""
    dict1 = dict(a=1, b=2, c=dict(d=3, e=dict(f=4)))
    dict2 = dict(a=1, b=2, c=dict(d=3, e=dict(f=4)))
    result = recursive_diff(dict1, dict2)
    assert(result is None)

    dict1 = dict(a=1, b=2, c=dict(d=3, e=dict(f=4)))
    dict2 = dict(a=2, b=3, c=dict(d=4, e=dict(f=5)))
    dict1_expected, dict2_expected = dict(a=1), dict(a=2)
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-20 15:47:46.412967
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=dict(a='a', b='b', c='c'), b='b')
    dict2 = dict(a=dict(a='a', b='b', d='d'), b='b')
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': {'c': 'c'}}, {'a': {'d': 'd'}})

    dict1 = dict(a=dict(a='a', b='b', c='c'), b='b')
    dict2 = dict(a=dict(a='a', b='b', c='C'), b='b')
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': {'c': 'c'}}, {'a': {'c': 'C'}})

   

# Generated at 2022-06-20 15:47:55.875734
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {"key1": 1,
                  "key_2": 2,
                  "Key_3": 3,
                  "a_complex_key_4": [4, 5, 6],
                  "a_list_of_dicts": [
                      {
                          "key1": 1,
                          "key_2": 2,
                      },
                      {
                          "key1": 3,
                          "key_2": 4
                      }
                  ],
                  "tags": {
                      "Key": "Value"
                  }
                  }
    camel_dict = snake_dict_to_camel_dict(snake_dict)

# Generated at 2022-06-20 15:48:02.194930
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'aaa', 'b': 'bbb'}
    b = {'b': 'ccc', 'd': 'ddd'}
    ab = dict_merge(a, b)
    assert ab == {'a': 'aaa', 'b': 'ccc', 'd': 'ddd'}
    abb = dict_merge(ab, b)
    assert abb == {'a': 'aaa', 'b': 'ccc', 'd': 'ddd'}

# Generated at 2022-06-20 15:48:09.332401
# Unit test for function dict_merge
def test_dict_merge():
    # Default usage
    a = {'a': 1}
    b = {'b': 2}
    expected = {'a': 1, 'b': 2}
    assert dict_merge(a, b) == expected

    # Nested dicts
    a = {'a': {'b': 1}}
    b = {'a': {'c': 2}}
    expected = {'a': {'b': 1, 'c': 2}}
    assert dict_merge(a, b) == expected

    # Overwrite with dict
    a = {'a': 1}
    b = {'a': {'b': 2}}
    expected = {'a': {'b': 2}}
    assert dict_merge(a, b) == expected



# Generated at 2022-06-20 15:48:12.121104
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {'A': {'B': 1, 'C': 2}, 'D': 3, 'E': [{'F': 4}, {'G': 5}, 6]}
    snake = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': [{'f': 4}, {'g': 5}, 6]}
    assert camel_dict_to_snake_dict(camel) == snake



# Generated at 2022-06-20 15:48:22.085375
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 3, 'd': 4, 'e': None, 'f': [{'foo': 1}, {'bar': 2}]}}
    dict2 = {'a': 1, 'b': {'c': 3, 'd': 4, 'e': None, 'f': [{'foo': 1}, {'bar': 2}]}}
    assert recursive_diff(dict1, dict2) is None

    dict2['a'] = 2
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': 1}, {'a': 2})
    dict1['a'] = 2
    result = recursive_diff(dict1, dict2)
    assert result is None

    dict2['b']['c'] = 31
    result = recursive_diff

# Generated at 2022-06-20 15:48:33.178265
# Unit test for function dict_merge
def test_dict_merge():
    '''
    basic dicts
    '''
    a = {'foo': {'bar': {'spam': 'yo'}}}
    b = {'foo': {'bar': {'spam': 'nope'}}}
    result = dict_merge(a, b)
    assert result['foo']['bar']['spam'] == 'nope'
    assert result['foo']['bar'] != a['foo']['bar']

    '''
    lists of dicts
    '''
    c = {'foo': {'bar': [{'spam': 'yo'}]}}
    d = {'foo': {'bar': [{'spam': 'nope'}]}}
    result = dict_merge(c, d)

# Generated at 2022-06-20 15:48:44.748729
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_to_test = {
        'HTTPEndpoint': {
            'EndpointUri': 'https://example.com',
            'Protocol': 'HTTPS',
            'Method': 'PUT',
            'TimeoutInMillis': 5000,
            'Auth': {
                'Type': 'AWS_IAM'
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{}',
            'BodyFrom': '',
            'DisableUriEscaping': False
        }
    }


# Generated at 2022-06-20 15:48:52.873447
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'KeyName': 'key',
        'InstanceType': 'm3.medium',
        'Tags': {
            'Name': 'test'
        },
        'BlockDeviceMappings': [
            {
                'DeviceName': '/dev/xvda',
                'Ebs': {
                    'VolumeSize': 8,
                    'VolumeType': 'gp2',
                    'DeleteOnTermination': True
                }
            }
        ],
        'NetworkInterfaces': [
            {
                'DeviceIndex': 0,
                'AssociatePublicIpAddress': True,
                'SubnetId': 'subnet-00000000',
                'Groups': ['sg-00000000']
            }
        ]
    }

    snake_dict = camel_dict_to_snake_dict(test_dict)
   

# Generated at 2022-06-20 15:49:03.082072
# Unit test for function recursive_diff
def test_recursive_diff():
    list1 = [1, 2, 3, 4]
    list2 = [1, 2, 3, 4]
    dict1 = dict(top1=dict(key1="value1", key2="value2"), top2="a value")
    dict2 = dict(top1=dict(key1="value1", key2="value2"), top2="a value")
    dict3 = dict(top1=dict(key1="value1", key2="value2", key3="value3"), top2="a value")
    dict4 = dict(top1=dict(key1="value2", key2="value1", key3="value3"), top2="a value")

    assert recursive_diff(dict4, dict4) == None
    assert recursive_diff(dict1, dict2) == None

# Generated at 2022-06-20 15:49:13.935899
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': 'b'}, dict()) == {'a': 'b'}
    assert dict_merge({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert dict_merge({'a': 'b'}, {'a': 'd'}) == {'a': 'd'}
    assert dict_merge({'a': 'b'}, {'a': {'e': 'f'}}) == {'a': {'e': 'f'}}
    assert dict_merge({'a': {'e': 'f'}}, {'a': {'e': 'g'}}) == {'a': {'e': 'g'}}

    assert dict

# Generated at 2022-06-20 15:49:20.849581
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:49:24.975279
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({}, {'A': 'a'}) == {'A': 'a'}
    assert dict_merge({'A': 'a'}, {}) == {'A': 'a'}
    assert dict_merge({'A': 'a'}, {'b': 'b'}) == {'A': 'a', 'b': 'b'}
    assert dict_merge({'A': 'a'}, {'A': 'b'}) == {'A': 'b'}
    assert dict_merge({'A': 'a'}, {'A': 'b', 'B': 'b'}) == {'A': 'b', 'B': 'b'}

# Generated at 2022-06-20 15:49:33.000496
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'DatabaseName': 'name',
        'Tags': {
            'Key': 'foo',
            'Value': 'bar'
        },
        'Parameters': {
            'name': 'value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict, ignore_list=['Parameters', 'Tags'])
    assert snake_dict.get('database_name') == 'name'
    assert snake_dict.get('tags') is CamelDict({'Key': 'foo', 'Value': 'bar'})
    assert snake_dict.get('parameters') is CamelDict({'name': 'value'})



# Generated at 2022-06-20 15:49:44.309171
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def test_deep_equality(dict_1, dict_2):
        return False if camel_dict_to_snake_dict(dict_1) != camel_dict_to_snake_dict(dict_2) else True

    result = test_deep_equality(
        {'HTTPEndpoint': {'URL': 'www.endpoint.com', 'Id': '1', 'Tags': {'HTTP': 'Endpoint', 'Id': '1'}}},
        {'HTTPEndpoint': {'URL': 'www.endpoint.com', 'Id': '1', 'Tags': {'HTTP': 'Endpoint', 'Id': '1'}}})
    assert result

    # Test for failure on non-matching capitals

# Generated at 2022-06-20 15:49:49.145987
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test typical snake_dict_to_camel_dict use
    keys = {'a_key': 1, 'another_key': 2}
    result = snake_dict_to_camel_dict(keys)
    assert result == {'aKey': 1, 'anotherKey': 2}

    # Test complicated use case
    keys = {'a_key': {'b_key': 1, 'c_key': 2}}
    result = snake_dict_to_camel_dict(keys)
    assert result == {'aKey': {'bKey': 1, 'cKey': 2}}

    # Test typical snake_dict_to_camel_dict use - with capitalized keys
    keys = {'a_key': 1, 'another_key': 2}

# Generated at 2022-06-20 15:50:01.980516
# Unit test for function recursive_diff
def test_recursive_diff():
    try:
        recursive_diff('a', 'b')
        assert False, 'recursive_diff should throw a TypeError exception if given strings'
    except TypeError:
        pass
    except Exception:
        assert False, 'recursive_diff should throw a TypeError exception if given strings'

    assert recursive_diff({'a':'b'}, {'a':'b'}) is None, 'recursive_diff({}, {}) should return None'
    assert recursive_diff({'a':'b'}, {'a':'c'}) == ({'a': 'b'}, {'a': 'c'}), 'recursive_diff incorrect for different values'

    d1 = {'a': {'b': [1, 2, 3]}, 'x': 'y'}

# Generated at 2022-06-20 15:50:11.926876
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        'Foo': {
            'Bar': {
                'Baz': 'qux'
            }
        }
    }) == {
        'foo': {
            'bar': {
                'baz': 'qux'
            }
        }
    }
    assert camel_dict_to_snake_dict({
        'FooBar': {
            'BarBaz': {
                'BazQux': 'qux'
            }
        }
    }) == {
        'foo_bar': {
            'bar_baz': {
                'baz_qux': 'qux'
            }
        }
    }

# Generated at 2022-06-20 15:50:21.646963
# Unit test for function dict_merge
def test_dict_merge():

    class TestException(Exception):
        pass

    def base_test(a, b, result):
        c = dict_merge(a, b)
        if c != result:
            raise TestException("Expected %s, but got %s when merging %s and %s" % (result, c, a, b))

    # Test a few examples
    base_test({}, {}, {})
    base_test({"a": 1}, {"b": 2}, {"a": 1, "b": 2})
    base_test({"a": 1, "b": 2}, {"b": 3}, {"a": 1, "b": 3})
    base_test({"a": 1}, {"a": 2}, {"a": 2})

    # Test new key

# Generated at 2022-06-20 15:50:31.303549
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}

    assert snake_dict_to_camel_dict({'Type': 'AWS::CloudWatch::Alarm'}) == {'Type': 'AWS::CloudWatch::Alarm'}

    assert snake_dict_to_camel_dict({'Properties': {'MetricName': 'm'}}) == {'Properties': {'MetricName': 'm'}}

    assert snake_dict_to_camel_dict({'Resources': {'resource': {'Properties': {'MetricName': "m"}}}}) == {
        'Resources': {'resource': {'Properties': {'MetricName': "m"}}}}


# Generated at 2022-06-20 15:50:43.186257
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'thisIsEndpoint', 'fooBarBaz': {'fooBar': 'thisIsBar', 'baz': 'thisIsBaz'},
                  'listKey': [{'listKey1': 'key1', 'listKey2': 'key2'}, {'listKey3': 'key3'}],
                  'booleanKey': True}


# Generated at 2022-06-20 15:50:54.869584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Inputs & Expected outputs
    test_data = {
        'stringProp': 'string',
        'boolProp': True,
        'listProp': [1, 2, 3],
        'dictProp': {'a': 1},
        'complexProp': [{'a': 1}, {'b': 2}],
        'complexPropWithSubTags': {
            'Tags': [{'Key': 'Key', 'Value': 'Value'}],
            'arg': 'value',
            'argcs': 'Value'
        }
    }

# Generated at 2022-06-20 15:51:04.524389
# Unit test for function dict_merge
def test_dict_merge():
    '''
    unit test for function dict_merge
    '''

    a = {'one': 1, 'two': 2, 'inner': {'three': 3, 'four': 4}}
    b = {'one': 1, 'two': 22, 'inner': {'three': 33}}
    c = {'one': 1, 'two': 22, 'inner': {'three': 33, 'four': 4}}

    if dict_merge(a, b) == c and dict_merge(b, a) == c:
        return True
    else:
        raise Exception("Dict merge test failed")

# Generated at 2022-06-20 15:51:16.835882
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'foo': 'bar'}, {'baz': 'qux'}) == {'foo': 'bar', 'baz': 'qux'}
    assert dict_merge({'foo': ['bar', 'baz']}, {'foo': ['qux', 'quux']}) == {'foo': ['bar', 'baz', 'qux', 'quux']}
    assert dict_merge({'foo': 'bar'}, {'foo': 'qux'}) == {'foo': 'qux'}
    assert dict_merge({'foo': {'bar': 'baz'}}, {'foo': {'qux': 'quux'}}) == {'foo': {'bar': 'baz', 'qux': 'quux'}}

# Generated at 2022-06-20 15:51:26.937855
# Unit test for function recursive_diff
def test_recursive_diff():
    # No diff
    a = {'key': {'a': 'klmn'}}
    b = {'key': {'a': 'klmn'}}
    expected = None
    result = recursive_diff(a, b)
    assert result == expected

    # Recursive diff
    a = {'key': {'a': 'ijk', 'b': 'pqr'}}
    b = {'key': {'a': 'klmn', 'b': 'pqr'}}
    expected = ({'key': {'a': 'ijk'}},
                {'key': {'a': 'klmn'}})
    result = recursive_diff(a, b)
    assert result == expected

    # Dict different
    a = {'key': {'a': 'ijk', 'b': 'pqr'}}
   

# Generated at 2022-06-20 15:51:38.230854
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': {'key1.1': 'value1.1'}, 'key2': 'value2'}
    dict2 = {'key1': {'key1.1': 'value1.1'}, 'key2': 'value2'}
    assert recursive_diff(dict1, dict2) is None

    dict2 = {'key1': {'key1.1': 'value1.1'}, 'key2': 'value2', 'key3': 'value3'}
    assert recursive_diff(dict1, dict2) == ({'key3': 'value3'},)

    dict1 = {'key1': {'key1.1': 'value1.1'}, 'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-20 15:51:57.399682
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = {'a': 1, 'b': 2, 'c': 4}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 4, 'f': 5}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5, 'g': 6}}

# Generated at 2022-06-20 15:52:05.395030
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 'value1', 'key2': {'key3': 'value3'}}
    b = {'key1': 'value2', 'key2': {'key3': 'value4'}, 'key5': 'value5'}
    result = dict_merge(a, b)
    assert result['key1'] == b['key1']
    assert result['key5'] == b['key5']
    assert result['key2']['key3'] == b['key2']['key3']

# Generated at 2022-06-20 15:52:12.012311
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test type error
    try:
        recursive_diff([],{})
    except TypeError:
        pass

    # Test 1
    dict1 = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'key4': 'value4'
        }
    }
    dict2 = {
        'key1': 'value1'
    }
    assert recursive_diff(dict1, dict2) == ({'key2': 'value2', 'key3': {'key4': 'value4'}}, {})

    # Test 2
    dict1 = {
        'key1': 'value1'
    }
    dict2 = {
        'key1': 'value1'
    }
    assert recursive_diff(dict1, dict2) is None



# Generated at 2022-06-20 15:52:23.399380
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'server': 'foo.com',
        'port': 3306,
        'user': 'sh',
        'password': 'sh',
        'database': 'm',
        'parameters': {
            'OPTIMIZER_SWITCH': 'index_merge=on,index_merge_union=on,index_merge_sort_union=on,index_merge_intersection=on',
            'SQL_MODE': 'TRADITIONAL'
        }
    }

# Generated at 2022-06-20 15:52:33.540707
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'https://static.foo.com',
            'Authentication': 'http-signature',
            'Username': 'my_user_name',
            'Password': 'my_password'
        },
        'Tags': {
            'foo': 'bar'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == {
        'h_t_t_p_endpoint': {
            'endpoint_url': 'https://static.foo.com',
            'authentication': 'http-signature',
            'username': 'my_user_name',
            'password': 'my_password'
        },
        'tags': {
            'foo': 'bar'
        }
    }



# Generated at 2022-06-20 15:52:45.363455
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4', 'key5': 'value5'}}
    dict2 = {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4', 'key5': 'value5different'}}
    dict3 = {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4', 'key5': 'value5'}}
    dict4 = {'key1': 'value1', 'key2': 'value2different', 'key3': {'key4': 'value4', 'key5': 'value5'}}

# Generated at 2022-06-20 15:52:56.334082
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'a': {'b': '1', 'c': '2', 'd': '3'}, 'b': '4', 'c': {'a': '1'}}
    b = {'a': {'b': '1', 'c': '2', 'd': {'e': '4'}}, 'b': '4', 'c': {'a': '1'}}

    def _test_recursive_diff_with_dicts(a, b):
        c, d = recursive_diff(a, b)
        return c == {'a': {'d': '3'}}, d == {'a': {'d': {'e': '4'}}}

    assert _test_recursive_diff_with_dicts(a, b)
    assert _test_recursive_diff_with_dicts

# Generated at 2022-06-20 15:53:08.307092
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "key1": "value1",
        "key2": "value2",
        "key3": {"key31": "value31", "key32": "value32", "key33": ["value331", "value332"]},
    }
    dict2 = {
        "key1": "value1",
        "key2": "value2",
        "key3": {"key31": "value31", "key32": "value32", "key33": ["value331", "value332"]},
    }
    assert recursive_diff(dict1, dict2) == None

    dict3 = {
        "key1": "value1",
        "key2": "value2",
        "key3": {"key31": "value31", "key32": "value32"},
    }
    assert recursive_diff

# Generated at 2022-06-20 15:53:20.204645
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel_dict = {'parentMember': 'superParent', 'childMember': 42, 'Tags': {'Tag1': 'something'}}
    actual = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict))
    assert actual == {'parentMember': 'superParent', 'childMember': 42, 'Tags': {'Tag1': 'something'}}
    camel_dict = {'parentMember': 'superParent', 'childMember': 42, 'Tags': {'Tag1': 'something'}}
    actual = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict, reversible=True))
    assert actual == {'parent_member': 'superParent', 'child_member': 42, 'tags': {'tag1': 'something'}}

# Generated at 2022-06-20 15:53:31.433402
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict1 = {'a': 'a', 'b': {'a': 'a', 'c': 'c'}, 'd': 'd'}
    test_dict2 = {'a': 'a', 'b': {'a': 'a', 'c': 'c'}, 'd': 'e'}
    test_dict3 = {'b': {'a': 'x', 'c': 'c'}}
    test_dict4 = {'b': {'a': 'a', 'c': 'c'}}
    test_dict5 = {'a': 'a', 'b': {'a': 'a', 'c': 'c', 'd': 'd'}, 'e': 'e'}