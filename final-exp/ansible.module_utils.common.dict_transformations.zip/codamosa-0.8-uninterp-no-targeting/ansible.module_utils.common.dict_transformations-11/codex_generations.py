

# Generated at 2022-06-20 15:44:31.673023
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({"a": 1, "b": {"x": 2, "y": 3}}, {"b": {"x": 20}, "c": 30}) == {
        "a": 1,
        "b": {"x": 20, "y": 3},
        "c": 30,
    }

# Generated at 2022-06-20 15:44:38.540676
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': [1, 2, 3]}
    dict2 = {'a': 1, 'b': [1, 2, 4]}

    assert recursive_diff(dict1, dict2) == ({'b': [3]}, {'b': [4]}), "recursive_diff fail"
    assert recursive_diff(dict1, dict1) == None, "recursive_diff fail"


# Generated at 2022-06-20 15:44:42.284695
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'keyName': 'foo', 'innerDict': {'innerKey': 'bar'}}) == {'key_name': 'foo', 'inner_dict': {'inner_key': 'bar'}}


# Generated at 2022-06-20 15:44:49.278405
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 1, 'key2': 2, 'key3': {'key4': 4}}
    b = {'key1': 1, 'key2': 2, 'key3': {'key5': 5}}
    c = {'key1': 1, 'key2': 2, 'key3': {'key4': 4, 'key5': 5}}

    d = dict_merge(a, b)
    assert d == c

    # Now try a more complex, real work example
    e = {'key1': {'key2': None, 'key3': 'value'}, 'key4': ['list', 'of', 'values']}
    f = {'key1': {'key2': 'value'}}
    g = {'key1': {'key3': 'value'}}

    h = dict

# Generated at 2022-06-20 15:44:53.586973
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"empty_receipt_rule_set": {}}
    new_dict = snake_dict_to_camel_dict({"empty_receipt_rule_set": {}})

    assert new_dict == test_dict



# Generated at 2022-06-20 15:45:03.678334
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    a = dict()
    assert camel_dict_to_snake_dict(a) == {}

    a = dict(foo=dict(bar='val'), baz='qux')
    assert camel_dict_to_snake_dict(a) == dict(foo=dict(bar='val'), baz='qux')

    a = dict(Foo=dict(bar='val'), baz='qux')
    assert camel_dict_to_snake_dict(a) == dict(foo=dict(bar='val'), baz='qux')

    a = dict(Foo=dict(bar='val'), Baz='qux')
    assert camel_dict_to_snake_dict(a) == dict(foo=dict(bar='val'), baz='qux')


# Generated at 2022-06-20 15:45:11.219152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {
        'TopicArn': 'arn',
        'Tags': {
            'HTTPEndpoint': 'http',
            'HTTPSEndpoint': 'https',
        },
    }
    expected_result = {
        'topic_arn': 'arn',
        'tags': {
            'HTTPEndpoint': 'http',
            'HTTPSEndpoint': 'https',
        },
    }
    result = camel_dict_to_snake_dict(data, ignore_list=('Tags',))
    assert result == expected_result


# Generated at 2022-06-20 15:45:22.376081
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test dict with single key
    snake_dict_input = {'key_one': 'val'}
    assert snake_dict_to_camel_dict(snake_dict_input) == {'keyOne': 'val'}

    # Test dict with a dict as a value
    snake_dict_input = {'key_one': {'key_one_child': 'val'}}
    assert snake_dict_to_camel_dict(snake_dict_input) == {'keyOne': {'keyOneChild': 'val'}}

    # Test dict with list as value
    snake_dict_input = {'key_one': ['val1', 'val2']}
    assert snake_dict_to_camel_dict(snake_dict_input) == {'keyOne': ['val1', 'val2']}



# Generated at 2022-06-20 15:45:31.950027
# Unit test for function dict_merge
def test_dict_merge():
    def _check(a, b, expected):
        got = dict_merge(a, b)
        assert got == expected, "dict_merge({}, {})\nreturned {}\nexpected {}".format(a, b, got, expected)

    _check({'k1': 1, 'k2': 2, 'k3': 3}, {'k3': 4, 'k4': 5}, {'k1': 1, 'k2': 2, 'k3': 4, 'k4': 5})

# Generated at 2022-06-20 15:45:42.235916
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test1 = {
        'OutboundRules': [
            {
                'ToPort': 80,
                'FromPort': 80,
                'IpProtocol': 'tcp',
            },
        ],
    }
    print('Test 1: ' + str(test1))
    result = camel_dict_to_snake_dict(test1, True)
    print('Expect: ' + str({
        'outbound_rules': [
            {
                'to_port': 80,
                'from_port': 80,
                'ip_protocol': 'tcp',
            },
        ],
    }))
    print('Result: ' + str(result))


# Generated at 2022-06-20 15:45:56.092001
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(
        first=dict(
            all_same=1,
            altogether_now=dict(
                deeper_left=1,
                deeper_right=2,
            ),
            spam=1,
        ),
        second=dict(
            a=2,
            b=3,
            c=dict(
                a=1,
                b=1,
                c=2,
            ),
        ),
    )

# Generated at 2022-06-20 15:46:04.077614
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'AttributeName': 'ARN',
        'AttributeValue': 'arn:aws:ecs:us-east-1:1234567890:cluster/default'
    }

    snake_dict = {
        'attribute_name': 'ARN',
        'attribute_value': 'arn:aws:ecs:us-east-1:1234567890:cluster/default'
    }
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-20 15:46:08.732296
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Payload': 'payload', 'HTTPHeaders': [{'Name': 'name', 'Value': 'value'}]},
                  'HTTPEndpoints': [{'HTTPEndpoint': {'Payload': 'payload', 'HTTPHeaders': [{'Name': 'name', 'Value': 'value'}]}}],
                  'HTTPEndpoint1': 'test',
                  'HTTPHeaders': [],
                  'Tags': {'Key': 'value'},
                  'TargetGroupARNs': ['arn1', 'arn2'],
                  'TargetGroupARN': ['arn1', 'arn2'],
                  'TargetGroups': ['a', 'b']
                  }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict

# Generated at 2022-06-20 15:46:14.496547
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_input = { "camelCase": "snake_case",
                    "camelCaseTag": { "tag": "value" }
                    }
    output = camel_dict_to_snake_dict(camel_input)
    expected_output = { "camel_case": "snake_case",
                        "camel_case_tag": { "tag": "value" }
                        }

    assert output == expected_output

# Generated at 2022-06-20 15:46:21.994596
# Unit test for function dict_merge
def test_dict_merge():
    a = {'c': {'d': 0, 'e': 0}, 'f': 0, 'g': 0}
    b = {'c': {'d': 1, 'e': 1}, 'f': 1, 'h': 1}

    c = dict_merge(a, b)
    assert c == {'c': {'d': 1, 'e': 1}, 'f': 1, 'g': 0, 'h': 1}

# Generated at 2022-06-20 15:46:32.120257
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-20 15:46:42.716062
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': {
            'x': 2,
            'y': {
                'p': 3,
                'q': 4
            }
        }
    }

    dict2 = {
        'a': 1,
        'b': {
            'w': 2,
            'y': {
                'p': 5,
                'q': 4
            }
        }
    }
    test_result = recursive_diff(dict1, dict2)
    assert test_result[0] == {'b': {'x': 2}}, test_result
    assert test_result[1] == {'b': {'w': 2, 'y': {'p': 5}}}, test_result


# Generated at 2022-06-20 15:46:52.465138
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Unit test for function snake_dict_to_camel_dict"""

    def assert_dicts_equal(dict1, dict2):
        """Assert that the two dictionaries are equal"""
        if dict1 != dict2:
            raise AssertionError(
                "Dicts not equal:\n--- dict1:\n%s\n--- dict2:\n%s" % (dict1, dict2))

    # Verify that we get back the same dictionary when we convert from from camel
    # to snake and back

# Generated at 2022-06-20 15:47:01.870454
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "subnetId": "subnet-12345",
        "PrivateIp": "10.0.0.1",
        "InstanceId": "i-12345",
        "BlockDeviceMappings": [
            {
                "DeviceName": "/dev/sda1",
                "Ebs": {
                    "VolumeId": "vol-12345",
                    "DeleteOnTermination": True
                }
            }
        ]
    }


# Generated at 2022-06-20 15:47:14.171849
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        "a": "a",
        "b": "b",
        "c": {
            "d": "d",
            "e": "e",
            "f": "f"
        },
        "g": "g"
    }

    dict2 = {
        "a": "a",
        "b": "b",
        "c": {
            "d": {
                "h": "diffh"
            },
            "e": "e",
            "f": "f"
        },
        "g": "diffg"
    }


# Generated at 2022-06-20 15:47:25.684775
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    x = {'node_id': '123123123', 'node_name': 'node-name-A', 'tags': {'slot-1111': 'slot-value-1111', 'slot-2222': 'slot-value-2222', 'slot-3333': 'slot-value-3333'}, 'node_type': 'node-type-A'}
    y = {'nodeId': '123123123', 'nodeName': 'node-name-A', 'tags': {'slot-1111': 'slot-value-1111', 'slot-2222': 'slot-value-2222', 'slot-3333': 'slot-value-3333'}, 'nodeType': 'node-type-A'}
    assert snake_dict_to_camel_dict(x) == y

# Generated at 2022-06-20 15:47:37.762731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        "HTTPEndpoint": {},
        "TargetInstances": [],
        "LifecycleState": "state",
        "VipAddress": "address",
        "HealthCheckProtocol": "protocol",
        "TargetGroupARNs": ["arns"],
        "Tags": {'key': 'value'},
    }) == {
        "h_t_t_p_endpoint": {},
        "target_instances": [],
        "lifecycle_state": "state",
        "vip_address": "address",
        "health_check_protocol": "protocol",
        "target_group_ar_ns": ["arns"],
        "Tags": {'key': 'value'},
    }

# Generated at 2022-06-20 15:47:47.311498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'MyKey': 'MyValue',
        'MultiWordKey': 'MultiWordValue',
        'MultiWordKey2': {
            'NestedKey': 'NestedValue',
            'NestedKey2': 'NestedValue2',
            'NestedList': [
                {
                    'NestedListKey': 'NestedListValue'
                }
            ]
        }
    }


# Generated at 2022-06-20 15:47:56.353905
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    TestList = ['foo', {'HTTPEndpoint': 'bar'}]
    TestData = {
        'foo': 'bar',
        'HTTPEndpoint': {
            'foo': 'bar',
            'HTTPEndpoint': {
                'foo': 'bar',
            },
            'HTTPEndpoints': {
                'HTTPEndpoint': {
                    'foo': 'bar',
                },
            },
        },
    }

    SnakeList = camel_dict_to_snake_dict(TestList, True)
    assert SnakeList[1]['h_t_t_p_endpoint'] == 'bar'
    SnakeData = camel_dict_to_snake_dict(TestData, True)

# Generated at 2022-06-20 15:48:05.794149
# Unit test for function dict_merge
def test_dict_merge():
    '''Unit test for function dict_merge    '''

# Generated at 2022-06-20 15:48:16.896172
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict()
    dict2 = dict()

    # No difference
    assert recursive_diff(dict1, dict2) is None

    # Keys only in dict1
    dict1 = dict((k, None) for k in ("A", "B", "C"))
    dict2 = dict()
    assert recursive_diff(dict1, dict2) == ({'A': None, 'C': None, 'B': None}, {})

    # Keys only in dict2
    dict1 = dict()
    dict2 = dict((k, None) for k in ("X", "Y", "Z"))
    assert recursive_diff(dict1, dict2) == ({}, {'X': None, 'Y': None, 'Z': None})

    # Keys in both dict1 and dict2 but different

# Generated at 2022-06-20 15:48:28.313052
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "element": {
            "key_0": 0,
            "key_1": 1,
            "key_2": 2,
            "dict": {
                "key_0": 0,
                "key_1": 1,
                "key_2": 2,
            }
        },
        "key_0": 0,
        "key_1": 1,
        "key_2": 2
    }


# Generated at 2022-06-20 15:48:39.456599
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({'snake': 'case'}) == {'snake': 'case'}
    assert snake_dict_to_camel_dict({'snake': 'case'}, True) == {'Snake': 'case'}
    assert snake_dict_to_camel_dict({'snake_case': 'test'}) == {'snakeCase': 'test'}
    assert snake_dict_to_camel_dict({'snake_case': 'test'}, True) == {'SnakeCase': 'test'}

# Generated at 2022-06-20 15:48:43.118522
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(dict(foo_bar='baz', foo_bar_baz='qux')) == dict(fooBar='baz', fooBarBaz='qux')
    assert snake_dict_to_camel_dict({'foo_bar': 'baz', 'foo_bar_baz': 'qux'}) == {}
    assert snake_dict_to_camel_dict({}, capitalize_first=False) == {}
    assert snake_dict_to_camel_dict({}, capitalize_first=True) == {}
    # Convert only first level keys

# Generated at 2022-06-20 15:48:51.788424
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': {},'FooBarBaz': {}}, ignore_list=('FooBar','FooBarBaz')) == {'foo_bar': {}, 'foo_bar_baz': {}}
    assert camel_dict_to_snake_dict({'FooBar': {},'FooBarBaz': {}}, ignore_list=('foo_bar','foo_bar_baz')) == {'foo_bar': {}, 'foo_bar_baz': {}}
    assert camel_dict_to_snake_dict({'FooBar': 'Hello'}, ignore_list=('foo_bar')) == {'foo_bar': 'Hello'}

# Generated at 2022-06-20 15:48:56.727947
# Unit test for function dict_merge
def test_dict_merge():

    assert dict_merge({'a': 1, 'b': 2}, {'b': '3', 'c': '4'}) == {'a': 1, 'b': '3', 'c': '4'}

# Generated at 2022-06-20 15:49:04.529753
# Unit test for function dict_merge
def test_dict_merge():
    d = dict(a=dict(b=1, c=2), f=3)
    d2 = dict(a=dict(a=5, d=4), g=5)
    dd = dict_merge(d, d2)

    assert dd['a']['b'] == 1
    assert dd['a']['c'] == 2
    assert dd['a']['a'] == 5
    assert dd['a']['d'] == 4
    assert dd['f'] == 3
    assert dd['g'] == 5


if __name__ == "__main__":
    test_dict_merge()

# Generated at 2022-06-20 15:49:09.406525
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(A=1, B=dict(A=1, B=2), C=dict(A=1))
    b = dict(A=2, B=dict(B=3, C=3), C=dict(B=2))
    print(dict_merge(a, b))

# Generated at 2022-06-20 15:49:17.120014
# Unit test for function dict_merge
def test_dict_merge():
    # Test 1 - source and destination same type
    assert dict_merge({'a': 'one'}, {'b': 'two'}) == {'a': 'one', 'b': 'two'}
    # Test 2 - source and destination different type
    assert dict_merge({'a': 'one', 'b': 'two'}, ['b', 'three']) == {'a': 'one', 'b': 'two'}
    # Test 3 - source and destination different type
    assert dict_merge({'a': 'one', 'b': 'two'}, ['b', 'three']) == {'a': 'one', 'b': 'two'}



# Generated at 2022-06-20 15:49:28.504469
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'second' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    d = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    e = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }


# Generated at 2022-06-20 15:49:38.892229
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test 1 compares two identical dictionaries with two-level nesting
    dict1 = dict(name="my-ec2", tags=dict(Name="my-ec2"))
    dict2 = dict(name="my-ec2", tags=dict(Name="my-ec2"))
    assert recursive_diff(dict1, dict2) is None

    # Test 2 compares two identical dictionaries with multiple-level nesting
    dict1 = dict(name="my-ec2", tags=dict(Name="my-ec2", Environment="test",
        Type="test", Parent="test"), image_tags=[
            dict(Key="Tag1", Value="Value1"),
            dict(Key="Tag2", Value="Value2")
            ])

# Generated at 2022-06-20 15:49:44.908228
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {"a": 1, "b": 2, "c": {"d": 3, "e": 4, "f": 5}}
    result = snake_dict_to_camel_dict(snake_dict)
    assert result ==  {"a": 1, "b": 2, "c": {"d": 3, "e": 4, "f": 5}}

# Generated at 2022-06-20 15:49:54.396155
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {
        "a": {
            "b": 10
        },
        "c": 10,
        "d": "foo"
    }
    dict2 = {
        "a": {
            "b": 20,
            "c": 30
        },
        "c": 20,
        "e": "bar"
    }
    dict3 = dict_merge(dict1, dict2)
    assert dict3['a']['b'] == 20
    assert dict3['a']['c'] == 30
    assert dict3['c'] == 20
    assert dict3['d'] == "foo"
    assert dict3['e'] == "bar"

# Generated at 2022-06-20 15:50:01.749432
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict_snake = dict(
        test_1 = dict(
            test_2 = dict(
                test_3 = "test_value"
            )
        ),
        test_4 = "test_value",
        test_list = [ 1, 2, 3 ],
        test_list2 = [ dict(test_list_value = 1), dict(test_list_value = 2), dict(test_list_value = 3) ],
        test_list3 = [ dict(test_list_value_2 = 1), dict(test_list_value_2 = 2), dict(test_list_value_2 = 3) ],
        test_dict = dict(test_dict_value = 1),
        test_type = type(dict(test_type_value = 1))  # test to make sure the value is not changed
    )
   

# Generated at 2022-06-20 15:50:11.723894
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1,
         'b': {'b1': 1,
               'b2': 2},
         'c': 3
         }
    b = {'c': {'c1': 1,
               'c2': 2},
         'd': {'d1': 1,
               'd2': 2}
         }
    c = dict_merge(a, b)
    assert c == {'a': 1,
                 'b': {'b1': 1,
                       'b2': 2},
                 'c': {'c1': 1,
                       'c2': 2},
                 'd': {'d1': 1,
                       'd2': 2}
                 }


# test dictionary for unit test for function recursive_diff

# Generated at 2022-06-20 15:50:22.582945
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert (snake_dict_to_camel_dict({"foo_bar": {"foo_baz": [{"foo_foo": "foo", "foo_bar": "bar"}]}})
            == {"fooBar": {"fooBaz": [{"fooFoo": "foo", "fooBar": "bar"}]}})
    assert (snake_dict_to_camel_dict({"foo_bar": "foo"}, capitalize_first=True)
            == {"FooBar": "foo"})
    assert (snake_dict_to_camel_dict({"foo_bar": "foo"})
            == {"fooBar": "foo"})

# Generated at 2022-06-20 15:50:32.137601
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_data = {
        'HTTPEndPoint': 'value',
        'target_group_arns': [
            'arn:aws:elasticloadbalancing:us-east-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ],
        'Tags': {
            'Environment': 'Test',
            'Service': 'TGT',
            'Tier': 'TEST-2'
        }
    }


# Generated at 2022-06-20 15:50:43.572583
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'fooBar_baz': {'abcDef': [{'fooBar': 'baz'}]}} ==\
        snake_dict_to_camel_dict({'foo_bar_baz': {'abc_def': [{'foo_bar': 'baz'}]}},
                                 capitalize_first=True)
    assert {'fooBar_baz': {'abcDef': [{'fooBar': 'baz'}]}} ==\
        snake_dict_to_camel_dict({'foo_bar_baz': {'abc_def': [{'foo_bar': 'baz'}]}})
    assert {} == snake_dict_to_camel_dict({})

# Generated at 2022-06-20 15:50:55.237064
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _snake_to_camel('http_endpoint') == 'httpEndpoint'

    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'
    assert _snake_to_camel('h_t_t_p_endpoint', True) == 'HTTPEndpoint'

    assert _camel_to_snake('TargetGroupARNs') == 'target_group_arns'
    assert _snake_to_camel('target_group_arns') == 'targetGroupArns'

    assert _camel_to_snake('TargetGroupARNs', True) == 'target_group_a_r_ns'
    assert _snake_to_

# Generated at 2022-06-20 15:51:07.324163
# Unit test for function recursive_diff
def test_recursive_diff():
    data1 = {
        'username': 'root',
        'password': 'p@ssw0rd',
        'hostname': 'host1'
    }

    data2 = {
        'username': 'root',
        'password': 'p@ssw0rd123',
        'hostname': 'host1'
    }

    assert recursive_diff(data1, data2) == ({'password': 'p@ssw0rd'},
                                            {'password': 'p@ssw0rd123'})


# Generated at 2022-06-20 15:51:20.257548
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict1 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
            },
        }
    test_dict2 = {
        'key1': 'value2',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
            },
        'key5': 'value5',
        }
    test_dict3 = {
        'key2': {
            'key4': 'value4',
            }
        }
    test_dict4 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value5',
            },
        }
    test_dict5

# Generated at 2022-06-20 15:51:27.532548
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
            'foo': 'bar',
            'hi_there': {
                'name': 'joe',
                'age': 12,
                'favorite_numbers': [1, 2, 3, 4]
                },
            'empty': {},
            'list': ['foo', 'bar'],
            }

    result = {
            'foo': 'bar',
            'hiThere': {
                'name': 'joe',
                'age': 12,
                'favoriteNumbers': [1, 2, 3, 4]
                },
            'empty': {},
            'list': ['foo', 'bar'],
            }

    assert snake_dict_to_camel_dict(test_dict) == result


# Generated at 2022-06-20 15:51:36.038102
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'b': 1, 'bb': {'b': 1, 'bb': 1}}, 'c': 3}
    b = {'a': 2, 'b': {'b': 2, 'bb': {'b': 2, 'bbb': 2}}, 'd': 4}
    assert {'a': 2, 'b': {'b': 2, 'bb': {'b': 2, 'bb': 1, 'bbb': 2}}, 'c': 3, 'd': 4} == dict_merge(a, b)



# Generated at 2022-06-20 15:51:44.578517
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Simple test
    snake_dict = {'partial_data': {'name': 'Tom'}}
    converted = {'partialData': {'name': 'Tom'}}

    assert snake_dict_to_camel_dict(snake_dict) == converted

    # Test with capitalized_first
    converted = {'PartialData': {'name': 'Tom'}}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == converted

    # Deeply-nested test
    snake_dict = {'partial_data': {'name': 'Tom', 'age': 23, 'address': {'street': 'Broadway', 'city': 'New York'}}}

# Generated at 2022-06-20 15:51:55.473596
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key1': 'value1',
        'key2': 'value2',
        'dict1': {
            'key1': 'value1',
            'key2': 'value2'
        },
        'list1': [
            {'key1': 'value1'},
            {'key2': 'value2'}
        ]
    }
    dict2 = {
        'key1': 'value1',
        'key3': 'value3',
        'dict1': {
            'key1': 'value1',
            'key3': 'value3'
        },
        'list1': [
            {'key1': 'value1'},
            {'key3': 'value3'}
        ]
    }
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-20 15:52:09.609489
# Unit test for function recursive_diff
def test_recursive_diff():
    from collections import Mapping

    a = {'first': [1, 2, 3], 'second': {'foo': 'bar'}, 'third': 3}
    b = {'third': 4, 'second': {'foo': 'bar'}, 'first': [1, 2, 3]}
    assert recursive_diff(a, b) == ({'third': 3}, {'third': 4})

    a = {'first': [1, 2, 3], 'second': {'foo': 'bar'}, 'third': '3'}
    b = {'third': '3', 'second': {'foo': 'bar'}, 'first': [1, 2, 3]}
    assert recursive_diff(a, b) == None


# Generated at 2022-06-20 15:52:21.196209
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Test some simple cases
    assert snake_dict_to_camel_dict({'foo_bar': 2}) == {'FooBar': 2}
    assert snake_dict_to_camel_dict({'foo': 2}) == {'Foo': 2}

    # Test some more complex dicts
    assert snake_dict_to_camel_dict(
        {'foo_bar': 2, 'bar_foo': {'foo_bar': 2, 'bar_foo': {'foo_bar': 2}}}
    ) == {
        'FooBar': 2,
        'BarFoo': {'FooBar': 2, 'BarFoo': {'FooBar': 2}}
    }


# Generated at 2022-06-20 15:52:26.937323
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict = {'this_is_snake_case': True}
    assert snake_dict_to_camel_dict(dict, capitalize_first=True) == {'ThisIsSnakeCase': True}
    assert snake_dict_to_camel_dict(dict, capitalize_first=False) == {'thisIsSnakeCase': True}

# Generated at 2022-06-20 15:52:35.442394
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    old_dict = {
        'InstanceIds': ['i-a6f8b6c2', 'i-a6f7b6c2', 'i-a6f6b6c2'],
        'HTTPEndpoint': "http://amazon.com",
        'Tags': {
            'BKey': 'BValue',
            'AKey': 'AValue',
            'CKey': {
                'C_Key': 'CValue'
            },
            'DKey': [{
                'Key': 'Value 1',
                'KeyA': 'ValueA 1',
                'key2': 'ValueB 1'
            }, {
                'Key': 'Value 2',
                'KeyA': 'ValueA 2',
                'key2': 'ValueB 2'
            }]
        },
    }

    new_

# Generated at 2022-06-20 15:52:46.857264
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        'host': 'hostname',
        'request_options': {
            'headers': {
                'User-Agent': 'python-dyn'
            }
        },
        'yada': 'hey'
    }
    dict2 = {
        'host': 'hostname',
        'yada': 'hey',
        'request_options': {
            'headers': {
                'User-Agent': 'boto-dyn'
            }
        }
    }

    dict_diff = recursive_diff(dict1, dict2)


# Generated at 2022-06-20 15:52:51.625590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {'HTTPEndpoint': 'URL', 'PrivateIpAddress': '1.1.1.1', 'ConnectionDraining': {'Enabled': bool, 'Timeout': int}, 'Attributes': [{'Name': "string", 'Value': "string"}, {'Name': "string", 'Value': "string"}]}
    snake = {'h_t_t_p_endpoint': 'URL', 'private_ip_address': '1.1.1.1', 'connection_draining': {'enabled': bool, 'timeout': int}, 'attributes': [{'name': "string", 'value': "string"}, {'name': "string", 'value': "string"}]}
    assert camel_dict_to_snake_dict(camel) == snake

# Generated at 2022-06-20 15:52:58.176589
# Unit test for function dict_merge
def test_dict_merge():

    # Test empty dicts
    a = {}
    b = {}
    result = dict_merge(a, b)
    assert result == a

    # Test empty dicts
    a = {}
    b = {'a': 1}
    result = dict_merge(a, b)
    assert result == b

    # Test empty dicts
    a = {'a': 1}
    b = {}
    result = dict_merge(a, b)
    assert result == a

    # Test unequal dicts
    a = {'a': 1}
    b = {'b': 'foo'}
    result = dict_merge(a, b)
    assert result == {'a': 1, 'b': 'foo'}

    # Test equal dicts
    a = {'a': 1}

# Generated at 2022-06-20 15:53:09.793519
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'aws_resource': {
            'aws_region': 'eu-west-1',
            'az_explicit_region': 'eu-west-1b'
        },
        'other_key': 'other_value'
    }
    dict2 = {
        'aws_resource': {
            'aws_region': 'eu-west-1',
            'az_explicit_region': 'eu-west-1a'
        },
        'other_key': 'other_value'
    }

# Generated at 2022-06-20 15:53:21.438108
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Simple conversion
    assert camel_dict_to_snake_dict({"fooBarBaz": 1}) == {"foo_bar_baz": 1}

    # Conversion of a complicated dictionary
    camelized = {"fooBarBaz": 1, "bizBaz": {"bingBong": 2, "buzzZiff": [3, 4, 5]}}
    assert camel_dict_to_snake_dict(camelized) == {"foo_bar_baz": 1, "biz_baz": {"bing_bong": 2, "buzz_ziff": [3, 4, 5]}}

    # Ignore a tag

# Generated at 2022-06-20 15:53:32.766244
# Unit test for function recursive_diff
def test_recursive_diff():
    from nose.tools import assert_dict_equal

    # test base cases
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None


# Generated at 2022-06-20 15:53:50.695457
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict_1 = {
      'key_snake': 'value_snake',
      'key_snake_second': 'value_snake_second'
    }
    camel_dict_1 = {
      'keySnake': 'value_snake',
      'keySnakeSecond': 'value_snake_second'
    }

    assert(snake_dict_to_camel_dict(snake_dict_1) == camel_dict_1)
    assert(snake_dict_to_camel_dict(snake_dict_1, capitalize_first=True) != camel_dict_1)


# Generated at 2022-06-20 15:54:02.792273
# Unit test for function dict_merge
def test_dict_merge():

    d = {'a': 1, 'b': 2}
    e = {'b': 3, 'c': 4}
    f = {'a': 1, 'b': 3, 'c': 4}
    assert dict_merge(d, e) == f

    a = {'a': {'b': 1, 'c': 2}}
    b = {'a': {'b': 3, 'd': 4}}
    c = {'a': {'b': 3, 'c': 2, 'd': 4}}
    assert dict_merge(a, b) == c

    o = {'a': 3, 'b': 2}
    p = {'a': 1, 'b': {'x': 7, 'y': 8}}