

# Generated at 2022-06-16 22:27:57.951684
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test case 1
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    expected_result = ({'c': {'e': 4}}, {'c': {'e': 5}})
    result = recursive_diff(dict1, dict2)
    assert result == expected_result

    # Test case 2
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    expected_result = None

# Generated at 2022-06-16 22:28:06.721495
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 3}
    dict2 = {'a': {'b': 1, 'c': 3}, 'd': 4}
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': {'c': 2}}, {'a': {'c': 3}, 'd': 4})
    result = recursive_diff(dict2, dict1)
    assert result == ({'a': {'c': 3}, 'd': 4}, {'a': {'c': 2}})
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 3}

# Generated at 2022-06-16 22:28:18.715828
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})
    assert recursive_diff(dict1, dict1) == None
    dict3 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    assert recursive_diff(dict1, dict3) == ({'e': 4}, {'f': 5})

# Generated at 2022-06-16 22:28:31.082377
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://localhost:8080',
            'Protocol': 'HTTP',
            'HTTPHeaders': [
                {
                    'Name': 'Content-Type',
                    'Value': 'application/json'
                }
            ]
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'url': 'http://localhost:8080',
            'protocol': 'HTTP',
            'h_t_t_p_headers': [
                {
                    'name': 'Content-Type',
                    'value': 'application/json'
                }
            ]
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake

# Generated at 2022-06-16 22:28:35.164376
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function"""

    # Test with empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test with empty and non-empty dictionaries
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})

    # Test with non-empty and empty dictionaries
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})

    # Test with non-empty dictionaries
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})

# Generated at 2022-06-16 22:28:40.034591
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}

# Generated at 2022-06-16 22:28:48.642034
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:00.049780
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})
    assert recursive_diff(dict2, dict1) == ({'b': {'d': 4}, 'f': 5}, {'b': {'d': 3}, 'e': 4})
    assert recursive_diff(dict1, dict1) == None
    assert recursive_diff(dict2, dict2) == None
    assert recursive_diff({}, {}) == None

# Generated at 2022-06-16 22:29:06.842038
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})

# Generated at 2022-06-16 22:29:16.319520
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}}, {'b': {'d': 4}})

    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    assert recursive_diff(dict1, dict2) == None


# Generated at 2022-06-16 22:29:29.898319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 1,
            "Period": 60,
            "SuccessCodes": "200,201",
            "HTTPMethod": "POST",
            "Auth": {
                "Type": "none"
            },
            "Headers": {
                "Content-Type": "application/json"
            },
            "Body": "{\"foo\": \"bar\"}",
            "HealthyThreshold": 10,
            "UnhealthyThreshold": 2,
            "Matcher": {
                "HttpCode": "200"
            }
        },
        "Tags": {
            "Name": "test-http-endpoint",
            "Environment": "test"
        }
    }

    expected_dict

# Generated at 2022-06-16 22:29:38.261030
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:49.147182
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:00.056043
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://example.com',
            'AuthorizationConfig': {
                'AuthorizationType': 'AWS_IAM',
                'AWSRegion': 'us-east-1'
            }
        }
    }

    snake_dict = {
        'http_endpoint': {
            'http_endpoint_url': 'http://example.com',
            'authorization_config': {
                'authorization_type': 'AWS_IAM',
                'aws_region': 'us-east-1'
            }
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:30:12.402943
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:21.284932
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:33.753266
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'TimeoutInMillis': 5000,
            'HealthyThresholdCount': 5,
            'UnhealthyThresholdCount': 2,
            'IntervalInSeconds': 30,
            'Matcher': {
                'HttpCode': '200-399'
            }
        },
        'Tags': [
            {
                'Key': 'foo',
                'Value': 'bar'
            }
        ]
    }

# Generated at 2022-06-16 22:30:45.968041
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://localhost:8080/',
            'Timeout': 10,
            'HTTPHeaders': [
                {
                    'Name': 'Content-Type',
                    'Value': 'application/json'
                },
                {
                    'Name': 'Accept',
                    'Value': 'application/json'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:30:54.947395
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:04.245405
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Key": "value"
        }
    }
    snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "protocol": "HTTP"
        },
        "tags": {
            "Key": "value"
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:31:13.670927
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:31:17.907423
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': 1, 'c': 2}, 'd': 3}
    b = {'a': {'b': 4, 'd': 5}, 'e': 6}
    c = dict_merge(a, b)
    assert c == {'a': {'b': 4, 'c': 2, 'd': 5}, 'd': 3, 'e': 6}



# Generated at 2022-06-16 22:31:23.648209
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 5, 'f': 6}, 'g': 7}
    c = {'a': 1, 'b': {'c': 5, 'd': 3, 'f': 6}, 'e': 4, 'g': 7}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:31:35.293340
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '10s',
            'TLSConfig': {
                'CAFile': '/etc/ssl/certs/ca-certificates.crt',
                'CertFile': '/etc/ssl/certs/client.pem',
                'KeyFile': '/etc/ssl/certs/client-key.pem',
                'InsecureSkipVerify': True
            }
        },
        'Tags': {
            'Name': 'test-name',
            'Role': 'test-role'
        }
    }

# Generated at 2022-06-16 22:31:42.233135
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:31:49.327342
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200',
            'HTTPMethod': 'GET',
            'FailureThreshold': 5,
            'MeasureLatency': True,
            'Enabled': True,
            'Tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:31:57.139836
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 10
        },
        'Tags': {
            'key': 'value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['h_t_t_p_endpoint']['endpoint'] == 'http://example.com'
    assert snake_dict['h_t_t_p_endpoint']['protocol'] == 'HTTP'
    assert snake_dict['h_t_t_p_endpoint']['timeout_in_seconds'] == 10
    assert snake_dict['tags']['key'] == 'value'



# Generated at 2022-06-16 22:32:03.739126
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    c = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4, 'f': 5}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:32:10.597728
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:32:20.692824
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict



# Generated at 2022-06-16 22:32:30.917156
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP',
            'Id': 'http-endpoint-1',
            'Name': 'http-endpoint-1',
            'Tags': {
                'Key1': 'Value1',
                'Key2': 'Value2'
            }
        },
        'HTTPEndpointConfig': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP',
            'Name': 'http-endpoint-1',
            'Tags': {
                'Key1': 'Value1',
                'Key2': 'Value2'
            }
        }
    }

# Generated at 2022-06-16 22:32:41.703029
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-16 22:32:50.326445
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Key": "value"
        }
    }
    snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "protocol": "HTTP"
        },
        "tags": {
            "Key": "value"
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:33:01.751275
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:14.362243
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test'
        }
    }


# Generated at 2022-06-16 22:33:25.716305
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '30',
            'Tags': {
                'Key': 'value'
            }
        },
        'Tags': {
            'Key': 'value'
        },
        'Tag': 'value',
        'TagList': ['value1', 'value2'],
        'TagDict': {
            'Key': 'value'
        },
        'TagListDict': [{
            'Key': 'value'
        }]
    }


# Generated at 2022-06-16 22:33:37.334862
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:47.830210
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'EDGE',
            'Target': 'arn:aws:lambda:us-east-1:123456789012:function:my-function',
            'TimeoutInMillis': 12345
        },
        'Tags': {
            'Tag': {
                'Key': 'TagKey',
                'Value': 'TagValue'
            }
        }
    }

    snake

# Generated at 2022-06-16 22:33:55.263029
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'FailureThreshold': 2,
            'HTTPMethod': 'GET'
        }
    }
    snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 5,
            'period': 60,
            'success_codes': '200,201',
            'failure_threshold': 2,
            'http_method': 'GET'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:34:04.588515
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Enabled': True,
            'Timeout': 10,
            'HTTPMethod': 'POST',
            'HTTPPath': '/',
            'AuthKey': '1234567890',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Amzn-Trace-Id': 'Root=1-5c7e91d0-bd862e3fe1be46a994272793'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:34:20.647916
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:32.377015
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:44.937982
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Authentication': {
                'Type': 'AWS_IAM'
            }
        },
        'TCPEndpoint': {
            'Protocol': 'TCP',
            'Port': 80,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:34:53.975785
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': {'fooBar': 'baz'}}}) == {'foo_bar': {'foo_bar': {'foo_bar': 'baz'}}}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_

# Generated at 2022-06-16 22:35:03.473194
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:15.351886
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:35:24.816991
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:33.365800
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for simple case
    camel_dict = {'HTTPEndpoint': 'http://example.com'}
    snake_dict = {'http_endpoint': 'http://example.com'}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # Test for complex case
    camel_dict = {'HTTPEndpoint': 'http://example.com',
                  'Tags': {'Key': 'value'},
                  'TargetGroupARNs': ['arn1', 'arn2']}
    snake_dict = {'http_endpoint': 'http://example.com',
                  'tags': {'Key': 'value'},
                  'target_group_ar_ns': ['arn1', 'arn2']}

# Generated at 2022-06-16 22:35:45.421908
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:35:54.422641
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:10.340652
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:19.088762
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict, reversible=True) == camel_dict


# Generated at 2022-06-16 22:36:30.721329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:36:38.266524
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 30,
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'AWS_IAM',
                'CredentialsParameter': {
                    'Ref': 'MyCredentials'
                }
            },
            'Headers': [
                {
                    'Key': 'Content-Type',
                    'Value': 'application/json'
                }
            ],
            'URLPath': '/',
            'URLQueryParameters': [
                {
                    'Key': 'foo',
                    'Value': 'bar'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:36:45.431773
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInMillis': 123,
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'AWS_IAM',
                'AWS_IAM': {
                    'RoleArn': 'arn:aws:iam::123456789012:role/test-role',
                    'ServiceName': 'test-service'
                }
            }
        },
        'Tags': {
            'Key1': 'Value1',
            'Key2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:36:57.340605
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:05.184466
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com', 'Timeout': 10},
                  'Tags': {'Key': 'Value'},
                  'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']}

# Generated at 2022-06-16 22:37:15.519237
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test simple case
    camel_dict = {'FooBar': 'baz'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': 'baz'}

    # Test nested case
    camel_dict = {'FooBar': {'FooBarBaz': 'baz'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': {'foo_bar_baz': 'baz'}}

    # Test list case
    camel_dict = {'FooBar': ['FooBarBaz', 'baz']}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_

# Generated at 2022-06-16 22:37:26.188021
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '5',
            'Period': '5',
            'SuccessCodes': '200,201',
            'FailureThreshold': '5',
            'Tags': {
                'Key': 'value'
            }
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': '5',
            'period': '5',
            'success_codes': '200,201',
            'failure_threshold': '5',
            'tags': {
                'Key': 'value'
            }
        }
    }
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:37:37.738743
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'test'
        }
    }
