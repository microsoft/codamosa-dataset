

# Generated at 2022-06-16 22:27:58.100031
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:06.774045
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:28:18.758508
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'FailureThreshold': 3,
            'Tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:28:31.082329
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 7}

# Generated at 2022-06-16 22:28:34.744151
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:28:45.840110
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': 3}
    dict2 = {'a': 1, 'b': {'c': 1, 'd': 3}, 'f': 4}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 2}}, {'b': {'d': 3}, 'f': 4})
    assert recursive_diff(dict1, dict1) == None
    assert recursive_diff(dict2, dict2) == None
    dict3 = {'a': 1, 'b': {'c': 1, 'd': {'e': 2, 'f': 3}}, 'g': 4}

# Generated at 2022-06-16 22:28:53.897656
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:29:02.702552
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function."""

    # Test empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test different dictionaries
    assert recursive_diff({'a': 1}, {'b': 2}) == ({'a': 1}, {'b': 2})

    # Test different dictionaries with nested dictionaries
    assert recursive_diff({'a': 1, 'b': {'c': 3}}, {'a': 1, 'b': {'c': 4}}) == ({'b': {'c': 3}}, {'b': {'c': 4}})

    # Test different dictionaries with nested dictionaries and lists

# Generated at 2022-06-16 22:29:13.700158
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5, 'g': 6}}

# Generated at 2022-06-16 22:29:25.046161
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4}
    dict2 = {'a': {'b': {'c': 1, 'd': 3}, 'e': 3}, 'f': 4}
    dict3 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 5}
    dict4 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4, 'g': 5}
    dict5 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4, 'g': 5}

# Generated at 2022-06-16 22:29:39.262603
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:49.605836
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:01.442236
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}, reversible=True) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:30:13.859534
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:21.957791
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:30:34.334865
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:42.470492
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': '5',
            'Period': '60'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:30:53.321650
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 1,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:04.616119
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:16.418102
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:27.569182
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10,
            'period': 60,
            'success_codes': '200,201,202',
            'tags': {
                'Key': 'Value'
            }
        }
    }



# Generated at 2022-06-16 22:31:38.721528
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Pass': 'pass',
            },
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test',
        },
    }


# Generated at 2022-06-16 22:31:48.040475
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'HTTPPath': '/',
            'HTTPMethod': 'GET',
            'SuccessCodes': '200,201',
            'FailureCodes': '400,404',
            'TimeoutSeconds': '10',
            'IntervalSeconds': '30',
            'UnhealthyThresholdCount': '5',
            'HealthyThresholdCount': '5',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:58.278397
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'endpoint_type': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }
    actual_snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert actual_snake_dict == expected_snake_dict



# Generated at 2022-06-16 22:32:10.010887
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1,
            'MeasureLatency': True,
            'Type': 'HTTP',
            'HTTPCode': [200, 302],
            'Inverted': False,
            'Disabled': False,
            'Regions': ['us-east-1', 'us-west-1'],
            'RegionsList': ['us-east-1', 'us-west-1'],
            'Tags': {
                'key1': 'value1',
                'key2': 'value2'
            }
        }
    }


# Generated at 2022-06-16 22:32:22.168885
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleArn': 'arn:aws:iam::123456789012:role/test'
                    }
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointStatus': 'ACTIVE'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:32.846936
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:45.816373
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}, reversible=True) == {'f_o_o_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBarBaz': 'baz'}}) == {'foo_bar': {'foo_bar_baz': 'baz'}}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBarBaz': 'baz'}}, reversible=True) == {'f_o_o_bar': {'f_o_o_bar_baz': 'baz'}}

# Generated at 2022-06-16 22:32:58.015272
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=True) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=False) == {'http_endpoint': {'http_path': '/foo'}}

# Generated at 2022-06-16 22:33:09.403118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 30,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 5,
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'MyHTTPEndpoint'
            }
        ]
    }


# Generated at 2022-06-16 22:33:19.496186
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:29.495351
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'MyLoadBalancer',
            'Project': 'XYZ'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['http_endpoint']['endpoint'] == 'http://example.com'
    assert snake_dict['http_endpoint']['timeout']

# Generated at 2022-06-16 22:33:41.415430
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'AuthKey': 'abc123',
            'AuthType': 'basic',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'foo'
            },
            'Body': '{"foo": "bar"}',
            'BodyType': 'json',
            'Tags': {
                'Name': 'My HTTP Endpoint'
            }
        }
    }

# Generated at 2022-06-16 22:33:51.721048
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200-299',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': 10,
            'IgnoreHttp1xx': False,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:34:02.212106
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:15.139757
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:25.098048
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 10,
            "Period": 60
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://example.com",
            "Timeout": 10,
            "Period": 60
        },
        "Tags": {
            "Key": "value"
        }
    }


# Generated at 2022-06-16 22:34:35.578218
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:34:47.792861
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test',
            'HTTPEndpointDescription': 'test',
            'ServiceExecutionRole': 'test',
            'EndpointType': 'test',
            'RequireHTTPS': True,
            'HTTPCustomHeaders': [
                {
                    'HeaderName': 'test',
                    'HeaderValue': 'test'
                }
            ],
            'AuthorizationConfig': {
                'AllowAuthorization': True,
                'AuthorizationType': 'test',
                'AuthorizerId': 'test'
            },
            'Tags': [
                {
                    'Key': 'test',
                    'Value': 'test'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:34:54.554093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']
    }


# Generated at 2022-06-16 22:35:12.960184
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:22.320166
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 123,
            'Period': 456,
            'FailureThreshold': 789,
            'SuccessThreshold': 987,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:35:32.712426
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'http',
            'Timeout': 10,
            'Period': 10,
            'FailureThreshold': 10,
            'SuccessThreshold': 10,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:44.819063
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:53.900145
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'URL': 'http://www.example.com', 'Protocol': 'HTTP'},
                  'HTTPSEndpoint': {'URL': 'https://www.example.com', 'Protocol': 'HTTPS'},
                  'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                                      'arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'],
                  'Tags': {'Key': 'Value'}}


# Generated at 2022-06-16 22:36:05.172273
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': '3',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:36:15.710832
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:23.230891
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:33.214711
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:42.215999
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Timeout': 100,
            'HTTPHeaders': [
                {
                    'Name': 'X-Custom-Header',
                    'Value': 'CustomHeaderValue',
                },
            ],
        },
        'Tags': {
            'key1': 'value1',
            'key2': 'value2',
        },
    }

# Generated at 2022-06-16 22:37:00.132145
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Timeout': 10,
            'HTTPHeaders': [
                {
                    'Name': 'X-Header',
                    'Value': 'Foo'
                }
            ]
        },
        'Tags': [
            {
                'Key': 'Foo',
                'Value': 'Bar'
            }
        ]
    }


# Generated at 2022-06-16 22:37:11.949989
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'FailureThreshold': 2,
            'SuccessThreshold': 2,
            'MeasureLatency': True,
            'Type': 'HTTP',
            'HTTPCode': [200, 201, 202, 203, 204, 205, 206, 207, 208, 226, 300, 301, 302, 303, 304, 305, 306, 307, 308],
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:37:21.058706
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:37:29.233767
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test the camel_dict_to_snake_dict function
    """


# Generated at 2022-06-16 22:37:40.375620
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'Custom-Value'
            },
            'Body': '{"key": "value"}'
        },
        'Tags': {
            'Name': 'MyName',
            'Environment': 'Production'
        }
    }
