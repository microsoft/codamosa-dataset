

# Generated at 2022-06-16 22:27:59.711040
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200-299',
            'FailureThreshold': 3
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200-299',
            'FailureThreshold': 3
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:28:07.541242
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:28:19.250052
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:28:31.549323
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:43.991735
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:55.624410
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200-299',
            'HTTPMethod': 'GET',
            'Path': '/health',
            'Matcher': {
                'HttpCode': '200-299'
            }
        },
        'Tags': {
            'Name': 'test-app'
        }
    }


# Generated at 2022-06-16 22:29:03.801020
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3
        },
        'e': 4
    }
    dict2 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 4
        },
        'f': 5
    }
    expected = ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})
    assert recursive_diff(dict1, dict2) == expected
    assert recursive_diff(dict2, dict1) == expected


# Generated at 2022-06-16 22:29:14.514462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'BASIC',
                'UserName': 'username',
                'Password': 'password'
            },
            'Headers': {
                'Content-Type': 'application/json'
            }
        }
    }


# Generated at 2022-06-16 22:29:25.254906
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:36.077669
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:49.189360
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:01.094352
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://www.example.com',
                'Authorization': {
                    'Scheme': 'AWS_IAM',
                    'SigningRegion': 'us-east-1',
                    'SigningServiceName': 'execute-api'
                },
                'TimeoutInMillis': 29000
            },
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:30:13.485363
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'https://example.com',
            'Protocol': 'HTTPS',
            'AuthKey': '12345',
            'AuthType': 'AWS_IAM',
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = {
        'http_endpoint': {
            'endpoint_url': 'https://example.com',
            'protocol': 'HTTPS',
            'auth_key': '12345',
            'auth_type': 'AWS_IAM',
            'tags': {
                'Key': 'Value'
            }
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

# Generated at 2022-06-16 22:30:21.799443
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleArn': 'arn:aws:iam::123456789012:role/test-role'
                    }
                }
            },
            'EndpointDescription': 'Test endpoint',
            'EndpointStatus': 'ACTIVE',
            'Tags': {
                'Tag1': 'Value1',
                'Tag2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:30:34.192166
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:42.376994
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'https://example.com',
            'protocol': 'HTTPS'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict
    assert camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:53.286210
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:04.575198
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://localhost:8080",
            "Timeout": 30,
            "Period": 60
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://localhost:8080",
            "Timeout": 30,
            "Period": 60
        },
        "Tags": {
            "Name": "MyName",
            "Environment": "Production"
        }
    }


# Generated at 2022-06-16 22:31:16.420018
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:25.673496
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:38.816903
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_bar': {'foo_b_ar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, ignore_list=['fooBar']) == {'foo_bar': {'fooBar': 'baz'}}
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:31:48.096714
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Protocol': 'HTTP',
            'Method': 'GET',
            'TimeoutInSeconds': 30,
            'HTTPAuthentication': {
                'Username': 'username',
                'Password': 'password',
                'Type': 'BASIC'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:31:58.959595
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 3,
            'MeasureLatency': True,
            'Enabled': True,
            'Tags': {
                'Name': 'MyEndpoint',
                'Environment': 'Production'
            }
        }
    }


# Generated at 2022-06-16 22:32:10.252759
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'none',
                'User': '',
                'Password': ''
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key": "value"}'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:22.463144
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://localhost:8080/',
            'Timeout': '10',
            'HTTPHeaders': [
                {
                    'Name': 'X-Auth-Token',
                    'Value': '12345'
                }
            ]
        },
        'Tags': {
            'Name': 'Test',
            'Environment': 'Test'
        }
    }


# Generated at 2022-06-16 22:32:30.821360
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:43.828774
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'baz': 'qux',
            'quux': 'corge',
            'grault': 'garply',
            'waldo': 'fred',
            'plugh': 'xyzzy',
            'thud': '',
            'HTTPEndpoint': 'http://example.com',
            'HTTPSEndpoint': 'https://example.com',
            'Tags': {
                'foo': 'bar',
                'baz': 'qux'
            }
        }
    }


# Generated at 2022-06-16 22:32:54.419813
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:33:04.310378
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:15.581246
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:33:25.146809
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 1}, 'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'timeout': 1}, 'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:33:36.843947
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'HTTPEndpointURL': 'test',
            'AuthorizationType': 'test',
            'AuthorizerId': 'test',
            'EndpointConfiguration': {
                'Types': ['test']
            },
            'Tags': {
                'Key': 'test'
            }
        }
    }


# Generated at 2022-06-16 22:33:46.756958
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "URL": "https://example.com/endpoint"
            },
            "Id": "endpoint-id",
            "Name": "endpoint-name"
        }
    }
    expected_dict = {
        "h_t_t_p_endpoint": {
            "h_t_t_p_endpoint_configuration": {
                "url": "https://example.com/endpoint"
            },
            "id": "endpoint-id",
            "name": "endpoint-name"
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:33:54.435712
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:04.065326
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:34:16.994093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'HTTPBasicAuth': {
                        'Password': 'password',
                        'Username': 'username'
                    }
                }
            },
            'EndpointDescription': 'string',
            'EndpointName': 'string'
        },
        'Tags': {
            'Tag': {
                'Key': 'string',
                'Value': 'string'
            }
        }
    }


# Generated at 2022-06-16 22:34:28.213260
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080/',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            'Tags': {
                'Environment': 'Test',
                'Service': 'TestService'
            }
        }
    }


# Generated at 2022-06-16 22:34:37.422950
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}, reversible=True) == {'f_o_o_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBar': 'baz'}}, reversible=True) == {'f_o_o_bar': {'f_o_o_bar': 'baz'}}
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:34:48.825652
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'https://example.com',
            'Timeout': 1,
            'HTTPPath': '/',
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Password': 'password',
            },
            'Headers': {
                'Content-Type': 'application/json',
            },
            'Body': '{"key": "value"}',
            'Response': {
                'Status': [200],
                'Body': '{"key": "value"}',
                'Headers': {
                    'Content-Type': 'application/json',
                },
            },
        },
        'Tags': {
            'key': 'value',
        },
    }

    snake

# Generated at 2022-06-16 22:34:57.870861
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test for simple dictionary
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 1
        }
    }
    expected_snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 1
        },
        'https_endpoint': {
            'endpoint': 'https://localhost:8080',
            'timeout': 1
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict

    # Test for dictionary with list

# Generated at 2022-06-16 22:35:17.647958
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}) == {'http_endpoint': {'http_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=True) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'HTTPPath': '/foo'}}

# Generated at 2022-06-16 22:35:27.431917
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': '30',
            'Period': '300'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': '30',
            'Period': '300'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:37.388999
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:45.049283
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:52.260914
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-16 22:35:58.912752
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': '200',
            'Region': 'us-east-1',
            'FailureThreshold': 1,
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['http_endpoint']['endpoint'] == 'http://example.com'
    assert snake_dict['http_endpoint']['timeout'] == 1

# Generated at 2022-06-16 22:36:10.554812
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202,203,204,205,206,207,208,226,300,301,302,303,304,305,306,307,308',
            'FailureThreshold': 10,
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:36:19.804182
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'FailureThreshold': '5'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'FailureThreshold': '5'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:36:31.386079
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:36:38.715383
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 5000,
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleArn': 'arn:aws:iam::123456789012:role/test-role'
                    }
                }
            },
            'HTTPContentType': 'application/json',
            'HTTPContentEncoding': 'gzip',
            'EndpointDescription': 'Test HTTP Endpoint',
            'EndpointStatus': 'ACTIVE',
            'FailureCode': 'REQUEST_TIMEOUT',
            'FailureDescription': 'Request timed out'
        }
    }

    expected_sn

# Generated at 2022-06-16 22:36:58.090332
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://localhost:8080",
            "Timeout": 10,
            "Period": 10,
            "SuccessCodes": "200,201,202",
            "FailureCodes": "500,501,502",
            "Tags": {
                "HTTPEndpoint": "http://localhost:8080",
                "Timeout": 10,
                "Period": 10,
                "SuccessCodes": "200,201,202",
                "FailureCodes": "500,501,502"
            }
        }
    }

# Generated at 2022-06-16 22:37:09.412566
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:13.643701
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Auth': {
                'Type': 'NONE',
                'Members': [
                    'arn:aws:iam::123456789012:user/Alice',
                    'arn:aws:iam::123456789012:user/Bob'
                ]
            }
        },
        'Tags': {
            'Key1': 'Value1',
            'Key2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:37:24.887083
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:32.550466
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test a simple dictionary
    camel_dict = {'fooBar': 'baz'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': 'baz'}

    # Test a dictionary with a nested dictionary
    camel_dict = {'fooBar': 'baz', 'nested': {'fooBar': 'baz'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': 'baz', 'nested': {'foo_bar': 'baz'}}

    # Test a dictionary with a nested list
    camel_dict = {'fooBar': 'baz', 'nested': [{'fooBar': 'baz'}]}
    snake