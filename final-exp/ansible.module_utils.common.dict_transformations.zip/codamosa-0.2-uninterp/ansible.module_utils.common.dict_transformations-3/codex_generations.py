

# Generated at 2022-06-16 22:28:05.138274
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 7}}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6, 'i': 7}}}

# Generated at 2022-06-16 22:28:17.729792
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:22.418659
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:28:29.819772
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:28:42.232029
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test empty dictionary and non-empty dictionary
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})

    # Test non-empty dictionary and empty dictionary
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})

    # Test non-empty dictionaries with no differences
    assert recursive_diff({'a': 1}, {'a': 1}) is None

    # Test non-empty dictionaries with differences
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    # Test non-empty dictionaries with nested differences

# Generated at 2022-06-16 22:28:49.596904
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}

# Generated at 2022-06-16 22:28:57.486066
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 2, 'b': {'c': 3, 'f': 5}, 'g': 6}
    c = {'a': 2, 'b': {'c': 3, 'd': 3, 'f': 5}, 'e': 4, 'g': 6}
    d = dict_merge(a, b)
    assert d == c



# Generated at 2022-06-16 22:29:09.447021
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 7}}}
    assert recursive_diff(dict1, dict2) == ({'c': {'f': {'h': 6}}}, {'c': {'f': {'h': 7}}})
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    assert recursive_diff(dict1, dict2) == None

# Generated at 2022-06-16 22:29:17.779365
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test 1: Test for empty dictionaries
    dict1 = {}
    dict2 = {}
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Test 2: Test for dictionaries with same content
    dict1 = {'key1': 'value1', 'key2': 'value2'}
    dict2 = {'key1': 'value1', 'key2': 'value2'}
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Test 3: Test for dictionaries with different content
    dict1 = {'key1': 'value1', 'key2': 'value2'}
    dict2 = {'key1': 'value1', 'key2': 'value3'}

# Generated at 2022-06-16 22:29:29.108595
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == ({}, {'b': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, {})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 3}) == ({'b': 2}, {'b': 3})

# Generated at 2022-06-16 22:29:39.111360
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com/endpoint',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointName': 'test_endpoint',
            'EndpointStatus': 'ACTIVE',
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:29:44.695266
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:51.581220
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com/endpoint',
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AuthorizationHeader': 'AuthorizationHeader'
                }
            },
            'EndpointName': 'endpoint_name',
            'EndpointType': 'endpoint_type',
            'EndpointStatus': 'endpoint_status',
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:30:03.059200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://www.example.com/endpoint'
            },
            'Id': 'endpoint-id'
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_configuration': {
                'url': 'https://www.example.com/endpoint'
            },
            'id': 'endpoint-id'
        }
    }
    camel_dict = snake_dict_to_camel_dict(snake_dict)

# Generated at 2022-06-16 22:30:15.169831
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Enabled': True,
            'TimeoutSeconds': 60,
            'PeriodSeconds': 60,
            'SuccessThreshold': 1,
            'FailureThreshold': 3,
            'Tags': {
                'Name': 'my-http-endpoint',
                'Environment': 'test'
            }
        }
    }

# Generated at 2022-06-16 22:30:26.382927
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:37.173778
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "URL": "https://example.com/endpoint",
                "Authorization": {
                    "Type": "AWS_IAM",
                    "AuthorizationHeader": "EXAMPLE"
                }
            },
            "EndpointType": "HTTP"
        },
        "Tags": {
            "Key": "Value"
        }
    }


# Generated at 2022-06-16 22:30:49.895973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:01.368815
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:08.481442
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'my-endpoint',
            'HTTPEndpointDescription': 'My endpoint',
            'ServiceExecutionRole': 'arn:aws:iam::123456789012:role/service-role/MyRole',
            'EndpointUrl': 'https://my-endpoint.execute-api.us-east-1.amazonaws.com/prod/my-path',
            'EndpointConfiguration': {
                'Types': [
                    'HTTP'
                ]
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:31:21.963689
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointConfiguration': {
                'Types': [
                    'EDGE',
                    'REGIONAL'
                ],
                'HTTPHeaders': [
                    {
                        'Key': 'X-Custom-Header',
                        'Value': 'CustomHeaderValue'
                    }
                ],
                'HTTPPath': '/',
                'HTTPPort': 80,
                'HTTPSPort': 443,
                'Protocol': 'HTTP'
            },
            'EndpointName': 'MyEndpoint',
            'EndpointStatus': 'ENABLED',
            'HostName': 'myendpoint.example.com',
            'Id': '123456789',
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:31:32.723825
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'HTTPHeader': [
                {'Name': 'X-Custom-Header', 'Value': 'CustomValue'}
            ]
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'url': 'http://www.example.com',
            'h_t_t_p_header': [
                {'name': 'X-Custom-Header', 'value': 'CustomValue'}
            ]
        },
        'tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:31:43.992639
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '60',
            'Period': '60',
            'FailureThreshold': '2',
            'SuccessThreshold': '2',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'TCPEndpoint': {
            'Endpoint': 'tcp://localhost:8080',
            'Timeout': '60',
            'Period': '60',
            'FailureThreshold': '2',
            'SuccessThreshold': '2',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test'
        }
    }



# Generated at 2022-06-16 22:31:55.597616
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Enabled': True,
            'TimeoutSeconds': 10,
            'HTTPMethod': 'POST',
            'AuthKey': '1234567890',
            'CustomHeaders': {
                'X-Custom-Header': 'CustomHeaderValue'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:32:06.783669
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointType': 'HTTP',
            'TargetARN': 'arn:aws:sqs:us-east-1:123456789012:my-queue',
            'UseBasePath': True,
            'HTTPMethods': ['GET', 'POST'],
            'TimeoutInSeconds': 30,
            'Authorization': {
                'AuthorizationType': 'AWS_IAM',
                'AuthorizerId': 'ID'
            }
        }
    }


# Generated at 2022-06-16 22:32:19.194395
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Auth': {
                'Type': 'NONE',
                'AuthorizationScopes': [
                    'aws.cognito.signin.user.admin'
                ]
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:28.912975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10,
            'SuccessThreshold': 10,
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:32:36.539471
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'h_t_t_p_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}

# Generated at 2022-06-16 22:32:48.710652
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:00.410205
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:15.418329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'Tags': {
            'Name': 'MyName',
            'Environment': 'Production'
        }
    }


# Generated at 2022-06-16 22:33:26.897159
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://localhost:8080",
            "Timeout": 30,
            "Period": 60,
            "SuccessCodes": "200,202",
            "HTTPMethod": "POST",
            "Path": "/",
            "Matcher": {
                "HttpCode": "200"
            }
        },
        "Tags": {
            "Name": "MyLoadBalancer"
        }
    }

# Generated at 2022-06-16 22:33:38.680860
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:33:48.783381
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 1000
            },
            'Id': 'HTTPEndpoint',
            'Name': 'HTTPEndpoint',
            'Tags': [
                {
                    'Key': 'Key1',
                    'Value': 'Value1'
                },
                {
                    'Key': 'Key2',
                    'Value': 'Value2'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:33:58.782010
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Timeout': '5'
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'url': 'http://www.example.com',
            'timeout': '5'
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict



# Generated at 2022-06-16 22:34:06.270447
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'Baz': 'qux'}}) == {'foo_bar': {'baz': 'qux'}}
    assert camel_dict_to_snake_dict({'FooBar': {'Baz': {'Qux': 'quux'}}}) == {'foo_bar': {'baz': {'qux': 'quux'}}}

# Generated at 2022-06-16 22:34:18.718215
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleArn': 'arn:aws:iam::123456789012:role/my-role'
                    }
                }
            },
            'EndpointDescription': 'My HTTP endpoint',
            'EndpointStatus': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:34:31.590376
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:44.031194
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key": "value"}'
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['http_endpoint']['endpoint'] == 'http://localhost:8080'
    assert snake_dict['http_endpoint']['timeout'] == 5


# Generated at 2022-06-16 22:34:51.986995
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com/endpoint',
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                },
                'RetryCount': 1,
                'RetryInterval': 1
            },
            'Id': 'endpoint-id',
            'RoleArn': 'arn:aws:iam::123456789012:role/service-role/iot-role',
            'Status': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:35:14.036014
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'http_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, ignore_list=['HTTPEndpoint']) == {'http_endpoint': {'URL': 'http://www.example.com'}}
    assert camel_dict_to

# Generated at 2022-06-16 22:35:22.986526
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com'}) == {'http_endpoint': 'http://www.example.com'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com'}, reversible=True) == {'h_t_t_p_endpoint': 'http://www.example.com'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com', 'Tags': {'Key': 'Value'}}) == {'http_endpoint': 'http://www.example.com', 'tags': {'Key': 'Value'}}

# Generated at 2022-06-16 22:35:33.294788
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:45.339674
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:54.362003
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 1000,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AuthorizationHeader': 'EXAMPLE'
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointStatus': 'ACTIVE',
            'DateCreated': '2018-11-01T00:00:00Z',
            'DateLastModified': '2018-11-01T00:00:00Z',
            'ARN': 'arn:aws:cloudwatch:us-east-1:123456789012:logs:endpoint:example-endpoint'
        }
    }
    expected_

# Generated at 2022-06-16 22:36:00.197385
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:11.631968
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }

    snake_dict

# Generated at 2022-06-16 22:36:22.452140
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:36:33.021338
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200-204'
            }
        }
    }

# Generated at 2022-06-16 22:36:42.040538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200',
            'FailureThreshold': '2'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200',
            'FailureThreshold': '2'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:37:12.287017
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': '60',
            'Period': '60',
            'SuccessCodes': '200,201,202',
            'FailureThreshold': '3'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': '60',
            'Period': '60',
            'SuccessCodes': '200,201,202',
            'FailureThreshold': '3'
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:37:23.931809
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:30.640596
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 3,
            'MeasureLatency': True,
            'Inverted': False,
            'Disabled': False,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:37:41.374495
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 10
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict