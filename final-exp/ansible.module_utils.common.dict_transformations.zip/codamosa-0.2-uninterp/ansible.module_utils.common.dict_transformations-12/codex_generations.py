

# Generated at 2022-06-16 22:27:47.955047
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:28:00.228532
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:28:07.774920
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}

# Generated at 2022-06-16 22:28:19.412610
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 1000
            },
            'HTTPContentType': 'application/json',
            'HTTPMethod': 'POST',
            'HTTPHeaders': [
                {
                    'HTTPHeaderName': 'Content-Type',
                    'HTTPHeaderValue': 'application/json'
                }
            ],
            'RetryCount': 3,
            'RetryDelayInMillis': 1000
        },
        'Tags': [
            {
                'Key': 'string',
                'Value': 'string'
            }
        ]
    }


# Generated at 2022-06-16 22:28:31.697902
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    dict3 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict4 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    dict5 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': {'g': 6}}

# Generated at 2022-06-16 22:28:44.111594
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:55.755618
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://www.example.com",
            "EndpointStatus": "ACTIVE",
            "EndpointType": "HTTP",
            "Id": "http-endpoint-1",
            "Tags": {
                "Key": "value"
            }
        },
        "HTTPEndpointConfig": {
            "EndpointType": "HTTP",
            "Name": "http-endpoint-1",
            "Tags": {
                "Key": "value"
            }
        }
    }


# Generated at 2022-06-16 22:29:03.801963
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 5,
            'SuccessCodes': '200',
            'FailureThreshold': 2,
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 1,
            'period': 5,
            'success_codes': '200',
            'failure_threshold': 2,
            'tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:29:10.939856
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:29:16.285281
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:29:30.240953
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:38.448897
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/health',
            'Matcher': '200-299',
            'Region': 'us-east-1',
            'Disabled': False,
            'UnhealthyThreshold': 2,
            'HealthyThreshold': 2,
            'Tags': {
                'Name': 'my-http-endpoint',
                'Environment': 'prod'
            }
        }
    }


# Generated at 2022-06-16 22:29:49.189584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Timeout': 5,
            'HTTPEndpointConfiguration': {
                'RequestConfiguration': {
                    'ContentEncoding': 'NONE',
                    'ContentType': 'application/json',
                    'UseBase64': False
                },
                'AuthorizationType': 'AWS_IAM'
            },
            'Name': 'http_endpoint'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:29:58.877164
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'protocol': 'HTTP',
            'port': 80,
            'path': '/'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:30:11.072012
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointDescription": "Test",
            "HTTPEndpointUrl": "https://test.com",
            "AuthorizationType": "AWS_IAM"
        },
        "Tags": {
            "Key": "Value"
        }
    }
    expected_result = {
        "h_t_t_p_endpoint": {
            "h_t_t_p_endpoint_description": "Test",
            "h_t_t_p_endpoint_url": "https://test.com",
            "authorization_type": "AWS_IAM"
        },
        "tags": {
            "Key": "Value"
        }
    }

# Generated at 2022-06-16 22:30:20.693486
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:33.216026
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:41.191382
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': 'http://example.com',
        'Tags': {
            'Key': 'value',
            'Key2': 'value2'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': 'http://example.com',
        'tags': {
            'Key': 'value',
            'Key2': 'value2'
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict


# Generated at 2022-06-16 22:30:52.662557
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test for empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test for empty dictionary and non-empty dictionary
    assert recursive_diff({}, {'a': 'b'}) == ({}, {'a': 'b'})

    # Test for non-empty dictionary and empty dictionary
    assert recursive_diff({'a': 'b'}, {}) == ({'a': 'b'}, {})

    # Test for non-empty dictionaries
    assert recursive_diff({'a': 'b'}, {'a': 'b'}) is None
    assert recursive_diff({'a': 'b'}, {'a': 'c'}) == ({'a': 'b'}, {'a': 'c'})

# Generated at 2022-06-16 22:31:03.947531
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:18.527021
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['http_endpoint']['endpoint'] == 'http://localhost:8080'
    assert snake_dict['http_endpoint']['timeout'] == 3
    assert snake_dict['http_endpoint']['period']

# Generated at 2022-06-16 22:31:27.354326
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:38.521263
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'FailureThreshold': 3,
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:31:47.925482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_description',
            'ServiceExecutionRole': 'test_role',
            'EndpointUrl': 'test_url',
            'EndpointConfiguration': {
                'Types': ['test_type']
            },
            'Tags': {
                'TagKey': 'test_key',
                'TagValue': 'test_value'
            }
        }
    }


# Generated at 2022-06-16 22:31:58.847837
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Protocol': 'HTTPS'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:32:10.158019
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'EndpointType': 'HTTP',
            'Id': 'http-endpoint-1',
            'Name': 'http-endpoint-1',
            'Tags': {
                'Key': 'value'
            }
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'endpoint_type': 'HTTP',
            'id': 'http-endpoint-1',
            'name': 'http-endpoint-1',
            'tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:32:22.332402
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 12345
            },
            'Id': 'id',
            'Name': 'name',
            'Tags': {
                'Key1': 'Value1',
                'Key2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:32:33.109219
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.example.com',
            'TimeoutInSeconds': 10,
            'Authorization': {
                'Type': 'AWS_IAM',
                'AuthorizationHeader': 'AuthorizationHeader'
            },
            'Tags': {
                'Tag': [
                    {
                        'Key': 'Key',
                        'Value': 'Value'
                    }
                ]
            }
        }
    }


# Generated at 2022-06-16 22:32:39.416507
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Path': '/',
            'Protocol': 'HTTP',
            'TimeoutInMillis': 5000,
            'HTTPMethod': 'GET',
            'SuccessCodes': '200,201,202',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'my-service',
            'Environment': 'production'
        }
    }

# Generated at 2022-06-16 22:32:50.629545
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://example.com',
            'AuthorizationConfig': {
                'AuthorizationType': 'AWS_IAM',
                'AWSRegion': 'us-east-1'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = {
        'http_endpoint': {
            'http_endpoint_url': 'http://example.com',
            'authorization_config': {
                'authorization_type': 'AWS_IAM',
                'aws_region': 'us-east-1'
            }
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake

# Generated at 2022-06-16 22:33:00.651846
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'string',
                'Value': 'string'
            }
        ]
    }


# Generated at 2022-06-16 22:33:13.522970
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "URL": "http://example.com",
            "Timeout": "10",
            "HTTPHeaders": [
                {
                    "Name": "header1",
                    "Value": "value1"
                },
                {
                    "Name": "header2",
                    "Value": "value2"
                }
            ]
        },
        "Tags": [
            {
                "Key": "tag1",
                "Value": "value1"
            },
            {
                "Key": "tag2",
                "Value": "value2"
            }
        ]
    }


# Generated at 2022-06-16 22:33:24.892016
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'HTTPHeaders': [
                {
                    'Name': 'X-Test-Header',
                    'Value': 'Test-Value'
                }
            ]
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'h_t_t_p_headers': [
                {
                    'name': 'X-Test-Header',
                    'value': 'Test-Value'
                }
            ]
        },
        'tags': {
            'Key': 'Value'
        }
    }
    snake_

# Generated at 2022-06-16 22:33:36.626314
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://example.com',
            'Authorization': {
                'AuthorizationType': 'AWS_IAM',
                'AWS_IAM': {
                    'SigningRegion': 'us-east-1',
                    'SigningServiceName': 'execute-api'
                }
            },
            'TimeoutInMillis': 29000,
            'IdleTimeoutInMillis': 29000
        },
        'TCPEndpoint': {
            'TCPEndpointURL': 'tcp://example.com:80'
        }
    }


# Generated at 2022-06-16 22:33:47.351500
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 10,
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS',
            'TimeoutInSeconds': 10,
        },
        'Tags': {
            'Key': 'Value',
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
        ],
    }


# Generated at 2022-06-16 22:33:54.892402
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:34:04.363022
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:34:17.309464
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:34:28.856562
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:37.757473
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com/endpoint',
                'TimeoutInMillis': 5000,
            },
            'HTTPContentType': 'application/json',
            'HTTPMethod': 'POST',
            'Tags': {
                'Key': 'Value',
            },
        },
        'HTTPEndpointName': 'MyEndpoint',
        'HTTPEndpointDescription': 'MyEndpointDescription',
    }


# Generated at 2022-06-16 22:34:50.808760
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '1',
            'Period': '1',
            'SuccessCodes': '200',
            'FailureThreshold': '1',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['h_t_t_p_endpoint']['endpoint'] == 'http://example.com'
    assert snake_dict['h_t_t_p_endpoint']['timeout'] == '1'

# Generated at 2022-06-16 22:34:58.925915
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:06.420942
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Auth': {
                'Type': 'NONE'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'protocol': 'HTTP',
            'port': 80,
            'path': '/',
            'auth': {
                'type': 'NONE'
            }
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-16 22:35:17.919887
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://www.example.com/endpoint',
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointName': 'test-endpoint',
            'EndpointType': 'HTTP',
            'EndpointStatus': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:35:27.728531
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'HTTPEndpointUrl': 'test',
            'AuthorizationConfig': {
                'AuthorizationType': 'test',
                'AwsIamConfig': {
                    'SigningRegion': 'test',
                    'SigningServiceName': 'test'
                }
            },
            'EndpointConfiguration': {
                'Types': ['test']
            },
            'Tags': {
                'test': 'test'
            }
        }
    }


# Generated at 2022-06-16 22:35:38.071620
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:35:49.301852
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Timeout': 123
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:35:56.871791
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:09.405772
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:36:19.125264
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 5,
            'Period': 60
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:36:45.562361
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202,204',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:36:53.500175
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://localhost:8080', 'Timeout': 1}, 'Tags': {'Key': 'value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://localhost:8080', 'timeout': 1}, 'tags': {'Key': 'value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:37:02.655594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com/'
            },
            'HTTPEndpointDescription': 'Test HTTPEndpoint',
            'HTTPEndpointName': 'TestHTTPEndpoint'
        },
        'HTTPContentType': 'application/json',
        'HTTPMethod': 'POST',
        'Tags': {
            'Tag': [
                {
                    'Key': 'TestKey',
                    'Value': 'TestValue'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:37:13.745738
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:24.968661
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:32.577317
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
