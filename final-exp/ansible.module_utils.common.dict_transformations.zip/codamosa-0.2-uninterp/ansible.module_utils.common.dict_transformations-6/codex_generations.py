

# Generated at 2022-06-16 22:27:53.552344
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 30,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 30,
            'Period': 60
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }

# Generated at 2022-06-16 22:28:03.861523
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 5
        },
        'g': 6
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 6
        },
        'h': 6
    }
    expected = ({
        'c': {
            'f': 5
        },
        'g': 6
    }, {
        'c': {
            'f': 6
        },
        'h': 6
    })
    assert recursive_diff(dict1, dict2) == expected

# Generated at 2022-06-16 22:28:13.059563
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    b = {'a': 1, 'b': {'c': 20, 'd': 30}, 'e': 40, 'g': 6}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'b': {'c': 20, 'd': 30}, 'e': 40, 'f': 5, 'g': 6}



# Generated at 2022-06-16 22:28:22.484557
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Key": "Value"
        },
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"
        ]
    }

# Generated at 2022-06-16 22:28:34.706239
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 30,
            'Period': 60
        },
        'MetricRules': [
            {
                'MetricName': 'CPUUtilization',
                'ComparisonOperator': 'GreaterThanThreshold',
                'Threshold': 90.0,
                'EvaluationPeriods': 1,
                'Period': 60,
                'Statistic': 'Average',
                'Namespace': 'AWS/EC2',
                'Unit': 'Percent',
                'Dimensions': [
                    {
                        'Name': 'InstanceId',
                        'Value': 'i-12345678'
                    }
                ]
            }
        ]
    }

# Generated at 2022-06-16 22:28:43.991331
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com/'
            }
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_configuration': {
                'endpoint_u_r_l': 'https://www.example.com/'
            }
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:28:53.748350
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 1}, 'HTTPSEndpoint': {'Endpoint': 'https://www.example.com', 'Timeout': 2}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'timeout': 1}, 'h_t_t_p_s_endpoint': {'endpoint': 'https://www.example.com', 'timeout': 2}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:29:02.598658
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    assert dict_merge(a, b) == a
    b = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    assert dict_merge(a, b) == b
    b = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5, 'g': {'h': 6}}
    assert dict_merge(a, b) == b

# Generated at 2022-06-16 22:29:13.571481
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:24.805980
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200',
            'HTTPMethod': 'GET',
            'FailureThreshold': 2,
            'Disabled': False,
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:29:38.823120
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1,
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1,
        },
        'Tags': {
            'key': 'value',
        }
    }


# Generated at 2022-06-16 22:29:47.911883
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200',
            'FailureThreshold': 10
        }
    }

    snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 10,
            'period': 10,
            'success_codes': '200',
            'failure_threshold': 10
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:29:55.617405
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:07.630299
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'HTTPMethod': 'GET',
            'HTTPPath': '/',
            'Auth': {
                'Type': 'BASIC',
                'User': 'username',
                'Password': 'password'
            },
            'Headers': {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            'Body': '{"key": "value"}',
            'BodyFrom': 'body_from'
        }
    }


# Generated at 2022-06-16 22:30:18.463727
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'h_t_t_p_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}

# Generated at 2022-06-16 22:30:31.134327
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:40.607506
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://www.example.com",
            "Timeout": 3
        },
        "Tags": {
            "Key1": "Value1",
            "Key2": "Value2"
        },
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"
        ]
    }


# Generated at 2022-06-16 22:30:52.390262
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:03.688224
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:15.655331
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"foo": "bar"}',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Password': 'password'
            }
        }
    }


# Generated at 2022-06-16 22:31:31.762014
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10,
            'SuccessThreshold': 10,
            'InsufficientDataThreshold': 10,
            'MeasureLatency': True,
            'RequestInterval': 10,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:31:43.197794
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:55.177839
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'https://example.com',
            'HTTPEndpointConfiguration': {
                'TimeoutInSeconds': 60
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['http_endpoint']['http_endpoint_url'] == 'https://example.com'
    assert snake_dict['http_endpoint']['http_endpoint_configuration']['timeout_in_seconds'] == 60
    assert snake_dict['tags']['Key'] == 'Value'

    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)

# Generated at 2022-06-16 22:32:06.448773
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'HTTPUsername': 'username',
            'HTTPPassword': 'password',
            'HTTPCustomHeaders': {
                'X-Custom-Header': 'value'
            },
            'HTTPCustomQueryParameters': {
                'param': 'value'
            },
            'HTTPCustomRequestBody': 'body'
        }
    }


# Generated at 2022-06-16 22:32:18.760923
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:28.566473
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Tag': {
                    'Key': 'Name',
                    'Value': 'MyHTTPEndpoint'
                }
            }
        }
    }


# Generated at 2022-06-16 22:32:40.662433
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBaz': 'baz'}}) == {'foo_bar': {'foo_baz': 'baz'}}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBaz': 'baz'}}, reversible=True) == {'f_o_o_bar': {'f_o_o_baz': 'baz'}}

# Generated at 2022-06-16 22:32:51.386146
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:33:02.374203
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:14.176759
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Key": "Value"
        }
    }
    snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "protocol": "HTTP"
        },
        "tags": {
            "Key": "Value"
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert snake_dict_to_camel_dict(snake_dict) == camel_dict


# Generated at 2022-06-16 22:33:27.531172
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'Tags': {
                'Name': 'test',
                'Environment': 'test'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:33:39.518866
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True, ignore_list=['fooBar']) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'bazBar': 'baz'}}) == {'foo_bar': {'baz_bar': 'baz'}}

# Generated at 2022-06-16 22:33:49.318388
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 1
        },
        "Tags": {
            "Key": "value"
        },
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"
        ]
    }


# Generated at 2022-06-16 22:34:00.871104
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'my-endpoint',
            'HTTPEndpointDescription': 'My endpoint',
            'ServiceExecutionRole': 'arn:aws:iam::123456789012:role/service-role/MyRole',
            'EndpointType': 'READER',
            'VpcConfiguration': {
                'SubnetIds': [
                    'subnet-12345678',
                    'subnet-87654321'
                ],
                'SecurityGroupIds': [
                    'sg-12345678'
                ]
            },
            'Tags': {
                'TagKey': 'TagValue'
            }
        }
    }


# Generated at 2022-06-16 22:34:13.137880
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointName': 'test-endpoint',
            'EndpointStatus': 'ACTIVE',
            'Tags': {
                'Key': 'value'
            }
        }
    }

# Generated at 2022-06-16 22:34:18.052666
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'https://example.com',
            'Protocol': 'HTTPS',
            'Attributes': {
                'AttributeName': 'AttributeValue'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint_url': 'https://example.com',
            'protocol': 'HTTPS',
            'attributes': {
                'attribute_name': 'AttributeValue'
            }
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_dict


# Unit test

# Generated at 2022-06-16 22:34:25.444374
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 3
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:34:35.849030
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:47.831525
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:34:55.616566
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com'
            },
            'Id': 'HTTPEndpointId'
        }
    }
    snake_dict = {
        'http_endpoint': {
            'http_endpoint_configuration': {
                'endpoint_url': 'https://www.example.com'
            },
            'id': 'HTTPEndpointId'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:35:13.556070
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP",
            "TimeoutInSeconds": 60
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://example.com",
            "Protocol": "HTTPS",
            "TimeoutInSeconds": 60
        },
        "Tags": {
            "Key": "value"
        }
    }

# Generated at 2022-06-16 22:35:22.864084
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:33.213314
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:45.252452
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 5,
            'HTTPMethod': 'GET',
            'AuthToken': 'token',
            'Headers': {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            'Body': '{"key": "value"}'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:35:54.299233
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:00.163361
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:11.632329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBarBaz': 'baz'}}) == {'foo_bar': {'foo_bar_baz': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBarBaz': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar_baz': 'baz'}}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:36:22.451282
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com/endpoint',
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointName': 'endpoint-name',
            'EndpointType': 'HTTP',
            'TargetArn': 'arn:aws:lambda:us-east-1:123456789012:function:my-function',
            'Tags': {
                'Tag1': 'Value1',
                'Tag2': 'Value2'
            }
        }
    }

    expected_

# Generated at 2022-06-16 22:36:33.021241
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:42.040975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test',
            'HTTPEndpointDescription': 'test',
            'ServiceExecutionRole': 'test',
            'EndpointUrl': 'test',
            'EndpointConfiguration': {
                'Types': ['test']
            }
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_name': 'test',
            'h_t_t_p_endpoint_description': 'test',
            'service_execution_role': 'test',
            'endpoint_url': 'test',
            'endpoint_configuration': {
                'types': ['test']
            }
        }
    }

    assert camel_dict

# Generated at 2022-06-16 22:37:21.331548
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }


# Generated at 2022-06-16 22:37:29.481081
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'AuthKey': 'secret',
            'AuthType': 'Basic',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'value'
            },
            'Body': '{"key": "value"}',
            'BodyType': 'text',
            'Tags': {
                'key': 'value'
            }
        }
    }
