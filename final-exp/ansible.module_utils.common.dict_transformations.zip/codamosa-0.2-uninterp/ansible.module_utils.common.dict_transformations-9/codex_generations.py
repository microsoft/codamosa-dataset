

# Generated at 2022-06-16 22:28:07.140968
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointName': 'test-endpoint',
            'EndpointStatus': 'ACTIVE',
            'EndpointType': 'HTTP',
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:28:18.966065
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test case 1:
    # dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    # dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    # expected_result = ({'c': {'e': 4}}, {'c': {'e': 5}})
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    expected_result = ({'c': {'e': 4}}, {'c': {'e': 5}})
    result

# Generated at 2022-06-16 22:28:31.235098
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080/',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'AWSRegion': 'us-east-1',
            'HTTPCheck': True,
            'Tags': {
                'Name': 'test-http-endpoint'
            }
        }
    }


# Generated at 2022-06-16 22:28:43.747967
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5}}}

# Generated at 2022-06-16 22:28:55.409616
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Name': 'test',
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Authorization': {
                'Type': 'NONE'
            },
            'TimeoutInMillis': 10000,
            'HealthyThreshold': {
                'Count': 5,
                'IntervalInSeconds': 5
            },
            'UnhealthyThreshold': {
                'Count': 2,
                'IntervalInSeconds': 2
            },
            'Tags': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }

    expected_

# Generated at 2022-06-16 22:29:03.688059
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }


# Generated at 2022-06-16 22:29:14.447585
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 5,
            'Period': 120
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:29:19.251741
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'FailureThreshold': 2,
        },
        'Tags': {
            'Name': 'foo',
            'Role': 'bar',
        },
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:29:30.240991
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 1,
            'Period': 1
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:29:38.448839
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 12345,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AuthorizationRequestExtraParams': {
                        'Param1': 'value1',
                        'Param2': 'value2'
                    }
                }
            },
            'EndpointDescription': 'This is an endpoint',
            'EndpointStatus': 'ACTIVE'
        },
        'Tags': {
            'Tag1': 'Value1',
            'Tag2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:29:51.327221
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) is None

    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 6}
    assert recursive_diff(dict1, dict2) == ({'f': 5}, {'f': 6})

    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 6}

# Generated at 2022-06-16 22:30:02.551208
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
            },
        },
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 7,
            },
        },
    }
    assert recursive_diff(dict1, dict2) == ({'c': {'f': {'h': 6}}}, {'c': {'f': {'h': 7}}})
    assert recursive_diff(dict1, dict1) is None

# Generated at 2022-06-16 22:30:15.002834
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:26.049043
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:36.917164
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'barBaz': 'baz'}}) == {'foo_bar': {'bar_baz': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'barBaz': 'baz'}}, reversible=True) == {'foo_bar': {'bar_b_a_z': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'barBaz': 'baz'}}, ignore_list=['barBaz']) == {'foo_bar': {'barBaz': 'baz'}}
   

# Generated at 2022-06-16 22:30:49.594870
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:01.272658
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'FailureThreshold': 2
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'FailureThreshold': 2
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:08.449344
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://www.example.com',
                'TimeoutInMillis': 1000,
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointDescription': 'Endpoint description',
            'EndpointStatus': 'ACTIVE'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:18.975610
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointDescription": "test",
            "HTTPEndpointUrl": "test",
            "AuthorizationType": "test",
            "AuthorizerId": "test",
            "Method": "test",
            "TimeoutInMillis": 123,
            "CreationDate": 123,
            "LastModifiedDate": 123
        },
        "HTTPEndpointName": "test",
        "HTTPEndpointARN": "test",
        "Tags": {
            "Tags": [
                {
                    "Key": "test",
                    "Value": "test"
                }
            ]
        }
    }


# Generated at 2022-06-16 22:31:29.443008
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:44.002299
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 5,
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            },
            'InsufficientDataHealthStatus': 'Healthy'
        },
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'MyTargetGroup'
            }
        ]
    }


# Generated at 2022-06-16 22:31:55.597564
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar': 'baz'}}

# Generated at 2022-06-16 22:32:06.783411
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Enabled': True,
            'TimeoutInSeconds': 10,
            'HTTPMethod': 'POST',
            'URIPath': '/',
            'UseProxy': False,
            'HTTPParameters': {
                'Header': [
                    {
                        'Name': 'Content-Type',
                        'Value': 'application/json'
                    }
                ],
                'QueryString': [
                    {
                        'Name': 'foo',
                        'Value': 'bar'
                    }
                ]
            }
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'foo',
                    'Value': 'bar'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:32:19.192522
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 1,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'test'
        }
    }


# Generated at 2022-06-16 22:32:28.912758
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'Tags': {
                'Name': 'Test'
            }
        }
    }
    expected_snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5,
            'period': 60,
            'success_codes': '200,201',
            'disabled': False,
            'tags': {
                'Name': 'Test'
            }
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict

# Generated at 2022-06-16 22:32:41.143253
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:51.907874
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080/',
            'Timeout': 1,
            'Period': 1,
            'SuccessCodes': '200',
            'FailureThreshold': 1,
            'HTTPMethod': 'GET'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080/',
            'timeout': 1,
            'period': 1,
            'success_codes': '200',
            'failure_threshold': 1,
            'http_method': 'GET'
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict


# Generated at 2022-06-16 22:33:02.603046
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:33:08.623054
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:18.125396
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4}
    dict3 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    dict4 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4, 'f': 5}
    dict5 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4, 'f': 6}

# Generated at 2022-06-16 22:33:30.427808
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.example.com',
            'Timeout': 3,
            'HTTPMethod': 'POST',
            'Username': 'username',
            'Password': 'password',
            'AuthType': 'BasicAuth',
            'KmsKeyId': '1234abcd-12ab-34cd-56ef-1234567890ab',
            'HTTPContentType': 'application/json',
            'RetryCount': 1,
            'RetryInterval': 30,
            'Headers': {
                'Content-Type': 'application/json',
                'Content-Length': '1024'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    expected_snake_dict

# Generated at 2022-06-16 22:33:42.231596
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://example.com",
            "Protocol": "HTTPS"
        },
        "Tags": {
            "Key": "value"
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:33:52.725087
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True, ignore_list=['fooBar']) == {'foo_bar': {'fooBar': 'baz'}}
    assert camel_dict_to

# Generated at 2022-06-16 22:34:02.911802
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for simple dict
    camel_dict = {'HTTPEndpoint': 'http://example.com'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'http_endpoint': 'http://example.com'}

    # Test for nested dict
    camel_dict = {'HTTPEndpoint': {'HTTPEndpoint': 'http://example.com'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'http_endpoint': {'http_endpoint': 'http://example.com'}}

    # Test for list
    camel_dict = {'HTTPEndpoint': ['http://example.com']}

# Generated at 2022-06-16 22:34:15.608910
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Timeout': 10,
            'HTTPHeaders': [
                {
                    'Name': 'Content-Type',
                    'Value': 'application/json'
                },
                {
                    'Name': 'Content-Length',
                    'Value': '123'
                }
            ]
        },
        'Tags': {
            'Tag1': 'Value1',
            'Tag2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:34:25.455302
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://www.example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'EDGE'
        }
    }


# Generated at 2022-06-16 22:34:35.849468
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 10,
            "Period": 60,
            "SuccessCodes": "200,201",
            "HTTPMethod": "POST",
            "AuthKey": "key",
            "AuthType": "none",
            "CustomHeaders": {
                "X-Custom-Header": "value"
            }
        },
        "Tags": {
            "Name": "test"
        }
    }


# Generated at 2022-06-16 22:34:47.128472
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict, reversible=True) == camel_dict



# Generated at 2022-06-16 22:34:56.615138
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Key": "Value"
        },
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"
        ]
    }

# Generated at 2022-06-16 22:35:05.682513
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 1,
            'Period': 1
        },
        'Tags': {
            'Tag': {
                'Key': 'key',
                'Value': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:35:19.583309
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:27.683158
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:37.959731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}, reversible=True) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:35:49.226021
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:56.814389
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:09.365431
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:19.089293
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:36:30.721798
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '30',
            'Period': '60',
            'FailureThreshold': '3'
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': '30',
            'Period': '60',
            'FailureThreshold': '3'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:36:38.267513
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:46.508036
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Protocol': 'HTTPS',
            'Method': 'POST',
            'Auth': {
                'Type': 'AWS_IAM',
                'AWS4Signer': {
                    'ServiceName': 'service',
                    'Region': 'us-east-1',
                    'AccessKey': 'access_key',
                    'SecretKey': 'secret_key',
                }
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:36:59.911392
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': 3}
    dict2 = {'a': 1, 'b': {'c': 1, 'd': 3}, 'f': 4}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 2}}, {'b': {'d': 3}, 'f': 4})

    dict1 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': 3}
    dict2 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': 3}
    assert recursive_diff(dict1, dict2) == None


# Generated at 2022-06-16 22:37:11.706343
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.common._collections_compat import MappingView
    from ansible.module_utils.common._collections_compat import KeysView
    from ansible.module_utils.common._collections_compat import ItemsView
    from ansible.module_utils.common._collections_compat import ValuesView

# Generated at 2022-06-16 22:37:23.784023
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': {
                'f': 4,
                'g': 5
            }
        }
    }
    dict2 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': {
                'f': 4,
                'g': 6
            }
        }
    }
    dict3 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': {
                'f': 4,
                'g': 5
            }
        }
    }

# Generated at 2022-06-16 22:37:30.565807
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}

# Generated at 2022-06-16 22:37:41.055093
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 5,
        },
        'g': 6,
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 6,
        },
        'g': 7,
    }
    expected = ({'c': {'f': 5}, 'g': 6}, {'c': {'f': 6}, 'g': 7})
    assert recursive_diff(dict1, dict2) == expected
    assert recursive_diff(dict2, dict1) == expected