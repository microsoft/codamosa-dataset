

# Generated at 2022-06-16 22:28:00.941602
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'FailureThreshold': 5,
            'MeasureLatency': True,
            'InsufficientDataHealthStatus': 'Healthy',
            'Enabled': True,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:28:08.121491
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 123,
            'Period': 456,
            'SuccessCodes': '200,201',
            'FailureThreshold': 789,
        },
        'Tags': {
            'Key': 'value',
        },
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 123,
            'period': 456,
            'success_codes': '200,201',
            'failure_threshold': 789,
        },
        'tags': {
            'Key': 'value',
        },
    }

# Generated at 2022-06-16 22:28:19.649075
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'AuthKey': '12345',
            'AuthType': 'basic',
            'CustomHeaders': {
                'X-Custom-Header': 'value'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:28:32.080868
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 7}}}
    assert recursive_diff(dict1, dict2) == ({'c': {'f': {'h': 6}}}, {'c': {'f': {'h': 7}}})
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}

# Generated at 2022-06-16 22:28:44.237878
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:28:56.136160
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 5}
    dict3 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict4 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    dict5 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': {'g': 6}}

# Generated at 2022-06-16 22:29:00.247864
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': {'c': 1, 'd': 2}}}
    b = {'a': {'b': {'e': 3}}}
    c = {'a': {'b': {'c': 1, 'd': 2, 'e': 3}}}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:29:11.632521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar': 'baz'}}

# Generated at 2022-06-16 22:29:22.322949
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Port': 80,
            'Protocol': 'HTTP',
            'Timeout': 3,
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:29:33.640770
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:48.139081
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Tags': {
                'Key': 'Value'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:29:59.494978
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://www.example.com',
            'HTTPEndpointConfiguration': {
                'HTTPEndpointRequestConfiguration': {
                    'ContentHandlingStrategy': 'CONVERT_TO_TEXT'
                },
                'HTTPEndpointResponseConfiguration': {
                    'StatusCode': '200'
                }
            }
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }

# Generated at 2022-06-16 22:30:11.800923
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:21.115632
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:33.564121
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Password': 'password'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:30:45.650741
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 1
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test'
        }
    }


# Generated at 2022-06-16 22:30:54.827942
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:05.705250
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 10,
            'MeasureLatency': True,
            'Enabled': True,
            'Regions': ['us-east-1', 'us-west-1'],
            'InsufficientDataHealthStatus': 'Healthy',
            'ChildHealthChecks': ['child-health-check-1', 'child-health-check-2'],
            'Inverted': False,
            'HealthThreshold': 10,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:31:16.997653
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 'qux'}}) == {'foo_bar': {'baz': 'qux'}}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 'qux'}}, reversible=True) == {'foo_bar': {'baz': 'qux'}}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 'qux'}}, reversible=True, ignore_list=['baz']) == {'foo_bar': {'baz': 'qux'}}
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:31:24.243093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 1
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:31:42.906805
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Enabled': True
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:31:55.177960
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.example.com',
            'TimeoutInMillis': 123,
            'HTTPMethod': 'POST',
            'UseSignatureVersion4': False,
            'AuthCredentials': {
                'AccessKey': 'AKIAIOSFODNN7EXAMPLE',
                'SecretKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:06.450139
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:18.761375
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 1000,
                'Authorization': {
                    'Type': 'AWS_IAM'
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointStatus': 'ACTIVE'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-16 22:32:28.606338
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:40.734578
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Tags': {
                'Name': 'MyHTTPEndpoint',
                'Environment': 'Test'
            }
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 3,
            'period': 60,
            'success_codes': '200,201',
            'tags': {
                'Name': 'MyHTTPEndpoint',
                'Environment': 'Test'
            }
        }
    }
    assert camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:51.469835
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:02.412503
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 1,
            'Tags': {
                'Name': 'test',
                'Environment': 'test'
            }
        }
    }


# Generated at 2022-06-16 22:33:14.946095
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'FailureThreshold': '2'
        },
        'Tags': {
            'Name': 'test-http-endpoint'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': '5',
            'period': '60',
            'success_codes': '200,201',
            'failure_threshold': '2'
        },
        'tags': {
            'Name': 'test-http-endpoint'
        }
    }

   

# Generated at 2022-06-16 22:33:26.412034
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:03.960114
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:16.993723
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'HTTPEndpointUrl': 'test',
            'AuthorizationConfig': {
                'AuthorizationType': 'test',
                'AWSV4Authorization': {
                    'SigningRegion': 'test',
                    'ServiceName': 'test'
                }
            }
        }
    }


# Generated at 2022-06-16 22:34:26.039634
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:36.265602
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:48.121594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://example.com",
            "Protocol": "HTTPS"
        },
        "Tags": {
            "Key": "value"
        }
    }

# Generated at 2022-06-16 22:34:57.401784
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:05.829584
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:17.408206
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Disabled': False,
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }


# Generated at 2022-06-16 22:35:25.989993
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "URL": "http://example.com",
            "Timeout": 10,
            "HTTPMethod": "POST",
            "Headers": {
                "Content-Type": "application/json"
            },
            "Body": "{\"foo\": \"bar\"}"
        },
        "HTTPEndpoint2": {
            "URL": "http://example.com",
            "Timeout": 10,
            "HTTPMethod": "POST",
            "Headers": {
                "Content-Type": "application/json"
            },
            "Body": "{\"foo\": \"bar\"}"
        },
        "Tags": {
            "Key": "value"
        }
    }


# Generated at 2022-06-16 22:35:35.218864
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Protocol": "HTTPS",
            "Port": 80,
            "Path": "/",
            "Authentication": {
                "Type": "NONE"
            }
        },
        "Tags": {
            "Key": "Value"
        }
    }

    expected_snake_dict = {
        "h_t_t_p_endpoint": {
            "protocol": "HTTPS",
            "port": 80,
            "path": "/",
            "authentication": {
                "type": "NONE"
            }
        },
        "tags": {
            "Key": "Value"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict




# Generated at 2022-06-16 22:35:52.374083
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:58.984669
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:10.602643
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 1,
            "Period": 60,
            "FailureThreshold": 1,
            "SuccessThreshold": 1,
            "Matcher": {
                "HttpCode": "200"
            }
        },
        "TCPEndpoint": {
            "Endpoint": "example.com:80",
            "Timeout": 1,
            "Period": 60,
            "FailureThreshold": 1,
            "SuccessThreshold": 1
        }
    }


# Generated at 2022-06-16 22:36:20.741005
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'foo',
                'Value': 'bar'
            }
        ]
    }


# Generated at 2022-06-16 22:36:32.076076
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 5000,
                'Authorization': {
                    'Scheme': 'AWS4-HMAC-SHA256',
                    'Signature': 'signature'
                }
            },
            'EndpointDescription': 'description',
            'EndpointStatus': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:36:38.960878
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 12345,
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1',
                    'AWSSigningRegion': 'us-east-1',
                    'AWSServiceName': 'execute-api'
                }
            },
            'EndpointDescription': 'This is a test endpoint',
            'EndpointStatus': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:36:45.290457
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:57.246691
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:05.106215
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': '200',
            'FailureThreshold': 3,
            'SuccessThreshold': 1,
        },
        'Tags': {
            'Key': 'value',
        },
    }


# Generated at 2022-06-16 22:37:15.486503
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_endpoint_description',
            'ServiceExecutionRole': 'test_role',
            'EndpointUrl': 'test_endpoint_url',
            'EndpointConfiguration': {
                'Types': ['test_type1', 'test_type2']
            },
            'Tags': {
                'TagKey': 'TagValue'
            }
        }
    }


# Generated at 2022-06-16 22:37:42.335111
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'CustomValue'
            },
            'Body': '{"key": "value"}'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
