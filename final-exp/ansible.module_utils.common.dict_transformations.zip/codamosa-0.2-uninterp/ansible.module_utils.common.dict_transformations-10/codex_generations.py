

# Generated at 2022-06-16 22:27:57.598446
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'grault',
        },
        'waldo': 'fred',
    }
    dict2 = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'garply',
        },
        'waldo': 'fred',
    }
    dict3 = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'garply',
        },
        'waldo': 'fred',
        'plugh': 'xyzzy',
    }

# Generated at 2022-06-16 22:28:06.558234
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test for empty dictionaries
    assert recursive_diff({}, {}) is None

    # Test for different dictionaries
    assert recursive_diff({'a': 1}, {'b': 2}) == ({'a': 1}, {'b': 2})

    # Test for dictionaries with nested dictionaries
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}}) == ({'a': {'b': 1}}, {'a': {'b': 2}})

    # Test for dictionaries with nested dictionaries and different keys
    assert recursive_diff({'a': {'b': 1}}, {'a': {'c': 2}}) == ({'a': {'b': 1}}, {'a': {'c': 2}})

    #

# Generated at 2022-06-16 22:28:18.630735
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
            'key5': {
                'key6': 'value6',
                'key7': 'value7',
            },
        },
    }
    dict2 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
            'key5': {
                'key6': 'value6',
                'key7': 'value7',
            },
        },
    }
    assert recursive_diff(dict1, dict2) is None


# Generated at 2022-06-16 22:28:31.038662
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:28:43.626184
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': {
                'f': 4,
                'g': 5,
                'h': 6
            }
        }
    }
    dict2 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
            'e': {
                'f': 4,
                'g': 5,
                'h': 7
            }
        }
    }

# Generated at 2022-06-16 22:28:55.367103
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}, 'd': 4}
    dict2 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}, 'd': 4}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}, 'd': 4}
    dict2 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}, 'd': 5}

# Generated at 2022-06-16 22:29:03.442152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'URL': 'http://www.example.com', 'Timeout': '10'},
                  'HTTPSEndpoint': {'URL': 'https://www.example.com', 'Timeout': '10'},
                  'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'url': 'http://www.example.com', 'timeout': '10'},
                  'h_t_t_p_s_endpoint': {'url': 'https://www.example.com', 'timeout': '10'},
                  'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:29:14.292771
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test function recursive_diff"""
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    dict3 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}}, {'b': {'d': 4}, 'f': 5})
    assert recursive_diff(dict1, dict3) is None
    assert recursive_diff(dict1, dict1) is None
    assert recursive_diff(dict1, None) is None
    assert recursive_diff(None, dict1) is None

# Generated at 2022-06-16 22:29:25.213689
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'Baz': 'qux'}}) == {'foo_bar': {'baz': 'qux'}}
    assert camel_dict_to_snake_dict({'FooBar': [{'Baz': 'qux'}]}) == {'foo_bar': [{'baz': 'qux'}]}
    assert camel_dict_to_snake_dict({'FooBar': [{'Baz': 'qux'}]}, reversible=True) == {'f_o_o_bar': [{'b_a_z': 'qux'}]}
    assert camel

# Generated at 2022-06-16 22:29:36.042196
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function

    :return: ``True`` if tests pass, ``False`` otherwise.
    """

    # Test 1: dict1 and dict2 are identical
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    result = recursive_diff(dict1, dict2)
    if result is not None:
        return False

    # Test 2: dict1 and dict2 are different
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}

# Generated at 2022-06-16 22:29:50.902046
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 123,
            'Period': 456,
            'FailureThreshold': 789,
            'SuccessThreshold': 987,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['http_endpoint']['endpoint'] == 'http://www.example.com'
    assert snake_dict['http_endpoint']['timeout'] == 123
    assert snake_dict['http_endpoint']['period'] == 456
    assert snake_dict

# Generated at 2022-06-16 22:30:02.162648
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 5}
    b = {'a': 2, 'b': {'c': 4, 'f': 6}, 'g': 7}
    c = {'a': 2, 'b': {'c': 4, 'd': 3, 'f': 6}, 'e': 5, 'g': 7}
    assert dict_merge(a, b) == c
    assert dict_merge(b, a) == c
    assert dict_merge(a, {}) == a
    assert dict_merge({}, a) == a
    assert dict_merge(a, a) == a
    assert dict_merge({}, {}) == {}

# Generated at 2022-06-16 22:30:14.577322
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4', 'f': {'g': '5', 'h': '6'}}}
    dict2 = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4', 'f': {'g': '5', 'h': '7'}}}
    dict3 = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4', 'f': {'g': '5', 'h': '6'}}}

# Generated at 2022-06-16 22:30:19.804808
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 3, 'f': 5}, 'g': 6}
    c = {'a': 1, 'b': {'c': 3, 'd': 3}, 'e': 4, 'g': 6}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:30:26.999485
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    b = {'a': {'b': {'c': 2}}, 'f': 4}
    c = {'a': {'b': {'c': 2, 'd': 2}}, 'e': 3, 'f': 4}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:30:33.776676
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 100,
                'Authorization': {
                    'Type': 'AWS_HMAC',
                    'AWS_HMAC': {
                        'AccessKey': 'AKIAIOSFODNN7EXAMPLE',
                        'SecretKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
                        'Region': 'us-east-1'
                    }
                }
            },
            'EndpointDescription': 'Endpoint description',
            'EndpointStatus': 'ACTIVE'
        }
    }


# Generated at 2022-06-16 22:30:42.080522
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 30,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': 3,
            'ChildHealthchecks': ['chk1', 'chk2'],
            'EnableSNI': True,
            'Regions': ['us-east-1', 'us-west-1'],
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:30:53.107403
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:04.412972
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Protocol': 'http',
            'AuthKey': '12345',
            'Enabled': True,
            'Period': 60,
            'Timeout': 3,
            'HTTPMethod': 'POST',
            'PagerDutyEventDetails': {
                'IncidentKey': '12345',
                'Details': {
                    'foo': 'bar'
                }
            },
            'SlackEventDetails': {
                'Channel': '#general',
                'Details': {
                    'foo': 'bar'
                }
            },
            'Tags': {
                'foo': 'bar'
            }
        }
    }

# Generated at 2022-06-16 22:31:16.419562
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    expected = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == expected
    assert dict_merge(b, a) == expected
    assert dict_merge(a, {}) == a
    assert dict_merge({}, b) == b
    assert dict_merge({}, {}) == {}

# Generated at 2022-06-16 22:31:27.830620
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:36.953044
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict


# Generated at 2022-06-16 22:31:46.815480
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Auth': {
                'Type': 'NONE'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'protocol': 'HTTP',
            'port': 80,
            'path': '/',
            'auth': {
                'type': 'NONE'
            }
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:31:57.807350
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:09.541700
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'FailureThreshold': 3,
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:21.696413
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})
    assert recursive_diff(dict1, dict1) == None
    assert recursive_diff(dict1, dict2) == recursive_diff(dict2, dict1)
    try:
        recursive_diff(dict1, [])
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised"

# Generated at 2022-06-16 22:32:30.362788
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Enabled': True,
            'TimeoutSeconds': 10,
            'HTTPMethod': 'POST',
            'AuthKey': 'secret',
            'CustomHeaders': {
                'X-Custom-Header': 'value'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:32:42.978054
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 30,
            'HTTPMethod': 'POST',
            'Auth': {
                'AuthType': 'AWS_IAM',
                'AWS4SignerType': 'AWS4SignerType',
                'AWS4SignerName': 'AWS4SignerName'
            },
            'Headers': {
                'Content-Type': 'application/json',
                'X-Amz-Target': 'AWSGlue.CreateDevEndpoint'
            },
            'Body': '{}'
        }
    }


# Generated at 2022-06-16 22:32:52.837299
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyCount': 5,
            'UnhealthyCount': 5,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:33:02.713302
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': {'g': 4, 'h': 5}, 'i': 6}}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': {'g': 4, 'h': 5}, 'i': 6}}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': {'g': 4, 'h': 5}, 'i': 6}}

# Generated at 2022-06-16 22:33:15.245566
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict



# Generated at 2022-06-16 22:33:20.553834
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict



# Generated at 2022-06-16 22:33:29.013022
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 10,
            'period': 60
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:33:40.969072
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'TimeoutInMillis': 5000,
            'HealthyThresholdCount': 5,
            'UnhealthyThresholdCount': 2,
            'IntervalInSeconds': 30,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:33:51.269462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test'
        }
    }


# Generated at 2022-06-16 22:34:01.916240
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '60',
            'HTTPMethod': 'POST',
            'HTTPPath': '/',
            'Auth': {
                'Type': 'BASIC',
                'User': 'user',
                'Password': 'password'
            },
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'foobar'
            },
            'Body': '{"foo": "bar"}'
        }
    }


# Generated at 2022-06-16 22:34:14.771839
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:24.844214
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}) == {'http_endpoint': {'url': 'http://localhost:8080'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://localhost:8080'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'URL': 'http://localhost:8080'}}
    assert camel

# Generated at 2022-06-16 22:34:35.373997
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Timeout': 123,
            'HTTPEndpointConfiguration': {
                'AcceptedPayloadVersion': '1.0',
                'ContentHandlingStrategy': 'CONVERT_TO_TEXT'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:34:47.661354
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:58.824157
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://www.example.com",
            "Timeout": 3,
            "Period": 60
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://www.example.com",
            "Timeout": 5,
            "Period": 60
        }
    }

    snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://www.example.com",
            "timeout": 3,
            "period": 60
        },
        "h_t_t_p_s_endpoint": {
            "endpoint": "https://www.example.com",
            "timeout": 5,
            "period": 60
        }
    }

    assert camel_

# Generated at 2022-06-16 22:35:06.376344
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 5000,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleArn': 'arn:aws:iam::123456789012:role/test-role'
                    }
                }
            },
            'EndpointDescription': 'test endpoint',
            'EndpointStatus': 'ACTIVE'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:35:16.036117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP"
        },
        "Tags": {
            "Name": "test"
        }
    }
    expected_result = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "protocol": "HTTP"
        },
        "tags": {
            "Name": "test"
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_result


# Generated at 2022-06-16 22:35:24.710815
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:34.384606
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:46.282133
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': '200',
            'Region': 'us-east-1',
            'FailureThreshold': 1,
            'MeasureLatency': True,
            'Inverted': False,
            'Disabled': False,
            'Tags': {
                'Name': 'test'
            }
        }
    }


# Generated at 2022-06-16 22:35:54.592893
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:06.733603
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 30,
            'HTTPMethod': 'POST',
            'Auth': {
                'Type': 'AWS_IAM',
                'CredentialsParameter': {
                    'Ref': 'MyCredentialsParameter'
                }
            },
            'Headers': {
                'Content-Type': 'application/json',
                'Content-Length': '123'
            },
            'URLPath': '/path/to/resource',
            'URLQueryParameters': {
                'param1': 'value1',
                'param2': 'value2'
            },
            'RequestBody': '{"key":"value"}'
        }
    }



# Generated at 2022-06-16 22:36:15.119778
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP',
            'Id': 'http-endpoint-1',
            'Name': 'http-endpoint-1',
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'endpoint_type': 'HTTP',
            'id': 'http-endpoint-1',
            'name': 'http-endpoint-1',
            'tags': {
                'Key': 'Value'
            }
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:36:26.641336
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com',
                'TimeoutInSeconds': '10'
            },
            'HTTPEndpointDescription': {
                'HTTPEndpointDescription': {
                    'EndpointURL': 'https://www.example.com',
                    'TimeoutInSeconds': '10'
                }
            }
        }
    }

# Generated at 2022-06-16 22:36:39.024491
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'prod'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Name': 'test',
            'Environment': 'prod'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)

    assert snake_dict

# Generated at 2022-06-16 22:36:45.357281
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'fooBarBaz': {
                'fooBarBazQuux': 'quux',
                'fooBarBazQuux2': 'quux2',
            },
            'fooBarBaz2': 'baz2',
        },
        'fooBar2': 'bar2',
    }

    snake_dict = {
        'foo_bar': {
            'foo_bar_baz': {
                'foo_bar_baz_quux': 'quux',
                'foo_bar_baz_quux2': 'quux2',
            },
            'foo_bar_baz2': 'baz2',
        },
        'foo_bar2': 'bar2',
    }


# Generated at 2022-06-16 22:36:57.290290
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 5,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Matcher': '200',
            'FailureThreshold': 2,
            'SuccessThreshold': 2,
            'Tags': {
                'Tag': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:37:05.132296
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:15.488720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com/',
            'Protocol': 'HTTPS',
            'Method': 'GET',
            'TimeoutInSeconds': 10,
            'SuccessCodes': '200,201,202',
            'Auth': {
                'Type': 'AWS_IAM',
                'AWS_IAM': {
                    'RoleArn': 'arn:aws:iam::123456789012:role/test-role'
                }
            }
        },
        'Tags': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }


# Generated at 2022-06-16 22:37:26.154514
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:37.410769
# Unit test for function camel_dict_to_snake_dict