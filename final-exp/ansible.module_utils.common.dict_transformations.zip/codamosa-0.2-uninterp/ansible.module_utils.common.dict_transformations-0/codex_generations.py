

# Generated at 2022-06-16 22:28:02.631312
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'e': 5})
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    assert recursive_diff(dict1, dict2) == None

# Generated at 2022-06-16 22:28:08.852669
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 10
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 5,
            'Period': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:28:20.141102
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict['h_t_t_p_endpoint']['endpoint'] == 'http://example.com'
    assert snake_dict['h_t_t_p_endpoint']['timeout'] == 10
    assert snake_dict['h_t_t_p_endpoint']['period'] == 60

# Generated at 2022-06-16 22:28:33.068345
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:44.615017
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    assert recursive_diff(dict1, dict2) == ({'c': {'e': 4}}, {'c': {'e': 5}})

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert recursive_diff(dict1, dict2) == None


# Generated at 2022-06-16 22:28:51.223770
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    c = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:29:01.472286
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': '5',
            'MeasureLatency': 'true',
            'InsufficientDataHealthStatus': 'Healthy',
            'Inverted': 'false',
            'Enabled': 'true',
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:29:12.566442
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:23.604522
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 7}}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6, 'i': 7}}}

# Generated at 2022-06-16 22:29:34.889631
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:48.669851
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com/',
            'Protocol': 'HTTPS',
            'Method': 'GET',
            'TimeoutInSeconds': 10,
            'SuccessHttpCodes': '200,201,202',
            'SuccessMatchPattern': '^(200|201|202)$',
            'FailureMatchPattern': '^(400|401|402)$',
            'Headers': {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        },
        'Tags': {
            'Key1': 'Value1',
            'Key2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:30:00.488799
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'MeasureLatency': True,
            'Enabled': True,
            'Regions': [
                'us-east-1',
                'us-west-1'
            ],
            'InsufficientDataHealthStatus': 'Healthy',
            'ChildHealthChecks': [
                'child-health-check-1',
                'child-health-check-2'
            ],
            'Inverted': False,
            'HealthThreshold': 10,
            'EnableSNI': False
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:30:12.808599
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS',
            'Method': 'POST',
            'Path': '/',
            'Auth': {
                'Scheme': 'AWS_IAM',
                'AWS4Signer': {
                    'ServiceName': 'execute-api',
                    'Region': 'us-east-1'
                }
            },
            'Headers': [
                {
                    'Content-Type': 'application/json'
                }
            ],
            'Body': '{"foo": "bar"}',
            'TimeoutInSeconds': 30
        }
    }


# Generated at 2022-06-16 22:30:21.473521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'EndpointType': 'HTTP',
            'URL': 'http://www.example.com',
            'RequestParameters': {
                'HTTPParameter': [
                    {
                        'Name': 'string',
                        'Value': 'string'
                    },
                ]
            },
            'Headers': [
                {
                    'Name': 'string',
                    'Value': 'string'
                },
            ]
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'string',
                    'Value': 'string'
                },
            ]
        }
    }


# Generated at 2022-06-16 22:30:33.513813
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    expected_result = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10,
            'period': 60,
            'success_codes': '200,201',
            'tags': {
                'Key': 'Value'
            }
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_result



# Generated at 2022-06-16 22:30:45.548561
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'HTTPEndpointName': 'test',
            'HTTPURL': 'test',
            'RequestConfiguration': {
                'ContentEncoding': 'test',
                'CommonAttributes': [
                    {
                        'AttributeName': 'test',
                        'AttributeValue': 'test'
                    }
                ]
            },
            'RoleARN': 'test'
        }
    }


# Generated at 2022-06-16 22:30:51.163875
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Tags': {
                'Key': 'value'
            }
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 10,
            'tags': {
                'Key': 'value'
            }
        }
    }

    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:31:02.551733
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:31:14.694412
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:19.175973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Path': '/test', 'Protocol': 'HTTP'}, 'Tags': {'Key': 'test', 'Value': 'test'}}
    snake_dict = {'h_t_t_p_endpoint': {'path': '/test', 'protocol': 'HTTP'}, 'tags': {'Key': 'test', 'Value': 'test'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:31:32.098225
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 10,
            "Period": 60,
            "SuccessCodes": "200-299",
            "HTTPMethod": "GET",
            "FailureThreshold": 3,
            "Matcher": {
                "HttpCode": "200-299"
            }
        },
        "Tags": {
            "Key": "value"
        }
    }

# Generated at 2022-06-16 22:31:43.493803
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:55.231452
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 3
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

# Generated at 2022-06-16 22:32:06.493065
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:18.849666
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test',
            'HTTPEndpointDescription': 'test',
            'ServiceExecutionRole': 'test',
            'EndpointUrl': 'test',
            'EndpointConfiguration': {
                'Types': ['test']
            },
            'Tags': {
                'Key': 'test',
                'Value': 'test'
            }
        }
    }

# Generated at 2022-06-16 22:32:28.645445
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:32:36.516358
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:42.876583
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'FailureThreshold': 1,
            'SuccessThreshold': 1,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'FailureThreshold': 1,
            'SuccessThreshold': 1,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:52.767848
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "URL": "https://www.example.com",
                "AuthorizationConfig": {
                    "AuthorizationType": "AWS_IAM",
                    "AWSRegion": "us-east-1"
                }
            },
            "Name": "test_endpoint",
            "Tags": {
                "Tag1": "value1",
                "Tag2": "value2"
            }
        }
    }


# Generated at 2022-06-16 22:33:02.676233
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS',
            'TimeoutInSeconds': 5,
            'PeriodInSeconds': 10,
            'SuccessThreshold': 1,
            'FailureThreshold': 5,
            'Tags': {
                'Key': 'Value'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS',
            'TimeoutInSeconds': 5,
            'PeriodInSeconds': 10,
            'SuccessThreshold': 1,
            'FailureThreshold': 5,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:33:15.730401
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint_url': 'http://example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:33:21.824294
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:33.580991
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Name': 'test'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }

# Generated at 2022-06-16 22:33:45.004828
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:56.330206
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 5,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:34:04.280034
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5'
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:34:17.208260
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:34:26.153433
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:36.361519
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 5,
            'Protocol': 'HTTP',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:34:48.203030
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:04.389972
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:35:16.182015
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:24.807720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10
        },
        'Tags': {
            'Name': 'Test'
        }
    }


# Generated at 2022-06-16 22:35:34.460244
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:35:46.318541
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:54.852366
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://www.example.com',
                'TimeoutInMillis': 123
            },
            'EndpointDescription': 'Example HTTP endpoint',
            'EndpointName': 'ExampleHTTPEndpoint',
            'EndpointType': 'HTTP',
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:36:07.265148
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:17.448914
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://example.com',
            'Protocol': 'HTTP',
            'Attributes': {
                'Key': 'Value'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint_url': 'http://example.com',
            'protocol': 'HTTP',
            'attributes': {
                'key': 'Value'
            }
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:36:29.449051
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1,
            'MeasureLatency': True,
            'InsufficientDataHealthStatus': 'Healthy',
            'EnableSNI': True,
            'Regions': [
                'us-east-1',
                'us-west-1'
            ],
            'ChildHealthChecks': [
                'child-health-check-1',
                'child-health-check-2'
            ]
        },
        'Tags': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }


# Generated at 2022-06-16 22:36:36.475208
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:37:11.030314
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '10',
            'Period': '10'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': '10',
            'period': '10'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-16 22:37:23.652776
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:30.487749
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:41.235696
# Unit test for function camel_dict_to_snake_dict