

# Generated at 2022-06-16 22:28:00.435288
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5, 'g': 6}, 'h': 7, 'i': 8}
    dict2 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5, 'g': 6}, 'h': 7, 'i': 9}
    dict3 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5, 'g': 6}, 'h': 7, 'i': 8}

# Generated at 2022-06-16 22:28:07.866515
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:14.332567
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': 1, 'c': 2}, 'd': 3}
    b = {'a': {'b': 4, 'e': 5}, 'f': 6}
    c = {'a': {'b': 4, 'c': 2, 'e': 5}, 'd': 3, 'f': 6}
    assert dict_merge(a, b) == c

# Generated at 2022-06-16 22:28:23.142728
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:35.230769
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}, reversible=True) == {'f_oo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}, ignore_list=['FooBar']) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': {'FooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}

# Generated at 2022-06-16 22:28:46.162686
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': 'i'}
    dict2 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': 'i'}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': 'i'}
    dict2 = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': 'j'}
    assert recursive_diff(dict1, dict2) == ({'h': 'i'}, {'h': 'j'})

# Generated at 2022-06-16 22:28:57.873347
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test case 1:
    # dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    # dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    # Expected result: None
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}

# Generated at 2022-06-16 22:29:09.598365
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 2, 'b': {'c': 3, 'd': 4}, 'f': 5}
    c = {'a': 2, 'b': {'c': 3, 'd': 4}, 'f': 5}
    d = {'a': 2, 'b': {'c': 3, 'd': 4}, 'f': 5}
    e = {'a': 2, 'b': {'c': 3, 'd': 4}, 'f': 5}
    f = {'a': 2, 'b': {'c': 3, 'd': 4}, 'f': 5}

# Generated at 2022-06-16 22:29:19.497803
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key1': 'value1',
        'key2': {
            'key2_1': 'value2_1',
            'key2_2': 'value2_2',
            'key2_3': {
                'key2_3_1': 'value2_3_1',
                'key2_3_2': 'value2_3_2',
            },
        },
    }

# Generated at 2022-06-16 22:29:30.461332
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:29:43.237759
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 5,
            'SuccessCodes': '200,202',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-16 22:29:52.515468
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:03.997020
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://www.example.com"}}) == \
        {"http_endpoint": {"url": "http://www.example.com"}}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://www.example.com"}}, reversible=True) == \
        {"h_t_t_p_endpoint": {"u_r_l": "http://www.example.com"}}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://www.example.com"}}, reversible=True, ignore_list=["HTTPEndpoint"]) == \
        {"h_t_t_p_endpoint": {"URL": "http://www.example.com"}}

# Generated at 2022-06-16 22:30:15.907813
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPPath': '/',
            'HTTPPort': 80,
            'HTTPResponseCode': 200,
            'HTTPResponseBody': 'OK'
        },
        'HTTPSEndpoint': {
            'HTTPPath': '/',
            'HTTPPort': 443,
            'HTTPResponseCode': 200,
            'HTTPResponseBody': 'OK'
        }
    }


# Generated at 2022-06-16 22:30:27.588780
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:34.671714
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Auth': {
                'Type': 'BASIC',
                'User': 'user',
                'Password': 'password'
            },
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'custom'
            },
            'Body': '{"foo": "bar"}',
            'BodyType': 'text'
        }
    }


# Generated at 2022-06-16 22:30:42.712984
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,202',
            'HealthyThreshold': 2,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'MyLoadBalancer'
            }
        ]
    }

# Generated at 2022-06-16 22:30:53.461791
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'foobar'
            },
            'Body': '{"state": "SUCCESS"}',
            'Auth': {
                'Type': 'basic',
                'User': 'username',
                'Password': 'password'
            }
        }
    }


# Generated at 2022-06-16 22:31:04.732422
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpointName': 'test'}}) == {'h_t_t_p_endpoint': {'h_t_t_p_endpoint_name': 'test'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpointName': 'test'}}, reversible=True) == {'h_t_t_p_endpoint': {'h_t_t_p_endpoint_name': 'test'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpointName': 'test'}}, reversible=False) == {'http_endpoint': {'http_endpoint_name': 'test'}}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:31:16.462216
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:32.823696
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:43.063406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 1000
            },
            'EndpointType': 'HTTP'
        }
    }

    snake_dict = {
        'http_endpoint': {
            'http_endpoint_configuration': {
                'endpoint_url': 'http://example.com',
                'timeout_in_millis': 1000
            },
            'endpoint_type': 'HTTP'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:31:55.183466
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://example.com',
            'Protocol': 'HTTP',
            'Method': 'GET',
            'TimeoutInSeconds': 1,
            'NumberOfRetries': 1,
            'EndpointConfiguration': {
                'TimeoutInSeconds': 1,
                'NumberOfRetries': 1,
            },
            'HTTPContentHandling': 'CONVERT_TO_TEXT',
        },
        'HTTPContentHandling': 'CONVERT_TO_TEXT',
        'Tags': {
            'Key': 'Value',
        },
    }


# Generated at 2022-06-16 22:32:03.223023
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Protocol': 'HTTP'},
                  'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'protocol': 'HTTP'},
                  'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:32:14.754244
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:25.922895
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAMConfig': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'Method': 'POST',
            'PathWithQueryString': '/path/to/resource?foo=bar',
            'TimeoutInMillis': 3000
        }
    }


# Generated at 2022-06-16 22:32:38.962421
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'AuthKey': 'secret',
            'AuthType': 'basic',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'foobar'
            },
            'Body': '{"foo": "bar"}'
        },
        'Tags': {
            'Name': 'my-http-endpoint',
            'Environment': 'production'
        }
    }


# Generated at 2022-06-16 22:32:50.239686
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'Type': 'AWS_IAM',
                    'AuthorizationParameters': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointRequestParameters': {
                'Attributes': {
                    'Enabled': True,
                    'StringListValues': [
                        'string1',
                        'string2'
                    ]
                }
            }
        }
    }


# Generated at 2022-06-16 22:33:01.751044
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '5',
            'FailureThreshold': '5',
            'SuccessThreshold': '5',
            'MeasureLatency': True,
            'Type': 'HTTP',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200',
            },
        },
        'Tags': {
            'Name': 'test',
        },
    }

# Generated at 2022-06-16 22:33:14.362838
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'test'
        }
    }


# Generated at 2022-06-16 22:33:36.233937
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:33:42.168783
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:52.669155
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'FailureThreshold': '5',
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': '5',
            'period': '60',
            'success_codes': '200,201',
            'failure_threshold': '5',
            'tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:34:02.873246
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "HTTP",
            "TimeoutInSeconds": 1,
            "HealthyThresholdCount": 5,
            "UnhealthyThresholdCount": 2,
            "IntervalInSeconds": 30,
            "Matcher": {
                "HttpCode": "200"
            }
        },
        "Tags": {
            "Key": "value"
        }
    }


# Generated at 2022-06-16 22:34:15.608655
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'HTTPMethod': 'GET',
            'UnhealthyThreshold': 3,
            'HealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            },
            'Path': '/',
            'Port': 80,
            'Protocol': 'HTTP'
        },
        'Tags': [
            {
                'Key': 'foo',
                'Value': 'bar'
            }
        ]
    }


# Generated at 2022-06-16 22:34:25.412162
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:35.809820
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar': 'baz'}}

# Generated at 2022-06-16 22:34:47.790907
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for simple case
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict(camel_dict) == {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com'}}

    # Test for complex case
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 10, 'HTTPMethod': 'GET'}}
    assert camel_dict_to_snake_dict(camel_dict) == {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'timeout': 10, 'http_method': 'GET'}}

    # Test for list case


# Generated at 2022-06-16 22:34:57.153297
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "https://example.com",
            "Protocol": "HTTPS"
        },
        "Tags": {
            "Key": "value"
        },
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-other-targets/c5b80b5c3cbe71d6"
        ]
    }

# Generated at 2022-06-16 22:35:05.799497
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:23.024359
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 12345
            },
            'RetryOptions': {
                'DurationInSeconds': 123
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:33.339787
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 10
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:35:38.270883
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'HTTPMethod': 'POST',
            'Auth': {
                'Scheme': 'AWS_IAM',
                'AWSAccessKey': 'AKIAIOSFODNN7EXAMPLE',
                'AWSSecretKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key1":"value1", "key2":"value2", "key3":"value3"}'
        }
    }


# Generated at 2022-06-16 22:35:49.448754
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'Unit': 'Seconds',
            'Path': '/',
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'AuthToken': 'test',
            'UnhealthyThreshold': 2,
            'HealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:56.979207
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:09.543203
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:19.338866
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200',
            'FailureThreshold': 2
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200',
            'FailureThreshold': 2
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:36:30.970673
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:38.445388
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_dict({'fooBar': [{'fooBar': 'baz'}]}, reversible=True) == {'foo_bar': [{'foo_bar': 'baz'}]}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:36:45.523594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key": "value"}'
        }
    }


# Generated at 2022-06-16 22:37:14.369855
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:25.482784
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:36.679482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Protocol': 'HTTP',
            'Method': 'GET',
            'Timeout': 30,
            'HTTPEndpointConfiguration': {
                'Path': '/',
                'AuthKey': 'string',
                'Body': 'string',
                'Headers': {
                    'string': 'string'
                },
                'SupportedResponseTypes': [
                    'JSON',
                ],
                'TimeoutInSeconds': 123
            }
        },
        'Tags': {
            'string': 'string'
        }
    }
