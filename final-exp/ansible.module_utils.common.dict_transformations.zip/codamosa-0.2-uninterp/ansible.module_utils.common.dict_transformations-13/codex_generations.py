

# Generated at 2022-06-16 22:27:56.453189
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 6}
    assert recursive_diff(dict1, dict2) == ({'f': 5}, {'f': 6})


# Generated at 2022-06-16 22:28:00.267938
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}) == {'http_endpoint': {'url': 'http://example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'url': 'http://example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}, ignore_list=['HTTPEndpoint']) == {'http_endpoint': {'URL': 'http://example.com'}}

# Generated at 2022-06-16 22:28:05.623206
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:28:18.091996
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 60,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'Auth': {
                'Type': 'BASIC',
                'User': 'user',
                'Password': 'password'
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key": "value"}',
            'Tags': {
                'key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:28:22.418429
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) == ({'b': {'d': 3}, 'e': 4}, {'b': {'d': 4}, 'f': 5})

# Generated at 2022-06-16 22:28:34.656429
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}

# Generated at 2022-06-16 22:28:45.766419
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': '120',
            'HTTPHeaders': [
                {
                    'Name': 'Content-Type',
                    'Value': 'application/json'
                }
            ]
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': '120',
            'h_t_t_p_headers': [
                {
                    'name': 'Content-Type',
                    'value': 'application/json'
                }
            ]
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
   

# Generated at 2022-06-16 22:28:57.536650
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 1}}) is None

# Generated at 2022-06-16 22:29:09.539470
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': '1',
        'b': {
            'c': '2',
            'd': '3',
            'e': {
                'f': '4',
                'g': '5',
                'h': '6'
            }
        }
    }
    dict2 = {
        'a': '1',
        'b': {
            'c': '2',
            'd': '3',
            'e': {
                'f': '4',
                'g': '5',
                'h': '7'
            }
        }
    }
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-16 22:29:19.269939
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 6}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5, 'g': 7}

# Generated at 2022-06-16 22:29:33.737850
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Pass': 'pass'
            }
        },
        'TCPEndpoint': {
            'Endpoint': 'example.com:80',
            'Timeout': 3,
            'Period': 60
        }
    }


# Generated at 2022-06-16 22:29:44.652452
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:29:53.557918
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10,
            'Disabled': False,
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 10,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:30:05.619739
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:16.824122
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'http_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, ignore_list=['HTTPEndpoint']) == {'http_endpoint': {'URL': 'http://www.example.com'}}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:30:28.942767
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:39.144965
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'FailureThreshold': 3,
            'Tags': {
                'Key': 'value'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'FailureThreshold': 3,
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:30:52.065684
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:03.376852
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Enabled': True,
            'Timeout': 10,
            'HTTPPath': '/',
            'HTTPMethod': 'POST',
            'AuthKey': '12345',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'custom'
            }
        },
        'Tags': {
            'Key1': 'Value1',
            'Key2': 'Value2'
        }
    }


# Generated at 2022-06-16 22:31:15.370079
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:29.677267
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com', 'Timeout': 3}, 'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 3}, 'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 3}, 'tags': {'Key': 'Value'}}

# Generated at 2022-06-16 22:31:41.072072
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': 'http://example.com',
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:31:48.877915
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:59.447845
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:10.634773
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:32:22.838521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 10,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:32:34.001839
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Protocol': 'HTTP'},
                  'Tags': {'Key': 'Value'},
                  'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                                      'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']}

# Generated at 2022-06-16 22:32:46.810332
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080/',
            'Timeout': 5,
            'Period': 60
        },
        'Tags': {
            'Key': 'value'
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080/',
            'timeout': 5,
            'period': 60
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == expected_snake_dict


# Generated at 2022-06-16 22:32:55.109512
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointConfig': {
                'AccessKey': 'AKIAIOSFODNN7EXAMPLE',
                'SecretKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:33:03.846536
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }

# Generated at 2022-06-16 22:33:19.027489
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:29.294058
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'HealthCheckPath': '/',
            'HealthCheckIntervalSeconds': 30,
            'HealthCheckTimeoutSeconds': 5,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'MyLoadBalancer',
            'Environment': 'Production'
        }
    }


# Generated at 2022-06-16 22:33:39.953404
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 10,
            'period': 10
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(test_dict, ignore_list=['Tags']) == expected_dict



# Generated at 2022-06-16 22:33:49.251403
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:00.826954
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 1,
        },
        'HTTPAuth': {
            'Scheme': 'Basic',
            'Username': 'username',
            'Password': 'password',
        },
        'Tags': {
            'Key1': 'Value1',
            'Key2': 'Value2',
        },
    }


# Generated at 2022-06-16 22:34:13.138415
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'FailureThreshold': 3
        },
        'Tags': {
            'Name': 'test'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://localhost:8080',
            'timeout': 1,
            'period': 60,
            'success_codes': '200,201,202',
            'failure_threshold': 3
        },
        'tags': {
            'Name': 'test'
        }
    }


# Generated at 2022-06-16 22:34:23.804047
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'h_t_t_p_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}

# Generated at 2022-06-16 22:34:34.929256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInMinutes': 1,
            'HTTPMethod': 'GET',
            'AuthToken': 'token',
            'URIPath': '/',
            'Headers': {
                'Content-Type': 'application/json'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:34:47.368901
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 3},
                  'Tags': {'Key': 'Value'},
                  'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                                      'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']}


# Generated at 2022-06-16 22:34:54.206689
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointType': 'HTTP'
        }
    }


# Generated at 2022-06-16 22:35:20.254569
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Protocol': 'HTTP',
            'Method': 'GET',
            'Timeout': 10,
            'HTTPEndpointConfiguration': {
                'AcceptableStatusCodes': [200, 201, 202, 203, 204, 205, 206, 207, 208, 226, 300, 301, 302, 303, 304, 305, 306, 307, 308],
                'AuthenticationConfiguration': {
                    'HTTPBasicAuthConfiguration': {
                        'Password': 'password',
                        'Username': 'username'
                    }
                }
            }
        }
    }


# Generated at 2022-06-16 22:35:28.009921
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': 5,
            'MeasureLatency': True,
            'InsufficientDataHealthStatus': 'Healthy',
            'Tags': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:35:36.403535
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:47.806568
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'FailureThreshold': 3,
            'MeasureLatency': True,
            'Enabled': True,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'InsufficientDataHealthStatus': 'Healthy'
        }
    }


# Generated at 2022-06-16 22:35:55.291470
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'POST',
            'AuthKey': 'secret',
            'AuthType': 'basic',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Auth-Token': 'secret'
            }
        },
        'Tags': {
            'Name': 'MyHTTPEndpoint'
        }
    }


# Generated at 2022-06-16 22:36:07.885998
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Id': 'string',
            'URL': 'string',
            'Authorization': {
                'Type': 'string',
                'AuthorizationParameter': 'string'
            },
            'AccessKey': 'string',
            'UseDefaultCredentials': True,
            'TimeoutInSeconds': 123,
            'Tags': [
                {
                    'Key': 'string',
                    'Value': 'string'
                },
            ]
        }
    }


# Generated at 2022-06-16 22:36:17.951785
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:29.894135
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:36:36.883824
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP',
            'Id': 'http-endpoint',
            'Name': 'http-endpoint',
            'Tags': {
                'Tag': {
                    'Key': 'Name',
                    'Value': 'http-endpoint'
                }
            }
        }
    }


# Generated at 2022-06-16 22:36:44.700800
# Unit test for function camel_dict_to_snake_dict