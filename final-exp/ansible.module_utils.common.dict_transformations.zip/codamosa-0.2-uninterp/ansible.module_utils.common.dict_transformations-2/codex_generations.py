

# Generated at 2022-06-16 22:27:53.347456
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "URL": "http://www.example.com/example"
            },
            "Name": "example"
        },
        "Tags": {
            "Key": "example",
            "Value": "example"
        }
    }

    snake_dict = {
        "h_t_t_p_endpoint": {
            "h_t_t_p_endpoint_configuration": {
                "url": "http://www.example.com/example"
            },
            "name": "example"
        },
        "tags": {
            "Key": "example",
            "Value": "example"
        }
    }


# Generated at 2022-06-16 22:28:02.334708
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'endpoint_type': 'HTTP'
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:28:08.732965
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:20.069422
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 5,
            'MeasureLatency': True,
            'Type': 'HTTP',
            'HTTPCode': [200, 201, 202, 203, 204, 205, 206, 207, 208, 226, 300, 301, 302, 303, 304, 305, 306, 307, 308],
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:28:33.020759
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:44.576985
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': 4}
    dict2 = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': 5}
    assert recursive_diff(dict1, dict2) == ({'e': 4}, {'e': 5})
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': 4}
    dict2 = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': 4}
    assert recursive_diff(dict1, dict2) is None
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 3, 'e': 4}

# Generated at 2022-06-16 22:28:56.524806
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200-299',
            'FailureThreshold': 5,
            'Tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:29:04.082352
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "URL": "http://www.example.com",
            "HTTPHeaders": [
                {
                    "Name": "Content-Type",
                    "Value": "application/json"
                }
            ]
        },
        "Tags": [
            {
                "Key": "key1",
                "Value": "value1"
            },
            {
                "Key": "key2",
                "Value": "value2"
            }
        ]
    }

# Generated at 2022-06-16 22:29:14.410421
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com'
            },
            'Name': 'test'
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_configuration': {
                'url': 'http://example.com'
            },
            'name': 'test'
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:29:19.230967
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,202',
            'HTTPMethod': 'GET',
            'Path': '/health',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Name': 'Test',
            'Environment': 'Test'
        }
    }


# Generated at 2022-06-16 22:29:35.052493
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar': 'baz'}}

# Generated at 2022-06-16 22:29:45.962009
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5,
        },
        'Tags': {
            'Key': 'value',
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
        ],
    }

# Generated at 2022-06-16 22:29:50.826772
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:29:57.640539
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 2, 'd': 4}, 'f': 5}
    c = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 4, 'f': 5}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:30:09.306342
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/test'}}) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/test'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/test'}}, reversible=True) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/test'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/test'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'HTTPPath': '/test'}}
    assert camel_dict_to_snake_

# Generated at 2022-06-16 22:30:19.720196
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"state": "ok"}'
        },
        'Tags': {
            'Name': 'test',
            'Environment': 'test'
        }
    }


# Generated at 2022-06-16 22:30:31.812731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://www.example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointStatus': 'READY',
            'HTTPEndpointName': 'test_endpoint',
            'HTTPFullUrl': 'http://www.example.com',
            'HTTPId': 'test_id',
            'HTTPMethod': 'POST',
            'Tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:30:38.225296
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:30:50.358076
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    c = {'a': 5, 'b': {'c': 6, 'd': 3, 'f': 7}, 'e': 4, 'g': 8}
    assert dict_merge(a, b) == c
    assert dict_merge(b, a) == c
    assert dict_merge(a, {}) == a
    assert dict_merge({}, a) == a
    assert dict_merge(a, a) == a
    assert dict_merge({}, {}) == {}

# Generated at 2022-06-16 22:30:57.426710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 10}, 'Tags': {'Key': 'value'}}
    expected_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'timeout': 10}, 'tags': {'Key': 'value'}}
    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:31:07.089720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "https://example.com",
            "Protocol": "HTTPS"
        },
        "Tags": {
            "Name": "example",
            "Environment": "test"
        }
    }

    snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "https://example.com",
            "protocol": "HTTPS"
        },
        "tags": {
            "Name": "example",
            "Environment": "test"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:31:18.274591
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP',
            'timeout_in_seconds': 10
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert snake_dict_to_camel_dict(snake_dict) == camel_dict
    assert snake_dict_to

# Generated at 2022-06-16 22:31:27.153292
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:31:38.324805
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 3,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 5,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:47.785646
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200-399',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10,
            'Disabled': False,
            'Tags': {
                'key': 'value',
                'key2': 'value2'
            }
        }
    }


# Generated at 2022-06-16 22:31:58.729810
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': 3,
            'MeasureLatency': True,
            'InsufficientDataHealthStatus': 'Healthy',
            'Tags': {
                'Name': 'MyHTTPEndpoint',
                'Environment': 'Production'
            }
        }
    }


# Generated at 2022-06-16 22:32:10.110080
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://www.example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointStatus': 'READY'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['http_endpoint']['http_endpoint_configuration']['url'] == 'http://www.example.com'

# Generated at 2022-06-16 22:32:22.272367
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }


# Generated at 2022-06-16 22:32:30.755538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://www.example.com',
            'Timeout': '10',
            'HTTPEndpointConfiguration': {
                'AcceptedPayloadVersion': '1.0',
                'ContentHandlingStrategy': 'CONVERT_TO_BINARY'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:32:43.720053
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True) == {'foo_b_ar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_b_ar': {'foo_b_ar': 'baz'}}

# Generated at 2022-06-16 22:32:54.258793
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 5,
            'Period': 120
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 3,
            'period': 60
        },
        'h_t_t_p_s_endpoint': {
            'endpoint': 'https://www.example.com',
            'timeout': 5,
            'period': 120
        }
    }

    assert camel_

# Generated at 2022-06-16 22:33:03.380980
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:15.073575
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInMillis': 5000,
            'HTTPMethod': 'POST',
            'Auth': {
                'AuthType': 'AWS_IAM',
                'AWSAccessKey': 'AKIAIOSFODNN7EXAMPLE',
                'AWSSecretKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
                'AWSRegion': 'us-east-1'
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'Body': '{"key":"value"}'
        }
    }


# Generated at 2022-06-16 22:33:26.562613
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': 'http://www.example.com',
        'HTTPSEndpoint': 'https://www.example.com',
        'Tags': {
            'Key': 'Value',
            'Key2': 'Value2'
        },
        'TagList': [
            {
                'Key': 'Value',
                'Key2': 'Value2'
            },
            {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        ]
    }


# Generated at 2022-06-16 22:33:38.394916
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:48.569721
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json'
            }
        },
        'Tags': {
            'Name': 'test'
        }
    }


# Generated at 2022-06-16 22:34:00.144661
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Enabled': True,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'InsufficientDataHealthStatus': 'Healthy',
            'Tags': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }


# Generated at 2022-06-16 22:34:06.767740
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_endpoint_description',
            'ServiceName': 'test_service',
            'VpcEndpointId': 'test_vpc_endpoint_id',
            'VpcId': 'test_vpc_id',
            'SubnetIds': ['test_subnet_id_1', 'test_subnet_id_2'],
            'SecurityGroupIds': ['test_security_group_id_1', 'test_security_group_id_2'],
            'Tags': {
                'TagKey': 'TagValue'
            }
        }
    }


# Generated at 2022-06-16 22:34:19.178765
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://example.com',
                'TimeoutInMillis': 123,
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWSRegion': 'us-east-1'
                }
            },
            'EndpointDescription': 'My HTTP Endpoint',
            'EndpointStatus': 'ACTIVE'
        }
    }

# Generated at 2022-06-16 22:34:27.054935
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 5,
            'MeasureLatency': True,
            'Enabled': True,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:34:44.135876
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:52.038981
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'HTTP',
            'Target': 'arn:aws:lambda:us-east-1:123456789012:function:my-function'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:01.285302
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 10
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://localhost:8080',
            'Timeout': 10,
            'Period': 10
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:35:13.229539
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'h_t_t_p_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}

# Generated at 2022-06-16 22:35:22.376075
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:35:32.754462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'Disabled': False,
            'HTTPMethod': 'GET',
            'HTTPVersion': 'HTTP/1.1',
            'CustomHeaders': {
                'X-Custom-Header': 'CustomHeaderValue'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:35:44.916064
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True, ignore_list=['fooBar']) == {'foo_bar': {'fooBar': 'baz'}}
    assert camel_dict_to

# Generated at 2022-06-16 22:35:52.412183
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:35:56.899188
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com', 'Timeout': 10},
                  'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 10},
                  'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:36:09.453642
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:32.503984
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:37.620248
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5
        },
        'tags': {
            'Key': 'value'
        }
    }



# Generated at 2022-06-16 22:36:45.140517
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:57.115748
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'string',
            'HTTPEndpointName': 'string',
            'HTTPEndpointStatus': 'string',
            'HTTPURI': 'string',
            'RequestConfiguration': {
                'CommonAttributes': [
                    {
                        'AttributeName': 'string',
                        'AttributeValue': 'string'
                    },
                ],
                'ContentEncoding': 'string',
                'ContentType': 'string'
            },
            'RoleARN': 'string'
        },
        'Tags': {
            'string': 'string'
        }
    }


# Generated at 2022-06-16 22:37:05.025892
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:15.420329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 5,
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'AWS_IAM',
                'CredentialsParameter': {
                    'Name': 'MyCredentials',
                    'Type': 'SECRETS_MANAGER'
                }
            },
            'Headers': [
                {
                    'Key': 'Content-Type',
                    'Value': 'application/json'
                }
            ],
            'Payload': '{"foo": "bar"}'
        }
    }


# Generated at 2022-06-16 22:37:26.119189
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5,
            'period': 60,
            'success_codes': '200,201',
            'disabled': False,
            'tags': {
                'Key': 'Value'
            }
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

# Generated at 2022-06-16 22:37:37.369758
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com/endpoint',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
