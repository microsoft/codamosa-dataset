

# Generated at 2022-06-16 22:27:46.152896
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 7}}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}, 'i': 7}

# Generated at 2022-06-16 22:27:55.773450
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 5
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:28:05.659803
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:18.092018
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 1,
            'Period': 60
        },
        'Tags': {
            'Tag': [
                {
                    'Key': 'key1',
                    'Value': 'value1'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }

# Generated at 2022-06-16 22:28:30.588352
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThresholdCount': 5,
            'UnhealthyThresholdCount': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:28:43.174241
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6
            }
        }
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6
            }
        }
    }
    assert recursive_diff(dict1, dict2) is None


# Generated at 2022-06-16 22:28:54.870511
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4}
    dict2 = {'a': {'b': {'c': 1, 'd': 3}, 'e': 3}, 'f': 4}
    dict3 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4}
    dict4 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 5}
    dict5 = {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4, 'g': 5}

# Generated at 2022-06-16 22:29:03.355409
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 1,
            'Period': 1,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'custom-value'
            },
            'Body': '{"key": "value"}',
            'Auth': {
                'Type': 'basic',
                'User': 'user',
                'Password': 'password'
            }
        }
    }


# Generated at 2022-06-16 22:29:14.166611
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}, 'f': 6}
    expected = ({'c': {'e': 4}}, {'c': {'e': 5}, 'f': 6})
    assert recursive_diff(dict1, dict2) == expected
    assert recursive_diff(dict2, dict1) == expected

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}

# Generated at 2022-06-16 22:29:25.173759
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    assert recursive_diff(dict1, dict2) == ({'c': {'e': 4}}, {'c': {'e': 5}})
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert recursive_diff(dict1, dict2) is None

# Generated at 2022-06-16 22:29:39.111263
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202,203,204,205,206,207,208,226,300,301,302,303,304,305,306,307,308',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'test-http-endpoint'
            }
        ]
    }


# Generated at 2022-06-16 22:29:49.522426
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:57.246018
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'b': {1: 1, 2: 7}, 'c': 3, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:30:08.998524
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:19.536482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}) == {'http_endpoint': {'url': 'http://localhost:8080'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://localhost:8080'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://localhost:8080'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'URL': 'http://localhost:8080'}}
    assert camel

# Generated at 2022-06-16 22:30:31.761214
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5,
            'period': 60,
            'success_codes': '200,201',
            'disabled': False,
            'tags': {
                'Key': 'Value'
            }
        }
    }

# Generated at 2022-06-16 22:30:40.990766
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 10,
            'MeasureLatency': True,
            'Enabled': True,
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-16 22:30:52.586792
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:03.862690
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://www.example.com",
            "Timeout": 3,
            "Period": 60
        },
        "HTTPSEndpoint": {
            "Endpoint": "https://www.example.com",
            "Timeout": 5,
            "HealthyThreshold": 2,
            "UnhealthyThreshold": 2,
            "Matcher": {
                "HttpCode": "200"
            }
        },
        "Tags": {
            "Key": "Value"
        }
    }

# Generated at 2022-06-16 22:31:12.044610
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:31:22.809809
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:33.984159
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test for simple case
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com'}}

    # Test for simple case with reversible=True
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)
    assert snake_dict == {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com'}}

    # Test for simple case with reversible=

# Generated at 2022-06-16 22:31:44.717496
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:56.166348
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:07.277351
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com',
                'Protocol': 'HTTPS'
            },
            'Id': 'http-endpoint-1',
            'Name': 'MyHTTPEndpoint'
        }
    }

    expected_snake_dict = {
        'http_endpoint': {
            'http_endpoint_configuration': {
                'endpoint_url': 'https://www.example.com',
                'protocol': 'HTTPS'
            },
            'id': 'http-endpoint-1',
            'name': 'MyHTTPEndpoint'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict

# Generated at 2022-06-16 22:32:19.690805
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 5,
            'MeasureLatency': True,
            'Type': 'HTTP',
            'HTTPCode': [
                'HTTP_2XX',
                'HTTP_3XX'
            ],
            'HTTPMethod': 'GET',
            'URLPath': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'MyEndpoint'
            }
        ]
    }


# Generated at 2022-06-16 22:32:27.501593
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Protocol": "http"
        },
        "Tags": {
            "Key": "value"
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "protocol": "http"
        },
        "tags": {
            "Key": "value"
        }
    }



# Generated at 2022-06-16 22:32:39.602808
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:50.757413
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'FailureThreshold': 10,
            'SuccessThreshold': 10,
            'MeasureLatency': True,
            'Type': 'HTTP',
            'HTTPCode': [
                200,
                201,
                202,
                203,
                204,
                205,
                206,
                207,
                208,
                226
            ],
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:33:01.871257
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://www.example.com',
            'HTTPEndpointConfiguration': {
                'EndpointType': 'HTTP',
                'RetryOptions': {
                    'DurationInSeconds': '300',
                    'MaxAttempts': '3'
                }
            }
        },
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:33:17.455763
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'URL': 'test',
            'AuthorizationType': 'test',
            'AuthorizerId': 'test',
            'Method': 'test',
            'TimeoutInSeconds': 'test',
            'TLSConfig': {
                'ServerNameToVerify': 'test'
            },
            'Tags': {
                'Tag1': 'test',
                'Tag2': 'test'
            }
        }
    }


# Generated at 2022-06-16 22:33:27.691759
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'test',
            'HTTPEndpointUrl': 'test',
            'AuthorizationConfig': {
                'AuthorizationType': 'test',
                'AWSV4Authorization': {
                    'SigningRegion': 'test',
                    'ServiceName': 'test',
                    'RoleArn': 'test'
                }
            },
            'EndpointConfiguration': {
                'Types': ['test']
            },
            'Tags': {
                'Tag': [
                    {
                        'Key': 'test',
                        'Value': 'test'
                    }
                ]
            }
        }
    }


# Generated at 2022-06-16 22:33:39.695302
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'CustomHeaderValue'
            },
            'Body': '{"key": "value"}',
            'Auth': {
                'Type': 'basic',
                'User': 'username',
                'Password': 'password'
            }
        }
    }


# Generated at 2022-06-16 22:33:48.705315
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'GET',
            'Path': '/health',
            'Headers': {
                'X-Custom-Header': 'some-value'
            },
            'Tags': {
                'Tag1': 'Value1',
                'Tag2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:34:00.302970
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:12.449527
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'FailureThreshold': 10,
            'MeasureLatency': True,
            'InsufficientDataHealthStatus': 'Healthy',
            'Tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }


# Generated at 2022-06-16 22:34:23.411943
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:34.565590
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:47.035256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}) == {'http_endpoint': {'url': 'http://example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://example.com'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'URL': 'http://example.com'}}
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:34:56.498093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com',
                'TimeoutInSeconds': 10,
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'RoleARN': 'arn:aws:iam::123456789012:role/my-role'
                    }
                }
            },
            'HTTPContentType': 'application/json',
            'EndpointStatus': 'ACTIVE',
            'EndpointType': 'DATA',
            'Tags': {
                'TagKey': 'TagValue'
            }
        }
    }


# Generated at 2022-06-16 22:35:18.635438
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': 10
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-16 22:35:27.244309
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:36.840994
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:48.606338
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTPS',
            'Port': 80,
            'Path': '/foo',
            'Auth': {
                'Type': 'AWS_IAM',
                'AWS_IAM': {
                    'Role': 'arn:aws:iam::123456789012:role/myRole'
                }
            },
            'Tags': {
                'Key': 'Value'
            }
        },
        'TCPEndpoint': {
            'Protocol': 'TCP',
            'Port': 80,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:35:56.336699
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:09.172050
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '5',
            'Period': '60',
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': '5',
            'Disabled': 'false',
            'HealthyThreshold': '5',
            'UnhealthyThreshold': '5',
            'Path': '/',
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:36:18.936644
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessThreshold': 1,
            'FailureThreshold': 5
        },
        'Tags': {
            'key': 'value'
        }
    }
    expected = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 1,
            'period': 60,
            'success_threshold': 1,
            'failure_threshold': 5
        },
        'tags': {
            'key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected



# Generated at 2022-06-16 22:36:30.593795
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:36:38.185395
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:45.387555
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:23.695679
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 10,
            'SuccessCodes': '200,201,202',
            'HTTPMethod': 'POST',
            'Path': '/',
            'FailureThreshold': 10,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:37:31.578258
# Unit test for function camel_dict_to_snake_dict