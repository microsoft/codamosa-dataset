

# Generated at 2022-06-16 22:28:05.020556
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:28:17.730439
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    dict3 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}
    dict6 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}}

# Generated at 2022-06-16 22:28:29.820812
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 5}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': 6}
    assert recursive_diff(dict1, dict2) == ({'f': 5}, {'f': 6})


# Generated at 2022-06-16 22:28:38.122235
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'b': {1: 1, 2: 7}, 'c': 3, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:28:47.543229
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    b = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    c = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5, 'f': 6}
    d = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5, 'f': {'g': 7}}
    e = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5, 'f': {'g': 7, 'h': 8}}

# Generated at 2022-06-16 22:28:55.089686
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:29:03.473214
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
                'i': {
                    'j': 7,
                    'k': 8,
                    'l': 9
                }
            }
        }
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
                'i': {
                    'j': 7,
                    'k': 8,
                    'l': 10
                }
            }
        }
    }
    dict3

# Generated at 2022-06-16 22:29:14.291711
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:21.569591
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'b1': 1, 'b2': 2}, 'c': 3}
    b = {'a': 2, 'b': {'b1': 3, 'b3': 4}, 'd': 5}
    c = {'a': 2, 'b': {'b1': 3, 'b2': 2, 'b3': 4}, 'c': 3, 'd': 5}
    assert dict_merge(a, b) == c



# Generated at 2022-06-16 22:29:29.156030
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}



# Generated at 2022-06-16 22:29:38.122347
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com/endpoint'
            },
            'Name': 'endpoint-name'
        }
    }
    snake_dict = {
        'http_endpoint': {
            'http_endpoint_configuration': {
                'url': 'https://example.com/endpoint'
            },
            'name': 'endpoint-name'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:29:49.147936
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201,202,203,204,205,206,207,208,226,300,301,302,303,304,305,306,307,308',
            'FailureThreshold': 10
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:30:01.048083
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}) == {'http_endpoint': {'url': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://www.example.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://www.example.com'}}, ignore_list=['HTTPEndpoint']) == {'http_endpoint': {'URL': 'http://www.example.com'}}
    assert camel_dict_to

# Generated at 2022-06-16 22:30:13.433585
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:21.774766
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:34.147435
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:42.345311
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:53.250136
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:04.535134
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'HTTPEndpointType': 'AWS_PROXY',
            'HTTPHeaders': [
                {
                    'Key': 'X-Forwarded-Proto',
                    'Value': 'https'
                }
            ],
            'TimeoutInMillis': 29000
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:16.420261
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com/endpoint',
                'TimeoutInMillis': 1000
            },
            'RetryOptions': {
                'DurationInSeconds': 60
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:27.320977
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://www.example.com",
            "Timeout": 3,
            "Period": 60,
            "SuccessCodes": "200,201",
            "HTTPMethod": "GET",
            "FailureThreshold": 3,
            "MeasureLatency": True,
            "Enabled": True,
            "Tags": {
                "Key": "Value"
            }
        }
    }


# Generated at 2022-06-16 22:31:38.471969
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://www.example.com/endpoint',
                'TimeoutInSeconds': 123
            },
            'Id': 'HTTPEndpointId',
            'Name': 'HTTPEndpointName'
        }
    }

    snake_dict = {
        'http_endpoint': {
            'http_endpoint_configuration': {
                'endpoint_url': 'https://www.example.com/endpoint',
                'timeout_in_seconds': 123
            },
            'id': 'HTTPEndpointId',
            'name': 'HTTPEndpointName'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Unit test

# Generated at 2022-06-16 22:31:47.888404
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com/endpoint'
            },
            'Id': 'endpoint-id',
            'Name': 'endpoint-name'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_configuration': {
                'url': 'https://example.com/endpoint'
            },
            'id': 'endpoint-id',
            'name': 'endpoint-name'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:31:58.808478
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com', 'Timeout': 5}, 'Tags': {'Key': 'value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 5}, 'tags': {'Key': 'value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict, capitalize_first=True)) == snake_dict

# Generated at 2022-06-16 22:32:10.159664
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 1,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:21.916414
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'http://www.example.com',
                'Protocol': 'HTTPS'
            },
            'Name': 'MyHTTPEndpoint'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint_configuration': {
                'endpoint_url': 'http://www.example.com',
                'protocol': 'HTTPS'
            },
            'name': 'MyHTTPEndpoint'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-16 22:32:30.483049
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict

# Generated at 2022-06-16 22:32:43.085205
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5
        },
        'Tags': {
            'Key': 'Value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 5
        },
        'tags': {
            'Key': 'Value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict

# Generated at 2022-06-16 22:32:47.706728
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'URL': 'http://example.com', 'Protocol': 'HTTP'},
                  'Tags': {'Key': 'value'}}
    snake_dict = {'h_t_t_p_endpoint': {'url': 'http://example.com', 'protocol': 'HTTP'},
                  'tags': {'Key': 'value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict)) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict, capitalize_first=True)) == snake_dict
    assert camel_dict

# Generated at 2022-06-16 22:32:59.810645
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:14.945768
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:21.384970
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com', 'Timeout': 1}, 'Tags': {'Key': 'Value'}}
    expected_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 1}, 'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == {'h_t_t_p_endpoint': {'endpoint': 'http://example.com', 'timeout': 1}, 'tags': {'key': 'Value'}}

# Generated at 2022-06-16 22:33:33.472989
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:33:44.860803
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 3,
            'Period': 60,
            'SuccessCodes': '200,201,202',
            'HealthyThreshold': 3,
            'UnhealthyThreshold': 3,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }

# Generated at 2022-06-16 22:33:56.042402
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'http',
            'TimeoutInSeconds': 10,
            'HTTPMethod': 'GET',
            'Auth': {
                'Type': 'AWS_IAM',
                'CredentialsParameter': {
                    'Ref': 'MyCredentials'
                }
            },
            'Headers': {
                'Content-Type': 'application/json'
            },
            'PathWithQueryString': '/path?query=string',
            'Body': '{"key": "value"}',
            'ConnectionRetryCount': 3,
            'ConnectionRetryIntervalInSeconds': 10
        }
    }


# Generated at 2022-06-16 22:34:04.878057
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:17.797767
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointId': 'endpoint-id',
            'EndpointType': 'endpoint-type',
            'VpcEndpointId': 'vpc-endpoint-id',
            'VpcId': 'vpc-id',
            'VpcRegion': 'vpc-region',
            'ServiceName': 'service-name',
            'PolicyDocument': 'policy-document',
            'SecurityGroupIds': ['security-group-id'],
            'SubnetIds': ['subnet-id'],
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:34:26.423282
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_description',
            'ServiceExecutionRole': 'test_role',
            'EndpointConfigName': 'test_config',
            'Tags': {
                'Key': 'value'
            }
        }
    }

# Generated at 2022-06-16 22:34:36.513117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 3,
            'Period': 60,
            'FailureThreshold': 3,
            'SuccessThreshold': 1
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:34:47.312174
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Name': 'MyTag',
            'Value': 'MyValue'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Name': 'MyTag',
            'Value': 'MyValue'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:34:57.994839
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.example.com', 'Timeout': 10},
                  'Tags': {'Key': 'Value'}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint': 'http://www.example.com', 'timeout': 10},
                  'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict, reversible=True) == camel_dict



# Generated at 2022-06-16 22:35:05.938955
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'http',
            'Timeout': 10,
            'Period': 60,
            'SuccessThreshold': 1,
            'FailureThreshold': 3,
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'http',
            'timeout': 10,
            'period': 60,
            'success_threshold': 1,
            'failure_threshold': 3,
            'tags': {
                'Key': 'Value'
            }
        }
    }
    assert camel_

# Generated at 2022-06-16 22:35:17.548710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://example.com',
            'Timeout': 10,
            'HTTPHeaders': [
                {
                    'Name': 'X-Header',
                    'Value': 'Value'
                }
            ]
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'url': 'http://example.com',
            'timeout': 10,
            'h_t_t_p_headers': [
                {
                    'name': 'X-Header',
                    'value': 'Value'
                }
            ]
        },
        'tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:35:27.270077
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:36.890482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Id': 'http-endpoint-1'
        },
        'HTTPEndpoints': [
            {
                'Endpoint': 'http://example.com',
                'Id': 'http-endpoint-1'
            },
            {
                'Endpoint': 'http://example.com',
                'Id': 'http-endpoint-2'
            }
        ],
        'Tags': {
            'Key': 'value'
        }
    }

# Generated at 2022-06-16 22:35:48.647320
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:56.371538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': '60',
            'HTTPMethod': 'GET',
            'HTTPPath': '/',
            'SuccessCodes': '200,201',
            'FailureCodes': '404,500',
            'Tags': {
                'Tag': {
                    'Key': 'key',
                    'Value': 'value'
                }
            }
        }
    }


# Generated at 2022-06-16 22:36:09.166709
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for simple dict
    camel_dict = {'HTTPEndpoint': 'http://example.com'}
    snake_dict = {'http_endpoint': 'http://example.com'}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # Test for nested dict
    camel_dict = {'HTTPEndpoint': {'HTTPEndpoint': 'http://example.com'}}
    snake_dict = {'http_endpoint': {'http_endpoint': 'http://example.com'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # Test for list
    camel_dict = {'HTTPEndpoint': ['http://example.com']}

# Generated at 2022-06-16 22:36:18.681753
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 5,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 5,
            'Matcher': {
                'HttpCode': '200'
            }
        }
    }


# Generated at 2022-06-16 22:36:29.710947
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}) == {'http_endpoint': {'http_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=True) == {'h_t_t_p_endpoint': {'h_t_t_p_path': '/foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/foo'}}, reversible=True, ignore_list=['HTTPEndpoint']) == {'h_t_t_p_endpoint': {'HTTPPath': '/foo'}}


# Generated at 2022-06-16 22:36:42.388278
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:53.783093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessThreshold': 1,
            'FailureThreshold': 5,
            'Tags': {
                'Key': 'Value'
            }
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessThreshold': 1,
            'FailureThreshold': 5,
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:37:02.840382
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:13.916011
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'EndpointURL': 'https://example.com',
                'TimeoutInMillis': 5000
            },
            'RetryOptions': {
                'DurationInSeconds': 300
            },
            'RoleArn': 'arn:aws:iam::123456789012:role/test-role'
        },
        'Id': 'test-id',
        'Name': 'test-name',
        'Tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:37:25.130476
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:35.856444
# Unit test for function camel_dict_to_snake_dict