

# Generated at 2022-06-16 22:27:55.436531
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': '5'
        },
        'Tags': {
            'Key': 'Value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'timeout': '5'
        },
        'tags': {
            'Key': 'Value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:28:05.552815
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test case 1
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'c': {'e': 4}}, {'c': {'e': 5}})

    # Test case 2
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Test case 3


# Generated at 2022-06-16 22:28:18.043488
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 6}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': 7}

# Generated at 2022-06-16 22:28:30.486317
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function"""
    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    result = recursive_diff(dict1, dict2)
    assert result == ({'b': {'d': 3}}, {'b': {'d': 4}, 'e': 5})

    dict1 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    result = recursive_diff(dict1, dict2)
    assert result is None


# Generated at 2022-06-16 22:28:43.071981
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_endpoint_description',
            'ServiceExecutionRole': 'test_service_execution_role',
            'EndpointType': 'test_endpoint_type',
            'VpcConfig': {
                'SecurityGroupIds': [
                    'test_security_group_id_1',
                    'test_security_group_id_2'
                ],
                'Subnets': [
                    'test_subnet_1',
                    'test_subnet_2'
                ]
            },
            'Tags': {
                'Key': 'test_key',
                'Value': 'test_value'
            }
        }
    }

    expected_snake_dict

# Generated at 2022-06-16 22:28:54.235783
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
            },
        },
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 7,
            },
        },
    }
    expected = ({'c': {'f': {'h': 6}}}, {'c': {'f': {'h': 7}}})
    assert recursive_diff(dict1, dict2) == expected

# Generated at 2022-06-16 22:29:02.939983
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    dict1 = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key4": "value4",
            "key5": "value5",
            "key6": {
                "key7": "value7",
                "key8": "value8",
                "key9": "value9"
            }
        }
    }

# Generated at 2022-06-16 22:29:13.871458
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:29:25.047238
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Enabled': True,
            'TimeoutInSeconds': 10,
            'HTTPMethod': 'POST',
            'AuthKey': '12345',
            'CustomHeaders': {
                'X-Custom-Header': 'CustomHeaderValue'
            }
        }
    }


# Generated at 2022-06-16 22:29:35.908051
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'foo'}) == {'http_endpoint': 'foo'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'foo'}, reversible=True) == {'h_t_t_p_endpoint': 'foo'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'foo', 'Tags': {'Key': 'bar'}}) == {'http_endpoint': 'foo', 'tags': {'Key': 'bar'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'foo', 'Tags': {'Key': 'bar'}}, ignore_list=['Tags']) == {'http_endpoint': 'foo', 'tags': {'Key': 'bar'}}

# Generated at 2022-06-16 22:29:49.889047
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-16 22:30:01.443172
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:13.859633
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.example.com',
            'Timeout': 3,
            'HTTPMethod': 'POST',
            'Username': 'username',
            'Password': 'password',
            'AuthType': 'BasicAuth',
            'CustomHeaders': {
                'CustomHeader': [
                    {
                        'Key': 'key1',
                        'Value': 'value1'
                    },
                    {
                        'Key': 'key2',
                        'Value': 'value2'
                    }
                ]
            }
        }
    }


# Generated at 2022-06-16 22:30:21.958123
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:30:34.325954
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '10',
            'HTTPMethod': 'POST',
            'HTTPPath': '/path',
            'Auth': {
                'Type': 'BASIC',
                'Username': 'username',
                'Password': 'password',
            },
            'Headers': {
                'Content-Type': 'application/json',
                'X-Custom-Header': 'value',
            },
            'Body': '{"key": "value"}',
        },
        'Tags': {
            'Key': 'value',
        },
    }


# Generated at 2022-06-16 22:30:46.340875
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': 'http://example.com',
        'Tags': {
            'Key': 'Value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:30:55.076594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 1
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'FailureThreshold': 1
        }
    }


# Generated at 2022-06-16 22:31:05.767031
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:31:17.041467
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'https://example.com',
                'Authorization': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'Name': 'test-endpoint',
            'ProtocolType': 'HTTP'
        },
        'Tags': {
            'key': 'value'
        }
    }

# Generated at 2022-06-16 22:31:26.216572
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': '10',
            'HTTPEndpointConfiguration': {
                'Authorization': {
                    'Type': 'AWS_IAM'
                },
                'EndpointType': 'EDGE'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:31:43.325055
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://localhost:8080',
            'Timeout': 10,
            'Period': 30,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'Path': '/',
            'Headers': {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Custom-Header': 'CustomHeaderValue'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:31:55.230723
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointURL': 'http://www.example.com',
            'AuthorizationConfig': {
                'AuthorizationType': 'AWS_IAM',
                'AWSRegion': 'us-east-1'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:32:06.504234
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:18.849679
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:28.644725
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:36.492921
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:32:48.663749
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:33:00.365025
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True, ignore_list=['fooBar']) == {'foo_bar': {'fooBar': 'baz'}}
    assert camel_dict_to

# Generated at 2022-06-16 22:33:13.110404
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 5,
            'Period': 60
        },
        'HTTPSEndpoint': {
            'Endpoint': 'https://www.example.com',
            'Timeout': 5,
            'Period': 60
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:33:24.288590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointName': 'test_endpoint',
            'HTTPEndpointDescription': 'test_description',
            'ServiceExecutionRole': 'test_role',
            'EndpointConfigName': 'test_config',
            'Tags': {
                'TagKey': 'test_key',
                'TagValue': 'test_value'
            }
        }
    }

# Generated at 2022-06-16 22:33:39.899897
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'Disabled': False,
            'Tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }

    expected_dict = {
        'http_endpoint': {
            'endpoint': 'http://example.com',
            'timeout': 1,
            'period': 60,
            'success_codes': '200,201',
            'disabled': False,
            'tags': {
                'Key': 'Value',
                'Key2': 'Value2'
            }
        }
    }

    assert camel_dict_to_

# Generated at 2022-06-16 22:33:47.914519
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://example.com",
            "Timeout": 10
        },
        "Tags": {
            "Key": "value"
        }
    }

    expected_snake_dict = {
        "h_t_t_p_endpoint": {
            "endpoint": "http://example.com",
            "timeout": 10
        },
        "tags": {
            "Key": "value"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict



# Generated at 2022-06-16 22:33:55.327465
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:04.619330
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:17.514849
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:26.333123
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 10
        },
        'Tags': {
            'Key': 'value'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
        ]
    }


# Generated at 2022-06-16 22:34:36.454150
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:34:46.468835
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Key': 'value'
        }
    }
    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Key': 'value'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-16 22:34:55.829938
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.example.com',
            'EndpointStatus': 'ACTIVE',
            'EndpointType': 'HTTP',
            'Tags': {
                'Key': 'value',
                'Key2': 'value2'
            }
        },
        'HTTPEndpoint2': {
            'EndpointURL': 'http://www.example.com',
            'EndpointStatus': 'ACTIVE',
            'EndpointType': 'HTTP',
            'Tags': {
                'Key': 'value',
                'Key2': 'value2'
            }
        }
    }

# Generated at 2022-06-16 22:35:05.262161
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}) == {'foo_bar': {'foo_bar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, reversible=True) == {'foo_bar': {'foo_b_ar': 'baz'}}
    assert camel_dict_to_snake_dict({'fooBar': {'fooBar': 'baz'}}, ignore_list=['fooBar']) == {'foo_bar': {'fooBar': 'baz'}}
    assert camel_dict_to_sn

# Generated at 2022-06-16 22:35:22.149697
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 10,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HTTPMethod': 'GET',
            'HTTPCode': 200,
            'HTTPVersion': 'HTTP/1.1',
            'Disabled': False,
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            },
            'Tags': {
                'Key': 'Value'
            }
        }
    }


# Generated at 2022-06-16 22:35:32.539326
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://example.com/',
            'Protocol': 'HTTP',
            'TimeoutInSeconds': 10,
            'Tags': {
                'Key': 'value'
            }
        },
        'HTTPSEndpoint': {
            'EndpointURL': 'https://example.com/',
            'Protocol': 'HTTPS',
            'TimeoutInSeconds': 10,
            'Tags': {
                'Key': 'value'
            }
        }
    }


# Generated at 2022-06-16 22:35:44.626832
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:35:53.712601
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:36:05.116027
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://example.com',
            'Timeout': 1,
            'Period': 60,
            'SuccessCodes': '200,201',
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HttpCode': '200'
            }
        },
        'Tags': {
            'Key': 'Value'
        }
    }

# Generated at 2022-06-16 22:36:11.310632
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Protocol': 'HTTP'
        },
        'Tags': {
            'Name': 'Test'
        }
    }
    expected_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'http://www.example.com',
            'protocol': 'HTTP'
        },
        'tags': {
            'Name': 'Test'
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict


# Generated at 2022-06-16 22:36:20.292785
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'https://example.com',
            'Protocol': 'HTTPS',
            'AuthKey': 'authkey',
            'Name': 'httpendpoint',
            'Tags': {
                'Key': 'Value'
            }
        }
    }
    expected_snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint_url': 'https://example.com',
            'protocol': 'HTTPS',
            'auth_key': 'authkey',
            'name': 'httpendpoint',
            'tags': {
                'Key': 'Value'
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
   

# Generated at 2022-06-16 22:36:31.799841
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'https://www.example.com',
            'Protocol': 'HTTPS',
            'Method': 'POST',
            'Auth': {
                'AuthType': 'AWS_IAM',
                'AWS4SignerType': 'AWS_IAM',
                'AWS4SignerName': 'AWS4SignerType'
            },
            'Headers': [
                {
                    'Key': 'Content-Type',
                    'Value': 'application/json'
                }
            ],
            'Body': '{"key": "value"}',
            'ContentEncoding': 'NONE',
            'ClientProfileName': 'default'
        },
        'Tags': {
            'key': 'value'
        }
    }



# Generated at 2022-06-16 22:36:38.960843
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'HTTPEndpointConfiguration': {
                'URL': 'http://example.com',
                'AuthorizationConfig': {
                    'AuthorizationType': 'AWS_IAM',
                    'AWS_IAM': {
                        'SigningRegion': 'us-east-1',
                        'SigningServiceName': 'execute-api'
                    }
                }
            },
            'EndpointType': 'HTTP',
            'TargetArn': 'arn:aws:lambda:us-east-1:123456789012:function:my-function'
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-16 22:36:45.314355
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:15.209500
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'https://example.com',
            'Protocol': 'HTTPS'
        },
        'Tags': {
            'Key': 'value'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoint': {
            'endpoint': 'https://example.com',
            'protocol': 'HTTPS'
        },
        'tags': {
            'Key': 'value'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict, reversible=True) == camel_dict

# Generated at 2022-06-16 22:37:25.977327
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointType': 'PRIVATE',
            'TargetGroupARNs': [
                'arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
                'arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
            ],
            'URL': 'http://my-service.us-west-2.elb.amazonaws.com:8080'
        },
        'Tags': {
            'Key': 'Project',
            'Value': 'My Service'
        }
    }

    expected_snake

# Generated at 2022-06-16 22:37:31.723859
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-16 22:37:41.811617
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80,
            'Path': '/',
            'Timeout': 30,
            'HealthyThreshold': 5,
            'UnhealthyThreshold': 2,
            'Matcher': {
                'HTTPCode': '200-399'
            }
        },
        'Tags': [
            {
                'Key': 'key1',
                'Value': 'value1'
            },
            {
                'Key': 'key2',
                'Value': 'value2'
            }
        ]
    }
