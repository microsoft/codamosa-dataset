

# Generated at 2022-06-22 21:30:37.630822
# Unit test for function recursive_diff
def test_recursive_diff():
    from copy import deepcopy
    from pprint import pprint

    base = {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': 'Template for a simple EC2 instance',
        'Parameters': {
            'AmiId': {
                'Description': 'ID of a Windows Server 2016 Base AMI',
                'Type': 'AWS::EC2::Image::Id',
            }
        },
        'Resources': {
            'MyInstance': {
                'Properties': {
                    'ImageId': { 'Ref': 'AmiId' },
                    'InstanceType': 't2.micro'
                },
                'Type': 'AWS::EC2::Instance'
            }
        }
    }

    modified = deepcopy(base)

# Generated at 2022-06-22 21:30:48.590868
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:30:59.906362
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {"key-1": "value-1", "key-2": "value-2"}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=False) == {"key1": "value-1", "key2": "value-2"}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == {"Key1": "value-1", "Key2": "value-2"}

    snake_dict = {"key_1": "value-1", "key_2": "value-2"}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=False) == {"key1": "value-1", "key2": "value-2"}

# Generated at 2022-06-22 21:31:11.450593
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test1 = {'test_key': 'test_value'}
    test2 = {
        'test_key': 'test_value',
        'test_dict': {
            'test_key': 'test_value'
        },
        'test_dict_list': [
            {
                'test_key': 'test_value'
            }
        ]
    }
    test3 = {'test_key': 'test_value', 'test_key_2': 'test_value_2'}
    assert test_snake_dict_to_camel_dict_run(test1, 'test_key', 'testKey') is True
    assert test_snake_dict_to_camel_dict_run(test2, 'test_key', 'testKey') is True
    assert test_snake_dict_to

# Generated at 2022-06-22 21:31:22.562822
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sample_dict = {
        'test_1': 'val1',
        'test_2': {
            'test_3': 'val2',
            'test_4': [
                'val3',
                {
                    'test_5': 'val4'
                }
            ]
        },
        'test_6': {
            'test_7': {
                'test_8': 'val5'
            }
        },
        'test_9': {
            'HTTPEndpoint': {
                'URL': 'val6'
            }
        },
        'test_10': {
            'test_11': {
                'test_12': 'val7'
            }
        },
    }


# Generated at 2022-06-22 21:31:31.279554
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = {'target_group_arns': [
        'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067',
        'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'],
        'target_health_descriptions': [{'Target': {'Id': 'i-0f76fade', 'Port': 80},
                                       'HealthCheckPort': '80',
                                       'TargetHealth': {'State': 'healthy',
                                                        'Reason': 'Elb.Healthy'}}]}

# Generated at 2022-06-22 21:31:41.410551
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': 1, 'baz_quux': [2, 3]}) == {'fooBar': 1, 'bazQuux': [2, 3]}
    assert snake_dict_to_camel_dict({'foo_bar': 1, 'baz_quux': [2, 3]}, capitalize_first=True) == {'FooBar': 1, 'BazQuux': [2, 3]}

# Generated at 2022-06-22 21:31:49.681493
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test = {
        "access_logs": {
            "enabled": True,
            "s3": {
                "bucket_name": "my-bucket",
                "buffering_hints": {
                    "interval_in_seconds": 300,
                    "size_in_m_bs": 2
                },
                "prefix": "my-app"
            }
        },
        "description": "My App HTTP Endpoint",
        "endpoint_url": "https://example.com",
        "name": "my-app",
        "protocol_type": "HTTP",
        "tags": {
            "Owner": "my-owner",
            "MyApp": "Production"
        }
    }


# Generated at 2022-06-22 21:32:00.239726
# Unit test for function recursive_diff
def test_recursive_diff():
    # Case 1: No changes
    dict1 = {"key1": {"key2": "value"},
             "key3": "value"}
    dict2 = {"key1": {"key2": "value"},
             "key3": "value"}
    assert recursive_diff(dict1, dict2) is None

    # Case 2: Only values have changed
    dict1 = {"key1": {"key2": "value"},
             "key3": "value"}
    dict2 = {"key1": {"key2": "value2"},
             "key3": "value2"}

# Generated at 2022-06-22 21:32:12.570594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dictionary = {
        'KeyName': 'test',
        'MaxSize': 'test',
        'HTTPEndpoint': {
            'Enabled': 'test',
            'HTTPPort': 'test',
            'HTTPSPort': 'test'
        },
        'Tags': {
            'key': 'value',
            'key2': 'value2'
        },
        'Disabled': 'test',
        'HTTPEndpoints': [{
            'Enabled': 'test',
            'HTTPPort': 'test',
            'HTTPSPort': 'test'
        }],
        'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']
    }


# Generated at 2022-06-22 21:32:24.555758
# Unit test for function dict_merge
def test_dict_merge():
    d1 = dict(a='foo', b=1, c=dict(a='foo', b='bar'), d=set([1, 2, 3]))
    d2 = dict(a='foo2', b=2, c=dict(a='fooW', b='barW'), d=set([3, 4, 5]))

    d3 = dict_merge(d1, d2)
    assert d3['a'] == 'foo2'
    assert d3['b'] == 2
    assert d3['c']['a'] == 'fooW'
    assert d3['c']['b'] == 'barW'
    assert d3['d'] == set([1, 2, 3, 4, 5])
    d3 = dict_merge(d2, d1)

# Generated at 2022-06-22 21:32:34.879881
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'foo': {
            'camelList': [
                {
                    'camelCase': 'casey',
                    'camelCamel': [
                        'camel'
                    ]
                }
            ],
            'camelCamel': 'CAMEL',
            'camelCase': 'CASE',
            'IgnoreCase': 'case',
            'IgnoreCamel': 'camel',
            'Tags': [
                {
                    'Key': 'key',
                    'Value': 'value'
                },
                {
                    'Key': 'key2',
                    'Value': 'value2'
                }
            ]
        }
    }


# Generated at 2022-06-22 21:32:45.730975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_camel_dict = {
        'HTTPEndpoint': 'some-endpoint',
        'targetType': 'some-target',
        'targets': ['TARG_1', 'TARG_2'],
        'Tags': {
            'Key': {
                'tag-key': 'tag-value'
            }
        },
        'TargetGroupARNs': ['ARN1', 'ARN2'],
        'ChildStacks': [
            {
                'TargetGroupARNs': ['ARN1', 'ARN2']
            },
            {
                'TargetGroupARNs': ['ARN1', 'ARN2']
            }
        ]
    }

# Generated at 2022-06-22 21:32:54.419332
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:33:05.224513
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for function camel_dict_to_snake_dict
    """

    # TODO: This test should be changed to use pytest.
    def assert_dictionary_equals(message, expected, actual):
        assert expected == actual, "%s\nexpected: %s\nactual: %s\n" % (message, expected, actual)

    def assert_dict_snake(expected, actual):
        assert_dictionary_equals("Non-reversible conversion failed", expected, actual)
        assert_dictionary_equals("Reversible conversion failed", actual, camel_dict_to_snake_dict(expected, True))

    assert_dict_snake({'test': 'abc'}, {'Test': 'abc'})
    assert_dict_snake({'test': None}, {'Test': None})

# Generated at 2022-06-22 21:33:14.982292
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {"key1": "value1", "key2": "value2", "key3": {"key31": {'key311': 'value311'}, "key32": "value32"}}
    dict2 = {"key2": "value2", "key3": {"key31": {'key311': 'value311', 'key312': 'value312'}, "key32": "value32"}}
    expected_result = ({'key1': 'value1', 'key3': {'key31': {'key312': 'value312'}}}, {'key3': {'key31': {'key312': 'value312'}}})
    assert expected_result == recursive_diff(dict1, dict2)

# Generated at 2022-06-22 21:33:24.590999
# Unit test for function recursive_diff
def test_recursive_diff():
    def _test_diff(dict1, dict2, expected):
        actual = recursive_diff(dict1, dict2)
        assert actual == expected

    # Testing empty dictionary
    _test_diff({}, {}, None)

    # Testing same dictionaries
    _test_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 2}, None)

    # Testing different dictionaries
    _test_diff(
        {'a': 1, 'b': {'c': 4, 'd': 5}, 'e': 6},
        {'a': 1, 'b': {'c': 4}, 'e': 7},
        ({'b': {'d': 5}, 'e': 6}, {'b': {}, 'e': 7})
    )

# Generated at 2022-06-22 21:33:30.135623
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'sub': {'foo': -1, 'bar': 5}}
    b = {'y': 3, 'z': 4, 'sub': {'bar': 6}}
    c = dict_merge(a, b)

    assert(c['x'] == 1)
    assert(c['y'] == 3)
    assert(c['z'] == 4)
    assert(c['sub']['foo'] == -1)
    assert(c['sub']['bar'] == 6)


# Custom unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:33:40.034152
# Unit test for function dict_merge
def test_dict_merge():
    # Simple merge
    a = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4'}}
    b = {'a': '5', 'c': {'d': '6', 'e': '7'}}
    r = dict_merge(a, b)
    expected = {'a': '5', 'b': '2', 'c': {'d': '6', 'e': '7'}}
    assert r == expected, "dict_merge(a, b) returned %s but expected %s" % (r, expected)
    # Change in nested dict
    a = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4'}}

# Generated at 2022-06-22 21:33:50.672223
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_case = {'abc_def_ghi': {'abc_def': {'abc_def_xyz': 3}, 'abc_xyz': 5}}
    camel_case = {'AbcDefGhi': {'AbcDef': {'AbcDefXyz': 3}, 'AbcXyz': 5}}
    assert snake_dict_to_camel_dict(snake_case) == camel_case

    camel_case = {'abcDefGhi': {'abcDef': {'abcDefXyz': 3}, 'abcXyz': 5}}
    assert snake_dict_to_camel_dict(snake_case, capitalize_first=False) == camel_case


# Generated at 2022-06-22 21:34:01.675500
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        "VpcSecurityGroupIds": [
            "sg-12345678"
        ],
        "SubnetIds": [
            "subnet-123456"
        ],
        "AvailabilityZone": "us-east-1a",
        "Port": "3306",
        "AvailabilityZone": "us-east-1a",
        "MultiAZ": "true"
    }
    b = {
        "SubnetIds": [
            "subnet-234567"
        ],
        "MultiAZ": "false",
        "DBSecurityGroups": [
            "sg-2345678"
        ]
    }


# Generated at 2022-06-22 21:34:10.290455
# Unit test for function dict_merge
def test_dict_merge():

    assert dict_merge({}, {}) == {}
    assert dict_merge(
        {}, {'foo': 'bar'}) == {'foo': 'bar'}
    assert dict_merge(
        {'foo': 'bar'}, {}) == {'foo': 'bar'}
    assert dict_merge(
        {'foo': 'bar'}, {'foo': 'bar'}) == {'foo': 'bar'}
    assert dict_merge(
        {'foo': 'bar'}, {'foo': 'baz'}) == {'foo': 'baz'}
    assert dict_merge(
        {'foo': 'bar'}, {'foo': {'bar': 'baz'}}) == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-22 21:34:20.296865
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'id':'test_id',
        'tags':{'role':'test_role'},
        'name':'test_name',
        'taskId':'test_taskId',
        'taskIds':['test_taskId_1', 'test_taskId_2'],
        'taskIdFoo':'test_taskIdFoo'
    }
    expected_dict = {
        'id':'test_id',
        'tags':{'role':'test_role'},
        'name':'test_name',
        'task_id':'test_taskId',
        'task_ids':['test_taskId_1', 'test_taskId_2'],
        'task_id_foo':'test_taskIdFoo'
    }
    assert camel

# Generated at 2022-06-22 21:34:25.665011
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'on_premises_instance_tags': [
            {
                'key': 'foo',
                'value': 'bar',
                'type': 'KEY_AND_VALUE',
            },
        ],
        'app_spec_content': {
            'resources': [
                {
                    'target_id': 'i-aabbccd1e2f3',
                    'type': 'EC2_INSTANCE',
                },
            ],
            'version': '0.0',
        },
    }

# Generated at 2022-06-22 21:34:35.563489
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': 'baz'}) == {'fooBar': 'baz'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz'}, capitalize_first=True) == {'FooBar': 'baz'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz', 'foo_bar_baz': 'qux'}) == {'fooBar': 'baz', 'fooBarBaz': 'qux'}
    assert snake_dict_to_camel_dict({'foo_bar': 'baz', 'foo_bar_baz': 'qux'}, capitalize_first=True) == {'FooBar': 'baz', 'FooBarBaz': 'qux'}



# Generated at 2022-06-22 21:34:48.739265
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {u'Index': 1, u'Restore': u'false', u'UniqueId': u'a1b2c3d',
                  u'Products': [{u'ProductCode': u'AmazonES',
                                 u'ProductName': u'Amazon Elasticsearch Service'}],
                  u'Id': u'1', u'SubnetIds': [u'subnet-1234abcd', u'subnet-abcd1234'],
                  u'Tags': {u'key': u'value'}}

    # Convert to snake case and confirm original `camel_dict` is unchanged
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-22 21:35:00.044623
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'camel_case': 'test',
                                     'lower_case': 'foobar'}) == {'camelCase': 'test', 'lowerCase': 'foobar'}

    assert snake_dict_to_camel_dict({'tag': {'tag_key': 'Name', 'tag_value': 'TestServer'}}) == \
           {'tag': {'tagKey': 'Name', 'tagValue': 'TestServer'}}

    assert snake_dict_to_camel_dict({'tags': {'tags': [{'key': 'Name', 'value': 'TestServer'}]}}) == \
           {'tags': {'tags': [{'key': 'Name', 'value': 'TestServer'}]}}

    # Test the capitalize_first option
    assert snake

# Generated at 2022-06-22 21:35:09.650216
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict_true_camel_case = {'key_name': 'value', 'key_name2': 'value2',
                                  'key_name3': {'key_name4': 'value4', 'key_name5': 'value5'},
                                  'key_name6': [{'key_name7': 'value7'}, {'key_name8': 'value8'}]}
    snake_dict_dromedary_case = {'key_name': 'value', 'key_name2': 'value2',
                                 'key_name3': {'key_name4': 'value4', 'key_name5': 'value5'},
                                 'key_name6': [{'key_name7': 'value7'}, {'key_name8': 'value8'}]}

    camel_

# Generated at 2022-06-22 21:35:19.793591
# Unit test for function dict_merge

# Generated at 2022-06-22 21:35:29.466814
# Unit test for function dict_merge
def test_dict_merge():

    # dict_merge sample dicts
    first = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': {'g': 5, 'h': 6}}}
    second = {'a': 10, 'b': 20, 'd': {'e': 40, 'f': {'g': 50}}}

    # dict_merge correctness test
    assert dict_merge(first, second) == {'a': 10, 'b': 20, 'c': 3, 'd': {'e': 40, 'f': {'g': 50, 'h': 6}}}

    # dict_merge left deep copy test
    first_copy = deepcopy(first)
    dict_merge(first_copy, second)
    assert first == first

    # dict_merge left deep copy test


# Generated at 2022-06-22 21:35:38.427389
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        'a': {
            'b': {
                'c': 1,
            },
            'd': 2,
            'e': 3,
        },
        'f': 4,
        'g': 5,
    }
    d2 = {
        'a': {
            'b': {
                'c': 5,
                'd': 6,
            },
            'd': 7,
            'e': {
                'f': 8,
                'g': 9,
            },
        },
        'g': 10,
        'h': 11,
    }
    d3 = dict_merge(d1, d2)

# Generated at 2022-06-22 21:35:49.595211
# Unit test for function dict_merge
def test_dict_merge():
    '''
    Test for dict_merge
    '''

    first = {'a': 1, 'b': 2, 'c': None}
    second = {'b': None, 'c': 3}
    assert dict_merge(first, second) == {'a': 1, 'b': 2, 'c': 3}

    first = {'a': 1, 'b': 2, 'c': {'e': 5, 'f': 6}}
    second = {'b': None, 'c': {'e': None, 'g': 7}}
    assert dict_merge(first, second) == {'a': 1, 'b': 2, 'c': {'e': 5, 'f': 6, 'g': 7}}


# Generated at 2022-06-22 21:35:58.780341
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:04.172215
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    some_dict = {
        'HTTPEndpoint': {
            'Name': 'http-endpoint',
            'SubDomain': 'example.com',
            'TLSSecurityPolicy': 'RedirectToHTTPS',
            'CertificateArn': 'arn:aws:acm:us-east-2:123456789012:certificate/12345678-1234-1234-1234-123456789012',
            'Targets': [{
                'TargetType': 'instance',
                'TargetValue': 'i-1234567890abcdef0'
            }]
        },
        'Tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-22 21:36:13.651317
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"foo_bar": 1}) == {"fooBar": 1}
    assert snake_dict_to_camel_dict({"foo_bar": 1}, True) == {"FooBar": 1}
    assert snake_dict_to_camel_dict({"foo_bar_baz": 1}) == {"fooBarBaz": 1}
    assert snake_dict_to_camel_dict({"foo_bar_baz": 1}, True) == {"FooBarBaz": 1}
    assert snake_dict_to_camel_dict({"foo_bar_baz_": 1}) == {"fooBarBaz": 1}
    assert snake_dict_to_camel_dict({"foo_bar_baz_": 1}, True) == {"FooBarBaz": 1}


# Generated at 2022-06-22 21:36:21.278690
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"a_key":"a_value","another_key":3}
    expected_dict = {"aKey":"a_value","anotherKey":3}
    resulting_dict = snake_dict_to_camel_dict(test_dict)
    assert resulting_dict == expected_dict, "snake_dict_to_camel_dict does not behave as expected"
    test_dict = {"http_endpoint":"a_value", "list_of_strings":["a","b","c"]}
    expected_dict = {"httpEndpoint":"a_value", "listOfStrings":["a","b","c"]}
    resulting_dict = snake_dict_to_camel_dict(test_dict)
    assert resulting_dict == expected_dict, "snake_dict_to_camel_dict does not behave as expected"
   

# Generated at 2022-06-22 21:36:32.210355
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, \
        "dict_merge failed merging %s and %s" % (a, b)

    a = {}
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }

# Generated at 2022-06-22 21:36:41.064536
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def assert_snake_keys(snake_dict, camel_dict):
        for key in snake_dict.keys():
            assert key in camel_dict.keys()

    simple_camel_dict = {
        'camelCaseKey1': 'value1',
        'camelCaseKey2': {
            'CamelCaseKey3': 'value3'
        },
        'camelCaseKey4': [
            {
                'CamelCamelCaseKey5': 'value5'
            },
            {
                'camelCaseKey6': 'value6'
            }
        ]
    }


# Generated at 2022-06-22 21:36:51.905754
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'key1': 'value1',
        'key2': dict(a=1, b=2),
        'key3': {
            'key4': 'value4',
            'key5': {
                'key6': 'value6'
            }
        }
    }
    b = {
        'key2': dict(c=3),
        'key3': {
            'key5': {
                'key7': 'value7'
            },
            'key8': 'value8'
        },
        'key9': 'value9'
    }

# Generated at 2022-06-22 21:36:55.404264
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = dict(a='a', b=dict(a='a', b='b', c='b'), c=dict(a='a', b='b', c='b'))
    dict2 = dict(a='a', b=dict(a='a', b='b', c='c'), c=dict(a='a', b='b', c='b'))

    result_dict = recursive_diff(dict1, dict2)

    assert result_dict == ({'b': {'c': ('b', 'c')}, 'c': None},)


# Generated at 2022-06-22 21:37:01.794823
# Unit test for function recursive_diff
def test_recursive_diff():
    '''
    The unit test is inspired by the following PR:
    '''
    # https://github.com/ansible/ansible/pull/36257

    assert recursive_diff(dict1={}, dict2={}) is None

    assert recursive_diff(
        dict1={'a': 1, 'b': 2, 'c': 3},
        dict2={'a': 1, 'b': 2, 'c': 3}) is None

    assert recursive_diff(
        dict1={'a': 1, 'b': 2, 'c': 3},
        dict2={'a': 1, 'b': 2, 'c': 4}) == ({'c': 3}, {'c': 4})


# Generated at 2022-06-22 21:37:12.462015
# Unit test for function dict_merge

# Generated at 2022-06-22 21:37:23.642616
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': 1}) == {'fooBar': 1}
    assert snake_dict_to_camel_dict({'foo_bar': 1}, capitalize_first=True) == {'FooBar': 1}
    assert snake_dict_to_camel_dict({'foo_bar': [1,2,3]}) == {'fooBar': [1,2,3]}
    assert snake_dict_to_camel_dict({'foo_bar': [1,2,3]}, capitalize_first=True) == {'FooBar': [1,2,3]}
    assert snake_dict_to_camel_dict({'foo_bar': {'a': 1, 'b': 2}}) == {'fooBar': {'a': 1, 'b': 2}}

# Generated at 2022-06-22 21:37:34.494954
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'list': [
            {'ThisKeyNameIsCamelCase': 'value1'},
            {'thisKeyNameIsCamelCase': 'value2'},
            {'ThisKeyNameIsCamelCase': {'Time': 'value3'}},
        ],
        'thisKeyNameIsCamelCase': 'value4',
        'dict': {'ThisKeyNameIsCamelCase': 'value5'},
        'Tags': [{'Key': 'key', 'Value': 'value'}],
    }

    check_reversible = camel_dict_to_snake_dict(camel_dict_to_snake_dict(test_dict, True), True)

    check_camel_to_snake = camel_dict_to_snake_dict(test_dict)
    assert check

# Generated at 2022-06-22 21:37:43.527794
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=dict(x=dict(x1=1, x2=2), y=1))
    dict2 = dict(b=dict(x=dict(x2=2, x3=3), y=2))
    dict3 = dict(a=dict(x=dict(x1=1, x2=22), y=1))
    dict4 = dict(a=dict(x=dict(x1=1, x2=2), y=22))
    dict5 = dict(a=dict(x=dict(x1=1, x2=2), y=1, z=1))
    dict6 = dict(a=dict(x=dict(x1=1, x2=2), y=1))
    dict7 = dict(a=dict(x=1, y=1))

    result

# Generated at 2022-06-22 21:37:48.320033
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(x=dict(a=2, b=3, c=4), y=dict(a=2, b=3, c=4))
    b = dict(x=dict(a=1, b=9), z=dict(a=2, b=3, c=4))
    r = dict(x=dict(a=1, b=9, c=4), y=dict(a=2, b=3, c=4), z=dict(a=2, b=3, c=4))
    c = dict_merge(a, b)
    assert(c == r)

    a = dict(x=1, y=2, z=3, n=dict(x=1, y=2, z=3))

# Generated at 2022-06-22 21:37:59.526666
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {'diff': 'different',
            'same': 'same'}
    right = {'same': 'same',
             'diff': 'different'}
    assert recursive_diff(left, right) == None
    left['diff2'] = {'A': 'different'}
    assert recursive_diff(left,right) == ({'diff2': {'A': 'different'}}, {'diff2': {'A': 'different'}})
    right['diff2'] = {'A': 'different'}
    assert recursive_diff(left,right) == None
    right['diff2'] = {'A': 'different'
                      ,'B': 'different'}

# Generated at 2022-06-22 21:38:09.877723
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'r': 22, 'y': 23}, 'd': 4, 'f': {'g': {'h': 2, 'j': 4}}}
    b = {'b': {'x': 3}, 'c': 3, 'd': {'e': 5}, 'f': {'g': {'i': 3}}}
    assert dict_merge(a, b) == {'a': 1, 'b': {'r': 22, 'y': 23, 'x': 3}, 'c': 3, 'd': {'e': 5}, 'f': {'g': {'h': 2, 'j': 4, 'i': 3}}}

# Generated at 2022-06-22 21:38:19.710356
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    sample_data = {
        "http_body": {
            "any_data_type": True,
            "http_endpoints": [
                {
                    "url": "http://localhost:8080",
                    "headers": {
                        "username": "user",
                        "password": "password"
                    }
                }
            ]
        }
    }

    result = snake_dict_to_camel_dict(sample_data)

    assert result["httpBody"]["anyDataType"] is True
    assert isinstance(result["httpBody"]["httpEndpoints"], list)
    assert len(result["httpBody"]["httpEndpoints"]) == 1
    assert result["httpBody"]["httpEndpoints"][0]["url"] == "http://localhost:8080"

# Generated at 2022-06-22 21:38:30.338139
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {'HTTPHeaders': [{'Name': 'X-Test-Header1', 'Value': 'Test-Value1'}, {'Name': 'X-Test-Header2', 'Value': 'Test-Value2'}], 'ViewerProtocolPolicy': 'redirect-to-https'}
    result = camel_dict_to_snake_dict(data)
    assert result == {'http_headers': [{'name': 'X-Test-Header1', 'value': 'Test-Value1'}, {'name': 'X-Test-Header2', 'value': 'Test-Value2'}], 'viewer_protocol_policy': 'redirect-to-https'}
    result = camel_dict_to_snake_dict(data, reversible=True)

# Generated at 2022-06-22 21:38:43.014050
# Unit test for function recursive_diff
def test_recursive_diff():
    # no diff
    assert recursive_diff({'a':1}, {'a':1}) == None
    # primitive values
    assert recursive_diff({'a':2}, {'a':1}) == ({'a':2}, {'a':1})
    # nested level 1, object
    assert recursive_diff({'a':{'b':1}}, {'a':{'b':2}}) == ({'a':{'b':1}}, {'a':{'b':2}})
    # nested level 1, array
    assert recursive_diff({'a':[1,2,3]}, {'a':[1,2,3]}) == None

# Generated at 2022-06-22 21:38:49.659690
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'iam': {'arn': 'x'}}, capitalize_first=False)['iam']['arn'] == 'x'
    assert snake_dict_to_camel_dict({'iam': {'arn': 'x'}}, capitalize_first=True)['Iam']['arn'] == 'x'



# Generated at 2022-06-22 21:38:55.604495
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"CamelCase": "test", "CamelCase2": "test2"}
    snake_dict = {"camel_case": "test", "camel_case2": "test2"}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_snake_dict(snake_dict) == camel_dict


# Generated at 2022-06-22 21:39:07.576290
# Unit test for function recursive_diff
def test_recursive_diff():
    assert None == recursive_diff({'a': 'A', 'b': 'B'}, {'a': 'A', 'b': 'B'})
    assert ({'b': 'B', 'a': 'A'}, {}) == recursive_diff({'a': 'A', 'b': 'B'}, {'a': 'X', 'b': 'B'})
    assert ({'a': 'A'}, {'b': 'B'}) == recursive_diff({'a': 'A'}, {'b': 'B'})
    assert ({'a': 'A'}, {'b': 'C', 'a': 'A'}) == recursive_diff({'a': 'A'}, {'b': 'C', 'a': 'X'})

# Generated at 2022-06-22 21:39:17.350184
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_to_test = dict(
        AKey='AValue',
        HTTPEndpoint='HVal',
        HTTPSEndpoint='HVal',
        Tags=[{'Key': 'v1', 'Value': 'vv1'}, {'Key': 'v2', 'Value': 'vv2'}],
        Targets=[{'Id': 'id1'}, {'Id': 'id2'}],
        OtherKey=[{'SecretAccessKey': 'Secret', 'KeyName': 'Value'},
                  {'SecretAccessKey': 'Secret', 'KeyName': 'Value'}])

    # This should not change due to 'reversible=False'

# Generated at 2022-06-22 21:39:29.092662
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Test empty dict
    output = snake_dict_to_camel_dict({})
    assert output is None, "snake_dict_to_camel_dict failed with empty dict"

    # Test dict with all caps key
    input_dict = {"SSH_KEY": "ssh-rsa foo"}
    output = snake_dict_to_camel_dict(input_dict)

    assert output == input_dict, "snake_dict_to_camel_dict failed with dict with all caps key"

    # Test dict with nested dict to be converted
    input_dict = {
        "SSH_KEY": "ssh-rsa foo",
        "NESTED_TEST": {"TWO_KEY": "test", "ANOTHER_TWO": "test", "THREE_KEYS": "test"},
    }
    output

# Generated at 2022-06-22 21:39:40.610323
# Unit test for function dict_merge
def test_dict_merge():
    """
    Unit test for function dict_merge
    """

    # Test 1
    a = {'x': 1, 'y': 2}
    b = {'x': 3, 'z': 4}
    c = {'x': 3, 'y': 2, 'z': 4}
    assert dict_merge(a, b) == c

    # Test 2
    a = {'x': {'a': 1, 'b': 2}}
    b = {'x': {'a': 3, 'c': 4}}
    c = {'x': {'a': 3, 'b': 2, 'c': 4}}
    assert dict_merge(a, b) == c

    # Test 3
    a = {'x': 1, 'y': {'a': 1, 'b': 2}}

# Generated at 2022-06-22 21:39:50.819826
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {"HTTPStatusCode": 200,
            "HTTPHeaders": {"x-amzn-RequestId": "1c8b73e0-9f7e-11e8-8a12-43a0a738c62e",
                            "x-amz-apigw-id": "TnTBA3dAJAMFayA=",
                            "Content-Type": "application/json"},
            "RetryAttempts": 0,
            "Tags": {"Name": "test-lambda"},
            "ready": False}

    output = camel_dict_to_snake_dict(data)
    assert output['h_t_t_p_status_code'] == 200

# Generated at 2022-06-22 21:40:00.297688
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key1': 'value1',
        'key2': 2,
        'key3': {
            'k3_1': {
                'sub_k1': 'sub_v1',
                'sub_k2': 'sub_v2',
            },
            'k3_2': 'sub_v2',
        }
    }
    dict2 = {
        'key1': 'value1',
        'key3': {
            'k3_1': {
                'sub_k1': 'sub_v1',
            },
            'k3_3': 'sub_v3',
        }
    }

# Generated at 2022-06-22 21:40:10.317502
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "key1": "value1", "key2": "value2",
        "dict1": {"key11": "value11", "key12": {"key121": "value121", "key122": "value122"}}
    }
    dict2 = {
        "key3": "value3", "key2": "value2",
        "dict1": {"key11": "value11", "key12": {"key121": "value121", "key122": "value123"}}
    }
    assert recursive_diff(dict1, dict2) == ({'key1': 'value1'}, {'key3': 'value3'})

# Generated at 2022-06-22 21:40:17.464703
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = dict()
    test_dict['my_key'] = 'my_value'
    test_dict['my_key2'] = 'my_value2'
    test_dict['my_key3'] = 42
    test_dict['my_key4'] = dict()
    test_dict['my_key4']['my_key5'] = 42
    test_dict['my_key4']['my_key6'] = dict()
    test_dict['my_key4']['my_key6']['my_key7'] = 42
    test_dict['my_key4']['my_key6']['my_key8'] = 'my_value8'

    camel_dict = snake_dict_to_camel_dict(test_dict)
    assert 'myKey' in camel_

# Generated at 2022-06-22 21:40:27.962930
# Unit test for function recursive_diff
def test_recursive_diff():
    from types import GeneratorType
    from nose.tools import eq_, ok_
    from ansible.module_utils.common.dict_merge import recursive_diff

    # Test for both non-dict inputs
    try:
        result = recursive_diff(1, 2)
    except TypeError:
        ok_(True, "Test for both non-dict inputs passed.")
    else:
        eq_(result, None, "Test for both non-dict inputs failed.")

    # Test for one dict input
    try:
        result = recursive_diff({}, 2)
    except TypeError:
        ok_(True, "Test for one dict input passed.")
    else:
        eq_(result, None, "Test for one dict input failed.")

    # Test for one dict input