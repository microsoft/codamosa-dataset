

# Generated at 2022-06-22 21:30:34.557929
# Unit test for function recursive_diff
def test_recursive_diff():
    # empty dictionaries
    assert recursive_diff({}, {}) == None
    # dictionaries with same pair of key value
    assert recursive_diff({1: "vmware_vcenter"}, {1: "vmware_vcenter"}) == None
    # dictionaries with one key value pair for dict1
    assert recursive_diff({1: "vmware_vcenter"}, {}) == ({1: "vmware_vcenter"}, {})
    # dictionaries with one key value pair for dict2
    assert recursive_diff({}, {1: "vmware_vcenter"}) == ({}, {1: "vmware_vcenter"})
    # dictionaries with one key value pair for dict1 and dict2

# Generated at 2022-06-22 21:30:42.721909
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    data = {
        'snake_case': {
            'another_dictionary': {
                'snake_key': {
                    'list_key': []
                }
            }
        }
    }
    assert snake_dict_to_camel_dict(data) == {
        'snakeCase': {
            'anotherDictionary': {
                'snakeKey': {
                    'listKey': []
                }
            }
        }
    }
    assert snake_dict_to_camel_dict(data, capitalize_first=True) == {
        'SnakeCase': {
            'AnotherDictionary': {
                'SnakeKey': {
                    'ListKey': []
                }
            }
        }
    }

# Generated at 2022-06-22 21:30:53.259765
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'Name': 'test'}}
    snake_dict = camel_dict_to_snake_dict(test_dict)
    assert(snake_dict == {'http_endpoint': {'name': 'test'}})

    test_dict = {'HTTPEndpoint': {'Name': 'test'}}
    snake_dict = camel_dict_to_snake_dict(test_dict, reversible=True)
    assert(snake_dict == {'h_t_t_p_endpoint': {'name': 'test'}})

    test_dict = {'HTTPEndpoint': {'Name': 'test'}}
    tags = [{'Key': 'A', 'Value': '1'}, {'Key': 'B', 'Value': '2'}]
    test_

# Generated at 2022-06-22 21:31:05.172131
# Unit test for function dict_merge
def test_dict_merge():
    p1 = dict(
        key1=dict(
            key2=10,
            key3=2,
            key4=3,
            key5=4,
            key6=dict(
                key7=5,
                key8=10,
                key9=dict(
                    key10=20,
                ),
            ),
        ),
        key11=11,
        key12=dict(
            key13='abc',
        ),
    )

# Generated at 2022-06-22 21:31:14.610726
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:31:25.333668
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict()
    dict2 = dict()
    dict1['instance_id'] = 'i-abc123'
    dict2['instance_id'] = 'i-abc123'
    result = dict_merge(dict1, dict2)
    assert dict1 == dict2 == result

    dict1['tags'] = dict()
    dict2['tags'] = dict()
    dict1['tags']['newtag'] = 'newvalue'
    result = dict_merge(dict1, dict2)
    assert dict1 == result

    dict1['tags'] = dict()
    dict2['tags'] = dict()
    dict2['tags']['newtag'] = 'newvalue'
    result = dict_merge(dict1, dict2)
    assert dict2 == result

    dict1['tags'] = dict()


# Generated at 2022-06-22 21:31:36.943569
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}}
    d2 = deepcopy(d1)
    assert None is recursive_diff(d1, d2)
    d2['a'] = 10
    assert ({'a': 1}, {'a': 10}) == recursive_diff(d1, d2)
    d2['c']['a'] = 10
    assert ({'a': 1, 'c': {'a': 1}}, {'a': 10, 'c': {'a': 10}}) == recursive_diff(d1, d2)
    d2['d'] = 4

# Generated at 2022-06-22 21:31:47.885293
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}}) == ({'a': {'b': 1}}, {'a': {'b': 2}})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': '1'}}) == ({'a': {'b': 1}}, {'a': {'b': '1'}})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 1}}) == None

# Generated at 2022-06-22 21:31:58.916244
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict()
    dict2 = dict()
    assert recursive_diff(dict1, dict2) == None

    dict1 = dict([("key1", 1), ("key2", 2), ("key3", dict([("key1", 1), ("key2", 2)]))])
    dict2 = dict([("key1", 1), ("key2", 2), ("key3", dict([("key1", 1), ("key2", 2)]))])
    assert recursive_diff(dict1, dict2) == None

    dict1 = dict([("key1", 1), ("key2", 2), ("key3", dict([("key1", 1), ("key2", 2)]))])
    dict2 = dict([("key1", 2), ("key2", 2), ("key3", dict([("key1", 1), ("key2", 2)]))])

# Generated at 2022-06-22 21:32:06.093851
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    random_string = "This is a string for the unit test"

    # string is not accepted as an argument
    try:
        camel_dict_to_snake_dict(random_string)
    except:
        assert True

    # dict with only camel cased keys
    camel_dict = {
        "CamelCaseKey1": "Value1",
        "CamelCaseKey2": "Value2",
        "CamelCaseKey3": {
            "NestedCamelCaseKey1": "Value1",
            "NestedCamelCaseKey2": "Value2",
            "NestedCamelCaseKey3": {
                "NestedNestedCamelCaseKey1": "Value1",
                "NestedNestedCamelCaseKey2": "Value2",
            }
        }
    }

    # dict with only snake

# Generated at 2022-06-22 21:32:15.538473
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {'HTTPEndpoint': {'endpointUrl': 'https://example.com', 'protocol': 'HTTP'}, 'tags': {'AWSTEMPLATEFORMATVERSION': '2010-09-09', 'Description': 'Test Camel to Snake Dictionary'}, 'versions': [{'versionName': 'example-version', 'versionDescription': 'An example version', 'versionEndpointConfiguration': {'default': {'endpointType': 'endpoint-type'}}}, {'versionName': 'example', 'versionDescription': 'An example version', 'versionEndpointConfiguration': {'default': {'endpointType': 'endpoint-type'}, 'v2': [{'endpointType': 'endpoint-type', 'region': 'region'}]}}]}


# Generated at 2022-06-22 21:32:26.753368
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Test recursive_diff for various conditions.
    """
    # Two identical dictionaries should return None
    d1 = {'M': 9,
          'N': 10,
          'O': {'P': 11,
                'Q': 12,
                'R': {'S': 13,
                      'T': 14}}}

    d2 = {'M': 9,
          'N': 10,
          'O': {'P': 11,
                'Q': 12,
                'R': {'S': 13,
                      'T': 14}}}
    assert recursive_diff(d1, d2) is None

    # Identical dictionaries but one with extra key should return None

# Generated at 2022-06-22 21:32:32.324160
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:32:43.883233
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ec2 import (
        camel_dict_to_snake_dict,
        ansible_dict_to_boto3_filter_list,
    )

    # Test for convert camel dict to snake dict
    camel_dict = dict(
        HTTPEndpoint=dict(
            Description='my description',
            Enabled=True
        ),
        DefaultTaskHeartbeatTimeout='120',
        DefaultTaskList=dict(
            Name='my-task-list'
        ),
        DefaultTaskPriority='1',
        DefaultChildPolicy='TERMINATE',
        DisableCountDown=False
    )


# Generated at 2022-06-22 21:32:50.917252
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    result = snake_dict_to_camel_dict({"abc_def": "ghi_jkl", "mno_pqr": {"stu_vwx": [{"yza_bcd": "efg_hij", "klm_nop": "qrs_tuv"}]}})
    expected = {'abcDef': 'ghi_jkl', 'mnoPqr': {'stuVwx': [{'yzaBcd': 'efg_hij', 'klmNop': 'qrs_tuv'}]}}
    assert result == expected

# Generated at 2022-06-22 21:33:03.208485
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:33:14.661201
# Unit test for function dict_merge
def test_dict_merge():
    # Empty case, empty dicts
    a = {}
    b = {}
    c = dict_merge(a, b)
    assert c == {}

    # Empty case, empty dicts
    c = dict_merge(b, a)
    assert c == {}

    a = {'a': 1}
    b = {'b': 1}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'b': 1}

    c = dict_merge(b, a)
    assert c == {'a': 1, 'b': 1}

    # Merge two non-colliding non-nested dicts
    a = {'a': 1, 'b': 2}
    b = {'c': 3, 'd': 4}

# Generated at 2022-06-22 21:33:24.240919
# Unit test for function dict_merge
def test_dict_merge():

    assert (dict_merge({"x": "1", "y": "2"}, {"x": "3"}) == {
        "x": "3", "y": "2"}), "Merge doesn't work in simple case"

    assert (dict_merge({"x": "1", "y": "2"}, {"x": "3", "z": "4"}) == {
        "x": "3", "y": "2", "z": "4"}), "Merge doesn't work in simple case"

    assert (dict_merge({"x": {"a": "1", "b": "2"}}, {"x": {"b": "3"}}) == {
        "x": {"a": "1", "b": "3"}}), "Merge doesn't work with dicts"


# Generated at 2022-06-22 21:33:31.211184
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:33:40.500126
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:33:52.273336
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({"a": "A1", "b": "B1"}, {"a": "A2", "b": "B1"}) == ({"a": "A1"}, {"a": "A2"})
    assert recursive_diff({"a": "A1", "b": "B1"}, {"a": "A2", "b": "B2"}) == ({"a": "A1", "b": "B1"}, {"a": "A2", "b": "B2"})
    assert recursive_diff({"a": "A1", "b": "B1"}, {"a": "A1", "b": "B1"}) is None


# Generated at 2022-06-22 21:34:03.346129
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 'a'}
    dict2 = {'a': 'a'}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'a': 'b'}
    dict2 = {'a': 'a'}
    diff = recursive_diff(dict1, dict2)
    assert diff is not None
    left, right = diff
    assert left == {'a': 'b'}
    assert right == {'a': 'a'}

    dict1 = {'a': {'b': 'c'}}
    dict2 = {'a': {'b': 'c'}}
    assert recursive_diff(dict1, dict2) is None

    dict

# Generated at 2022-06-22 21:34:13.813484
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(dict(a=1, b=2), dict(c=3, d=4)) == dict(a=1, b=2, c=3, d=4)
    assert dict_merge(dict(a=dict(b=1), c=dict(d=4)), dict(a=dict(e=2), c=dict(f=5))) == dict(a=dict(b=1, e=2), c=dict(d=4, f=5))
    assert dict_merge(dict(a=dict(b=1), c=dict(d=4)), dict(a=dict(b=2), c=dict(d=5))) == dict(a=dict(b=2), c=dict(d=5))



# Generated at 2022-06-22 21:34:22.156341
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, dict_merge(a, b)
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_

# Generated at 2022-06-22 21:34:34.059335
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Unit test for function camel_dict_to_snake_dict
    camel_dict = {'ApiKey': 'MyApiKeyForTesting', 'ServiceToken': 'MyServiceTokenForTesting'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'api_key': 'MyApiKeyForTesting', 'service_token': 'MyServiceTokenForTesting'}

    camel_dict = {'MyHTTPEndpoint': 'MyHTTPEndpointForTesting', 'ServiceToken': 'MyServiceTokenForTesting'}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)

# Generated at 2022-06-22 21:34:40.232488
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 'val1', 'key2': {'key3': 'val3'}}
    b = {'key4': 'val4', 'key2': {'key5': 'val5'}}
    expected = {'key1': 'val1', 'key2': {'key3': 'val3', 'key5': 'val5'}, 'key4': 'val4'}
    assert(dict_merge(a, b) == expected)



# Generated at 2022-06-22 21:34:51.003420
# Unit test for function dict_merge
def test_dict_merge():
    assert {} == dict_merge({}, {})
    assert {'a': 'b'} == dict_merge({'a': 'b'}, {})
    assert {'a': 'c'} == dict_merge({'a': 'b'}, {'a': 'c'})
    assert {'a': {'b': u'c'}} == dict_merge({'a': {'b': 'c'}}, {})
    assert {'a': {'b': 'd'}} == dict_merge({'a': {'b': 'c'}}, {'a': {'b': 'd'}})
    assert {'a': {'b': 'd'}} == dict_merge({'a': {'b': 'd'}}, {'a': {'b': 'c'}})


# Generated at 2022-06-22 21:34:55.038102
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Basic conversion
    camel_dict_1 = dict(FirstKey='hello world', SecondKey=False, ThirdKey=dict())
    snake_dict_1 = camel_dict_to_snake_dict(camel_dict_1)
    assert sorted(snake_dict_1.keys()) == ['first_key', 'second_key', 'third_key']
    assert snake_dict_1['first_key'] == 'hello world'
    assert snake_dict_1['second_key'] == False
    assert snake_dict_1['third_key'] == dict()
    # Reversal
    first_camel = snake_dict_to_camel_dict(snake_dict_1)
    assert first_camel == camel_dict_1
    # Double reversal
    second_snake = camel_dict_to_snake

# Generated at 2022-06-22 21:35:05.218502
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(
        a=dict(b=1, c=2, d=3),
        b=dict(b=2, c=3, d=4)
    )
    b = dict(
        a=dict(b=5, d=1),
        b=dict(b=2, c=3, d=4),
        c=dict(d=9, e=10)
    )
    expected = dict(
        a=dict(b=5, c=2, d=1),
        b=dict(b=2, c=3, d=4),
        c=dict(d=9, e=10)
    )
    assert dict_merge(a, b) == expected



# Generated at 2022-06-22 21:35:14.662400
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:35:22.925316
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'foo': 'bar',
        'baz': 'bar',
        'blah': 'not blah',
        'deep': {
            'deep_foo': 'deep bar',
            'deep_baz': 'deep bar',
            'deep_blah': {
                'deep_deep_blah': 'not deep deep blah',
            },
        },
    }

# Generated at 2022-06-22 21:35:32.504820
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_test_dict = {
        'testKey': 'testValue',
        'testKey1': {
            'testKey2': 'testValue2',
            'testKey3': {
                'testKey4': 'testValue4',
                'testKey5': 'testValue5'
            }
        }
    }

    camel_test_list = [{
        'testKey': 'testValue',
        'testKey1': {
            'testKey2': 'testValue2',
            'testKey3': {
                'testKey4': 'testValue4',
                'testKey5': 'testValue5'
            }
        }
    }]

    for test_dict in (camel_test_dict, camel_test_list):
        snake_test_dict = camel_dict_to_snake_

# Generated at 2022-06-22 21:35:42.746491
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        'key1': 'value1',
        'key2': {'key3': 'value3', 'key4': 'value4'},
        'key5': 'value5'
    }
    d2 = {
        'key1': 'value2',
        'key2': {'key3': 'value6'},
        'key6': 'value6'
    }
    expected = {
        'key1': 'value2',
        'key2': {'key3': 'value6', 'key4': 'value4'},
        'key5': 'value5',
        'key6': 'value6'
    }
    actual = dict_merge(d1, d2)

    assert actual == expected

# Generated at 2022-06-22 21:35:51.020899
# Unit test for function recursive_diff
def test_recursive_diff():

    import pprint


# Generated at 2022-06-22 21:35:56.852942
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'this_is_a_dict_key': 'foo'}
    camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=False)
    assert camel_dict == {u'thisIsADictKey': u'foo'}
    camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=True)
    assert camel_dict == {u'ThisIsADictKey': u'foo'}


# Generated at 2022-06-22 21:36:05.253016
# Unit test for function recursive_diff
def test_recursive_diff():
    struct1 = {
        "name": "policy_name",
        "host": {
            "host1": {"name": "policy_name", "createtime": 1234567890},
            "host2": {"name": "policy_name", "createtime": 1234567890}
        },
        "policy": {
            "backup": {
                "param": {
                    "retention_count": 10
                },
                "scheme": {
                    "hourlycycle": {
                        "interval": 5
                    },
                    "weeklycycle": {
                        "interval": 1,
                        "weekday": ["Monday", "Tuesday"]
                    }
                }
            }
        }
    }


# Generated at 2022-06-22 21:36:15.357225
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'on_premises_tag_set': {
            'tags': [
                {'key': 'String', 'value': 'String'},
            ]
        },
        'service_role_arn': 'String',
        'asg_name': 'String',
        'additional_tags': [
            {'key': 'String', 'value': 'String'},
        ],
        'deployment_option': 'WITH_TRAFFIC_CONTROL',
        'ec2_tag_set': {
            'prod': {
                'ec2_tag_filter': {
                    'key': 'String', 'value': 'String', 'type': 'KEY_AND_VALUE'
                }
            }
        }
    }


# Generated at 2022-06-22 21:36:21.344961
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        'a': {
            'b': 1,
            'c': 2,
        },
        'd': 3,
        'e': 4
    }

    d2 = {
        'a': {
            'b': 1,
            'c': 1,
        },
        'd': 3,
        'e': 5,
        'f': 6
    }

    expected = ({'a': {'c': 2}, 'e': 4}, {'a': {'c': 1}, 'e': 5, 'f': 6})
    assert recursive_diff(dict1=d1, dict2=d2) == expected


# Generated at 2022-06-22 21:36:28.404467
# Unit test for function recursive_diff
def test_recursive_diff():
    a = dict(one=1, two=dict(three=3, four=4), six=6)
    b = dict(one=1, two=dict(three=3, five=5), seven=7)

    expected = ({'two': {'four': 4}, 'six': 6},
                {'two': {'five': 5}, 'seven': 7})

    assert recursive_diff(a, b) == expected


# Generated at 2022-06-22 21:36:39.457957
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'key1': 'value1',
        'key2': {
            'key3': 'value2',
            'key4': 'value4',
            'key5': {
                'key6': 'value6',
            }
        }
    }
    b = {
        'key2': {
            'key3': 'value3',
            'key7': 'value7',
        },
        'key8': 'value8',
    }
    result = dict_merge(a, b)


# Generated at 2022-06-22 21:36:49.823204
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:56.880641
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Prepare
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://123.123.123.123:8080/'
        },
        'Tags': {
            'Project': 'myProject'
        }
    }

    # Action
    snake_dict = camel_dict_to_snake_dict(camel_dict)

    # Assert
    assert snake_dict == {
        'http_endpoint': {
            'endpoint_url': 'http://123.123.123.123:8080/'
        },
        'tags': {
            'Project': 'myProject'
        }
    }



# Generated at 2022-06-22 21:37:03.395247
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:37:13.897017
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert (snake_dict_to_camel_dict({'snake_case': 'snake_case'}) == {'snakeCase': 'snake_case'})
    assert (snake_dict_to_camel_dict({'snake_case': 'snake_case'}, capitalize_first=True) == {'SnakeCase': 'snake_case'})
    assert (snake_dict_to_camel_dict({'snake_case': {'snake_case': 'snake_case'}}) == {'snakeCase': {'snakeCase': 'snake_case'}})

# Generated at 2022-06-22 21:37:24.271071
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aCamelizedKey': 'value'}) == {'a_camelized_key': 'value'}
    assert camel_dict_to_snake_dict({'aCamelizedKey': {'aCamelizedKey': 'value'}}) == {'a_camelized_key': {'a_camelized_key': 'value'}}
    assert camel_dict_to_snake_dict({'aCamelizedKey': {'aCamelizedKey': {'aCamelizedKey': 'value'}}}) == {'a_camelized_key': {'a_camelized_key': {'a_camelized_key': 'value'}}}



# Generated at 2022-06-22 21:37:34.672969
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:37:40.040720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fileSystemId': 'fs-1234567',
        'fileSystemArn': 'arn:aws:elasticfilesystem:us-east-1:012345678901:file-system/fs-1234567',
        'lifecyclePolicies': [
            {
                'TransitionToIA': 'AFTER_7_DAYS,60'
            }
        ]
    }

    # result is a deepcopy of camel_dict
    result = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-22 21:37:45.462460
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=1, b=dict(c=1, d=2))
    b = dict(a=2, b=dict(d=3))
    assert dict_merge(a,b) == dict(a=2, b=dict(c=1, d=3))



# Generated at 2022-06-22 21:37:53.986467
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({
        'foo_bar': 'baz',
        'boo_far': [{
            'fie_fum': 'fiz',
            'bim_bam': [{
                'bing_bong': 'bung',
                'john_doe': 'jan_doe'
                }]
            }]
        }) == {'fooBar': 'baz', 'booFar': [{'fieFum': 'fiz', 'bimBam': [{'bingBong': 'bung', 'johnDoe': 'jan_doe'}]}]}
    assert snake_dict_to_camel_dict({'Tags': {'key': 'value'}}) == {'Tags': {'key': 'value'}}



# Generated at 2022-06-22 21:38:01.119340
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a':{'b':1,'c':2},'j':100}
    b = {'a':{'d':3,'e':4}}
    assert dict_merge(a,b)['a']['b'] == 1
    assert dict_merge(a,b)['a']['c'] == 2
    assert dict_merge(a,b)['a']['d'] == 3
    assert dict_merge(a,b)['a']['e'] == 4
    assert dict_merge(a,b)['j'] == 100


# Generated at 2022-06-22 21:38:13.381055
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict()
    dict1['key1'] = 'value1'
    dict1['key2'] = 'value2'
    dict1['key3'] = 'value3'
    dict1['key4'] = dict()
    dict1['key4']['key4_1'] = 'value4_1'
    dict1['key4']['key4_2'] = 'value4_2'

    dict2 = dict()
    dict2['key1'] = 'value1'
    dict2['key2'] = 'value2'
    dict2['key3'] = 'value3'
    dict2['key4'] = dict()
    dict2['key4']['key4_1'] = 'value4_1'

# Generated at 2022-06-22 21:38:21.658810
# Unit test for function dict_merge
def test_dict_merge():

    a = {
        "a": 1,
        "b": 2,
        "circles": {
            "first": {
                "x": 10,
                "y": 20
            },
            "second": {
                "x": 20,
                "y": 30
            }
        }
    }

    b = {
        "a": 2,
        "b": 3,
        "circles": {
            "second": {
                "x": 201,
                "y": 302
            },
            "third": {
                "x": 30,
                "y": 40
            }
        },
        "squares": {
            "first": {
                "x": 100,
                "y": 200
            }
        }
    }


# Generated at 2022-06-22 21:38:27.165134
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Case sensitive
    assert snake_dict_to_camel_dict({'abc': {'def': {'ghi': 'jkl'}}}) == {'abc': {'def': {'ghi': 'jkl'}}}
    # Case insensitive
    assert snake_dict_to_camel_dict(
        {'abc': {'def': {'ghi': 'jkl'}}}, capitalize_first=True
    ) == {'Abc': {'Def': {'Ghi': 'jkl'}}}


# Generated at 2022-06-22 21:38:36.250689
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test on a sample input
    dict1 = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'quuz': {
                'corge': 'grault'
            },
            'corge': 'garply'
        },
        'waldo': {
            'fred': 'plugh',
            'xyzzy': 'thud'
        },
        'fred': 'garply',
        'plugh': 'thud'
    }


# Generated at 2022-06-22 21:38:45.853516
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:38:56.913692
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Test for snake_dict_to_camel_dict"""
    # Case 1: simple dict
    test_dict1 = {'hello_world': 'value1'}
    result_dict1 = snake_dict_to_camel_dict(test_dict1)
    assert result_dict1 == {'helloWorld': 'value1'}

    # Case 2: simple nested dict
    test_dict2 = {'hello_world': {'inner_key': 'value1'}}
    result_dict2 = snake_dict_to_camel_dict(test_dict2)
    assert result_dict2 == {'helloWorld': {'innerKey': 'value1'}}

    # Case 3: list of dicts

# Generated at 2022-06-22 21:39:08.471761
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test case: Same data is given in dict1 and dict2
    dict1 = dict(name='ansible')
    dict2 = dict(name='ansible')
    assert recursive_diff(dict1, dict2) is None

    # Test case: Different data is given in dict1 and dict2
    dict1 = dict(name='ansible')
    dict2 = dict(name='ansible2')
    assert recursive_diff(dict1, dict2) == ({'name': 'ansible'}, {'name': 'ansible2'})

    # Test case: Different keys in dict1 and dict2
    dict1 = dict(name='ansible')
    dict2 = dict(name='ansible', app='cloud')
    assert recursive_diff(dict1, dict2) == ({}, {'app': 'cloud'})

    # Test case

# Generated at 2022-06-22 21:39:19.094286
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'some_things': [{'some_other_things': 'hello'}]}) == {'someThings': [{'someOtherThings': 'hello'}]}
    assert snake_dict_to_camel_dict({'some_things': [{'some_other_things': 'hello'}]}, capitalize_first=True) == {'SomeThings': [{'SomeOtherThings': 'hello'}]}
    assert snake_dict_to_camel_dict(snake_dict_to_camel_dict({'some_things': [{'some_other_things': 'hello'}]})) == {'someThings': [{'someOtherThings': 'hello'}]}

# Generated at 2022-06-22 21:39:30.382340
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test to ensure camel_dict_to_snake_dict is behaving as expected
    """

    d = {
        'tagStart': 'tagstart',
        'TagEnd': 'tagend',
        'HTTPSEndpoint': 'httpsendpoint',
        'HTTPEndpoint': 'httpendpoint',
        'TargetGroupARNs': 'targetgrouparns',
        'Role': 'role',
        'ARN': 'arn',
        'Tags': {},
        'MultiAZ': False
    }


# Generated at 2022-06-22 21:39:41.855914
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff

    """
    test_dictionary = {
            'x': 1,
            'y': 2,
        }
    assert recursive_diff({}, test_dictionary) == ({'x': 1, 'y': 2}, {})
    assert recursive_diff({'x': 23}, test_dictionary) == ({'x': 1}, {'x': 23})
    assert recursive_diff(test_dictionary, {'y': 23}) == ({'y': 2}, {'y': 23})
    assert recursive_diff(test_dictionary, {'x': 1, 'y': 23}) == ({'y': 2}, {'y': 23})
    assert recursive_diff({'x': 1, 'y': 3}, test_dictionary) == ({'y': 3}, {'y': 2})
    assert recursive_diff

# Generated at 2022-06-22 21:39:51.650417
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test equal dictionaries
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) is None

    # Test equal nested dictionaries
    dict1 = {'foo': {'bar': 'baz'}}
    dict2 = {'foo': {'bar': 'baz'}}
    assert recursive_diff(dict1, dict2) is None

    # Test non-equal nested dictionaries
    dict1 = {'foo': {'bar': 'baz'}}
    dict2 = {'foo': {'bar': 'baz', 'qux': 'qax'}}
    assert recursive_diff(dict1, dict2) == ({}, {'foo': {'qux': 'qax'}})

    # Test key missing in first dictionary
    dict1 = {}

# Generated at 2022-06-22 21:40:00.948287
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Empty
    assert recursive_diff({}, {}) is None
    assert recursive_diff({}, {'dict1_key': 'dict1_value'}) == ({}, {'dict1_key': 'dict1_value'})
    assert recursive_diff({'dict1_key': 'dict1_value'}, {}) == ({'dict1_key': 'dict1_value'}, {})

    # Exact match
    assert recursive_diff({'dict1_key': 'dict1_value'}, {'dict1_key': 'dict1_value', 'dict2_key': 'dict2_value'}) == ({}, {'dict2_key': 'dict2_value'})

# Generated at 2022-06-22 21:40:13.276580
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None

    d1 = {'key1': 'value1', 'key2': 'value2', 'key4': {'key4_key1': 'value4_value1', 'key4_key2': 'value4_value2'}}
    d2 = {'key1': 'value1', 'key2': 'value2', 'key4': {'key4_key2': 'value4_value2', 'key4_key1': 'value4_value1'}}
    assert recursive_diff(d1, d2) is None

    d1 = {'key1': 'value1', 'key2': 'value2', 'key3': {'key3_key1': 'value3_value1', 'key3_key2': 'value3_value2'}}

# Generated at 2022-06-22 21:40:19.173117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test dictionary
    camel_dict = dict(HTTPEndpoint=dict(name='somename',
                                        endpoint='someendpoint',
                                        tags=dict(Name='sometag',
                                                  Key='somekey')))
    # Dict as we would expect to get
    snake_dict = dict(h_t_t_p_endpoint=dict(name='somename',
                                            endpoint='someendpoint',
                                            tags=dict(Name='sometag',
                                                      Key='somekey')))
    assert(camel_dict_to_snake_dict(camel_dict) == snake_dict)


# Generated at 2022-06-22 21:40:30.160564
# Unit test for function dict_merge
def test_dict_merge():
    a = {'test1': 'test1'}
    b = {'test2': 'test2'}
    ret = dict_merge(a, b)
    assert 'test1' in ret
    assert 'test2' in ret

    a = {'test1': {'test2': 'test2'}, 'test3': 'test3'}
    b = {'test1': {'test4': 'test4'}}
    ret = dict_merge(a, b)
    assert 'test2' in ret['test1']
    assert 'test4' in ret['test1']
    assert 'test3' in ret

    a = {'test1': {'test2': {'test3': 'test3'}}}