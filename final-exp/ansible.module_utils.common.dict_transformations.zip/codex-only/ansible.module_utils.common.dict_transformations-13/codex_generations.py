

# Generated at 2022-06-22 21:30:29.031500
# Unit test for function dict_merge
def test_dict_merge():
    a = {'test1': [1, 2, 3], 'test2': 'foo', 'test3': {'test4': 'bar', 'test5': 'baz'}}
    b = {'test1': [4, 5, 6], 'test2': 'bur', 'test3': {'test6': 'qux', 'test7': 'quux'}}

    expected = {'test1': [1, 2, 3, 4, 5, 6], 'test2': 'foo', 'test3': {'test7': 'quux', 'test4': 'bar', 'test5': 'baz', 'test6': 'qux'}}
    got = dict_merge(a, b)

    assert expected == got

# Generated at 2022-06-22 21:30:38.636252
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'key11': 'value11'},
         'key2': {'key21': 'value21'}}
    b = {'key1': {'key12': 'value12'},
         'key2': {'key21': 'value21_updated'}}

    merged_dict = dict_merge(a, b)
    assert merged_dict['key1']['key11'] == 'value11'
    assert merged_dict['key1']['key12'] == 'value12'
    assert merged_dict['key2']['key21'] == 'value21_updated'



# Generated at 2022-06-22 21:30:44.626841
# Unit test for function dict_merge
def test_dict_merge():
    # base case
    assert dict_merge({}, {}) == {}

    # base case - simple dict
    assert dict_merge({'a': 2}, {'b': 3}) == {'a': 2, 'b': 3}

    # base case - dicts with sub dicts
    assert dict_merge({'a': 2, 'b': {'c': 5}}, {'b': {'d': 7}, 'e': {'f': 9}}) == \
        {'a': 2, 'b': {'c': 5, 'd': 7}, 'e': {'f': 9}}

    # base case - dicts with sub dicts + overlap

# Generated at 2022-06-22 21:30:51.707178
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        'username': 'fred',
        'password': 'secret',
        'key1': {
            'key1_in_key1': 'key1_in_key1',
            'key2_in_key1': {
                'key1_in_key2_in_key1': 'key1_in_key2_in_key1'
            }
        }
    }

# Generated at 2022-06-22 21:31:03.806303
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:31:13.951986
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict_1 = {
        "tag_keys": [
            "team",
            "project",
            "environment"
        ],
        "tag_values": [
            "1234",
            "ABCD",
            "XYZ"
        ]
    }
    expected_dict_1 = {
        "tagKeys": [
            "team",
            "project",
            "environment"
        ],
        "tagValues": [
            "1234",
            "ABCD",
            "XYZ"
        ]
    }
    actual_dict_1 = snake_dict_to_camel_dict(test_dict_1)
    assert actual_dict_1 == expected_dict_1


# Generated at 2022-06-22 21:31:24.750370
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Checking for normal use case of conversion
    camel_dict = {'KeyOne': 'one', 'KeyTwo': 'two'}
    assert camel_dict_to_snake_dict(camel_dict) == {'key_one': 'one', 'key_two': 'two'}

    # Checking for conversion of sub-trees in dictionary
    camel_dict = {'KeyOne': 'one', 'KeyTwo': 'two', 'SubTree': {'SubKeyOne': 'subone'}}
    assert camel_dict_to_snake_dict(camel_dict) == {'key_one': 'one', 'key_two': 'two', 'sub_tree': {'sub_key_one': 'subone'}}

    # Checking for conversion of sub-trees in lists in dictionary

# Generated at 2022-06-22 21:31:31.614167
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    x = {
        'foo': 'bar',
        'baz': {
            'foo_bar': 'qux'
        }
    }

    expected = {
        'foo': 'bar',
        'baz': {
            'fooBar': 'qux'
        }
    }

    assert snake_dict_to_camel_dict(x) == expected


# Generated at 2022-06-22 21:31:42.900516
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test case when no difference
    left, right = recursive_diff({
        "name": "foo",
        "children": {
            "name": "bar"
        }
    }, {
        "name": "foo",
        "children": {
            "name": "bar"
        }
    })
    assert left is right is None

    # Test case when only top level difference
    left, right = recursive_diff({
        "name": "foo",
        "children": {
            "name": "bar"
        }
    }, {
        "name": "foo",
        "children": {
            "name": "bar2"
        }
    })
    assert left == {
        "children": {
            "name": "bar"
        }
    }

# Generated at 2022-06-22 21:31:54.024425
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1, 'b': 1, 'd': 3, 'e': 1},
                          {'a': 1, 'b': 2, 'c': 2}) == ({'b': 1, 'd': 3, 'e': 1}, {'b': 2, 'c': 2})

    assert recursive_diff({'a': 1, 'b': 1, 'd': {'a': {'a': 1}, 'b': {'c': 3}}},
                          {'a': 1, 'b': 1, 'd': {'a': {'a': 1}, 'b': {'c': 2}}}) == (
        {'d': {'b': {'c': 3}}}, {'d': {'b': {'c': 2}}})


# Generated at 2022-06-22 21:32:01.896609
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = {
        "HTTPEndpoint": {
            "Command": "",
            "CommandTimeout": 600,
            "EndpointName": "",
            "IdleTimeout": 60
        }
    }
    snake_dict_1 = {
        "h_t_t_p_endpoint": {
            "command": "",
            "command_timeout": 600,
            "endpoint_name": "",
            "idle_timeout": 60
        }
    }
    assert camel_dict_to_snake_dict(camel_dict_1) == snake_dict_1


# Generated at 2022-06-22 21:32:09.104718
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar':1}) == {'foo_bar':1}
    assert camel_dict_to_snake_dict({'fooBar':1}) == {'foo_bar':1}
    assert camel_dict_to_snake_dict({'FooBar':1}, reversible=True) == {'f_oo_bar':1}


# Generated at 2022-06-22 21:32:16.716891
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {'HTTPEndpoint': 'https://example.com', 'TagKeys': {'TagKey1': 'value1'}}
    r = camel_dict_to_snake_dict(d)
    assert isinstance(r, dict)
    assert r['http_endpoint'] == 'https://example.com'
    assert r['tag_keys'] == {'tag_key': 'value1'}
    d = {'SSM': {'HTTPEndpoint': 'https://example.com', 'TagKeys': {'TagKey1': 'value1'}}}
    r = camel_dict_to_snake_dict(d)
    assert isinstance(r, dict)

# Generated at 2022-06-22 21:32:28.356939
# Unit test for function dict_merge
def test_dict_merge():
    # This is a test function for the dict_merge function
    # We expect the function to return a dictionary that has all the keys
    # and values of both the a and b dictionaries, especially in the case of
    # nested dictionaries.

    a = {
        'one': {
            'a': 1,
            'b': 2
        },
        'two': {
            'a': 3,
            'b': 4
        },
        'extra': 1
    }

    b = {
        'one': {
            'b': 'override2',
            'c': 3
        },
        'two': {
            'a': 1,
            'c': 4
        },
        'extra': 2
    }


# Generated at 2022-06-22 21:32:37.207166
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'some_key_1': {
            'some_key_2': 'some_value_2',
            'some_key_3': 'some_value_3',
            'some_key_4': 'some_value_4',
        }
    }

    assert snake_dict_to_camel_dict(test_dict) == {
        'someKey1': {
            'someKey2': 'some_value_2',
            'someKey3': 'some_value_3',
            'someKey4': 'some_value_4',
        }
    }


# Generated at 2022-06-22 21:32:47.026601
# Unit test for function dict_merge
def test_dict_merge():
    try:
        import json
    except ImportError:
        import simplejson as json
    from deepdiff import DeepDiff

    test_payload = {
        'a': {'b': {'c': 1}},
        'd': [1, 2, 3],
        'z': {'h': 'g'}
    }

    with open('tests/units/module_utils/dict_merge_test_data.json') as json_data:
        expected_merge_data = json.load(json_data)

    diff = DeepDiff(expected_merge_data, dict_merge(test_payload, expected_merge_data))
    assert not diff, "Merge results do not match expectation. Diff is: %s" % diff

# Generated at 2022-06-22 21:32:55.316047
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "tcp": {
            "HTTPEndpoint": [
                "10.0.0.1:8080",
                "10.0.0.2:8080",
                "10.0.0.3:8080"
            ]
        },
        "udp": {
            "DNSQueryEndpoint": [
                "10.0.0.1:53",
                "10.0.0.2:53",
                "10.0.0.3:53"
            ]
        }
    }


# Generated at 2022-06-22 21:33:05.874200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'key1': 'value1',
        'keyA': 'valueA',
        'keyA2': 'valueA2',
        'keyB_1': 'valueB_1',
        'keyC': {
            'key1_1': 'value1_1',
            'key2': 'value2',
            'key2_1': 'value2_1',
            'key3': {
                'key3_1': 'value3_1',
                'key3_2': 'value3_2',
                'key3_3': {
                    'key3_3_1': 'value3_3_1'
                }
            }
        }
    }


# Generated at 2022-06-22 21:33:16.842944
# Unit test for function dict_merge
def test_dict_merge():
    # Test the dicitonary merge function
    print("Testing dict_merge()")
    dict1 = {"a": 1, "b": 2, "c": 3}
    dict2 = dict(a=3, b=2, c=1)
    dict3 = {"a": 2, "b": [{"mango": "delicious"}, {"key": "value"}], "c": list("cat")}
    dict4 = {"a": 3, "z": list("I'm a dict"), "b": [{"mango": "delicious"}, {"other_key": "other_value"}]}

    dict5 = {"a": 2, "b": [{"mango": "delicious"}, {"key": "value"}], "c": list("cat")}

# Generated at 2022-06-22 21:33:26.144881
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "a": 1,
        "b": "2",
        "c": {
            "c1": "1",
            "c2": "2",
            "c3": "3",
            "c4": {
                "c41": "c41",
                "c42": "c42",
            },
        },
        "d": ["e", "f"],
        "g": "h",
    }

# Generated at 2022-06-22 21:33:37.857764
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'b': 5, 'c': 6, 'd': 7}
    d3 = {'b': 5, 'c': 6, 'd': 7, 'e': 8}
    d4 = {'e': {'f': 8, 'g': 9}}
    d5 = {'a': 1, 'b': 2, 'c': 3, 'e': {'f': 10, 'j': 11}}

    assert dict_merge(d1, d2) == {'a': 1, 'c': 6, 'b': 5, 'd': 7}
    assert dict_merge(d2, d1) == {'b': 2, 'd': 7, 'c': 3, 'a': 1}
    assert dict_

# Generated at 2022-06-22 21:33:50.217616
# Unit test for function recursive_diff
def test_recursive_diff():
    input_dict1 = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': 'g'
        },
        'h': 'i'
    }
    input_dict2 = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': 'g'
        },
        'h': 'j'
    }
    assert recursive_diff(input_dict1, input_dict2) == ({'h': 'i'}, {'h': 'j'})
    input_dict1 = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': 'g'
        },
        'h': 'i'
    }

# Generated at 2022-06-22 21:34:00.363893
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'second' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    d = { 'second' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    e = { 'second' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' }, 'second_row' : { 'pass' : 'dog', 'number' : '10' } } }

# Generated at 2022-06-22 21:34:07.755624
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aBc': 'dEF', 'ghI': {'jKl': 'mnO'}}) == {'a_bc': 'd_e_f', 'gh_i': {'j_kl': 'mn_o'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'dEF'}, reversible=True) == {'h_t_t_p_endpoint': 'dEF'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'dEF'}, reversible=False) == {'http_endpoint': 'dEF'}
    assert camel_dict_to_snake_dict({'Tags': {'key': 'value'}}) == {'tags': {'key': 'value'}}

# Generated at 2022-06-22 21:34:18.384252
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:34:28.973689
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sample_dict = {
        'A': {
            'B': [1, 2, 3],
            'C': [4, 5, 6]
        },
        'D': {
            'E': {
                'F': 'G',
                'H': 'I'
            },
            'J': {
                'K': 'L',
                'M': 'N'
            }
        }
    }


# Generated at 2022-06-22 21:34:37.258226
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'key1': 'value1'} == snake_dict_to_camel_dict({'key1': 'value1'})
    assert {'Key1': 'value1'} == snake_dict_to_camel_dict({'key1': 'value1'}, True)
    assert {'key1': 'value1'} == snake_dict_to_camel_dict({'Key1': 'value1'})
    assert {'key1': 'value1', 'key2': 'value2'} == snake_dict_to_camel_dict({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-22 21:34:46.010680
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': {
            'b': 1,
            'c': 2
        }
    }
    dict2 = {
        'a': {
            'b': 2,
            'c': 2
        },
        'd': 3
    }
    diff = recursive_diff(dict1, dict2)
    assert diff == ({'a': {'b': 1}}, {'a': {'b': 2}, 'd': 3})

# Generated at 2022-06-22 21:34:57.191203
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_data = {
        'HTTPEndpoint': 'test',
        'PluralizedHTTPEndpoints': {
            'HTTPEndpoint1': 'test1'
        },
        'CamelCaseHTTPEndpoint': {
            'HTTPAbbreviation': 'test2'
        },
        '_AbsoluteURI': 'test3',
        '_AbsoluteUrl': {
            '_HttpUrl': 'test4'
        },
        'Tags': {'test': 5}
    }


# Generated at 2022-06-22 21:35:07.465240
# Unit test for function recursive_diff
def test_recursive_diff():
    # Two empty dictionaries should return None
    assert recursive_diff({}, {}) is None
    # Dictionaries with different keys
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})
    # Dictionaries with different values
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    # Dictionaries with different keys and values
    assert recursive_diff({'a': 1}, {'a': 2, 'b': 1}) == ({'a': 1}, {'a': 2, 'b': 1})
    # Nested dictionaries with different values

# Generated at 2022-06-22 21:35:17.981513
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils import basic

    def build_dict(depth, width, value=None):
        if value is None:
            value = dict()
        for i in range(width):
            if depth <= 1:
                value[i] = i
            else:
                value[i] = build_dict(depth-1, width, dict())
        return value

    def assert_same(dict1, dict2, msg=None):
        dict1_str = basic.json_dict_unicode_to_bytes(basic.jsonify(dict1))
        dict2_str = basic.json_dict_unicode_to_bytes(basic.jsonify(dict2))
        assert dict1_str == dict2_str, (dict1_str, dict2_str)


# Generated at 2022-06-22 21:35:27.866653
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: 1}, {1: 1}) is None
    assert recursive_diff({1: 1}, {2: 2}) == ({1: 1}, {2: 2})
    assert recursive_diff({1: 1, 2: {3: 3, 4: 4}, 5: '5'}, {1: 1, 2: {3: 3, 4: 4}, 5: '5'}) is None
    assert recursive_diff({1: 1, 2: {3: 3, 4: 4}, 5: '5'}, {1: 1, 2: {3: 3, 4: 4}, 5: '6'}) == ({5: '5'}, {5: '6'})

# Generated at 2022-06-22 21:35:31.573782
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': {'b': 'c'}}
    d2 = {'a': {'b': 'd'}}
    r = recursive_diff(d1, d2)
    assert r == ({'a': {'b': 'c'}}, {'a': {'b': 'd'}})

# Generated at 2022-06-22 21:35:37.758189
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': '123'}) == {'foo_bar': '123'}
    assert camel_dict_to_snake_dict({'FooBar': '123'}, True) == {'f_o_o_bar': '123'}
    assert camel_dict_to_snake_dict({'FooBar': '123', 'SubKey': {'BazQux': '456'}}) == {'foo_bar': '123', 'sub_key': {'baz_qux': '456'}}

# Generated at 2022-06-22 21:35:49.102058
# Unit test for function recursive_diff
def test_recursive_diff():
    import pprint

# Generated at 2022-06-22 21:35:58.013482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    tags = {'key': 'value'}
    params = {
        'VirtualGatewayName': 'mygateway',
        'Listeners': [
            {
                'PortMapping': {
                    'ListenerPort': 443,
                    'Protocol': 'https',
                    'ServicePort': 443,
                },
                'HealthCheck': {
                    'HealthCheckPort': 443,
                    'Protocol': 'https',
                },
                'Tls': {
                    "ServerCertificateArn": "arn:aws:acm:aws:us-east-1:123456789012:certificate/abcd-1234-abcd-1234-abcd-123451234",
                    "Mode": "STRICT"
                }
            },
        ],
        'Tags': tags
    }


# Generated at 2022-06-22 21:36:05.418340
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': 1}}
    dict2 = {'a': {'b': 2}}
    diff = recursive_diff(dict1, dict2)
    assert diff == ({'a': {'b': 1}}, {'a': {'b': 2}})
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': {'e': 3, 'f': 4}}
    dict2 = {'a': {'b': 1, 'c': 2}, 'd': {'e': 3}}
    diff = recursive_diff(dict1, dict2)
    assert diff == ({'d': {'f': 4}}, {'d': None})

# Generated at 2022-06-22 21:36:11.177634
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({'test_dict': 'test_value', 'test_list': ['one', 'two']}) == {'testDict': 'test_value', 'testList': ['one', 'two']}
    assert snake_dict_to_camel_dict({'test_dict': {'second_dict': 'second_value'}}) == {'testDict': {'secondDict': 'second_value'}}



# Generated at 2022-06-22 21:36:20.514677
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {"operation": "create", "item":
        {"index": "0", "item":
            {"item_type": "value", "value": "password"}},
        "search":
        {"index": "0", "item":
            {"item_type": "value", "value": "search_string"}}}
    b = {"operation": "create", "item":
        {"index": "0", "item":
            {"item_type": "value", "value": "password"}},
        "search":
        {"index": "0", "item":
            {"item_type": "value", "value": "search_string"}}}
    assert recursive_diff(a, b) == None


# Generated at 2022-06-22 21:36:31.977075
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:40.952890
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:50.652830
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {'key1': 1, 'key_also_1': 'foo1', 'key2': {'key2-1': 'bar1', 'key2-2': 'baz1'}}
    right = {'key1': 1, 'key_also_1': 'foo2', 'key2': {'key2-1': 'bar2', 'key2-2': 'baz2'}}
    diff = recursive_diff(left, right)
    assert diff == ({'key_also_1': 'foo1'}, {'key_also_1': 'foo2'})

    left = {'key1': 1, 'key_also_1': 'foo1', 'key2': {'key2-1': 'bar1', 'key2-2': 'baz1'}}

# Generated at 2022-06-22 21:36:56.257569
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': {
            'e': 'e',
            'f': 'f',
            'g': 'g',
        },
        'h': {
            'i': 'i',
            'j': 'j',
            'k': 'k',
            'l': {
                'm': 'm',
                'n': 'n',
                'o': 'o',
            },
        },
    }

# Generated at 2022-06-22 21:37:03.188259
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'foo_bar_baz': 'hello world',
        'list_of_things': [
            {'one': 1, 'two': 2, 'three': 3},
            {'this_is_an_int': 12345, 'this_is_a_string': '54321'}
        ]
    }

    camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=True)

    assert len(snake_dict) == len(camel_dict)
    assert snake_dict['foo_bar_baz'] == camel_dict['FooBarBaz']
    assert snake_dict['list_of_things'] == camel_dict['ListOfThings']



# Generated at 2022-06-22 21:37:10.833507
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = { "name": "foo_bar", "resource_type": { "name": "foo_resource", "list_of_things": [{ "another_thing": "value" }, { "another_thing": "value" }] } }
    result = snake_dict_to_camel_dict(test_dict)
    assert result == { "name": "foo_bar", "resourceType": { "name": "foo_resource", "listOfThings": [{ "anotherThing": "value" }, { "anotherThing": "value" } ] } }


# Generated at 2022-06-22 21:37:22.041075
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_camel = {'VpcId': 'vpc-12345678',
                       'Tags': {'Tag': [{'Key': 'thing1',
                                         'Value': 'value1'},
                                        {'Key': 'thing2',
                                         'Value': 'value2'}]},
                       'FooBar': 'test_FooBar'}
    expected_dict = {'vpc_id': 'vpc-12345678',
                     'tags': {'Tag': [{'key': 'thing1',
                                       'value': 'value1'},
                                      {'key': 'thing2',
                                       'value': 'value2'}]},
                     'foo_bar': 'test_FooBar'}

# Generated at 2022-06-22 21:37:33.181738
# Unit test for function dict_merge
def test_dict_merge():
    """
    Test dict_merge
    """

    dict1 = {'a': {'b': 1, 'c': 2, 'd': 3, 'e': {'f': 4}},
             'b': {'a': 7, 'c': 10, 'd': 11},
             'd': 5,
             'e': 6}

    dict2 = {'a': {'b': 2, 'c': 3, 'd': 5},
             'b': {'a': 8, 'd': 12},
             'e': {'g': 10}}


# Generated at 2022-06-22 21:37:43.425605
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'key1': {'key2': {'key3': 'value3'}}, 
          'key4': 'value4'}
    d2 = {'key1': {'key2': {'key3': 'value3'}}, 
          'key5': 'value5'}
    d3 = {'key1': {'key2': {'key3': 'value3'}}, 
          'key4': 'value4',
          'key5': 'value5'}
    d4 = {'key1': {'key2': {'key3': 'value3'}}, 
          'key4': 'value4',
          'key5': 'value5'}

# Generated at 2022-06-22 21:37:46.862200
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict1 = {'FooBar': 'Bar'}
    dict2 = {'FooBar': 'Bar'}
    assert(snake_dict_to_camel_dict(dict1, capitalize_first=True) == dict2)

# Generated at 2022-06-22 21:37:58.337552
# Unit test for function recursive_diff
def test_recursive_diff():
    test_case_1 = {'dict1': {'key1': 'value1'},
                   'dict2': {'key2': 'value2'},
                   'expected': ({'key1': 'value1'}, {'key2': 'value2'})}

    test_case_2 = {'dict1': {'key1': 'value1', 'key2': {'key3': 'value3', 'key4': 'value4'}},
                   'dict2': {'key1': 'value1', 'key2': {'key3': 'value3', 'key5': 'value5'}},
                   'expected': ({'key2': {'key4': 'value4'}}, {'key2': {'key5': 'value5'}})}


# Generated at 2022-06-22 21:38:10.124673
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test normal case
        - camel_dict's key is single word
        - camel_dict's value is list or dict
        - camel_dict's value has many level lists
    """
    # Test
    camel_dict = dict(
        Tags=[
            dict(
                Key="Key",
                Value="Value"
            ),
            dict(
                Key="Key2",
                Value="Value2"
            )
        ],
        Name="not_allowed",
        Type="camel_dict"
    )
    assert dict(
        tags=[
            dict(
                key="Key",
                value="Value"
            ),
            dict(
                key="Key2",
                value="Value2"
            )
        ],
        name="not_allowed",
        type="camel_dict"
    ) == camel_

# Generated at 2022-06-22 21:38:19.871280
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    actual = {
        "test": "True",
        "keyId": "26",
        "Http": {
            "HttpEndpoint": {
                "Url": "http://test.com"
            }
        },
        "Tcp": {
            "TcpEndpoint": {
                "Url": "tcp://test.com:80"
            }
        },
        "Tags": {
            "TagOne": "test",
            "TagTwo": "test"
        },
        "Failover": {
            "Policy": "primary",
            "default": []
        }
    }

    # Test default output

# Generated at 2022-06-22 21:38:30.577186
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(
        a=1,
        b=dict(
            b1=dict(
                d=4,
                e=5
            ),
            b2=dict(
                f=6,
                g=7,
            ),
            b3=[8, 9, 10]
        ),
        c=3
    )
    b = dict(
        a=1,
        b=dict(
            b1=dict(
                d=4,
                e=5,
                bob=99
            ),
            b3=dict(
                f=6,
                g=7,
            )
        ),
        c=3,
        d=4
    )

    c = dict_merge(a, b)

# Generated at 2022-06-22 21:38:38.194205
# Unit test for function dict_merge
def test_dict_merge():
    # simple merge
    a = {'a': {'b': {'c': 'd'}}}
    b = {'a': {'b': {'e': 'f'}}}
    assert(dict_merge(a, b) == {'a': {'b': {'c': 'd', 'e': 'f'}}})

    # deep merge
    c = {'a': {'g': 'h'}}
    assert(dict_merge(a, c) == {'a': {'b': {'c': 'd'}, 'g': 'h'}})

    # insert new key
    d = {'j': 'k'}
    assert(dict_merge(a, d) == {'a': {'b': {'c': 'd'}}, 'j': 'k'})

    #

# Generated at 2022-06-22 21:38:46.879034
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:38:52.370462
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # test values
    snake_dict_lower_case = {
        'key_one': 'value_one',
        'key_two': 'value_two',
        'key_three': 'value_three'
    }

    snake_dict_upper_case = {
        'KEY_ONE': 'value_one',
        'KEY_TWO': 'value_two',
        'KEY_THREE': 'value_three'
    }

    camel_dict_expected = {
        'keyOne': 'value_one',
        'keyTwo': 'value_two',
        'keyThree': 'value_three'
    }


# Generated at 2022-06-22 21:39:01.119560
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:11.168097
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {
            "isHTTP": True,
            "HTTPEndpoint": "test_endpoint",
            "AllowedPatterns": [
                "10.1.1.1"
            ],
            "Tags": {
                "Info": "test_info"
            }
        }, True) == {
        "is_h_t_t_p": True,
        "h_t_t_p_endpoint": "test_endpoint",
        "allowed_patterns": [
            "10.1.1.1"
        ],
        "tags": {
            "Info": "test_info"
        }
    }



# Generated at 2022-06-22 21:39:18.179197
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:29.539081
# Unit test for function dict_merge
def test_dict_merge():
    # pylint: disable=redefined-outer-name

    # Test merge of both dictionaries being empty
    a = {}
    b = {}
    result = {}
    assert dict_merge(a, b) == result

    # Test merge of one dictionary being empty
    a = {}
    b = {'a': 'b',
         'c': 'd',
         'e': {'f': {'g': 'h'}}}
    result = {
        'a': 'b',
        'c': 'd',
        'e': {'f': {'g': 'h'}}
    }
    assert dict_merge(a, b) == result

    # Test merge of both dictionaries having single entry
    a = {'a': 'b'}
    b = {'c': 'd'}
    result

# Generated at 2022-06-22 21:39:41.031351
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Ensures that dictionary retains camel case if reversible is False
    """

    input = {'HTTPDomain': '1234567890.com'}
    output = camel_dict_to_snake_dict(input)
    assert output == {'http_domain': '1234567890.com'}
    output_reversible = camel_dict_to_snake_dict(input, reversible=True)
    assert output_reversible == {'h_t_t_p_domain': '1234567890.com'}
    output_recamelized = camel_dict_to_snake_dict(output_reversible, reversible=True)
    assert output_recamelized == {'h_t_t_p_domain': '1234567890.com'}
    assert input == snake_dict_to_c

# Generated at 2022-06-22 21:39:51.101448
# Unit test for function recursive_diff
def test_recursive_diff():

    # Simple case (dict1 is a parent of dict2)
    d1 = {'a': 1}
    d2 = {'a': 1, 'b': 2}
    assert (recursive_diff(d1, d2) == ({'b': 2}, None))

    # Simple case (dict2 is a parent of dict1)
    d1 = {'a': 1, 'b': 2}
    d2 = {'a': 1}
    assert (recursive_diff(d1, d2) == (None, {'b': 2}))

    # Recursive case (dict1 is a parent of dict2)
    d1 = {'a': {'aa': 'aa1'}}
    d2 = {'a': {'aa': 'aa1', 'bb': 'bb1'}}

# Generated at 2022-06-22 21:40:00.520930
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    original_dict = {
        'FunctionName': 'testfn',
        'Runtime': 'python2.7',
        'Handler': 'testhandler',
        'VpcConfig': {
            'VpcId': 'vpc-123456',
            'SecurityGroupIds': [
                'sg-123456'
            ],
            'SubnetIds': [
                'subnet-123456',
                'subnet-234567'
            ]
        },
        'Tags': {
            'Foo': 'bar'
        }
    }

# Generated at 2022-06-22 21:40:12.854654
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({'foo_bar': {'bar_baz': 'qux'}}) == {'fooBar': {'barBaz': 'qux'}}
    assert snake_dict_to_camel_dict({'foo_bar': {'bar_baz': 'qux'}}, capitalize_first=True) == {'FooBar': {'BarBaz': 'qux'}}
    assert snake_dict_to_camel_dict({'foo_bar': {'bar_baz': {'qux': 'target_group_arns'}}}, capitalize_first=True) == {'FooBar': {'BarBaz': {'Qux': 'target_group_arns'}}}

# Generated at 2022-06-22 21:40:19.779016
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4'}}
    dict2 = {'a': '5', 'b': '2', 'c': {'d': '6', 'f': '4'}}
    dict3 = {'a': '5', 'b': '2', 'c': {'d': '6', 'f': '4'}, 'g': '7'}
    dict4 = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4'}, 'g': '7'}

# Generated at 2022-06-22 21:40:27.439929
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': {'bar': 1, 'baz': 2}, 'boo': {'bar': 1}}
    b = {'foo': {'baz': 3}, 'boo': {'baz': 4}}

    result = dict_merge(a,b)
    expected = {'foo': {'bar': 1, 'baz': 3}, 'boo': {'bar': 1, 'baz': 4}}

    assert result == expected, "dict_merge returned %s when %s was expected" % (result, expected)