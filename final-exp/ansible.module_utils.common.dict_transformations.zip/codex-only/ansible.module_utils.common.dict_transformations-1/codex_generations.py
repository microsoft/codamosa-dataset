

# Generated at 2022-06-22 21:30:31.496652
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    before = {'foo_bar': {'baz_tend': [1, 2, 3], 'baz_tend_two': 2}}

    after = {'fooBar': {'bazTend': [1, 2, 3], 'bazTendTwo': 2}}
    assert snake_dict_to_camel_dict(before) == after

    after = {'FooBar': {'BazTend': [1, 2, 3], 'BazTendTwo': 2}}
    assert snake_dict_to_camel_dict(before, capitalize_first=True) == after

# Generated at 2022-06-22 21:30:42.331056
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"FooBar": 1}) == {"foo_bar": 1}
    assert camel_dict_to_snake_dict({"FooBar": 1, "Baz": 2}) == {"foo_bar": 1, "baz": 2}
    assert camel_dict_to_snake_dict({"FooBar": {"Baz": 2}}) == {"foo_bar": {"baz": 2}}
    assert camel_dict_to_snake_dict({"FooBar": {"Baz": [2, 3]}}) == {"foo_bar": {"baz": [2, 3]}}
    assert camel_dict_to_snake_dict({"FooBar": {"Baz": {"Zot": 1}}}) == {"foo_bar": {"baz": {"zot": 1}}}

# Generated at 2022-06-22 21:30:52.480386
# Unit test for function dict_merge
def test_dict_merge():
    """Unit test for the dict_merge function."""
    import unittest

    class TestDictMerge(unittest.TestCase):

        def test_empty(self):
            a = {}
            b = {}
            self.assertEqual(dict_merge(a, b), {})

        def test_empty_to_dict(self):
            a = {}
            b = {'a': {'b': 'c'}}
            self.assertEqual(dict_merge(a, b), {'a': {'b': 'c'}})

        def test_dict_to_empty(self):
            a = {'a': {'b': 'c'}}
            b = {}

# Generated at 2022-06-22 21:30:59.075956
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    example_dict = {'Name': 'Bob', 'URL': 'http://example.com', 'Int': 1, 'Tags': {'Key': 'Value'}}
    expected_dict = {'name': 'Bob', 'u_r_l': 'http://example.com', 'int': 1, 'tags': {'Key': 'Value'}}
    assert camel_dict_to_snake_dict(example_dict, False) == expected_dict


# Generated at 2022-06-22 21:31:08.008742
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(one=dict(two=2, three=3, four=4),
             five=dict(six=6))
    b = dict(one=dict(two=22, three=33),
             five=dict(seven=7))

    result = dict_merge(a,b)

    assert result['one']['two'] == 22
    assert result['one']['three'] == 33
    assert result['one']['four'] == 4
    assert result['five']['six'] == 6
    assert result['five']['seven'] == 7



# Generated at 2022-06-22 21:31:16.185293
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict, snake_dict_to_camel_dict

    assert snake_dict_to_camel_dict({'abc_def': 1}) == {'abcDef': 1}
    assert snake_dict_to_camel_dict({'abc_def': 1}, capitalize_first=True) == {'AbcDef': 1}
    assert snake_dict_to_camel_dict({'abc_def': {'ghi_jkl': 2}}, capitalize_first=True) == \
           {'AbcDef': {'GhiJkl': 2}}


# Generated at 2022-06-22 21:31:26.208195
# Unit test for function recursive_diff
def test_recursive_diff():
    print("Testing function recursive_diff")

    # Test empty dicts
    print("\tEmpty dicts")
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == None
    dict1 = {'test': {'test1': 'test', 'test2': 'test'}}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == ({'test': {'test1': 'test', 'test2': 'test'}}, {})
    dict1 = {'test': 'test', 'test1': 'test'}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == ({'test': 'test', 'test1': 'test'}, {})

    # Test different values
    print("\tValues")

# Generated at 2022-06-22 21:31:37.114509
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'test_case': 'foo'}) == {'testCase': 'foo'}
    assert snake_dict_to_camel_dict({'test_case': 'foo'}, capitalize_first=True) == {'TestCase': 'foo'}
    assert snake_dict_to_camel_dict({'test_case': ['foo', 'bar']}) == {'testCase': ['foo', 'bar']}
    assert snake_dict_to_camel_dict({'test_case': {'foo': 'bar', 'baz': 'bash'}}) == {'testCase': {'foo': 'bar', 'baz': 'bash'}}

# Generated at 2022-06-22 21:31:48.006307
# Unit test for function recursive_diff
def test_recursive_diff():
    first_dict = {
        'name': 'nondescript',
        'nested_dict': {
            'name': 'nested_nondescript',
            'key_a': 'value_a',
            'key_b': 'value_b'
        },
        'key_a': 'value_a',
        'key_b': 'value_b',
        'key_c': 'value_c'
    }

# Generated at 2022-06-22 21:31:59.012766
# Unit test for function dict_merge
def test_dict_merge():
    "This function tests the dict_merge function by feeding it test data"

    def _test_dict_merge(a, b, expected):
        "Helper function to test dict_merge"
        actual = dict_merge(a, b)
        assert actual == expected, "act: %s != exp: %s" % (actual, expected)

    # Basic case
    _test_dict_merge({'a': 1}, {'b': 2}, {'a': 1, 'b': 2})

    # Both dicts have same key, dict value
    _test_dict_merge({'a': {'x': 1}}, {'a': {'y': 2}}, {'a': {'x': 1, 'y': 2}})

    # dict2 value replaces dict1 value

# Generated at 2022-06-22 21:32:10.695787
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    test_dict = {
        "vpc_id": "vpc-123456789",
        "tags": {
            "Name": "my-vpc"
        }
    }

    expected_result = {
        "vpcId": "vpc-123456789",
        "tags": {
            "Name": "my-vpc"
        }
    }
    result = snake_dict_to_camel_dict(test_dict)
    assert expected_result == result

    expected_result = {
        "VpcId": "vpc-123456789",
        "Tags": {
            "Name": "my-vpc"
        }
    }
    result = snake_dict_to_camel_dict(test_dict, capitalize_first=True)
    assert expected_result == result



# Generated at 2022-06-22 21:32:15.971308
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aBc': [{'dEf': 'ghi'}]}) == {'a_bc': [{'d_ef': 'ghi'}]}
    assert camel_dict_to_snake_dict({'aBc': [{'dEfGhi': [{'jKlMno': 'pqr'}]}]}) == {'a_bc': [{'d_ef_ghi': [{'j_kl_mno': 'pqr'}]}]}

# Generated at 2022-06-22 21:32:27.940824
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1}}
    d2 = {'a': {'c': 2}}
    assert(dict_merge(d1, d2) == {'a': {'b': 1, 'c': 2}})
    d1 = {'a': {'b': 1}}
    d2 = {'a': {'b': 2}}
    assert(dict_merge(d1, d2) == {'a': {'b': 2}})
    d1 = {'a': {'b': {'c': {'d': 1}}}}
    d2 = {'a': {'b': {'c': {'e': 2}}}}

# Generated at 2022-06-22 21:32:36.908273
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert (snake_dict_to_camel_dict({"hello_world": None}) == {"HelloWorld": None})
    assert (snake_dict_to_camel_dict({"hello_world": "foobar"}) == {"HelloWorld": "foobar"})
    assert (snake_dict_to_camel_dict({"hello_world": {"foo": "bar"}}) == {"HelloWorld": {'Foo': 'bar'}})
    assert (snake_dict_to_camel_dict({"hello_world": {"foo": "bar"}}, capitalize_first=True) == {"HelloWorld": {'Foo': 'bar'}})

# Generated at 2022-06-22 21:32:43.165531
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Check if function recursive_diff is working
    """
    dict_a = {'a': 1, 'b': 2, 'c': {'first': 1, 'second': 2}}
    dict_b = {'a': 1, 'b': 2, 'c': {'first': 1, 'second': 2}}
    assert recursive_diff(dict_a, dict_b) == None # pylint: disable=singleton-comparison

    dict_a = {'a': 1, 'b': 2, 'c': {'first': 1, 'second': 2}}
    dict_b = {'a': 1, 'b': 2, 'c': {'first': 1, 'third': 2}}

# Generated at 2022-06-22 21:32:50.456048
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }

    c = dict_merge(a, b)

    assert expected == c, "%s does not equal %s" % (expected, c)

# Generated at 2022-06-22 21:32:56.978671
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'firstKey': 'a', 'secondKey': 'b'}) == {'first_key': 'a', 'second_key': 'b'}
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'a'}) == {'http_endpoint': 'a'}
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'a'}, True) == {'h_t_t_p_endpoint': 'a'}
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'a'}, True, ['Tags']) == {'h_t_t_p_endpoint': 'a'}

# Generated at 2022-06-22 21:33:06.732075
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({"a":1}, {"b":2}) == {"a":1, "b":2}
    assert dict_merge({"a":1}, {"a":2}) == {"a":2}
    assert dict_merge({"a":1, "b":1}, {"b":2, "c":2}) == {"a":1, "b":2, "c":2}
    assert dict_merge({"a":{"a":1}}, {"a":{"b":2}}) == {"a":{"a":1, "b":2}}
    assert dict_merge({"a":{"a":1, "b":1}}, {"a":{"b":2, "c":2}}) == {'a': {'a': 1, 'b': 2, 'c': 2}}

# Generated at 2022-06-22 21:33:15.033679
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dicts = [
        {"this_is_a_test": "foo"},
        {"this_is_a_test": {"foo_bar": "baz"}},
        {"this_is_a_test": [{"foo_bar": "baz"}]},
    ]
    for snake_dict in snake_dicts:
        camel_dict = snake_dict_to_camel_dict(snake_dict)
        for key in snake_dict:
            assert key in camel_dict
            assert key not in camel_dict.keys()



# Generated at 2022-06-22 21:33:20.020601
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'zombie': 'awakened', 'KEY': 'value'}) == {'zombie': 'awakened', 'key': 'value'}
    assert (camel_dict_to_snake_dict({'someCamelCaseString': None}) == {'some_camel_case_string': None})


# Generated at 2022-06-22 21:33:26.358303
# Unit test for function dict_merge
def test_dict_merge():

    a = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}}
    b = {'c': {'h': 'i'}, 'j': 'k'}
    merged = dict_merge(a, b)
    assert merged['a'] == 'b'
    assert merged['c']['d'] == 'e'
    assert merged['c']['f'] == 'g'
    assert merged['c']['h'] == 'i'
    assert merged['j'] == 'k'



# Generated at 2022-06-22 21:33:38.141028
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    def assert_dicts_equal(dict1, dict2):
        for key in dict1.keys():
            assert key in dict2
            assert dict1[key] == dict2[key]

    snake_dict = {"foo_bar_baz": "test1", "test_test": 2, "foobar":
                  {"foo_bar_baz": "test1", "test_test": 2, "foobar":
                   {"foo_bar_baz": "test1", "test_test": 2, "foobar":
                    {"foo_bar_baz": "test1", "test_test": 2, "foobar":
                     {"foo_bar_baz": "test1", "test_test": 2, "foobar":
                      {"foo_bar_baz": "test1", "test_test": 2}}}}}}


# Generated at 2022-06-22 21:33:50.211552
# Unit test for function dict_merge
def test_dict_merge():
    # Tests for dict_merge.
    a = {'foo': 'bar'}
    b = {'fizz': 'buzz'}
    c = dict_merge(a, b)
    assert c['foo'] == 'bar'
    assert c['fizz'] == 'buzz'

    a = {'foo': 'bar'}
    b = {'foo': {'fizz': 'buzz'}}
    c = dict_merge(a, b)
    assert c['foo'] == {'fizz': 'buzz'}

    a = {'foo': {'bar': 'baz'}}
    b = {'foo': {'fizz': 'buzz'}}
    c = dict_merge(a, b)

# Generated at 2022-06-22 21:33:57.809580
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'fooBar': 'baz', 'qux': {'fooBar': 'baz'}, 'myHTTPEndpoint': 'localhost:8080'}
    snake_dict = {'foo_bar': 'baz', 'qux': {'foo_bar': 'baz'}, 'my_h_t_t_p_endpoint': 'localhost:8080'}

    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == snake_dict



# Generated at 2022-06-22 21:34:08.437403
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test equal
    dict1 = {'a':1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    dict2 = {'a':1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    assert recursive_diff(dict1, dict2) == None
    # Test simple unequal
    dict1 = {'a':1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    dict2 = {'a':1, 'b': 2, 'c': {'a': 1, 'b': 3}}
    assert recursive_diff(dict1, dict2) == ({'b': 2}, {'b': 3})
    # Test unequal with additional key in dict1

# Generated at 2022-06-22 21:34:19.066455
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input = {'key_with_lower_case': 'value',
             'KeyWithCamelCase': 'value',
             'HttpHeaders': [{'headerName': 'value'}],
             'TargetGroupARNs': ['value1', 'value2'],
             'Tags': {'ARN': 'value'}}
    output_with_false = {'keyWithLowerCase': 'value',
                         'keyWithCamelCase': 'value',
                         'httpHeaders': [{'headerName': 'value'}],
                         'targetGroupARNs': ['value1', 'value2'],
                         'Tags': {'ARN': 'value'}}

# Generated at 2022-06-22 21:34:29.287936
# Unit test for function dict_merge
def test_dict_merge():
    """Unit test for function dict_merge"""
    a = {'foo': {'bar': {'qux': 'qux1', 'quux': 'quux1'}}}
    b = {'foo': {'bar': {'qux': 'qux2', 'quuux': 'quuux1'}, 'baz': {'qux': 'qux3', 'quuux': 'quuux3'}}}
    result = dict_merge(a, b)
    assert result == {'foo': {'bar': {'quux': 'quux1', 'qux': 'qux2', 'quuux': 'quuux1'}, 'baz': {'qux': 'qux3', 'quuux': 'quuux3'}}}
    print("Function dict_merge() ok.")



# Generated at 2022-06-22 21:34:37.429152
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = dict(
        key1='value1',
        key2='value2',
        key_3=dict(
            key4='value4',
            key5='value5',
            key_6=dict(
                key7='value7',
                key8='value8',
                key_9=dict(
                    key10='value10',
                    key11='value11'
                )
            )
        )
    )

    camel_dict = snake_dict_to_camel_dict(snake_dict)

# Generated at 2022-06-22 21:34:49.725629
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test no difference
    assert recursive_diff({'a': {'b': 1}, 'c': 2}, {'a': {'b': 1}, 'c': 2}) is None

    # Test distance differences
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 2}) == ({'a': 1, 'b': 2}, {'a': 2})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}}) == ({'a': {'b': 1}}, {'a': {'b': 2}})

    # Test addition differences

# Generated at 2022-06-22 21:35:00.910023
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"foo": "bar"}
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=True) == {"Foo": "bar"}
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=False) == {"foo": "bar"}

    test_dict = {"foo": "bar"}
    test_dict["baz"] = {"blah": "boom"}
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=False) == {"foo": "bar", "baz": {"blah": "boom"}}
    assert snake_dict_to_camel_dict(test_dict, capitalize_first=True) == {"Foo": "bar", "Baz": {"Blah": "boom"}}


# Generated at 2022-06-22 21:35:10.402644
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test case where left and right are equal
    dict1 = dict()
    dict2 = dict()
    assert recursive_diff(dict1, dict2) == None

    # Test case where left and right are not equal
    dict1 = dict(parent=dict())
    dict2 = dict(child=dict())
    assert recursive_diff(dict1, dict2) == ({'parent': {}}, {'child': {}})

    # Test case where left and right are equal but have children that are not equal
    dict1 = dict(parent=dict(child=dict(grandparent=dict())))
    dict2 = dict(parent=dict(child=dict(grandchild=dict())))

# Generated at 2022-06-22 21:35:20.605843
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'key1': 'value1',
        'Key2': {'key3': {'key4': 'value4'}, 'Key5': 'value5', 'key6': 'value6'},
        'key7': {'key8': 'value8'},
        'key9': [{'key10': 'value10'}],
        'Key11': 'value11',
        'Key12': 12,
        'Key13': None
    }


# Generated at 2022-06-22 21:35:28.186852
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict1 = {
        "key_with_mixed_case_key": "value with mixed case value",
        "key_with_mixed_case_key_nested": {
            "key_with_mixed_case_key": "value with mixed case value",
            "key_with_mixed_case_key_nested": {
                "key_with_mixed_case_key": "value with mixed case value"
            },
            "key_with_mixed_case_key_array": [
                {
                    "key_with_mixed_case_key": "value_with_mixed_case_value"
                }
            ]
        }
    }

# Generated at 2022-06-22 21:35:35.918362
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:35:47.362077
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'A': {'A1': 1}, 'B': {'B1': 1}}
    dict2 = {'A': {'A1': 1}, 'B': {'B1': 1}, 'C': {'C1': 1}}
    result = recursive_diff(dict1, dict2)
    assert result == ({}, {'C': {'C1': 1}})

    dict2 = {'A': {'A1': 1}, 'B': {'B1': 2}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'B': {'B1': 1}}, {'B': {'B1': 2}})

    dict1 = {'A': {'A1': {'A11': 1}}}

# Generated at 2022-06-22 21:35:57.106067
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'prop1': 'a', 'prop2': {'a': 'b'}}, {'prop1': 'a', 'prop2': {'a': 'b'}}) is None
    assert recursive_diff({'prop1': 'a', 'prop2': {'a': 'b'}}, {'prop1': 'a'}) == (
        {'prop2': {'a': 'b'}}, {})
    assert recursive_diff({'prop1': 'a', 'prop2': {'a': 'b'}}, {'prop1': 'a', 'prop2': {'a': 'bb'}}) == (
        {'prop2': {'a': 'bb'}}, {'prop2': {'a': 'b'}})

# Generated at 2022-06-22 21:36:04.019056
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    my_dict = {
        "ref": "resource.my_resource",
        "list_value": [
            "list_item_value",
            {
                "dict_value": "item_value"
            }
        ]
    }

    # Test default return
    result = snake_dict_to_camel_dict(my_dict)
    assert result["listValue"][1]["dictValue"] == "item_value"

    # Test capitalize_first=True results
    result = snake_dict_to_camel_dict(my_dict, True)
    assert result["ListValue"][1]["DictValue"] == "item_value"

# Generated at 2022-06-22 21:36:13.479577
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:21.205345
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # If the same snake_dict is passed in, the same dict should
    # be returned by snake_dict_to_camel_dict
    snake_dict = {
        u'foo_bar': u'hello',
        u'baz_quux': 42,
        u'_underscored': True,
        u'already_camelCase': False,
        u'things': [
            {u'this_is_snake': u'yep'},
            {u'also_snake': False}
        ]
    }
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)

    # If the same camel_dict is passed in, the same dict should
    # be returned by

# Generated at 2022-06-22 21:36:32.141595
# Unit test for function dict_merge
def test_dict_merge():
    source = {
        "branch": "master",
        "formats": ["html", "pdf"],
        "author": {
            "firstname": "Nik",
            "surname": "Johnson",
        },
        "version": 0.1,
    }
    target = {
        "branch": "release",
        "formats": ["html", "epub"],
        "version": 1.0,
        "author": {
            "firstname": "Nik",
            "middlename": "B",
            "surname": "Johnson",
        },
    }


# Generated at 2022-06-22 21:36:41.039492
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:51.906861
# Unit test for function recursive_diff
def test_recursive_diff():
    expected = ({'a': {'b': 1}, 'c': 3}, {'a': {'b': 4}, 'e': 5})
    # Both keys and values differ
    assert recursive_diff({'a': {'b': 1}, 'c': 3, 'd': 4},
                          {'a': {'b': 4}, 'e': 5}) == expected
    # One key, one value different
    assert recursive_diff({'a': {'b': 1}, 'c': 3},
                          {'a': {'b': 4}, 'e': 5}) == expected
    # Both keys and values differ, mixed in with other non-dict keys

# Generated at 2022-06-22 21:36:57.067857
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"test_snake_key": "test_snake_value",
                 "test_camel_key": {"nested_snake_key": "nested_snake_val",
                                    "nested_camel_key": {"deeper_dict": "yup"}},
                 "another_snake_key": "another_value",
                 "test_list": [1,2,3],
                 "test_list_of_dicts": [{"key": "value"}, {"another_key": "another_value"}]
                 }

# Generated at 2022-06-22 21:37:03.366490
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'aa': 5, 'bb': 6}, 'key2': {'cc': 7, 'dd': 8}, 'key3': 9}
    b = {'key1': {'aa': 50, 'dd': 80}, 'key2': {'ee': 70}, 'key3': 90}
    result = {'key1': {'aa': 50, 'bb': 6, 'dd': 80}, 'key2': {'ee': 70, 'cc': 7, 'dd': 8}, 'key3': 90}

    if dict_merge(a, b) != result:
        raise Exception("Expected %s, got %s" % (result, dict_merge(a, b)))

# Unit tests for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:37:13.895951
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {'Name': 'Foo', 'Tags': {'Key': 'Role', 'Value':'Test'}, 'Prop1': 'Test', 'Prop2': 'Test', 'Prop3': 'Test', 'Prop4': 'Test'}
    dict2 = {'Name': 'Foo', 'Tags': {'Key': 'Role', 'Value':'Test2'}, 'Prop2': 'Test2', 'Prop3': 'Test2', 'Prop4': 'Test2'}
    expected = ({'Tags': {'Value': 'Test'}}, {'Tags': {'Value': 'Test2'}})
    assert recursive_diff(dict1, dict2) == expected


# Generated at 2022-06-22 21:37:18.418497
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'first_name': 'John', 'last_name': 'Doe', 'tags': {'tag1': 'value1', 'tag2': 'value2'}}
    camel_dict = {'firstName': 'John', 'lastName': 'Doe', 'tags': {'tag1': 'value1', 'tag2': 'value2'}}
    assert snake_dict_to_camel_dict(snake_dict) == camel_dict


# Generated at 2022-06-22 21:37:28.020028
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'animal': 'emu',
        'reptile': {
            'snake': 'python',
            'lizard': {
                'gecko': 'leopard',
                'dragon': 'chinese'
            }
        }
    }
    b = {
        'animal': 'emu',
        'reptile': {
            'snake': 'python',
            'lizard': {
                'gecko': 'crested',
                'iguana': 'green'
            }
        }
    }


# Generated at 2022-06-22 21:37:34.155368
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'b': 1, 'c': 2, 'd': { 'e': 3, 'f': 4 } }
    b = { 'c': 42, 'd': { 'e': 43, 'f': 44, 'g': 45 } }
    c = { 'b': 42, 'c': 2, 'd': { 'e': 3, 'f': 44, 'g': 45 } }
    assert dict_merge(a, b) == c

# Generated at 2022-06-22 21:37:39.746787
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(
        dict(name='John', age=30, salary=10000,
             family=dict(name='Jane', age=30, salary=20000),
             tags=['loves beer', 'loves pizza']),
        dict(name='Doe', age=40, salary=20000,
             family=dict(name='Mike', age=30, salary=10000),
             tags=['loves beer', 'hates pizza'])) == dict(
        name='Doe', age=40, salary=20000,
        family=dict(name='Mike', age=30, salary=10000),
        tags=['loves beer', 'hates pizza'])


# Generated at 2022-06-22 21:37:50.196242
# Unit test for function dict_merge
def test_dict_merge():
    # Test empty dicts
    a = {}
    b = {}
    merged = dict_merge(a, b)
    assert merged == {}
    # Test empty vs not empty
    b = {"foo": "bar"}
    merged = dict_merge(a, b)
    assert merged == b
    a = {"one": "two"}
    merged = dict_merge(a, b)
    assert merged == {"foo": "bar", "one": "two"}
    # Test nested dicts
    a = {"first": {"one": "two"}}
    b = {"first": {"three": "four"}}
    assert dict_merge(a, b) == {"first": {"one": "two", "three": "four"}}
    # Test lists
    a = {"first": ["one", "two"]}

# Generated at 2022-06-22 21:38:00.498254
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(foo="bar", bar="baz", hi=dict(one="un", two="deux"), three="tres")
    dict2 = dict(foo="baz", bar="baz", hi=dict(one="uno", two="deux"), three="three")
    dict3 = dict(foo="baz", bar="baz", hi=dict(one="uno", two="deux", three="tres"), three="three")
    dict4 = dict(foo="baz", bar="baz", hi=dict(one="uno", two="deux", three="tres", four="quatre"), three="three")
    dict5 = dict(foo="baz", bar="baz", hi=dict(one="uno", two="deux", three="tres", four="quatre"), three="three", five="cinq")

# Generated at 2022-06-22 21:38:12.319696
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Key1': 'value1',
        'Key2': {
            'Key3': 'value3',
            'Key4': [
                'value4.1',
                {
                    'Key5': 'value5'
                }
            ]
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['key1'] == 'value1'
    assert snake_dict['key2']['key3'] == 'value3'
    assert snake_dict['key2']['key4'][0] == 'value4.1'
    assert snake_dict['key2']['key4'][1]['key5'] == 'value5'


# Generated at 2022-06-22 21:38:24.082264
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:38:34.030246
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:38:43.474624
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key6': {'key7': 'value7'}}
    dict2 = {'key3': 'value3bis', 'key4': 'value4', 'key5': 'value5'}
    dict3 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3bis', 'key4': 'value4', 'key5': 'value5', 'key6': {'key7': 'value7'}}

    assert dict_merge(dict1, dict2) == dict3

# Generated at 2022-06-22 21:38:55.561113
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Input dictionary
    snake_dict = {'basic_auth_user': 'foo',
                  'basic_auth_password': 'bar',
                  'client_id': '83648',
                  'connect_timeout_seconds': 5,
                  'read_timeout_seconds': 5,
                  'tags': {'key': 'value'}}

    # Expected output dictionary
    camel_dict = {'basicAuthUser': 'foo',
                  'basicAuthPassword': 'bar',
                  'clientId': '83648',
                  'connectTimeoutSeconds': 5,
                  'readTimeoutSeconds': 5,
                  'tags': {'key': 'value'}}

    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == camel_dict

# Generated at 2022-06-22 21:39:07.576439
# Unit test for function recursive_diff
def test_recursive_diff():
    a = { 'x': 1, 'y': { 'p': { 'q': 'qvalue'}}, 'z': [ 1, 2, 3]}
    b = { 'x': 1, 'y': { 'p': { 'm': 'mvalue'}}, 'z': [ 1, 2, 3]}
    assert recursive_diff(a, a) is None
    assert recursive_diff(a, b) == ({ 'y': { 'p': { 'q': 'qvalue'}}}, { 'y': { 'p': { 'm': 'mvalue'}}})
    a = { 'x': 1, 'y': { 'p': { 'q': 'qvalue'}}, 'z': [ 1, 2, 3, 4]}

# Generated at 2022-06-22 21:39:16.542005
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:28.220655
# Unit test for function recursive_diff
def test_recursive_diff():
    from random import randint
    from copy import deepcopy

    def generate_test_dict(level = 0):
        test_dict = dict()
        test_dict['key_int'] = randint(1, 10)
        for i in range(1, randint(1, 5)):
            iter_dict = dict()
            for j in range(1, randint(1, 5)):
                iter_dict.update({'key_int_%d' % j: randint(1, 10)})
            if level > 0:
                iter_dict.update({'sub_dict': generate_test_dict(level=level-1)})
            test_dict.update({'key_dict_%d' % i: iter_dict})
        return test_dict


# Generated at 2022-06-22 21:39:39.988749
# Unit test for function dict_merge
def test_dict_merge():
    # passing two empty dictionaries
    a={}
    b={}
    assert a == dict_merge(a,b)

    # passing two empty dictionaries
    a={}
    b={}
    assert a == dict_merge(a,b)

    # passing two dictionaries
    a = {
        'x': {
            'a': [1, 2, 3],
            'b': [4, 5, 6],
            'c': [7, 8, 9]
        },
        'y': 2
    }
    b = {
        'x': {
            'b': [10, 11, 12],
            'c': [13, 14, 15]
        },
        'y': 30
    }

# Generated at 2022-06-22 21:39:50.132453
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    d = {'foo_bar': 'baz'}
    assert(snake_dict_to_camel_dict(d) == {'fooBar': 'baz'})
    assert(snake_dict_to_camel_dict(d, capitalize_first=True) == {'FooBar': 'baz'})

    f = {'foo_bar': 'baz', 'sub_dict': {'sub_foo': 'sub_baz'}}
    assert(snake_dict_to_camel_dict(f) == {'fooBar': 'baz', 'subDict': {'subFoo': 'sub_baz'}})


# Generated at 2022-06-22 21:39:57.954479
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': 2, 'd': 4, 'e': {'f': [1, 2, 3, {'g': 1}]}}
    d2 = {'a': 1, 'b': 3, 'c': 3, 'e': {'f': [1, 2, 4, {'g': 2}]}}
    result = dict_merge(d1, d2)
    assert(result == {'a': 1, 'b': 3, 'd': 4, 'e': {'f': [1, 2, 4, {'g': 2}]}, 'c': 3})



# Generated at 2022-06-22 21:40:09.552733
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:40:19.854420
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict((k, i) for k, i in zip(range(1, 10), range(10, 19)))
    dict2 = dict((k, i) for k, i in zip(range(1, 10), range(19, 28)))
    dict3 = dict((k, i) for k, i in zip(range(1, 10), range(28, 37)))
    dict4 = dict((k, i) for k, i in zip(range(10, 13), range(37, 40)))

    # test basic functionality
    test_dict = dict_merge(dict1, dict2)
    assert test_dict[1] == 19
    assert test_dict[2] == 20
    assert test_dict[8] == 26
    assert test_dict[9] == 27

    # test third merge
    test_dict = dict

# Generated at 2022-06-22 21:40:31.781329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'FooBar': {'SubDict': {'SubSubValue': 1,
                                        'SubSubList': [1, 2, 3],
                                        'SubSubDict': {'SubSubList': [1, 2, 3],
                                                       'SubSubValue': 1}},
                            'MovingAverage': 0.1,
                            'Timestamp': 1536019724,
                            'Value': 1.1,
                            'MetricName': 'FakeMetric',
                            'Unit': 'Percent'},
                 'FooBarBaz': {'MovingAverage': 0.1,
                               'Timestamp': 1536019724,
                               'Value': 0.1,
                               'MetricName': 'FakeMetric',
                               'Unit': 'Percent'}
    }

