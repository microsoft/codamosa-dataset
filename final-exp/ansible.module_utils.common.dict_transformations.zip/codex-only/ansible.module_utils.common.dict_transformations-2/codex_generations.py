

# Generated at 2022-06-22 21:30:36.106322
# Unit test for function recursive_diff
def test_recursive_diff():
    # diff of two empty dict
    assert recursive_diff({}, {}) is None
    # diff of two equal dict
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 2, 'a': 1}) is None
    # diff of two dict with different values
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 1, 'a': 2}) == ({'b': 2}, {'b': 1})
    # diff of two dict with different keys
    assert recursive_diff({}, {'b': 2, 'a': 1}) == ({}, {'b': 2, 'a': 1})
    # diff of two dict with different values, different keys

# Generated at 2022-06-22 21:30:43.495338
# Unit test for function recursive_diff
def test_recursive_diff():
    # This test is based on the values in aws_s3_bucket.py.
    # could not use the actual values from that module as the
    # test files are not on the python path.
    dict1 = dict(
        name="foo",
        account_id="123456789012",
        region="us-east-1",
        location="us-east-1",
        tags=dict(
            Name="foo"
        ),
        versioning=dict(
            enabled=False
        )
    )

# Generated at 2022-06-22 21:30:49.487836
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {u'a': u'b', u'c': {u'd': u'e', u'f': u'g'}}
    d2 = {u'a': u'b', u'c': {u'f': u'g'}}

    result = recursive_diff(d1, d2)
    assert result[0]['c']['d'] == u'e'
    assert result[1]['c']['d'] is None

# Generated at 2022-06-22 21:31:00.733162
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:31:12.182306
# Unit test for function dict_merge
def test_dict_merge():

    # Test merging of strings
    a = dict(foo="string_a")
    b = dict(foo="string_b")
    c = dict_merge(a, b)
    assert a['foo'] == c['foo'] == "string_b"

    # Test merging of dicts with dict values
    a = dict(foo=dict(bar='baz'))
    b = dict(foo=dict(qux='quux'))
    c = dict_merge(a, b)
    assert a['foo'] == dict(bar='baz')
    assert b['foo'] == dict(qux='quux')
    assert c['foo'] == dict(bar='baz', qux='quux')

    # Test merging of dicts without dict values
    a = dict(foo='baz')

# Generated at 2022-06-22 21:31:17.048133
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'fooBar': 1, 'goodbyeFool': 2, 'HTTPEndpoint': 3}
    result = camel_dict_to_snake_dict(test_dict)
    assert result == {'foo_bar': 1, 'goodbye_fool': 2, 'http_endpoint': 3}



# Generated at 2022-06-22 21:31:26.807416
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    object_1 = {
        "example": {
            "tags": {
                "key_1": "value_1",
                "key_2": "value_2",
            },
            "cluster_tags": [
                {
                    "key_1": "value_1",
                    "key_2": "value_2",
                },
            ],
            "resource_tags": [
                {
                    "key_1": "value_1",
                    "key_2": "value_2",
                },
            ]
        }
    }


# Generated at 2022-06-22 21:31:37.556996
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Legacy test to assert that we're not breaking camel_dict_to_snake_dict
    camel_dict_1 = {'Route53HostedZoneId': 'Z2Z2A2A2', 'HttpsEndpoint': {'DNSName': 'aa', 'HostedZoneId': 'Z2Z2A2A2'}}
    snake_dict_1 = {'route53_hosted_zone_id': 'Z2Z2A2A2', 'https_endpoint': {'dns_name': 'aa', 'hosted_zone_id': 'Z2Z2A2A2'}}
    assert camel_dict_to_snake_dict(camel_dict_1) == snake_dict_1

    # Test for a list of items in a dictionary, to ensure we recurse into the list
    camel_dict

# Generated at 2022-06-22 21:31:48.281570
# Unit test for function dict_merge
def test_dict_merge():

    a = {"a": 1, "b": 2}
    b = {"a": 3, "d": 4}
    result = {"a": 3, "b": 2, "d": 4}
    assert(result == dict_merge(a, b))

    a = {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}
    b = {"a": 3, "c": {"d": 5, "e": 6, "f": 7}, "g": 8}
    result = {"a": 3, "b": 2, "c": {"d": 5, "e": 6, "f": 7}, "g": 8}
    assert(result == dict_merge(a, b))

    a = {"a": {"b": 1, "c": 2, "d": 3}, "e": 4}

# Generated at 2022-06-22 21:31:59.060131
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test for a normal dict
    test_dict = {
        "HTTPEndpoint": "ansible",
        "TargetGroupArn": "arn:aws:elasticloadbalancing:{}:1234:targetgroup/test_target_group/12345",
        "LoadBalancerArns": ["arn:aws:elasticloadbalancing:{}:1234:loadbalancer/test_load_balancer/12345"]
    }
    ret = camel_dict_to_snake_dict(test_dict)

# Generated at 2022-06-22 21:32:10.736461
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Function test
    test_dict = {
        'this_is_a_key': 'test',
        'key_with_list': ['test1', 'test2'],
        'key_with_dict': {
            'dict_key': 'test3'
        },
        'key_with_dict_and_list': {
            'dict_key': 'test3',
            'list': ['test4', 'test5', 'test6'],
        },
        'key_with_dict_in_list': [
            {
                'dict_key': 'test7'
            },
            {
                'dict_key': 'test8'
            }
        ]
    }

    # Function test
    test_dict_res = snake_dict_to_camel_dict(test_dict)
    test_

# Generated at 2022-06-22 21:32:15.995408
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
        "foo": 1,
        "bar": {
            "a": 1,
            "b": 2,
            "c": {
                "d": 1,
                "e": 2,
            },
        },
        "faz": None,
    }

    d2 = {
        "foo": 2,
        "bar": {
            "a": 2,
        },
        "baz": 3,
    }

    ret1 = {
        "foo": 2,
        "bar": {
            "a": 2,
            "b": 2,
            "c": {
                "d": 1,
                "e": 2,
            },
        },
        "faz": None,
        "baz": 3,
    }


# Generated at 2022-06-22 21:32:27.526539
# Unit test for function recursive_diff
def test_recursive_diff():
    """Recursively diff two dictionaries: test"""
    test_dict = {
        'foo': {
            'bar': 42,
        },
        'baz': {
            'bing': 43,
        }
    }
    test_dict_2 = {
        'foo': {
            'bar': 42,
        },
        'baz': {
            'bing': 43,
        }
    }
    assert None == recursive_diff(test_dict, test_dict_2)

    test_dict_2 = {
        'foo': {
            'bar': 43,
        },
        'baz': {
            'bing': 43,
        }
    }

# Generated at 2022-06-22 21:32:36.792330
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Test for standard camelize case
    assert snake_dict_to_camel_dict({"snake_case_key": "snake_case_value"}) == {"snakeCaseKey": "snake_case_value"}

    # Test for irregularly snake cased key and value
    assert snake_dict_to_camel_dict({"snake_case_key": "snake_case_VALUE"}) == {"snakeCaseKey": "snake_case_VALUE"}

    # Test for camel change through deep level
    assert snake_dict_to_camel_dict({"snake_case_key": {"snake_case_inner_key": "snake_case_inner_value"}}) == \
           {"snakeCaseKey": {"snakeCaseInnerKey": "snake_case_inner_value"}}

    #

# Generated at 2022-06-22 21:32:48.371423
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': {
            'id': 'id-one',
            'anotherFooBar': {
                'id': 'id-two'
            },
            'foos': ['foo-one', 'foo-two'],
            'bars': [
                {
                    'id': 'bar-one'
                },
                {
                    'id': 'bar-two'
                }
            ]
        }
    }

    # Add endpoints to validate that HTTPEndpoint becomes http_endpoint
    test_dict['HTTPEndpoint'] = "HTTPEndpoint"

    # Add tags to validate that tags are not converted to snake case
    test_dict['Tags'] = {"item": "value"}


# Generated at 2022-06-22 21:32:55.141909
# Unit test for function dict_merge
def test_dict_merge():
    a = {'first' : {'all_rows' : {'pass' : 'dog', 'number' : '1'}}}
    b = {'first' : {'all_rows' : {'fail' : 'cat', 'number' : '5'}}}
    c = {'first' : {'all_rows' : {'fail' : 'cat', 'pass' : 'dog', 'number' : '5'}}}
    d = dict_merge(a, b)
    assert d == c



# Generated at 2022-06-22 21:33:05.773959
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "key1": "value1",
        "key2": {
            "key3": "value3",
            "key4": "value4",
            "key5": "value5",
        },
    }
    dict2 = {
        "key1": "value1",
        "key2": {
            "key3": "value3",
            "key6": "value6",
            "key7": "value7",
        },
    }
    diff = recursive_diff(dict1, dict2)
    assert diff == ({}, {'key2': {'key5': 'value5', 'key4': 'value4'}, 'key7': 'value7', 'key6': 'value6'})


# Generated at 2022-06-22 21:33:16.700416
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 'value1',
         'key2': 'value2',
         'key3': {'key4': 'value4',
                  'key5': 'value5',
                  'key6': {'key7': 'value7'}}}
    b = {'key2': 'value2b',
         'key3': {'key4': 'value4b',
                  'key6': {'key7': 'value7b'}}}
    c = {'key1': 'value1',
         'key2': 'value2b',
         'key3': {'key4': 'value4b',
                  'key5': 'value5',
                  'key6': {'key7': 'value7b'}}}

    assert(dict_merge(deepcopy(a), deepcopy(b)) == c)

# Generated at 2022-06-22 21:33:27.246615
# Unit test for function dict_merge
def test_dict_merge():
    assert(dict_merge({"a": 1}, {"a": 1}) == {"a": 1})
    assert(dict_merge({"a": 1}, {"b": 2}) == {"a": 1, "b": 2})
    assert(dict_merge({"a": {"b": 1}}, {"a": {"b": 1}}) == {"a": {"b": 1}})
    assert(dict_merge({"a": {"b": 1}}, {"a": {"b": 2}}) == {"a": {"b": 2}})
    assert(dict_merge({"a": {"b": 1, "c": 2}}, {"a": {"b": 3}}) == {"a": {"b": 3, "c": 2}})


# Generated at 2022-06-22 21:33:38.584672
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit tests for function recursive_diff"""

    # Test basic recursive diff
    d1 = {"key1": "value1", "key2": {"key21": "value21"}}
    d2 = {"key1": {"key11": "value11"}, "key2": {"key21": "value21"}}
    d3 = {"key1": "value1", "key2": {"key21": "value21"}}
    d4 = {"key1": "value1", "key2": {"key21": "value21", "key22": "value22"}}
    assert recursive_diff(d1, d2) == ({"key1": "value1"}, {"key1": {"key11": "value11"}})
    assert recursive_diff(d1, d3) is None

# Generated at 2022-06-22 21:33:50.336626
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""


# Generated at 2022-06-22 21:34:01.320826
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 4,
            'e': 5,
            'f': 6,
        },
        'g': {
            'h': 7,
            'i': 8,
            'j': 9,
            'k': {
                'l': 10,
                'm': 11,
                'n': 12,
                },
            },
        }

# Generated at 2022-06-22 21:34:10.056239
# Unit test for function dict_merge
def test_dict_merge():
    # base cases
    assert(dict_merge({}, {}) == {})
    assert(dict_merge({1: 2}, {1: 2}) == {1: 2})
    assert(dict_merge({1: 2}, {1: 3}) == {1: 3})
    assert(dict_merge({1: 2}, {2: 3}) == {1: 2, 2: 3})

    # recurse
    assert(dict_merge({1: 2, 3: {1: 2}}, {3: {2: 3}}) == {1: 2, 3: {1: 2, 2: 3}})
    assert(dict_merge({1: 2, 3: {1: 2}}, {3: {1: 3}}) == {1: 2, 3: {1: 3}})

# Generated at 2022-06-22 21:34:20.198923
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'aws_key': 'value'}) == {'AwsKey': 'value'}
    assert snake_dict_to_camel_dict({'aws_key': 'value'}, capitalize_first=True) == {'AWSKey': 'value'}
    assert snake_dict_to_camel_dict({'aws_key': {'aws_key2': 'value', 'aws_key3': 'value'}}) == {'AwsKey': {'AwsKey2': 'value', 'AwsKey3': 'value'}}

# Generated at 2022-06-22 21:34:27.300888
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a,b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }



# Generated at 2022-06-22 21:34:36.472286
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Validate class function camel_dict_to_snake_dict()"""
    camel_dict = {
        'PublicIpV4Pool': 'public_ip',
        'HTTPEndpoint': {
            'Enabled': True
        },
        'Tags': {
            'Name': 'TestTags',
            'Purpose': 'TestTagAgain'
        },
        'IsPublic': False,
        'VpcConfig': {
            'SubnetIds': [
                'subnet-89a430f0',
            ]
        }
    }

# Generated at 2022-06-22 21:34:49.205734
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.ec2

    dict1 = {
        'Name': "MyKeyPair",
        'ResourceTags': {},
        'PublicKeyMaterial': "xxxxx"
    }

    dict2 = {
        'Name': 'MyKeyPair',
        'ResourceTags': {
            'ansible': '2.4.2.0'
        }
    }
    result = recursive_diff(dict1, dict2)
    AnsibleModule.fail_json = AnsibleModule.exit_json = lambda self, data: data['changed']
    # this test case should fail because changes detected
    ec2 = ansible.module_utils.ec2.Ec2AnsibleModule(argument_spec=dict())

# Generated at 2022-06-22 21:34:55.278187
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'newkey': 'newvalue'}
    d2 = {'key1': 'value1',
          'key2': {
              'key2.1': 'value2.1',
              'key2.2': 'value2.2',
              'key2.3': {
                  'key2.3.1': 'value2.3.1',
                  'key2.3.2': 'value2.3.2',
              }
          }
    }

# Generated at 2022-06-22 21:35:06.039439
# Unit test for function dict_merge
def test_dict_merge():
    test_string = "test_string"
    test_int = 100
    test_float = 10.5
    test_dict = {'test_string': test_string, 'test_int': test_int}

    # test_dict_merge_type_1: E1 = E2
    a = {'test_string': test_string, 'test_int': test_int}
    b = {'test_string': test_string, 'test_int': test_int}
    result = dict_merge(a, b)
    expected_result = {'test_string': test_string, 'test_int': test_int}

# Generated at 2022-06-22 21:35:14.534448
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'a', 'b': 'b', '4': {'4a': '4a', '4b': '4b'}}
    b = {'a': 'aaa', 'b': 'bbb', 'c': 'ccc', '4': {'4a': '44a', '4c': '4ccc'}}
    expected = {'a': 'aaa', 'b': 'bbb', 'c': 'ccc', '4': {'4a': '44a', '4b': '4b', '4c': '4ccc'}}
    result = dict_merge(a, b)
    assert result == expected



# Generated at 2022-06-22 21:35:22.826709
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:35:32.504884
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:35:43.260527
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': {'f': {'g': 7, 'h': 8}}}
    d2 = {'a': 1, 'b': {'x': 3, 'd': 4}, 'e': {'f': {'g': 7, 'h': 9}}}
    rd = recursive_diff(d1, d2)
    assert len(rd) == 2
    assert len(rd[0]) == 2
    assert len(rd[1]) == 2
    assert rd[0]['b'] == {'c': 3}
    assert rd[1]['b'] == {'x': 3}
    assert rd[0]['e']['f']['h'] == 8

# Generated at 2022-06-22 21:35:44.961627
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(dict(foo_bar=dict(foo='a', bar='b')))['fooBar'] == dict(foo='a', bar='b')



# Generated at 2022-06-22 21:35:56.629420
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:36:05.086601
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Unit testing of recursive_diff function.
    """
    # All of the following should return None
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: 2}, {1: 2}) is None
    assert recursive_diff({1: {2: 3}}, {1: {2: 3}}) is None
    assert recursive_diff({"1": {"2": "3"}}, {"1": {"2": "3"}}) is None
    # All of the following should return a tuple
    assert recursive_diff({1: 2}, {}) == ({1: 2}, {})
    assert recursive_diff({}, {1: 2}) == ({}, {1: 2})
    assert recursive_diff({1: 2}, {3: 4}) == ({1: 2}, {3: 4})

# Generated at 2022-06-22 21:36:10.436882
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {
        'foo_bar': {'baz_quux': 1, 'quux_corge': None, 'grault': {'garply_waldo': True}},
        'corge_grault': [{'garply_waldo': True}],
        'fred_plugh': ['bar', 'baz'],
        'xyzzy_thud': [1, 2],
        'empty_list': []
    }

    dromedary_dict = snake_dict_to_camel_dict(deepcopy(snake_dict))
    camel_dict = snake_dict_to_camel_dict(deepcopy(snake_dict), capitalize_first=True)


# Generated at 2022-06-22 21:36:19.855746
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test case with no differences
    dict_one = {
        'key1': 'value1',
        'key2': 'value2'}
    dict_two = {
        'key1': 'value1',
        'key2': 'value2'}
    assert recursive_diff(dict_one, dict_two) is None

    # Test case with differences in values
    dict_one = {
        'key1': 'value1',
        'key2': 'value2'}
    dict_two = {
        'key1': 'value1',
        'key2': 'different'}
    assert recursive_diff(dict_one, dict_two) == ({'key2': 'value2'}, {'key2': 'different'})

    # Test case with differences in keys

# Generated at 2022-06-22 21:36:25.829630
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict_test = {
        'first_key': 'first_value',
        'second_key': [
            'first_value',
            'second_value'
        ],
        'third_key': {
            'first_key': 'first_value',
        }
    }
    assert (snake_dict_to_camel_dict(deepcopy(snake_dict_test), True) == {
        'FirstKey': 'first_value',
        'SecondKey': [
            'first_value',
            'second_value'
        ],
        'ThirdKey': {
            'FirstKey': 'first_value',
        }
    })


# Generated at 2022-06-22 21:36:36.395021
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'aB': {
            'cD': 1,
            'eF': [
                2,
                {
                    'gH': [
                        {
                            'iJ': 3,
                            'kL': 4
                        }
                    ]
                }
            ]
        },
        'mN': {
            'oP': 5,
            'qR': {
                'sT': 6,
                'uV': 7
            }
        },
        'wX': 'yZ'
    }

    result = camel_dict_to_snake_dict(test_dict)


# Generated at 2022-06-22 21:36:46.910891
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Interval': 10,
        'FooBar': {
            'a': 1,
            'b': 2,
            'c': 3,
        },
        'HTTPEndpoint': {
            'URL': 'https://www.example.com',
            'Timeout': 2,
        },
        'TcpEndpoint': {
            'Port': 5000,
        },
        'Tags': {
            'foo': 'bar',
        },
        'TargetGroups': [
            {'Name': 'group-1'},
            {'Name': 'group-2'},
        ],
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-22 21:36:55.688956
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'foo': 'bar', 'baz': {'foo': 'bar2'}, 'qux': {'quux': {'quuz': {'corge': 'garply'}}}}
    dict2 = {'foo': 'bar', 'baz': {'foo': 'bar2'}, 'qux': {'quux': {'quuz': {'corge': 'garply'}}}}
    dict3 = {'foo': 'baz', 'baz': {'foo': 'bar'}}  # check key order preservation
    result = recursive_diff(dict1, dict2)
    assert result is None
    result = recursive_diff(dict1, dict3)
    assert result[0] == {'foo': 'bar'}
    assert result[1] == {'foo': 'baz'}
   

# Generated at 2022-06-22 21:37:02.114003
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_success = {
        "foo": {
            "g": 1,
            "h": 2,
            "i": 3,
            "j": {
                "a": 2,
                "b": 3,
                "c": 5
            }
        },
        "bar": {
            "g": 2
        }
    }
    dict_success_left = {
        "foo": {
            "g": 1,
            "h": 2,
            "i": 3,
            "j": {
                "a": 2,
                "c": 5,
                "b": 3
            }
        },
        "bar": {
            "g": {
                "h": 2
            }
        }
    }

# Generated at 2022-06-22 21:37:11.949472
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'this': {'a': 1} }

    b = { 'this': {'b': 2} }

    c = dict_merge(a,b)
    assert(c == {'this': {'a': 1, 'b': 2}})

    d = { 'this': {'c': 3} }
    e = dict_merge(c,d)
    assert(e == {'this': {'a': 1, 'b': 2, 'c': 3}})

    f = dict_merge({'that': {'d': 4}},e)
    assert(f == {'this': {'a': 1, 'b': 2, 'c': 3}, 'that': {'d': 4}})


# Generated at 2022-06-22 21:37:21.945314
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake = {'foo_bar': 2, 'baz_qux': {'foo': [1, 2, 3], 'bar': {'f_b': 1}}}
    camel = snake_dict_to_camel_dict(snake, False)
    assert camel == {'fooBar': 2, 'bazQux': {'foo': [1, 2, 3], 'bar': {'fB': 1}}}
    camel_upper = snake_dict_to_camel_dict(snake, True)
    assert camel_upper == {'FooBar': 2, 'BazQux': {'Foo': [1, 2, 3], 'Bar': {'FB': 1}}}



# Generated at 2022-06-22 21:37:30.349072
# Unit test for function dict_merge
def test_dict_merge():
    # Some basic tests
    assert dict_merge({}, {}) == {}
    assert dict_merge({'foo': 'bar'}, {}) == {'foo': 'bar'}
    assert dict_merge({}, {'foo': 'bar'}) == {'foo': 'bar'}
    assert dict_merge({'foo': 'bar'}, {'foo': 'bar'}) == {'foo': 'bar'}

    # Tests for merging values that are dicts
    assert dict_merge({}, {'foo': {'bar': 'baz'}}) == {'foo': {'bar': 'baz'}}
    assert dict_merge({'foo': {'bar': 'baz'}}, {}) == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-22 21:37:41.278482
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'a_bc': 123}) == {'aBc': 123}
    assert snake_dict_to_camel_dict({'a_bc': [1,2,3]}) == {'aBc': [1,2,3]}
    assert snake_dict_to_camel_dict({'a_bc': {'d_ef': {'g_hi': 'j_kl'}}}) == {'aBc': {'dEf': {'gHi': 'j_kl'}}}
    assert snake_dict_to_camel_dict({'a_bc': {'d_ef': {123: 'j_kl'}}}) == {'aBc': {'dEf': {123: 'j_kl'}}}
    assert snake_dict_to_c

# Generated at 2022-06-22 21:37:47.591636
# Unit test for function dict_merge
def test_dict_merge():
    assert(dict_merge({"a": "b"}, {"c": "d"}) == {"a": "b", "c": "d"})
    assert(dict_merge({}, {"c": "d"}) == {"c": "d"})
    assert(dict_merge({"a": {"foo": "bar"}}, {"a": {"fiz": "baz"}}) == {"a": {"foo": "bar", "fiz": "baz"}})

# Generated at 2022-06-22 21:37:58.806100
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(a=1, b=2)
    dict2 = dict(c=3, d=4)
    dict3 = dict_merge(dict1, dict2)
    assert dict3 == dict(a=1, b=2, c=3, d=4)

    dict1 = dict(a=1, b=2)
    dict2 = dict(a=3, d=4)
    dict3 = dict_merge(dict1, dict2)
    assert dict3 == dict(a=3, b=2, d=4)

    dict1 = dict(a=1, b=2, c=dict(d=3, e=4))
    dict2 = dict(b=4, c=dict(d=4, f=5), g=6)

# Generated at 2022-06-22 21:38:07.475981
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'hi', 'b': '2'}
    b = {'c': 'd', 'b': {'b1': 'b1val', 'b2': 'b2val'}, 'd': 'd', 'e': {'e1': 'e1val'}}
    c = dict_merge(a, b)
    assert c == {'a': 'hi', 'b': {'b1': 'b1val', 'b2': 'b2val'}, 'c': 'd', 'd': 'd', 'e': {'e1': 'e1val'}}

# Generated at 2022-06-22 21:38:14.678380
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:38:22.076908
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'test',
         'b': {'h': 'test',
               'c': {'d': 'test',
                     'e': 'test',
                     },
               },
         'f': 'test',
         }
    b = {'a': 'test1',
         'b': {'c': {'d': 'test2',
                     'e': 'test1',
                     'g': 'test',
                     },
               'i': 'test',
               },
         'h': 'test',
         }


# Generated at 2022-06-22 21:38:29.815776
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': 1, 'b': 2}, {}) == {'a': 1, 'b': 2}
    assert dict_merge({}, {'a': 1}) == {'a': 1}
    assert dict_merge({'a': 1}, {'a': 2}) == {'a': 2}
    assert dict_merge({'a': {'b': 1}}, {'a': {'c': 2}}) == {'a': {'b': 1, 'c': 2}}
    assert dict_merge({'a': 1}, {'a': {'b': 2}}) == {'a': {'b': 2}}
    assert dict_merge({'a': {'b': 1}}, {'a': 2}) == {'a': 2}

# Generated at 2022-06-22 21:38:37.746552
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:38:46.636388
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_data    = {
                    "Key" : "Value",
                    "Key1" : "Value1",
                    "InnerDict" : {
                                    "Key2" : "Value2",
                                    "Key3" : "Value3"
                                  },
                    "SomeList" : [
                                    "Value1",
                                    ["Value2"],
                                    {"InnerKey" : "InnerValue"}
                                 ],
                    "SomeBool" : True,
                    "SomeFloat" : 1.1
                    }
    camel_dict   = deepcopy(test_data)
    snake_dict   = camel_dict_to_snake_dict(camel_dict)
    snake_dict_2 = camel_dict_to_snake_dict(deepcopy(snake_dict))
    camel_dict_2

# Generated at 2022-06-22 21:38:57.398606
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:39:09.268267
# Unit test for function recursive_diff
def test_recursive_diff():

    import unittest

    class TestRecursiveDiff(unittest.TestCase):

        def setUp(self):
            self.diff = recursive_diff

        def test_no_diff(self):
            self.assertEqual(self.diff({}, {}), None)
            self.assertEqual(self.diff({'foo': 'bar'}, {'foo': 'bar'}), None)
            self.assertEqual(self.diff({'foo': {'bar': 'baz'}}, {'foo': {'bar': 'baz'}}), None)

        def test_empty_diff(self):
            self.assertEqual(self.diff({'foo': 'bar'}, {}), ({'foo': 'bar'}, {}))

# Generated at 2022-06-22 21:39:17.265755
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:39:29.043319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        FooBar="foobar",
        FooBarBar="foobarbar",
        FooBarBaz="foobarbaz",
        HTTPEndpoint="httpendpoint",
        HTTPEndpoints="httpendpoints",
        _HTTPEndpoint="httpendpoint",
        _HTTPEndpoints="httpendpoints",
        HTTPEndpointArray=["httpendpoint", "httpendpoint"],
        HTTPEndpointDict=dict(Foo="bar"),
        HTTPEndpointsDictArray=[dict(Foo="bar"), dict(Foo="bar")],
        FooBarBazList=[1, 2, 3],
        FooBarBarList=["a", "b", "c"],
    )


# Generated at 2022-06-22 21:39:40.561135
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    initial_dictionary = camel_dict_to_snake_dict({
        "target": {
            "Target": {
                "Arn": "string",
                "Id": "string",
                "Input": "string",
                "InputPath": "string",
                "InputTransformer": {
                    "InputPathsMap": {
                        "string" : "string"
                    },
                    "InputTemplate": "string"
                },
                "RoleArn": "string",
                "RunCommandParameters": {
                    "RunCommandTargets": [
                        {
                            "Key": "string",
                            "Values": [
                                "string",
                                "string"
                            ]
                        }, "string"
                    ]
                }
            }
        }
    })


# Generated at 2022-06-22 21:39:50.786422
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1:2}, {1:2}) is None
    assert recursive_diff({1:2,3:4}, {3:4,1:2}) is None
    assert recursive_diff({1:2,3:4}, {3:5,1:2}) == ({3:4}, {3:5})
    assert recursive_diff({1:2,3:4}, {3:5,1:2,6:7}) == ({3:4}, {3:5,6:7})
    assert recursive_diff({1:2,3:4}, {3:5,1:2,6:7}) == ({3:4}, {3:5,6:7})

# Generated at 2022-06-22 21:40:00.258145
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test function to test function recursive_diff
    """
    dict1 = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f',
            'g': 'h'
        },
        'i': 'j'
    }
    dict2 = {
        'a': {
            'b': {
                'c': 'a'
            },
            'e': 'f',
            'g': 'h'
        },
        'k': 'l'
    }
    result = recursive_diff(dict1, dict2)
    if result:
        assert result[0] == {'a': {'b': {'c': 'd'}}}, \
            "recursive_diff failed to detect difference in nested keys"
        assert result[1]

# Generated at 2022-06-22 21:40:12.592224
# Unit test for function recursive_diff
def test_recursive_diff():
    import json

    # Testcase with the same type of value change
    dict1 = {'key1': 'value1',
             'key2': 'value2',
             'key3': {'subkey1': 'subvalue1',
                      'subkey2': 'subvalue2'},
             'key4': {'subkey1': 'subvalue1',
                      'subkey2': {'subsubkey1': 'subsubvalue1',
                                  'subsubkey2': 'subsubvalue2'}},
             'key5': 'value5'
            }

# Generated at 2022-06-22 21:40:22.717668
# Unit test for function recursive_diff
def test_recursive_diff():
    left1 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abc'}}}}}
    left2 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abcd'}}}}}
    left3 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abcd'}}}}}
    right1 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abcd'}}}}}
    right2 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abce'}}}}}
    right3 = {'abc': {'abc': {'abc': {'abc': {'abc': 'abcd'}}}}}

# Generated at 2022-06-22 21:40:34.637745
# Unit test for function camel_dict_to_snake_dict