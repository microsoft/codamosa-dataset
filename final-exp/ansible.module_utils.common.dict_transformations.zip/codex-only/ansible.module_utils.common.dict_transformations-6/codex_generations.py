

# Generated at 2022-06-22 21:30:36.155853
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"some_key": "some_value",
                 "dict_key": {"dict_value_key": "some_dict_value"},
                 "list_key": [{"some_list_key": "some_list_value"},
                              "some_list_string"],
                 "dict_list_key": [{"dict_list_key": "dict_list_value"},
                                   {"nested_list_key": ["nested_list_value", "nested_list_value2"]}]}

    camel_dict = snake_dict_to_camel_dict(test_dict)
    assert isinstance(camel_dict, dict)
    assert camel_dict["someKey"] == "some_value"
    assert isinstance(camel_dict["dictKey"], dict)

# Generated at 2022-06-22 21:30:40.132642
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"this_is_snake": "value", "this_is_also_snake": "other_value"}) == {"thisIsSnake": "value", "thisIsAlsoSnake": "other_value"}



# Generated at 2022-06-22 21:30:47.026389
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    result = dict_merge(a, b)

# Generated at 2022-06-22 21:30:58.183871
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test Reversible Conversion
    snake_dict = {
        'test_id': '1234',
        'test_name': 'test_name',
        'test_description': 'test_description',
        'test_dict': {
            'test_key': 'test_value'
        },
        'test_list': [
            'test_item1',
            'test_item2',
            'test_item3'
        ]
    }

# Generated at 2022-06-22 21:31:03.528706
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    in_dict = {'camel_case': 'foo', 'pascal_case': 'bar', 'UPPER_CASE': 'baz',
               'snake_case': 'qux', 'Title_Case': 'quux', 'dot.case': 'corge',
               'CONSTANT_CASE': 'grault', 'space case': 'garply', 'dromedaryCase': 'waldo'}

    out_dict = snake_dict_to_camel_dict(in_dict)

    assert out_dict['camelCase'] == 'foo'
    assert out_dict['pascalCase'] == 'bar'
    assert out_dict['upperCase'] == 'baz'
    assert out_dict['snakeCase'] == 'qux'
    assert out_dict['titleCase'] == 'quux'

# Generated at 2022-06-22 21:31:11.603734
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'key1': {
            'registry_id': 'foo',
            'repository_name': 'bar',
            'image_digest': 'digest',
            'image_tags': [
                'tag1',
                'tag2'
            ],
            'image_id': "sha256:123"
        },
        'key2': [
            'value1',
            'value2'
        ]
    }

# Generated at 2022-06-22 21:31:20.903631
# Unit test for function dict_merge
def test_dict_merge():
    base = dict(
        a=dict(
            b=1,
            c=3,
        ),
        d=dict(
            e=5,
            f=6,
        ),
    )
    delta = dict(
        a=dict(
            b=2,
            c=4,
        ),
        g=7,
    )
    expected = dict(
        a=dict(
            b=2,
            c=4,
        ),
        d=dict(
            e=5,
            f=6,
        ),
        g=7,
    )
    assert dict_merge(base, delta) == expected

# Generated at 2022-06-22 21:31:24.541062
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': {'bar': 1}}
    b = {'foo': {'baz': 2}}
    c = dict_merge(a, b)
    assert c == {'foo': {'bar': 1, 'baz': 2}}



# Generated at 2022-06-22 21:31:33.552050
# Unit test for function recursive_diff
def test_recursive_diff():
    class DummyModule:
        pass
    test_module = DummyModule()

    # Test 1: Empty dict1, Empty dict2
    dict1 = {}
    dict2 = {}
    test_module.assertEqual(recursive_diff(dict1, dict2), None)

    # Test 2: Empty dict1, Non-empty dict2
    dict1 = {}
    dict2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    test_module.assertEqual(recursive_diff(dict1, dict2), ({}, dict2))

    # Test 3: Non-empty dict1, Empty dict2
    dict1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    dict2 = {}

# Generated at 2022-06-22 21:31:43.355611
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils import six
    import json

    try:
        import yaml
    except ImportError:
        yaml = None

    # load test data
    with open('/dev/null') as file:
        test_data = yaml.safe_load(file) if yaml else json.load(file)

    # run tests
    for test_name, data in test_data.items():
        result = dict_merge(data['input'][0], data['input'][1])
        if six.PY3:
            assert result == data['output']
        else:
            assert result == data['output'], 'Test %s failed' % test_name

# Generated at 2022-06-22 21:31:54.135252
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """ Unit tests for snake_dict_to_camel_dict """
    snake_dict = {
        'key1': 'value1',
        'full_featured_key': {
            'child_key1': 'child_value1',
            'child_key2': 'child_value2'
        },
        'list_key': [
            {
                'nested_list_key1': 'nested_list_value1',
                'nested_list_key2': 'nested_list_value2'
            },
            {
                'nested_list_key1': 'nested_list_value1',
                'nested_list_key2': 'nested_list_value2'
            },
        ]
    }
    dromedary_dict = snake_dict_to_camel_

# Generated at 2022-06-22 21:32:03.378228
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'second' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    d = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat' } } }
    assert dict_merge(a,b) == d

# Generated at 2022-06-22 21:32:14.072655
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointType': 'READER',
            'Scope': 'ALL',
            'URL': 'http://localhost:8080'
        },
        'Enabled': True,
        'TargetGroupARNs': [{'FooBar': 'BarFoo'}],
        'Tags': {'FooBar': 'BarFoo'}
    }


# Generated at 2022-06-22 21:32:17.620094
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'hello_world': 'something'}
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {'HelloWorld': 'something'}

# Generated at 2022-06-22 21:32:29.293080
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Create a camel case dict
    camel_dict = {'billingMode': 'PAY_PER_REQUEST',
                  'capacity': {'readCapacityUnits': 5, 'writeCapacityUnits': 5}}

    # Convert it to snake case
    snake_dict = snake_dict_to_camel_dict(camel_dict)

    # Confirm snake case keys
    assert set(snake_dict.keys()) == {'billing_mode', 'capacity'}
    assert set(snake_dict['capacity'].keys()) == {'read_capacity_units', 'write_capacity_units'}

    # Confirm values
    assert snake_dict['billing_mode'] == 'PAY_PER_REQUEST'
    assert snake_dict['capacity']['read_capacity_units'] == 5
    assert snake_dict

# Generated at 2022-06-22 21:32:38.363981
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 0, 'b': 1, 'c': {'a': 0, 'b': {'a': 0, 'b': 1}, 'c': 3}}
    b = {'a': 1, 'c': {'b': {'c': 2, 'd': 5}, 'c': 4, 'd': 6}}
    c = {'a': 1, 'b': 1, 'c': {'a': 0, 'b': {'a': 0, 'b': 1, 'c': 2, 'd': 5}, 'c': 4, 'd': 6}}

    assert dict_merge(a, b) == c


# Unit tests for functions _camel_to_snake and _snake_to_camel
# These are *not* tests of the "public" interface which is just
# camel_dict_

# Generated at 2022-06-22 21:32:49.014737
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:32:56.140709
# Unit test for function dict_merge
def test_dict_merge():
    # Tests for simple merging of one key
    assert dict_merge({"key": "val"}, {"key": "override"}) == {"key": "override"}

    # Tests for simple merging of one key
    assert dict_merge({"key": "val"}, {"key": "override"}) == {"key": "override"}

    # Tests for simple merging of none-existing keys
    assert dict_merge({"key": "val"}, {"key2": "override"}) == {"key": "val", "key2": "override"}

    # Tests for overriding key with a dictionary
    assert dict_merge({"key": "val"}, {"key": {"key2": "override"}}) == {"key": {"key2": "override"}}

    # Tests for overriding key with a dictionary, where the key is not defined in the first

# Generated at 2022-06-22 21:33:06.434442
# Unit test for function dict_merge
def test_dict_merge():
    # Initialize
    a = {'key1': 'value1', 'key2': 'value2'}
    b = {'key2': 'value2.2', 'key3': 'value3'}
    expected = {'key1': 'value1', 'key2': 'value2.2', 'key3': 'value3'}

    # Run and check
    if dict_merge(a, b) == expected:
        print("Test #1: Success, the expected output is '%s'" % expected)
    else:
        print("Test #1: Failed, the expected output is '%s', got '%s' instead" % (expected, dict_merge(a, b)))

    # Initialize
    a = {'a': {'b': {'c': 1}}}

# Generated at 2022-06-22 21:33:15.482642
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPEndpoint": "endpoint", "BasePathMappingId": "mapping_id"}
    output = camel_dict_to_snake_dict(camel_dict, True)
    assert output['h_t_t_p_endpoint'] == 'endpoint'
    assert output['base_path_mapping_id'] == 'mapping_id'
    output = camel_dict_to_snake_dict(camel_dict, False)
    assert output['http_endpoint'] == 'endpoint'
    assert output['base_path_mapping_id'] == 'mapping_id'



# Generated at 2022-06-22 21:33:25.121072
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(None, {'foo': 'bar'}) == {'foo': 'bar'}
    assert dict_merge({'foo': 'bar'}, {'foo': 'baz'}) == {'foo': 'baz'}
    assert dict_merge({'foo': 'bar'}, {'foo': {'baz': 'baz'}}) == {'foo': {'baz': 'baz'}}
    assert dict_merge({'foo': {'bar': 'bar'}}, {'foo': {'baz': 'baz'}}) == {'foo': {'bar': 'bar', 'baz': 'baz'}}

# Generated at 2022-06-22 21:33:31.331847
# Unit test for function dict_merge
def test_dict_merge():

    # Creating dict
    dict1 = {
        'apple': {
            'red': 2,
            'green': 1
        },
        'banana': 6,
        'cherry': 3
    }
    dict2 = {
        'banana': 4,
        'cherry': {
            ' Pie': {
                'sweet': 3,
                'sour': 1
            }
        },
        'orange': 5
    }

    # Merging dict
    dict3 = dict_merge(dict1, dict2)
    assert dict3 == {'apple': {'red': 2, 'green': 1}, 'cherry': {' Pie': {'sweet': 3, 'sour': 1}}, 'banana': 4, 'orange': 5}


# Generated at 2022-06-22 21:33:36.834322
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Test recursive_diff
    """
    import pytest

    with pytest.raises(TypeError):
        recursive_diff('', '')

    with pytest.raises(TypeError):
        recursive_diff('', {})

    with pytest.raises(TypeError):
        recursive_diff({}, '')

    # Test when there are no differences
    assert recursive_diff({}, {}) is None

    # Test when only the first dictionary is empty
    assert recursive_diff({}, {'key1': 'value1'}) == ({}, {'key1': 'value1'})

    # Test when only the second dictionary is empty
    assert recursive_diff({'key1': 'value1'}, {}) == ({'key1': 'value1'}, {})

    # Test when only the first dictionary is none
    assert recursive

# Generated at 2022-06-22 21:33:48.556180
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible_collections.amazon.aws.plugins.module_utils.core import recursive_diff

    d1 = {'a':'1', 'b':2, 'c':{'c1':'v1', 'c2': 'v2'}}
    d2 = {'a':'1', 'b':2, 'c':{'c1':'v1', 'c2': 'v2'}}
    assert(recursive_diff(d1,d2) == None)

    d1 = {'a':{'a1':'1', 'a2':2}, 'b':2, 'c':{'c1':'v1', 'c2': 'v2'}}

# Generated at 2022-06-22 21:34:00.208017
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    dict_to_convert = {
        'aws': {
            'foo_bar': 'baz',
            'baz_boo': [
                {'zip': 'a_b'},
                {'zip': 'c_d'},
            ],
        },
        'azure': {
            'foo_bar': 'baz',
            'baz_boo': [
                {'zip': 'a_b'},
                {'zip': 'c_d'},
            ],
        },
    }


# Generated at 2022-06-22 21:34:03.908456
# Unit test for function dict_merge
def test_dict_merge():
    """Test for the dict_merge method
    """
    a = {'first': 1, 'second': 2, 'third': {'inner': 3}}
    b = {'first': 'one', 'second': 'two', 'fourth': {'inner': 'four'}}
    assert dict_merge(a, b) == {'first': 'one', 'second': 'two', 'third': {'inner': 3}, 'fourth': {'inner': 'four'}}



# Generated at 2022-06-22 21:34:11.584365
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_snake_dict_correct_conversion = {
        'key_1': 'value_1',
        'key_2': 'value_2',
        'key_3': {
            'key_4': 'value_4',
            'key_5': 'value_5',
            },
        'key_6': [
            'value_6_0',
            'value_6_1',
            ],
        }

# Generated at 2022-06-22 21:34:20.645573
# Unit test for function dict_merge
def test_dict_merge():
    # empty dict merge test
    assert dict_merge({}, {}) == {}

    # simple merge test
    a = {"a": "1"}
    b = {"b": "2"}
    assert dict_merge(a, b) == {"a": "1", "b": "2"}

    # simple merge test reversed
    a = {"b": "2"}
    b = {"a": "1"}
    assert dict_merge(a, b) == {"a": "1", "b": "2"}

    # simple merge test with overwrite
    a = {"a": "1"}
    b = {"a": "2"}
    assert dict_merge(a, b) == {"a": "2"}

    # simple merge test with overwrite reversed
    a = {"a": "2"}
    b = {"a": "1"}


# Generated at 2022-06-22 21:34:29.733685
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test cases from https://github.com/ansible-community/collection_compare/blob/79bbd8a3b16f095c569ccd5d5c52577f012766e6/test.py#L12
    a = {'a': 'a', 'b': {'a': 'a', 'b': 'b'}, 'c': ['c']}
    b = {'a': 'a', 'b': {'a': 'a', 'b': 'b'}, 'c': ['c']}
    assert recursive_diff(a, b) is None

    b = {'a': 'b', 'b': {'a': 'a', 'b': 'b'}, 'c': ['c']}
    result = recursive_diff(a, b)

# Generated at 2022-06-22 21:34:40.927760
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test unchanged
    assert(recursive_diff({'a': 1}, {'a': 1}) == None)
    # Test change
    assert(recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2}))
    # Test addition
    assert(recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == (None, {'b': 2}))
    # Test deletion
    assert(recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, None))
    # Test nested dict

# Generated at 2022-06-22 21:34:48.512965
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'oneCamel': 'Hello World!',
        'twoCamels': {
            'threeCamels': 'Hello World!'
        },
        'HTTPEndpoint': 'Hello World!'
    }

    snake_dict = {
        'one_camel': 'Hello World!',
        'two_camels': {
            'three_camels': 'Hello World!'
        },
        'h_t_t_p_endpoint': 'Hello World!'
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-22 21:34:57.834850
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'client_token': 'foobar',
        'filters': [{
            'name': 'cpu_utilization',
            'values': ['0']
        }],
        'tag': 'tag',
        'test_parameter' : 'test_value'
    }

    camel_dict = {
        'ClientToken': 'foobar',
        'Filters': [{
            'Name': 'cpu_utilization',
            'Values': ['0']
        }],
        'Tag': 'tag',
        'TestParameter': 'test_value'
    }

    assert snake_dict_to_camel_dict(snake_dict) == camel_dict

# Generated at 2022-06-22 21:35:05.790300
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'foo': 1}, {'foo': 2}) == ({'foo': 1}, {'foo': 2})
    assert recursive_diff({'foo': 1}, {'bar': 2}) == ({'foo': 1}, {'bar': 2})
    assert recursive_diff({'foo': {'bar': 1}}, {'foo': {'bar': 2}}) == ({'foo': {'bar': 1}}, {'foo': {'bar': 2}})
    assert recursive_diff({'foo': {'bar': 1}}, {'foo': {'bar': 1}}) == None

# Generated at 2022-06-22 21:35:15.403806
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert(snake_dict_to_camel_dict({'a_b_cdef': 1}) == {'aBCdef': 1})
    assert(snake_dict_to_camel_dict({'a_b_cdef': 1}, capitalize_first=True) == {'ABCdef': 1})
    assert(snake_dict_to_camel_dict({'a_b_c_d_efgh': {'i_j_klmnop': 2}}) == {'aBCDEfgh': {'iJKLmnop': 2}})

# Generated at 2022-06-22 21:35:25.377381
# Unit test for function dict_merge
def test_dict_merge():
    def test_dict_merge_helper(a, b, expected):
        r = dict_merge(a, b)
        assert(r == expected)
        r = dict_merge(b, a)
        assert(r == expected)


# Generated at 2022-06-22 21:35:34.336653
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        "ThisIsCamelCase": {
            "Tags": {
                "Tag": [
                    {
                        "TagKey": "tag_key",
                        "TagValue": "tag_value"
                    }
                ]
            }
        },
        "AndThisIsNot": "foo",
        "HereAreSomeTags": {
            "Tags": {
                "Tag": [
                    {
                        "TagKey": "tag_key",
                        "TagValue": "tag_value"
                    }
                ]
            }
        }
    }


# Generated at 2022-06-22 21:35:45.794110
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {u'fooBar': u'foobar',
                  u'fooBarBaz': {u'fooKey': u'fooval'},
                  u'fooBarBazList': [{u'fooKey': u'fooval'},
                                     {u'fooKey': u'fooval'},
                                     {u'fooKey': u'fooval'}],
                  u'foo_bar': u'foolbar',
                  u'foo_bar_baz': {u'foo_key': u'fooval'},
                  u'foo_bar_baz_list': [{u'fooKey': u'fooval'},
                                        {u'fooKey': u'fooval'},
                                        {u'fooKey': u'fooval'}]}
    # Using default reversible=False
    snake_dict

# Generated at 2022-06-22 21:35:56.664865
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:05.085956
# Unit test for function recursive_diff
def test_recursive_diff():
    a_dict = {
        'name': 'foo',
        'type': 'type_foo',
        'extra': {
            'extra_name': 'extra_foo',
            'extra_type': 'extra_type_foo',
            'extra_extra': {
                'extra_extra_name': 'extra_extra_foo',
                'extra_extra_type': 'extra_extra_type_foo',
            }
        }
    }


# Generated at 2022-06-22 21:36:15.187453
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:23.040711
# Unit test for function dict_merge
def test_dict_merge():
    # Basic merge test
    a = dict(a=1, b=2)
    b = dict(c=3, d=4)
    c = dict_merge(a, b)
    assert c == dict(a=1, b=2, c=3, d=4)

    # Overriding value test
    d = dict_merge(a, dict(b=4, c=3))
    assert d == dict(a=1, b=4, c=3)

    # Nested dict test
    e = dict(a=1, b=dict(c=1, d=3))
    f = dict(a=2, b=dict(d=4, e=5))
    g = dict_merge(e, f)

# Generated at 2022-06-22 21:36:33.598238
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "PublicIpv4Pool": "amazon",
        "HTTPEndpoints": [
            {
                "HTTPEndpointDescription": "string",
                "HTTPStatusCode": "string",
                "HTTPMethod": "string",
                "HTTPPath": "string",
                "VpcLinkId": "string"
            },
        ],
    }

# Generated at 2022-06-22 21:36:44.098222
# Unit test for function recursive_diff
def test_recursive_diff():
    def _test_recursive_diff(a, b, expected):
        result = recursive_diff(a, b)
        if result and result == expected:
            return True
        else:
            return False

    # Test 1
    d1 = {'a': 2, 'b': 3, 'c': 4}
    d2 = {'a': 1, 'b': 3, 'c': 4}
    expected = ({'a': 2}, {'a': 1})
    assert _test_recursive_diff(d1, d2, expected) is True

    # Test 2
    d1 = {'a': 2, 'b': 3, 'c': 4}
    d2 = {'a': 1, 'b': 3, 'c': 4}
    expected = ({'a': 2}, {'a': 1})

# Generated at 2022-06-22 21:36:48.027789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test 1
    camel_dict = {"a" : 1, "b_c" : 2, "d" : {"e" : 3, "f" : 4, "g" : {"h" : 5, "i" : 6, "j" : 7}}, "k" : 8, "l" : {"m" : 9, "n" : {"o" : 10, "p" : 11, "q" : {"r" : 12, "s" : 13}}, "t" : 14}}

# Generated at 2022-06-22 21:36:56.524234
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'Name': 'Foo', 'Value': None, 'Tags': {'Key': 'Value'}}
    dict2 = {'Name': 'Foo', 'Value': 20, 'Tags': {'Key': 'Value'}}
    dict3 = {'Name': 'Bar', 'Value': 20, 'Tags': {'Key': 'Value'}}
    dict4 = {'Name': 'Foo', 'Value': 20, 'Tags': {'Key': 'Value2'}}
    assert recursive_diff(dict1, dict2) == ({'Value': None}, {'Value': 20})

# Generated at 2022-06-22 21:37:03.025135
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': 'bar'}
    b = {'bang': 'whiz'}
    merged = dict_merge(a, b)
    print(merged)  # prints {'bang': 'whiz', 'foo': 'bar'}

    a = {"foo": {"baz": "bar"}}
    b = {"foo": {"bang": "whiz"}}
    merged = dict_merge(a, b)
    print(merged)  # prints {'foo': {'bang': 'whiz', 'baz': 'bar'}}

    a = {"foo": {"baz": "bar"}}
    b = {"foo": {"baz": "whiz", "bang": "whiz"}}
    merged = dict_merge(a, b)
    print(merged)  # prints {'foo

# Generated at 2022-06-22 21:37:11.820000
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'ip': '192.168.1.1',
             'name': 'example.com',
             'data': {'x': 1, 'y': 2},
             'data2': {'x': 1, 'y': 2},
             'data3': {'x': 3, 'y': 4}}
    dict2 = {'ip': '192.168.1.1',
             'name': 'example.com',
             'data': {'x': 1, 'y': 3},
             'data2': {'x': 1, 'y': 2},
             'data3': {'x': 3, 'y': 4},
             'data4': {'x': 5, 'y': 6}}
    rec_diff = recursive_diff(dict1, dict2)

# Generated at 2022-06-22 21:37:23.058428
# Unit test for function recursive_diff
def test_recursive_diff():
    # Initialization for test
    test_dict1 = {'v1': 'val1', 'v2': {'v2a': 'val2a', 'v2b': 'val2b'}}
    test_dict2 = {'v2': {'v2a': 'val2a', 'v2b': 'val2b'}, 'v1': 'val1'}
    test_dict3 = {'v1': 'val1', 'v2': {'v2b': 'val2b', 'v2a': 'val2a'}}
    test_dict4 = {'v1': 'val1', 'v2': {'v2a': 'val2a'}}

# Generated at 2022-06-22 21:37:31.145543
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': {'key11': {'key111': 'value111',
                                'key112': 'value112',
                                'key113': 'value113'},
                      'key12': 'value12',
                      'key13': 'value13'},
             'key2': {'key21': ['value211', 'value212', 'value213'],
                      'key22': 'value22',
                      'key23': {'key231': 'value231',
                                'key232': 'value232'}}
             }


# Generated at 2022-06-22 21:37:38.037810
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {'foo': {'bar': {'baz': []}}, 'awesome_sauce': 'yeehaw'} == camel_dict_to_snake_dict({'Foo': {'Bar': {'Baz': []}}, 'AwesomeSauce': 'yeehaw'}, reversible=False)
    assert {'foo': {'bar': {'baz': []}}, 'awesome_sauce': 'yeehaw'} == camel_dict_to_snake_dict({'Foo': {'Bar': {'Baz': []}}, 'AwesomeSauce': 'yeehaw'}, reversible=True)

# Generated at 2022-06-22 21:37:49.513502
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'name': 'the_name'}) == {'name': 'theName'}
    assert snake_dict_to_camel_dict({'name': 'the_name'}, capitalize_first=True) == {'name': 'TheName'}

    assert snake_dict_to_camel_dict({
        'the_list': [{'name': 'theName'}, {'list_2': [{'name': 'theName'}]}]
    }) == {
        'theList': [{'name': 'theName'}, {'list_2': [{'name': 'theName'}]}]
    }


# Generated at 2022-06-22 21:38:00.184680
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    d = {
            'snake_case': 'value',
            'snake_case_bis': 'value',
            'snake_case_list': ['value'],
            'snake_case_list_bis': ['value'],
            'snake_case_dict': {
                'snake_case': 'value'
            }
        }

    camelized = snake_dict_to_camel_dict(d)

    assert camelized['snakeCase'] == 'value'
    assert camelized['snakeCaseBis'] == 'value'
    assert camelized['snakeCaseList'][0] == 'value'
    assert camelized['snakeCaseListBis'][0] == 'value'
    assert camelized['snakeCaseDict']['snakeCase'] == 'value'


# Unit test

# Generated at 2022-06-22 21:38:12.368633
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for camel_dict_to_snake_dict
    """


# Generated at 2022-06-22 21:38:24.082580
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'SubResource': {
            'TargetGroupARNs': [
                'string',
            ],
        },
        'HTTPEndpoint': {
            'URL': 'string',
            'Protocol': 'string',
            'Method': 'string',
            'Authorization': {
                'CredentialsParameter': 'string',
            },
            'TimeoutInMillis': 123,
        },
    }

    snake_dict = camel_dict_to_snake_dict(test_dict)

    assert snake_dict['sub_resource']['target_group_ar_ns'][0] == 'string'
    assert snake_dict['http_endpoint']['url'] == 'string'
    assert snake_dict['http_endpoint']['protocol'] == 'string'
    assert snake_dict

# Generated at 2022-06-22 21:38:30.549822
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'one_two_three': 1, 'four_five_six': 2,
                                     'seven_eight': {'nine_ten': 3}}) == \
        {'oneTwoThree': 1, 'fourFiveSix': 2, 'sevenEight': {'nineTen': 3}}

    assert snake_dict_to_camel_dict({'one_two_three': 1, 'four_five_six': 2,
                                     'seven_eight': {'nine_ten': 3}}, True) == \
        {'OneTwoThree': 1, 'FourFiveSix': 2, 'SevenEight': {'NineTen': 3}}



# Generated at 2022-06-22 21:38:38.167217
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:38:46.882505
# Unit test for function recursive_diff
def test_recursive_diff():
    print('Running function recursive_diff')

# Generated at 2022-06-22 21:38:57.398450
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test CamelCase
    camel_dictionary_1 = {'CamelCase': {'Foo': 'Bar'}}
    snake_dictionary_1 = {'camel_case': {'foo': 'Bar'}}
    assert camel_dict_to_snake_dict(camel_dictionary_1) == snake_dictionary_1

    # Test camelCase
    camel_dictionary_2 = {'camelCase': {'Foo': 'Bar'}}
    snake_dictionary_2 = {'camel_case': {'foo': 'Bar'}}
    assert camel_dict_to_snake_dict(camel_dictionary_2) == snake_dictionary_2

    # Test CamelCase with list in dictionary

# Generated at 2022-06-22 21:39:09.218211
# Unit test for function recursive_diff
def test_recursive_diff():
    """Tests for function recursive_diff"""
    # Note: Not using assertDictEqual because of unicode differences.
    expected = ({}, {'x': 2, 'y': 4})
    result = recursive_diff({'x': 1, 'y': 2}, {'x': 2, 'y': 4})
    assert result == expected, \
        "Expected %s. Got %s" % (expected, result)

    expected = ({'a': {'c': 1, 'd': 2}}, {'a': {'d': 3}, 'b': {}}, None)

# Generated at 2022-06-22 21:39:20.223845
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict = {'name': 'test_ecs_service', 'cluster': 'default', 'task_definition': 'nginx:1', 'desired_count': 3,
            'started_by': 'test_ecs_service', 'state': 'present',
            'placement_constraints': [{'type': 'distinctInstance', 'expression': 'attribute:ecs.availability-zone'},
                                      {'type': 'memberOf', 'expression': 'attribute:ecs.availability-zone in [us-west-2a,us-west-2b,us-west-2c]'}],
            'aws_access_key': 'AWS_ACCESS_KEY', 'aws_secret_key': 'AWS_SECRET_KEY', 'region': 'us-west-2'}

    assert snake_dict_to_c

# Generated at 2022-06-22 21:39:31.762995
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:42.872550
# Unit test for function recursive_diff
def test_recursive_diff():
    import json

    # Diff between two same dictionaries
    assert recursive_diff({"key": "value"}, {"key": "value"}) is None

    # Diff between two different dictionaries
    assert recursive_diff({"key1": "value1"}, {"key1": "value2"}) == ({'key1': 'value1'}, {'key1': 'value2'})

    # Diff a dictionary with a list
    assert recursive_diff({"key": "value"}, {"key": ["value"]}) == ({'key': 'value'}, {'key': ['value']})

    # Diff a dictionary with another dictionary
    assert recursive_diff({"key": "value"}, {"key": {"key1": "value1"}}) == ({'key': 'value'}, {'key': {'key1': 'value1'}})

    # Diff a dictionary

# Generated at 2022-06-22 21:39:53.054271
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:40:02.839021
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test generic examples
    camel_dict = {'KeyName': '', 'HTTPServer': {'HTTPPort': 80, 'SSLCertificateId': ''}, 'Tags': [{'Key': '', 'Value': ''}], 'InstanceId': ''}
    snake_dict = {'key_name': '', 'h_t_t_p_server': {'h_t_t_p_port': 80, 's_s_l_certificate_id': ''}, 'tags': [{'Key': '', 'Value': ''}], 'instance_id': ''}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # Test example with ignore_list

# Generated at 2022-06-22 21:40:09.859101
# Unit test for function dict_merge
def test_dict_merge():
    print("Testing dict_merge function")
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    print(dict_merge(a, b))


if __name__ == '__main__':
    test_dict_merge()

# Generated at 2022-06-22 21:40:20.116661
# Unit test for function dict_merge
def test_dict_merge():
    a = {"a": 1, "b": 2}
    b = {"c": 3, "d": 4}
    c = {"a": 1, "b": 2, "c": 3, "d": 4}
    assert c == dict_merge(a,b)

    a = {"a": 1, "b": {"a": 3, "b": 4}}
    b = {"a": 5, "b": {"a": 5, "c": 6}}
    c = {"a": 5, "b": {"a": 5, "b": 4, "c": 6}}
    assert c == dict_merge(a,b)

    a = {"a": {"a": 1}, "b": {"b": 2}}
    b = {"a": {"b": 3}, "b": {"c": 4}}

# Generated at 2022-06-22 21:40:32.004444
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test for case that there are no differences between left and right
    # parameters
    assert recursive_diff({}, {}) == None
    assert recursive_diff({'a': 1}, {'a': 1}) == None
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 1}}) == None

    # Test for case that there is a difference in a top level key
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})

    # Test for case that there is a difference in a sub-