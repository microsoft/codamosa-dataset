

# Generated at 2022-06-22 21:30:38.866542
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "a_b": {
            "c_d": 3,
            "e_f":{
                "g_h": "foo"
            },
            "l_m": [
                1,
                2,
                {
                    "p_r": "x"
                }
            ]
        },
        "y_z": 9,
        "plural_tag": [ # plural_tag will be lower-cased
            {
                "Key": "foo", # Key will not be converted
                "Value": "bar" # Value will not be converted
            }
        ]
    }


# Generated at 2022-06-22 21:30:48.630612
# Unit test for function recursive_diff
def test_recursive_diff():
    def _check_dicts(first, second, expected):
        result = recursive_diff(first, second)
        print(result)
        assert result == expected

    _check_dicts(
        first={
            'Key': 'Value',
            'Key2': {
                'Key': 'Same'
            }
        },
        second={
            'Key': 'Value',
            'Key2': {
                'Key': 'Same'
            }
        },
        expected=None
    )


# Generated at 2022-06-22 21:30:58.774579
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_casedict = {'TestOne': 'testone', 'TestTwo': 'testtwo',
                     'TestThree': [{'TestFour': 'testfour',
                                    'TestFive': 'testfive'}],
                     'Tags': {'TestSix': 'testsix', 'TestSeven': 'testseven'}}

    expected = {'test_one': 'testone', 'test_two': 'testtwo', 'test_three': [{'test_four': 'testfour', 'test_five': 'testfive'}], 'Tags': {'TestSix': 'testsix', 'TestSeven': 'testseven'}}

    assert camel_dict_to_snake_dict(test_casedict) == expected



# Generated at 2022-06-22 21:31:10.307905
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    >>> test_recursive_diff()
    """
    # Two empty dictionaries
    print(recursive_diff({}, {}))
    # Two identical dictionaries
    print(recursive_diff({'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3}))
    # Two dictionaries with identical keys, but different values
    print(recursive_diff({'a': 1, 'b': 2, 'c': 3}, {'a': 4, 'b': 5, 'c': 6}))
    # Two dictionaries with identical keys and identical nested dictionaries

# Generated at 2022-06-22 21:31:13.389130
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': {'b': 'c', 'd': 'e'}}, {'a': {'b': 'f'}}) == {'a': {'b': 'f', 'd': 'e'}}

# Generated at 2022-06-22 21:31:24.411760
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': 'bar', 'a': {'a': 'a', 'c': 'c'}}
    b = {'foo': 'baz', 'b': 'b'}
    assert dict_merge(a, b) == {'foo': 'baz', 'b': 'b', 'a': {'a': 'a', 'c': 'c'}}
    assert dict_merge(b, a) == {'foo': 'bar', 'a': {'a': 'a', 'c': 'c'}, 'b': 'b'}

    # Tests for handling of overriding values
    c = {'foo': 'new'}
    assert dict_merge(c, b) == {'foo': 'new', 'b': 'b'}

# Generated at 2022-06-22 21:31:36.321420
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:31:43.813277
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({"a": "b"}, {"c": "d"}) == {"a": "b", "c": "d"}
    assert dict_merge({"a": {"b": "c"}}, {"a": {"b": "d"}}) == {"a": {"b": "d"}}
    assert dict_merge({"a": "b", "c": "d"}, {"a": {"b": "c"}}) == {"a": {"b": "c"}, "c": "d"}



# Generated at 2022-06-22 21:31:54.660696
# Unit test for function dict_merge
def test_dict_merge():
    test_0 = {'a': {'b': {'c': 1, 'd': 2}}}
    test_1 = {'a': {'b': {'x': 3}}}
    test_2 = {'a': {'b': {'c': 1, 'd': 2, 'x': 3}}}
    assert test_2 == dict_merge(test_0, test_1)

    test_0 = {'a': {'b': {'c': 1, 'd': 2}}}
    test_1 = {'a': {'b': {'x': 3}}}
    test_2 = {'a': {'b': {'c': 1, 'd': 2, 'x': 3}}}
    assert test_2 == dict_merge(test_0, test_1)


# Generated at 2022-06-22 21:32:03.729330
# Unit test for function recursive_diff
def test_recursive_diff():
    """Tests the function recursive_dict, using the following cases:
      case 1: return None if there is no difference between the 2 dictionaries
      case 2: if left and right are different, return left and right
      case 3: if left and right are the same and if they are dictionaries,
              return left and right which are empty dictionaries
    """
    dict1 = dict([('key1', dict([('subkey1', 'value1'), ('subkey2', 'value2')])),
                  ('key2', 'value3'), ('key3', 'value4')])
    dict2 = dict([('key1', dict([('subkey1', 'value1'), ('subkey2', 'value2')])),
                  ('key2', 'value5'), ('key3', 'value4')])

# Generated at 2022-06-22 21:32:10.345587
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    CamelDict = dict(
        CamelCase=dict(
            CamelCase=dict(
                CamelCase="Value"
            )
        )
    )
    SnakeDict = dict(
        camel_case=dict(
            camel_case=dict(
                camel_case="Value"
            )
        )
    )
    assert SnakeDict == camel_dict_to_snake_dict(CamelDict)



# Generated at 2022-06-22 21:32:17.283228
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Foo': {
            'bar': {
                'baz': 'value'
            }
        },
        'Arn': 'arn_value',
        'Tags': {
            'tag_key_1': 'tag_value_1',
            'tag_key_2': 'tag_value_2',
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-22 21:32:28.318207
# Unit test for function dict_merge
def test_dict_merge():
    as_expected = True
    test1 = {'a': 1}
    test2 = {'a': {'b': 1}}
    test3 = {'a': {'b': 2}}
    res1 = dict_merge(test1, test2)
    res2 = dict_merge(test2, test3)
    res3 = dict_merge(test2, test2)

    if res1['a'] != test2['a']:
        as_expected = False
    if res2['a'] != {'b': 2}:
        as_expected = False
    if res3['a'] != test2['a']:
        as_expected = False

    print("Test dict_merge(): " + ("OK" if as_expected else "FAILED"))

# Generated at 2022-06-22 21:32:33.534894
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': {'bar': {'baz': 1}}}
    b = {'foo': {'bar': {'baz': 2, 'qux': 3}}}

    merged = {'foo': {'bar': {'baz': 2, 'qux': 3}}}
    assert merged == dict_merge(a, b)
    assert merged == dict_merge(b, a)



# Generated at 2022-06-22 21:32:41.062938
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        "a": "a_1",
        "b": "b_1",
        "c": {
            "c_a": "c_a_1",
            "c_b": "c_b_1"
        }
    }

    d2 = {
        "a": "a_2",
        "c": {
            "c_a": "c_a_2"
        },
        "e": "e_2"
    }

    d3 = {
        "a": "a_1",
        "b": "b_1",
        "c": {
            "c_a": "c_a_2",
            "c_b": "c_b_1"
        },
        "e": "e_2"
    }

    assert dict_mer

# Generated at 2022-06-22 21:32:44.777412
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
  camel_dict = {'thisIsAKey': 'foo'}
  assert camel_dict_to_snake_dict(camel_dict) == {'this_is_a_key': 'foo'}


# Generated at 2022-06-22 21:32:53.674399
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test sub-dict keys that are different
    dict1 = {'key1': 'value1', 'key2': {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}}
    dict2 = {'key1': 'value1', 'key2': {'subkey1': 'subvalue2', 'subkey2': 'subvalue2'}}
    result = recursive_diff(dict1, dict2)
    assert result[0]['key2']['subkey1'] == 'subvalue1'
    assert result[1]['key2']['subkey1'] == 'subvalue2'
    assert result[0]['key2'].get('subkey2') is None


# Generated at 2022-06-22 21:33:04.614183
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.cloudformation import CloudFormationTemplate
    ami_id = 'ami-xxxxxxxx'
    ami_named_id = {'Fn::FindInMap': ['AWSRegionArch2AMI', {'Ref': 'AWS::Region'}, {'Fn::FindInMap': ['AWSInstanceType2Arch', {'Ref': 'InstanceType'}, 'Arch']}]}

# Generated at 2022-06-22 21:33:15.627934
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    '''
    unit test for snake_dict_to_camel_dict
    '''
    test_dict = {}
    test_dict.update({
        "hello": "world",
        "the_answer": 42,
        "foo-bar": "baz",
        "a": {
            "nested": "dict",
            "with_underscores": True
        },
        "list": [
            {
                "nested": "dict",
                "with_underscores": True
            }
        ]
    })
    new_dict = snake_dict_to_camel_dict(test_dict)
    assert new_dict['hello'] == 'world'
    assert new_dict['theAnswer'] == 42
    assert new_dict['fooBar'] == 'baz'

# Generated at 2022-06-22 21:33:25.266777
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:33:31.557313
# Unit test for function recursive_diff
def test_recursive_diff():
    a = { "key1": "value1",
          "key2": { "key2_1": "value2_1",
                    "key2_2": "value2_2",
                    "key2_3": "value2_3" } }

    b = { "key1": "value1",
          "key2": { "key2_1": "value2_1",
                    "key2_2": "value2_2" } }

    c = { "key1": "value1",
          "key2": { "key2_1": "value2_1",
                    "key2_2": "value2_2",
                    "key2_3": "value2_3" } }


# Generated at 2022-06-22 21:33:40.535530
# Unit test for function dict_merge
def test_dict_merge():
    # Test simple key-value merges
    dict1 = dict(a=1, b=2)
    dict2 = dict(a=3, c=4)
    result = dict_merge(dict1, dict2)
    assert(result == dict(a=3, b=2, c=4))

    # Test nested dicts
    dict1 = dict(nested=dict(a=1, b=2))
    dict2 = dict(nested=dict(a=3, c=4))
    result = dict_merge(dict1, dict2)
    assert(result == dict(nested=dict(a=3, b=2, c=4)))

    # Test duplicate entries
    dict1 = dict(a=1, b=2, c=3)

# Generated at 2022-06-22 21:33:47.985595
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'a': {'b':1, 'c':2}, 'd':3 }
    b = { 'a': {'b':3, 'd':4}, 'e':5 }
    expected = { 'a': {'b':3, 'd':4, 'c':2}, 'd':3, 'e':5 }
    assert dict_merge(a, b) == expected
    assert dict_merge(b, a) == expected



# Generated at 2022-06-22 21:33:56.810847
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "h_t_t_p_body": "<p>Test Body</p>",
        "h_t_t_p_headers": {
            "X-Custom-Header": "Test-Header"
        }
    }

    expected = {
        "httpBody": "<p>Test Body</p>",
        "httpHeaders": {
            "X-Custom-Header": "Test-Header"
        }
    }

    assert snake_dict_to_camel_dict(test_dict) == expected
    assert test_dict == camel_dict_to_snake_dict(snake_dict_to_camel_dict(test_dict))



# Generated at 2022-06-22 21:34:07.780777
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:34:18.422603
# Unit test for function recursive_diff
def test_recursive_diff():
    import pytest

    # Test simple case, no difference
    dict1 = {'k1': 'v1', 'k2': 'v2'}
    dict2 = {'k1': 'v1', 'k2': 'v2'}
    ret = recursive_diff(dict1, dict2)
    assert ret is None

    # Test simple case, diff at the outermost
    dict1 = {'k1': 'v1', 'k2': 'v2'}
    dict2 = {'k1': 'v1'}
    ret = recursive_diff(dict1, dict2)
    assert ret is not None
    assert len(ret) == 2
    assert ret[0] == {'k2': 'v2'}
    assert ret[1] == {}

    # Test simple case, diff at the outermost


# Generated at 2022-06-22 21:34:29.003302
# Unit test for function dict_merge
def test_dict_merge():

    dict1 = dict(a=dict(b=dict(c=dict(d=1, e=2, f=3), h=7, i=8), j=4, k=5), m=6)
    dict2 = dict(a=dict(b=dict(c=dict(d=4, g=5), h=7), j=4), k=5)

    dict3 = dict_merge(dict1, dict2)
    dict3_ref = dict(a=dict(b=dict(c=dict(d=4, e=2, f=3, g=5), h=7, i=8), j=4, k=5), m=6)

    assert dict3 == dict3_ref
    assert dict3['a'] == dict3_ref['a']

# Generated at 2022-06-22 21:34:37.291103
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Foo': u'bar',
        'bar': [
            {'Baz': 'Baz'},
            {'Qux': 'Qux'}
        ]
    }
    expected_dict = {
        'foo': u'bar',
        'bar': [
            {'baz': 'Baz'},
            {'qux': 'Qux'}
        ]
    }
    assert(camel_dict_to_snake_dict(test_dict) == expected_dict)

    test_dict = {
        'HTTPEndpoint': u'bar',
        'Tags': [
            {'Key': 'Baz', 'Value': 'Baz'},
            {'Key': 'Qux', 'Value': 'Qux'}
        ]
    }
    expected_

# Generated at 2022-06-22 21:34:47.670153
# Unit test for function recursive_diff
def test_recursive_diff():
    from ansible.module_utils.common.dict_merge import recursive_diff
    dict1 = {'a': 'b', 'c': {'d': {'e': 'f', 'g': 'h'}, 'i': 'j'}, 'k': 'l'}
    dict2 = {'a': 'x', 'c': {'d': {'e': 'f', 'g': 'y'}, 'i': 'j'}, 'n': 'o'}
    expected = ({'a': 'b'}, {'a': 'x'})
    assert recursive_diff(dict1, dict2) == expected



# Generated at 2022-06-22 21:34:54.734004
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 'value1', 'key2': {'key2key1': 'value2'}, 'key3': {'key3key1': {'key3key1key1': 'value3'}}}
    b = {'key4': 'value4', 'key5': {'key5key1': 'value5'}, 'key2': {'key2key2': 'value2'}}
    c = {'key6': 'value6', 'key3': {'key3key1': {'key3key1key2': 'value3'}}}
    d = {'key7': 'value7', 'key3': {'key3key3': 'value3'}}
    e = {'key8': 'value8', 'key2': {'key2key2': 'value2'}}

# Generated at 2022-06-22 21:35:05.609309
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:35:15.269509
# Unit test for function recursive_diff
def test_recursive_diff():
    a = dict(one=dict(two=dict(three="foo")),
             four=dict(five=dict(six="bar")))
    b = dict(four=dict(five=dict(six="bar")),
             one=dict(two=dict(three="foo")))
    c = dict(one=dict(two=dict(three="foo")),
             four=dict(five=dict(six="bar")),
             seven=dict(eight=dict(nine="baz")))

    assert recursive_diff(a, a) == None
    assert recursive_diff(a, b) == None
    assert recursive_diff(a, c) == ({'seven': {'eight': {'nine': 'baz'}}},
                                    {'seven': {'eight': {'nine': 'baz'}}})
    assert recursive_

# Generated at 2022-06-22 21:35:25.194144
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel = {'HTTPEndpoint': {'Name': 'MyHTTPEndpoint', 'Protocol': 'HTTPS', 'URL': 'http://example.com', 'AuthorizationType': 'AWS_IAM'},
             'BatchSize': 123,
             'Tags': {'Key': 'Value'},
             'UseCallerCredentials': False,
             'AccessLoggingPolicy': {'Enabled': True, 'Format': '%h %l %u %t %r %>s'}}


# Generated at 2022-06-22 21:35:34.198122
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'a1': 'a',
        'a2': {
            'k1': 'a',
            'k2': {
                'x': 'a',
                'y': 'a'
            }
        }
    }
    b = {
        'a1': 'a',
        'a2': {
            'k1': 'b',
            'k2': {
                'x': 'a',
                'y': 'b'
            }
        },
        'c1': 'c'
    }

# Generated at 2022-06-22 21:35:43.109013
# Unit test for function recursive_diff
def test_recursive_diff():
    import sys

    try:
        from nose import TestProgram
    except ImportError:
        class TestProgram:
            def __init__(self, module='__main__', argv=None, exit=False, defaultTest=None): # pylint: disable=too-many-arguments
                from unittest import main
                main(module=module, argv=argv, exit=exit, defaultTest=defaultTest)

    # Required if executing from project root
    sys.path.append('lib/ansible/modules/cloud/amazon')
    sys.exit(TestProgram().success)

# Generated at 2022-06-22 21:35:51.330536
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': 1, 'b': 2, 'c': 3}, {'a': 2, 'b': 2, 'd': 4}) == {'a': 2, 'b': 2, 'c': 3, 'd': 4}
    assert dict_merge({'a': 1, 'b': 2, 'c': 3}, {'a': 2, 'd': 4}) == {'a': 2, 'b': 2, 'c': 3, 'd': 4}
    assert dict_merge({'a': 1, 'b': 2, 'c': 3}, {'a': 2, 'd': 4}, {'a': 3, 'd': 5}) == {'a': 3, 'b': 2, 'c': 3, 'd': 5}

# Generated at 2022-06-22 21:36:00.429804
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'branches': {
            'develop': {
                'environment': 'dev',
                'accounts': ['111111111111', '222222222222']
            },
            'master': {
                'environment': 'prod',
                'accounts': ['333333333333', '444444444444']
            },
            'version': '1.0.0'
        },
        'owner': 'Foo Bar'
    }

# Generated at 2022-06-22 21:36:10.877961
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'foo'},
        reversible=True
    ) == {'h_t_t_p_endpoint': 'foo'}
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'foo'}
    ) == {'http_endpoint': 'foo'}
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'foo'},
        reversible=True
    ) == {'h_t_t_p_endpoint': 'foo'}
    assert camel_dict_to_snake_dict(
        {'tags': {'key': 'value'}}
    ) == {'tags': {'key': 'value'}}
    assert camel_dict_to_snake

# Generated at 2022-06-22 21:36:20.229036
# Unit test for function recursive_diff
def test_recursive_diff():
    from collections import namedtuple
    import pytest
    from ansible.module_utils.common._collections_compat import MutableSequence

    def check(dict1, dict2, result):
        actual_diff = recursive_diff(dict1, dict2)
        assert actual_diff == result

    Check = namedtuple('Check', ['dict1', 'dict2', 'result'])

    simplest_check = Check(dict(a=1, b=2, c=3), dict(a=1, b=2, c=3), None)
    simple_check = Check(dict(a=1, b=2, c=3), dict(a=1, b=2, c=4), ({'c': 3}, {'c': 4}))

# Generated at 2022-06-22 21:36:31.732549
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:38.276705
# Unit test for function dict_merge
def test_dict_merge():
    """Test dict_merge function.

    Returns:
        None

    """

    collection = {'a': {'b': {'c': {'d': {'e': 'test1'}}}}}
    updates = {'a': {'b': {'c': {'d': {'e': 'test2'}}}}}

    assert dict_merge(collection, updates) == {'a': {'b': {'c': {'d': {'e': 'test2'}}}}}



# Generated at 2022-06-22 21:36:49.355092
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict = {'key_with_underscores': 'value'}
    new_dict = snake_dict_to_camel_dict(dict)
    assert new_dict['KeyWithUnderscores'] == 'value'

    dict = {'more_keys': {'key_with_underscores': 'value'}}
    new_dict = snake_dict_to_camel_dict(dict)
    assert new_dict['MoreKeys']['KeyWithUnderscores'] == 'value'

    dict = {'more_keys': {'key_with_underscores': 'value', 'another_key': {'nested_key': 'value'}}}
    new_dict = snake_dict_to_camel_dict(dict)

# Generated at 2022-06-22 21:36:57.597396
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.basic import AnsibleModule

    a = {'a': {'b': {'c': 'd'}}, 'e': 'f', 'g': 'h'}
    b = {'g': 'z', 'e': {'i': 'j', 'k': 'l'}, 'm': 'n'}

    assert {'a': {'b': {'c': 'd'}}, 'e': {'i': 'j', 'k': 'l'}, 'g': 'z', 'm': 'n'} == dict_merge(a, b)

    module = AnsibleModule(
        argument_spec={
            'a': dict(type='dict'),
            'b': dict(type='dict'),
        },
    )

# Generated at 2022-06-22 21:37:04.055836
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    expected = dict(
        eksClusterArn='dummy',
        eksClusterName='dummy',
        eksClusterPlatformVersion='1.0',
        eksClusterPlatformVersionUpdatedAt='11/11/11',
        eksClusterRoleArn='dummy',
        eksClusterVersion='1.0',
        eksClusterVersionUpdatedAt='11/11/11',
        eksClusterVpcId='dummy',
    )

# Generated at 2022-06-22 21:37:14.585670
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel_dict = {
        "attributeDefinitions": [{"attributeName": "ForumName", "attributeType": "S"}],
        "tableName": "Thread",
        "keySchema": [{"attributeName": "Subject", "keyType": "HASH"}],
        "localSecondaryIndexes": [{
            "indexName": "LastPostIndex",
            "keySchema": [{"attributeName": "ForumName", "keyType": "HASH"}, {"attributeName": "LastPostDateTime", "keyType": "RANGE"}],
            "projection": {"projectionType": "KEYS_ONLY"}}],
        "provisionedThroughput": {"readCapacityUnits": 5, "writeCapacityUnits": 5}}

# Generated at 2022-06-22 21:37:25.503697
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test passing non-dict
    try:
        recursive_diff(0, 0)
    except TypeError:
        pass
    else:
        assert False

    # Test first level difference
    left, right = recursive_diff({'a': 1}, {'b': 2})
    assert left == {'a': 1}
    assert right == {'b': 2}

    # Test second level difference
    left, right = recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}})
    assert left == {'a': {'b': 1}}
    assert right == {'a': {'b': 2}}

    # Test second level difference in a list
    left, right = recursive_diff({'a': [1, 2]}, {'a': [2, 3]})
    assert left

# Generated at 2022-06-22 21:37:35.615240
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Basic unit test for snake_dict_to_camel_dict function.
    """
    result = snake_dict_to_camel_dict(
        {
            "key_1": "value_1",
            "key_2":
            {
                "key_2_1": "value_2_1",
                "key_2_2": "value_2_2"
            },
            "key_3": [
                "value_3_1", "value_3_2"
            ]
        })

# Generated at 2022-06-22 21:37:46.264567
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {
        'key1': 1,
        'key2': [1, 2, 3],
        'key3': {'key': 3, 'key2': 4}
    }
    d2 = {
        'key1': 2,
        'key2': [2, 3, 4],
        'key3': {'key': 5, 'key2': 6}
    }
    d3 = dict_merge(d1, d2)
    assert d3['key1'] == 1
    assert d3['key2'] == [1, 2, 3]
    assert d3['key3'] == {'key': 3, 'key2': 4}

# Generated at 2022-06-22 21:37:58.232557
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
        'key1': 'val1',
        'key2': {
            'key4': 'val4',
            'key5': ['val5']
        }
    }

    d2 = {
        'key1': 'val1a',
        'key3': 'val3',
        'key2': {
            'key4': 'val4a',
            'key6': ['val6']
        }
    }

    assert dict_merge(d1, d2) == {
        'key1': 'val1a',
        'key2': {
            'key4': 'val4a',
            'key5': ['val5'],
            'key6': ['val6']
        },
        'key3': 'val3'
    }


# Generated at 2022-06-22 21:38:05.223262
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict =  {
        'TargetGroupARNs': ['arn:aws:elasticloadbalancing:us-east-1:0123456789:targetgroup/my-targets1/6d0ecf831eec9f09'],
        'AutoScalingGroupARN': 'arn:aws:autoscaling:us-east-1:0123456789:autoScalingGroup:a123bcd-1234-1234-1234-123456789:autoScalingGroupName/my-auto-scaling-group2'
    }
    # test with reversible=False
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-22 21:38:16.946794
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert 'foo' == _camel_to_snake('foo')
    assert 'foo' == _camel_to_snake('foo', True)
    assert 'foo_bar' == _camel_to_snake('fooBar')
    assert 'foo_bar' == _camel_to_snake('fooBar', True)
    assert 'foo_bar' == _camel_to_snake('fooBar', False)
    assert 'f_b' == _camel_to_snake('FB', False)
    assert 'foo_bar' == _camel_to_snake('FooBar', False)
    assert 'h_t_t_p_endpoint' == _camel_to_snake('HTTPEndpoint', reversible=True)
    assert 'target_group_a_rns' == _c

# Generated at 2022-06-22 21:38:26.829672
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict(dict(HTTPEndpoint=dict(Path='/', Port=8080))) == dict(h_t_t_p_endpoint=dict(path='/', port=8080))
    assert camel_dict_to_snake_dict(dict(HTTPEndpoint=dict(Path='/', Port=8080)), reversible=True) == dict(h_t_t_p_endpoint=dict(path='/', port=8080))
    assert camel_dict_to_snake_dict(dict(HTTPEndpoints=[dict(Path='/', Port=8080)])) == dict(h_t_t_p_endpoints=[dict(path='/', port=8080)])

# Generated at 2022-06-22 21:38:36.047575
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # For the 'true' CamelCase
    snake_dict = {'camel_case': 1, 'two_words': 2, 'two_more_words': 3}
    expected_camel_dict = {'CamelCase': 1, 'TwoWords': 2, 'TwoMoreWords': 3}
    actual_camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=True)

    assert expected_camel_dict == actual_camel_dict

    # For the dromedaryCase aka lower CamelCase
    snake_dict = {'camel_case': 1, 'two_words': 2, 'two_more_words': 3}
    expected_camel_dict = {'camelCase': 1, 'twoWords': 2, 'twoMoreWords': 3}
    actual_camel_

# Generated at 2022-06-22 21:38:45.752941
# Unit test for function dict_merge
def test_dict_merge():
    # This is supposed to be a dictionary merge utility with limited
    # support for guessing at user intent.
    # It is by no means a general purpose tool.

    # Merge two empty dictionaries.
    # Should return empty.
    assert dict_merge({}, {}) == {}

    # Merge a dictionary1 with dictionary2.
    # Should return dictionary2.
    assert dict_merge({'a':1, 'b':2, 'c':3},
                      {'d':4, 'e':5, 'f':6}) == {'d':4, 'e':5, 'f':6}

    # Merge a dictionary2 with dictionary1.
    # Should return dictionary2.

# Generated at 2022-06-22 21:38:56.877755
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:08.426258
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    empty_dict = {}
    empty_dict_result = snake_dict_to_camel_dict(empty_dict)
    assert empty_dict == empty_dict_result

    single_key_dict = {'a_simple_key': 'a_simple_value'}
    single_key_dict_result = snake_dict_to_camel_dict(single_key_dict)
    assert single_key_dict != single_key_dict_result
    assert {'aSimpleKey': 'a_simple_value'} == single_key_dict_result

    multiple_key_dict = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}

# Generated at 2022-06-22 21:39:13.709492
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': {'b_a_z': 1}}) == {'fooBar': {'bAZ': 1}}
    assert snake_dict_to_camel_dict({'foo_bar': {'b_a_z': 1}}, capitalize_first=True) == {'FooBar': {'BAZ': 1}}


# Generated at 2022-06-22 21:39:25.581089
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': {'c': 3}, 'd': 4 }, 'e': 5, 'f': 6}
    dict2 = {'a': {'b': {'d': 3}, 'd': 4 }, 'e': 7, 'g': 8}
    result = ({'a': {'b': {'c': 3}}, 'f': 6, 'e': 5}, {'a': {'b': {'d': 3}}, 'e': 7, 'g': 8})
    assert recursive_diff(dict1, dict2) == result

    dict1 = {'a': {'b': {'c': 3}, 'd': 4 }, 'e': 5, 'f': 6}

# Generated at 2022-06-22 21:39:37.093715
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('FooBar') == 'foo_bar'
    assert _camel_to_snake('fooBar') == 'foo_bar'
    assert _camel_to_snake('fooBarBazBoz') == 'foo_bar_baz_boz'
    assert _camel_to_snake('FooBarBazBoz') == 'foo_bar_baz_boz'
    assert _camel_to_snake('Foo3Bar3Baz3Boz') == 'foo3_bar3_baz3_boz'
    assert _camel_to_snake('FooBarBazBoz') == 'foo_bar_baz_boz'

# Generated at 2022-06-22 21:39:48.208303
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:58.343855
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "MyFirstKey": "Hello",
        "mySecondKey": "World",
        "MyThirdKey": False,
        "NumberOfKeys": 3,
        "ThirdLevel": {
            "FourthLevel": {
                "NestedKey1": "nested_value1",
                "NestedKey2": "nested_value2",
                "NestedKey3": "nested_value3"
            }
        }
    }


# Generated at 2022-06-22 21:40:08.874753
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b=dict(c=1, d=2, e=3))
    dict2 = dict(a=1, b=dict(c=3, d=2, e=3))
    dict3 = dict(a=1, b=dict(c=1, d=2, e=3))

    # Test diff with identical dicts
    assert recursive_diff(dict1, dict1) is None
    # Test diff with two different dicts
    assert recursive_diff(dict1, dict2) == (dict(b=dict(c=1)), dict(b=dict(c=3)))
    # Test that dicts are not modified during the diff
    assert dict1 == dict3


# Generated at 2022-06-22 21:40:16.575291
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a':{'b':1}}
    b = {'a':{'b':2,'c':3},'d':4}
    c = dict_merge(a,b)
    assert c['a']['c'] == 3
    d = {'a':{'x':1}}
    e = dict_merge(d,b)
    assert e['a']['x'] == 1
    e = dict_merge(a,d)
    assert e['a']['x'] == 1


# Generated at 2022-06-22 21:40:26.917520
# Unit test for function recursive_diff
def test_recursive_diff():
    number_of_tests = 2

    test1_dict1 = {
        "name": "test resource 1",
        "tags": {
            "tag 1": "value 1",
            "tag 2": "value 2"
        },
        "identifier": {
            "key1": "value 1",
            "key2": "value 2"
        },
        "enabled": True,
        "percent_data_in_cache": 90,
        "value": "string value"
    }

    test1_dict2 = test1_dict1.copy()
    test1_dict2['enabled'] = False
    test1_dict2['percent_data_in_cache'] = 80
    test1_dict2['value'] = "new string value"

# Generated at 2022-06-22 21:40:38.359979
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test case 1
    camel_dict_test_1 = {
        'test_case': '1',
        'test_number': '1',
        'test_case_string': 'Test case 1',
        'test_case_string_with_HTTPEndpoint': 'Test case 1 with HTTPEndpoint',
        'test_case_string_with_targetGroupArns': 'Test case 1 with targetGroupArns',
        'test_case_object_with_targetGroupARNs': {
            'one': '1',
            'two': '2',
            'three': '3',
            'four': '4',
            'five': '5'
        }
    }

    snake_dict_test_1 = camel_dict_to_snake_dict(camel_dict_test_1)
    assert snake_dict