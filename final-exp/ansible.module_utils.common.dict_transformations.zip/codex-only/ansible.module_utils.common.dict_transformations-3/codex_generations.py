

# Generated at 2022-06-22 21:30:33.150886
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.ec2 import HAS_BOTO3
    # Setup our test object
    aws_client_params = {
        'region': 'eu-west-1',
        'aws_secret_access_key': 'abc123',
        'aws_access_key_id': 'abc123',
        'aws_session_token': 'abc123',
        'role_arn': 'arn:aws:iam::123456789012:role/role1',
        'external_id': '123ABC',
        'mfa_serial_number': 'arn:aws:iam::123456789012:mfa/user1'
    }

    # Setup default values

# Generated at 2022-06-22 21:30:42.617634
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first': {'all_rows': {'pass': 'dog', 'number': '1' } } }
    b = { 'first': {'all_rows': {'fail': 'cat', 'number': '5' } } }
    c = { 'second': {'all_rows': {'pass': 'dog', 'number': '1' } } }
    d = { 'first': {'all_rows': {'fail': 'cat', 'number': '5' } },
          'second': {'all_rows': {'pass': 'dog', 'number': '1' } } }
    e = { 'first': {'all_rows': {'pass': 'dog', 'fail': 'cat' } } }

    assert dict_merge(a, b) == d

# Generated at 2022-06-22 21:30:53.037646
# Unit test for function dict_merge
def test_dict_merge():

    a = {'a': 1,
         'b': {
            'b1': 1,
            'b2': 2,
            'b3': 3,
         },
         'c': [{'c1': 1}]
    }

    b = dict(a)
    b['c'][0]['c1'] = 2
    b['d'] = {'d1': 1}
    b['e'] = 'e'

    c = dict_merge(a, b)

    assert c == {'a': 1,
                 'b': {
                    'b1': 1,
                    'b2': 2,
                    'b3': 3,
                 },
                 'c': [{'c1': 2}],
                 'd': {'d1': 1},
                 'e': 'e'}



# Generated at 2022-06-22 21:31:04.522266
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:31:14.161567
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Unit test for function camel_dict_to_snake_dict

    This tests the basic dictionary case, which is the most common.
    """

    snake_dict = {
        'instance_id': 'i-12345678',
        'tags': {
            'Name': 'Testing',
            'Another Tag': 'Another Value'
        }
    }
    camel_dict = {
        'InstanceId': 'i-12345678',
        'Tags': {
            'Name': 'Testing',
            'Another Tag': 'Another Value'
        }
    }
    assert camel_dict == snake_dict_to_camel_dict(snake_dict)
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)



# Generated at 2022-06-22 21:31:20.759234
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(a=1, b=2, c=dict(d=4, e=5))
    dict2 = dict(a=1, b=2, c=dict(e=3, f=4))
    expected = dict(a=1, b=2, c=dict(d=4, e=3, f=4))
    assert dict_merge(dict1, dict2) == expected



# Generated at 2022-06-22 21:31:27.216914
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2, 'd': {'e': 3}}, 'f': 4}
    b = {'x': 1, 'b': {'y': 2, 'd': {'z': 3}}, 'g': 4}
    expected_result = {'a': 1, 'b': {'c': 2, 'd': {'e': 3, 'z': 3}}, 'f': 4, 'x': 1, 'g': 4}
    result = dict_merge(a, b)
    assert result == expected_result



# Generated at 2022-06-22 21:31:37.909323
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test input types and raise TypeError
    with pytest.raises(TypeError):
        recursive_diff(None, None)
        recursive_diff(dict(), list())
        recursive_diff({}, set())

    # Test no difference
    assert recursive_diff({}, {}) == None

    # Test key not in both
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})

    # Test key in both and value same
    assert recursive_diff({'a': 1}, {'a': 1}) == None
    assert recursive_diff({'a': list()}, {'a': list()}) == None

    # Test key in both and value different

# Generated at 2022-06-22 21:31:48.449408
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils._text import to_bytes

    d = {'x': {'a': 'a', 'b': 'b'}, 'y': {'a': 'a', 'b': 'b'}, 'z': {'a': 'a', 'b': 'b'}}
    d1 = {'x': {'a': 'r', 'c': 'c'}, 'y': '1', 'z': {'a': 'r', 'c': 'c'}}
    d2 = dict_merge(d, d1)

    assert d2['x']['a'] == 'r'
    assert d2['y'] == '1'
    assert d2['z']['c'] == 'c'


# Generated at 2022-06-22 21:31:59.242979
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # unit tests for camel_dict_to_snake_dict
    assert camel_dict_to_snake_dict({"firstKey": "firstValue", "SecondKey": "secondValue"}) == {"first_key": "firstValue", "second_key": "secondValue"}
    assert camel_dict_to_snake_dict({"firstKey": "firstValue", "SecondKey": "secondValue", "Tags": {"secondKey": "firstValue"}}) == {"first_key": "firstValue", "second_key": "secondValue", "tags": {"secondKey": "firstValue"}}

# Generated at 2022-06-22 21:32:11.547421
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_with_ignore = {
        'Tags': {
            'Key': 'Ansible',
            'Value': 'true',
            'WithCamelCase': 'bad'
        },
        'MetricType': 'ALBRequestCountPerTarget',
        'Statistic': 'Sum'
    }

    snake_dict_with_ignore = {
        'tags': {
            'Key': 'Ansible',
            'Value': 'true',
            'WithCamelCase': 'bad'
        },
        'metric_type': 'ALBRequestCountPerTarget',
        'statistic': 'Sum'
    }

    assert camel_dict_to_snake_dict(camel_dict_with_ignore, ignore_list=['Tags']) == snake_dict_with_ignore
    assert camel_dict_to

# Generated at 2022-06-22 21:32:24.361939
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'z': {'a': 1, 'b': 2, 'c': 3}, 'h': [1, 2, 3]}
    b = {'w': 10, 'x': 11, 'y': 2, 'z': {'a': 11, 'c': 31}, 'h': [1, 4, 3]}
    c = {'x': 1, 'y': 2, 'z': {'a': 1, 'b': 2, 'c': 3}, 'h': [1, 2, 3]}
    d = {'x': 11, 'y': 2, 'z': {'a': 11, 'c': 31}, 'h': [1, 4, 3]}


# Generated at 2022-06-22 21:32:34.765335
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'1': 1}, {'1': 1}) is None
    assert recursive_diff({'1': 1}, {'1': 2}) == ({'1': 1}, {'1': 2})
    assert recursive_diff({'1': 1, '2': 2}, {'1': 1}) == ({'2': 2}, {})
    assert recursive_diff({'1': 1}, {'1': 1, '2': 2}) == ({}, {'2': 2})
    assert recursive_diff({'1': 1, '2': 2, '3': {'a': 3}}, {'1': 1, '2': 2, '3': {'a': 4}}) == ({}, {'3': {'a': 4}})

# Generated at 2022-06-22 21:32:45.618523
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    test_dict = {
        'spec': {
            'containers': [
                {
                    'name': 'c',
                    'image': 'c',
                    'portMappings': [
                        {
                            'containerPort': 80,
                        },
                    ],
                },
            ],
        },
        'metadata': {
            'name': 'n',
        },
    }

    expected_dict = {
        'spec': {
            'containers': [
                {
                    'name': 'c',
                    'image': 'c',
                    'portMappings': [
                        {
                            'containerPort': 80,
                        },
                    ],
                },
            ],
        },
        'metadata': {
            'name': 'n',
        },
    }

    assert snake_dict_to_camel_

# Generated at 2022-06-22 21:32:54.318439
# Unit test for function dict_merge
def test_dict_merge():

    class TestException(Exception):
        pass

    def dicts_equal(d1, d2):
        if set(d1.keys()) != set(d2.keys()):
            raise TestException("Dict keys should be the same")
        for k in d1.keys():
            if d1[k] != d2[k]:
                raise TestException("'%s' key's values should be the same" % k)

    a = {
        'simple_key': 'value',
        'true_key': True,
        'false_key': False,
        'none_key': None,
        'dict1': {'a': 1, 'b': 2, '3': '3'},
        'list1': [1, 2, 3],
    }


# Generated at 2022-06-22 21:33:02.222466
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == expected

# Generated at 2022-06-22 21:33:14.022951
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    test_dict = {
        'test': 'test',
        'test_dict': {
            'test_nested_dict_key': 'test_nested_dict_value'
        },
        'test_list': [{
            'test_nested_list_dict_key': 'test_nested_list_dict_value'
        }]
    }

    expected_dict = {'test': 'test',
                     'testDict': {'testNestedDictKey': 'test_nested_dict_value'},
                     'testList': [{'testNestedListDictKey': 'test_nested_list_dict_value'}]}

    assert expected_dict == snake_dict_to_camel_dict(test_dict)

# Generated at 2022-06-22 21:33:23.516465
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function
    """
    test_dict1 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4'
        },
        'key5': {
            'key6': 'value6'
        }
    }
    test_dict2 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4'
        },
        'key5': {
            'key6': 'value7'
        }
    }
    expected_result = ({}, {'key5': {'key6': 'value7'}})
    result = recursive_diff(test_dict1, test_dict2)

# Generated at 2022-06-22 21:33:30.812945
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = dict(
        one=1,
        two=2,
        three=dict(
            List=[
                dict(
                    ID="1",
                    Name="foo"
                )
            ],
            ID="421",
            Name="bar"
        ),
        Four=4,
        HTTPEndpoint=dict(
            ID="3",
            Name="foo"
        )
    )

# Generated at 2022-06-22 21:33:40.467245
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({'foo': 1}, {}) == {'foo': 1}
    assert dict_merge({}, {'bar': 2}) == {'bar': 2}
    assert dict_merge({'foo': 1}, {'bar': 2}) == {'foo': 1, 'bar': 2}
    assert dict_merge({'foo': 1}, {'foo': 2}) == {'foo': 2}
    assert dict_merge({'foo': 1}, {'foo': [2]}) == {'foo': [2]}
    assert dict_merge({'foo': {'bar': 1}}, {'foo': {'bar': 2}}) == {'foo': {'bar': 2}}

# Generated at 2022-06-22 21:33:52.230128
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test 1
    ret = recursive_diff({'a': 2}, {'a': 2})
    assert ret is None

    # Test 2
    ret = recursive_diff({'a': 2}, {'a': 1})
    assert ret == ({'a': 2}, {'a': 1})

    # Test 3
    ret = recursive_diff({'a': {'b': 1, 'c': 3}}, {'a': {'b': 1, 'c': 2}})
    assert ret == ({'a': {'c': 3}}, {'a': {'c': 2}})

    # Test 4

# Generated at 2022-06-22 21:34:03.300690
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'snake': 'case'}) == {'snake': 'case'}
    assert snake_dict_to_camel_dict({'snake_case': 'value'}) == {'snakeCase': 'value'}
    assert snake_dict_to_camel_dict({'snake_case': 'value'}, capitalize_first=True) == {'SnakeCase': 'value'}
    assert snake_dict_to_camel_dict({'snake': {'case': 'value'}}) == {'snake': {'case': 'value'}}
    assert snake_dict_to_camel_dict({'snake': {'case': 'value'}}, capitalize_first=True) == {'Snake': {'Case': 'value'}}
    assert snake_dict

# Generated at 2022-06-22 21:34:11.269982
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake = { "snake_case_key": "value",
              "also_snake": {
                  "nested_snake_case_key": "value"
                  }
              }
    snake_copy = deepcopy(snake)

    assert snake_dict_to_camel_dict(snake) == { "snakeCaseKey": "value",
                                                "alsoSnake": {
                                                    "nestedSnakeCaseKey": "value"
                                                }
                                                }

    assert snake_dict_to_camel_dict(snake, capitalize_first=True) == { "SnakeCaseKey": "value",
                                                                       "AlsoSnake": {
                                                                           "NestedSnakeCaseKey": "value"
                                                                       }
                                                                       }

    assert snake == snake_copy

# Generated at 2022-06-22 21:34:17.702332
# Unit test for function recursive_diff
def test_recursive_diff():
    res = recursive_diff({'a': {'b': 1, 'c': 2}, 'd': 3, 'e': [1, 2]}, {'a': {'b': 2, 'c': 2}, 'e': [1, 2], 'f': 3})
    assert res == ({'a': {'b': 1}}, {'a': {'b': 2}, 'd': 3, 'f': 3})

    res = recursive_diff({}, {1: 2})
    assert res == ({}, {1: 2})

    res = recursive_diff({'a': {1: 2}}, {})
    assert res == ({'a': {1: 2}}, {})

    res = recursive_diff({}, {'a': {1: 2}})
    assert res == ({}, {'a': {1: 2}})

   

# Generated at 2022-06-22 21:34:22.997652
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(foo='bar', baz='flux')
    dict2 = dict(foo='BAR', bar='baz')
    dict_merge(dict1, dict2) == dict(foo='BAR', baz='flux', bar='baz')

# Generated at 2022-06-22 21:34:34.297916
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 'a'}
    b = {'b': 'b'}
    c = dict_merge(a, b)
    assert 'a' in c
    assert 'b' in c
    a = {'a': 'a'}
    b = {'a': 'b'}
    c = dict_merge(a, b)
    assert 'a' in c
    assert c['a'] == 'b'
    a = {'a': {'x': 'ax'}}
    b = {'a': {'y': 'ay'}}
    c = dict_merge(a, b)
    assert 'a' in c
    assert 'x' in c['a']
    assert 'y' in c['a']
    a = {'a': {'x': 'ax'}}

# Generated at 2022-06-22 21:34:42.121466
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'aa': {'aaa': 1}}}
    b = {'a': {'aa1': {'bbb': 2}}}

    result = {'a': {'aa': {'aaa': 1}, 'aa1': {'bbb': 2}}}

    assert (dict_merge(a, b) == result)



# Generated at 2022-06-22 21:34:51.816967
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Some basic tests
    assert(_camel_to_snake('CamelCase') == 'camel_case')
    assert(_camel_to_snake('CamelCase', reversible=True) == 'c_a_m_e_l_c_a_s_e')
    assert(_camel_to_snake('EC2Instance') == 'ec2_instance')
    assert(_camel_to_snake('ExpiryTime') == 'expiry_time')
    assert(_camel_to_snake('TargetGroupARNs') == 'target_group_a_r_ns')
    assert(_camel_to_snake('TargetGroupARNs', reversible=True) == 'target_group_a_r_ns')

# Generated at 2022-06-22 21:35:03.441898
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({"foo": "bar"}, {"foo": "bar"}) is None
    assert recursive_diff({}, {}) is None

    assert recursive_diff({'foo':1}, {'bar':2}) == ({'foo':1}, {'bar':2})

    assert recursive_diff({'foo':1, 'bar':2}, {'bar':2}) == ({'foo':1}, {})
    assert recursive_diff({'foo':1, 'bar':2}, {'foo':1}) == ({}, {'bar':2})
    assert recursive_diff({'foo':1, 'bar':2}, {'foo':3}) == ({'bar':2}, {'foo':3})


# Generated at 2022-06-22 21:35:13.723964
# Unit test for function dict_merge
def test_dict_merge():
    import pytest
    d1 = {'a': 1, 'b': 2}
    d2 = {'b': 3, 'c': 4}
    assert dict_merge(d1, d2) == {'a': 1, 'b': 3, 'c': 4}

    d3 = {'a': {'b': 2}}
    d4 = {'a': {'b': 3, 'c': 4}}
    assert dict_merge(d3, d4) == {'a': {'b': 3, 'c': 4}}

    d5 = {'a': ["list", "of", "list"]}
    d6 = {'a': ["list2"]}
    assert dict_merge(d5, d6) == {'a': ["list2"]}


# Generated at 2022-06-22 21:35:19.104489
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1}}
    print(d1)
    d2 = {'a': {'c': 2}}
    print(d2)
    d1 = dict_merge(d1, d2)
    print(d1)

if __name__ == "__main__":
    test_dict_merge()

# Generated at 2022-06-22 21:35:22.763908
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'from_address': 'foo'}) == {'fromAddress': 'foo'}
    assert snake_dict_to_camel_dict({'from_address': 'foo'}, capitalize_first=True) == {'FromAddress': 'foo'}



# Generated at 2022-06-22 21:35:32.465045
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'string_value': 'abcd',
                  'integer_value': 42,
                  'float_value': 3.14,
                  'boolean_value': True,
                  'list_value': [1, 2, 3],
                  'dict_value': {'a': 1, 'b': 2},
                  'empty_value': '',
                  'none_value': None}

    camel_dict = snake_dict_to_camel_dict(snake_dict, capitalize_first=False)
    assert (camel_dict['stringValue'] == 'abcd')
    assert (camel_dict['integerValue'] == 42)
    assert (camel_dict['floatValue'] == 3.14)
    assert (camel_dict['booleanValue'] == True)

# Generated at 2022-06-22 21:35:43.232260
# Unit test for function recursive_diff
def test_recursive_diff():
    from unittest import TestCase
    from json import dumps

    class RecursiveDiffTestCase(TestCase):
        def test_no_diff(self):
            dict1 = dict(a=1, b=2, c='3', d=[1, 2, 4], e=None, f=dict(g=[dict(h=1)]))
            dict2 = dict(a=1, b=2, c='3', d=[1, 2, 4], e=None, f=dict(g=[dict(h=1)]))
            result = recursive_diff(dict1, dict2)
            self.assertEqual(result, None)


# Generated at 2022-06-22 21:35:51.442686
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'employees': {
            'name': 'John',
            'occupation': 'gardener',
            'age': '25'
        },
        'users': {
            'name': 'John',
            'occupation': 'gardener',
            'age': '25'
        }
    }
    b = {
        'employees': {
            'name': 'Ann',
            'occupation': 'driver',
            'age': '25'
        },
        'users': {
            'name': 'John',
            'occupation': 'Network Engineer',
            'age': '25'
        }
    }


# Generated at 2022-06-22 21:36:00.548611
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:11.010387
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Expected primitive types as input
    camel_dict_1 = {"stringKey": "stringValue", "intKey": 0, "floatKey": 0.0, "boolKey": True}
    expected_snake_dict_1 = {"string_key": "stringValue", "int_key": 0, "float_key": 0.0, "bool_key": True}
    camel_dict_2 = {"stringKey": "stringValue", "intKey": 0, "floatKey": 0.0, "boolKey": True}
    expected_snake_dict_2 = {
        "string_key": "stringValue",
        "int_key": 0,
        "float_key": 0.0,
        "bool_key": True}

# Generated at 2022-06-22 21:36:20.341078
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'dict1_key1': {
            'dict1_key1_1': 'value1_1_1',
            'dict1_key1_2': {
                'dict1_key1_2_1': 'value1_1_2_1',
                'dict1_key1_2_2': 'value1_1_2_2'
            }
        },
        'dict1_key2': {
            'dict1_key2_1': 'value1_2_1',
            'dict1_key2_2': 'value1_2_2'
        },
        'dict1_key3': 'value1_3'
    }

# Generated at 2022-06-22 21:36:31.527100
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'snakekey': 'snakevalue',
        'snake_dict': {'snake_key': 'snake_value'},
        'snake_list': ['snake_key', 'snake_value'],
        'some_list': [{'snake_key': 'snake_value'}],
    }
    assert snake_dict_to_camel_dict(snake_dict, False) != snake_dict
    assert snake_dict_to_camel_dict(snake_dict, False)['snakeDict']['snakeKey'] == 'snake_value'
    assert snake_dict_to_camel_dict(snake_dict, True)['SnakeDict']['SnakeKey'] == 'snake_value'

# Generated at 2022-06-22 21:36:40.654949
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'key_1': 'value_1', 'another_key': 'another_value', 'list_key': ['item_1', 'item_2']}
    camel_dict = {'Key1': 'value_1', 'AnotherKey': 'another_value', 'ListKey': ['item_1', 'item_2']}

    assert snake_dict_to_camel_dict(snake_dict) == camel_dict
    assert snake_dict_to_camel_dict(snake_dict,capitalize_first=True) == {'Key1': 'value_1', 'AnotherKey': 'another_value', 'ListKey': ['item_1', 'item_2']}

# Generated at 2022-06-22 21:36:50.608916
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'foo': {'bar': {'baz': 'fizz'}}}
    dict2 = {'foo': {'bar': {'baz': 'buzz'}}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'foo': {'bar': {'baz': 'fizz'}}}, {'foo': {'bar': {'baz': 'buzz'}}})
    dict1 = {'foo': 'bar'}
    dict2 = {'foo': 'baz'}
    result = recursive_diff(dict1, dict2)
    assert result == ({'foo': 'bar'}, {'foo': 'baz'})
    dict1 = {'foo': 'bar'}
    dict2 = {'foo': Object()}

# Generated at 2022-06-22 21:36:58.564539
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_data = {
        'test_data': {
            'test_data_1': [
                1,
                {
                    'test_data_2': {
                        'test_data_2_1': [
                            1,
                            {
                                'test_data_2_2': [
                                    1,
                                    2,
                                    3,
                                ],
                            },
                            3,
                        ],
                    },
                },
                3,
            ],
        },
    }

# Generated at 2022-06-22 21:37:08.484212
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Recursively diff two dictionaries
    Raises ``TypeError`` for incorrect argument type.
    :arg dict1: Dictionary to compare against.
    :arg dict2: Dictionary to compare with ``dict1``.
    :return: Tuple of dictionaries of differences or ``None`` if there are no differences.
    """
    dict1 = {'a': 'b', 'c': 'd'}
    dict2 = {'a': 'b', 'c': 'e'}
    dict3 = {'a': 'b', 'c': 'e', 'f': 'g'}
    dict4 = {'a': 'b', 'c': 'e', 'f': 'i'}
    dict5 = {'a': {'h': 'g'}, 'c': 'z', 'd': [1, 2, 3]}
    dict

# Generated at 2022-06-22 21:37:20.026661
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({}, {1: 1}) == ({}, {1: 1})
    assert recursive_diff({1: 1}, {}) == ({1: 1}, {})
    assert recursive_diff({1: 1}, {1: 1}) is None
    assert recursive_diff({1: 1}, {1: 2}) == ({1: 1}, {1: 2})
    assert recursive_diff({1: 1}, {1: 1, 2: 2}) == ({}, {2: 2})
    assert recursive_diff({1: 1}, {1: 2, 2: 2}) == ({1: 1}, {1: 2, 2: 2})
    assert recursive_diff({1: 1, 2: 2}, {1: 1, 2: 3}) == ({2: 2}, {2: 3})

# Generated at 2022-06-22 21:37:29.001601
# Unit test for function dict_merge
def test_dict_merge():
    # Basic merging of 2 dicts
    A = {
        'a': 1,
        'b': 2,
        'c': {
            'c1': 1,
            'c2': 2
        }
    }
    B = {
        'a': 1,
        'b': 3,
        'c': {
            'c1': 1,
            'c3': 3
        },
        'd': {
            'd1': 1
        }
    }
    A2 = {
        'a': 1,
        'b': 3,
        'c': {
            'c1': 1,
            'c2': 2,
            'c3': 3
        },
        'd': {
            'd1': 1
        }
    }

# Generated at 2022-06-22 21:37:39.449858
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b="asdf", c=dict(a=1, b=2), d=dict(a=1, b=2), e=None, f=dict(a=3))
    dict2 = dict(a=1, b="asdf", c=dict(a=1, b=2), d=dict(a=3, b=4), e=None)
    left, right = recursive_diff(dict1, dict2)
    assert left == dict(f=dict(a=3)), left
    assert right == dict(d=dict(a=3, b=4)), right

    dict1 = dict(a=[1, 2, 3], b=[4, 5, 6])
    dict2 = dict(a=[1, 2, 3], b=[4, 5, 6])

# Generated at 2022-06-22 21:37:48.632484
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPEndpoint": "foo", "TFTPEndpoint": "bar"}

    snake_dict = {'http_endpoint': 'foo', 't_f_t_p_endpoint': 'bar'}
    res = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == res

    snake_dict = {'h_t_t_p_endpoint': 'foo', 't_f_t_p_endpoint': 'bar'}
    res = camel_dict_to_snake_dict(camel_dict, reversible=True)
    assert snake_dict == res



# Generated at 2022-06-22 21:37:56.500372
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Name': 'foo', 'associationIds': ['ID1', 'ID2'],
                                     'tags': {'key1': 'value1', 'key2': 'value2'}}) == \
           {'name': 'foo', 'association_ids': ['ID1', 'ID2'], 'tags': {'key1': 'value1', 'key2': 'value2'}}



# Generated at 2022-06-22 21:38:07.045417
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test the recursive_diff function of the ec2_utils module."""


# Generated at 2022-06-22 21:38:18.188876
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "resource_id": "i-12345678901234567",
        "resource_type": "instance",
        "tags": {
            "Name": "foobar",
        },
        "detail_type": "Scheduled Event",
        "source": "aws.events",
        "detail": {
            "test_key": "test_value",
            "test_list": [
                0,
                1,
                2,
                3
            ]
        }
    }


# Generated at 2022-06-22 21:38:27.005005
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    source_dict = {'Foo': 'foovalue',
                   'Bar': 'barvalue',
                   'HTTPEndpoint': {'Hostname': 'mydomain.com',
                                    'HTTPTrafficPolicy': {'Enabled': True}},
                   'LoadBalancerAttributes': [{'Key1': 'value1'},
                                              {'Key2': 'value2'}]
                   }

# Generated at 2022-06-22 21:38:36.148532
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_test_dict = {
        'test': {
            'test_test': 'test',
            'test_test2': 'test2',
            'test_test3': {
                'test_test4': 'test4',
                'test_test5': 'test5',
                'test_test6': [
                    {
                        'test_test7': 'test7',
                        'test_test8': 'test8',
                        'test_test9': 9
                    }
                ]
            }
        },
        'test2': 'test2',
        'test3': 3,
    }
    camel_test_dict = snake_dict_to_camel_dict(snake_test_dict)

# Generated at 2022-06-22 21:38:43.260986
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'x': 2, 'y': 3}, 'd': 6}
    b = {'b': {'y': 4, 'z': 5}, 'c': 7}
    c = dict_merge(a, b)
    assert c['a'] == 1
    assert c['b']['x'] == 2
    assert c['b']['y'] == 4
    assert c['b']['z'] == 5
    assert c['c'] == 7
    assert 'd' not in c

# Generated at 2022-06-22 21:38:51.638821
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'pass' : 'dog', 'number' : '5' } } }
    assert dict_merge(a,b) == c

# Generated at 2022-06-22 21:39:00.750984
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    class dict_class(dict):
        pass

    camel_dict = dict_class()
    camel_dict['httpMethod'] = 'POST'
    camel_dict['httpEndpoint'] = 'http://ec2-1-2-3-4.compute-1.amazonaws.com'
    camel_dict['ignoredCase'] = dict_class()
    camel_dict['ignoredCase']['tags'] = dict_class()
    camel_dict['ignoredCase']['tags']['Key0'] = "Value0"
    camel_dict['ignoredCase']['tags']['Key1'] = "Value1"
    camel_dict['ignoredCase']['tags']['Key2'] = "Value2"

    expected = dict_class()
    expected['http_method'] = 'POST'

# Generated at 2022-06-22 21:39:12.040771
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1,
         'b': {
             'ba': 2,
             'bb': {
                 'bba': 3
             }
         },
         'c': 4}
    b = {'b': {
             'bb': {
                 'bbb': 5
             }
         },
         'c': {
             'ca': 6
         },
         'd': 7
    }
    c = dict_merge(a, b)
    assert(c['b']['bb']['bbb'] == 5)
    assert(a['b']['bb']['bba'] == 3)
    assert(c['b']['bb']['bba'] == 3)
    assert(c['d'] == 7)
    assert(c['c']['ca'] == 6)

# Generated at 2022-06-22 21:39:23.782334
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'z': 3}
    b = {'w': 10, 'x': 11, 'y': 2}
    c = {'u': 11, 'v': 12, 'w': 13}
    d = {'x': -1, 'u': 2, 'y': 3, 'z': 4}
    e = {'x': 5, 'u': 6, 'y': 7, 'z': 8}
    f = {'w': 12, 'x': 13, 'y': 14, 'z': 15}
    g = {'x': -1, 'u': 2, 'y': 3, 'z': 4}
    h = {'z': 5}

    result = dict_merge(a, b)

# Generated at 2022-06-22 21:39:31.953615
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(
        a=1,
        b=dict(
            c=1,
            d=2))
    b = dict(
        a=1,
        b=dict(
            c=3))
    merge = dict_merge(a, b)
    assert merge['b']['c'] == 3
    assert merge['b']['d'] == 2
    merge = dict_merge(b, a)
    assert merge['b']['c'] == 1
    assert merge['b']['d'] == 2

# Generated at 2022-06-22 21:39:43.768562
# Unit test for function dict_merge
def test_dict_merge():

    should_be_simple_flat_dict = {
        "a": 1,
        "b": 2,
        "c": 3
    }

    simple_flat_dict = {
        "a": 1,
        "c": 3,
        "b": 2,
    }

    assert dict_merge(simple_flat_dict, {}) == simple_flat_dict
    assert dict_merge({}, simple_flat_dict) == simple_flat_dict
    assert dict_merge(simple_flat_dict, simple_flat_dict) == simple_flat_dict
    assert dict_merge(simple_flat_dict, should_be_simple_flat_dict) == simple_flat_dict


# Generated at 2022-06-22 21:39:53.217722
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # test for empty dict
    assert(snake_dict_to_camel_dict({}) == {})

    # test for simple dict
    snake_dict_simple = {'id': 1, 'name': 'test'}
    assert(snake_dict_to_camel_dict(snake_dict_simple) == {'id': 1, 'name': 'test'})

    # test for complex dict
    snake_dict_complex = {
            'id': 1,
            'name': 'test',
            'tags': {
                'tag1': 'tag1',
                'tag2': 'tag2'
            }
        }

# Generated at 2022-06-22 21:40:01.951047
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2}
    dict11 = {'a': 1, 'b': 2, 'c': 3}
    dict3 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = {'a': 1, 'b': 9}
    dict4 = {'a': 1, 'b': 9}
    dict5 = {'a': 1, 'b': 9, 'd': 10}
    dict6 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4}}
    dict7 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 5}}

# Generated at 2022-06-22 21:40:09.654815
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    testDict = {
        "first_key": "first_value",
        "second_key": [
            "second_value",
            "second_second_value"
            ],
        "third_key": {
            "third_value": "third_third_value",
            "fourth_value": "third_fourth_value"
            },
        "fifth_key": [
            { "fifth_value": "fifth_fifth_value" },
            { "sixth_value": "fifth_sixth_value" }
            ]
    }


# Generated at 2022-06-22 21:40:19.895201
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test removing tags
    config = {}
    config['Tags'] = [{"Key": "Name", "Value": "server1"},
                      {"Key": "Env", "Value": "production"}]
    config2 = {}
    config2['Tags'] = [{"Key": "Name", "Value": "server1"},
                       {"Key": "Env", "Value": "staging"}]
    diffs = recursive_diff(config, config2)
    assert diffs == ({'Tags': [{'Value': 'production', 'Key': 'Env'}, {'Value': 'staging', 'Key': 'Env'}]},
                     {'Tags': [{'Value': 'production', 'Key': 'Env'}, {'Value': 'staging', 'Key': 'Env'}]})

    # Test modifying tags
    config

# Generated at 2022-06-22 21:40:31.820105
# Unit test for function recursive_diff
def test_recursive_diff():
    def test_case(dict1, dict2, expected):
        if not all((isinstance(item, MutableMapping) for item in (dict1, dict2, expected))):
            raise TypeError("Unable to test 'dict1' %s, 'dict2' %s and 'expected' %s. "
                            "All three must be a dictionary." % (type(dict1), type(dict2), type(expected)))
        result = recursive_diff(dict1, dict2)
        assert result == expected, "Expected '%s', got '%s'" % (expected, result)
    test_case({'a': 1, 'b': 2}, {'a': 1, 'b': 2}, None)
    test_case({'a': 1, 'b': 2}, {'a': 1}, ({'b': 2}, None))