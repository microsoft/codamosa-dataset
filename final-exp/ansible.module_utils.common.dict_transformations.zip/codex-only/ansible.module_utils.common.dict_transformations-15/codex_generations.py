

# Generated at 2022-06-22 21:30:37.249513
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'CamelDict': {
            'CamelList': [
                {
                    'CamelKey': 'CamelValue',
                    'CamelDict': {
                        'CamelKey': 'CamelValue',
                    },
                },
            ],
            'CamelKey': 'CamelValue',
            'Tags': {
                'Key': 'Value'
            },
        },
        'CamelList': [
            {
                'CamelKey': 'CamelValue',
            },
        ],
    }
    # Default case, reversible=False

# Generated at 2022-06-22 21:30:48.551348
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Testing simple conversions
    assert camel_dict_to_snake_dict({'camelCase': 'value'}) == {'camel_case': 'value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}) == {'h_t_t_p_endpoint': 'value'}

    # Test that dicts can be converted within dicts
    assert camel_dict_to_snake_dict({'camelCase': 'value', 'listVar': [{'camelCase': 'value'}]}) == {
        'camel_case': 'value',
        'list_var': [{'camel_case': 'value'}],
    }

    # Test that list values are not converted

# Generated at 2022-06-22 21:30:58.670077
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': {'b': 1, 'c': 2}}
    dict2 = {'a': {'b': 0, 'c': 3}}
    dict3 = {'a': {'b': 0, 'c': 3, 'd': 4}}

    dict1_merge_dict2 = {'a': {'b': 0, 'c': 3}}
    dict1_merge_dict3 = {'a': {'b': 0, 'c': 3, 'd': 4}}

    assert dict_merge(dict1, dict2) == dict1_merge_dict2
    assert dict_merge(dict1, dict3) == dict1_merge_dict3


# Generated at 2022-06-22 21:31:10.225045
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(one=1, two=2, three=dict(four=44, five=55), six=dict(seven=77, eight=88))
    b = dict(three=dict(four=444, ten=1010), eleven=11)

    dict_merge(a, b)
    assert(a['one'] == 1)
    assert(a['two'] == 2)
    assert(a['three']['four'] == 444)
    assert(a['three']['five'] == 55)
    assert(a['three']['ten'] == 1010)
    assert(a['six']['seven'] == 77)
    assert(a['six']['eight'] == 88)
    assert(a['eleven'] == 11)

    # this is for the case when the user defines c as a = dict().

# Generated at 2022-06-22 21:31:17.435172
# Unit test for function recursive_diff
def test_recursive_diff():
    # Basic usage
    assert recursive_diff({'data1': 'foo', 'data2': 'bar'}, {'data1': 'foo'}) == ({'data2': 'bar'}, {})
    assert recursive_diff({'data1': 'foo', 'data2': 'bar'}, {'data2': 'baz'}) == ({'data2': 'bar'}, {'data2': 'baz'})
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'data1': 'foo'}, {'data1': 'foo'}) is None
    assert recursive_diff({'data1': 'foo'}, {}) == ({'data1': 'foo'}, {})
    assert recursive_diff({}, {'data1': 'foo'}) == ({}, {'data1': 'foo'})

    # Wrong

# Generated at 2022-06-22 21:31:22.949824
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    import sys
    module = __import__(__name__)
    sys.modules[__name__] = module

    result = snake_dict_to_camel_dict({"target_group_arns": ["foo:bar:123"]})
    assert result == {"TargetGroupArns": ["foo:bar:123"]}

    result = snake_dict_to_camel_dict({"target_group_arns": ["foo:bar:123"]}, capitalize_first=True)
    assert result == {"TargetGroupArns": ["foo:bar:123"]}

    result = snake_dict_to_camel_dict({"target_group_arns": {"FooBar": "123"}})
    assert result == {"TargetGroupArns": {"fooBar": "123"}}

    result = snake_dict_to_camel_dict

# Generated at 2022-06-22 21:31:34.797737
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {"fargle": "fargle",
                  "fargle_map": {"fargle": "fargle"},
                  "char_list": ["f", "a", "r", "g", "l", "e", ":", " ", "f", "a", "r", "g", "l", "e"],
                  "fargle_list": ["fargle", "fargle"],
                  "fargle_map_list": [{"fargle": "fargle"},
                                      {"fargle": "fargle"}]}

    test_dict = snake_dict_to_camel_dict(snake_dict)
    assert(test_dict['Fargle'] == "fargle")
    assert(test_dict['FargleList'][0] == "fargle")

# Generated at 2022-06-22 21:31:45.627172
# Unit test for function recursive_diff
def test_recursive_diff():
    # region test normal dictionary diff
    a = {'a': 1, 'b': {'c': 1, 'd': {'e': 1, 'f': 2, 'g': 2}}}
    b = {'a': 1, 'b': {'c': 1, 'd': {'e': 1, 'f': 1}}}
    expected_result = ({'b': {'d': {'f': 2, 'g': 2}}}, {'b': {'d': {'f': 1}}})
    assert expected_result == recursive_diff(a, b)
    # endregion

    # region test when one of the dictionary is None
    a = {'a': 1, 'b': {}}
    b = None
    expected_result = a
    assert expected_result == recursive_diff(a, b)[0]
    # end

# Generated at 2022-06-22 21:31:52.299174
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    d = {'test_snake_case': {'test_snake_case_2': {
            'test_list': [{'test_snake_case': 'value'}]}}}
    camel_d = {'testSnakeCase': {'testSnakeCase2': {
            'testList': [{'testSnakeCase': 'value'}]}}}
    c = snake_dict_to_camel_dict(d)
    assert c == camel_d


# Generated at 2022-06-22 21:31:59.115156
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({
        'foo_bar': {'bar_baz': 'baz'},
        'something_else': 'else',
        'foo_bar_baz': {'some_list': [{'foo': 'bar'}]},
    }) == {
        'fooBar': None,
        'somethingElse': 'else',
        'fooBarBaz': {'someList': [{'foo': 'bar'}]},
    }



# Generated at 2022-06-22 21:32:10.839904
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {1: {1: {1: {1: {1: {1: {1: 2}}}}}, 2: 5, 3: 8}, 2: {1: {1: {1: {1: {1: {1: 2}}}}}, 2: 5, 3: 9}, 3: {1: {1: {1: {1: {1: {1: 2}}}}}, 2: 5, 3: 10}}

# Generated at 2022-06-22 21:32:16.092445
# Unit test for function recursive_diff
def test_recursive_diff():
    # Nothing changes
    old = dict(one=dict(i=dict(first=1), ii=1), two=dict(peas=2))
    new = dict(one=dict(i=dict(first=1), ii=1), two=dict(peas=2))
    assert recursive_diff(old, new) is None
    # Changed value
    old = dict(one=dict(i=dict(first=1), ii=1), two=dict(peas=2))
    new = dict(one=dict(i=dict(first=1), ii=1), two=dict(peas=3))
    assert recursive_diff(old, new) == (dict(), dict(two=dict(peas=3)))
    # Added key

# Generated at 2022-06-22 21:32:28.018286
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:32:34.140537
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    from pprint import pprint
    pprint(a)
    pprint(b)
    pprint(dict_merge(a, b))
    pprint(a)
    pprint(b)

# Generated at 2022-06-22 21:32:44.983896
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    data =  { "parameters": [ { "type": "String", "defaultValue": "", "maxLength": 1024, "minLength": 0, "name": "some_string" }, { "type": "Number", "defaultValue": 0, "maxValue": 100, "minValue": 0, "name": "some_int" }, { "type": "List", "defaultValue": [], "maxLength": 5, "minLength": 0, "name": "some_list" }, { "type": "Json", "defaultValue": {}, "name": "some_json" } ], "resourceLogicalId": "SnsTopicLambdaPermission", "type": "AWS::SNS::Topic", "dependsOn": [ "SnsTopic" ] }
    converted_data = snake_dict_to_camel_dict(data)

# Generated at 2022-06-22 21:32:54.093929
# Unit test for function dict_merge
def test_dict_merge():

    def assert_merge_result(result, expected):
        assert_res = result == expected
        msg = "\nresult:\t\t%s\nexpected:\t%s" % (result, expected)
        assert assert_res, msg


# Generated at 2022-06-22 21:33:01.142025
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': 1, 'c': 2}}
    b = {'a': {'c': 3, 'd': 4}, 'e': 5}
    c = dict_merge(a, b)

    assert c['a']['b'] == 1
    assert c['a']['c'] == 3
    assert c['a']['d'] == 4
    assert c['e'] == 5



# Generated at 2022-06-22 21:33:07.982619
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    def check_dict(expected, returned):
        assert len(expected) == len(returned)
        for item in expected:
            assert expected[item] == returned[item]

    test_dict = {"FindType": "ByName",
                 "SortOrder": "Ascending",
                 "MaxResults": 10,
                 "NextToken": "token",
                 "Filters": [{"Name": "string",
                              "Values": [
                                  "string"
                              ]}]}


# Generated at 2022-06-22 21:33:19.489033
# Unit test for function recursive_diff
def test_recursive_diff():
    # Empty
    assert recursive_diff({}, {}) is None
    # Both sides of comparison
    assert recursive_diff({'a': 'a', 'b': 'b'}, {'a': 'c', 'b': 'b'}) == ({'a': 'a'}, {'a': 'c'})
    # Left side gets None
    assert recursive_diff({'a': None, 'b': 'b'}, {'a': 'c', 'b': 'b'}) == ({'a': None}, {'a': 'c'})
    # Left side
    assert recursive_diff({'a': 'b', 'c': 'd'}, {}) == ({'a': 'b', 'c': 'd'}, {})
    # Right side
    assert recursive_diff({}, {'a': 'b', 'c': 'd'})

# Generated at 2022-06-22 21:33:27.684947
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar_baz': 1}) == {'fooBarBaz': 1}
    assert snake_dict_to_camel_dict({'foo_bar_baz': 1}, capitalize_first=True) == {'FooBarBaz': 1}
    assert snake_dict_to_camel_dict({'foo_bar': {'foo_baz': 1}}) == {'fooBar': {'fooBaz': 1}}
    assert snake_dict_to_camel_dict({'foo_bar': [1, 2, 3]}) == {'fooBar': [1, 2, 3]}

# Generated at 2022-06-22 21:33:38.625248
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dic = {
           'author': 'Evan Limanto',
           'title': 'AWS SDK for Python',
           'description': 'A Python wrapper for the official Amazon Web Services (AWS) SDK',
           'url': 'https://github.com/boto/boto',
           'license': 'MIT',
           'keywords': ['aws', 'boto', 'ec2', 's3', 'cloudformation', 'cloudwatch'],
           'version': '2.36.0'
           }


# Generated at 2022-06-22 21:33:50.339286
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert dict_merge({'a': 1}, {'a': 2}) == {'a': 2}
    assert dict_merge({'a': 1, 'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}
    assert dict_merge({'a': {'c': 1, 'd': 2}, 'b': 2}, {'a': {'d': 3}}) == {'a': {'c': 1, 'd': 3}, 'b': 2}

# Generated at 2022-06-22 21:33:55.796597
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': 1}, 'c': 1, 'e': {'z': 1}}
    b = {'a': {'c': 2}, 'c': 3, 'e': {'w': 2}}
    c = {'a': {'b': 1, 'c': 2}, 'c': 3, 'e': {'w': 2, 'z': 1}}
    assert dict_merge(a, b) == c

# Generated at 2022-06-22 21:34:02.814629
# Unit test for function dict_merge
def test_dict_merge():

    a = {'key1': 'value1', 'key2': {'key3': 'value3', 'key4': 'value4'}}

    b = {'key4': 'value4_new', 'key5': 'value5'}

    a_merge_b = dict_merge(a, b)

    assert a_merge_b == {'key1': 'value1', 'key2': {'key3': 'value3', 'key4': 'value4'}, 'key5': 'value5'}

    a_merge_b = dict_merge(a, b, True)

    assert a_merge_b == {'key1': 'value1', 'key2': {'key3': 'value3', 'key4': 'value4_new'}, 'key5': 'value5'}

# Generated at 2022-06-22 21:34:11.009591
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'scheduled_task': {
            'task_period': 0,
            'task_type': 'CHECK_RECEIPT'
        },
        'label': 'TaskChecksReceipt',
        'name': 'Check receipt'
    }

    dict2 = {
        'scheduled_task': {
            'task_period': 12,
            'task_type': 'CHECK_RECEIPT',
            'task_args': {
                'by_page': True
            }
        },
        'label': 'TaskChecksReceipt',
        'name': 'Check receipt'
    }

# Generated at 2022-06-22 21:34:20.512572
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        'foo': 'bar',
        'Foo': 'Bar',
        'fooBar': {
            'fooBarBaz': 'Quux'
        },
        'HTTPEndpoint': 'Not_reversible',
        'HTTPEndpoints': 'Not_reversible',
        'fooBarBaz': {
            'HTTPEndpoint': 'Reversible'
        },
        'fooBarBazHTTPEndpoint': 'Not_reversible',
        'fooBarBazHTTPEndpoints': 'Not_reversible',
        'targetGroups': [
            {
                'TargetGroupArn': "foo",
                'TargetGroupName': "bar"
            }
        ]
    }

# Generated at 2022-06-22 21:34:23.870504
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {
        'Bucket': 'foo',
        'Key': 'bar',
        'Delete': {
            'Objects': [],
            'Quiet': True
        }
    }
    assert camel_dict_to_snake_dict(data) == {
        'bucket': 'foo',
        'key': 'bar',
        'delete': {
            'objects': [],
            'quiet': True
        }
    }

# Generated at 2022-06-22 21:34:34.415484
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'test_little_camel_dict': [{'test_propA': 'value1',
                                              'test_propB': 'value2',
                                              'test_propC': ['value3', 'value4', 'value5']},
                                             {'test_propA': 'value6',
                                              'test_propB': 'value7',
                                              'test_propC': ['value8', 'value9', 'value10']}],
                   'test_propD': {'test_propE': {'test_propF': 'value11'},
                                  'test_propG': 'value12'}}

    camel_dict = snake_dict_to_camel_dict(snake_dict)
    # Assert that only the first character has been camelized
    assert camel

# Generated at 2022-06-22 21:34:47.555978
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:34:58.439294
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for 'should not convert keys of tags'
    input_dict = {'NoPSN': {'tags': {'Key2': 'Value2', 'Key1': 'Value1'}}}
    expected_dict = input_dict
    assert camel_dict_to_snake_dict(input_dict) == expected_dict

    # Test for 'should convert all keys of tags'
    input_dict = {'NoPSN': {'Tags': {'Key2': 'Value2', 'Key1': 'Value1'}}}
    expected_dict = {'noPSN': {'tags': {'Key2': 'Value2', 'Key1': 'Value1'}}}
    assert camel_dict_to_snake_dict(input_dict) == expected_dict

    # Test for 'should convert all keys of tags with snaked ones'
   

# Generated at 2022-06-22 21:35:08.561626
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({
        'foo_bar': {
            'foobar': 'foobar',
            'foo_bar_list': [
                'foo_bar',
                {
                    'foobar': 'foobar'
                }
            ],
            'foo_bar_dict': {
                'foo_bar': {
                    'foobar': 'foobar'
                }
            }
        }
    }) == {
        'fooBar': {
            'foobar': 'foobar',
            'fooBarList': [
                'foo_bar',
                {
                    'foobar': 'foobar'
                }
            ],
            'fooBarDict': {
                'fooBar': {
                    'foobar': 'foobar'
                }
            }
        }
    }


# Generated at 2022-06-22 21:35:18.526956
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test when there are no differences
    assert recursive_diff({'test1': 'test1', 'test2': 'test2'},
                          {'test1': 'test1', 'test2': 'test2'}) is None
    # Test for difference in case of key
    assert recursive_diff({'test1': {'test11': 'test11'}},
                          {'TEST1': {'test11': 'test11'}}) == ({'test1': {'test11': 'test11'}},
                                                               {'TEST1': {'test11': 'test11'}})
    # Test for difference in case of value

# Generated at 2022-06-22 21:35:28.328957
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Test with a basic dict
    data = {
        "describe_instances": {
            "next_token": "some_token"
        }
    }
    result = snake_dict_to_camel_dict(data)
    assert result == {"DescribeInstances": {"NextToken": "some_token"}}

    # Test with a nested dict
    data = {
        "describe_instances": {
            "next_token": "some_token",
            "details": {
                "instance_details": "some_details",
                "instance_name": "some_name"
            }
        }
    }
    result = snake_dict_to_camel_dict(data)

# Generated at 2022-06-22 21:35:38.108736
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test cases
    # Test 1: Empty case
    data1 = {}
    data2 = {}
    # Test 2: Same key and values
    data3 = {'c1': 'val1'}
    data4 = {'c1': 'val1'}
    # Test 3: Different key and values
    data5 = {'c1': 'val1'}
    data6 = {'c1': 'val2'}
    # Test 4: Same keys but different values :
    data7 = {'c1': 'val1'}
    data8 = {'c1': 1}
    # Test 5: Same keys but different dictionary values
    data9 = {'c1': {'c11': 'val11'}}
    data10 = {'c1': {'c11': 'val21'}}
    # Test

# Generated at 2022-06-22 21:35:49.342488
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    def is_string(d):
        if isinstance(d, str) or isinstance(d, unicode):
            return True
        return False

    def is_dict(d):
        if isinstance(d, dict):
            return True
        return False

    def is_list(d):
        if isinstance(d, list):
            return True
        return False

    def test_conversions(dict_a, dict_b):
        assert is_dict(dict_a) == is_dict(dict_b)

        if is_dict(dict_a):
            for k, v in dict_a.items():
                if is_dict(dict_b) and k in dict_b:
                    test_conversions(v, dict_b[k])

# Generated at 2022-06-22 21:35:58.296792
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:06.506001
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'x': 1, 'y': 2, 'z': 3}, 'b': {'x': 1, 'y': 2, 'z': 3}, 'c': 3}
    b = {'a': {'w': 4}, 'c': {'w': 4}, 'd': 5}
    c = dict_merge(a, b)
    assert c == {'a': {'w': 4, 'x': 1, 'y': 2, 'z': 3}, 'b': {'x': 1, 'y': 2, 'z': 3}, 'c': {'w': 4}, 'd': 5}
    b = {'a': {'w': None}, 'c': {'w': 4}, 'd': 5}
    c = dict_merge(a, b)

# Generated at 2022-06-22 21:36:18.333992
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Foo': 'bar',
        'camelList': [
            'Camel',
            'List'
        ],
        'HTTPEndpoint': {
            'path': '/foo',
            'port': '80',
        },
        'Tags': {
            'Key': 'Value',
            'foo': ['bar', 'baz']
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict, False)

# Generated at 2022-06-22 21:36:30.332796
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test function recursive_diff"""

    # Test arguments are not dictionaries
    bad_args = ('foo', 'bar')
    for bad_arg in bad_args:
        try:
            assert(recursive_diff(bad_arg, bad_arg) is None)
        except TypeError:
            pass

    # Test dictionary arguments are not the same

# Generated at 2022-06-22 21:36:38.379672
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for the recursive_diff function
    """
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2}, 'f': 3}
    dict2 = {'a': 1, 'b': 3, 'c': {'d': 1, 'e': 3}, 'h': 1}
    dict3 = {'a': 1, 'c': {'d': 1, 'e': 3}, 'h': 1}
    dict4 = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2}, 'f': 3}
    dict5 = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2, 'f': 3}, 'f': 3}

# Generated at 2022-06-22 21:36:49.395782
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_camel_dict = {
        'HTTPEndpoint': 'foo',
        'HTTPSEndpoint': 'bar',
        'TCPEndpoint': 'baz',
        'UDPSource': 'qux',
        'Tags': {
            'TagKey': 'quux',
            'TagValue': 'corge'
        },
        "TagList": [
            {
                'Key': 'grault',
                'Value': 'garply'
            },
            {
                'Key': 'Type',
                'Value': 'Stateful'
            }
        ]
    }


# Generated at 2022-06-22 21:36:57.630471
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1, 'c': 3, 'd': 4}, 'b': 2, 'c': 3, 'd': {'a': 1, 'b': 2}}
    d2 = {'a': {'b': 4, 'e': 5}, 'b': 1, 'c': 5, 'd': {'g': 12}}
    expected = {'a': {'b': 4, 'c': 3, 'd': 4, 'e': 5}, 'b': 1, 'c': 5, 'd': {'a': 1, 'b': 2, 'g': 12}}
    assert expected == dict_merge(d1, d2)
    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'b': 3, 'd': 4}


# Generated at 2022-06-22 21:37:04.078484
# Unit test for function recursive_diff
def test_recursive_diff():

    # test for empty dict
    assert recursive_diff({}, {}) is None

    # test for single level dict with different keys
    assert recursive_diff({'a': 'A', 'b': 'B'}, {'b': 'B', 'c': 'C'}) == ({'a': 'A'}, {'c': 'C'})

    # test for first level dict with same keys but different values
    assert recursive_diff({'a': 'A', 'b': 'B'}, {'b': 'B', 'a': 'C'}) == ({'a': 'A'}, {'a': 'C'})

    # test for first level dict with same keys and values
    assert recursive_diff({'a': 'A', 'b': 'B'}, {'a': 'A', 'b': 'B'}) is None

    # test for

# Generated at 2022-06-22 21:37:14.635688
# Unit test for function dict_merge
def test_dict_merge():
    # basic
    a = {'a': 1, 'b': 2, 'd': 4, 2: 3}
    b = {'b': 'dog', 'c': 12, 'd': {1: 23}}
    c = dict_merge(a, b)
    assert c == {'a': 1, 'b': 'dog', 'd': {1: 23}, 'c': 12, 2: 3}

    # base
    a = {'a': 1, 'b': 2, 'd': 4, 2: 3}
    b = {'b': 'dog', 'c': 12, 'd': {1: 23}}
    result = dict_merge(a, b)
    assert result == {'a': 1, 'b': 'dog', 'd': {1: 23}, 'c': 12, 2: 3}

   

# Generated at 2022-06-22 21:37:21.724197
# Unit test for function dict_merge
def test_dict_merge():
    assert {'a': 1} == dict_merge({'a': 1}, {})
    assert {'a': 1} == dict_merge({}, {'a': 1})
    assert {'a': 1, 'b': 2} == dict_merge({'a': 1}, {'b': 2})
    assert {'a': 1, 'b': 2} == dict_merge({'b': 2}, {'a': 1})
    assert {'a': {'b': 1}} == dict_merge({'a': {'b': 1}}, {})
    assert {'a': {'b': 1}} == dict_merge({}, {'a': {'b': 1}})

# Generated at 2022-06-22 21:37:30.209164
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'Name': 'CamelCase',
                  'isCamel': True,
                  'LowerCase': False,
                  'randomCase': 'random',
                  # Note, we convert the 'Tags' key but nothing below.
                  'Tags':
                      [{'Key': 'Name',
                        'Value': 'CamelCase'},
                       {'Key': 'isCamel',
                        'Value': 'True'}]
                  }


# Generated at 2022-06-22 21:37:38.777794
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': {'y': 'z'}, 'a': 'b'}
    b = {'t': {'u': 'v'}, 'u': {'u': 'v'}, 'a': 'b'}
    c = dict_merge(a, b)
    assert c['a'] == 'b'
    assert c['t'] == {'u': 'v'}
    assert c['u'] == {'u': 'v'}
    assert c['x']['y'] == 'z'



# Generated at 2022-06-22 21:37:50.039387
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:38:00.339386
# Unit test for function recursive_diff
def test_recursive_diff():
    # list of test cases
    testcase = [
        # test if both arguments are empty dictionaries
        ({}, {}, None),
        # test if one argument is empty dictionary
        ({'a': 'b'}, {}, ({'a': 'b'}, {})),
        # test if there is no difference in the dictionaries
        ({'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'd'}, None),
    ]

    # Add testcases to check if the dictionaries have any differences
    #   1. The key is present in only one of the dictionaries
    #   2. The key is present in both the dictionaries but associated with
    #      different values
    #   3. The key is present in both the dictionaries and associated with
    #      same value but the value is one of the dictionary

# Generated at 2022-06-22 21:38:07.283312
# Unit test for function dict_merge
def test_dict_merge():
    a = {"Key1": "Value1", "Key2": "Value2", "Key3": "Value3"}
    b = {"Key1": "NewValue1", "Key4": "NewValue4"}

    c = dict_merge(a,b)

    assert c == {"Key1": "NewValue1", "Key2": "Value2", "Key3": "Value3", "Key4": "NewValue4"}



# Generated at 2022-06-22 21:38:18.382497
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': 2}
    d2 = {'c': 3, 'd': 4}
    e1 = {'a': 5, 'b': 2}
    r1 = dict_merge(d1, d2)
    assert r1 == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    r2 = dict_merge(d2, d1)
    assert r2 == {'c': 3, 'd': 4, 'a': 1, 'b': 2}
    r3 = dict_merge(d1, e1)
    assert r3 == {'a': 5, 'b': 2}
    r4 = dict_merge(e1, d1)
    assert r4 == {'a': 1, 'b': 2}

# Generated at 2022-06-22 21:38:24.794587
# Unit test for function recursive_diff
def test_recursive_diff():
    left_dict = dict(a=5, b=dict(c="hello"), d=dict(e="abcd", g=dict(i=2)))
    right_dict = dict(a=5, b=dict(c="hello"), d=dict(e="abra", g=dict(j=5)))
    assert recursive_diff(left_dict, right_dict) == (dict(d=dict(e="abcd", g=dict(i=2))), dict(d=dict(e="abra", g=dict(j=5))))

# Generated at 2022-06-22 21:38:34.616567
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:38:45.405446
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({1: 1}, {1: 2}) == ({1: 1}, {1: 2})
    assert recursive_diff({1: 1}, {2: 1}) == ({1: 1}, {2: 1})
    assert recursive_diff({1: 1}, {}) == ({1: 1}, {})
    assert recursive_diff({1: 1}, {2: 3}) == ({1: 1}, {2: 3})
    assert recursive_diff({1: {2: 3}}, {1: {2: 3}}) is None
    assert recursive_diff({1: {2: 3}}, {1: {2: 4}}) == (
        {1: {2: 3}},
        {1: {2: 4}}
    )

# Generated at 2022-06-22 21:38:56.615534
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict1 = {
        'KeyOne': 'value',
        'KeyTwo': {
            'KeyThree': 'value',
            'KeyFour': 'value'
        }
    }
    camel_dict2 = {
        'KeyOne': 'value',
        'KeyTwo': {
            'KeyThree': 'value',
            'KeyFour': 'value'
        },
        'Key_Five': 'value'
    }
    camel_dict3 = {
        'KeyOne': 'value',
        'KeyTwo': {
            'KeyThree': 'value',
            'KeyFour': 'value'
        },
        'Key_Five': {
            'keyOne': 'value',
            'keyTwo': 'value'
        }
    }


# Generated at 2022-06-22 21:39:08.325458
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test the recursive_diff function

    Given two dictionaries, test to make sure they are both valid dictionaries
    and perform a recursive_diff to make sure they are the same.

    Arguments:
        dict1: First dictionary to compare
        dict2: Second dictionary to compare
    """

    dict1 = {
        "AWSTemplateFormatVersion": "2010-09-09",
        "Resources": {
            "IAMUser": {
                "Type": "AWS::IAM::User",
                "Properties": {
                    "Path": "/",
                    "Policies": []
                }
            }
        }
    }


# Generated at 2022-06-22 21:39:18.821621
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    orig = {'dict': {'snake_key': 'value'}}
    expected = {'dict': {'snakeKey': 'value'}}
    assert expected == snake_dict_to_camel_dict(orig)

    orig = {'list': [{'snake_key': 'value'}]}
    expected = {'list': [{'snakeKey': 'value'}]}
    assert expected == snake_dict_to_camel_dict(orig)

    orig = {'value': 'value'}
    expected = {'value': 'value'}
    assert expected == snake_dict_to_camel_dict(orig)

    orig = {'dict': {'dict': {'snake_key': 'value'}}}

# Generated at 2022-06-22 21:39:28.942611
# Unit test for function dict_merge
def test_dict_merge():
    """Test dict_merge function"""

    result = dict_merge(
        {
            'foo': 'bar',
            'baz': {
                'fuz': 'fiz',
                'buz': {
                    'biz': 'boz',
                }
            }
        },
        {
            'foo': 'bar2',
            'buz': {
                'biz': 'boz2',
            }
        }
    )

    assert result == {
        'foo': 'bar2',
        'baz': {
            'fuz': 'fiz',
            'buz': {
                'biz': 'boz2',
            }
        }
    }



# Generated at 2022-06-22 21:39:36.412537
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:39:47.490821
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({'foo': 'bar'}) == {'foo': 'bar'}
    assert snake_dict_to_camel_dict({'foo': 'bar', 'baz': 'qux'}) == {'foo': 'bar', 'baz': 'qux'}
    assert snake_dict_to_camel_dict({'foo': 'bar', 'qux': {'quux': 'quuux'}}) == {'foo': 'bar', 'qux': {'quux': 'quuux'}}

# Generated at 2022-06-22 21:39:57.911176
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'access_key_id': 'test',
        'secret_access_key': 'test',
        'security_token': 'test',
        'region': 'test',
        'a_b': 'test',
        'tags': {
            'key': 'value',
            'Name': 'ansible'
        },
        'dictionary': {
            'with': {
                'nested': 'dictionaries'
            }
        }
    }
    test_dict_camel = snake_dict_to_camel_dict(test_dict)

    assert test_dict_camel['secretAccessKey'] == 'test'
    assert test_dict_camel['aB'] == 'test'
    assert test_dict_camel['tags']['Name'] == 'ansible'
   

# Generated at 2022-06-22 21:40:09.502784
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': 'bar', 'k1': 'v1', 'nested': {'a': 'b'}, 'list': ['a', 'b'], 'nested_list': ['a', {'f': 'g'}]}
    b = {'foo': 'bar2', 'k2': 'v2', 'nested': {'c': 'd'}, 'list': 'a', 'nested_list': ['c', {'f': 'g'}]}


# Generated at 2022-06-22 21:40:19.778612
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }, 'unable to merge'
    b = {'second': {'all_rows': {'fail': 'cat', 'number': '5'}}}

# Generated at 2022-06-22 21:40:31.696878
# Unit test for function dict_merge
def test_dict_merge():
    '''Unit test for function dict_merge.
    '''

    # test simple merge
    a = {'x': 1, 'y': 2}
    b = {'y': 3, 'z': 4}
    c = dict_merge(a, b)
    assert c['x'] == 1
    assert c['y'] == 3
    assert c['z'] == 4

    # simple merge but with a list value
    a = {'x': 1, 'y': 2, 'z': [1, 2, 3]}
    b = {'y': 3, 'z': [4, 5, 6]}
    c = dict_merge(a, b)
    assert c['x'] == 1
    assert c['y'] == 3
    assert c['z'] == [4, 5, 6]

    # test nested merge