

# Generated at 2022-06-22 21:30:33.753261
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_test_dict = {
        "test": "Test",
        "test2": {
            "test3": "Test3"
        }
    }

    snake_test_dict = {
        "test": "Test",
        "test_2": {
            "test_3": "Test3"
        }
    }

    assert(camel_dict_to_snake_dict(camel_test_dict) == snake_test_dict)
    assert(snake_dict_to_camel_dict(snake_test_dict) == camel_test_dict)



# Generated at 2022-06-22 21:30:41.607187
# Unit test for function dict_merge
def test_dict_merge():
    A = {'a': 1, 'b': {'b1': 11, 'b2': 12}}

    B = {'c': 3, 'b': {'b1': 13, 'b3': 33, 'b2': 12}, 'd': {'d1': 1}}

    expected = {'a': 1, 'b': {'b1': 13, 'b3': 33, 'b2': 12}, 'd': {'d1': 1}, 'c': 3}

    assert expected == dict_merge(A, B)
    assert expected == dict_merge(B, A)



# Generated at 2022-06-22 21:30:48.211244
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TestKeys': ['A', 'B', 'C'], 'TestBool': True, 'TestInt': 0, 'TestDict': {'CamelKey': 'Value'}}
    snake_dict = {'test_keys': ['A', 'B', 'C'], 'test_bool': True, 'test_int': 0, 'test_dict': {'camel_key': 'Value'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-22 21:30:59.471464
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        "foo_bar_baz": {
            "foo_bar_baz": [
                {
                    "foo_bar_baz": "foobar",
                    "some_key": "some_value"
                },
                {
                    "foo_bar_baz": "foobar",
                    "some_key": "some_value"
                }
            ],
            "some_key": "some_value"
        },
        "some_key": {
            "foo_bar_baz": "foobar",
            "some_key": "some_value"
        }
    }


# Generated at 2022-06-22 21:31:08.350870
# Unit test for function dict_merge
def test_dict_merge():
    a = {'first': '1',
         'class': {
             'a': '1',
             'b': '2'
         }
         }

    b = {'second': '2',
         'class': {
             'c': '3'
         }
         }

    c = dict_merge(a, b)

    assert c == {
        'first': '1',
        'second': '2',
        'class': {
            'a': '1',
            'b': '2',
            'c': '3'
        }
    }

# Generated at 2022-06-22 21:31:16.379077
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test basic case
    camel_source = {"aCamelCaseKey": 10}
    camel_expected = {"a_camel_case_key": 10}
    camel_actual = camel_dict_to_snake_dict(camel_source)
    assert camel_actual == camel_expected

    # Test pluralized abbreviations
    plural_source = {"TargetGroupARNs": ["arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
                                         "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067"]}

# Generated at 2022-06-22 21:31:26.351481
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test equal items and different items
    def test_one_step(dict1, dict2, dict_expected_result):
        result = recursive_diff(dict1, dict2)
        assert result == dict_expected_result, 'Expected result for comparison is %s, test result is %s' % (dict_expected_result, result)

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 4}}
    dict2 = {'a': 1, 'b': 9, 'c': {'d': 4}}
    dict_expected_result = ({'b': 2}, {'b': 9})
    test_one_step(dict1, dict2, dict_expected_result)

    dict1 = {'a': 1, 'c': {'d': 4}}

# Generated at 2022-06-22 21:31:37.155439
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:31:48.044216
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # {"tag:key":"value"} is converted to {"tag_key": "value"}
    tag_key_camel = {"tag:key": "value"}
    tag_key_expected = {"tag_key": "value"}
    assert camel_dict_to_snake_dict(tag_key_camel) == tag_key_expected

    # {"tags":[{"key":"value"}]} is converted to {"tags":[{"key":"value"}]}
    tags_camel = {"tags": [{"key": "value"}]}
    tags_expected = {"tags": [{"key": "value"}]}
    assert camel_dict_to_snake_dict(tags_camel) == tags_expected

    # {"hTTPEndpoint": "value"} is converted to {"h_t_t_p_endpoint": "value"}
    hTTPEndpoint_

# Generated at 2022-06-22 21:31:57.440101
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({'foo_bar': 1}) == {'fooBar': 1}
    assert snake_dict_to_camel_dict({'foo_bar': {'baz_qux': [1, 2]}}) == {'fooBar': {'bazQux': [1, 2]}}
    assert snake_dict_to_camel_dict({'foo_bar': {'baz_qux': [1, 2]}}, capitalize_first=True) == {'FooBar': {'BazQux': [1, 2]}}



# Generated at 2022-06-22 21:32:05.157132
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict((k,v) for (k,v) in enumerate(['a', 'b', 'c']))
    dict2 = dict((k,v) for (k,v) in enumerate(['a', 'b', 'c']))
    result = recursive_diff(dict1, dict2)
    assert result is None, 'No difference between dict1 and dict2'

    dict3 = dict((k,v) for (k,v) in enumerate(['a', 'c', 'b']))
    result = recursive_diff(dict1, dict3)
    assert result is not None, 'dict1 and dict3 differ'
    assert len(result[0]) == 1, 'dict1 and dict3 differ by one key/value'

# Generated at 2022-06-22 21:32:11.546735
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(bunch=dict(of=dict(nested=dict(stuff='value1'))))
    b = dict(bunch=dict(of=dict(nested=dict(stuff='value2'))))
    merged_dict = dict_merge(a, b)
    assert merged_dict == dict(bunch=dict(of=dict(nested=dict(stuff='value2'))))



# Generated at 2022-06-22 21:32:24.360867
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # input_dict1 is a camelized dictionary
    # expected_dict1 is the snake_dict_to_camel_dict equivalent of input_dict1
    input_dict1 = {
        'key1': 1,
        'key2': 2,
        'key3': [
            {'key4': 4},
            {'key5': 5}
        ],
        'key6': {'key7': 7}
    }
    expected_dict1 = {
        'key1': 1,
        'key2': 2,
        'key3': [
            {'key4': 4},
            {'key5': 5}
        ],
        'key6': {'key7': 7}
    }
    assert camel_dict_to_snake_dict(input_dict1) == expected_dict1

# Generated at 2022-06-22 21:32:29.346217
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {
        'this_is_snake': 'value',
        'this_Is_also_snake': 'value',
        'this_iS_NOT_snake': 'value',
        'snake': {
            'site': 'value',
            'this_is_also_snake': 'value',
            'this_Is_not_snake': 'value',
            'this_iS_NOT_snake': 'value',
            'nest': {
                'this_is_snake': 'value'
            }
        },
        'plural_abbreviations': {
            'targetGroupARNs': 'value',
            'arNs': 'value'
        }
    }


# Generated at 2022-06-22 21:32:38.382052
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    a_dict = {'a_key': 'a value', 'a_nested_key': {'a': 'val1',
                                                   'b': 'val2',
                                                   'c': 'val3'},
              'a_nested_list': ['value_1',
                                'value_2']}
    results = snake_dict_to_camel_dict(a_dict)
    assert results['aKey'] == 'a value'
    assert results['aNestedKey']['a'] == 'val1'
    assert results['aNestedKey']['b'] == 'val2'
    assert results['aNestedKey']['c'] == 'val3'
    assert results['aNestedList'][0] == 'value_1'
    assert results['aNestedList'][1]

# Generated at 2022-06-22 21:32:43.597255
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {
        'this_is_an_entry': {
            'A_list': [
                'list_item0',
                'list_item1',
                'list_item2',
            ],
            'key2': 'value2',
            'key3': 'value3',
        },
        'key4': 'value4',
    }
    expected_dict = {
        'ThisIsAnEntry': {
            'aList': [
                'list_item0',
                'list_item1',
                'list_item2',
            ],
            'key2': 'value2',
            'key3': 'value3',
        },
        'key4': 'value4',
    }
    assert snake_dict_to_camel_dict(test_dict) == expected_dict




# Generated at 2022-06-22 21:32:51.025050
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
      'a': '1',
      'b': {
        'c': '4',
        'd': '5',
        'e': '6'
      },
      'f': {
        'g': '7',
      }
    }

    dict2 = {
      'a': '1',
      'b': {
        'c': '2',
        'd': '3',
        'e': '6'
      },
      'f': {
        'h': '8',
      }
    }


# Generated at 2022-06-22 21:33:03.293161
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': 1}, 'c': 3}
    dict1_old = dict(dict1)
    dict2 = {'a': {'b': 2}, 'c': 3}
    dict2_old = dict(dict2)
    res = recursive_diff(dict1, dict2)
    assert res
    assert 'a' in res[0]
    assert 'a' in res[1]
    assert 'b' in res[0]['a']
    assert 'b' in res[1]['a']
    assert res[0]['a']['b'] == 1
    assert res[1]['a']['b'] == 2

    dict1 = {'a': {'b': 1, 'c': 3}, 'c': 3}

# Generated at 2022-06-22 21:33:08.598247
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'FooBar': 'baz', 'aArray': ['foo', 'bar'], 'bDict': {'foo': 'bar'}} == snake_dict_to_camel_dict({'foo_bar': 'baz', 'a_array': ['foo', 'bar'], 'b_dict': {'foo': 'bar'}})

# Generated at 2022-06-22 21:33:19.986645
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert {'firstName': 'Fred', 'lastName': 'Flintstone'} == snake_dict_to_camel_dict({'first_name': 'Fred', 'last_name': 'Flintstone'})
    assert {'firstName': 'Fred', 'lastName': 'Flintstone'} == snake_dict_to_camel_dict({'first_name': 'Fred', 'last_name': 'Flintstone'}, capitalize_first=True)
    assert {'FirstName': 'Fred', 'LastName': 'Flintstone'} == snake_dict_to_camel_dict({'FirstName': 'Fred', 'LastName': 'Flintstone'})

# Generated at 2022-06-22 21:33:28.002131
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {'a': '1', 'b': {'b1': 'b1', 'b2': 'b2'}, 'c': ['1', '2']}
    dict2 = {'a': '1', 'b': {'b1': 'b1', 'b2': 'b2'}, 'c': ['1', '2', '3']}
    assert recursive_diff(dict1, dict2) == \
        (dict(), {'c': ['1', '2', '3']})

    dict1 = {'a': '1', 'b': '2', 'c': ['1', '2']}
    dict2 = {'a': '1', 'b': '3', 'c': ['1', '2', '3']}

# Generated at 2022-06-22 21:33:38.383777
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1, 'b': 2, 'c': 3}, {'b': 4, 'd': 5, 'e': 6}) == ({'a': 1, 'c': 3}, {'b': 4, 'd': 5, 'e': 6})
    assert recursive_diff({'a': 1, 'e': 2}, {'b': 4, 'd': 5, 'e': 2}) == ({'a': 1}, {'b': 4, 'd': 5})
    assert recursive_diff({'a': {'b': 1, 'c': 3}, 'd': 4}, {'a': {'b': 1, 'c': 2}, 'd': 4}) == ({'a': {'c': 3}}, {'a': {'c': 2}})

# Generated at 2022-06-22 21:33:44.462205
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'a': 1, 'b': 2, 'c': 3}
    b = {'a': 1, 'b': 2, 'c': 4}
    # No diff, empty tuple
    assert recursive_diff(a, a) == None
    assert recursive_diff(b, b) == None
    assert recursive_diff(a, b) == ({'c': 3}, {'c': 4})
    assert recursive_diff(b, a) == ({'c': 4}, {'c': 3})
    a = {'a': {'a1': 1, 'a2': 2}}
    b = {'b': {'b1': 1, 'b2': 2}}

# Generated at 2022-06-22 21:33:54.979239
# Unit test for function dict_merge
def test_dict_merge():

    # Test a merge where some values are nested dicts and some are the same
    a = {'one': '1', 'two': '2', 'three': {'three_one': 'three_1', 'three_two': 'three_2'},
         'four': {'four_one': 'four_1', 'four_two': 'four_2'}, 'five': '5'}
    b = {'one': '1', 'two': '2', 'three': {'three_one': 'three_1', 'three_two': 'three_2'},
         'four': {'four_one': 'four_1', 'four_two': 'four_2'}, 'five': '5'}
    assert a == b

    # Test a merge where all values are the same

# Generated at 2022-06-22 21:34:01.786919
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {'subnetIds': ['subnet-1', 'subnet-2'],
                 'Tags': [{'Key': 'abc', 'Value': 'def'},
                          {'Key': 'ghi', 'Value': 'jkl'}]}

    result = camel_dict_to_snake_dict(test_dict, reversible=True)

    assert result == {'subnet_ids': ['subnet-1', 'subnet-2'], 'tags': [{'key': 'abc', 'value': 'def'}, {'key': 'ghi', 'value': 'jkl'}]}



# Generated at 2022-06-22 21:34:10.357604
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel = {
        "HTTPCookie": {
            "Name": "MyCookie",
            "Value": "MyValue",
            "Path": "/path/to/resource"
        },
        "HTTPHeader": {
            "Name": "X-Amz-Security-Token",
            "Value": "AQoDYXdzEMr..."
        },
    }
    snake = {
        "http_cookie": {
            "name": "MyCookie",
            "value": "MyValue",
            "path": "/path/to/resource"
        },
        "http_header": {
            "name": "X-Amz-Security-Token",
            "value": "AQoDYXdzEMr..."
        },
    }

# Generated at 2022-06-22 21:34:20.357778
# Unit test for function recursive_diff
def test_recursive_diff():
    result = None
    assert recursive_diff({}, {}) == result
    assert recursive_diff({'k1': 'v1'}, {}) == ({'k1': 'v1'}, {})
    assert recursive_diff({}, {'k1': 'v1'}) == ({}, {'k1': 'v1'})
    assert recursive_diff({'k1': 'v1'}, {'k1': 'v1'}) == result
    assert recursive_diff({'k1': 'v1'}, {'k1': 'v2'}) == ({'k1': 'v1'}, {'k1': 'v2'})

# Generated at 2022-06-22 21:34:25.713564
# Unit test for function dict_merge
def test_dict_merge():
    d1 = { 'a' : 1, 'b' : 2, 'c' : { 'a' : 1, 'b' : 2, 'c' : { 'a' : 1, 'b' : 2 } } }
    d2 = { 'a' : 3, 'c' : { 'a' : 3, 'c' : { 'a' : 3 } } }

    d3 = dict_merge(d1, d2)
    assert d3['a'] == 3
    assert d3['b'] == 2
    assert d3['c']['a'] == 3
    assert d3['c']['b'] == 2
    assert d3['c']['c']['a'] == 3
    assert d3['c']['c']['b'] == 2

# Generated at 2022-06-22 21:34:34.782371
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """Test snake_dict_to_camel_dict logic"""
    my_dict = {"snake_case": "value", "camelCase": "value", "AlreadyCamelized": "value"}
    assert my_dict == snake_dict_to_camel_dict(snake_dict_to_camel_dict(my_dict, capitalize_first=True), True)
    assert "CamelCase" == snake_dict_to_camel_dict(my_dict, True)["CamelCase"]
    assert "camelCase" == snake_dict_to_camel_dict(my_dict, False)["camelCase"]
    assert "AlreadyCamelized" == snake_dict_to_camel_dict(my_dict, False)["AlreadyCamelized"]

# Generated at 2022-06-22 21:34:44.554173
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = {"subnet_id": "subnet-id", "subnet_list": ["subnet-id-1", "subnet-id-2"]}
    expected_dict = {"subnetId": "subnet-id", "subnetList": ["subnet-id-1", "subnet-id-2"]}
    actual_dict = snake_dict_to_camel_dict(input_dict)
    assert(actual_dict == expected_dict)

# Generated at 2022-06-22 21:34:54.468534
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Testing snake_dict_to_camel_dict and camel_dict_to_snake_dict round trip:
    input_dict = {"testCase": "testCaseData", "testCase1": "testCaseData1"}
    assert(snake_dict_to_camel_dict(camel_dict_to_snake_dict(input_dict)) == input_dict)

    # Testing snake_dict_to_camel_dict and camel_dict_to_snake_dict round trip:
    input_dict = {"test_case": "test_case_data", "test_case1": "test_case_data1"}
    assert(camel_dict_to_snake_dict(snake_dict_to_camel_dict(input_dict)) == input_dict)

    # Testing snake_dict_to_camel

# Generated at 2022-06-22 21:35:05.526133
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Checking if snake_dict_to_camel_dict function works with dictionaries and list
    """
    test_dict = {
        "test_snake_case_key": "test_value",
        "test_snake_list": [
            "test_list_value",
            "test_list_value_1"
        ],
        "test_snake_dict": {
            "test_nested_dict_key": "test_nested_dict_value"
        },
        "test_snake_nested_list": [
            "test_nested_list_value",
            "test_nested_list_value_1",
            {
                "test_nested_list_dict_key": "test_nested_list_dict_value"
            }
        ]
    }



# Generated at 2022-06-22 21:35:15.177677
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:35:23.640911
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:35:33.030431
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = {
        "param1": "insert",
        "param2": {
            "param3": "insert",
            "param4": "insert"
        },
        "param5": "insert"
    }
    dict_b = {
        "param1": "insert",
        "param2": {
            "param3": "update",
            "param4": "insert"
        },
        "param5": "remove"
    }
    expected_diff = ({'param2': {'param3': 'insert'}}, {'param2': {'param3': 'update'}, 'param5': 'remove'})
    assert(recursive_diff(dict_a, dict_b) == expected_diff)

# Generated at 2022-06-22 21:35:43.487840
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test None
    assert recursive_diff(None, None) is None

    # Test Non-dictionary
    try:
        recursive_diff("", "")
    except TypeError:
        assert True
    else:
        assert False

    # Test dictionary arguments
    assert recursive_diff({"A": 1}, {}) == ({'A': 1}, {})
    assert recursive_diff({}, {"B": 2}) == ({}, {'B': 2})
    assert recursive_diff({"A": 1}, {"B": 2}) == ({'A': 1}, {'B': 2})
    assert recursive_diff({"A": 1}, {"A": 2}) == ({'A': 1}, {'A': 2})
    assert recursive_diff({"A": {"B": [1, 2]}}, {"A": {"B": [3, 4]}})

# Generated at 2022-06-22 21:35:48.078541
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test: recursive_diff()"""
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.basic import AnsibleModule

    if not isinstance(recursive_diff({"a": 2}, {"a": 1}), tuple):
        AnsibleModule.fail_json(msg="recursive_diff() did not return tuple")



# Generated at 2022-06-22 21:35:56.744410
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'foo': 'bar',
        'inner': {
            'fizz': 'buzz',
            'list': [1, 2, 3],
        },
    }
    b = {
        'foo': 'overridden',
        'inner': {
            'list2': [4, 5, 6],
        },
    }
    expected_result = {
        'foo': 'overridden',
        'inner': {
            'fizz': 'buzz',
            'list': [1, 2, 3],
            'list2': [4, 5, 6],
        },
    }
    result = dict_merge(a, b)
    assert result == expected_result

# Generated at 2022-06-22 21:36:05.153714
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:15.273339
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': {'b': 1, 'c': 2}}, {'a': {'b': 2, 'c': 3}}) == ({'a': {'b': 1}}, {'a': {'b': 2, 'c': 3}})
    assert recursive_diff({'a': {'b': {'d': 1, 'e': 2}, 'c': 2}}, {'a': {'b': {'d': 1}, 'c': 2}}) == ({'a': {'b': {'e': 2}}}, {'a': {'b': {}}})
    assert recursive_diff({'a': {'b': 1, 'c': 2}}, {'a': {'b': 1, 'c': 2}}) is None
    assert recursive_diff({}, {}) is None
    assert recursive

# Generated at 2022-06-22 21:36:23.108870
# Unit test for function dict_merge
def test_dict_merge():
    # simple test case
    a = {'key1' : 'value1', 'key2' : 'value2', 'key3' : 'value3'}
    b = {'key2' : 'value2a', 'key3' : 'value3a', 'key4' : 'value4'}

    ab = dict_merge(a, b)
    # verify original dicts are unchanged
    assert a == {'key1' : 'value1', 'key2' : 'value2', 'key3' : 'value3'}
    assert b == {'key2' : 'value2a', 'key3' : 'value3a', 'key4' : 'value4'}
    # merge result


# Generated at 2022-06-22 21:36:33.600396
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:44.096822
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(
        {'test_key': 'test_value',
         'test_key2': 'test_value2',
         'test_camel': 'test_camel_value'}
    ) == {
      'testKey': 'test_value',
      'testKey2': 'test_value2',
      'testCamel': 'test_camel_value'
    }

# Generated at 2022-06-22 21:36:53.033626
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key1': {
            'innerkey1': 'inner1',
            'innerkey2': 'inner2',
            'innerkey3': {
                'innerinnerkey1': 'innerinner1',
                'innerinnerkey2': 'innerinner1'
            }
        }
    }
    dict2 = {
        'key1': {
            'innerkey1': 'inner1',
            'innerkey2': 'inner2',
            'innerkey3': {
                'innerinnerkey1': 'innerinner1',
                'innerinnerkey2': 'innerinner1'
            }
        }
    }
    # There are no differences between both given dictionaries
    assert recursive_diff(dict1, dict2) is None


# Generated at 2022-06-22 21:37:01.490763
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'int': 1,
        'str': 'a',
        'list': [1, 2, 3],
        'dict': {'aaa': 1, 'bbb': 2},
        'dict2': {'aaa': 1, 'bbb': 2},
        'dict3': {'aaa': 1, 'bbb': 2},
        'dict4': {'aaa': 1, 'bbb': 2},
    }

# Generated at 2022-06-22 21:37:11.691421
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'k1': {'k1k1': {'k1k1k1': 'v1'}, 'k1k2': 'v2'}, 'k2': 'v3'}
    d2 = {'k1': {'k1k1': {'k1k1k2': 'v4'}}, 'k2': 'v3', 'k3': 'v5'}
    expected_result = {'k1': {'k1k1': {'k1k1k1': 'v1', 'k1k1k2': 'v4'}, 'k1k2': 'v2'}, 'k2': 'v3', 'k3': 'v5'}
    assert dict_merge(d1, d2) == expected_result

# Generated at 2022-06-22 21:37:22.918659
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': '1', 'b': '2'}
    d2 = {'a': '3', 'c': '4'}
    assert dict_merge(d1, d2) == {'a': '1', 'b': '2', 'c': '4'}

    d3 = {'a': {'a1': '1', 'a2': '2'}, 'b': '2'}
    d4 = {'a': {'a1': '1', 'a2': '2'}, 'c': '4'}
    assert dict_merge(d3, d4) == {'a': {'a1': '1', 'a2': '2'}, 'b': '2', 'c': '4'}


# Generated at 2022-06-22 21:37:34.002842
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TestKey': 'TestValue', 'MoreTesting': {'TestKeyA': 'TestValueA', 'TestKeyB': ['a', 'b', 'c']}, 'FriendsAndEnemies': {'BugsBunny': 'Friend', 'ElmerFudd': 'Enemy'}}
    snake_dict = {'test_key': 'TestValue', 'more_testing': {'test_key_a': 'TestValueA', 'test_key_b': ['a', 'b', 'c']}, 'friends_and_enemies': {'bugs_bunny': 'Friend', 'elmer_fudd': 'Enemy'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert snake_dict_to_camel_dict(snake_dict) == camel_dict


# Generated at 2022-06-22 21:37:43.526617
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    def assert_camel_dict(snake_dict, camel_dict):
        assert snake_dict_to_camel_dict(snake_dict) == camel_dict

    assert_camel_dict({'foo_bar': 1}, {'fooBar': 1})
    assert_camel_dict({'foo_bar': {'foo_bar': 1}}, {'fooBar': {'fooBar': 1}})
    assert_camel_dict({'foo_bar': [{'foo_bar': [1]}]}, {'fooBar': [{'fooBar': [1]}]})

# Generated at 2022-06-22 21:37:48.323019
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'original_snake_key': {'original_snake_nested_key': 'original_snake_nested_value'}}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=True) == {'OriginalSnakeKey': {'OriginalSnakeNestedKey': 'original_snake_nested_value'}}
    assert snake_dict_to_camel_dict(snake_dict, capitalize_first=False) == {'originalSnakeKey': {'originalSnakeNestedKey': 'original_snake_nested_value'}}
    assert snake_dict_to_camel_dict(snake_dict) == {'originalSnakeKey': {'originalSnakeNestedKey': 'original_snake_nested_value'}}



# Generated at 2022-06-22 21:37:59.475601
# Unit test for function dict_merge
def test_dict_merge():
    """ tests the dict_merge function """

    a = dict(one=1, two=2, three=dict(four=4, five=5))
    b = dict(two=20, three=dict(five=50))

    assert dict_merge(a, b) == dict(one=1, two=20, three=dict(four=4, five=50))

    a = dict(one=1, two=2, three=dict(four=4, five=5))
    b = dict(one=10, three=dict(five=50))

    assert dict_merge(a, b) == dict(one=10, two=2, three=dict(four=4, five=50))

    a = dict(one=1, two=dict(three=3, four=4), five=5)
    b = dict

# Generated at 2022-06-22 21:38:11.635937
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPURL': {
                'Method': 'GET',
                'Path': '/',
            },
            'RequestHeaders': [
                {
                    'Name': 'X-Test',
                    'Value': 'test',
                },
            ],
            'UseSSL': True,
        },
        'Port': 1234,
        'Protocol': 'UDP',
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'testing',
            },
        ],
    }

    # Make a copy since function mutates the input
    camel_dict_copy = deepcopy(camel_dict)
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict

# Generated at 2022-06-22 21:38:20.680113
# Unit test for function dict_merge
def test_dict_merge():
    test_obj1 = {'name1': 'value1',
                 'name2': 'value2',
                 'name3': {'name31': 'value31',
                           'name32': 'value32',
                           'name33': {'name331': 'value331',
                                      'name332': 'value332'}}}

    test_obj2 = {'name1': 'value1_update',
                 'name2': 'value2_update',
                 'name3': {'name31': 'value31_update',
                           'name32': 'value32_update',
                           'name33': {'name331': 'value331_update'}}}


# Generated at 2022-06-22 21:38:31.709905
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dromedary_dict = {
        'vpc_endpoint_ids': [
            'vpce-0123456789abcdef0'
        ],
        'tag_filters': [{
            'key': 'foo',
            'values': ['bar']
        }]
    }
    camel_dict = snake_dict_to_camel_dict(dromedary_dict)
    assert camel_dict == {
        'VpcEndpointIds': [
            'vpce-0123456789abcdef0'
        ],
        'TagFilters': [{
            'Key': 'foo',
            'Values': ['bar']
        }]
    }
    assert dromedary_dict == snake_dict_to_camel_dict(camel_dict, False)
    assert dromed

# Generated at 2022-06-22 21:38:37.284101
# Unit test for function dict_merge
def test_dict_merge():
    a = {'dicta': {'keya': 1, 'keyd': 'fish'}, 'keyb': 2}
    b = {'dicta': {'keya': 2, 'keyc': 'pig'}, 'dictc': {'keyd': 'horse'}}
    assert dict_merge(a, b) == {'dicta': {'keya': 2, 'keyd': 'fish', 'keyc': 'pig'},
                                'keyb': 2, 'dictc': {'keyd': 'horse'}}



# Generated at 2022-06-22 21:38:46.362433
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict_to_test = dict(
        test_key_a=1,
        test_key_b=[
            1,
            2,
            3
        ],
        test_key_c=dict(
            test_key_d=[
                dict(
                    test_key_e=1,
                    test_key_f=2
                )
            ]
        )
    )
    expected_output = dict(
        TestKeyA=1,
        TestKeyB=[
            1,
            2,
            3
        ],
        TestKeyC=dict(
            TestKeyD=[
                dict(
                    TestKeyE=1,
                    TestKeyF=2
                )
            ]
        )
    )


# Generated at 2022-06-22 21:38:47.740446
# Unit test for function recursive_diff
def test_recursive_diff():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 21:38:57.921370
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:09.709366
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:16.831682
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({'foo_bar': 1, 'foo_baz': {'foo_bar': 2}}) == {'fooBar': 1, 'fooBaz': {'fooBar': 2}}
    assert snake_dict_to_camel_dict({'fooBar': 1, 'fooBaz': {'fooBar': 2}}) == {'fooBar': 1, 'fooBaz': {'fooBar': 2}}
    assert snake_dict_to_camel_dict({'fooBar': 1, 'fooBaz': {'fooBar': 2}}, True) == {'FooBar': 1, 'FooBaz': {'FooBar': 2}}


# Generated at 2022-06-22 21:39:28.398088
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:39:36.188455
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Trivial cases
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({"a": 1}) == {"a": 1}
    assert snake_dict_to_camel_dict({"a": {"b": 1}}) == {"a": {"b": 1}}

    # Dictionary
    assert snake_dict_to_camel_dict({"foo_bar": 1}) == {"fooBar": 1}
    assert snake_dict_to_camel_dict({"foo_bar": 1}, True) == {"FooBar": 1}

# Generated at 2022-06-22 21:39:41.998548
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = dict(
        a_key=dict(
            b_key=dict(
                c_key=1
            )
        )
    )
    output_dict = snake_dict_to_camel_dict(input_dict)
    assert(output_dict['aKey']['bKey']['cKey'] == 1)



# Generated at 2022-06-22 21:39:51.748499
# Unit test for function recursive_diff
def test_recursive_diff():
        # Test for no difference
        assert recursive_diff({}, {}) is None, "Empty dicts should be equal"
        assert recursive_diff({'a': 1, 'b': {'c': {'d': None}}},
                              {'b': {'c': {'d': None}}, 'a': 1}) is None, "Dicts should be equal"
        assert recursive_diff({'b': {'c': {'d': None}}, 'a': 1},
                              {'a': 1, 'b': {'c': {'d': None}}}) is None, "Dicts should be equal"

        # Test for differences
        left = {'a': 'different', 'b': {'c': {'d': None}}}
        right = {'a': 'different', 'b': {'c': {'d': None}}}

# Generated at 2022-06-22 21:40:00.137679
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sample_camel_dict = {'CamelKey': {'CamelKey': 'CamelValue'}, 'NestedCamelKey': [{'NestedCamelKey': {'NestedCamelKey': 'NestedCamelValue'}}]}
    expected_snake_dict = {'camel_key': {'camel_key': 'CamelValue'}, 'nested_camel_key': [{'nested_camel_key': {'nested_camel_key': 'NestedCamelValue'}}]}
    snake_dict = camel_dict_to_snake_dict(sample_camel_dict)
    assert snake_dict == expected_snake_dict


# Generated at 2022-06-22 21:40:12.455239
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Single example from
    # [aws-doc-sdk-examples/python/example_code/ec2/modify_instance_attribute.py](https://github.com/awsdocs/aws-doc-sdk-examples/blob/master/python/example_code/ec2/modify_instance_attribute.py)
    input_dict = {'SourceDestCheck': {'Value': False}}
    output_dict = {'source_dest_check': {'value': False}}
    assert camel_dict_to_snake_dict(input_dict) == output_dict

    # Check 'reversible' kwarg
    assert snake_dict_to_camel_dict(output_dict) == input_dict
    # Check that items in ignore_list are unchanged

# Generated at 2022-06-22 21:40:22.568602
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert {'tags': {'foo': 'bar'}} == camel_dict_to_snake_dict({'Tags': {'foo': 'bar'}})
    assert {'tags': [{"foo": [{"bar": "baz"}]}]} == camel_dict_to_snake_dict(
        {'Tags': [{"foo": [{"bar": "baz"}]}]})

    assert {"a_b_c_d_e": "foo"} == camel_dict_to_snake_dict({"abcDe": "foo"})
    assert {"is_default": "foo"} == camel_dict_to_snake_dict({"isDefault": "foo"})
    assert {"http_endpoint": "foo"} == camel_dict_to_snake_dict({"HTTPEndpoint": "foo"})

# Generated at 2022-06-22 21:40:34.537603
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("Camel") == "camel"
    assert _camel_to_snake("CamelCase") == "camel_case"
    assert _camel_to_snake("CamelCamelCase") == "camel_camel_case"
    assert _camel_to_snake("CamelCamelCamelCase") == "camel_camel_camel_case"
    assert _camel_to_snake("Camel2Camel2Case") == "camel2_camel2_case"
    assert _camel_to_snake("getHTTPResponseCode") == "get_http_response_code"
    assert _camel_to_snake("get2HTTPResponseCode") == "get2_http_response_code"
   