

# Generated at 2022-06-22 21:30:37.292017
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = {'test_key': 'test_value', 'test_key_two': {'test_key_three':'test_value_three'}, 'test_key_four': [{'test_key_five':'test_value_five'}]}
    output_dict = snake_dict_to_camel_dict(input_dict)
    assert output_dict == {
        'testKey': 'test_value',
        'testKeyTwo': {
            'testKeyThree':'test_value_three'
        },
        'testKeyFour': [{
            'testKeyFive':'test_value_five'
        }]
    }

# Generated at 2022-06-22 21:30:48.517039
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:30:59.808418
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:31:10.534258
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {
            'DeviceName': '/dev/sda',
            'NoDevice': True,
            'Ebs':
                {
                    'Iops': 100,
                    'VolumeSize': 120,
                    'DeleteOnTermination': True
                },
            'VirtualName': 'ephemeral0'
        }
    ) == {
        'device_name': '/dev/sda',
        'no_device': True,
        'ebs':
            {
                'iops': 100,
                'volume_size': 120,
                'delete_on_termination': True
            },
        'virtual_name': 'ephemeral0'
    }



# Generated at 2022-06-22 21:31:17.578641
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    print("test_snake_dict_to_camel_dict")
    dict1 = {'a_b_c': [1, 2, 3], 'd_e_f': {'a': 1, 'b': {'c': 2}, 'd_e_f': 4}, 'g_h': set([1, 2, 3])}
    dict2 = {'aBC': [1, 2, 3], 'dEF': {'a': 1, 'b': {'c': 2}, 'dEF': 4}, 'gH': set([1, 2, 3])}
    dict3 = {'Abc': [1, 2, 3], 'Def': {'a': 1, 'b': {'c': 2}, 'Def': 4}, 'Gh': set([1, 2, 3])}

# Generated at 2022-06-22 21:31:23.035523
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'key_name': 'value'}) == {'keyName': 'value'}
    assert snake_dict_to_camel_dict({'KeyName': 'value'}) == {'keyName': 'value'}
    assert snake_dict_to_camel_dict({'KeyName': 'value'}, capitalize_first=True) == {'KeyName': 'value'}
    assert snake_dict_to_camel_dict({'key_name': [{'key_name': 'value'}]}) == {'keyName': [{'keyName': 'value'}]}

# Generated at 2022-06-22 21:31:34.928663
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_dict = {
        "elasticBeanstalk": "eb",
        "rds": {
            "database": "rds",
            "securityGroupIds": [
                "sg-12345",
                "sg-67890",
            ]
        },
        "lambda": {
            "functionName": "lambda_function_name",
            "handler": "lambda_handler_name"
        },
        "NAT" : {
            "subnetIds": [
                "subnet_1",
                "subnet_2",
            ],
            "subnetIDs": "subnet_1,subnet_2"
        },
        'Tags': {
            'key': 'value'
        }
    }
    converted_dict = camel_dict_to_snake_dict(complex_dict)
   

# Generated at 2022-06-22 21:31:45.744204
# Unit test for function recursive_diff
def test_recursive_diff():
    # no differences
    assert not recursive_diff({"a": 1, "b": 2}, {"a": 1, "b": 2})
    # no differences
    assert not recursive_diff({"a": 1, "b": {}}, {"a": 1, "b": {}})
    # different dictionaries
    assert recursive_diff({"a": 1, "b": 2}, {"a": 3, "b": 4}) == ({'a': 1}, {'a': 3})
    # different dictionaries
    assert recursive_diff({"a": 1, "b": {"c": 2}}, {"a": 1, "b": {"c": 3}}) == ({'b': {'c': 2}}, {'b': {'c': 3}})
    # nested differences

# Generated at 2022-06-22 21:31:56.655274
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    """
    Unit test for function snake_dict_to_camel_dict
    """

    assert snake_dict_to_camel_dict({"region": "us-east-1"}) == {"region": "us-east-1"}

    assert snake_dict_to_camel_dict({"http_method": "GET"}) == {"httpMethod": "GET"}

    assert snake_dict_to_camel_dict({"http_method": "GET"}, capitalize_first=True) == {"HttpMethod": "GET"}

    assert snake_dict_to_camel_dict({"path_part": "/foo"}) == {"pathPart": "/foo"}

    assert snake_dict_to_camel_dict({"path_part": "/foo"}, capitalize_first=True) == {"PathPart": "/foo"}

    assert snake_dict_to

# Generated at 2022-06-22 21:32:02.765530
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == { 'first' : { 'all_rows' : { 'pass' : 'dog',
                                                            'fail' : 'cat',
                                                            'number' : '5' } } }


# Generated at 2022-06-22 21:32:13.863866
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test for recursive_diff function.
    """
    dict1 = {
        'a': 'bar',
        'list': [1, 2, 3],
        'dict': {
            'a': 'bar',
            'list': [1, 2, 3],
        },
    }
    dict2 = {
        'a': 'bar',
        'list': [1, 2, 3],
        'dict': {
            'a': 'baz',
            'list': [1, 2, 3],
        },
    }
    dict3 = {
        'a': 'bar',
        'list': [1, 2, 3],
        'dict': {
            'a': 'baz',
            'list': [1, 2, 3],
        },
    }

# Generated at 2022-06-22 21:32:25.506049
# Unit test for function dict_merge
def test_dict_merge():
    dict_a = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    dict_b = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    dict_c = {'a': 5, 'b': {'c': 6, 'f': 7}, 'g': 8}
    dict_d = {'a': 5, 'b': {'c': 6, 'd': 7}, 'g': 8, 'z': 9}
    dict_e = {'a': 5, 'b': {'c': 6, 'd': 4}, 'g': 8, 'z': 9}


# Generated at 2022-06-22 21:32:35.593059
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test simple case
    a = {'a': 1, 'b': 2, 'c': 3}
    b = {'a': 1, 'b': 2, 'c': 4}
    assert recursive_diff(a, b) == ({}, {'c': 4})

    # Test with nested dictionaries
    a = {'a': 1, 'b': {'c': 2}, 'd': 3}
    b = {'a': 1, 'b': {'c': 3}, 'd': 3}
    assert recursive_diff(a, b) == ({}, {'b': {'c': 3}})

    # Test with nested dictionaries
    a = {'a': 1, 'b': {'c': 2}, 'd': 3}

# Generated at 2022-06-22 21:32:45.771760
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': 'baz',
        'fooBarBaz': {
            'fooBar': 'baz'
        },
        'fooBarBazBim': [
            {
                'fooBar': 'baz'
            }
        ]
    }
    expected_dict = {
        'foo_bar': 'baz',
        'foo_bar_baz': {
            'foo_bar': 'baz'
        },
        'foo_bar_baz_bim': [
            {
                'foo_bar': 'baz'
            }
        ]
    }
    assert(camel_dict_to_snake_dict(test_dict) == expected_dict)


# Generated at 2022-06-22 21:32:54.452071
# Unit test for function dict_merge
def test_dict_merge():
    ab = dict_merge({'a': 1, 'b': 2}, {'b': 3, 'c': 5})
    assert ab['a'] == 1
    assert ab['b'] == 3
    assert ab['c'] == 5

    abc = dict_merge(ab, {'c': 4, 'd': 6})
    assert abc['a'] == 1
    assert abc['b'] == 3
    assert abc['c'] == 4
    assert abc['d'] == 6

    abd = dict_merge({'a': 1, 'b': 2}, {'b': 3, 'd': 5})
    assert abd['a'] == 1
    assert abd['b'] == 3
    assert abd['d'] == 5


# Generated at 2022-06-22 21:33:05.258725
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for camel_dict_to_snake_dict, to ensure it converts all camel case
    keys to snake case keys and that it reverses properly.
    """

# Generated at 2022-06-22 21:33:16.203500
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    # This test is not comprehensive, just verifying that the conversion works
    # at a high level, and we can get the output back into the same format we
    # started with.
    camel_dict = {
        "dryRun": True,
        "volumeId": "vol-12345678",
        "instanceId": "i-12345678"
    }

    # Not using camel_dict_to_snake_dict because it's the function being tested.
    # Leave it to the test harness to report any errors
    snake_dict = {
        "dry_run": True,
        "volume_id": "vol-12345678",
        "instance_id": "i-12345678"
    }

    # Verify that we can convert back and forth.
    # If so, then we can trust that the conversion is working.

# Generated at 2022-06-22 21:33:27.410343
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key': {'key11': 'value11', 'key12': 'value12'}, 'key1': 'value1'}
    dict2 = {'key': {'key11': 'value11', 'key12': 'value12'}, 'key1': 'value2'}
    assert recursive_diff(dict1, dict2) == \
        ({'key1': 'value1'}, {'key1': 'value2'})

    dict1 = {'key': {'key11': 'value11', 'key12': 'value12'}, 'key1': 'value1'}
    dict2 = {'key': {'key13': 'value13', 'key12': 'value12'}, 'key1': 'value1'}

# Generated at 2022-06-22 21:33:38.584974
# Unit test for function dict_merge
def test_dict_merge():

    assert dict_merge({'c': 1}, {'a': 'test1', 'b': {'x': 5, 'y': 10, 'z': 15}}) == {'c': 1, 'a': 'test1', 'b': {'x': 5, 'y': 10, 'z': 15}}
    assert dict_merge({'c': 1, 'a': {'x': 5, 'y': 10, 'z': 15}}, {'a': 'test1', 'b': {'x': 5, 'y': 10, 'z': 15}}) == {'c': 1, 'a': 'test1', 'b': {'x': 5, 'y': 10, 'z': 15}}

# Generated at 2022-06-22 21:33:44.246984
# Unit test for function dict_merge
def test_dict_merge():
    a = {'deep_key': {'a': 1, 'b': 2}}
    b = {'deep_key': {'a': 1, 'c': 3}}

    result = {'deep_key': {'a': 1, 'b': 2, 'c': 3}}
    assert(dict_merge(a, b) == result)

# Generated at 2022-06-22 21:33:54.763381
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:34:05.697243
# Unit test for function dict_merge
def test_dict_merge():
    # Test case 1 : dict_merge({'a': 1}, {}) => {'a': 1}
    # This test case tests if merged results are still the same if the second
    # dictionary is empty dictionary
    dict1 = {'a': 1}
    dict2 = {}
    result = dict_merge(dict1, dict2)
    assert result == {'a': 1}

    # Test case 2 : dict_merge({'a': 1}, {'a': 2}) => {'a': 2}
    dict1 = {'a': 1}
    dict2 = {'a': 2}
    result = dict_merge(dict1, dict2)
    assert result == {'a': 2}

    # Test case 3 : dict_merge({'a': {'b': 1}}, {'a':{'c

# Generated at 2022-06-22 21:34:12.574960
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Set up test objects
    camel_dict = {
        'HTTPEndpoint': 'http://www.example.com',
        'HTTPPath': '/foo/bar',
        'HTTPMethod': 'POST',
        'Tags': {
            'tag1': 'tag1value',
            'Tag2': 'tag2value',
        }
    }
    expected_output = {
        'http_endpoint': 'http://www.example.com',
        'http_path': '/foo/bar',
        'http_method': 'POST',
        'tags': {
            'tag1': 'tag1value',
            'Tag2': 'tag2value',
        }
    }

    # Run unit test
    assert camel_dict_to_snake_dict(camel_dict) == expected_output


# Unit

# Generated at 2022-06-22 21:34:21.473467
# Unit test for function dict_merge
def test_dict_merge():
    a = {
        'b': 1,
        'c': {
            'd': 2,
            'e': 3,
        },
        'f': 5,
    }
    b = {
        'b': 10,
        'c': {
            'd': 20,
            'f': 30,
        },
        'g': 40,
    }
    expected = {
        'b': 10,
        'c': {
            'd': 20,
            'e': 3,
            'f': 30,
        },
        'f': 5,
        'g': 40,
    }
    assert dict_merge(a, b) == expected
    assert dict_merge(b, a) == expected
    assert dict_merge({}, a) == a

# Generated at 2022-06-22 21:34:32.470729
# Unit test for function dict_merge
def test_dict_merge():
    orig = dict(a=1, b=2, c=dict(d=4,e=5))
    new = dict(f=6, c=dict(k=12,l=13))
    result = dict_merge(orig, new)
    assert(result == dict(f=6, a=1, b=2, c=dict(k=12,l=13,d=4,e=5)))
    # Test that orig is unmodified
    assert(orig == dict(a=1, b=2, c=dict(d=4,e=5)))


# Generated at 2022-06-22 21:34:41.590812
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test that various dictionary combinations return the expected diff result"""
    assert recursive_diff({}, {}) is None
    assert recursive_diff({"a": 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {"a": 1}) == ({}, {'a': 1})
    assert recursive_diff({"a": 1}, {"a": 1}) is None
    assert recursive_diff({"a": 1}, {"a": 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({"a": {"b": 1, "c": 2}}, {"a": {"b": 1}}) == ({'a': {'c': 2}}, {'a': {}})

# Generated at 2022-06-22 21:34:51.534722
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for function `camel_dict_to_snake_dict`
    """
    from ansible.module_utils.aws.core import AnsibleAWSModule

    module = AnsibleAWSModule(argument_spec={}, supports_check_mode=False)
    assert camel_dict_to_snake_dict({'HttpEndpoints': 'for k8s'}) == {'http_endpoints': 'for k8s'}
    assert camel_dict_to_snake_dict({'HttpEndpoints': [{'HTTPEndpoint': 'for k8s'}]}) == {'http_endpoints': [{'h_t_t_p_endpoint': 'for k8s'}]}

# Generated at 2022-06-22 21:35:03.217150
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 100}) == {'h_t_t_p_endpoint': 100}
    assert camel_dict_to_snake_dict({'HTTPRedirect': {'HTTPEndpoint': 100, 'Description': 'This is a description'}}) == \
           {'h_t_t_p_redirect': {'h_t_t_p_endpoint': 100, 'description': 'This is a description'}}

# Generated at 2022-06-22 21:35:12.329189
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'vpc_id': 'vpc-1',
        'tags': {'Name': 'my-vpc', 'Environment': 'Production'},
        'cidr_block': '10.0.0.0/16',
        'state': 'available',
        'dhcp_options_id': 'dopt-4a0c4e22',
        'instance_tenancy': 'default',
        'is_default': False
    }

# Generated at 2022-06-22 21:35:22.356257
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:35:32.015894
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:35:38.598168
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({}, {'a': 1}) == {'a': 1}
    assert dict_merge({'a': 1}, {}) == {'a': 1}
    assert dict_merge({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert dict_merge({'a': {'b': 1}}, {'a': {'c': 2}}) == {'a': {'b': 1, 'c': 2}}


# Generated at 2022-06-22 21:35:49.606187
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:00.738906
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    assert recursive_diff({'a': 12, 'b': 'xyz'}, {'a': 13, 'b': 'xyz'})[0]['a'] == 12
    assert recursive_diff({'a': 12, 'b': 'xyz'}, {'a': 13, 'b': 'xyz'})[1]['a'] == 13
    assert recursive_diff({'a': 12, 'b': 'xyz'}, {'a': 12, 'b': 'xyz', 'z': 'new'})[1]['z'] == 'new'
    assert recursive_diff({'a': 12, 'b': 'xyz'}, {'a': 12, 'b': 'xyz', 'z': 'new'})[0] == None

# Generated at 2022-06-22 21:36:11.222410
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'z': 3}
    b = {'w': 10, 'x': 11, 'y': 2}
    c = {'merge_dicts': [a, b]}

    d = {'x': 11, 'y': 2, 'z': 3, 'w': 10, 'merge_dicts': [{'x': 1, 'y': 2, 'z': 3}, {'w': 10, 'x': 11, 'y': 2}]}
    e = {'x': 1, 'y': 2, 'z': 3, 'w': 10}
    f = {'x': {'a': 1, 'b': 2}, 'y': 2, 'z': 3}

# Generated at 2022-06-22 21:36:20.525813
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = {'a': 1, 'b': {'c': 1, 'd': 1}, 'e': 1}
    dict_b = {'a': 1, 'b': {'c': 2, 'd': 1}, 'e': 1}
    dict_c = {'a': 1, 'b': {'c': 2, 'd': 2}, 'e': 1}
    dict_d = {'a': 1, 'b': {'c': 2, 'd': 2}, 'e': 2}

    result_ab = recursive_diff(dict_a, dict_b)
    assert result_ab == ({'b': {'c': 1}}, {'b': {'c': 2}})
    result_ba = recursive_diff(dict_b, dict_a)

# Generated at 2022-06-22 21:36:31.936484
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:40.922291
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff

    This function cannot be tested with py.test.
    """

    print('*' * 80)
    print("Unit test for function recursive_diff")
    print('*' * 80)

    d1 = {
        "Key": "Value",
        "Key2": {
            "Item1": 1,
            "Item2": 2,
            "Item3": 3,
            "Item4": {
                "ItemA": "a",
                "ItemB": "b"
            }
        },
        "Key3": "value3",
        "Key4": "value4",
        "Key5": "value5",
    }

# Generated at 2022-06-22 21:36:51.070935
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b=2, c=dict(a=4, b=5), d=dict(a=dict(f=6)))
    dict2 = dict(a=1, b=2, c=dict(a=4, b=5), e=dict(d=dict(g=7)))
    dict3 = dict(c=dict(a=4, b=10))
    dict4 = dict(d=dict(a=dict(f=6)))
    left, right = recursive_diff(dict1, dict2)
    assert left == dict4, "Expected %s but got %s" % (dict4, left)
    assert right == dict3, "Expected %s but got %s" % (dict3, right)

# Generated at 2022-06-22 21:36:58.873131
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict_original = [
        {'key': 'value'},
        {'key2': 'value2'},
        {'key-key': 'value'},
        {'key_key': 'value'},
        {'key1key1': 'value'},
        {'KEy': 'value'},
        {'key': {'key': 'value'}},
        {'key': [{'key': 'value'}]},
        {'key': [{'key': 'value'}, {'key': 'value'}]},
    ]

# Generated at 2022-06-22 21:37:08.886695
# Unit test for function dict_merge
def test_dict_merge():

    from collections import OrderedDict

    def assert_dict_equal(expected, actual):
        assert expected == actual, "%s != %s " % (expected, actual)

    def assert_dict_merge_equal(a, b, c):
        assert_dict_equal(c, dict_merge(a, b))

    # if either dict is empty, return the other dict
    assert_dict_merge_equal({'a': 'b'}, {}, {'a': 'b'})
    assert_dict_merge_equal({}, {'a': 'b'}, {'a': 'b'})

    # simple strings
    assert_dict_merge_equal({'a': 'a'}, {'b': 'b'}, {'a': 'a', 'b': 'b'})

    # overwrite value with an int

# Generated at 2022-06-22 21:37:17.442183
# Unit test for function recursive_diff
def test_recursive_diff():
    # test1: dict1 and dict2 are exactly the same
    dict1 = dict(a={'a': 1})
    dict2 = dict(a={'a': 1})
    assert recursive_diff(dict1, dict2) == None

    dict1 = dict(a={'a': 1})
    dict2 = dict(a={'a': 1}, b={'b': 1})
    assert recursive_diff(dict1, dict2) == ({'b':{'b':1}}, {'b':{'b':1}})

    dict1 = dict(a='a', b='b')
    dict2 = dict(a='a', b='d')
    assert recursive_diff(dict1, dict2) == ({}, {'b':'d'})

    # test3: dict1 has key 'a' missing in dict2

# Generated at 2022-06-22 21:37:26.662303
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': None}) == {'fooBar': None}
    assert snake_dict_to_camel_dict({'foo_bar': 1}) == {'fooBar': 1}
    assert snake_dict_to_camel_dict({'foo_bar': []}) == {'fooBar': []}
    assert snake_dict_to_camel_dict({'foo_bar': {}}) == {'fooBar': {}}
    assert snake_dict_to_camel_dict({'foo_bar': [{'bar_baz': None}]}) == {'fooBar': [{'barBaz': None}]}

# Generated at 2022-06-22 21:37:33.221089
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': {'b': {'c': 1, 'e': 5}, 'f': 6}}
    b = {'a': {'b': {'d': 2}, 'g': 7}}
    assert dict_merge(a, b) == {'a': {'b': {'c': 1, 'e': 5, 'd': 2}, 'f': 6, 'g': 7}}

# Generated at 2022-06-22 21:37:43.452495
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a':1, 'b':2, 'c':{'d': 4, 'e': 5, 'f': 6}, 'g': 7}
    dict2 = {'a':1, 'b':3, 'c':{'d': 4, 'e': 5, 'f': 7}, 'g':8}
    dict3 = {'a':1, 'b':2, 'c':{'d': 4, 'e': 5, 'f': 6}, 'g': 7}
    dict4 = {'a':1, 'b':2, 'c':{'x': 4, 'y': 5, 'z': 6}, 'g': 7}
    dict5 = {'a':1, 'x':2, 'c':{'d': 4, 'e': 5, 'f': 6}, 'g': 7}

# Generated at 2022-06-22 21:37:52.480195
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Name': 'Bob', 'Age': '30', 'WeightKg': '90'}) == {'name': 'Bob', 'age': '30', 'weight_kg': '90'}
    assert camel_dict_to_snake_dict({'Name': 'Bob', 'Age': '30', 'metaData': 'metadata'}) == {'name': 'Bob', 'age': '30', 'meta_data': 'metadata'}
    assert camel_dict_to_snake_dict({'Tags': {'Tag': 'Metadata'}}) == {'tags': {'Tag': 'Metadata'}}

# Generated at 2022-06-22 21:38:02.094623
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    def validate_camelized_dict(camel_dict, expected_dict):
        assert isinstance(camel_dict, MutableMapping)
        assert ''.join(camel_dict.keys()) == ''.join(expected_dict.keys())

    # Simple dict
    camel_dict = snake_dict_to_camel_dict({'foo_bar': 'FooBar'})
    validate_camelized_dict(camel_dict, {'FooBar': 'FooBar'})

    # List of dicts
    camel_dict = snake_dict_to_camel_dict([{'foo_bar': 'FooBar'}, {'bar_foo': 'BarFoo'}])

# Generated at 2022-06-22 21:38:14.151594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_string = 'The quick brown fox jumps over the lazy dog'
    assert(_camel_to_snake(test_string) == 'the_quick_brown_fox_jumps_over_the_lazy_dog')
    assert(_camel_to_snake(test_string, True) == 'theQuickBrownFoxJumpsOverTheLazyDog')
    assert(_camel_to_snake('TheQuickBrownFoxJumpsOverTheLazyDog') == 'the_quick_brown_fox_jumps_over_the_lazy_dog')
    assert(_camel_to_snake('HTTPEndpoint') == 'h_t_t_p_endpoint')
    assert(_camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint')

# Generated at 2022-06-22 21:38:19.157246
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({'foo': 'bar', 'bar_baz': 'foo'}) == {'foo': 'bar', 'barBaz': 'foo'}
    assert snake_dict_to_camel_dict({'foo': 'bar', 'bar_baz': 'foo'}, True) == {'Foo': 'bar', 'BarBaz': 'foo'}



# Generated at 2022-06-22 21:38:27.664836
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    def test_snake_to_camel(test_data):
        '''test_data - dictionary of <snake_key>: <expected_camel_key> pairs'''
        for k, v in test_data.items():
            assert _snake_to_camel(k) == v, "%s != %s" % (_snake_to_camel(k), v)

    # Simple test
    test_data = {
        'simple_key': 'simpleKey',
    }
    test_snake_to_camel(test_data)

    # Test that single letters are not capitalized, except for the first letter
    test_data = {
        'a': 'a',
        'b': 'b',
        'bb': 'bB',
    }

# Generated at 2022-06-22 21:38:36.565814
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "fooCamelTest": {
            "barCamelTest": {
                "ThingName": "FooBar"
            },
            "fooBarBar": {
                "BazBazBaz": [
                    {
                        "greeting": "hello"
                    },
                    {
                        "salutation": "goodbye"
                    }
                ]
            }
        }
    }

# Generated at 2022-06-22 21:38:42.205161
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': {'b': {'c': 1, 'd': 2}}}
    dict2 = {'a': {'b': {'c': 1, 'd': 3, 'e': 4}}}
    dict3 = dict_merge(dict1, dict2)
    assert dict3 == {'a': {'b': {'c': 1, 'd': 3, 'e': 4}}}



# Generated at 2022-06-22 21:38:48.962278
# Unit test for function recursive_diff
def test_recursive_diff():
    # Functions returns None if no difference, else return left and right
    assert recursive_diff({'a': 1}, {'a': 1}) == None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    # Function returns nested value if there is a difference
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 2}}) == ({'a': {'b': 1}}, {'a': {'b': 2}})
    assert recursive_diff({'a': {'b': 1}}, {'a': {'b': 1}}) == None

    # Function returns error if arguments are invalid

# Generated at 2022-06-22 21:38:58.446258
# Unit test for function dict_merge
def test_dict_merge():
    a = {'prop1': 1, 'prop2': {'prop3': 10, 'prop4': {'prop5': {'prop6': 100}}}}
    b = {'prop1': 2, 'prop2': {'prop3': 20, 'prop4': {'prop5': {'prop6': 200}}}}
    c = {'prop1': 2, 'prop2': {'prop3': 20, 'prop4': {'prop5': {'prop6': 100}}}}
    d = {'prop1': 1, 'prop2': {'prop3': 10, 'prop4': {'prop5': {'prop6': 100}}}}
    e = {'prop1': 1}

# Generated at 2022-06-22 21:39:10.088154
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:39:21.350624
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake("CamelCase") == "camel_case"
    assert _camel_to_snake("camelCase") == "camel_case"
    assert _camel_to_snake("CamelCamelCase") == "camel_camel_case"
    assert _camel_to_snake("camelCamelCase") == "camel_camel_case"
    assert _camel_to_snake("HTTPEndpoint") == "h_t_t_p_endpoint"
    assert _camel_to_snake("HTTPEndpoint", reversible=True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("HTTPEndpoint", reversible=False) == "http_endpoint"
    assert _camel_to_

# Generated at 2022-06-22 21:39:32.914716
# Unit test for function dict_merge
def test_dict_merge():
    def assert_merge(actual, expected, name):
        if actual != expected:
            raise AssertionError(('Error in %s:\n' % name) +
                                 ('Expected: %r\n' % expected) +
                                 ('Actual:   %r' % actual))

    class TestClass(object):
        pass
    assert_merge(dict_merge({}, {}), {}, 'two empty dicts')
    assert_merge(dict_merge({'a': 1}, {}), {'a': 1}, 'one empty dict')
    assert_merge(dict_merge({}, {'a': 1}), {'a': 1}, 'one empty dict')

# Generated at 2022-06-22 21:39:44.644190
# Unit test for function dict_merge
def test_dict_merge():

    # Simple merge of two dictionaries
    a = { 'a': 1 }
    b = { 'b': 2 }
    result = dict_merge(a, b)
    assert result == { 'a': 1, 'b': 2 }

    # Dictionary merged with a value (no key/value collision)
    b = { 'b': 2 }
    result = dict_merge(a, b)
    assert result == { 'a': 1, 'b': 2 }

    # Value merged with a dictionary (no key/value collision)
    b = 2
    result = dict_merge(a, b)
    assert result == a

    # Dictionary merged with a list (no key/value collision)
    b = [ 2 ]
    result = dict_merge(a, b)
    assert result == 'a'

    # List merged with

# Generated at 2022-06-22 21:39:55.141973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "HTTPStatusCode": 200,
        "HTTPHeaders": {
            "headerName": "headerValue",
            "x-amzn-RequestId": "x-amzn-RequestId"
        },
        "RequestId": "requestId"
    }

    expected_output = {
        "http_status_code": 200,
        "http_headers": {
            "header_name": "headerValue",
            "x_amzn_request_id": "x-amzn-RequestId"
        },
        "request_id": "requestId"
    }

    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected_output



# Generated at 2022-06-22 21:40:03.253869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_data = {
        "HTTPEndpoint": {"HTTPCode": "200", "EndpointLocation": "cloudfront"},
        "CollectorStatus": "ERROR",
        "CollectorTypeName": "HTTP",
        "CreatedAt": 1569507257.0,
        "UpdatedAt": 1569507257.0,
        "CollectorRegion": "us-west-2"
    }


# Generated at 2022-06-22 21:40:11.410141
# Unit test for function dict_merge
def test_dict_merge():
    a = {'1': {'2': {'3': 'four'}}, 'five': {'six': 'seven'}, 'eight': 8}
    b = {'1': {'two': 2}, 'five': 5, 'newkey': 'newvalue'}
    expected_dict = {'1': {'2': {'3': 'four'}, 'two': 2}, 'five': 5, 'eight': 8, 'newkey': 'newvalue'}
    assert dict_merge(a, b) == expected_dict


# Generated at 2022-06-22 21:40:18.159913
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    result = {'first': {'all_rows': {'pass': 'dog', 'fail': 'cat', 'number': '5'}}}

    assert dict_merge(a, b) == result


# Generated at 2022-06-22 21:40:28.860251
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict({"foo_bar": "example"}) == {"fooBar": "example"}
    assert snake_dict_to_camel_dict({"foo_bar": "example"}, True) == {"FooBar": "example"}
    assert snake_dict_to_camel_dict({"foo_bar": ["example", "example2"]}) == {"fooBar": ["example", "example2"]}
    assert snake_dict_to_camel_dict({"foo_bar": ["example", "example2"]}, True) == {"FooBar": ["example", "example2"]}
    assert snake_dict_to_camel_dict({"foo_bar": {"example": 1}}) == {"fooBar": {"example": 1}}
