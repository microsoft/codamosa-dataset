

# Generated at 2022-06-22 21:30:35.004457
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    # Creating a sample dictionary
    sample_snake_dict = {
        'some_lower_case': {
            'some_more_lower_case': 5
        },
        'some_upper_case': {
            'some_more_upper_case': 'hello'
        },
        'some_numbers': [
            'some_string',
            1
        ],
        'some_mixed': [
            {'some_number': 1},
            {'Some_Key': 'some_value'}
        ],
        'Some_Key_With_Numbers2': 'some_value'
    }

    # Creating expected result

# Generated at 2022-06-22 21:30:43.456869
# Unit test for function recursive_diff
def test_recursive_diff():
    from itertools import product
    from collections import namedtuple

    DictType = namedtuple('DictType', 'a b')
    ResultType = namedtuple('ResultType', 'left right')

    def assert_dict_type(test_case, result, left, right, msg=None):
        if result != ResultType(left, right):
            msg = msg or "%s != %s" % (result, (left, right))
            raise AssertionError(msg)


# Generated at 2022-06-22 21:30:51.760778
# Unit test for function recursive_diff
def test_recursive_diff():
    # Ensure recursive diff returns None if no difference
    assert not recursive_diff({'var_a': 'test'}, {'var_a': 'test'})

    # Ensure recursive diff returns expected differences
    results = recursive_diff({'var_a': 'test', 'var_b': {'var_b_a': 'test', 'var_b_b': 'test'}},
                             {'var_a': 'test2', 'var_b': {'var_b_a': 'test2', 'var_b_b': 'test'}})
    assert results == ({'var_a': 'test'}, {'var_a': 'test2'})



# Generated at 2022-06-22 21:31:03.852609
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'aAa': 'val', 'aBC': {'aAb':1}, 'aCb': [1, {'aAc': 2}, [3, {'aAd': 4}]]}
    expected_snake_dict = {'a_a_a': 'val', 'a_b_c': {'a_ab':1}, 'a_cb': [1, {'a_ac': 2}, [3, {'a_ad': 4}]]}
    assert camel_dict_to_snake_dict(camel_dict, False) == expected_snake_dict

# Generated at 2022-06-22 21:31:13.996072
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict1 = {'HTTPEndpoint': 'test_value'}
    camel_dict2 = {'TargetGroupARNs': ['arn:aws:elasticloadbalancing:eu-west-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067,arn:aws:elasticloadbalancing:eu-west-1:123456789012:targetgroup/my-other-targets/54dcef0349384aab']}
    camel_dict3 = {'Tags': [{'Key': 'test'}, {'Key': 'test2', 'Value': 'test3'}], 'SubnetARNs': ['arn:aws:ec2:eu-west-1a:54321:subnet/subnet-123456789']}
    camel_

# Generated at 2022-06-22 21:31:24.799267
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': 'foo.com',
        'LoadBalancerArns': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/my-load-balancer/50dc6c495c0c9188'],
        'MultiAZ': True,
        'Port': 443,
        'SslPolicy': 'ELBSecurityPolicy-TLS-1-1-2017-01',
        'Tags': [{'Key': 'foo', 'Value': 'bar'}],
        'VPCId': 'vpc-3ac0fb5f'
    }


# Generated at 2022-06-22 21:31:32.026145
# Unit test for function dict_merge
def test_dict_merge():
    """
    Simple test case to ensure the dict_merge function works as expected
    """

    a = {'a': 1, 'b': {'a': 1, 'b': 1}}
    b = {'b': {'c': 2}}

    c = dict_merge(a, b)

    assert c['a'] == 1
    assert 'c' in c['b']
    assert c['b']['c'] == 2



# Generated at 2022-06-22 21:31:43.325295
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    dict2 = {'a': {'b': {'c': 1}}, 'e': 4}
    expected = ({'a': {'b': {'d': 2}}}, {'a': {'b': {}}, 'e': 4})
    assert recursive_diff(dict1, dict2) == expected

    dict1 = {'a': 1, 'b': 2}
    dict2 = {'c': 3, 'd': 4}
    expected = ({'a': 1, 'b': 2}, {'c': 3, 'd': 4})
    assert recursive_diff(dict1, dict2) == expected


# Generated at 2022-06-22 21:31:54.122594
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        "some_dict_key": {
            "sub_some_dict_key": [
                1,
                2,
                3
            ],
        },
        "some_list": [
            {
                "sub_some_list": [
                    "foo",
                    "bar"
                ]
            },
            {
                "sub_some_list": [
                    "baz"
                ]
            }
        ]
    }


# Generated at 2022-06-22 21:32:03.376663
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 2}) == None
    assert recursive_diff({'a': 1, 'b': 2}, {'b': 2, 'a': 1}) == None
    assert recursive_diff({'a': 1, 'b': {'c': 2}}, {'a': 1, 'b': {'c': 2}}) == None
    assert recursive_diff({'a': 1, 'b': {'c': 2}}, {'a': 1, 'b': {'c': 2, 'd': 3}}) == ({'b': {'d': None}}, {'b': {'d': 3}})

# Generated at 2022-06-22 21:32:12.332768
# Unit test for function dict_merge
def test_dict_merge():
    a = {'job_type': {'name': 'ansible', 'interpreter': 'python', 'extra_vars': {'foo': 'bar'}}}
    b = {'job_type': {'name': 'python', 'interpreter': 'python3', 'extra_vars': {'baz': 'bat'}}}

    expected_result = {'job_type': {'name': 'python', 'interpreter': 'python3', 'extra_vars': {'foo': 'bar', 'baz': 'bat'}}}
    result = dict_merge(a, b)
    assert result == expected_result

# Generated at 2022-06-22 21:32:24.453861
# Unit test for function dict_merge
def test_dict_merge():
    """Test that dict_merge behaves as expected.
    The results should be equivalent to normal dictionary
    updates, except with recursive nested dictionary updates.
    """
    a = dict(a=1, b=dict(a=1, b=2), c=3)
    b = dict(b=dict(c=3, d=4), e=5)
    assert dict_merge(a, b) == dict(a=1, b=dict(a=1, b=2, c=3, d=4), c=3, e=5)

    a = dict(a=dict(b=dict(c=dict(d=1), f=dict(d=1)), g=1), h=dict(i=1))

# Generated at 2022-06-22 21:32:29.475360
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:32:38.534406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'ThisIsA': 'string'}) == {'this_is_a': 'string'}
    assert camel_dict_to_snake_dict({'ThisIsA': {'Thing': 'string', 'OtherThing': ['list', 'of', 'strings']}},
                                    reversible=True) == {'t_h_i_s_i_s_a': {'t_h_i_n_g': 'string',
                                                                             'o_t_h_e_r_t_h_i_n_g': ['list', 'of',
                                                                                                      'strings']}}

# Generated at 2022-06-22 21:32:49.133161
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    snake_dict = {
        'one_level': {
            'two_level': {
                'three_level': 'hello world'
            }
        },
        'one_level_list': [
            {'two_level': 'hello world'},
            {'two_level': 'hello world'},
            {'two_level': 'hello world'}
        ]
    }

    expected_dict = {
        'oneLevel': {
            'twoLevel': {
                'threeLevel': 'hello world'
            }
        },
        'oneLevelList': [
            {'twoLevel': 'hello world'},
            {'twoLevel': 'hello world'},
            {'twoLevel': 'hello world'}
        ]
    }


# Generated at 2022-06-22 21:32:56.219581
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a,b) == c

    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'pass' : 'cat', 'number' : '5' } } }

# Generated at 2022-06-22 21:33:06.461185
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit test for function recursive_diff """

    import json

    with open('tests/unit/plugins/modules/testdata.json') as f:
        reference_data = json.load(f)

    # Test case #1: No difference between the two dictionaries
    dict1 = reference_data['dict_1']
    dict2 = reference_data['dict_1']

    assert not recursive_diff(dict1, dict2)

    # Test case #2: Only items are different
    dict1 = reference_data['dict_1']
    dict2 = reference_data['dict_2']

    assert recursive_diff(dict1, dict2) == reference_data['dict_diff_1']

    # Test case #3: Item values are different
    dict1 = reference_data['dict_1']

# Generated at 2022-06-22 21:33:18.142038
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    assert snake_dict_to_camel_dict({}) == {}
    assert snake_dict_to_camel_dict(dict()) == {}
    assert snake_dict_to_camel_dict(dict(a=1, b=2)) == {}

    assert snake_dict_to_camel_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert snake_dict_to_camel_dict({'A': 1, 'B': 2}) == {'A': 1, 'B': 2}

    assert snake_dict_to_camel_dict({'a': 1, 'b_c': 2}) == {'a': 1, 'bC': 2}
    assert snake_dict_to_camel_dict({'a': 1, 'b_c_d': 2})

# Generated at 2022-06-22 21:33:28.166482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for function camel_dict_to_snake_dict
    """

    def dict_compare(dict1, dict2):

        def ordered(obj):
            if isinstance(obj, dict):
                return sorted((k, ordered(v)) for k, v in obj.items())
            if isinstance(obj, list):
                return sorted(ordered(x) for x in obj)
            else:
                return obj

        return ordered(dict1) == ordered(dict2)

    # Test case 1: (ansible/awx/test.json)

# Generated at 2022-06-22 21:33:35.280821
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    simple_dict = {
        'foo_bar': 1,
        'foo_bar2': 3,
        'foo.bar': 2,
        'foo': {
            'FOO_BAR': 1,
            'foo-bar': 2
        }
    }

    assert simple_dict == snake_dict_to_camel_dict(snake_dict_to_camel_dict(simple_dict),
                                                   capitalize_first=False)



# Generated at 2022-06-22 21:33:42.565103
# Unit test for function recursive_diff
def test_recursive_diff():

    # No differences
    dict1 = {'a': 1, 'b': {'x': 2, 'y': 3}}
    dict2 = {'a': 1, 'b': {'x': 2, 'y': 3}}
    assert recursive_diff(dict1, dict2) is None

    # Simple key/values are different
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = {'a': 2, 'b': 2, 'c': 3}
    assert recursive_diff(dict1, dict2) == ({'a': 1}, {'a': 2})

    # A mapping is different
    dict2['b'] = {'a': 1}
    assert recursive_diff(dict1, dict2) == ({'b': 2}, {'b': {'a': 1}})



# Generated at 2022-06-22 21:33:54.121801
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {'my_snake_dict': {'my_snake_key_1': 12, 'my_snake_key_2': 13},
                  'my_second_key': {'my_sub_key_2': [{'sub_sub_key_1': 31},
                                                     {'sub_sub_key_2': 32}]}}

    expected_camel_dict = {'mySnakeDict': {'mySnakeKey1': 12, 'mySnakeKey2': 13},
                           'mySecondKey': {'mySubKey2': [{'subSubKey1': 31},
                                                         {'subSubKey2': 32}]}}

    # Test the default, which is the original implementation

# Generated at 2022-06-22 21:34:05.127051
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:34:16.841026
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    original_dict = {
        "some_snake_key": "some_value",
        "some_other_snake_key": "some_other_value",
        "some_list": [
            "list_snake_key",
            "list_snake_key"
        ],
        "some_dict_in_list": [
            {
                "some_list_dict_key": "some_value"
            }
        ],
        "some_dict": {
            "some_nested_snake_key": "some_value"
        }
    }
    camelized_dict = snake_dict_to_camel_dict(original_dict)
    for key in original_dict:
        assert key != camelized_dict[key]
    assert "someList" in camelized_dict

# Generated at 2022-06-22 21:34:28.040200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_in = {'KeyName': 'MyKeyPair', 'SecurityGroups': [{'GroupId': 'value1'},{'GroupId': 'value2'}]}
    dict_out = camel_dict_to_snake_dict(dict_in)
    dict_expected = {'key_name': 'MyKeyPair', 'security_groups': [{'group_id': 'value1'},{'group_id': 'value2'}]}
    if dict_out != dict_expected:
        raise AssertionError("Fail")
    pass
    dict_out_reversible = camel_dict_to_snake_dict(dict_in, reversible=True)

# Generated at 2022-06-22 21:34:36.884385
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test to verify function recursive_dict"""
    from ansible.module_utils.ec2 import recursive_diff

    d1 = {'a': '1', 'b': {'b1': '2'}, 'c': '3'}
    d2 = {'a': '1', 'b': {'b1': '2'}, 'c': '3', 'd': '4'}
    d3 = {'a': '1', 'b': {'b1': '2'}, 'e': '5'}
    d4 = {'a': '1', 'b': {'b1': '2'}, 'b': {'b1': '3'}}
    d5 = {'a': '1', 'b': {'b1': '2'}, 'b': {'b2': '3'}}


# Generated at 2022-06-22 21:34:47.432522
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict = {
        'a_b': 1,
        'c_d': 2,
        'e_f': [{
            'g_h': 1,
            'i_j': 2,
            'k_l': [1, 2, 3],
        }]
    }
    expected = {
        'aB': 1,
        'cD': 2,
        'eF': [{
            'gH': 1,
            'iJ': 2,
            'kL': [1, 2, 3],
        }]
    }
    assert snake_dict_to_camel_dict(snake_dict) == expected

# Generated at 2022-06-22 21:34:56.166182
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    result = dict_merge(a,b)
    correct = {
        'first' : {
            'all_rows' : {
                'pass' : 'dog',
                'fail' : 'cat',
                'number' : '5'
            }
        }
    }
    assert result == correct

# Generated at 2022-06-22 21:35:06.597247
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    d = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    assert dict_merge(a, b) == c
    assert dict_merge(b, d) == d
    assert dict_merge(d, a) == c
    assert dict_merge({}, {}) == {}

# Generated at 2022-06-22 21:35:16.862780
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    import json
    import os
    import yaml

    root_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

    with open(os.path.join(root_dir, "docs", "ec2", "examples", "example_asg.json")) as fh:
        f = json.load(fh)

    asg = camel_dict_to_snake_dict(f)
    asg = yaml.safe_dump(asg, default_flow_style=False)


# Generated at 2022-06-22 21:35:26.797604
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'bazBam': {
                'fooBarBaz': 'test',
                'samplE': 4
            },
            'one': 1,
            'two': 2,
            'three': 3
        },
        'someValue': True,
        'anotherValue': 84,
        'someList': [1, 2, 3, 4, 5],
        'someOtherList': [
            {
                'one': 1,
                'two': 2,
                'three': 3
            },
            {
                'four': 4,
                'five': 5,
                'six': 6
            }
        ]
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-22 21:35:35.163560
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    input_dict = {
        'string': 'abc',
        'list': [
            {
                'string': 'def',
            },
            {
                'string': 'ghi',
            },
        ],
        'dict': {
            'string': 'jkl',
            'list': [
                {
                    'string': 'mno',
                },
                {
                    'string': 'pqr',
                },
            ]
        }
    }

# Generated at 2022-06-22 21:35:46.576358
# Unit test for function dict_merge
def test_dict_merge():

    class AnsibleModuleMock(object):

        def __init__(self, changed=False, failed=False, diff=None):
            self.changed = changed
            self.failed = failed
            self.diff = diff

        def exit_json(self, changed=False, **kwargs):
            self.changed = changed
            self.kwargs = kwargs
            return

        def fail_json(self, msg=None, **kwargs):
            self.failed = True
            self.msg = msg
            self.kwargs = kwargs
            return

    def _dict_merge_test_helper(a, b, expected, existing_tags=None, insert_before=None, insert_after=None, debug=False):

        module = AnsibleModuleMock()

# Generated at 2022-06-22 21:35:56.742724
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'instance': {
            'name1': 'val1',
            'name2': 'val2',
            'name3': 'val3',
            'name4': 'val4',
            'name5': 'val5',
            'name6': 'val6',
        }
    }

    dict2 = {
        'instance': {
            'name1': 'val1',
            'name2': 'val2',
            'name3': 'val3',
            'name4': 'val4',
            'name5': 'changed_value',
        }
    }

    expected = {
        'instance': {
            'name6': 'val6',
            'name5': 'changed_value',
        }
    }


# Generated at 2022-06-22 21:36:05.188772
# Unit test for function dict_merge
def test_dict_merge():
    x = dict(a=1, b=2, c=dict(a=1, b=2, d=4), e=dict(a=1, b=2))
    y = dict(a=3, b=4, c=dict(a=3), d=5)
    z = dict_merge(x, y)
    assert z == dict(a=3, b=4, c=dict(a=3, b=2, d=4), d=5, e=dict(a=1, b=2))
    a = dict(a=dict(k=1, l=1))
    b = dict(a=dict(l=2))
    c = dict_merge(a, b)
    assert c == dict(a=dict(k=1, l=2))


# Generated at 2022-06-22 21:36:13.561408
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    with open("test/unit/plugins/modules/cloudwatch_rule_facts.json") as json_file:
        rule_data = json.load(json_file)
    rule_result = camel_dict_to_snake_dict(rule_data)
    assert rule_result['source_rule_id'] == 'arn:aws:events:us-east-1:123456789012:rule/MyEC2-BackToNormalStatus'
    assert rule_result['arn'] == 'arn:aws:events:us-east-1:123456789012:rule/MyEC2-AlertStatus'
    assert rule_result['state'] == 'ENABLED'


# Generated at 2022-06-22 21:36:21.230477
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-22 21:36:32.173117
# Unit test for function dict_merge

# Generated at 2022-06-22 21:36:41.064702
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:36:50.270467
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert dict_merge({'a': {'x': 1}}, {'a': {'y': 2}}) == {'a': {'y': 2, 'x': 1}}
    assert dict_merge({'a': {'x': 1}}, {'b': {'y': 2}}) == {'a': {'x': 1}, 'b': {'y': 2}}
    assert dict_merge({'a': {'x': 1}}, {'a': 1}) == {'a': 1}

# Generated at 2022-06-22 21:36:58.333570
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [{'g': 5}, {'h': 6}]})
    assert result == {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [{'g': 5}, {'h': 6}]}
    result = camel_dict_to_snake_dict({'Tags': {'key': {'value': 'value'}}}, ignore_list=['Tags'])
    assert result == {'tags': {'key': {'value': 'value'}}}

# Generated at 2022-06-22 21:37:04.462254
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a':{'aa':'foo', 'ab':'bar'}, 'b':'baz', 'c':'zoo'}
    dict2 = {'a':{'aa':'foo1', 'ab':'bar1'}, 'b':'baz1', 'c':'zoo1'}
    expected = ({'a':{'aa':'foo', 'ab':'bar'}, 'b':'baz', 'c':'zoo'},
                {'a':{'aa':'foo1', 'ab':'bar1'}, 'b':'baz1', 'c':'zoo1'})
    actual = recursive_diff(dict1, dict2)
    assert actual == expected, "%s != %s" % (actual, expected)

# Generated at 2022-06-22 21:37:13.733757
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {
        'HelloWorld': {
            'HTTPEndpoint': {
                'TestTag': {
                    'hello': 1,
                    'world': 'test'
                },
                'testTag': 1,
                'testTags': [
                    1,
                    2,
                    3
                ]
            }
        }
    }
    snake = {
        'hello_world': {
            'http_endpoint': {
                'test_tag': {
                    'hello': 1,
                    'world': 'test'
                },
                'test_tag': 1,
                'test_tags': [
                    1,
                    2,
                    3
                ]
            }
        }
    }


# Generated at 2022-06-22 21:37:20.531076
# Unit test for function dict_merge
def test_dict_merge():
    a = {"a": 1, "b": {"c": 2}, "d": [1,2,3]}
    assert dict_merge(a, {"d": [4, 5, 6]}) == {"a": 1, "b": {"c": 2}, "d": [4, 5, 6]}
    assert dict_merge(a, {"a": 2}) == {"a": 2, "b": {"c": 2}, "d": [1,2,3]}

# Generated at 2022-06-22 21:37:29.360881
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'a': {
            'b': {
                'c': 'd',
            },
            'e': 'f',
            'g': 'h',
        },
        'i': {
            'j': 'k',
        },
        'l': 'm',
        'n': 'o',
    }

# Generated at 2022-06-22 21:37:35.584211
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(a=1, b=2, c=dict(a=1, b=2, c=3))
    dict2 = dict(a=4, b=5, c=dict(a=4, b=5, c=6, d=7))
    dict3 = dict_merge(dict1, dict2)
    assert dict3.items() == dict(
        a=4,
        b=5,
        c=dict(a=4, b=5, c=6, d=7),
    ).items()


# Generated at 2022-06-22 21:37:46.220697
# Unit test for function dict_merge
def test_dict_merge():

    class TestObj(object):
        pass

    # Confirm that Types other than dicts are returned unchanged
    assert dict_merge({}, TestObj()) == TestObj()

    # Confirm that a simple merge works
    assert dict_merge({'x': 1}, {'y': 2}) == {'x': 1, 'y': 2}
    assert dict_merge({}, {'x': 1}) == {'x': 1}

    # Confirm that a merge with a dict inside works
    assert dict_merge({'x': {'y': 2}}, {'x': {'z': 3}}) == {'x': {'y': 2, 'z': 3}}

# Generated at 2022-06-22 21:37:52.690749
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'c': 2}}
    b = {'a': 1, 'b': {'d': 4}}
    merged_dict = dict_merge(a, b)
    assert(merged_dict == {'a': 1, 'b': {'c': 2, 'd': 4}})

# Generated at 2022-06-22 21:38:00.849590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "InstanceType": "t2.medium",
        "Tags": {
            "Key": "Value"
        }
    }
    result = camel_dict_to_snake_dict(test_dict)
    assert result == {
        'instance_type': 't2.medium',
        'tags': {
            'Key': 'Value'
        }
    }
    result = camel_dict_to_snake_dict(test_dict, reversible=True)
    assert result == {
        'instance_type': 't2.medium',
        'tags': {
            'Key': 'Value'
        }
    }


# Generated at 2022-06-22 21:38:13.091931
# Unit test for function dict_merge
def test_dict_merge():

    # Simple merge test
    test1 = dict(key1='value1', key2='value2', key3=dict(key4='value4', key5='value5'))
    test2 = dict(key1='value1b', key2='value2b', key3=dict(key4='value4b', key5='value5b'))
    assert dict_merge(test1, test2) == dict(key1='value1b', key2='value2b', key3=dict(key4='value4b', key5='value5b'))

    # Merge where value1 and value2 are lists
    test1 = dict(key1='value1', key2='value2', key3=dict(key4='value4', key5='value5'))

# Generated at 2022-06-22 21:38:21.529498
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(one=1, two=2, three=3, four=dict(x=4, y=5, z=6))
    b = dict(four=dict(x=44, y=55), seven=7, eight=8, nine=9)
    c = dict_merge(a, b)
    print("a is %s" % a)
    print("b is %s" % b)
    print("c is %s" % c)
    assert (a['one'] == c['one'])
    assert (a['two'] == c['two'])
    assert (a['three'] == c['three'])
    assert (b['seven'] == c['seven'])
    assert (b['eight'] == c['eight'])
    assert (b['nine'] == c['nine'])

# Generated at 2022-06-22 21:38:28.357675
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    d1 = {'tags': {'tagKey': 'tagValue'}}
    result = snake_dict_to_camel_dict(d1, capitalize_first=False)
    assert result == {'tags': {'tagKey': 'tagValue'}}
    result = snake_dict_to_camel_dict(d1, capitalize_first=True)
    assert result == {'Tags': {'tagKey': 'tagValue'}}



# Generated at 2022-06-22 21:38:36.990992
# Unit test for function recursive_diff
def test_recursive_diff():
    import pprint
    import sys

    dict_1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 1,
            'e': 2,
            'f': {
                'g': 1,
                'h': 2
            }
        },
        'i': {
            'j': 1,
            'k': 2,
            'l': {
                'm': 1,
                'n': 2
            }
        }
    }


# Generated at 2022-06-22 21:38:46.188856
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "Return": "doc",
        "TransferEncoding": "chunked",
        "ContentType": "application/json",
        "Vary": "Accept-Encoding",
        "Headers": {
            "x-amzn-RequestId": "24d4b4e4-2c2e-44b0-9efb-dfe4034bd05b",
            "Date": "Thu, 04 Apr 2019 12:48:50 GMT",
            "Content-Type": "application/x-amz-json-1.1"
        }
    }


# Generated at 2022-06-22 21:38:57.159322
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case = {
        'IncludeGlobalServiceEvents': False,
        'HTTPStatusCode': 200,
        'ResponseMetadata': {
            'HTTPHeaders': {
                'date': 'Mon, 23 Jan 2017 01:54:07 GMT',
                'content-type': 'text/xml',
                'content-length': '879',
                'vary': 'accept-encoding',
                'x-amzn-requestid': 'e04b10f8-e9cc-11e6-aabd-27efc6b54e30'
            },
            'RequestId': 'e04b10f8-e9cc-11e6-aabd-27efc6b54e30'
        },
        'HTTPStatusMessage': 'OK',
        'RetryAttempts': 0
    }
   

# Generated at 2022-06-22 21:39:09.023323
# Unit test for function recursive_diff

# Generated at 2022-06-22 21:39:17.128176
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Nested dictionary example
    d = {
        'vpc_id': 'vpc-12345678',
        'sgs': {
            'web': 'sg-12345678',
            'db': 'sg-87654321'
        }
    }

    # Expected results
    expected_dict = {
        'vpc_id': 'vpc-12345678',
        'sgs': {
            'db': 'sg-87654321',
            'web': 'sg-12345678',
        },
    }

    expected_dict_capitalized = {
        'vpc_id': 'vpc-12345678',
        'sgs': {
            'db': 'sg-87654321',
            'web': 'sg-12345678',
        },
    }

    #

# Generated at 2022-06-22 21:39:28.893983
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:39:39.645042
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    snake_dict_test = {'test_dict': {'test_dict_2': {'test_dict_3': {'value': 'test1', 'value_2': 'test2'}, 'value_3': 'test3'}, 'value_4': 'test4'}, 'value_5': 'test5'}

    camel_dict_test = {'TestDict': {'TestDict2': {'TestDict3': {'Value': 'test1', 'Value2': 'test2'}, 'Value3': 'test3'}, 'Value4': 'test4'}, 'Value5': 'test5'}
    assert snake_dict_to_camel_dict(snake_dict_test) == camel_dict_test


# Generated at 2022-06-22 21:39:49.889288
# Unit test for function dict_merge
def test_dict_merge():
    # Simple merge
    a = { "a": 1, "b": 2, "c": 3 }
    b = { "d": 4, "e": 5, "b": "changed" }
    assert dict_merge(a, b) == {"a": 1, "b": "changed", "c": 3, "d": 4, "e": 5}
    # Nested merge single layer
    a = { "a": { "b": 1, "c": 2}, "d": 3}
    b = { "a": { "d": 4, "e": 5}, "f": 6}
    assert dict_merge(a,b) == {"a": {"b": 1, "c": 2, "d": 4, "e": 5}, "d": 3, "f": 6}
    # Nested merge 2 layers

# Generated at 2022-06-22 21:39:57.288074
# Unit test for function dict_merge
def test_dict_merge():
    class Test(object):
        def test(self):
            a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
            b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
            c = dict_merge(a, b)
            assert(c == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } })
    test = Test()
    test.test()

# Generated at 2022-06-22 21:40:09.223440
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        'a': {
            'a1': {
                'a11': 'value',
                'a12': 'oldvalue',
                'a13': {
                    'a131': 'newvalue',
                },
            },
            'a2': 1,
        },
        'b': {
            'b1': [1,2,3],
            'b2': [4,5],
            'b3': [4],
            'b4': [4,5,6],
        },
        'c': [1,2,3,4,5]
    }

# Generated at 2022-06-22 21:40:19.568092
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-22 21:40:24.041919
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    key = 'instance_ids'
    value = ['i-123456', 'i-abcdef']
    expected_result = {'InstanceIds': ['i-123456', 'i-abcdef']}
    assert snake_dict_to_camel_dict({key: value}) == expected_result
