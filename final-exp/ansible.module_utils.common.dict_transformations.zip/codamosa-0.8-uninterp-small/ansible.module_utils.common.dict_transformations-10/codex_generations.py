

# Generated at 2022-06-24 20:25:30.442838
# Unit test for function recursive_diff
def test_recursive_diff():
    print('\n\n***Start*** test_recursive_diff')
    int_0 = dict()
    int_1 = dict()
    int_1['key1'] = 1
    int_2 = dict()
    int_2['key2'] = 2

    int_3 = dict()
    int_3['key1'] = 1
    int_3['key2'] = 2
    int_4 = dict()
    int_4['key1'] = 1
    int_4['key2'] = 3

    print('\nTest case 1: Dicts int_0 and int_0')
    var_1 = recursive_diff(int_0, int_0)
    print('Return value var_1: ', var_1)

# Generated at 2022-06-24 20:25:39.666938
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:25:44.289603
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPServer': {'HTTPEndpoint': {'EndpointName': 'my_http_endpoint',
                                                                      'Timeout': {'Hours': 0, 'Minutes': 2}}}}) ==\
        {'http_server': {'h_t_t_p_endpoint': {'endpoint_name': 'my_http_endpoint', 'timeout': {'hours': 0, 'minutes': 2}}}}


# Generated at 2022-06-24 20:25:54.916006
# Unit test for function recursive_diff
def test_recursive_diff():

    d1 = {
        'Bucket': 'mybucket',
        'state': 'present',
        'notify': {
            'events': [
                's3:ObjectCreated:*'
            ],
            'topic_config': {
                'Topic': 'arn:aws:sns:us-east-1:698519295917:s3'
            }
        },
        'filter': {
            'Key': {
                'filterrules': [
                    {
                        'Name': 'prefix',
                        'Value': 'document'
                    },
                    {
                        'Name': 'suffix',
                        'Value': 'pdf'
                    }
                ]
            }
        }
    }


# Generated at 2022-06-24 20:26:01.758293
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict()
    dict2 = dict()
    result = recursive_diff(dict1, dict2)
    assert result is None

    dict1 = dict(a=1, c=dict(d=6))
    dict2 = dict(a=1, b=2, c=dict(e=7))
    result = recursive_diff(dict1, dict2)
    assert result == (dict(b=2), dict(b=2, c=dict(e=7)))

    dict1 = dict(a=1, c=dict(d=6))
    dict2 = dict(a=1, b=2, c=dict(d=None, e=7))
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-24 20:26:10.799607
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test 1: Test snake case generated as expected
    int_1 = {
        "methodName": "method_name",
        "httpBody": "http_body",
        "httpCorsOrigin": "http_cors_origin",
        "httpMethod": "http_method",
        "httpPath": "http_path",
        "image": "image",
        "name": "name",
        "queueLength": "queue_length",
        "revisionId": "revision_id",
        "rootDirectory": "root_directory",
        "vpcId": "vpc_id",
        "accountId": "account_id",
        "timeoutMs": "timeout_ms"
    }

# Generated at 2022-06-24 20:26:16.834448
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Different tests for different ways to call the function

    # Test Case 1
    int_1 = {'A': 'B'}
    var_1 = snake_dict_to_camel_dict(int_1)
    # print(var_1)
    assert var_1 == {'a': 'B'}

    # Test Case 2
    int_2 = [1, 2]
    var_2 = snake_dict_to_camel_dict(int_2)
    # print(var_2)
    assert var_2 == [1, 2]

    # Test Case 3
    int_3 = {'A': [{'B': 1, 'C': 2}, {'B': 3, 'C': 4}]}
    var_3 = snake_dict_to_camel_dict(int_3)
    #

# Generated at 2022-06-24 20:26:24.577527
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': {'c': 10, 'd': 20}}}
    dict2 = {'a': {'b': {'c': 10, 'e': 20}}}
    diff = recursive_diff(dict1, dict2)
    assert diff == ({'a': {'b': {'d': 20}}}, {'a': {'b': {'e': 20}}})



# Generated at 2022-06-24 20:26:34.772260
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Set up test cases for function camel_dict_to_snake_dict
    # First case
    print('Starting Test 1')
    dict_in_0 = {'ID': 0, 'Name': 'string', 'Type': 'AWS::CloudFormation::Stack',
                 'Properties': {'TemplateURL': 'string', 'NotificationARNs': 0, 'Parameters': 0, 'TimeoutInMinutes': 0,
                                'OnFailure': 'string', 'Capabilities': 0}}

# Generated at 2022-06-24 20:26:42.585947
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'c': 'x', 'd': {'e': 5}}}
    dict2 = {'a': 1, 'b': {'c': 'y', 'd': {'e': 6}}}
    assert recursive_diff(dict1, dict2) == ({'b': {'c': 'x', 'd': {'e': 5}}},
                                            {'b': {'c': 'y', 'd': {'e': 6}}})

    dict1 = {'a': 1, 'b': {'c': 'x', 'd': {'e': 5}}}
    dict2 = {'a': 1, 'b': {'c': 5, 'd': {'e': 6}}}

# Generated at 2022-06-24 20:26:57.463791
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Case 0:
    # None input
    dict_0 = None
    var_0 = _camel_to_snake(dict_0)
    expected_result_0 = None
    assert var_0 == expected_result_0

    # Case 1:
    # Normal usage
    dict_1 = {"IP":"5"}
    var_1 = _camel_to_snake(dict_1)
    expected_result_1 = "5"
    assert var_1 == expected_result_1


# Generated at 2022-06-24 20:27:08.840861
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case = {
        "firstName": "John",
        "lastName": "Smith",
        "address": {
            "city": "New York",
            "state": "NY",
            "zipCode": 10021
        },
        "phoneNumber": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "fax",
                "number": "646 555-4567"
            }
        ],
        "status": True,
        "tags": [
            "I_am_a_tag",
            "I_am_also_a_tag"
        ],
        "ThingsThatShouldNotConvert": [
            "HelloThere"
        ]
    }

# Generated at 2022-06-24 20:27:11.378142
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = {'Enabled': True}
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == {'enabled': True}


# Generated at 2022-06-24 20:27:22.466229
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Testing with : TestCase 1")
    var_1 = {}
    expected_1 = {}
    result_1 = camel_dict_to_snake_dict(var_1)
    assert expected_1 == result_1

    print("Testing with : TestCase 2")
    var_2 = {
        'Arn': 'arn:aws:secretsmanager:us-east-1:123456789012:secret:test_secret-a1b2c3',
        'Description': 'Test secret',
        'Name': 'test_secret',
        'Tags': [],
        'VersionId': 'EXAMPLE1-90ab-cdef-fedc-ba987SECRET1'
    }

# Generated at 2022-06-24 20:27:29.111749
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CloudWatchEventsRoleArn': 'arn', 'HTTPEndpoint': 'http', 'S3KeyPrefix': 'prefix'}) == {'cloud_watch_events_role_arn': 'arn', 'h_t_t_p_endpoint': 'http', 's3_key_prefix': 'prefix'}



# Generated at 2022-06-24 20:27:38.996830
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:49.602017
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    input_dict = {'myName': 'myValue', 'myList': [{'myDict1': {'innerKey': 'innerValue'}, 'myDict2': {'innerKey': 'innerValue'}}, {'myDict1': {'innerKey': 'innerValue'}, 'myDict2': {'innerKey': 'innerValue'}}], 'myInteger': 0, 'myString': 'myStringValue'}
    output_dict = camel_dict_to_snake_dict(input_dict)

# Generated at 2022-06-24 20:27:59.424205
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {
        'AzureEndpoint': {
            'Host': '0.0.0.0',
            'Port': 1000
        }
    }

    assert camel_dict_to_snake_dict(input) == {
        'azure_endpoint': {
            'host': '0.0.0.0',
            'port': 1000
        }
    }

    assert camel_dict_to_snake_dict(input, True) == {
        'azure_endpoint': {
            'host': '0.0.0.0',
            'port': 1000
        }
    }


# Generated at 2022-06-24 20:28:06.449939
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = {
        'camelized': 'this',
        'SubType': None,
        'Tags': {
            'Name': 'test'
        },
        'HTTPEndpoint': 'http://example.com',
        'HTTPEndpoints': [
            {
                'HTTPPOSTEndpoint': 'http://example.com',
                'Name': 'test'
            }
        ]
    }

# Generated at 2022-06-24 20:28:18.255037
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.amazon.aws import camel_dict_to_snake_dict


# Generated at 2022-06-24 20:28:30.051567
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': 1, 'BarBaz': 2}) == {'foo': 1, 'bar_baz': 2}
    assert camel_dict_to_snake_dict({'Foo': 1, 'BarBaz': 2, 'HTTPEndpoint': 3}) == {'foo': 1, 'bar_baz': 2, 'http_endpoint': 3}
    assert camel_dict_to_snake_dict({'Foo': 1, 'BarBaz': 2, 'HTTPEndpoint': 3}, reversible=True) == {'foo': 1, 'bar_baz': 2, 'h_t_t_p_endpoint': 3}

# Generated at 2022-06-24 20:28:34.149985
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:42.095577
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test 1: input dict is None
    dict_1 = None
    result_1 = camel_dict_to_snake_dict(dict_1)
    assert result_1 is None, "camel_dict_to_snake_dict(None) should return None"

    # Test 2: input dict is a dict, but is empty
    dict_2 = {}
    result_2 = camel_dict_to_snake_dict(dict_2)
    assert result_2 == {}, "camel_dict_to_snake_dict({}) should return {}"

    # Test 3: input dict contains a single key-value pair
    dict_3 = {'a': 1}
    result_3 = camel_dict_to_snake_dict(dict_3)

# Generated at 2022-06-24 20:28:52.888230
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:02.333736
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d_snake_0 = camel_dict_to_snake_dict({})
    assert d_snake_0 == {}, \
        'The actual output is: %s' % d_snake_0

    d_snake_1 = camel_dict_to_snake_dict({'Key': 'Value'})
    assert d_snake_1 == {'key': 'Value'}, \
        'The actual output is: %s' % d_snake_1

    d_snake_2 = camel_dict_to_snake_dict({'Foo': {'Bar': 'Value', 'Baz': 'Value'}})
    assert d_snake_2 == {'foo': {'bar': 'Value', 'baz': 'Value'}}, \
        'The actual output is: %s' % d

# Generated at 2022-06-24 20:29:11.863396
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:21.396405
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_0 = {
        'theInput': {
            'HTTPEndpoint': 'is awsom',
            'BucketName': 'camel-case-dict',
            'ObjectKey': 'object-key',
            'Tags': {
                'created': 'j'
            },
            'ValidateCertificate': True,
            'ValidateCertificateAuthority': False,
            'ValidatePath': True,
            'ValidatePort': False,
        },
        'thisIsADict': {
            'One': 1,
            'Two': 2
        }
    }

    # Test that a normal dictionary converts correctly
    test_0 = camel_dict_to_snake_dict(test_dict_0)

# Generated at 2022-06-24 20:29:29.069589
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = {
        'key' : 'value',
        'dict': {
            'key' : 'value',
        },
        'list': [{
            'key': 'value'
        }],
        'tags': {
            'Tags': [{
                'Key': 'k',
                'Value': 'v'
            }]
        }
    }
    test_dict = camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict))
    assert test_dict == snake_dict



# Generated at 2022-06-24 20:29:40.106794
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # simple 1 key check
    test_dict = {
        'CamelCase': 'test'
    }
    expected_result = {
        'camel_case': 'test'
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_result

    # more complicated 1 key check
    test_dict = {
        'CamelCase1': {
            'CamelCase2': 'test'
        }
    }
    expected_result = {
        'camel_case1': {
            'camel_case2': 'test'
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_result

    # list value check

# Generated at 2022-06-24 20:29:48.957507
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:00.922345
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com', 'Tags': {'tag_key': 'tag_value'}})
    assert result == {'tags': {'tag_key': 'tag_value'}, 'h_t_t_p_endpoint': 'http://www.example.com'}


# Generated at 2022-06-24 20:30:10.111986
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "Tags": [{
            "Key": "test-key-1",
            "Value": "test-value-1"
        }, {
            "Key": "test-key-2",
            "Value": "test-value-2"
        }],
        "NodeGroupId": "test-node-group-id",
        "NodeGroupName": "test-node-group-name"
    }

# Generated at 2022-06-24 20:30:20.849928
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Abc': [1,2,3]})['abc'] == [1,2,3]
    assert camel_dict_to_snake_dict({'HTTPServer': 'http://127.0.0.1'})['h_t_t_p_server'] == 'http://127.0.0.1'
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://127.0.0.1'})['h_t_t_p_endpoint'] == 'http://127.0.0.1'
    assert camel_dict_to_snake_dict({'Abc': [1,2,3]}, True)['abc'] == [1,2,3]

# Generated at 2022-06-24 20:30:29.232567
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Simple test that converts a DrupalSettingsDumperOptions
    # https://docs.aws.amazon.com/elasticbeanstalk/latest/apireference/API_DrupalSettingsDumperOptions.html
    test_dict = {
        'DatabasePassword': 'example',
        'DrupalAdminEmail': 'admin@example.com',
        'DrupalDb': 'example',
        'DrupalRoot': '/tmp/drupal-8.4.4/',
        'Internal': True,
    }
    expected_res = {
        'database_password': 'example',
        'drupal_admin_email': 'admin@example.com',
        'drupal_db': 'example',
        'drupal_root': '/tmp/drupal-8.4.4/',
        'internal': True,
    }
    result = camel

# Generated at 2022-06-24 20:30:39.803209
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    simple_input = {
        "Text": "This is a test string.",
        "Number": 123,
        "ListOfStuff": [
            {
                "Dict": {
                    "SubText": "This is a sub test string.",
                    "SubNumber": 456,
                }
            },
            {
                "Dict": {
                    "SubText": "This is another sub test string.",
                    "SubNumber": 789,
                }
            }
        ]
    }


# Generated at 2022-06-24 20:30:47.624357
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    emptydict = dict()
    dict1 = dict(
        DictKey=dict(DictKey=dict(DictKey='valuenested')))
    dict2 = dict(
        DictKey=dict(DictKey=dict(DictKey='valuenested', DictKey2='value')))
    dict3 = dict(
        DictKey=dict(DictKey=dict(DictKey='valuenested', DictKey2='value'),
                    DictKey2='value2'),
        DictKey2='topvalue')

# Generated at 2022-06-24 20:30:55.432976
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    _dict = {
        "HTTPEndpoint": "http://172.17.0.1/root/1",
        "HTTPSEndpoint": "https://172.17.0.1/root/1"
    }
    output = camel_dict_to_snake_dict(_dict)
    assert output['http_endpoint'] == 'http://172.17.0.1/root/1'
    assert output['https_endpoint'] == 'https://172.17.0.1/root/1'



# Generated at 2022-06-24 20:31:04.970450
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = {"AWSTemplateFormatVersion": "2010-09-09", "Resources": {"DBInstance": {"Properties": {"AvailabilityZone": "us-east-1d", "DBInstanceClass": "db.t2.micro", "DBInstanceIdentifier": "mydbinstance", "Engine": "mysql", "EngineVersion": "5.6.37", "MasterUsername": "admin", "MasterUserPassword": "mypassword", "Tags": [{"Key": "Department", "Value": "Engineering"}, {"Key": "Project", "Value": "Some project"}], "VPCSecurityGroups": ["sg-ab12cd34"]}, "Type": "AWS::RDS::DBInstance"}}}
    var_0 = camel_dict_to_snake_dict(int_0)

# Generated at 2022-06-24 20:31:14.614186
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_cases = {}

# Generated at 2022-06-24 20:31:21.826476
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def flatten(d, parent_key='', sep='.'):
        items = []
        for k, v in d.items():
            new_key = parent_key + sep + k if parent_key else k
            if isinstance(v, MutableMapping):
                items.extend(flatten(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)

    int_0 = {"Cluster":["cluster-example"],"ClusterParameterGroupFamily":"redshift-1.0","Description":"Test description","Tags":[],"ParameterGroupName":"parameter-group-example"}

    result_0 = snake_dict_to_camel_dict(int_0)
    result_1 = camel_dict_to_snake_dict(result_0)

# Generated at 2022-06-24 20:31:41.249500
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:50.007368
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = {
        "RetrySettings": {
            "RetryToken": 1,
            "RetryTimeMilliSeconds": 2
        },
        "Encryption": {
            "KMSKeyId": "key1",
            "KMSMasterKeyID": "key2",
            "KMSType": "type1"
        },
        "Tags": {
            "key1": "value1",
            "key2": "value2"
        },
        "Arn": "arn1",
        "Name": "name1"
    }

# Generated at 2022-06-24 20:31:55.684936
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"FirstName": "David", "LastName": "Stanley", "LastNameOrigin": "Polish"}
    expected_camel_dict = {"first_name": "David", "last_name": "Stanley", "last_name_origin": "Polish"}
    actual_camel_dict = camel_dict_to_snake_dict(camel_dict)
    assert actual_camel_dict == expected_camel_dict



# Generated at 2022-06-24 20:32:04.659104
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:15.126683
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Setup
    camel_dict = {'Foo': {'CreateDBInstanceReadReplica': {'Tags': [{'Key': 'string', 'Value': 'string'}]}, 'PubliclyAccessible': True}, 'DBInstanceIdentifier': 'string', 'DBSubnetGroupName': 'string'}

    # Act
    result = camel_dict_to_snake_dict(camel_dict, reversible=True)

    # Verify
    assert result == {'foo': {'create_d_b_instance_read_replica': {'tags': [{'key': 'string', 'value': 'string'}]}, 'publicly_accessible': True}, 'd_b_instance_identifier': 'string', 'd_b_subnet_group_name': 'string'}



# Generated at 2022-06-24 20:32:24.015713
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:32.921584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # User provided parameters for camel_dict_to_snake_dict
    
    arg_0 = {
    "AllowedPattern": "(([0-9]{1,3}).){3}[0-9]{1,3}",
    "ConstraintDescription": "must be a valid IP address of the form x.x.x.x.",
    "MaxLength": 15,
    "MinLength": 7,
    "NoEcho": True,
    "Ref": "Ref_param0",
    "Type": "String",
    }


# Generated at 2022-06-24 20:32:41.953072
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:49.852770
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = dict()
    int_0 = dict({'DBName': 'string', 'Tags': dict({'DBSecurityGroups': 'string', 'DBParameterGroups': 'string', 'DBSubnetGroups': 'string'})})
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == dict({'db_name': 'string', 'tags': dict({'d_b_security_groups': 'string', 'd_b_parameter_groups': 'string', 'd_b_subnet_groups': 'string'})})



# Generated at 2022-06-24 20:32:57.402448
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:28.757015
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert_equals(camel_dict_to_snake_dict(int_0),None)

# Generated at 2022-06-24 20:33:37.678801
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    param = {
        "autoscaling_group_name": "test",
        "tags": [
            {
                "ResourceId": "test",
                "ResourceType": "test",
                "key": "test",
                "propagate_at_launch": True,
                "value": "test"
            }
        ]
    }
    camel_to_snake = {
        'autoscaling_group_name': 'test',
        'tags': [{
            'ResourceId': 'test',
            'ResourceType': 'test',
            'key': 'test',
            'propagate_at_launch': True,
            'value': 'test'}]
    }
    assert camel_dict_to_snake_dict(param) == camel_to_snake


# Generated at 2022-06-24 20:33:47.139434
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:48.943593
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'helloWorld': 'world'}) == {'hello_world': 'world'}



# Generated at 2022-06-24 20:33:58.181210
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'test_case_0' in globals(), "you should properly name your test case."
    assert snake_dict_to_camel_dict({"test_case_0": 1}) == {"testCase0": 1}, "check your camel_dict_to_snake_dict function"
    assert snake_dict_to_camel_dict({"test_case_1": 1}) == {"testCase1": 1}, "check your camel_dict_to_snake_dict function"
    assert snake_dict_to_camel_dict({"test_case_2": 1}) == {"testCase2": 1}, "check your camel_dict_to_snake_dict function"

# Generated at 2022-06-24 20:34:06.641972
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"testCamelCase": "test"}, False, []) == {'test_camel_case': 'test'}
    assert camel_dict_to_snake_dict({"testHTTPCase": "test"}, False, []) == {'test_h_t_t_p_case': 'test'}
    assert camel_dict_to_snake_dict({"testABCCase": "test"}, False, []) == {'test_a_b_c_case': 'test'}
    assert camel_dict_to_snake_dict({"testHTTPEndpoint": "test"}, True, []) == {'h_t_t_p_endpoint': 'test'}

# Generated at 2022-06-24 20:34:13.795993
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = {
        "HTTPEndpoint": {
            "EndpointState": "REGISTERED",
            "EndpointTypes": [
                "READER",
                "WRITER"
            ],
            "ExpirationTime": "2019-12-30T23:46:40.811Z",
            "HTTPEndpointDescription": "description",
            "HTTPEndpointUrl": "https://url/",
            "ID": "kinesis-stream-reader",
            "Name": "name"
        }
    }
    var_0 = snake_dict_to_camel_dict(int_0)

# Generated at 2022-06-24 20:34:25.938536
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    example_dict_camel_case = {
        "AccessLogs": {
            "Enabled": True,
            "S3Bucket": "example-bucket",
            "S3Prefix": "example-logs"
        },
        "LoadBalancerName": "my-load-balancer",
        "Listeners": [
            {
                "InstancePort": 80,
                "LoadBalancerPort": 80,
                "Protocol": "http"
            }
        ]
    }


# Generated at 2022-06-24 20:34:37.124300
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CamelCase': 'foo'}) == {'camel_case': 'foo'}
    assert camel_dict_to_snake_dict({'camelCase': 'foo'}) == {'camel_case': 'foo'}
    assert camel_dict_to_snake_dict({'CamelCase': 'foo'},
                                    reversible=True) == {'c_amel_case': 'foo'}
    assert camel_dict_to_snake_dict({'camelCase': 'foo'},
                                    reversible=True) == {'camel_case': 'foo'}

# Generated at 2022-06-24 20:34:46.817150
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Initial case
    int_0 = {'MyTag': 'Test Tag'}
    result_0 = camel_dict_to_snake_dict(int_0)
    assert result_0 == {'my_tag': 'Test Tag'}

    # Dictionary with multiple items
    int_1 = {'MyTag': 'Test Tag', 'MyList': ['my', 'list']}
    result_1 = camel_dict_to_snake_dict(int_1)
    assert result_1 == {'my_tag': 'Test Tag', 'my_list': ['my', 'list']}

    # Nested dictionary and list
    int_2 = {'MyTag': 'Test Tag',
             'MyList': ['my', 'list'],
             'NestedDict': {'NestedItem': {'Item': 2}}}
