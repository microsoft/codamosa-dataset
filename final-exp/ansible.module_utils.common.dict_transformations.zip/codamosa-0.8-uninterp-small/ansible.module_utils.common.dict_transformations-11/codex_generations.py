

# Generated at 2022-06-24 20:25:32.589047
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2, 'dict3': {'a': 1, 'b': 2}, 'dict2': {'a': 1, 'b': 2}}
    b = {'x': 2, 'z': 3, 'dict3': {'c': 3, 'd': 4}, 'dict2': {'c': 3, 'd': 4}}
    c = dict_merge(a, b)
    print(c)
    assert c['x'] == 2
    assert c['y'] == 2
    assert c['z'] == 3
    assert c['dict3']['a'] == 1
    assert c['dict3']['b'] == 2
    assert c['dict3']['c'] == 3
    assert c['dict3']['d'] == 4

# Generated at 2022-06-24 20:25:41.587600
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test case 1
    dict1 = {u'a': {u'b': 2}}
    dict2 = {u'a': {u'b': 3}}
    expected = ({u'a': {u'b': 2}}, {u'a': {u'b': 3}})
    result = recursive_diff(dict1, dict2)
    assert expected == result

    # Test case 2
    dict1 = {u'a': 5}
    dict2 = {u'a': 5}
    expected = None
    result = recursive_diff(dict1, dict2)
    assert expected == result

    # Test case 3
    dict1 = {u'a': 5}
    dict2 = {u'b': 5}
    expected = ({u'a': 5}, {u'b': 5})
    result = recursive_diff

# Generated at 2022-06-24 20:25:49.012445
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {
        "TagResources": [
            {
                "ResourceARN": "string",
                "Tags": {
                    "string": "string"
                }
            },
            {
                "ResourceARN": "string",
                "Tags": {
                    "string": "string"
                }
            }
        ]
    }
    dict_1 = {
        "tag_resources": [
            {
                "resource_arn": "string",
                "tags": {
                    "string": "string"
                }
            },
            {
                "resource_arn": "string",
                "tags": {
                    "string": "string"
                }
            }
        ]
    }
    result_0 = camel_dict_to_snake_dict(dict_0)
    assert result_0

# Generated at 2022-06-24 20:25:54.104284
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {
        'a': {
            'b': {
                'c': 'd'
            }
        },
        'e': 'f',
        'g': 'h',
    }

    dict2 = {
        'a': {
            'b': {
                'c': 'not d'
            }
        },
        'i': 'j'
    }

    assert dict_merge(dict1, dict2) == {'a': {'b': {'c': 'not d'}}, 'e': 'f', 'g': 'h', 'i': 'j'}



# Generated at 2022-06-24 20:25:55.418575
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 20:26:00.192531
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:26:06.187630
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected_result = {
        'tag_list': [
            {
                'value': 'test_value',
                'key': 'test_key'
            }
        ]
    }
    test_data = {
        'TagList': [
            {
                'Value': 'test_value',
                'Key': 'test_key'
            }
        ]
    }
    result = camel_dict_to_snake_dict(test_data)
    assert result == expected_result

# Generated at 2022-06-24 20:26:17.424286
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = camel_dict_to_snake_dict({
          "LocalGateway": {
            "State": "available",
            "Tags": [
                    {
                      "Value": "lb.vgw.dev",
                      "Key": "Name"
                    }
                  ],
            "LocalGatewayId": "local-0df1d5e5c5f5e5d5a"
          }
        }, True, ignore_list=['Tags'])

# Generated at 2022-06-24 20:26:21.465446
# Unit test for function dict_merge
def test_dict_merge():
    pass
    #assert dict_merge() == expected



# Generated at 2022-06-24 20:26:30.954852
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=1, b=dict(c=2), d=4)
    b = dict(a=1, b=dict(c=3), e=5)
    assert dict_merge(a,b) == dict(a=1, b=dict(c=3), d=4, e=5)
    assert dict_merge(b,a) == dict(a=1, b=dict(c=2), d=4, e=5)
    assert a == dict(a=1, b=dict(c=2), d=4)
    assert b == dict(a=1, b=dict(c=3), e=5)

# Generated at 2022-06-24 20:26:40.034820
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 0

    # Input:
    #     bool_0 = False
    #     var_0 = camel_dict_to_snake_dict(bool_0)
    # Expected:
    #     var_0 = None

    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    assert var_0 == None



# Generated at 2022-06-24 20:26:48.765317
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    str_0 = "str"
    var_1 = camel_dict_to_snake_dict(str_0)
    int_0 = 32
    var_2 = camel_dict_to_snake_dict(int_0)
    float_0 = 5.2823
    var_3 = camel_dict_to_snake_dict(float_0)
    print("Test", var_0)
    print("Test", var_1)
    print("Test", var_2)
    print("Test", var_3)



# Generated at 2022-06-24 20:26:59.134894
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool = False
    var = camel_dict_to_snake_dict(bool)
    assert var is False
    assert camel_dict_to_snake_dict({'foo': 'bar'}) == {'foo': 'bar'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz', 'anz': {'fooBar': 'baz'}}) == {'foo_bar': 'baz', 'anz': {'foo_bar': 'baz'}}

# Generated at 2022-06-24 20:27:09.035696
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("*** Testing camel_dict_to_snake_dict() ***")
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    if var_0:
        print("camel_dict_to_snake_dict", var_0, "    <--- Problem")
    else:
        print("camel_dict_to_snake_dict", var_0, "    <--- OK")
    int_0 = 5 
    var_0 = camel_dict_to_snake_dict(int_0)
    if var_0:
        print("camel_dict_to_snake_dict", var_0, "    <--- Problem")

# Generated at 2022-06-24 20:27:11.775818
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(bool_0) == False
    assert camel_dict_to_snake_dict(var_0) == False
    assert camel_dict_to_snake_dict(var_1) == {'timestamp': '2018-07-31T16:28:17Z'}


# Generated at 2022-06-24 20:27:22.843963
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = True
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = True
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = True
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = True
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_

# Generated at 2022-06-24 20:27:33.963422
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:44.522545
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {}
    dict_1 = {}
    dict_1['HttpEndpoint'] = '0'
    dict_0['HttpEndpoints'] = dict_1
    dict_2 = {}
    dict_2['HttpEndpoints'] = dict_1
    dict_0['HttpEndpoints'] = dict_2
    dict_3 = {}
    dict_3['HttpEndpoints'] = dict_2
    dict_0['HttpEndpoints'] = dict_3
    dict_4 = {}
    dict_4['HttpEndpoint'] = '0'
    dict_0['HttpEndpoints'] = dict_4
    dict_5 = {}
    dict_5['HttpEndpoint'] = '0'
    dict_0['HttpEndpoints'] = dict_5


# Generated at 2022-06-24 20:27:51.978599
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_1 = True
    var_1 = camel_dict_to_snake_dict(bool_1)
    bool_2 = False
    var_2 = camel_dict_to_snake_dict(bool_2)
    bool_3 = True
    var_3 = camel_dict_to_snake_dict(bool_3)
    bool_4 = False
    var_4 = camel_dict_to_snake_dict(bool_4)
    bool_5 = True
    var_5 = camel_dict_to_snake_dict(bool_5)
    bool_6 = False
    var_6 = camel_dict_to_snake_dict(bool_6)
    bool_

# Generated at 2022-06-24 20:28:00.221552
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    '''Checking for exceptions'''
    instance_0 = {}
    instance_1 = {}
    instance_2 = {}
    instance_3 = {}
    instance_4 = {}
    instance_5 = {}
    instance_6 = {}
    instance_7 = {}
    instance_8 = {}
    instance_9 = {}
    instance_10 = {}
    instance_11 = {}
    instance_12 = {}
    instance_13 = {}
    instance_14 = {}
    instance_15 = {}
    instance_16 = {}
    instance_17 = {}
    instance_18 = {}
    instance_19 = {}
    instance_20 = {}
    instance_21 = {}
    instance_22 = {}
    instance_23 = {}
    instance_24 = {}
    instance_25 = {}
    instance_26 = {}


# Generated at 2022-06-24 20:28:15.329190
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"DataSourceConfigurations": "{\"Configurations\": \"test\", \"Enabled\": true}"}, False, 'Tags') == {'data_source_configurations': '{"Configurations": "test", "Enabled": true}'}
    assert camel_dict_to_snake_dict({'DatabaseName': 'test'}, False, 'Tags') == {'database_name': 'test'}
    assert camel_dict_to_snake_dict({'TableName': 'test'}, False, 'Tags') == {'table_name': 'test'}
    assert camel_dict_to_snake_dict({'SourceRegion': 'test'}, False, 'Tags') == {'source_region': 'test'}

# Generated at 2022-06-24 20:28:21.780858
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_1 = {'TestWeight': 21}
    dict_2 = {'test_weight': 21}
    if camel_dict_to_snake_dict(dict_1) == dict_2:
        print("Expected: %s\n Output: %s\n Success\n" % (dict_2, camel_dict_to_snake_dict(dict_1)))
    else:
        print("Expected: %s\n Output: %s\n Fail\n" % (dict_2, camel_dict_to_snake_dict(dict_1)))



# Generated at 2022-06-24 20:28:29.986529
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.azure_rm_common import camel_dict_to_snake_dict
    bool_0 = False
    str_0 = '!@#$%^&*()'
    tuple_0 = (1, 2)
    dict_0 = {}
    list_0 = []

    var_0 = {'foo': 'bar'}
    var_1 = var_0
    var_0 = camel_dict_to_snake_dict(var_0)
    # SetVarEqual
    var_2 = 'bar'
    var_1['foo'] = var_2
    # SetVarEqual
    var_3 = {'foo': 'bar'}
    var_1 = var_3
    var_3 = camel_dict_to_snake_dict(var_3)
   

# Generated at 2022-06-24 20:28:40.518957
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    assert camel_dict_to_snake_dict(bool_0) == False
    bool_1 = True
    assert camel_dict_to_snake_dict(bool_1) == True
    dict_0 = {'foo_bar': 'bar'}
    assert camel_dict_to_snake_dict(dict_0) == {'foo_bar': 'bar'}
    dict_1 = {'fooBar': 'bar'}
    assert camel_dict_to_snake_dict(dict_1) == {'foo_bar': 'bar'}
    dict_2 = {'fooBar': {'foo_bar': 'bar', 'bar': 'foo'}}

# Generated at 2022-06-24 20:28:51.453185
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var = { "Name": "Test", "isDisplay": True, "SSLCertificate": { "CertificateType": "iam" } }
    var_dict = camel_dict_to_snake_dict(var, True)
    assert isinstance(var_dict, dict)
    assert var_dict['name'] == 'Test'
    assert isinstance(var_dict['ssl_certificate'], dict)
    assert var_dict['ssl_certificate']['certificate_type'] == 'iam'

    var = { "Tags": { "Name": "Test" } }
    var_dict = camel_dict_to_snake_dict(var)
    assert isinstance(var_dict['tags'], dict)
    assert var_dict['tags']['Name'] == 'Test'

# Generated at 2022-06-24 20:28:52.306894
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()


# Generated at 2022-06-24 20:28:56.868915
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    assert var_0 == False

    bool_1 = True
    var_1 = camel_dict_to_snake_dict(bool_1)
    assert var_1 == True

    dict_0 = {'foo': '', 'bar': {'baz': {}, 'quz': {}, 'quux': {}, 'corge': {}, 'grault': {}}, 'baz': {'raz': {'dwa': {}, 'kar': {}}}, 'quux': {}, 'corge': {}}
    var_2 = camel_dict_to_snake_dict(dict_0)

# Generated at 2022-06-24 20:28:59.812217
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)

    bool_1 = False
    var_1 = camel_dict_to_snake_dict(bool_1)



# Generated at 2022-06-24 20:29:05.902307
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    dict_0 = dict()
    dict_1 = {}
    dict_2 = {'HTTPEndpoint': 'a', 'TargetGroupARNs': ['arn:one', 'arn:two'], 'Tags': {'Key': 'Value'}}

    # pass dict test
    dict_3 = deepcopy(dict_2)
    dict_3['Tags'] = {'Key': 'Value', 'key': 'value'}

    dict_4 = deepcopy(dict_2)
    dict_4['Tags'].update({'key': 'value'})

    dict_5 = deepcopy(dict_2)
    dict_5['Tags'] = {'key': 'value'}

    dict_6 = deepcopy(dict_2)

# Generated at 2022-06-24 20:29:15.243312
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'firstName' != camel_dict_to_snake_dict({'FirstName': 'foo'})
    assert 'firstName' == camel_dict_to_snake_dict(
        {'FirstName': 'foo'}, reversible=True)

    assert 'h_t_t_p_endpoint' == camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'foo'}, reversible=True)

    assert 'http_endpoint' == camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'foo'})


# Generated at 2022-06-24 20:29:27.858976
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # If a dictionary with keys that are in camelCase is passed as the argument to camel_dict_to_snake_dict, it should return a dictionary with the keys in snake_case.
    assert camel_dict_to_snake_dict({"camelCase": "foo"}) == {"camel_case": "foo"}, "Function camel_dict_to_snake_dict() did not work properly."


# Generated at 2022-06-24 20:29:30.357424
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test setup

    # Test function call
    camel_dict_to_snake_dict()

    # Test assertions

    # Test cleanup


# Generated at 2022-06-24 20:29:37.952222
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(4) == 4
    assert camel_dict_to_snake_dict(4.0) == 4.0
    assert camel_dict_to_snake_dict('string') == 'string'
    assert camel_dict_to_snake_dict([1, 2, 3]) == [1, 2, 3]
    assert camel_dict_to_snake_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}



# Generated at 2022-06-24 20:29:47.376193
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:55.738869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    assert isinstance(camel_dict_to_snake_dict(bool_0), bool)
    assert False == bool_0
    bool_0 = True
    assert isinstance(camel_dict_to_snake_dict(bool_0), bool)
    assert True == bool_0
    int_0 = 0
    assert isinstance(camel_dict_to_snake_dict(int_0), int)
    assert 0 == int_0
    int_0 = 1
    assert isinstance(camel_dict_to_snake_dict(int_0), int)
    assert 1 == int_0
    float_0 = 0.0
    assert isinstance(camel_dict_to_snake_dict(float_0), float)
    assert 0.0 == float_0


# Generated at 2022-06-24 20:30:04.595591
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    bool_1 = True
    var_1 = camel_dict_to_snake_dict(bool_1)
    int_0 = -746228078
    var_2 = camel_dict_to_snake_dict(int_0)
    int_1 = -1823018022
    var_3 = camel_dict_to_snake_dict(int_1)
    float_0 = -3.0796127747571
    var_4 = camel_dict_to_snake_dict(float_0)
    float_1 = -2.7383597631935
    var_5 = camel_dict_to_snake_dict(float_1)

# Generated at 2022-06-24 20:30:16.270285
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 0
    bool_0 = False
    var_0 = camel_dict_to_snake_dict(bool_0)
    assert not var_0
    # Test case 1
    bool_1 = None
    var_1 = camel_dict_to_snake_dict(bool_1)
    assert var_1 is None
    # Test case 2
    bool_2 = True
    var_2 = camel_dict_to_snake_dict(bool_2)
    assert var_2
    # Test case 3
    int_3 = 1666889633
    var_3 = camel_dict_to_snake_dict(int_3)
    assert var_3 == 1666889633
    # Test case 4
    str_4 = "Ansible"
    var_4 = camel_dict_

# Generated at 2022-06-24 20:30:19.152193
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert False

# Generated at 2022-06-24 20:30:23.695394
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(bool_0) is False
    assert camel_dict_to_snake_dict(var_0) == 'foo-bar'
    assert camel_dict_to_snake_dict(var_0, True) == 'foo-bar'



# Generated at 2022-06-24 20:30:30.484660
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_camel_dict = {
        'HTTPResponseCodeRanges': [
            {
                'StatusRangeStart': 500,
                'StatusRangeEnd': 509
            }
        ],
        'HTTPEndpoint': {
            'Endpoint': 's3-website.us-east-1.amazonaws.com'
        },
        'HostHeader': {
            'Values': [
                's3-website.us-east-1.amazonaws.com'
            ]
        },
        'PathPattern': {
            'Values': [
                '/error/*'
            ]
        }
    }


# Generated at 2022-06-24 20:30:48.787937
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(bool_0) == bool_0
    # assert camel_dict_to_snake_dict(bool_0) == expected_0
    # assert camel_dict_to_snake_dict(bool_0) == expected_0
    # assert camel_dict_to_snake_dict(bool_0) == expected_0


# Generated at 2022-06-24 20:30:57.316088
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = {'HTTPEndpoint': True}
    dict2 = {'HTTPEndpoint': True}
    expected_dict = {'http_endpoint': True}
    actual_dict = camel_dict_to_snake_dict(dict1)
    assert actual_dict == expected_dict

    dict1 = {'HTTPEndpoint': True}
    dict2 = {'h_t_t_p_endpoint': True}
    expected_dict = {'http_endpoint': True}
    actual_dict = camel_dict_to_snake_dict(dict1, reversible=True)
    assert actual_dict == expected_dict


# Generated at 2022-06-24 20:31:08.337797
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Pass the boolean input to the camel_dict_to_snake_dict function
    # Test used to ensure the function raises an exception when passed a
    # boolean (or any other incorrect type)
    test_case_0()
    camel_dict = {
        "TestKey": "TestValue",
        "TestKey2": "TestValue",
        "TestKey3": {
            "TestKey4": "TestValue",
            "TestKey5": "TestValue"
        },
        "PortMappings": {
            "TestKey6": "TestValue"
        },
        "Tags": {
            "TestKey": "TestValue"
        }
    }
    reversible = False
    ignore_list = ()

# Generated at 2022-06-24 20:31:14.134118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test with valid parameters
    res = camel_dict_to_snake_dict({"f1":"v1", "f2": "v2"})
    assert res == {'f1': 'v1', 'f2': 'v2'}, "Expected {'f1': 'v1', 'f2': 'v2'}"
    # Test with invalid parameters
    res = camel_dict_to_snake_dict({"F1":"v1", "f2": "v2"})
    assert res == {'f1': 'v1', 'f2': 'v2'}, "Expected {'f1': 'v1', 'f2': 'v2'}"

# Generated at 2022-06-24 20:31:20.069438
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input1 = camel_dict_to_snake_dict({'HttpEndpoint': 'httpEndpoint', 'CamelCase': 'dromedaryCase'})
    output1 = {'http_endpoint': 'httpEndpoint', 'camel_case': 'dromedaryCase'}
    assert input1 == output1

    input2 = camel_dict_to_snake_dict(
        {
            'CamelCase': 'dromedaryCase',
            'another': 'another',
            'source': {'InnerCamelCase': 'innerDromedaryCase'},
            'list': ['ListCamelCase', 'ListDromedaryCase']
        }
    )


# Generated at 2022-06-24 20:31:28.587990
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    with pytest.raises(TypeError) as e:
        bool_0 = False
        var_0 = camel_dict_to_snake_dict(bool_0)

    assert e.type == TypeError
    assert "Expected 'dict' type, got bool" == str(e.value)

    with pytest.raises(TypeError) as e:
        bool_1 = True
        var_1 = camel_dict_to_snake_dict(bool_1)

    assert e.type == TypeError
    assert "Expected 'dict' type, got bool" == str(e.value)

    with pytest.raises(TypeError) as e:
        array_0 = list()
        var_2 = camel_dict_to_snake_dict(array_0)

    assert e.type == TypeError


# Generated at 2022-06-24 20:31:36.943969
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {'Bool': False, 'Int': 1, 'List': [1, 'a', {'Bool': True}],
                  'Dict': {'Bool': True, 'Dict': {'Bool': False}, 'Int': 2}}
    output_dict = {'bool': False, 'int': 1, 'list': [1, 'a', {'bool': True}],
                   'dict': {'bool': True, 'dict': {'bool': False}, 'int': 2}}
    result = camel_dict_to_snake_dict(input_dict)
    assert result == output_dict


# Generated at 2022-06-24 20:31:46.497094
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = False
    str_0 = ""
    dict_0 = {
        "A": "B",
        "C": "B",
        "D": "E"
    }
    dict_1 = {
        "A": "B",
        "C": "B",
        "d": "E"
    }
    dict_2 = {
        "A": "B",
        "B": "B",
        "C": "D"
    }
    dict_3 = {
        "A": "B",
        "B": "B",
        "D": "D"
    }
    #Test cases for camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:55.307493
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:58.789175
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert '`camel_dict_to_snake_dict` arg 1 must be a dictionary' in str(the_exception)
