

# Generated at 2022-06-24 20:25:39.051239
# Unit test for function recursive_diff
def test_recursive_diff():
    # Values that don't match
    dict1 = {"a": "1", "b": "2", "c": ["3", "4", "5"]}
    dict2 = {"a": "1", "b": "3", "c": ["3", "4", "5"], "d": "4"}
    expected = ({'b': '2'}, {'b': '3', 'd': '4'})
    diff = recursive_diff(dict1, dict2)
    assert diff == expected

    # Order of lists does not matter
    dict1 = {"a": "1", "b": ["2", "3", "4"]}
    dict2 = {"a": "1", "b": ["3", "4", "2"]}
    expected = None
    diff = recursive_diff(dict1, dict2)

# Generated at 2022-06-24 20:25:42.707789
# Unit test for function recursive_diff
def test_recursive_diff():

    left = dict(a=1, b=2, c=dict(d=3, e=4, f=5), g=6, h=7)
    right = dict(a=1, b=2, c=dict(d=3, e=9, f=5), g=6, h=7)
    expected = (dict(), dict(c=dict(e=9)))
    actual = recursive_diff(left, right)

    assert actual == expected

# Generated at 2022-06-24 20:25:48.184655
# Unit test for function dict_merge
def test_dict_merge():
    expected_result = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': {'x': 5, 'y': 6}, 'f': {'q': 7, 'r': 8}}
    assert expected_result == dict_merge({'a': 1},
                                         {'b': 2,
                                          'c': 3,
                                          'd': 4,
                                          'e': {'x': 5},
                                          'f': {'q': 7}})

# Generated at 2022-06-24 20:25:51.855923
# Unit test for function recursive_diff
def test_recursive_diff():
    try:
        recursive_diff(None, None)
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError")

    d1 = {
        "a": 1,
        "b": 2,
        "c": {
            "d": {
                "e": 1,
                "f": 2
            },
        },
    }

    d2 = {
        "a": 2,
        "b": 2,
        "c": {
            "d": {
                "e": 1,
                "f": 3
            },
        },
    }
    d3 = {
        "a": 2,
        "b": 3,
        "c": {
            "d": {
                "e": 1,
                "f": 2
            },
        },
    }


# Generated at 2022-06-24 20:25:57.551475
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'dict1': {
            'key1': 'value1a'
        },
        'key2': 'value2',
        'key3': 'value3'
    }
    dict2 = {
        'dict1': {
            'key1': 'value1b'
        },
        'key2': 'value2',
        'key3': 'value3'
    }
    expected = ({
        'dict1': {
            'key1': 'value1a'
        }
    }, {
        'dict1': {
            'key1': 'value1b'
        }
    })
    actual = recursive_diff(dict1, dict2)
    assert expected == actual, 'recursive_diff returned %s when it should have returned %s' % (actual, expected)


#

# Generated at 2022-06-24 20:26:04.914473
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'camelDictToSnakeDict'
    str_1 = 'camel_dict_to_snake_dict'
    var_0 = _camel_to_snake(str_0, False)
    assert var_0 == str_1

    str_0 = 'camelDictToSnakeDict'
    str_1 = 'camelDictToSnakeDict'
    var_0 = _camel_to_snake(str_0, True)
    assert var_0 == str_1



# Generated at 2022-06-24 20:26:13.108747
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_0 = {
        'version': 3,
        'vars': {
            'foo': 'bar',
            'baz': 'qux'
        },
        'plays': {
            'play0': {
                'hosts': ['all'],
                'tasks': [{
                    'include': 'graphite.yml'
                }]
            },
            'play1': {
                'hosts': ['beastie'],
                'vars': {
                    'foo': 'baz',
                    'new_var': 'is_unset'
                },
                'tasks': [{
                    'include': 'graphite.yml'
                }]
            }
        }
    }


# Generated at 2022-06-24 20:26:21.497032
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b=dict(c=2, d=dict(e=3)), f=4)
    dict2 = dict(a=1, b=dict(d=dict(e=3), f=5), f=4)
    assert(recursive_diff(dict1, dict2) == (dict(b=dict(c=2)), dict(b=dict(f=5))))
    dict1 = dict(a=dict(a=1, b=dict(c=2, d=dict(e=3)), f=4))
    dict2 = dict(a=dict(a=1, b=dict(d=dict(e=3), f=5), f=4))

# Generated at 2022-06-24 20:26:24.991364
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Arrange:

    # Act:
    # Assert:
    assert 1 == 1 # TODO replace with actual asserts

# Generated at 2022-06-24 20:26:28.873564
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    pass


# Generated at 2022-06-24 20:26:40.138041
# Unit test for function dict_merge
def test_dict_merge():
    list_0 = {'k1': {'n1': 1}}
    list_1 = {'k1': {'n2': 2}}
    list_2 = {'k1': {'n1': 1, 'n2': 2}}
    var_0 = dict_merge(list_0, list_1)

    #assert(var_0 == list_2)


# Generated at 2022-06-24 20:26:41.940164
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-24 20:26:52.109764
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    my_dict = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'f': {
                                'g': [
                                    {'h': {'i': 'j'}},
                                    {'k': {'l': 'm'}},
                                    {'n': {'o': 'p'}}
                                ]
                            }
                        }
                    }
                }
            }
        }
    }

# Generated at 2022-06-24 20:26:59.055806
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_0 = {'AWS': {'AccessKey': None, 'SecretKey': None}, 'Connection': {'Password': None, 'Port': None, 'RegionName': None, 'UserName': None}}
    expected_output_0 = {'aws': {'access_key': None, 'secret_key': None}, 'connection': {'password': None, 'port': None, 'region_name': None, 'user_name': None}}
    assert camel_dict_to_snake_dict(input_0) == expected_output_0



# Generated at 2022-06-24 20:27:03.930747
# Unit test for function dict_merge
def test_dict_merge():
    # empty dicts
    assert dict_merge({}, {}) == {}

    # dicts with non-overlapping keys
    assert dict_merge(
        {'a': 1},
        {'b': 2}
    ) == {'a': 1, 'b': 2}

    # dicts with overlapping keys that can be merged
    assert dict_merge(
        {'a': 1, 'b': {'c': 1}},
        {'b': {'d': 2}}
    ) == {'a': 1, 'b': {'c': 1, 'd': 2}}

    # dicts with overlapping keys that cannot be merged

# Generated at 2022-06-24 20:27:13.455163
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({1:1}, {2:2}) == {1: 1, 2: 2}
    assert dict_merge({1:1, 3:3}, {2:2, 3:30}) == {1: 1, 3: 30, 2: 2}
    assert dict_merge({1:1}, {'foo': [1, 2, 3], 2:2}) == {1: 1, 'foo': [1, 2, 3], 2: 2}
    assert dict_merge({1:1, 3:3}, {'foo': [1, 2, 3], 2:2}) == {1: 1, 3: 3, 'foo': [1, 2, 3], 2: 2}

# Generated at 2022-06-24 20:27:21.665507
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': {'b': 1, 'c': 2}, 'd': {'e': 1, 'f': 2}}
    d2 = {'a': {'b': 1, 'c': 2, 'd': 3}, 'g': {'h': 1, 'i': 2}}
    d3 = {'a': {'b': 1, 'c': 2, 'd': 3}, 'd': {'e': 1, 'f': 2}, 'g': {'h': 1, 'i': 2}}
    assert d3 == dict_merge(d1, d2)


# Generated at 2022-06-24 20:27:28.894270
# Unit test for function dict_merge
def test_dict_merge():
    assert type(dict_merge({}, {})) == dict
    assert type(dict_merge({}, {'a': 1})) == dict
    assert type(dict_merge({'a': 1}, {})) == dict

    # merge empty dicts
    assert dict_merge({}, {}) == {}

    # merge empty dict with non-empty dict
    assert dict_merge({}, {'a': 1}) == {'a': 1}

    # merge non-empty dict with empty dict
    assert dict_merge({'a': 1}, {}) == {'a': 1}

    # override values
    assert dict_merge({'a': 1}, {'a': 2}) == {'a': 2}

    # add values

# Generated at 2022-06-24 20:27:37.834068
# Unit test for function dict_merge
def test_dict_merge():
    a = {'Simple': 'before', 'Complex': {'A': [1, 2, 3], 'B': [4, 5, 6]}}
    b = {'Simple': 'after', 'Complex': {'A': [3, 4, 5], 'C': [7, 8, 9]}}
    expected = {'Simple': 'after', 'Complex': {'A': [3, 4, 5], 'B': [4, 5, 6], 'C': [7, 8, 9]}}
    actual = dict_merge(a, b)
    assert expected == actual, 'Expected %s, got %s' % (expected, actual)


# Generated at 2022-06-24 20:27:44.854801
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Running  tests for function camel_dict_to_snake_dict")
    # Integration tests using real data
    list_1 = {"1": {"2": {"3": [{"4": 5}]}}, "6": {"7": 8}, "9": 10}
    var_1 = camel_dict_to_snake_dict(list_1)
    print(var_1)
    print("Test for case 0")
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {}



# Generated at 2022-06-24 20:27:55.354803
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'name': 'test'}, {}) == ({'name': 'test'}, {})
    assert recursive_diff({}, {'name': 'test'}) == ({}, {'name': 'test'})
    assert recursive_diff({'name': 'test'}, {'name': 'test'}) is None
    assert recursive_diff({'name': 'test'}, {'name': 'test2'}) == ({'name': 'test'}, {'name': 'test2'})
    assert recursive_diff({'name': 'test1'}, {'name': 'test2', 'new': 'test'}) == ({'name': 'test1'}, {'name': 'test2', 'new': 'test'})

# Generated at 2022-06-24 20:28:04.416574
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = camel_dict_to_snake_dict(None)
    list_1 = camel_dict_to_snake_dict({"SubnetIds": ["subnet-a93ea8ef"]})
    list_2 = camel_dict_to_snake_dict({"SubnetIds": ["subnet-a93ea8ef"]}, False)
    list_3 = camel_dict_to_snake_dict({"SubnetIds": [["subnet-a93ea8ef"]]}, False)
    list_4 = camel_dict_to_snake_dict({"SubnetIds": [["subnet-a93ea8ef"]]}, True)

# Generated at 2022-06-24 20:28:15.811988
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:20.619952
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test that expected exceptions are raised
    # (none)
    # Test that expected results are returned
    assert(camel_dict_to_snake_dict(None) is None)
    assert(camel_dict_to_snake_dict({}) == {})
    assert(camel_dict_to_snake_dict({'Key': 'Value'}) == {'key': 'Value'})


# Generated at 2022-06-24 20:28:26.189609
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test function camel_dict_to_snake_dict()
    """

    # 1
    # Test case with simple dictionary
    list_1 = {'Hellow': 'worl'}
    var_0 = camel_dict_to_snake_dict(list_1)
    expected = {'hellow': 'worl'}
    assert var_0 == expected


# Generated at 2022-06-24 20:28:36.786835
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "VPNConnection": {
            "VpnConnectionId": "vpn-7e2b6d1f",
            "State": "deleting",
            "CustomerGatewayConfiguration": "..."
        }
    }
    dict2 = {
        "VPNConnection": {
            "State": "deleting",
            "CustomerGatewayConfiguration": "...",
            "Tags": [
                {
                    "Key": "Name",
                    "Value": "VPN"
                }
            ],
            "VpnConnectionId": "vpn-7e2b6d1f"
        }
    }
    actual_result = recursive_diff(dict1, dict2)

# Generated at 2022-06-24 20:28:42.363489
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key0': 0, 'key1': 1, 'key2': 2, 'key3': {'key3': '3', 'key4': '4', 'key5': '5'}}
    dict2 = {'key0': 0, 'key2': 2, 'key3': {'key3': '3', 'key4': '4'}, 'key9': {'key9': '9'}}
    assert recursive_diff(dict1, dict2) == ({'key1': 1, 'key3': {'key5': '5'}}, {'key9': {'key9': '9'}})

# Generated at 2022-06-24 20:28:53.065575
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 is None
    list_0 = {u'Int': [12345]}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {u'int': [12345]}
    list_0 = {u'VPCRegion': u'eu-west-1'}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {u'vpc_region': u'eu-west-1'}

# Generated at 2022-06-24 20:29:02.471046
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {1: "2", 3: "4"}
    assert camel_dict_to_snake_dict(list_0) == {"1": "2", "3": "4"}
    list_0 = {1: "2", 3: "4", 5: {"6": "7", "8": "9", 11: "12"}}
    assert camel_dict_to_snake_dict(list_0) == {'1': '2', '3': '4', '5': {'6': '7', '8': '9', '11': '12'}}
    list_0 = {1: "2", 3: "4", 5: {"6": "7", "8": "9", 11: "12", 13: {"14": "15", "16": "17"}}}
    assert camel_dict_to_

# Generated at 2022-06-24 20:29:03.421319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    pass



# Generated at 2022-06-24 20:29:15.124750
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict_0 = {'something_here': 'value', 'something_else': 'value'}
    var_0 = camel_dict_to_snake_dict(snake_dict_0)
    assert var_0['something_else'] == 'value'
    assert var_0['something_here'] == 'value'
    var_1 = snake_dict_to_camel_dict(var_0)
    assert var_1['somethingHere'] == 'value'
    assert var_1['somethingElse'] == 'value'
    camel_dict_0 = {'somethingHere': 'value', 'somethingElse': 'value'}
    var_2 = camel_dict_to_snake_dict(camel_dict_0)
    assert var_2['something_else'] == 'value'

# Generated at 2022-06-24 20:29:24.071748
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {"vpc_id": "vpc-33", "cidr_block": "123.123.123.123/32"} == camel_dict_to_snake_dict(
        {"VpcId": "vpc-33", "CidrBlock": "123.123.123.123/32"})
    assert {"tags": {"key": "value"}} == camel_dict_to_snake_dict({"Tags": {"Key": "value"}}, ignore_list=["Tags"])
    assert {"a": "A", "b_c": "B C"} == camel_dict_to_snake_dict({"A": "A", "B_C": "B C"})
    assert {"a": "A", "b_c": "B C", "tags": {"key": "value"}} == camel_dict_to_

# Generated at 2022-06-24 20:29:35.598460
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = {
        'endpoint_url': 'http://localhost',
        'endpoint_type': 'HTTPEndpoint',
        'endpoint_configuration': {
            'tags': {
                'key': 'value'
            }
        },
        'chain_configuration_names': [
            'example_chain_configuration'
        ]
    }

    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == {
        'EndpointUrl': 'http://localhost',
        'EndpointType': 'HTTPEndpoint',
        'EndpointConfiguration': {
            'Tags': {
                'key': 'value'
            }
        },
        'ChainConfigurationNames': [
            'example_chain_configuration'
        ]
    }

    snake_

# Generated at 2022-06-24 20:29:38.130840
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'a': 1, 'b': 2}, False, ()) == {'a': 1, 'b': 2}



# Generated at 2022-06-24 20:29:41.256637
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_1 = None
    assert var_0 == list_1
    list_2 = 'Test'
    var_1 = camel_dict_to_snake_dict(list_2)


# Generated at 2022-06-24 20:29:49.753985
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    class Test_camel_dict_to_snake_dict:
        def test_0(self):
            list_0 = None
            var_0 = camel_dict_to_snake_dict(list_0)

        def test_1(self):
            list_0 = {}
            var_0 = camel_dict_to_snake_dict(list_0)

        def test_2(self):
            list_0 = {"abc": "abc"}
            var_0 = camel_dict_to_snake_dict(list_0)

        def test_3(self):
            list_0 = {"camelCase": "camelCase"}
            var_0 = camel_dict_to_snake_dict(list_0)

    obj = Test_camel_dict_to_snake_dict()
    obj

# Generated at 2022-06-24 20:29:50.940079
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(list_0) == None

# Generated at 2022-06-24 20:29:59.943223
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    tags = {'Tags': [{'Key': 'string', 'Value': 'string'}]}
    tags1 = {'tag_0': {'key': 'string', 'value': 'string'}}
    tags2 = {'tag_0': {'key': 'string'}}
    tags3 = {'tag_0': {} }

    dict_0 = None
    dict_1 = {'Filters': [{'Name': 'string', 'Values': ['string',]}]}
    dict_3 = {'Filters': []}
    dict_4 = {}
    dict_5 = {'Filters': [{'Name': 'string', 'Values': ['string',],
                           "Filter": [{'Name': 'string', 'Values': ['string',]}]}]}

# Generated at 2022-06-24 20:30:07.423546
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = camel_dict_to_snake_dict(None)

    var_1 = camel_dict_to_snake_dict(True)

    var_2 = camel_dict_to_snake_dict(False)

    var_3 = camel_dict_to_snake_dict(123)

    var_4 = camel_dict_to_snake_dict(123.456)

    var_5 = camel_dict_to_snake_dict('DromedaryCase')

    var_6 = camel_dict_to_snake_dict(('DromedaryCase',))

    var_7 = camel_dict_to_snake_dict(['DromedaryCase'])


# Generated at 2022-06-24 20:30:12.816118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {'A': 1, 'B': 2, 'C': 3}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {'a': 1, 'b': 2, 'c': 3}  # Expected
    list_1 = {'AmazonDynamoDB': 1, 'AmazonDynamoDBEndpoint': 2, 'AmazonDynamoDBReadThroughput': 3}
    var_1 = camel_dict_to_snake_dict(list_1)
    assert var_1 == {'amazon_dynamo_db': 1, 'amazon_dynamo_db_endpoint': 2, 'amazon_dynamo_db_read_throughput': 3}  # Expected

# Generated at 2022-06-24 20:30:20.463049
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"testString": "testString"}) == {"test_string": "testString"}
    assert camel_dict_to_snake_dict({"testString": {"testString": "testString"}}) == {"test_string": {"test_string": "testString"}}
    assert camel_dict_to_snake_dict({"testString": [{"testString": "testString"}]}) == {"test_string": [{"test_string": "testString"}]}


# Generated at 2022-06-24 20:30:28.937109
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:39.805717
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    in_dict = {'FooName': 'baz',
               'foo': {'bar': 'baz'},
               'fooList': [{'ID': 'a'}, {'ID': 'b'}],
               'Port': 8080}

    out_dict = {'foo_name': 'baz',
                'foo': {'bar': 'baz'},
                'foo_list': [{'id': 'a'}, {'id': 'b'}],
                'port': 8080}

    assert camel_dict_to_snake_dict(in_dict) == out_dict


# Generated at 2022-06-24 20:30:46.167256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = { 'HTTPEndpoint': 'https://169.254.169.254/latest/', 'MetadataServiceUsage': 'optional', 'MetadataServiceRequestTimeout': '1000', 'KeysToRemove': [ 'InstanceId', 'AmiId', 'ReservationId', 'PublicIpv4', 'PublicKeys', 'SecurityGroups', 'StackId', 'VpcId', 'RamdiskId', 'BlockDeviceMappings', 'SpotInstanceRequestId', 'Platform', 'KernelId' ] }
    var_0 = camel_dict_to_snake_dict(list_0)
    #Check the following variables are type "list"
    assert type(var_0) is list


# Generated at 2022-06-24 20:30:51.062992
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'a': 1}, False, ()) == {'a': 1}
    assert camel_dict_to_snake_dict({'a': 1, 'b': 2}, False, ()) == {'a': 1, 'b': 2}
    assert camel_dict_to_snake_dict({'a': 1, 'b': {'c': 2}}, False, ()) == {'a': 1, 'b': {'c': 2}}
    assert camel_dict_to_snake_dict({}, False, ()) == {}


# Generated at 2022-06-24 20:31:01.363747
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = camel_dict_to_snake_dict(None)
    # Call function with args
    # Call function with kwargs
    # Impossible to test unless we implement the type.
    # var_3 = camel_dict_to_snake_dict(**{'camel_dict': None})
    # assert var_3 is None
    # var_4 = camel_dict_to_snake_dict(**{'camel_dict': None, 'reversible': None})
    # assert var_4 is None
    # var_5 = camel_dict_to_snake_dict(**{'camel_dict': None, 'ignore_list': None})
    # assert var_5 is None
    # var_6 = camel_dict_to_snake_dict(**{'camel_dict': None, '

# Generated at 2022-06-24 20:31:03.192498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert not camel_dict_to_snake_dict(list_0)
    assert var_0 == list_0

# Generated at 2022-06-24 20:31:06.549022
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_type = {
        'ListOfString': ['initial', 'changed'],
        'String': 'initial',
    }
    new_type = camel_dict_to_snake_dict(complex_type)
    print(new_type)



# Generated at 2022-06-24 20:31:16.195596
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = [{u'InstanceId': u'i-0cda06b922a46a972', u'PrivateIpAddress': u'172.31.2.239'},
              {u'InstanceId': u'i-0b7e72b34c62e5215', u'PrivateIpAddress': u'172.31.9.227'},
              {u'InstanceId': u'i-0a41cdf15dc6e6524', u'PrivateIpAddress': u'172.31.1.156'}]

    var_0 = camel_dict_to_snake_dict(list_0, ignore_list=["Tags"])

# Generated at 2022-06-24 20:31:27.740379
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test to assert that we can create a camel_dict from a list of strings.
    camel_dict = {"HTTPEndpoint": {
        "EndpointAddress": "http://httpbin.org/post"
    }}
    expected_snake_dict = {"h_t_t_p_endpoint": {
        "endpoint_address": "http://httpbin.org/post"
    }}
    assert expected_snake_dict == camel_dict_to_snake_dict(camel_dict)

    # Test to assert that we can create a camel_dict from a list of strings.
    camel_dict = {"HTTPEndpoint": {
        "EndpointAddress": "http://httpbin.org/post",
        "Protocols": [
            "HTTP"
        ]}}

# Generated at 2022-06-24 20:31:32.912154
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True == True


# Generated at 2022-06-24 20:31:41.912458
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Function for creating random data for testing
    import random
    import json
    import string
    import re

    # Prepare for testing
    # If there's any keys with the same value, camel_dict_to_snake_dict() will throw error.
    # Because we use dict[dict[key]] to modify.
    def matching_keys(d):
        return [k for k, v in d.items() if dict(d).values().count(v) > 1]

    def check_items_in_list(list_1, list_2):
        items = [i for i in list_1 if i not in list_2]
        return items == []

    def check_matches(d):
        for k in matching_keys(d):
            old_value = d[k]
            del[d[k]]

# Generated at 2022-06-24 20:31:50.390227
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {'HTTPEndpoint': {'Endpoint': 'http://www.ansible.com', 'PostBody': 'This is the body of the POST', 'PostParameters': {'a': '1', 'b': '2', 'c': '3'}}, 'Name': 'Test HTTP egress rule', 'Priority': 1, 'Tags': {'camel': 'should not change'}}
    var_0 = {'http_endpoint': {'endpoint': 'http://www.ansible.com', 'post_body': 'This is the body of the POST', 'post_parameters': {'a': '1', 'b': '2', 'c': '3'}}, 'name': 'Test HTTP egress rule', 'priority': 1, 'tags': {'camel': 'should not change'}}

# Generated at 2022-06-24 20:31:59.409329
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:10.416473
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:18.921191
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test simple dict
    test_dict = {
        "string": "string",
        "list": [1, 2, 3],
        "dict": {
            "nested" : "dict"
        }
    }
    test_dict_camelized = {
        "String": "string",
        "List": [1, 2, 3],
        "Dict": {
            "Nested" : "dict"
        }
    }
    assert snake_dict_to_camel_dict(test_dict) == test_dict_camelized

    # Test EIP association

# Generated at 2022-06-24 20:32:28.206221
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)
    print(var_0)
    assert var_0 == None

    list_1 = {'http_endpoint': 'https://www.example.com'}
    var_1 = camel_dict_to_snake_dict(list_1)
    assert var_1 == {'http_endpoint': 'https://www.example.com'}

    list_2 = {'Host': 'localhost', 'User': 'bob'}
    var_2 = camel_dict_to_snake_dict(list_2)
    assert var_2 == {'host': 'localhost', 'user': 'bob'}


# Generated at 2022-06-24 20:32:34.799856
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Call function with arguments:
    # (camel_dict, reversible=False, ignore_list=())
    assert camel_dict_to_snake_dict(mock_data_0) == list_0
    assert camel_dict_to_snake_dict(mock_data_1) == list_1
    assert camel_dict_to_snake_dict(mock_data_2) == list_2
    assert camel_dict_to_snake_dict(mock_data_3) == list_3
    assert camel_dict_to_snake_dict(mock_data_4) == list_4
    assert camel_dict_to_snake_dict(mock_data_5) == list_5
    assert camel_dict_to_snake_dict(mock_data_6) == list_

# Generated at 2022-06-24 20:32:44.836376
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {
        'key1': 'value1',
        'key2': {
            'camelCaseKey': 'value2',
            'anotherCamelCaseKey': 'value3',
        },
        'key3': 'value4',
    }

    list_1 = {
        'key1': 'value1',
        'key2': {
            'camel_case_key': 'value2',
            'another_camel_case_key': 'value3',
        },
        'key3': 'value4',
    }
    expected = list_1
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == expected


# Generated at 2022-06-24 20:32:47.975704
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    res = camel_dict_to_snake_dict(what_the_hell="go on")
    assert res == {"what_the_hell": "go on"}
    res = camel_dict_to_snake_dict(HTTPEndpoint=None)
    assert res == {"http_endpoint": None}



# Generated at 2022-06-24 20:32:57.663069
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    passed = True
    exception = None

    try:
        test_case_0()
    except Exception as exception:
        passed = False
    assert passed, "Test case 0: " + "Exception thrown: " + str(exception)
    passed = True
    exception = None

    return passed


# Generated at 2022-06-24 20:33:09.589748
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:19.952898
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)
    dict_0 = {
        'PublicKey': 'salt://my/public/key.pub',
        'test': 'test',
        'test2': 'test2',
        'test3': {
            'test4': 'test4',
            'test5': 'test5',
        },
        'test6': [
            {
                'test7': 'test7',
                'test8': 'test8',
            },
        ],
    }

# Generated at 2022-06-24 20:33:26.600965
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 is None
    list_0 = {}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {}
    list_0 = {'CamelCase': 'CamelCase', 'camelCase': 'camelCase', 'camel': 'camel', '__': '__', 'swift': 'swift', 'if_if': 'if_if'}
    var_0 = camel_dict_to_snake_dict(list_0)

# Generated at 2022-06-24 20:33:36.992334
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:41.690952
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {"FooBar": "baz", "BazFoo": {"BizBaz": "qux"}}
    list_1 = {"foo_bar": "baz", "baz_foo": {"biz_baz": "qux"}}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == list_1

# Generated at 2022-06-24 20:33:49.213436
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    args = {}
    args['camel_dict'] = {
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'test_instance'
            }
        ]
    }
    args['reversible'] = False
    args['ignore_list'] = ()
    args_copy = deepcopy(args)
    dict_0 = camel_dict_to_snake_dict(**args)

    assert dict_0 == {'tags': [{'key': 'Name', 'value': 'test_instance'}]}
    assert args == args_copy



# Generated at 2022-06-24 20:33:58.794382
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict([('a', 1)])
    dict_1 = dict([('b', 2)])
    dict_2 = dict([('c', 3)])
    dict_3 = dict([('d', 4)])
    dict_4 = {}
    dict_4['a'] = dict_0
    dict_4['b'] = dict_1
    dict_4['c'] = dict_2
    dict_4['d'] = dict_3
    dict_5 = {}
    dict_5['a'] = dict_0
    dict_5['b'] = dict_1
    dict_5['c'] = dict_2
    dict_5['d'] = dict_3
    camel_dict = dict_merge(dict_4, dict_5)
    snake_dict = camel_dict_to_snake_

# Generated at 2022-06-24 20:34:07.213256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {'TagFilters': [{'Key': 'Name', 'Values': ['sql-server-db']}], 'Filters': [{'Name': 'tag:Name', 'Values': ['sql-server-db']}], 'DBClusterIdentifier': 'sql-server-db', 'DBInstanceClass': 'db.t2.medium'}
    list_1 = {'TagFilters': [{'Key': 'Name', 'Values': ['sql-server-db']}], 'Filters': [{'Name': 'tag:Name', 'Values': ['sql-server-db']}], 'DBClusterIdentifier': 'sql-server-db', 'DBInstanceClass': 'db.t2.medium'}
    var_0 = camel_dict_to_snake_dict(list_0)
    var_1 = camel

# Generated at 2022-06-24 20:34:14.448831
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    result = camel_dict_to_snake_dict({
        "HTTPEndpoint": {
            "Url": "string",
            "AccessKey": "string",
            "UseDefaultCredentials": True
        },
        "Tags": {
            "Tags": {
                "Project": "string"
            }
        }
    })

    assert result == {
        "h_t_t_p_endpoint": {
            "url": "string",
            "access_key": "string",
            "use_default_credentials": True
        },
        "tags": {
            "Tags": {
                "Project": "string"
            }
        }
    }



# Generated at 2022-06-24 20:34:29.258884
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:32.018513
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    var_0 = camel_dict_to_snake_dict(list_0)



# Generated at 2022-06-24 20:34:38.745125
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():


    # Parameters:
    #   camel_dict: (list) - Required
    #   reversible: (bool) - Optional - Default: False
    #   ignore_list: (list) - Optional

    produced = camel_dict_to_snake_dict(list_0)
    expected = None
    assert produced == expected, "Test #0 Failed!"




# Generated at 2022-06-24 20:34:47.856564
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = {
        "Subnet": "10.0.1.0/24",
        "DNSNameServers": [
            "10.0.0.2",
            "10.0.0.3"
        ],
        "VPCId": "vpc-3da8c25a",
        "Name": "PrimarySubnet",
        "AvailabilityZone": "us-east-1a",
        "Tags": {
            "Service": "default",
            "Name": "PrimarySubnet"
        },
        "MapPublicIpOnLaunch": False
    }
    var_0 = camel_dict_to_snake_dict(list_0)

# Generated at 2022-06-24 20:34:56.612788
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = ['HTTPEndpoint', 'HTTPSEndpoint']
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {'h_t_t_p_endpoint': None, 'h_t_t_p_s_endpoint': None}
    list_0 = {}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {}
    list_0 = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5}
    var_0 = camel_dict_to_snake_dict(list_0)
    assert var_0 == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
   

# Generated at 2022-06-24 20:35:06.801784
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    list_0 = None
    # Try to call the function with arguments that you expect to raise an exception
    try:
        var_0 = camel_dict_to_snake_dict(list_0)
    except Exception:
        var_0 = None
    if var_0 is not None:
        return 1
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'qux'
    var_1 = camel_dict_to_snake_dict(dict_0)
    var_2 = camel_dict_to_snake_dict(dict_0, False, [])
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    dict_1['baz'] = 'qux'

# Generated at 2022-06-24 20:35:15.390492
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {u'HTTPEndpoint': {u'Endpoint': u'http://example.com', u'TimeoutMillis': 80, u'Path': u'', u'HTTPMethod': u'GET'}}
    var_0 = camel_dict_to_snake_dict(dict_0)
    assert var_0 == {'h_t_t_p_endpoint': {'endpoint': u'http://example.com', 'path': u'', 'timeout_millis': 80, 'http_method': u'GET'}}
    dict_1 = {u'HTTPEndpoint': {u'Endpoint': u'http://example.com', u'timeoutMillis': 80, u'path': u'', u'httpMethod': u'GET'}}
    var_1 = camel_dict_to_snake