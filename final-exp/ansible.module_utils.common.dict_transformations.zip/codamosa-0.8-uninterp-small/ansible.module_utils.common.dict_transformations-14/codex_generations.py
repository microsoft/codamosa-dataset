

# Generated at 2022-06-24 20:25:28.456930
# Unit test for function dict_merge
def test_dict_merge():
    a = {'currency': {'allowed': ['USD', 'GBP'],
                      'default': 'USD'},
         'language': 'en',
         'modes': ['beta', 'production'],
         'name': 'Test'}
    b = {'currency': {'allowed': ['USD', 'EUR'],
                      'default': 'EUR'},
         'language': 'en',
         'name': 'Test',
         'modes': ['beta', 'test']}
    c = {'currency': {'allowed': ['USD', 'GBP'],
                      'default': 'USD'},
         'language': 'en',
         'name': 'Test'}

# Generated at 2022-06-24 20:25:39.051986
# Unit test for function recursive_diff

# Generated at 2022-06-24 20:25:45.193800
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-24 20:25:54.811028
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff
    """

    dict1 = {
        'baz': 1,
        'foo': {
            'bar': 'panda'
        }
    }

    dict2 = {
        'boo': 3,
        'baz': 1,
        'foo': {
            'bar': 'grizzly'
        }
    }

    assert recursive_diff(dict1, dict2) == ({
        'foo': {
            'bar': 'panda'
        }
    }, {
        'boo': 3,
        'foo': {
            'bar': 'grizzly'
        }
    })

# Generated at 2022-06-24 20:25:59.821451
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Starting: Test camel_dict_to_snake_dict")
    bytes_0 = b'\xe7u\xac\xdd\xd4\rsQ\xd0\xa2\xf5;\x1b'

# Generated at 2022-06-24 20:26:06.713022
# Unit test for function recursive_diff
def test_recursive_diff():
    # Dictionaries to test
    dict1 = {'a': 'b', 'c': 'd', 'e': {'f': 'g'}}
    dict2 = {'a': 'b', 'c': 'de', 'e': {'f': 'g'}}

    # Test results
    result = recursive_diff(dict1, dict2)
    assert isinstance(result, tuple)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)
    assert result[0] == {'c': 'd'}
    assert result[1] == {'c': 'de'}

# Generated at 2022-06-24 20:26:09.818072
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': {'b': 2, 'c': 3}}, {'a': {'b': 4, 'd': 5}}) == {'a': {'b': 4, 'c': 3, 'd': 5}}


# Generated at 2022-06-24 20:26:13.084422
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dictionary = {'Name': 'Test'}
    new_dictionary = camel_dict_to_snake_dict(dictionary)
    assert new_dictionary == {'name': 'Test'}



# Generated at 2022-06-24 20:26:21.469313
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'hello': {'world': 1234}}
    b = {'hello': {'world': 1234}}
    assert not recursive_diff(a, b)

    b = {'hello': {'world': 1234, 'world2': 56789}}
    assert recursive_diff(a, b) == ({'hello': {'world2': 56789}}, {'hello': {'world2': 56789}})

    b = {'hello': {'world': 56789}}
    assert recursive_diff(a, b) == ({'hello': {'world': 1234}}, {'hello': {'world': 56789}})

    b = {'hello2': {'world': 56789}}

# Generated at 2022-06-24 20:26:32.269056
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("HttpEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint") == "h_t_t_p_endpoint"
    assert _camel_to_snake("HTTPEndpoint", True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("HTTPEndpoint", True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("TargetGroupARNs") == "target_group_ar_ns"

    assert _snake_to_camel("http_endpoint") == "HttpEndpoint"
    assert _snake_to_camel

# Generated at 2022-06-24 20:26:47.583792
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('running test for function camel_dict_to_snake_dict..')
    # Test case 0
    print('test case 0...')
    dict_0 = dict()
    dict_0['HTTPEndpoint'] = True
    dict_0['TargetGroups'] = [
        {'TargetGroupArns': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']},
        {'TargetGroupArns': ['arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067']},
    ]
    dict_0['MatchIncomingTraffic'] = True

# Generated at 2022-06-24 20:26:58.082172
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Set name
    name_0 = 'set_0'

    # Set parameters and arguments
    parameters_0 = [
        ['camel_dict'],
        ['reversible'],
        ['ignore_list'],
    ]
    parameters_0[2][0] = None
    parameters_0[1][0] = None
    parameters_0[0][0] = None

    arguments_0 = {
        'camel_dict': None,
        'reversible': None,
        'ignore_list': None,
    }

    # Set default values
    default_values_0 = {
        'camel_dict': None,
        'reversible': None,
        'ignore_list': None,
    }

    # Set empty value

# Generated at 2022-06-24 20:27:08.920582
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_1 = {'fooBar': 'stuff', 'hasOtherStuff': {'fooBar': 'stuff'}}
    var_1 = camel_dict_to_snake_dict(set_1)
    assert var_1 == {'foo_bar': 'stuff', 'has_other_stuff': {'foo_bar': 'stuff'}}

    set_2 = {'fooBar': 'stuff', 'hasOtherStuff': {'fooBar': 'stuff'}}
    var_2 = camel_dict_to_snake_dict(set_2, set_2)

# Generated at 2022-06-24 20:27:09.996169
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()
    test_case_1()



# Generated at 2022-06-24 20:27:15.040521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dictionary_1 = {'Name': 'Test', 'IpAddress': '127.0.0.1', 'Tags': {'Owner': 'User', 'Environment': 'Test'}}
    dictionary_2 = {'name': 'Test', 'ip_address': '127.0.0.1', 'tags': {'owner': 'User', 'environment': 'Test'}}

    assert(camel_dict_to_snake_dict(dictionary_1, False, ignore_list=['Tags']) == dictionary_2)



# Generated at 2022-06-24 20:27:24.817292
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'x-forwarded': {'X-Forwarded-Host': 'host.net'},
             'host': 'localhost',
             'x-request-id': '5ecb1e3b-c4b4-4f0c-a4dd-69f66fcaa7a9',
             'cache-control': 'max-age=0, no-cache, no-store',
             'x-forwarded-for': '9.9.9.9',
             'status': 1000,
             'x-forwarded-proto': 'http'}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)

# Generated at 2022-06-24 20:27:35.485195
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Check error if non dict is passed
    try:
        camel_dict_to_snake_dict(True)
    except TypeError:
        pass
    else:
        assert False, "Should have raised TypeError"
    # Check empty dict
    assert {} == camel_dict_to_snake_dict({}), "Empty dict not working"
    # Check dict with integer
    assert {'int_dict': 1} == camel_dict_to_snake_dict({'intDict': 1}), "Dict with integer not working"
    # Check dict with float
    assert {'float_dict': 1.1} == camel_dict_to_snake_dict({'floatDict': 1.1}), "Dict with float not working"
    # Check dict with string

# Generated at 2022-06-24 20:27:45.490245
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:53.905608
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Case 0: When set_0 is None, the function returns None
    set_0 = None
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0 is None

    # Case 1: When set_0 is a dictionary of one entry, with a value of a list,
    # the function returns a dictionary of one entry, with a list as a value
    set_0 = {'Name': ['Duke', 'Earl', 'Squire', 'Peon']}
    set_1 = camel_dict_to_snake_dict(set_0, set_0)
    var_0 = {'name': ['Duke', 'Earl', 'Squire', 'Peon']}
    # assert var_0 == set_1

    # Case 2: When set_0 is

# Generated at 2022-06-24 20:27:56.329416
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    set = {'One': 1, 'Two': 2, 'Three': 3}
    result = camel_dict_to_snake_dict(set)

    assert result['one'] == 1



# Generated at 2022-06-24 20:28:06.504156
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Unit test for function camel_dict_to_snake_dict
    set_0 = [{'key1': 'value1', 'key2': 'value2'}]
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0 == {'key1': 'value1', 'key2': 'value2'}
    set_0 = {"key1": "value1", "key2": "value2"}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0 == {'key1': 'value1', 'key2': 'value2'}
    set_0 = {'key1': 'value1', 'key2': 'value2'}
    var_0 = camel_dict_to

# Generated at 2022-06-24 20:28:17.189935
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    string_0 = 'bar'
    dict_0 = {'foo': string_0}
    assert_0 = camel_dict_to_snake_dict(dict_0, False, [])
    assert assert_0['foo'] == string_0

    dict_1 = {'foo': dict_0}
    assert_1 = camel_dict_to_snake_dict(dict_1, False, [])
    assert assert_1['foo']['bar'] == string_0

    dict_2 = {'FooBar': string_0}
    assert_2 = camel_dict_to_snake_dict(dict_2, True, [])
    assert assert_2['foo_bar'] == string_0

# Generated at 2022-06-24 20:28:21.311314
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test with None as the first argument
    try:
        assert test_case_0() == None
    except AssertionError:
        raise AssertionError("Failed")
    # Test with None as the second argument
    try:
        assert test_case_0() == None
    except AssertionError:
        raise AssertionError("Failed")


# Generated at 2022-06-24 20:28:27.143338
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'URL': 'http://google.com', 'IPAddress': '192.168.1.1'}
    var_0 = camel_dict_to_snake_dict(set_0)
    var_1 = camel_dict_to_snake_dict(var_0)
    assert var_1 == {'url': 'http://google.com', 'i_p_address': '192.168.1.1'}


# Generated at 2022-06-24 20:28:37.616550
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # NOTE: these tests are not exhaustive, just for sample code coverage
    #       the true test is to see if the boto3 client methods work
    #       and return the expected data

    # test with no input
    set_0 = None
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    if var_0 is None:
        print("Test case 0 passed")
    else:
        print("Test case 0 failed")

    # test with an empty dictionary
    set_1 = {}
    var_1 = camel_dict_to_snake_dict(set_1, set_1)
    if var_1 == {}:
        print("Test case 1 passed")
    else:
        print("Test case 1 failed")

    # test a one dimensional dictionary

# Generated at 2022-06-24 20:28:49.837118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # test case 0
    set_0 = {
        "camel": None,
        "camel_case": "snake_case",
        "innerCamel": {
            "inner": None,
            "inner_case": "snake case"
        },
        "inner_camel": {
            "inner": None,
            "inner_case": "snake case"
        }}
    set_0_result = {
        "_camel": None,
        "_camel_case": "snake_case",
        "inner_camel": {
            "_inner": None,
            "_inner_case": "snake case"
        },
        "_inner_camel": {
            "_inner": None,
            "_inner_case": "snake case"
        }
    }
    var_0 = camel_

# Generated at 2022-06-24 20:28:55.287055
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # get_expected_set_0 = {}
    # get_actual_set_0 = camel_dict_to_snake_dict(set_0, set_0)
    # assert get_actual_set_0 == get_expected_set_0
    assert camel_dict_to_snake_dict(None, None) == {}



# Generated at 2022-06-24 20:29:03.415462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert test_case_0() == None
    assert test_case_1() == None
    assert test_case_2() == None
    assert test_case_3() == None
    assert test_case_4() == None
    assert test_case_5() == None
    assert test_case_6() == None
    assert test_case_7() == None
    assert test_case_8() == None
    assert test_case_9() == None
    assert test_case_10() == None
    assert test_case_11() == None
    assert test_case_12() == None
    assert test_case_13() == None
    assert test_case_14() == None
    assert test_case_15() == None
    assert test_case_16() == None
    assert test_case_17() == None
   

# Generated at 2022-06-24 20:29:12.797826
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'a': {}, 'b': {}}) == {'a': {}, 'b': {}}
    assert camel_dict_to_snake_dict({'a': {'b': 2}}) == {'a': {'b': 2}}
    assert camel_dict_to_snake_dict({'a': {'b': 2, 'C': 3}}) == {'a': {'b': 2, 'c': 3}}
    assert camel_dict_to_snake_dict({'A': {'B': 2, 'C': 3}}) == {'a': {'b': 2, 'c': 3}}

# Generated at 2022-06-24 20:29:14.421319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict()
    assert result == None


# Generated at 2022-06-24 20:29:37.818538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = None
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    print(var_0)
    var_1 = {'CamelCase': {'CamelCase': {'CamelCase': 'CamelCase'}, 'camelCase': 'camelCase', 'camelcase': 'camelcase'}, 'HTTPEndpoint': 'HTTPEndpoint', 'httpePpoint': 'httpePpoint', 'foo_bar': {'camelCase': 'camelCase', 'fooBar': {'camelCase': 'camelCase', 'camelcase': 'camelcase'}, 'camelcase': 'camelcase'}, 'camelCase': 'camelCase', 'camelcase': 'camelcase'}

# Generated at 2022-06-24 20:29:44.332069
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {"a": {},
             "b": {},
             "c": {},
             "d": {},
             "e": {},
             "f": {},
             "g": {}}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0 == {"a": {}, "b": {}, "c": {}, "d": {}, "e": {}, "f": {}, "g": {}}

# Generated at 2022-06-24 20:29:53.255421
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    in_dict = {
        'Tags': [
            {
                'Key': 'foo',
                'Value': 'bar'
            }
        ],
        'HealthCheckPath': '/my/health/check/path',
        'HealthCheckProtocol': 'http',
        'HealthCheckTimeoutSeconds': 42,
        'HealthCheckIntervalSeconds': 43,
        'HealthyThresholdCount': 44,
        'UnhealthyThresholdCount': 45,
        'Matcher': {
            'HttpCode': '200-399'
        },
        'LoadBalancerArn': 'loadBalancerArn',
        'TargetGroupArn': 'targetGroupArn'
    }

    out_dict = camel_dict_to_snake_dict(in_dict)


# Generated at 2022-06-24 20:30:02.589354
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_1 = {}
    set_1['TagSpecifications'] = [{'Tags': [{'Value': 'test_val', 'Key': 'test_key'}, {'Value': 'test_val', 'Key': 'test_key'}], 'ResourceType': 'Instance'}, {'Tags': [{'Value': 'test_val', 'Key': 'test_key'}, {'Value': 'test_val', 'Key': 'test_key'}], 'ResourceType': 'Instance'}]
    set_1['Test'] = True
    var_1 = camel_dict_to_snake_dict(set_1, set_1)
    set_2 = {}

# Generated at 2022-06-24 20:30:10.283881
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_1 = None
    set_2 = True
    set_3 = False
    set_4 = 'string'
    set_5 = 13
    set_6 = 42
    set_7 = 13.0
    set_8 = 42.0
    set_9 = [set_7, set_8, set_7, set_8]
    set_10 = [set_3, set_2, set_3, set_2]
    set_11 = [set_7, set_8, set_7, set_8]
    set_12 = [set_2, set_2, set_2, set_2]

# Generated at 2022-06-24 20:30:20.877449
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {"KeyId": "arn:aws:kms:us-east-1:123456789:key:fake_key", "Plaintext": "Hello", "CiphertextBlob": "AQICAHgGdnbF+crtLR2YFKkc8WCH/xGwhhTc/Q/aI9+OzsLJNgAAAIcwgYQYJKoZIhvcNAQcGoGcwZQIBADBdBgkqhkiG9w0BBwEwHgYJYIZIAWUDBAEuMBEEDHU6lBnf2srg6JbGPgIBEIB6nGqxOqvLFnTftQfvnX9XtcOGsVhMg1s98sMZ8So="}

# Generated at 2022-06-24 20:30:29.261234
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:39.832761
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {
        "HTTPEndpoint": {
            "Index": 0,
            "Port": "4000-4040",
            "Protocol": "HTTP",
            "Type": "ESTABLISHED",
        },
        "MaxResults": 500,
        "NextToken": "None",
    }
    var_0 = camel_dict_to_snake_dict(set_0, False, set_0)
    set_1 = {
        "h_t_t_p_endpoint": {
            "index": 0,
            "port": "4000-4040",
            "protocol": "HTTP",
            "type": "ESTABLISHED",
        },
        "max_results": 500,
        "next_token": "None",
    }
    var_1 = camel_dict_

# Generated at 2022-06-24 20:30:47.231223
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = camel_dict_to_snake_dict({"HTTPEndpoint": set()})
    assert var_0 == {"h_t_t_p_endpoint": set()}
    var_1 = camel_dict_to_snake_dict({"HTTPS": set()})
    assert var_1 == {"https": set()}
    var_2 = camel_dict_to_snake_dict({"Id": "Id"})
    assert var_2 == {"id": "Id"}
    var_3 = camel_dict_to_snake_dict({"Ids": set()}, True)
    assert var_3 == {"i_d_s": set()}
    var_4 = camel_dict_to_snake_dict({"Ids": set()})

# Generated at 2022-06-24 20:30:56.372672
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'b': 'b', 'a': 'a', 'A': 'A', 'AaA': 'AaA', 'aB': 'aB', 'Byeeeeee': 'Byyyyyy', 'c': 'c', 'X': 'X', 'ByeA': 'ByeA', 'Byee': 'Byee'}
    var_0 = camel_dict_to_snake_dict(set_0, False, set_0)
    assert var_0 == {'b': 'b', 'a_b': 'aB', 'a': 'a', 'x': 'X', 'a_a_a': 'AaA', 'c': 'c', 'bye_a': 'ByeA', 'bye_e': 'Byee', 'bye_eeeeee': 'Byyyyyy'}

#

# Generated at 2022-06-24 20:31:06.641376
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'Tags': {}, 'ARN': 'string', 'ClientToken': 'string', 'EventSubscriptions': {}, 'Parameters': {}, 'ServiceRoleArn': 'string'}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert(var_0['service_role_arn'] == set_0['ServiceRoleArn'])


# Generated at 2022-06-24 20:31:11.438333
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = dict({'a': 'b'})
    var_0 = camel_dict_to_snake_dict(set_0, set_0)

    set_1 = dict({'a': 'b'})
    var_1 = camel_dict_to_snake_dict(set_1, set_1)



# Generated at 2022-06-24 20:31:21.044526
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Running unit test for function camel_dict_to_snake_dict")

# Generated at 2022-06-24 20:31:26.294030
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {
        "SupportedKeyAlgorithms": [
            "RSA_2048",
            "RSA_1024",
            "EC_prime256v1",
            "EC_secp384r1"
        ]
    }
    var_0 = camel_dict_to_snake_dict(set_0, False, [])
    var_1 = {
        "supported_key_algorithms": [
            "RSA_2048",
            "RSA_1024",
            "EC_prime256v1",
            "EC_secp384r1"
        ]
    }
    assert var_0 == var_1


# Generated at 2022-06-24 20:31:36.984422
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_0['Foo'] = dict()
    dict_0['Foo']['Bar'] = dict()
    dict_0['Foo']['Bar']['Target'] = dict()
    dict_0['Foo']['Bar']['Target']['Group'] = dict()
    dict_0['Foo']['Bar']['Target']['Group']['Type'] = 'New'
    dict_0['Foo']['Bar']['Target']['Group']['Tags'] = dict()
    dict_0['Foo']['Bar']['Target']['Group']['Tags']['Key'] = 'value'
    dict_0['Foo']['Bar']['Target']['Group']['Tags']['Key2']

# Generated at 2022-06-24 20:31:46.538715
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'Value': 3.141592653589793, 'HTTP': True, 'Subnets': ['subnet-123456', 'subnet-7890ab'], 'Group': 'ABC123', 'Tags': [{'Key': 'Project', 'Value': 'BAD'}, {'Key': 'Dummy', 'Value': 'OK'}], 'AvailabilityZones': ['us-east-2c', 'us-east-1b'], 'Enabled': False, 'Endpoint': 'http://foo.bar', 'Project': 'OK', 'Vpc': 'vpc-12345678'}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)

# Generated at 2022-06-24 20:31:49.359333
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test with bad input type - raise TypeError if input is a int.
    if len(sys.argv) > 1 and sys.argv[1] == 'test_case_0':
        test_case_0()
    print('Test Complete')



# Generated at 2022-06-24 20:31:55.525332
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'foo': 'bar'}
    var_0 = camel_dict_to_snake_dict(set_0, False, ())
    var_1 = camel_dict_to_snake_dict(set_0, True, ())
    var_2 = camel_dict_to_snake_dict(set_0, False, ())
    assert var_0 == {'foo': 'bar'} and var_1 == {'foo': 'bar'} and var_2 == {'foo': 'bar'}


# Generated at 2022-06-24 20:32:04.496588
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # set_0
    set_0 = None
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0 is None
    set_1 = {}
    var_1 = camel_dict_to_snake_dict(set_1, set_1)
    assert var_1 is None
    set_2 = {"tag": {}}
    var_2 = camel_dict_to_snake_dict(set_2, set_2)
    assert var_2 == {'tag': {}}
    set_3 = {"tag": [], "key": {"tag": [{"tag": "tag1"}], "tag2": 2}}
    var_3 = camel_dict_to_snake_dict(set_3, set_3)

# Generated at 2022-06-24 20:32:07.825945
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test expected return type
    assert(isinstance(camel_dict_to_snake_dict(set_0, set_0), type(var_0)))


# Generated at 2022-06-24 20:32:24.861172
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = None
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert (var_0 == set_0)


# Generated at 2022-06-24 20:32:34.392028
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint", True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("HttpEndpoint") == "http_endpoint"
    assert _camel_to_snake("HttpEndpoint", True) == "http_endpoint"
    assert _camel_to_snake("notEndpoint") == "not_endpoint"
    assert _camel_to_snake("notEndpoint", True) == "not_endpoint"
    assert _camel_to_snake("HTTPEndpointARNs") == "http_endpoint_ar_ns"

# Generated at 2022-06-24 20:32:45.774555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_set_0 = {
        "Id": "Id",
        "Arns": [
            "Arn1",
            "Arn2"
        ]
    }
    expected_result_0 = {
        'id': 'Id',
        'arns': [
            'Arn1',
            'Arn2'
        ]
    }
    assert camel_dict_to_snake_dict(test_set_0, False) == expected_result_0

    test_set_1 = {
        "AppMesh": {
            "Tags": {
                "Tag1": "Value1",
                "Tag2": "Value2"
            }
        }
    }

# Generated at 2022-06-24 20:32:56.627306
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:02.285422
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {"AccessKeyId": "abc123", "SecretAccessKey": "xyz456", "Tags": {"foo": "bar"}}
    ) == {"access_key_id": "abc123", "secret_access_key": "xyz456", "tags": {"foo": "bar"}}



# Generated at 2022-06-24 20:33:10.846615
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test for function 'camel_dict_to_snake_dict'"""

    set_0 = {
        "Tags": {
            "Tag": [{
                "Key": "string",
                "Value": "string"
            }]
        },
        "Name": "string",
        "AppMeshRef": "string",
        "VirtualRouterRef": "string"
    }
    var_0 = camel_dict_to_snake_dict(set_0, set_0)

# Generated at 2022-06-24 20:33:17.774001
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    params = {
        'file': u'my.file',
        'metaData': {
            'someMetaData': 'someMetaData'
        },
        'vars': {
            'someVariable': 'someValue',
            'someOtherVariable': 'someOtherValue'
        },
        'vaultPassword': 'someVaultPassword'
    }

    result = camel_dict_to_snake_dict(params, reversible=True)


# Generated at 2022-06-24 20:33:26.454943
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Initial test case
    set_0 = {
        "HTTPEndpoint": {
            "Endpoint": "asdf",
            "Tags": {
                "ABC": "DEF"
            },
            "HTTPEndpoint": {
                "Endpoint": "asdf",
                "Tags": {
                    "ABC": "DEF"
                }
            }
        },
        "List": [
            "a",
            "b",
            "c",
            {
                "a": "b",
                "c": "d"
            }
        ]
    }
    var_0 = camel_dict_to_snake_dict(set_0, set_0)

    # Test case with a lowercase parameter name

# Generated at 2022-06-24 20:33:36.922176
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var1 = {"A": 1, "B": "foo", "C": {"A": 1, "C": "foo"}}
    var_0 = camel_dict_to_snake_dict(var1)
    # var_0 = {'b': 'foo', 'a': 1, 'c': {'a': 1, 'c': 'foo'}}
    assert var_0 == {'b': 'foo', 'a': 1, 'c': {'a': 1, 'c': 'foo'}}

    # camel_dict =  {'A': 1, 'B': 'foo', 'C': {'A': 1, 'C': 'foo'}, 'D': [{'A': 1, 'B': ['foo', 'bar', 'red']}]}

# Generated at 2022-06-24 20:33:46.812412
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = dict(
        Foo=dict(
            foo=dict(
                FooFoo="hi",
                FooBar=1,
                FooBaz=[
                    dict(
                        foo=1
                    )
                ]
            ),
            bar=dict(
                BarFoo="hi",
                BarBar=2,
                BarBaz=1
            ),
        ),
        Bar=dict(
            foo=dict(
                FooFoo="hi",
                FooBar=1,
                FooBaz=[
                    dict(
                        foo=1
                    )
                ]
            ),
            bar=dict(
                BarFoo="hi",
                BarBar=2,
                BarBaz=1
            ),
        )
    )


# Generated at 2022-06-24 20:34:13.745670
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {
        "CacheSecurityGroupName": "abcd",
        "EC2SecurityGroupName": "abcd"
    }
    expected_0 = {
        "CacheSecurityGroupName": "abcd",
        "E_c_2SecurityGroupName": "abcd"
    }
    set_1 = {
        "CacheSecurityGroupName": "abcd",
        "EC2SecurityGroupName": "abcd"
    }
    expected_1 = {
        "cache_security_group_name": "abcd",
        "e_c_2_security_group_name": "abcd"
    }
    set_2 = {
        "CacheSecurityGroupName": "abcd",
        "EC2SecurityGroupName": "abcd"
    }

# Generated at 2022-06-24 20:34:25.937971
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dictionary = {'ArbitraryString': 'some_string'}
    snake_dictionary = {'arbitrary_string': 'some_string'}

    assert(camel_dict_to_snake_dict(camel_dictionary) == snake_dictionary), \
        'camel_dict_to_snake_dict took {}, but should have taken {}'.format(camel_dict_to_snake_dict(
            camel_dictionary), snake_dictionary)

    camel_dictionary = {'ArbitraryHttpEndpoint': 'https://aws.amazon.com'}
    snake_dictionary = {'arbitrary_http_endpoint': 'https://aws.amazon.com'}


# Generated at 2022-06-24 20:34:33.231408
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {"onDemandProvisioningSpecification": {"allocationStrategy": "prioritized"}}
    set_1 = {"on_demand_provisioning_specification": {"allocation_strategy": "prioritized"}}
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    # assert var_0 == set_1
    return var_0


# Generated at 2022-06-24 20:34:41.357647
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'SourceSecurityGroupOwnerId': '987654321098'}, False, None) == {'source_security_group_owner_id': '987654321098'}
    assert camel_dict_to_snake_dict({'SourceSecurityGroupOwnerId': '987654321098'}, False, None) == {'source_security_group_owner_id': '987654321098'}
    assert camel_dict_to_snake_dict({'Tags': [{'Key': 'foo', 'Value': 'bar'}]}, False, None) == {'tags': [{'key': 'foo', 'value': 'bar'}]}
    assert camel_dict_to_snake_dict({'SourceSecurityGroupOwnerId': '987654321098'}, False, None)

# Generated at 2022-06-24 20:34:47.236577
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"CorrelationId": "12345678-1234-1234-1234-123456789012"}) == {"correlation_id": "12345678-1234-1234-1234-123456789012"}

# Generated at 2022-06-24 20:34:56.098385
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {
        'ACL': 'public-read',
        'Bucket': 'cicd-yamls',
        'CacheControl': 'max-age=315360000',
        'ContentDisposition': 'attachment',
        'ContentType': 'application/octet-stream',
        'Expires': 'Sun, 17 Jan 2038 19:14:07 GMT',
        'Key': 'my_new_file',
        'StorageClass': 'STANDARD'
    }
    var_0 = camel_dict_to_snake_dict(set_0, False)

# Generated at 2022-06-24 20:34:58.665393
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert type(camel_dict_to_snake_dict(set_0)) == type(var_0)



# Generated at 2022-06-24 20:35:02.582081
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {
        "testKey": "testValue"
    }
    var_0 = camel_dict_to_snake_dict(set_0, set_0)
    assert var_0['test_key'] == 'testValue'


# Generated at 2022-06-24 20:35:10.124460
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = dict({'SecurityGroups': ['sg-0f8fdd80a63c4f4f4'], 'SubnetId': 'subnet-0ad29a69e8d8f6f1a'})
    expected_0 = {'security_groups': ['sg-0f8fdd80a63c4f4f4'], 'subnet_id': 'subnet-0ad29a69e8d8f6f1a'}
    var_0 = camel_dict_to_snake_dict(set_0, True, [])
    assert var_0 == expected_0


# Generated at 2022-06-24 20:35:13.191689
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    set_0 = {'my_http_endpoint': 'foo'}
    var_0 = camel_dict_to_snake_dict(set_0)
    assert var_0 == {'my_http_endpoint': 'foo'}

