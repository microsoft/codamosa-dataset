

# Generated at 2022-06-24 20:25:27.143127
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"key1": "value1", "key2": "value2"}
    snake_dict = {"key_1": "value1", "key_2": "value2"}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-24 20:25:34.715413
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_arg_0 = {'CustomerCidr': '39.1.63.238/29', 'BackendService': 'lb-backend-server-8', 'VpcId': 'lb-vpc-p-z8b4', 'Description': 'NAT Gateway for lb-vpc-p-z8b4', 'AllocationId': 'eipalloc-0f287c18b0dbc3741', 'InstanceId': 'i-02bcf27406957ae9d'}

# Generated at 2022-06-24 20:25:43.072984
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test
    #     dict1 = {}
    #     dict2 = {}
    dict1 = {}
    dict2 = {}
    print("Test 1: dict1={}, dict2={}".format(dict1, dict2))
    result = recursive_diff(dict1, dict2)
    print("Result: {}".format(result))

    # Test
    #     dict1 = {'key1': 'value1'}
    #     dict2 = {}
    dict1 = {'key1': 'value1'}
    dict2 = {}
    print("\nTest 2: dict1={}, dict2={}".format(dict1, dict2))
    result = recursive_diff(dict1, dict2)
    print("Result: {}".format(result))

    # Test
    #     dict1 = {'key1':

# Generated at 2022-06-24 20:25:46.589109
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        'id': 'value1',
        'Name': 'value2',
        'timezone': 'value3'
    }
    output_dict = {
        'id': 'value1',
        'name': 'value2',
        'timezone': 'value3'
    }
    assert camel_dict_to_snake_dict(input_dict) == output_dict


# Generated at 2022-06-24 20:25:50.975406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(int_0, str_0) == var_0


# Generated at 2022-06-24 20:25:56.863954
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=True),
                                    capitalize_first=True) == {'FooBar': 'baz'}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'fooBar': 'baz'}, reversible=False),
                                    capitalize_first=True) == {'FooBar': 'baz'}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'foobar': 'baz'}), capitalize_first=True) == {'Foobar': 'baz'}

# Generated at 2022-06-24 20:26:06.601624
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import sys
    import os
    import pytest

    try:
        from unittest.mock import MagicMock
        from unittest.mock import patch
        mock = MagicMock()
        from ansible.module_utils.aws.core import AnsibleAWSModule
        from ansible.module_utils.ec2 import camel_dict_to_snake_dict
        import ansible.module_utils.ec2 as ec2
    except ImportError:
        from mock import MagicMock
        from mock import patch
        mock = MagicMock()
        from ansible.module_utils.ec2 import camel_dict_to_snake_dict
        import ansible.module_utils.ec2 as ec2

    # Ansible 2.8 compat
    module = MagicMock()

# Generated at 2022-06-24 20:26:14.148654
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Simple cases
    assert _camel_to_snake('HTTPSEndpoint') == 'https_endpoint'
    assert _camel_to_snake('HTTPSEndpoint', True) == 'h_t_t_p_s_endpoint'

    assert _snake_to_camel('https_endpoint') == 'HttpsEndpoint'
    assert _snake_to_camel('https_endpoint', True) == 'HttpsEndpoint'

    # Plurals
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_arns'
    assert _camel_to_snake('AcceleratorARNs') == 'accelerator_arns'

# Generated at 2022-06-24 20:26:17.577799
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(int_0) == 976
    assert camel_dict_to_snake_dict(str_0) == '&<\na^\x0bLjLR7Z'


# Generated at 2022-06-24 20:26:26.816547
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_1 = {
        'variable_1': 'value1',
        'variable_2': 'value2',
        'dict_1': {
            'key1': 'value1',
            'key2': 'value2',
            'list_1': [
                'list1',
                'list2',
                'list3',
                {
                    'item': 'item1'
                },
                {
                    'item': 'item2'
                }
            ]
        }
    }


# Generated at 2022-06-24 20:26:44.312654
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(-2526) == -2526
    assert camel_dict_to_snake_dict(-2526.0) == -2526.0
    assert camel_dict_to_snake_dict(2526.0) == 2526.0
    assert camel_dict_to_snake_dict(-1.2526) == -1.2526
    assert camel_dict_to_snake_dict(1.2526) == 1.2526
    assert camel_dict_to_snake_dict(False) == False
    assert camel_dict_to_snake_dict(None) == None
    assert camel_dict_to_snake_dict('yukino') == 'yukino'

# Generated at 2022-06-24 20:26:54.698547
# Unit test for function dict_merge

# Generated at 2022-06-24 20:27:03.612229
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'x': 1, 'y': 2, 'z': {'a': 11, 'b': 12}, 'list': [1, 2, 3]}
    dict2 = {'x': 10, 'z': {'a': 13, 'c': 14}, 'list': [10, 20, 30]}

    # Simple merge
    dict_merge(dict1, dict2) == {'x': 10, 'y': 2, 'z': {'a': 13, 'b': 12, 'c': 14}, 'list': [10, 20, 30]}

    # Confirm dict1 is unchanged
    dict1 == {'x': 1, 'y': 2, 'z': {'a': 11, 'b': 12}, 'list': [1, 2, 3]}

    # Add an optional argument to prevent from modifying original
    dict_mer

# Generated at 2022-06-24 20:27:05.789065
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == -2526


# Generated at 2022-06-24 20:27:14.411842
# Unit test for function recursive_diff
def test_recursive_diff():
    print("UNIT TESTING FUNCTION: recursive_diff()")
    from nose.tools import assert_equals

    # case 1:
    dict1 = {'db': {'host': 'localhost', 'password': 'Mysq1$', 'user': 'admin'},
             'user': 'root'}
    dict2 = {'db': {'host': 'localhost', 'password': 'Mysql$', 'user': 'admin'},
             'user': 'root'}

    assert_equals(recursive_diff(dict1, dict2),
                  ({'db': {'password': 'Mysq1$'}},
                   {'db': {'password': 'Mysql$'}}))

    # case 2:

# Generated at 2022-06-24 20:27:24.427852
# Unit test for function dict_merge
def test_dict_merge():
    # should not fail
    dict_merge({}, {})
    dict_merge({'a': 'string'}, {})
    dict_merge({}, {'a': 'string'})

    # should not fail
    dict_merge({'a': {'b': 1}}, {})
    dict_merge({'a': {'b': 1}}, {'a': {'b': 2}})
    dict_merge({'a': {'b': 1}}, {'a': {}})

    # should not fail
    dict_merge({'a': ['b', {'c': 1}]}, {})
    dict_merge({'a': ['b', {'c': 1}]}, {'a': ['b', {'c': 2}]})

# Generated at 2022-06-24 20:27:33.827619
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}, 'f': {'g': {'h': 8, 'i': 9}}}
    dict2 = {'a': 1, 'b': 3, 'c': {'d': 4, 'e': 6}, 'f': {'g': {'h': 8, 'i': 9}}}
    expected = {'b': 2, 'c': {'e': 5}, 'f': {'g': {'i': 9}}}
    assert expected == recursive_diff(dict1, dict2)[0]

# Generated at 2022-06-24 20:27:40.256946
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test various objects
    items = [1, 1.0, 'test', ['a']]
    first = {}
    second = {}
    for elem in items:
        first[elem] = elem
        second[elem] = elem

    # Verify no diffs
    assert recursive_diff(first, second) is None

    # Test changes with lists and dicts
    for elem in items:
        first[elem] = [elem]
        assert recursive_diff(first, second)[1]
    for elem in items:
        second[elem] = {elem: elem}
        assert recursive_diff(first, second)[1]

# Generated at 2022-06-24 20:27:49.726102
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        "foo": "bar",
        "baz": "qux",
        "depth": {
            "a": "test",
            "b": "test2",
            "c": "test3"
        },
        "list": [
            { "a": "test", "b": "test2", "c": "test3" },
            { "a": "test", "b": "test2", "c": "test3" },
            { "a": "test", "b": "test2", "c": "test3" },
            { "a": "test", "b": "test2", "c": "test3" },
            { "a": "test", "b": "test2", "c": "test3" }
        ]
    }


# Generated at 2022-06-24 20:27:55.487659
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('test_string') == 'test_string'
    assert camel_dict_to_snake_dict(2526) == 2526
    assert camel_dict_to_snake_dict([1,2,3]) == [1,2,3]
    assert camel_dict_to_snake_dict(({'camel': 1, 'dromedary': 2}, [3,4,5])) == ({'camel': 1, 'dromedary': 2}, [3,4,5])


# Generated at 2022-06-24 20:28:01.389305
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict([]) == []
    assert camel_dict_to_snake_dict(2526) == 2526


# Generated at 2022-06-24 20:28:07.549011
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_0['IsTruncated'] = False
    dict_0['MaxItems'] = '1'
    dict_0['Marker'] = '1'
    dict_0['NextMarker'] = '1'
    dict_0['AccountQuotas'] = list()
    dict_0['AccountQuotas'].append(dict())
    dict_0['AccountQuotas'][0]['AccountQuotaName'] = 'ec2-max-elastic-ips'
    dict_0['AccountQuotas'][0]['ServiceCode'] = 'ec2'
    dict_0['AccountQuotas'][0]['Value'] = -7937
    dict_0['AccountQuotas'][0]['Unit'] = 'Count'

# Generated at 2022-06-24 20:28:18.879349
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3
        },
        'e': 4,
        'f': {
            'g': 5,
            'h': 6
        }
    }

    dict2 = {
        'a': 1,
        'b': {
            'c': 3,
            'd': 3
        },
        'e': 4,
        'f': {
            'g': 5,
            'h': 7
        }
    }

    result = recursive_diff(dict1, dict2)
    assert result is not None
    assert result[0] == {'b': {'c': 2}}
    assert result[1] == {'b': {'c': 3}, 'f': {'h': 7}}

# Generated at 2022-06-24 20:28:29.325660
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:40.442683
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:49.174222
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {"HTTPEndpoint": {"AcceptanceRequired": False, "BasePath": "string", "EndpointType": "string", "Id": "string", "Name": "string"}, "Type": "string"}
    expected_result = {"h_t_t_p_endpoint": {"acceptance_required": False, "base_path": "string", "endpoint_type": "string", "id": "string", "name": "string"}, "type": "string"}
    result = camel_dict_to_snake_dict(dict_0)
    assert result == expected_result


# Generated at 2022-06-24 20:28:59.571137
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-24 20:29:00.396426
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()

# Generated at 2022-06-24 20:29:06.332811
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:15.871767
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "TestString": "Romeo",
        "TestInt": 23,
        "TestBool": True,
        "SampleDict": {
            "SubDictString": "Juliet",
            "SubDictInt": 27
        },
        "SampleList": [
            {
                "SubListDictString": "Mercutio",
                "SubListDictInt": 31
            },
            {
                "SubListDictString": "Tybalt",
                "SubListDictInt": 18
            }
        ]
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-24 20:29:26.651296
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "RetryCount": 1,
                "URL": "MyString",
                "Username": "MyString",
                "Password": "MyString",
                "AuthType": "basicAuth",
                "ProxyHost": "MyString",
                "ProxyPort": 1,
                "ProxyUsername": "MyString",
                "ProxyPassword": "MyString"
            }
        },
        "Name": "MyString",
        "Tags": [
            {
                "Key": "MyString",
                "Value": "MyString"
            }
        ]
    }

    snaked_dict = camel_dict_to_snake_dict(test_camel_dict)
    assert snaked_dict

# Generated at 2022-06-24 20:29:31.943419
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == int_0

    dict_0 = {'EIP': 'eip', 'LoadBalancer': 'load_balancer', 'TargetGroupARNs': 'target_group_ar_ns'}

    dict_1 = {'EIP': 'eip', 'LoadBalancer': 'load_balancer', 'TargetGroupARNs': 'target_group_ar_ns'}

    var_1 = camel_dict_to_snake_dict(dict_0)
    assert var_1 == dict_1



# Generated at 2022-06-24 20:29:34.833302
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Parameterize a string value to test with
    camel_dict_int_0 = -2526
    # Execute function
    result = camel_dict_to_snake_dict(camel_dict_int_0)
    # Verify the results
    assert result == -2526



# Generated at 2022-06-24 20:29:44.501741
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'key_1': 'val_1',
        'key_2': {
            'key_2.1': 'val_1',
            'key_2.2': 'val_2',
        },
    }
    dict2 = {
        'key_1': 'val_1',
        'key_2': {
            'key_2.1': 'value_1',
            'key_2.2': 'val_2',
        },
    }
    diff = recursive_diff(dict1, dict2)
    assert diff == ({'key_2': {'key_2.1': 'val_1'}}, {'key_2': {'key_2.1': 'value_1'}})


# Generated at 2022-06-24 20:29:53.331498
# Unit test for function recursive_diff
def test_recursive_diff():
    # Case 1:
    dict1 = {'test_key1': 1, 'test_key2': 2, 'test_key3': {'test_key4': {'test_key5': 4}}, 'test_key6': 6}
    dict2 = {'test_key1': 1, 'test_key2': 2, 'test_key3': {'test_key4': {'test_key5': 5}}, 'test_key6': 6}
    result = recursive_diff(dict1, dict2)
    valid_result = ({'test_key3': {'test_key4': {'test_key5': 4}}}, {'test_key3': {'test_key4': {'test_key5': 5}}})
    assert valid_result == result
    # Case 2:

# Generated at 2022-06-24 20:29:57.800430
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'instanceId': 'InstanceId', 'instanceType': 'InstanceType'}
    dict_1 = camel_dict_to_snake_dict(camel_dict)
    dict_2 = {'instance_id': 'InstanceId', 'instance_type': 'InstanceType'}

    assert dict_1 == dict_2



# Generated at 2022-06-24 20:30:06.022739
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:16.341932
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict1 = { "TestName" : "test"}
    camel_dict2 = { "TestName" : "test", "ValueOne" : "value"}
    camel_dict3 = { "TestName" : "test", "ValueTwo" : { "TestName" : "test"}}
    camel_dict4 = { "TestName" : "test", "ValueTwo" : { "TestName" : "test", "ValueThree" : [ 1, 2, 3]}}
    camel_dict5 = { "TestName" : "test", "ValueThree" : [ 1, 2, {"ValueFour" : "test", "ValueFive" : "test"}, 3]}
    expected_output1 = { "test_name" : "test"}

# Generated at 2022-06-24 20:30:26.483125
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == int_0

    list_0 = [360, 479]
    str_0 = "Ansible is a radically simple IT automation platform that " \
            "makes your applications and systems easier to deploy. Avoid writing scripts or custom code to deploy and update your applications— automate in a language that approaches plain English, using SSH, with no agents to install on remote systems."
    str_1 = "Ansible is a simple IT automation platform that " \
            "makes your applications and systems easier to deploy. Avoid writing scripts or custom code to deploy and update your applications— automate in a language that approaches plain English, using SSH, with no agents to install on remote systems."

# Generated at 2022-06-24 20:30:34.531339
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_0 = {
        "VpcId": "vpc-abcdef12",
        "Tags": {
            # Tags are a special case where we don't want to (or can't)
            # convert keys
            "Name": "test",
        },
        "Subnets": [
            # Subnets is a list of dicts, so we need a recursive check
            {"SubnetId": "subnet-abcdef12"},
            {"SubnetId": "subnet-abcdef13"},
        ]
    }


# Generated at 2022-06-24 20:30:47.415538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import random

    # Test a list with a function call, a string, a unicode and a list
    test_list = [
        {"ThisIsJustATest": "test",
         "ThisIsAList": ['a', 2, [{'test': None}, 'b']]},
        "test",
        "test",
        "test",
        {"ThisIsAList": ['a', 2, [{'test': None}, 'b']]},
    ]

    # Test converting a list recursively
    test_list = camel_dict_to_snake_dict(test_list)

    # Test converting a string
    test_str = "ThisIsATestString"
    test_str = camel_dict_to_snake_dict(test_str)

    # Test converting a unicode

# Generated at 2022-06-24 20:30:56.472766
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_0["AWS::Region"] = "eu-west-1"
    dict_0["AWS::AccountId"] = "1234567890"
    dict_0["StackName"] = "test_camel_dict_to_snake_dict"
    dict_0["StackId"] = "arn:aws:cloudformation:eu-west-1:1234567890:stack/" + dict_0["StackName"] + "/12345678-1234-1234-1234-123456789012"

# Generated at 2022-06-24 20:31:05.717027
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {}
    dict_1 = {}
    dict_1['Tags'] = {}
    dict_0['TagList'] = dict_1
    dict_0['SubnetId'] = 'subnet-c857208e'
    dict_2 = {}
    dict_3 = {}
    dict_3['HostHeader'] = 'example.com'
    dict_3['PathPattern'] = '/'
    dict_3['HttpCode'] = '200'
    dict_2['Values'] = dict_3
    dict_2['Name'] = 'HttpCode'
    dict_4 = {}
    dict_4['Quantity'] = 1
    dict_4['Type'] = 'HTTP'
    dict_4['Name'] = 'http'
    dict_5 = {}
    dict_5['Value'] = dict_4
    dict

# Generated at 2022-06-24 20:31:15.357458
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_1 = {
        'dict1_key1': 1,
        'dict1_key2': '2',
        'dict1_key3': {
            'recursive_key1': 3,
            'recursive_key2': '4'
        }
    }

    dict_2 = {
        'dict1_key1': 99,
        'dict1_key2': '2',
        'dict1_key3': {
            'recursive_key1': 3,
            'recursive_key2': 4
        },
        'dict1_key4': 'bazinga!'
    }

    expected = ({'dict1_key1': 1}, {'dict1_key1': 99, 'dict1_key4': 'bazinga!'})

# Generated at 2022-06-24 20:31:21.313453
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = -2526
    assert camel_dict_to_snake_dict(int_0) == -2526
    bool_0 = True
    assert camel_dict_to_snake_dict(bool_0) == True
    str_0 = 'abc'
    assert camel_dict_to_snake_dict(str_0) == 'abc'
    dict_0 = {"tags": {"Type": "text"}}
    assert camel_dict_to_snake_dict(dict_0) == {"tags": {"Type": "text"}}
    list_0 = [1, 2, 3]
    assert camel_dict_to_snake_dict(list_0) == [1, 2, 3]

# Generated at 2022-06-24 20:31:29.390290
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test #0
    # Simple camelDict
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict({'CamelDict': int_0})
    assert var_0 == {'camel_dict': int_0}

    # Test #1
    # Complex camelDict
    var_1 = camel_dict_to_snake_dict({'CamelDict': {'subDict': {'subSubDict': {'subSubSubDict': [1, 2, 3]}}}})
    assert var_1 == {'camel_dict': {'sub_dict': {'sub_sub_dict': {'sub_sub_sub_dict': [1, 2, 3]}}}}

    # Test #2
    # Replace case
    var_2 = camel_

# Generated at 2022-06-24 20:31:35.850066
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    assert var_0 == -2526


    int_1 = 1
    var_1 = camel_dict_to_snake_dict(int_1)
    assert var_1 == 1


    str_0 = "abc"
    var_2 = camel_dict_to_snake_dict(str_0)
    assert var_2 == "abc"


# Generated at 2022-06-24 20:31:44.864856
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:45.391346
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True

# Generated at 2022-06-24 20:31:54.929247
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'abcDef': {
            'httpEndpoint': 'https://foobar.com',
            'tags': {
                'notAGoodTag': 'not a good value',
                'AnotherBadTag': 'another bad value',
                'AnotherListOfTags': [
                    'T',
                    'H',
                    'I',
                    'S',
                    'I',
                    'S',
                    'A',
                    'T',
                    'A',
                    'G'
                ]
            }
        },
        'abcDef2': {
            'abcDef2': {
                'httpEndpoint': 'https://foobar.com'
            },
            'HTTPEndpoint': 'https://foobar.com'
        },
        'HTTPEndpoint': 'https://foobar.com'
    }



# Generated at 2022-06-24 20:32:04.048575
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Key1': 'Value1',
        'Key2': 'Value2',
        'Key3': 'Value3',
        'Key4': {
            'Key5': 'Value5',
            'Key6': 'Value6'
        },
        'Key7': {
            'Key8': {
                'Key9': 'Value9',
                'Key10': 'Value10'
            }
        }
    }

# Generated at 2022-06-24 20:32:12.706593
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_0 = {"HTTPEndpoint": {"URL": "http://foobar.com"}}
    output_0 = {"h_t_t_p_endpoint": {"url": "http://foobar.com"}}
    assert camel_dict_to_snake_dict(input_0) == output_0

    input_1 = {"HTTP_Endpoint": {"URL": "http://foobar.com"}}
    output_1 = {"h_t_t_p_endpoint": {"url": "http://foobar.com"}}
    assert camel_dict_to_snake_dict(input_1) == output_1


# Generated at 2022-06-24 20:32:20.818953
# Unit test for function recursive_diff
def test_recursive_diff():
    old_list = {'list': [{'a': 2, 'b': 3}]}
    new_list = {'list': [{'a': 2, 'b': 2}]}
    assert recursive_diff(old_list, new_list) == ({'list': [{'b': 3}]}, {'list': [{'b': 2}]})
    old_list = {'list': [{'a': 2, 'b': 3}, {'b': 2}]}
    new_list = {'list': [{'a': 2, 'c': 3}]}
    assert recursive_diff(old_list, new_list) == ({'list': [{'b': 3}, {'b': 2}]}, {'list': [{'c': 3}]})

# Generated at 2022-06-24 20:32:31.941452
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:39.216443
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:48.648318
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    in_0 = {"HTTPEndpoint": "MyHTTPDestination", "MatchOptions": ["ResponseCode"], "Name": "MySubscription", "TransformationTemplate": "$default"}
    expected_0 = {"match_options": ["ResponseCode"], "name": "MySubscription", "http_endpoint": "MyHTTPDestination", "transformation_template": "$default"}
    actual_0 = camel_dict_to_snake_dict(in_0)
    assert actual_0 == expected_0

    in_1 = {"HTTPDestinationConfiguration": {"HTTPEndpoint": "MyHTTPDestination", "MatchOptions": ["ResponseCode"], "Name": "MySubscription", "TransformationTemplate": "$default"}}

# Generated at 2022-06-24 20:32:52.159772
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = {'HTTPEndpoint': {'URL': 'www.example.com'}}
    assert camel_dict_to_snake_dict(x) == {'http_endpoint': {'url': 'www.example.com'}}



# Generated at 2022-06-24 20:33:04.646297
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('Test function camel_dict_to_snake_dict')
    # Test Case #0
    print('Test Case #0')
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    if var_0 != -2526:
        print('var_0 =', var_0, 'Expected output = -2526')
        raise Exception('Test Case #0 Failed')
    print('Test Case #1')
    dict_0 = {
        'FooBar': 30,
        'BarBaz': 'Hello',
        'BazFoo': 'World',
        'Foo': 1,
        'Bar': 'ThisIsAString'
    }
    var_1 = camel_dict_to_snake_dict(dict_0)

# Generated at 2022-06-24 20:33:11.639306
# Unit test for function recursive_diff
def test_recursive_diff():
    first = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }
    second = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 4,
            'e': 3,
        },
    }
    # We do not care about the order of the items in an array, but
    # the order of the keys in a dictionary are relevant, so this
    # fails (expectedly)
    third = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 4,
            'e': 3,
        },
    }

# Generated at 2022-06-24 20:33:21.528377
# Unit test for function recursive_diff
def test_recursive_diff():
    initial = {
        'lev1': {
            'lev2': {
                'key1': 'val1',
                'key2': 'val2',
                'key3': 'val3',
            },
            'key4': 'val4',
        },
        'key5': 'val5',
    }
    updated = {
        'lev1': {
            'lev2': {
                'key1': 'val1',
                'key2': 'val2',
                'key3': 'val3',
            },
            'key4': 'val5',
        },
        'key5': 'val5',
    }


# Generated at 2022-06-24 20:33:35.565473
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(
        {'foo': 'bar', 'bar': 'baz'},
        {'foo': 'bar', 'bar': 'test'}
    ) == ({'bar': 'test'}, {'bar': 'baz'})

    assert recursive_diff(
        {'foo': 'foo', 'bar': 'bar', 'baz': 'baz'},
        {'bar': 'bar', 'baz': 'baz'}
    ) == ({'foo': 'foo'}, None)

    assert recursive_diff(
        {'foo': 'foo', 'bar': 'bar', 'baz': 'baz'},
        {'foo': 'foo', 'bar': 'test', 'baz': 'baz'}
    ) == ({'bar': 'test'}, {'bar': 'bar'})



# Generated at 2022-06-24 20:33:46.690772
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_cases = []
    test_cases.append({
        "camel": {
            "Tags": {
                "Key": "foo",
                "Value": "bar"
            },
            "DryRun": False,
            "HTTPEndpoint": "example.com"
        },
        "snake": {
            "tags": {
                "Key": "foo",
                "Value": "bar"
            },
            "dry_run": False,
            "h_t_t_p_endpoint": "example.com"
        }
    })

# Generated at 2022-06-24 20:33:53.577107
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=1, b=2, c=dict(a=1, b=2, c=dict(a=1, b=2)))
    dict2 = dict(a=1, b=2, c=dict(a=3, b=2, c=dict(a=1, b=2)))
    assert recursive_diff(dict1, dict2) == (dict(c=dict(a=1)), dict(c=dict(a=3)))
    dict1 = dict(a=1, b=2, c=dict(a=1, b=2, c=dict(a=1, b=2)))
    dict2 = dict(a=1, b=2, c=dict(a=3, b=2, c=dict(a=1, b=2)))

# Generated at 2022-06-24 20:34:02.702197
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print ("Test Case 0:")
    int_0 = -2526
    var_0 = camel_dict_to_snake_dict(int_0)
    print ("\tvar_0 is:", var_0)
    assert var_0 == -2526

    print ("Test Case 1: ")
    dict_0 = {}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    print ("\tdict_1 is:", dict_1)
    assert dict_1 == {}

    print ("Test Case 2: ")
    dict_0 = {'a': 'a_value', 'b': 'b_value'}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    print ("\tdict_1 is:", dict_1)
   

# Generated at 2022-06-24 20:34:11.112117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        int_0 = -2526
        var_0 = camel_dict_to_snake_dict(int_0)
        assert False
    except TypeError as e:
        assert True

    try:
        str_0 = "YWxpY2UgYXNzdW1lcyB0aGUgbW9zdCwgYnV0IGZhaWxzIG9uZSB0aW1lIHRvIGV2ZXJ5IHR3by4="
        var_0 = camel_dict_to_snake_dict(str_0)
        assert False
    except TypeError as e:
        assert True


# Generated at 2022-06-24 20:34:15.951001
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Check simple case
    result = camel_dict_to_snake_dict({'InstanceId': 'i-1234567890abcdef0'})
    assert result['instance_id'] == 'i-1234567890abcdef0'

    result = camel_dict_to_snake_dict({'HTTPEndpoint': 'http://localhost'})
    assert result['h_t_t_p_endpoint'] == 'http://localhost'

    # Check nested dict
    result = camel_dict_to_snake_dict({'Tags': {'Name': 'ExampleTag'}})
    assert result['tags']['name'] == 'ExampleTag'

    # Check empty dict
    result = camel_dict_to_snake_dict({}, True)
    assert result == {}


# Generated at 2022-06-24 20:34:17.619321
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Test: camel_dict_to_snake_dict")
    test_case_0()


test_camel_dict_to_snake_dict()

# Generated at 2022-06-24 20:34:26.722235
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('CamelCase', reversible=False) == 'camel_case'
    assert _camel_to_snake('CamelCase', reversible=True) == 'camel_case'
    assert _camel_to_snake('ACamelCase', reversible=False) == 'a_camel_case'
    assert _camel_to_snake('ACamelCase', reversible=True) == 'a_camel_case'
    assert _camel_to_snake('CamelCaseWithSuffix', reversible=False) == 'camel_case_with_suffix'
    assert _camel_to_snake('CamelCaseWithSuffix', reversible=True) == 'camel_case_with_suffix'

# Generated at 2022-06-24 20:34:35.962637
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({"a": 1, "b": 2}, {"a": 1, "b": 3}) == ({}, {'b': 3})
    assert recursive_diff({"a": 1, "b": {"c": {"d": 4}}}, {"a": 1, "b": {"c": {"d": 4}}}) is None
    assert recursive_diff({"a": 1, "b": {"c": {"d": 4}}}, {"a": 1, "b": {"c": {"d": 11}}}) == ({'b': {'c': {'d': 4}}}, {'b': {'c': {'d': 11}}})

# Generated at 2022-06-24 20:34:42.490880
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    map_0 = {}
    map_1 = {}
    map_2 = {"One": [{"Two": 2, "Three": "three"}, [{"Four": 4}, {"Five": 5}, {"Six": 6}]], "Seven": 7, "Eight": 8, "Nine": 9}
    map_3 = {"One": [{"two": 2, "three": "three"}, [{"four": 4}, {"five": 5}, {"six": 6}]], "seven": 7, "eight": 8, "nine": 9}

    assert camel_dict_to_snake_dict(map_0) == map_0
    assert snake_dict_to_camel_dict(map_0) == map_0

    assert camel_dict_to_snake_dict(map_1) == map_1
    assert snake_dict_to_camel_

# Generated at 2022-06-24 20:34:56.637077
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:35:05.748149
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Input parameters
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPPath': '/path1',
            'HTTPPort': 123
        }
    }
    reversible = False
    ignore_list = ()

    # Actual output
    actual_output = camel_dict_to_snake_dict(camel_dict, reversible, ignore_list)

    # Expected output
    expected_output = {
        'http_endpoint': {
            'http_path': '/path1',
            'http_port': 123
        }
    }

    assert actual_output == expected_output, \
        "camel_dict_to_snake_dict() did not return expected output"



# Generated at 2022-06-24 20:35:14.656334
# Unit test for function camel_dict_to_snake_dict