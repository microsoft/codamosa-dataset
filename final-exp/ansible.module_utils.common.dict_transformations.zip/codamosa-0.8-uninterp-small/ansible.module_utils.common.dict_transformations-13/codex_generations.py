

# Generated at 2022-06-24 20:25:20.939905
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(str_0) != str_0


# Generated at 2022-06-24 20:25:29.284810
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1, 'b': 2, 'c': 3, 'e': {'f': 5, 'g': 6, 'h': 7, 'i': 8}},
                          {'a': 1, 'b': 2, 'c': 4, 'e': {'f': 5, 'g': 7, 'h': 6, 'i': 8}}) == \
                            ({'c': 3, 'e': {'g': 6, 'h': 7}},
                             {'c': 4, 'e': {'g': 7, 'h': 6}})


# Generated at 2022-06-24 20:25:39.187433
# Unit test for function recursive_diff
def test_recursive_diff():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest


# Generated at 2022-06-24 20:25:45.285460
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'name': 'Foo', 'state': 'present', 'vpc': {'id': 'foo_bar', 'ipaddress': '192.0.2.1'}, 'environment': 'production'}
    dict2 = {'name': 'Foo', 'state': 'present', 'environment': 'production'}
    assert recursive_diff(dict1, dict2) == ({'vpc': {'ipaddress': '192.0.2.1', 'id': 'foo_bar'}}, {'vpc': {}})
    dict1 = {'name': 'Foo', 'state': 'present', 'vpc': {'id': 'foo_bar', 'ipaddress': '192.0.2.1'}, 'environment': 'production'}

# Generated at 2022-06-24 20:25:56.105370
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {}
    dict_0['dict_0'] = {'dict_0_0': {'list_0_0_0': [{'dict_0_0_0_0_0': {'list_0_0_0_0_0_0': [1, 2]}}, 3, 4]}}
    dict_0['dict_0']['dict_0_0']['list_0_0_0'].append(5)
    dict_0['dict_0']['dict_0_0']['list_0_0_0'].append(6)

# Generated at 2022-06-24 20:25:59.025510
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_0 = { 'a': 1, 'b': 2 }
    dict_1 = { 'a': 1, 'c': 3 }
    expected = (dict_1, dict_0)

    result = recursive_diff(dict_0, dict_1)
    assert result == expected

# Generated at 2022-06-24 20:26:07.476303
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'checkpoint': {'qos': 1, 'crc': 8, 'overwrite': False}, 'filename': 'file.txt', 'time_interval': 1}
    dict2 = {'filename': 'file.txt', 'time_interval': 1, 'checkpoint': {'overwrite': False, 'crc': 8, 'qos': 1}}
    assert recursive_diff(dict1, dict2) == None
    dict1 = {'filename': 'file.txt', 'checkpoint': {'overwrite': False, 'crc': 8, 'qos': 1}, 'time_interval': 1}
    dict2 = {'filename': 'file.txt', 'time_interval': 1, 'checkpoint': {'overwrite': False}}

# Generated at 2022-06-24 20:26:14.673105
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1_1 = dict(
        a='1',
        b='2',
        c=dict(
            d='3',
            e=dict(
                f='4',
                g='5',
                h='6',
            ),
            i='7',
        ),
        j='8',
    )
    dict1_2 = dict(
        a='1',
        b='2',
        c=dict(
            d='3',
            e=dict(
                f='4',
                g='4',
                h='6',
            ),
            i='7',
        ),
        j='8',
    )

# Generated at 2022-06-24 20:26:22.053775
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        "a": 1,
        "b": 2,
        "c": {
            "a": 2,
            "b": {
                "a": 3,
                "b": 4
            }
        },
        "d": 4
    }

    dict2 = {
        "a": 1,
        "b": 2,
        "c": {
            "a": 2,
            "b": {
                "a": 3,
                "b": 4
            }
        },
        "d": 4
    }

    assert recursive_diff(dict1, dict2) is None

    dict2["c"]["b"]["c"] = 5

    assert recursive_diff(dict1, dict2) == ({}, {"c": {"b": {"c": 5}}})


# Generated at 2022-06-24 20:26:24.270660
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    case_0 = {
        'Key': 'value',
        'AnotherKey': 'AnotherValue'
    }

    result = camel_dict_to_snake_dict(case_0)

    assert result == {
        'key': 'value',
        'another_key': 'AnotherValue'
    }


# Generated at 2022-06-24 20:26:33.100232
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict("", False, ()) == ""
    assert camel_dict_to_snake_dict("") == ""
    assert camel_dict_to_snake_dict("", True, ()) == ""
    assert camel_dict_to_snake_dict("", True) == ""



# Generated at 2022-06-24 20:26:40.386214
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test when camel_dict is empty
    str_0 = ''

    assert camel_dict_to_snake_dict(str_0) == ''

    # Test when camel_dict is None
    str_0 = None

    assert camel_dict_to_snake_dict(str_0) == None

    # Test when camel_dict is not a dictionary type
    str_0 = 'IS59+QB'

    assert camel_dict_to_snake_dict(str_0) == 'IS59+QB'



# Generated at 2022-06-24 20:26:43.025571
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"ConfigKey": "ConfigValue"}, False) == {"config_key": "ConfigValue"}



# Generated at 2022-06-24 20:26:53.268179
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Running: test_camel_dict_to_snake_dict")
    inputs = {
        "ClusterName": "cluster",
        "ContainerName": "container",
        "TaskCount": 1,
        "Family": "family",
        "Uuid": "UUID",
        "LaunchType": "EC2",
        "Connections": {
          "ContainerPort": 80,
          "ContainerPortMappings": [
            {
              "HostPort": 80,
              "ContainerPort": 80
            }
          ]
        },
        "ContainerDefinitions": [
          {
            "Hostname": "",
            "Memory": 256,
            "Image": "image",
            "Name": "name"
          }
        ]
    }

# Generated at 2022-06-24 20:26:56.657968
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert callable(camel_dict_to_snake_dict)


# Generated at 2022-06-24 20:27:05.005330
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    #from ansible.module_utils.ec2 import camel_dict_to_snake_dict
    camel_dict = {'aBc': True, 'cDf': True, 'tHg': 'Hello',
                  'list': ['aBc', 'eFg', 'iLk', 'mNq'], 'dict': {'aBc': True, 'cDf': True}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'a_bc': True, 'c_df': True, 't_hg': 'Hello',
                          'list': ['a_bc', 'e_fg', 'i_lk', 'm_nq'], 'dict': {'a_bc': True, 'c_df': True}}



# Generated at 2022-06-24 20:27:13.859793
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:23.998456
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:32.124356
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "camelCase": "Str1",
        "CamelCaseIgnored": "Str2",
        "additionalProperty": "Str3",
    }

    result = camel_dict_to_snake_dict(camel_dict)

    expected = {
        "camel_case": "Str1",
        "camel_case_ignored": "Str2",
        "additional_property": "Str3",
    }

    assert result == expected


# Generated at 2022-06-24 20:27:33.761615
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {'foo': 'bar'}
    var_1 = False
    var_2 = []
    var_3 = camel_dict_to_snake_dict(var_0, var_1, var_2)



# Generated at 2022-06-24 20:27:45.230607
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_ar_ns'
    assert _camel_to_snake('TargetGroupARNs', True) == 'target_group_a_r_ns'
    assert _camel_to_snake('TargetGroupARNsList') == 'target_group_ar_ns_list'
    assert _camel_to_snake('TargetGroupARNsList', True) == 'target_group_a_r_ns_list'


# Generated at 2022-06-24 20:27:52.472117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    value_0 = {
        'a': 'new',
        'b': 'addition',
        'c': 'change',
        'd': {'a': 'new', 'b': 'addition', 'c': 'change', 'd': 'unchanged'}
    }
    value_1 = {
        'a': 'change',
        'b': 'unchanged',
        'c': 'change',
        'e': 'deletion'
    }
    value_2 = {
        'a': 'change',
        'b': 'remove',
        'd': 'unchanged'
    }
    out_0 = recursive_diff(value_0, value_1)
    out_1 = recursive_diff(value_1, value_2)

# Generated at 2022-06-24 20:27:54.233345
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Verify that exception is raised and caught
    try:
        pass
        # assert False
    except:
        pass
    return True



# Generated at 2022-06-24 20:28:02.021817
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    case_0 = {'NATGatewayId': '1', 'VPCId': '2', 'VPCName': '3'}
    case_1 = {'VPCId': '1', 'VPCName': '2', 'VPCId2': '3'}
    case_2 = {'VPCId': '3', 'VPCId2': '1', 'VPCName': '2'}

    var_0 = camel_dict_to_snake_dict(case_0)
    var_1 = camel_dict_to_snake_dict(case_1)
    var_2 = camel_dict_to_snake_dict(case_2)

    assert var_0 == {'nat_gateway_id': '1', 'vpc_id': '2', 'vpc_name': '3'}

# Generated at 2022-06-24 20:28:06.858544
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:14.936771
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Input parameters
    camel_dict = {'HTTPEndpoint': {'Protocol': 'HTTP'}, 'HTTPSEndpoint': {'Protocol': 'HTTPS'}}
    reversible = False
    ignore_list = []
    result = camel_dict_to_snake_dict(camel_dict, reversible, ignore_list)
    assert result == {'http_endpoint': {'protocol': 'HTTP'}, 'https_endpoint': {'protocol': 'HTTPS'}}



# Generated at 2022-06-24 20:28:23.433961
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = dict(loadBalancerName='MyLB', targetGroups=[dict(targetGroupName='MyLB'), dict(targetGroupArn='arn:aws:elasticloadbalancing:us-west-2:746381148573:targetgroup/MyLB/50dc6c495c0c9188')])
    expected = dict(load_balancer_name='MyLB', target_groups=[dict(target_group_name='MyLB'), dict(target_group_arn='arn:aws:elasticloadbalancing:us-west-2:746381148573:targetgroup/MyLB/50dc6c495c0c9188')])
    result = camel_dict_to_snake_dict(input)
    assert result == expected


# Generated at 2022-06-24 20:28:34.513906
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:42.357884
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_0['Test'] = 'test'
    dict_0['NestedTest'] = dict()
    dict_0['NestedTest']['NestTest'] = 'nest_test'
    dict_0['NestedTest']['Test'] = 'test'
    dict_0['NestedTest']['NestedTest2'] = dict()
    dict_0['NestedTest']['NestedTest2']['Test'] = 'test'
    dict_0['NestedTest']['NestedTest2']['NestTest'] = 'nest_test'
    dict_0['NestedTest']['NestedTest2']['NestedTest3'] = dict()

# Generated at 2022-06-24 20:28:46.555894
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert (camel_dict_to_snake_dict({'CamelCase': 1, 'dromedaryCase': 2}) == {'camel_case': 1, 'dromedary_case': 2})



# Generated at 2022-06-24 20:28:58.644242
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.modules.cloud.oracle import oracle_waas_service
    from ansible.modules.cloud.oracle import oracle_waas_device_facts


# Generated at 2022-06-24 20:29:02.424435
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = dict()
    var_0['aB'] = 1
    var_0['cD'] = 2
    var_0['eF'] = 3
    assert (camel_dict_to_snake_dict(var_0) == {
        'a_b': 1,
        'c_d': 2,
        'e_f': 3
    })



# Generated at 2022-06-24 20:29:11.946358
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test camel_dict_to_snake_dict()"""
    assert {'first_name': 'John', 'last_name': 'Doe'} == camel_dict_to_snake_dict({'FirstName': 'John', 'LastName': 'Doe'})
    assert {'first_name': 'John', 'last_name': {'doe': 'John', 'john': 'Doe'}} == camel_dict_to_snake_dict({'FirstName': 'John', 'LastName': {'Doe': 'John', 'John': 'Doe'}})

# Generated at 2022-06-24 20:29:21.435100
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}, False) == {}
    assert camel_dict_to_snake_dict({}, True) == {}
    assert camel_dict_to_snake_dict({'aQ8vdDzj': 'oEfGV'}, False) == {'a_q8vd_dzj': 'o_e_f_g_v'}
    assert camel_dict_to_snake_dict({'aQ8vdDzj': 'oEfGV'}, True) == {'a_q8vd_dzj': 'o_e_f_g_v'}

# Generated at 2022-06-24 20:29:32.410895
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': dict(
            Id='ep-tpoo0soghw0hxgx6',
            Path='/export',
            FunctionName='arn:aws:lambda:eu-west-1:210467932988:function:api-environment-MyApi-1IWX1XQ2QZJF7:$LATEST',
            Method= 'GET',
            AuthorizationType='NONE',
            AuthorizerId= None
        ),
        'TargetGroupArn': 'arn:aws:elasticloadbalancing:eu-west-1:210467932988:targetgroup/api-environment-MyApi-186PR4W4NQ1MZ/bb60f7b57dda27f6'
    }

# Generated at 2022-06-24 20:29:39.163732
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_0 = {
        'Key': 'value',
        'nestedDict': {
            'foo': 'bar'
        },
        'nestedList': [
            {'foo': 'bar'},
            {'foo': 'bar'},
            {'foo': 'bar'},
            {'foo': 'bar'}
        ],
        'HTTPEndpoint': 'foo',
        'Tags': {
            'tagkey': 'tagvalue'
        }
    }

# Generated at 2022-06-24 20:29:40.155050
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True == True



# Generated at 2022-06-24 20:29:46.829990
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Given.
    camel_dict = {
        "HTTPEndpoint": {
            "Name": "foo",
            "Host": "http://www.example.com",
            "Method": "POST",
            "Path": "/path",
            "AuthType": "AWS_IAM",
            "Protocol": "HTTPS",
            "Url": "https://firehose.us-west-1.amazonaws.com/endpoints/foo"
        }
    }

    # When.
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)

    # Then.
    assert snake_dict["h_t_t_p_endpoint"]["name"] == "foo"

# Generated at 2022-06-24 20:29:50.763298
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        # Testing with expected input
        camel_dict = {
                        "AccessToken": "faketoken",
                        }
        assert camel_dict_to_snake_dict(camel_dict) == {"access_token": "faketoken"}

    except:
        raise AssertionError('Test camel_dict_to_snake_dict failed')


# Generated at 2022-06-24 20:29:56.850273
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_0 = {'A': 'B', 'C': ['D', 'E'], 'F': {'G': 'H', 'I': 'J'}, 'K': {'L': 'M', 'N': 'O'}}
    expected_0 = {'a': 'B', 'c': ['D', 'E'], 'f': {'g': 'H', 'i': 'J'}, 'k': {'l': 'M', 'n': 'O'}}
    actual_0 = camel_dict_to_snake_dict(input_0)
    assert actual_0 == expected_0



# Generated at 2022-06-24 20:30:05.694812
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'HTTP endpoint'}) == {'http_endpoint': 'HTTP endpoint'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'HTTP endpoint'}, reversible=True) == {'h_t_t_p_endpoint': 'HTTP endpoint'}
    assert camel_dict_to_snake_dict({'http_endpoint': 'HTTP endpoint'}, reversible=True) == {'http_endpoint': 'HTTP endpoint'}
    assert camel_dict_to_snake_dict({'httpEndpoint': 'HTTP endpoint'}, reversible=True) == {'http_endpoint': 'HTTP endpoint'}





# Generated at 2022-06-24 20:30:15.839724
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    given = {
        'Action': 'DescribeInstances',
        'Filter': [
            {'Name': 'tag-key', 'Value.1': 'Name'},
            {'Name': 'tag-value', 'Value.1': 'MyServer'},
        ],
    }
    expected = {
        'action': 'DescribeInstances',
        'filter': [
            {'name': 'tag-key', 'value.1': 'Name'},
            {'name': 'tag-value', 'value.1': 'MyServer'},
        ],
    }
    actual = camel_dict_to_snake_dict(given)

    assert expected == actual, 'camel_dict_to_snake_dict() does not return an expected result'



# Generated at 2022-06-24 20:30:25.916003
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.aws.core import AnsibleAWSModule
    from ansible.modules.cloud.amazon import cdk_stack
    import os

    test_module = AnsibleAWSModule(
        argument_spec={},
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[],
    )
    test_module._ansible_debug = True
    test_module.params = {
        'StackName': 'aws-s3-encryption',
        'TemplateFile': 'my_stack_template.yaml',
        'StackPolicy': 'my_stack_policy.yaml',
        'Tags': {
            'Foo': 'Bar',
            'Bar': 'Baz',
        },
    }


# Generated at 2022-06-24 20:30:32.016715
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:42.402837
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_input = {'ListBuckets': {'Buckets': {'CanonicalUser': 'fbid:1234', 'Email': 'joe@example.com',
                                              'ID': 'minioadmin', 'DisplayName': 'minio'}}}
    test_result = {'list_buckets': {'buckets': {'canonical_user': 'fbid:1234', 'email': 'joe@example.com',
                                                'id': 'minioadmin', 'display_name': 'minio'}}}

    result = camel_dict_to_snake_dict(test_input)
    assert (result == test_result)


# Generated at 2022-06-24 20:30:49.179078
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:57.314516
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dictionary = {
        "UserName": "John",
        "Friends": [
            {
                "FirstName": "Joe"
            },
            {
                "FirstName": "Jane"
            }
        ]
    }
    expected_outout = {
        "user_name": "John",
        "friends": [
            {
                "first_name": "Joe"
            },
            {
                "first_name": "Jane"
            }
        ]
    }

    output = camel_dict_to_snake_dict(dictionary)

    assert expected_outout == output



# Generated at 2022-06-24 20:31:02.428873
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'a': 'b'}) == {'a': 'b'}
    assert camel_dict_to_snake_dict({'aA': 'b'}) == {'a_a': 'b'}
    assert camel_dict_to_snake_dict({'aA': 'b'}, True) == {'a_a': 'b'}
    assert camel_dict_to_snake_dict({'aA': 'b'}, False) == {'a_a': 'b'}
    assert camel_dict_to_snake_dict({'aA': 'b'}) == {'a_a': 'b'}

# Generated at 2022-06-24 20:31:07.153277
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    log_0 = 'h'
    str_0 = {'HttpVerb': 'h', 'Path': '/', 'TargetGroupArn': 'T', 'Matcher': {'HttpCode': '200'}}
    var_0 = camel_dict_to_snake_dict(str_0, False, [])

    if (var_0['http_verb'] == log_0):
        return True

# Generated at 2022-06-24 20:31:08.977844
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict("HelloWorld") == "hello_world"


# Generated at 2022-06-24 20:31:18.942524
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'testString': 'test'}) == {'test_string': 'test'}
    assert camel_dict_to_snake_dict({'testString': 'test', 'testDict': {'testInner': 'test'}}) == {'test_string': 'test', 'test_dict': {'test_inner': 'test'}}
    assert camel_dict_to_snake_dict({'testString': 'test', 'testDict': {'testInner': 'test'}, 'testList': [{'testInner2': 'test'}]}) == {'test_string': 'test', 'test_dict': {'test_inner': 'test'}, 'test_list': [{'test_inner2': 'test'}]}
    assert camel_dict_to

# Generated at 2022-06-24 20:31:20.046507
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    pass



# Generated at 2022-06-24 20:31:28.561306
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    func_name = 'camel_dict_to_snake_dict'
    test_count = 6
    test_pass = 0

    # Test #0

# Generated at 2022-06-24 20:31:38.819026
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:41.800329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(str_0, True)
    assert result == True

# Generated at 2022-06-24 20:31:50.470448
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:59.446141
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 0
    pytest.test_case_0()
    str_1 = 'IS59+QB'
    var_1 = snake_dict_to_camel_dict(str_1)
    # Test case 1
    str_2 = 'wz1Y6;1U'
    var_2 = snake_dict_to_camel_dict(str_2)
    # Test case 2
    str_3 = 'x2QX9.VJ'
    var_3 = snake_dict_to_camel_dict(str_3)
    # Test case 3
    str_4 = 'd3qw'
    var_4 = snake_dict_to_camel_dict(str_4)
    # Test case 4
    str_5 = '0rW1'
    var_5 = snake

# Generated at 2022-06-24 20:32:07.784494
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Target case 0
    str_0 = 'IS59+QB'
    var_0 = snake_dict_to_camel_dict(str_0)
    expected_value_0 = "IS59+QB"
    
    # Target case 1
    str_1 = 'h_t_t_p_endpoint'
    var_1 = camel_dict_to_snake_dict(str_1, True)
    expected_value_1 = "h_t_t_p_endpoint"

    # Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:17.088544
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {'Name': {'FileName': 'S3_data', 'Type': 'S3'}, 'SecretString': '{"username": "DBUSER", "password": "DBPASS"}', 'VersionId': 's8sjk2sjkfsj23f', 'ARN': 'arn:aws:secretsmanager:us-east-1:974356470246:secret:rds-db-credentials/cluster-EATFIDJWEA', 'CreatedDate': datetime.datetime(2018, 6, 15, 19, 12, 49, tzinfo=tzlocal()), 'Description': 'RDS database credentials'}

# Generated at 2022-06-24 20:32:23.933082
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    item_0 = {'foo': {'bar': 'baz'}}
    item_1 = {'foo': {'bar': 'baz'}}
    item_2 = {'foo': {'bar': 'baz'}}
    item_3 = {'foo': {'bar': 'baz'}}
    item_4 = {'foo': {'bar': 'baz'}}
    item_5 = {'foo': {'bar': 'baz'}}
    item_6 = {'foo': {'bar': 'baz'}}
    item_7 = {'foo': {'bar': 'baz'}}
    item_8 = {'foo': {'bar': 'baz'}}
    item_9 = {'foo': {'bar': 'baz'}}

# Generated at 2022-06-24 20:32:31.629719
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'IS59+QB'
    var_0 = camel_dict_to_snake_dict(str_0)
    str_1 = 'ZR'
    var_1 = camel_dict_to_snake_dict(str_1)
    assert var_0 == 'IS59+QB'
    assert var_1 == 'ZR'

# Generated at 2022-06-24 20:32:36.642848
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:45.038816
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('TestSSMKey') == 'test_ssm_key'
    assert _camel_to_snake('TestSSMKey', True) == 't_e_s_t_s_s_m_key'
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_ar_ns'
    assert _camel_to_snake('TargetGroupARNs', True) == 'target_group_ar_ns'

# Generated at 2022-06-24 20:32:46.675171
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('foo', 'bar') == 'bar'



# Generated at 2022-06-24 20:32:51.675920
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'z6UTO'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == 'z6_u_t_o'


# Generated at 2022-06-24 20:32:58.031869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'someKey': {
            'anotherSubKey': 'anotherSubValue',
            'yetAnotherSubKey': 'yetAnotherSubValue',
            'subKey': {
                'subSubKey': 'subSubValue',
                'subSubKey2': 'subSubValue2',
                'subSubKey3': {
                    'subSubSubKey1': 'subSubSubValue1'
                },
            },
        },
        'someKey2': {
            'subKey2': 'subValue2',
            'subKey3': 'subValue3',
        }
    }

# Generated at 2022-06-24 20:33:01.139204
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'IS59+QB'
    var_0 = camel_dict_to_snake_dict(str_0, False, ())



# Generated at 2022-06-24 20:33:11.180239
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    res = camel_dict_to_snake_dict({'HTTPServer': {'HTTPPort': 1337, 'HTTPEnabled': True, 'Endpoints': [{'HTTPListenOn': '127.0.0.1', 'HTTPAddress': '127.0.0.1', 'HTTPPort': 8080}], 'HTTPEndpoint': {'HTTPListenOn': '127.0.0.1', 'HTTPAddress': '127.0.0.1', 'HTTPPort': 8080}}, 'HTTPEnabled': True, 'HTTPPort': 1337})
    assert res.keys() == set(['h_t_t_p_server', 'h_t_t_p_enabled', 'h_t_t_p_port'])

# Generated at 2022-06-24 20:33:21.840628
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    str_0 = 'IS59+QB'
    var_0 = str_0
    var_1 = '_IS59+QB'
    var_2 = '_IS59+QB'
    var_3 = '_IS59+QB'

    var_0 = camel_dict_to_snake_dict(str_0)
    var_1 = camel_dict_to_snake_dict(str_0, reversible=True)
    var_2 = camel_dict_to_snake_dict(str_0, ignore_list=['somekey'])
    var_3 = camel_dict_to_snake_dict(str_0, reversible=True, ignore_list=['somekey'])

    str_1 = 'IS59+QB'
    str_2 = 'IS59+QB'

# Generated at 2022-06-24 20:33:33.838196
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    v_0 = {'aLongCamelString': ['A', 'B', 'A'], 'anotherOne': {'one': 'two'}, 'thisIsATest': 'one', 'AWS': 'two', 'anotherThing': 'yes'}
    v_1 = {'a_long_camel_string': ['A', 'B', 'A'], 'another_one': {'one': 'two'}, 'this_is_a_test': 'one', 'a_w_s': 'two', 'another_thing': 'yes'}
    var_0 = camel_dict_to_snake_dict(v_0)
    assert var_0 == v_1

# Generated at 2022-06-24 20:33:48.233363
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:54.425795
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:03.647629
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'testKey1': 'testValue1', 'testKey2': 'testValue2'}) == {'test_key1': 'testValue1', 'test_key2': 'testValue2'}, 'Test with simple dictionary'
    assert camel_dict_to_snake_dict({'testKey1': {'testKey2': 'testValue2'}}) == {'test_key1': {'test_key2': 'testValue2'}}, 'Test with nested dictionary'
    assert camel_dict_to_snake_dict({'testKey1': {'testKey2': {'testKey3': 'testValue3'}}}) == {'test_key1': {'test_key2': {'test_key3': 'testValue3'}}}, 'Test with deeply nested dictionary'

# Generated at 2022-06-24 20:34:05.071114
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert callable(camel_dict_to_snake_dict)



# Generated at 2022-06-24 20:34:13.330996
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test 0
    test_case_0()
    # Test 1
    str_0 = 'sjDqLN'
    var_0 = snake_dict_to_camel_dict(str_0)
    # Test 2
    str_0 = 'QUt9mj'
    var_0 = snake_dict_to_camel_dict(str_0)
    # Test 3
    str_0 = 'LktmDv'
    var_0 = snake_dict_to_camel_dict(str_0)
    # Test 4
    str_0 = 'z6D7hK'
    var_0 = snake_dict_to_camel_dict(str_0)
    # Test 5
    str_0 = '5+5JkM'
    var_0 = snake_dict_

# Generated at 2022-06-24 20:34:25.911568
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        'Name': 'a',
        'ARN': 'b',
        'Tags': [
            {'Key': 'c', 'Value': 'd'}
        ]
    }, True) == {
        'name': 'a',
        'a_r_n': 'b',
        'tags': [
            {'key': 'c', 'value': 'd'}
        ]
    }, 'Case 1.1.1 failed.'


# Generated at 2022-06-24 20:34:31.653474
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict()
    assert result == "IS59+QB"


if __name__ == "__main__":
    # test_case_0()
    test_camel_dict_to_snake_dict()

# Generated at 2022-06-24 20:34:41.271468
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        assert 'http_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': {}})
        assert 'http_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPENDPOINTTEST': 'test'}})
        assert 'http_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpoint': 'test'}})
        assert 'h_t_t_p_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpoint': 'test'}}, reversible=True)
    except AssertionError:
        raise AssertionError("Test Failed.  Unexpected output in camel_dict_to_snake_dict")


# Generated at 2022-06-24 20:34:43.356005
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'Endpoint'}) == {'h_t_t_p_endpoint': 'Endpoint'}



# Generated at 2022-06-24 20:34:51.422238
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sample_1 = dict()
    sample_1['Foo'] = 'foo'
    sample_1['Bar'] = 'bar'
    dictionary = camel_dict_to_snake_dict(sample_1)
    assert dictionary['foo'] == 'foo'
    assert dictionary['bar'] == 'bar'
