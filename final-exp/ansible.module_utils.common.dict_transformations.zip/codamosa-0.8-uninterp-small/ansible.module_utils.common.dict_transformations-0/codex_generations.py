

# Generated at 2022-06-24 20:25:39.737922
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = dict((k, v) for (k, v) in dict1.items() if k not in dict2)
    right = dict((k, v) for (k, v) in dict2.items() if k not in dict1)
    for k in (set(dict1.keys()) & set(dict2.keys())):
        if isinstance(dict1[k], dict) and isinstance(dict2[k], dict):
            result = recursive_diff(dict1[k], dict2[k])
            if result:
                left[k] = result[0]
                right[k] = result[1]
        elif dict1[k] != dict2[k]:
            left[k] = dict1[k]
            right[k] = dict2[k]
    if left or right:
        return left

# Generated at 2022-06-24 20:25:43.656595
# Unit test for function dict_merge
def test_dict_merge():

    dict1 = {'a': {'b': {'c': 1}}}
    dict2 = {'a': {'b': {'c': 2, 'd': 2}}}
    merged = dict_merge(dict1, dict2)
    if (merged['a']['b']['c'] == 2) and (merged['a']['b']['d'] == 2):
        print("True")
    else:
        print("False")


# Generated at 2022-06-24 20:25:51.952217
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(A=1, B=dict(C=2, D=3, E=4))
    dict2 = dict(A=5, B=dict(C=6, G=7), H=8)
    dict3 = dict_merge(dict1, dict2)
    assert dict3['A'] == 5
    assert dict3['B']['G'] == 7
    assert dict3['H'] == 8

    dict1 = dict(B=dict(C=2, D=3, E=4))
    dict2 = dict(A=5, B=dict(C=6, G=7), H=8)
    dict3 = dict_merge(dict1, dict2)
    assert dict3['A'] == 5
    assert dict3['B']['G'] == 7

# Generated at 2022-06-24 20:25:58.564499
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    args = {}
    args["camel_dict"] = {}
    args["reversible"] = True
    args["ignore_list"] = [(("test"))]
    verify_result = {}
    verify_result["camel_dict"] = {}
    verify_result["reversible"] = True
    verify_result["ignore_list"] = [(("test"))]
    expected_result = {}
    expected_result["camel_dict"] = {}
    expected_result["reversible"] = True
    expected_result["ignore_list"] = [(("test"))]

    actual_result = camel_dict_to_snake_dict(**args)
    assert actual_result == expected_result


# Generated at 2022-06-24 20:26:06.752485
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Set up test variables
    bool_0 = None
    str_0 = 'True'
    str_1 = 'False'
    dict_0 = {'Testing': {'True': str_0, 'False': str_1}}
    dict_1 = {'Testing': {'True': str_0, 'False': str_1}, 'More': {'True': str_0, 'False': str_1}}
    dict_2 = {'Testing': {'True': str_0, 'False': str_1}, 'More': {'True': str_0, 'False': str_1}, 'Overall': dict_1}

# Generated at 2022-06-24 20:26:14.252461
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = {'testKey1': 'testValue1', 'testKey2': 'testValue2'}
    result = camel_dict_to_snake_dict(dict1)
    assert dict1 == result
    dict2 = {'testKey1': 'testValue1', 'testKey2': 'testValue2'}
    result = camel_dict_to_snake_dict(dict2, reversible=True)
    assert dict2 == result
    dict3 = {'testKey1': 'testValue1', 'testKey2': 'testValue2', 'TestKey3': 'testValue3'}
    result = camel_dict_to_snake_dict(dict3, reversible=True)
    assert dict3 == result

# Generated at 2022-06-24 20:26:16.988694
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'key1': 'value1'}
    dict2 = {'key2': 'value2'}
    dict_merge(dict1, dict2)


# Generated at 2022-06-24 20:26:26.796380
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_a = {'foo': 'bar',
              'a': 'b',
              'c': {'d': {'e': 'f', 'g': 'h'},
                    'i': 'j'},
              'k': {'l': {'m': 'n', 'o': 'p'},
                    'q': [{'r': 's'}, {'t': {'u': 'v', 'w': 'x'}}],
                    'y': 'z'}}

# Generated at 2022-06-24 20:26:32.536619
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(dict1={}, dict2={}) is None

    assert recursive_diff(dict1={'one': 1, 'two': 2, 'three': {'four': 4, 'five': 5}},
                          dict2={'one': 1, 'two': 2, 'three': {'four': 4, 'five': 6}}) == \
           ({'three': {'five': 5}}, {'three': {'five': 6}})



# Generated at 2022-06-24 20:26:42.086802
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test a simple set of dictionaries
    assert recursive_diff({'foo': 'bar'}, {'foo': 'baz'}) == ({'foo': 'bar'}, {'foo': 'baz'})
    assert recursive_diff({'foo': 'bar'}, {'foo': 'bar'}) is None

    # Test non-dictionary inputs
    try:
        recursive_diff(['foo'], {'foo': 'bar'})
    except TypeError:
        pass
    else:
        assert False

    # Test nested dictionaries
    assert recursive_diff({'foo': {'bar': 'baz'}}, {'foo': {'bar': 'baz'}}) is None

# Generated at 2022-06-24 20:26:54.990611
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:26:56.407777
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test case 0
    test_case_0()



# Generated at 2022-06-24 20:27:04.769982
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint':{'Test':'Foo'}}, False, ['Tags']) == {'h_t_t_p_endpoint': {'Test': 'Foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint':{'Test':'Foo'}}, True, ['Tags']) == {'h_t_t_p_endpoint': {'Test': 'Foo'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint':{'Test':'Foo'}}, False) == {'http_endpoint': {'Test': 'Foo'}}

# Generated at 2022-06-24 20:27:13.439575
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:23.702808
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:34.762661
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = None
    var_0 = camel_dict_to_snake_dict(bool_0)
    assert var_0 == None

    bool_0 = {
        'AWSTemplateFormatVersion': None,
        'Description': None
    }
    var_0 = camel_dict_to_snake_dict(bool_0)
    assert var_0 == {
        'a_w_s_template_format_version': None,
        'description': None
    }

    bool_0 = {
        'AWSTemplateFormatVersion': None,
        'Description': None,
        'Parameters': None
    }
    var_0 = camel_dict_to_snake_dict(bool_0)

# Generated at 2022-06-24 20:27:38.309059
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    if False is False:
        test_camel_dict_to_snake_dict_0()
        test_camel_dict_to_snake_dict_1()
        test_camel_dict_to_snake_dict_2()
        # testing Test_final()
        print('Function(s) passed all tests.')


# Generated at 2022-06-24 20:27:46.694049
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:53.262605
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_list_0 = [{'FooBar': '1', 'Baz': '2'}, {'abc': '3', 'def': '4'}]
    test_dict_0 = {'foo': 'bar', 'baz': 'qux'}
    result = camel_dict_to_snake_dict(test_list_0)
    assert result == {'foo_bar': '1', 'baz': '2'}
    result = camel_dict_to_snake_dict(test_dict_0)
    assert result == test_dict_0


# Generated at 2022-06-24 20:27:59.268944
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = camel_dict_to_snake_dict({'TestString': 'hello'})
    bool_1 = camel_dict_to_snake_dict({'TestString': 'hello'})
    bool_2 = camel_dict_to_snake_dict({'TestString': 'hello'})
    assert bool_0 == {'test_string': 'hello'}, 'test_case_0 failed'
    assert bool_1 == {'test_string': 'hello'}, 'test_case_1 failed'
    assert bool_2 == {'test_string': 'hello'}, 'test_case_2 failed'


# Generated at 2022-06-24 20:28:16.190033
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_ar_ns'
    assert _camel_to_snake('TargetGroupARNs', True) == 'target_group_a_r_ns'

    assert _snake_to_camel('http_endpoint') == 'httpEndpoint'
    assert _snake_to_camel('http_endpoint', True) == 'HttpEndpoint'
    assert _snake_to_camel('h_t_t_p_endpoint') == 'httpEndpoint'
    assert _snake_to_camel

# Generated at 2022-06-24 20:28:24.344417
# Unit test for function recursive_diff

# Generated at 2022-06-24 20:28:35.436061
# Unit test for function dict_merge
def test_dict_merge():

    def _get_dict_a():
        return {
            "simple_key": "1",
            "dict_key": {
                "simple_key": "2",
                "list_key": ["3", "4", {
                    "simple_key": "5",
                    "dict_key": {
                        "simple_key": "6"
                    }
                }]
            },
            "list_key": ["7", "8", {
                "simple_key": "9",
                "list_key": ["10", "11"],
                "dict_key": {
                    "simple_key": "12",
                    "dict_key": {
                        "simple_key": "13"
                    }
                }
            }]
        }


# Generated at 2022-06-24 20:28:43.007281
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'k1': {'k1_1': 'v'}, 'k2': 'foo'}, {'k1': {'k1_2': 'bar'}, 'k2': 'v'}) == {
        'k1': {'k1_1': 'v', 'k1_2': 'bar'}, 'k2': 'v'}
    assert dict_merge({'k1': {'k1_1': 'v'}, 'k2': 'foo'}, {'k1': 'bar'}) == {
        'k1': {'k1_1': 'v'}, 'k2': 'foo'}

# Generated at 2022-06-24 20:28:52.052685
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'Key3': [
            {
                'Key4': 'value4',
                'key5': 'value5'
            }
        ]
    }

    actual = camel_dict_to_snake_dict(test_dict)
    expected = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': [
            {
                'key4': 'value4',
                'key5': 'value5'
            }
        ]
    }

    assert actual == expected



# Generated at 2022-06-24 20:28:55.385978
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}



# Generated at 2022-06-24 20:29:03.474428
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-24 20:29:12.834758
# Unit test for function recursive_diff
def test_recursive_diff():

    # Example #1: Null object
    dict1 = None
    dict2 = None
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Example #2: Primitive object
    dict1 = 10
    dict2 = 20
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Example #3: Primitive lists
    dict1 = [1, 2]
    dict2 = [1, 2]
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Example #4: Primitive lists
    dict1 = [1, 2]
    dict2 = [1, 3]
    result = recursive_diff(dict1, dict2)
    assert result[0] == [1, 2]

# Generated at 2022-06-24 20:29:19.127507
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': {'f': 1, 'g': 2}}, 'f': 3}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': {'f': 2, 'g': 2}}, 'd': 3}
    assert recursive_diff(dict1, dict2) == ({'c': {'e': {'f': 1}}}, {'c': {'e': {'f': 2}}, 'd': 3})

# Generated at 2022-06-24 20:29:20.612947
# Unit test for function dict_merge
def test_dict_merge():

    bool_0 = { 'Name': 'test'}
    if not bool_0:
        return False



# Generated at 2022-06-24 20:29:31.379113
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 'test',
        'b': 2,
        'c': None,
        'd': {
            'e': {
                'f': 'test2',
                'g': 2
            }
        }
    }
    dict2 = {
        'a': 'test3',
        'b': 3,
        'd': {
            'e': {
                'f': 'test2',
                'g': 1
            }
        }
    }
    dict_result = {
        'a': ('test', 'test3'),
        'b': (2, 3),
        'c': (None, None),
        'd': {
            'e': {
                'g': (2, 1)
            }
        }
    }

# Generated at 2022-06-24 20:29:42.199515
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "Key1": 1,
        "Key2": 2,
        "Key3": {
            "SubKey1": 11,
            "SubKey2": 12,
            "SubKey3": 23
        }
    }

    dict2 = {
        "Key1": 1,
        "Key2": 2,
        "Key3": {
            "SubKey1": 11
        }
    }

    expected_result = ({
        "Key3": {
            "SubKey2": 12,
            "SubKey3": 23
        }
    }, {
        "Key3": {
            "SubKey2": None,
            "SubKey3": None
        }
    })

    actual_result = recursive_diff(dict1, dict2)

    assert expected_result == actual_result

# Generated at 2022-06-24 20:29:44.328591
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"fooBar": None}) == {"foo_bar": None}


# Generated at 2022-06-24 20:29:52.135412
# Unit test for function recursive_diff
def test_recursive_diff():
    result = {}
    assert recursive_diff({"key1": "val1", "key2": "val2", "key3": "val3"},
                          {"key1": "val1", "key2": "val2", "key3": "val3"}) == result
    result = {"key1": "val1", "key2": "val2"}
    assert recursive_diff({"key1": "val1", "key2": "val2", "key3": "val3"},
                          {"key1": "val2", "key2": "val1", "key3": "val3"}) == result
    result = {"key1": "val1", "key2": "val2", "key3": {"key4": "val4", "key5": "val5"}}

# Generated at 2022-06-24 20:29:58.645912
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({"foo_bar": "baz"}) == {"FooBar": "baz"}
    assert snake_dict_to_camel_dict({"foo_bar": "baz"}, capitalize_first=True) == {"FooBar": "baz"}
    assert snake_dict_to_camel_dict({"foo_bar": "baz"}, capitalize_first=False) == {"fooBar": "baz"}
    assert snake_dict_to_camel_dict([{"foo_bar": "baz"}, {"foo_bar": "baz"}], capitalize_first=False) == [{"fooBar": "baz"}, {"fooBar": "baz"}]



# Generated at 2022-06-24 20:30:04.398682
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': 'b'}, {}) == {'a': 'b'}
    assert dict_merge({}, {'a': 'b'}) == {'a': 'b'}
    assert dict_merge({'a': 'b'}, {'a': 'c'}) == {'a': 'c'}
    assert dict_merge({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert dict_merge({'a': {'c': 'b'}}, {'a': {'d': 'e'}}) == {'a': {'c': 'b', 'd': 'e'}}

# Generated at 2022-06-24 20:30:11.675156
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    for key in camel_dict_to_snake_dict({"VpcId": 'test', "VPCID": 'test', "VpcCidrBlock": 'test', "SubnetId": 'test', "Tags": 'test', "Httpendpoint": 'test', "HttpEndpoint": 'test', "HTTPEndpoint": 'test'}):
        print(key)


# Generated at 2022-06-24 20:30:20.145584
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():

    bool_0 = {'attr_0': 'value_0'}
    var_0 = snake_dict_to_camel_dict(bool_0)
    assert var_0 == {'attr0': 'value_0'}

    bool_1 = {'attr_0': {'attr_0': 'value_0'}, 'attr_1': {'attr_1': 'value_1'}}
    var_1 = snake_dict_to_camel_dict(bool_1)
    assert var_1 == {'attr0': {'attr0': 'value_0'}, 'attr1': {'attr1': 'value_1'}}


# Generated at 2022-06-24 20:30:28.684271
# Unit test for function dict_merge
def test_dict_merge():
    # simple merge of two dictionaries
    d1 = {'a': 1}
    d2 = {'b': 2}
    d3 = dict_merge(d1, d2)
    print (d3)
    assert d3 == {'a': 1, 'b': 2}
    # no elements in d1, or d2
    d1 = {}
    d2 = {}
    d3 = dict_merge(d1, d2)
    assert d3 == {}
    # no elements in d2, but some in d1
    d1 = {'a': 1}
    d2 = {}
    d3 = dict_merge(d1, d2)
    assert d3 == {'a': 1}
    # no elements in d1, but some in d2
    d1 = {}
    d

# Generated at 2022-06-24 20:30:39.769542
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-24 20:30:46.624657
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(bool_0) == None

# Generated at 2022-06-24 20:30:48.786600
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict(bool_0) == None
    assert snake_dict_to_camel_dict(var_0) == None


# Generated at 2022-06-24 20:30:51.150789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    with pytest.raises(TypeError):
        camel_dict_to_snake_dict('a')


# Generated at 2022-06-24 20:30:58.012423
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a':1, 'b':'ab', 'c':'abc', 'd':{'e':'mi', 'f':'me'}}
    dict2 = {'a':1, 'b':'ab', 'c':'stu', 'd':{'e':'mi', 'f':'me'}}
    out = ({'c': 'abc'}, {'c': 'stu'})
    assert(recursive_diff(dict1, dict2) == out)



# Generated at 2022-06-24 20:31:06.833616
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test input types
    # Passing 'dict':
    expected_result = {
        'Key1': 'Value1',
        'Key2': {
            'Key3': 'Value3',
            'Key4': {
                'Key5': 'Value5'
            }
        }
    }
    assert snake_dict_to_camel_dict({
        'key1': 'Value1',
        'key2': {
            'key3': 'Value3',
            'key4': {
                'key5': 'Value5'
            }
        }
    }) == expected_result
    # Passing 'None':
    test_none = str(None)
    expected_result = None
    assert snake_dict_to_camel_dict(test_none) == expected_result



# Generated at 2022-06-24 20:31:16.430925
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    empty_dict = {}
    var_0 = snake_dict_to_camel_dict(empty_dict)
    empty_list = []
    var_1 = snake_dict_to_camel_dict(empty_list)
    test_dict = {u'my_key': u'my_value'}
    var_2 = snake_dict_to_camel_dict(test_dict)
    test_dict = {u'my_key': u'my_value', u'myKey': u'myValue'}
    var_3 = snake_dict_to_camel_dict(test_dict)
    test_dict = {u'my_key': {u'my_nested_key': u'my_nested_value'}}

# Generated at 2022-06-24 20:31:27.773820
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    camel_0 = {
        "externalFrameworks": [
            {
                "name": "FwtTest",
                "version": "1.0.0"
            }
        ],
        "httpEndpoint": "/",
        "input": "",
        "memorySize": 256,
        "name": "arn:aws:lambda:us-east-1:123456789012:function:my-function",
        "registeredWithInternalRuntime": False,
        "runtime": "nodejs12.x",
        "tags": {
            "Initial-Tag": "testing",
            "Tag2": "second"
        },
        "timeout": 3
    }


# Generated at 2022-06-24 20:31:35.553978
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    answer = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }

    assert dict_merge(a,b) == answer


# Generated at 2022-06-24 20:31:40.815872
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'b': 1}, {'a': 2}) == {'b': 1, 'a': 2}
    assert dict_merge({'a': {'a1': 1}}, {'a': {'a2': 2}}) == {'a': {'a1': 1, 'a2': 2}}
    assert dict_merge({}, {'a': 2}) == {'a': 2}
    assert dict_merge({}, {}) == {}
    assert dict_merge({'a': {'a1':{}}}, {'a': {'a2': 2}}) == {'a': {'a1':{}, 'a2': 2}}


# Generated at 2022-06-24 20:31:48.688782
# Unit test for function recursive_diff
def test_recursive_diff():
    # Setup
    dict1 = {'a': {'b': 1, 'c': 2, 'e': 4, 'f': 5}, 'g': 7}
    dict2 = {'a': {'b': 1, 'c': 3, 'd': 5}, 'e': 8, 'f': 5}

    # Exercise
    actual_left, actual_right = recursive_diff(dict1, dict2)

    # Verify
    expected_left = {'a': {'c': 2}, 'g': 7}
    expected_right = {'a': {'c': 3, 'd': 5}, 'e': 8}
    assert actual_left == expected_left and actual_right == expected_right



# Generated at 2022-06-24 20:32:04.241942
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'a': 2, 'b': {'x': 1}}, {'b': {'y': 2}, 'c': 3}) == {'a': 2, 'b': {'x': 1, 'y': 2}, 'c': 3}


# Generated at 2022-06-24 20:32:14.726116
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "word": "Example",
        "names": [
            "Bob",
            "Tom"
        ]
    }

    dict2 = {
        "word": "Example",
        "names": [
            "Bob",
            "Tom"
        ]
    }

    dict3 = {
        "word": "Example",
        "names": [
            "Bob",
            "Sam"
        ]
    }

    dict4 = {
        "word": "Example",
        "names": [
            "Bob",
            "Sam"
        ]
    }

    dict5 = {
        "word": {
            "neat": "Example"
        },
        "names": [
            "Bob",
            "Tom"
        ]
    }


# Generated at 2022-06-24 20:32:23.998768
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert 'ansible' == _camel_to_snake('ansible')
    assert 'ansible' == _camel_to_snake('Ansible')

    assert 'ansible' == _camel_to_snake('ansible', reversible=True)
    assert 'a_nsible' == _camel_to_snake('Ansible', reversible=True)

    assert 'ansi_ble' == _camel_to_snake('AnsiBle')
    assert 'ansi_ble' == _camel_to_snake('AnsiBle', reversible=True)

    assert 'ansible' == _snake_to_camel('ansible')
    assert 'ansible' == _snake_to_camel('ansible', capitalize_first=True)
    assert 'Ansible' == _snake

# Generated at 2022-06-24 20:32:33.665403
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    dict = [{'vpc_id': 'vpc-12345678', 'tags': {'Name': 'test_tag'}, 'ip_address': '172.11.34.56', 'subnet_id': 'subnet-87654321', 'private_ip_address': '172.11.34.57'}]
    dict_copy = dict.copy()
    dict[0]['name'] = 'test_inst'
    dict[0]['tags']['name'] = 'test_inst'
    dict_reversed = camel_dict_to_snake_dict(dict[0])
    dict_reversed_back = snake_dict_to_camel_dict(dict_reversed)

# Generated at 2022-06-24 20:32:41.302856
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_case_dict = {'HTTPEndpoint': {'Enabled': True}}

    expected_result = {'h_t_t_p_endpoint': {'enabled': True}}
    actual_result = camel_dict_to_snake_dict(camel_case_dict)

    assert actual_result == expected_result, \
        "Camel case dict did not match expected snake case dict result"



# Generated at 2022-06-24 20:32:51.787061
# Unit test for function dict_merge
def test_dict_merge():
    assert {} == dict_merge(dict(), dict())
    assert {'a': 1, 'b': 2, 'c': 3} == dict_merge({'a': 1, 'b': 2}, {'b': 1, 'c': 3})
    assert {'a': 1, 'b': 2} == dict_merge({'a': 1, 'b': 2}, {})
    assert {'a': 1, 'c': 2} == dict_merge({}, {'a': 1, 'c': 2})

    # Test that the merge happens recursively
    assert {'a': 1, 'b': {'c': 2, 'd': 3}} == dict_merge({'a': 1, 'b': {'c': 2}}, {'b': {'d': 3}})

    # Test that the merge does not change

# Generated at 2022-06-24 20:33:04.606606
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(
        {'a': 'b'},
        {'a': 'b'}) is None

    assert recursive_diff(
        {'a': 'b'},
        {'a': 'a'}) == ({'a': 'b'}, {'a': 'a'})

    assert recursive_diff(
        {'a': 'b'},
        {'c': 'b'}) == ({'a': 'b'}, {'c': 'b'})

    assert recursive_diff(
        {'a': 'b'},
        {'a': 'b', 'c': 'a'}) == (None, {'c': 'a'})


# Generated at 2022-06-24 20:33:11.619265
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar': True}) == {'fooBar': True}
    assert snake_dict_to_camel_dict({'foo_bar': {'baz_qux': True}}) == {'fooBar': {'bazQux': True}}
    assert snake_dict_to_camel_dict({'foo_bar': [{'baz_qux': True}]}) == {'fooBar': [{'bazQux': True}]}
    assert snake_dict_to_camel_dict({'foo_bar_baz_qux': True}, capitalize_first=True) == {'FooBarBazQux': True}

# Generated at 2022-06-24 20:33:19.735893
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(val='a', d=dict(val='x'))
    dict2 = dict(val='b', d=dict(val='y'))
    result = recursive_diff(dict1, dict2)
    assert result == ({'val': 'a'}, {'val': 'b'})

    dict1 = dict(val='a', d=dict(val='x'))
    dict2 = dict(val='a', d=dict(val='x'))
    result = recursive_diff(dict1, dict2)
    assert result == (None, None)



# Generated at 2022-06-24 20:33:24.433871
# Unit test for function recursive_diff
def test_recursive_diff():
    data = dict(action='create', resource=dict(
        endpoint=dict(
            domain_name='example.com',
            type='EDGE',
            authorization_type='NONE',
        ),
        order=list(
            dict(value=5.5, name='item1', quantity=2),
        ),
        owner=dict(name='John', surname='Doe'),
        tags=dict(
            Name='Service',
            Environment='Production',
        ),
    ))

    assert recursive_diff(data, data) == None
    assert recursive_diff(data, {}) == ({'resource': data['resource']}, {})
    assert recursive_diff({}, data) == ({}, {'resource': data['resource']})