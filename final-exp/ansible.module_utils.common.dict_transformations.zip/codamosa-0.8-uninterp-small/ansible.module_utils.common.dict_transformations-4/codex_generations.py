

# Generated at 2022-06-24 20:25:28.290158
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    initial_dict_0 = {
        "AccountId": "string",
        "GroupId": "string"
    }
    expected_result_0 = {
        "account_id": "string",
        "group_id": "string"
    }
    result_0 = camel_dict_to_snake_dict(initial_dict_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-24 20:25:31.412424
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'hello_world' == _camel_to_snake('HelloWorld')


# Generated at 2022-06-24 20:25:40.546166
# Unit test for function recursive_diff
def test_recursive_diff():
    # If the argument provided to the recursive_diff function is not of type dict, a TypeError should be raised.
    with pytest.raises(TypeError) as e_info:
        recursive_diff(False, False)

    # If the arguments provided to the recursive_diff function is of type dict, but they are not equal, a tuple
    # of the missing items should be returned.
    dict_1 = {"key1": "value1"}
    dict_2 = {"key2": "value2"}
    assert recursive_diff(dict_1, dict_2) == ({"key1": "value1"}, {"key2": "value2"})

    # If the arguments provided to the recursive_diff function is of type dict, and they are equal, None should
    # be returned.
    dict_1 = {"key1": "value1"}
    dict

# Generated at 2022-06-24 20:25:46.177674
# Unit test for function recursive_diff
def test_recursive_diff():
    var_0 = {}
    var_1 = {}
    var_2 = recursive_diff(var_0, var_1)
    assert(var_2 is None)
    var_3 = {}
    var_4 = {"key": "value"}
    var_5 = recursive_diff(var_3, var_4)
    assert(var_5 == ({"key": "value"}, {}))
    var_6 = {}
    var_7 = {"key": {"key": "value"}}
    var_8 = recursive_diff(var_6, var_7)
    assert(var_8 == ({"key": {"key": "value"}}, {}))
    var_9 = {"key": "value", "key_2": "value_2"}
    var_10 = {"key": {"key": "value"}}
    var_

# Generated at 2022-06-24 20:25:56.639428
# Unit test for function recursive_diff
def test_recursive_diff():

    with pytest.raises(TypeError) as err:
        test_case_0()
    assert err.match("Unable to diff 'dict1' 'bool' and 'dict2' 'bool'")
    assert 'arguments must be dicts' in str(err.value)

    dict_0 = {
        'key_0': {
            'key_0': 'var_0',
            'key_1': 'var_1'
        },
        'key_1': 'var_1'
    }
    dict_1 = {
        'key_0': {
            'key_0': 'var_0',
            'key_2': 'var_2'
        },
        'key_1': 'var_1'
    }
    diff_0 = recursive_diff(dict_0, dict_1)

# Generated at 2022-06-24 20:26:05.502853
# Unit test for function dict_merge
def test_dict_merge():
    # Bool test
    dict1_0 = {"instance_type": "t2.micro", "image_id": "ami-0947d2ba12ee1ff75", "tags": {"Name": "Ansible_Tester1"}}
    dict2_0 = None
    dict3_0 = {"instance_type": "t2.micro", "image_id": "ami-0947d2ba12ee1ff75", "tags": {"Name": "Ansible_Tester1"}}
    dict_diff_0 = dict_merge(dict1_0, dict2_0)
    assert dict_diff_0 == dict3_0

# Generated at 2022-06-24 20:26:13.456172
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict = {'foo': {'bar': {'baz': 3}}}

    result = recursive_diff(test_dict, test_dict)
    assert result is None

    result = recursive_diff(test_dict, {})
    assert result == ({'foo': {'bar': {'baz': 3}}}, {})

    result = recursive_diff({}, test_dict)
    assert result == ({}, {'foo': {'bar': {'baz': 3}}})

    result = recursive_diff({'foo': {'bar': {'qux': 3}}}, test_dict)
    assert result == ({'foo': {'bar': {'qux': 3}}}, {'foo': {'bar': {'baz': 3}}})


# Generated at 2022-06-24 20:26:21.674065
# Unit test for function dict_merge
def test_dict_merge():
  # Case 0
  bool_0 = True
  bool_1 = True
  var_0 = dict_merge(bool_0, bool_1)
  print('dict_merge(bool_0, bool_1): ', var_0)
  assert type(var_0) == bool
  assert var_0 == True

  # Case 1
  dict_0 = { "val_0": True, "val_1": True, "val_2": True }
  dict_1 = { "val_3": True, "val_4": True, "val_5": True }
  dict_2 = { "val_6": dict_0, "val_7": dict_1 }
  dict_3 = { "val_6": dict_1, "val_7": dict_0 }

# Generated at 2022-06-24 20:26:32.425613
# Unit test for function dict_merge
def test_dict_merge():
    # Test case 1
    # Test data set 1
    dic_0 = {}
    dic_1 = {}
    dic_0['key0'] = dic_1
    dic_0['key1'] = dic_1
    dic_1['key2'] = dic_0
    dic_0['key3'] = dic_1
    dic_0['key4'] = 'string_0'
    dic_0['key5'] = 'string_0'
    dic_0['key6'] = 'string_0'
    dic_1['key7'] = 'string_0'
    dic_1['key8'] = 'string_0'
    dic_1['key9'] = 'string_0'

    # Test data set 2
    dic_2 = {}

# Generated at 2022-06-24 20:26:42.014735
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = {'HTTPEndpoint': {'Address': 'a', 'Description': 'b', 'Name': 'c', 'TargetArn': 'd'},
                    'Port': 8080, 'VpcEndpointId': 'l'}

    snake_dict_1 = camel_dict_to_snake_dict(camel_dict_1)

    assert snake_dict_1['http_endpoint']['address'] == 'a'
    assert snake_dict_1['http_endpoint']['description'] == 'b'
    assert snake_dict_1['http_endpoint']['name'] == 'c'
    assert snake_dict_1['http_endpoint']['target_arn'] == 'd'
    assert snake_dict_1['port'] == 8080

# Generated at 2022-06-24 20:26:56.919986
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test for cased_string_to_lower_case_underscore function
    # Test for string with CamelCase
    camel_str_0 = 'HelloWorld'
    snake_str_0 = 'hello_world'
    assert (_camel_to_snake(camel_str_0) == snake_str_0)

    # Test for string with CamelCase and '_'
    camel_str_1 = 'Hello_World'
    snake_str_1 = 'hello_world'
    assert (_camel_to_snake(camel_str_1) == snake_str_1)

    # Test for string with CamelCase, '_' and numbers
    camel_str_2 = 'Hello_Node39'
    snake_str_2 = 'hello_node39'

# Generated at 2022-06-24 20:27:05.183517
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:13.016502
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = dict(SimpleString='hello world', SimpleInt=1, SimpleBool=True,
             SimpleList=[1, 2, 3, 'a', 'b', 'c'],
             SimpleDict={'a': 1, 'b': 2, 'c': 3})
    y = dict(simple_string='hello world', simple_int=1, simple_bool=True,
             simple_list=[1, 2, 3, 'a', 'b', 'c'],
             simple_dict={'a': 1, 'b': 2, 'c': 3})
    assert camel_dict_to_snake_dict(x) == y
    assert snake_dict_to_camel_dict(y) == x



# Generated at 2022-06-24 20:27:20.450002
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3
        }
    }

    d2 = {
        'a': 'one',
        'b': 'two',
        'c': {
            'd': 'three'
        }
    }

    assert dict_merge(d1, d2) == {
        'a': 'one',
        'b': 'two',
        'c': {
            'd': 'three'
        }
    }

# Generated at 2022-06-24 20:27:24.491494
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_0 = {'HTTPEndpoint': {'Name': 'hi', 'TargetArn': 'arn:a:a:a:a:a:b:b:b:b/hi'}}
    camel_1 = {'HTTPEndpoint': {'Name': 'hi', 'TargetArn': 'arn:a:a:a:a:a:b:b:b:b/hi'}, 'Name': 'hi', 'other': 'no'}
    camel_2 = {'Tags': {'hello': 'world', 'goodbye': 'world', 'a': 1, 'b': None}}

    snake_0 = {'h_t_t_p_endpoint': {'name': 'hi', 'target_arn': 'arn:a:a:a:a:a:b:b:b:b/hi'}}

   

# Generated at 2022-06-24 20:27:35.351532
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("This the test for function camel_dict_to_snake_dict")

# Generated at 2022-06-24 20:27:45.165550
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {'AssumeRolePolicyDocument': {'Version': '2012-10-17', 'Statement': [{'Effect': 'Allow', 'Action': 'sts:AssumeRole', 'Resource': 'arn:aws:iam::012345678912:role/test-role'}]}, 'Path': '/', 'RoleName': 'test-role', 'ManagedPolicyArns': ['arn:aws:iam::aws:policy/AdministratorAccess']}

# Generated at 2022-06-24 20:27:53.801396
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Key1': 'Value1', 'Key2': {'Key3': 'Value3'}}, reversible=False, ignore_list=['tags']) == {'key1': 'Value1', 'key2': {'key3': 'Value3'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com', 'Tags': {'Tag1': 'Value1', 'Tag2': {'Tag3': 'Value3'}}}, reversible=True, ignore_list=['tags']) == {'h_t_t_p_endpoint': 'http://www.example.com', 'tags': {'Tag1': 'Value1', 'Tag2': {'Tag3': 'Value3'}}}
    assert camel_dict_to_snake

# Generated at 2022-06-24 20:28:01.652766
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:06.534472
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # str
    str_0 = 'HelloWorld'
    str_1 = 'HelloWorld'
    str_2 = 'helloWorld'
    str_3 = 'Hello world'
    str_4 = 'Hello-world'
    str_5 = 'Hello_world'

    # list
    list_0 = ['HelloWorld', 'helloWorld', 'Hello world', 'Hello-world', 'Hello_world']
    list_1 = ['HelloWorld', 'helloWorld', 'Hello world', 'Hello-world', 'Hello_world']
    list_2 = ['hello-world', 'hello_world', 'hello world', 'hello-world', 'hello_world']
    list_3 = ['Hello world', 'Hello world', 'Hello world', 'Hello world', 'Hello world']

# Generated at 2022-06-24 20:28:21.170711
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test no camel case
    camel_dict_0 = {
        'abc': 'def'
    }
    snake_dict_0 = {
        'abc': 'def'
    }

    assert(camel_dict_to_snake_dict(camel_dict_0) == snake_dict_0)
    assert(snake_dict_to_camel_dict(snake_dict_0) == camel_dict_0)

    # Test one camel case without reversible=True
    camel_dict_1 = {
        'abcDef': 'def'
    }
    snake_dict_1 = {
        'abc_def': 'def'
    }

    assert(camel_dict_to_snake_dict(camel_dict_1) == snake_dict_1)

# Generated at 2022-06-24 20:28:29.763737
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 1
    # Expected results
    expected_snake_dict = {'hello_world': 'hello_world'}
    # Actual results
    actual_snake_dict = camel_dict_to_snake_dict({'HelloWorld': 'hello_world'})
    # assert statements
    assert expected_snake_dict == actual_snake_dict

    # Test case 2
    # Expected results
    expected_reversible_dict = {'hello_world': {'hello_world': 'hello_world'}}
    # Actual results
    actual_reversible_dict = camel_dict_to_snake_dict({'HelloWorld': {'HelloWorld': 'hello_world'}}, reversible=True)
    # assert statements
    assert expected_reversible_dict == actual_reversible_dict

    # Test case 3

# Generated at 2022-06-24 20:28:40.495625
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {
        'HTTPEndpoint': 'hello', 
        'TargetGroupARNs': ['1', '2', '3'],
        'LoadBalancerNames': ['2', '3', '4'],
        'Names': ['1', '1', '4']
    }

    dict_1 = {
        'HttpEndpoint': 'hello', 
        'TargetGroupARNs': ['1', '2', '3'],
        'LoadBalancerNames': ['2', '3', '4'],
        'Names': ['1', '1', '4']
    }


# Generated at 2022-06-24 20:28:51.775686
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {'hello': 'world', 'HelloWorld': 'goodbye', 'fizz': {'buzz': 'bazz'}}
    assert camel_dict_to_snake_dict(dict_0) == {'hello': 'world', 'hello_world': 'goodbye', 'fizz': {'buzz': 'bazz'}}
    dict_1 = {'hello': 'world', 'HelloWorld': 'goodbye', 'fizz': {'buzz': {'hello': 'world', 'bazz': 'hello'}}}
    assert camel_dict_to_snake_dict(dict_1) == {'hello': 'world', 'hello_world': 'goodbye', 'fizz': {'buzz': {'hello': 'world', 'bazz': 'hello'}}}

# Generated at 2022-06-24 20:29:01.488450
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:11.243604
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'HelloWorld'
    str_1 = _camel_to_snake(str_0)
    print(str_1)

    str_2 = 'ThisIsATest'
    str_3 = _camel_to_snake(str_2)
    print(str_3)

    d_0 = {'HelloWorld': 'ThisIsATest'}
    d_out_0 = camel_dict_to_snake_dict(d_0)
    print(d_out_0)

    d_1 = {'HelloWorld': [1, 2, 3, 4], 'ThisIsATest': 'HelloWorld'}
    d_out_1 = camel_dict_to_snake_dict(d_1)
    print(d_out_1)


# Generated at 2022-06-24 20:29:20.839527
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case for Empty list
    camel_dict_0 = {}
    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)
    # Check that the two dicts are equal
    assert snake_dict_0 == {}

    # Test case for Dictionary with only int
    camel_dict_1 = {
        'x': 1
    }
    snake_dict_1 = camel_dict_to_snake_dict(camel_dict_1)
    # Check that the two dicts are equal
    assert snake_dict_1 == {
        'x': 1
    }

    # Test case for Dictionary with other data types
    camel_dict_2 = {
        'x': 1,
        'y': 3.14,
        'z': 'hello'
    }
    snake_dict

# Generated at 2022-06-24 20:29:25.559976
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Protocol': 'HTTP'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)
    snake_dict_expected = {'h_t_t_p_endpoint': {'protocol': 'HTTP'}}

    assert(snake_dict == snake_dict_expected)


# Generated at 2022-06-24 20:29:36.966756
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test 0
    camel_dict_0 = {
        'name': 'ec2-tag-test-name',
        'requiredTags': {
            'project': 'dev',
            'owner': 'bob',
        },
        'optionalTags': {
            'billingAccount': '111111'
        },
        'resourceTypeFilters': [
            'ec2:instance'
        ]
    }
    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)

# Generated at 2022-06-24 20:29:44.958861
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    This test case shows that for camel_dict_to_snake_dict with 
    a dictionary with a string key and a integer value
    """
    camel_dict = {"test_key_0": 123, "test_key_1": "test_value_1"}
    reversed_dict = {"testKey0": 123, "testKey1": "test_value_1"}

    output = camel_dict_to_snake_dict(camel_dict, True)
    assert output == reversed_dict
    assert output["testKey0"] == 123
    assert output["testKey1"] == "test_value_1"


# Generated at 2022-06-24 20:29:54.946400
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = {
        'Policy': {
            'PolicyName': 'MyPolicy',
            'PolicyDocument': {
                'Statement': [
                    {
                        'Action': 'sts:AssumeRole',
                        'Effect': 'Allow',
                        'Principal': {
                            'Service': [
                                'ec2.amazonaws.com',
                                'lambda.amazonaws.com',
                                'apigateway.amazonaws.com',
                            ]
                        }
                    }
                ]
            }
        }
    }

# Generated at 2022-06-24 20:30:03.699758
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'ThisIsATest': 'HelloWorld',
             'thisIsATest': 'HelloWorld',
             'this': {'is': 'a nested test'},
             'list': [1, 2, 3],
             'listinlist': [1, 2, 3, [4, 5, 6]],
             }

    expected_dict = {
        'hello_world': 'HelloWorld',
        'this_is_a_test': 'HelloWorld',
        'this': {'is': 'a nested test'},
        'list': [1, 2, 3],
        'listinlist': [1, 2, 3, [4, 5, 6]],
    }

    assert camel_dict_to_snake_dict(test_dict) == expected_dict


# Generated at 2022-06-24 20:30:08.285957
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'ApplicationName': 'Helloworld',
                  'Description': 'application_description',
                  'Command': {'Name': 'heroku run'},
                  'Tags': {'key1': 'value1', 'key2': 'value2'},
                  'Procfile': 'web: gunicorn helloworld.wsgi'
                  }
    x = camel_dict_to_snake_dict(camel_dict)
    print(x)


# Generated at 2022-06-24 20:30:13.863375
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:23.419783
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('HelloWorld') == 'hello_world'
    assert _camel_to_snake('HttpRequest') == 'http_request'
    assert _camel_to_snake('FullName', reversible=True) == 'full_name'
    assert _camel_to_snake('HTTPEndpoint', reversible=True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('HTTPServer', reversible=True) == 'h_t_t_p_server'
    assert _camel_to_snake('Id') == 'id'
    assert _camel_to_snake('Id', reversible=True) == 'id'
    assert _camel_to_snake('IdAndName', reversible=True) == 'id_and_name'

# Generated at 2022-06-24 20:30:30.270942
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'DBClusterIdentifier': 'test-db-cluster-identifier',
        'ApplyImmediately': True,
        'Tags': {
            'Tag': [],
            'Tag': []
        },
        'BackupRetentionPeriod': 5,
        'Port': 3306
    }

    expected_dict = {
        'db_cluster_identifier': 'test-db-cluster-identifier',
        'apply_immediately': True,
        'tags': {
            'Tag': [],
            'Tag': []
        },
        'backup_retention_period': 5,
        'port': 3306
    }

    # TODO: create an assertDictEqual function/option for custom diffs
    # assertDictEqual(camel_dict_to_

# Generated at 2022-06-24 20:30:40.862215
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:42.665626
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HelloWorld': 'HelloWorld'}, False) == {'hello_world': 'HelloWorld'}


# Generated at 2022-06-24 20:30:46.432159
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 'HelloWorld'
    str_1 = _camel_to_snake(str_0)
    print(str_1)

    str_2 = 'HelloWorld'
    str_3 = _camel_to_snake(str_2, reversible=True)
    print(str_3)



# Generated at 2022-06-24 20:30:51.139016
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_0 = {'Attribute': 'Varchar', 'Deletable': True, 'Nullable': False}
    camel_dict_1 = {'Attribute': 'Varchar', 'Deletable': True, 'Nullable': False}
    assert camel_dict_to_snake_dict(camel_dict_0) == camel_dict_to_snake_dict(camel_dict_1)


# Generated at 2022-06-24 20:31:06.333834
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'InstanceId': 123,
        'HTTPEndpoint': {
            'URL': 'https://www.example.com'
        },
        'Tags': {
            'Name': 'test1',
            'Owner': 'test2'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {
        'instance_id': 123,
        'h_t_t_p_endpoint': {
            'url': 'https://www.example.com'
        },
        'tags': {
            'Name': 'test1',
            'Owner': 'test2'
        }
    }


# Generated at 2022-06-24 20:31:12.203521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {}
    dict_1 = {}
    dict_0['TestKey0'] = 'TestValue0'
    dict_0['TestKey1'] = 'TestValue1'
    dict_1['test_key0'] = 'TestValue0'
    dict_1['test_key1'] = 'TestValue1'
    assert (camel_dict_to_snake_dict(dict_0) == dict_1)


# Generated at 2022-06-24 20:31:21.092908
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('\nTesting camel_dict_to_snake_dict...')

    test_dict = {'Name': 'MyValue', 'Tags': {'DummyTag': 'DummyValue'}, 'MutuallyExclusive': True}
    test_result = camel_dict_to_snake_dict(test_dict)

    expected_result = {'name': 'MyValue', 'tags': {'DummyTag': 'DummyValue'}, 'mutually_exclusive': True}
    test_passed = test_result == expected_result
    if test_passed:
        print('  PASSED')
    else:
        print(' FAILED')
        print('  Input Dictionary: %s' % test_dict)
        print('  Expected Result: %s' % expected_result)

# Generated at 2022-06-24 20:31:26.983727
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_0 = {
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-target-group/73e2d6bc24d8a067'
        ],
        'Foo': {
            'SomeKey': 'SomeValue',
            'SomeArrayKey': [
                {
                    'AnotherKey': 'AnotherValue'
                }
            ]
        },
        'Bar': [
            {
                'SomeKey': 'SomeValue',
                'SomeArrayKey': [
                    {
                        'AnotherKey': 'AnotherValue'
                    }
                ]
            }
        ]
    }

    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)

    assert snake

# Generated at 2022-06-24 20:31:37.408373
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dromedary_case = {'Str0': 'Foo', 'Str1': 'Bar', 'HTTPEndpoint': {'Str2': 'Zoo', 'Int0': 99},
                      'HTTPEndpointId': 'Id'}
    camel_dict = {'Str0': 'Foo', 'Str1': 'Bar', 'HTTPEndpoint': {'Str2': 'Zoo', 'Int0': 99},
                  'HTTPEndpointId': 'Id'}

    test_dict = {'str_0': 'Foo', 'str_1': 'Bar', 'h_t_t_p_endpoint': {'str_2': 'Zoo', 'int_0': 99},
                 'h_t_t_p_endpoint_id': 'Id'}

# Generated at 2022-06-24 20:31:46.831625
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_1 = 'helloWorld'

    # The string to be tested is 'helloWorld'
    # With the first lowercase following the first uppercase
    # In snake case, the string should be 'hello_world'
    camel_dict = {str_1: 123}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['hello_world'] == 123

    # The string to be tested is 'helloWorld'
    # With the first uppercase, this is a normal snake case
    # So the resutl is 'hello_world'
    camel_dict = {str_1[0].upper() + str_1[1:]: 123}
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-24 20:31:54.560973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict(A='a', B='b', FName='fname', LName='lname')
    dict_1 = dict(a='a', b='b', f_name='fname', l_name='lname')
    dict_2 = dict(h_t_t_p_endpoint='httpendpoint', t_e_s_t_endpoint='testendpoint', t_a_r_g_e_t_group_a_r_n_s='targetgrouparns')

    if camel_dict_to_snake_dict(dict_0) != dict_1:
        print('Test 1 failed')
    if camel_dict_to_snake_dict(dict_2, reversible=True) != dict_2:
        print('Test 2 failed')


# Generated at 2022-06-24 20:32:01.802645
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('\n=== Test of function camel_dict_to_snake_dict')
    camel_dict = {'instanceId': 'i-01234567', 'state': 'running', 'vpc': {'vpcId': 'vpc-0123456789'}}
    print('--- camel_dict:')
    print(camel_dict)
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    print('\n--- snake_dict:')
    print(snake_dict)
    assert snake_dict == {'instance_id': 'i-01234567', 'state': 'running', 'vpc': {'vpc_id': 'vpc-0123456789'}}


# Generated at 2022-06-24 20:32:05.173219
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_1 = 'HelloWorld'
    print(str_1)
    print(_camel_to_snake(str_1))
    print(_snake_to_camel(_camel_to_snake(str_1)))


# Generated at 2022-06-24 20:32:11.729249
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import cStringIO
    import sys

    saved_stdout = sys.stdout
    try:
        out = cStringIO.StringIO()
        sys.stdout = out

        test_case_0()
        sys.stdout.seek(0)
        out = sys.stdout.read()[:-1]
        assert "Hello World" == out
    finally:
        sys.stdout = saved_stdout



# Generated at 2022-06-24 20:32:34.439029
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:45.774138
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:56.603140
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:08.921565
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        _TestDataType0=dict(
            BooleanArg=True,
            DoubleArg=1.1,
            ListArg=['a', 'b', 'c'],
            LongArg=123,
            MapArg=dict(a=1, b=2, c=3),
            StringArg='string',
            DefaultStr='default',
        ),
    )
    snake_dict = dict(
        _test_data_type0=dict(
            boolean_arg=True,
            double_arg=1.1,
            list_arg=['a', 'b', 'c'],
            long_arg=123,
            map_arg=dict(a=1, b=2, c=3),
            string_arg='string',
            default_str='default',
        ),
    )


# Generated at 2022-06-24 20:33:19.102581
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:23.965101
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Build a camel case dictionary to convert
    camel_dict = { 'Dummy': { 'Key1': 1, 'Key2': 2}, 'Key3': 3,
                         'HTTPEndpoint': {'EndpointDescriptions': [ { 'CustomName': 'blah' }] },
                         'Tags': {'Unchanged': 1} }
    # Build expected result
    expected_result = { 'dummy': { 'key1': 1, 'key2': 2}, 'key3': 3,
                       'h_t_t_p_endpoint': {'endpoint_descriptions': [ { 'custom_name': 'blah' }] },
                       'tags': {'Unchanged': 1} }

    returned_result = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-24 20:33:34.999519
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # result = camel_dict_to_snake_dict(str_0)
    # assert (result == 'HelloWorld'), 'Test failed.'

    result = camel_dict_to_snake_dict({'one': 1, 'two': 2})
    assert (result == {'one': 1, 'two': 2}), 'Test failed.'

    result = camel_dict_to_snake_dict({'one': {'two': 2}, 'three': 3})
    assert (result == {'one': {'two': 2}, 'three': 3}), 'Test failed.'

    result = camel_dict_to_snake_dict({'one': {'two': 2}, 'three': 3}, False, ('one',))
    assert (result == {'one': {'two': 2}, 'three': 3}), 'Test failed.'

   

# Generated at 2022-06-24 20:33:42.529250
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPEndpoint": "http://www.google.com/", "Test": True}
    expected_snake_dict =  {"h_t_t_p_endpoint": "http://www.google.com/", "test": True}
    assert camel_dict_to_snake_dict(camel_dict) == expected_snake_dict
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict)) == camel_dict


# Generated at 2022-06-24 20:33:47.072641
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Build test data
    camel_dict_0 = {'FakeName': 'FakeValue'}
    camel_dict_1 = {'HelloWorld': 'v1'}
    camel_dict_2 = {'HelloWorld': {'fakeName': {'fakeValue': 66}}}
    camel_dict_3 = {'HTTPEndpoint': 1}
    camel_dict_4 = {'HTTPEndpoint': [{'fakeValue': 'hello'}, {'fakeValue': 'world'}]}
    camel_dict_5 = {'HelloWorld': {'fakeName': {'fakeValue': 66}, 'fakeTags': {'hello': 'world'}}}

    assert 'hello_world' == _camel_to_snake('HelloWorld', True)
    assert 'hello_world' == _camel_to_snake('HelloWorld', False)

# Generated at 2022-06-24 20:33:53.819339
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {
        'HTTPEndpoint': {
            'Destination': {
                'DestinationType': 'NONE',
                'AttributeMap': {}
            },
            'EndpointType': 'READER',
            'EnforceHTTPS': False,
            'Source': {
                'SourceType': 'DEFAULT',
                'AttributeMap': {}
            },
            'Name': 'http_endpoint_0',
            'Auth': {
                'AuthType': 'Open'
            },
            'EndpointStatus': 'ACTIVE',
            'CreationTime': 1562378119000
        }
    }

# Generated at 2022-06-24 20:34:15.067459
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create test data
    camel_dict = {}
    camelDict = {}
    CamelDict = {}
    camel_dict['Tag'] = ['arn:aws:elasticloadbalancing:us-east-1:1234567890:targetgroup/alb-tracker-example-target-group/bd5121e3e3a3d833']
    camelDict['Tag'] = ['arn:aws:elasticloadbalancing:us-east-1:1234567890:targetgroup/alb-tracker-example-target-group/bd5121e3e3a3d833']

# Generated at 2022-06-24 20:34:26.033264
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HelloWorld': 1, 'HttpEndpoint': 2, 'Tag': {'Key': {'a': 1}, 'Value': {'b': 2}}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict
    assert snake_dict['hello_world'] == 1
    assert snake_dict['http_endpoint'] == 2
    assert snake_dict['tag']['key']['a'] == 1
    assert snake_dict['tag']['value']['b'] == 2
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict
    assert camel_dict['HelloWorld'] == 1
    assert camel_dict['HttpEndpoint'] == 2

# Generated at 2022-06-24 20:34:36.627560
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(_camel_to_snake('CamelToSnake') == 'camel_to_snake')
    assert(_camel_to_snake('camelToSnake') == 'camel_to_snake')
    assert(_camel_to_snake('camelTo_snake', reversible=True) == 'camel_to_snake')

    assert(_camel_to_snake('CamelToSnake', reversible=True) == '_camel_to_snake')
    assert(_camel_to_snake('camelToSnake', reversible=True) == '_camel_to_snake')


if __name__ == "__main__":
    test_camel_dict_to_snake_dict()

# Generated at 2022-06-24 20:34:46.416197
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_case = {
        'someKey1': 'someValue1',
        'someKey2': 'someValue2',
        'someKey3': {
            'someOtherKey1': 'someOtherValue1',
            'someOtherKey2': 'someOtherValue2'
        }
    }
    assert camel_dict_to_snake_dict(camel_case) == {'some_key1': 'someValue1', 'some_key2': 'someValue2', 'some_key3': {'some_other_key1': 'someOtherValue1', 'some_other_key2': 'someOtherValue2'}}

# Generated at 2022-06-24 20:34:55.035601
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(SimpleKey='1234', CamelCaseKey='abc', CamelCaseKey2='ABC', HTTPEndpoint='https://www.example.com')
    expected_dict = dict(simple_key='1234', camel_case_key='abc', camel_case_key2='ABC', h_t_t_p_endpoint='https://www.example.com')
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == expected_dict

    camel_dict = dict(SimpleKey='1234', CamelCaseKey='abc', CamelCaseKey2='ABC', HTTPEndpoint='https://www.example.com')
    snake_dict = camel_dict_to_snake_dict(camel_dict, True)

# Generated at 2022-06-24 20:35:05.834524
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Test: Test: Test: Test: Test: Test: Test: ")
    test_dict = {}
    test_dict["HelloWorld"] = "str"
    test_dict["Hello_World"] = "str"
    test_dict["helloWorld"] = "str"
    test_dict["helloWorld-World"] = "str"
    test_dict["HelloWorldWorld"] = "str"
    test_dict["hELLOwORLD"] = "str"
    test_dict["HelloWorld1"] = "str"
    test_dict["HelloWorld_1"] = "str"
    test_dict["1HelloWorld"] = "str"
    test_dict["1_HelloWorld"] = "str"
    test_dict["HelloWorld1_World"] = "str"

# Generated at 2022-06-24 20:35:12.602859
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_foo = {'FooBar': [
        {
            'Baz': 'bar',
            'HTTPEndpoint': [
                {
                    'Id': 'id'
                }
            ]
        }
    ],
        'A': 'B'
    }

    expected_foo = {'a': 'B', 'foo_bar': [{'baz': 'bar', 'h_t_t_p_endpoint': [{'id': 'id'}]}]}

    foo = camel_dict_to_snake_dict(camel_foo)

    assert foo == expected_foo
