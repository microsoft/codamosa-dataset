

# Generated at 2022-06-24 20:25:34.596820
# Unit test for function recursive_diff
def test_recursive_diff():
    dict_1 = {'port': 80, 'host': 'localhost', 'other_attr': 'test'}
    dict_2 = {'host': '127.0.0.1', 'other_attr': 'test', 'port': '8080'}
    assert recursive_diff(dict_1, dict_2) == ({'host': 'localhost', 'port': 80}, {'host': '127.0.0.1', 'port': '8080'})
    assert recursive_diff(dict_1, {}) == ({'port': 80, 'host': 'localhost', 'other_attr': 'test'}, {})
    assert recursive_diff({}, dict_1) == ({}, {'port': 80, 'host': 'localhost', 'other_attr': 'test'})

# Generated at 2022-06-24 20:25:43.005326
# Unit test for function recursive_diff

# Generated at 2022-06-24 20:25:45.697706
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {'a': {'b': 1, 'c': 2}, 'd': 4}
    dict2 = {'a': {'b': 3}, 'c': 5}

    result = dict_merge(dict1, dict2)
    assert result['a'] == {'b': 3, 'c': 2}
    assert result['d'] == 4



# Generated at 2022-06-24 20:25:56.401866
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test for string values
    dict1 = {"A": 1, "B": "2", "C": "3"}
    dict2 = {"A": 1, "B": "42", "C": "3"}
    left, right = recursive_diff(dict1, dict2)
    assert left == {"B": "2"}
    assert right == {"B": "42"}
    # Test for dictionary values
    dict1 = {"A": 1, "B": "2", "C": {"D": 3, "E": "4"}}
    dict2 = {"A": 1, "B": "2", "C": {"D": 5, "E": "6"}}
    left, right = recursive_diff(dict1, dict2)
    assert left == {"C": {"D": 3, "E": "4"}}

# Generated at 2022-06-24 20:26:01.361251
# Unit test for function recursive_diff
def test_recursive_diff():
    data_a = {
        'prop_1': 'val_1',
        'prop_2': 'val_2',
        'prop_3': 'val_3',
        'prop_4': {
            'prop_4a': 'val_4a',
            'prop_4b': 'val_4b',
            'prop_4c': {
                'prop_4c_1': 'val_4c_1',
                'prop_4c_2': 'val_4c_2'
            },
            'prop_4d': 'val_4d'
        }
    }


# Generated at 2022-06-24 20:26:10.450650
# Unit test for function recursive_diff
def test_recursive_diff():
    # dict1 with dict2 keys
    dict1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}}
    dict2 = {'a': 1, 'b': 3, 'c': {'a': 1, 'b': 2, 'd': 3}}
    expected = {'b': 2, 'c': {'b': 2, 'c': 3}, 'b': 3, 'c': {'d': 3}}
    result = recursive_diff(dict1, dict2)
    assert expected == result

    # dict2 with dict1 keys
    dict1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}}

# Generated at 2022-06-24 20:26:20.122986
# Unit test for function dict_merge
def test_dict_merge():

    dict_1 = {'key_1': 'val_1', 'key_2': 'val_2'}
    dict_2 = {'key_1': 'val_1', 'key_2': 'val_2_2'}
    dict_3 = {'key_1': 'val_1_1', 'key_2': 'val_2_2'}
    dict_4 = {'key_1': 'val_1_1', 'key_2': 'val_2_2', 'key_3': 'val_3'}
    dict_5 = {'key_1': 'val_1_1', 'key_2': {'inner_key_1': 'inner_val_1'}}

# Generated at 2022-06-24 20:26:30.863176
# Unit test for function dict_merge
def test_dict_merge():
    # Test with different KV Pair
    a = {'key': 'value', 'key2': 'value2'}
    b = {'key': 'value1', 'key2': 'value2'}
    output = {'key': 'value1', 'key2': 'value2'}
    assert dict_merge(a, b) == output

    # Test with different KV Pair inside a nested dictionary
    a = {'key': {'key1': 'value1', 'key2': 'value2'}}
    b = {'key': {'key1': 'value11', 'key2': 'value2'}}
    output = {'key': {'key1': 'value11', 'key2': 'value2'}}
    assert dict_merge(a, b) == output

    # Test with same KV Pair


# Generated at 2022-06-24 20:26:39.242234
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = { 'one': 1, 'two': 2, 'three': { 'four': 4, 'five': 5 } }
    dict2 = { 'one': 1, 'two': 3, 'three': { 'four': 4, 'five': 6 } }
    diff3 = recursive_diff(dict1, dict2)
    if not diff3 or diff3 != ({ 'two': 2 }, { 'two': 3 }, { 'three': { 'five': 5 } }, { 'three': { 'five': 6 } }):
        raise AssertionError()


# Generated at 2022-06-24 20:26:39.868905
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    pass

# Generated at 2022-06-24 20:26:53.736152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86') == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    assert camel_dict_to_snake_dict({b'%\x1bs+\x86': b'k%\x1bs+\x86'}) == {b'%_s+_\x86': b'k%\x1bs+\x86'}

# Generated at 2022-06-24 20:27:02.878292
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'StartAt': 'abc'},
                                    reversible=False,
                                    ignore_list=[]) == {'start_at': 'abc'}
    assert camel_dict_to_snake_dict({'StartAt': 'abc'},
                                    reversible=True,
                                    ignore_list=[]) == {'start_at': 'abc'}
    assert camel_dict_to_snake_dict({'StartAt': 'abc'},
                                    reversible=False,
                                    ignore_list=['start_at']) == {'start_at': 'abc'}

# Generated at 2022-06-24 20:27:11.773827
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "ThisIsCamelCase": "Dictionary",
        "AndSoIsThis": ["With", "A", "List", {"AndADictionary": "Hidden inside"}],
        "Build": {"Tags": {"Key": "Value"}, "MoreTags": [{"Key1": "Value1"}]}
    }
    expected_result = {
        "this_is_camel_case": "Dictionary",
        "and_so_is_this": ["With", "A", "List", {"and_a_dictionary": "Hidden inside"}],
        "build": {"tags": {"Key": "Value"}, "more_tags": [{"Key1": "Value1"}]}
    }
    assert camel_dict_to_snake_dict(camel_dict, reversible=False) == expected_result

# Generated at 2022-06-24 20:27:19.329331
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {}
    camel_dict['key0'] = 'value0'
    camel_dict['key1'] = 'value1'
    camel_dict['key2'] = 'value2'
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['key0'] == 'value0'
    assert snake_dict['key1'] == 'value1'
    assert snake_dict['key2'] == 'value2'



# Generated at 2022-06-24 20:27:27.593515
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86') == None
    assert camel_dict_to_snake_dict(b'\xbf\xd1\x9c\xf5\xb7p\x83\x07\xca\x13\x96Iq\x93\x9aQ\x94\x8a\xd3\xdb') == None
    assert camel_dict_to_snake_dict(b'\xb6\x0c\x87\xa1z\xd1\x8a\xef(d\x9c\xee\xa4\x0b\x11\xbf\x1f*') == None
    assert camel

# Generated at 2022-06-24 20:27:30.387785
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    unit_test = dict(
        {"Tags": [{"Key": "aws:cloudformation:logical-id", "Value": "myS3Bucket"}], "Id": "arn:aws:iam::123456789012:user/UserName"})
    assert camel_dict_to_snake_dict(unit_test) == {
        "id": "arn:aws:iam::123456789012:user/UserName", "tags": [{"key": "aws:cloudformation:logical-id", "value": "myS3Bucket"}]}



# Generated at 2022-06-24 20:27:39.100106
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:45.393692
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:53.870860
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Running Test for camel_dict_to_snake_dict")


# Generated at 2022-06-24 20:27:56.582149
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Setup
    input_dict = camel_dict_to_snake_dict(None)

    # Test
    result = camel_dict_to_snake_dict(input_dict)

    # Verify
    assert result == None


# Generated at 2022-06-24 20:28:07.116026
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_0 = {"TestAttr": "abc", "TestObj": {"TestAttr2": "xyz"}}
    snake_dict_0 = {"test_attr": "abc", "test_obj": {"test_attr_2": "xyz"}}
    snake_dict_1 = {"test_attr": "abc", "test_obj": {"test_attr2": "xyz"}}
    assert camel_dict_to_snake_dict(camel_dict_0) == snake_dict_0
    assert camel_dict_to_snake_dict(snake_dict_0) == camel_dict_0
    assert camel_dict_to_snake_dict(camel_dict_0, True) == snake_dict_1

# Generated at 2022-06-24 20:28:12.314514
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelcase_dict = {'CamelCase': 1, 'IHaveACamel': 3}
    snakecase_dict = {'camel_case': 1, 'i_have_a_camel': 3}
    assert camel_dict_to_snake_dict(camelcase_dict) == snakecase_dict



# Generated at 2022-06-24 20:28:21.205536
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test variables
    input_dict = {"keyOne": 1,
                  "keyTwo": "two",
                  "keyThree": None,
                  "keyFour": {"KeyFive": 5},
                  "keySix": {"keySeven": "7"}}

    expected_output = {'key_one': 1,
                       'key_two': 'two',
                       'key_three': None,
                       'key_four': {'key_five': 5},
                       'key_six': {'key_seven': '7'}}

    # Actual output
    actual_output = camel_dict_to_snake_dict(input_dict)

    # Test assertion
    assert actual_output == expected_output



# Generated at 2022-06-24 20:28:24.365748
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert var_0 == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'


# Generated at 2022-06-24 20:28:35.435450
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    assert var_0 == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'


# Generated at 2022-06-24 20:28:39.972882
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    if var_0 is None:
        assert False

# Generated at 2022-06-24 20:28:47.598237
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""
    # Test for valid case
    test_data = dict(UserName='testuser',
                     UserEmail='test@email.com',
                     UserPassword='Test12345')
    expected = dict(user_name='testuser',
                    user_email='test@email.com',
                    user_password='Test12345')
    actual = camel_dict_to_snake_dict(test_data)
    assert actual == expected



# Generated at 2022-06-24 20:28:49.995948
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake(test_case_0) == ''
    assert _camel_to_snake(test_case_0) == ''



# Generated at 2022-06-24 20:28:52.570580
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    arg0 = dict(AWSInstanceType='t2.micro')
    arg1 = False
    arg2 = []
    rc = camel_dict_to_snake_dict(arg0, arg1, arg2)
    assert type(rc) is dict
    assert rc == {'a_w_s_instance_type': 't2.micro'}



# Generated at 2022-06-24 20:29:02.091478
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # byte object that is decryptable with aes-128-ecb
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    # byte object that is decryptable with aes-128-ecb
    bytes_1 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    # byte object that is decryptable with aes-128-ecb
    bytes_2 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    # byte object that is decryptable with aes-128-ecb

# Generated at 2022-06-24 20:29:15.478702
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = { 1: { 'aBc': 'def' }, 'ghiJKL': [ 123 ] }
    v1 = { 1: { 'a_bc': 'def' }, 'ghi_j_k_l': [ 123 ] }
    v2 = { 1: { 'a_b_c': 'def' }, 'g_h_i_j_k_l': [ 123 ] }
    var_2 = { 1: { 'abc': 'def' }, 'ghijkl': [ 123 ] }
    var_3 = { 1: { 'aBc': 'def' }, 'ghiJKL': [ 123 ] }
    var_4 = { 'a_bc': 'def' }
    var_5 = { 'aBc': 'def' }

# Generated at 2022-06-24 20:29:21.214620
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {
        "host": "localhost",
        "port": 22,
        "username": "user",
        "testString": "test",
        "testNumber": 3.2,
        "testBoolean": True,
        "testArray": [
            "item1",
            "item2",
            "item3"
        ],
        "testObject": {
            "subKeyString": "subValue",
            "subKeyNumber": 123.45,
            "subKeyBoolean": False
        },
        "testNull": None
    }

    camel_dict_to_snake_dict(data)



# Generated at 2022-06-24 20:29:28.312039
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 10}) == {'foo_bar': 10}
    assert camel_dict_to_snake_dict({'fooBar': 10}, reversible=True) == {'foo_bar': 10}
    assert camel_dict_to_snake_dict({'fooBar': 10}, True) == {'foo_bar': 10}
    assert camel_dict_to_snake_dict({'fooBar': 10}, True, []) == {'foo_bar': 10}



# Generated at 2022-06-24 20:29:30.457995
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()
    print("Success")

test_camel_dict_to_snake_dict()

# Generated at 2022-06-24 20:29:34.835794
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    with pytest.raises(TypeError) as excinfo:
        assert camel_dict_to_snake_dict(None)
    the_exception = excinfo.value
    assert "object is not subscriptable" in str(the_exception)


# Generated at 2022-06-24 20:29:40.790896
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    #example1
    bytes_0 = b'\xab\xfa\xbb\xad\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    out = camel_dict_to_snake_dict(bytes_0)
    assert out is None, "Expected: None, Got: %s" % out

    #example2

# Generated at 2022-06-24 20:29:49.430467
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('NetworkConfiguration') == 'network_configuration'
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('HTTPEndpoint', reversible=True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_arns'
    assert _camel_to_snake('TargetGroupARNs', reversible=True) == 'target_group_ar_ns'
    assert _camel_to_snake('LoadBalancerARNs') == 'load_balancer_arns'
    assert _camel_to_snake('LoadBalancerARNs', reversible=True) == 'load_balancer_arns'
    assert _c

# Generated at 2022-06-24 20:29:58.322446
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    assert var_0 == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    bytes_1 = b'\xd6\x10\x98\x9a\x8a\x1c\xda\x89\x91\x8b\xffh<\xaf5'
    var_1 = camel_dict_to_snake_dict(bytes_1)

# Generated at 2022-06-24 20:30:04.561561
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_0 = {
        "labelName": "test-label",
        "labelValues": ["v1", "v2", "v3"],
        "metricName": "test-metric"
    }
    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)
    assert snake_dict_0 == {'metric_name': 'test-metric', 'label_values': ['v1', 'v2', 'v3'], 'label_name': 'test-label'}


# Generated at 2022-06-24 20:30:16.262584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Tags': {},
        'TrustedSigners': {
            'Enabled': True,
            'Quantity': 0
        },
        'ViewerCertificate': {
            'Certificate': 'string',
            'CertificateSource': 'string',
            'CloudFrontDefaultCertificate': True,
            'IAMCertificateId': 'string',
            'MinimumProtocolVersion': 'string',
            'SSLSupportMethod': 'string'
        },
        'WebACLId': 'string'
    }

# Generated at 2022-06-24 20:30:27.792892
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake(camel_dict_to_snake_dict('abc','def')) == 'abc_def'


# Generated at 2022-06-24 20:30:33.080757
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    my_dict = {"BlockDeviceMappings": [{"DeviceName": "/dev/sda1","DryRun": False,}, {"DeviceName": "/dev/sdb","Ebs": {"DeleteOnTermination": True,"Encrypted": False,},},], "InstanceType": "t2.micro","ImageId": "ami-fce3c696",}
    my_dict_capitalized = {"BlockDeviceMappings": [{"DeviceName": "/dev/sda1","DryRun": False,}, {"DeviceName": "/dev/sdb","Ebs": {"DeleteOnTermination": True,"Encrypted": False,},},], "InstanceType": "t2.micro","ImageId": "ami-fce3c696",}
    result_dict = camel_dict_to_snake_dict(my_dict, True)
    result_dict_capitalized

# Generated at 2022-06-24 20:30:43.796071
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    src_dict = {
        'KeyExample': 'ValueExample1',
        'KeyExample2': {
            'KeyExample2': 'ValueExample2',
            'KeyExample3': [
                'ValueExample3',
                {
                    'KeyExample4': 'ValueExample4'
                }
            ],
            'KeyExample5': 'ValueExample5'
        }
    }
    dest_dict = {
        'key_example': 'ValueExample1',
        'key_example2': {
            'key_example2': 'ValueExample2',
            'key_example3': [
                'ValueExample3',
                {
                    'key_example4': 'ValueExample4'
                }
            ],
            'key_example5': 'ValueExample5'
        }
    }
    # Convert dict keys from camel case to

# Generated at 2022-06-24 20:30:44.594428
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert not test_case_0()

# Generated at 2022-06-24 20:30:52.926134
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    '''Test camel_dict_to_snake_dict function'''

    # Testing with a simple example
    assert (camel_dict_to_snake_dict({'TestCamelCase': {'Name': 'test'}}) ==
            {'test_camel_case': {'name': 'test'}})

    # Testing with the AWS example

# Generated at 2022-06-24 20:30:57.687221
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPPath': '/', 'HTTPMethod': 'POST'}})
    assert camel_dict == {'h_t_t_p_endpoint': {'http_path': '/', 'http_method': 'POST'}}



# Generated at 2022-06-24 20:31:06.788509
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('HTTPEndpoint') == "h_t_t_p_endpoint"
    assert _camel_to_snake('HTTPEndpoint', True) == "h_t_t_p_end_point"
    assert _snake_to_camel('http_endpoint', True) == "HttpEndpoint"
    assert _snake_to_camel('http_endpoint') == "httpEndpoint"
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}) == {'http_endpoint': 'value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}, reversible=True) == {'h_t_t_p_endpoint': 'value'}
    assert camel_dict_to_snake

# Generated at 2022-06-24 20:31:16.392129
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': True}) == {'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({'keyName': True}) == {'key_name': True}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': True}, True) == {'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({'keyName': True}, True) == {'key_name': True}
    assert camel_dict_to_snake_dict({'Id': 'Id', 'Arn': 'Arn'}) == {'id': 'Id', 'arn': 'Arn'}

# Generated at 2022-06-24 20:31:27.775064
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    assert var_0 == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    bytes_1 = b'\xc3\x8e\x06\xe3\xed%\x00\x9c#\x82V\xc0\x84\x8e\x18\x1d\x9d\x04\xf4t\x0e\xbb\x1e\xe8'
    var_1 = camel_dict_to_snake

# Generated at 2022-06-24 20:31:38.505859
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    bytes_1 = b'\x1e\xea\x93\x97\xcf\x86\xe1\x83\x8c\xec\xdeK\x97\x0e\x0f\xcc\xee^\xc9'
    var_1 = camel_dict_to_snake_dict(bytes_1)

# Generated at 2022-06-24 20:31:52.880030
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'SourceName': 'test_source'}) == {'source_name': 'test_source'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'test_endpoint'}) == {'h_t_t_p_endpoint': 'test_endpoint'}
    assert camel_dict_to_snake_dict({'Tags': {'test_key': 'test_value', 'test_key2': 'test_value2'}}) == {'tags': {'test_key': 'test_value', 'test_key2': 'test_value2'}}

# Generated at 2022-06-24 20:31:57.751868
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {'aCamelKey': 'ACamelValue',
              'snake_key': 'snake_value',
              'mixedKey': 'mixedValue'}

    assert {'a_camel_key': 'ACamelValue', 'snake_key': 'snake_value', 'mixed_key': 'mixedValue'} == camel_dict_to_snake_dict(dict_0)



# Generated at 2022-06-24 20:32:01.961138
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'http://example.com', 'MaxCount': 42, 'Tags': {'bit': 'bucket'}}
    expected = {'h_t_t_p_endpoint': 'http://example.com', 'max_count': 42, 'tags': {'bit': 'bucket'}}
    assert camel_dict_to_snake_dict(camel_dict) == expected


# Generated at 2022-06-24 20:32:12.665113
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({"TestString": "value"}))["TestString"] == "value"
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({"TestString": "value"})) == {"TestString": "value"}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({"TestString": "value"}, True), True)["TestString"] == "value"
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({"TestString": "value"}, True), True) == {"TestString": "value"}

# Generated at 2022-06-24 20:32:19.100216
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    params = {
        "HTTPEndpoint": {
            "Enabled": True
        },
        "Tags": [
            {
                "Key": "test",
                "Value": "test"
            }
        ]
    }

    expected_results = {
        "http_endpoint": {
            "enabled": True
        },
        "tags": [
            {
                "Key": "test",
                "Value": "test"
            }
        ]
    }

    actual_results = camel_dict_to_snake_dict(params)
    assert expected_results == actual_results


# Generated at 2022-06-24 20:32:29.757498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "MetricsEnabled": True,
        "AccessLogs": {
            "Enabled": True,
            "IncludeCookies": True,
            "Bucket": "my-bucket-name"
        },
        "HealthCheck": {
            "Target": "HTTP:80/png",
            "HealthyThreshold": 3,
            "UnhealthyThreshold": 5,
            "Interval": 30,
            "Timeout": 3
        },
        "ConnectionSettings": {
            "IdleTimeout": 60
        },
        "Tags": [
            {
                "Key": "Project",
                "Value": "XYZ"
            }
        ]
    }


# Generated at 2022-06-24 20:32:37.219815
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    assert var_0 == b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'


# Generated at 2022-06-24 20:32:46.706160
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:53.732191
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:05.721761
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = {'Foo': {'Bar': 'Baz', 'Baz': '4'}, 'List': [{'Entry': 1}, {'Entry': 2}]}
    dict2 = {'foo': {'bar': 'Baz', 'baz': '4'}, 'list': [{'entry': 1}, {'entry': 2}]}
    dict3 = {'fOo': {'bAr': 'Baz', 'bAz': '4'}, 'lIst': [{'eNtry': 1}, {'eNtry': 2}]}
    dict4 = {'foo': {'bar': 'Baz', 'baz': '4'}, 'list': [{'entry': 1}, {'entry': 2}], 'Arbitrary': 'Field'}
    dict5 = camel_dict_to_snake

# Generated at 2022-06-24 20:33:35.317600
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert '''camel_dict_to_snake_dict''' in globals(), "Function does not exist"
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    bytes_1 = b'\xac\xad\x1b{}\xb6\x02d\x8b\x8cq\xaf\xab'
    var_1 = camel_dict_to_snake_dict(bytes_1)

# Generated at 2022-06-24 20:33:46.559283
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = {
        'HELLO': 'WORLD',
        'hi_there': 'world',
    }
    var_2 = {
        'HELLO': 'WORLD',
        'hello': 'world',
    }


# Generated at 2022-06-24 20:33:53.501638
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'InstanceId': 'i-0cd6fcbfea9b45d67', 'State': {'Name': 'running', 'Code': 16}, 'PrivateIpAddress': '10.10.0.45'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert list(snake_dict.keys()) == ['instance_id', 'state', 'private_ip_address']
    assert snake_dict['instance_id'] == 'i-0cd6fcbfea9b45d67'
    assert snake_dict['state']['name'] == 'running'
    assert snake_dict['state']['code'] == 16
    assert snake_dict['private_ip_address'] == '10.10.0.45'


# Generated at 2022-06-24 20:34:02.620392
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    simple_dict = {'MultiAZ': True}
    result = camel_dict_to_snake_dict(simple_dict)
    expected_result = {'multi_az': True}
    assert result == expected_result, 'camel_dict_to_snake_dict() returned ' + str(result) + ' but expected ' + str(expected_result)

    nested_dict = {'BackupRetentionPeriod': 5, 'DBInstanceIdentifier': 'rds1', 'MultiAZ': True}
    result = camel_dict_to_snake_dict(nested_dict)
    expected_result = {'backup_retention_period': 5, 'db_instance_identifier': 'rds1', 'multi_az': True}

# Generated at 2022-06-24 20:34:11.000453
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_1[u'k'] = u'v'
    dict_0[u'k'] = dict_1
    dict_2 = dict()
    dict_2[u'k'] = dict_1
    dict_3 = dict_2[u'k']
    dict_3[u'k'] = u'v'
    dict_3 = dict_2[u'k']
    dict_3[u'k'] = u'E'
    dict_4 = dict()
    dict_4[u'k'] = dict_2
    dict_5 = dict_4[u'k']
    dict_5[u'k'] = dict_1
    dict_5 = dict_4[u'k']

# Generated at 2022-06-24 20:34:17.969710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'InstanceType': 't2.micro',
        'ImageId': 'ami-xxxxxxxx',
        'NetworkInterfaces': [{'DeviceIndex': 0, 'SubnetId': 'subnet-xxxxxxxx', 'Groups': ['sg-xxxxxxxx'], 'AssociatePublicIpAddress': True}],
        'BlockDeviceMappings': [{'DeviceName': '/dev/sda1', 'Ebs': {'VolumeSize': 8, 'VolumeType': 'gp2'}}],
        'IamInstanceProfile': {'Name': 'my-instance-profile'},
        'Tags': [{'ResourceType': 'instance', 'Tags': [{'Key': 'Name', 'Value': 'my-instance'}]}]
    }

# Generated at 2022-06-24 20:34:26.259103
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Arrange
    camel_dict = {'TestCase': 'test case', 'TestCase_Dict': {'sub_key': 'sub value', 'sub_key_Dict': {'sub_sub_key': 'sub sub value'}}}

    # Act
    snake_dict = camel_dict_to_snake_dict(camel_dict)

    # Assert
    assert snake_dict['test_case'] == 'test case'
    assert snake_dict['test_case_dict']['sub_key'] == 'sub value'
    assert snake_dict['test_case_dict']['sub_key_dict']['sub_sub_key'] == 'sub sub value'



# Generated at 2022-06-24 20:34:37.346236
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bytes_0 = b'\t\x0c\xb2\xb1`\xf7^\x94\x01k%\x1bs+\x86'
    var_0 = camel_dict_to_snake_dict(bytes_0)
    bytes_1 = b'\xac\x08V\xd6\x13\x16\x9c\xc2\xf0\xc1\xfc\xf5\x81\xb5:\x0c\x00'
    var_1 = camel_dict_to_snake_dict(bytes_1)

# Generated at 2022-06-24 20:34:44.014823
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:54.735537
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        "MyNameIs": "Bob",
        "AndISay": "Hello",
        "AndIDontLike": "ThisFieldNameWithCapitals",
        "Tags": {
            "Key": "Value",
            "Key2": "Value2"  # If we convert this we break AWS
        },
        "HTTPEndpoint": "https://www.example.com"
    }