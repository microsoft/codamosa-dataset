

# Generated at 2022-06-24 20:25:27.799739
# Unit test for function dict_merge
def test_dict_merge():
    # Input and expected result.
    a = {'a': 1, 'b': {1: 1, 2: 2, 'c': {'hello': 'world'}}}
    b = {'a': 2, 'b': {2: 3, 3: 3}, 'c': {'goodbye': 'world'}}
    d = {'a': 2, 'b': {1: 1, 2: 3, 3: 3, 'c': {'hello': 'world', 'goodbye': 'world'}},
         'c': {'goodbye': 'world'}}

    # Test function
    test_dict_merge = dict_merge(a, b)

    # Assert we have the expected result, allowing for any dict order

# Generated at 2022-06-24 20:25:35.221762
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'foo': 'bar'}) == {'foo': 'bar'}
    assert camel_dict_to_snake_dict({'foo': {'bAr': 'baz'}}) == {'foo': {'b_ar': 'baz'}}
    assert camel_dict_to_snake_dict({'foo': [{'bAr': 'baz'}]}) == {'foo': [{'b_ar': 'baz'}]}

# Generated at 2022-06-24 20:25:43.409969
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {
        'a': 1,
        'b': {
            'c': 'd',
            'e': 'f',
            'g': 'h',
            'i': 'j'
        },
        'k': 'l',
        'm': {
            'n': 'o',
            'p': 'q'
        },
        'r': 's',
        't': {
            'u': 'v',
            'w': ['x'],
            'y': 'z'
        }
    }


# Generated at 2022-06-24 20:25:48.672425
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_dict_1 = {'RoleARN': 'foo', 'RoleSessionName': 'bar', 'Policy': 'baz', 'Tags': {'foo': 'bar'}}
    camel_dict_1 = {'fooBarBaz': 'BarBarBar'}
    complex_dict_2 = {'Tags': {'foo': 'bar', 'fooBarBaz': 'BarBarBar'}}
    complex_dict_3 = {'Tags': {'bar': {'foo': 'bar'}, 'baz': 'bar'}}
    assert camel_dict_to_snake_dict(camel_dict=camel_dict_1, reversible=False) == {'foo_bar_baz': 'BarBarBar'}

# Generated at 2022-06-24 20:25:54.834764
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_0 = {
        'TargetGroupARNs': ['arn:1', 'arn:2'],
        'TargetGroupStickinessConfig': {
            'Enabled': True,
            'DurationSeconds': 300
            },
        'Tags': {
            'Name': 'test'
        }
    }
    snake_0 = {
        'target_group_a_r_ns': ['arn:1', 'arn:2'],
        'target_group_stickiness_config': {
            'enabled': True,
            'duration_seconds': 300
        },
        'tags': {
            'Name': 'test'
        }
    }

    snake_1 = camel_dict_to_snake_dict(camel_0)

    assert snake_0 == snake_1


# Generated at 2022-06-24 20:25:59.841758
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:26:08.668444
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_0 = {
        'param1': 'value1',
        'param2': {
            'subParam1': 'subValue1',
            'subParam2': 'subValue2',
        },
        'param3': [
            {
                'subParam1': 'subValue1',
                'subParam2': 'subValue2',
            }
        ]
    }
    complex_1 = {
        'param1': 'value1',
        'param2': {
            'sub_param_1': 'subValue1',
            'sub_param_2': 'subValue2',
        },
        'param3': [
            {
                'sub_param_1': 'subValue1',
                'sub_param_2': 'subValue2',
            }
        ]
    }
    var_

# Generated at 2022-06-24 20:26:14.594186
# Unit test for function recursive_diff
def test_recursive_diff():
    test0 = {'a': 'foo', 'b': {'c': 'bar'}}
    test1 = {'a': 'foo', 'b': {'c': 'foo'}}
    assert recursive_diff(test0, test0) is None
    assert recursive_diff(test0, test1) == ({'b': {'c': 'bar'}}, {'b': {'c': 'foo'}})

# Generated at 2022-06-24 20:26:22.011190
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test for camel_dict_to_snake_dict
    """


# Generated at 2022-06-24 20:26:27.607865
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_profile_dict = {'DbInstanceIdentifier': 'test',
                         'PubliclyAccessible': True,
                         'DBInstanceParameterGroupName': 'default.mysql5.7',
                         'DBSnapshotIdentifier': 'test',
                         'AllocatedStorage': 128,
                         'DBInstanceClass': 'db.t2.micro',
                         'Engine': 'mysql',
                         'MasterUsername': 'test',
                         'MasterUserPassword': 'test',
                         'DBSubnetGroupName': 'default',
                         'MultiAZ': False,
                         'Port': '3306'}


# Generated at 2022-06-24 20:26:38.655745
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {'HTTPEndpoint': 'test@test.com', 'HttpEndpoint': 'test@test.com', 'HTTPMethod': 'POST'}
    dict_1 = {'h_t_t_p_endpoint': 'test@test.com', 'http_endpoint': 'test@test.com', 'http_method': 'POST'}
    assert camel_dict_to_snake_dict(dict_0) == dict_1



# Generated at 2022-06-24 20:26:44.497159
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Test starting")

    d_0 = {'SimpleKey': 'SimpleValue', 'SimpleList': [1, 2, 3], 'IntKey': 100, 'Key1': 'Value1'}
    r_0 = '{SimpleKey: SimpleValue, SimpleList: [1, 2, 3], IntKey: 100, Key1: Value1}'
    print("d_0 =", d_0)

    d_1 = {'SimpleKey': 'SimpleValue', 'SimpleList': [1, 2, 3], 'IntKey': 100, 'Key1': 'Value1'}
    r_1 = {'simple_key': 'SimpleValue', 'simple_list': [1, 2, 3], 'int_key': 100, 'key1': 'Value1'}
    print("d_1 =", d_1)

    d_2

# Generated at 2022-06-24 20:26:54.898170
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {
    "HTTPEndpoint": {
        "Enabled": True,
        "Endpoint": "http://ansible.com/status"
    },
    "Tags": {
        "Foo": "Bar"
    },
    "OtherStuff": {
        "Containers": [
            {
                "Image": "httpd",
                "Memory": 128
            }
        ]
    },
    "ClusterName": "test-cluster",
    "Version": "1.0"
}


# Generated at 2022-06-24 20:27:05.572227
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:14.299444
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '

# Generated at 2022-06-24 20:27:24.317568
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    print(str_0)
    name_0 = 'HTTPEndpoint'
    name_1 = 'HttpEndpoint'
    name_2 = 'HTTPEndpointReversed'
    name_3 = 'HTTPResponseCode'
    name_4 = 'HTTPResponseCodeRR'
    name_5 = 'HttpResponseCodeRR'
    name_6 = 'httpResponseCode'
    name_7 = 'httpResponseCode'

# Generated at 2022-06-24 20:27:35.295694
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Check for the correct output for a given input.

    print(test_case_0.__doc__)

# Generated at 2022-06-24 20:27:42.509887
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"test-list": [{"test-dict": "a"}]}
    snake_dict = {"test_list": [{"test_dict": "a"}]}
    assert snake_dict == camel_dict_to_snake_dict(camel_dict), "Expected %s but got %s" % (snake_dict, camel_dict_to_snake_dict(camel_dict))
    camel_dict = {"test-dict": {"test-list": "a"}}
    snake_dict = {"test_dict": {"test_list": "a"}}
    assert snake_dict == camel_dict_to_snake_dict(camel_dict), "Expected %s but got %s" % (snake_dict, camel_dict_to_snake_dict(camel_dict))

# Generated at 2022-06-24 20:27:44.856775
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print(str_0)
    result1 = camel_dict_to_snake_dict({'test':'test'})
    assert result1 == {'test':'test'}, "Pass"


# Generated at 2022-06-24 20:27:53.661169
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for camel_dict_to_snake_dict
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    dict_0 = {'AmazonProvidedIpv6CidrBlock': True}
    dict_1 = camel_dict_to_snake_dict(dict_0)

    # Verify dict_1 == {'amazon_provided_ipv6_cidr_block': True}
    assert dict_1 == {'amazon_provided_ipv6_cidr_block': True}
    dict_0 = {'Association': {'IpOwnerId': 'amazon'}}
    dict_1 = camel_dict_to_snake_dict(dict_0)

    # Verify dict_1 == {'association': {'ip_owner_id': '

# Generated at 2022-06-24 20:28:02.262090
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    s = {
        "Groups": {
            "Test": {
                "TestGroup1": {
                    "Description": "Test for camel_dict_to_snake_dict",
                    "Tags": {
                        "Color": "Blue",
                        "Number": "One"
                    }
                }
            }
        }
    }
    a = {
        "groups": {
            "test": {
                "test_group1": {
                    "description": 'Test for camel_dict_to_snake_dict',
                    "tags": {
                        "Color": "Blue",
                        "Number": "One"
                    }
                }
            }
        }
    }
    assert(camel_dict_to_snake_dict(s, ignore_list=['tags']) == a)


# Generated at 2022-06-24 20:28:07.200882
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    # Test for basic conversion
    camel_dict_0 = {'Test': 'camel_dict_to_snake_dict'}
    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)
    assert snake_dict_0['test'] == 'camel_dict_to_snake_dict'
    # Test for list handling
    camel_dict_1 = {'Test': ['camel', 'dict', 'to', 'snake', 'dict']}
    snake_dict_1 = camel_dict_to_snake_dict(camel_dict_1)

# Generated at 2022-06-24 20:28:18.632304
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('\n    Test for camel_dict_to_snake_dict\n    ')

    # This is an example for a test for function camel_dict_to_snake_dict

    # Define a test input

# Generated at 2022-06-24 20:28:29.293278
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_0['HTTPEndpoint'] = 'http://5.5.5.5:8080'
    dict_0['HTTPSEndpoint'] = 'https://1.1.1.1:8443'
    dict_0['Host'] = '1.1.1.1'
    dict_0['Port'] = 8443
    dict_0['Protocol'] = 'https'
    dict_0['TargetGroupARNs'] = ['arn:aws:elasticloadbalancing:us-east-2:123456789012:targetgroup/my-targets123/6d0ecb0389f0c645']
    dict_0['TargetType'] = 'lambda'
    dict_0['VpcId'] = 'vpc-234567890'

    dict_1 = dict()


# Generated at 2022-06-24 20:28:39.094839
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    dict_0 = {'hasTagsForResource': [{'Value': 'string', 'Key': 'string'}], 'MaxResults': 123, 'NextToken': 'string'}
    dict_1 = {
        u'nextToken': 'string',
        u'hasTagsForResource': [{'Value': 'string', 'Key': 'string'}],
        u'maxResults': 123}
    assert(camel_dict_to_snake_dict(dict_0)==dict_1)


# Generated at 2022-06-24 20:28:44.717331
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Body of function camel_dict_to_snake_dict.
    try:
        for i in range(2):
            for j in range(5):
                k = j + 10
                l = i + k
                print(l)
            print('\n')
    except:
        continue

    return (str_0)


# Generated at 2022-06-24 20:28:55.434939
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'dromedaryCase': 'camel', 'snake_case': 'snake', 'capsOn': 'CAPS'})) == {'dromedary_case': 'camel', 'snake_case': 'snake', 'caps_on': 'CAPS'}
    assert(camel_dict_to_snake_dict({'dromedaryCase': 'camel', 'snake_case': 'snake', 'capsOn': 'CAPS'})) != {'dromedary_case': 'camel', 'snake_case': 'snake', 'caps_on': 'CAPS'}

# Generated at 2022-06-24 20:29:03.501819
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_0 = {'lastModifiedDate': '2019-05-31T13:32:13.996Z', 'status': 'Available', 'name': 'test-apim-3', 'version': '1', 'apiRevision': '2019-05-31T13:31:53.987Z', 'apiId': '1hx7xvn2tua13', 'endpointConfiguration': {'types': ['PRIVATE']}, 'apiKeySelectionExpression': '$request.header.x-api-key', 'disableExecuteApiEndpoint': False}

# Generated at 2022-06-24 20:29:12.866843
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Case # 0: Test for camel_dict_to_snake_dict with reversible=True
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    dict_0 = camel_dict_to_snake_dict({'HTTPEndpoint': {'EndpointURL': 'string', 'Protocol': 'string', 'AuthType': 'string'}}, reversible=True)
    dict_1 = {'h_t_t_p_endpoint': {'endpoint_u_r_l': 'string', 'protocol': 'string', 'auth_type': 'string'}}
    assert (dict_0 == dict_1), str_0
    
    # Case # 1: Test for camel_dict_to_snake_dict with reversible=False

# Generated at 2022-06-24 20:29:21.430004
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"TestKey": "TestValue"}) == {"test_key": "TestValue"}, "camel_dict_to_snake_dict failed"
    assert camel_dict_to_snake_dict({"TestKey": {"TestSubKey": "TestValue"}}) == {"test_key": {"test_sub_key": "TestValue"}}, "camel_dict_to_snake_dict failed"
    assert camel_dict_to_snake_dict({"SubKeyMap": {"TestKey": {"TestSubKey": "TestValue"}}}) == {"sub_key_map": {"test_key": {"test_sub_key": "TestValue"}}}, "camel_dict_to_snake_dict failed"

# Generated at 2022-06-24 20:29:37.624812
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '


# Generated at 2022-06-24 20:29:47.103577
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '

    dict_0 = {'CamelCaseKey': 'value'}
    dict_1 = {'camel_case_key': 'value'}

    dict_2 = {'CamelCaseKey': {'CamelCaseSubKey': 'value'}}
    dict_3 = {'camel_case_key': {'camel_case_sub_key': 'value'}}

    assert str(camel_dict_to_snake_dict(dict_0)) == str(dict_1)
    assert str(camel_dict_to_snake_dict(dict_0)) != str(dict_0)

# Generated at 2022-06-24 20:29:55.369551
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:04.298252
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_camel = '\n    Test for camel_dict_to_snake_dict\n    '
    camel = {'TestStr': 'TestStr', 'TestInt': 123, 'TestBool': True, 'TestArr': [1,2,3], 'TestDict': {'a': 1, 'b': 2}}
    snake = camel_dict_to_snake_dict(camel)
    assert snake == {'test_str': 'TestStr', 'test_int': 123, 'test_bool': True, 'test_arr': [1,2,3], 'test_dict': {'a': 1, 'b': 2}}

# Generated at 2022-06-24 20:30:10.605114
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 1}
    d2 = {'b': 2}
    assert recursive_diff(d1, d2) == ({'a': 1}, {'b': 2})
    d1 = {'a': {'b': {'c': 3}}, 1: 2}
    d2 = {'a': {'b': {'c': 4}}, 1: 2}
    assert recursive_diff(d1, d2) == ({'a': {'b': {'c': 3}}}, {'a': {'b': {'c': 4}}})
    d1 = {'a': 1}
    d2 = {'a': 1}
    assert recursive_diff(d1, d2) == None



# Generated at 2022-06-24 20:30:19.460005
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    dict_0 = dict()
    dict_0['LoadBalancerAttributes'] = dict()
    dict_0['LoadBalancerAttributes']['ConnectionSettings'] = dict()
    dict_0['LoadBalancerAttributes']['ConnectionSettings']['IdleTimeout'] = dict()
    dict_0['LoadBalancerAttributes']['ConnectionSettings']['IdleTimeout']['Timeout'] = 1000
    dict_0['LoadBalancerAttributes']['ConnectionSettings']['IdleTimeout']['Enabled'] = True
    dict_0['LoadBalancerAttributes']['ConnectionSettings']['IdleTimeout']['Unit'] = 'SECONDS'

# Generated at 2022-06-24 20:30:19.984262
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True



# Generated at 2022-06-24 20:30:24.639705
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'EndpointType': 'IP', 'Port': 80}, 'IsEnabled': True}) == {'h_t_t_p_endpoint': {'endpoint_type': 'IP', 'port': 80}, 'is_enabled': True}


# Generated at 2022-06-24 20:30:34.844461
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '\n    Test for camel_dict_to_snake_dict\n    '
    dict_0 = {'abc': 1, 'def': 2, 'ghi': {'foo': {'1': 1, '2': 2}, 'bar': [{'3a': 3}, {'3b': 'three'}]}}
    dict_1 = {'abc': 1, 'def': 2, 'ghi': {'foo': {'1': 1, '2': 2}, 'bar': [{'3a': 3}, {'3b': 'three'}]}}
    dict_2 = {'abc': 1, 'def': 2, 'ghi': {'foo': {'1': 1, '2': 2}, 'bar': [{'3a': 3}, {'3b': 'three'}]}}

# Generated at 2022-06-24 20:30:44.284679
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(dict(), dict()) is None

    left = {
        'first': 1,
        'second': 2,
        'third': 3
    }

    right = {
        'first': 1,
        'second': 2,
        'third': 4
    }

    difference = recursive_diff(left, right)
    assert difference[0] == {'third': 3}
    assert difference[1] == {'third': 4}

    left = {
        'first': 1,
        'second': {
            'first': 1,
            'second': 2,
            'third': 3
        },
        'third': 3
    }


# Generated at 2022-06-24 20:30:59.137602
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("camelCaseString") == "camel_case_string"
    assert _camel_to_snake("already_snake_case") == "already_snake_case"
    assert _camel_to_snake("ALLSNakeCase") == "all_snake_case"
    assert _camel_to_snake("PascalCaseString") == "pascal_case_string"
    assert _camel_to_snake("ThisIsPascalCase") == "this_is_pascal_case"
    assert _camel_to_snake("thisIsPascalCase") == "this_is_pascal_case"
    assert _camel_to_snake("ACRONYM") == "acronym"
    assert _camel_to_sn

# Generated at 2022-06-24 20:31:07.587246
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test case for recursive_diff
    """
    expected_output = {'k1': {'k2': 'v2', 'k6': 'v6'}, 'k7': 'v7'}
    actual_output = recursive_diff({'k1': {'k2': 'v2', 'k3': 'v3'}, 'k4': 'v4', 'k5': 'v5'},
                                   {'k1': {'k2': 'v2', 'k3': 'v333'}, 'k4': 'v4', 'k5': 'v555'})
    assert actual_output == expected_output

    expected_output = {'k4': 'v4', 'k5': 'v555'}

# Generated at 2022-06-24 20:31:16.984085
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-24 20:31:27.807108
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {u'instance_type': u'r3.large', u'enabled': False}
    b = {u'instance_type': u'r3.large', u'description': u'', u'enabled': True}
    (left, right) = recursive_diff(a, b)
    assert left == {u'enabled': False}
    assert right == {u'enabled': True, u'description': u''}

    a = {u'instance_type': u'r3.large', u'enabled': False}
    b = {u'instance_type': u'r3.large', u'description': u'', u'enabled': False}
    (left, right) = recursive_diff(a, b)
    assert left == {}
    assert right == {u'description': u''}


# Generated at 2022-06-24 20:31:38.501454
# Unit test for function recursive_diff
def test_recursive_diff():
    #Test 1
    expected_result = ({'e':{'right':'e-right', 'left':'e-left'}, 'g':'g-left'}, {'e':{'right':'e-right', 'left':'e-left'}, 'h':'h-right'})
    a = {'a':'one', 'b':'two', 'c':'three', 'd':'four', 'e':{'left':'e-left', 'right':'e-right'}, 'g':'g-left'}
    b = {'a':'one', 'b':'two', 'c':'three', 'd':'four', 'e':{'left':'e-left', 'right':'e-right'}, 'h':'h-right'}

# Generated at 2022-06-24 20:31:49.052955
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    complex_0 = {"HTTPEndpoint": None}
    var_0 = camel_dict_to_snake_dict(complex_0)
    _assert_equals(var_0, {"h_t_t_p_endpoint": None})

    complex_1 = {"HTTPEndpoint": None, "HTTPSEndpoint": None, "TCPEndpoint": None, "Endpoint": None}
    var_1 = camel_dict_to_snake_dict(complex_1)
    _assert_equals(var_1, {"h_t_t_p_endpoint": None, "h_t_t_p_s_endpoint": None, "t_c_p_endpoint": None, "endpoint": None})


# Generated at 2022-06-24 20:31:57.039299
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_0 = {
        'HTTPHeader': [
            {
                'Name': 'string',
                'Value': 'string'
            },
        ],
        'HTTPParameters': {
            'Path': 'string',
            'QueryString': 'string'
        },
        'HTTPRetryPolicy': {
            'HTTPCodes': [
                'string',
            ],
            'PerRetryTimeout': {
                'Unit': 'string',
                'Value': 123
            },
            'RetryOn': 'string',
            'RetryAttempts': 123
        },
        'HTTPRouteKeys': [
            'string',
        ]
    }

    var_0 = camel_dict_to_snake_dict(complex_0)
    # test passed, no exceptions raised
    return var_0


#

# Generated at 2022-06-24 20:32:01.702323
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(key1='value1', key2='value2', key3=dict(key4='value4'))
    dict2 = dict(key1='value1', key2='value2', key3=dict(key8='value8'))

    actual = recursive_diff(dict1, dict2)
    assert actual == ({'key3': {'key4': 'value4'}}, {'key3': {'key8': 'value8'}})

# Generated at 2022-06-24 20:32:12.473132
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(dict()) == dict()
    assert camel_dict_to_snake_dict(dict(a=1, B=2)) == dict(a=1, b=2)
    assert camel_dict_to_snake_dict(dict(
        a=dict(b=dict(c=1), B=2),
        C=dict(d=1, D=dict(e=1)),
        E=dict(f=1),
        G=1)) == dict(
            a=dict(b=dict(c=1), b=2),
            c=dict(d=1, d=dict(e=1)),
            e=dict(f=1),
            g=1)

# Generated at 2022-06-24 20:32:20.642177
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:35.572674
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_0 = {'SomeKey': 'SomeValue', 'SomeOtherKey': 'SomeOtherValue'}
    var_0 = camel_dict_to_snake_dict(complex_0)
    assert var_0 == {'some_key': 'SomeValue', 'some_other_key': 'SomeOtherValue'}
    complex_0 = {'SomeKey': 'SomeValue', 'SomeOtherKey': 'SomeOtherValue'}
    var_1 = camel_dict_to_snake_dict(complex_0, False, ())
    assert var_1 == {'some_key': 'SomeValue', 'some_other_key': 'SomeOtherValue'}
    complex_1 = {'SomeKey': 'SomeValue', 'SomeOtherKey': 'SomeOtherValue'}

# Generated at 2022-06-24 20:32:45.885512
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})

    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    assert recursive_diff({'a': ['b']}, {'a': ['c']}) == ({'a': ['b']}, {'a': ['c']})

    assert recursive_diff({'a': {'b': 2}}, {'a': {'b': 3}}) == ({'a': {'b': 2}}, {'a': {'b': 3}})

    assert recursive_diff({'a': {}}, {'a': {'b': 3}}) == ({'a': {}}, {'a': {'b': 3}})


# Generated at 2022-06-24 20:32:56.679412
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    print(">>>>> test_camel_dict_to_snake_dict() >>>>>")

    # Initialize test variables
    # Case 0
    complex_0 = None
    expected_0 = None
    # Case 1
    complex_1 = {'a': 'b'}
    expected_1 = {'a': 'b'}
    # Case 2
    complex_2 = {'a_b': 'c', 'd': 'e'}
    expected_2 = {'a_b': 'c', 'd': 'e'}
    # Case 3
    complex_3 = {'mixedCase': 'alpha', 'UPPERCASE': 'beta', 'CamelCase': 'gamma', 'snake_case': 'delta', 'snake_case_': 'epsilon'}

# Generated at 2022-06-24 20:33:08.953380
# Unit test for function recursive_diff
def test_recursive_diff():
    # Define and init the needed variables
    dict1 = {
        "a": {
            "b": "c",
            "d": "e"
        },
        "f": {
            "g": {
                "h": "i"
            }
        },
        "j": "k",
        "l": "m"
    }
    dict2 = {
        "a": {
            "b": "c",
            "d": "e"
        },
        "f": {
            "g": {
                "h": "i"
            }
        },
        "j": "k",
        "l": "m"
    }
    expected = None
    # Compare the results
    assert recursive_diff(dict1, dict2) == expected


# Generated at 2022-06-24 20:33:19.140832
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff(dict(a=10, b=dict(a=10, b=20), c=dict(a=30, b=dict(a=10, b=20))),
                          dict(a=10, b=dict(a=10, b=20), c=dict(a=30, b=dict(a=10, b=dict(a=20))))) == ({},
                                                                                                       {'c': {'b': {
                                                                                                           'b': {
                                                                                                               'a': 20}}}})


# Generated at 2022-06-24 20:33:23.663594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Testing with a empty dict
    test0 = {}
    expected0 = {}
    assert camel_dict_to_snake_dict(test0) == expected0

    # Testing with a non-empty dict
    test1 = {
        "Foo": "foo",
        "Bar": "bar",
        "FooBar": "foobar",
        "HTTPEndpoint": "httpendpoint",
    }
    expected1 = {
        "foo": "foo",
        "bar": "bar",
        "foo_bar": "foobar",
        "h_t_t_p_endpoint": "httpendpoint",
    }
    assert camel_dict_to_snake_dict(test1) == expected1



# Generated at 2022-06-24 20:33:34.939555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def build_complex_dict():
        return {
            "HTTPEndpoint": {
                "EndpointStatus": "string",
                "EndpointType": "string",
                "Vip": "string"
            },
            "MetricName": "string",
            "MetricNamespace": "string",
            "Statistic": "string",
            "Unit": "string",
            "Value": 123
        }

    complex_dict = build_complex_dict()
    complex_dict_keys = complex_dict.keys()

    # Convert complex_dict to snake case
    snake_complex_dict = camel_dict_to_snake_dict(complex_dict)

    # Verify some snake_complex_dict keys are 'metric_namespace', 'metric_name', etc.
    snake_complex_dict_keys = snake_complex_

# Generated at 2022-06-24 20:33:42.493510
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict1 = {u'HTTPEndpoint': u'http://ec2-204-236-193-182.compute-1.amazonaws.com', u'HttpPort': 80}
    snake_dict1 = {u'h_t_t_p_endpoint': u'http://ec2-204-236-193-182.compute-1.amazonaws.com', u'http_port': 80}
    assert camel_dict_to_snake_dict(camel_dict1) == snake_dict1



# Generated at 2022-06-24 20:33:50.920119
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:00.162752
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {"a": "b", "c": "d"}
    var_1 = {"a": "b", "c": "d", "eFg": {"hIj": "kLm"}}
    var_2 = {"a": "b", "c": "d", "eFg": "hIj"}

# Generated at 2022-06-24 20:34:16.342136
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_1 = {'CreationTime': '2017-10-31T00:43:58.597000+00:00',
                 'ModifiedTime': '2017-10-31T01:00:01.192000+00:00',
                 'ThingName': 'raspberry_pi'}

    var_1 = camel_dict_to_snake_dict(complex_1)
    var_2 = camel_dict_to_snake_dict(var_1)

    assert var_1 == {'creation_time': '2017-10-31T00:43:58.597000+00:00',
                     'modified_time': '2017-10-31T01:00:01.192000+00:00',
                     'thing_name': 'raspberry_pi'}

    assert var_2 == var_1



# Generated at 2022-06-24 20:34:26.643185
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = dict(fooBar="foobar")
    dict2 = dict(foo_bar="foobar")
    assert camel_dict_to_snake_dict(dict1) == dict2

    dict1 = dict(fooBar="foobar", pingPong="pingpong")
    dict2 = dict(foo_bar="foobar", ping_pong="pingpong")
    assert camel_dict_to_snake_dict(dict1) == dict2

    dict1 = dict(fooBarBaz="foobarbaz")
    dict2 = dict(foo_bar_baz="foobarbaz")
    assert camel_dict_to_snake_dict(dict1) == dict2

    dict1 = dict(fooBarBaz="foobarbaz", pingPong="pingpong")

# Generated at 2022-06-24 20:34:33.903757
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Endpoint': 'http://www.amazon.com', 'Port': 443}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {'h_t_t_p_endpoint': {'endpoint': 'http://www.amazon.com', 'port': 443}}



# Generated at 2022-06-24 20:34:41.160714
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'foo', 'HTTPSEndpoint': 'bar'}
    expected_result = {'h_t_t_p_endpoint': 'foo', 'h_t_t_ps_endpoint': 'bar'}
    assert camel_dict_to_snake_dict(camel_dict) == expected_result
    assert camel_dict_to_snake_dict(camel_dict, True, []) == {'h_t_t_p_endpoint': 'foo',
                                                             'h_t_t_ps_endpoint': 'bar'}

# Generated at 2022-06-24 20:34:48.081090
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'A': 1, 'B': 2, 'c': {'D': 1, 'E': 2}}, False) == {'A': 1, 'B': 2, 'c': {'D': 1, 'E': 2}}
    assert camel_dict_to_snake_dict({'a': 1, 'B': 2, 'c': {'D': 1, 'E': 2}}, False) == {'a': 1, 'B': 2, 'c': {'D': 1, 'E': 2}}

# Generated at 2022-06-24 20:34:56.780270
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:35:06.928355
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_0 = {'Tags': [{'Key': 'k1', 'Value': 'v1'}, {'Key': 'k2', 'Value': 'v2'}],
                 'Type': 'AWS::ApiGateway::RestApi',
                 'Properties': {'Name': 'api', 'Description': 'api'}}
    var_0 = camel_dict_to_snake_dict(complex_0, False, ignore_list=['Tags'])
    expected_0 = {'tags': [{'Key': 'k1', 'Value': 'v1'}, {'Key': 'k2', 'Value': 'v2'}],
                  'type': 'AWS::ApiGateway::RestApi',
                  'properties': {'Name': 'api', 'Description': 'api'}}
    assert var_0

# Generated at 2022-06-24 20:35:15.480516
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_dict = camel_dict_to_snake_dict({"HTTPEndpoint": {
                                                                "Attributes": [
                                                                    {
                                                                        "Key": "string",
                                                                        "Value": "string"
                                                                    }
                                                                ],
                                                                "EndpointArn": "string"
                                                            }})

    assert complex_dict == {'h_t_t_p_endpoint': {'attributes': [{'key': 'string', 'value': 'string'}],
                                                'endpoint_arn': 'string'}}
