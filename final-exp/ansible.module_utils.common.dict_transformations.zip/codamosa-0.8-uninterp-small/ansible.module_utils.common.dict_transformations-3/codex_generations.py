

# Generated at 2022-06-24 20:25:35.125333
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'data': {'list': [{'age': 1, 'name': 'kevin'},
                               {'age': 2, 'name': 'tom'},
                               {'age': 3, 'name': 'mary'}]}}
    dict2 = {'data': {'list': [{'age': 2, 'name': 'mary'},
                               {'age': 3, 'name': 'kevin'},
                               {'age': 1, 'name': 'tom'}]}}

# Generated at 2022-06-24 20:25:43.348195
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    assert dict_1 == {}

    dict_0 = {'aBcD': 1}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    assert dict_1 == {'a_bc_d': 1}

    dict_0 = {'aBcD': {'A_Z': 1, 'a_bC_d': {'ABC': 1}}, 'd_E_f': 2}
    #reversed dictionary
    dict_1 = camel_dict_to_snake_dict(dict_0, True)

# Generated at 2022-06-24 20:25:51.922513
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Testing camel_dict_to_snake_dict()")
    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint", reversible=True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("IAMRoleArn") == "iam_role_arn"
    assert _camel_to_snake("IAMRoleArn", reversible=True) == "i_a_m_role_arn"
    assert _camel_to_snake("TargetGroupARNs") == "target_group_arns"
    assert _camel_to_snake("TargetGroupARNs", reversible=True) == "target_group_a_r_ns"
    assert _camel_to

# Generated at 2022-06-24 20:25:55.270473
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'key1': 5, 'key2': 'abc', 'key3': { 'key4': 'val4', 'key5': 'val5'}}
    dict2 = {'key1': 5, 'key2': 'abc'}
    result = recursive_diff(dict1, dict2)
    assert result == ({'key3': { 'key4': 'val4', 'key5': 'val5'}}, None)


# Generated at 2022-06-24 20:26:01.913726
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{8@F'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == str_0


# Generated at 2022-06-24 20:26:10.378796
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=0, b=dict(a=1))
    b = dict(b=dict(a=1, b=2))
    c = dict(c=2)
    assert dict_merge(a, b) == dict(a=0, b=dict(a=1, b=2))
    assert dict_merge(b, a) == dict(b=dict(a=1), a=0)
    assert dict_merge(a, b, c) == dict(a=0, b=dict(a=1, b=2), c=2)
    assert dict_merge(b, a, c) == dict(b=dict(a=1, b=2), a=0, c=2)


# Generated at 2022-06-24 20:26:20.090454
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{8@F'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert isinstance(var_0, str)
    assert var_0 == '{8@F'
    str_0 = '<d~\x1f\x11\x0e\x0c\x12K\x03\x01\x0b\x1d\x0e'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert isinstance(var_0, str)
    assert var_0 == '<d~\x1f\x11\x0e\x0c\x12K\x03\x01\x0b\x1d\x0e'

# Generated at 2022-06-24 20:26:30.867639
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data_0 = {
        'HTTPEndpoint': 1,
        'KinesisStreamAsSourceConfiguration': {
            'KinesisStreamARN': 'arn:aws:kinesis:us-west-2:123456789012:stream/exampleStreamName',
            'RoleARN': 'arn:aws:iam::123456789012:role/exampleRoleName'
        },
        'Tags': {
            'Text': 'string'
        }
    }

# Generated at 2022-06-24 20:26:38.932151
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
        'foo': 'bar',
        'nested': {
            'a': 'b',
        }
    }
    d2 = {
        'foo': 'bar2',
        'nested': {
            'c': 'd'
        }
    }
    merged = dict_merge(d1, d2)

    assert {'foo': 'bar2', 'nested': {'c': 'd', 'a': 'b'}} == merged



# Generated at 2022-06-24 20:26:48.017852
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    simple_camel_dict = {
        'Id': 'i-218',
        'State': 'running',
        'Tags': {
            'someKey': 'someValue'
        }
    }
    simple_snake_dict = {
        'id': 'i-218',
        'state': 'running',
        'tags': {
            'someKey': 'someValue'
        }
    }
    assert camel_dict_to_snake_dict(simple_camel_dict) == simple_snake_dict

    # Test that when we don't ignore the tags, we convert them
    tags = {
        'someKey': 'someValue'
    }
    tags_expected = {
        'some_key': 'someValue'
    }

# Generated at 2022-06-24 20:26:56.853282
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{8@F'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == {8: '@F'}



# Generated at 2022-06-24 20:27:04.246559
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert isinstance(camel_dict_to_snake_dict(None), dict)
    assert isinstance(camel_dict_to_snake_dict(None, reversible=False), dict)
    assert isinstance(camel_dict_to_snake_dict(None, reversible=True), dict)
    assert isinstance(camel_dict_to_snake_dict(None, ignore_list=()), dict)
    assert isinstance(camel_dict_to_snake_dict(None, reversible=False, ignore_list=()), dict)
    assert isinstance(camel_dict_to_snake_dict(None, reversible=True, ignore_list=()), dict)



# Generated at 2022-06-24 20:27:12.417860
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    hello = {
        'InstalledVersion': '0.0.0-0.0.0.0',
        'TargetVersion': '0.0.1-0.0.0.0',
        'UpdateAvailable': True,
        'UpdateDownloaded': False
      }
    helloSnake = {
        'installed_version': '0.0.0-0.0.0.0',
        'target_version': '0.0.1-0.0.0.0',
        'update_available': True,
        'update_downloaded': False
      }
    connected = camel_dict_to_snake_dict(hello)
    assert connected == helloSnake
    assert type(connected) == type(hello)



# Generated at 2022-06-24 20:27:23.124676
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_test = '{8@F'

# Generated at 2022-06-24 20:27:29.807935
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    s = {'a': {'b': {'c': 'foobar'}}}
    result = {'a': {'b': {'c': 'foobar'}}}
    assert camel_dict_to_snake_dict(s) == result

    s = {'a': {'b': {'c': ['foobar']}}}
    result = {'a': {'b': {'c': ['foobar']}}}
    assert camel_dict_to_snake_dict(s) == result

    s = {'a': {'b': {'c': ['foobar', 'baz']}}}
    result = {'a': {'b': {'c': ['foobar', 'baz']}}}
    assert camel_dict_to_snake_dict(s) == result


# Generated at 2022-06-24 20:27:33.335717
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_vars = globals().copy()
    for (key, value) in test_vars.items():
        if key.startswith("test_case"):
            value()

# Generated at 2022-06-24 20:27:35.370579
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        assert callable(camel_dict_to_snake_dict)
    except AssertionError as e:
        raise(e)



# Generated at 2022-06-24 20:27:45.197860
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{8@F'
    str_1 = {'*A\x7f': '\t', '\t\x0b': '\t', '\t4': 42, '?': '\x17\n', '\x1a': 'X\x17@', '~': '\x13', '\x1c': '\x025'}
    str_2 = '{8@F'
    str_3 = {'*A\x7f': '\t', '\t\x0b': '\t', '\t4': 42, '?': '\x17\n', '\x1a': 'X\x17@', '~': '\x13', '\x1c': '\x025'}
    str_4 = '{8@F'
   

# Generated at 2022-06-24 20:27:51.802782
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'a': {'b': {'Cd': 0}}}), {'a': {'b': {'cd': 0}}}
    assert camel_dict_to_snake_dict({'a': {'B': {'cD': 0}}}), {'a': {'b': {'cd': 0}}}
    assert camel_dict_to_snake_dict({'A': {'b': {'CD': 0}}}), {'a': {'b': {'cd': 0}}}
    assert camel_dict_to_snake_dict({'A': {'B': {'CD': 0}}}), {'a': {'b': {'cd': 0}}}



# Generated at 2022-06-24 20:27:55.739588
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    a = {'HTTPEndpoint': "http://", 'name': 'joe'}
    b = {'h_t_t_p_endpoint': "http://", 'name': 'joe'}
    assert camel_dict_to_snake_dict(a) == b


# Generated at 2022-06-24 20:28:04.892936
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Set up test data
    test_dict_0 = {
        'aBc': 123,
        'DEF': {
            'A1A': 'abc',
            'B2B': 'cde'
        },
        'Ghi': [
            'abC',
            'cde'
        ]
    }

    # Execute function
    test_dict_0 = camel_dict_to_snake_dict(test_dict_0)

    # Verify the results
    assert test_dict_0['a_bc'] == 123
    assert test_dict_0['d_e_f'] == {'a1_a': 'abc', 'b2_b': 'cde'}
    assert test_dict_0['ghi'] == ['abC', 'cde']



# Generated at 2022-06-24 20:28:16.274000
# Unit test for function recursive_diff

# Generated at 2022-06-24 20:28:23.675681
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = {'aBc': 1, 'DeF': {'aBcDeF': 1, 'GHiJ': 2}, 'KlMn': [1, 2, 3, 4], 'OpQr': {'aBcDeF': 'aBcDeF'}}
    var_2 = {'abc': 1, 'def': {'abc_def': 1, 'ghi_j': 2}, 'kl_mn': [1, 2, 3, 4], 'op_qr': {'abc_def': 'aBcDeF'}}
    assert var_2 == camel_dict_to_snake_dict(var_1)


# Generated at 2022-06-24 20:28:31.719173
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Basic case
    var_1 = camel_dict_to_snake_dict({'TestKey': 'TestVal'})
    assert var_1 == {'test_key': 'TestVal'}
    # Nested case
    var_2 = camel_dict_to_snake_dict({'TestKey1': {'TestKey2': 'TestVal'}})
    assert var_2 == {'test_key1': {'test_key2': 'TestVal'}}


# Generated at 2022-06-24 20:28:40.609736
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:28:51.854981
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'some_value'}, reversible=False) == {'http_endpoint': 'some_value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'some_value'}, reversible=True) == {'h_t_t_p_endpoint': 'some_value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'HTTPEndpoint': 'some_value'}}, reversible=False) == {'http_endpoint': {'http_endpoint': 'some_value'}}

# Generated at 2022-06-24 20:29:01.560388
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {"foo": {"bar": "one"}}
    dict2 = {"foo": {"bar": "two"}}
    result = recursive_diff(dict1, dict2)
    assert result == ({}, {'foo': {'bar': 'two'}})
    dict1 = {"foo": {"bar": "one"}}
    dict2 = {"foo": {"bar": "two", "baz": "three"}}
    result = recursive_diff(dict1, dict2)
    assert result == ({}, {'foo': {'bar': 'two', 'baz': 'three'}})
    dict1 = {"foo": {"bar": "one"}}
    dict2 = {"foo": {"baz": "three"}}
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-24 20:29:06.588879
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:16.348631
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test None case
    assert recursive_diff(None,None) is None
    assert recursive_diff('a','a') is None
    assert recursive_diff(['a','b','c'],'a') is None

    # Test various mixes of different lists, ints, and strings
    assert recursive_diff([1,2,3,4], [1,2,3,4]) is None
    assert recursive_diff([1,2,3,4], [1,2,5,4]) == ({2: 3}, {2: 5})
    assert recursive_diff([1,2,3,4], [1,2,3]) == ({3: 4}, {})
    assert recursive_diff(['a', 'b', 'c'], ['a', 'b', 'c']) is None

# Generated at 2022-06-24 20:29:25.513859
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:39.192747
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:45.867185
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Field': 'Foobar'}) == {'field': 'Foobar'}
    assert camel_dict_to_snake_dict({'Field': 'Foobar'}, reversible=True) == {'field': 'Foobar'}
    assert camel_dict_to_snake_dict({'Field': 'Foobar'}, reversible=False) == {'field': 'Foobar'}
    assert camel_dict_to_snake_dict({'Field': 'Foobar'}, reversible=True) == {'field': 'Foobar'}
    assert camel_dict_to_snake_dict({'f': {'Field': 'Foobar'}}) == {'f': {'field': 'Foobar'}}
    assert camel_dict_to_

# Generated at 2022-06-24 20:29:54.548791
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:03.666816
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:05.814217
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    var_0 = globals()
    var_0['camel_dict_to_snake_dict']()
    var_0['camel_dict_to_snake_dict']()


# Generated at 2022-06-24 20:30:11.766096
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:12.528720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = None
    var_2 = globals()


# Generated at 2022-06-24 20:30:20.695917
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {'Strings': ['a', 'b'], 'One': 1, 'Two': '2',
                                 'Three': {'A': 1, 'B': 2, 'camelCase': True},
                                 'HTTPEndpoint': 'abc', 'HTTPEndpoints': True,
                                 'HttpEndpointA': 'abc', 'HttpEndpointB': 'abc'}
    var_1 = camel_dict_to_snake_dict(var_0, ignore_list=['Tags'])
    assert 'h_t_t_p_endpoint' in var_1
    assert 'h_t_t_p_endpoints' in var_1
    var_2 = camel_dict_to_snake_dict(var_0, reversible=True, ignore_list=['Tags'])

# Generated at 2022-06-24 20:30:25.262125
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {'camelCase': {'fooBar': 'baz'}}
    res_dict = camel_dict_to_snake_dict(input_dict)
    assert (res_dict != input_dict)
    assert (res_dict == {'camel_case': {'foo_bar': 'baz'}})


# Generated at 2022-06-24 20:30:27.355659
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': 'bar'}) == {'foo_bar': 'bar'}


# Generated at 2022-06-24 20:30:34.683826
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    class UnitTestCamelDictToSnakeDict(unittest.TestCase):

        result_0 = camel_dict_to_snake_dict(var_0)

    unittest.main()


if __name__ == "__main__":

    import unittest

    test_case_0()

# Generated at 2022-06-24 20:30:44.168950
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {'fooBar': '1'}
    res_0 = {'foo_bar': '1'}
    res = camel_dict_to_snake_dict(var_0)
    assert res == res_0
    var_1 = {'fooBar': '1', 'fooBar2': '2'}
    res_1 = {'foo_bar': '1', 'foo_bar2': '2'}
    res = camel_dict_to_snake_dict(var_1)
    assert res == res_1
    var_2 = {'fooBar': '1', 'fooBar2': {'fooBar3': 3}}
    res_2 = {'foo_bar': '1', 'foo_bar2': {'foo_bar3': 3}}
    res = camel_dict_to_

# Generated at 2022-06-24 20:30:44.977511
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = globals()


# Generated at 2022-06-24 20:30:53.264755
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Basic input for camel_dict_to_snake_dict
    x = {'a': 1, 'ab': {'ab': {'ab': {'ab': 1}}, 'abC': 4}}
    y = camel_dict_to_snake_dict(x)
    w = {'a': 1, 'ab': {'ab': {'ab': {'ab': 1}}, 'ab_c': 4}}
    assert (y == w)
    # Basic input for camel_dict_to_snake_dict
    x = {'a': 1, 'ab': {'ab': {'ab': {'ab': 1}}, 'abC': 4}}
    y = camel_dict_to_snake_dict(x, False, ())

# Generated at 2022-06-24 20:31:01.093581
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    meta = var_0.get('camel_dict_to_snake_dict', None)
    if meta is None:
        print("No function named camel_dict_to_snake_dict")
        exit(1)
    else:
        print("Testing function camel_dict_to_snake_dict")
        test_camel_dict_to_snake_dict_0()
        test_camel_dict_to_snake_dict_1()
        test_camel_dict_to_snake_dict_2()
        test_camel_dict_to_snake_dict_3()


# Generated at 2022-06-24 20:31:08.561093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'items': {
            'id': 'abcdefg',
            'name': 'myTag',
            'prop': 'myProp',
            'otherProp': 'myOtherProp',
            'tags': {
                'Key': 'myKey',
                'Value': 'myValue'
            }
        }
    }
    expected = {
        'items': {
            'id': 'abcdefg',
            'name': 'myTag',
            'prop': 'myProp',
            'other_prop': 'myOtherProp',
            'tags': {
                'Key': 'myKey',
                'Value': 'myValue'
            }
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expe

# Generated at 2022-06-24 20:31:14.824589
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_data = {'aBc': 'XYZ', 'DEFG': [{'HiJk': 10, 'LMnop': 20}], 'QrSt': {'Uv': 30, 'wX': 40}}
    output_data= {'a_bc': 'XYZ', 'd_e_f_g': [{'hi_jk': 10, 'l_mnop': 20}], 'qr_st': {'uv': 30, 'w_x': 40}}
    if camel_dict_to_snake_dict(test_data) != output_data:
        raise Exception("{} failed!".format(vars()['test_camel_dict_to_snake_dict'].__name__))


# Generated at 2022-06-24 20:31:21.441215
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    module_args = {}
    # set up test values
    test_0 = {'A' : '1', 'B' : {'C' : '2', 'D' : '3'}}
    test_1 = {'A' : '1', 'B' : {'E' : '2', 'F' : '3'}}
    expected_result_0 = {'a' : '1', 'b' : {'c' : '2', 'd' : '3'}}
    expected_result_1 = {'a' : '1', 'b' : {'e' : '2', 'f' : '3'}}
    result_0 = camel_dict_to_snake_dict(test_0)
    result_1 = camel_dict_to_snake_dict(test_1)
    assert result

# Generated at 2022-06-24 20:31:29.468918
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "ApplicationName": "Test",
        "ApplicationDescription": "Test",
        "ServerGroups": [
            {"ServerGroupName": "Test"},
            {"ServerGroupName": "Test"}
       ],
        "Tags": [
            {"Key": "Test", "Value": "Test"},
            {"Key": "Test", "Value": "Test"}
        ]
    }

    expected_result = {
        "application_name": "Test",
        "application_description": "Test",
        "server_groups": [
            {"server_group_name": "Test"},
            {"server_group_name": "Test"}
        ],
        "tags": [
            {"Key": "Test", "Value": "Test"},
            {"Key": "Test", "Value": "Test"},
        ]
    }

   

# Generated at 2022-06-24 20:31:38.943703
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'ContentEncoding': 'GZIP', 'Enabled': True, 'PayloadFormatVersion': '1.0', 'URL': 'https://foo.someUrl', 'TimeoutInSeconds': 10, 'Version': '1'}}) == {'h_t_t_p_endpoint': {'content_encoding': 'GZIP', 'enabled': True, 'payload_format_version': '1.0', 'url': 'https://foo.someUrl', 'timeout_in_seconds': 10, 'version': '1'}}
    assert camel_dict_to_snake_dict({'Enabled': True}) == {'enabled': True}
    assert camel_dict_to_snake_dict({'Enabled': False}) == {'enabled': False}
    assert camel

# Generated at 2022-06-24 20:31:45.137657
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sources = []


# Generated at 2022-06-24 20:31:54.128555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import time
    import re

    camel_dict_to_snake_dict_input = b'{"Key":"Value","Dict":{"Key":"Value"},"List":[1,2,3],"Number":1,"Float":0.1,"BoolTrue":true,"BoolFalse":false,"String":"Value","Null":null}'

    # Run the function and check the result
    result = camel_dict_to_snake_dict(json.loads(camel_dict_to_snake_dict_input))

    assert type(result) == dict
    assert result['dict']['key'] == "Value"
    assert result['float'] == 0.1
    assert type(result['list']) == list
    assert type(result['number']) == int
    assert type(result['string']) == str

# Generated at 2022-06-24 20:32:01.992439
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_object = {
        "firstName": "John",
        "lastName": "Doe",
        "age": 26,
        "address": {
            "streetAddress": "naist street",
            "city": "Nara",
            "postalCode": "630-0192"
        },
        "phoneNumbers": [
            {
                "type": "iPhone",
                "number": "0123-4567-8888"
            },
            {
                "type": "home",
                "number": "0123-4567-8910"
            }
        ]
    }


# Generated at 2022-06-24 20:32:12.659944
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:13.773071
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    if var_0:
        var_0()


# Generated at 2022-06-24 20:32:18.946945
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = {}
    var_26 = camel_dict_to_snake_dict(var_1)
    var_27 = {}
    assert var_26 == var_27


# Generated at 2022-06-24 20:32:20.352875
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = {'GroupName': 'ansible'}
    var_2 = globals()


# Generated at 2022-06-24 20:32:31.519002
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:37.881890
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {'testDict': {'testKey': 'test1'}, 'testDict2': {'testKey2': {'testKey': 'test2'}}}
    snake_dict = camel_dict_to_snake_dict(input_dict)
    assert snake_dict['test_dict']['test_key'] == 'test1'
    assert snake_dict['test_dict2']['test_key2']['test_key'] == 'test2'


# Generated at 2022-06-24 20:32:47.158837
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:56.299177
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # tests camel_dict_to_snake_dict

    args = [
        'test_61',
        'test_63',
    ]

    var_0 = {'test_61': 'test_58', 'test_62': 'test_59'}
    var_1 = {'test_63': 'test_58', 'test_64': 'test_59'}

    # test 0
    assert camel_dict_to_snake_dict(var_0) == {'test_61': 'test_58', 'test_62': 'test_59'}
    # test 1
    assert camel_dict_to_snake_dict(var_0, *args[0:0]) == {'test_61': 'test_58', 'test_62': 'test_59'}
    # test 2
    assert camel

# Generated at 2022-06-24 20:33:08.703932
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = dict()
    var_1 = dict()
    var_0 = {
        'MyTest': {
            'SubKey': 'foo'
        },
        'HTTPEndpoint': {
            'SubKey': 'foo'
        },
        'HttpsEndpoint': {
            'SubKey': 'foo'
        },
        'TargetGroupARNs': {
            'SubKey': 'foo'
        }
    }

# Generated at 2022-06-24 20:33:09.563710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = (globals())


# Generated at 2022-06-24 20:33:11.690277
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print(camel_dict_to_snake_dict(dict(aBc=1, dEf=2)))


# Generated at 2022-06-24 20:33:18.158693
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    param_0 = {'String': 'abc', 'Int': 2, 'Dict': {'a': 'b', 'b': 2}, 'Bool': True}
    param_1 = True
    result_0 = camel_dict_to_snake_dict(param_0, param_1)

    assert {'string': 'abc', 'int': 2, 'dict': {'a': 'b', 'b': 2}, 'bool': True} == result_0


# Generated at 2022-06-24 20:33:20.277136
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = camel_dict_to_snake_dict({"Test": "value"})
    assert var_1 == {'test': 'value'}



# Generated at 2022-06-24 20:33:26.024470
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
            "jargon": {
                "FooBarBaz" : "v1",
                "FooBarBazBin" : "v2"
            },
            "FooBarBaz" : "v3",
            "FooBarBazBin" : "v4",
            "TargetGroupARNs" : "v5",
            "TargetGroupARNsBin" : "v6"
        }

# Generated at 2022-06-24 20:33:36.661253
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'tags' == _camel_to_snake('Tags')
    assert 'h_t_t_p_endpoint' == _camel_to_snake('HTTPEndpoint', True)
    assert 'http_endpoint' == _camel_to_snake('HTTPEndpoint')

    camel_dict = {
        'HTTPEndpoint': 'bar',
        'Tags': {
            'TagKey': 'my-key',
            'TagValue': 'my-value'
        }
    }
    expected_snake_dict = {
        'http_endpoint': 'bar',
        'tags': {
            'TagKey': 'my-key',
            'TagValue': 'my-value'
        }
    }


# Generated at 2022-06-24 20:33:42.773500
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_3 = {}
    var_3["SSECustomerKeyMD5"] = "jdg9F9jyKx+E5O5R5B5Zbw=="
    var_3["Metadata"] = {}
    var_3["RequestPayer"] = "requester"
    var_4 = snake_dict_to_camel_dict(camel_dict_to_snake_dict(var_3))
    assert var_3 == var_4


# Generated at 2022-06-24 20:33:50.981650
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("HTTPEndpoint", True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("HTTPEndpoint", False) == "http_endpoint"

    camel_dict = {"HTTPEndpoint": {
        "Endpoint": "something"
    }}
    snake_dict = {"h_t_t_p_endpoint": {
        "endpoint": "something"
    }}

    assert camel_dict_to_snake_dict(camel_dict, True) == snake_dict

    camel_dict = {"HTTPEndpoint": {
        "Endpoint": "something"
    }}
    snake_dict = {"http_endpoint": {
        "endpoint": "something"
    }}


# Generated at 2022-06-24 20:33:58.916783
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(var_0) == var_1
    assert camel_dict_to_snake_dict(var_0, True) == var_2
    assert camel_dict_to_snake_dict(var_0, False, [var_4]) == var_3
    assert camel_dict_to_snake_dict(var_0, True, [var_6]) == var_5


# Generated at 2022-06-24 20:34:07.323660
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camelized_dict = {
        'HTTPEndpoint': {
            'EndpointId': 'test123',
            'EndpointAddress': 'https://test.com',
            'TargetARNs': [
                'arn:aws:sqs:us-east-1:123456789012:Some_Queue',
                'arn:aws:sqs:us-east-1:123456789012:AnotherQueue'
            ],
            'Tags': {
                'MyTagKey': 'MyTagValue'
            }
        }
    }

# Generated at 2022-06-24 20:34:15.354130
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'HTTPMethod': 'GET', 'Path': '/my/api', 'URL': 'http://myapi.com'},
                  'Tags': {'Key': 'Value'}}

    print('%s : %s' % ('camel_dict_to_snake_dict', camel_dict_to_snake_dict(camel_dict)))

    camel_dict = {'HTTPEndpoint': {'HTTPMethod': 'GET', 'Path': '/my/api', 'URL': 'http://myapi.com'},
                  'Tags': {'Key': 'Value'}, 'Description': 'foo'}


# Generated at 2022-06-24 20:34:21.381133
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {'MultipleValue': 'value', 'Boolean': True, 'NoneValue': None, 'Num': 10}
    var_1 = {'multiple_value': 'value', 'boolean': True, 'none_value': None, 'num': 10}
    assert _camel_dict_to_snake_dict(var_0) == var_1



# Generated at 2022-06-24 20:34:29.279498
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:38.246219
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': '123'}) == {'foo_bar': '123'}
    assert camel_dict_to_snake_dict({'fooBar': '123', 'Bar': '123'}) == {'foo_bar': '123', 'bar': '123'}
    assert camel_dict_to_snake_dict({'fooBar': '123', 'Bar': '123'}, equivalent=False) == {'foo_bar': '123', 'bar': '123'}
    assert camel_dict_to_snake_dict({'fooBar': '123', 'Bar': '123'}, equivalent=True) == {'foo_bar': '123', 'bar': '123'}

# Generated at 2022-06-24 20:34:44.739750
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        import boto3
    except Exception:
        print('[FAILED] Unable to import boto3.  Aborting test.')
        return
    camel_dict = {
        'TagFilters': [{
            'Value': 'ansible',
            'Key': 'role'
        }],
        'ResourceArn': 'arn:aws:dynamodb:us-east-1:123456789012:table/EdgeTable',
        'Name': 'EdgyEvent1'
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-24 20:34:54.757604
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("starting test_camel_dict_to_snake_dict")
    # Example 1 - Identity test
    example_1 = {
        "Test1": "test1",
        "Test2": "test2",
    }
    assert camel_dict_to_snake_dict(example_1) == example_1
    # Example 2 - One item with a camel case key
    example_2 = {
        "TestItem": "test1",
    }
    assert camel_dict_to_snake_dict(example_2) == {"test_item": "test1"}
    # Example 3 - One item with a mixed case key
    example_3 = {
        "TestItem": "test1",
        "TestItem1": "test2",
    }

# Generated at 2022-06-24 20:35:05.706238
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:35:12.492196
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    try:
        dummy_dict = {'LotsOfCamelCase':'this_needs_to_be_snake_case'}
        # Answer should be {'lots_of_camel_case':'this_needs_to_be_snake_case'}
        assert camel_dict_to_snake_dict(dummy_dict) == {'lots_of_camel_case':'this_needs_to_be_snake_case'}
    except:
        print("Failed to convert dummy_dict from CamelCase to snake_case")
        raise
