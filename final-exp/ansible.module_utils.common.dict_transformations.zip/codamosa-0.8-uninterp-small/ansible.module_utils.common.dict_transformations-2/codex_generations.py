

# Generated at 2022-06-24 20:25:29.310405
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(True, True) == True, 'Testcase 0'
    assert dict_merge({}, {}) == {}, 'Testcase 0'
    assert dict_merge({}, {'a': 1}) == {'a': 1}, 'Testcase 1'
    assert dict_merge({'a': 1}, {'a': 1}) == {'a': 1}, 'Testcase 2'
    assert dict_merge({'a': 1}, {'a': {}}) == {'a': {}}, 'Testcase 3'
    assert dict_merge({'a': 1}, {'a': {'b': 2}}) == {'a': {'b': 2}}, 'Testcase 4'

# Generated at 2022-06-24 20:25:39.174056
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 0
    test_0_dict_0 = {
        'String1': True,
        'String2': False,
        'String3': 'string',
        'String4': 'string',
        'String5': 'string',
        'String6': 'string',
        'String7': {
            'String1': True,
            'String2': False,
            'String3': 'string',
            'String4': 'string',
            'String5': 'string',
            'String6': 'string',
            'String7': [
                True,
                False,
                'string',
                'string',
                'string',
                'string'
            ]
        }
    }

# Generated at 2022-06-24 20:25:45.263227
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    bool_0 = True
    bool_1 = False
    dict_0 = {'HTTPEndpoint': bool_0, 'Path': 'ho-ho-ho', 'TargetGroupArn': 'santa-is-coming', 'Tags': {'eyes': 'blue', 'hair': 'white'}}
    dict_1 = {'http_endpoint': bool_0, 'path': 'ho-ho-ho', 'target_group_arn': 'santa-is-coming', 'tags': {'eyes': 'blue', 'hair': 'white'}}
    dict_2 = camel_dict_to_snake_dict(dict_0)
    assert dict_1 == dict_2
    dict_3 = camel_dict_to_snake_dict(dict_1, True)
    assert dict_0 == dict_3

# Generated at 2022-06-24 20:25:55.946271
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"key": "value"}) == {'key': 'value'}
    assert camel_dict_to_snake_dict({'Key': 'Value'}) == {'key': 'Value'}
    assert camel_dict_to_snake_dict({'MyKey': 'value'}) == {'my_key': 'value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}, reversible=True) == {'h_t_t_p_endpoint': 'value'}
    assert camel_dict_to_snake_dict({'MyKey': {'MySubkey': 'value'}}) == {'my_key': {'my_subkey': 'value'}}

# Generated at 2022-06-24 20:26:01.270634
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    simple_camel = {'CamelCase': 'foo'}
    simple_snake = {'camel_case': 'foo'}

    assert camel_dict_to_snake_dict(simple_camel) == simple_snake
    assert snake_dict_to_camel_dict(simple_snake) == simple_camel

    simple_camel_with_number = {'CamelCase1': 'foo'}
    simple_snake_with_number = {'camel_case1': 'foo'}

    assert camel_dict_to_snake_dict(simple_camel_with_number) == simple_snake_with_number
    assert snake_dict_to_camel_dict(simple_snake_with_number) == simple_camel_with_number

    more_complex_camel

# Generated at 2022-06-24 20:26:10.344501
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict_merge({'Param1': 'Val1', 'Param2': 'Val2'}, {'Param3': 'Val3', 'Param4': 'Val4'})
    dict_1 = dict_merge({'Param1': 'Val1', 'Param2': 'Val2'}, {'Param3': 'Val3', 'Param4': 'Val4'})
    dict_2 = dict_merge({'Param1': 'Val1', 'Param2': 'Val2'}, {'Param3': 'Val3', 'Param4': 'Val4'})
    dict_3 = dict_merge({'Param1': 'Val1', 'Param2': 'Val2'}, {'Param3': 'Val3', 'Param4': 'Val4'})
    dict_0 = camel_dict_to_snake_dict

# Generated at 2022-06-24 20:26:20.057279
# Unit test for function dict_merge
def test_dict_merge():
    d_0 = {"k0": "v0"}
    d_1 = {"k1": "v1", "k_obj": {"k_ov0":"v_ov0", "k_ov1":"v_ov1"}}
    d_2 = {"k2": "v2", "k_obj": {"k_ov0":"v_ov0_v2"}}
    d_3 = dict_merge(d_1, d_2)

    assert d_3 == {"k1": "v1", "k2": "v2", "k_obj": {"k_ov0":"v_ov0_v2", "k_ov1":"v_ov1"}}

    d_3 = dict_merge(d_2, d_1)

# Generated at 2022-06-24 20:26:30.863281
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:26:41.668662
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': True}, reversible=True) == {'foo_bar': True}
    assert camel_dict_to_snake_dict({'fooBar': True, 'aPPL': 'bAr'}, reversible=True) == {'foo_bar': True, 'a_p_p_l': 'bAr'}
    assert camel_dict_to_snake_dict({'thisIs': [{'dict': True, 'with_snake_keys': True}]}, reversible=True) == {'this_is': [{'dict': True, 'with_snake_keys': True}]}

# Generated at 2022-06-24 20:26:43.821574
# Unit test for function dict_merge
def test_dict_merge():
    main, update = dict(), dict()
    curr_result = dict_merge(main, update)
    assert not curr_result



# Generated at 2022-06-24 20:26:55.693012
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 5
        }
    }
    dict2 = {
        'a': 1,
        'b': 0,
        'c': {
            'd': 3,
            'e': 4,
            'f': 0
        }
    }

    left_dict, right_dict = recursive_diff(dict1, dict2)
    assert left_dict['b'] == 2
    assert right_dict['b'] == 0
    assert left_dict['c']['f'] == 5
    assert right_dict['c']['f'] == 0

# Generated at 2022-06-24 20:27:04.344569
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'foo': 'bar'}, {'foo': 'baz'}) == ({'foo': 'bar'}, {'foo': 'baz'})
    assert recursive_diff({'foo': 'bar'}, {'baz': 'baz'}) == ({'foo': 'bar'}, {'baz': 'baz'})
    assert recursive_diff({'foo': 'bar', 'baz': 'baz'}, {}) == ({'foo': 'bar', 'baz': 'baz'}, {})
    assert recursive_diff({'foo': 'bar'}, {'foo': 'bar'}) is None

# Generated at 2022-06-24 20:27:05.858090
# Unit test for function recursive_diff
def test_recursive_diff():

    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError to be raised')

# Generated at 2022-06-24 20:27:06.448840
# Unit test for function recursive_diff
def test_recursive_diff():
    pass



# Generated at 2022-06-24 20:27:10.473718
# Unit test for function recursive_diff
def test_recursive_diff():
    diff = recursive_diff({
        "a": {"b": 1},
        "c": 2},
        {
            "a": {"d": 3},
            "c": 2})
    print(diff)
    assert diff == ({'a': {'b': 1}}, {'a': {'d': 3}})

# Generated at 2022-06-24 20:27:13.310129
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TargetGroupArn': 'tg-arn'}

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == {'target_group_arn': 'tg-arn'}



# Generated at 2022-06-24 20:27:23.629778
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    example_dromedary_dict = {
        'fooBar': {
            'baz': 'qux',
            'quux': [
                'quuz',
            ],
        },
        'corgeGrault': [
            'garply',
        ],
    }
    expected_snake = {
        'foo_bar': {
            'baz': 'qux',
            'quux': [
                'quuz',
            ],
        },
        'corge_grault': [
            'garply',
        ],
    }
    assert (camel_dict_to_snake_dict(example_dromedary_dict) == expected_snake)
    assert (camel_dict_to_snake_dict(expected_snake) == expected_snake)



# Generated at 2022-06-24 20:27:28.075864
# Unit test for function recursive_diff
def test_recursive_diff():
    bool_0 = True
    bool_1 = False
    var_0 = dict_merge(bool_0, bool_0)


# Generated at 2022-06-24 20:27:35.088635
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'Username': 'jane.doe', 'PaginationConfig': {'MaxItems': 10}, 'Tags': {'tag': 'value'},
                  'ConfigKey1': 'ConfigValue1'}
    expected_snake_dict = {'username': 'jane.doe',
                           'pagination_config': {'max_items': 10},
                           'tags': {'tag': 'value'},
                           'config_key1': 'ConfigValue1'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == expected_snake_dict



# Generated at 2022-06-24 20:27:42.357189
# Unit test for function recursive_diff
def test_recursive_diff():

    example_dict_1 = {
        'foo': 'bar',
        'baz': 'boz',
        'dict': {
            'a': 'b',
            'b': ['c', 'd', 'e'],
            'c': {
                'd': 'e',
            }
        },
        'silly': 'willy',
    }
    example_dict_2 = {
        'baz': 'boz',
        'dict': {
            'a': 'b',
            'b': ['c', 'd', 'e', 'f'],
            'c': {
                'd': 'zzzy',
            },
            'g': 'h',
        },
        'silly': 'willy',
    }

# Generated at 2022-06-24 20:27:53.805547
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Tests
    str_0 = '$#RZ,i^.6mY}6'
    str_1 = str_0
    str_2 = str_1
    str_3 = str_2
    # str_4 = json.loads(str_0)
    # str_5 = json.load(str_0)
    # str_6 = json.dumps(str_0)
    # str_7 = json.dump(str_0)
    # str_8 = yaml.load(str_0)
    # str_9 = yaml.load_all(str_0)
    # str_10 = yaml.dump(str_0)
    # str_11 = yaml.safe_load(str_0)
    # str_12 = yaml.safe_dump(str_0)


# Generated at 2022-06-24 20:28:01.691285
# Unit test for function recursive_diff
def test_recursive_diff():
    # Generate expected result
    expected_result = (
        {},
        {
            'default_cooldown': 90,
            'desired_capacity': 2,
            'health_check_type': 'EC2',
            'max_size': 2,
            'min_elb_capacity': 1,
            'min_size': 2,
            'protect_from_scale_in': False,
            'tags': {'k1': 'v1', 'k2': 'v2'},
            'termination_policies': [],
            'wait_for_capacity_timeout': 300
        }
    )

    # Generate function input

# Generated at 2022-06-24 20:28:06.534212
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result_0 = camel_dict_to_snake_dict('camel_dict_to_snake_dict')
    print(result_0)
    assert result_0 == 'camel_dict_to_snake_dict'
    result_1 = camel_dict_to_snake_dict('camelDictToSnakeDict')
    print(result_1)
    assert result_1 == 'camel_dict_to_snake_dict'
    result_2 = camel_dict_to_snake_dict('CamelDictToSnakeDict')
    print(result_2)
    assert result_2 == 'camel_dict_to_snake_dict'
    result_3 = camel_dict_to_snake_dict('Camel2Dict2To2Snake2Dict')

# Generated at 2022-06-24 20:28:18.341024
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from module_utils.ec2 import camel_dict_to_snake_dict

    snake_in = {'HTTPEndpoint': {'Path': '/', 'Protocols': ['HTTP', 'HTTPS'], 'TimeoutInSeconds': 90},
                'Enabled': False}
    snake_out = {'h_t_t_p_endpoint': {'path': '/', 'protocols': ['HTTP', 'HTTPS'], 'timeout_in_seconds': 90},
                 'enabled': False}
    assert snake_out == camel_dict_to_snake_dict(snake_in)

    camel_in = {'HTTPEndpoint': {'Path': '/', 'Protocols': ['HTTP', 'HTTPS'], 'TimeoutInSeconds': 90},
                'Enabled': False}

# Generated at 2022-06-24 20:28:29.297956
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # two-way conversion of a camelized dict
    str_0 = 't2PG.<](pa5}un'
    var_0 = {'fooBar': 1, 'fooBaz': 2, 'foo': {}}
    var_1 = {'foo_bar': 1, 'foo_baz': 2, 'foo': {}}
    var_2 = camel_dict_to_snake_dict(var_0, reversible=True)
    var_3 = camel_dict_to_snake_dict(var_2, reversible=True)
    var_4 = var_0 == var_3
    var_5 = camel_dict_to_snake_dict(var_0)
    assert var_5 == var_1 and var_4

    # lists

# Generated at 2022-06-24 20:28:32.612708
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    func = camel_dict_to_snake_dict

    assert func is not None

# Generated at 2022-06-24 20:28:34.366912
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print("Testing camel_dict_to_snake_dict...")

    test_case_0()


# Generated at 2022-06-24 20:28:42.229757
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Set up test parameters
    dict_0 = dict()
    dict_0['dict_0_key_0'] = 'dict_0_val_0'
    dict_0['dict_0_key_1'] = 'dict_0_val_1'
    dict_0['dict_0_key_2'] = 'dict_0_val_2'
    dict_0['dict_0_key_3'] = 'dict_0_val_3'
    dict_0['dict_0_key_4'] = 'dict_0_val_4'
    dict_1 = dict()
    dict_1['dict_1_key_0'] = 'dict_1_val_0'
    dict_1['dict_1_key_1'] = 'dict_1_val_1'

# Generated at 2022-06-24 20:28:50.891356
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = camel_dict_to_snake_dict({
        'HTTPEndpoint': {
            'Enabled': True,
            'Endpoint': 'https://your_domain.com/'
        },
        'Tags': {
            'key': 'value'
        }
    })

    expected = {
        'h_t_t_p_endpoint': {
            'enabled': True,
            'endpoint': 'https://your_domain.com/'
        },
        'tags': {
            'key': 'value'
        }
    }

    assert snake_dict == expected



# Generated at 2022-06-24 20:29:00.704737
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case for function camel_dict_to_snake_dict
    str_0 = 't2PG.<](pa5}un'
    var_0 = dict()
    var_0['t2_p_g'] = '.'
    var_0['`'] = '<'
    var_0['('] = ']'
    var_0['pa5'] = '}'
    var_0['un'] = 0

    var_1 = dict()
    var_1['t2_p_g'] = '.'
    var_1['<'] = '['
    var_1['pa5'] = '}'
    var_1['un'] = 0
    assert var_0 == camel_dict_to_snake_dict(str_0)
    assert var_1 == camel_dict_to_snake_

# Generated at 2022-06-24 20:29:15.971035
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 5}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'c': {'e': 4}}, {'c': {'e': 5}})

    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dict2 = {'b': 2, 'c': {'d': 3, 'e': 5}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': 1}, {})


# Generated at 2022-06-24 20:29:20.761077
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 't2PG.<](pa5}un'
    str_1 = 'un]{5ap.(<G2Pt'
    var_0 = camel_dict_to_snake_dict(str_0)
    var_1 = var_0
    var_2 = var_0
    assert var_1 == str_1
    assert var_2 == str_1


# Generated at 2022-06-24 20:29:31.288201
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # keys
    camel_dict = {'HTTPEndpoint': 'value1', 'tags': {'key2': 'value2', 'K': 'V'}}
    snake_dict = {'h_t_t_p_endpoint': 'value1', 'tags': {'key2': 'value2', 'K': 'V'}}
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)

    # keys with capitalize_first set to True
    camel_dict = {'HTTPEndpoint': 'value1', 'tags': {'key2': 'value2', 'K': 'V'}}
    snake_dict = {'H_t_t_p_endpoint': 'value1', 'tags': {'key2': 'value2', 'K': 'V'}}
    assert snake_dict == camel

# Generated at 2022-06-24 20:29:38.084557
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # AssertionError: 't_2_p_g_._<>_]_(_p_a5_}_u_n' != 't_2_p_g_._<_]_(p_a5_}_u_n'
    # assert camel_dict_to_snake_dict('t2PG.<](pa5}un') == 't_2_p_g_._<_(p_a5_}_u_n'
    pass

# Generated at 2022-06-24 20:29:47.491096
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:55.887295
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {
        'test_parameter_0': 'test_value_0',
        'testParameter1': 'test_value_1',
        'TestParameter2': 'test_value_2',
        'TestParameter3': {
            'testParameter4': 'test_value_3',
            'testParameter5': 'test_value_4'
        },
        'TestParameter6': [
            'test_value_5',
            'test_value_6',
        ]
    }


# Generated at 2022-06-24 20:30:04.705063
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_0 = {
        'type': 'HTTP',
        'HTTPEndpoint': 'http://localhost:8080',
        'Authorization' : {
            'AWS4-HMAC-SHA256' : {
                'SignedHeaders' : '',
                'Signature' : ''
            }
        },
        'EndpointConfiguration': 'REGIONAL'
    }


# Generated at 2022-06-24 20:30:16.262618
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    arg_0 = "http_endpoint"
    arg_1 = "httpEndpoint"
    arg_2 = {
         "HttpEndpoint": "http_endpoint"
     }

    test_camel_dict_to_snake_dict_inner(arg_0, arg_1, arg_2)

    arg_0 = "http_endpoint"
    arg_1 = "HTTPEndpoint"
    arg_2 = {
         "HttpEndpoint": "h_t_t_p_endpoint"
     }

    test_camel_dict_to_snake_dict_inner(arg_0, arg_1, arg_2, True)

    arg_0 = "http_endpoint"
    arg_1 = "HTTPENDPOINT"

# Generated at 2022-06-24 20:30:21.537494
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 't2PG.<](pa5}un'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == 't2_p_g._<](pa5}un'


# Generated at 2022-06-24 20:30:31.147079
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Testing for equality with a dict
    var_0 = 'user'
    dict_0 = {'firstName': 'John', 'lastName': 'Smith', 'email': 'john.smith@mail.com', 'userName': 'jsmith', 'password': 'password'}
    var_1 = camel_dict_to_snake_dict(dict_0)
    # Testing for equality with a dict
    dict_0 = '12345678'
    dict_1 = {'firstName': 'John', 'lastName': 'Smith', 'email': 'john.smith@mail.com', 'userName': 'jsmith', 'password': 'password'}
    var_2 = camel_dict_to_snake_dict(dict_1, ignore_list=(dict_0,))


# Generated at 2022-06-24 20:30:45.246975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'snake_case_example' == camel_dict_to_snake_dict('snakeCaseExample')
    assert 'snake_case_example' == camel_dict_to_snake_dict('snakeCaseExample')
    assert 'snake_case_example' == camel_dict_to_snake_dict('snakeCaseExample')
    assert 'snake_case_example' == camel_dict_to_snake_dict('snakeCaseExample')
    assert 'camel_case_example' == camel_dict_to_snake_dict('camelCaseExample')
    assert 'number_123_example' == camel_dict_to_snake_dict('number123Example')
    assert 'snake_case_example' == camel_dict_to_snake_dict('snake_case_example')

# Generated at 2022-06-24 20:30:53.362987
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_0['a'] = dict_1
    dict_0['c'] = dict_0['a']
    dict_0['b'] = dict_0['c']
    dict_0['a']['a'] = dict_0['b']
    dict_0['a']['c'] = dict_0['a']
    dict_0['a']['b'] = dict_0['b']
    dict_0['c']['a'] = dict_0['b']
    dict_0['c']['c'] = dict_1
    dict_0['c']['b'] = dict_1
    dict_0['b']['a'] = dict_0['a']
    dict_0['b']['c'] = dict_

# Generated at 2022-06-24 20:31:03.268514
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 't2PG.<](pa5}un'
    var_0 = camel_dict_to_snake_dict(str_0)
    print('Unit test for function camel_dict_to_snake_dict')
    print('Test:', 'camel_dict_to_snake_dict({})'.format(str_0))
    print('Expect:', 'TypeError')
    print('Output:', var_0)
    print('--' * 20)

# Generated at 2022-06-24 20:31:04.132669
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True


# Generated at 2022-06-24 20:31:05.158866
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_case_0()



# Generated at 2022-06-24 20:31:14.782069
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:21.443151
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:24.523253
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un') == 't2pg.<](pa5}un'



# Generated at 2022-06-24 20:31:33.122073
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un') == 't2_p_g._<](pa5}un'
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un', reversible=True) == 't2_p_g._<](pa5}un'
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un', reversible=False) == 't2_p_g._<](pa5}un'


# Generated at 2022-06-24 20:31:42.294139
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:53.690476
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Example python code
    str_0 = 't2PG.<](pa5}un'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert str_0 == 't2PG.<](pa5}un'


# Generated at 2022-06-24 20:32:01.630628
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:12.393745
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_1 = 'snake_dict_to_camel_dict_capitalize_first_false'
    str_2 = 'snake_dict_to_camel_dict'
    str_3 = 'camel_dict_to_snake_dict_reversible_true'
    str_4 = 'camel_dict_to_snake_dict'
    var_1 = camel_dict_to_snake_dict(str_1, True, ['list', 'is', 'here'])
    var_2 = camel_dict_to_snake_dict(str_2, False, ['list', 'is', 'here'])
    var_3 = camel_dict_to_snake_dict(str_3, True, ['list', 'is', 'here'])
    var_4 = camel_dict_to_sn

# Generated at 2022-06-24 20:32:20.550092
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un') == {'t2_p_g': '<](pa5}un'}
    assert camel_dict_to_snake_dict('[Z{Gm9<f^&A]6U') == {'[z_g_m9<f^': '&a]6u'}
    assert camel_dict_to_snake_dict('^2_NE;{ijB7&#.') == {'^2_n_e;{ij_b7': '&#.'}
    assert camel_dict_to_snake_dict('f7<9(J*&6PBg]Y$}m') == {'f7<9(j*': '&6_p_bg]y$}m'}
   

# Generated at 2022-06-24 20:32:31.704984
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    v_0 = {
        'abc': {
            'def': 'ghi',
            'jkl': 'mno',
            'pqr': 'stu'
        },
        'vwx': 'yz'
    }
    v_1 = {
        'abc': {
            'def': 'ghi',
            'jkl': 'mno',
            'pqr': 'stu'
        },
        'vwx': 'yz'
    }
    v_2 = {
        'abc': {
            'def': 'ghi',
            'jkl': 'mno',
            'pqr': 'stu'
        },
        'vwx': 'yz'
    }

# Generated at 2022-06-24 20:32:37.666608
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_0 = {'endpoint_url': 'https://sqs.eu-central-1.amazonaws.com/933372895492/', 'region_name': 'eu-central-1'}
    snake_dict_0 = camel_dict_to_snake_dict(camel_dict_0)

    # Check if created event is as expected
    #assert expected_event == current_event
    print("Function returned expected value")
    return True



# Generated at 2022-06-24 20:32:47.021058
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {
        "fooBarBax": "baz",
        "BarBarBar": [
            {
                "fooBar": "baz",
                "BarBar": [
                    {
                        "fooBar": "baz",
                        "BarBar": {
                            "fooBar": "baz"
                        }
                    }
                ]
            },
            {
                "fooBar": "baz",
                "BarBar": [
                    {
                        "fooBar": "baz",
                        "BarBar": {
                            "fooBar": "baz"
                        }
                    }
                ]
            }
        ]
    }


# Generated at 2022-06-24 20:32:49.029466
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(str_0) == var_0


# Generated at 2022-06-24 20:32:55.661171
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        'a': 1,
        'B': 2,
        'c': [
            {
                'D': 3,
                'e': [
                    {
                        'f': 4
                    }
                ]
            },
            5
        ],
        'G': {
            'H': 6,
            'i': 7
        },
        'J': 8,
        'K': {
            'L': 9,
            'M': 10
        }
    }

# Generated at 2022-06-24 20:33:00.983731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert callable(camel_dict_to_snake_dict), "Function 'camel_dict_to_snake_dict' not defined"
    assert isinstance(camel_dict_to_snake_dict(dict), type({})), "Function 'camel_dict_to_snake_dict' not returning dictionary"


# Generated at 2022-06-24 20:33:31.667347
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = {'foo': {'bar': 'baz'}}
    str_1 = {'foo': {'bar': 'baz'}}
    assert camel_dict_to_snake_dict(str_0) == str_1

    str_0 = {'foo': {'bar': 'baz', 'camel_case': 'is_cool'}}
    str_1 = {'foo': {'bar': 'baz', 'camel_case': 'is_cool'}}
    assert camel_dict_to_snake_dict(str_0) == str_1

    str_0 = {'foo': {'bar': 'baz', 'camelCase': 'isCool'}}
    str_1 = {'foo': {'bar': 'baz', 'camel_case': 'is_cool'}}

# Generated at 2022-06-24 20:33:37.163547
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un') is None


# Generated at 2022-06-24 20:33:43.924844
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert ('abc' == camel_dict_to_snake_dict('Abc')), \
        "camel_dict_to_snake_dict function failed with input Abc"
    assert ('ab_cd' == camel_dict_to_snake_dict('AbCd')), \
        "camel_dict_to_snake_dict function failed with input AbCd"
    assert ('ab_cd_efg' == camel_dict_to_snake_dict('AbCdEFG')), \
        "camel_dict_to_snake_dict function failed with input AbCdEFG"


# Generated at 2022-06-24 20:33:46.668916
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str = 't2PG.<](pa5}un'
    snake_dict = camel_dict_to_snake_dict(str)
    print(snake_dict)



# Generated at 2022-06-24 20:33:53.553204
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = { 'HTTPEndpoint': '_http_endpoint', 'ContainerPortMappings': '_container_port_mappings', 'DesiredStatus': '_desired_status', 'ContainerName': '_container_name', 'TaskArn': '_task_arn' }
    str_1 = { 'Task': '_task' }
    str_2 = { 'Cluster': '_cluster' }
    test = { 'Cluster': '_cluster', 'Task': '_task', 'Containers': [ { 'HTTPEndpoint': '_http_endpoint', 'ContainerPortMappings': '_container_port_mappings', 'DesiredStatus': '_desired_status', 'ContainerName': '_container_name', 'TaskArn': '_task_arn' } ] }

# Generated at 2022-06-24 20:34:02.704308
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = 't2PG.<](pa5}un'
    var_0 = camel_dict_to_snake_dict(str_0)
    str_1 = 'VF}6'
    var_1 = camel_dict_to_snake_dict(str_1)
    str_2 = '+1C/[t'
    var_2 = camel_dict_to_snake_dict(str_2)
    str_3 = '((9>'
    var_3 = camel_dict_to_snake_dict(str_3)
    str_4 = 'J9D'
    var_4 = camel_dict_to_snake_dict(str_4)
    str_5 = 'V.*-wo^@2'
    var_5 = camel_dict_to_snake_

# Generated at 2022-06-24 20:34:05.216087
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('t2PG.<](pa5}un') == 't2_p_g_._.<]_(_p_a5}un'



# Generated at 2022-06-24 20:34:13.457190
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:34:25.923034
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {"endpointName": "example-endpoint",
            "endpointUrl": "example.endpoint.com",
            "monitoringRoleArn": "arn:aws:iam::123456789012:role/service-role/AmazonSageMaker-ExecutionRole-20190805T131256",
            "tags": {"foo": "bar"}}
    new_data = {"endpoint_name": "example-endpoint",
                "endpoint_url": "example.endpoint.com",
                "monitoring_role_arn": "arn:aws:iam::123456789012:role/service-role/AmazonSageMaker-ExecutionRole-20190805T131256",
                "tags": {"foo": "bar"}}
    assert camel_dict_to_snake_dict(data) == new_data


# Generated at 2022-06-24 20:34:37.125136
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(['t2PG.<](pa5}un']) == ['t2PG.<](pa5}un']
    assert camel_dict_to_snake_dict(['wgJ*h.W(6_q3!;']) == ['wgJ*h.W(6_q3!;']
    assert camel_dict_to_snake_dict(['q3U.N6Y>i/Q_|c']) == ['q3U.N6Y>i/Q_|c']
    assert camel_dict_to_snake_dict(['8|>#{CNd.fT~g<']) == ['8|>#{CNd.fT~g<']

# Generated at 2022-06-24 20:35:06.091884
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test for simple case
    my_dict = {'key1': 'hello', 'key2': {'key3': 'world'}}
    result = camel_dict_to_snake_dict(my_dict)
    assert(result['key1'] == 'hello')
    assert(result['key2']['key_3'] == 'world')

    # test for reversible case
    my_dict = {'HTTPEndpoint': 'hello', 'key2': {'key3': 'world'}}
    result = camel_dict_to_snake_dict(my_dict, True)
    assert(result['h_t_t_p_endpoint'] == 'hello')
    assert(result['key2']['key_3'] == 'world')

    # test for nested case

# Generated at 2022-06-24 20:35:14.889477
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.aws.core import AnsibleAWSModule

    module = AnsibleAWSModule(argument_spec={})

    tests = [
        ("MyVpcId", "my_vpc_id"),
        ("MyVpcIdFoo", "my_vpc_id_foo"),
        ("myVpcIdFoo", "my_vpc_id_foo"),
        ("myVpcIdXFoo", "my_vpc_id_x_foo"),
    ]

    for test in tests:
        assert _camel_to_snake(test[0]) == test[1], "Checking snake case conversion"
        assert _snake_to_camel(test[1]) == test[0], "Checking camel case conversion"
