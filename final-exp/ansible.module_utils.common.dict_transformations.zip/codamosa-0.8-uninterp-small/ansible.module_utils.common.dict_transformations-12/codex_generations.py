

# Generated at 2022-06-24 20:25:38.967512
# Unit test for function dict_merge
def test_dict_merge():
    d_0 = {'a':1, 'b': [1,2,3], 'c': 3}
    d_1 = {'a':2, 'b': [1,2,3], 'e': 4}
    res_0 = dict_merge(d_0, d_1)
    assert res_0 == {'a': 2, 'b': [1, 2, 3], 'c': 3, 'e': 4}

    d_0 = {'a':1, 'b': [1,2,3], 'c': 3}
    d_1 = {'a':2, 'b': [1,2,3], 'c': {'e':4}}
    res_0 = dict_merge(d_0, d_1)

# Generated at 2022-06-24 20:25:40.123548
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    args_0 = {}
    camel_dict_to_snake_dict(args_0)

# Generated at 2022-06-24 20:25:45.933415
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict()
    dict2 = dict()
    dict1['test'] = None
    dict2['testing'] = None
    dict1['foo'] = dict()
    dict2['foo'] = dict()
    dict1['foo']['bar'] = None
    dict1['foo']['baz'] = None
    dict2['foo']['bar'] = None
    dict2['foo']['baz'] = None
    dict2['foo']['biz'] = None
    dict1['foo']['answer'] = None
    dict2['foo']['answer'] = 42
    dict2['foo']['fizz'] = 'buzz'
    dict1['foo']['deeper'] = dict()
    dict2['foo']['deeper'] = dict()

# Generated at 2022-06-24 20:25:54.073545
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(None) == None
    str_0 = '{}'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == {}
    str_1 = '{"DBInstanceIdentifier": "test"}'
    var_1 = camel_dict_to_snake_dict(str_1)
    assert var_1 == {'db_instance_identifier': 'test'}


# Generated at 2022-06-24 20:26:01.034550
# Unit test for function recursive_diff
def test_recursive_diff():
    str_0 = b'https://github.com'
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    dict_1 = {'a': '1', 'c': 3, 'b': 3}
    str_1 = 'https://github.com'
    str_2 = 'https://github.com'
    dict_2 = {'a': 1, 'c': 3, 'b': 2}
    dict_3 = {'a': 1, 'c': 3, 'b': 3}
    dict_4 = {'a': 1, 'c': 3, 'b': 2}
    dict_5 = {'a': 1, 'b': 2, 'c': 3}
    dict_6 = {'a': 1, 'b': 2, 'c': 3}
    dict_7

# Generated at 2022-06-24 20:26:10.160306
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict1 = {
        'first_key': 'first_value',
        'second_key': {
            'third_key': 'third_value',
            'fourth_key': 'fourth_value'
        },
        'fifth_key': 'sixth_value'
    }

    test_dict2 = {
        'first_key': 'first_value',
        'second_key': {
            'third_key': 'third_value',
            'fourth_key': 'fourth_value'
        },
        'fifth_key': 'fifth_value'
    }

    result = recursive_diff(test_dict1, test_dict2)
    expected = ({'fifth_key': 'fifth_value'}, {'fifth_key': 'sixth_value'})

    assert result == expected



# Generated at 2022-06-24 20:26:19.917529
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'instance_type': 't2.nano',
        'security_groups': [
            'group1',
            'group2'
        ],
        'block_device_mappings': [
            {
                'device_name': '/dev/sda1',
                'ebs': {
                    'delete_on_termination': True,
                    'volume_size': 8,
                    'volume_type': 'gp2'
                }
            }
        ],
        'image_id': 'ami-d0f506b0',
        'key_name': 'Some Key',
        'monitoring': True
    }

# Generated at 2022-06-24 20:26:30.698242
# Unit test for function dict_merge
def test_dict_merge():
    dict_0 = dict({'a': dict({'b': 1, 'c': 2})})
    dict_0.update(dict({'a': dict({'d': 3, 'e': 4})}))
    dict_1 = dict({'a': dict({'b': 1, 'c': 2}), 'b': dict({'d': 4, 'e': 5})})
    dict_2 = dict({'b': dict({'d': 4, 'e': 5})})

    dict_merge_result = dict_merge(dict_1, dict_2)
    dict_merge_expected = dict({'a': dict({'b': 1, 'c': 2}), 'b': dict({'d': 4, 'e': 5})})
    assert dict_merge_result == dict_merge_expected

    dict_

# Generated at 2022-06-24 20:26:41.163387
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('Classic') == 'classic'
    assert _camel_to_snake('HTTPSecurityPolicy') == 'http_security_policy'
    assert _camel_to_snake('IPSetReferenceStatement') == 'i_p_set_reference_statement'
    assert _camel_to_snake('DiscoveredPortal') == 'discovered_portal'
    assert _camel_to_snake('TlsConfigurationAction') == 'tls_configuration_action'
    assert _camel_to_snake('DescribeListenerRequest') == 'describe_listener_request'
    assert _camel_to_snake('HTTPSecurityPolicy') == 'http_security_policy'

# Generated at 2022-06-24 20:26:47.792309
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'Name': 'foo',
        'SubnetGroups': {
            'Name': 'foo_subnet',
        },
    }
    dict2 = {
        'Name': 'bar',
        'SubnetGroups': {
            'Name': 'bar_subnet',
        },
    }
    output = ({'Name': 'foo'}, {'Name': 'bar'})
    assert recursive_diff(dict1, dict2) == output



# Generated at 2022-06-24 20:27:00.944163
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{"DryRun": False, "Type": "AWS::EC2::Route", "Properties": {"DestinationCidrBlock": "10.0.0.0/16", "RouteTableId": "rtb-12345678", "NetworkInterfaceId": "eni-d78a2f92"}}'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert (var_0 == '{"dry_run": False, "type": "AWS::EC2::Route", "properties": {"destination_cidr_block": "10.0.0.0/16", "route_table_id": "rtb-12345678", "network_interface_id": "eni-d78a2f92"}}')


# Generated at 2022-06-24 20:27:06.743560
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 1}}) == {'foo_bar': {'baz': 1}}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 1}}, reversible=True) == {'foo_b_a_r': {'baz': 1}}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 1}}, ignore_list=['fooBar']) == {'foo_bar': {'baz': 1}}


# Generated at 2022-06-24 20:27:14.963749
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Testing a dict with a dict as a value
    dict_0 = {'KeyName': 'ansible-key', 'SecurityGroups': {'GroupName': 'default'}}
    var_0 = camel_dict_to_snake_dict(dict_0)
    assert var_0 == {'key_name': 'ansible-key', 'security_groups': {'group_name': 'default'}}

    # Testing a dict with a list of dicts as a value
    dict_1 = {'SecurityGroups': [{'GroupName': 'default'}]}
    var_1 = camel_dict_to_snake_dict(dict_1)
    assert var_1 == {'security_groups': [{'group_name': 'default'}]}

    # Testing a dict with a subdict (under 'Tags')
    dict

# Generated at 2022-06-24 20:27:24.760018
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = {'keyA': {'keyB': {'keyC': 'valC'}, 'keyD': 'valD'}, 'keyE': 'valE'}
    var_0 = camel_dict_to_snake_dict(str_0)
    assert set(var_0.keys()) == {"key_a", "key_e"}
    assert set(var_0["key_a"].keys()) == {"key_b", "key_d"}
    assert set(var_0["key_a"]["key_b"].keys()) == {"key_c"}
    assert var_0["key_a"]["key_b"]["key_c"] == 'valC'
    assert var_0["key_a"]["key_d"] == 'valD'

# Generated at 2022-06-24 20:27:35.455195
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    clean_val = {'fooBar': 'hello', 'bazFooBar': [{'fooBar': 'battery', 'bazFooBar': 'staple'}]}
    result = camel_dict_to_snake_dict(clean_val)
    assert result == {'foo_bar': 'hello', 'baz_foo_bar': [{'foo_bar': 'battery', 'baz_foo_bar': 'staple'}]}
    dirty_canonical = {'FooBar': 'hello', 'BazFooBar': [{'FooBar': 'battery', 'BazFooBar': 'staple'}]}
    result = camel_dict_to_snake_dict(dirty_canonical)

# Generated at 2022-06-24 20:27:45.260713
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{}'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert var_0 == '{}'
    str_1 = "{'TagFilters': [{'Values': ['test1'], 'Key': 'test2'}], 'ResourceIds': ['test3'], 'ResourceType': 'test4'}"
    var_1 = camel_dict_to_snake_dict(str_1)
    assert var_1 == "{'tag_filters': [{'values': ['test1'], 'key': 'test2'}], 'resource_ids': ['test3'], 'resource_type': 'test4'}"
    str_2 = "{'Values': ['test1'], 'Key': 'test2'}"
    var_2 = camel_dict_to

# Generated at 2022-06-24 20:27:52.269381
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Mock the arguments
    opts = {'dry-run': False, 'delete-tags': False, 'api-request-id': 'a6a7baa5-a8a8-41a1-9b9a-a8d8c8d8f8g8', 'web-cache': False}
    opts = camel_dict_to_snake_dict(opts)

    # Execution
    assert opts['api_request_id'] == 'a6a7baa5-a8a8-41a1-9b9a-a8d8c8d8f8g8'
    assert opts['dry_run'] == False
    assert opts['delete_tags'] == False
    assert opts['web_cache'] == False



# Generated at 2022-06-24 20:27:53.397232
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert test_case_0() if 'test_case_0' in globals() else None


# Generated at 2022-06-24 20:28:01.257375
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = ''
    var_0 = camel_dict_to_snake_dict(str_0)
    if not var_0:
        raise AssertionError("Expected {}, got {}".format(True, False))
    str_1 = 'string'
    var_1 = camel_dict_to_snake_dict(str_1)
    if not var_1:
        raise AssertionError("Expected {}, got {}".format(True, False))
    str_2 = 0
    var_2 = camel_dict_to_snake_dict(str_2)
    if not var_2:
        raise AssertionError("Expected {}, got {}".format(True, False))
    str_3 = 0.0

# Generated at 2022-06-24 20:28:06.170248
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_0 = {'aclRule': {'acl_rule': {'key1': 'value1', 'key2': 'value2'}}, 'project_id': '12345', 'test_dict': {'test_key_a': 'test_value_a', 'test_key_b': 'test_value_b'}}
    dict_1 = {'acl_rule': {'key1': 'value1', 'key2': 'value2'}, 'project_id': '12345', 'test_dict': {'test_key_a': 'test_value_a', 'test_key_b': 'test_value_b'}}


# Generated at 2022-06-24 20:28:11.697789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = ''
    var_0 = camel_dict_to_snake_dict(str_0)
    print(var_0)

test_camel_dict_to_snake_dict()


# Generated at 2022-06-24 20:28:21.607706
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = {'Tags': [{'Key': 'Key', 'Value': 'Value'}, {'Key': 'Key', 'Value': 'Value'}, {'Key': 'Key', 'Value': 'Value'}], 'KeyName': 'KeyName', 'LaunchConfigurationName': 'LaunchConfigurationName', 'TargetGroupARNs': ['TargetGroupARNs'], 'SecurityGroups': ['SecurityGroups'], 'IAMInstanceProfile': 'IAMInstanceProfile', 'HealthCheckType': 'HealthCheckType', 'ImageId': 'ImageId', 'InstanceType': 'InstanceType', 'DesiredCapacity': 10, 'MaxSize': 10, 'MinSize': 10}
    var_0 = camel_dict_to_snake_dict(str_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 20:28:25.961756
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'FooBar': 'foo', 'TelephoneNumber': '555-1234'}
    assert camel_dict_to_snake_dict(test_dict) == {'telephone_number': '555-1234', 'foo_bar': 'foo'}


# Generated at 2022-06-24 20:28:36.626143
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = camel_dict_to_snake_dict({'aBcD': 'efgh'})
    assert var_1 == {'a_bc_d': 'efgh'}
    var_2 = camel_dict_to_snake_dict({'aBcD': 'efgh'}, True)
    assert var_2 == {'a_b_c_d': 'efgh'}
    var_3 = camel_dict_to_snake_dict({'anLists': [1, 2, 3, 'a']})
    assert var_3 == {'an_lists': [1, 2, 3, 'a']}
    var_4 = camel_dict_to_snake_dict({'anLists': [1, 2, 3, 'a']}, True)

# Generated at 2022-06-24 20:28:40.053924
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert True == True


# Generated at 2022-06-24 20:28:41.920321
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = ''
    var_0 = camel_dict_to_snake_dict(str_0)
    print(var_0)


# Generated at 2022-06-24 20:28:52.844126
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Two simple strings
    str_0 = 'This is fun'
    str_1 = 'I like eggs'
    assert str_0 == camel_dict_to_snake_dict(str_1)

    # A random list
    list_0 = [1, 2, 3, 4]
    list_1 = [5, 6, 7, 8]
    assert list_0 == camel_dict_to_snake_dict(list_1)

    # A snake_dict -> camel_dict -> snake_dict conversion
    snake_dict_0 = {'foo_bar': {'bar_baz': {'doo_dah': 1}}}
    snake_dict_1 = {'foo_bar': {'bar_baz': {'doo_dah': 2}}}
    camel_dict_0 = snake_dict_to_

# Generated at 2022-06-24 20:29:02.300184
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'ab_cd_ef' == camel_dict_to_snake_dict('ABCDEf')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('abcDefGhi')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('AbcDefGhi')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('abc_def_ghi')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('abcDefGhi')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('abc_defGhi')
    assert 'abc_def_ghi' == camel_dict_to_snake_dict('abc_def_ghi')

# Generated at 2022-06-24 20:29:11.822386
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{"key1":1,"key2":{"key2_2":2,"key2_3":{"key2_3_1":3}}}'
    var_0 = camel_dict_to_snake_dict(str_0)
    str_1 = '{"key_1":1,"key_2":{"key2_2":2,"key2_3":{"key2_3_1":3}}}'
    var_1 = str_1
    assert var_0 == var_1

if __name__ == '__main__':
    import sys
    import argparse

    test_case_0()
    test_camel_dict_to_snake_dict()

    # Parse arguments
    parser = argparse.ArgumentParser(description='Convert camelCase JSON to snake_case JSON.')
    parser.add_

# Generated at 2022-06-24 20:29:21.357539
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{"PublicAccessBlockConfiguration": {"BlockPublicAcls": true, "BlockPublicPolicy": true, "IgnorePublicAcls": true, "RestrictPublicBuckets": true}}'
    var_0 = camel_dict_to_snake_dict(str_0)
    assert(var_0 == {'public_access_block_configuration': {'block_public_acls': True, 'block_public_policy': True, 'ignore_public_acls': True, 'restrict_public_buckets': True}})

    str_1 = '{"IPAddress": "192.0.2.0", "ClasslessStaticRoute": {"DestinationCidrBlock": "192.0.2.0/24", "GatewayId": "local"}}'
    var_1 = camel_dict_to_sn

# Generated at 2022-06-24 20:29:37.352567
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_1 = {'a': 1, 'b': {'c': 3, 'd': {'e': 5, 'f': 6}}, 'g': [{'h': 8, 'i': 9}, {'j': 10, 'k': 11}]}
    var_2 = {'a': 1, 'b': {'c': 3, 'd': {'e': 5, 'f': 6}}, 'g': [{'h': 8, 'i': 9}, {'j': 10, 'k': 11}]}
    var_3 = {'a': 1, 'b': {'c': 3, 'd': {'e': 5, 'f': 6}}, 'g': [{'h': 8, 'i': 9}, {'j': 10, 'k': 11}]}

# Generated at 2022-06-24 20:29:38.806397
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    resp_0 = camel_dict_to_snake_dict(var_0)
    assert resp_0.lower() == '__call__'



# Generated at 2022-06-24 20:29:40.918756
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict("TestSSM") == "test_s_s_m"


# Generated at 2022-06-24 20:29:42.700506
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('test_String') == 'test_string'



# Generated at 2022-06-24 20:29:47.849105
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('{"TestKey": "TestValue"}') == '{"test_key": "TestValue"}'
    assert camel_dict_to_snake_dict('{}') == '{}'


# Generated at 2022-06-24 20:29:56.328642
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    print('Test function camel_dict_to_snake_dict')
    assert(camel_dict_to_snake_dict({'keyFoo': 'valueBar'}) == {'key_foo': 'valueBar'})
    assert(camel_dict_to_snake_dict({'keyFoo': 'valueBar'}, reversible=True) == {'key_f_oo': 'valueBar'})
    assert(camel_dict_to_snake_dict({'keyFoo': 'valueBar'}, ignore_list=['keyFoo']) == {'keyFoo': 'valueBar'})

# Generated at 2022-06-24 20:30:05.014571
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Try to call camel_dict_to_snake_dict with correct arguments
    # Try to call camel_dict_to_snake_dict with correct arguments
    # Try to call camel_dict_to_snake_dict with correct arguments
    var_1 = camel_dict_to_snake_dict({'InstanceIds': [], 'RegionName': 'mars'}, False)
    if var_1 != {'instance_ids': [], 'region_name': 'mars'}:
        raise AssertionError('Test failed, method did not return the correct result.')
    
    var_2 = camel_dict_to_snake_dict({'InstanceIds': [], 'RegionName': 'mars', 'Tags': {'test': []}}, False)

# Generated at 2022-06-24 20:30:16.271736
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Creating test data
    str_sample_0 = '{"aBcDeFg" : "jKlMnOp", "hijkL": {"A": "B"}}'
    str_sample_1 = '{"aBcDeFgQ" : "jKlMnOp", "hijkL": {"A": "B", "C": [{"D": "E"}]}}'
    str_sample_2 = '{"abcDefg" : "jKlMnOp", "hijkL": {"A": "B", "C": [{"D": "E"}]}}'

    # Compute result
    res_0 = camel_dict_to_snake_dict(str_sample_0)
    res_1 = camel_dict_to_snake_dict(str_sample_1)
    res_2

# Generated at 2022-06-24 20:30:26.484510
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = ''
    str_1 = '{"DefaultCoalesceWaitMs": 10, "Key": "nome"}'
    str_2 = '{"DefaultCoalesceWaitMs": 10, "Key": "nome", "value": 11, "value2": {"value": 2, "value2": 3}, "value3": [{"value": 2, "value2": 3}]}'
    str_3 = '{"DefaultCoalesceWaitMs": 10, "Key": "nome", "value": 11, "value2": {"value": 2, "value2": 3}, "value3": [{"value": 2, "value2": 3}], "Tags": {"key": "value"}}'

# Generated at 2022-06-24 20:30:34.531427
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = {'HTTPEndpoint': {'Url': 'http://localhost:80'}, 'HttpEndpoint': {'Url': 'http://localhost:80'}}
    assert {'http_endpoint': {'url': 'http://localhost:80'}, 'h_t_t_p_endpoint': {'url': 'http://localhost:80'}} == camel_dict_to_snake_dict(x, reversible=True)
    x = {'HTTPEndpoint': {'Url': 'http://localhost:80'}, 'HttpEndpoint': {'Url': 'http://localhost:80'}}

# Generated at 2022-06-24 20:30:45.633066
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict({'var_0': {'var_2': 'var_5', 'var_3': 'var_7', 'var_1': {'var_4': 'var_7'}}, 'var_6': 'var_9'}, False)
    assert result == {'var_0': {'var_2': 'var_5', 'var_3': 'var_7', 'var_1': {'var_4': 'var_7'}}, 'var_6': 'var_9'}


# Generated at 2022-06-24 20:30:47.415570
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # test case 0
    test_case_0()

    # Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-24 20:30:53.373554
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # str_0 = ''
    # var_0 = camel_dict_to_snake_dict(str_0)
    # assert var_0 == None

    dict_0 = {'foo': {'firstName': 'John', 'lastName': 'Doe'},
              'bar': [1, 2, 3],
              'HTTPEndpoint': {'IpAddress': '1.2.3.4',  'Port': 12345},
              'Tags': [{u'Value': u'foobar', u'Key': u'Name'},
                       {u'Value': u'arn:aws:iam::999999999999:role/test-admin-role', u'Key': u'Role'}]
              }


# Generated at 2022-06-24 20:30:57.596141
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    str_0 = '{"Globals": {"EcsParameters": {"Cluster": "poc-cluster-ecs"}}}'
    var_0 = camel_dict_to_snake_dict(str_0)

    assert var_0 == {"globals": {"ecs_parameters": {"cluster": "poc-cluster-ecs"}}}

# Generated at 2022-06-24 20:31:01.275103
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result_0 = camel_dict_to_snake_dict(str_0, False, ())
    assert result_0 is None
    result_1 = camel_dict_to_snake_dict(str_0, True, ())
    assert result_1 is None


# Generated at 2022-06-24 20:31:10.700971
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test with simple dictionary
    str_0 = {'fooBarBaz': 'value'}
    assert camel_dict_to_snake_dict(str_0) == {'foo_bar_baz': 'value'}
    # Test nested dictionaries
    str_1 = {'fooBarBaz': {'bazFooBar': 'value'}}
    assert camel_dict_to_snake_dict(str_1) == {'foo_bar_baz': {'baz_foo_bar': 'value'}}
    # Test with list in dictionary
    str_2 = {'fooBarBaz': {'bazFooBar': ['value']}}

# Generated at 2022-06-24 20:31:17.099499
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint", reversible=True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("h_t_t_p_endpoint", reversible=True) == "http_endpoint"
    assert _camel_to_snake("TargetGroupARNs") == "target_group_arns"
    assert _camel_to_snake("TargetGroupARNs", reversible=True) == "t_a_r_g_e_t_g_r_o_u_p_a_r_n_s"

# Generated at 2022-06-24 20:31:27.840829
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:38.502619
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Tests for non-reversible conversion
    # ===================================

    # Unit test for function camel_dict_to_snake_dict
    # An empty dictionary is returned unchanged
    try:
        str_0 = {}
        var_0 = camel_dict_to_snake_dict(str_0)
        assert var_0 == {}, "Test 0: '{}' != {}"
    except AssertionError as e:
        print(e)
    except Exception as e:
        print(e)
    else:
        print("Test 0: " + "ok")

    # Unit test for function camel_dict_to_snake_dict
    # A dictionary with a single pair is returned unchanged

# Generated at 2022-06-24 20:31:49.052768
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test the case where a dict has empty keys
    dict_0 = {'key_1': 'value_0', 'key_2': 'value_1'}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    assert dict_1['key_1'] == 'value_0'

    # Test the case where a dict has a capital letter as the first character
    dict_0 = {'Key_1': 'value_0', 'Key_2': 'value_1'}
    dict_1 = camel_dict_to_snake_dict(dict_0)
    assert dict_1['key_1'] == 'value_0'
    assert dict_1['key_2'] == 'value_1'

    # Test the case where a dict has a capital letter in the middle of the key
    dict

# Generated at 2022-06-24 20:32:11.852116
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:20.107801
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = {
        'member1': 'value1',
        'member2': 'value2',
        'member3': 'value3',
        'member4': 'value4'
    }
    dict_1 = {
        'member1': 'value1',
        'member2': 'value2',
        'member3': 'value3',
        'member4': 'value4'
    }
    dict_2 = {
        'member1': 'value1',
        'member2': 'value2',
        'member3': 'value3',
        'member4': 'value4'
    }
    dict_3 = {
        'member1': 'value1',
        'member2': 'value2',
        'member3': 'value3',
        'member4': 'value4'
    }

# Generated at 2022-06-24 20:32:31.250257
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:32:36.451200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test cases
    arg = '{"StageName": "dev", "RestApiId": "gw6d5h6j24", "MethodSettings": [{"ResourcePath": "*", "HttpMethod": "GET", "ThrottlingBurstLimit": 5000, "ThrottlingRateLimit": 10000.0}], "CacheClusterEnabled": true, "CacheClusterStatus": "CREATE_IN_PROGRESS", "MethodSettings": [{"ResourcePath": "*", "HttpMethod": "GET", "ThrottlingBurstLimit": 5000, "ThrottlingRateLimit": 10000.0}], "CacheClusterStatus": "CREATE_IN_PROGRESS"}'

# Generated at 2022-06-24 20:32:45.958718
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('') == ''
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'a': 'b'}) == {'a': 'b'}
    assert camel_dict_to_snake_dict({'aB': 'b'}) == {'a_b': 'b'}
    assert camel_dict_to_snake_dict({'aB': 'b', 'cD': 'd'}) == {'a_b': 'b', 'c_d': 'd'}

# Generated at 2022-06-24 20:32:47.874001
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict('test_0') == 'test_0', "Function 'camel_dict_to_snake_dict' - Passed"


# Generated at 2022-06-24 20:32:54.570816
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create a dict to pass as parameter
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['fooBar'] = 'foobar'

    # Create a dict with Camel case keys to pass as parameter
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    dict_1['fooBar'] = 'foobar'
    dict_1['fooBar1'] = 'foobar1'

    # Create a dict to assert test result with
    dict_2 = dict()
    dict_2['foo'] = 'bar'
    dict_2['foo_bar'] = 'foobar'
    dict_2['foo_bar_1'] = 'foobar1'

    # Call function with a simple dict to convert

# Generated at 2022-06-24 20:33:07.102197
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    name = 'camel_dict_to_snake_dict'


# Generated at 2022-06-24 20:33:16.866670
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    string1 = '{"HTTPEndpoint": {"Url": "http://0.0.0.0", "HttpAuth": {"Enabled": True, "Username": "admin", "PasswordSecretArn": "arn:aws:secretsmanager:us-east-1:123456789012:secret:YmFyZWJhcmUtUjNTd1JvTjBkVxBGT3JpZ3RYZ0hPZlVKeFdRd2RQa2s4QXhldEg0"}}}'
    response = camel_dict_to_snake_dict(string1)

# Generated at 2022-06-24 20:33:24.212533
# Unit test for function camel_dict_to_snake_dict