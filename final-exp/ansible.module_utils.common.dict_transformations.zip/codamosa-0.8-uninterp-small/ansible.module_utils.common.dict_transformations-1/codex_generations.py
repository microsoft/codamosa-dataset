

# Generated at 2022-06-24 20:25:33.123317
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:25:38.537442
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'UserId': 123, 'Description': 'test123', 'Tags': {'key1': 'val1', 'key2': 'val2'}}
    snake_dict = {'user_id': 123, 'description': 'test123', 'tags': {'key1': 'val1', 'key2': 'val2'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-24 20:25:44.644364
# Unit test for function recursive_diff
def test_recursive_diff():
    # Input parameters
    float_0 = -4958.18418
    float_1 = -4958.18418
    str_0 = 'weird looking'
    str_1 = 'weird looking'
    # Output data
    ans_0 = None

    # Function call
    var_0 = recursive_diff(float_0, float_1)
    # Print results
    if var_0 == ans_0:
        print('Success!')
    else:
        print('False!')

    # Input parameters
    float_0 = -4958.18418
    float_1 = 0.35171
    str_0 = 'weird looking'
    str_1 = 'weird looking'
    # Output data
    ans_0 = ({}, {'0': -4958.18418})

    # Function call
   

# Generated at 2022-06-24 20:25:55.286841
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_var_0 = {'message': 'hello'}
    camel_dict_var_1 = {'message': 'hello', 'array': [0, 1, 2, 3]}
    camel_dict_var_2 = {'hello': {'content': 'this is a test'}}
    camel_dict_var_3 = {'hello': {'content': 'this is a test'}, 'world': 0}
    camel_dict_var_4 = {'hello': {'content': 'this is a test'}, 'array': [0, 1, 2, 3]}
    camel_dict_var_5 = {'message': 'hello', 'array': [{'item': 1}, {'item': 2}, {'item': 3}]}

# Generated at 2022-06-24 20:25:57.597529
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_type = {
        'host': 'localhost',
        'port': 8080
    }
    expected = {
        'host': 'localhost',
        'port': 8080
    }
    actual = camel_dict_to_snake_dict(complex_type)
    assert expected == actual


# Generated at 2022-06-24 20:26:03.477727
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    params = {'KeyName': 'keypair', 'SecurityGroupIds': ['sg-xxxxxxxx'],
              'TagSpecifications': [{'ResourceType': 'instance',
                                     'Tags': [{'Key': 'Name', 'Value': 'bastion'}, {'Key': 'Owner', 'Value': 'mark'}]}],
              'InstanceType': 'm4.xlarge', 'ImageId': 'ami-xxxxxxxx', 'UserData': '...',
              'IamInstanceProfile': {'Arn': 'arn:aws:iam::1234556789012:instance-profile/bastion'},
              'MinCount': 1, 'MaxCount': 1}

# Generated at 2022-06-24 20:26:10.626519
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 = dict_merge(
            dict(
                a=dict(
                    B=dict(
                        C=0
                    )
                )
            ),
            dict(a=dict(B=dict()))
        )
    dict_1 = camel_dict_to_snake_dict(
            dict(
                a=dict(
                    b=dict(
                        c=0
                    )
                )
            )
        )
    print(dict_1)
    var_0 = recursive_diff(dict_0, dict_1)
    var_1 = recursive_diff(dict_1, dict_0)


# Generated at 2022-06-24 20:26:15.818607
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test negative case, does not return null
    var_0 = '{}'
    var_1 = {}
    var_0 = camel_dict_to_snake_dict(var_0)
    if var_0 != var_1:
        raise Exception("Test case expected 0, got %s" % var_0)


# Generated at 2022-06-24 20:26:26.446962
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    testcase = '''
    { "string": "Hello world",
    "integer": 4,
    "float": 4.2,
    "boolean": true,
    "array": [1,2,3],
    "nested": {
        "a": "b",
        "c": "d"
    },
    "snake": {
        "some_snake_key": "some snake value"
    },
    "already_camel": {
        "someCamelKey": "some Camel value"
    },
    "tag": {
        "Tags": {
            "Name": "test"
        }
    },
    "tags": [
        {
            "Key": "Name",
            "Value": "test"
        }
    ]
}
    '''
    import json
    test

# Generated at 2022-06-24 20:26:28.378606
# Unit test for function recursive_diff
def test_recursive_diff():
    test_case_0()

if __name__ == '__main__':
    test_recursive_diff()

# Generated at 2022-06-24 20:26:41.210974
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(str_0)
    assert (result['integer'] == 4)
    assert (result['float'] == 4.2)
    assert (result['boolean'] == True)
    assert (result['array'] == [1,2,3])
    assert (result['snake']['some_snake_key'] == 'some snake value')
    assert (result['already_camel']['some_camel_key'] == 'some Camel value')
    assert (result['tags'][0]['key'] == 'Name')


# Generated at 2022-06-24 20:26:51.651998
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:01.336822
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:27:09.148035
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_a = dict(keyOne='valueOne', keyTwo='valueTwo', keyThree='valueThree')
    dict_b = dict(key_one='valueOne', key_two='valueTwo', key_three='valueThree')

    try:
        assert camel_dict_to_snake_dict(dict_a) == dict_b
        assert snake_dict_to_camel_dict(dict_b) == dict_a
        assert snake_dict_to_camel_dict(dict_a) == dict_b
    except AssertionError:
        raise

    try:
        assert camel_dict_to_snake_dict(dict_b) == dict_a
    except AssertionError:
        raise


# Generated at 2022-06-24 20:27:15.177673
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(json.loads(str_0))

# Generated at 2022-06-24 20:27:16.336520
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
  assert False == False


# Generated at 2022-06-24 20:27:25.926039
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import ast

    # Convert from string to dict

# Generated at 2022-06-24 20:27:31.632411
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    flatten1 = flatten(json.loads(str_0), parent_key='', sep='_')
    assert(flatten1 == {'array': [1,2,3], 'already_camel_some_camel_key': 'some Camel value', 'boolean': True, 'float': 4.2, 'integer': 4, 'nested_a': 'b', 'nested_c': 'd', 'snake_some_snake_key': 'some snake value', 'string': 'Hello world', 'tag_tags_0_key': 'Name', 'tag_tags_0_value': 'test', 'tags_0_key': 'Name', 'tags_0_value': 'test'})

from ansible.utils.json import json
from ansible.utils.jinja import camel_dict_to_snake_dict


# Generated at 2022-06-24 20:27:39.925281
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_0 =  {
        "string": "Hello world",
        "integer": 4,
        "float": 4.2,
        "boolean": True,
        "array": [1,2,3],
        "nested": {
            "a": "b",
            "c": "d"
        },
        "snake": {
            "some_snake_key": "some snake value"
        },
        "already_camel": {
            "someCamelKey": "some Camel value"
        },
        "tag": {
            "Tags": {
                "Name": "test"
            }
        },
        "tags": [
            {
                "Key": "Name",
                "Value": "test"
            }
        ]
    }

    dict_1 = camel_dict_

# Generated at 2022-06-24 20:27:49.695730
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        "string": "Hello world",
        "integer": 4,
        "float": 4.2,
        "boolean": True,
        "array": [1, 2, 3],
        "nested": {
            "a": "b",
            "c": "d"
        },
        "snake": {
            "some_snake_key": "some snake value"
        },
        "already_camel": {
            "someCamelKey": "some Camel value"
        },
        "tag": {
            "Tags": {
                "Name": "test"
            }
        },
        "tags": [
            {
                "Key": "Name",
                "Value": "test"
            }
        ]
    }

# Generated at 2022-06-24 20:27:54.511328
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)

# Generated at 2022-06-24 20:28:02.273784
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    trim_0 = {
        'baz': -918.44,
        'qux': 602.0
    }

    # Write your code here

    assert_equal(camel_dict_to_snake_dict(trim_0), {
        'baz': -918.44,
        'qux': 602.0
    }, 'camel_dict_to_snake_dict - 0')


# Generated at 2022-06-24 20:28:08.097007
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == -3049.396

    # Test case for a simple dict, and reversed = False
    d_0 = {'MyNumber': '1234', 'MyString': 'test', 'MyList': [1, 2, 3], 'MyDict': {'key': 'value'}, 'HTTPEndpoint': {'URL': 'https://test.example.com/foo/bar'}, 'Tags': {'Tag': {'Key': 'TestKey', 'Value': 'TestValue'}}}

    result = camel_dict_to_snake_dict(d_0)

# Generated at 2022-06-24 20:28:11.180638
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    f1 = dict_merge
    f2 = _snake_to_camel
    f3 = snake_dict_to_camel_dict
    f4 = _camel_to_snake



# Generated at 2022-06-24 20:28:20.848212
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    float_1 = 7072.2
    var_1 = camel_dict_to_snake_dict(float_0, float_1)
    float_2 = 8491.78
    var_2 = camel_dict_to_snake_dict(float_1, float_2)
    var_3 = camel_dict_to_snake_dict(float_0, float_1, float_2)
    float_3 = -7789.596
    var_4 = camel_dict_to_snake_dict(float_0, float_1, float_2, float_3)


# Generated at 2022-06-24 20:28:24.152444
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == -3049.396


# Generated at 2022-06-24 20:28:35.273053
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Variables
    float_0 = -3049.396
    list_0 = [bool_0, int_0, float_1, list_0, dict_0]
    bool_0 = False
    int_0 = -3049
    float_1 = float_0
    dict_0 = {"type": str_0, "properties": int_0}
    str_0 = "JGdle"
    dict_1 = {"type": str_0, "properties": int_0}
    dict_2 = {"type": str_0, "properties": int_0}
    dict_3 = {"type": str_0, "properties": int_0}
    dict_4 = {"type": str_0, "properties": int_0}
    dict_5 = {"type": str_0, "properties": int_0}

# Generated at 2022-06-24 20:28:42.890406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == -3049.396
    float_1 = 0.38
    var_1 = camel_dict_to_snake_dict(float_1)
    assert var_1 == 0.38
    str_0 = '\''
    var_2 = camel_dict_to_snake_dict(str_0)
    assert var_2 == '\''
    dict_0 = dict()
    dict_0['First_key'] = None
    dict_0['Second_key'] = None
    dict_0['Third_key'] = None
    dict_0['Pre_and_post_key'] = None
    dict_0['Another_one_more_key'] = None

# Generated at 2022-06-24 20:28:46.957667
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    var_0 = camel_dict_to_snake_dict(float_0)


# Generated at 2022-06-24 20:28:55.657823
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:15.466539
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test keys that only need leading underscore
    assert camel_dict_to_snake_dict({'Foo': 1}) == {'foo': 1}

    # Test keys that only need leading underscores
    assert camel_dict_to_snake_dict({'FooAndBar': 1}) == {'foo_and_bar': 1}

    # Test keys that need to be lowercased
    assert camel_dict_to_snake_dict({'FooBar': 1}) == {'foo_bar': 1}

    # Test multiples

# Generated at 2022-06-24 20:29:23.888462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # function arguments
    float_0 = -3049.396
    dict_1 = {'Memory': {'InUseCount': 1, 'TotalCount': 2, 'Slabs': [{'Name': 'system', 'SlabSize': 1074, 'InUseCount': 1, 'TotalCount': 2}]}, 'Tasks': {'InUseCount': 0, 'TotalCount': 0}}

    # function returns
    expected_ret = camel_dict_to_snake_dict(dict_1)

    # function returning results
    result = camel_dict_to_snake_dict(dict_1)

    # Tests function outputs
    assert result == expected_ret, \
        "camel_dict_to_snake_dict() test case 0 failed with output: {}".format(result)



# Generated at 2022-06-24 20:29:29.938683
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(float_0) == float_0

#
# Tested function: camel_dict_to_snake_dict
# Test case 0
#
# Tested function: camel_dict_to_snake_dict
# Test case 0
#
# Tested function: camel_dict_to_snake_dict
# Test case 0
#

# Generated at 2022-06-24 20:29:40.827986
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    var_1 = camel_dict_to_snake_dict({'ClusterName': 'cluster_name1', 'Engine': 'engine1'}, True, ['Tags'])
    var_2 = camel_dict_to_snake_dict({'HostName': 'host_name1', 'AvailabilityZone': 'availability_zone1'}, True, ['Tags'])
    var_3 = camel_dict_to_snake_dict({'SubnetIdentifier': 'subnet_identifier1'}, True)
    var_4 = camel_dict_to_snake_dict({'Key': 'key1', 'Value': 'value1'}, True)
    var_5 = camel_dict_to_sn

# Generated at 2022-06-24 20:29:42.979406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    snake_dict = {}
    camel_dict_to_snake_dict(float_0, snake_dict)



# Generated at 2022-06-24 20:29:48.978172
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:29:57.800602
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:03.698845
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test with valid types
    var_0 = {u'HTTPEndpoint': u'http://example.com/endpoint'}
    expected_0 = {u'h_t_t_p_endpoint': u'http://example.com/endpoint'}
    assert camel_dict_to_snake_dict(var_0) == expected_0

    var_0 = {u'HTTPEndpointWithManyWords': u'http://example.com/endpoint'}
    expected_0 = {u'h_t_t_p_endpoint_with_many_words': u'http://example.com/endpoint'}
    assert camel_dict_to_snake_dict(var_0) == expected_0

    var_0 = {u'HTTPEndpointWithInt': 12}

# Generated at 2022-06-24 20:30:06.175064
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == -3049.396


# Generated at 2022-06-24 20:30:16.380492
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:30:34.881979
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == float_0
    dict_0 = {
        'a': -8493,
        'B': -536.904,
        'C': '20c38_f6-',
        'D': -7017.1,
        'E': '-4.430',
        'F': -0.1096,
        'G': '-4a0d.42',
        'H': '-7be0.1ab',
        'I': '-0.0ae2',
        'J': '-9.96',
        'K': '980'
    }

# Generated at 2022-06-24 20:30:44.320742
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    float_1 = -4326.2984
    float_2 = -6899.3104
    float_3 = -4034.1952
    float_4 = -6790.27
    float_5 = -723.1224
    float_6 = -1869.2136
    float_7 = -7778.2784
    list_0 = []
    list_0.append(float_0)
    list_0.append(float_1)
    list_0.append(float_2)
    list_0.append(float_3)
    list_0.append(float_4)
    list_0.append(float_5)
    list_0.append(float_6)
    list_0.append(float_7)
    var

# Generated at 2022-06-24 20:30:52.666534
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:02.629399
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    bool_0 = True
    int_0 = -9223372036854775808
    int_1 = -70
    int_2 = -81
    int_3 = -45
    int_4 = -66
    int_5 = -73
    int_6 = -83
    int_7 = -87
    int_8 = -39
    int_9 = -97
    int_10 = -7
    int_11 = -96
    int_12 = -1
    int_13 = -95
    int_14 = -51
    int_15 = -54
    int_16 = -60
    int_17 = -10
    var_0 = camel_dict_to_snake_dict(float_0)
    var_1 = camel_dict

# Generated at 2022-06-24 20:31:12.293128
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(float(-3049.396)) == -3049.396
    assert camel_dict_to_snake_dict(int(-10228)) == -10228
    assert camel_dict_to_snake_dict(bytearray(b'\xcc\xbe')) == bytearray(b'\xcc\xbe')
    assert camel_dict_to_snake_dict(None) is None
    assert camel_dict_to_snake_dict(dict(a=1)) == {u'a': 1}
    assert camel_dict_to_snake_dict(dict(a=1, b=dict(c=2))) == {u'a': 1, u'b': {u'c': 2}}
    assert camel_dict_to_snake_dict

# Generated at 2022-06-24 20:31:20.164301
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create test data
    float_0 = -3049.396
    float_1 = -1258.17
    int_2 = 64578
    float_3 = 1437.5809999999999
    int_4 = 66858
    float_5 = -1918.4259999999999
    float_6 = -1594.1830000000002
    int_7 = 27643
    dict_8 = dict(foo=dict())
    dict_9 = dict(bar=dict())
    dict_10 = dict(baz=dict())
    int_11 = 55998
    dict_12 = dict(foo=dict())
    dict_13 = dict(bar=dict())
    dict_14 = dict(baz=dict())

    var_0 = camel_dict_to_snake_dict(float_0)
    var

# Generated at 2022-06-24 20:31:28.638709
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    list_0 = [float_0, float_0]
    list_1 = [list_0, list_0]
    list_2 = [list_1, list_1]
    list_3 = [list_2, list_2]

# Generated at 2022-06-24 20:31:38.898252
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    var_0 = {'n_e_w': '', 'l_a_s_t_s_t_o_p_p_e_d_v_m': {'memory_mb': 2097152,
                                                        'name': 'vagrant_ubuntu',
                                                        'v_m_id': '3049',
                                                        'v_m_type': 'XEN',
                                                        'zone_id': 'f92e36',
                                                        '_h_i_d_d_e_n': '',
                                                        '_p_a_g_e_n_u_m': 1,
                                                        '_p_a_g_e_s_i_z_e': 65535}}

# Generated at 2022-06-24 20:31:49.082161
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = {
        'fooBar': {
            'bazBat': 1,
            'fooBar_barBaz': {
                'bazBat': 1,
                'fooBar_barBaz': 1
            }
        }
    }

    result = camel_dict_to_snake_dict(snake_dict)

    assert result == snake_dict

    # Test keys with underscores
    test_dict = {
        'Foo_Bar': 1,
        'FooBar': 1
    }

    result = {
        'foo_bar': 1,
        'foo_bar1': 1
    }

    assert camel_dict_to_snake_dict(test_dict) == result

    # Test keys that start with a capital letter

# Generated at 2022-06-24 20:31:58.011987
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.basic import AnsibleModule

    set_module_args = dict(
        arguments=dict(
            EcsClusters=[
                dict(
                    EcsClusterArn="test_string_0",
                    EcsClusterName="test_string_1",
                    EcsClusterState="test_string_2"
                )
            ],
            NextToken="test_string_0",
            MaxResults=56
        )
    )

    module = AnsibleModule(
        argument_spec=dict(
            arguments=dict(type='dict', required=True)
        ),
        supports_check_mode=True
    )

    # Setup AnsibleModule mock
    module.params = set_module_args
    module.exit_json = lambda x: x

# Generated at 2022-06-24 20:32:24.039099
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict("string") == 'string'
    assert camel_dict_to_snake_dict("Start") == 'start'
    assert camel_dict_to_snake_dict("_StartEnd") == '_start_end'
    assert camel_dict_to_snake_dict("Start_end") == 'start_end'
    assert camel_dict_to_snake_dict("_") == '_'
    assert camel_dict_to_snake_dict("_Start") == '_start'
    assert camel_dict_to_snake_dict("Start_") == 'start_'
    assert camel_dict_to_snake_dict("START") == 's_t_a_r_t'

# Generated at 2022-06-24 20:32:24.746008
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert test_case_0() is None



# Generated at 2022-06-24 20:32:34.294019
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    import random

    for i in range(10):
        # Test data.
        a = random.randint(1, 100)
        b = random.randint(1, 100)
        c = random.randint(1, 100)

        float_0 = float(random.randint(1, 100)) / float(random.randint(1, 100))
        float_1 = float(random.randint(1, 100)) / float(random.randint(1, 100))
        float_2 = float(random.randint(1, 100)) / float(random.randint(1, 100))

        list_0 = []
        for j in range(5):
            val = random.randint(1, 100)
            while val in list_0:
                val = random.randint(1, 100)
            list_

# Generated at 2022-06-24 20:32:45.734893
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)

# Generated at 2022-06-24 20:32:56.602161
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Arrange
    float_0 = -3049.396
    float_1 = -7874.51
    float_2 = -3502.238


# Generated at 2022-06-24 20:33:00.360139
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    assert var_0 == -3049.396



# Generated at 2022-06-24 20:33:10.075132
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)
    var_1 = {'Name': 'test'}
    var_2 = camel_dict_to_snake_dict(var_1)
    var_3 = {'test': {'test1': {'test2': 'test3'}}}
    var_4 = camel_dict_to_snake_dict(var_3)
    
    assert var_0 == -3049.396
    assert var_2 == {'name': 'test'}
    assert var_4 == {'test': {'test1': {'test2': 'test3'}}}


# Generated at 2022-06-24 20:33:20.523751
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        'String': 'example_string',
        'Integer': 123,
        'Float': 123.456,
        'Boolean': True,
        'Dict': {
            'String': 'example_string',
            'Integer': 123,
            'Float': 123.456,
            'Boolean': True
        },
        'List': [
            'String', 123, 123.456, True,
            {
                'String': 'example_string',
                'Integer': 123,
                'Float': 123.456,
                'Boolean': True
            },
            [
                'String', 123, 123.456, True
            ]
        ],
        'Reversible': True
    }


# Generated at 2022-06-24 20:33:26.558731
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-24 20:33:36.970319
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case for camel_dict_to_snake_dict
    float_0 = -3049.396
    var_0 = camel_dict_to_snake_dict(float_0)

    assert var_0 == -3049.396

    bool_0 = -1
    var_0 = camel_dict_to_snake_dict(bool_0)

    assert var_0 == -1

    list_0 = []
    var_0 = camel_dict_to_snake_dict(list_0)

    assert var_0 == []

    string_0 = 'm5Y5J_'
    var_0 = camel_dict_to_snake_dict(string_0)

    assert var_0 == 'm5Y5J_'

    int_0 = -15
    var_0 = camel_

# Generated at 2022-06-24 20:34:44.325536
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    for v in globals().values():
        if type(v) is type(test_camel_dict_to_snake_dict):
            if v.__name__.startswith('test_'):
                v()

test_case_0()

# Generated at 2022-06-24 20:34:52.989367
# Unit test for function dict_merge
def test_dict_merge():
    var_0 = dict(a=1, b=2, c=dict(c1='abc', c2='def', c3='ghi'))
    var_1 = dict(c=dict(c2='xxx', c3='yyy'))
    var_2 = dict_merge(var_0, var_1)
    assert var_2 == dict(a=1, b=2, c=dict(c1='abc', c2='xxx', c3='yyy'))



# Generated at 2022-06-24 20:35:03.350852
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    # Test 2
    complex_type = {
        'created_at': '2016-02-23T21:24:38-08:00',
        'disabled': False,
        'id': '1',
        'name': 'My ECS Cluster',
        'tags': [
            {
                'key': 'key',
                'value': 'value'
            },
            {
                'key': 'key2',
                'value': 'value2'
            }
        ],
        'updated_at': '2016-02-23T21:24:38-08:00',
        'vpc_id': 'vpc-abc1234'
    }
    result = snake_dict_to_camel_dict(complex_type)
    assert result == complex_type
    # Test 3

# Generated at 2022-06-24 20:35:05.888932
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {}
    dict2 = {}
    result = recursive_diff(dict1, dict2)

    assert(result == None)

test_case_0()

# Generated at 2022-06-24 20:35:14.726029
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    host_vars = dict(LoadBalancerName="AnsibleLoadBalancerTest",
                     Subnets=["subnet-1", "subnet-2"],
                     SecurityGroups=["sg-1", "sg-2"],
                     HealthCheck=dict(Target="HTTP:8080/",
                                      Interval=30,
                                      Timeout=3,
                                      UnhealthyThreshold=10,
                                      HealthyThreshold=2),
                     Tags=[dict(Key="Name", Value="AnsibleLoadBalancerTest"),
                           dict(Key="Environment", Value="Test")])