

# Generated at 2022-06-11 00:58:27.043097
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json

    # 1. test a simple conversion
    camel_dict = {
        'InstanceType': 't2.micro',
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'HelloWorld'
            }
        ]
    }
    assert (camel_dict_to_snake_dict(camel_dict) == {
        'instance_type': 't2.micro',
        'tags': [
            {
                'key': 'Name',
                'value': 'HelloWorld'
            }
        ]
    })

    # 2. test a complex conversion
    with open('tests/unit/modules/aws_vpc_endpoint_info/complex-camel.json', 'r') as f:
        complex_camel_dict = json.load(f)

# Generated at 2022-06-11 00:58:37.213785
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'DataSourceConfig':
                  {'S3Config':
                   {'BucketARN': 'string',
                    'FileKey': 'string'}},
                  'Name': 'string',
                  'Tags': [{'Key': 'string', 'Value': 'string'}],
                  'VersioningConfiguration':
                      {'EnableVersioning': True}}

# Generated at 2022-06-11 00:58:47.144371
# Unit test for function recursive_diff
def test_recursive_diff():
    def assert_recursive_diff(dict1, dict2, diff_expected=None):
        if diff_expected is not None:
            left, right = diff_expected
        else:
            left = right = None
        diff = recursive_diff(dict1, dict2)
        if diff is not None:
            dict1_diff, dict2_diff = diff
        else:
            dict1_diff = dict2_diff = None
        print("Testing:")
        print("Dict 1:\n", dict1)
        print("Dict 2:\n", dict2)
        print("Expected diff:")
        print(diff_expected)
        print("Diff:")
        print(diff)
        assert left == dict1_diff
        assert right == dict2_diff


# Generated at 2022-06-11 00:58:58.925162
# Unit test for function recursive_diff
def test_recursive_diff():

    assert recursive_diff({}, {}) is None

    assert recursive_diff({'x': 'some value'}, {'x': 'some value'}) is None

    left, right = recursive_diff(
        {'x': 'some value'},
        {'x': 'other value'}
    )
    assert left == {'x': 'some value'}
    assert right == {'x': 'other value'}

    left, right = recursive_diff(
        {'x': 'some value'},
        {'a': 'other value'}
    )
    assert left == {'x': 'some value'}
    assert right == {'a': 'other value'}


# Generated at 2022-06-11 00:59:06.399532
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test for no change
    a_dict = { "id": 0, "name": "A", "group": "a",
        "address": { "street": "a", "city": "a", "state": "a", "zip": "a", "country": "a" } }
    b_dict = a_dict.copy()
    assert recursive_diff(a_dict, b_dict) is None # No change, no result

    # Test for top level change
    b_dict.pop("id")
    assert recursive_diff(a_dict, b_dict) == ({'id': 0}, None) # id must be removed

    a_dict["id"] = 100
    assert recursive_diff(a_dict, b_dict) == ({'id': 0}, {'id': 100}) # id must change


# Generated at 2022-06-11 00:59:17.457934
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': 2, 'd': {'e': 5, 'f': 6}, 'g': {'h': {'i': 9}}}
    dict2 = {'a': 1, 'b': 4, 'd': {'e': 5, 'f': 7}, 'g': {'h': {'j': 9}}}

    left, right = recursive_diff(dict1, dict2)
    expected_left = {'b': 2, 'd': {'f': 6}, 'g': {'h': {'i': 9}}}
    expected_right = {'b': 4, 'd': {'f': 7}, 'g': {'h': {'j': 9}}}

    assert left == expected_left
    assert right == expected_right

# Generated at 2022-06-11 00:59:24.523842
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # simple test
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    # test non-reversible
    assert camel_dict_to_snake_dict({"aBc": 1, "bCd": 2}) == {"a_bc": 1, "b_cd": 2}
    assert camel_dict_to_snake_dict({'aBc': {'cDe': 1}}) == {'a_bc': {'c_de': 1}}

    # test reversible

# Generated at 2022-06-11 00:59:36.109677
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(b='blah', c=dict(d=2, e='fff'), f=3.0)
    dict2 = dict(a=1, b='blah', c=dict(d=2, e='ggg', f=dict(g='wow')), f=30.0)
    dict_result = dict(a=1, b='blah', c=dict(e='fff', f=dict(g='wow')), f=3.0)
    left_result = dict(c=dict(e='ggg'))
    right_result = dict(a=1, c=dict(f=dict(g='wow')), f=30.0)

    dict_answer = dict_merge(dict1, dict2)
    left_answer, right_answer = recursive_diff(dict1, dict2)

# Generated at 2022-06-11 00:59:46.425735
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:57.913426
# Unit test for function recursive_diff
def test_recursive_diff():

    d1 = {'a': 1, 'b': 2, 'c': {'d': {'e': 1, 'f': 2}, 'g': 1}, 'h': [1, 2, 3]}
    d2 = {'a': 1, 'c': {'d': {'e': 1, 'f': 3}, 'g': 1}, 'h': [1, 2, 4]}
    diff = recursive_diff(d1, d2)
    # Test simple left and right diff
    assert d1['b'] != d2['b']
    assert d1['c']['d']['f'] != d2['c']['d']['f']
    assert d1['h'][2] != d2['h'][2]
    # Test recursive diff

# Generated at 2022-06-11 01:00:13.381395
# Unit test for function dict_merge
def test_dict_merge():

    # Simple merge, nothing special
    check = {
        'name': 'foo',
        'bar': 42
    }
    test_dict = {
        'name': 'foo',
        'bar': 42,
    }
    assert check == dict_merge(check, test_dict)

    # simple deep merge
    check['two'] = {
        'name': 'bird'
    }
    test_dict['two'] = {
        'name': 'bird',
        'nest': 'tree'
    }
    assert check == dict_merge(check, test_dict)

    # now go the other direction, for complete coverage
    test_dict['two'] = {
        'name': 'bird',
    }
    assert check == dict_merge(check, test_dict)

    # with lists

# Generated at 2022-06-11 01:00:25.291589
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({"a": "b", "c": "d"}) == {"a": "b", "c": "d"}
    assert camel_dict_to_snake_dict({"a": "b", "c": "d", "eFg": "h"}) == {"a": "b", "c": "d", "e_fg": "h"}
    assert camel_dict_to_snake_dict({"a": "b", "c": {"d": "e", "fG": "h"}}) == {"a": "b", "c": {"d": "e", "f_g": "h"}}

# Generated at 2022-06-11 01:00:35.236955
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'ContainerDefinitions': [
            {'Name': 'wordpress', 'Image': 'wordpress', 'Memory': '348', 'PortMappings': [{'ContainerPort': 80}]}
        ],
        'LoadBalancers': [{'ContainerName': 'wordpress', 'ContainerPort': 80}],
        'Tags': [{'Key': 'asdf', 'Value': 'asdf'}]
    }
    s_test_dict = camel_dict_to_snake_dict(test_dict, ignore_list=('Tags', ))

# Generated at 2022-06-11 01:00:47.213023
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import pytest
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'CamelCase': 'camel'}) == {'camel_case': 'camel'}
    assert camel_dict_to_snake_dict({'CamelCase': {}}) == {'camel_case': {}}
    assert camel_dict_to_snake_dict({'CamelCase': {'CamelCase': {'CamelCase': 'camel'}}}) == {'camel_case': {'camel_case': {'camel_case': 'camel'}}}

# Generated at 2022-06-11 01:00:57.590283
# Unit test for function dict_merge
def test_dict_merge():
    a = {'big': {'foo': {'bar': {'baz': 'hello'}}}}
    b = {'big': {'foo': {'bar': {'baz': 'goodbye'}}}}
    result = dict_merge(a, b)
    assert result == {'big': {'foo': {'bar': {'baz': 'goodbye'}}}}

    a = {'big': {'foo': {'bar': {'baz': 'hello'}}}}
    b = {'big': {'foo': {'bar': {'baz': 'goodbye'}}}, 'small': 100}
    result = dict_merge(a, b)
    assert result == {'big': {'foo': {'bar': {'baz': 'goodbye'}}}, 'small': 100}

   

# Generated at 2022-06-11 01:01:08.222639
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(AttachedTo='VPC', Attachment={'VolumeSize': 20, 'Device': '/dev/sdb', 'DeleteOnTermination': True}, AvailabilityZone='us-east-1a',
                      CreateTime='2016-04-08T18:50:41+00:00', Encrypted=False, Iops=1000, Size=20, SnapshotId='snap-818d5f06',
                      State='in-use', StateTransitionReason='', VolumeId='vol-e767f58a', VolumeType='gp2')


# Generated at 2022-06-11 01:01:18.985961
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:30.258529
# Unit test for function dict_merge
def test_dict_merge():
    from ansible.module_utils.common._collections_compat import assertDictEqual

    class TestDict(dict):
        pass


# Generated at 2022-06-11 01:01:34.989125
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(HTTPEndpoint=dict(Description='This is a test'))
    test_dict = dict(h_t_t_p_endpoint=dict(description='This is a test'))
    assert camel_dict_to_snake_dict(camel_dict) == test_dict



# Generated at 2022-06-11 01:01:44.240460
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict([{"foo": "bar", "baz": "blam"}]) == [{"foo": "bar", "baz": "blam"}]
    assert camel_dict_to_snake_dict(["foo", "baz", "blam"]) == ["foo", "baz", "blam"]
    assert camel_dict_to_snake_dict({"foo": "bar", "baz": "blam"}) == {"foo": "bar", "baz": "blam"}
    assert camel_dict_to_snake_dict({"foo": ["bar", {"baz": "blam"}]}) == {"foo": ["bar", {"baz": "blam"}]}

# Generated at 2022-06-11 01:01:57.446164
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # making sure dict is converted to snake case
    snake_dict = {'foo_bar': 'baz'}
    result = camel_dict_to_snake_dict(snake_dict)
    assert result == {'foo_bar': 'baz'}

    # making sure dict is case insensitive
    dict_upper = {'FooBar': 'baz'}
    result = camel_dict_to_snake_dict(dict_upper)
    assert result == {'foo_bar': 'baz'}

    dict_mixed = {'fOoBar': 'baz'}
    result = camel_dict_to_snake_dict(dict_mixed)
    assert result == {'foo_bar': 'baz'}

    # making sure dict is converted to snake case recursively
    dict_nested

# Generated at 2022-06-11 01:02:08.530638
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict = {'MyKey': 'MyValue', 'anotherKey': 'AnotherValue'}
    result = camel_dict_to_snake_dict(dict)
    assert 'my_key' in result, result
    assert 'another_key' in result, result
    assert len(result) == 2, result

    dict = {'AnotherKey': {'subKey': 'subValue'}}
    result = camel_dict_to_snake_dict(dict)
    assert 'sub_key' in result['another_key'], result
    assert len(result) == 1, result
    assert len(result['another_key']) == 1, result

    dict = {'ListKey': [{'subKey': 'subValue'}]}
    result = camel_dict_to_snake_dict(dict)

# Generated at 2022-06-11 01:02:20.847871
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:28.046288
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    my_dict = {'HTTPEndpoint': {'URL': 'q', 'Method': 'w'},
               'Tags': [{'Key': 'a', 'Value': 's'}],
               'StatusCode': 'd',
               'CompressionType': 'f',
               'ContentEncoding': 'g',
               'HTTPHeaders': {'Content-Type': 'h', 'Content-Length': 'j'},
               'Body': 'kkkkkkk'}


# Generated at 2022-06-11 01:02:33.566162
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"fooBar": "baz"}, reversible=False) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({"fooBar": "baz"}, reversible=True) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "baz"}, reversible=False) == {'http_endpoint': 'baz'}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "baz"}, reversible=True) == {'h_t_t_p_endpoint': 'baz'}


# Generated at 2022-06-11 01:02:42.771029
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'dict1': {'testkey1': 'testvalue1'}, 'dict2': {'testkey2': 'testvalue2'}}
    expected_dict = {'dict1': {'test_key1': 'testvalue1'}, 'dict2': {'test_key2': 'testvalue2'}}
    assert camel_dict_to_snake_dict(test_dict) == expected_dict

    test_dict = {'dict1': {'testkey1': ['a', 'b', 'c']}, 'dict2': {'testkey2': 'testvalue2'}}
    expected_dict = {'dict1': {'test_key1': ['a', 'b', 'c']}, 'dict2': {'test_key2': 'testvalue2'}}
    assert camel_dict_to_sn

# Generated at 2022-06-11 01:02:54.481773
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'TestKey1': 'value1', 'TestKey2': 'value2'}) == \
        {'test_key1': 'value1', 'test_key2': 'value2'}
    assert camel_dict_to_snake_dict({'TestKey1': {'TestKey2': 'value2'}}) == \
        {'test_key1': {'test_key2': 'value2'}}

# Generated at 2022-06-11 01:03:01.464124
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'helloWorld': {'iAmCamels': [{'helloWorldAgain': 'foobar'}]}}
    json_result = u'{"hello_world": {"i_am_camels": [{"hello_world_again": "foobar"}]}}'
    assert json_result == json.dumps(camel_dict_to_snake_dict(camel_dict, reversible=False),
                                     sort_keys=True, indent=4, separators=(',', ': '))



# Generated at 2022-06-11 01:03:08.679444
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'fooBar': 'value1',
                  'fooBarBaz': 'value2',
                  'qux': {'corgeGrault1': 'value1',
                          'corgeGrault2': 'value2'}}
    expected = {'foo_bar': 'value1',
                'foo_bar_baz': 'value2',
                'qux': {'corge_grault1': 'value1',
                        'corge_grault2': 'value2'}}
    assert camel_dict_to_snake_dict(camel_dict, reversible=False) == expected



# Generated at 2022-06-11 01:03:18.911390
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_camel = {'camel': 'case', 'Camel': 'Case', 'CamelCase': 'SnakeCaseFormat'}
    dict_snake = {'camel': 'case', 'camel_case': 'SnakeCaseFormat'}
    dict_reversible = {'camel': 'case', 'c_a_m_e_l': 'SnakeCaseFormat'}
    assert camel_dict_to_snake_dict(dict_camel, reversible=False) == dict_snake
    assert camel_dict_to_snake_dict(dict_camel, reversible=True) == dict_reversible

# Unit tests for function snake_dict_to_camel_dict

# Generated at 2022-06-11 01:03:33.723352
# Unit test for function recursive_diff
def test_recursive_diff():
    # Correct usage
    import pytest
    assert not recursive_diff({}, {})
    assert not recursive_diff({'a': 1}, {'a': 1})
    assert recursive_diff({'a': 1}, {'b': 1}) == ({'a': 1}, {'b': 1})
    assert recursive_diff({'a': None}, {'a': None}) == ({}, {})
    assert recursive_diff({'a': 1, 'b': None}, {'a': 1, 'b': None}) == ({}, {})
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': []}, {'a': []}) == ({}, {})
    assert recursive_diff({'a': {}}, {'a': {}})

# Generated at 2022-06-11 01:03:44.600536
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:53.931937
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    test_dict = {"key1": {"key2": {"key3": {"key4": "val"}}}, "key5": [{"key6": "val"}, {"key7": {"key8": "val"}}]}
    assert snake_dict_to_camel_dict(test_dict) == {"Key1": {"Key2": {"Key3": {"Key4": "val"}}}, "Key5": [{"Key6": "val"}, {"Key7": {"Key8": "val"}}]}
    assert snake_dict_to_camel_dict(test_dict, True) == {"Key1": {"Key2": {"Key3": {"Key4": "val"}}}, "Key5": [{"Key6": "val"}, {"Key7": {"Key8": "val"}}]}

# Generated at 2022-06-11 01:04:05.120582
# Unit test for function dict_merge

# Generated at 2022-06-11 01:04:16.933494
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'endpoint': 'someurl',
            'id': '123'
        },
        'HTTPEndpoints': {
            'HTTPEndpoint': [
                {
                    'id': '123',
                    'endpoint': 'someurl'
                },
                {
                    'id': '456',
                    'endpoint': 'someotherurl'
                }
            ]
        },
        'HTTPEndpoints2': [
            {
                'id': '123',
                'endpoint': 'someurl'
            }
        ],
        'Tags': {
            'item': [{'key': 'a', 'value': 'b'}]
        }
    }

    # Camel and snake dicts should be the same
    snake_dict = camel_dict_to_

# Generated at 2022-06-11 01:04:28.077013
# Unit test for function dict_merge
def test_dict_merge():

    # Create a linked list for testing
    d = {}
    temp = d
    for letter in 'abcdefghij':
        temp[letter] = {}
        temp = temp[letter]

    # Test a simple merge
    merged = dict_merge(d, {'a': {'b': 1}})

    assert merged == {'a': {'b': 1, 'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': {}}}}}}}}}}

    # Test a deeper merge

# Generated at 2022-06-11 01:04:36.340886
# Unit test for function recursive_diff
def test_recursive_diff():
    ''' Unit test for function recursive_diff '''
    # Test cases
    test_left = {
        'a': {
            'a1': 1,
            'a2': 2,
            'a3': 3,
            'a4': 4,
            'a5': 5
        }
    }
    test_right = {
        'a': {
            'a1': 1,
            'a2': 2,
            'a3': 3,
            'a4': 8,
            'a6': 6
        }
    }
    test_equal_dicts = {
        'a': {
            'a1': 1,
            'a2': 2,
            'a3': 3,
            'a4': 4
        }
    }
    # Test for equality
    result = recursive_diff

# Generated at 2022-06-11 01:04:47.574186
# Unit test for function recursive_diff
def test_recursive_diff():

    # dict1 and dict2 are the two dictionaries that are to be compared
    dict1 = {'name': 'test-vpc', 'cidr_block': '10.0.0.0/16',
             'tags': {'Network': 'Public', 'deployment': 'test'}}
    dict2 = {'name': 'test-vpc', 'cidr_block': '10.0.0.0/16',
             'tags': {'Network': 'Private', 'deployment': 'Prod'}}

    # Expected result is a tuple of two dictionaries
    left = {'tags': {'Network': 'Public'}}
    right = {'tags': {'Network': 'Private'}}
    result = recursive_diff(dict1, dict2)

    assert result[0] == left and result[1]

# Generated at 2022-06-11 01:04:55.113853
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'pass' : 'dog', 'number' : '5' } } }
    assert dict_merge(a, b) == c, "Failed to merge dictionary"


# Generated at 2022-06-11 01:05:02.394626
# Unit test for function dict_merge
def test_dict_merge():
    a = {'foo': {'bar': 'baz'}}
    b = {'foo': {'bar': 'moo'},
         'hello': {'world': '!'}}
    c = {'foo': {'bar': 'baz'},
         'hello': {'world': '!'}}
    d = {'foo': {'bar': 'moo'}}
    e = {'foo': {'bar': 'baz'},
         'hello': {'world': '!'},
         'more': {'stuff': {'yes': 'please'}}}
    f = {'hello': {'world': '!'},
         'more': {'stuff': {'yes': 'please'},
                  'other': 'things'}}

# Generated at 2022-06-11 01:05:18.241001
# Unit test for function snake_dict_to_camel_dict

# Generated at 2022-06-11 01:05:26.013744
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    c = dict_merge(a, b)
    assert c == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }

# Generated at 2022-06-11 01:05:29.308729
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    d = snake_dict_to_camel_dict({"name": "test", "test_dict": {"test_name": "test"}}, True)
    assert d['Name'] == 'test'
    assert d['TestDict']['TestName'] == 'test'

# Generated at 2022-06-11 01:05:36.049786
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'CreateAt': 2134124124,
        'DisplayName': 'Ansible',
        'Domain': 'aws',
        'Tags': {
            'CostCenter': 'CC123',
            'Environment': 'Production'
        },
        'CamelCaseTags': {
            'CostCenter': 'CC123',
            'Environment': 'Production'
        },
        'Aws_workload': 'nodejs'
    }


# Generated at 2022-06-11 01:05:48.116045
# Unit test for function dict_merge
def test_dict_merge():
    """
    This is to test the dict_merge function in this file.
    """
    a = dict(
        scalar_value=0,
        list_value=[1, 2, 3],
        dict_value={'a': 1, 'b': 2}
    )
    b = dict(
        scalar_value=None,
        list_value=['a', 'b', 'c'],
        dict_value={'d': 3, 'e': 4}
    )
    c = dict(
        scalar_value=None,
        list_value=['a', 'b', 'c'],
        dict_value={'a': 1, 'b': 2, 'd': 3, 'e': 4}
    )
    assert dict_merge(a, b) == c

# Generated at 2022-06-11 01:05:56.166414
# Unit test for function snake_dict_to_camel_dict
def test_snake_dict_to_camel_dict():
    assert snake_dict_to_camel_dict({'foo_bar_baz': 'quux'}) == {'fooBarBaz': 'quux'}
    assert snake_dict_to_camel_dict({'foo_bar_baz': 'quux'}, capitalize_first=True) == {'FooBarBaz': 'quux'}
    assert snake_dict_to_camel_dict({'foo_bar_baz': {'hello': 'world'}}) == {'fooBarBaz': {'hello': 'world'}}
    assert snake_dict_to_camel_dict({'hello-world': 'foo_bar_baz'}) == {'helloWorld': 'foo_bar_baz'}

# Generated at 2022-06-11 01:06:04.756813
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test basic functionality
    dict1 = {'one': 'one', 'two': 2}
    dict2 = {'one': 'one', 'two': 3}
    result = recursive_diff(dict1, dict2)
    assert result == ({'two': 2}, {'two': 3})

    # Test different types
    dict1 = {'one': 'one', 'two': 2}
    dict2 = {'one': 'one', 'two': 'two'}
    result = recursive_diff(dict1, dict2)
    assert result == ({'two': 2}, {'two': 'two'})

    # Test nested dictionaries
    dict1 = {'a': {'b': {'c': 1}}}
    dict2 = {'a': {'b': {'c': 1}}}

# Generated at 2022-06-11 01:06:12.772743
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff

    :raise: ``AssertionError`` if the test failed.
    """

    a = {'a': 1, 'b': 2, 'c': 3, 'd': {'a': 1, 'b': 2, 'c': 3}}
    b = {'a': 1, 'b': 2, 'c': 4, 'e': 5, 'd': {'a': 1, 'b': 2, 'c': 4}}

    left, right = recursive_diff(a, b)
    assert left == {'d': {'c': 3}, 'c': 3}
    assert right == {'e': 5, 'd': {'c': 4}, 'c': 4}

    left, right = recursive_diff(b, a)

# Generated at 2022-06-11 01:06:19.836687
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'String': 'hello', 'Array': ['hello', 'world']},
        reversible=False
    ) == {'string': 'hello', 'array': ['hello', 'world']}

    assert camel_dict_to_snake_dict(
        {'String': 'hello', 'Array': ['hello', 'world']},
        reversible=True
    ) == {'string': 'hello', 'array': ['hello', 'world']}

    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'hello', 'HTTPEndpoints': ['hello', 'world']},
        reversible=False
    ) == {'http_endpoint': 'hello', 'http_endpoints': ['hello', 'world']}

    assert camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:28.303691
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'foo': 'bar',
        'TVShow': {
            'title': 'Game of Thrones',
            'TVNetwork': 'HBO'
        },
        'HTTPEndpoint': {
            'URL': 'https://httpbin.org',
            'port': 80
        },
        'ILovePython': True,
        'EC2SecurityGroups': ['sg-a', 'sg-b', 'sg-c'],
        'Tags': {
            'Application': 'Ansible',
            'Environment': 'Development'
        },
        'ListOfNones': [None, None]
    }
