

# Generated at 2022-06-11 00:58:29.658675
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {"Tier": "1", "ClientData": {"ClientEmail": "gmail.com", "ClientName": "mtech"}, "ClientID": "1", "ASN": "65351", "CIDR": "11.11.11.0/24", "Tags": {"ClientName": "mtech", "Environment": "Production"}, "CustomerID": "2", "ForceRegistration": True}
    expected_dict = {"tier": "1", "client_data": {"client_email": "gmail.com", "client_name": "mtech"}, "client_id": "1", "asn": "65351", "cidr": "11.11.11.0/24", "tags": {"ClientName": "mtech", "Environment": "Production"}, "customer_id": "2", "force_registration": True}
    assert camel

# Generated at 2022-06-11 00:58:36.425241
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({"A": "B"}) == {"a": "B"}
    assert camel_dict_to_snake_dict({"A": {"B": "C"}}) == {"a": {"b": "C"}}
    assert camel_dict_to_snake_dict({"A": "B", "C": "D"}) == {"a": "B", "c": "D"}

# Generated at 2022-06-11 00:58:46.345290
# Unit test for function recursive_diff
def test_recursive_diff():
    from pprint import pformat
    from sys import version_info

    # python2
    if version_info[0] < 3:
        from __builtin__ import unicode

    # python3
    if version_info[0] == 3:
        unicode = str

    # equal dictionaries
    assert recursive_diff({}, {}) == None
    assert recursive_diff({1: 1}, {1: 1}) == None
    assert recursive_diff({1: 1, 'a': 'a'}, {1: 1, 'a': 'a'}) == None

    # different dictionaries
    assert recursive_diff({}, {1: 1}) == ({}, {1: 1})
    assert recursive_diff({1: 2}, {1: 1}) == ({1: 2}, {1: 1})

# Generated at 2022-06-11 00:58:58.269641
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test diff of two dictionaries.

    These unit tests are checking the dictionaries are not equal and
    then doing a diff and making sure the result of the diff is what is
    expected.
    """
    # pylint: disable=dangerous-default-value

# Generated at 2022-06-11 00:59:06.062358
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = dict(a=dict(b=1,c=2,d=4),e=5)
    dict2 = dict(a=dict(b=1,c=3,e=5),f=6)
    dict3 = dict(a=dict(b=1,c=2,d=4),e=5,g=7)
    dict4 = dict(a=dict(b=1,c=2,d=4),e=5)

    assert recursive_diff(dict1, dict2) == ({'a': {'c': 2}}, {'a': {'c': 3}, 'f': 6})
    assert recursive_diff(dict1, dict3) == (dict1, dict3)
    assert recursive_diff(dict1, dict4) is None
    assert recursive_diff(dict1, dict())

# Generated at 2022-06-11 00:59:15.968106
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        'a': {
            'b': 'foobar'
        },
        'c': 'something',
        'd': {
            'e': 'another'
        }
    }
    right = {
        'a': {
            'b': 'foobar1'
        },
        'c': 'something2',
        'd': {
            'e': 'another'
        }
    }
    result = recursive_diff(left, right)
    assert result == ({'a': {'b': 'foobar'}}, {'a': {'b': 'foobar1'}}), "Result is not correct"

test_recursive_diff()

# Generated at 2022-06-11 00:59:23.761817
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'InstanceId': 'i-123456789'}) == \
        {'instance_id': 'i-123456789'}

    assert camel_dict_to_snake_dict({'InstanceId': 'i-123456789', 'Tags': {'Key': 'Env', 'Value': 'Test'}}) == \
        {'instance_id': 'i-123456789', 'tags': {'key': 'Env', 'value': 'Test'}}


# Generated at 2022-06-11 00:59:35.390631
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:45.170710
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {
        "key1": "value1",
        "nestedKey1": {
            "key2": "value2",
            "nestedKey2": {
                "nestedKey3": "value3"
            }
        }
    }

    output_dict = {
        "key1": "value1",
        "nested_key1": {
            "key2": "value2",
            "nested_key2": {
                "nested_key3": "value3"
            }
        }
    }

    assert camel_dict_to_snake_dict(input_dict) == output_dict
    assert snake_dict_to_camel_dict(output_dict) == input_dict

# Generated at 2022-06-11 00:59:55.053924
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': {
            'falseValue': False,
            'fooStr': 'fooStr',
            'trueValue': True,
        },
        'anotherCamelKey': {
            'fooList': [
                {
                    'something': 'something',
                },
            ],
            'fooDict': {
                'anotherValue': 'anotherValue',
            },
        },
        'someCamelKey': 'someCamelValue',
    }

    snake_dict = camel_dict_to_snake_dict(test_dict)


# Generated at 2022-06-11 01:00:16.470576
# Unit test for function dict_merge
def test_dict_merge():
    # simple keys
    a = {'a': 'a', 'b': 'b'}
    b = {'b': 'c', 'd': 'd'}
    assert dict_merge(a, b) == {'a': 'a', 'b': 'c', 'd': 'd'}

    # nested keys
    a = {'a': {'b': 'b', 'e': {'f': {'g': 'g'}}}}
    b = {'a': {'c': 'c', 'e': {'h': {'i': 'i'}}}}
    assert dict_merge(a, b) == {'a': {'b': 'b', 'e': {'f': {'g': 'g'}, 'h': {'i': 'i'}}, 'c': 'c'}}



# Generated at 2022-06-11 01:00:27.319514
# Unit test for function dict_merge
def test_dict_merge():
    import pytest
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert(dict_merge(a, b) == expected)
    with pytest.raises(TypeError):
        dict_merge(a, 'fail')
    with pytest.raises(TypeError):
        dict_merge('fail', b)



# Generated at 2022-06-11 01:00:36.596717
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:48.885959
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {
      'LoadBalancerName': 'foobar',
      'Tags': [
        {
          'Key': 'Name',
          'Value': 'foobar_s1'
        },
        {
          'Key': 'Application',
          'Value': 'foobar'
        }
      ]
    }
    d2 = {
      'LoadBalancerName': 'foobar',
      'Tags': [
        {
          'Key': 'Name',
          'Value': 'foobar_s2'
        },
        {
          'Key': 'Role',
          'Value': 'test'
        }
      ]
    }
    d3 = dict_merge(d1, d2)

    assert len(d3['Tags']) == 3

# Generated at 2022-06-11 01:00:58.403725
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': 'bar', 'Boo': 'far'}) == {'foo': 'bar', 'boo': 'far'}
    assert camel_dict_to_snake_dict({'Foo': 'bar', 'Boo': 'far'}, True) == {'f_oo': 'bar', 'b_oo': 'far'}
    assert camel_dict_to_snake_dict({'Tags': {'Foo': 'bar'}}, True) == {'tags': {'f_oo': 'bar'}}
    assert camel_dict_to_snake_dict({'Tags': {'Foo': 'bar'}}, True, ['Tags']) == {'tags': {'Foo': 'bar'}}

# Generated at 2022-06-11 01:01:09.357069
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_camel_dict = {
        'prop1': 'val1',
        'prop2': {
            'subProp1': 'subVal1',
            'subProp2': 'subVal2'
        },
        'prop3_list': [
            'listVal1',
            {
                'subListProp1': 'subListVal1',
                'subListProp2': 'subListVal2'
            }
        ]
    }


# Generated at 2022-06-11 01:01:19.935393
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'AttributeName': 'Value',
        'key2': 'value2',
        'tag': {'tag2': {'tag3': {'tag4': 'value'}}},
        'tag_list': [
            {'tag1': 'value'},
            {'tag2': 'value2'}
        ]
    }

    assert camel_dict_to_snake_dict(camel_dict) == {'attribute_name': 'Value',
                                                    'key2': 'value2',
                                                    'tag': {'tag2': {'tag3': {'tag4': 'value'}}},
                                                    'tag_list': [{'tag1': 'value'},
                                                                 {'tag2': 'value2'}]}

    assert camel_dict_to_

# Generated at 2022-06-11 01:01:31.284734
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Function to test conversion of camel_dict_to_snake_dict

    Returns:
        bool: True if all test passed successfully else False
    """
    res = True
    camel_dict = {'abc': 'abc', 'abcXyz': 'abcxyz', 'abcABc': 'abcabc'}
    snake_dict = {'abc': 'abc', 'abc_xyz': 'abcxyz', 'abc_a_bc': 'abcabc'}
    result = camel_dict_to_snake_dict(camel_dict)
    if result == snake_dict:
        res &= True
    else:
        res &= False

    camel_dict = {'A': 'A', 'AA': 'A', 'AAA': 'A'}

# Generated at 2022-06-11 01:01:41.417803
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    before = camel_dict_to_snake_dict(
        {
            "camelCase": {
                "camelCase": {
                    "camelCase": {
                        "camelCase": "test",
                        "camelCase2": "test",
                        "camelCase3": "test",
                        "camelCase4": "test"
                    },
                    "camelCase2": "test",
                    "camelCase3": "test"
                },
                "camelCase2": "test"
            },
            "ThingNames": ["somethings"],
            "camelCase2": "test"
        }
    )

# Generated at 2022-06-11 01:01:47.212155
# Unit test for function dict_merge
def test_dict_merge():

    a = {'a': 1, 'b': {'b1': 'b1', 'b2': 'b2'}}
    b = {'a': 2, 'b': {'b1': 'b1', 'b3': 'b3'}, 'c': 'c'}
    c = {'a': 2, 'b': {'b1': 'b1', 'b3': 'b3'}, 'c': 'c'}

    assert dict_merge(a, b) == c
    assert dict_merge(dict(), a) == a



# Generated at 2022-06-11 01:01:58.475856
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'KeyName': 'key',
        'bogus': None,
        'cluster': {
            'ec2': {
                'AvailabilityZones': [
                    'us-west-2a',
                    'us-west-2b'
                ]
            }
        },
        'node': {
            'instanceType': 'c3.2xlarge',
            'runTags': {
                'key': 'value'
            }
        },
        'tags': {
            'Key': 'value'
        }
    }


# Generated at 2022-06-11 01:02:10.620908
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    x = {
        "HTTPEndpoint": {
            "Endpoint": "https://github.com",
            "Encryption": "TLSv1.3",
            "Timeout": 5,
            "AllowedMethods": [
                "GET",
                "PUT"
            ]
        },
        "Tags": {
            "Name": "foo",
            "Timestamp": "bar"
        }
    }
    """

# Generated at 2022-06-11 01:02:21.957736
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""

    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': {'path': '/api', 'callback': 'handler'}}) == \
           {'http_endpoint': {'path': '/api', 'callback': 'handler'}}

    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': {'path': '/api', 'callback': 'handler'}},
        reversible=True) == \
           {'h_t_t_p_endpoint': {'path': '/api', 'callback': 'handler'}}


# Generated at 2022-06-11 01:02:29.850725
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:35.605056
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "fooBar": "Baz",
        "fooBar2": {
            "fooBar3": "Baz"
        },
        "fooBar4": [
            {
                "fooBar5": "Baz"
            }
        ],
        "HTTPEndpoint": "config.mydomain.com",
        "HTTPEndpoints": [
            {
                "HTTPEndpoint": "config.mydomain.com"
            }
        ],
        "Tags": {
            "Foo": "Bar"
        }
    }


# Generated at 2022-06-11 01:02:43.076060
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:54.801482
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    testdict = {
        "name": "social",
        "metaData": {
            "some": "metadata",
            "someTags": [
                {
                    "key": "hello",
                    "value": "there"
                },
                {
                    "key": "URL",
                    "value": "http://camel.com"
                }
            ]
        },
        "tags": {
            "someTagKey": "someTagValue"
        }
    }

    # Convert the keys in the dictionary and check that they have been
    # converted to snake case
    result = camel_dict_to_snake_dict(testdict)
    assert result['name'] == testdict['name']
    assert result['meta_data']['some'] == testdict['metaData']['some']

# Generated at 2022-06-11 01:03:05.503629
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.ec2 import boto3_conn, ec2_argument_spec

    ec2_argument_spec, ec2_connect_params = ec2_argument_spec()
    ec2_connect_params["boto_profile"] = ec2_connect_params.pop("profile_name")
    ec2_connect_params["aws_secret_access_key"] = ec2_connect_params.pop("secret_key")
    ec2_connect_params["aws_access_key_id"] = ec2_connect_params.pop("access_key")
    ec2_connect_params["region"] = ec2_connect_params.pop("region_name")

# Generated at 2022-06-11 01:03:17.207079
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test non-reversible conversion
    snake_dict = camel_dict_to_snake_dict({'A': 'B', 'C': {'D': 'E', 'F': 'G'}, 'H': [1, 2, 3]})
    assert snake_dict['a'] == 'B'
    assert snake_dict['c']['d'] == 'E'
    assert snake_dict['c']['f'] == 'G'
    assert snake_dict['h'] == [1, 2, 3]

    # Test reversible conversion
    snake_dict = camel_dict_to_snake_dict({'A': 'B', 'C': {'D': 'E', 'F': 'G'}, 'H': [1, 2, 3]}, reversible=True)
    assert snake_dict['a'] == 'B'
   

# Generated at 2022-06-11 01:03:28.416977
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'some_endpoint'}, reversible=False) == {'http_endpoint': 'some_endpoint'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'some_endpoint'}, reversible=True) == {'h_t_t_p_endpoint': 'some_endpoint'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'some_endpoint', 'Tags': {'Name': 'test_tag'}}, reversible=False, ignore_list=['Tags']) == {'http_endpoint': 'some_endpoint', 'tags': {'Name': 'test_tag'}}

# Generated at 2022-06-11 01:03:40.437052
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'bazFoo': 'A',
            'bazBar': 'B'
        },
        'fooBarBaz': {
            'bazFoo': 'C',
            'bazBar': 'D'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert(snake_dict == {
        'foo_bar': {
            'baz_foo': 'A',
            'baz_bar': 'B'
        },
        'foo_bar_baz': {
            'baz_foo': 'C',
            'baz_bar': 'D'
        }
    })



# Generated at 2022-06-11 01:03:49.270584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HttpEndpoint': 'h'}) == {'http_endpoint': 'h'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'h'}) == {'h_t_t_p_endpoint': 'h'}
    assert camel_dict_to_snake_dict(
            {'HttpEndpoint': 'h', 'HTTPEndpoint': 'a'}) == {'http_endpoint': 'h', 'h_t_t_p_endpoint': 'a'}

# Generated at 2022-06-11 01:04:00.446380
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:09.334971
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit tests for camel_dict_to_snake_dict
    """


# Generated at 2022-06-11 01:04:20.437169
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'SubnetId': 'subnet-9d4a7b6c', 'CidrBlock': '172.31.32.0/19'}) ==
           {'subnet_id': 'subnet-9d4a7b6c', 'cidr_block': '172.31.32.0/19'})


# Generated at 2022-06-11 01:04:30.923517
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected = {'snake_case'.upper(): 'camelCase'.lower(),
                'tags': {'such_doge': 'w_wow',
                         'very_dict': {'so_nested': 'such_wow'}
                         },
                'string_list': ['such_doge', 'many_wow'],
                'dict_list': [{'dict_key': 'dict_value'}]
                }

    camel_dict = {'snakeCase': 'camelCase',
                  'tags': {'suchDoge': 'w_wow',
                           'veryDict': {'soNested': 'such_wow'}
                           },
                  'stringList': ['suchDoge', 'many_wow'],
                  'dictList': [{'dictKey': 'dict_value'}]
                  }



# Generated at 2022-06-11 01:04:40.808711
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = {
        "DryRun": True,
        "Tags": [
            {
                "Key": "string",
                "Value": "string"
            }
        ],
        "TagSpecifications": [
            {
                "ResourceType": "string",
                "Tags": [
                    {
                        "Key": "string",
                        "Value": "string"
                    }
                ]
            }
        ]
    }
    x_out = camel_dict_to_snake_dict(x)

# Generated at 2022-06-11 01:04:49.832404
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # simple test case
    camel_test_dict = {'testKey': 'testVal'}
    assert camel_dict_to_snake_dict(camel_test_dict) == {'test_key': 'testVal'}
    # more complicated case with nested dict
    camel_test_dict = {'testKey': 'testVal', 'nestedDict': {'nestedKey': 'nestedVal'}}
    assert camel_dict_to_snake_dict(camel_test_dict) == {'test_key': 'testVal',
                                                        'nested_dict': {'nested_key': 'nestedVal'}}
    # test case with nested list
    camel_test_dict = {'testKey': 'testVal', 'nestedList': ['testVal1', 'testVal2']}

# Generated at 2022-06-11 01:05:00.631109
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    The basic test is the opposite of snake_dict_to_camel_dict

    The reversible test autogenerates values and then sees if they match
    after two conversions
    """

# Generated at 2022-06-11 01:05:08.306434
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': {'Bar': 'boo'}}, reversible=True) == {'foo': {'bar': 'boo'}}
    assert camel_dict_to_snake_dict({'Foo': {'Bar': ['Loo']}}, reversible=True) == {'foo': {'bar': ['Loo']}}
    assert camel_dict_to_snake_dict({'Foo': {'Bar': {'Loo': 'boo'}}}, reversible=True) == {'foo': {'bar': {'loo': 'boo'}}}

# Generated at 2022-06-11 01:05:19.559755
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'AccounID': 1,
        'keyName': 'John',
        'instanceList': [
            {
                'instanceId': 'i-123456789',
                'instanceState': {
                    'code': 16,
                    'name': 'running'
                }
            },
            {
                'instanceId': 'i-987654321',
                'instanceState': {
                    'code': 48,
                    'name': 'terminated'
                }
            }
        ],
        'tagSet': {
            'value': 'Example1',
            'key': 'ExampleKeyName'
        }
    }

# Generated at 2022-06-11 01:05:30.126524
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3'
        },
        'tags': {
            'key4': 'value4'
        },
        'key5': [
            {
                'key6': 'value6',
                'key7': [
                    {
                        'key8': 'value8'
                    }
                ]
            }
        ]
    }


# Generated at 2022-06-11 01:05:40.562343
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:52.178912
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    mydict = {'HTTPEndpoint': {'url': 'foobar', 'Paths': ['foo', 'bar'], 'IpAddress': '127.0.0.1'}}
    mykeylist = ['HTTPEndpoint', 'url', 'Paths', 'IpAddress']
    assert set(camel_dict_to_snake_dict(mydict).keys()) == set(mykeylist)
    mydict = {'HTTPEndpoint': {'tags': {'MyKey': 'MyValue'}}}
    mykeylist = ['HTTPEndpoint', 'tags', 'MyKey']
    assert set(camel_dict_to_snake_dict(mydict).keys()) == set(mykeylist)
    mydict = {'HTTPEndpoint': {'tags': {'MyKey': 'MyValue'}}}

# Generated at 2022-06-11 01:06:02.007873
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'prop1': 'value1',
        'prop2': {
            'subProp1': 'value2',
            'subProp2': {
                'subSubProp1': 'value3'
            }
        },
        'prop3': ['value4', {'subProp3': 'value5'}],
        'prop4': [{'subProp4': 'value6'}]
    }


# Generated at 2022-06-11 01:06:06.537196
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPCode":"200", "HTTPEndpoint" : "TestEndpoint" }
    snake_dict = {"http_code":"200", "http_endpoint" : "TestEndpoint" }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-11 01:06:14.863083
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'myTestKey': {
            'nested': {
                'myTestNestedKey': 'nested_test_value',
                'myTestNestedKey2': 'nested_test_value2'
            },
            'myTestNestedKey3': 'nested_test_value3'
        },
        'camelizedARN': 'arn:aws:s3:::my_bucket/my_key.jpg',
        'target_group_name': 'my_target_group'
    }

# Generated at 2022-06-11 01:06:18.723745
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    with open("test/unit/plugins/modules/cloud/aws/test_data.json") as data_file:
        data = json.load(data_file)

    try:
        assert 'instance_type' in camel_dict_to_snake_dict(data), "missing instance type"
    except AssertionError as exc:
        print('AssertionError: %s' % exc)
        raise



# Generated at 2022-06-11 01:06:28.340517
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # simple test
    assert camel_dict_to_snake_dict({"foo": "bar"}) == {"foo": "bar"}

    # test with complex type
    res = {"foo": {"bar": "baz"}, "qux": "quux"}
    assert camel_dict_to_snake_dict({"foo": {"bar": "baz"}, "qux": "quux"}) == res

    # test with unicode
    res = {"foo": u"bar", "qux": u"quux"}
    assert camel_dict_to_snake_dict({"foo": u"bar", "qux": u"quux"}) == res

    # test with integers
    res = {"foo": 42, "qux": "quux"}

# Generated at 2022-06-11 01:06:36.714622
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:47.260732
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'myCamelCaseKey': 'myCamelValue',
        'myOtherCamelCaseKey': 'myOtherCamelValue',
        'myIP': '192.168.1.1'
    }

    assert camel_dict_to_snake_dict(camel_dict) == {
        'my_camel_case_key': 'myCamelValue',
        'my_other_camel_case_key': 'myOtherCamelValue',
        'my_i_p': '192.168.1.1'
    }


# Generated at 2022-06-11 01:06:57.474103
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'HTTPEndpoint': {
            'Path': 'string',
            'Protocol': 'HTTP',
            'AuthorizationType': 'NONE',
            'AuthorizerId': 'string',
            'Method': 'GET'
        },
        'Name': 'Test-Endpoint',
        'Tags': {
            'Project': 'Production',
            'CostCenter': '12345'
        }
    }


# Generated at 2022-06-11 01:07:07.950956
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'Echo': True,
                 'InstanceId': '1234',
                 'SSMAssociationIds': ['a', 'b', 'c'],
                 'Tags': {
                     'Key': 'Value',
                     'CamelCaseKey': 'CamelCaseValue',
                     'snake_case_key': 'snake_case_value',
                     'http_endpoint': '123',
                     'mixed_Case_KEY': 'mixed_Case_Value',
                     'tags': {
                         'CamelCaseKey': 'CamelCaseValue',
                         'snake_case_key': 'snake_case_value',
                         'http_endpoint': '123',
                         'mixed_Case_KEY': 'mixed_Case_Value',
                     }
                 }
                 }

# Generated at 2022-06-11 01:07:17.426730
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_data = {
        "TestKey": "TestValue",
        "SubObject": {
            "SubKey": "SubNestedValue",
        },
        "SubArray": [
            {
                "SubItemKey": "SubItemValue"
            }
        ],
        "TagMap": {
            "Tags": {
                "TagKey1": "TagValue1",
                "TagKey2": "TagValue2",
            },
        }
    }


# Generated at 2022-06-11 01:07:25.834397
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "protocol": "HTTP",
        "healthCheckPath": "/health",
        "interval": 30,
        "port": 80,
        "timeout": 5,
        "healthyThresholdCount": 5,
        "unhealthyThresholdCount": 2
    }

    snake_dict = {
        "protocol": "HTTP",
        "health_check_path": "/health",
        "interval": 30,
        "port": 80,
        "timeout": 5,
        "healthy_threshold_count": 5,
        "unhealthy_threshold_count": 2
    }

    assert(snake_dict == camel_dict_to_snake_dict(camel_dict))
    assert(camel_dict == snake_dict_to_camel_dict(snake_dict))




# Generated at 2022-06-11 01:07:34.268538
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict_1 = {
        "DBInstanceIdentifier": "db1",
        "Tags": {
            "Key1": "Value1",
            "Key2": "Value2",
            "Key3": "Value3"
        }
    }

    snake_dict_1 = {
        "db_instance_identifier": "db1",
        "Tags": {
            "Key1": "Value1",
            "Key2": "Value2",
            "Key3": "Value3"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict_1) == snake_dict_1


# Generated at 2022-06-11 01:07:43.626928
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:53.216588
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create a sample nested dictionary
    test_dict = {'TestKey': 'test_value',
                 'TestText': {'TestKey': 'test_value',
                              'TestList': [{'TestKey': 'test_value'}, {'TestKey': 'test_value'}]},
                 'TestMyList': [{'TestKey': 'test_value'}, {'TestKey': 'test_value'}]}

    # Convert the camelcase dictionary to snake case dictionary
    snake_dict = camel_dict_to_snake_dict(test_dict)

    # Validate the snakecase key names
    assert("test_key" in snake_dict)
    assert("test_text" in snake_dict)
    assert("test_my_list" in snake_dict)

    # Validate the snakecase value names

# Generated at 2022-06-11 01:08:01.203329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'SomeKey': 'SomeValue1',
        'SomeOtherKey': 'SomeValue2',
        'OtherKey': 'SomeValue3',
        'HTTPEndpoint': {
            'HTTPEndpointDescription': 'my http endpoint',
            'HTTPPath': 'mypath',
        },
        'Subnets': ['sn1', 'sn2'],
    }

# Generated at 2022-06-11 01:08:09.405991
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Key1': 'Val1', 'Key2': 'Val2'}) == {'key1': 'Val1', 'key2': 'Val2'}
    assert camel_dict_to_snake_dict({'Key1': {'Key1-1': 'Val1-1', 'Key1-2': 'Val1-2'}, 'Key2': 'Val2'}) == {'key1': {'key1_1': 'Val1-1', 'key1_2': 'Val1-2'}, 'key2': 'Val2'}