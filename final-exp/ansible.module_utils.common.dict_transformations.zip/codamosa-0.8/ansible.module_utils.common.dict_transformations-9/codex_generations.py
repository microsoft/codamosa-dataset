

# Generated at 2022-06-11 00:58:26.150304
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test module for target_group.camel_dict_to_snake_dict
    """

# Generated at 2022-06-11 00:58:36.600541
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {1: {4: 1, 5: {6: {10: 1}}}, 2: 2, 3: 3}
    d2 = {1: {4: 1, 5: {6: {10: 2}}}, 2: 4, 3: 3, 7: 7}
    d3 = {1: {4: 1, 5: {6: {100: 2}}}, 2: 4, 3: 3, 7: 7}

    excepted_result = ({}, {7: 7, 2: 4, 1: {5: {6: {10: 2}}}})
    result = recursive_diff(d1, d2)
    assert result == excepted_result

    excepted_result = ({}, {7: 7, 2: 4, 1: {5: {6: {100: 2}}}})
    result = recursive_diff

# Generated at 2022-06-11 00:58:43.259949
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {"a": 1, "b": {"c": 2}, "d": 3}
    dict2 = {"a": 1, "b": {"d": 1, "c": 2}, "e": 4}
    diff = recursive_diff(dict1, dict2)
    assert diff[0] == {"b": {"d": None}, "d": 3}
    assert diff[1] == {"b": {"d": 1}, "e": 4}

    dict3 = {"a": 1, "b": {"c": 2}, "d": 3}
    dict4 = {"a": 2, "b": {"c": 2}, "d": 3}
    diff = recursive_diff(dict3, dict4)
    assert diff[0] == {"a": 1}
    assert diff[1] == {"a": 2}

# Generated at 2022-06-11 00:58:55.291412
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:04.450864
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def check(j, expected, reversible=False):
        r = camel_dict_to_snake_dict(j, reversible)
        assert r == expected

    j = {"fooBar": {"bazBuz": [{'gooGoo': 'foo bar'}, {'gooGoo': 'foo baz'}]}, "HTTPSListener": {'EndPoint': 'foo'},
         'TargetGroupARNs': ['arn:0:0:0:0:0:0:0:0:0:0:0:0:0:0', 'arn:0:0:0:0:0:0:0:0:0:0:0:0:0:0']}


# Generated at 2022-06-11 00:59:16.067079
# Unit test for function dict_merge
def test_dict_merge():

    a = {'a': 1, 'b': {'b1': 1, 'b2': 2}, 'c': 3, 'd': {'d1': {'d2': 3}}}
    b = {'a': 2, 'b': {'b2': 3, 'b3': 4}, 'c': 5, 'd': {'d1': {'d3': 1}}}
    expected = {'a': 2, 'b': {'b1': 1, 'b2': 3, 'b3': 4}, 'c': 5, 'd': {'d1': {'d2': 3, 'd3': 1}}}
    assert dict_merge(a, b) == expected
    assert dict_merge(b, a) == expected


# Generated at 2022-06-11 00:59:23.620881
# Unit test for function recursive_diff
def test_recursive_diff():
    expected_result = ({'a': {'b': {'c': 1}}}, {'a': {'b': {'d': 2}}})
    dict1 = {'a': {'b': {'c': 1}}, 'e': 3}
    dict2 = {'a': {'b': {'d': 2}}, 'e': 3}
    assert recursive_diff(dict1, dict2) == expected_result
    assert recursive_diff(dict2, dict1) == (expected_result[1], expected_result[0])

    expected_result = ({'a': 1}, {'a': 2})
    dict1 = {'a': 1}
    dict2 = {'a': 2}
    assert recursive_diff(dict1, dict2) == expected_result
    assert recursive_diff(dict2, dict1)

# Generated at 2022-06-11 00:59:35.249082
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({"k1": {"k2": {"k3": 123}}}, {"k1": {"k2": {"k4": 567}}}) == \
           {"k1": {"k2": {"k3": 123, "k4": 567}}}
    assert dict_merge({"k1": {"k2": {"k3": 123}}}, {"k1": {"k2": {"k3": 567}}}) == \
           {"k1": {"k2": {"k3": 567}}}
    assert dict_merge({"k1": {"k2": {"k3": 123}}}, {"k1": {"k2": {"k3": {"k4": 567}}}}) == \
           {"k1": {"k2": {"k3": {"k4": 567}}}}

# Generated at 2022-06-11 00:59:45.694221
# Unit test for function dict_merge

# Generated at 2022-06-11 00:59:56.368355
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'key2': 1}}
    b = {'key1': {'key2': 2}}
    c = {'key1': {'key2': 2, 'key3': 3}}
    d = {'key1': {'key2': 2, 'key3': {'key4': 4}}}
    e = {'key1': 4}
    f = {}
    g = {'key1': {'key2': {'key3': 3}}}
    h = {'key1': {'key2': []}}
    i = {'key1': {'key2': [1, 2, 3]}}
    j = {'key1': None, 'key2': 100}
    k = {'key1': {'key2': {'key3': {'key4': None}}}}

# Generated at 2022-06-11 01:00:15.546262
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': {'Id': 'testId', 'Path': 'testPath', 'Protocol': 'HTTP'},
         'Tags': {'TAG1': 'value1', 'TAG2': 'value2'}}
    ) == {'h_t_t_p_endpoint': {'id': 'testId', 'path': 'testPath', 'protocol': 'HTTP'},
          'tags': {'TAG1': 'value1', 'TAG2': 'value2'}}


# Generated at 2022-06-11 01:00:27.206448
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:36.572043
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aB': 'cD'}) == {'a_b': 'cD'}
    assert camel_dict_to_snake_dict({'a_b': 'c'}) == {'a_b': 'c'}
    assert camel_dict_to_snake_dict({'aB': 'cD', 'e_f': 'h'}) == {'a_b': 'cD', 'e_f': 'h'}
    assert camel_dict_to_snake_dict({'aB': [{'cD': 'eF'}]}) == {'a_b': [{'c_d': 'eF'}]}

# Generated at 2022-06-11 01:00:49.254598
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    obj = {
            "HTTPEndpoints": [{
                "HTTPEndpoint": {
                    "Host": "example.com",
                    "RelativePath": "/abc"
                }
            }],
            "Tags": {"Key": "value"}
        }

    assert camel_dict_to_snake_dict(obj) == {
        "http_endpoints": [
            {"http_endpoint": {"host": "example.com", "relative_path": "/abc"}}
        ],
        "tags": {"Key": "value"}
    }


# Generated at 2022-06-11 01:00:58.635282
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_1 = {
        "HTTPEndpoint": {
            'URL': "https://10.0.0.1:1234/",
            'AccessKey': "1234abcd-12ab-34cd-56ef-1234567890ab",
            'SecretKey': "abcdefgiklmnopqrstuvwxyz",
            'VerifySecretKey': True,
            'ConnectionCipher': "TLSv1_2",
            'ObjectPrefix': "protected/",
            'S3ForcePathStyle': True,
            'S3VirtualAddressingStyle': None,
            'EndpointType': "S3Compatible"},
        "VaultARN": "arn:aws:backup:us-east-1:111112345678:vault:test-vault"}
    test_dict_2

# Generated at 2022-06-11 01:01:09.704217
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:18.752618
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelTestDict = {'MyCamelCase': 'camelCase', 'myCamelCase': {'deepCamel': 'deepCamel'}, 'camelCase': 'camelcase',
                     'CamelCase': 'CamelCase'}
    snakeTestDict = {'my_camel_case': 'camelCase', 'my_camel_case': {'deep_camel': 'deepCamel'},
                     'camel_case': 'camelcase', 'camel_case': 'CamelCase'}

    assert camel_dict_to_snake_dict(camelTestDict, reversible=False) == snakeTestDict


# Generated at 2022-06-11 01:01:25.649554
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {}}) == {'http_endpoint': {}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'string'}}) == {'http_endpoint': {'url': 'string'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'string'}}, reversible=True) == {'h_t_t_p_endpoint': {'url': 'string'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'string'}}, reversible=True) == camel_dict_to_snake_dict({'HttPEndPoInt': {'uRL': 'string'}}, reversible=True)
    assert camel

# Generated at 2022-06-11 01:01:37.203441
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:47.083942
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test 1: Basic test
    camel_dict = {'HTTPEndpoint': 'http://www.example.com', 'Params': {'Param': [{'Name1': 'Value1'}]}}
    test_dict = camel_dict_to_snake_dict(camel_dict)
    expected_dict = {'h_t_t_p_endpoint': 'http://www.example.com', 'params': {'param': [{'name1': 'Value1'}]}}
    assert test_dict == expected_dict

    # Test 2: Test for preserving order of elements
    camel_dict2 = {'HTTPEndpoint': 'http://www.example.com', 'tags': {'tag': 'foo'}, 'Params': {'Param': [{'Name1': 'Value1'}]}}
    test_

# Generated at 2022-06-11 01:01:58.541600
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "HTTPEndpoint": {
            "URL": "http://dummy.test/endpoint"
        },
        "HTTPHeader": [
            {
                "Name": "x-test",
                "Value": "test-header-value"
            }
        ]
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    expected_snake_dict = {
        "h_t_t_p_endpoint": {
            "url": "http://dummy.test/endpoint"
        },
        "h_t_t_p_header": [
            {
                "name": "x-test",
                "value": "test-header-value"
            }
        ]
    }

    assert snake_dict == expected_snake

# Generated at 2022-06-11 01:02:10.673121
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'OneKey': {'AnotherKey': 'AnotherValue'}}) == {'one_key': {'another_key': 'AnotherValue'}}
    assert camel_dict_to_snake_dict({"LogUri": "/uri", "WorkerType": "optional"}) == {'log_uri': '/uri', 'worker_type': 'optional'}

    assert camel_dict_to_snake_dict({'OneKey': {'AnotherKey': 'AnotherValue'}}, reversible=True) == {'one_key': {'another_key': 'AnotherValue'}}

# Generated at 2022-06-11 01:02:16.346055
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # The following is a simple test case that can be used to validate that the
    # function has no adverse effects on dict's that have no camel case
    # characters.
    #
    # This test should fail when the implementation has been changed to
    # introduce bugs in the code.
    original_dict = {
        "aws_name_tag": "my tag",
        "vpc_id": "VPC_ID",
        "vpc_ids": ["VPC_ID_1", "VPC_ID_2"],
        "vpc_id_group": {
            "test1": "test2",
            "test4": [
                "test5",
                "test6"
            ]
        }
    }

    # Since camel_dict_to_snake_dict does not modify the original dict, but
    # returns a new

# Generated at 2022-06-11 01:02:26.375235
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test of the function camel_dict_to_snake_dict
    """
    # Test the basic of camel_dict_to_snake_dict
    x = {'Test': 'test',
         'Test1': 'test1',
         'Test2': [{'Test3': 'test3',
                    'Test4': {'Test5': 'test5'},
                    'test6': 'test6',
                    'test7': [{'test8': 'test8'}]},
                   {'test9': 'test9'}],
         'test10': {'test11': 'test11'},
         'test12': [{'test13': 'test13'}]}

# Generated at 2022-06-11 01:02:34.015034
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_test_dict = {
        "Foo": "foo",
        "FooBar": "foobar",
        "fooBar": "foobar",
        "fooBarBaz": "foobarbaz",
        "FooBarBaz": "foobarbaz",
        "_Foo": "_foobar",
        "__Foo": "__foobar",
        "_foo": "_foobar",
        "__foo": "__foobar",
        "__foo__": "__foobar__",
        "foo__": "foobar__",
        "__fooBar": "__foobar",
        "_HTTPEndpoint": "_h_t_t_p_endpoint",
        "HTTPEndpoint": "h_t_t_p_endpoint"
    }


# Generated at 2022-06-11 01:02:43.098086
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:54.800075
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test simple
    assert camel_dict_to_snake_dict({'A': {'B': {'C': 1}}}, reversible=False) == {
        'a': {'b': {'c': 1}}}

    # Test with reversible
    assert camel_dict_to_snake_dict({'A': {'B': {'C': 1}}}, reversible=True) == {
        'a': {'b': {'c': 1}}}

    # Test plural
    assert camel_dict_to_snake_dict({'TargetGroupARNs': ['arn1', 'arn2']}, reversible=False) == {
        'target_group_a_r_ns': ['arn1', 'arn2']}

    # Test with tags

# Generated at 2022-06-11 01:03:04.789118
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""
    my_dict = {
        'a': 1,
        'b_c': 2,
        'HTTPEndpoint': {
            'a': 2
        }
    }

    returned_dict = camel_dict_to_snake_dict(my_dict, reversible=True)
    assert returned_dict == {'a': 1, 'b_c': 2, 'h_t_t_p_endpoint': {'a': 2}}

    returned_dict = camel_dict_to_snake_dict(my_dict)
    assert returned_dict == {'a': 1, 'b_c': 2, 'http_endpoint': {'a': 2}}



# Generated at 2022-06-11 01:03:15.785813
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test camel_dict_to_snake_dict"""

    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('httpEndpoinT') == 'http_endpoin_t'
    assert _camel_to_snake('_httpEndpoinT') == '_http_endpoin_t'
    assert _camel_to_snake('httpEndpoint', True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('_httpEndpoint', True) == '_h_t_t_p_endpoint'
    assert _camel_to_snake('aBBaCC', True) == 'a_b_b_a_c_c'
    assert _camel_

# Generated at 2022-06-11 01:03:27.592255
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:40.236547
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "Endpoint": "http://polling.weather.gov/v1/forecast/hourly/CAZ043?product=hourly_forecast&format=application/json&Unit=e&LabelType=C",
            "RESTEndpoint": "http://polling.weather.gov/v1/forecast/hourly/CAZ043?product=hourly_forecast&format=application/json&Unit=e&LabelType=C",
            "Tags": {"abc": 1, "aBc": 2, "Abc": 3}
        }
    }
    result = camel_dict_to_snake_dict(test_dict, True)

    assert ("Tags" in result["h_t_t_p_endpoint"])

# Generated at 2022-06-11 01:03:49.129627
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'GlobalSecondaryIndexes': [],
        'ProvisionedThroughput': {
            'ReadCapacityUnits': 10,
            'WriteCapacityUnits': 10
            },
        'TableName': 'test-dynamodb-table'
        }
    snake_dict_conv1 = {
        'global_secondary_indexes': [],
        'provisioned_throughput': {
            'read_capacity_units': 10,
            'write_capacity_units': 10
            },
        'table_name': 'test-dynamodb-table'
        }

# Generated at 2022-06-11 01:04:00.280906
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'foo',
                  'HTTPSEndpoint': 'bar',
                  'fooBar': 'baz',
                  'snakeAndMongoose': 'snafu',
                  'Tags':
                      {'foo': 'bar',
                       'Foo': 'Bar'}}
    expected = {'h_t_t_p_endpoint': 'foo',
                'h_t_t_p_s_endpoint': 'bar',
                'foo_bar': 'baz',
                'snake_and_mongoose': 'snafu',
                'tags':
                    {'foo': 'bar',
                     'Foo': 'Bar'}}
    actual = camel_dict_to_snake_dict(camel_dict)
    assert expected == actual



# Generated at 2022-06-11 01:04:09.242839
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:20.335555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'HTTPEndpoint': {'URL': 'http://example.com', 'Protocol': 'https'}}

    assert camel_dict_to_snake_dict(camel_dict) == {'h_t_t_p_endpoint': {'url': 'http://example.com', 'protocol': 'https'}}

    reversible_camel_dict = {'HTTPEndpoint': {'URL': 'http://example.com', 'Protocol': 'https'}}

    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == {'h_t_t_p_endpoint': {'url': 'http://example.com', 'protocol': 'https'}}


# Generated at 2022-06-11 01:04:30.835056
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'http://www.google.com',
                  'HostDiff': [{
                      'Key1': 'Value1',
                      'Key2': 'Value2'}]}

    # test normal dict
    snake_dict = camel_dict_to_snake_dict(camel_dict, False)
    assert snake_dict.get('http_endpoint') == 'http://www.google.com'

    # test list of dicts
    assert len(snake_dict.get('host_diff')) == 1
    for item in snake_dict.get('host_diff'):
        assert item.get('key1') == 'Value1'
        assert item.get('key2') == 'Value2'

    # test reversible dict
    snake_dict = camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:37.871910
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test the normal class of camel dict
    test_dict1 = {'fooBar': 1, 'bazMoo': 2}
    test_dict2 = camel_dict_to_snake_dict(test_dict1)
    assert test_dict2 == {'foo_bar': 1, 'baz_moo': 2}

    test_dict1 = {'fooFoo': 1, 'bazBaz': [1, 2, 3]}
    test_dict2 = camel_dict_to_snake_dict(test_dict1)
    assert test_dict2 == {'foo_foo': 1, 'baz_baz': [1, 2, 3]}

    # Test the reversible class of camel dict
    test_dict1 = {'fooBar': 1, 'bazMoo': 2}

# Generated at 2022-06-11 01:04:48.120229
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    update = {'Tags': {'User-Name': 'test'}, 'Name': 'test', 'UserData': 'test', 'HTTPEndpoint': 'test', 'TargetGroups': [{'HealthCheckIntervalSeconds': 1000,'HealthCheckPath': '/test', 'Name': 'test', 'Port': 1234, 'Protocol': 'HTTP', 'Stickiness': 'test'}]}
    update_expected = {'name': 'test', 'user_data': 'test', 'target_groups': [{'health_check_interval_seconds': 1000, 'health_check_path': '/test', 'name': 'test', 'port': 1234, 'protocol': 'HTTP', 'stickiness': 'test'}], 'h_t_t_p_endpoint': 'test', 'tags': {'user-name': 'test'}}

   

# Generated at 2022-06-11 01:04:57.838871
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'foo': 'bar'}) == {'foo': 'bar'}
    assert camel_dict_to_snake_dict({'foo': 'bar', 'FOOBAR': {'FOO': 'BAR'}}) == {'foo': 'bar', 'f_o_o_b_a_r': {'f_o_o': 'BAR'}}
    assert camel_dict_to_snake_dict({'foo': 'bar', 'FOOBAR': ['FOO', 'BAR']}) == {'foo': 'bar', 'f_o_o_b_a_r': ['FOO', 'BAR']}

# Generated at 2022-06-11 01:05:04.061465
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    a = {
        "HTTPEndpoint": "sg-12345678",
        "Types": [
            "AWS::EC2::SecurityGroup",
            "AWS::EC2::NetworkInterface",
            "AWS::EC2::Instance"
        ],
        "Tags": {
            "Test": "test",
            "MyTag": "Tag"
        }
    }
    b = {
        "h_t_t_p_endpoint": "sg-12345678",
        "types": [
            "AWS::EC2::SecurityGroup",
            "AWS::EC2::NetworkInterface",
            "AWS::EC2::Instance"
        ],
        "tags": {
            "Test": "test",
            "MyTag": "Tag"
        }
    }

# Generated at 2022-06-11 01:05:17.445406
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # sample dict to test function with
    test_camel_dict = {'Tags': {'Test1': 'Value1'},
                       'Test2': 'Value2',
                       'HTTPEndpoint': {'URL': 'Value3', 'Enabled': True}}

    # sample dict should be turned into this result
    expected_result = dict(Tags={'Test1': 'Value1'},
                           test_2='Value2',
                           http_endpoint={'URL': 'Value3', 'Enabled': True})

    # do the conversion to the test dict
    result = camel_dict_to_snake_dict(test_camel_dict)

    # check that the conversion matches the expected result
    assert result == expected_result

    # check that going from camel to snake and back doesn't lose info
    assert camel_dict_to_snake

# Generated at 2022-06-11 01:05:25.613857
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'cake': 'lie', 'HTTPEndpoint': 'cake', 'TargetGroupARNs': [{'Name': 'lie'}]}
    expected_snake_dict = {'cake': 'lie', 'h_t_t_p_endpoint': 'cake', 'target_group_ar_ns': [{'name': 'lie'}]}
    actual_snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert actual_snake_dict == expected_snake_dict


# Generated at 2022-06-11 01:05:32.499335
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        "HTTPHeaders": [
            {
                "Name": "string",
                "Value": "string"
            }
        ],
        "HTTPPort": 123,
        "HTTPSPort": 123,
        "IPAddressType": "string",
        "IsDefault": True,
        "PortMappings": [
            {
                "ApplicationPort": 123,
                "ContainerPort": 123,
                "HostPort": 123
            }
        ],
        "Protocol": "string",
        "Tags": [
            {
                "Key": "string",
                "Value": "string"
            }
        ]
    }

    snake_dict = camel_dict_to_snake_dict(test_dict)
    assert 'http_headers' in snake_dict

# Generated at 2022-06-11 01:05:43.381379
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Ensure that we can snakecase a dictionary and recamelize without loss of data.
    """

    camel_dict = {"FooBar": {"baz": 5}, "FizzBuzz": 7, "HTTPResponse": True, "targetGroups": [{"foo": "bar"}, "baz"]}

    # First roundtrip
    roundtrip_dict = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict))

    assert roundtrip_dict == camel_dict

    # Second roundtrip
    roundtrip_dict = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict, reversible=True))


# Generated at 2022-06-11 01:05:53.351226
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected_output= {
        'tag_filters': [{'key': 'Project', 'value': 'Infrastructure'},
                        {'key': 'Environment', 'value': 'test'}],
        'vpc_id': 'vpc-0bb0e2fe9d9d5f5a5'}
    input_data = {
        'TagFilters': [{'Key': 'Project', 'Value': 'Infrastructure'},
                       {'Key': 'Environment', 'Value': 'test'}],
        'VpcId': 'vpc-0bb0e2fe9d9d5f5a5'}
    output = camel_dict_to_snake_dict(input_data)
    assert output == expected_output


# Generated at 2022-06-11 01:06:03.088168
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'A': 1, 'B': {'C': 3, 'D': 4}, 'E': [{'F': 5}, {'G': 6}]}
    assert {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [{'f': 5}, {'g': 6}]} == camel_dict_to_snake_dict(camel_dict)
    assert {'e': [{'g': 6}, {'f': 5}], 'b': {'d': 4, 'c': 3}, 'a': 1} == camel_dict_to_snake_dict(camel_dict, reversible=True)

# Generated at 2022-06-11 01:06:11.858554
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'A': 'a',
        'B': 'b',
        'C': 'c',
        'D': 'd',
        'E': 'e',
        'F': 'f',
        'G': 'g',
        'H': 'h',
        'HTTPEndpoint': 'http_endpoint',
        'HTTP_Endpoint': 'http_endpoint',
        'HttpEndpoint': 'http_endpoint',
        'Nested': {
            'Key': 'value',
            'Nested': {
                'Key': 'value'
            }
        },
        'Tags': {
            'Name': 'test'
        }
    }

# Generated at 2022-06-11 01:06:22.513011
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "httpEndpoint": {
            "endpointConfiguration": {
                "types": [
                    "PRIVATE"
                ]
            },
            "endpointDescription": "A description",
            "endpointName": "Name of endpoint",
            "vpcEndpointPolicySupported": True,
            "serviceName": "my-service"
        },
        "Tags": {
            "key": "value"
        }
    }


# Generated at 2022-06-11 01:06:32.673650
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    This is a unit test for the function camel_dict_to_snake_dict
    """

    test_camel = {'SimpleKey': 'simple_value', 'CompoundKey': {
        'SimpleKey': 'simple_value', 'CompoundKey': {'SimpleKey': 'simple_value'}}}
    test_snake = {'simple_key': 'simple_value', 'compound_key': {
        'simple_key': 'simple_value', 'compound_key': {'simple_key': 'simple_value'}}}
    if test_snake != camel_dict_to_snake_dict(test_camel):
        raise AssertionError


# Generated at 2022-06-11 01:06:41.892394
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    d = {'FirstKey': 'ValueX', 'SecondKey': 'ValueY', 'Targets': {'HTTPTargets': [{'HTTPEndpoint': 'https://blah.blah.com'}]}}
    answer = {'first_key': 'ValueX', 'targets': {'http_targets': [{'http_endpoint': 'https://blah.blah.com'}]}, 'second_key': 'ValueY'}
    assert camel_dict_to_snake_dict(d) == answer

    d2 = {'mixedCaseKey': 'value', 'MixedCaseKey': 'value'}
    answer2 = {'mixed_case_key': 'value', 'mixed_case_key_0': 'value'}
    assert camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:56.605894
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"fooBar": 123,
                 "Foo": [{"fooBar": 123, "aBcDef": 456}, "Bar", "fooBar"],
                 "baz": {"fooBar": 123, "Foo": {"fooBar": 123, "abc": 456}}}
    expected_dict = {"foo_bar": 123,
                     "foo": [{"foo_bar": 123, "a_bc_def": 456}, "Bar", "fooBar"],
                     "baz": {"foo_bar": 123, "foo": {"foo_bar": 123, "abc": 456}}}
    result = camel_dict_to_snake_dict(test_dict)
    assert result == expected_dict



# Generated at 2022-06-11 01:07:07.219743
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:14.721436
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:23.021003
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # A simple test
    test_data = {
        'baz': 'bam',
        'foo': {
            'bar': 'baz',
            'Foo': {
                'bar': 'baz'
            }
        }
    }
    expected_results = {'baz': 'bam', 'foo': {'bar': 'baz', 'foo': {'bar': 'baz'}}}
    assert camel_dict_to_snake_dict(test_data) == expected_results

    # A test with two keys that require reversing
    test_data = {
        'baz': 'bam',
        'HttpEndpoint': {
            'bar': 'baz',
            'convertMe': 'converted'
        }
    }

# Generated at 2022-06-11 01:07:33.224080
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    mydict = {'Foo': 'foo', 'Bar': 'bar', 'BazFoo': 'bazfoo', 'BazBar': 'bazbar'}
    mylist = ['Foo', 'Bar']
    snake_dict = {'bar': 'bar', 'baz_foo': 'bazfoo', 'baz_bar': 'bazbar', 'foo': 'foo'}

    assert camel_dict_to_snake_dict(mydict) == snake_dict
    assert camel_dict_to_snake_dict(mydict, reversible=True) == {'bar': 'bar', 'h_t_t_p_endpoint': 'bazfoo', 'b_a_z_bar': 'bazbar', 'foo': 'foo'}

# Generated at 2022-06-11 01:07:42.973859
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    original = {
        "AttributeName": "user_name",
        "AttributeType": "S",
        "KeySchema": [
            {
                "AttributeName": "role",
                "KeyType": "HASH"
            },
            {
                "AttributeName": "user_name",
                "KeyType": "RANGE"
            }
        ],
        "ProvisionedThroughput": {
            "ReadCapacityUnits": 5,
            "WriteCapacityUnits": 5
        },
        "TableName": "accounts"
    }

    # Test normal case
    camel_to_snake = camel_dict_to_snake_dict(original)
    assert camel_to_snake['attribute_name'] == 'user_name'

# Generated at 2022-06-11 01:07:52.632451
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TestCase': {'dromedaryCase': 'value',
                               'HTTPEndpoint': 'value',
                               'Tags': [{'Key': 'value'},
                                        {'Key': 'value'}]},
                  'trueCamelCase': 'value',
                  'TrueCamelCase': 'value',
                  'True': 'value'}
    expected = {'test_case': {'dromedary_case': 'value',
                              'h_t_t_p_endpoint': 'value',
                              'tags': [{'key': 'value'},
                                       {'key': 'value'}]},
                'true_camel_case': 'value',
                'true_camel_case': 'value',
                'true': 'value'}

    # Test default

# Generated at 2022-06-11 01:08:00.858728
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Simple test of conversion of a basic camelized dict
    """

    camel_dict = {
        "HTTPEndpoint": "http://ec2.amazonaws.com",
        "HTTPPath": "/",
        "HTTPMethod": "GET",
        "HTTPHeaders": [
            {
                "HTTPHeaderName": "User-Agent",
                "HTTPHeaderValue": "ansible"
            }
        ]
    }

    snake_dict = {
        "http_endpoint": "http://ec2.amazonaws.com",
        "http_path": "/",
        "http_method": "GET",
        "http_headers": [
            {
                "http_header_name": "User-Agent",
                "http_header_value": "ansible"
            }
        ]
    }

   

# Generated at 2022-06-11 01:08:09.168536
# Unit test for function camel_dict_to_snake_dict