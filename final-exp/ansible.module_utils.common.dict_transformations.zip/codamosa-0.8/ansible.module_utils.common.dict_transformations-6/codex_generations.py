

# Generated at 2022-06-11 00:58:28.473752
# Unit test for function recursive_diff
def test_recursive_diff():
    # Empty Dicts
    assert recursive_diff({}, {},) == None
    assert recursive_diff({}, {}) == None
    assert recursive_diff({}, {'foo': 'bar'}) == ({}, {'foo': 'bar'})
    assert recursive_diff({'foo': 'bar'}, {}) == ({'foo': 'bar'}, {})
    assert recursive_diff({'foo': 'bar'}, {'foo': 'bar'}) == None
    assert recursive_diff({'foo': None}, {'foo': 'bar'}) == ({'foo': None}, {'foo': 'bar'})
    assert recursive_diff({'foo': None}, {'foo': None}) ==  None
    assert recursive_diff({'foo': {}}, {'foo': 'bar'}) == ({'foo': {}}, {'foo': 'bar'})

# Generated at 2022-06-11 00:58:38.419121
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:58:49.267072
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test recursive_diff function"""
    # Test simple dictionary with values
    dict1 = {'a': 'foo'}
    dict2 = {'a': 'bar'}
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': 'foo'}, {'a': 'bar'})

    # Test simple dictionary with values
    dict1 = {'a': 'foo'}
    dict2 = {'b': 'bar'}
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': 'foo'}, {'b': 'bar'})

    # Test simple dictionary with values
    dict1 = {'a': 'foo', 'b': 'bar'}
    dict2 = {'c': 'foo', 'd': 'bar'}
    result = recursive_diff

# Generated at 2022-06-11 00:59:00.565880
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake("HTTPEndpoint") == "http_endpoint"
    assert _camel_to_snake("HTTPCookieExpirationDate") == "http_cookie_expiration_date"
    assert _camel_to_snake("ARNs", reversible=True) == "a_r_ns"

    assert _snake_to_camel("http_endpoint") == "HttpEndpoint"
    assert _snake_to_camel("http_endpoint", capitalize_first=True) == "HTTPEndpoint"
    assert _snake_to_camel("a_r_ns", reversible=True) == "ARNs"

    assert snake_dict_to_camel_dict({'http_endpoint': "foo"}) == {'HttpEndpoint': "foo"}
    assert snake_dict

# Generated at 2022-06-11 00:59:10.349051
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:20.484978
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:31.257155
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'a': 'b'}, {'a': 'c'}) == ({'a': 'b'}, {'a': 'c'})
    assert recursive_diff({'a': 'b'}, {'b': 'c'}) == ({'a': 'b'}, {'b': 'c'})
    assert recursive_diff({'a': {'b': 'c'}}, {'a': {'b': 'd'}}) == ({'a': {'b': 'c'}}, {'a': {'b': 'd'}})
    assert recursive_diff({'a': {'b': {'c': 'd'}}}, {'a': {'b': {'c': 'd'}}}) is None

# Generated at 2022-06-11 00:59:37.378303
# Unit test for function dict_merge
def test_dict_merge():
    d1 = dict(a=1, b=2, c=dict(d=3, e=4))
    d2 = dict(e=5, c=dict(d=6, f=7))
    r = dict_merge(d1, d2)
    assert r == dict(a=1, b=2, c=dict(d=6, e=5, f=7))

# Generated at 2022-06-11 00:59:47.176729
# Unit test for function recursive_diff
def test_recursive_diff():
    # Two identical dictionaries
    dict1 = {'foo': {'bar': {'baz': 'quux'}}}
    dict2 = {'foo': {'bar': {'baz': 'quux'}}}
    result = recursive_diff(dict1, dict2)
    assert result is None

    # Two dictionaries with different values
    dict1 = {'foo': {'bar': {'baz': 'quux'}}}
    dict2 = {'foo': {'bar': {'baz': 'qux'}}}
    result = recursive_diff(dict1, dict2)
    assert result[0] == {'foo': {'bar': {'baz': 'quux'}}}
    assert result[1] == {'foo': {'bar': {'baz': 'qux'}}}

    # Two dictionaries

# Generated at 2022-06-11 00:59:56.924540
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected_merge = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    assert(dict_merge(a,b) == expected_merge)
    assert(dict_merge(b,a) == expected_merge)


# Generated at 2022-06-11 01:00:03.897150
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelized_dict = {'TagKey': 'test', 'TagValue': 'test1'}
    result = {'tag_key': 'test', 'tag_value': 'test1'}
    assert camel_dict_to_snake_dict(camelized_dict) == result



# Generated at 2022-06-11 01:00:13.122778
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake('fooBar') == 'foo_bar'
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_ar_ns'
    assert _camel_to_snake('TargetGroupARNs', True) == 'target_group_a_r_n_s'

    assert _snake_to_camel('foo_bar') == 'fooBar'
    assert _snake_to_camel('http_endpoint') == 'HTTPEndpoint'

# Generated at 2022-06-11 01:00:24.953414
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_dict = {
        'stringProperty': 'string',
        'booleanFalseProperty': False,
        'booleanTrueProperty': True,
        'listProperty': [{'listKey': 'listValue'}],
        'dictProperty': {'dictKey': 'dictValue'},
        'nullProperty': None,
    }

    complex_dict_snake = {
        'string_property': 'string',
        'boolean_false_property': False,
        'boolean_true_property': True,
        'list_property': [{'list_key': 'listValue'}],
        'dict_property': {'dict_key': 'dictValue'},
        'null_property': None,
    }


# Generated at 2022-06-11 01:00:27.317531
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'}



# Generated at 2022-06-11 01:00:33.127093
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {"MyKey":"my_value","anotherKey":"another_value","HTTPEndpoint":0}

    expected = {
        "my_key" : "my_value", 
        "another_key" : "another_value",
        "h_t_t_p_endpoint" : 0
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == expected

# Generated at 2022-06-11 01:00:43.844396
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CamelCaseKey': {'snake_case_key': 'snake_case_value'},
                                     'camelCaseListKey': ['camelCaseListValue'],
                                     'CamelCaseValue': 'camel_case_value',
                                     'Tags': {'Key': 'Value'}},
                                    reversible=True) == \
           {'camel_case_key': {'snake_case_key': 'snake_case_value'},
            'camel_case_list_key': ['camelCaseListValue'],
            'camel_case_value': 'camel_case_value',
            'tags': {'Key': 'Value'}}



# Generated at 2022-06-11 01:00:55.349630
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test regular camel_dict_to_snake_dict works as expected:
    camel_dict = {
        "Key1": "Value1",
        "SubKey1": {
            "Key2": "Value2"
        }
    }

    expected_output = {
        "key1": "Value1",
        "sub_key1": {
            "key2": "Value2"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected_output

    # test that reversible camel_dict_to_snake_dict actually recamelizes:
    camel_dict = {
        "HTTPEndpoint": "Value1",
        "SubKey1": {
            "Key2": "Value2"
        }
    }

# Generated at 2022-06-11 01:01:05.112584
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake('fooBar') == 'foo_bar'
    assert _camel_to_snake('fooBarBaz') == 'foo_bar_baz'
    assert _camel_to_snake('fooBarBazBiz', reversible=True) == 'foo_b_ar_b_az_b_iz'
    assert _camel_to_snake('HTTPEndpoint', reversible=True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_arns'
    assert _camel_to_snake('fooBar', True) == 'Foo_bar'
    assert _camel_to_snake('HTTPEndpoint', True) == 'H_t_t_p_endpoint'

# Generated at 2022-06-11 01:01:15.919717
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_a = {"keyZvalue": "value",
               "InsideDict": {"insideKey": "inside_value",
                              "insideList": [{"insideList1Key": "inside_list_value"}]},
               "keyThatIsList": ["value1", "value2"],
               "keyThatIsCapitalizedList": [{"insideCapitalizedList": "inside_capitalized_value"}],
               "KeyThatIsDict": {"insideDict": "inside_value"},
               "Tags": {"TAG": {"TAGS": {"TAG_KEY": "TAG_VALUE"}}}}

# Generated at 2022-06-11 01:01:24.377088
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'fooBarBaz': 'foobbb',
            'fooBarCamelDoesntSpit': 'foospit',
            'HTTP': {
                'HTTPEndpoint': 'fooend'
            }
        },
        'theFooBar': {
            'Baz': 'baz'
        },
        'fooBarList': [
            'foobaz',
            {
                'fooBarBaz': 'foobbb'
            }
        ],
        'fooBarBaz': 'foobbb',
        'fooBarBazFooBaz': 'foobazbaz',
        'fooBarBazFooBazBar': 'foobazbazbar',
        'TargetGroupARNs': ['targets']
    }
    snake_dict

# Generated at 2022-06-11 01:01:37.955960
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'EndpointURL': 'http://www.amazon.com',
            'HTTPHeaderList': [{
                'HeaderName': 'User-Agent',
                'HeaderValue': '{aws-sdk-cpp}',
                'Replace': True
            }],
            'HTTPStatusCodeList': [200, 201, 400],
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:01:47.750695
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.ec2 import HAS_BOTO3


# Generated at 2022-06-11 01:01:57.624827
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Protocol': 'HTTP'}, 'HTTPSEndpoint': {'Protocol': 'HTTPS'}}) == {'http_endpoint': {'protocol': 'HTTP'}, 'https_endpoint': {'protocol': 'HTTPS'}}
    assert camel_dict_to_snake_dict({'A': {'B': {'C': {'D': 'E'}}}}) == {'a': {'b': {'c': {'d': 'E'}}}}
    assert camel_dict_to_snake_dict({'A': ['B', 'C', 'D', 'E']}) == {'a': ['B', 'C', 'D', 'E']}

# Generated at 2022-06-11 01:02:03.758359
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': 'value', 'FooBar': {'KeyName': 'value2', 'key_name': 'value3'}}
    expected_dict = {'h_t_t_p_endpoint': 'value', 'foo_bar': {'key_name': 'value2', 'key_name': 'value3'}}
    assert camel_dict_to_snake_dict(test_dict) == expected_dict

# Generated at 2022-06-11 01:02:16.164267
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:26.279137
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "KeyOne": "value",
        "KeyTwo": {
            "HTTPEndpoint": "value",
            "NotIgnored": "value",
            "Tags": {
                "KeyThree": "value"
            }
        }
    }

    expected_snake_dict = {
        "key_one": "value",
        "key_two": {
            "h_t_t_p_endpoint": "value",
            "not_ignored": "value",
            "tags": {
                "KeyThree": "value"
            }
        }
    }

    test_snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert test_snake_dict == expected_snake_dict



# Generated at 2022-06-11 01:02:33.966179
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test input
    camel_input_1 = {
        "fooBar": {
            "bazPee": [
                {"fooBar": "bazPee"}
            ],
            "bazPeeToo": "bazPee",
            "aDict": {
                "aList": [
                    {
                        "fooBar": "bazPee"
                    }
                ]
            },
            "HTTPEndpoint": "http_endpoint",
            "anotherHTTPEndpoint": "http_endpoint",
            "HTTPSEndpoint": "http_endpoint",
            "anotherHTTPSEndpoint": "http_endpoint",
            "HTTP": "http",
            "HTTPS": "http"
        }
    }

    # Test expected output

# Generated at 2022-06-11 01:02:43.070767
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "fooBar": "value",
        "fooBarList": [
            "value1",
            "value2"
        ],
        "fooBarDict": {
            "fooBarBaz": "value"
        },
        "tags": {
            "foo": "bar"
        },
        "ARN": "arn:aws:s3:::my_corporate_bucket/exampleobject.png"
    }


# Generated at 2022-06-11 01:02:54.803178
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Unit test for function camel_dict_to_snake_dict
    def assert_dicts(orig, expected):
        assert orig == expected, \
            '''\nOriginal: %s\nExpected: %s\n''' % (orig, expected)

    # simple
    assert_dicts(camel_dict_to_snake_dict(
            {'SimpleKey': 'SimpleValue'}),
            {'simple_key': 'SimpleValue'})
    # complex

# Generated at 2022-06-11 01:03:05.503884
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HttpEndpoint': {'EndpointName': 'test-test-test', 'S3BackupMode': 'S3_SNAPSHOT', 'RetryOptions': {'DurationInSeconds': '300'}, 'HttpEndpointType': 'TARGET'}, 'Tags': [{'Key': 'k', 'Value': 'v'}]}
    expected_dict = {'http_endpoint': {'endpoint_name': 'test-test-test', 's3_backup_mode': 'S3_SNAPSHOT', 'retry_options': {'duration_in_seconds': '300'}, 'http_endpoint_type': 'TARGET'}, 'tags': [{'Key': 'k', 'Value': 'v'}]}

# Generated at 2022-06-11 01:03:20.213746
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(
        {
            "HostName": "test",
            "IdentityId": "testId",
            "IdentityPoolId": "testIdPoolId",
            "IsAuthenticated": True,
            "Tokens": {
                "IdToken": "id-token-here",
                "AccessToken": "access-token-here",
                "RefreshToken": "refresh-token-here"
            }
        },
        reversible=True
    )


# Generated at 2022-06-11 01:03:30.368001
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_string = {"SourceSecurityGroupName": "test-group"}
    assert camel_dict_to_snake_dict(camel_string) == {"source_security_group_name": "test-group"}

    camel_dict = {'OverrideDefaultVpc': True}
    assert camel_dict_to_snake_dict(camel_dict) == {'override_default_vpc': True}

    camel_list = [{"SourceSecurityGroupName": "test-group", "GroupName": "test-group"}]
    assert camel_dict_to_snake_dict(camel_list) == [{"source_security_group_name": "test-group",
                                                     "group_name": "test-group"}]


# Generated at 2022-06-11 01:03:41.526487
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
      'MailFromDomain': 'mail.example.com',
      'ConfigurationSetName': 'ConfigSet',
      'DefaultTags': [
        {
          'Value': 'testString',
          'Key': 'string'
        }
      ],
      'DkimTokens': [
        'string'
      ],
      'Name': 'string'
    }

    # Known issue: camel_dict_to_snake_dict will throw an exception if
    # DefaultTags or Tags are given as an argument. DefaultTags is a deprecated field
    # that is not typically set in practice. This has been fixed in newer versions of
    # boto3, so we will remove this exception when we switch to the newer boto3 version.

    snake_dict = camel_dict_to_snake_dict(camel_dict)

   

# Generated at 2022-06-11 01:03:49.963398
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def check_dict(camel_dict, snake_dict, reversible=False, ignore_list=()):
        ret = camel_dict_to_snake_dict(camel_dict, reversible, ignore_list)
        assert ret == snake_dict

    test_dict = {'fooBar': {'bazQux': {'quxQux': 'garply'},
                            'aString': 'Waldo'},
                 'aList': [1, 2, 3],
                 'anotherList': [{'aDict': 1}, {'aDict': 2}],
                 'withIgnoreList': {'tags': {'this': 'should not be modified'}},
                 'HTTPEndpoint': {'aDict': {'this': 'should be modified'}}}


# Generated at 2022-06-11 01:04:01.171563
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_orig = {'Test': 'value1',
                 'Test2': {'Test': 'value2'},
                 'HTTPEndpoint': 'value3',
                 'Tags': {'key1': 'value4'},
                 'Test4': {'Test4': [{'Test4': [{'Test4': 'value5'},
                                                 {'Test4': 'value6'}]}]}}


# Generated at 2022-06-11 01:04:09.743185
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:21.093770
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert_equal(camel_dict_to_snake_dict({'fooBar': 'FooBar'}), {'foo_bar': 'FooBar'})
    assert_equal(camel_dict_to_snake_dict({'fooBar': 'FooBar', 'snakeCase': 'FooBar'}), {'foo_bar': 'FooBar', 'snake_case': 'FooBar'})
    assert_equal(camel_dict_to_snake_dict({'fooBar': 'FooBar', 'snakeCase': 'FooBar', 'ABC': {'fooBar': 'FooBar'}}), {'foo_bar': 'FooBar', 'snake_case': 'FooBar', 'a_b_c': {'foo_bar': 'FooBar'}})

# Generated at 2022-06-11 01:04:31.356961
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:41.486325
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'HTTPPaths': [
        {'Path': '/', 'HTTPMethod': 'GET', 'Interval': 300, 'TimeoutMillis': 500, 'UnhealthyThreshold': 3},
        {'Path': '/', 'HTTPMethod': 'POST', 'Interval': 300, 'TimeoutMillis': 500, 'UnhealthyThreshold': 3}]}}
    converted_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:04:45.687975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'vpcEndpointId': 'vpce-0123456789abcdef'}}
    expected_dict = {'h_t_t_p_endpoint': {'vpc_endpoint_id': 'vpce-0123456789abcdef'}}
    expected_dict_reversible = {'h_t_t_p_endpoint': {'v_p_c_endpoint_i_d': 'vpce-0123456789abcdef'}}

    assert camel_dict_to_snake_dict(test_dict, reversible=False) == expected_dict
    assert camel_dict_to_snake_dict(test_dict, reversible=True) == expected_dict_reversible

# Generated at 2022-06-11 01:04:57.790276
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "fooBar": {
            "baz": 1,
            "quux": 2,
            "frobozz": 3
        }
    }
    snake_dict = {
        "foo_bar": {
            "baz": 1,
            "quux": 2,
            "frobozz": 3
        }
    }
    assert (camel_dict_to_snake_dict(camel_dict) == snake_dict)



# Generated at 2022-06-11 01:05:07.241382
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:17.647721
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    json_blob = '''
{
  "MyNameIs": "camelCase",
  "Capitals": "sometimes",
  "camelcase": "is concatenated",
  "ACMECertificate":"this is snake_case",
  "TargetGroups": [
    {
      "HealthCheckIntervalSeconds": 30,
      "TargetType": "ip"
    }
  ],
  "Tags": {
    "Name": "test",
    "Owner": "testrole",
    "Environment": "test_env"
  }
}'''

# Generated at 2022-06-11 01:05:28.606365
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:35.617439
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "DesiredCount": 1,
            "Environment": {
                "Variables": {
                    "VAR_ONE": "var_one",
                    "VAR_TWO": "var_two"
                }
            }
        },
        "ServicePackage": {
            "UsagePlanPermission": "v1.0"
        },
        "Tags": {
            "key": "value",
            "key_two": "value_two"
        }
    }

# Generated at 2022-06-11 01:05:47.412988
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test basic conversion
    camel_dict = {'fooBar': 1, 'FooBaz': 2, 'foo_bar': 3, 'foo_baz': 4}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': 1, 'foo_baz': 2, 'foo_bar': 3, 'foo_baz': 4}

    # Test top level key only
    camel_dict = {'fooBar': {'fooBaz': 1}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'foo_bar': {'fooBaz': 1}}

    # Test nested dicts
    camel_dict = {'fooBar': {'fooBaz': 1}}
   

# Generated at 2022-06-11 01:05:55.902721
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:04.636133
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import camel_dict_to_snake_dict, snake_dict_to_camel_dict


# Generated at 2022-06-11 01:06:12.736435
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    params = {
        'TagKeys': [
            'Tag1',
            'Tag2',
        ],
        'DryRun': False,
        'Filters': [
            {
                'Values': [
                    'test',
                ],
                'Name': 'string',
            },
        ],
        'Ebs': {
            'VolumeSize': 100,
            'DeleteOnTermination': True,
            'Iops': 123,
            'Encrypted': False,
            'VolumeType': 'gp2',
        },
    }

# Generated at 2022-06-11 01:06:19.813082
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'FooBar': 1}) == {'foo_bar': 1})
    assert(camel_dict_to_snake_dict({'FooBar': [1, 2, 3]}) == {'foo_bar': [1, 2, 3]})
    assert(camel_dict_to_snake_dict({'FooBar99': {'BarBar99': 'baz'}}) == {'foo_bar99': {'bar_bar99': 'baz'}})
    assert(camel_dict_to_snake_dict({'FooBar': {'BarBar': 'baz'}}) == {'foo_bar': {'bar_bar': 'baz'}})

# Generated at 2022-06-11 01:06:34.999086
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({"fooBar": "baz", "qux": ["x", "y", "z"]}) == {'foo_bar': 'baz', 'qux': ['x', 'y', 'z']}
    assert camel_dict_to_snake_dict({"fooBar": {"barBaz": "baz"}}) == {'foo_bar': {'bar_baz': 'baz'}}
    assert camel_dict_to_snake_dict({"fooBar": "baz", "array": [1, 2, 3]}, ignore_list=["array"]) == {'foo_bar': 'baz', 'array': [1, 2, 3]}

# Generated at 2022-06-11 01:06:43.497058
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:53.204091
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict_1 = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'subKey1': 'subValue1',
            'subKey2': 'subValue2',
            'subKey3': {
                'deepSubKey1': 'deepSubValue1',
                'deepSubKey2': 'deepSubValue2',
            },
        },
    }

# Generated at 2022-06-11 01:07:03.610297
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_cases = {}
    test_cases['Simple'] = {
        'camel': {'hotDog': 'DeepFried'},
        'snake': {'hot_dog': 'DeepFried'},
        'reversible': {'h_o_t_dog': 'DeepFried'}
    }

# Generated at 2022-06-11 01:07:12.621435
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict_1 = {'isListening': True, 'port': 443, 'protocol': 'https', 'enableSNI': True, 'tags': {'environment': 'production'}}
    result_1 = camel_dict_to_snake_dict(test_dict_1)
    assert result_1 == {'is_listening': True, 'port': 443, 'protocol': 'https', 'enable_sni': True, 'tags': {'environment': 'production'}}

    test_dict_2 = {'isListening': True, 'port': 443, 'protocol': 'https', 'enableSNI': True, 'enableIPV6': True, 'tags': {'environment': 'production'}}
    result_2 = camel_dict_to_snake_dict(test_dict_2)

# Generated at 2022-06-11 01:07:18.137065
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test a simple dict
    test_dict = {'HTTPEndpoint': 'http://localhost:8080'}
    converted_dict = camel_dict_to_snake_dict(test_dict)
    assert converted_dict == {'h_t_t_p_endpoint': 'http://localhost:8080'}

    # Test a simple dict with a list inside it
    test_dict = {'HTTPEndpoint': ['http://localhost:8080']}
    converted_dict = camel_dict_to_snake_dict(test_dict)
    assert converted_dict == {'h_t_t_p_endpoint': ['http://localhost:8080']}

    # Test a simple dict with a dict inside it
    test_dict = {'HTTPEndpoint': {'Port': 8080}}
    converted_dict = camel_

# Generated at 2022-06-11 01:07:26.511153
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {}

    # All lower case
    test_dict['key1'] = 'value'

    # Mixed case
    test_dict['Key2'] = 'value'

    # All upper case
    test_dict['KEYS3'] = 'value'

    test_dict['KEYS4S'] = 'value'

    # Complex value
    test_dict['Key5'] = '{"a":1}'

    # Complex value with ignored list
    test_dict['Key6'] = {'Tag': {'one': 1, 'two': 2}}
    test_dict['Key6']['Tags'] = {'one': 1, 'two': 2}

    test_dict['Key6']['Tag2'] = 'one'
    test_dict['Key6']['Tag2s'] = 'one'

    test_

# Generated at 2022-06-11 01:07:37.274078
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    with open("test_camel_dict_to_snake_dict_test_cases") as file:
        test_cases = file.readlines()

    for test_case in test_cases:

        result = eval(test_case)

        if result != None:

            if result[1] == "camel":
                result[0]["AttributesToGet"] = ["Att1","Att2","Att3"]
                result[0]["KeyConditions"] = {"Att4":{"AttributeValueList":[{"S":"Att4Value1"},{"S":"Att4Value2"}],"ComparisonOperator":"EQ"}}
                result[0]["ProjectionExpression"] = "Att1, Att2, Att3"

# Generated at 2022-06-11 01:07:45.105110
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils import basic

    original_dict = {
        'InstanceId': 'i-09876',
        'HTTPEndpoint': {
            'Protocol': 'http',
            'Enabled': False,
            'Path': '/test/',
            'Port': 80,
            'CustomHeaders': {
                'X-Test': 'hello',
                'X-Test2': 'world',
            }
        },
        'Tags': {
            'Name': 'healthchecks',
            'Instance': 'i-09876',
        }
    }


# Generated at 2022-06-11 01:07:54.249499
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Test': 'test'}) == {'test': 'test'}
    assert camel_dict_to_snake_dict({'TEST': 'test'}) == {'t_e_s_t': 'test'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://www.example.com', 'HTTPS': 'https'}) == {'h_t_t_p_endpoint': 'http://www.example.com', 'h_t_t_p_s': 'https'}