

# Generated at 2022-06-11 00:58:35.226243
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {'HTTPEndpoint': {'SelfSignedCertificate': {'CertificateBody': 'foo', 'CertificateChain': 'bar'}}}
    d_rev = {'H_T_T_P_endpoint': {'Self_signed_certificate': {'Certificate_body': 'foo', 'Certificate_chain': 'bar'}}}
    d_final = {'h_t_t_p_endpoint': {'self_signed_certificate': {'certificate_body': 'foo', 'certificate_chain': 'bar'}}}
    assert camel_dict_to_snake_dict(d) == d_final
    assert camel_dict_to_snake_dict(d, reversible=True) == d_rev


# Generated at 2022-06-11 00:58:42.557412
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {
        'a': 1,
        'b': 1,
        'c': {
            'ca': 1,
            'cb': 1,
            'cc': {
                'cca': 1
            }
        }
    }
    d2 = {
        'b': 2,
        'c': {
            'ca': 2,
            'cc': {
                'cca': 1,
                'ccb': 1
            }
        },
        'd': 3
    }
    # Result should be:
    # {
    #   'a': 1,
    #   'b': 1,
    #   'c': {
    #       'ca': 1,
    #       'cc': {
    #           'cca': 1
    #       }
    #   }
    # }, {


# Generated at 2022-06-11 00:58:52.422417
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'MyCustomKey': {'HTTPEndpoint': 'foo'}, 'OtherKey': ['a', 'b', 'c'], 'OtherOtherKey': {'AnEvenMoreCustomKey': 'bar'}}
    snake_dict = {'my_custom_key': {'h_t_t_p_endpoint': 'foo'}, 'other_key': ['a', 'b', 'c'], 'other_other_key': {'an_even_more_custom_key': 'bar'}}
    assert camel_dict_to_snake_dict(camel_dict,False) == snake_dict



# Generated at 2022-06-11 00:59:02.685880
# Unit test for function recursive_diff
def test_recursive_diff():
    def assert_equal(got, expected):
        assert got == expected

    def assert_none(got):
        assert_equal(got, None)

    assert_equal(recursive_diff({1:2, 3:4}, {1:2, 3:4}), None)
    assert_equal(recursive_diff({1:2, 3:4}, {1:2, 3:5}), (None, {3:5}))
    assert_equal(recursive_diff({1:2, 3:4}, {1:2}), (None, {3:4}))
    assert_equal(recursive_diff({1:2}, {1:2, 3:4}), ({3:4}, None))

# Generated at 2022-06-11 00:59:14.266386
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'vpc': {'id': 'vpc-5d18ce08', 'subnet': 'subnet-6ea1f10d', 'internet_gateway': 'igw-b91c3da3'},
             'key_name': 'ansible', 'instances': {'name': 'ansible-test', 'count': 1, 'tags': {'name': 'ansible-test',
                                                                                              'service': 'ansible-test'},
                                                 'image_id': 'ami-ea26a3d3', 'instance_type': 't2.micro',
                                                 'security_groups': 'sg-5f18cc3d'},
             'host_key_checking': False}

# Generated at 2022-06-11 00:59:22.850652
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "String1": "value1",
        "String2": "value2",
        "String3": {
            "String1": "value2",
            "String3": "value3",
            "String4": [
                {
                    "String1": "value2",
                    "String3": "value3",
                    "String4": [
                        "String1",
                        "value2",
                        "String3",
                        "value3"
                    ]
                }
            ]
        }
    }
    print (camel_dict)
    print (camel_dict_to_snake_dict(camel_dict))
    print (camel_dict_to_snake_dict(camel_dict_to_snake_dict(camel_dict)))

# Generated at 2022-06-11 00:59:34.446125
# Unit test for function recursive_diff
def test_recursive_diff():
    import unittest

    class TestRecursiveDiff(unittest.TestCase):
        def test_no_diff(self):
            dict1 = {
                'a': {
                    'b': {
                        'c': 3,
                    },
                    'd': 4,
                },
                'e': 5,
            }
            dict2 = {
                'a': {
                    'b': {
                        'c': 3,
                    },
                    'd': 4,
                },
                'e': 5,
            }

            self.assertIs(recursive_diff(dict1, dict2), None)


# Generated at 2022-06-11 00:59:45.046748
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'EndpointType': 'http'}}) == {'http_endpoint': {'endpoint_type': 'http'}}
    assert camel_dict_to_snake_dict({'HTTPSEndpoint': {'EndpointType': 'http'}}) == {'https_endpoint': {'endpoint_type': 'http'}}
    assert camel_dict_to_snake_dict({'URLName': {'EndpointType': 'http'}}) == {'url_name': {'endpoint_type': 'http'}}


# Generated at 2022-06-11 00:59:52.245958
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_result = {'deploymentId': 101, 'deploymentName': 'testDeployment',
                                            'deploymentDescription': 'testDeploymentDesc',
                                            'deploymentStatus': 'Succeeded'}
    camel_dict = {'DeploymentId': 101, 'DeploymentName': 'testDeployment',
                                        'DeploymentDescription': 'testDeploymentDesc',
                                        'DeploymentStatus': 'Succeeded'}
    assert camel_dict_to_snake_dict(camel_dict) == camel_dict_result


# Generated at 2022-06-11 01:00:03.626351
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test when some values are different
    dict1 = { 'a': { 'b': {'c': 'd', 'e': 'f'}}}
    dict2 = { 'a': { 'b': {'c': 'd', 'e': 'g'}}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'a': {'b': {'e': 'f'}}}, {'a': {'b': {'e': 'g'}}}), \
        "Expected result={0} , got={1}".format(({'a': {'b': {'e': 'f'}}}, {'a': {'b': {'e': 'g'}}}), result)

    # Test when dictionaries are same

# Generated at 2022-06-11 01:00:16.759239
# Unit test for function dict_merge
def test_dict_merge():
    a = {'x': 1, 'y': 2}
    b = {'y': 3, 'z': 4}
    c = {'w': 5, 'z': 6}
    d = {'x': 1, 'y': 2, 'z': 4, 'w': 5}
    e = {'x': 1, 'y': 3, 'z': 4}
    f = {'w': 5, 'z': 6, 'x': 1, 'y': 2}
    assert d == dict_merge(a, b)
    assert e == dict_merge(d, b)
    assert d == dict_merge(b, a)
    assert f == dict_merge(a, c)



# Generated at 2022-06-11 01:00:28.686748
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:37.216077
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': {'c': 1, 'd': 2}, 'e': {'f': {'g': 1, 'h': 2}}}
    d2 = {'a': 2, 'b': {'c': 2}, 'e': {'i': 1}}

    r = dict_merge(d1, d2)
    assert d1['a'] == 1
    assert d2['a'] == 2
    assert r['a'] == 2
    assert d1['b']['c'] == 1
    assert d2['b']['c'] == 2
    assert r['b']['c'] == 2
    assert d1['b']['d'] == 2
    assert 'd' not in d2['b']
    assert r['b']['d'] == 2

# Generated at 2022-06-11 01:00:50.001132
# Unit test for function dict_merge
def test_dict_merge():
    # First test: dictionaries with simple values
    d1 = {"key1": "value1"}
    d2 = {"key2": "value2"}
    d3 = dict_merge(d1, d2)
    assert d3 == {"key1": "value1", "key2": "value2"}
    # Second test: dictionaries with complex values
    d1 = {"key1": {"key1_1": "value1_1"}}
    d2 = {"key2": {"key2_1": "value2_1"}}
    d3 = dict_merge(d1, d2)
    assert d3 == {"key1": {"key1_1": "value1_1"}, "key2": {"key2_1": "value2_1"}}
    # Third test: dictionaries with shared keys
    d1

# Generated at 2022-06-11 01:00:59.089719
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=dict(b=1, c=2))
    b = dict(a=dict(b=7))
    c = dict_merge(a, b)
    print("c is %s" % c)
    assert(c == dict(a=dict(b=7, c=2)))

    a = dict(a=dict(b=1, c=2))
    b = dict(a=dict(b=7, d=5))
    c = dict_merge(a, b)
    print("c is %s" % c)
    assert(c == dict(a=dict(b=7, c=2, d=5)))

    a = dict(a=[1, 2, 3])
    b = dict(a=dict(b=7, d=5))
    c = dict_

# Generated at 2022-06-11 01:01:10.052979
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:20.434842
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(a=1, b=2, c=dict(a=1, b=2, c=3))
    dict2 = dict(b=3, c=dict(c=4), d=5)

    result = dict_merge(dict1, dict2)
    assert result == dict(a=1, b=3, c=dict(a=1, b=2, c=4), d=5)
    dict3 = dict(a=1, b=dict(b=2, c=3), c=4)
    dict4 = dict(a=1, b=dict(b=3), d=5)
    result = dict_merge(dict3, dict4)
    assert result == dict(a=1, b=dict(b=3, c=3), c=4, d=5)

# Generated at 2022-06-11 01:01:32.050484
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    input_dict = {'HTTPEndpoint': {'Endpoint': 'http://example.com',
                                   'Id': 'http-endpoint-example-com'},
                  'Tags': {'some-tag': 'test-tag',
                           'another-tag': 'test-another-tag'},
                  'Thing': {'Name': 'my-thing'},
                  'ThingARN': 'thing:arn:aws:iot:us-east-1:123456789012:thing/my-thing',
                  'PolicyName': 'PolicyName'}


# Generated at 2022-06-11 01:01:40.738565
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'inner_key1': 2, 'inner_key2': 'foo'},
         'key2': 5,
         'key3': {'inner_key3': 'bar'}}
    b = {'key1': {'inner_key1': 2},
         'key2': 7,
         'key3': 'abc'}
    result = dict_merge(a, b)
    expected = {'key1': {'inner_key1': 2, 'inner_key2': 'foo'},
                'key2': 7,
                'key3': 'abc'}
    assert result == expected, result


# Generated at 2022-06-11 01:01:47.554536
# Unit test for function dict_merge
def test_dict_merge():
    a = {'b': 'c', 'd': {'e': 'f', 'g': 'h', 'i': {'j': 'k'}}, 'l': None}
    b = {'b': 'x', 'd': {'e': 'f', 'g': 'y', 'i': {'j': 'z'}}}
    assert dict_merge(a, b) == {'b': 'x', 'd': {'e': 'f', 'g': 'y', 'i': {'j': 'z'}}, 'l': None}

# Generated at 2022-06-11 01:01:58.762045
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {"KeyName": ["foo"], "SecurityGroupIds": ["bar"], "SubnetId": "baz", "TagSpecifications": [{"ResourceType": "instance", "Tags":[{"Key" : "Name", "Value": "ansible-test-instance"}]}]}
    assert camel_dict_to_snake_dict(d) == {'key_name': ['foo'], 'security_group_ids': ['bar'], 'subnet_id': 'baz', 'tag_specifications': [{'resource_type': 'instance', 'tags': [{'key': 'Name', 'value': 'ansible-test-instance'}]}]}

# Generated at 2022-06-11 01:02:10.932546
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Unit tests for the camel_dict_to_snake_dict function.

    # Test: reversible=False
    camelDict = {'TestKey': 'TestValue',
                 '10GigE': 'CamelCase',
                 '10GigE-MAC': 'CamelCase',
                 'test_Key': 'TestValue_2',
                 'test-Key': 'TestValue_3',
                 'test_Key-CamelCase': 'TestValue_4',
                 'test-Key-CamelCase': 'TestValue_5'}

# Generated at 2022-06-11 01:02:22.280371
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:30.353134
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = { "HTTPEndpoint": { "URL": "http://www.ansible.com", "HttpMethod": "POST" } }
    snake_dict = { "h_t_t_p_endpoint": { "u_r_l": "http://www.ansible.com", "http_method": "POST" } }
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # test the reversible option to allow two-way conversion
    snake_reversible = { "h_t_t_p_endpoint": { "u_r_l": "http://www.ansible.com", "h_t_t_p_method": "POST" } }
    assert camel_dict_to_snake_dict(camel_dict, True) == snake_reversible

   

# Generated at 2022-06-11 01:02:40.100799
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # A sample from the AWS boto3 docs https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/autoscaling.html#AutoScaling.Client.attach_load_balancer_target_groups
    camel_dict = {
        "AutoScalingGroupName": "my-asg",
        "TargetGroupARNs": [
            "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/73e2d6bc24d8a067",
            "arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/0d544760c84389f4"
        ]
    }

    # what the returned snake_dict should look like

# Generated at 2022-06-11 01:02:47.352861
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {
        'id': 'test_key',
        'dependent_services': [{'dependent_service_id': 'test_service', 'dependent_resource': 'test_resource'}]
    }

    assert camel_dict_to_snake_dict(d) == {'dependent_services': [{'dependent_resource': 'test_resource', 'dependent_service_id': 'test_service'}], 'id': 'test_key'}



# Generated at 2022-06-11 01:02:58.770644
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    tests = {}

    tests["SimpleDict"] = {"Key1":"Value1", "Key2":"Value2"}
    tests["SimpleDict_Result"] = {"key1":"Value1", "key2":"Value2"}

    tests["ComplexDict"] = {"Key1":"Value1", "Key2":{"Key3":"Value3"}}
    tests["ComplexDict_Result"] = {"key1":"Value1", "key2":{"key3":"Value3"}}

    tests["SimpleList"] = ["Value1", "Value2"]
    tests["SimpleList_Result"] = ["Value1", "Value2"]

    tests["ComplexList"] = ["Value1", {"Key1":"Value1"}]
    tests["ComplexList_Result"] = ["Value1", {"key1":"Value1"}]


# Generated at 2022-06-11 01:03:08.574641
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    from ansible.module_utils.aws.core import AnsibleAWSModule

    class TestModule(AnsibleAWSModule):
        def __init__(self):
            self.argument_spec = dict(
                tags={'type': 'dict'}
            )
            super(TestModule, self).__init__(add_ignore_missing=True, supports_check_mode=True)

    module = TestModule()
    camel_dict = dict(DnsName='test.com', Tags={'Key': 'Value'})
    ignore_list = ('Tags',)
    result = camel_dict_to_snake_dict(camel_dict, ignore_list=ignore_list)

# Generated at 2022-06-11 01:03:20.618507
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Create a sample AWS API response in camelCase format
    response = {
        "LaunchTemplateId": "lt-098765432101234567",
        "LaunchTemplateName": "My-Template-1",
        "DefaultVersionNumber": 1,
        "LatestVersionNumber": 1,
        "CreatedBy": "0123456789012",
        "CreateTime": "2018-01-15T16:32:14.000Z",
        "Tags": [
            {
                "Key": "costcenter",
                "Value": "12345"
            }
        ],
        "ModifiedTime": "2018-01-15T16:32:14.000Z"
    }

    # Convert using camel_dict_to_snake_dict
    response_snaked = camel_dict_to_snake_dict(response)

# Generated at 2022-06-11 01:03:30.542205
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_list1 = {'A': 'b', 'C': 'd'}
    assert camel_dict_to_snake_dict(test_list1) == {'a': 'b', 'c': 'd'}
    test_list2 = {'Aa': 'b', 'Cc': {'D': 'e'}}
    assert camel_dict_to_snake_dict(test_list2) == {'aa': 'b', 'cc': {'d': 'e'}}
    test_list3 = {'Aa': 'b', 'Cc': {'D': 'e'}, 'F': ['g', {'H': 'i'}]}

# Generated at 2022-06-11 01:03:43.748171
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:52.401498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"HTTPEndpoint": {"HTTPEndpointName": 'test1', "AcceptFormat": 'JSON', "Protocols": ['https', 'http']},
                 "HTTPContinuationToken": 'test2',
                 "ReverseContinuationToken": 'test3'}
    expected_dict = {"h_t_t_p_endpoint": {"h_t_t_p_endpoint_name": 'test1', "accept_format": 'JSON',
                                          "protocols": ['https', 'http']},
                     "h_t_t_p_continuation_token": 'test2',
                     "reverse_continuation_token": 'test3'}
    result = camel_dict_to_snake_dict(test_dict)
    assert result == expected_dict


# Generated at 2022-06-11 01:04:04.060346
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test1: convert camel dict to snake dict
    # convert a simple dict
    a_dict1 = {'KinesisStreamName': 'my_stream', 'ShardCount': 1}
    assert({'kinesis_stream_name': 'my_stream', 'shard_count': 1} == camel_dict_to_snake_dict(a_dict1))

    # convert a hierarchical dict
    a_dict2 = {
        'ClusterName': 'MyCluster',
        'NodeGroups': [
            {
                'NodeGroupId': 'ng-1234',
                'Slots': '0-3999'
            }
        ]
    }

# Generated at 2022-06-11 01:04:15.406280
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Minimal test of camel_dict_to_snake_dict
    """

    camel_dict = {
        'Key1': 'value1',
        'Key2': 'value2',
        'Key3': {
            'Camel1': 'value3',
            'Camel2': 'value4',
            'Camel3': {
                'Camel4': 'value5'
            }
        },
        'Key4': [
            'value6',
            'value7'
        ]
    }


# Generated at 2022-06-11 01:04:26.523424
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test string conversion
    assert _camel_to_snake('helloWorld') == 'hello_world'
    assert _snake_to_camel('hello_world') == 'helloWorld'

    # Test reversible conversion
    assert _camel_to_snake('helloWorld', reversible=True) == 'hello_w_o_r_l_d'
    assert _snake_to_camel('hello_w_o_r_l_d') == 'helloWorld'

    # Test regular conversion
    assert camel_dict_to_snake_dict({'helloWorld': 'hello_world'}) == {'hello_world': 'hello_world'}

    # Test pluralized abbreviations
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_arns'
    assert _snake_

# Generated at 2022-06-11 01:04:35.374071
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        Tags=[
            dict(
                Key="Name",
                Value="test",
            ),
        ],
        Clusters=[
            dict(
                Name='test',
                Opens=[
                    dict(
                        TargetGroupARNs=[
                            "t1",
                            "t2",
                        ],
                        SecurityGroups=[
                            "sg1",
                            "sg2",
                        ],
                        HttpEndpoint='ENABLED',
                    ),
                ],
            ),
        ],
    )


# Generated at 2022-06-11 01:04:47.087188
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test for an empty dict
    assert camel_dict_to_snake_dict({}) == {}

    # Test for a dict which is not empty
    camel_dict = {
        'NestedDict': {
            'String': 'Hello',
            'Number': 1
        },
        'String': 'World',
        'Number': 5,
        'List': [1, 2, 3, 4]
    }
    expected_snake_dict = {
        'nested_dict': {
            'string': 'Hello',
            'number': 1
        },
        'string': 'World',
        'number': 5,
        'list': [1, 2, 3, 4]
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == expected_

# Generated at 2022-06-11 01:04:56.912758
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'FooBarBaz': [1, 2, 3],
        'BarBazFoo': {
            'FizzBuzz': [1, 2, 3],
            'BuzzFizz': {
                'ABC': 'xyz'
            }
        },
        'BTW': 'foo',
        'Tags': {
            'Tags': [{'Key': 'Tag1', 'Value': 'Tag1_Value'}]
        }
    }

    result = camel_dict_to_snake_dict(test_dict)
    assert result['foo_bar_baz'] == [1, 2, 3]
    assert result['bar_baz_foo']['fizz_buzz'] == [1, 2, 3]

# Generated at 2022-06-11 01:05:06.636176
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': 1,
        'bazQux': 2,
        'quxx': [
            {'corgeGrault': 3},
            {'garplyWaldo': 4},
        ],
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    expected_dict = {
        'foo_bar': 1,
        'baz_qux': 2,
        'quxx': [
            {'corge_grault': 3},
            {'garply_waldo': 4},
        ],
    }

    assert snake_dict == expected_dict

    # Test for reversible conversion
    camel_dict = camel_dict_to_snake_dict(snake_dict, reversible=True)

    assert camel_dict == camel_dict_

# Generated at 2022-06-11 01:05:17.075340
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': 'bar', 'Baz': 'qux'}) == {'foo': 'bar', 'baz': 'qux'}
    assert camel_dict_to_snake_dict({'FooBar': 'bar', 'BazQux': 'qux'}) == {'foo_bar': 'bar', 'baz_qux': 'qux'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'bar', 'Baz': 'qux'}) == {'h_t_t_p_endpoint': 'bar', 'baz': 'qux'}

# Generated at 2022-06-11 01:05:30.744373
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Ensure that the camel_dict_to_snake_dict function works as expected"""

    camel_dict = dict()
    camel_dict['HTTPEndpoint'] = dict()
    camel_dict['HTTPEndpoint']['Protocol'] = 'HTTP'
    camel_dict['HTTPEndpoint']['Port'] = 80

    camel_dict['SNSEndpoint'] = dict()
    camel_dict['SNSEndpoint']['Protocol'] = 'SNS'
    camel_dict['SNSEndpoint']['TopicArn'] = 'arn:123'

    tags_dict = {'tag_key': 'tag_value'}

    camel_dict['Tags'] = tags_dict

    ignore_list = ['Tags']

    expected_output = dict()
    expected_output['http_endpoint'] = dict()
    expected

# Generated at 2022-06-11 01:05:41.553163
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'camelCase': {'orNot': None}}) == {
        'camel_case': {'or_not': None}}

    assert camel_dict_to_snake_dict({
        'isArray': ['one', 'two', 'three']}) == {
        'is_array': ['one', 'two', 'three']}

    assert camel_dict_to_snake_dict({
        'camelCase': {'HTTPEndpoint': None}}) == {
        'camel_case': {'h_t_t_p_endpoint': None}}

# Generated at 2022-06-11 01:05:52.726726
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    import json
    import unittest

    class TestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def runTest(self):
            self.maxDiff = None
            self.run_test_camel_dict_to_snake_dict()
            self.run_test_camel_dict_to_snake_dict_reversible()


# Generated at 2022-06-11 01:06:02.518380
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # returns camel_dict_to_snake_dict with key and value
    camel_case = dict(
        AttributeName='Environment',
        HTTPEndpoint={
            'EndpointURL': 'http://hc-ping.com',
            'Timeout': 3
        },
        Tags=[
            {
                'Key': 'Application',
                'Value': 'MyTest'
            },
            {
                'Key': 'Environment',
                'Value': 'MyTest'
            },
            {
                'Key': 'ApplicationGroup',
                'Value': 'MyTest'
            },
            {
                'Key': 'Application2',
                'Value': 'MyTest'
            }
        ]
    )

    # returns snake_dict_to_camel_dict with key and value

# Generated at 2022-06-11 01:06:05.182501
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'thisIsACamelCasedKey': True}, reversible=False) == {
        'this_is_a_camel_cased_key': True
    }



# Generated at 2022-06-11 01:06:12.561144
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:19.762163
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'id': 'test_id', 'myApp': {'elbInfo': {'elbEndPoint': 'test.elb.endpoint'}}}, True) == {'id': 'test_id', 'my_app': {'elb_info': {'elb_end_point': 'test.elb.endpoint'}}}
    assert camel_dict_to_snake_dict({'id': 'test_id', 'myApp': {'elbInfo': {'elbEndPoint': 'test.elb.endpoint'}}}, False) == {'id': 'test_id', 'my_app': {'elb_info': {'elb_endpoint': 'test.elb.endpoint'}}}

# Generated at 2022-06-11 01:06:28.673407
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:36.844103
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict(camel_dict_to_snake_dict({"HTTPEndpoint": "http://www.example.com"})) == {"HTTPEndpoint": "http://www.example.com"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "http://www.example.com"}) == {"http_endpoint": "http://www.example.com"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "http://www.example.com"}, reversible=True) == {"h_t_t_p_endpoint": "http://www.example.com"}

# Generated at 2022-06-11 01:06:43.806315
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'fooBar': 'baz', 'quxFoo': 42, 'foo': {'barBaz': 'qux'}}
    expected = {'foo_bar': 'baz', 'qux_foo': 42, 'foo': {'bar_baz': 'qux'}}
    assert camel_dict_to_snake_dict(camel_dict) == expected
    # Test two-way
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict, reversible=True), capitalize_first=True) == snake_dict_to_camel_dict(camel_dict)



# Generated at 2022-06-11 01:06:58.036925
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_keys = ['AWSTagKeys', 'Subnets', 'Tags', 'Type', 'VpcId']
    dict_values = [u'Environment', u'persistent', [{u'Value': None}, {u'Value': u'default'}, {u'Value': u'test'}, {u'Value': u'dev'}, {u'Value': u'production'}], [], u'ElasticLoadBalancerV2', u'vpc-12345678']

    # defaults should work for <aws>_tags
    a = dict(zip(dict_keys, dict_values))

# Generated at 2022-06-11 01:07:08.483171
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'MySQLParameters': {
            'port': 3306,
            'param1': True,
            'param2': False,
            'param3': None,
            'param4': 1,
            'param5': 'abc',
            'param6': '1'
        },
        'HTTPEndpoint': {
            'port': 80,
            'path': '/',
            'responseTimeout': 1
        },
        'Tags': {
            'tAg': 'tAg',
            '123': '123',
            'abc': 'abc'
        }
    }

# Generated at 2022-06-11 01:07:17.996789
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://example.com"}}) == {"h_t_t_p_endpoint": {"url": "http://example.com"}}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://example.com"}}, reversible=True) == {"h_t_t_p_endpoint": {"u_r_l": "http://example.com"}}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"URL": "http://example.com"}}, ignore_list=["HTTPEndpoint"]) == {"http_endpoint": {"url": "http://example.com"}}

# Generated at 2022-06-11 01:07:26.370278
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import pytest
    # test for case when camel_dict is empty
    assert camel_dict_to_snake_dict({}) == {}

    # test for case when camel_dict has non-empty values
    camel_dict = {"CamelCase": "Hello", "MultiWord": "world"}
    snake_dict = {"camel_case": "Hello", "multi_word": "world"}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

    # test for case when camel_dict has empty values
    camel_dict = {"EmptyCamelCase": {"": ""}, "EmptyMultiWord": {}}
    snake_dict = {"empty_camel_case": {"": ""}, "empty_multi_word": {}}
    assert camel_dict_to_snake_dict(camel_dict) == snake

# Generated at 2022-06-11 01:07:37.079501
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({u'HTTPEndpoint': True}) == {u'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({u'HTTPEndpoint': True}, reversible=True) == {u'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({u'h_t_t_p_endpoint': True}) == {u'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({u'HTTPEndpoint': True}, reversible=True) == {u'h_t_t_p_endpoint': True}
    assert camel_dict_to_snake_dict({u'HTTPEndpoint': {u'HTTP2': True}})

# Generated at 2022-06-11 01:07:44.973109
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:54.200521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'myFirstKey': 'my value',
        'mySecondKey': {'subCamelKey': 'sub value'},
        'myThirdKey': ['sub value 1', 'sub value 2'],
        'myFourthKey': {
            'subCamelKey': {
                'subCamelList': ['sub value 1', {'subCamelKey2': 'sub value 2'}]
            }
        },
        'myFifthKey': ['sub value 1', {'subCamelKey': 'sub value 2'}],
        'HTTPEndpoint': 'sub value'
    }


# Generated at 2022-06-11 01:08:01.616825
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_posts_list = [
        {
            "content": "this is a post",
            "tags": ["test"],
            "url": "http://test.com"
        },
        {
            "content": "test 2",
            "tags": ["test", "test2"],
            "url": "http://test.com/2"
        }
    ]

    expected_snake_posts_list = [
        {
            "content": "this is a post",
            "tags": ["test"],
            "url": "http://test.com"
        },
        {
            "content": "test 2",
            "tags": ["test", "test2"],
            "url": "http://test.com/2"
        }
    ]
