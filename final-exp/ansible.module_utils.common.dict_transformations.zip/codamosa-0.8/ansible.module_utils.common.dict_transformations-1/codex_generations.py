

# Generated at 2022-06-11 00:58:27.999972
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {'key': 'value', 'other': 'value', 'andanother': 'value'}}
    b = {'a': 2, 'b': {'nested': 'nested'}, 'c': 'c'}
    expected = {'a': 2, 'b': {'key': 'value', 'other': 'value', 'andanother': 'value', 'nested': 'nested'}, 'c': 'c'}
    assert dict_merge(a, b) == expected

# Generated at 2022-06-11 00:58:38.057129
# Unit test for function dict_merge
def test_dict_merge():

    dict1 = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3',
            'key4': 'value4',
        }
    }

    dict2 = {
        'key2': {
            'key3': 'changedvalue3',
            'key4': 'changedvalue4',
            'key5': 'value5',
        }
    }

    dict3 = {
        'key1': 'value1',
        'key2': {
            'key3': 'changedvalue3',
            'key4': 'changedvalue4',
            'key5': 'value5',
        }
    }

    merged = dict_merge(dict1, dict2)
    assert merged == dict3
    assert merged['key1'] == dict3['key1']
   

# Generated at 2022-06-11 00:58:48.789690
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:00.126735
# Unit test for function recursive_diff
def test_recursive_diff():
    sample_data = {
        "1": {
            "a": "A",
            "b": "B",
            "c": {
                "1": 1,
                "2": 2,
                "3": 3
            }
        },
        "2": "B",
        "3": [1, 2, 3]
    }
    sample_data_2 = {
        "1": {
            "a": "A",
            "b": "B",
            "c": {
                "1": 1,
                "2": 20,
                "3": 3
            }
        },
        "2": "B",
        "3": [1, 2, 3]
    }

# Generated at 2022-06-11 00:59:06.981244
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {}
    test_dict['key1'] = 'value1'
    test_dict['Key2'] = 'value2'
    test_dict['Key3'] = {'SubKey1': 'subvalue1', 'SubKey2': 'subvalue2'}
    test_dict['Key4'] = {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}

    expected_dict = {}
    expected_dict['key1'] = 'value1'
    expected_dict['key2'] = 'value2'
    expected_dict['key3'] = {'sub_key1': 'subvalue1', 'sub_key2': 'subvalue2'}
    expected_dict['key4'] = {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}

# Generated at 2022-06-11 00:59:18.220747
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:28.732261
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'a': {'b': {'c': 'd'}}, 'e': 'f'}) == {'a': {'b': {'c': 'd'}}, 'e': 'f'}
    assert camel_dict_to_snake_dict({'AB': {'CD': {'EF': 'GH'}}, 'IJ': 'KL'}) == {'ab': {'cd': {'ef': 'GH'}}, 'ij': 'KL'}

# Generated at 2022-06-11 00:59:39.703169
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': 1, 'Bar': 2}) == {'foo': 1, 'bar': 2}
    assert camel_dict_to_snake_dict({'Foo': 1, 'Bar': 2, 'Baz': 3}) == {'foo': 1, 'bar': 2, 'baz': 3}
    assert camel_dict_to_snake_dict({'Foo': {'Bar': 2}, 'Baz': 3}) == {'foo': {'bar': 2}, 'baz': 3}
    assert camel_dict_to_snake_dict({'Foo': {'HTTPEndpoint': 2}, 'Baz': 3}) == {'foo': {'h_t_t_p_endpoint': 2}, 'baz': 3}
    assert camel_dict_to_

# Generated at 2022-06-11 00:59:44.469994
# Unit test for function dict_merge
def test_dict_merge():
    test_a = {'k1': 'v1', 'k2': 'v2'}
    test_b = {'k3': 'v3', 'k4': 'v4'}
    result = dict_merge(test_a, test_b)
    assert result == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v4'}

    test_a = {'k1': 'v1', 'k2': {'k2.1': 'v2.1', 'k2.2': 'v2.2'}}
    test_b = {'k1': 'v1', 'k2': {'k2.2': 'v2.2', 'k2.3': 'v2.3'}}
    result = dict_

# Generated at 2022-06-11 00:59:49.551425
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aBc': 1, 'dEf': {'gHi': 2, 'jKl': 3}, 'mNo': 4, 'mNoP': {'qRs': 5, 'tUv': 6}}) == \
    {'a_bc': 1, 'd_ef': {'g_hi': 2, 'j_kl': 3}, 'm_no': 4, 'm_no_p': {'q_rs': 5, 'tUv': 6}}



# Generated at 2022-06-11 01:00:03.811486
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:12.075690
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {
        'MyName': 'aws-module',
        'Section': {
            'HTTPEndpoint': 'abc.com',
            'Tags': [
                {
                    'Key': 'name',
                    'Value': 'aws-module'
                },
                {
                    'Key': 'project',
                    'Value': 'ansible'
                }
            ],
            'Region': 'us-east-1'
        }
    }


# Generated at 2022-06-11 01:00:24.199960
# Unit test for function recursive_diff
def test_recursive_diff():

    # Test identical dictionaries
    d1 = {'key': 'value'}
    d2 = {'key': 'value'}
    assert recursive_diff(d1, d2) is None,\
           "recursive_diff does not return None for identical dictionaries"

    # Test fully different dictionaries
    d1 = {'key': 'value'}
    d2 = {'key': 'different'}
    assert recursive_diff(d1, d2) == ({'key': 'value'}, {'key': 'different'}),\
           "recursive_diff is expected to return ({'key': 'value'}, {'key': 'different'}). "\
           "Instead got %s" % str(recursive_diff(d1, d2))

    # Test partially different dictionaries

# Generated at 2022-06-11 01:00:34.344159
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'a': 1, 'b': 2, 'c': {'c1': 1, 'c2': 2}, 'd': {'d1': 1, 'd2': 2, 'd3': None}}
    b = {'a': 1, 'b': 3, 'c': {'c1': 1, 'c2': 4}, 'd': {'d1': 1, 'd2': 2, 'd4': 4}}

    left, right = recursive_diff(a, b)
    assert left == {'b': 2, 'c': {'c2': 2}, 'd': {'d3': None}}
    assert right == {'b': 3, 'c': {'c2': 4}, 'd': {'d4': 4}}


# Code to calculate differences between 2 dicts. This is useful
# for

# Generated at 2022-06-11 01:00:45.890845
# Unit test for function recursive_diff
def test_recursive_diff():
    """tests for the function recursive_diff"""
    dict1 = {'foo': 'bar', 'bar': {'bar1': 'foo1', 'bar2': 'foo2'}, 'none_key': None, 'morekeys': {'none_key': None}}
    dict2 = {'foo': 'bar', 'bar': {'bar2': 'foo2', 'bar1': 'foo1'}, 'none_key': None, 'morekeys': {'none_key': None}}
    dict3 = {'foo': 'bar', 'bar': {'bar1': 'foo1', 'bar2': 'foo22'}, 'none_key': None, 'morekeys': {'none_key': None}}

# Generated at 2022-06-11 01:00:56.532073
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    testDict = {"fooBar": {"barFoo": "foobar", "bar": "foo", "fooBarFoo": "bar"},
                "foo": {"fooFoo": "bar"},
                "fooFoo": "foo",
                "foobar": [{"foo": "bar", "fooFoo": "barFoo"}]}
    assert camel_dict_to_snake_dict(testDict) == {'foo_bar': {'bar_foo': 'foobar', 'bar': 'foo', 'foo_bar_foo': 'bar'},
                                                  'foo': {'foo_foo': 'bar'},
                                                  'foo_foo': 'foo',
                                                  'foobar': [{'foo': 'bar', 'foo_foo': 'barFoo'}]}

# Generated at 2022-06-11 01:01:06.767503
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test simple case
    input_dict = {'Tier': 'Gold', 'Environment': 'Test', 'Created': 'June 15, 2018'}

    expected_dict = {'tier': 'Gold', 'environment': 'Test', 'created': 'June 15, 2018'}

    assert camel_dict_to_snake_dict(input_dict) == expected_dict

    # Test case with nested dictionary
    input_dict = {'Tier': 'Gold', 'Environment': 'Test', 'Created': 'June 15, 2018', 'Engine': {'Name': 'Oracle'}}

    expected_dict = {'tier': 'Gold', 'environment': 'Test', 'created': 'June 15, 2018',
                     'engine': {'name': 'Oracle'}}

    assert camel_dict_to_snake_dict(input_dict) == expected_dict

    # Test

# Generated at 2022-06-11 01:01:17.613139
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'EndpointURL': 'https://amazonaws.com', 'HTTPCode': 200, 'HTTPHeaders': {'content-type': 'application/json'}}, 'Tags': {'HTTPEndpoint': 'Test'}}

    assert camel_dict_to_snake_dict(test_dict) == {'http_endpoint': {'endpoint_url': 'https://amazonaws.com', 'http_code': 200, 'http_headers': {'content-type': 'application/json'}}, 'tags': {'HTTPEndpoint': 'Test'}}

# Generated at 2022-06-11 01:01:25.185419
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict_sample_one = {
        "master": {
            "cluster": {
                'cluster_size': 1,
                'cluster_ids': [
                    'cluster_id1',
                    'cluster_id2'
                ],
                "cluster_name": "test_cluster"
            },
            "advance_option": {
                "metadata_options": {
                    "collection_namespace": "test_namespace",
                    "aws_request_timeout": {
                        "collection_timeout_millis": 1000
                    }
                }
            }
        }
    }


# Generated at 2022-06-11 01:01:36.787573
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'b': 2}) == ({}, {'b': 2})
    assert recursive_diff({'a': 1}, {'b': 2}) == ({'a': 1}, {'b': 2})
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, {})

# Generated at 2022-06-11 01:01:52.053187
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    assert recursive_diff({1: 2}, {1: 2}) == None
    assert recursive_diff({1: 2}, {1: 3}) == ({1: 2}, {1: 3})
    assert recursive_diff({1: 2}, {}) == ({1: 2}, {})
    assert recursive_diff({}, {1: 2}) == ({}, {1: 2})
    assert recursive_diff({1: {3: 4}}, {1: {3: 4}}) == None
    assert recursive_diff({1: {3: 4}}, {1: {3: 5}}) == ({1: {3: 4}}, {1: {3: 5}})

# Generated at 2022-06-11 01:02:00.613660
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Verify that the example snake_to_camel functions work as advertised
    assert _snake_to_camel("route_table_id") == "routeTableId"
    assert _snake_to_camel("address_family") == "addressFamily"
    assert _snake_to_camel("route_table_ids") == "routeTableIds"
    assert _snake_to_camel("route_table_id", True) == "RouteTableId"
    assert _snake_to_camel("address_family", True) == "AddressFamily"
    assert _snake_to_camel("route_table_ids", True) == "RouteTableIds"

    # Verify that the example camel_to_snake functions work as advertised

# Generated at 2022-06-11 01:02:12.518980
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Check that dict with singular capitalized keys is converted to dict with all lowercase keys
    test_dict = {'SingularValue': 'value', 'PluralValues': ['value1', 'value2']}
    result = camel_dict_to_snake_dict(test_dict)
    assert result == {'singular_value': 'value', 'plural_values': ['value1', 'value2']}

    # Check that dict with singular CamelCase keys is converted to dict with all snake_case keys
    test_dict = {'CamelCaseValue': 'value', 'CamelCaseValues': ['value1', 'value2']}
    result = camel_dict_to_snake_dict(test_dict)

# Generated at 2022-06-11 01:02:23.728156
# Unit test for function recursive_diff
def test_recursive_diff():
    d_1 = {}
    d_2 = {}
    assert recursive_diff(d_1, d_2) is None

    d_1 = {'a': '1'}
    d_2 = {'a': '2'}
    assert recursive_diff(d_1, d_2) == ({'a': '1'}, {'a': '2'})

    d_1 = {'a': {'c': '1'}, 'b': '2'}
    d_2 = {'a': {'c': '1'}, 'b': '3'}
    assert recursive_diff(d_1, d_2) == ({'b': '2'}, {'b': '3'})

    d_1 = {'a': '1', 'b': {'c': '1'}}
    d

# Generated at 2022-06-11 01:02:31.954051
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:41.473931
# Unit test for function recursive_diff
def test_recursive_diff():
    # special cases
    # both empty dicts
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == None

    # dict1 contains dict2
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    dict2 = {'b': 2}
    assert recursive_diff(dict1, dict2) == ({'a': 1, 'c': {'d': 4, 'e': 5}}, {})

    # dict2 contains dict1
    dict2 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    dict1 = {'b': 2}

# Generated at 2022-06-11 01:02:53.442208
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"ApiGatewayManaged": False,
                 "Description": "Test Gateway",
                 "HttpApiId": 12345,
                 "Name": "TestName",
                 "RouteSelectionExpression": "${request.method} ${request.path}",
                 "Target": "TestTarget",
                 "Tags": {
                     "Name": "TestName"
                 }}

    expected_test_dict = {"api_gateway_managed": False,
                          "description": "Test Gateway",
                          "http_api_id": 12345,
                          "name": "TestName",
                          "route_selection_expression": "${request.method} ${request.path}",
                          "target": "TestTarget",
                          "tags": {
                              "Name": "TestName"
                          }}

    returned

# Generated at 2022-06-11 01:03:04.366741
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Run unit test for function ``recursive_diff``
    """
    import json
    import os
    import shutil
    import tempfile

    def _prepare_data_file(data):
        (fd, path) = tempfile.mkstemp(prefix='ansible_test_recursive_diff_')
        f = os.fdopen(fd, "w")
        json.dump(data, f)
        f.close()
        return path

    def _verify_results(expected, actual):
        assert(expected[0] == actual[0])
        assert(expected[1] == actual[1])


# Generated at 2022-06-11 01:03:14.873250
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {'test_prop': 'v1'} == camel_dict_to_snake_dict({'testProp': 'v1'})
    assert {
        'test_prop': {
            'sub_prop': 'v1'
        }
    } == camel_dict_to_snake_dict({'testProp': {'subProp': 'v1'}})
    assert {
        'tags': {
            'prop1': 'v1'
        }
    } == camel_dict_to_snake_dict({'tags': {'prop1': 'v1'}}, ignore_list=['tags', 'subtags'])

    # edge case a single word
    assert {'ec2': 'v1'} == camel_dict_to_snake_dict({'EC2': 'v1'})

    #

# Generated at 2022-06-11 01:03:23.245442
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'aBcDe': 'fgh', 'iJkL': 'mnOp', 'qrStUvWxYz': '1234567890'}
    snake_dict = {'a_bc_de': 'fgh', 'i_jk_l': 'mnOp', 'qr_st_uv_wx_yz': '1234567890'}

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-11 01:03:32.564432
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'HTTPEndpoint': {'Protocols': ['HTTP', 'HTTPS'],
                                   'Path': 'string',
                                   'Authorization': {'AuthorizationType': 'NONE',
                                                     'AuthorizerId': 'string'},
                                   'RouteSelectionExpression': 'string',
                                   'TimeoutInMillis': 123,
                                   'TLSConfig': {'ServerNameToVerify': 'string'}},
                  'SelectiveAuth': {'RequiredAuthTypes': ['default'],
                                    'DefaultAuthType': 'string'}}


# Generated at 2022-06-11 01:03:43.795933
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "foo": "bar",
        "listOfStuff": [1,2,3],
        "TCPOptions": {
            "one": "two",
            "three": "four",
            "five": "six"
        }
    }

    # Test default conversion, which shouldn't have any reversibility
    expected_result = {
        "foo": "bar",
        "list_of_stuff": [1,2,3],
        "tcp_options": {
            "one": "two",
            "three": "four",
            "five": "six"
        }
    }
    assert expected_result == camel_dict_to_snake_dict(test_dict)


# Generated at 2022-06-11 01:03:52.500498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelDict1 = { "Prop1": "value1", "Prop2": ["value1","value2"] }
    snakeDict1 = camel_dict_to_snake_dict(camelDict1)
    assert isinstance(snakeDict1, (dict))
    assert snakeDict1['prop1'] == 'value1'
    assert snakeDict1['prop2'] == ["value1","value2"]

    camelDict2 = { "Prop1": "value1", "Prop2": ["value1","value2"],
                    "Prop3": { "SubProp1": "sub_value1", "SubProp2": "sub_value2" } }
    snakeDict2 = camel_dict_to_snake_dict(camelDict2)
    assert isinstance(snakeDict2, (dict))


# Generated at 2022-06-11 01:04:04.194249
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # An empty dict
    assert camel_dict_to_snake_dict({}) == {}

    # A dict with a simple value
    assert camel_dict_to_snake_dict({"key": "val"}) == {'key': 'val'}

    # A dict with more than one simple value
    assert camel_dict_to_snake_dict({"key1": "val1", "key2": "val2"}) == {'key1': 'val1',
                                                                       'key2': 'val2'}

    # A dict with nested (sub)dicts
    assert camel_dict_to_snake_dict({"key": {"subKey": "val"}}) == {'key': {'sub_key': 'val'}}

    # A dict with nested (sub)dicts, more than one simple value


# Generated at 2022-06-11 01:04:15.612864
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:26.783015
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:35.582605
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Camel Dict
    camel_dict = {'myCamelDict': 'camel_dict',
                  'camelList': [
                      'list',
                      {'listCamelDict': 'list_dict',
                       'listCamelList': ['list', 'list']}],
                  'camelDict': {'dictCamelDict': 'dict_dict'},
                  'camelIgnoreTags': {'Tags': {
                      'Key': 'Name', 'Value': 'test-1'}},
                  'camelIgnorePropertyList': ['dict', 'dict'],
                  }
    # Expected snake dict

# Generated at 2022-06-11 01:04:47.294958
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test simple cases
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "foo"}) == {"h_t_t_p_endpoint": "foo"}
    assert camel_dict_to_snake_dict({"HTTP_Endpoint": "foo"}) == {"h_t_t_p_endpoint": "foo"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "foo"}, reversible=True) == {"h_t_t_p_endpoint": "foo"}
    assert camel_dict_to_snake_dict({"HTTP_Endpoint": "foo"}, reversible=True) == {"h_t_p_endpoint": "foo"}

# Generated at 2022-06-11 01:04:57.157594
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': {
            'baz': {
                'fooBarBaz': 'qux'
            },
            'HTTPEndpoint': {
                'host': 'somehost',
                'port': 80,
                'HTTPEndpoint2': {
                    'host': 'somehost2',
                    'port': 8080,
                }
            }
        }
    }

    # print test_dict


# Generated at 2022-06-11 01:05:06.850301
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'stringKey': 'stringVal',
        'integerKey': 1234,
        'dictKey': {
            'matchKey': 'matchVal',
            'noMatchKey': 'noMatchVal'
        },
        'listKey': [
            {
                'listMatchKey': 'listMatchVal',
                'listNoMatchKey': 'listNoMatchVal'
            }
        ]
    }


# Generated at 2022-06-11 01:05:19.673087
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def assert_camel_to_snake(input, expected_output):
        assert camel_dict_to_snake_dict(input) == {expected_output: "value"}

    assert_camel_to_snake({'HTTPEndpoint': 'value'}, 'http_endpoint')
    assert_camel_to_snake({'HTTPEndpoint': 'value'}, 'http_endpoint')
    assert_camel_to_snake({'HttpEndpoint': 'value'}, 'http_endpoint')
    assert_camel_to_snake({'EC2': 'value'}, 'ec2')
    assert_camel_to_snake({'EC2': 'value'}, 'ec2')
    assert_camel_to_snake({'EC2Instance': 'value'}, 'ec2_instance')

# Generated at 2022-06-11 01:05:30.126518
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPEndpoint": {}, "HTTPEndpointConfig": {}, "TargetGroupARNs": ["arn:aws:elasticloadbalancing:us-east-1:1234567890:targetgroup/lb-test-http-endpoint/6d0ecb6931e6a184"]}

    expected_dict = {"h_t_t_p_endpoint": {}, "h_t_t_p_endpoint_config": {}, "target_group_ar_ns": ["arn:aws:elasticloadbalancing:us-east-1:1234567890:targetgroup/lb-test-http-endpoint/6d0ecb6931e6a184"]}


# Generated at 2022-06-11 01:05:40.563310
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {'HTTPEndpoint': 'ARN', 'ContainerDefinition': {'Tags': {'Name': 'my_container'}}},
        ignore_list=['Tags']) == {
            'h_t_t_p_endpoint': 'ARN',
            'container_definition': {
                'tags': {
                    'Name': 'my_container'}}}


# Generated at 2022-06-11 01:05:52.180012
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:02.008299
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_true_snake = {'KeyName': 'test',
                             'SecurityGroups': [{'GroupId': 'sg-1234567'}],
                             'InstanceType': 't2.micro',
                             'BlockDeviceMappings': [
                                 {'DeviceName': '/dev/sda1',
                                  'Ebs': {'VolumeSize': 8,
                                          'DeleteOnTermination': True,
                                          'VolumeType': 'gp2'}}],
                             'NetworkInterfaces': [
                                 {'SubnetId': 'subnet-1234567',
                                  'DeviceIndex': 0,
                                  'AssociatePublicIpAddress': True,
                                  'Groups': []}],
                             'Placement': {'AvailabilityZone': 'us-east-1a'}}


# Generated at 2022-06-11 01:06:10.761159
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict({
        "StringKey": "StringValue",
        "NumberKey": 12345,
        "BooleanKey": False,
        "ListKey": [1, 2, 3],
        "DictKey": {
            "Value1": "StringValue",
            "Value2": 12345,
            "Value3": False,
        }
    })
    assert result == {
        "string_key": "StringValue",
        "number_key": 12345,
        "boolean_key": False,
        "list_key": [1, 2, 3],
        "dict_key": {
            "value1": "StringValue",
            "value2": 12345,
            "value3": False,
        }
    }

# Generated at 2022-06-11 01:06:21.193301
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"FooBar": "baz"}) == {"foo_bar": "baz"}  # Single key/val
    assert camel_dict_to_snake_dict({"fooBar": "baz"}) == {"foo_bar": "baz"}  # Single key/val, starting lowercase
    assert camel_dict_to_snake_dict({"FooBar": {"fooBar": "baz"}}) == {"foo_bar": {"foo_bar": "baz"}}  # Deeply nested dict
    assert camel_dict_to_snake_dict({"fooBar": {"fooBar": "baz"}}) == {"foo_bar": {"foo_bar": "baz"}}  # Deeply nested dict, starting lowercase
    assert camel_dict_to_snake_

# Generated at 2022-06-11 01:06:29.415401
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = dict(BucketName='ansible-s3-bucket', Tags=[dict(Key='mytag1', Value='myvalue1')])
    expected_dict = dict(bucket_name='ansible-s3-bucket', tags=[dict(key='mytag1', value='myvalue1')])
    assert camel_dict_to_snake_dict(test_dict) == expected_dict
    test_dict = dict(HTTPEndpoint='http://endpoint', Tags=[dict(Key='mytag1', Value='myvalue1')])
    expected_dict = dict(h_t_t_p_endpoint='http://endpoint', tags=[dict(key='mytag1', value='myvalue1')])
    assert camel_dict_to_snake_dict(test_dict, reversible=True) == expected_dict

# Generated at 2022-06-11 01:06:34.902812
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"awsRegion": "us-east-1", "AvailabilityZones": ["us-east-1c"]}
    assert camel_dict_to_snake_dict(test_dict) == {'aws_region': 'us-east-1', 'availability_zones': ['us-east-1c']}


# Unit tests for function snake_dict_to_camel_dict

# Generated at 2022-06-11 01:06:43.424055
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test CamelCase -> snake_case
    camel_dict = {
        "Key": "value",
        "nestedDict": {"nestedKey": "nestedValue"},
        "nestedList": [
            {
                "nestedListKey1": "nestedListValue1",
                "nestedListKey2": "nestedListValue2"
            }
        ]
    }
    expected_snake_dict = {
        "key": "value",
        "nested_dict": {"nested_key": "nestedValue"},
        "nested_list": [
            {
                "nested_list_key1": "nestedListValue1",
                "nested_list_key2": "nestedListValue2"
            }
        ]
    }

    snake_dict = camel_dict_to

# Generated at 2022-06-11 01:06:58.784693
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"HTTPEndpoint": {"Path": "/example", "Protocol": "HTTPS"}}
    expected = {"http_endpoint": {"path": "/example", "protocol": "HTTPS"}}
    assert camel_dict_to_snake_dict(camel_dict) == expected

    camel_dict = {"HTTPEndpoint": {
        "Protocol": "HTTP",
        "HostHeaderConfig": {
            "HostHeader": "www.example.com",
            "UseRoute53Hostname": True
        }
    }}
    expected = {"http_endpoint": {
        "protocol": "HTTP",
        "host_header_config": {
            "host_header": "www.example.com",
            "use_route53_hostname": True
        }
    }}
    assert camel_dict_to

# Generated at 2022-06-11 01:07:08.645869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'fooBar': 'baz', 'isThing': True}
    result = camel_dict_to_snake_dict(camel_dict)

    assert result['foo_bar'] == 'baz'
    assert result['is_thing'] == True

    camel_dict = {'fooBar': {'isThing': True, 'Results': [{'foo': 'bar'}, {'baz': 'qux'}]}}
    result = camel_dict_to_snake_dict(camel_dict)

    assert result['foo_bar']['is_thing'] == True
    assert result['foo_bar']['results'] == [{'foo': 'bar'}, {'baz': 'qux'}]



# Generated at 2022-06-11 01:07:18.207072
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Note the importance of including 'Tags' in the ignore_list
    # due to case-sensitive nature of some keys
    camel_dict = {
        "AccountId": "8675309",
        "Tags": {
            "FirstName": "Bob",
            "LastName": "Ross"
        },
        "VpcId": "vpc-23456789",
    }
    snake_dict = {
        "account_id": "8675309",
        "tags": {
            "FirstName": "Bob",
            "LastName": "Ross"
        },
        "vpc_id": "vpc-23456789",
    }
    assert(camel_dict_to_snake_dict(camel_dict, ignore_list=['Tags']) == snake_dict)

    # Test _camel_

# Generated at 2022-06-11 01:07:26.584364
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Testing for function camel_dict_to_snake_dict"""

    starting_dict = {
        'OptionSetting': [
            {'Name': 'string', 'Value': 'string', 'DBId': 'string'}
        ]
    }

    expected_dict = {
        'option_setting': [
            {'name': 'string', 'value': 'string', 'db_id': 'string'}
        ]
    }

    assert camel_dict_to_snake_dict(starting_dict) == expected_dict


# Generated at 2022-06-11 01:07:37.371398
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:45.130548
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test data
    test_case = {
        'Tags': {
            'Key': 'Value'
        },
        'JSON': True,
    }

    # Test values
    assert {
        'tags': {
            'Key': 'Value'
        },
        'j_s_o_n': True
    } == camel_dict_to_snake_dict(test_case)

    # Test values
    assert {
        'Tags': {
            'Key': 'Value'
        },
        'JSON': True
    } == snake_dict_to_camel_dict(camel_dict_to_snake_dict(test_case), capitalize_first=True)

    # Test values

# Generated at 2022-06-11 01:07:54.249997
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:59.246318
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assertions = {
        "custom_policy": {
            "policy_name": "a",
            "policy_document": "b"
        }
    }
    camel_dict = {
        "CustomPolicy": {
            "PolicyName": "a",
            "PolicyDocument": "b"
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == assertions



# Generated at 2022-06-11 01:08:07.759109
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_data = {
        'HTTPEndpoint': {
            'Type': 'INSERT',
            'HTTPEndpointConfiguration': {
                'URL': 'http://example/endpoint'
            },
            'Name': 'test',
            'EndpointARN': 'arn:aws:sns:us-east-1:123456789:test'
        }
    }

    result = camel_dict_to_snake_dict(test_data, reversible=True)