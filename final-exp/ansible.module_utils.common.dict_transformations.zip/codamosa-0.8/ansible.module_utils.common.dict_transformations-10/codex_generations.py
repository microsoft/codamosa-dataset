

# Generated at 2022-06-11 00:58:17.075041
# Unit test for function recursive_diff
def test_recursive_diff():
    pass

# Generated at 2022-06-11 00:58:23.618570
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': {'key2': 1}}
    b = {'key1': {'key3': 2}}
    expected_result = {'key1': {'key2': 1, 'key3': 2}}
    assert dict_merge(a, b) == expected_result


# Test function recursive_diff

# Generated at 2022-06-11 00:58:34.215526
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test with no changes.
    dict1 = {}
    dict2 = {}
    diff = recursive_diff(dict1, dict2)
    assert diff is None

    dict1 = dict(a=1, b=2)
    dict2 = dict()
    dict2.update(dict1)
    diff = recursive_diff(dict1, dict2)
    assert diff is None

    dict1 = dict(a=1, b=2)
    dict2 = dict()
    dict2.update(dict1)
    dict2['c'] = 3
    diff = recursive_diff(dict1, dict2)
    assert diff is not None
    assert len(diff[1]) == 1
    assert diff[1]['c'] == 3


# Generated at 2022-06-11 00:58:41.967836
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Case of empty dictionary
    assert camel_dict_to_snake_dict({}) == {}
    # Case of a simple dictionary
    assert camel_dict_to_snake_dict({"key1": "val1", "key2": 2}) == {"key1": "val1", "key2": 2}
    # Case of nested dictionaries
    assert camel_dict_to_snake_dict({"key1": "val1", "sub": {"subKey1": "subVal1"}}) == {"key1": "val1", "sub": {"sub_key1": "subVal1"}}

# Generated at 2022-06-11 00:58:51.821548
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'httpEndpoint': {
            'path': '',
            'host': '',
            'scheme': '',
            'verb': '',
            'enabled': True,
            'port': 80
        }
    }
    expected_dict = {
        'http_endpoint': {
            'path': '',
            'host': '',
            'scheme': '',
            'verb': '',
            'enabled': True,
            'port': 80
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-11 00:59:02.255720
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {'HTTPEndpoint': {'URL': 'https://myendpoint.com', 'Method': 'POST'}, 'string_key': 'string', 'int_key': 123, 'VPC': {'VPCId': 'vpc-1a2b3c4d', 'Subnets': ['subnet-1a2b3c4d', 'subnet-5e6f7g8h', 'subnet-1i2j3k4l']}, 'Tags': {'Name': 'TestName'}}

# Generated at 2022-06-11 00:59:13.738091
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:22.568694
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Tags': {
            'tag1': 'value',
            'tag2': 'value',
        },
        'HTTPEndpoint': 'https://example.com',
        'HTTPHeaders': [
            {
                'Name': 'name1',
                'Value': 'value1'
            },
            {
                'Name': 'name2',
                'Value': 'value2'
            }
        ]
    }

# Generated at 2022-06-11 00:59:34.095158
# Unit test for function recursive_diff
def test_recursive_diff():
    """test recursive_diff function"""
    # Test 1
    dict1 = {'a': 1, 'b': 2, 'c': {'c1': 1, 'c2': 2}}
    dict2 = {'a': 1, 'b': 3, 'c': {'c1': 1, 'c2': 3, 'c3': 4}}
    result = recursive_diff(dict1, dict2)
    assert(result == ({'b': 2}, {'b': 3, 'c': {'c2': 3, 'c3': 4}}))
    # Test 2
    dict1 = {'a': 1, 'b': 2, 'c': {'c1': 1, 'c2': 2}}

# Generated at 2022-06-11 00:59:44.752638
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'instanceIds': ['i-1','i-2','i-3'],
        'vegetables': [{'carrots': 'orange'}]
    }
    assert camel_dict_to_snake_dict(camel_dict) == {'instance_ids': ['i-1', 'i-2', 'i-3'], 'vegetables': [{'carrots': 'orange'}]}
    assert camel_dict_to_snake_dict(camel_dict, ignore_list=['vegetables']) == {'instance_ids': ['i-1', 'i-2', 'i-3'], 'vegetables': [{'carrots': 'orange'}]}


# Generated at 2022-06-11 01:00:01.546557
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test that two empty dictionaries are equal
    assert recursive_diff({}, {}) == None

    # Test that two dictionaries with different key sizes are equal
    assert recursive_diff({'key': 'value'}, {}) == ({'key': 'value'}, {})

    # Test that two dictionaries with different values are equal
    assert recursive_diff({'key': 'value1'}, {'key': 'value2'}) == ({'key': 'value1'}, {'key': 'value2'})

    # Test that two dictionaries with one level of nesting are equal
    assert recursive_diff({'level1': {'key1': 'value1', 'key2': 'value2'}}, {'level1': {'key1': 'value1', 'key2': 'value2'}}) == None

# Generated at 2022-06-11 01:00:10.578988
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'foo': 'bar'}, {'foo': 'bar'}) is None
    assert recursive_diff({'foo': 'bar'}, {'foo': 'baz'}) == ({'foo': 'bar'}, {'foo': 'baz'})
    assert recursive_diff({'foo': 'bar'}, {'foo': 'baz', 'biz': 'faz'}) == ({'foo': 'bar'}, {'foo': 'baz', 'biz': 'faz'})
    assert recursive_diff({'foo': 'bar', 'biz': 'faz'}, {'foo': 'bar'}) == ({'biz': 'faz'}, {})

# Generated at 2022-06-11 01:00:22.476385
# Unit test for function recursive_diff
def test_recursive_diff():
    # Check if all the following conditions return a difference
    # between two dictionaries.
    #
    # if a key in one dictionary is not in the other
    assert isinstance(recursive_diff({'a':1}, {'b':1}), tuple)
    # if a key in both dictionaries are of different data types
    assert isinstance(recursive_diff({'a':1}, {'a':'b'}), tuple)
    # if a key in one dictionary is a nested dictionary
    assert isinstance(recursive_diff({'a':{'b':1}}, {'a':2}), tuple)
    # if a key in both dictionaries are of type dictionary
    # but are different

# Generated at 2022-06-11 01:00:31.632354
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': 1, 'b': {'b1': 2, 'b2': 3, 'b3': {'b3a': 1, 'b3b': 2}}, 'c': 4}
    dict2 = {'a': 1, 'b': {'b1': 2, 'b2': 3, 'b3': {'b3a': 1, 'b3b': 3}}, 'd': 4}
    result = recursive_diff(dict1, dict2)
    assert result[0] == {'c': 4}
    assert result[1] == {'d': 4, 'b': {'b3': {'b3b': 3}}}

# Generated at 2022-06-11 01:00:42.669477
# Unit test for function recursive_diff
def test_recursive_diff():
    # Normal diff
    dict1 = {"a": 1, "b": 2}
    dict2 = {"a": 1, "b": 3}
    diff = recursive_diff(dict1, dict2)
    if diff == ({'b': 2}, {'b': 3}):
        print('recursive_diff: Normal diff test passed')
    else:
        print('recursive_diff: Normal diff test failed')

    # Recursive diff
    dict1 = {"a": 1, "b": 2, "c": {"d": 4, "e": 5, "f": {"g": 7, "h": 8}}}
    dict2 = {"a": 1, "b": 3, "c": {"d": 4, "e": 5, "i": {"j": 10}}}
    diff = recursive_diff(dict1, dict2)

# Generated at 2022-06-11 01:00:54.212429
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        a=dict(
            camelCase=dict(
                CamelCase1=1,
                CamelCase2=2,
            )
        ),
        b=dict(
            camelCase=dict(
                CamelCase3=3,
            ),
            snake_case=dict(
                snake_case1=1,
                snake_case2=2,
            )
        ),
        c=3,
        d=dict(
            camelCase=dict(
                CamelCase4=4,
            )
        ),
        Tags=dict(
            Key1=dict(
                Value=1,
            ),
            Key2=dict(
                Value=2,
            )
        ),
    )


# Generated at 2022-06-11 01:00:54.585486
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    pass

# Generated at 2022-06-11 01:01:03.697670
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict1 = {
        'InstanceIds': [
            'i-00000000000000000',
            'i-11111111111111111'
        ],
        'MaxResults': 20,
        'Filters': [
            {
                'Name': 'tag:Name',
                'Values': [
                    'instance-name'
                ]
            }
        ]
    }

    snake_dict1 = {
        'instance_ids': [
            'i-00000000000000000',
            'i-11111111111111111'
        ],
        'max_results': 20,
        'filters': [
            {
                'name': 'tag:Name',
                'values': [
                    'instance-name'
                ]
            }
        ]
    }


# Generated at 2022-06-11 01:01:14.532636
# Unit test for function recursive_diff
def test_recursive_diff():
    import pytest

    # Test empty dicts
    assert recursive_diff({}, {}) is None

    # Test basic difference
    assert recursive_diff({'foo': 'bar'}, {}) == ({'foo': 'bar'}, {})

    # Test basic difference
    assert recursive_diff({}, {'foo': 'bar'}) == ({}, {'foo': 'bar'})

    # Test deeper difference
    assert recursive_diff({'foo': {'baz': 'abc'}}, {'foo': {'baz': 'xyz'}}) == ({'foo': {'baz': 'abc'}}, {'foo': {'baz': 'xyz'}})

    # Test deeper multiple difference

# Generated at 2022-06-11 01:01:23.583196
# Unit test for function recursive_diff
def test_recursive_diff():
    # test recursive diff with different values in first and second layer
    dict1 = {'dict1_key1': 'dict1_value1', 'dict1_key2': 'dict1_value2', 'dict1_key3': {'dict3_key1': 'dict3_value1'}}
    dict2 = {'dict1_key1': 'dict2_value1', 'dict1_key2': 'dict2_value2', 'dict1_key3': {'dict3_key1': 'dict3_value1'}}

# Generated at 2022-06-11 01:01:36.443527
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "ArrayValue": [1, 2, 3],
            "BooleanValue": True,
            "DoubleValue": 123.4,
            "HTTPHeaders": [{"Key": "X-ANSIBLE", "Value": "ROCKS"}],
            "HttpMethod": "POST",
            "LongValue": 123,
            "Name": "baz",
            "RequestParameters": {
                "entry.1.key": "instanceType",
                "entry.1.value": "m4.10xlarge"
            },
            "ResourcePath": "/",
            "TimeoutInSeconds": 29
        }
    }
    camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:01:45.411555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Tags': {
            'Environment': 'dev',
            'Name': 'test'
        },
        'HTTPEndpoint': {
            'Enable': False
        },
        'TargetGroupARNs': [],
        'TargetType': 'ip',
        'HTTPTargets': [],
        'TargetGroupARNs': [],
        'TargetType': 'ip',
        'Targets': [
            {
                'Id': 'i-0f76fade',
                'Port': 80,
                'AvailabilityZone': 'eu-west-1c'
            }
        ]
    }

    result = camel_dict_to_snake_dict(test_dict, True)

    assert(result['h_t_t_p_endpoint']['enable'] == False)

# Generated at 2022-06-11 01:01:56.110973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'FooBar': 'baz'}) == {'foo_bar': 'baz'})
    assert(camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'})
    assert(camel_dict_to_snake_dict({'isFooBar': 'baz'}) == {'is_foo_bar': 'baz'})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint': 'baz'}) == {'http_endpoint': 'baz'})

# Generated at 2022-06-11 01:02:06.680953
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'helloWorld': {'fooBarBaz': 'qux', 'bar': 'qux'}, 'baz': 'qux', 'listCompatible': [{'fooBarBaz': 'qux', 'bar': 'qux'}, {'fooBarBaz': 'qux', 'bar': 'qux'}]}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'hello_world': {'foo_bar_baz': 'qux', 'bar': 'qux'}, 'baz': 'qux', 'list_compatible': [{'foo_bar_baz': 'qux', 'bar': 'qux'}, {'foo_bar_baz': 'qux', 'bar': 'qux'}]}
    assert camel

# Generated at 2022-06-11 01:02:19.011377
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    class TestCamelDict(object):

        def __init__(self):
            self.camel_dict = {
                "Subnet": "subnet1",
                "SecurityGroup": "group2",
                "HTTPEndpoint": {
                    "Method": "POST",
                    "Host": "www.microsoft.com",
                    "Path": "/path/to/api/endpoint"
                }
            }
            self.reversible_camel_dict = {
                "Subnet": "subnet1",
                "SecurityGroup": "group2",
                "HTTPDetails": {
                    "Method": "POST",
                    "Host": "www.microsoft.com",
                    "Path": "/path/to/api/endpoint"
                }
            }

# Generated at 2022-06-11 01:02:28.008020
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:34.409394
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'camelCase': 'test',
        'camelCase2': {
            'camelCase3': 'test',
            'camelCase4': 'test'
        },
        'camelCase5': {
            'Tags': [
                {
                    'key': 'test',
                    'value': 'test'
                }
            ]
        }
    }

# Generated at 2022-06-11 01:02:43.339980
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    import json

    test = {
        "VpcId": "vpc-123456",
        "Tags": {
            "Environment": "prod",
            "Name": "foo"
        },
        "SubnetIds": [
            "subnet-123456",
            "subnet-234567"
        ],
    }

    expected = {
        "vpc_id": "vpc-123456",
        "tags": {
            "Environment": "prod",
            "Name": "foo"
        },
        "subnet_ids": [
            "subnet-123456",
            "subnet-234567"
        ],
    }

    result = camel_dict_to_snake_dict(test)

    assert result == expected

    assert json.dumps(result) == json.d

# Generated at 2022-06-11 01:02:55.090904
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "loadBalancers": {
            "HTTPEndpoint": {
                "endpointName": "http_endpoint",
                "endpointState": "ENABLED",
                "host": "example.com",
            }
        },
        "tags": {
            "TestTag": "test"
        }
    }
    expected = {
        "load_balancers": {
            "h_t_t_p_endpoint": {
                "endpoint_name": "http_endpoint",
                "endpoint_state": "ENABLED",
                "host": "example.com"
            },
        },
        "tags": {
            "TestTag": "test"
        }
    }

# Generated at 2022-06-11 01:03:05.722563
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    "Test function camel_dict_to_snake_dict from helper"

    input_dict = {
        'TargetGroup':
        {
            'TargetGroupARNs': [
                'arn-target-group'
            ],
            'Origin': 'origin',
            'TargetType': 'ip'
        }
    }

    test_dict = camel_dict_to_snake_dict(input_dict)
    assert test_dict == {'target_group': {'origin': 'origin', 'target_group_arns': ['arn-target-group'],
                                          'target_type': 'ip'}}

    test_dict = camel_dict_to_snake_dict(input_dict, True)

# Generated at 2022-06-11 01:03:19.532999
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def assertEqual(left, right):
        if left == right:
            return
        raise Exception("Assertion failure: %s != %s" % (left, right))


# Generated at 2022-06-11 01:03:29.981799
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # following example taken from https://github.com/ansible/ansible/issues/32015
    camel_dict = {
      "TagSpecifications": [
        {
          "ResourceType": "instance",
          "Tags": [
            {
              "Key": "foo",
              "Value": "bar"
            }
          ]
        }
      ]
    }

    snake_dict = {
      "tag_specifications": [
        {
          "resource_type": "instance",
          "tags": [
            {
              "key": "foo",
              "value": "bar"
            }
          ]
        }
      ]
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-11 01:03:41.153201
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'EndpointURL': 'https://example.com',
                                   'Protocol': 'HTTPS'},
                  'HTTPProxy': {'Endpoint': 'HTTPEndpoint', 'Path': '/',
                                'TimeoutMillis': 5000},
                  'HTTPSettings': {'IdleTimeoutMillis': 60000, 'ProxyEndpoint': 'HTTPProxy'}}

    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['http_endpoint']['endpoint_url'] == 'https://example.com'
    assert snake_dict['http_proxy']['endpoint'] == 'http_endpoint'
    assert snake_dict['http_settings']['proxy_endpoint'] == 'http_proxy'

    # Test that it works with

# Generated at 2022-06-11 01:03:48.189222
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {
        'one': {
            'two': 2,
        },
        'HTTPEndpoint': True,
        'targetGroupARNs': ['arn1', 'arn2'],
    }
    snake = camel_dict_to_snake_dict(camel)
    assert snake['h_t_t_p_endpoint']
    assert snake['one']['two'] == 2
    assert snake['target_group_ar_ns'] == ['arn1', 'arn2']
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel)) == camel
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel, reversible=True)) != camel



# Generated at 2022-06-11 01:03:58.832659
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test simple value
    assert camel_dict_to_snake_dict(
        {
            "SimpleValue": "This is a simple value"
        }
    ) == {
        "simple_value": "This is a simple value"
    }

    # Test value in a dict
    assert camel_dict_to_snake_dict(
        {
            "TopLevel": {
                "SecondLevel": "A value two levels deep"
            }
        }
    ) == {
        "top_level": {
            "second_level": "A value two levels deep"
        }
    }

    # Test a list of simple values

# Generated at 2022-06-11 01:04:08.544067
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'A': {'B': {'C': {'D': 'F'}}}}) == {'a': {'b': {'c': {'d': 'F'}}}}
    assert camel_dict_to_snake_dict({'A': {'B': {'C': {'D': 'F'}}}}) == {'a': {'b': {'c': {'d': 'F'}}}}
    # Ensure that we don't overwrite the original dict
    a = {'A': {'B': {'C': {'D': 'F'}}}}
    camel_dict_to_snake_dict(a)
    assert a == {'A': {'B': {'C': {'D': 'F'}}}}
    assert camel_dict_to

# Generated at 2022-06-11 01:04:19.488521
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'keyOne': 1, 'keyTwo': 2}) == {'key_one': 1, 'key_two': 2}
    assert camel_dict_to_snake_dict({'keyOne': 1, 'keyTwo': 2}, reversible=True) == {'key_o_n_e': 1, 'key_t_w_o': 2}
    assert camel_dict_to_snake_dict({'keyOne': 1, 'keyTwo': 2, 'KeyThree': 3}) == {'key_one': 1, 'key_two': 2, 'key_three': 3}

# Generated at 2022-06-11 01:04:30.106257
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Base case
    camel_dict = {
        "HTTPMethod": "GET",
        "HTTPEndpoint": {
            "Protocol": "HTTPS"
        }
    }
    expected_result = {
        "http_method": "GET",
        "http_endpoint": {
            "protocol": "HTTPS"
        }
    }
    assert camel_dict_to_snake_dict(camel_dict) == expected_result

    # Empty list

# Generated at 2022-06-11 01:04:37.529560
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'VpcId': 'vpc-12345678',
        'Tags': [
            {
                'Key': 'Name',
                'Value': 'awesome_test_1'
            },
            {
                'Key': 'Stack',
                'Value': 'test'
            }
        ],
        'SemiCamelCase': 'test',
        'camelCase': 'test',
        'TargetGroups': [
            {
                'TargetGroupARNs': [
                    'arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/73e2d6bc24d8a067'
                ]
            }
        ],
        'HTTPEndpoint': 'test'
    }


# Generated at 2022-06-11 01:04:48.024272
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:00.733608
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoints': [{
            'HTTPPath': 'PATH',
            'HTTPMethod': 'GET',
        }],
        'Id': 'ID',
        'Tags': {
            'k1':'v1',
            'k2':'v2'
        }
    }

    snake_dict = {
        'h_t_t_p_endpoints': [{
            'http_path': 'PATH',
            'http_method': 'GET',
        }],
        'id': 'ID',
        'tags': {
            'k1':'v1',
            'k2':'v2'
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert camel_dict_to_

# Generated at 2022-06-11 01:05:07.765887
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = dict(CreateDate='Fri, 29 Jun 2018 10:01:38 GMT',
                 HTTPEndpoint='https://api.push.amazonaws.com',
                 Platform='ADM',
                 Attributes=dict(Enabled='true',
                                 DefaultAuthenticationMethod='OAuth2'))
    dict2 = dict(create_date='Fri, 29 Jun 2018 10:01:38 GMT',
                 h_t_t_p_endpoint='https://api.push.amazonaws.com',
                 platform='ADM',
                 attributes=dict(enabled='true',
                                 default_authentication_method='OAuth2'))
    assert camel_dict_to_snake_dict(dict1, True) == dict2


# Generated at 2022-06-11 01:05:18.101215
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "arn": "arn:123:456:789:user/test",
        "Tags": [
            {
                "Key": "Name",
                "Value": "test-iam-user"
            },
            {
                "Key": "Ansible",
                "Value": "True"
            }
        ]
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {
        'arn': 'arn:123:456:789:user/test',
        'tags': [
            {
                'key': 'Name',
                'value': 'test-iam-user'
            },
            {
                'key': 'Ansible',
                'value': 'True'
            }
        ]
    }


# Generated at 2022-06-11 01:05:29.000362
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_init_dict = {'ApiId': '9876', 'RouteKey': '$default', 'StageName': 'dev'}
    snake_init_dict = {'api_id': '9876', 'route_key': '$default', 'stage_name': 'dev'}
    assert camel_dict_to_snake_dict(camel_init_dict) == snake_init_dict
    reversible_camel_init_dict = {'ApiId': '9876', 'routeH_t_t_p_method': 'GET', 'StageName': 'dev'}
    reversible_snake_init_dict = {'api_id': '9876', 'route_h_t_t_p_method': 'GET', 'stage_name': 'dev'}
    assert camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:35.832145
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:47.908454
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:56.036793
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test can convert a combination of camelcase and snakecase dictionaries.

    It can convert both a single camelcase key and a key within a nested
    dictionary.

    It can also perform a reversible conversion.
    """
    test_dict = {
        'TagSpecifications': [
            {
                'ResourceType': 'instance',
                'Tags': [
                    {
                        'Key': 'key',
                        'Value': 'value'
                    }
                ]
            }
        ],
        'Tags': [
            {
                'Key': 'foo',
                'Value': 'bar'
            },
            {
                'Key': 'baz',
                'Value': 'qux'
            }
        ]
    }


# Generated at 2022-06-11 01:06:04.708818
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:12.757807
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HelloWorld': 'A test string',
                 'HTTPEndpoint': {
                     'URL': 'http://www.ansible.com',
                     'Description': 'Ansible Homepage'
                 },
                 'Tags': {'tag': 'value'},
                 'MatchEquals': 'value',
                 'MultipleWords': 'value',
                 'UpperCamelCase': 'value',
                 'acronym_ARNs': 'value',
                 'plural_abbreviation_ARNs': 'value'}


# Generated at 2022-06-11 01:06:19.839854
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {}
    camel_dict["booleanTrue"] = True
    camel_dict["booleanFalse"] = False
    camel_dict["integerNumber"] = 123
    camel_dict["floatNumber"] = 123.456
    camel_dict["stringType"] = "string"
    camel_dict["listType"] = ["string1", "string2", "string3"]
    camel_dict["dictType"] = {"string1": "value1",
                              "string2": "value2",
                              "string3": "value3"}
    camel_dict["dictType2"] = {"string11": "value11",
                               "string22": "value22",
                               "string33": "value33"}

# Generated at 2022-06-11 01:06:35.145949
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HttpEndpoint': 'http://endpoint',
            'EndpointType': 'HTTP'
        },
        'TargetGroupARNs': [
            'arn:aws:elasticloadbalancing:us-west-2:730741750622:targetgroup/my-targets/73e2d6bc24d8a067',
            'arn:aws:elasticloadbalancing:us-west-2:730741750622:targetgroup/my-targets/73e2d6bc24d8a067'
        ],
        'Tags': [
            {u'Name': u'Name', u'Value': u'Hello'},
            {u'Name': u'Name', u'Value': u'World'}
        ]
    }


# Generated at 2022-06-11 01:06:41.888895
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict = {
        "string": "test1",
        "test": "test2",
        "SomeDictionary": {
            "key1": "value1",
            "key2": "value2"
        },
        "tags": {
            "Key": "Value",
        }
    }
    new_dict = camel_dict_to_snake_dict(dict)
    assert(new_dict.keys() == {'string', 'test', 'tags', 'some_dictionary'})
    assert(new_dict['tags'] == {'Key': 'Value'})


# Generated at 2022-06-11 01:06:48.830571
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'CamelCase': 'test'}) == {'camel_case': 'test'}
    assert camel_dict_to_snake_dict({'CheckStrategy': 'test', 'CheckIntervalSeconds': 0, 'UnhealthyThreshold': 0, 'HealthyThreshold': 0}) == {'check_strategy': 'test', 'check_interval_seconds': 0, 'unhealthy_threshold': 0, 'healthy_threshold': 0}

# Generated at 2022-06-11 01:06:59.170358
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import yaml

    test_content = yaml.safe_load('''
    Test:
      Reverse: Yes
      Ignore:
        Tags: {"Key":"Name","Value":"test_host"}
        RetentionPeriod: 12
        NotJson: AlsoNotJson
      TestCase:
        - Case: A case
          InCase: True
          Numbers:
            - 1
            - 2
            - 3
        - Case: Another case
          InCase: False
          Numbers:
            - 4
            - 5
            - 6
      MoreCamelCase: true
    ''')


# Generated at 2022-06-11 01:07:09.257199
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(
        camel_dict_to_snake_dict({'InstanceId': 'i-0123456', 'Platform': 'Windows', 'PendingTime': '2018-03-16T23:32:45'}) ==
        {'instance_id': 'i-0123456', 'platform': 'Windows', 'pending_time': '2018-03-16T23:32:45'})

    # Test the reverse conversion
    assert(camel_dict_to_snake_dict(camel_dict_to_snake_dict({'InstanceId': 'i-0123456'}), reversible=True) == {'InstanceId': 'i-0123456'})

    # Test conversion of a dict which is a value of a key

# Generated at 2022-06-11 01:07:18.818192
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test simple cases
    assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'

    # test conversion of dicts
    test_camel = {'HTTPEndpoint': 'http_endpoint', 'EC2': {'HTTPEndpoint': 'http_endpoint'}}
    expected_snake = {'http_endpoint': 'http_endpoint', 'ec2': {'http_endpoint': 'http_endpoint'}}
    assert camel_dict_to_snake_dict(test_camel) == expected_snake

    # test conversion of dicts with plurals

# Generated at 2022-06-11 01:07:27.063587
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:32.015768
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CamelKey': {'CamelValue': ['CamelKeyValue']}, 'OtherKey': 'OtherValue'}) == \
            {'camel_key': {'camel_value': ['CamelKeyValue']}, 'other_key': 'OtherValue'}



# Generated at 2022-06-11 01:07:42.097208
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # normal case
    camel_dict = {
        "httpEndpoint": {
            "default": {
                "path": "/metrics",
                "port": "8080",
                "protocol": "http",
                "hostname": "application-server"
            },
            "yaml": "{omitted}",
            "json": "{omitted}"
        },
        "tags": {
            "Name": "application-server"
        },
        "targetGroupArn": "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/cloudwatch-metrics/1234567890abcd",
        "httpPutResponseBody": False
    }


# Generated at 2022-06-11 01:07:51.850589
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:08:07.324527
# Unit test for function camel_dict_to_snake_dict