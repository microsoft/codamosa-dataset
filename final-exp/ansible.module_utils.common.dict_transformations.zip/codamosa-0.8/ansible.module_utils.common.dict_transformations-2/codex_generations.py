

# Generated at 2022-06-11 00:58:36.289853
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge(dict(a=1), dict(b=2)) == dict(a=1, b=2)
    assert dict_merge(dict(a=1, b=dict(c=2)), dict(b=dict(d=3), e=4)) == dict(a=1, b=dict(c=2, d=3), e=4)
    assert dict_merge(dict(a=1, b=dict(c=2, d=3)), dict(b=dict(c=4))) == dict(a=1, b=dict(c=4, d=3))

# Generated at 2022-06-11 00:58:46.245987
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({'foo': {'bar': 'baz', 'boo': 'bah'}}, {'foo': {'bam': 'buz'}}) == {'foo': {'bar': 'baz', 'boo': 'bah', 'bam': 'buz'}}, "expected {'foo': {'bar': 'baz', 'boo': 'bah', 'bam': 'buz'}}"

# Generated at 2022-06-11 00:58:58.171972
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {"Url": "http://example.com"},
        "Value": 1,
        "ProcessorFeatures": [
            {"Name": "string",
             "Selector": [
                 {"Name": "string",
                     "Value": "string"}]},
            {"Name": "string",
             "Selector": [
                 {"Name": "string",
                     "Value": "string"}]}]
        }

# Generated at 2022-06-11 00:59:06.007421
# Unit test for function recursive_diff

# Generated at 2022-06-11 00:59:16.748310
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Needed': 1}) == {'needed': 1}
    assert camel_dict_to_snake_dict({'Needed': {'Deeply': 1}}) == {'needed': {'deeply': 1}}
    assert camel_dict_to_snake_dict({'Needed': [1, 2, 3, {'Deeply': 1}]}) == {'needed': [1, 2, 3, {'deeply': 1}]}
    assert camel_dict_to_snake_dict({'Needed': [1, 2, 3, {'Tags': 1}]}) == {'needed': [1, 2, 3, {'Tags': 1}]}



# Generated at 2022-06-11 00:59:25.548535
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 'b'}, {'a': 'b'}) is None
    assert recursive_diff({'a': 'b'}, {'a': 'c'}) == ({'a': 'b'}, {'a': 'c'})
    assert recursive_diff({'a': 'b', 'a1': 'd'}, {'a': 'b', 'a2': 'd'}) == ({'a1': 'd'}, {'a2': 'd'})
    assert recursive_diff({'a': 'b', 'd': {'e': 'f'}}, {'a': 'b'}) == ({'d': {'e': 'f'}}, {})

# Generated at 2022-06-11 00:59:37.234019
# Unit test for function dict_merge
def test_dict_merge():
    assert dict_merge({}, {}) == {}
    assert dict_merge({}, {1: 2}) == {1: 2}
    assert dict_merge({1: 2}, {}) == {1: 2}
    assert dict_merge({1: 2}, {1: 3}) == {1: 3}
    assert dict_merge({1: 2}, {2: 3}) == {1: 2, 2: 3}
    assert dict_merge({"a": {}}, {"a": {"b": 1}}) == {"a": {"b": 1}}
    assert dict_merge({"a": {}}, {"a": {"b": 1}}) == {"a": {"b": 1}}
    assert dict_merge({"a": {"b": 1}}, {"a": {"b": 2}}) == {"a": {"b": 2}}

# Generated at 2022-06-11 00:59:47.092983
# Unit test for function recursive_diff
def test_recursive_diff():
    # no difference
    assert(recursive_diff({'key1': 'val1'}, {'key1': 'val1'}) is None)

    # difference in value
    expected = ({'key1': 'val1'}, {'key1': 'val2'})
    assert(recursive_diff({'key1': 'val1'}, {'key1': 'val2'}) == expected)

    # difference in list
    expected = ({'key1': ['val1']}, {'key1': ['val2']})
    assert(recursive_diff({'key1': ['val1']}, {'key1': ['val2']}) == expected)

    # difference in dict
    expected = ({'key1': {'key2': 'val1'}}, {'key1': {'key2': 'val2'}})

# Generated at 2022-06-11 00:59:59.112390
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    This test case should demonstrate how the recursive_diff function works.
    It should test edge cases as well as give an example. Testing the final
    return value is not that important.
    """
    # Our example dictionary
    dict1 = {
        'foo': 'bar',
        'nested': {
            'foo': 'bar',
            'nested_nested': {
                'foo': 'bar'
            }
        }
    }

    # Simple value change
    dict2 = deepcopy(dict1)
    dict2['foo'] = 'baz'

    # Nested value change
    dict3 = deepcopy(dict2)
    dict3['nested']['foo'] = 'baz'

    # Nested nested value change
    dict4 = deepcopy(dict3)

# Generated at 2022-06-11 01:00:08.810291
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    General test test_camel_dict_to_snake_dict.
    """


# Generated at 2022-06-11 01:00:23.252549
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {"fooBar": {"bazCar": {"baz": "baz", "bar": "bar", "foo": "foo"}}}

    assert camel_dict_to_snake_dict(camel_dict) == {'foo_bar': {'baz_car': {'baz': 'baz', 'bar': 'bar', 'foo': 'foo'}}}

    camel_dict = {"HTTPMethod": "GET"}
    assert camel_dict_to_snake_dict(camel_dict) == {'http_method': 'GET'}

    camel_dict = {"HTTPEndpoint": "GET"}
    assert camel_dict_to_snake_dict(camel_dict) == {'http_endpoint': 'GET'}



# Generated at 2022-06-11 01:00:33.617395
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:45.349973
# Unit test for function recursive_diff
def test_recursive_diff():

    list_diffs_1 = [1, 1]
    list_diffs_2 = [1, 2]

    dict_diffs_1 = {
                         'serial': 1,
                         'name': 'serial_1',
                         'vlan': 10,
                         'state': 'present',
                         'port': 1,
                         'speed': 'auto',
                         'duplex': 'auto',
                         'state': 'present',
                         'trunk_native_vlan': 1,
                         'trunk_allowed_vlans': 'all'
                         }


# Generated at 2022-06-11 01:00:56.453880
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        'key1': {
            'key2': 'value2a'
        },
        'key3': 'value3a',
        'key4': {
            'key5': 'value5a',
            'key6': 'value6a',
            'key7': 'value7a'
        },
        'key8': 'value8a'
    }

    dict2 = {
        'key1': {
            'key2': 'value2b'
        },
        'key3': 'value3b',
        'key4': {
            'key5': 'value5b',
            'key6': 'value6b',
            'key7': 'value7b'
        },
        'key8': 'value8b'
    }


# Generated at 2022-06-11 01:01:06.720872
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'HTTPPath': 'foo'
        },
        'TargetGroupARNs': [
            'bar', 'baz'
        ],
        'Targets': [
            {'Id': 'id_1', 'Port': '8000'},
            {'Id': 'id_2', 'Port': '9000'},
        ],
        'Tags': {
            'tag_key_1': 'value 1',
            'tag_key_2': 'value 2',
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)


# Generated at 2022-06-11 01:01:17.563259
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:25.161454
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Reversible allows two way conversion of a camelized dict
    such that snake_dict_to_camel_dict(camel_dict_to_snake_dict(x)) == x

    This is achieved through mapping e.g. HTTPEndpoint to h_t_t_p_endpoint
    where the default would be simply http_endpoint, which gets turned into
    HttpEndpoint if recamelized.
    """


# Generated at 2022-06-11 01:01:36.742778
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'foo': {
            'bar': 'baz'
        }
    }
    dict2 = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert(recursive_diff(dict1, dict2) is None)

    dict2 = {
        'fiz': {
            'bar': 'baz'
        }
    }
    assert(recursive_diff(dict1, dict2) == ({'foo': {'bar': 'baz'}}, {'fiz': {'bar': 'baz'}}))

    dict1 = {
        'foo': {
            'bar': 'baz'
        }
    }

# Generated at 2022-06-11 01:01:45.627184
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:56.238358
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test different types
    res = recursive_diff('foo', 'bar')
    assert 2 == len(res)
    assert 'foo' == res[0]
    assert 'bar' == res[1]

    # Test empty dict
    res = recursive_diff({}, {})
    assert None is res

    # Test different keys
    res = recursive_diff({'a': 1}, {'b': 1})
    assert {'a': 1}, {'b': 1} == res

    # Test same keys different values
    res = recursive_diff({'a': 1}, {'a': 2})
    assert {'a': 1}, {'a': 2} == res

    res = recursive_diff({'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'd': 3})
   

# Generated at 2022-06-11 01:02:05.345333
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    original_dict = {
        "helloWorld": {
            "foo": "bar",
            "boo": "tar",
        }
    }


    expected_dict = {
        "hello_world": {
            "foo": "bar",
            "boo": "tar",
        }
    }

    snake_dict = camel_dict_to_snake_dict(original_dict, reversible=False)
    assert snake_dict == expected_dict



# Generated at 2022-06-11 01:02:11.878831
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'Route53HostedZoneId': 'ABC123', 'LogBucket': 'test-bucket'}
    expected_result = {'route53_hosted_zone_id': 'ABC123', 'log_bucket': 'test-bucket'}
    assert camel_dict_to_snake_dict(camel_dict) == expected_result


# Generated at 2022-06-11 01:02:23.113308
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CamelCase': 1}) == {'camel_case': 1}
    assert camel_dict_to_snake_dict({'CamelCamelCase': 1}) == {'camel_camel_case': 1}
    assert camel_dict_to_snake_dict({'Camel2Camel2Case': 1}) == {'camel2_camel2_case': 1}
    assert camel_dict_to_snake_dict({'getCamel2Camel2Case': 1}) == {'get_camel2_camel2_case': 1}

# Generated at 2022-06-11 01:02:31.316162
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(HTTPEndpoint='value',
                      Description='value',
                      List=list(),
                      SomeDict=dict(),
                      CamelCase='value',
                      )

    expected_dict = dict(h_t_t_p_endpoint='value',
                         description='value',
                         list=list(),
                         some_dict=dict(),
                         camel_case='value',
                         )

    camel_dict['List'].append(camel_dict.copy())
    camel_dict['List'].append(camel_dict.copy())
    camel_dict['SomeDict'] = camel_dict.copy()

    expected_dict['list'].append(expected_dict.copy())
    expected_dict['list'].append(expected_dict.copy())
    expected_dict['some_dict'] = expected_dict.copy()

# Generated at 2022-06-11 01:02:40.830242
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict1 = dict(
        Foo="bar",
        HTTPEndpoint="baz",
        HTTPEndpoints="faz",
        HttpEndpoint="faz",
        IPAddress="1.2.3.4",
        IPAddresses="1.2.3.4",
        IpAddress="1.2.3.4",
        IpAddresses="1.2.3.4",
        AutoScalingGroupARNs=["123", "456"],
        Tags={"foo": "bar"},
        TagSpecificList=[{"foo": "bar"}, {"foo": "baz"}]
    )


# Generated at 2022-06-11 01:02:45.314804
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'java': 'Elasticsearch'}
    expected_result = {'java': 'Elasticsearch'}

    assert camel_dict_to_snake_dict(test_dict) == expected_result



# Generated at 2022-06-11 01:02:56.863117
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'fooBar': 42}) == {'foo_bar': 42}
    assert camel_dict_to_snake_dict({'fooBar': {'baz': 42}}) == {'foo_bar': {'baz': 42}}
    assert camel_dict_to_snake_dict({'fooBar': [42, {'baz': 'qux'}]}) == {'foo_bar': [42, {'baz': 'qux'}]}
    assert camel_dict_to_snake_dict({'fooBar': [42, {'someBaz': 'qux'}]}) == {'foo_bar': [42, {'some_baz': 'qux'}]}

# Generated at 2022-06-11 01:03:07.162663
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # basic test for camel to snake
    test_dict = {
        'fooBar': {
            'bazFoo': 1
        },
        'fooBarBaz': {
            'bazFoo': 2
        },
        'foo': 3,
        'baz': 4,
        'qux': 5,
        'quux': 6
    }
    expected_dict = {
        'foo_bar': {
            'baz_foo': 1
        },
        'foo_bar_baz': {
            'baz_foo': 2
        },
        'foo': 3,
        'baz': 4,
        'qux': 5,
        'quux': 6
    }
    assert camel_dict_to_snake_dict(test_dict) == expected_dict

    # test for reversible

# Generated at 2022-06-11 01:03:18.911438
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = {
        'String1': 'One',
        'String2': 'Two',
        'String3': {
            'String31': 'ThreeOne',
            'String32': 'ThreeTwo',
            'String33': {
                'String331': 'ThreeThreeOne',
                'String332': 'ThreeThreeTwo',
            },
        },
        'String4': 'Four',
    }

    snake_dict_1 = camel_dict_to_snake_dict(camel_dict_1, False, [])

# Generated at 2022-06-11 01:03:29.201948
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    from ansible.module_utils.ec2 import AWSRetry, get_aws_connection_info, boto3_conn
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict, AWSRetry
    from ansible.module_utils.ec2 import ec2_argument_spec, boto3_tag_list_to_ansible_dict

    module = AnsibleModule(
        argument_spec=dict(
            dict_to_convert=dict(required=True, type='dict'),
        )
    )

    dict_to_convert = module.params['dict_to_convert']
    result = camel_dict_to_snake_dict(dict_to_convert)
    module.exit_json(result=result)



# Generated at 2022-06-11 01:03:40.120769
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {'foo': {'bar': 23, 'Baz': 42}, 'quux': [{'Bog': 1, 'Zoo': 2}, {'Bog': 3, 'Zoo': 4}], 'Zip': 'zap'}
    exp_d = {'foo': {'bar': 23, 'baz': 42}, 'quux': [{'bog': 1, 'zoo': 2}, {'bog': 3, 'zoo': 4}], 'zip': 'zap'}
    assert camel_dict_to_snake_dict(d) == exp_d
    assert snake_dict_to_camel_dict(exp_d) == d



# Generated at 2022-06-11 01:03:49.097558
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test cases for camel_dict_to_snake_dict
    """
    camel_dict = {'keyName': 'value', 'SecondKey': {'anotherKey': 'anotherValue'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['key_name'] == 'value'
    assert snake_dict['second_key']['another_key'] == 'anotherValue'

    camel_dict = {'key1': 'value1', 'key2': 'value2', 'key3': [{'key4': 'value4'}, {'anotherKey': 'anotherValue'}]}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['key1'] == 'value1'
    assert snake_dict

# Generated at 2022-06-11 01:04:00.224600
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'URL': 'https://<host>:<port>/v1/endpoint'}, 'Name': 'my_endpoint_name'}
    expected_snake_dict = {'h_t_t_p_endpoint': {'url': 'https://<host>:<port>/v1/endpoint'}, 'name': 'my_endpoint_name'}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected_snake_dict

    camel_dict = {'HTTPEndpoint': {'URL': 'https://<host>:<port>/v1/endpoint'}, 'Name': 'my_endpoint_name'}

# Generated at 2022-06-11 01:04:06.041818
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.ec2 import HAS_BOTO3
    if HAS_BOTO3:
        import boto3
        import boto3.session
        session = boto3.session.Session()
        client = session.client('ec2')
        camel_dict = client.describe_instances()
        snake_dict = camel_dict_to_snake_dict(camel_dict)
        assert snake_dict is not None

# Generated at 2022-06-11 01:04:17.516428
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Host': 'host',
                                   'HTTPS': True,
                                   'Port': 443,
                                   'Tags': {'Test': 'of-camel-case-dict'},
                                   'URLPath': '/path',
                                   'With': 'NotInSnake'},
                  'HTTPSendpoint': {'Host': 'host',
                                    'HTTPS': True,
                                    'Port': 443,
                                    'Tags': {'Test': 'of-camel-case-dict'},
                                    'URLPath': '/path',
                                    'With': 'NotInSnake'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    # Check conversion of field names
    assert snake_dict['http_endpoint']['host']

# Generated at 2022-06-11 01:04:28.366622
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'k1': 'v1',
                                     'k2': 'v2',
                                     'k3': {'k31': 'v31',
                                            'k32': 'v32'},
                                     'k4': {'k4_1': 'v4_1'}}, False, ()) == \
           {'k1': 'v1',
            'k2': 'v2',
            'k3': {'k31': 'v31', 'k32': 'v32'},
            'k4': {'k4_1': 'v4_1'}}


# Generated at 2022-06-11 01:04:36.533158
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test the camel_dict_to_snake_dict function.

    Return value is a dictionary with all keys converted to snake_case, recursively.
    """

# Generated at 2022-06-11 01:04:47.587030
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel = {
        'HTTPEndpoint': {
            'HTTPVersion': 'HTTP/1.1'
        },
        'Name': 'camel-to-snake-dict',
        'Region': 'us-east-1',
        'Tags': {
            'Foo': 'foo',
            'FooBar': 'foobar'
        },
        'hostEndpoint': 'hostEndpoint'
    }

    # Expected result without reversible=True

# Generated at 2022-06-11 01:04:57.032448
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""

    camel_dict = {
        'CreationTimestamp': '2018-07-06T13:17:52.000000000Z',
        'IsDefault': False,
        'Name': 'default',
        'SupportsCodeDeploy': True,
        'SupportedPlatformVersions': [
            '1.0',
            '1.1'
        ]
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['creation_timestamp'] == '2018-07-06T13:17:52.000000000Z'
    assert snake_dict['is_default'] == False
    assert snake_dict['supports_code_deploy'] == True


# Generated at 2022-06-11 01:05:06.744590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    snake_dict = {
        "key_one": "value_one",
        "key_two": "value_two",
        "key_three": {
            "key_four": "value_four",
            "key_five": "value_five"
        },
        "key_six": [{
            "key_seven": {
                "key_eight": "value_eight"
            }
        }]
    }


# Generated at 2022-06-11 01:05:18.315557
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Success
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Host': 'host', 'Port': '8080'}}) == \
        {'h_t_t_p_endpoint': {'host': 'host', 'port': '8080'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Host': 'host', 'Port': '8080'}}, reversible=True) == \
        {'h_t_t_p_e_n_d_p_o_i_n_t': {'host': 'host', 'port': '8080'}}

# Generated at 2022-06-11 01:05:29.156355
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': 'Hello'}) == {'foo': 'Hello'}
    assert camel_dict_to_snake_dict({'Foo': 'Hello', 'Bar': {'FooBar': ['Hello', 'World']}}) == {'foo': 'Hello', 'bar': {'foo_bar': ['Hello', 'World']}}
    assert camel_dict_to_snake_dict({'fooS': 'Hello'}) == {'foo_s': 'Hello'}
    assert camel_dict_to_snake_dict({'fooSS': 'Hello'}) == {'foo_ss': 'Hello'}

# Generated at 2022-06-11 01:05:35.978711
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test a variety of ways of CamelCase and dromedaryCase
    # and their conversion to snake_case
    # In all camelcase the first letter is capitalised.
    # In dromedarycase the first letter is not capitalised.
    # In snake_case, words are separated by underscores.
    #
    # Incidentally, the reason for the odd name 'dromedary' for
    # this style of case is that camel is the animal and
    # dromedary is merely a camel with one hump and is therefore
    # not a true camel.

    camel_dict = {'IPReservation': True, 'DnsServers': [], 'NtpServers': []}

# Generated at 2022-06-11 01:05:48.060160
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_camel_dict = {
        'HTTPEndpoint': {
            'Id': 'test_id',
            'HTTPSettings': {
                'Id': 'test_id',
                'Port': 1234,
                'Protocol': 'HTTP',
                'CertificateSource': 'test_certificate_source',
                'HTTPSMethod': 'test_method'
            },
            'EndpointConfiguration': {
                'Id': 'test_id',
                'Protocol': 'HTTP'
            },
            'HealthCheck': None,
            'WebsocketSettings': {
                'Id': 'test_id',
                'ConnectionIdleTimeout': 2345
            }
        }
    }


# Generated at 2022-06-11 01:05:56.115773
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test each element of the tuple as a dict
    count = 0

# Generated at 2022-06-11 01:06:04.732872
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "KeyName": "not_a_real_keypair",
        "InstanceType": "t3.micro",
        "SubnetId": "not_a_real_subnet",
        "ImageId": "not_a_real_ami",
        "SecurityGroupIds": ["not_a_real_security_group"],
        "Tags": [
            {"Key": "aws:cloudformation:logical-id", "Value": "MyInstance"},
            {"Key": "aws:cloudformation:stack-id", "Value": "not_a_real_stack_id"},
            {"Key": "aws:cloudformation:stack-name", "Value": "not_a_real_stack_name"},
        ],
    }

# Generated at 2022-06-11 01:06:08.991465
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected_dict = {"foo": "bar", "baz": {"qux": "quux"}}
    camel_dict = {"Foo": "bar", "Baz": {"Qux": "quux"}}
    assert camel_dict_to_snake_dict(camel_dict) == expected_dict



# Generated at 2022-06-11 01:06:18.211325
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Name': 'http-endpoint',
            'Vip': '10.0.1.1',
            'Port': 80,
            'Tags': [{'Key': 'Name', 'Value': 'my-http-endpoint'}]
        }
    }

    expected = {
        'http_endpoint': {
            'name': 'http-endpoint',
            'vip': '10.0.1.1',
            'port': 80,
            'tags': [{'Key': 'Name', 'Value': 'my-http-endpoint'}]
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == expected


# Generated at 2022-06-11 01:06:28.010105
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 1, 'HTTPSEndpoint': 2}) == {'http_endpoint': 1, 'https_endpoint': 2}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 1, 'HTTPSEndpoint': 2}, reversible=True) == {'h_t_t_p_endpoint': 1, 'h_t_t_p_s_endpoint': 2}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 1, 'HTTPSEndpoint': 2}, reversible=True, ignore_list=['HTTPSEndpoint']) == {'h_t_t_p_endpoint': 1, 'https_endpoint': 2}

# Generated at 2022-06-11 01:06:36.514498
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'Acme': [{'MotorSpeedRPM': 50},
                           {'MotorSpeedRPM': 60},
                           {'MotorSpeedRPM': 70},
                           {'MotorSpeedRPM': 80}],
                  'MotorSpeedRPM': 80,
                  'InputVoltage': 12,
                  'Name': 'Acme Motor',
                  'HTTPEndpoint': {'EndpointURL': 'http://test.com'},
                  'Tags': [{'Key': 'Test'}]}


# Generated at 2022-06-11 01:06:43.774581
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit testing for camel_dict_to_snake_dict()."""
    camel_dict = {'FooBar': {'FakeAWS': 'fake_aws', 'HTTPEndpoint': 'http_endpoint', 'Baz': [{'Foo': 'bar'}, 'foo']}}
    snake_dict = {'foo_bar': {'fake_a_w_s': 'fake_aws', 'h_t_t_p_endpoint': 'http_endpoint', 'baz': [{'foo': 'bar'}, 'foo']}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-11 01:06:50.089828
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Unit test for function camel_dict_to_snake_dict
    test_dict = {
                'fooBar': {
                    'bazFoo': 'test_string',
                    'h_t_t_p_endpoint': 'foo',
                    'properties': [{
                        'BucketName': 'test',
                        'privateSubnets': [
                            'subnet-123'
                        ]}
                    ],
                    'tags': {
                        'BucketName': 'test'
                    }
                }
            }

# Generated at 2022-06-11 01:07:00.471633
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:07.268964
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict_snake = {'attribute_values': [{'attribute_value': 'value1'}, {'attribute_value': 'value2'}],
                  'key': 'name'}

    dict_camel = {'AttributeValues': [{'AttributeValue': 'value1'}, {'AttributeValue': 'value2'}],
                  'Key': 'name'}

    result = camel_dict_to_snake_dict(dict_camel)

    assert result == dict_snake



# Generated at 2022-06-11 01:07:14.748637
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    complex_dict = {'firstKey': 1,
                    'secondKey': {'subKey1': 2,
                                  'subKey2': [{'subsubKey': 3}]},
                    'HTTPEndpoint': 'http://example.com'}
    expected_dict = {'first_key': 1,
                     'second_key': {'sub_key1': 2,
                                    'sub_key2': [{'subsub_key': 3}]},
                     'h_t_t_p_endpoint': 'http://example.com'}
    assert camel_dict_to_snake_dict(complex_dict, reversible=True) == expected_dict
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict(complex_dict, reversible=True)) == complex_dict



# Generated at 2022-06-11 01:07:23.117534
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': None,
                  'Tags': [{'Key': 'ThisIsACamelCaseKey', 'Value': 'ThisIsACamelCaseValue'},
                           {'Key': 'ThisIsAnotherCamelCaseKey', 'Value': 'ThisIsAnotherCamelCaseValue'},
                           {'Key': 'ThisIsNotACamelCaseKey', 'Value': 'ThisIsNotACamelCaseValue'}
                           ]
                  }

# Generated at 2022-06-11 01:07:31.617944
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HelloWorld': True, 'Test1': {'firstKey': 'first_value', 'secondKey': False}, 'Test2': [{'firstKey': 'first_value', 'secondKey': False}]}
    snake_dict = {'hello_world': True, 'test1': {'first_key': 'first_value', 'second_key': False}, 'test2': [{'first_key': 'first_value', 'second_key': False}]}

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict
    assert snake_dict_to_camel_dict(snake_dict) == camel_dict

# Generated at 2022-06-11 01:07:41.802759
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:51.576636
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:58.158959
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test = {'fooBar': 'value', 'Blerg': 'blarg', 'fooBarBaz': 2,
            'array': [{'fooBar': 'value', 'Blerg': 'blarg', 'fooBarBaz': 2}]}
    test_result = {'foo_bar': 'value', 'blerg': 'blarg', 'foo_bar_baz': 2,
                   'array': [{'foo_bar': 'value', 'blerg': 'blarg', 'foo_bar_baz': 2}]}
    assert test_result == camel_dict_to_snake_dict(test)

