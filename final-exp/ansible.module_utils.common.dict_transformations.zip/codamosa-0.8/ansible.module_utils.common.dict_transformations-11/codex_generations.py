

# Generated at 2022-06-11 00:58:29.739219
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:58:39.463218
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'someKey': 'someValue'}) == {'some_key': 'someValue'}
    assert camel_dict_to_snake_dict({'someKey': 'someValue'},
                                    reversible=True) == {'some_key': 'someValue'}
    assert camel_dict_to_snake_dict({'someKey': 'someValue'},
                                    reversible=False) == {'some_key': 'someValue'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'someValue'},
                                    reversible=True) == {'h_t_t_p_endpoint': 'someValue'}

# Generated at 2022-06-11 00:58:50.346706
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:01.553068
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = {
        'level1': {
            'level2': {
                'level3_leaf': 1,
                'level3_other_leaf': 2,
            },
            'level2_other_leaf': 3,
        },
        'level1_other_leaf': 4,
    }

    dict2 = {
        'level1': {
            'level2': {
                'level3_leaf': 5,
            },
            'level2_other_leaf': 6,
        },
        'level1_other_leaf': 7,
    }

    merged_dict = dict_merge(dict1, dict2)


# Generated at 2022-06-11 00:59:12.093754
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test camel_dict_to_snake_dict
    """
    camel_dict = {'FooBar': 1, 'HTTPMethod': 'GET', 'HTTPEndpoint': '/foo/bar', 'Arn': 'arn:example:foo/bar'}
    reversed_dict = {'foo_bar': 1, 'http_endpoint': '/foo/bar', 'h_t_t_p_method': 'GET', 'arn': 'arn:example:foo/bar'}
    assert camel_dict_to_snake_dict(camel_dict) == reversed_dict
    assert camel_dict_to_snake_dict(reversed_dict, reversible=True) == reversed_dict

    camel_dict = {'HTTPEndpoint': '/foo/bar', 'HTTPEndpointKey': 'httpEndpoint'}


# Generated at 2022-06-11 00:59:21.712300
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    import pytest

    # Test case 1 - empty dictionaries
    result = recursive_diff({},{})
    assert result is None

    # Test case 2 - one empty dictionary and another with a value
    result = recursive_diff({},{'A': 'a'})
    assert result == ({}, {'A': 'a'})

    # Test case 3 -  one dictionary with a value and another empty
    result = recursive_diff({'A': 'a'},{})
    assert result == ({'A': 'a'}, {})

    # Test case 4 - two identical dictionaries
    result = recursive_diff({'A': 'a'},{'A': 'a'})
    assert result is None

    # Test case 5 - two identical dictionaries, one nested

# Generated at 2022-06-11 00:59:33.170042
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Url': 'test'}, 'test': ['list']}) == {'h_t_t_p_endpoint': {'url': 'test'}, 'test': ['list']}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Url': 'test'}, 'test': ['list']}, reversible=True) == {'h_t_t_p_endpoint': {'url': 'test'}, 'test': ['list']}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Url': 'test'}, 'test': ['list']}, reversible=False) == {'http_endpoint': {'url': 'test'}, 'test': ['list']}
    assert camel_dict_to_

# Generated at 2022-06-11 00:59:43.962560
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Test items with different class types
    dict1 = {'a': 'a', 'b': {'b': 'a', 'c': 'b', 'd': 'c'}, 'c': 'c'}
    dict2 = {'a': 'a', 'b': {'b': 'a', 'c': 'a', 'd': 'c'}, 'c': 1}
    expected = ({'c': 'c'}, {'c': 1})
    assert recursive_diff(dict1, dict2) == expected

    # Test no differences
    dict2 = {'a': 'a', 'b': {'b': 'a', 'c': 'a', 'd': 'c'}, 'c': 'c'}
    assert recursive_diff(dict1, dict2) is None

   

# Generated at 2022-06-11 00:59:50.721536
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:02.560341
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    class CamelCaseClass(object):
        CamelCaseKey = 'value'
        CamelCaseList = [1, 2, 3]
        CamelCaseDict = {
            'CamelCaseKey': 'value',
            'CamelCaseList': [1, 2, 3],
            'CamelCaseDict': {
                'CamelCaseKey': 'value',
            },
        }

        class CamelCaseClassInClass(object):
            CamelCaseKey = 'value'

    def check_snake_marks(snake_dict, num_snake_marks):
        if isinstance(snake_dict, dict):
            for k, v in snake_dict.items():
                if '_' in k:
                    num_snake_marks += 1

# Generated at 2022-06-11 01:00:13.464736
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    expected_result = {
        'not_camel': 'value',
        'just_snake': {
            'sub_key': 'sub_value'
        },
        'camel': {
            'sub_key': {
                'sub_sub_key': 'sub_sub_value'
            }
        },
        'camel_list': [
            {
                'sub_key': 'sub_value'
            }
        ],
        'reversible_camel': 'value',
        'plural': {
            'sub_key': 'sub_value'
        }
    }


# Generated at 2022-06-11 01:00:25.389020
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 1:
    camel_dict = {"HTTPEndpoint": "http://localhost:80/post", "Streaming": False}
    snake_dict = {"h_t_t_p_endpoint": "http://localhost:80/post", "streaming": False}
    assert(camel_dict_to_snake_dict(camel_dict) == snake_dict)

    # Test case 2:
    camel_dict = {"HTTPEndpoint": "http://localhost:80/post", "Streaming": False, "Tags": {"TagKey": "TagValue"}}
    snake_dict = {"h_t_t_p_endpoint": "http://localhost:80/post", "streaming": False, "tags": {"TagKey": "TagValue"}}

# Generated at 2022-06-11 01:00:35.314561
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    This test is a bit more comprehensive than the test for
    snake_dict_to_camel_dict
    """

# Generated at 2022-06-11 01:00:43.600467
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d1 = {"HTTPEndpoint": {"AcceptFormat": "JSON", "Protocol": "HTTP"}}
    d2 = {"h_t_t_p_endpoint": {"accept_format": "JSON", "protocol": "HTTP"}}
    d3 = {"HTTPEndpoint": {"accept_format": "JSON", "protocol": "HTTP"}}
    assert camel_dict_to_snake_dict(d1) == d2
    assert camel_dict_to_snake_dict(d1, reversible=True) == d3

# Generated at 2022-06-11 01:00:55.132934
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'ThingName': 'thing-name'}) \
           == {'thing_name': 'thing-name'}
    assert camel_dict_to_snake_dict({'thingName': 'thing-name'}) \
           == {'thing_name': 'thing-name'}
    assert camel_dict_to_snake_dict({'thingName': 'thing-name'}, reversible=True) \
           == {'thing_name': 'thing-name'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'http://amazon.com'}) \
           == {'http_endpoint': 'http://amazon.com'}

# Generated at 2022-06-11 01:01:04.809143
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_test_dict = {
        'HTTPEndpoint': {
            'EndpointID': '12345',
            'HTTPURL': 'https://www.example.com'
        },
        'Tags': [
            {
                'Key': 'Env',
                'Value': 'Example'
            },
            {
                'Key': 'Name',
                'Value': 'Example'
            },
            {
                'Key': 'Environment',
                'Value': 'Example'
            }
        ]
    }

# Generated at 2022-06-11 01:01:15.649740
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:21.867731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test for dictionaries
    name = 'helloWorld'
    expected_result = 'hello_world'
    assert _camel_to_snake(name) == expected_result

    name = 'helloWorldAgain'
    expected_result = 'hello_world_again'
    assert _camel_to_snake(name) == expected_result

    name = 'helloWorld'
    expected_result = 'HelloWorld'
    assert _snake_to_camel(name, capitalize_first=True) == expected_result

    name = 'HelloWorld'
    expected_result = 'helloWorld'
    assert _snake_to_camel(name) == expected_result

    name = 'helloWorldAgain'
    expected_result = 'hello_world_again'
    assert _snake_to_camel(name) == expected

# Generated at 2022-06-11 01:01:33.484801
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'property1': 'value1',
        'propertyTwo': 'value2',
        'propThree': 3,
        'propFour': [
            {
                'propSubOne': 'value1',
                'propSubTwo': 'value2',
            },
            'propSubThree',
        ],
    }

    expected_dict = {
        'property1': 'value1',
        'property_two': 'value2',
        'prop_three': 3,
        'prop_four': [
            {
                'prop_sub_one': 'value1',
                'prop_sub_two': 'value2',
            },
            'propSubThree',
        ],
    }

    camel_dict_to_snake_dict(test_dict) == expected_dict



# Generated at 2022-06-11 01:01:43.283512
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:56.719593
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:05.295973
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'__MyHTTPEndPoint': 'www.example.com'}) == {'my_http_endpoint': 'www.example.com'}
    assert not camel_dict_to_snake_dict({'__HTTPEndPoint': 'www.example.com'},reversible=True) == {'__h_t_t_p_endpoint': 'www.example.com'}
    assert camel_dict_to_snake_dict({'__HTTPEndPoint': 'www.example.com'},reversible=True) == {'h_t_t_p_endpoint': 'www.example.com'}

# Generated at 2022-06-11 01:02:17.719078
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:27.296526
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:34.411110
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    class CamelDict(dict):
        def __getitem__(self, key):
            try:
                return super(CamelDict, self).__getitem__(key)
            except KeyError:
                snake_key = _camel_to_snake(key)
                try:
                    return super(CamelDict, self).__getitem__(snake_key)
                except KeyError:
                    raise KeyError("No such key '%s' or '%s'" % (key, snake_key))

    camel_dict = CamelDict(fooBar="baz", tags=dict(env="dev"))

    actual = camel_dict_to_snake_dict(camel_dict)
    expected = dict(foo_bar="baz", tags=dict(env="dev"))

# Generated at 2022-06-11 01:02:38.724104
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import sys


# Generated at 2022-06-11 01:02:49.866708
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        "keyName": "testKey",
        "value": {
            "key": "value"
        },
    }

    assert camel_dict_to_snake_dict(test_dict) == {
        'key_name': 'testKey',
        'value': {
            'key': 'value'
        }
    }

    test_dict = {
        "keyName": "testKey",
        "value": {
            "key": "value"
        },
        "tags": {
            "camelCaseKey": "value"
        }
    }


# Generated at 2022-06-11 01:03:01.093291
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "TestKey1": "TestValue1",
        "TestKey2": "TestValue2",
        "TestKey3": "TestValue3",
        "KeyWithHTTPInit": "ValueWithHTTPInit",
        "KeyThatIsInIgnoreList": "ValueThatShouldNotBeConverted",
        "HTTPEndpoint": "ValueWithHTTPInit",
        "HTTPEndpoint": "ValueWithHTTPInit",
        "Tags": {
            "TagKey1": "TagValue1",
            "TagKey2": "TagValue2",
            "TagKey3": "TagValue2",
        }
    }

    # Normal test

# Generated at 2022-06-11 01:03:10.088368
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'LoadBalancerArn': 'foo-arn',
            'Port': 8080,
            'TargetGroupArns': ['target_group_arn'],
            'Url': 'http://foo.com',
        },
        'HttpsEndpoint': {
            'LoadBalancerArn': 'foo-arn',
            'Port': 8080,
            'TargetGroupArns': ['target_group_arn'],
            'Url': 'http://foo.com',
        },
        'Disabled': False,
        'Type': 'EDGE',
    }


# Generated at 2022-06-11 01:03:22.271919
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:32.736337
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:43.841275
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:51.800030
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from collections import OrderedDict

    test = OrderedDict()
    test['Key1'] = 'StringValue1'
    test['Key2'] = {
        'Key21': 'StringValue21',
        'Key22': ['StringValue211', 'StringValue212', 'StringValue213']
    }

    expected = [OrderedDict(
        [('key1', 'StringValue1'),
         ('key2', [OrderedDict(
             [('key21', 'StringValue21'),
              ('key22', ['StringValue211', 'StringValue212', 'StringValue213'])])])])]

    result = [camel_dict_to_snake_dict(test)]

    assert result == expected


# Generated at 2022-06-11 01:04:03.540811
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'foo': 'bar',
        'baz': {
            'simple': 'this is simple',
            'list': [
                'a',
                'b',
                'c'
            ],
            'listOfDicts': [
                {
                    'abc': 'abc',
                    'xyz': 'xyz'
                }
            ],
            'camelCase': 'isConvertedToSnakeCase',
            'HTTPEndpoint': 'isConvertedToHttpEndpoint'
        },
        'camelCase': 'isConvertedToSnakeCase',
        'HTTPEndpoint': 'isConvertedToHttpEndpoint'
    }


# Generated at 2022-06-11 01:04:14.730183
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Id': 'xyz', 'Tags': {'Name': 'abc'}}}
    snake_dict = camel_dict_to_snake_dict(camel_dict, False)
    assert snake_dict == {'http_endpoint': {'id': 'xyz', 'tags': {'Name': 'abc'}}}

    # Reversible check
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake_dict), False) == snake_dict

    # List check
    camel_dict = {'HTTPEndpoints': [{'Id': 'xyz'}, {'Id': 'abc'}]}
    snake_dict = camel_dict_to_snake_dict(camel_dict, False)

# Generated at 2022-06-11 01:04:25.728999
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:34.983100
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test if the function can convert regular camelcase to snake case
    test_camel_dict_snake_dict = {"AWSTemplateFormatVersion": "2010-09-09", "Resources": {
        "ServiceEC2Instance1": {"Type": "AWS::EC2::Instance", "Properties": { "InstanceType": "t2.micro" }},
        "ServiceEC2Instance2": {"Type": "AWS::EC2::Instance", "Properties": { "InstanceType": "t2.micro" }}}}


# Generated at 2022-06-11 01:04:44.481348
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'HTTPEndpoint': {'EndpointName': 'string', 'EndpointUrl': 'string'},
                  'tags': {'key': 'value'}}

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert(snake_dict['h_t_t_p_endpoint']['endpoint_name'] == 'string')
    assert(snake_dict['h_t_t_p_endpoint']['endpoint_url'] == 'string')
    assert(snake_dict['tags']['key'] == 'value')



# Generated at 2022-06-11 01:04:54.480871
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'myCamelKey1': 'myCamelValue1',
                 'myCamelKey2': 'myCamelValue2',
                 'myTestCamelKey3': 'myTestCamelValue3',
                 'testCamelKey3': 'testCamelValue3',
                 'Camel': 'Camel'
                 }

    snake_dict = camel_dict_to_snake_dict(test_dict, reversible=True)

# Generated at 2022-06-11 01:05:01.958817
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:18.315306
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    dict1 = dict(
        foo='bar',
        baz='bam',
        Tags=[
            dict(
                Key='foo',
                Value=1
            ),
            dict(
                Key='bar',
                Value=2
            )
        ],
        httpEndpoint=dict(
            url='http://foo.com',
            port=1234,
            enabled=True
        )
    )


# Generated at 2022-06-11 01:05:29.197324
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Key1': 'Value1',
        'Key2': 'Value2',
        'Key3': 'Value3',
        'Key4': {
            'SubKey1': 'SubValue1',
            'SubKey2': 'SubValue2',
            'SubKey3': 'SubValue3',
            'SubKey4': 'SubValue4'
        }
    }
    correct_result = {
        'key1': 'Value1',
        'key2': 'Value2',
        'key3': 'Value3',
        'key4': {
            'sub_key1': 'SubValue1',
            'sub_key2': 'SubValue2',
            'sub_key3': 'SubValue3',
            'sub_key4': 'SubValue4'
        }
    }

# Generated at 2022-06-11 01:05:30.849996
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 'foobar'}) == {'foo_bar': 'foobar'}



# Generated at 2022-06-11 01:05:41.702941
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict1 = {
        'testKeyCamelCase': 'testValue'
    }
    test_dict2 = {
        'testKeyWithCamelCase': {'testKeyCamelCase': 'testValue'},
        'testKeyWithList': ['item']
    }
    test_dict3 = {
        'testKeyWithCamelCase': {'testKeyCamelCase': {'testKeyCamelCase': 'testValue'}},
        'testKeyWithList': ['item', {'testKeyCamelCase': 'testValue'}]
    }

# Generated at 2022-06-11 01:05:52.839486
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:02.630519
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {'name': 'alex', 'age': 20, 'user_name': 'alex@gmail.com',
            "child": {'c_name': 'alex', 'c_age': 20, 'c_user_name': 'alex@gmail.com'}} == \
        camel_dict_to_snake_dict(
            {"Name": 'alex', "Age": 20, "UserName": 'alex@gmail.com',
             "Child": {"CName": 'alex', "CAge": 20, "CUserName": 'alex@gmail.com', "CChild": None}})
    # CamelDictToSnakeDictTestCase.test_camel_dict_to_snake_dict()

# Generated at 2022-06-11 01:06:06.922035
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'foo': 'bar', 'camelCase': 'dict'}
    expected_dict = {'foo': 'bar', 'camel_case': 'dict'}
    assert camel_dict_to_snake_dict(test_dict) == expected_dict


# Generated at 2022-06-11 01:06:15.342892
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {'HTTPEndpoint': {'URL': 'https://example.com', 'InsecureSkipVerify': True},
         'HTTPSEndpoint': {'URL': 'https://example.com', 'InsecureSkipVerify': True}}
    s = {'h_t_t_p_endpoint': {'url': 'https://example.com', 'insecure_skip_verify': True},
         'h_t_t_p_s_endpoint': {'url': 'https://example.com', 'insecure_skip_verify': True}}
    assert s == camel_dict_to_snake_dict(d)
    assert d == snake_dict_to_camel_dict(s, capitalize_first=False)

# Generated at 2022-06-11 01:06:25.667502
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:34.846508
# Unit test for function camel_dict_to_snake_dict