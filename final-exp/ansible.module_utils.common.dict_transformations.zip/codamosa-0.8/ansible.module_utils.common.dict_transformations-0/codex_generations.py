

# Generated at 2022-06-11 00:58:36.558467
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'camelCase': 'test',
        'nested': {
            'camelCase': 'test',
            'nested': {
                'camelCase': 'test',
                'nested': {
                    'camelCase': 'test',
                    'nested': {
                        'camelCase': 'test',
                        'nested': {
                            'camelCase': 'test'
                        }
                    }
                }
            }
        }
    }


# Generated at 2022-06-11 00:58:41.536141
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Given
    my_dict = {"HTTPEndpoint": "http_endpoint", "VisualForce": "visual_force"}

    # When
    returned_dict = camel_dict_to_snake_dict(my_dict)

    # Then
    assert returned_dict["h_t_t_p_endpoint"] == "http_endpoint"
    assert returned_dict["visual_force"] == "visual_force"



# Generated at 2022-06-11 00:58:53.586765
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test with two empty dictionaries
    dict1 = {}
    dict2 = {}
    assert recursive_diff(dict1, dict2) is None

    # Test with empty dictionaries and simple keys
    dict1 = {'key': 'value'}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == ({'key': 'value'}, {})

    # Test with empty dictionaries and keys with dict values
    dict1 = {'key': {'value': 'value'}}
    dict2 = {}
    assert recursive_diff(dict1, dict2) == ({'key': {'value': 'value'}}, {})

    # Test with valid dictionaries with simple key values
    dict1 = {'key': 'value'}
    dict2 = {'key': 'value'}

# Generated at 2022-06-11 00:59:03.399057
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    state = 'present'
    filters = [{'Name': 'tag:Name', 'Values': ['ansible-managed-vpc']}]
    tags = dict((tag['Key'], tag['Value']) for tag in [
        {'Key': 'Name', 'Value': 'ansible-managed-vpc'},
        {'Key': 'ManagedBy', 'Value': 'ansible'}
    ])
    tags_to_add = deepcopy(tags)
    tags_to_add['Ansible'] = 'example'
    tags_to_remove = ['Name']
    tags_to_update = tags_to_add


# Generated at 2022-06-11 00:59:14.982388
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    key_list = [{'Name': 'test'}, {'PhoneNumber': '123-456-7890', 'BillingMode': 'provisioned'},
                {'KeyId': 'arn:aws:kms:us-east-1:012345678910:key/2f2f2f2f-2f2f-2f2f-2f2f-2f2f2f2f2f2f',
                 'Tags': [{'Key': 'TagKey1', 'Value': 'TagValue1'}]}]
    assert camel_dict_to_snake_dict(key_list[0]) == {'name': 'test'}

# Generated at 2022-06-11 00:59:20.434139
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test a flat dictionary
    camel_a = {'firstName': 'Joe', 'lastName': 'Smith'}
    camel_b = {'firstName': 'Jane', 'lastName': 'Doe'}

    snake_a = camel_dict_to_snake_dict(camel_a)
    snake_b = camel_dict_to_snake_dict(camel_b)

    # Ensure the first name is snakecased and the value is correct
    assert snake_a['first_name'] == 'Joe'
    # Ensure the last name is snakecased and the value is correct
    assert snake_a['last_name'] == 'Smith'

    # Ensure the first name is snakecased and the value is correct
    assert snake_b['first_name'] == 'Jane'
    # Ensure the last name is snakecased

# Generated at 2022-06-11 00:59:31.156948
# Unit test for function dict_merge
def test_dict_merge():

    d1 = {'sub1': {'sub2': 1, 'sub3': 2}}
    d2 = {'sub1': {'sub3': 3}}
    assert dict_merge(d1, d2) == {'sub1': {'sub2': 1, 'sub3': 3}}
    assert dict_merge(d2, d1) == {'sub1': {'sub3': 2, 'sub2': 1}}
    assert d1 == {'sub1': {'sub2': 1, 'sub3': 2}}
    assert d2 == {'sub1': {'sub3': 3}}

    d1 = {'sub1': {'sub2': 1, 'sub3': 2, 'sub4': {'sub5': 3, 'sub6': 4}}}

# Generated at 2022-06-11 00:59:42.300355
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'HTTPEndpoint': "A1", "HTTPSEndpoint": "B2"}) == {'http_endpoint': "A1", "https_endpoint": "B2"})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint': "A1", "HTTPSEndpoint": "B2"}, reversible=True) == {'h_t_t_p_endpoint': "A1", "h_t_t_p_s_endpoint": "B2"})

# Generated at 2022-06-11 00:59:47.892898
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(
        a=1,
        b=dict(b1=1, b2=2),
        c=3,
    )
    b = dict(
        a=2,
        b=dict(b1=2),
        d=4,
    )
    assert dict_merge(a, b) == dict(
        a=2,
        b=dict(b1=2, b2=2),
        c=3,
        d=4,
    )



# Generated at 2022-06-11 01:00:00.115018
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:08.050828
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(
        {"Route53ZoneId": "testId", "Tags": {"Name": "testName"}}
    ) == {
        "route53_zone_id": "testId",
        "tags": {"Name": "testName"}
    }



# Generated at 2022-06-11 01:00:14.578588
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    def assertEqual(a, b):
        if a!=b:
            raise Exception('%s != %s' % (a,b))

    # Test basic conversion from camelCase to snake_case
    test = {'FooBarBaz': 'foo_bar_baz', 'fooBarBaz': 'foo_bar_baz'}
    for (camel, expected) in test.items():
        assertEqual(camel_dict_to_snake_dict({camel: None})[expected], None)
        assertEqual(camel_dict_to_snake_dict({expected: None})[expected], None)

    # Test conversion with list of dictionaries
    test = {'FooBarBaz': 'foo_bar_baz', 'fooBarBaz': 'foo_bar_baz'}
   

# Generated at 2022-06-11 01:00:26.163802
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:35.903392
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    f = {
        'booleanTrue': True,
        'booleanFalse': False,
        'NoneType': None,
        'stringType': 'string',
        'integerType': 42,
        'dictType': {
            'dictKey1': 'dictValue1',
            'dictKey2': 'dictValue2',
        },
        'listType': [
            'listValue1',
            'listValue2',
        ]
    }
    f_snake = camel_dict_to_snake_dict(f)


# Generated at 2022-06-11 01:00:48.016614
# Unit test for function recursive_diff
def test_recursive_diff():
    test = dict()
    test['d1'] = dict()
    test['d1']['d1-1'] = dict()
    test['d1']['d1-1']['key1'] = 'value1'
    test['d1']['d1-1']['key2'] = 'value2'
    test['d1']['d1-2'] = dict()
    test['d1']['d1-2']['key3'] = 'value3'

    expected = dict()
    expected['d1'] = dict()
    expected['d1']['d1-1'] = dict()
    expected['d1']['d1-1']['key1'] = 'value1'
    # will return a dict of differences
    result = dict()

# Generated at 2022-06-11 01:00:58.060664
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'HTTP',
            'Port': 80
        },
        'HTTPSEndpoint': {
            'Protocol': 'HTTPS',
            'Port': 443
        },
        'Tags': {
            'Key': 'Value',
            'KeyWithoutValue': None
        },
        'BooleanValue': True,
        'List': ['one', 'two', 'three']
    }


# Generated at 2022-06-11 01:01:08.926226
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'someKey': 'someValue',
        'anotherKey': {
            'nestedKey1': 'nestedValue1',
            'nestedKey2': 'nestedValue2',
            'nestedList': [{
                'nestedListCamelKey1': 'nestedListValue1',
                'nestedListCamelKey2': 'nestedListValue2',
                'nestedListCamelKey3': 'nestedListValue3',
            }]
        },
        'anotherList': [{
            'anotherListCamelKey1': 'anotherListValue1',
            'anotherListCamelKey2': 'anotherListValue2',
            'anotherListCamelKey3': 'anotherListValue3',
        }]
    }


# Generated at 2022-06-11 01:01:19.629927
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:30.918928
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Initialize test input
    camel_dict_input = {"HTTPEndpoint": "http_endpoint", "MixedCase": "mixed_case",
                        "HTTP_Endpoint": "http_endpoint", "AllCAPS": "all_caps", "all_snake": "all_snake"}

    # Test case 1: No arguments passed.
    assert camel_dict_to_snake_dict({}) == {}

    # Test case 2: No camelized keys

# Generated at 2022-06-11 01:01:41.144493
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert(camel_dict_to_snake_dict(dict(A=1)) == dict(a=1))
    assert(camel_dict_to_snake_dict(dict(A=1, B=dict(C=2))) == dict(a=1, b=dict(c=2)))
    assert(camel_dict_to_snake_dict(dict(A=1, b=dict(c=2))) == dict(a=1, b=dict(c=2)))
    assert(camel_dict_to_snake_dict(dict(A=1, b=dict(C=2))) == dict(a=1, b=dict(c=2)))

# Generated at 2022-06-11 01:01:50.006047
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        'Test': 'test',
        'One': 1,
        'Two': 2,
        'Three': 3,
        'Is': {
            'Four': 4,
            'Five': 5,
            'Six': 6,
            'Seven': {
                'Eight': 8,
                'Nine': 9,
                'Ten': 10
            }
        }
    }) == {
        'test': 'test',
        'one': 1,
        'two': 2,
        'three': 3,
        'is': {
            'four': 4,
            'five': 5,
            'six': 6,
            'seven': {
                'eight': 8,
                'nine': 9,
                'ten': 10
            }
        }
    }

   

# Generated at 2022-06-11 01:01:56.811893
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'NetworkInterfaces': [{'SubnetId': 'subnet-12345',
                                                            'PrivateIpAddress': '10.0.0.1'}],
                                     'Placement': {'AvailabilityZone': 'us-west-2a'}},
                                    reversible=True) == {'network_interfaces': [{'subnet_id': 'subnet-12345',
                                                                                  'private_ip_address': '10.0.0.1'}],
                                                         'placement': {'availability_zone': 'us-west-2a'}}


# Generated at 2022-06-11 01:02:07.868816
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:20.139755
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        "key1":"value1",
        "key2":"value2",
        "key3": {
            "subkey1": "subvalue1",
            "subkey2": "subvalue2",
            "subkey3": "subvalue3"
        }
    }
    right = {
        "key1":"value1",
        "key2":"value_new",
        "key3": {
            "subkey1": "subvalue1",
            "subkey2": "subvalue2_new",
            "subkey3": "subvalue3_new"
        }
    }

    result = recursive_diff(left,right)
    expected = ({
                "key2":"value2"
                },
                {
                "key2":"value_new"
                })

# Generated at 2022-06-11 01:02:28.602523
# Unit test for function recursive_diff
def test_recursive_diff():
    def assert_diff(dict1, dict2, expected_result):
        result = recursive_diff(dict1, dict2)
        assert result == expected_result

    assert_diff(dict(a=1), dict(a=2), (dict(a=1), dict(a=2)))

    assert_diff(dict(a=1), dict(b=1),
                (dict(a=1), dict(b=1)))

    assert_diff(dict(a=1, b=dict(c=2)), dict(a=1),
                (dict(b=dict(c=2)), dict(a=1)))


# Generated at 2022-06-11 01:02:34.866393
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test with dictionary
    assert recursive_diff(
        {"key1": "value1"},
        {"key1": "value1"}) is None

    assert recursive_diff(
        {"key1": "value2"},
        {"key1": "value1"}) == ({"key1": "value2"}, {"key1": "value1"})

    assert recursive_diff(
        {"key1": "value1"},
        {"key2": "value2"}) == ({"key1": "value1"}, {"key2": "value2"})

    assert recursive_diff(
        {"key1": "value1", "key2": "value2"},
        {"key2": "value2"}) == ({"key1": "value1"}, {})


# Generated at 2022-06-11 01:02:39.333252
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'Endpoint': 'some_endpoint'}}
    test_dict_result = {'h_t_t_p_endpoint': {'endpoint': 'some_endpoint'}}

    assert camel_dict_to_snake_dict(test_dict) == test_dict_result



# Generated at 2022-06-11 01:02:45.294902
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = dict(
        SrcSecurityGroupOwnerId='111',
        SrcSecurityGroupName='test',
        IpProtocol='tcp',
        FromPort='22',
        ToPort='22',
        CidrIp='0.0.0.0/0',
        IpPermissions=[
            dict(
                IpProtocol='tcp',
                FromPort='22',
                ToPort='22',
                IpRanges=[
                    dict(CidrIp='0.0.0.0/0')
                ]
            )
        ]
    )

# Generated at 2022-06-11 01:02:56.811316
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

  camel_dict = {
      "HTTPHeaders": [
          {
              "Name": "test",
              "Value": "test"
          }
      ],
      "HTTPCookie": {
          "Name": "test",
          "Value": "test",
          "Domain": "test",
          "Path": "test",
          "Expiration": "test",
          "Secure": False,
          "HttpOnly": False
      },
      "HTTPHeader": {
          "Name": "test",
          "Value": "test"
      },
      "Tags": {
          "Name": "test"
      },
      "QueryString": "test"
  }


# Generated at 2022-06-11 01:03:07.122516
# Unit test for function recursive_diff
def test_recursive_diff():
    # Sample dictionaries
    dict1 = {
       'a': 1,
       'b': {
           'ba': {
               'baa': 1
           },
           'bb': 2
       }
    }
    dict2 = {
       'a': 2,
       'b': {
           'ba': {
               'baa': 2
           },
           'bb': 2
       }
    }

    # Expected result of recursive_diff
    expected_left = {
       'a': 1,
       'b': {
           'ba': {
               'baa': 1
           }
       }
    }
    expected_right = {
       'a': 2,
       'b': {
           'ba': {
               'baa': 2
           }
       }
    }

    # Test recursive_

# Generated at 2022-06-11 01:03:21.695223
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "foo": "bar",
        "baz": "boom",
        "HTTPEndpoint": "https://example.com",
        "target_group_arns": [
            "aws:///targetgroup1",
            "aws:///targetgroup2"
        ],
        "Tags": {
            "Tag1": "abcdefg",
            "Tag2": "hijklmn",
            "Tag3": "opqrstu",
        },
        "yolo": [
            "a",
            "b",
            {
                "x": "c",
                "y": "d",
            }
        ]
    }


# Generated at 2022-06-11 01:03:30.925561
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "NotCamelCase": "test_1",
        "ShouldNotBeAffected": "test_2",
        "ShouldBeAffected": {
            "CamelCase": "test_3"
        }
    }
    reversed_dict = {
        "not_camel_case": "test_1",
        "should_not_be_affected": "test_2",
        "should_be_affected": {
            "camel_case": "test_3"
        }
    }
    assert(camel_dict_to_snake_dict(test_dict) == reversed_dict)
    assert(camel_dict_to_snake_dict(test_dict, reversible=True) == reversed_dict)


# Generated at 2022-06-11 01:03:42.157370
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_camel_data = {
        'aCamelDict': {
            'anotherCamelDict': {
                'someKey': 'someValue',
            },
            'someKey': 'someValue',
        },
    }

    test_snake_data = {
        'a_camel_dict': {
            'another_camel_dict': {
                'some_key': 'someValue',
            },
            'some_key': 'someValue',
        },
    }

    assert camel_dict_to_snake_dict(test_camel_data) == test_snake_data
    assert snake_dict_to_camel_dict(test_snake_data) == test_camel_data

# Generated at 2022-06-11 01:03:50.302048
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create test camel case string
    camel_dict = {
        'abc': {
            'def': {
                'ghi': True
            },
            'jkl': {
                'mno': True
            }
        },
        'pqrs': ['HTTPEndpoint'],
        'URLs': ['https://www.fakewebsite.com', 'UDPEndpoint'],
        'FooBarMoo': 'foo',
        'Tags': {
            'A': 'B',
            'C': 'D'
        }
    }

    # Convert the test string to snake case
    snake_dict = camel_dict_to_snake_dict(camel_dict)

    # Define the expected snake case string

# Generated at 2022-06-11 01:04:01.911470
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:07.064797
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_case_dict = {'HTTPEndpoint': {}, "Attribute": {}, 'Tags': {'key': 'Name', 'value': 'Random'}}
    expected_dict = {'h_t_t_p_endpoint': {}, "attribute": {}, 'tags': {'key': 'Name', 'value': 'Random'}}
    assert camel_dict_to_snake_dict(camel_case_dict) == expected_dict

# Generated at 2022-06-11 01:04:18.196368
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    random_dict = {'a': 1, 'B': 2, 'C': {'d': 3}, 'D': [1], 'Ef': 5, 'F': [{'g': 6}, {'h': [7, 8]}]}

    snake_dict = camel_dict_to_snake_dict(random_dict)
    assert snake_dict == {'a': 1, 'b': 2, 'c': {'d': 3}, 'd': [1], 'ef': 5, 'f': [{'g': 6}, {'h': [7, 8]}]}

    rev_dict = snake_dict_to_camel_dict(snake_dict)

# Generated at 2022-06-11 01:04:28.588565
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'KeyPairName': 'ansible_20151106', 'SecurityGroupNames': ['default', 'ansible'], 'StackName': 'test', 'Tags': [{'Key': 'foo', 'Value': 'bar'}, {'Key': 'fizz', 'Value': 'buzz'}]}
    assert camel_dict_to_snake_dict(camel_dict) == {'key_pair_name': 'ansible_20151106', 'security_group_names': ['default', 'ansible'], 'stack_name': 'test', 'tags': [{'key': 'foo', 'value': 'bar'}, {'key': 'fizz', 'value': 'buzz'}]}, "Camel dictionary not converted correctly to snake dictionary"



# Generated at 2022-06-11 01:04:36.686206
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'HTTPEndpoint': {
            'Url': 'http://localhost/endpoint',
            'Timeout': '5',
            'Tags': {
                'tag1': 'tag-value',
                'tag2': 'tag-value'
            }
        }
    }
    assert camel_dict_to_snake_dict(test_dict) == {
        'h_t_t_p_endpoint': {
            'url': 'http://localhost/endpoint',
            'timeout': '5',
            'tags': {
                'tag1': 'tag-value',
                'tag2': 'tag-value'
            }
        }
    }

# Generated at 2022-06-11 01:04:47.612975
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict1 = {'HTTPEndpoint': 'endpoint1'}
    snake_dict1 = {'http_endpoint': 'endpoint1'}

    camel_dict2 = {'HTTPEndpoint': 'endpoint1', 'PortRanges': [{'From': 0, 'To': 1}]}
    snake_dict2 = {'http_endpoint': 'endpoint1', 'port_ranges': [{'from': 0, 'to': 1}]}

    camel_dict3 = {'PortRanges': [{'From': 0, 'To': 1}]}
    snake_dict3 = {'port_ranges': [{'from': 0, 'to': 1}]}

    camel_dict4 = {'From': 0, 'To': 1}

# Generated at 2022-06-11 01:04:55.433183
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = {"aBc": "d", "e": "f"}
    dict2 = {"a_bc": "d", "e": "f"}
    assert camel_dict_to_snake_dict(dict1) == dict2



# Generated at 2022-06-11 01:05:01.893481
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        fooBar='baz',
        fooBaz='blah',
        foobar='blarg',
        foo='quux',
        bam={
            'fooBar':'quux',
            'foo':'quuz'
        }
    )
    snake_dict = dict(
        foo_bar='baz',
        foo_baz='blah',
        foobar='blarg',
        foo='quux',
        bam={
            'foo_bar':'quux',
            'foo':'quuz'
        }
    )

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-11 01:05:11.531813
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'foo': 'bar',
        'Foo2': 'bar2',
        'foo3': {
            'bar': 'baz'
        },
        'zoomZ': 'boom',
        'zapZ': {
            'boom': 'Zoom'
        },
        'maxConn': '100',
        'max_conn': '100',
        'max_conn_per_route': '100',
        'maxConnPerRoute': '100',
        'HTTPEndpoint': 'http://www.example.com',
        'Tags': [
            {'Key': 'tag1', 'Value': 'value1'},
        ]
    }
    res = camel_dict_to_snake_dict(test_dict)

# Generated at 2022-06-11 01:05:20.309030
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'key1': 'value1',
                 'key2': {
                   'key3': 'value3',
                   'key4': 'value4'
                 },
                 'key5': ['item1', 'item2', 'item3'],
                 'key6': [{'key7': 'value7'}, {'key8': 'value8'}]
                }

    expected_result = {'key1': 'value1',
                       'key2': {
                           'key3': 'value3',
                           'key4': 'value4'
                       },
                       'key5': ['item1', 'item2', 'item3'],
                       'key6': [{'key7': 'value7'}, {'key8': 'value8'}]
                      }

    result = camel_dict_

# Generated at 2022-06-11 01:05:30.392983
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:41.093284
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Foo': {'Bar': {'Baz': 'FooBarBaz'}}}) == {'foo': {'bar': {'baz': 'FooBarBaz'}}}
    assert camel_dict_to_snake_dict({'Foo': {'Bar': {'Baz': 'FooBarBaz'}}}, reversible=True) == {'foo': {'bar': {'baz': 'FooBarBaz'}}}
    assert camel_dict_to_snake_dict({'Foo': {'Bar': {'Baz': 'FooBarBaz'}}}, reversible=True, ignore_list=['Foo']) == {'f_oo': {'bar': {'baz': 'FooBarBaz'}}}
    assert camel_dict_

# Generated at 2022-06-11 01:05:52.380826
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:02.209454
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Unit test for function recursive_diff
    """
    dict1 = {"key1": "value1", "key2": {"key3": "value3"}, "key4": {"key5": {"key6": "value6"}}}
    dict2 = {"key1": "value1", "key2": {"key3": "value3"}, "key4": {"key5": {"key6": "value6"}}}
    dict3 = {"key1": "value1", "key2": {"key3": "value3"}, "key4": {"key5": {"key6": "value66"}}}

    expected_result = None
    result = recursive_diff(dict1, dict2)
    assert(result == expected_result)


# Generated at 2022-06-11 01:06:11.198737
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:21.798334
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'FooBar': 42}) == {'foo_bar': 42}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 42}) == {'h_t_t_p_endpoint': 42}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 42}, reversible=True) == {'h_t_t_p_endpoint': 42}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 42}, reversible=False) == {'http_endpoint': 42}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 42}, reversible=False, ignore_list=['HTTPEndpoint']) == {'HTTPEndpoint': 42}
    assert camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:39.206022
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'Person': {'Name': 'Joe', 'Age': 12}}, False) == {'person': {'name': 'Joe', 'age': 12}}
    assert camel_dict_to_snake_dict({'Person': {'Name': 'Joe', 'Age': 12}}, True) == {'person': {'name': 'Joe', 'age': 12}}
    assert camel_dict_to_snake_dict({'Person': {'Name': 'Joe', 'Age': 12, 'Tags': [{'Key': 'something'}]}}, True) == {'person': {'name': 'Joe', 'age': 12, 'tags': [{'key': 'something'}]}}

# Generated at 2022-06-11 01:06:46.496202
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {'tags': {'Tag1': 'Value1', 'Tag2': 'Value2'}, 'my_key': 'my_value', 'my_list': [1, 2], 'my_list_of_dicts': [{'list_key': 'list_value'}], 'my_dict': {'dict_key': 'dict_value'}} == camel_dict_to_snake_dict({'Tags': {'Tag1': 'Value1', 'Tag2': 'Value2'}, 'MyKey': 'my_value', 'MyList': [1, 2], 'MyListOfDicts': [{'ListKey': 'list_value'}], 'MyDict': {'DictKey': 'dict_value'}})

# Generated at 2022-06-11 01:06:56.720343
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Tests a complex example when the reversible flag is False
    # Tags key is ignored and not transformed
    camel_dict = {
        'DBName': 'test',
        'DBInstanceClass': 'db.t2.micro',
        'MultiAZ': False,
        'AllocatedStorage': 5,
        'Tags': [{
            'Key': 'string',
            'Value': 'string'
        }]
    }
    snake_dict = {
        'db_name': 'test',
        'db_instance_class': 'db.t2.micro',
        'multi_az': False,
        'allocated_storage': 5,
        'Tags': [{
            'Key': 'string',
            'Value': 'string'
        }]
    }

# Generated at 2022-06-11 01:07:01.835589
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'EnumVal1': 'Val1',
        'EnumVal2': 'Val2',
        'Name': 'hello',
        'Tags': {'Key': 'Name'},
        'HTTPEndpoint': True,
        'HTTPPort': 80,
        'HTTPProtocol': 'HTTPAndHTTPS',
        'SeoConfiguration': {
            'SeoConfiguration': {
                'Option1': 'option_1',
                'Option2': 'opt2'
            }
        }
    }

# Generated at 2022-06-11 01:07:11.338934
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {"FooFoo": "foobar", "HTTPEndpoint": {"Foo": {"barbaz": "foobar"}}}
    expected_output = {"foo_foo": "foobar", "h_t_t_p_endpoint": {"foo": {"barbaz": "foobar"}}}

    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == expected_output
    assert camel_dict_to_snake_dict(camel_dict) == {"foo_foo": "foobar", "http_endpoint": {"foo": {"barbaz": "foobar"}}}
    assert _camel_to_snake("HTTPEndpoint", reversible=True) == "h_t_t_p_endpoint"

# Generated at 2022-06-11 01:07:20.660689
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {'a': {'b': '1', 'c': '2', 'd': '3'}, 'e': '4', 'f': '5'}
    right = {'a': {'b': '2', 'c': '3', 'd': '4'}}
    res = recursive_diff(left, right)
    print(res)
    #assert res == ({'a': {'b': '1'}, 'e': '4', 'f': '5'}, {'a': {'b': '2'}})
    # left = {'a': {'b': '1', 'c': '2', 'd': '3'}, 'e': '4', 'f': '5'}
    # right = {'a': {'b': '2', 'c': '3', 'd': '4

# Generated at 2022-06-11 01:07:27.328407
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "BusinessHours": {
            "TimeZone": {
                "Name": "Greenland Standard Time"
            }
        },
        "Tags": {
            "Key1": "Value1",
            "Key2": "Value2"
        }
    }

    test_dict_output = {
        'business_hours': {'time_zone': {'name': 'Greenland Standard Time'}},
        'tags': {'Key1': 'Value1', 'Key2': 'Value2'}
    }

    assert camel_dict_to_snake_dict(test_dict) == test_dict_output



# Generated at 2022-06-11 01:07:38.270074
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:45.593815
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test simple diff with dicts
    dict1 = {'one': 'two'}
    dict2 = {'one': 'two'}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'one': 'two'}
    dict2 = {'two': 'one'}
    assert recursive_diff(dict1, dict2) == ({'one': 'two'}, {'two': 'one'})

    dict1 = {'one': 'three'}
    dict2 = {'one': 'two'}
    assert recursive_diff(dict1, dict2) == ({'one': 'three'}, {'one': 'two'})

    # Test diff with dicts and dicts in dicts
    dict1 = {'one': {'two': 'three'}}

# Generated at 2022-06-11 01:07:54.409579
# Unit test for function camel_dict_to_snake_dict