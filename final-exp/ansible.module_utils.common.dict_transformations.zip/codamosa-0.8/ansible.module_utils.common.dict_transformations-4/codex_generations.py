

# Generated at 2022-06-11 00:58:16.654206
# Unit test for function recursive_diff
def test_recursive_diff():
    d1 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}}
    d2 = {'a': 1, 'b': 3, 'c': {'a': 2, 'b': 2, 'c': 3}}
    expected = (
        {'b': 2},
        {'b': 3}
    )

    ret = recursive_diff(d1, d2)
    assert ret == expected, "result %s != expected %s" % (ret, expected)

# Generated at 2022-06-11 00:58:23.471375
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'AWSVPCConfiguration': {'AssignPublicIp': True, 'SecurityGroups': ['sg-abbc2bc']}}) == \
           {'awsvpc_configuration': {'assign_public_ip': True, 'security_groups': ['sg-abbc2bc']}}



# Generated at 2022-06-11 00:58:34.070602
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""

    # Correct type is passed - two simple dictionaries
    test_dict_1 = {
        'description': 'test dictionary'
    }
    test_dict_2 = {
        'description': 'test dictionary'
    }
    assert recursive_diff(test_dict_1, test_dict_2) == None

    # Correct type is passed - two nested dictionaries with only one level difference
    test_dict_1 = {
        'description': 'test dictionary',
        'meta': {
            'version': '1.0'
        }
    }

# Generated at 2022-06-11 00:58:40.503516
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'VpcId': 'vpc-1a2b3c4d',
        'Tags': {
            'Key': 'Name',
            'Value': 'MySubnet'
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict, ignore_list=('Tags',))
    assert snake_dict['vpc_id'] == 'vpc-1a2b3c4d'
    assert snake_dict['tags'] == {'Key': 'Name', 'Value': 'MySubnet'}



# Generated at 2022-06-11 00:58:52.375515
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:02.646809
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://s3-us-west-2.amazonaws.com'}}) == {'h_t_t_p_endpoint': {'u_r_l': 'http://s3-us-west-2.amazonaws.com'}}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'URL': 'http://s3-us-west-2.amazonaws.com'}}, reversible=True) == {'h_t_t_p_endpoint': {'u_r_l': 'http://s3-us-west-2.amazonaws.com'}}

# Generated at 2022-06-11 00:59:14.215924
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert {'foo_bar': 'baz'} == camel_dict_to_snake_dict({'FooBar': 'baz'})

# Generated at 2022-06-11 00:59:22.820345
# Unit test for function dict_merge
def test_dict_merge():

    # Initialize test dictionaries
    d1 = {'a': 1,
          'b': {'d': 3,
                'e': {'g': 5, 'h': 6, 'i': 7}},
          'c': 2,
          'f': {'z': 26}}
    d2 = {'a': 2,
          'b': {'d': 4,
                'e': {'g': 6, 'h': 7, 'i': 8}},
          'c': 2,
          'f': {'z': 27}}

    # Test dict_merge function
    d3 = dict_merge(d1, d2)
    assert d3['a'] == 2
    assert d3['b']['d'] == 4
    assert d3['b']['e']['g'] == 6


# Generated at 2022-06-11 00:59:34.388292
# Unit test for function recursive_diff
def test_recursive_diff():
    """ Unit tests for function recursive_diff """

    correct_result = (
        {1: {'a': 1, 'b': 2, 'test': 1}, 'c': 3, 'test': 1},
        {1: {'a': 1, 'b': 1, 'test': 2}, 'c': 4, 'test': 2})

    dict1 = {1: {'a': 1, 'b': 2}, 'c': 3,'test': 1}
    dict2 = {1: {'a': 1, 'b': 1}, 'c': 4,'test': 2}
    result = recursive_diff(dict1, dict2)
    assert result == correct_result, "recursive_diff returned incorrect result:\n%s\nExpected:\n%s" \
                                     % (result, correct_result)


# Generated at 2022-06-11 00:59:45.006174
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {}) == ({'a': 1}, {})
    assert recursive_diff({}, {'a': 1}) == ({}, {'a': 1})
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'a': 1, 'b': 1}) == ({}, {'b': 1})
    assert recursive_diff({'a': 1, 'b': 1}, {'a': 1}) == ({'b': 1}, {})

# Generated at 2022-06-11 01:00:00.356925
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'fooBarBaz': 'qux'}) == {'foo_bar_baz': 'qux'}
    assert camel_dict_to_snake_dict({'fooBar': {'bazQux': 'bar'}}) == {'foo_bar': {'baz_qux': 'bar'}}
    assert camel_dict_to_snake_dict({'foo': {'baz': {'qux': ['bar', 'quux']}}}) == {'foo': {'baz': {'qux': ['bar', 'quux']}}}


# Generated at 2022-06-11 01:00:09.692488
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_1 = {
        'Tags': {
            'Tag': [
                {'Value': 'arn:aws:ecr:us-east-1:12345678:repository/test-repository', 'Key': 'TestKey'},
                {'Value': 'arn:aws:ecr:us-east-1:12345678:image/test-repository:12345678', 'Key': 'Metadata'}
            ]
        },
        'HttpEndpoint': 'ENABLED'
    }

# Generated at 2022-06-11 01:00:21.619534
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:32.296994
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test the case of the normal Django model serializer
    camel = {'someKey1': 1, 'someKey2': 2}
    expected_snake = {'some_key1': 1, 'some_key2': 2}

    # Test the case of the normal Django model serializer
    camel = {'a': 1, 'b': 2, 'c': 3}
    expected_snake = {'a': 1, 'b': 2, 'c': 3}

    # Test the case of the normal Django model serializer
    camel = {'someKey': {'someKey1': 1, 'someKey2': 2}}
    expected_snake = {'some_key': {'some_key1': 1, 'some_key2': 2}}

    # Test the case that the key is a list

# Generated at 2022-06-11 01:00:43.551292
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:55.089508
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:04.757254
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        "HTTPEndpoint": {
            "Protocol": "http",
            "Path": "",
            "TimeoutInMillis": 5000,
            "RetryCount": 1,
            "HTTPUserAgent": "Custom",
            "Enabled": True
        },
        "Tags": {
            "Server": "www.example.com",
            "Departament": "Web",
            "OS": "Linux"
        },
        "Period": 900
    }


# Generated at 2022-06-11 01:01:15.601271
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:21.757408
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Action': 'GetUser',
        'Version': '2010-05-08',
        'UserName': 'Bob',
        'HTTPEndpoint': 'http://example.com/foo',
        'HTTPEndpoints': [{'HTTPCompression': 'GZIP'},
                          {'HTTPCompression': 'GZIP'}],
        'Tags': {'key': 'value'},
        'Tag': [{'key': 'value'}, {'key': 'value2'}, {'key': 'value3'}]
    }


# Generated at 2022-06-11 01:01:33.299890
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:44.333669
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}, False) == {}
    assert camel_dict_to_snake_dict({'FooBar': 'baz'}, False) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz', 'QuX': 'quux'}, False) == {'foo_bar': 'baz', 'qu_x': 'quux'}
    assert camel_dict_to_snake_dict({'FooBar': 'baz', 'child': {'FooBar': 'quux'}}, False) == {'foo_bar': 'baz', 'child': {'foo_bar': 'quux'}}

# Generated at 2022-06-11 01:01:50.384200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Precondition
    assert camel_dict_to_snake_dict({}) == {}
    # Test 1
    assert camel_dict_to_snake_dict({'a': {'b': {'c': 1, 'D': 2}, 'Ef': 3}}) == {'a': {'b': {'c': 1, 'd': 2}, 'ef': 3}}
    # Test 2
    assert (camel_dict_to_snake_dict({'a': {'b': {'c': 1, 'D': 2}, 'Ef': 3}},
                                     ignore_list=['b']) ==
            {'a': {'b': {'c': 1, 'D': 2}, 'ef': 3}})
    # Postcondition
    assert camel_dict_to_snake_dict({}) == {}



# Generated at 2022-06-11 01:01:54.823250
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"name": "TestInstance", "privateIpAddress": "192.0.2.1", "tags": {"key": "value"}}
    expected_camelized_dict = {"Name": "TestInstance", "PrivateIpAddress": "192.0.2.1", "Tags": {"key": "value"}}
    camelized_dict = snake_dict_to_camel_dict(camel_dict_to_snake_dict(camel_dict))
    assert camelized_dict == expected_camelized_dict

# Generated at 2022-06-11 01:02:02.145443
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict_test = {
        "HTTPEndpoint": {"URL": "http://example.com"},
        "SomeOtherValue": "test",
        "tags": {"testTag": "test"}
    }

    snake_dict_test = {
        "http_endpoint": {"url": "http://example.com"},
        "some_other_value": "test",
        "tags": {"testTag": "test"}
    }

    assert(camel_dict_to_snake_dict(camel_dict_test) == snake_dict_test)



# Generated at 2022-06-11 01:02:14.272703
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:24.928581
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"snakeCase": "snakecase"}) == {"snake_case": "snakecase"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "endpoint"}) == {"h_t_t_p_endpoint": "endpoint"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "endpoint"}, reversible=True) == {"h_t_t_p_endpoint": "endpoint"}
    assert camel_dict_to_snake_dict({"TargetGroups": [{"TargetGroupArn": "arn"}]}) == {"target_groups": [{"target_group_arn": "arn"}]}

# Generated at 2022-06-11 01:02:33.078126
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {
        'HTTPEndpoint': {
            'Name': 'MyEndpoint',
            'Type': 'HTTP',
            'Tags': {
                'key': 'value',
                'keyFoo': 'valueBar'
            },
            'HTTPBody': "Hello world!"
        },
        'AWSInterval': {
            'Interval': 30,
            'Unit': "SECONDS"
        }
    }
    result = camel_dict_to_snake_dict(d)


# Generated at 2022-06-11 01:02:42.376209
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "test": {
            "test": {
                "test": {
                    "test": "test"
                },
                "HTTPEndpoint": {
                    "test": "test"
                }
            }
        },
        "targetGroupARNs": [
            "1",
            "2"
        ],
        "Tags": {
            "test": "test",
            "Key": "value"
        }
    }
    test_dict_snake_reversible = camel_dict_to_snake_dict(test_dict, reversible=True)

# Generated at 2022-06-11 01:02:54.051127
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(
        {
            'TaskDefinition': 'arn:aws:ecs:us-east-2:12345:task-definition/node-hello',
            'PreviousTaskDefinition': 'arn:aws:ecs:us-east-2:12345:task-definition/node-hello',
        }
    )

    if not isinstance(result, dict):
        return 'Expected a dictionary, got {}'.format(type(result))
    for key in ('task_definition', 'previous_task_definition'):
        if key not in result:
            return 'Expected key {} in dictionary, got {}'.format(key, list(result.keys()))

# Generated at 2022-06-11 01:03:04.883794
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:18.913732
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert _camel_to_snake("simpleKey") == "simple_key"
    assert _camel_to_snake("HTTPEndpoint", irreversible=False) == "http_endpoint"
    assert _camel_to_snake("HTTPEndpoint", irreversible=True) == "h_t_t_p_endpoint"
    assert _camel_to_snake("TargetGroupARNs") == "target_group_ar_ns"
    assert _camel_to_snake("TargetGroupARNs", irreversible=True) == "target_group_a_r_ns"
    assert _camel_to_snake("", irreversible=False) == ""
    assert _camel_to_snake("", irreversible=True) == ""
    assert _camel_to_snake("_") == "_"
    assert _

# Generated at 2022-06-11 01:03:29.515294
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelized = {
        'Tags': {
            'CreatedBy': 'ansible'
        },
        'DryRun': False,
        'MaxResults': 1000,
        'NextToken': 'string',
        'Repositories': [
            {
                'RepositoryArn': 'arn:aws:ecr:us-east-1:012345678910:repository/test',
                'RegistryId': '012345678910',
                'RepositoryName': 'test',
                'RepositoryUri': '012345678910.dkr.ecr.us-east-1.amazonaws.com/test',
                'CreatedAt': datetime.datetime(2015, 12, 22, 16, 42, 57, tzinfo=tzlocal())
            }
        ]
    }


# Generated at 2022-06-11 01:03:38.295401
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    testing_dict = {
        'Foo': 'bar',
        'nestedDict': {
            'Foo': 'bar',
            'nestedList': [
                {'Foo': 'bar'}
            ]
        },
        'AnotherDict': {}
    }

    assert camel_dict_to_snake_dict(testing_dict) == \
        {
            'foo': 'bar',
            'nested_dict': {
                'foo': 'bar',
                'nested_list': [
                    {'foo': 'bar'}
                ]
            },
            'another_dict': {}
        }



# Generated at 2022-06-11 01:03:47.832510
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "InstanceType": "t2.micro",
        "Placement": {
            "AvailabilityZone": "us-west-2a"
        },
        "Tags": [{
            "Key": "Name",
            "Value": "myName"
        }, {
            "Key": "Application",
            "Value": "myApp"
        }, {
            "Key": "Deployment",
            "Value": "test"
        }],
        "UserData": "",
        "BlockDeviceMappings": [{
            "DeviceName": "/dev/sda1",
            "Ebs": {
                "DeleteOnTermination": True,
                "Encrypted": False
            }
        }],
    }


# Generated at 2022-06-11 01:03:50.930731
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camelDict = {'fooBar': {'baz': 'qux'}}
    assert camel_dict_to_snake_dict(camelDict) == {'foo_bar': {'baz': 'qux'}}

# Generated at 2022-06-11 01:04:02.675257
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"SimpleCase": {"InnerTest": "inner_test", "One": 1},
                 "InnerList": [{"InnerListItem1": "InnerListItem1",
                                "InnerListItem2": ["Item1", "Item2", "Item3"],
                                "InnerListItem3": {"InnerListItem3": "inner_list_item3", "innerListItem4": "InnerListItem4"}}],
                 "InnerDict": {"Key1": "key1",
                               "Key2": {"Key2": "key2"}},
                 "InnerNone": None,
                 "InnerInt": 4,
                 }


# Generated at 2022-06-11 01:04:10.589013
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {"fooBar": "foobar", "FooBar": "foobar", "fooBar123": "foobar123",
                 "foo_Bar": "foobar", "foo_bar": "foobar", "foo_bar_1234": "foobar1234",
                 "fooBar1234": "foobar1234", "foo": "foo", "Foo": "foo", "foO": "foo"}
    assert(camel_dict_to_snake_dict(test_dict) == test_dict)



# Generated at 2022-06-11 01:04:21.907604
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json

    with open('test/unit/plugins/modules/ec2_vpc_endpoint_info_example.json') as input_file:
        d = json.load(input_file)

    snake_d = camel_dict_to_snake_dict(d)

    assert type(d) is type(snake_d)

    assert d['VpcEndpointId'] == snake_d['vpc_endpoint_id']
    assert d['VpcEndpointType'] == snake_d['vpc_endpoint_type']
    assert d['VpcId'] == snake_d['vpc_id']
    assert d['State'] == snake_d['state']
    assert d['ServiceName'] == snake_d['service_name']

# Generated at 2022-06-11 01:04:32.034761
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict

    camel_dict = {
        'CamelCase': 'camel_case',
        'CamelCaseKey': {
            'subCamelCaseKey': {
                'subCamelCaseKey': 'sub_camel_case_key'
            },
            'subCamelCaseKeyList': [
                'sub_camel_case_key_list'
            ]
        },
        'CamelCaseList': [
            {'subCamelCaseListKey': 'sub_camel_case_list_key'}
        ]
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert(snake_dict['camel_case'] == 'camel_case')

# Generated at 2022-06-11 01:04:38.614042
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Given
    camel_dict = {'HTTPEndpoint': {'Url': 'mytestendpoint',
                                   'Protocol': 'HTTPS'}}
    expected_snake = {'h_t_t_p_endpoint': {'url': 'mytestendpoint',
                                           'protocol': 'HTTPS'}}
    # When
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    # Then
    assert expected_snake == snake_dict



# Generated at 2022-06-11 01:04:49.642203
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:00.373567
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    original_dict = {
        "theDict": {
            "simple_key": "Simple_value",
            "camelCase": "value1",
            "titleCase": "value2",
            "dromedaryCase": "value3",
            "nested": {
                "theNestedDict": {
                    "anotherCamelCase": "anotherValue"
                }
            }
        },
        "aList": ["one", "two", "three"],
        "alsoNotATag": {
            "TAG": "test"
        },
        "Tags": [
            {
                "Key": "key1",
                "Value": "value1"
            },
            {
                "Key": "key2",
                "Value": "value2"
            }
        ]
    }


# Generated at 2022-06-11 01:05:08.184648
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:18.387830
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:29.283152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "Service": "elasticloadbalancing.amazonaws.com"
                    },
                    "Action": "sts:AssumeRole"
                }
            ]
        },
        "RoleName": "aws-elasticloadbalancing-ec2-role",
        "Path": "/"
    }
    test_ignore_list = ["Version", "Statement", "Effect", "Principal", "Action"]
    test_dict_snake = camel_dict_to_snake_dict(test_dict)

# Generated at 2022-06-11 01:05:35.645418
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'EndpointName': 'foo', 'Tags': {'TagKey': 'bar'}}}
    snake_dict = {'h_t_t_p_endpoint': {'endpoint_name': 'foo', 'tags': {'TagKey': 'bar'}}}
    assert(camel_dict_to_snake_dict(camel_dict) == snake_dict)

    snake_dict_reversible = {'h_t_t_p_endpoint': {'endpoint_name': 'foo', 'tags': {'tag_key': 'bar'}}}
    assert(camel_dict_to_snake_dict(camel_dict, reversible=True) == snake_dict_reversible)



# Generated at 2022-06-11 01:05:46.117783
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': 'https://my_endpoint',
        'Tags': {
            'Name': 'my_name',
            'Tier': 'production'
            }
        }

    expected_snake_dict = {
        'h_t_t_p_endpoint': 'https://my_endpoint',
        'tags': {
            'Name': 'my_name',
            'Tier': 'production'
            }
        }

    result_snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert result_snake_dict == expected_snake_dict, 'camel_dict_to_snake_dict failed'



# Generated at 2022-06-11 01:05:55.030023
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'SomeName': 'SomeValue',
        'NonCamel': 'NonCamelValue',
        'CamelCase': {
            'FooBar': 'FooBarValue',
            'BazBiz': 'BazBizValue',
        }
    }

    expected_dict = {
        'some_name': 'SomeValue',
        'non_camel': 'NonCamelValue',
        'camel_case': {
            'foo_bar': 'FooBarValue',
            'baz_biz': 'BazBizValue',
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert snake_dict == expected_dict


# Generated at 2022-06-11 01:06:04.188314
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'MyCamelKey':{'MyCamelValue':'my_camel_value'}}
    assert camel_dict_to_snake_dict(camel_dict) == {'my_camel_key':{'my_camel_value':'my_camel_value'}}

    snake_dict = {'my_snake_key':{'my_snake_value':'my_snake_value'}}
    assert snake_dict_to_camel_dict(snake_dict) == {'mySnakeKey':{'mySnakeValue':'my_snake_value'}}


# Generated at 2022-06-11 01:06:12.512489
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'aKey': 'aVal',
        'keyB': 'valB',
        'KeyC': 'ValC',
        'someLongKey': 'someLongVal',
        'someCamelCaseKey': 'someCamelCaseVal',
        'someListKey': [
            {
                'SomeListKey': 'someListVal',
                'SomeListKeyTwo': 'someListValTwo',
                'someListKeyThree': 'someListValThree',
                'tags': [
                    {
                        'Key': 'key',
                        'Value': 'value'
                    }
                ]
            }
        ]
    }


# Generated at 2022-06-11 01:06:26.107033
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:35.217342
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:43.704570
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:53.501266
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:03.883785
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'FooBar': 'foobar',
        'fooBar': 'foobar',
        'FOO_BAR': 'foobar',
        'HTTPEndpoint': 'http_endpoint',
        'HTTPEndpoint': 'http_endpoint',
        'HTTP_ENDPOINT': 'http_endpoint',
        'HttpEndpoint': 'http_endpoint',
        'HTTPEndpoint': 'http_endpoint',
        'HTTP_ENDPOINT': 'http_endpoint',
        'Tags': {
            'Key': 'Value',
        },
    }

# Generated at 2022-06-11 01:07:12.824023
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test basic conversion
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Value': 'http://dummy'}},
                                    reversible=False) == {'http_endpoint': {'value': 'http://dummy'}}

    # Test that the conversion is reversible
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'HTTPEndpoint': {'Value': 'http://dummy'}})) == \
           {'HTTPEndpoint': {'Value': 'http://dummy'}}

    # Test that a complex structure is converted properly

# Generated at 2022-06-11 01:07:21.795969
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Create a camelCase dict with nested dicts
    camel_dict = {
        'HTTPEndpoint': {
            'Protocol': 'http',
            'TargetURL': 'http://example.com/endpoint',
            'Timeout': 1,
            'Authorization': 'none',
            'AuthorizationURL': 'http://example.com/auth',
            'IsActive': False,
            'Tags': {
                'foo': 'bar',
                'app': 'app_name',
            }
        }
    }

    # Convert camelCase dict to snake_case dict
    snake_dict = camel_dict_to_snake_dict(camel_dict, ignore_list=['Tags'])

    assert snake_dict['http_endpoint']['protocol'] == 'http'

# Generated at 2022-06-11 01:07:32.016077
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'testKey': 'testValue',
                  'test2Key': 'test2Value',
                  'description': {'descriptionKey': 'descriptionValue'},
                  'phases': [{'phasesKey': 'phasesValue'}]}

    snake_dict = {'test_key': 'testValue',
                  'test2_key': 'test2Value',
                  'description': {'description_key': 'descriptionValue'},
                  'phases': [{'phases_key': 'phasesValue'}]}


# Generated at 2022-06-11 01:07:42.060126
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert(camel_dict_to_snake_dict(dict(Tags=dict(Tag1="test1", Tag2="test2")))
           == dict(tags=dict(Tag1="test1", Tag2="test2")))

    assert(camel_dict_to_snake_dict(dict(Tags=[dict(Key="test1", Value="test2")]))
           == dict(tags=[dict(key="test1", value="test2")]))

    assert(camel_dict_to_snake_dict(dict(Tags=[dict(Key="test1", Value="test2")]), reversible=True)
           == dict(tags=[dict(key="test1", value="test2")]))


# Generated at 2022-06-11 01:07:51.809142
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'Test': 'test'}, reversible=True) == {'test': 'test'}
    assert camel_dict_to_snake_dict({'Capitals': 'test'}, reversible=True) == {'capitals': 'test'}
    assert camel_dict_to_snake_dict({'Abbreviations': 'test'}, reversible=True) == {'abbreviations': 'test'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'test'}, reversible=True) == {'h_t_t_p_endpoint': 'test'}
    assert camel_dict_to_snake_dict({'HTTP': 'test'}, reversible=True) == {'h_t_t_p': 'test'}
    assert camel_

# Generated at 2022-06-11 01:08:08.755121
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'a': {'b': 'c', 'd': 1}}) == {'a': {'b': 'c', 'd': 1}}
    assert camel_dict_to_snake_dict({'a': {'B': 'c', 'D': 1}}) == {'a': {'b': 'c', 'd': 1}}
    assert camel_dict_to_snake_dict({'a': {'b': 'c', 'D': 1}}) == {'a': {'b': 'c', 'd': 1}}
    assert camel_dict_to_snake_dict({'A': {'b': 'c', 'd': 1}}) == {'a': {'b': 'c', 'd': 1}}
    assert camel_dict_to_snake_