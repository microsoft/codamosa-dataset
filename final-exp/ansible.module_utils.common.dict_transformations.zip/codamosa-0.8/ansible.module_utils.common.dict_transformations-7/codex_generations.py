

# Generated at 2022-06-11 00:58:18.894834
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'TestKey': 'TestValue'}) == {'test_key': 'TestValue'}



# Generated at 2022-06-11 00:58:29.693619
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {'NestedDict': {'NestedCamel': 'value', 'Nested_snake': 'value'},
             'Flat_snake': 'value',
             'FlatCamel': 'value',
             'HTTPEndpoint': 'value',
             'HTTPEndpoint_normal': 'value'
             }

    assert camel_dict_to_snake_dict(camel) == \
        {'flat_snake': 'value', 'flat_camel': 'value', 'h_t_t_p_endpoint': 'value',
         'http_endpoint_normal': 'value', 'nested_dict': {'nested_snake': 'value', 'nested_camel': 'value'}}



# Generated at 2022-06-11 00:58:39.428559
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'fooBar': 'x', 'catDog': {'cat': 'mew', 'dog': 'woof'},
                 'dogFood': [{'type': 'salmon'}, {'type': 'vegetables'}]}
    correct_dict = {'foo_bar': 'x', 'cat_dog': {'cat': 'mew', 'dog': 'woof'},
                    'dog_food': [{'type': 'salmon'}, {'type': 'vegetables'}]}

    result_dict = camel_dict_to_snake_dict(test_dict, reversible=True)
    assert result_dict == correct_dict

    result_dict = camel_dict_to_snake_dict(test_dict)
    assert result_dict != correct_dict
    result_dict = camel_dict

# Generated at 2022-06-11 00:58:50.295971
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'TestKey': 'TestValue'}) == {'test_key': 'TestValue'}
    assert camel_dict_to_snake_dict({'TestKey': 'TestValue'}, reversible=True) == {'t_e_s_t_key': 'TestValue'}
    assert camel_dict_to_snake_dict({'TestKey': 'TestValue', 'Tags': {'TagKey': 'TagValue'}}) == {'test_key': 'TestValue', 'tags': {'TagKey': 'TagValue'}}

# Generated at 2022-06-11 00:59:01.491754
# Unit test for function recursive_diff
def test_recursive_diff():

    def test_helper(a, b):
        if a is None or b is None:
            assert recursive_diff(*((a, b) if a is not None else (b, a))) is None
        else:
            assert recursive_diff(*((a, b) if a is not None else (b, a))) == (a, b)

    test_helper({'a': {'b': {'c': 1}, 'd': 2}, 'e': 3},
                {'a': {'b': {'c': 1}, 'd': 2}, 'e': 4})

    test_helper({'a': {'b': 1, 'c': {'d': 2}}, 'e': 3},
                {'a': {'b': 1, 'c': {'d': 3}}, 'e': 3})

    test_hel

# Generated at 2022-06-11 00:59:07.237239
# Unit test for function dict_merge
def test_dict_merge():
    a = dict(a=1, b=2, c=dict(a=1, b=2, c=3), d=None, e=dict(a=1))
    b = dict(a=9, b=8, c=dict(b=3, c=None, d=5), d=dict(a=1, b=2), e="foo")
    c = dict_merge(a, b)
    assert c == dict(a=9, b=8, c=dict(a=1, b=3, c=None, d=5), d=dict(a=1, b=2), e="foo")
    assert recursive_diff(a, c) == (dict(a=1), dict(a=9))

# Generated at 2022-06-11 00:59:13.093604
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'one': 'one', 'two': 'two', 'three': {'four': 'four'}}
    snake_dict = {'one': 'one', 'two': 'two', 'three': {'four': 'four'}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict



# Generated at 2022-06-11 00:59:19.545585
# Unit test for function dict_merge
def test_dict_merge():
    a = {'a': 1, 'b': {1: 1, 2: 2}, 'd': 6}
    b = {'c': 3, 'b': {2: 7}, 'd': {'z': [1, 2, 3]}}
    expected = {'a': 1, 'c': 3, 'b': {1: 1, 2: 7}, 'd': {'z': [1, 2, 3]}}
    assert dict_merge(a, b) == expected



# Generated at 2022-06-11 00:59:23.094745
# Unit test for function dict_merge
def test_dict_merge():
    a = {'k1': {'k2': 2}}
    b = {'k1': {'k3': 3}}
    c = {'k1': {'k2': 2, 'k3': 3}}

    assert dict_merge(a, b) == c, 'Error merging nested dicts'



# Generated at 2022-06-11 00:59:34.750621
# Unit test for function recursive_diff
def test_recursive_diff():
    # Arrange
    dict1 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 'foo',
            'e': [1, 2, 3]
        },
        'h': {
            'o': {
                'w': 'l',
                'l': 'm'
            },
            'a': {
                'y': 's'
            }
        }
    }

    # Act / Assert
    assert recursive_diff(dict1, dict1) is None

# Generated at 2022-06-11 00:59:48.337635
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
            1: 2,
            2: 3,
            3: {
                4: 5,
                5: 6
            },
            6: 7
        }
    right = {
            1: 2,
            2: 3,
            3: {
                4: 5,
                5: 7,
                8: 9
            },
            10: 11
        }
    result = recursive_diff(left, right)
    if not result:
        print("Failed test: The result is None.")
        return 1

# Generated at 2022-06-11 01:00:00.577164
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None
    assert recursive_diff({'a': 1}, {'a': 1}) is None
    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})
    assert recursive_diff({'a': 1}, {'a': 1, 'b': 2}) == ({}, {'b': 2})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1}) == ({'b': 2}, {})
    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 3}) == ({'b': 2}, {'b': 3})


# Generated at 2022-06-11 01:00:09.838566
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:21.717896
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test for recursive_diff

    This unit test will ensure that the recursive_diff function behaves as expected.
    """
    from ansible.module_utils.facts.legacy import FactsLegacy

    dict1 = dict(one=dict(one=1))
    dict2 = dict(one=dict(two=2))

    current_facts = FactsLegacy({'ansible_facts': dict(one=dict(one=1))})
    new_facts = FactsLegacy({'ansible_facts': dict(one=dict(two=2))})
    diff_tuple = recursive_diff(current_facts, new_facts)
    assert diff_tuple is not None
    assert diff_tuple[0] == dict(one=dict(one=1))

# Generated at 2022-06-11 01:00:26.114770
# Unit test for function recursive_diff
def test_recursive_diff():
    """Validate recursive_diff function"""
    diff_tuple = recursive_diff({'a':1, 'b':2, 'c':3}, {'a':1, 'b':3, 'c': 3})
    assert diff_tuple == ({'b': 2}, {'b': 3})

# Generated at 2022-06-11 01:00:35.829151
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    example_dict = {
        'Tags': [
            {
                'Value': 'ANSIBLE',
                'Key': 'TestTag',
            },
        ],
        'HTTPEndpoint': 'true',
        'Id': 'havi-example-stack-1',
        'Status': 'CREATE_IN_PROGRESS',
        'HTTPNamespaceName': 'havi-example-namespace-1',
        'Arn': 'arn:aws:servicediscovery:us-east-1:012345678910:namespace/ns-235r34rt45tertdffdfd',
        'Name': 'havi-example-stack-1.havi-example-namespace-1.local',
        'Type': 'HTTP',
    }

    result = camel_dict_to_snake_dict(example_dict)

# Generated at 2022-06-11 01:00:43.745472
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'test_dict': {1: {'a': 1, 'b': 2}, 2: {'a': 3, 'b': 4}}}
    dict2 = {'test_dict': {1: {'a': 1, 'b': 2}, 2: {'a': 5, 'b': 4}}}
    result = recursive_diff(dict1, dict2)
    assert result == ({'test_dict': {2: {'a': 3}}}, {'test_dict': {2: {'a': 5}}})

# Generated at 2022-06-11 01:00:55.320859
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({'name': 'value'}, {'name': 'value'}) is None
    assert recursive_diff({'name': 'value1'}, {'name': 'value2'}) is not None
    assert recursive_diff({'name': 'value1'}, {'name': 'value2'}) == ({'name': 'value1'}, {'name': 'value2'})
    assert recursive_diff({'name': 'value1'}, {'name': 'value1', 'other': 'other'}) == ({'other': 'other'}, {'other': 'other'})

# Generated at 2022-06-11 01:01:05.062279
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'subdict1': {'sub1': 1},
        'subdict2': {'sub2': 2},
        'subdict3': {'sub3': 3},
        'dict1': 1
    }
    dict2 = {
        'subdict1': {'sub1': 1, 'sub2': 2},
        'subdict2': {'sub2': 2},
        'subdict3': {'sub3': 3},
        'dict2': 2
    }
    result = recursive_diff(dict1, dict2)
    assert len(result) == 2
    assert result[0] == {'subdict1': {'sub2': 2}, 'dict1': 1}
    assert result[1] == {'subdict1': {'sub2': 2}, 'dict2': 2}



# Generated at 2022-06-11 01:01:15.875302
# Unit test for function recursive_diff
def test_recursive_diff():
    test_dict1 = {'test': {'test1': {'test2': 5}, 'test3': 'test4', 'test5': 10},
                  'test6': [{'test7': 'test8'}]}
    test_dict2 = {'test': {'test1': {'test2': 10}, 'test3': 'test4', 'test5': 10},
                  'test6': [{'test7': 'test8'}]}
    result = recursive_diff(test_dict1, test_dict2)
    assert result
    test_dict1 = {'test': {'test1': {'test2': 5}, 'test3': 'test4', 'test5': 10},
                  'test6': [{'test7': 'test8'}]}

# Generated at 2022-06-11 01:01:25.433759
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    sample_camel_dict = {
        "Food": "Pizza",
        "Toppings": [
            {
                "ToppingType": "Cheese",
                "ToppingName": "Mozzarella"
            },
            {
                "ToppingType": "Meat",
                "ToppingName": "Pepperoni"
            }
        ],
        "Tags": {
            'Key': 'Name',
            'Value': 'my_ec2_instance'
        }
    }


# Generated at 2022-06-11 01:01:36.975310
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:46.991942
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_01 = {
        'HTTPEndpoint': {
            'Url': 'http://samplehost.com/api'
        },
        'Tags': {
            'Name': 'TestTag',
            'tagKey': 'tagValue'
        }
    }
    expected_camel01 = {
        'http_endpoint': {
            'url': 'http://samplehost.com/api'
        },
        'tags': {
            'name': 'TestTag',
            'tagKey': 'tagValue'
        }
    }
    actual_camel01 = camel_dict_to_snake_dict(camel_dict_01)

    assert actual_camel01 == expected_camel01


# Generated at 2022-06-11 01:01:57.066531
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    f = {'StackName': 'fuga',
         'Parameters': {'foo_bar': 'baz'},
         'Tags': {'foo': 'bar'},
         'Capabilities': ['FOO', 'BAR']}

# Generated at 2022-06-11 01:02:08.075394
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    my_dict = {'InstanceId': 'some_instance', 'KeyName': 'some_key',
               'ImageId': 'some_image', 'Tags': {'Ansible': 'yes', 'env': 'test', 'vpc': 'test_vpc'},
               'SecurityGroupIds': ['sg-12348'], 'SecurityGroups': [{'vpc': 'test_vpc', 'Name': 'test_sg'}],
               'Custom': {'key1': 'val1', 'key2': 'val2'}}
    # Test we have expected results with no reverse argument

# Generated at 2022-06-11 01:02:19.930473
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Name': 'NewTag',
        'Value': 'newValue',
        'PropagateAtLaunch': True,
        'Tags': [{'Key': 'oldKey',
                  'Value': 'oldValue'
                  }]
    }

    expected_snake_dict = {
        'name': 'NewTag',
        'value': 'newValue',
        'propagate_at_launch': True,
        'tags': [{'key': 'oldKey',
                  'value': 'oldValue'
                  }]
    }

    result_snake_dict = camel_dict_to_snake_dict(camel_dict, ignore_list=['Tags'])
    assert result_snake_dict == expected_snake_dict



# Generated at 2022-06-11 01:02:28.467196
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'fooBar':'baz'}) == {'foo_bar': 'baz'}

    assert camel_dict_to_snake_dict({'fooBar':'baz'}, reversible=True) == {'foo_bar': 'baz'}

    assert camel_dict_to_snake_dict({'fooBar':'baz', 'tags':{'key1':'val1', 'key2':'val2'}}) == {'foo_bar': 'baz', 'tags':{'key1':'val1', 'key2':'val2'}}


# Generated at 2022-06-11 01:02:34.748277
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:43.415438
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    def check_snake_dict(camel_dict, snake_dict, reversible=False, ignore_list=None):
        assert ignore_list is not None, "camel_dict_to_snake_dict(%s) should be %s" % (
            str(camel_dict), str(snake_dict))
        test_snake_dict = camel_dict_to_snake_dict(camel_dict, reversible, ignore_list)
        assert test_snake_dict == snake_dict, "camel_dict_to_snake_dict(%s) should be %s, not %s" % (
            str(camel_dict), str(snake_dict), str(test_snake_dict))

    # Basic tests

# Generated at 2022-06-11 01:02:55.150247
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test a simple case:
    camel_dict = {
        'Foo': {
            'Baz': {
                'Bar': 'Bar',
                # Make sure these are not converted
                'CaseSensitive': 'CaseSensitive',
                'CaseSensitiveList': [
                    {
                        'CaseSensitive': 'CaseSensitive',
                        'CaseSensitiveList': [
                            'CaseSensitive',
                            'CaseSensitive'
                        ]
                    }
                ]
            },
        },
    }

# Generated at 2022-06-11 01:03:07.481003
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert 'HTTPEndpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': 'http://ansible.com'})['HTTPEndpoint']
    assert 'h_t_t_p_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': 'http://ansible.com'}, reversible=True)['h_t_t_p_endpoint']
    assert 'http_endpoint' == camel_dict_to_snake_dict({'HTTPEndpoint': 'http://ansible.com'})['http_endpoint']
    assert 'http://ansible.com' == camel_dict_to_snake_dict({'HTTPEndpoint': 'http://ansible.com'}).get('http_endpoint')

# Generated at 2022-06-11 01:03:13.758045
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'SubnetIds': ['subnet-0cae6e71', 'subnet-a410ffc2']}) == {'subnet_ids': ['subnet-0cae6e71', 'subnet-a410ffc2']}
    assert camel_dict_to_snake_dict({'SubnetIds': ['subnet-0cae6e71', 'subnet-a410ffc2']}, True) == {'sub_net_ids': ['subnet-0cae6e71', 'subnet-a410ffc2']}

# Generated at 2022-06-11 01:03:26.107280
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    class Test:
        def __init__(self):
            self.camel_dict = { 'keyOne': 'valueOne',
                                'KeyTwo': 'value2',
                                'keyThree': [ 'listValue1', 'listValue2' ],
                                'keyFour': { 'subKey1': 'subValue1',
                                             'subKey2': 'subValue2' },
                                'Tags': { 'key': 'value' } }

# Generated at 2022-06-11 01:03:35.998804
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:39.542634
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'camelCase': 'to_snake_case'}) == {'camel_case': 'to_snake_case'}



# Generated at 2022-06-11 01:03:48.622826
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # This will raise an assertion error if test fails
    # Test that no exception is raised if there is no conversion necessary
    camel_dict_to_snake_dict({'FooBar': 'fooBar'})
    # Test that the dictionary is correctly converted
    assert camel_dict_to_snake_dict({'FooBar': 'fooBar', 'FooBarBaz': "fooBarBaz"}) == {'foo_bar': 'fooBar', 'foo_bar_baz': "fooBarBaz"}
    # Test that the dictionary is correctly converted with a list

# Generated at 2022-06-11 01:03:59.557605
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    d = {u"HTTPEndpoints": [], u"selfLink": u"/accounts/123/regions/us-east-1/notifications", u"Tags": {}, u"includeAllRegions": True, u"RegionName": u"us-east-1"}
    d_snake = camel_dict_to_snake_dict(d)

    assert(isinstance(d_snake, dict))
    assert(len(d_snake) == 5)
    assert(d_snake.has_key("h_t_t_p_endpoints"))
    assert(d_snake.has_key("self_link"))
    assert(d_snake.has_key("tags"))
    assert(d_snake.has_key("include_all_regions"))

# Generated at 2022-06-11 01:04:08.898235
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': '1',
        'fooBaz': 2,
        'fooBash': None,
        'foobang': {
            'fooBox': 'a',
            'fooBog': 'b'
        },
        'fooboo': [
            {
                'fooX': 'xx',
                'fooY': 'yy'
            }
        ],
        'FooBarBaz': {}
    }

# Generated at 2022-06-11 01:04:19.995410
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({"foo": "bar"}) == {"foo": "bar"}
    assert camel_dict_to_snake_dict({"fooBar": "baz"}) == {"foo_bar": "baz"}
    assert camel_dict_to_snake_dict({"targetGroupArns": ["a", "b"]}) == {"target_group_arns": ["a", "b"]}

    reversed = {
        "foo": {"bar": "baz", "bat": "baz"},
        "fooBar": "baz",
        "fooBaz": {"bat": "qux"},
        "targetGroupArns": ["a", "b"]}

# Generated at 2022-06-11 01:04:30.528683
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'Tags': {}})) == {'Tags': {}}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'tags': {}})) == {'Tags': {}}
    assert snake_dict_to_camel_dict(camel_dict_to_snake_dict({'tags': {'key1': 'value1', 'key2': 'value2'}})) == {'Tags': {'key1': 'value1', 'key2': 'value2'}}

# Generated at 2022-06-11 01:04:43.464208
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    def assert_matches_expected(test_input, expected):
        assert camel_dict_to_snake_dict(test_input) == expected
        # Make sure we can round-trip as long as the input doesn't have a key called 'tags'
        if 'tags' not in test_input:
            assert camel_dict_to_snake_dict(camel_dict_to_snake_dict(test_input)) == test_input
        # Check with reversible=true
        assert camel_dict_to_snake_dict(test_input, reversible=True) == expected

    # Basic dict with string and int values
    assert_matches_expected({'Foo': 'Bar', 'Baz': 123}, {'foo': 'Bar', 'baz': 123})

    # Empty sub-dict/lists
    assert_matches_expected

# Generated at 2022-06-11 01:04:54.001950
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'CamelCase': 1, 'CamelCaseWithNumbers': 2}) == {'camel_case': 1, 'camel_case_with_numbers': 2}
    assert camel_dict_to_snake_dict({'CamelCase': [{'CamelCase': 1, 'CamelCaseWithNumbers': 2}, {'CamelCase': 3, 'CamelCaseWithNumbers': 4}], 'CamelCaseWithNumbers': 5}) == {'camel_case': [{'camel_case': 1, 'camel_case_with_numbers': 2}, {'camel_case': 3, 'camel_case_with_numbers': 4}], 'camel_case_with_numbers': 5}

# Generated at 2022-06-11 01:05:01.574114
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {
        "HTTPHeaders": [{
            "Name": "X-Test-Header",
            "Value": "x-test-value"
        }],

        "Targets": [{
            "Id": "test-target-id",
            "Port": 1234
        }],

        "Protocol": "HTTP",
        "Port": 5678
    }

    reversible = True
    expected_reversible = {
        "h_t_t_p_headers": [{
            "name": "x-test-header",
            "value": "x-test-value"
        }],

        "targets": [{
            "id": "test-target-id",
            "port": 1234
        }],

        "protocol": "HTTP",
        "port": 5678
    }

# Generated at 2022-06-11 01:05:10.554495
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(dict(
        PolicyName='MyPolicy',
        PolicyDocument=dict(
            Version='2012-10-17',
            Statement=[
                dict(
                    Effect='Allow',
                    Action=['s3:Get*', 's3:List*'],
                    Resource='*'
                )
            ]
        )
    ))
    expected_result = dict(
        policy_name='MyPolicy',
        policy_document=dict(
            version='2012-10-17',
            statement=[
                dict(
                    effect='Allow',
                    action=['s3:Get*', 's3:List*'],
                    resource='*'
                )
            ]
        )
    )
    assert result == expected_result

# Generated at 2022-06-11 01:05:19.844058
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'TestString': 'test',
                  'TestNumber': 1,
                  'Engine': 'postgres',
                  'AvailabilityZones': ['a', 'b', 'c'],
                  'mutations': {'Test': 'test',
                                'List': [1, 2, 3],
                                'Dict': {'ab': 'ba', 'ba': 'ab'}},
                  'Tags': [{'Key': 'key1', 'Value': 'value1'},
                           {'Key': 'key2', 'Value': 'value2',
                            'Other': 'other'}]}


# Generated at 2022-06-11 01:05:30.125565
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'test': 1,
        'camel': 'dromedary',
        'CamelCase': 'DromedaryCase',
        'camelCase': 'dromedaryCase',
        'camel123Case': 'dromedary123Case',
        'list': [1, 2, 3, 4]
    }

    assert camel_dict_to_snake_dict(test_dict) == \
        {'test': 1, 'camel': 'dromedary', 'camel_case': 'DromedaryCase', 'camel_case': 'dromedaryCase',
         'camel123_case': 'dromedary123Case', 'list': [1, 2, 3, 4]}


# Generated at 2022-06-11 01:05:36.517109
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:48.415678
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    initial = {'UserID': '1', 'Name': 'foo', 'Active': '1', 'CamelCase': 'foo', 'Tags': {'bar': 'baz'}}

    true_snake = {'user_id': '1', 'name': 'foo', 'active': '1', 'camel_case': 'foo', 'tags': {'bar': 'baz'}}
    snake_via_camel = camel_dict_to_snake_dict(initial)
    assert (snake_via_camel == true_snake)

    true_reversible_snake = {'user_id': '1', 'name': 'foo', 'active': '1', 'c_a_m_e_l_case': 'foo', 'tags': {'bar': 'baz'}}
    reversible_snake_via_

# Generated at 2022-06-11 01:05:55.043823
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'URL': 'http://192.0.2.1:8080',
            'EndpointId': 'http-endpoint-1',
            'EndpointConfigId': 'http-endpoint-config-1',
        },
        'Tags': {
            'k1': 'v1',
            'k2': 'v2',
            'MyKey': 'MyValue',
        }
    }

# Generated at 2022-06-11 01:06:04.158634
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'fooBar': 1}
    assert camel_dict_to_snake_dict(camel_dict) == {'foo_bar': 1}

    camel_dict = {'fooBar': {'fooBar': {'fooBar': 1}}}
    assert camel_dict_to_snake_dict(camel_dict) == {'foo_bar': {'foo_bar': {'foo_bar': 1}}}

    camel_dict = {'fooBar': 1, 'BarFoo': 2}
    assert camel_dict_to_snake_dict(camel_dict) == {'foo_bar': 1, 'bar_foo': 2}

    camel_dict = {'fooBar': 1, 'BarFoo': {'fooBar': 2, 'BarFoo': 3}}
    assert camel_dict_to_

# Generated at 2022-06-11 01:06:20.682570
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:29.156961
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'HTTPEndpoint': {'Endpoint': '1.1.1.1', 'Port': 80},
                 'Tags': {'Environment': 'dev', 'NodeType': 'app'}}
    expected = {'h_t_t_p_endpoint': {'endpoint': '1.1.1.1', 'port': 80},
                'tags': {'Environment': 'dev', 'NodeType': 'app'}}
    result = camel_dict_to_snake_dict(test_dict)

    assert expected == result

    test_dict['Tags']['NodeType'] = 123

# Generated at 2022-06-11 01:06:37.073044
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:44.806083
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'camelCaseKey': 'value'}) == {'camel_case_key': 'value'}
    assert camel_dict_to_snake_dict({'camelCaseKey': {'camelCaseKey2': 'value'}}) == {'camel_case_key': {'camel_case_key2': 'value'}}
    assert camel_dict_to_snake_dict({'camelCaseListWithDict': [{'camelCaseKey': 'value'}]}) == {'camel_case_list_with_dict': [{'camel_case_key': 'value'}]}

# Generated at 2022-06-11 01:06:54.690825
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    result = camel_dict_to_snake_dict(
        {
            'HTTPEndpoint': {
                'Url': 'http://test.com',
                'AccessKey': 'mysecretaccesskey',
                'Timeout': 101,
                'ID': '1',
                'Name': 'test',
                'Tags': {
                    'a': 'b',
                    'c': 'd'
                }
            }
        },
        reversible=True
    )

# Generated at 2022-06-11 01:07:05.228152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Data
    camelized_dict = {'fooBar': {'fooBarBaz': 'bing', 'fooBarBazBing': 'baz'},
                      'foo': 'bar',
                      'fooBarBingBaz': {'fooBarBingBaz': 'bing'},
                      'list': [{'fooBar': 'bing'}, {'bingBar': 'foo'}],
                      'testHTTPEndpoint': 'test',
                      }


# Generated at 2022-06-11 01:07:11.742533
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {"fooFoo": "bar",
                  "foo": "bar",
                  "foo_bar": "bar",
                  "fooBar": "bar",
                  "HTTPEndpoint": "bar"}

    snake_dict = {"foo_foo": "bar",
                  "foo": "bar",
                  "foo_bar": "bar",
                  "foo_bar": "bar",
                  "h_t_t_p_endpoint": "bar"}

    assert camel_dict_to_snake_dict(camel_dict) == snake_dict


# Generated at 2022-06-11 01:07:20.367961
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {"HTTPEndpoint": "http://www.ansible.com",
             "Environment": {"Name": "test", "Type": "production"},
             "Tags": {"TaskGroup1": "A", "TaskGroup2": "B"}}
    snake = {"h_t_t_p_endpoint": "http://www.ansible.com",
             "environment": {"name": "test", "type": "production"},
             "tags": {"TaskGroup1": "A", "TaskGroup2": "B"}}
    assert camel_dict_to_snake_dict(camel) == snake
    assert camel_dict_to_snake_dict(snake_dict_to_camel_dict(snake)) == snake



# Generated at 2022-06-11 01:07:28.212427
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_input = {
        "HTTPEndpoint": {
            "URL": "http://example.com",
            "ContentType": "test/test",
            "HTTPEndpointDescription": "An example HTTP endpoint",
            "Name": "test-http-endpoint"
        },
        "Tags": {
            "MyTestTag": "A test tag"
        }
    }

# Generated at 2022-06-11 01:07:38.960865
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_case_dict = {
        "HTTPEndpoint": {
            "Path": "/console",
            "Protocol": "HTTP",
            "Enabled": True,
            "Port": 8080
        }
    }

    snake_case_dict = camel_dict_to_snake_dict(camel_case_dict)

    assert snake_case_dict["h_t_t_p_endpoint"]["path"] == "/console"
    assert snake_case_dict["h_t_t_p_endpoint"]["protocol"] == "HTTP"
    assert snake_case_dict["h_t_t_p_endpoint"]["enabled"] is True
    assert snake_case_dict["h_t_t_p_endpoint"]["port"] == 8080

# Generated at 2022-06-11 01:07:54.688334
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test simple conversion
    camel_dict = {'fooBar': 1, 'fooBaz': 2}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == {'foo_bar': 1, 'foo_baz': 2}

    # test conversion of nested dict
    camel_dict = {'foo': {'barBaz': 1, 'fooBaz': 2}}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == {'foo': {'bar_baz': 1, 'foo_baz': 2}}

    # test conversion of list of dicts
    camel_dict = {'fooBar': [{'fooBaz': 1}, {'fooBaz': 2}]}

# Generated at 2022-06-11 01:08:01.800878
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Unit test for function camel_dict_to_snake_dict
    """

    import json

    # with reversible=False
    expected = {
        "auto_scaling_group_name": "Ansible_Test_AutoScaleGroup",
        "desired_capacity": 2,
        "health_check_period": 60,
        "health_check_type": "EC2",
        "launch_configuration_name": "Ansible_Test_LaunchConfiguration",
        "max_size": 2,
        "min_size": 1,
        "placement_tenancy": "default",
        "vpc_zone_identifier": [
            "subnet-5cc5c822",
            "subnet-fd5f1e9c"
        ]
    }
    assert camel_dict_to_sn

# Generated at 2022-06-11 01:08:09.614336
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}

    assert camel_dict_to_snake_dict({"Key1": "Val1", "Key2": "Val2"}) == {
        "key1": "Val1",
        "key2": "Val2",
    }

    assert camel_dict_to_snake_dict({"Key1": "Val1", "Key2": "Val2", "Key3": {"KeyA": "ValA", "KeyB": "ValB"}}) == {
        "key1": "Val1",
        "key2": "Val2",
        "key3": {"key_a": "ValA", "key_b": "ValB"},
    }
