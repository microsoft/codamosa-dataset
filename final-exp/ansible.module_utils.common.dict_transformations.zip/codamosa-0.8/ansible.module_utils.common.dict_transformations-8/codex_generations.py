

# Generated at 2022-06-11 00:58:26.515077
# Unit test for function dict_merge
def test_dict_merge():
    d1 = {'a': 1, 'b': 2, 'c': {'f': {'x': 3}}}
    d2 = {'a': 1, 'b': 3, 'c': {'g': 4}}
    d = dict_merge(d1, d2)
    assert d['b'] == 3
    assert d['c']['f']['x'] == 3
    assert d['c']['g'] == 4
    return True


# Generated at 2022-06-11 00:58:32.727886
# Unit test for function recursive_diff
def test_recursive_diff():

    input = {
        'test': 'value',
        'test2': 'value',
        'testdict': {
            'test': 'value',
            'test_list': ['value1', 'value2', 'value3'],
            'test3': {
                'test': 'value',
                'another': 'value2'
            }
        },
        'test_list': ['value1', 'value2', 'value3']
    }

# Generated at 2022-06-11 00:58:41.182273
# Unit test for function recursive_diff
def test_recursive_diff():
    a = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    b = {'a': {'b': {'c': 2}}, 'e': 4}
    assert recursive_diff(a, b) == ({'e': 3}, {'a': {'b': {'d': 2}}, 'e': 4})
    a = {'a': {'b': {'c': 1, 'd': 2}}, 'e': 3}
    b = {'a': {'b': {'c': 2}}, 'e': 3}
    assert recursive_diff(a, b) == ({'a': {'b': {'d': 2}}}, {'a': {'b': {'c': 1}}})

# Generated at 2022-06-11 00:58:53.183672
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Tests for the camel_dict_to_snake_dict function
    :return:
    """
    test_dict = {
        "HTTPEndpoint": "http://acme.com",
        "HTTPHeaders": {
            "HTTPHeader1": "Value1",
            "HTTPHeader2": "Value2"
        },
        "Tags": {
            "HTTPHeader1": "Value1",
            "HTTPHeader2": "Value2"
        },
        "EventTypes": [
            {
                "EventType": "click"
            },
            {
                "EventType": "page-visit"
            }
        ],
        "Reversible": "Test"
    }


# Generated at 2022-06-11 00:59:03.228869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {
        "Sensitive": True,
        "Tags": {},
        "HTTPEndpoint": {
            "Url": "string"
        },
        "Permission": "ALLOW",
        "Parameters": {
            "string" : "string"
        }
    }
    expected = {
        "sensitive": True,
        "tags": {},
        "h_t_t_p_endpoint": {
            "url": "string"
        },
        "permission": "ALLOW",
        "parameters": {
            "string" : "string"
        }
    }
    actual = camel_dict_to_snake_dict(input)
    assert expected == actual


# Generated at 2022-06-11 00:59:09.683254
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_dict = {'HTTPEndpoint': {'HTTPEndpointConfiguration': {'TimeoutInMillis': 123}}}
    output_dict = {'h_t_t_p_endpoint':
                       {'h_t_t_p_endpoint_configuration':
                            {'timeout_in_millis': 123}}}
    assert(camel_dict_to_snake_dict(input_dict) == output_dict)



# Generated at 2022-06-11 00:59:20.073396
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    for reversible in (True, False):
        assert _camel_to_snake('S3Bucket') == 's3_bucket'
        assert _camel_to_snake('S3Bucket', reversible=reversible) == 's3b_ucket'
        assert _camel_to_snake('HTTPEndpoint', reversible=reversible) == 'h_t_t_p_endpoint'
        assert _camel_to_snake('HTTPEndpoint') == 'http_endpoint'
        assert _camel_to_snake('HTTPEndpointNames') == 'http_endpoint_names'
        assert _camel_to_snake('HTTPEndpointNames', reversible=reversible) == 'h_t_t_p_endpoint_name_s'

# Generated at 2022-06-11 00:59:30.699841
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        "list": ["one", "two"],
        "a": 1,
        "b": 2,
        "c": {
            "list": ["one", "two"],
            "a": 1,
            "b": 2,
            "c": {
                "list": ["one", "two"],
                "a": 1,
                "b": 2,
                "c": {
                    "list": ["one", "two"],
                    "a": 1,
                    "b": 2,
                }
            }
        }
    }


# Generated at 2022-06-11 00:59:41.739778
# Unit test for function recursive_diff
def test_recursive_diff():
    # Simple diff on a string
    assert('foo', 'bar') == recursive_diff({'a': 'foo'}, {'a': 'bar'})

    # Simple diff on a list
    assert({'a': ['foo']}, {'a': ['bar']}) == recursive_diff({'a': ['foo']}, {'a': ['bar']})

    # Simple diff on a list item
    assert({'a': ['bar']}, {'a': ['foo']}) == recursive_diff({'a': ['foo']}, {'a': ['bar']})

    # Simple diff on a list item with 2 items in the list
    assert({'a': [0, 'foo']}, {'a': [1, 'bar']}) == recursive_diff({'a': [0, 'foo']}, {'a': [1, 'bar']})

   

# Generated at 2022-06-11 00:59:49.153835
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict(dict(
        CamelCase=dict(
            HTTPEndpoint='foo',
            TaggedResource=dict(
                Name='foo',
                Tags=dict(
                    Key1='Value1',
                    Key2='Value2',
                )
            )
        )
    ), reversible=True) == {
        'camel_case': {
            'h_t_t_p_endpoint': 'foo',
            'tagged_resource': {
                'name': 'foo',
                'tags': {
                    'Key1': 'Value1',
                    'Key2': 'Value2',
                }
            }
        }
    }



# Generated at 2022-06-11 01:00:03.373996
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:00:11.760333
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('mooCow', False) == 'moo_cow'
    assert _camel_to_snake('MooCow', False) == 'moo_cow'
    assert _camel_to_snake('cowMoo', False) == 'cow_moo'
    assert _camel_to_snake('COWMOO', False) == 'cowmoo'
    assert _camel_to_snake('MooCow', True) == 'm_oo_cow'
    assert _camel_to_snake('HTTPEndpoint', True) == 'h_t_t_p_endpoint'
    assert _camel_to_snake('HTTPEndpoint', False) == 'http_endpoint'

# Generated at 2022-06-11 01:00:16.842832
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    class TestDict(dict):
        pass

    d = TestDict()
    d['HTTPEndpoint'] = TestDict()
    d['HTTPEndpoint']['HTTPMethod'] = 'PUT'
    d['HTTPEndpoint']['TimeoutInSeconds'] = 1
    d['HTTPEndpoint']['Authorization'] = TestDict()
    d['HTTPEndpoint']['Authorization']['SigningRegion'] = 'us-east-1'
    d['HTTPEndpoint']['Authorization']['SigningServiceName'] = 'execute-api'
    d['HTTPEndpoint']['Authorization']['SigningServiceKey'] = 'ASIA1234567890'

# Generated at 2022-06-11 01:00:28.736106
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_data = {
        'camelCase': 'hello',
        'camel_with_snake': 'hello',
        'CapitalizedString': 'hello',
        'ManyCapitalizedString': 'hello',
        'Compound::String': 'hello',
        'tags': [{'Key': 'test_key', 'Value': 'test_value'}]
    }

    expected_results = {
        'camel_case': 'hello',
        'camel_with_snake': 'hello',
        'capitalized_string': 'hello',
        'many_capitalized_string': 'hello',
        'compound::string': 'hello',
        'tags': [{'Key': 'test_key', 'Value': 'test_value'}]
    }
    
    assert camel_dict_to_snake_

# Generated at 2022-06-11 01:00:37.242920
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test a single level dict
    camel_dict = {'firstName': 'Fred'}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['first_name'] == 'Fred', snake_dict

    # Test a dict with a list
    camel_dict = {'firstName': 'Fred', 'lastName': 'Smith', 'pets': ['Dog', 'Cat']}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['first_name'] == 'Fred', snake_dict
    assert snake_dict['last_name'] == 'Smith', snake_dict
    assert snake_dict['pets'][0] == 'Dog', snake_dict
    assert snake_dict['pets'][1] == 'Cat', snake

# Generated at 2022-06-11 01:00:50.065489
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Name': 'test',
        'HTTPEndpoint': {
            'URL': 'https://www.example.com/endpoint',
            'Protocol': 'HTTPS',
            'Method': 'POST',
            'Path': '/post',
            'Auth': {
                'HTTPAuth': 'BASIC',
                'Username': 'username',
                'Password': 'password'
            }
        },
        'SLSCertificateId': 'arn:aws:acm:us-east-1:123456789012:certificate/12345678-1234-1234-1234-123456789012',
        'Tags': {
            'Name': 'test'
        }
    }


# Generated at 2022-06-11 01:00:59.144836
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'FooBar': 1,
        'BarBaz': {
            'Quux': 2,
            'corge': 3,
        },
        'Grault': [
            {
                'Fred': 4,
                'plugh': 5,
            },
            6,
            7,
        ]
    }
    snake_dict = {
        'foo_bar': 1,
        'bar_baz': {
            'quux': 2,
            'corge': 3,
        },
        'grault': [
            {
                'fred': 4,
                'plugh': 5,
            },
            6,
            7,
        ]
    }
    assert snake_dict == camel_dict_to_snake_dict(camel_dict)



# Generated at 2022-06-11 01:01:10.105343
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test var with underscore which will be left as it is
    camel_dict = {'test_var': {'test_1': 'test_1', 'test_2': 'test_2'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict['test_var']['test_1'] == 'test_1'
    assert snake_dict['test_var']['test_2'] == 'test_2'

    # Test var with camel case
    camel_dict = {'testVar': {'test_1': 'test_1', 'test_2': 'test_2'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:01:14.064682
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test case 1: keys are separated by underscore
    test_dict = {
        "Classification": "test_classification",
        "Properties": {
            "MyName": "test_name",
            "MyTestProperty": "test_property"
        }
    }

    expected_dict = {
        "classification": "test_classification",
        "properties": {
            "my_name": "test_name",
            "my_test_property": "test_property"
        }
    }

    assert camel_dict_to_snake_dict(test_dict) == expected_dict

    # Test case 2: keys contain upper case characters

# Generated at 2022-06-11 01:01:23.265527
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Url": "https://example.com",
            "Protocol": "HTTPS"
        },
        "tags": {
            "Name": "MyEC2Instance"
        }
    }

    assert camel_dict_to_snake_dict(camel_dict, reversible=False) == {
        "http_endpoint": {
            "url": "https://example.com",
            "protocol": "HTTPS"
        },
        "tags": {
            "Name": "MyEC2Instance"
        }
    }


# Generated at 2022-06-11 01:01:36.687853
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = range(26)

# Generated at 2022-06-11 01:01:45.592357
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': 0,
        'HTTPEndpoint': {
            'id': 123,
            'url': 'https://example.com/foo/bar',
            'badAss': True,
            'hostPatterns': ['*.example.com', 'example.com'],
            'camelHTTPRoute': {
                'name': 'myHTTPRoute',
                'match': {
                    'prefix': '/foo/bar',
                },
                'action': {
                    'weightedTargets': [
                        {
                            'virtualNode': 'myVirtualNode',
                            'weight': 10,
                         },
                     ],
                },
            },
        },
    }


# Generated at 2022-06-11 01:01:56.238342
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test a simple case
    camel_dict = {"HTTPEndpoint": {"URL": "http://example.com"}}
    expected = {"http_endpoint": {"url": "http://example.com"}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == expected

    # Test a complex case with a camelCase value
    camel_dict = {
        "HTTPEndpoint": {
            "URL": "http://example.com",
            "Protocols": [
                "http/1.1",
                "http/2"
            ]
        },
        "Tags": [
            {
                "Key": "Name",
                "Value": "MyApp"
            }
        ]
    }

# Generated at 2022-06-11 01:02:06.869479
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        'HTTPEndpoint': {'URL': 'http://example.com'},
        'TcpEndpoint': {'Port': 80},
        'Tags': {'AvailabilityZone': 'us-east-1a'},
        'RouteTableIds': ['rtb-12345678'],
        'SubnetIds': ['subnet-12345678']
    }) == {
        'http_endpoint': {'url': 'http://example.com'},
        'tcp_endpoint': {'port': 80},
        'tags': {'AvailabilityZone': 'us-east-1a'},
        'route_table_ids': ['rtb-12345678'],
        'subnet_ids': ['subnet-12345678']
    }


# Unit test

# Generated at 2022-06-11 01:02:19.240200
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test case to make sure dicts are camel cased
    assert camel_dict_to_snake_dict({'myKey': 'value',
                                     'myList': [1, 2, 3],
                                     'myNestedDict': {'myNestedKey': 'nested value'}
                                     }) == {'my_key': 'value',
                                            'my_list': [1, 2, 3],
                                            'my_nested_dict': {'my_nested_key': 'nested value'}
                                            }

    # Test case to make sure dicts are camel cased, with pluralization

# Generated at 2022-06-11 01:02:28.099132
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    original = {
        'MyName': {
            'Key1': {
                'Key2': 'Value'
            }
        }
    }

    snake_expected = {
        'my_name': {
            'key1': {
                'key2': 'Value'
            }
        }
    }

    snake_reversible_expected = {
        'my_name': {
            'key1': {
                'key2': 'Value'
            }
        }
    }

    # Test that the function is doing snake case conversion
    assert camel_dict_to_snake_dict(original) == snake_expected
    # Test that the function is doing snake case conversion for the case where conversion is reversible
    assert camel_dict_to_snake_dict(original, reversible=True) == snake_reversible_expected
   

# Generated at 2022-06-11 01:02:34.511582
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        'DryRun': False,
        'Filters': {
            'string': 'string',
            'string': 'string'
        },
        'MaxResults': 123,
        'NextToken': 'string'
    }

    assert camel_dict_to_snake_dict(test_dict, reversible=False) == {
        'dry_run': False,
        'filters': {
            'string': 'string',
            'string': 'string'
        },
        'max_results': 123,
        'next_token': 'string'
    }, "translating dictionary from camelCase to snake_case failed"


# Generated at 2022-06-11 01:02:40.947101
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'a': 1,
        'b': {
            'c': 2,
        },
        'HTTPEndpoint': 3,
    }

    expected_output = {
        'a': 1,
        'b': {
            'c': 2,
        },
        'h_t_t_p_endpoint': 3,
    }

    converted_output = camel_dict_to_snake_dict(camel_dict)

    assert expected_output == converted_output

# Generated at 2022-06-11 01:02:53.387180
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'Ec2InstanceIds': ['i-1234567890abcdef0', 'i-fedcba0987654321'],
        'Foo': 'Bar',
        'BazBam': [{'Quux': 'Quuz'}, {'Corge': 'Grault'}],
        'Garply': ''
    }

    snake_dict = {
        'ec2_instance_ids': ['i-1234567890abcdef0', 'i-fedcba0987654321'],
        'foo': 'Bar',
        'baz_bam': [{'quux': 'Quuz'}, {'corge': 'Grault'}],
        'garply': ''
    }


# Generated at 2022-06-11 01:03:04.318850
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict_in = dict(HTTPEndpoint=dict(List=[1, 2, 3], Dict={'a': 1, 'b': 2}),
                   HTTPCookie=dict(List=[4, 5, 6], Dict={'c': 3, 'd': 4}))
    dict_out = camel_dict_to_snake_dict(dict_in)

    assert (dict_out == dict(h_t_t_p_endpoint=dict(list=[1, 2, 3], dict={'a': 1, 'b': 2}),
                              http_cookie=dict(list=[4, 5, 6], dict={'c': 3, 'd': 4})))

# Generated at 2022-06-11 01:03:17.929638
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:28.254599
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Define a simple dict to test
    test_payload = {
        "vpcId": "",
        "t2": {
            "bur": "rur"
        },
        "blob": {
            "test": {
                "test": "test"
            }
        }
    }

    # Recursively apply the transform
    test_dict = camel_dict_to_snake_dict(test_payload)

    # Ensure the resulting dict contains all expected transforms
    assert test_dict['vpc_id'] == ''
    assert test_dict['t2']['bur'] == 'rur'
    assert test_dict['blob']['test']['test'] == 'test'



# Generated at 2022-06-11 01:03:39.753155
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Test camel_dict_to_snake_dict with different types of values"""

    camel_dict = {
        'HTTPEndpoint': {
            'SubPath': 'http_endpoint',
            'TargetGroupARNs': ['target_group_ar_ns']
        },
        'HTTPSEndpoint': {
            'SubPath': 'https_endpoint',
            'TargetGroupARNs': ['target_group_ar_ns']
        },
        'Id': 'id',
        'Name': 'name',
        'Tags': {
            'Key': 'value',
            'Key1': 'value1'
        }
    }


# Generated at 2022-06-11 01:03:48.510685
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    data = {
        "foo": {
            "barBaz": [
                "qux",
                "quux"
            ],
            "corgeGrault": {
                "garplyWaldo": "fred",
                "plughXyzzy": [
                    "thud"
                ]
            }
        }
    }

    assert camel_dict_to_snake_dict(data) == {
        "foo": {
            "bar_baz": [
                "qux",
                "quux"
            ],
            "corge_grault": {
                "garply_waldo": "fred",
                "plugh_xyzzy": [
                    "thud"
                ]
            }
        }
    }


# Generated at 2022-06-11 01:03:59.275357
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Test scalar values
    assert camel_dict_to_snake_dict({'CamelCase': 'value'}) == {'camel_case': 'value'}
    assert camel_dict_to_snake_dict({'CamelCase': 'value', 'camelCase': 'value'}) == {'camel_case': 'value', 'camel_case1': 'value'}
    assert camel_dict_to_snake_dict({'camelCase': 'value'}) == {'camel_case': 'value'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'value'}) == {'h_t_t_p_endpoint': 'value'}
    # Key as a list

# Generated at 2022-06-11 01:04:07.104812
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    original_dict = {"Route53HostedZoneId": "ABCDEFG", "VpcId": "12345",
                     "AutoUsePreviousTemplate": False, "Tags": {"Key1": "Value1", "Key2": "Value2"}}
    expected_dict = {"route53_hosted_zone_id": "ABCDEFG", "vpc_id": "12345",
                     "auto_use_previous_template": False, "tags": {"Key1": "Value1", "Key2": "Value2"}}
    assert (camel_dict_to_snake_dict(original_dict, False) == expected_dict)

# Generated at 2022-06-11 01:04:18.241590
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'AMIsFromLaunchConfig': '', 'Config': {}, 'LaunchConfig': '',
                  'LaunchConfigNames': ['ExampleName'], 'Tagged': False,
                  'Tags': {'tag-1': 'value-1', 'tag-2': 'value-2'}, 'TonsOfKeys': True}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    expected = {'amis_from_launch_config': '', 'config': {}, 'launch_config': '',
                'launch_config_names': ['ExampleName'], 'tagged': False,
                'tags': {'tag-1': 'value-1', 'tag-2': 'value-2'}, 'tons_of_keys': True}
    assert snake_dict == expected
    # When reversible

# Generated at 2022-06-11 01:04:29.001906
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {'MyKey': 'my_value', 'HTTPRedirectCode': 'http_redirect_code',
                 'CreationDate': 'creation_date', 'Tags': {'Key': 'Name', 'Value': 'Ansible-Test'},
                 'Credentials': {'AccessKeyId': 'access_key_id',
                                 'SecretAccessKey': 'secret_access_key'}}

    print("Running tests on function camel_dict_to_snake_dict:")

    # Test dictionary conversion to snake_case
    assert test_dict == camel_dict_to_snake_dict(camel_dict_to_snake_dict(test_dict))

    # Test conversion of an empty dictionary
    assert camel_dict_to_snake_dict({}) == {}

    # Test removal of keys in the

# Generated at 2022-06-11 01:04:36.910836
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:04:47.651207
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'InstanceIds': ['i-1', 'i-2'], 'BackupIds': ['b-1', 'b-2'], 'Tags': [{'Key': 'Key1', 'Value': 'Value1'}, {'Key': 'Key2', 'Value': 'Value2'}]}
    expected_result = {'instance_ids': ['i-1', 'i-2'], 'backup_ids': ['b-1', 'b-2'], 'tags': [{'Key': 'Key1', 'Value': 'Value1'}, {'Key': 'Key2', 'Value': 'Value2'}]}
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected_result


# Generated at 2022-06-11 01:05:02.527311
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict(
        {"fooBar": 1, "fooBarBazQux": 2},
    ) == {
        'foo_bar': 1,
        'foo_bar_baz_qux': 2,
    }
    assert camel_dict_to_snake_dict(
        {"fooBar": 1, "fooBarBazQux": 2},
        reversible=True
    ) == {
        'foo_b_ar': 1,
        'foo_b_ar_baz_q_ux': 2
    }

# Generated at 2022-06-11 01:05:10.094555
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_list = [{'TagKey': 'A'}, {'TagKey': 'B'}]
    camel_dict = {'String': 'string', 'Number': 10,
                  'Key': 'value', 'Boolean': True,
                  'TestTags': camel_list}

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    expected_snake_dict = {'string': 'string', 'number': 10,
                           'key': 'value', 'boolean': True,
                           'test_tags': camel_list}

    assert(snake_dict == expected_snake_dict)



# Generated at 2022-06-11 01:05:17.967843
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_case = {'KeyName': 'test_key_name', 'Tags': [
        {'Key': 'foo', 'Value': 'bar'}, {'Key': 'foo2', 'Value': 'bar2'}]}
    expected = {'key_name': 'test_key_name', 'tags': [
        {'key': 'foo', 'value': 'bar'}, {'key': 'foo2', 'value': 'bar2'}]}
    actual = camel_dict_to_snake_dict(test_case, ignore_list=('Tags',))

    assert expected == actual


# Generated at 2022-06-11 01:05:20.724285
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'thisIsCamel': 'test'}) == {'this_is_camel': 'test'}

# Generated at 2022-06-11 01:05:30.617008
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'VpnGatewayId': 'vgw-12345678',
        'VpcId': 'vpc-abcd1234',
        'Tags': {'Name': 'example_tag'},
        'VpnConnection': {
            'VpnConnectionId': 'vpn-abcd1234',
            'CustomerGatewayConfiguration': 'customer_gateway_configuration',
            'Tags': {'Name': 'example_tag'}
        }
    }

    # Convert to snake_case - should be identical to camel_dict as it's a one-way conversion
    new_dict = camel_dict_to_snake_dict(camel_dict)
    assert new_dict == camel_dict

    # Convert to snake_case with reversible=True - should be different to camel_dict
    new_dict

# Generated at 2022-06-11 01:05:41.402256
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict_1 = dict(FooBar=dict(High=dict(
        HTTPEndpoint="foo.com",
        HTTPSRedirect="False",
    ), Low=dict(
        HTTPEndpoint="bar.com",
        HTTPSRedirect="False",
    )), Tags=dict(
        BarTag='B',
        FooTag='F',
    ), Description="Created by Foo", FooRoleArn="arn:aws:foo:bar:baz/*")

# Generated at 2022-06-11 01:05:52.613955
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "TargetGroups": [
            {
                "HealthCheckPort": "traffic-port",
                "HealthCheckProtocol": "HTTP",
                "HealthCheckTimeoutSeconds": 5,
                "HealthyThresholdCount": 5,
                "Matcher": {
                    "HttpCode": "200-299"
                },
                "Port": 80,
                "Protocol": "HTTP",
                "TargetGroupName": "test-target-group-name",
                "UnhealthyThresholdCount": 2,
                "VpcId": "vpc-abcd1234"
            }
        ],
        "TargetType": "instance",
        "TrafficPort": 80,
        "VpcId": "vpc-abcd1234"
    }


# Generated at 2022-06-11 01:06:01.439343
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'myData': {'myName': 'myValue'}, 'myList': [{'myDataA': 'A', 'myDataB': 'B'}]}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)
    # assert snake_dict.keys() == ['my_data', 'my_list']
    assert snake_dict['my_data']['my_name'] == 'myValue'
    assert snake_dict['my_list'][0]['my_data_a'] == 'A'
    assert snake_dict['my_list'][0]['my_data_b'] == 'B'


# Generated at 2022-06-11 01:06:10.519742
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:20.966192
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    array_test = [
        {
            "Name": "MyWebServer",
            "ImageId": "ami-ed06a284",
            "SecurityGroups": [
                "quick-start-1",
                "quick-start-2"
            ],
            "InstanceType": "t2.micro"
        }
    ]
    array_test_snake = [
        {
            "name": "MyWebServer",
            "image_id": "ami-ed06a284",
            "security_groups": [
                "quick-start-1",
                "quick-start-2"
            ],
            "instance_type": "t2.micro"
        }
    ]
    assert camel_dict_to_snake_dict(array_test) == array_test_snake
    assert snake_dict_to

# Generated at 2022-06-11 01:06:39.376338
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'URL': 'http://example.org',
                                   'Any': 'anything'},
                  'CLUSTER': {'Arn': 'arn:aws:example',
                              'Any': 'anything'},
                  'SomeKey': 'somevalue',
                  'SomeKey2': {'Any': 'anything'},
                  'Tags': {'Key': 'value'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)


# Generated at 2022-06-11 01:06:46.572652
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'string': 'string',
        'int': 1,
        'float': 1.1,
        'complex': {
            'complexString': 'complexString',
            'complexInt': 1,
            'complexList': [{
                'complexNestedString': 'complexNestedString'
            }]
        },
        'list': [{
            'listString': 'listString'
        }]
    }

# Generated at 2022-06-11 01:06:56.718676
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'Bucket': 'something',
        'TimeLimit': 10,
        'TimeLimitToLive': True,
        'TimeLimitDict': {
            'TimeLimitDict2': 'somethigelse'
        },
        'HTTPEndpoint': 'somesite'
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict, False)
    assert snake_dict['http_endpoint'] == 'somesite'

    snake_dict = camel_dict_to_snake_dict(camel_dict, True)
    assert snake_dict['h_t_t_p_endpoint'] == 'somesite'

    # Tags is case-sensitive, so we need to add it to the ignore_list

# Generated at 2022-06-11 01:07:07.312664
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input_1 = {"AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{"Sid": "", "Effect": "Allow", "Principal": {"Service": "ec2.amazonaws.com"}, "Action": "sts:AssumeRole"}]}, "Path": "/", "RoleName": "role_for_ec2"}
    assert camel_dict_to_snake_dict(input_1) == {'path': '/', 'role_name': 'role_for_ec2', 'assume_role_policy_document': {'version': '2012-10-17', 'statement': [{'sid': '', 'effect': 'Allow', 'principal': {'service': 'ec2.amazonaws.com'}, 'action': 'sts:AssumeRole'}]}}
    assert camel_dict_to_

# Generated at 2022-06-11 01:07:14.781003
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:23.159491
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:29.678439
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "Enabled": True,
        }
    }
    expected_snake_dict = {
        "h_t_t_p_endpoint": {
            "enabled": True,
        }
    }

    assert camel_dict_to_snake_dict(camel_dict, reversible=False) == expected_snake_dict
    assert camel_dict_to_snake_dict(camel_dict, reversible=True) == {"h_t_t_p_end_point": {"enabled": True}}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": {"Enabled": True}}, reversible=False) == expected_snake_dict

# Generated at 2022-06-11 01:07:40.463245
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    data = {
        "stringProperty": "string_value",
        "intProperty": 42,
        "nestedProperty": {
            "stringProperty": "another_string_value",
            "intProperty": 1337,
            "listProperty": [
                {"stringProperty": "nested_string_value1"},
                {"stringProperty": "nested_string_value2"},
            ]
        },
        "listProperty": [
            {"stringProperty": "nested_string_value1"},
            {"stringProperty": "nested_string_value2"},
        ]
    }


# Generated at 2022-06-11 01:07:50.230254
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    def deepcmp(dict1, dict2):
        dict1_keys = sorted(dict1.keys())
        dict2_keys = sorted(dict2.keys())
        if dict1_keys != dict2_keys:
            return False
        for key in dict1_keys:
            if isinstance(dict1[key], dict) and isinstance(dict2[key], dict):
                if not deepcmp(dict1[key], dict2[key]):
                    return False
            elif isinstance(dict1[key], list) and isinstance(dict2[key], list):
                if not deepcmp(dict1[key], dict2[key]):
                    return False
            elif dict1[key] != dict2[key]:
                return False
        return True


# Generated at 2022-06-11 01:07:58.663301
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Standard test case
    camel_dict = {'fooBar': 'fooBar', 'bazQuux': {'fooBar': 'fooBar'}}
    expected_result = {'foo_bar': 'fooBar', 'baz_quux': {'foo_bar': 'fooBar'}}
    assert camel_dict_to_snake_dict(camel_dict) == expected_result

    # special case of a key that is all uppercase, to show that it is
    # downcased but that the first letter remains capitalized
    camel_dict = {'TAGS': 'fooBar', 'bazQuux': {'fooBar': 'fooBar'}}
    expected_result = {'t_a_g_s': 'fooBar', 'baz_quux': {'foo_bar': 'fooBar'}}