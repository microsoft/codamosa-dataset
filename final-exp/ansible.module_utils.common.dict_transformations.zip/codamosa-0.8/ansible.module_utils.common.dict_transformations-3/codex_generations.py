

# Generated at 2022-06-11 00:58:29.783958
# Unit test for function recursive_diff

# Generated at 2022-06-11 00:58:39.496151
# Unit test for function recursive_diff
def test_recursive_diff():
    """Returns unittest.TestCase for recursive_diff."""

    import unittest

    class TestRecursiveDiff(unittest.TestCase):
        """TestCase class for recursive_diff function."""

        def test_empty_dicts(self):
            """Test recursive_diff on empty dictionaries."""

            actual = recursive_diff({}, {})
            expected = None
            self.assertEqual(actual, expected)

        def test_one_empty_dict(self):
            """Test recursive_diff on one empty dictionary."""

            actual = recursive_diff({'a': 1}, {})
            expected = ({'a': 1}, {})
            self.assertEqual(actual, expected)

            actual = recursive_diff({}, {'a': 1})
            expected = ({}, {'a': 1})

# Generated at 2022-06-11 00:58:50.401568
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dicts = [{'Tags': [{'Key': 'Name', 'Value': 'test-instance'}], 'SubnetId': 'subnet-0f76f3a3'},
                  {'Placement': {'AvailabilityZone': 'us-east-1e', 'GroupName': None}, 'Tags': [{'Key': 'Name', 'Value': 'test-instance'}], 'SubnetId': 'subnet-0f76f3a3'},
                  {'Placement': {'AvailabilityZone': 'us-east-1e', 'GroupName': None}, 'Tags': [{'Key': 'Name', 'Value': 'test-instance'}], 'SubnetId': 'subnet-0f76f3a3'}]


# Generated at 2022-06-11 00:59:01.543992
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    #initializing test data
    camel_dict = {}
    camel_dict['testCamelKey'] = 'testCamelValue'
    camel_dict['testCamelList'] = ['testCamelListValue1', 'testCamelListValue2']
    camel_dict['testCamelDict'] = {}
    camel_dict['testCamelDict']['testCamelKey'] = 'testCamelValue'
    camel_dict['testCamelDict']['testCamelList'] = ['testCamelListValue1', 'testCamelListValue2']
    camel_dict['testCamelDictList'] = [{},{}]
    camel_dict['testCamelDictList'][0]['testCamelKey'] = 'testCamelValue'

# Generated at 2022-06-11 00:59:12.034366
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 00:59:21.676256
# Unit test for function recursive_diff
def test_recursive_diff():
    """Test function recursive_diff behavior."""
    # pylint: disable=too-many-branches


# Generated at 2022-06-11 00:59:33.100438
# Unit test for function recursive_diff
def test_recursive_diff():
    # Test empty dicts
    assert recursive_diff({}, {}) is None

    # Test dicts with only top-level items
    dict1 = {'key1': 'value1', 'key2': 'value2'}
    dict2 = {'key1': 'value1', 'key2': 'value2'}
    assert recursive_diff(dict1, dict2) is None

    dict1 = {'key1': 'value1', 'key2': 'value2'}
    dict2 = {'key1': 'value1', 'key2': 'value3'}
    expect_left = {'key2': 'value2'}
    expect_right = {'key2': 'value3'}
    result = recursive_diff(dict1, dict2)
    assert result[0] == expect_left

# Generated at 2022-06-11 00:59:43.920950
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) is None

    assert recursive_diff({'a': 1}, {'a': 1}) is None

    assert recursive_diff({'a': 1}, {'a': 2}) == ({'a': 1}, {'a': 2})

    assert recursive_diff({'a': 1}, {'b': 2}) == ({}, {'a': 1, 'b': 2})

    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 3}) == ({'b': 2}, {'b': 3})

    assert recursive_diff({'a': 1, 'b': 2}, {'a': 1, 'b': 3, 'c': 4}) == ({'b': 2}, {'b': 3, 'c': 4})


# Generated at 2022-06-11 00:59:50.700685
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # Simple case
    a = {'Name': 'my-aws-instance', 'HTTPEndpoint': {'Path': '/my/path'}}
    b = camel_dict_to_snake_dict(a)
    assert b == {'http_endpoint': {'path': '/my/path'}, 'name': 'my-aws-instance'}

    # Reversible
    elb = {'LoadBalancerArn': 'arn:thing', 'LoadBalancerName': 'name', 'TargetGroupARNs': ['arn1', 'arn2']}
    snake = camel_dict_to_snake_dict(elb, True)
    camel = snake_dict_to_camel_dict(snake, True)

# Generated at 2022-06-11 01:00:02.560399
# Unit test for function recursive_diff
def test_recursive_diff():
    assert recursive_diff({}, {}) == None
    # examples from https://gist.github.com/miniupnp/4e0a732b5c8d8e01eeba
    assert recursive_diff(
        {}, {'hello': 'world', 'toto': None, 'foo': 'bar'}
    ) == ({}, {'hello': 'world', 'toto': None, 'foo': 'bar'})

# Generated at 2022-06-11 01:00:16.937360
# Unit test for function recursive_diff
def test_recursive_diff():
    # No differences between the two dictionaries
    foo = { "a": 1 }
    bar = { "a": 1 }
    result = recursive_diff(foo,bar)
    assert result == None
    # No differences between the two dictionaries
    foo = { "a": 1, "b" : { "c": 1, "d" : 2 } }
    bar = { "a": 1, "b" : { "c": 1, "d" : 2 } }
    result = recursive_diff(foo,bar)
    assert result == None
    # # Differences between the two dictionaries
    foo = { "a": 1, "b" : { "c": 1, "d" : 2 } }
    bar = { "a": 1, "b" : { "c": 3, "d" : 2 } }
    result = recursive_

# Generated at 2022-06-11 01:00:28.739276
# Unit test for function recursive_diff
def test_recursive_diff():
    import json

    # Simple tests
    assert recursive_diff({}, {}) == None
    assert recursive_diff({}, {"a": 1}) == ({}, {"a": 1})
    assert recursive_diff({"a": 1}, {}) == ({"a": 1}, {})
    assert recursive_diff({"a": 1}, {"a": 2}) == ({"a": 1}, {"a": 2})
    assert recursive_diff({"a": 1}, {"a": 1}) == None

    # Simple test with nested dicts
    assert recursive_diff({"a": {"b": "c"}}, {"a": {"b": "d"}}) == ({}, {"a": {"b": "d"}})

# Generated at 2022-06-11 01:00:37.271803
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_dict = {
        "HTTPEndpoint": {
            "EndpointURL": 'https://foo.com/bar',
            "Protocol": 'HTTPS',
            "AuthType": 'AWS_IAM',
            "Permission": {
                "Principal": {
                    "Service": "s3.amazonaws.com"
                }
            }
        },
        "Id": 'test_id',
        "Description": "test_description",
        "RetryingDelivery": False,
        "Tags": {
            "test_tag": "test_description_1",
            "test_tag_2": "test_description_2"
        }
    }


# Generated at 2022-06-11 01:00:50.066015
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel = {'FooBar': 1, 'HTTPEndpoint': 2, 'TargetGroupARNs': [3]}
    snake = {'foo_bar': 1, 'target_group_arns': [3], 'h_t_t_p_endpoint': 2}
    assert camel_dict_to_snake_dict(camel, reversible=False) == snake
    assert camel_dict_to_snake_dict(camel, True) == {'foo_bar': 1,
                                                    'h_t_t_p_endpoint': 2,
                                                    'target_group_arns': [3]}
    # Test that tags have not been converted
    camel['Tags'] = {'foo': 'bar'}

# Generated at 2022-06-11 01:00:59.117259
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test = {
        'key1': 'val1',
        'keyB': 'valB',
        'keyC': 2,
        'key3': '',
        'key4': None,
        'key5': {'keyA': 'valA'},
        'key6': [],
        'key7': [{'keyA': 'valA'}],
        'key8': [{'keyA': 'valA', 'keyB': 'valB'}],
        'key9': [{'keyA': ['valA']}]
    }


# Generated at 2022-06-11 01:01:10.053787
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    samples = {"camel": {"A": 1, "B": 2},
               "pascal": {"a": 1, "b": 2},
               "mixedcase": {"A": 1, "B": 2},
               "hypenation": {"a-b": 1, "b-c": 2},
               "capital": {"A": {"B": 1}},
               "tree": {"A": {"B": {"C": 1, "D": 2}, "E": {"F": 3, "G": 4}}}
              }

    res = camel_dict_to_snake_dict(samples["camel"], reversible=True)
    assert res == {"a": 1, "b": 2}

    res = camel_dict_to_snake_dict(samples["pascal"], reversible=True)

# Generated at 2022-06-11 01:01:20.486682
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:01:32.098081
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': 'TestEndpoint',
        'ExtraArgs': {
            'extra': 'args',
            'some-more': 'extra-args'
        },
        'Environment': {
            'variables': {
                'VAR1': 'var1-value',
                'VAR2': 'var2-value',
            }
        },
        'ServiceName': 'test-service',
        'Image': 'test-image'
    }


# Generated at 2022-06-11 01:01:42.074203
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict1 = {
        'HTTPEndpoint': {
            'HTTPPath': '/',
            'Endpoint': {
                'Kinesis': {
                    'StreamName': 'test-stream'
                }
            }
        },
        'Tags': {
            "foo": "bar"
        },
    }

    # dict 1 - reversible=False, ignore_list=()
    snake_dict = camel_dict_to_snake_dict(camel_dict1, reversible=False)

# Generated at 2022-06-11 01:01:49.172694
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "test"}, reversible=False) == {"http_endpoint": "test"}
    assert camel_dict_to_snake_dict({"HTTPEndpoint": "test"}, reversible=True) == {"h_t_t_p_endpoint": "test"}
    assert camel_dict_to_snake_dict({"Tags": {"HTTPEndpoint": "test"}}, reversible=False) == {"tags": {"http_endpoint": "test"}}
    assert camel_dict_to_snake_dict({"Tags": {"HTTPEndpoint": "test"}}, reversible=True) == {"tags": {"HTTPEndpoint": "test"}}

# Generated at 2022-06-11 01:02:00.441831
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "HTTPEndpoint": {
            "HTTPEndpointConfiguration": {
                "URL": "https://foo.bar",
                "Authorization": {
                    "Type": "AWS_HMAC",
                    "AuthorizationParameter": "SOMEAWSKEY"
                },
                "RetryOptions": {
                    "DurationInSeconds": 200
                }
            }
        }
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:02:11.931153
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    fake_dict = {'VpcId': 'vpc-abcdefg',
                 'UserData': '#!/bin/sh',
                 'HTTPEndpoint': 1,
                 'Tags': {'Name': 'testname'}}
    snake_dict = camel_dict_to_snake_dict(fake_dict)
    assert snake_dict == {'vpc_id': 'vpc-abcdefg',
                          'user_data': '#!/bin/sh',
                          'h_t_t_p_endpoint': 1,
                          'tags': {'Name': 'testname'}}
    # Now reverse
    camel_dict = snake_dict_to_camel_dict(snake_dict)
    assert camel_dict == fake_dict



# Generated at 2022-06-11 01:02:23.157777
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Url': 'url', 'Timeout': 'timeout'}, 'HTTPEndpointArn': 'arn'}, True) == {'h_t_t_p_endpoint': {'url': 'url', 'timeout': 'timeout'}, 'h_t_t_p_endpoint_arn': 'arn'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'Url': 'url', 'Timeout': 'timeout'}, 'HTTPEndpointArn': 'arn'}, False) == {'http_endpoint': {'url': 'url', 'timeout': 'timeout'}, 'http_endpoint_arn': 'arn'}

# Generated at 2022-06-11 01:02:31.386763
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    dict1 = {'a': {'b': 'c'}, 'A': {'b': {'c': 'd'}}}
    dict2 = {'a': {'b': 'c'}, 'a_a': {'b': {'c': 'd'}}}
    assert camel_dict_to_snake_dict(dict1) == dict2

    dict1 = {'Tags': {'a': {'a': 'b'}}, 'reversible': True}
    dict2 = {'tags': {'a': {'a': 'b'}}, 'reversible': True}
    assert camel_dict_to_snake_dict(dict1, reversible=True) == dict2

    dict1 = {'a': {'b': [12, 'a']}}

# Generated at 2022-06-11 01:02:34.988210
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    input = {'ThisIsACamelCaseKey': 'aValue'}
    result = {'this_is_a_camel_case_key': 'aValue'}

    actual = camel_dict_to_snake_dict(input)

    assert actual == result



# Generated at 2022-06-11 01:02:43.485222
# Unit test for function recursive_diff
def test_recursive_diff():
    """recursive_diff should return the expected difference between the two given dictionaries"""
    dict1 = {'k1':'v1', 'k2':{'k3':'v3', 'k4':'v4'}, 'k5':'v6'}
    # The expected result is to return the value of k6 in the second dictionary and
    # the value of k3 in the second dictionary which is different from the first dictionary.
    dict2 = {'k1':'v1', 'k2':{'k3':'diff', 'k6':'v6'}, 'k5':'v6'}
    result = recursive_diff(dict1, dict2)

# Generated at 2022-06-11 01:02:55.286488
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:05.851329
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:03:17.671074
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert _camel_to_snake('TargetGroups') == 'target_groups'
    assert _camel_to_snake('TargetGroupARNs') == 'target_group_ar_ns'

    assert _camel_to_snake('TargetGroups', reversible=True) == 'target_g_roups'
    assert _camel_to_snake('TargetGroupARNs', reversible=True) == 'target_g_roup_a_rns'

    assert _snake_to_camel("target_group_ar_ns", capitalize_first=True) == 'TargetGroupARNs'

    assert _snake_to_camel("target_group_ar_ns") == 'targetGroupARNs'

# Generated at 2022-06-11 01:03:28.773863
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert(camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'})
    assert(camel_dict_to_snake_dict({'fooBar': {'batBaz': 'qux'}}) == {'foo_bar': {'bat_baz': 'qux'}})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint': 'baz'}) == {'h_t_t_p_endpoint': 'baz'})
    assert(camel_dict_to_snake_dict({'HTTPEndpoint': {'batBaz': 'qux'}}) ==
           {'h_t_t_p_endpoint': {'bat_baz': 'qux'}})

# Generated at 2022-06-11 01:03:42.046191
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {"Key1": "Value1",
                  "Key2": "Value2",
                  "Key3": "Value3",
                  "Key4": "Value4",
                  "Key5": "Value5",
                  "key6": "Value6",
                  "HTTPEndpoint": "http://www.test.com",
                  "tags": [
                      {"key": "value"},
                      {"key": "value"}
                  ]
                  }


# Generated at 2022-06-11 01:03:50.217959
# Unit test for function recursive_diff
def test_recursive_diff():
    """
    Unit test for function recursive_diff
    """
    # Tests
    # Test 1
    # Initialize source dictionary
    source = {
        "A": {
            "A1": "Hello",
            "A2": "World"
        },
        "B": {
            "B1": "Hello",
            "B2": "World"
        },
        "C": {
            "C1": "Hello",
            "C2": "World"
        }
    }

    # Initialize destination dictionary

# Generated at 2022-06-11 01:04:01.605656
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import unittest
    import json
    import os

    sample_file = os.path.join(os.path.dirname(__file__), 'sample_camel_data.json')
    with open(sample_file) as f:
        data = json.load(f)

    class TestCamelDictToSnakeDict(unittest.TestCase):

        def test_snake_camel(self):
            """Test with our data, checking if 'reversible' works"""
            result = camel_dict_to_snake_dict(data, reversible=True)
            self.assertEqual(result['h_t_t_p_endpoint'], data['HTTPEndpoint'])
            self.assertNotEqual(result['h_t_t_p_endpoint'], 'HTTPEndpoint')

# Generated at 2022-06-11 01:04:08.086329
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        HTTPEndpoint=dict(
            Description="Another endpoint",
            RouterRef="CamelRouterRef",
            Scheme="https",
            URI="host.com"
        )
    )
    expected = dict(
        h_t_t_p_endpoint=dict(
            description="Another endpoint",
            router_ref="CamelRouterRef",
            scheme="https",
            uri="host.com"
        )
    )
    assert camel_dict_to_snake_dict(camel_dict) == expected


# Generated at 2022-06-11 01:04:19.051815
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "HTTPEndpoint": {
            "Tags": {
                "Foo": "bar",
                "Baz": "qux"
            }
        }
    }
    expected_output = {
        "h_t_t_p_endpoint": {
            "tags": {
                "Foo": "bar",
                "Baz": "qux"
            }
        }
    }
    assert expected_output == camel_dict_to_snake_dict(test_dict)

    test_list = [
        {
            "Tags": {
                "Foo": "bar",
                "Baz": "qux"
            }
        }
    ]

# Generated at 2022-06-11 01:04:29.722425
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test standard camel case is converted as expected
    camel_dict = {
        'hTTPEndpoint' : {
            'endPoint' : '10.0.0.1'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict)

    assert len(snake_dict) == 1, 'Output snake_dict has the wrong number of keys'
    assert 'h_t_t_p_endpoint' in snake_dict, 'Key not converted as expected'

    # Test reversed camel case is converted as expected
    camel_dict = {
        'HTTPEndpoint' : {
            'EndPoint' : '10.0.0.1'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict, True)

   

# Generated at 2022-06-11 01:04:37.336388
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import pytest

# Generated at 2022-06-11 01:04:47.968152
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        'camelCaseKey': 'camelCaseValue',
        'camelCaseList': [
            'camelCaseList_ListValue1',
            'camelCaseList_ListValue2',
            {
                'camelCaseList_DictValue1Key': 'camelCaseList_DictValue1Value'
            }
        ],
        'camelCase': {
            'subCamelCaseKey': 'subCamelCaseValue'
        }
    }


# Generated at 2022-06-11 01:04:57.339864
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {"test": {"inner": {"test": "test"}}}
    dict2 = {"test": {"inner": {"test2": "test2"}}}
    result = recursive_diff(dict1, dict2)
    assert(result[0] == {"test": {"inner": {"test": "test"}}})
    assert(result[1] == {"test": {"inner": {"test2": "test2"}}})

    result = recursive_diff(dict1, {})
    assert(result[0] == {})
    assert(result[1] == {})

    result = recursive_diff({}, dict2)
    assert(result[0] == {})
    assert(result[1] == {})

    result = recursive_diff(dict1, dict1)
    assert(result == None)

# Generated at 2022-06-11 01:05:06.973093
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {
        'a': 1,
        'c': 2,
        'd': {
            'd1': 1,
            'd2': 2,
        },
        'e': 3,
    }
    dict2 = {
        'a': 1,
        'b': 2,
        'd': {
            'd1': 1,
            'd3': 2,
        },
        'e': 3,
    }
    assert recursive_diff(dict1, dict2) == ({'c': 2}, {'b': 2})
    assert recursive_diff(dict1, dict1) == None
    try:
        recursive_diff(dict1, [])
        assert False, "TypeError was not raised"
    except TypeError:
        pass

# Generated at 2022-06-11 01:05:19.049436
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {
        "MyCamelKey": "value",
        "tags": {"Key": "Value"},
        "SubnetId": "subnet-12345678",
        "NextToken": "nextToken",
        "SecurityGroups": ["sg-12345678","sg-23456789"],
        "HTTPHeaders": [{"HTTPHeaderKey": "HTTPHeaderValue"}],
        "Policies": [{"Name": "PolicyName", "PolicyDocument": {"Key": "Value"}}],
        "VPCID": "vpc-12345678",
        "Tags": {
            "KeyName1": "value",
            "KeyName2": "value"
        }
    }

# Generated at 2022-06-11 01:05:29.781176
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'Stuff': {
            'NestedStuff': None
        },
        'HTTPListenerArns': [
            'arn:some_arn'
        ],
        'HTTPTargetGroupARNs': [
            'arn:some_other_arn'
        ],
        'TagSpecifications': {
            'Tags': {
                'tagKey': 'tagValue'
            }
        }
    }

# Generated at 2022-06-11 01:05:40.094084
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    d = {"fooBar": [{"fooBaz": "fooBazinga"}],
         "barBaz": [{"fooBar": "fooBazinga"}],
         "Tags": [{"Key": "key1", "Value": "val1"}]}
    assert camel_dict_to_snake_dict(d) == {'foo_bar': [{'foo_baz': 'fooBazinga'}],
                                           'bar_baz': [{'foo_bar': 'fooBazinga'}],
                                           'tags': [{'key': 'key1', 'value': 'val1'}]}, \
        "Converted dict is not equal to expected dict"

# Generated at 2022-06-11 01:05:51.768150
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    #Test with simple input
    input_dict = {'fooBar': True, 'thisIsATest': 'test', 'thisIsAnotherTest': 100}
    expected_output = {'foo_bar': True, 'this_is_a_test': 'test', 'this_is_another_test': 100}
    assert camel_dict_to_snake_dict(input_dict) == expected_output

    #Test with nested dictionary
    input_dict = {'fooBar': True, 'thisIsATest': 'test', 'thisIsAnotherTest': 100, 'Items': {'fooBar': True, 'thisIsATest': 'test', 'thisIsAnotherTest': 100}}
    output_dict = camel_dict_to_snake_dict(input_dict)

# Generated at 2022-06-11 01:06:01.524973
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:09.414145
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected = {
        'auto_assign_private_ips': True,
        'map_public_ip_on_launch': True,
        'security_groups': ['default'],
        'subnet_id': 'subnet-1a2b3c4d'
    }
    camel_dict = {
        'autoAssignPrivateIPs': True,
        'mapPublicIpOnLaunch': True,
        'securityGroups': ['default'],
        'subnetId': 'subnet-1a2b3c4d'
    }
    result = camel_dict_to_snake_dict(camel_dict)
    assert result == expected


# Generated at 2022-06-11 01:06:16.060712
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'ClaimsPrincipal': {
            'Kind': 'Internet',
            'Properties': {
                'Provider': 'Google',
                'Account': 'test@test.com'
            }
        }
    }

    assert camel_dict_to_snake_dict(camel_dict) == {
        'claims_principal': {
            'kind': 'Internet',
            'properties': {
                'provider': 'Google',
                'account': 'test@test.com'
            }
        }
    }



# Generated at 2022-06-11 01:06:26.380811
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'fooString': 'stringData',
                  'fooInteger': 42,
                  'fooDouble': 3.14159,
                  'fooBoolean': True,
                  'fooDict': {'foo': 'bar', 'baz': 'qux'},
                  'fooList': [1, 2, 3, 4]}

    snake_dict = {'foo_string': 'stringData',
                  'foo_integer': 42,
                  'foo_double': 3.14159,
                  'foo_boolean': True,
                  'foo_dict': {'foo': 'bar', 'baz': 'qux'},
                  'foo_list': [1, 2, 3, 4]}

    assert(camel_dict_to_snake_dict(camel_dict) == snake_dict)

# Generated at 2022-06-11 01:06:35.457414
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        "instances": [
            {
                "region": "eu-west-1",
                "instanceId": "i-0123456789abcdefg",
                "instanceType": "c4.large",
                "vpcId": "vpc-0123456789abcdefg",
                "subnetId": "subnet-0123456789abcdefg"
            }
        ]
    }

# Generated at 2022-06-11 01:06:43.914314
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:57.082768
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(Foo="bar", IAmCamelCase="baz")
    assert(camel_dict_to_snake_dict(camel_dict) == dict(foo="bar", i_am_camel_case="baz"))
    camel_dict = dict(Foo="bar", IAmCamelCase="baz", Tags={"foo": "bar", "foo1": "bar1"})
    assert(camel_dict_to_snake_dict(camel_dict) == dict(foo="bar", i_am_camel_case="baz", tags={"foo": "bar", "foo1": "bar1"}))


# Generated at 2022-06-11 01:07:07.641214
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:16.937008
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    from nose.tools import assert_equals, assert_true
    # Test that a simple key value pair works
    camel = {'key': 'value'}
    snake = camel_dict_to_snake_dict(camel)
    assert_equals(snake['key'], 'value')
    # Test that a simple nested dict works
    camel = {'key': {'nested_key': 'nested_value'}}
    snake = camel_dict_to_snake_dict(camel)
    assert_equals(snake['key']['nested_key'], 'nested_value')
    # Test that a list of dict works
    camel = {'list': [{'first': 'value', 'second': 'value'}, {'first': 'value', 'second': 'value'}]}
    dict_

# Generated at 2022-06-11 01:07:25.312494
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({'a': 1}) == {'a': 1}
    assert camel_dict_to_snake_dict({'A': 1}) == {'a': 1}

    assert camel_dict_to_snake_dict({'abcdefGhiJKL': 1}) == {'abcdef_ghi_j_k_l': 1}

    assert camel_dict_to_snake_dict({'abcDefGhiJKL': {'mnoPQrSTUvWxYZ': 2}}) == \
           {'abc_def_ghi_j_k_l': {'mno_p_qr_s_t_u_v_wx_y_z': 2}}


# Generated at 2022-06-11 01:07:32.117682
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    # test input
    # [{'Key': 'Name', 'Value': 'my-app'}, {'Key': 'Env', 'Value': 'prod'}]
    camel_tags = [{'Key': 'Name', 'Value': 'my-app'}]
    snake_tags = [{'key': 'Name', 'value': 'my-app'}]
    camel_to_snake_tags = camel_dict_to_snake_dict(camel_tags)

    assert(camel_to_snake_tags == snake_tags)

# Generated at 2022-06-11 01:07:42.174104
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'fooBar': {
            'bazFoo': 'hi',
            'thisIsIgnored': {
                'thisIsAlsoIgnored': {
                    'butThisIsConverted': 'bye'
                }
            },
            'thisIsStillIgnored': 'yes'
        }
    }

    snake_dict = camel_dict_to_snake_dict(camel_dict, ignore_list=['thisIsIgnored', 'thisIsStillIgnored'])

    # Ensure that both dictionaries are unchanged after a round trip through camel_dict_to_snake_dict
    assert camel_dict_to_snake_dict(snake_dict, ignore_list=['thisIsIgnored', 'thisIsStillIgnored']) == snake_dict

    # Ensure that both dictionaries are unchanged after a round trip

# Generated at 2022-06-11 01:07:51.980995
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'FooBar': {
            'SOMETag': 'SomeValue',
            'Tags': {
                'SomeKey': 'SomeValue',
                'SomeOtherKey': 'SomeOtherValue',
            },
            'FooBaz': {
                'BazQux': 'QuxQux',
            },
            'FooList': ['foo', 'bar'],
            'FooInt': 1,
            'FooBool': True,
        }
    }


# Generated at 2022-06-11 01:08:00.251044
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = {'InitializeDisks': True}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert 'initialize_disks' in snake_dict.keys()

    camel_dict = {'PublicAccessBlock': {'BlockPublicAcls': False}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert 'public_access_block' in snake_dict.keys()
    assert 'block_public_acls' in snake_dict['public_access_block'].keys()

    camel_dict = {'Tags': {'Key': 'Name', 'Value': 'CloudfrontVPC'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)

# Generated at 2022-06-11 01:08:07.692419
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    test_input_dict = {'TagSpecifications': [{'ResourceType': 'instance'}],
                       'HTTPEndpoint': {'Enabled': True},
                       'Tags': [{'Key': 'foo'}, {'Value': 'bar'}]}

    test_output_dict = {'tags': [{'key': 'foo'}, {'value': 'bar'}],
                        'h_t_t_p_endpoint': {'enabled': True},
                        'tag_specifications': [{'resource_type': 'instance'}]}

    assert camel_dict_to_snake_dict(test_input_dict, reversible=True) == test_output_dict

