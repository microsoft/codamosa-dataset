

# Generated at 2022-06-11 00:58:32.453284
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {'Enabled': True},
        'HTTPEndpoints': [
            {
                'EndpointURL': 'my.elastic.co',
                'PermissionPolicies': ['cloud-admin'],
                'Username': 'foo',
                'Password': 'bar',
            }
        ],
        'Tags': {'key': 'value'},
    }
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert 'http_endpoint' in snake_dict
    assert 'h_t_t_p_endpoint' not in snake_dict
    assert 'http_endpoints' in snake_dict
    assert 'h_t_t_p_endpoints' not in snake_dict

# Generated at 2022-06-11 00:58:40.028702
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {
        'foo': 'bar',
        'baz': 'foo',
        'blah': {
            'inner': 'diff'
        }
    }
    right = {
        'foo': 'bar',
        'baz': 'bar',
        'blah': {
            'inner2': 'diff'
        }
    }
    expected = ({
        'baz': 'foo',
        'blah': {
            'inner': 'diff'
        }
    }, {
        'baz': 'bar',
        'blah': {
            'inner2': 'diff'
        }
    })
    assert expected == recursive_diff(left, right)

# Generated at 2022-06-11 00:58:51.721615
# Unit test for function dict_merge
def test_dict_merge():
    dict1 = dict(hostname='host1', cluster='cluster1', ip='172.168.0.1')
    dict2 = dict(hostname='host2', cluster='cluster2', ip='172.168.1.1')
    dict3 = dict(hostname='host3', cluster='cluster3', ip='172.168.2.1')
    dict1_modified = dict(hostname='host2', cluster='cluster1', ip='172.168.0.1')
    dict_merge_result = dict(hostname='host2', cluster='cluster1', ip='172.168.1.1')
    assert dict_merge(dict1, dict2) == dict_merge_result
    assert dict_merge(dict1, dict2, dict3) == dict3

# Generated at 2022-06-11 00:59:02.176281
# Unit test for function dict_merge

# Generated at 2022-06-11 00:59:13.588867
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    a = json.loads(
        """
        {
          "key": "value",
          "key2" : [
            "value2",
            "value3"
          ],
          "k": {
            "k2" : {
              "nested_key": "nested_value",
              "nested_list": [
                "nested_value1",
                "nested_value2"
              ],
              "nested_camel_key": "nested_value"
            }
          },
          "k3": [
            {
              "k4": "v4"
            },
            {
              "k5": "v5"
            }
          ]
        }
        """
    )
    b = camel_dict_to_snake_dict(a)

   

# Generated at 2022-06-11 00:59:22.464226
# Unit test for function recursive_diff
def test_recursive_diff():

    dict1 = {
        'test': 'foo',
        'test2': 'bar',
        'list': ['foo', 'bar', 'baz'],
        'dict': {
            'foo': 'bar',
            'bar': 'foo'
        }
    }
    dict2 = {
        'test': 'foo',
        'test2': 'bar',
        'list': ['foo', 'bar', 'baz'],
        'dict': {
            'foo': 'bar',
            'bar': 'foo'
        }
    }

    assert recursive_diff(dict1, dict2) is None

    dict2['test2'] = 'baz'
    assert recursive_diff(dict1, dict2) == ({'test2': 'bar'}, {'test2': 'baz'})


# Generated at 2022-06-11 00:59:33.998038
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """Unit test for function camel_dict_to_snake_dict"""
    # Just testing regular conversion
    result = camel_dict_to_snake_dict({'prepare': {'foo': 'bar'}, 'publish': 'baz'})
    assert result == {'prepare': {'foo': 'bar'}, 'publish': 'baz'}

    # Test case where camelcase key is pluralized; should still be converted
    result = camel_dict_to_snake_dict({'InstanceARNs': ['foo', 'bar']})
    assert result == {'instance_ar_ns': ['foo', 'bar']}

    # Test case where camelcase key is pluralized, including 's'; should still be converted

# Generated at 2022-06-11 00:59:44.665943
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    """ Unit test for function camel_dict_to_snake_dict """

# Generated at 2022-06-11 00:59:54.089681
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({
        'Include': True,
        'HTTPHeaders': [
            {
                'Key': 'test_key',
                'Value': 'test_value'
            }
        ]
    }) == {
        'include': True,
        'h_t_t_p_headers': [
            {
                'key': 'test_key',
                'value': 'test_value'
            }
        ]
    }

# Generated at 2022-06-11 01:00:05.259701
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'HTTPEndpoint': {
            'Endpoint': 'http://www.example.com',
            'Timeout': 1,
            'Period': 60,
            'HealthyThreshold': 10,
            'UnhealthyThreshold': 2,
            'SuccessCodes': '200,202',
            'Matcher': {
                'HttpCode': '200-204'
            }
        },
        'Targets': [
            {
                'Id': 'i-abcd1234',
                'Port': 80
            },
            {
                'Id': 'i-bcde2345',
                'Port': 80
            }
        ]
    }


# Generated at 2022-06-11 01:00:17.671732
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    expected = {'subnet_ids': ['subnet-1234567', 'subnet-7654321', 'subnet-1597531'], 'vpc_id': 'vpc-1234567'}
    camel = {'subnetIds': ['subnet-1234567', 'subnet-7654321', 'subnet-1597531'], 'vpcId': 'vpc-1234567'}
    assert camel_dict_to_snake_dict(camel) == expected
    assert camel_dict_to_snake_dict(expected, ignore_list=['subnet_ids']) == expected


if __name__ == '__main__':

    test_camel_dict_to_snake_dict()

# Generated at 2022-06-11 01:00:29.034529
# Unit test for function dict_merge
def test_dict_merge():
    try:
        import mozunit
    except ImportError:
        import os
        import sys
        sys.path.append(os.path.join(os.path.dirname(__file__), "../"))
        import mozunit

    # Test case 1
    given1 = {"key1": "value1", "key2": "value2"}
    given2 = {}
    expected = {"key1": "value1", "key2": "value2"}
    assert dict_merge(given1, given2) == expected, "dict_merge test failed: %s != %s" % (given1, given2)

    # Test case 2
    given1 = {"key1": "value1", "key2": "value2"}
    given2 = {"key1": "value1", "key2": "value2"}


# Generated at 2022-06-11 01:00:35.315475
# Unit test for function dict_merge
def test_dict_merge():
    a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    expected = {
        'first': {
            'all_rows': {
                'pass': 'dog',
                'fail': 'cat',
                'number': '5'
            }
        }
    }
    assert expected == dict_merge(a, b)

# Generated at 2022-06-11 01:00:47.312242
# Unit test for function recursive_diff
def test_recursive_diff():
    # same dicts
    d1 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    d2 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    assert recursive_diff(d1, d2) is None

    # b is missing key 'c' so diff returns dictionary of missing keys
    d1 = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': 5}
    d2 = {'a': 1, 'b': {'d': 4}, 'e': 5}
    assert recursive_diff(d1, d2) == ({'b': {'c': 2}}, {'b': {}})

    # Same as above but order is reversed
    assert recursive_

# Generated at 2022-06-11 01:00:57.070652
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = dict(
        TestCase1=1,
        TestCase2=2,
        TestCase3=dict(
            TestCaseProperty1=1,
            TestCaseProperty2="a",
            TestCaseProperty3=None,
            TestCaseProperty4=1.1,
        ),
    )
    assert camel_dict_to_snake_dict(camel_dict) == dict(
        test_case1=1,
        test_case2=2,
        test_case3=dict(
            test_case_property1=1,
            test_case_property2="a",
            test_case_property3=None,
            test_case_property4=1.1,
        ),
    )

# Generated at 2022-06-11 01:01:07.495543
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': True, 'tags': {'Project': 'ansible', 'Component': 'cloudformation'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict)
    assert snake_dict == {'h_t_t_p_endpoint': True, 'tags': {'Project': 'ansible', 'Component': 'cloudformation'}}
    camel_dict = {'HttpEndPoint': True, 'tags': {'Project': 'ansible', 'Component': 'cloudformation'}}
    snake_dict = camel_dict_to_snake_dict(camel_dict, True)
    assert snake_dict == {'http_e_n_d_point': True, 'tags': {'Project': 'ansible', 'Component': 'cloudformation'}}

# Generated at 2022-06-11 01:01:18.378466
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'TestCamelCase': {
            'TestHTTPEndpoint': None,
            'TestHTTPCase': {
                'TestSubCamelCase': {
                    'TestSubCamelCase': None,
                    'TestSubCamelCaseDeep': {
                        'TestSubSubCamelCase': {
                            'TestSubSubCamelCase': None
                        }
                    }
                }
            },
            'TestSubCamelCase': None
        }
    }

    # Check the conversion case

# Generated at 2022-06-11 01:01:28.834088
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import json
    import unittest
    import yaml


# Generated at 2022-06-11 01:01:39.435513
# Unit test for function dict_merge
def test_dict_merge():
    a = {'key1': 'val1'}
    b = {'key2': 'val2'}
    c = {}
    c = dict_merge(a, b)
    assert c == {'key1': 'val1', 'key2': 'val2'}

    a = {'key1': 'val1', 'level1': {'key1': 'val1'}}
    b = {'key1': 'val1', 'level1': {'key2': 'val2'}}
    c = dict_merge(a, b)
    assert c == {'key1': 'val1', 'level1': {'key1': 'val1', 'key2': 'val2'}}

    a = {'key1': 'val1', 'level1': {'key1': 'val1'}}


# Generated at 2022-06-11 01:01:47.506212
# Unit test for function dict_merge
def test_dict_merge():
    """Unit tests for function dict_merge"""
    def assert_dict_merge_equals_expected(test_case_name, dict1, dict2, expected_output, indent=0):
        """
        Helper function to run dict_merge tests with expected output.
        """
        result = dict_merge(dict1, dict2)
        if result != expected_output:
            raise AssertionError(
                "dict_merge(dict1=%s, dict2=%s)\n%stest case '%s' expected output: %s - got: %s" %
                (dict1, dict2, ' ' * indent, test_case_name, expected_output, result))

    # Test case description:
    #
    # dict_merge(dict1, dict2) == expected_output
    #


# Generated at 2022-06-11 01:01:58.574757
# Unit test for function recursive_diff
def test_recursive_diff():
    """Unit test for function recursive_diff"""
    # Test adding a new value to one of the dict
    dict1 = {'key1': {'key2': 'value1', 'key3': 'value2'}}
    dict2 = {'key1': {'key2': 'value1', 'key3': 'value2', 'key4': 'value3'}}
    assert recursive_diff(dict1, dict2) == (dict1, {'key4': 'value3'})
    # Test removing a value from one of the dict
    dict1 = {'key1': {'key2': 'value1', 'key3': 'value2', 'key4': 'value3'}}
    dict2 = {'key1': {'key2': 'value1', 'key3': 'value2'}}

# Generated at 2022-06-11 01:02:10.725424
# Unit test for function recursive_diff
def test_recursive_diff():

    # Tests for equal dictionaries
    assert recursive_diff({}, {}) == None
    assert recursive_diff({"a":5}, {"a":5}) == None
    assert recursive_diff({"a":5, "b":3}, {"a":5, "b":3}) == None
    assert recursive_diff({"a":5, "b":3, "c":4}, {"a":5, "b":3, "c":4}) == None
    assert recursive_diff({"a":5, "b":3, "c":4, "d":1}, {"a":5, "b":3, "c":4, "d":1}) == None

    # Tests for difference on a single key

# Generated at 2022-06-11 01:02:15.637956
# Unit test for function recursive_diff
def test_recursive_diff():
    left = {'device': {'type': 'qwerty', 'state': 'absent'}}
    right = {'device': {'type': 'asdfgh', 'state': 'absent'}}
    assert recursive_diff(left, right) == ({'type': 'qwerty'}, {'type': 'asdfgh'})

    left = {'device': {'type': 'qwerty', 'state': 'absent'}}
    right = {'device': {'type': 'qwerty', 'state': 'present'}}
    assert recursive_diff(left, right) == ({'state': 'absent'}, {'state': 'present'})


# Generated at 2022-06-11 01:02:25.951393
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:02:33.771346
# Unit test for function recursive_diff
def test_recursive_diff():
    def assert_dict_equal(a, b):
        assert a == b, "Collections are not equal. Expected {0}, got {1}".format(a, b)

    dict1 = dict()
    dict2 = dict()
    assert_dict_equal(recursive_diff(dict1, dict2), None)

    dict1 = dict(x='y')
    dict2 = dict(x='y')
    assert_dict_equal(recursive_diff(dict1, dict2), None)

    dict1 = dict(x='y')
    dict2 = dict(x='z')
    assert_dict_equal(recursive_diff(dict1, dict2), (dict(x='y'), dict(x='z')))

    dict1 = dict(x='y', y='z')

# Generated at 2022-06-11 01:02:42.942799
# Unit test for function recursive_diff
def test_recursive_diff():
    def assert_no_diff(dict1, dict2):
        diff = recursive_diff(dict1, dict2)
        assert diff is None, "Unexpected diff. Left: %s. Right: %s" % diff
        diff = recursive_diff(dict2, dict1)
        assert diff is None, "Unexpected diff. Left: %s. Right: %s" % diff

    def assert_diff(dict1, dict2):
        diff = recursive_diff(dict1, dict2)
        assert diff is not None, "Expected diff. Left: %s. Right: %s" % diff
        diff = recursive_diff(dict2, dict1)
        assert diff is not None, "Expected diff. Left: %s. Right: %s" % diff

    # Test both ways, a vs b and b vs a

# Generated at 2022-06-11 01:02:54.697760
# Unit test for function recursive_diff
def test_recursive_diff():
    dict1 = {'a': {'b': 'c', 'd': 'e'}, 'f': 'g', 'h': 'i', 'j': {'k': {'l': 'm', 'o': 'p'}}}
    dict2 = {'a': {'b': 'c', 'd': 'q'}, 'f': 'r', 'j': {'k': {'l': 'm', 'o': 'p'}, 'z': 'x'}, 'y': 'z'}
    result = recursive_diff(dict1, dict2)
    expected = ({'a': {'d': 'e'}, 'f': 'g', 'h': 'i'}, {'a': {'d': 'q'}, 'f': 'r', 'y': 'z'})
    assert result == expected

# Generated at 2022-06-11 01:03:05.415796
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Simple tests for function _camel_to_snake
    assert(_camel_to_snake("CamelTest") == "camel_test")
    assert(_camel_to_snake("camelTest") == "camel_test")
    assert(_camel_to_snake("CamelCaseTest") == "camel_case_test")
    assert(_camel_to_snake("HTTPEndpoint") == "http_endpoint")
    assert(_camel_to_snake("CamelHTTPResponse") == "camel_h_t_t_p_response")
    assert(_camel_to_snake("HTTPResponseCode") == "h_t_t_p_response_code")

# Generated at 2022-06-11 01:03:17.050842
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # test case 1
    camel_dict_sample_1 = {
        'Address': '10.0.0.1',
        'Port': 8800,
        'CustomHeaders': {
            'Header1': 'Value1',
            'Header2': 'Value2'
        },
        'Tags': {
            'TagMap': {
                'TagKey1': 'Value1',
                'TagKey2': 'Value2'
            }
        }
    }


# Generated at 2022-06-11 01:03:28.296869
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'aBcDeFg': 'aBcDeFg'}, reversible=True) == {'a_b_c_d_e_f_g': 'aBcDeFg'}
    assert camel_dict_to_snake_dict({'aBcDeFg': 'aBcDeFg'}, reversible=False) == {'abcdefg': 'aBcDeFg'}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': 'HTTPEndpoint'}, reversible=True) == {'h_t_t_p_endpoint': 'HTTPEndpoint'}

# Generated at 2022-06-11 01:03:41.003085
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'a': 1, 'A': 1}) == {'a': 1, 'a': 1}
    assert camel_dict_to_snake_dict({'a': 1, 'A': 1}, reversible=True) == {'a': 1, 'a_': 1}
    assert camel_dict_to_snake_dict({'HTTPEndpoint': {'a': 1, 'b': 2}}, reversible=True) == {'h_t_t_p_endpoint': {'a': 1, 'b': 2}}


# Generated at 2022-06-11 01:03:49.666333
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({}) == {}
    assert camel_dict_to_snake_dict({'foo': {}}) == {'foo': {}}
    assert camel_dict_to_snake_dict({'fooBar': 'baz'}) == {'foo_bar': 'baz'}
    assert camel_dict_to_snake_dict({'fooBar': 'baz', 'alphaBeta': {'gammaDelta': 'epsilon'}}) == {'foo_bar': 'baz', 'alpha_beta': {'gamma_delta': 'epsilon'}}

# Generated at 2022-06-11 01:04:00.865023
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test that nothing is changed if dict items are not camelCase.
    test_dict_1 = {'foo': 'bar', 'baz': 1, 'qux': [{'abc': 'xyz'}]}
    assert test_dict_1 == camel_dict_to_snake_dict(test_dict_1)

    test_dict_2 = {'foo': 'bar', 'baz': 1, 'qux': [{'abc': 'xyz'}], 'fizFiz': 'fizFiz'}
    assert test_dict_1 == camel_dict_to_snake_dict(test_dict_2)


# Generated at 2022-06-11 01:04:09.572462
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    camel_dict = dict(
        HTTPEndpoint=True,
        LambdaFunctionArn='foo',
        TargetGroupARNs=['bar', 'baz']
    )

    snake_dict = camel_dict_to_snake_dict(camel_dict, reversible=True)

    assert snake_dict['h_t_t_p_endpoint'] == True
    assert snake_dict['lambda_function_arn'] == 'foo'
    assert snake_dict['target_group_a_r_ns'] == ['bar', 'baz']

    # Test that a dict with a list that contains dicts is converted.
    # This was an issue with the lambda dict

# Generated at 2022-06-11 01:04:20.803728
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': 'value1', 'TargetGroupARNs': ['value2'], 'Tags': {'Foo': 'bar', 'Baz': 'qux'}}
    expected = {'http_endpoint': 'value1', 'target_group_ar_ns': ['value2'], 'tags': {'Foo': 'bar', 'Baz': 'qux'}}
    camel_dict_to_snake_dict(camel_dict) == expected
    camel_dict_to_snake_dict(camel_dict, ignore_list=['Tags']) == expected

# Generated at 2022-06-11 01:04:31.137850
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Name': 'Test', 'Path': '/', 'Protocol': 'HTTP', 'HTTPEndpoint': {'Path': '/', 'Protocol': 'HTTP'}}}
    snake_dict = {'http_endpoint': {'name': 'Test', 'path': '/', 'protocol': 'HTTP', 'h_t_t_p_endpoint': {'path': '/', 'protocol': 'HTTP'}}}
    assert camel_dict_to_snake_dict(camel_dict) == snake_dict

# Generated at 2022-06-11 01:04:41.434126
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'TagList': [
            {
                'Value': 'test',
                'Key': 'aws-sync'
            },
            {
                'Value': 'test',
                'Key': 'aws_sync_2'
            }
        ],
        'HTTPPort': 80,
        'HTTPEnabled': True,
        'TCPPort': 443,
        'InstanceName': 'instance-name'
    }

# Generated at 2022-06-11 01:04:50.054034
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:00.892249
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'MyRegion': 'eu-west-1',
        'MyAvailabilityZones': ['eu-west-1a', 'eu-west-1b'],
        'Tags': {
            'Application': 'MyApplication',
            'Group': 'MyGroup',
            'CostCode': 'MyCostCode',
        },
        'HTTPEndpoint': {
            'Path': '/monitor',
            'Protocol': 'HTTP',
            'Port': '80',
            'Authentication': {
                'Type': 'NONE'
            }
        }
    }
    output_dict = camel_dict_to_snake_dict(test_dict)
    assert output_dict['my_region'] == 'eu-west-1'

# Generated at 2022-06-11 01:05:06.672370
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        "TestList": [
            {
                "TestDict": {
                    "ExampleParam": "ExampleValue"
                }
            }
        ]
    }
    expected_dict = {
        "test_list": [
            {
                "test_dict": {
                    "example_param": "ExampleValue"
                }
            }
        ]
    }
    result = camel_dict_to_snake_dict(test_dict)
    assert result == expected_dict, "Dictionary conversion failed"



# Generated at 2022-06-11 01:05:19.181728
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {
        'id': '1',
        'systemId': '2',
        'permissions': {
            'secrets': {
                'acl': [{
                    'grants': [
                        {
                            'permission': ['read'],
                            'principal': 'principal_a'
                        }
                    ]
                }]
            }
        }
    }

# Generated at 2022-06-11 01:05:29.885553
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:05:40.243356
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():

    # Test 1
    my_camel_dict = {
        'TestAttribute': 'test',
        'TestAttribute2': 'test2',
        'TestTag': {
            'TestTagAttribute': 'test'
        },
        'BigTag': {
            'TestTagAttribute': 'test',
            'TestTagAttribute2': 'test2'
        }
    }

    my_expected_dict = {
        'test_attribute': 'test',
        'test_attribute2': 'test2',
        'test_tag': {
            'test_tag_attribute': 'test'
        },
        'big_tag': {
            'test_tag_attribute': 'test',
            'test_tag_attribute2': 'test2'
        }
    }


# Generated at 2022-06-11 01:05:51.892436
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    import sys
    import json


# Generated at 2022-06-11 01:06:01.606508
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({"SomeKey": "value"}) == {"some_key": "value"}
    assert camel_dict_to_snake_dict({"StartWithANumber": "value"}) == {"start_with_a_number": "value"}
    assert camel_dict_to_snake_dict({"anHTTPRule": "value"}) == {"an_http_rule": "value"}
    assert camel_dict_to_snake_dict({"SomeEndpoint": {"HTTPRule": "value"}}) == \
           {"some_endpoint": {"http_rule": "value"}}

# Generated at 2022-06-11 01:06:10.654958
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    camel_dict = {'HTTPEndpoint': {'Protocol': 'HTTPS', 'AuthorizationType': 'NONE'}, 'MethodSettings': [{'HttpMethod': '*', 'ResourcePath': '/*', 'KMSAuthorization': {'Enabled': False}, 'RequireAuthorizationForCacheControl': False, 'UnreservedConcurrentExecutions': 100}]}
    expected_dict = {'http_endpoint': {'protocol': 'HTTPS', 'authorization_type': 'NONE'}, 'method_settings': [{'http_method': '*', 'resource_path': '/*', 'k_m_s_authorization': {'enabled': False}, 'require_authorization_for_cache_control': False, 'unreserved_concurrent_executions': 100}]}
    assert camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:21.105088
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:29.365850
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:37.093848
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:44.825833
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:06:58.036731
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:08.441399
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    assert camel_dict_to_snake_dict({'test123': None}) == {'test123': None}
    assert camel_dict_to_snake_dict({'test123': 123}) == {'test123': 123}
    assert camel_dict_to_snake_dict({'test123': '123'}) == {'test123': '123'}
    assert camel_dict_to_snake_dict({'test123': {'test123': None}}) == {'test123': {'test123': None}}
    assert camel_dict_to_snake_dict({'test123': {'test123': '123'}}) == {'test123': {'test123': '123'}}

# Generated at 2022-06-11 01:07:17.998476
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:26.405301
# Unit test for function camel_dict_to_snake_dict

# Generated at 2022-06-11 01:07:30.293866
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    x = {
        'MyProperty': {
            'MySubProperty': 'MyValue'
        }
    }
    y = camel_dict_to_snake_dict(x)
    assert y['my_property']['my_sub_property'] == 'MyValue'



# Generated at 2022-06-11 01:07:40.782751
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    """
    Test that camel_dict_to_snake_dict can convert a simple dictionary
    """

    camel_dict = {
        "key1": "value1",
        "Key2": "value2",
        "KEY3": "value3",
        "list": ["one", "two", "three"],
        "dict": {"key4": "value4"},
        "dictInList": [{"key5": "value5"}, {"key6": "value6"}],
        "listInDict": {"key7": ["value7", "value8", "value9"]},
        "IgnoreCaseList": [{"key8": "value10"}],
        "tags": {"IgnoreCase": {"dontChangeMe": "value11"}},
    }

# Generated at 2022-06-11 01:07:50.496866
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'fooBar': {
            'bazBam': {
                'booBaz': 'blah',
            },
        },
        'tags': {
            'Key': 'value',
        },
        'HTTPEndpoint': {
            'HTTPEndpoint1': 'value1',
        },
    }
    assert camel_dict_to_snake_dict(test_dict) == {
        'foo_bar': {
            'baz_bam': {
                'boo_baz': 'blah',
            },
        },
        'tags': {
            'Key': 'value',
        },
        'h_t_t_p_endpoint': {
            'h_t_t_p_endpoint1': 'value1',
        },
    }

   

# Generated at 2022-06-11 01:07:58.916081
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dict = {
        'TagKeys': [
            'NewTagKey',
        ],
        'LoadBalancerName': 'test_load_balancer',
        'LoadBalancerAttributes': {
            'ConnectionSettings': {
                'IdleTimeout': 60
            },
            'AdditionalAttributes': [
                {
                    'Key': 'test-load-balancer-key-1',
                    'Value': 'test-load-balancer-value-1'
                },
                {
                    'Key': 'test-load-balancer-key-2',
                    'Value': 'test-load-balancer-value-2'
                },
            ]
        }
    }

    # This is the expected result based on the test dict above

# Generated at 2022-06-11 01:08:06.515843
# Unit test for function camel_dict_to_snake_dict
def test_camel_dict_to_snake_dict():
    test_dic = {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4'}, 'key5': ['value5', 'value6'], 'key6': None}
    returned_dic = camel_dict_to_snake_dict(test_dic)
    assert returned_dic == {u'key1': u'value1', u'key2': u'value2', u'key3': {u'key4': u'value4'}, u'key5': [u'value5', u'value6'], u'key6': None}, 'Error in function camel_dict_to_snake_dict()'
