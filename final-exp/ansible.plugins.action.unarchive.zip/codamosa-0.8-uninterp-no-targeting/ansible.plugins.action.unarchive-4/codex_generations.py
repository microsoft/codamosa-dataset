

# Generated at 2022-06-21 03:10:59.440829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        """ Test class  -  For unit testing run method """
        # Mocks
        def _connection_make_tmp_path(self):
            return "test_action_module/test_mocked"

        def _execute_remote_stat(self, path, all_vars=None, follow=True):
            stat = {
                "exists": True,
                "isdir": True
            }
            return stat

        def _remote_expand_user(self, path):
            return path

        def _execute_module(self, module_name=None, module_args=None, task_vars=None):
            return {"unarchive_result": module_args}

        def _fixup_perms2(self, file_args):
            return True


# Generated at 2022-06-21 03:11:06.381504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Check that ActionModule can be properly constructed.
    """
    # Call ActionModule constructor
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check that object was properly constructed
    assert obj
    if hasattr(obj, 'TRANSFERS_FILES'):
        assert obj.TRANSFERS_FILES is True

# Generated at 2022-06-21 03:11:15.366281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

    module_loader, lookup_loader, path_loader = ActionModule._get_action_plugins(play_context)
    # Constructor for unarchive.ActionModule
    action_module = ActionModule(
        task=Task(),
        connection=None,
        play_context=play_context,
        loader=module_loader,
        templar=None,
        shared_loader_obj=None
    )
    # Assert type(action_module) == unarchive.ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:11:25.323989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    host_list = []
    my_host = MockHost()
    my_host.vars = dict()
    my_host.vars['ansible_connection'] = 'local'
    my_host.vars['ansible_shell_type'] = 'csh'
    my_host.vars['ansible_shell_executable'] = '/bin/csh'
    my_host.vars['ansible_python_interpreter'] = '/usr/bin/python'
    host_list.append(my_host)
    variable_manager = MockVariableManager()
    loader = MockLoader()
    my_action = ActionModule(my_host, variable_manager, loader)
    my_action.start_firing()
    # If src and dest exist, the command should succeed.
    my_action._task

# Generated at 2022-06-21 03:11:30.193666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    context = PlayContext()
    task = Task()
    action_module = ActionModule(task, context, '/path/to/ansible/repo')
    action_module._remove_tmp_path('/tmp/path/to/repo')

# Generated at 2022-06-21 03:11:33.210846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    # Create an object of class ActionModule
    am = ActionModule()

# Generated at 2022-06-21 03:11:34.938280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleActionFail) as excinfo:
        ActionModule()

# Generated at 2022-06-21 03:11:40.713396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(actionPlugin=None, task=None)
    _task = dict()
    _task['args'] = dict()
    _task['args']['src'] = None
    _task['args']['dest'] = None
    action._task = _task

    try:
        action.run()
        assert False
    except AnsibleActionFail:
        pass
    except AnsibleActionSkip:
        pass
    except AnsibleAction:
        pass
    else:
        assert False

# Generated at 2022-06-21 03:11:46.528060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  am = ActionModule(task_vars={'ansible_python_interpreter': '/usr/bin/python', 'ansible_connection': 'local'}, connection=None, task_ds=None, variable_manager=None)
  result = am.run(tmp=None, task_vars={})
  assert result == {'invocation': {'module_args': {'creates': None, 'decrypt': True, 'dest': None, 'remote_src': False, 'src': None}}, 'changed': False, 'exception': None}

# Generated at 2022-06-21 03:11:51.582591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(dict(a=1, b=2))
    assert isinstance(test_module, ActionModule)
    try:
        assert test_module.a == 1
        assert test_module.b == 2
    except AttributeError as e:
        assert False, "Exception occurred: " + str(e)

# Generated at 2022-06-21 03:12:04.183867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {}
    data['task'] = {}
    data['task']['action'] = 'copy'
    data['task']['args'] = {'src': '/tmp/source', 'dest': '/tmp/dest'}
    ActionModule(data)


# Generated at 2022-06-21 03:12:07.324890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor...")

    module = ActionModule() # Define a new action module
    print("Module: ", module)

    print("Testing ActionModule constructor... Done.")


# Generated at 2022-06-21 03:12:18.933931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = to_text('/home/user/file.tar.gz')
    dest = to_text('/tmp')
    remote_src = True
    creates = None
    decrypt = False
    tmp = None
    task_vars = ['task_variables']

    action_module = ActionModule()
    res = action_module.run(tmp, task_vars)

    assert res == {} and tmp is None and task_vars == ['task_variables']
    # Check if method run raises the exception AnsibleActionFail
    try:
        action_module.run(tmp, task_vars)
    except AnsibleActionFail as e:
        assert to_text(e).find("parameters are mutually exclusive: ('copy', 'remote_src')") != -1


# Generated at 2022-06-21 03:12:29.586186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import tempfile
    import os
    import shutil

    # Make a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Make a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.write(fd, "test")
    os.close(fd)

    # Make a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Make a temporary file
    fd, tmpfile2 = tempfile.mkstemp()
    os.write(fd, "test")
    os.close(fd)

    # Add a temporary directory to the module search path
    sys.path.append(tmpdir)

    # Create the module file
    fd, tmpmodule = tempfile.mkstemp(suffix=".py", dir=tmpdir)

# Generated at 2022-06-21 03:12:35.865590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test empty constructor
    n = ActionModule()
    assert n.requires_hash__ is True
    assert n.requires_one_of__ is None
    assert n.required_if__ is None
    assert n.required_together__ is None
    assert n.required_together_with__ is None



# Generated at 2022-06-21 03:12:36.994914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass


# Generated at 2022-06-21 03:12:38.057905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 03:12:44.536547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Constructor test
  module = ActionModule()
  assert module

  # Member variables test
  assert module._display.deprecated == ("ssh has been deprecated in favor of 'ansible.legacy.ssh'. This feature will be removed in version 2.9", dict(version='2.9'))
  assert module._supports_check_mode == True
  assert module._supports_async == True
  assert module.TRANSFERS_FILES == True



# Generated at 2022-06-21 03:12:54.844971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    args = {'src': 'path/to/source', 'dest': 'path/to/dest'}
    task_vars = {}
    result = action_module._execute_module(module_name='ansible.legacy.unarchive', module_args=args, task_vars=task_vars)
    assert(result['rc'] == 0)
    assert('failed' in result)
    assert(result['failed'] == False)
    # Test whether it fails when dest is not a directory
    args = {'src': 'path/to/source', 'dest': 'file'}

# Generated at 2022-06-21 03:13:07.141783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    options = FakeOptions()
    loader = FakeLoader()
    add_all_plugin_dirs(loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory_sources('localhost,')


# Generated at 2022-06-21 03:13:29.067368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule('ansible.legacy.unarchive', dict(
        {'src': 'src', 'dest': 'dest', 'remote_src': 'remote_src', 'creates': 'creates', '_ansible_check_mode': False,
         '_ansible_diff': True, '_ansible_verbosity': 2, '_ansible_syslog_facility': 'LOG_USER',
         '_ansible_no_log': False, '_ansible_debug': False, '_ansible_diff_mode': 'default'}, **dict()))

# Generated at 2022-06-21 03:13:33.857989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import pytest

    # We are not implementing test_action_module, it's already done in test_action_base.
    # We only need to call the test_run function.
    import test_action_base
    test_action_base.load_fixtures()
    return test_action_base.test_run()



#===============================================================================
# Unit tests for class ActionModule
#===============================================================================

import pytest
import os
import tempfile

# TODO: Remove allow_module_downgrade when module_utils is moved out of core
pytestmark = pytest.mark.skipif("platform.system() == 'Windows'", reason="No module_utils on Windows")


# Generated at 2022-06-21 03:13:35.427246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert hasattr(module, '_execute_module')

# Generated at 2022-06-21 03:13:47.323286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import random
    import string

    # Create a test directory and file to archive.
    rand_str = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    test_dir = '/tmp/test_dir_' + rand_str
    test_file = '/tmp/test_file_' + rand_str
    source = test_dir + '.tar.gz'
    dest = '/tmp/dest_' + rand_str

# Generated at 2022-06-21 03:13:48.787546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    # TODO: Write test for run method

# Generated at 2022-06-21 03:13:49.947473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Create the unit tests for ActionModule()
    return True


# Generated at 2022-06-21 03:14:01.888161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the method run of class ActionModule

    :return:
    """
    # Creating a mock task
    mock_task = mock.Mock()

    action_module = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock task_vars
    task_vars = {'ansible_diff_mode': False}

    # Test with undefined args
    action_module_result = action_module.run(task_vars=task_vars)
    assert (action_module_result['failed'] is True)
    assert (action_module_result['msg'] == 'src (or content) and dest are required')

    # Test with undefined dest

# Generated at 2022-06-21 03:14:05.124530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(None, None, None, None, None)
    assert hasattr(test_module, 'run')
    assert hasattr(test_module, 'TRANSFERS_FILES')

# Generated at 2022-06-21 03:14:08.240714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()
    # Checking if the variable ActionModule contains a function named as run
    action_module.run()

# Generated at 2022-06-21 03:14:15.546323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    action_mod = ActionModuleTest(
        task=dict(args=dict(src='test', dest='tmp')),
        connection=dict(host='localhost', port=22),
        play_context=dict(remote_addr='', password=None),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_mod is not None

# Generated at 2022-06-21 03:14:58.259876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.reserved import RESERVED_KEYS
    ansible_vars = {}
    ansible_vars['foo'] = 'bar'
    ansible_vars['baz'] = 'qux'
    ansible_vars['ansible_connection'] = 'local'
    ansible_vars['ansible_python_interpreter'] = '/usr/bin/python'
    # Uncomment the next line to test if the reserved keyword '_ansible_verbosity' is being excluded from vars
    # ansible_vars['_ansible_verbosity'] = '3'

# Generated at 2022-06-21 03:14:58.832520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:15:00.075958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = AnsibleActionModule()
    assert(obj != None)

# Generated at 2022-06-21 03:15:04.160082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ 
    Create an instance of ActionModule and verify that it can run some defined tasks.
    Unit test automation template.
    """
    # The following lines are commented out so that they do not 
    # get run by nose test.
    #am = ActionModule()
    #am.run()
    return True

# Generated at 2022-06-21 03:15:15.616783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.loader import action_loader
    from ansible import __version__ as ANSIBLE_VERSION
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor import run
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.cli import CLI
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-21 03:15:25.328775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    admod = ActionModule(connection=None, runner=None, module_name=None, module_args=None, loader=None, templar=None, shared_loader_obj=None)
    admod._task = { 'args': { 'foo': 'bar' } }
    admod.connection = { '_shell': { 'tmpdir': '/tmp/mydir' } }
    admod._execute_module = lambda *args, **kwargs: { 'failed': False }

    admod._check_diff = lambda *args, **kwargs: {}

    admod._fixup_perms2 = lambda *args, **kwargs: {}

    admod._transport = 'local'
    admod._connection = 'local'

    admod.run()

# Generated at 2022-06-21 03:15:32.755877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.errors import AnsibleActionFail

    for key_name in ['copy', 'remote_src']:
        for val_name in ['copy', 'remote_src']:
            for bool_val in [True, False]:
                if key_name == 'copy' and val_name == 'remote_src':
                    # When both are True, raise an exception.
                    test_module = ActionModule()
                    test_module._task = type('FakeTask', (object,), {'args': {'src': None, 'dest': None, 'copy': bool_val, 'remote_src': bool_val}, 'run_additional_module': lambda self: None})

# Generated at 2022-06-21 03:15:41.810752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import datetime

    # Use example module
    module = ActionModule({'args': {'src': 'source.tar.gz', 'remote_src': False, 'dest': 'destination.tar.gz'}}, '/usr/local/tmp/ansible_tKkzgM/tmp',
        '/usr/local/tmp/ansible_tKkzgM/tmp/source.tar.gz', False, False, None, '/usr/local/tmp/ansible_tKkzgM/tmp/ansible_test_test_ActionModule_run',
        False, False, 'test_ActionModule_run', False, False, None, None, 'test_ActionModule_run', 'test_ActionModule_run', None, datetime.datetime.now(), None)

    # FIXME: Add test for result of method run
   

# Generated at 2022-06-21 03:15:42.333643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None)

# Generated at 2022-06-21 03:15:53.414080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run()')

    # Test 1: Check if run() returns a valid result when using params src, dest, creates and containing content.
    #         This test also checks if the src and dest are converted to UTF8 string properly (JIRA ticket # 15695).
    #         This test also checks if the method _remote_expand_user() is called properly when creating a remote directory.
    #         This test also checks if the method _remote_expand_user() is called properly when creating a remote tmp directory.
    print('Check if run() returns a valid result when using params src, dest, creates and containing content.')
    task_vars = dict()
    task_vars['ansible_node_tmp'] = 'C:\\Users\\Administrator\\AppData\\Local\\Temp'

# Generated at 2022-06-21 03:17:08.623398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert am != None

# Generated at 2022-06-21 03:17:20.434073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import pkg_resources
    # CCTODO: Re-implement on Windows.
    if os.name == 'nt':
        return
    # Setting up inputs.
    tmp = 'fake-tmp'
    task_vars = None
    # Setting up class to be tested.
    instance = mock.Mock(spec=ActionModule)
    instance.connection = mock.MagicMock()
    instance.__class__.__name__ = 'ActionModule'
    instance.__class__.datastructure_class = 'unarchive'
    instance._task.args = {'src': 'fake-src', 'remote_src': False}
    # Fake _execute_module function.

# Generated at 2022-06-21 03:17:28.830324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    try:
        ansible_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    except Exception:
        ansible_root = None
    removed('Argument self', 'object')
    ansible_action_module_run = ActionModule(self=None, task=None)
    ansible_action_module_run.playbook = None
    ansible_action_module_run._task = None
    ansible_action_module_run.connection = None
    ansible_action_module_run._play_context = None
    ansible_action_module_run.templar = None
    ansible_action_module_run._templar = None
    ansible_action_module_run._

# Generated at 2022-06-21 03:17:40.570845
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:17:41.125413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:17:52.185242
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:17:55.072891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_runner = unittest.mock.create_autospec(ActionModule, spec_set=True)
    result = mock_runner.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-21 03:18:00.640023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import MagicMock
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch

    fake_task = MagicMock()
    fake_task.args = {
        'dest': '/home/',
        'src': '/tmp/test.tar'
    }
    fake_connection = MagicMock()
    fake_connection.tmpdir = '/tmp/test-ansible-1234567890'
    fake_module = MagicMock()
    fake_module.run = MagicMock()

    am = ActionModule(fake_task, fake_connection, fake_module)


# Generated at 2022-06-21 03:18:04.099152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    task = Task()
    block = Block()
    action = ActionModule(task, block)
    assert action

# Generated at 2022-06-21 03:18:14.061431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the class.
    action_module = ActionModule(
        task=dict(
            args=dict(
                src="/text",
                dst="/text"
            ),
            async_val=10,
            delegate_to='localhost'),
        connection=None,
        play_context=dict(
            port=6112,
            network_os='asa'
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Ensure it looks correct.
    assert action_module._task.args.get('src') == "/text"
    assert action_module._task.args.get('dst') == "/text"
    assert action_module._task.async_val == 10
    assert action_module._task.delegate_to == 'localhost'
    assert action_module