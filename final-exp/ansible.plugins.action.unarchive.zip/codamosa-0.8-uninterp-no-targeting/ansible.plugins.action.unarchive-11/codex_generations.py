

# Generated at 2022-06-21 03:10:52.106923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'test_ActionModule_run unimplemented'

# Generated at 2022-06-21 03:10:55.789080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test method run of class ActionModule.
    """
    # TODO: CCTODO: Add test code here.
    print("Test code for test_ActionModule_run not implemented.")


# Generated at 2022-06-21 03:10:57.406088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.run() == {}

# Generated at 2022-06-21 03:10:58.471504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:10:59.734474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:11:04.581250
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructing
    expected = "unarchive"
    actual = ActionModule.name
    assert expected == actual
    expected = "<class 'ansible.plugins.action.unarchive.ActionModule'>"
    actual = repr(ActionModule)
    assert expected == actual
    return

# Generated at 2022-06-21 03:11:05.755661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert True

# Generated at 2022-06-21 03:11:08.706539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(None, None)
    assert test.run() == {'failed': True, 'msg': 'src (or content) and dest are required'}

# Generated at 2022-06-21 03:11:14.963507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_dict = {
        'decrypt': False,
        'content': 'hello',
        'src': 'source',
        'dest': 'destination',
        'creates': 'some_dir/some_file',
        'remote_src': False
    }

    test_action = ActionModule(None, test_dict, True)
    assert isinstance(test_action, ActionBase)

    # class variables
    assert test_action.TRANSFERS_FILES == True

# Generated at 2022-06-21 03:11:15.905887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:11:34.760493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            ''' handler for unarchive operations '''
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            source = self._task.args.get('src', None)
            dest = self._task.args.get('dest', None)
            remote_src = boolean(self._task.args.get('remote_src', False), strict=False)
            creates = self._task.args.get('creates', None)
            decrypt = self._task.args.get('decrypt', True)


# Generated at 2022-06-21 03:11:36.851394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:11:45.771170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.copy import ActionModule as AModule
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    module_name = 'ansible.legacy.unarchive'
    module_args = {'src': '/home/user/test.tar', 'dest': '/home/user'}
    am = AModule(
        task=Task(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    am.connection = MagicMock()
    am.connection.shell

# Generated at 2022-06-21 03:11:48.182364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test Construction of object 
    print("Testing Creation of ActionModule Object")
    assert ActionModule is not None

# Generated at 2022-06-21 03:11:59.422234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'src': '/tmp/src', 'dest': '/tmp/dest'}
    conn_plugin = MagicMock()
    conn_plugin.return_value.run.return_value = {'failed': False}
    conn_plugin.return_value.run.return_value = {'failed': True}
    conn_plugin.return_value.run.return_value = {'failed': False, 'exists': False, 'isdir':False}
    conn_plugin.return_value.run.return_value = {'failed': False, 'exists': True, 'isdir':True}
    conn_plugin.return_value._shell.join_path.return_value = '/tmp/tmp_src'
    conn_plugin.return_value._shell.tmpdir.return_value = '/tmp'
    task = MagicMock

# Generated at 2022-06-21 03:12:08.609446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = mock.MagicMock()
    conn._shell.tmpdir = 'tmpdir'
    conn._shell.join_path = os.path.join

    mods = mock.MagicMock()
    runner = mock.MagicMock()

    action = ActionModule(conn=conn,
                          runner=runner,
                          action_plugins=mods,
                          task=mock.MagicMock())

    module_args = dict()
    module_args['src'] = 'src'
    module_args['dest'] = 'dest'
    module_args['creates'] = 'creates'
    module_args['decrypt'] = True

    action._task.args = module_args

    action._execute_remote_stat = mock.MagicMock()

# Generated at 2022-06-21 03:12:20.750510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(
        connection = MockConnection(),
        task_queue_manager = None,
        loader = MockLoader(),
        templar = None,
        shared_loader_obj = None
    )
    am._remove_tmp_path = Mock()  # Mockable function to prevent deletion of temp path
    am._execute_remote_stat = Mock(return_value = {'exists': True, 'isdir': True})
    am._remote_file_exists = Mock(return_value = False)
    am._remote_expand_user = Mock(side_effect = lambda x: x)
    am._transfer_file = Mock()
    am._execute_module = Mock(return_value = None)
    am._fixup_perms2 = Mock()

    # Verify that a NotADirectoryError thrown by _execute_remote

# Generated at 2022-06-21 03:12:22.892486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check in case of empty Parameter
    assert ActionModule(None, None, None, None, None) is not None


# Generated at 2022-06-21 03:12:32.207688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModule(object):
        def __init__(self):
            self.task = dict()
            self.task['args'] = dict()
            self.task['args']['src'] = ""
            self.task['args']['dest'] = ""
            self.task['args']['remote_src'] = ""
            self.task['args']['decrypt'] = ""
            self.connection = dict()
            self.connection['_shell'] = dict()
            self.connection['_shell']['tmpdir'] = ""
            self.connection['_shell']['join_path'] = test_join_path
            self.connection['_shell']['expand_user'] = test_expand_user
            self.connection['_shell']['fixup_perms2'] = test_fixup_per

# Generated at 2022-06-21 03:12:35.972942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    assert not ActionModule(Task(), {}) is None
    assert not ActionModule(Task(), {'a':1}) is None

# Generated at 2022-06-21 03:12:52.146889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-21 03:12:53.282173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:13:05.516726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    hosts_file = 'hosts_file'
    source_file = 'source_file'
    dest_file = 'dest_file'
    ansible_vars = 'ansible_vars'
    play = 'play'
    inventory = InventoryManager(loader=DataLoader(), sources=hosts_file)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._extra_vars = ansible_vars
    # Create test task

# Generated at 2022-06-21 03:13:07.046575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    s = {}
    a.run(s, {})

# Generated at 2022-06-21 03:13:18.104332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    import ansible.constants as C

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[C.DEFAULT_HOST_LIST])
    module = ActionModule(loader=loader, variable_manager=variable_manager, inventory=inventory)
    task = Task()

# Generated at 2022-06-21 03:13:26.123968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.module_utils._text import to_bytes

    # Read in source file to use for unarchive test
    source = os.path.expanduser("~/test_data/test_unarchive.tgz")
    fp = open(source, 'rb')
    source_content = fp.read()
    fp.close()

    # Populate a object to use as task_vars
    task_vars = dict(
        ansible_connection='local',
        ansible_user='joe',
        ansible_ssh_pass='none',
        remote_tmp='/tmp',
        ansible_check_mode=True,
        ansible_shell_type='csh',
    )

    # Generate a dict to use as the source for the ActionModule.
    source_dict = dict

# Generated at 2022-06-21 03:13:35.035812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_var = dict()
    my_var.update({ 'my_task_vars': dict()})
    my_var['my_task_vars'].update({ 'ansible_check_mode': False })
    my_var['my_task_vars'].update({ 'ansible_diff_mode': False })
    my_var['my_task_vars'].update({ 'ansible_no_log': False })
    my_var['my_task_vars'].update({ 'ansible_verbosity': 0 })
    my_var['my_task_vars'].update({ 'create_variables': None })
    my_var['my_task_vars'].update({ 'environment': None })
    my_var['my_task_vars'].update({ 'no_log': False })
   

# Generated at 2022-06-21 03:13:35.970722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 03:13:47.800308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json

    if sys.version_info.major < 3:
        import mock
    else:
        from unittest import mock

    import ansible.plugins.action.unarchive
    actionModule = ansible.plugins.action.unarchive.ActionModule()

    def emptyFunction(*args, **kwargs):
        pass

    def sideEffectFunction(parameter):
        if (parameter == 'foo'):
            return 'bar'
        else:
            return parameter

    m = mock.mock_open()

# Generated at 2022-06-21 03:13:59.786075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            args=dict(
                src='source',
                dest='destination',
                remote_src=False,
                creates='creates',
                decrypt=True
            )
        ),
        connection=dict(
            module_implementation_preferences=[]
        ),
        play_context=dict(
            check_mode=True,
            diff=True
        ),
        loader=dict(),
        templar=dict(),
        share_loader_obj=False
    )


# Generated at 2022-06-21 03:14:38.881647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test the ability to unarchive a file on the remote host """

    # Dummy variables for the unit test.
    task_vars = dict()

    # Raise an AnsibleActionSkip exception when the file to unarchive, 'creates', already exists.
    try:
        ActionModule.run(
            ActionModule(),
            tmp=None,
            task_vars=task_vars,
            creates='/var/tmp/foo'
        )
    except AnsibleActionSkip as e:
        pass

    # Raise an AnsibleActionFail exception when 'dest' is not an existing directory

# Generated at 2022-06-21 03:14:49.294268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory


    # Create the module
    action_module = AnsibleModule(
        argument_spec = dict(
           src = dict(required=True, type='str'),
           dest = dict(required=True, type='str'),
           remote_src = dict(required=False, type='bool', default=False),
           creates = dict(required=False, type='str'),
           decrypt = dict(required=False, type='bool', default=True),
       ),
        add_file_common_args=True,
        supports_check_mode=True
    )


# Generated at 2022-06-21 03:14:55.598880
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # open AnsibleModule for unarchive module and check possibility to construct it
    unarchive_module = unarchive_module()
    print(unarchive_module)

# Generated at 2022-06-21 03:15:02.312267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    task['args']['src'] = dict()
    task['args']['dest'] = dict()
    task['args']['remote_src'] = dict()
    task['args']['creates'] = dict()
    task['args']['decrypt'] = dict()
    task_vars = dict()
    result = dict()
    action_module = ActionModule(task, task_vars, result)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:15:14.025266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Run tests on the action module run method. '''

    # Create a test AnsibleTaskVars module.
    task_vars = {}

    # Create a test module.
    task = AnsibleTask()
    task._task.args = {'remote_src': 'False', 'src': 'test.txt', 'dest': '/root'}
    # Create a test module.
    module = ModuleBase(task)

    # Create a test AnsibleActionModule object.
    action = ActionModule(module)

    # Run the test run method.
    result = action.run(task_vars)
    assert 'skipped' in result

    task._task.args = {'remote_src': 'False', 'src': 'test.txt', 'dest': '/root', 'creates': 'test.txt'}

    # Run the test

# Generated at 2022-06-21 03:15:22.567920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test scenario:
    - Create an ActionModule object.
    - Test if calls to module's "run" method fail or succeed (Exception is thrown if fail).
    '''
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts import get_collector_instance, get_collection_type
    from ansible.module_utils.facts.system import OperatingSystem

    # Setup fake environment.
    context.CLIARGS = lambda: None

# Generated at 2022-06-21 03:15:23.122218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:24.299978
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module = ActionModule()
  assert isinstance(module, ActionModule)

# Generated at 2022-06-21 03:15:25.723674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test_ActionModule_run()
    raise NotImplementedError()

# Generated at 2022-06-21 03:15:32.980518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile
    import unittest


# Generated at 2022-06-21 03:16:47.682002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:16:58.612093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case #1
    """
    module = ActionModule()
    module._task = None
    tmp = None
    task_vars = None
    result = module.run(tmp, task_vars)
    assert result == {'_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_verbose_override': False}
    """
    Test case #2
    """
    module = ActionModule()
    module._task = None
    tmp = None
    task_vars = {}
    result = module.run(tmp, task_vars)
    assert result == {'_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_verbose_override': False}


# Generated at 2022-06-21 03:16:59.302948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:16:59.880329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:17:09.197532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # All of the meta_vars are optional, but we will supply one.
    meta_vars = {"user": "bob"}

    # All of the task_vars are optional, but we will supply one.
    task_vars = {"user": "bob"}

    # Constructor for ActionModule
    am = ActionModule(meta_vars=meta_vars, task_vars=task_vars)

    # Returns a dict
    # CCTODO: Should we check to see if it returns the correct dict?
    # CCTODO: or if it returns a dict at all?
    # assertIsInstance(am.run(), dict())

    # Returns a dict
    # CCTODO: Should we check to see if it returns the correct dict?
    # CCTODO: or if it returns a dict at all?

# Generated at 2022-06-21 03:17:10.080611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:17:19.046665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This method tests ActionModule.
    """
    # Create an object for ActionModule class for testing
    action_module = ActionModule(connection=None,
                                 task_vars={'var1': 'var2', 'var2': 'var1'},
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    assert action_module.task_vars == {'var1': 'var2', 'var2': 'var1'}

# Generated at 2022-06-21 03:17:21.589646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule('action_plugins', 'library', {'module_utils': 'library.utils'})
    assert instance is not None

# Generated at 2022-06-21 03:17:29.423845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.copy import ActionModule
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    new_module_args = {
        'content': '#!/bin/bash\n\necho "This is a test file.  It is only a test.  It is only a test."\n',
        'dest': '/home/vagrant/myfile.txt',
    }

# Generated at 2022-06-21 03:17:41.042155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    This module tests for ActionModule class constructor and it's member functions
    '''
    from ansible.plugins.action.copy import ActionModule as CopyModule
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    # Set context variable
    context.CLIARGS = {}

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'dest': '/tmp', 'src': '/bin/echo'}
    variable_manager.options_vars['connection_plugins']

# Generated at 2022-06-21 03:20:35.047959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return "good"
    mod = MockModule()
    assert mod.run() == "good"



# Generated at 2022-06-21 03:20:38.027340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('action_plugin_test', 'mock_connection', {'dest': 'dir', 'src': 'file'})

# Generated at 2022-06-21 03:20:40.635699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule()
    assert cls.__doc__ == ''' handler for unarchive operations '''
    assert cls.TRANSFERS_FILES is True
