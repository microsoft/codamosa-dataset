

# Generated at 2022-06-21 03:11:00.368058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_class_instance = MockClass()
    mock_class_instance._connection=MockClass()
    mock_class_instance._connection._shell=MockClass()
    mock_class_instance._task=MockClass()
    mock_class_instance._task.args = {'src':'source', 'dest':'dest', 'creates':'test'}
    mock_class_instance._remove_tmp_path=MockClass()
    mock_class_instance._remote_expand_user=MockClass()
    mock_class_instance._execute_remote_stat=MockClass()
    mock_class_instance._execute_remote_stat.return_value = {'exists':True, 'isdir':True}
    mock_class_instance._loader = MockClass()
    mock_class_instance._transfer_file=M

# Generated at 2022-06-21 03:11:11.601181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    host = "localhost"
    connection = "local"
    play_context = {}
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager()

# Generated at 2022-06-21 03:11:14.621307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule('./test/yaml/is_directory.yaml', './test/files/unarchive').is_playbook()


# Generated at 2022-06-21 03:11:24.652309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.pytest.fixtures.mock_connection import mock_connection
    # No parameters passed in for task args.
    _action_module = ActionModule(mock_connection(), dict())

    with pytest.raises(AnsibleActionFail) as exec_info:
        _action_module.run()

    # Both src and dest passed in.
    _action_module = ActionModule(mock_connection(), dict(src='the_src', dest='the_dest'))

    with pytest.raises(AnsibleActionFail) as exec_info:
        _action_module.run()

    # Neither src nor dest passed in.
    _task_vars = dict(connection="local")

# Generated at 2022-06-21 03:11:25.353853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, 'No unit test written for ActionModule'

# Generated at 2022-06-21 03:11:26.509256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:11:30.109029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)
    assert action_module.TRANSFERS_FILES is True

# Generated at 2022-06-21 03:11:30.832874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:11:32.663751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False


# Generated at 2022-06-21 03:11:35.361955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule

    This method tests the run method of class ActionModule
    """
    ActionModule = ActionModule()
    ActionModule.run(tmp = None, task_vars = None)

# Generated at 2022-06-21 03:11:43.572859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:11:50.377385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule():
        def __init__(self):
            self.params = dict()
            self.params['src'] = "source"
            self.params['dest'] = "destination"
            self.params['remote_src'] = "False"
            self.params['creates'] = "creates"
            self.params['decrypt'] = "decrypt"

    class AnsibleAction():
        def __init__(self):
            self._task = AnsibleModule()
            self._task.args = dict()
            self._task.args['src'] = "source"
            self._task.args['dest'] = "destination"
            self._task.args['remote_src'] = "False"
            self._task.args['creates'] = "creates"

# Generated at 2022-06-21 03:11:54.963059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == "ActionModule"
    assert ActionModule.__doc__ == """ handler for unarchive operations """
    assert ActionModule.TRANSFERS_FILES == True


# Generated at 2022-06-21 03:11:56.516605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None

# This unit test is needed to satisfy code coverage.

# Generated at 2022-06-21 03:12:06.541945
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:12:07.253109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:12:09.148769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(src='source', dest='destination')))

# Generated at 2022-06-21 03:12:18.689569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the following lines create an instance of the class ActionModule.
    # This is needed to call the run method which is being tested.
    task_mock = MagicMock()
    task_mock.args = {}
    loader_mock = MagicMock()
    tqm_mock = MagicMock()
    tmp_mock = '/tmp'
    new_am = ActionModule(task_mock, loader_mock, tqm_mock, tmp_mock)

    # test with an invalid src
    result = new_am.run(tmp=None, task_vars=None)
    assert result['failed']

# Generated at 2022-06-21 03:12:26.695823
# Unit test for constructor of class ActionModule
def test_ActionModule():
	input = {'ansible_connection': 'asdf', 'ansible_connection_type': 'asdf', 'ansible_forks': 2, 'ansible_module_name': 'asdf', 'ansible_module_args': {  '_ansible_module_name': 'asdf', 'asdf': 'asdf'  }, 'ansible_play_batch_size': 'asdf', 'ansible_play_hosts': ['asdf'], 'ansible_playbook_python': 'asdf'}
	action_module = ActionModule(input)


# Generated at 2022-06-21 03:12:28.115572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-21 03:12:45.141294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict())

# Generated at 2022-06-21 03:12:45.771238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:12:50.817442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    create an instance of the ActionModule class
    '''

    action_module_obj = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert type(action_module_obj).__name__ == 'ActionModule'

# Generated at 2022-06-21 03:13:02.022240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.archive import ActionModule
    from ansible.plugins.action.unarchive import ActionModule
    # test for valid inputs
    a = ActionModule(task={'args':{'src':'src', 'dest':'dest'}}, connection={'_shell': {'tmpdir': 'tmp'}})
    a._execute_module = lambda name, args, vars: {'rc': 0}
    assert a.run()['rc'] == 0
    # test for invalid inputs
    a = ActionModule(task={'args':{}}, connection={'_shell': {'tmpdir': 'tmp'}})
    try:
        a.run()
    except AnsibleActionFail:
        # do nothing
        pass

# Generated at 2022-06-21 03:13:11.088791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test run method of ActionModule with all options"""
    action_module = ActionModule()
    task = {
        "action": {
            "__ansible_module__": "test",
            "__ansible_arguments__": {
                "src": "/tmp/src",
                "dest": "/tmp/dest",
                "remote_src": False,
                "creates": "test.txt",
                "decrypt": True
            }
        },
        "args": {
            "content": "abc",
            "copy": False,
            "decrypt": True,
            "remote_src": True,
            "src": "/tmp/src",
            "dest": "/tmp/dest"
        }
    }

# Generated at 2022-06-21 03:13:17.412653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = AnsibleActionModule(
        task=dict(action=dict(module_name='copy', module_args=dict(), tmp='/tmp', task_vars=dict()),
                 args=dict(), async_val=10, async_jid='1234567890', delegate_to=False, environment={},
                 name='copy', tags=[], tmp='/tmp'))
    print(ansible)


# Generated at 2022-06-21 03:13:25.547360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(
        task=dict(
            args=dict(
                src=dict(
                    string="some string"
                )
            )
        )
    )

# Generated at 2022-06-21 03:13:26.719956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('hello', 'world'), ActionModule)

# Generated at 2022-06-21 03:13:33.350854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not class_instance.TRANSFERS_FILES
    assert class_instance._remote_expand_user('~') == '/home/user'
    assert class_instance._remote_file_exists('/home/user/filename') is True
    assert class_instance._find_needle('files', 'home/user/filename') == 'home/user/filename'
    assert class_instance._fixup_perms2(('home/user/filename'))
    assert class_instance._remove_tmp_path('home/tmp')

# Generated at 2022-06-21 03:13:34.411857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.unarchive as unarchive
    assert unarchive.ActionModule

# Generated at 2022-06-21 03:14:06.819447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myActionModule = ActionModule()
    print(myActionModule.run())
    assert False

# Generated at 2022-06-21 03:14:14.186087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test for constructor of class ActionModule
    :return:
    '''
    obj = ActionModule(task={"args": {"dest": "/home/test", "src": "/etc/test.tar.gz"},
                             "action": "file_module",
                             "name": "test", "module": "copy"})
    # CCTODO: Test the results of obj.run()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 03:14:23.559083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    TASK_VARS = {
        'ansible_user': 'username',
        'ansible_password': 'password',
        'ansible_ssh_private_key_file': '/path/to/private/key',
        'ansible_host': 'hostname',
        'ansible_port': 22
    }
    ACTION_MODULE_TASK = {
        'args': {
            'dest': '/path/to/dest/',
            'src': '/path/to/src/',
            'remote_src': True
        }
    }
    ACTUAL_TASK_ARGUMENTS = {
        'src': '/path/to/src/',
        'dest': '/path/to/dest/',
        'remote_src': True
    }

    # Setup the imports
    import tempfile

# Generated at 2022-06-21 03:14:33.885666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    context = PlayContext()
    context._tqm = None
    context._play = None
    context.remote_addr = None
    context.connection = 'local'
    context.remote_user = None
    context.port = None
    context.become = False
    context.become_method = None
    context.become_user = None
    context.no_log = False
    context.verbosity = 0

    task = Task()
    task._role = None
    task._block = None
    task._play = None

# Generated at 2022-06-21 03:14:40.777266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager

    # Create new task and connection
    task = Task()
    task.action = 'unarchive'
    task.args = {'src': 'my_archive.tar',
                 'dest': '/tmp/my_destination'}

# Generated at 2022-06-21 03:14:50.180729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the data to test.
    data = ActionModule._get_test_data('test_ActionModule_run.yml')
    # Get the hosts and tasks.
    hosts = data["hosts"]
    tasks = data["tasks"]
    # Create a variable manager.
    variable_manager = VariableManager()
    # Get the variable manager.
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None, args=[])
    variable_manager.options_vars = load_options_vars(loader=None)
    # Create a loader.
    loader = DataLoader()
    # Create a task queue manager.

# Generated at 2022-06-21 03:15:00.300361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of AnsibleTask to test
    # constructor of class ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    # Create an instance of AnsibleTask
    h_task = Task()
    h_task._role = None

    # Create an instance of TaskExecutor
    h_task_executor = Task

# Generated at 2022-06-21 03:15:08.030240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest

    # Test case 1:
    # Test with normal parameters
    result = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert result.TRANSFERS_FILES
    assert result.SUPPORTED_FILTERS == frozenset(('unarchive',))

    # Test case 2:
    # Test with non-dict parameters
    with pytest.raises(TypeError) as error:
        ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, **'non-dict')
    assert "Unexpected type of parameter" in str(error.value)

# Generated at 2022-06-21 03:15:18.629002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run()")

    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost', 'otherhost'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 03:15:22.092862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Create an instance of the class.
        myObject = ActionModule()
    except Exception as excep:
        assert False, "ActionModule class constructor unit test failed." + str(excep)



# Generated at 2022-06-21 03:16:37.727619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:16:39.442937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Remove this return statement when you implement your test.
    return None

# Generated at 2022-06-21 03:16:47.322582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play

    from ansible.playbook.block import Block

    from ansible.playbook.task import Task

    from ansible.playbook.role import Role

    from ansible.playbook.handler import Handler

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.play_iterator import PlayIterator

    from ansible.plugins.loader import add_all_plugin_dirs

    import ansible.constants as C

    from ansible.plugins.loader import ActionModuleLoader

    from ansible.inventory.manager import InventoryManager

    from ansible.inventory.host import Host

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 03:16:58.294343
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:17:02.848443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of module
    module = unarchive.ActionModule()
    # Create a variable ``result``, so that the return value of method ``run`` can be stored in it.
    result = {}
    # Execute the method ``run`` of class ``module``.
    result = module.run()
    return result

# Generated at 2022-06-21 03:17:11.086050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.legacy.unarchive import ActionModule
    from ansible.utils.path import makedirs_safe
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import become_loader

    # Create temp directory and files to work with.
    temp_dir = mkdtemp()
    temp_src = os.path.join(temp_dir, 'test.tar.gz')
    temp_dest = os.path.join(temp_dir, 'test_dest')
    with open(temp_src, 'wb') as src_tarball:
        src_tarball.write(b'src-test')
    makedirs_safe(temp_dest)

    # Create mock for class ActionBase (we must

# Generated at 2022-06-21 03:17:22.878321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C


    class Base(object):
        def __init__(self):
            self.ROLE_CACHE = dict()
            
    class Options():
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = C.DEFAULT_FORKS
            self.become = False
            self.become_method = 'sudo'
            self.become_user = None

# Generated at 2022-06-21 03:17:23.620170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:17:24.605021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 03:17:25.669594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert("ActionModule" in globals())

# Generated at 2022-06-21 03:20:16.930787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return True  # Not implemented

# Generated at 2022-06-21 03:20:17.947170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement
    pass

# Generated at 2022-06-21 03:20:25.739048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor in following order:
    # 1. empty action
    # 2. empty task
    # 3. empty connection
    # 4. empty play_context
    # 5. everything else normal
    action = None
    task = None
    connection = None
    play_context = None
    test_args = [
        action,
        task,
        connection,
        play_context
        ]
    for arg in test_args:
        try:
            arg = arg
            test = unarchive.ActionModule(arg)
        except Exception:
            raise AssertionError('Constructor raised Exception unexpectedly!')
        finally:
            del test


# Generated at 2022-06-21 03:20:26.299421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:20:28.635381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 03:20:30.079564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constructing the target
    target = ActionModule()
    # Constructing the source
    # Testing the target
    pass

# Generated at 2022-06-21 03:20:35.844327
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    source_str = 'Test source string.'
    dest_str = '/some/path'
    task_vars_str = 'Test task_vars string.'
    tmp_str = 'Test tmp string.'
    remote_src_str = 'True'

    # Test case 1 - failure, as source is None.
    source_str = None
    result = module.run(tmp=tmp_str, task_vars=task_vars_str)
    assert result['failed'] == True
    assert result['msg'] == 'src (or content) and dest are required'

    # Test case 2 - failure, as dest is None.
    source_str = 'Test source string.'
    dest_str = None

# Generated at 2022-06-21 03:20:36.522951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 03:20:38.806304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None, "ActionModule module not loaded"
    actionmodule = ActionModule()
    assert actionmodule is not None, "Failed to create ActionModule object"