

# Generated at 2022-06-21 03:11:01.565880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import dummy_plugins.action.unarchive as unarchive
    import ansible.utils.unsafe_proxy as unsafe_proxy
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Required for AnsibleActionSkip, AnsibleActionFail and AnsibleAction.
    from ansible.errors import AnsibleAction
    from ansible.errors import AnsibleActionFail
    from ansible.errors import AnsibleActionSkip
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-21 03:11:06.057646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule), "Error: constructor of ActionModule class did not return an instance"
    assert isinstance(action_module, object), "Error: constructor of ActionModule class did not return an object"

# Generated at 2022-06-21 03:11:10.649804
# Unit test for method run of class ActionModule
def test_ActionModule_run(): # pylint: disable=redefined-outer-name
    ''' Unit test for method run of class ActionModule. '''

    import unittest
    import mock
    import os

    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.plugins.test import ActionModuleTestCase

    # Mocks
    _tmp_path_exc = os.path.join('tmp', 'path', 'does', 'not', 'exist')
    _tmp_path = os.path.join('tmp', 'path')
    _tmp_path_good = os.path.join(_tmp_path, 'good')
    _remote_path = os.path.join('remote', 'path')
    _remote_path_good = os.path.join(_remote_path, 'good')


# Generated at 2022-06-21 03:11:15.184068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(a=1), dict(b=2))
    assert a._task.args['a'] == 1
    assert a._shared_loader_obj.mfr._task_vars['b'] == 2
    assert a._shared_loader_obj.mfr._plugin_name == 'action_plugins'

# Generated at 2022-06-21 03:11:18.048751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructing an object of  class ActionModule...")
    action_module = ActionModule()
    print("Testing constructor of class ActionModule: OK!")


# Generated at 2022-06-21 03:11:26.420171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    t = Task()
    t.action = 'copy'
    t.args = {'src': 'some_file', 'dest': 'some_path'}

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    print(ActionModule(task = t, connection = None, play_context = None, loader = loader, templar = None, shared_loader_obj = None, variable_manager = variable_manager))

# Generated at 2022-06-21 03:11:27.735268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 03:11:39.413157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.system.os import Os
    from ansible.utils.display import Display
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_loader
    from ansible.plugins.strategy import ActionModuleComponent

    class TestHost(object):
        def __init__(self, connection=None):
            self.connection = connection
            self._shell = None
        def get_shell(self):
            return self._shell
        def set_shell(self, shell):
            self._shell = shell
        shell = property(get_shell, set_shell)


# Generated at 2022-06-21 03:11:45.007482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Delete if the file already exists
    if os.path.isfile("testdata/unarchive_test1.tar.gz"):
        os.remove("testdata/unarchive_test1.tar.gz")
    # Test for no arguments
    null_args = [{'name': 'test', 'src': None, 'dest': None, 'remote_src': False, 'decrypt': True}]
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.run(tmp=None, task_vars=null_args) == {'skipped': True, 'skipped_reason': 'src (or content) and dest are required'}
    # Test for no dest

# Generated at 2022-06-21 03:11:48.794364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule('uni', 'archive', 'src=a', 'dest=b', 'creates=c')

    assert a._task.action == 'uni'
    assert a._task.name == 'archive'
    assert a._task.args['src'] == 'a'
    assert a._task.args['dest'] == 'b'
    assert a._task.args['creates'] == 'c'

# Generated at 2022-06-21 03:11:58.588741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(args=dict()), connection=dict())

    am.run()


# Generated at 2022-06-21 03:12:00.214767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == hasattr(ActionModule, 'run')

# Generated at 2022-06-21 03:12:01.705248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_one = ActionModule()

# Generated at 2022-06-21 03:12:09.792612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This tests that the constructor of this class behaves as expected.
    # This test is a very simple sanity check.  It doesn't even test the run method.

    # First, initialize the values that the constructor will need.
    # The fix for issue 20362 (https://github.com/ansible/ansible-modules-core/pull/3796/commits/fe7b3c0b9a0e318b9820107e297354b1a67d0656)
    # adds an availaible_actions['ActionModule'] to this module.
    # That dictionary is used to obtain the 'class' value for this test.
    the_class = availaible_actions['ActionModule']

    task = {}
    connection = {}
    play_context = {}
    loader = {}
    templar = {}

# Generated at 2022-06-21 03:12:13.976433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the function run() in the class ActionModule.
    # Test the case where source is None or dest is None.
    # Input data:
    tmp = None
    task_vars = dict()
    action_module = ActionModule(tmp, task_vars)
    src = None
    dest = None
    created = None
    decrypt = True

    result = dict()

    try:
        # Test the case where source is None or dest is None.
        action_module.run(src, dest, created, decrypt, result)
    except AnsibleActionFail as e:
        pass
    else:
        raise Exception('Expected Exception to be raised.')

# Generated at 2022-06-21 03:12:25.300632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    task['action'] = dict()
    task['action']['name'] = "copy"
    task['action']['args'] = dict()
    task['action']['args']['src'] = "source"
    task['connection'] = dict()
    task['connection']['module_implementation_class'] = "Connection"
    task['connection']['module_name'] = "Connection"
    task['connection']['module_args'] = dict()
    task['connection']['module_args']['host'] = "localhost"
    task['connection']['module_args']['password'] = "password"
    task['connection']['module_args']['username'] = "username"
    task['connection']['queue'] = dict()

# Generated at 2022-06-21 03:12:31.998857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    tmp = {
        'content': b"",
        'encoding': 'uuencode',
        'src': '/file',
        'path': '/path',
        'dest': '/dest',
        'creates': '/creates',
        'remote_src': False,
        'convert_to_utf8': True,
        'decrypt': True
    }
    task_vars = {
    }
    _ = ActionModule(None, tmp, None)


# Generated at 2022-06-21 03:12:44.022056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ModuleArgs
    from ansible.module_utils.parsing.convert_bool import boolean

    test_action = ActionModule()
    test_task = {
        'args': {
            'creates': '/etc/puppet',
            'decrypt': True,
            'dest': '/root',
            'remote_src': True,
            'src': 'puppet',
        },
        'name': 'unarchive a file',
    }
    test_action._play_context = None
    test_action._task = test_task
    test_action._task_vars = {}
    test_result = TaskResult(host=None, task=test_task)

# Generated at 2022-06-21 03:12:54.503558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DummyExecutor(object):
        @staticmethod
        def get_real_file(filename, decrypt):
            return filename

        @staticmethod
        def _execute_remote_stat(dest, all_vars, follow):
            return {"exists": True, "isdir": True}

        @staticmethod
        def _transfer_file(source, dest):
            pass

        @staticmethod
        def _fixup_perms2(paths):
            pass

        @staticmethod
        def _find_needle(dir1, filename):
            return filename

    class DummyTask(object):
        def __init__(self):
            self.action = 'unarchive'

# Generated at 2022-06-21 03:13:01.925448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(
        task=dict(
            args=dict(
                src='./test-file',
                dest='/tmp',
                remote_src=True,
                decrypt=True,
                creates=None,
            ),
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    assert AM


# Generated at 2022-06-21 03:13:21.116114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if the class can be instantiated
    am = ActionModule()
    assert am is not None

    # Test the class variables that are set in the constructor
    assert am.TRANSFERS_FILES == True

    # Unit test complete
    assert True

# Generated at 2022-06-21 03:13:28.057312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # declared method for a test
    def _run(self, tmp=None, task_vars=None):
        ''' handler for unarchive operations '''
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)

        source = self._task.args.get('src', None)
        dest = self._task.args.get('dest', None)
        remote_src = boolean(self._task.args.get('remote_src', False), strict=False)
        creates = self._task.args.get('creates', None)
        decrypt = self._task.args.get('decrypt', True)


# Generated at 2022-06-21 03:13:30.008660
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert(module.run(tmp='tmp', task_vars={}) == {})

# Generated at 2022-06-21 03:13:36.147693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert(action_module is not None)
    assert(action_module._task is None)
    assert(action_module._connection is None)
    assert(action_module._play_context is None)
    assert(action_module._loader is None)
    assert(action_module._templar is None)
    assert(action_module._shared_loader_obj is None)
    assert(action_module._action is True)
    assert(action_module._task_vars is None)
    assert(action_module._post_validation is None)
    assert(action_module._always_run is None)

# Generated at 2022-06-21 03:13:47.954886
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_parameters_01 = {
        'src': 'sources_01.tar.gz',
        'dest': '/tmp',
        'remote_src': 'True',
        'creates': None,
        'decrypt': True
    }
    test_task_01 = {
        'args': test_parameters_01,
        'delegate_to': None
    }
    test_tasks_01 = [test_task_01]

    test_parameters_02 = {
        'src': 'sources_02.tar.gz',
        'dest': '/tmp',
        'remote_src': 'False',
        'creates': None,
        'decrypt': True
    }

# Generated at 2022-06-21 03:13:55.375013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # CCTODO: Need to make this test work with Windows hosts
    # CCTODO: Need to make this test work with ptys
    # CCTODO: Need to cover the branch: if creates:
    # CCTODO: Need to cover the branch: if not remote_src:
    # CCTODO: Need to cover the branch: try:

    # CCTODO: Need to test this method.
    pass



# Generated at 2022-06-21 03:13:59.603505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule(None, None, None, None, None)
    # get_info() is an abstract method in parent class ActionBase, so no need to test
    assert test_action.supports_check_mode == True
    assert test_action.supports_async == True


# Generated at 2022-06-21 03:14:00.261053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:14:00.889396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:14:01.778180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:14:33.105269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:14:42.630413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule. '''
    # create a task to pass to the action module
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_argspec'] = dict() # TODO: investigate why this is here.
    task['action']['__ansible_argspec']['args'] = dict()
    task['action']['__ansible_argspec']['defaults'] = dict()
    task['action']['__ansible_argspec']['kwargs'] = dict()

    # create a fake connection to pass to the action module
    connection = dict()
    connection['_shell'] = dict()
    connection['_shell']['tmpdir'] = 'my\tmp\path'

# Generated at 2022-06-21 03:14:51.309196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.unarchive import ActionModule
    import os

    # Modifying the source of unarchive for test, so that the original
    # source does not get affected by this test.
    src_path = 'ansible/plugins/action/unarchive.py'
    f = open(src_path, 'r')
    contents = f.read()
    contents = contents.replace('def run(self, tmp=None, task_vars=None):', 'def run_test(self, tmp=None, task_vars=None):')
    f.close()
    f = open(src_path, 'w')
    f.write(contents)
    f.close()

    # Creating an object of the ActionModule class.
    action_module = ActionModule()

# Generated at 2022-06-21 03:14:57.251169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = dict()
    task = dict()
    task["args"] = dict() 
    task["args"]["content"] = "abc123"
    task["args"]["dest"] = "/tmp/test-file"
    # Call the constructor of ActionModule
    action_mod = ActionModule(config=config, task=task)

    # Call the method run
    res = action_mod.run()
    assert(res == {})

# Generated at 2022-06-21 03:14:59.420445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(module_name='ansible.legacy.unarchive', task_vars=dict())
    assert am.module_name == 'ansible.legacy.unarchive'

# Generated at 2022-06-21 03:14:59.917663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:00.830686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:15:08.710747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass in None for the connection object to avoid TypeError
    test_action = ActionModule(
        task=dict(
            args=dict(
                src='test_src',
                dest='test_dest',
                creates='test_creates',
                decrypt=False
            )
        ),
        connection=None
    )

    assert test_action
    assert test_action.name == 'copy'
    assert test_action.pattern == '???'
    assert test_action.transfers_files is True
    assert test_action._task.args['src'] == 'test_src'
    assert test_action._task.args['dest'] == 'test_dest'
    assert test_action._task.args['creates'] == 'test_creates'
    assert not test_action._task.args['decrypt']

#

# Generated at 2022-06-21 03:15:11.335395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("**** test_ActionModule ****")

    # Constructor of base class returns an instance of ActionBase
    a = ActionModule()
    print(a)

# Generated at 2022-06-21 03:15:11.906882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:16:23.233157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.set_runner(RunnerMock())

    action.set_task(TaskMock({'args': {}}))
    action.run()



# Generated at 2022-06-21 03:16:29.378251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule used in Ansible module
    unarchive.
    '''
    print('Testing ActionModule.run')
    # Create an instance of class ActionModule
    act_mod = ActionModule()
    # Provide input parameters
    act_mod._task.args['src'] = 'test_src'
    act_mod._task.args['dest'] = 'test_dest'
    act_mod.run()


# Generated at 2022-06-21 03:16:40.366818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.file import is_executable
    from ansible.executor.task_result import TaskResult
    
    context = PlayContext()
    context._shell.tmpdir="/tmp"
    context._shell.system= "posix"
    result = TaskResult(host=context.remote_addr, task=None, task_items=None)
    
    # test if the module is executable
    assert is_executable('/usr/local/lib/python3.7/dist-packages/ansible/plugins/action/unarchive.py')
    
    # test if the result type is a dict
    assert type(test_ActionModule_run.__action_module__.run(context, None)) is dict
    
    # test if the entire

# Generated at 2022-06-21 03:16:42.294744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get an instance of the class
    action_module = ActionModule()
    # test the run method
    action_module.run()

# Generated at 2022-06-21 03:16:46.703396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(args=dict(src='src', dest='dest', remote_src=False)))

    # check if the constructor populates the necessary fields correctly
    assert action_module._task.args['src'] == 'src'
    assert action_module._task.args['dest'] == 'dest'
    assert action_module._task.args['remote_src'] == False

# Generated at 2022-06-21 03:16:58.036460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class under test
    a = ActionModule(loader=None, connection=None, play_context=None)

    # When source is None and dest is None, it should return an AnsibleActionFail
    results = a.run(dict(), dict())
    assert 'failed' in results
    assert results.get('msg') == 'src (or content) and dest are required'

    # When dest is None, it should return an AnsibleActionFail
    src = 'test.txt'
    real_file = './test/ansible_test_data/' + src
    results = a.run(dict(), dict(), src=src)
    assert 'failed' in results
    assert results.get('msg') == 'dest are required'

    # When dest is existing dir,  it should return {'changed': False, 'msg': '

# Generated at 2022-06-21 03:17:01.014401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(src="source", dest="destination", remote_src=False, decrypt=True)))
    action_module.run()

# Generated at 2022-06-21 03:17:10.151389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AVar(object):
        pass
    class SVar(object):
        pass
    connection = AVar()
    connection.shell_plugin_class = SVar()
    connection.shell_plugin_class.tmpdir = 'tmp'
    connection._shell = AVar()
    connection._shell.join_path = lambda x, y: x+','+y
    connection._shell.fixup_perms2 = lambda x: x
    connection._shell.remove_tmp_path = lambda x: x
    connection._shell.tmpdir = 'tmp'
    connection._shell.is_executable = lambda x:x
    task_vars = {'localhost': {}}
    task = AVar()
    task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': 'FALSE'}

# Generated at 2022-06-21 03:17:12.579573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()._connection

# Generated at 2022-06-21 03:17:12.974691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:20:08.204319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.unarchive import ActionModule

    # Create temp directory
    results = os.path.join(tempfile.gettempdir(),
                           '%s-%s' % (tempfile.template, random.randint(1000, 9999)))
    os.mkdir(results)


# Generated at 2022-06-21 03:20:18.858763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # data for setUp
    module_name = 'unarchive'
    module_args = {}

    # data for test
    dest = 'dest'
    path_module_name = 'ansible.builtin.path'
    remote_stat = {}
    local_stat = {}
    remote_src = False
    cmd = None

    # mocks
    mock_module = MagicMock()

# Generated at 2022-06-21 03:20:21.652106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The unit test will run the method run of class ActionModule
    # --
    # TODO: Add unit test to test execution of the method
    # --
    return


# Generated at 2022-06-21 03:20:30.773949
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # object to be tested on
    action_module = ActionModule()

    # Initializing empty dictionary
    task_vars = {}

    # Initializing empty dictionary
    tmp = {}

    # Initializing empty string
    creates = ""

    # Initializing empty string
    decrypt = ""

    # Initializing empty string
    source = ""

    # Initializing empty string
    dest = ""

    # Initializing empty string
    remote_src = ""

    # Create a test task object
    class Task:
        def __init__(self):
            self.args = {'creates': '', 'src': '', 'dest': ''}

    # Create a test connection object
    class Connection:
        def __init__(self):
            self._shell = Shell()

    # Create a test shell object

# Generated at 2022-06-21 03:20:40.881824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.unarchive

    # Test using a path that is a os.path.isdir.
    # Test using a path that is a os.path.isfile.
    # Test using a path that is a os.path.isdir and os.path.isfile.
    # Test using a path that does not exist.
    # Test using a path that does not exist and creating it.
    # Test using a path that does not exist and creating it and creating the file.
    # Test using a path that does not exist and creating it and creating the file.
    # Test using a path that does not exist and creating it and creating the file with a specific mode.
    # Test using a path that does not exist and creating it and creating the file with a specific mode and a specific owner.
    # Test using a path that does not exist and creating it and

# Generated at 2022-06-21 03:20:42.563042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    mod = ActionModule(dict(), dict())

    assert mod is not None