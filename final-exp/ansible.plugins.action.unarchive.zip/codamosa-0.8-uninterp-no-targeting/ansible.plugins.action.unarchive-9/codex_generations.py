

# Generated at 2022-06-21 03:10:59.905920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {
        'copy': "no",
        'decrypt': "yes",
        'dest': '/tmp/mydir',
        'src': "/foo/bar/baz"
    }

    action_module = ActionModule(d, None)
    assert action_module is not None
    assert action_module.action_type is not None
    assert action_module.action_type == 'unarchive'
    assert action_module.transfers_files is not None
    assert action_module.transfers_files

# Generated at 2022-06-21 03:11:11.359431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.module_utils._text import to_bytes
    import pytest

    # An AnsibleActionFail exception is expected to occur.
    # Test when 'src' is not provided.
    # Expected results: raises AnsibleActionFail exception.
    with pytest.raises(AnsibleActionFail):
        ActionModule._execute_module(
            ImmutableDict(
                ANSIBLE_MODULE_ARGS=dict(
                    dest='/fake/path/to/destination',
                    remote_src=True,
                    decrypt=False,
                ),
            ),
        )

    # An

# Generated at 2022-06-21 03:11:13.218869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """


# Generated at 2022-06-21 03:11:23.511718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Preparation
    class ActionModule(object):
        def __init__(self, value):
            self.value = value

        def get(self, key, value=None):
            if key in ['src', 'dest', 'remote_src', 'creates']:
                return self.value
            return None

    task_vars = {'ansible_unit_test_key': 'ansible_unit_test_value'}

    # Test
    import ansible.plugins.action.unarchive as unarchive_module
    a = unarchive_module.ActionModule(ActionModule({'src': 'src',                     'dest': 'dest', 'remote_src': False}))
    a1 = a.run(task_vars=task_vars)
    assert a1 is None


# Generated at 2022-06-21 03:11:33.479850
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock the AnsibleActionFail exception so that we can assert against its
    # message.
    class _ActionModule_run:
        def __init__(self, src, dest):
            self._task = {'args': {'src': src, 'dest': dest}}

    class _ActionModule_run_test_case(_ActionModule_run):
        def __init__(self, src, dest, error_message):
            self._error_message = error_message
            _ActionModule_run.__init__(self, src, dest)

        def run(self, *args, **kwargs):
            try:
                return _ActionModule_run.run(self, *args, **kwargs)
            except AnsibleActionFail as e:
                assert self._error_message == to_text(e)

    # Test with a non exist

# Generated at 2022-06-21 03:11:38.047263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data #1
    task_vars = {}
    action = ActionModule(task=dict(args=dict(src='path/to/source', dest='path/to/dest')))
    action._connection = FakeConnection()
    action._loader = FakeLoader()
    status = action.run(task_vars=task_vars)
    assert status == {}


# Generated at 2022-06-21 03:11:43.790849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # from ..mock import patch
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.action import ActionBase
    # import ansible.runner
    # import ansible.inventory
    # import ansible.playbook

    class TestAction(ActionBase):
        TRANSFERS_FILES = True

        def run(self, tmp=None, task_vars=None):
            return self._execute_module(module_name='ansible.legacy.unarchive', module_args=dict(src='src', dest='dest'), task_vars=dict())

    test_host = 'host name'
    test_port = 2222
    test_user = 'test_user'
    test_pass = 'test_pass'


# Generated at 2022-06-21 03:11:54.394249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = __import__('__main__')
    module.my_vars = dict()
    module.my_vars['ansible_connection'] = 'local'
    module.deprecation = __import__('deprecation')
    module.deprecation.deprecated = lambda x, y, z: (x, y, z)
    class ActionModule():
        _loader = __import__('ansible.parsing.dataloader')
        _connection = __import__('ansible.plugins.connection.local')
        _task = __import__('ansible.playbook.task')
        _execute_remote_stat = __import__('test_unarchive').ActionModule.execute_remote_stat
        _execute_module = __import__('test_unarchive').ActionModule.execute_module
        _transfer_file = __

# Generated at 2022-06-21 03:11:58.922512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    sys.path.append('..')
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.action.copy import ActionModule
    conn = Connection('/')
    test_class = ActionModule(conn=conn,complex_args=dict(),task=dict(),loader=None)
    assert type(test_class) == ActionModule

# Generated at 2022-06-21 03:12:02.161218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    # The constructor for ActionModule does not take any parms, so if we got an object then the constructor worked.
    assert am is not None

# Generated at 2022-06-21 03:12:11.027192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:12:23.092130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = "127.0.0.1"
    ansible_port = 22
    user = "root"
    host_commands_base_directory = "/etc/ansible_host_commands"
    host_commands_directory = os.path.join(host_commands_base_directory, host)
    test_command_files_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'host_commands', host)
    if not os.path.exists(host_commands_base_directory):
        os.mkdir(host_commands_base_directory)
    if not os.path.exists(host_commands_directory):
        os.mkdir(host_commands_directory)

# Generated at 2022-06-21 03:12:29.963570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        _play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(mod, ActionBase)
    assert mod._task.args == dict()
    assert mod._play_context == dict()
    assert mod._connection == dict()
    assert mod._loader is None
    assert mod._templar is None
    assert mod._shared_loader_obj is None

# Generated at 2022-06-21 03:12:32.371228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('', {}, {}, '')
    assert am.TRANSFERS_FILES == True

# Generated at 2022-06-21 03:12:33.625787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #  TODO
    pass


# Generated at 2022-06-21 03:12:41.611811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The class must be instantiated.
    try:
        obj = ActionModule()
        raise AssertionError("Failed to throw an exception when attempting to instantiate an instance of the class 'ActionModule'")
    except Exception:
        pass # Expected

    # The method run must be defined.
    try:
        ActionModule.run()
        raise AssertionError("Failed to throw an exception when attempting to call an abstract method 'run'")
    except Exception:
        pass # Expected

# Generated at 2022-06-21 03:12:48.558453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import get_all_plugin_loaders

    # Creating a valid play obj.
    loader = DataLoader()

# Generated at 2022-06-21 03:12:55.196552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the module is constructed with the correct instance variables.
    action_module_object = ActionModule(load_name="fake_loader", task={"args": {"test_arg": "fake_arg"}}, connection=None,
                                        play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module_object._task.args["test_arg"] == "fake_arg"
    assert action_module_object._loader.load_name == "fake_loader"

# Generated at 2022-06-21 03:12:56.310680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:13:08.011011
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a temporary file that we will use for this test.
    tmp_fh, tmp_file = tempfile.mkstemp()
    os.close(tmp_fh)

    # Create an archive of the temp file and save it as a string
    with open(tmp_file, 'w') as tmp_fh:
        tmp_fh.write('Hello World')
    tmp_archive_data = io.BytesIO()
    archive = tarfile.open(fileobj=tmp_archive_data, mode='w:gz')
    archive.add(tmp_file)
    archive.close()

    # Create the AnsibleAction object, which can be used to call a method on the ActionModule class
    # and pass in a namspace created by ansible.executor.task_executor.

# Generated at 2022-06-21 03:13:24.825059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:13:25.787351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:13:34.833903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sample_task = {"action": {"__ansible_module__": "copy",
                              "__ansible_arguments__": { "src": "source", "dest": "destination", "copy": "yes", "creates": "path/to/file" },
                              "__ansible_module_name__": "copy",
                              "__ansible_module_args__": { "src": "source", "dest": "destination", "copy": "yes", "creates": "path/to/file" }
                             }
                  }
    module_class_name = "ActionModule"
    args = {"task": sample_task, "connection": {}, "play_context": {}, "loader": {}, "templar": {}, "_shared_loader_obj": None, "_task_vars": {}}
    module_

# Generated at 2022-06-21 03:13:42.650431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    module = ActionModule(
        task=dict(action=dict(module_name='unarchive', src=None, dest=None, remote_src=True)),
        connection=dict(),
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module.run(tmp=None, task_vars=task_vars)


# Generated at 2022-06-21 03:13:50.765489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule.
    """
    print("Testing ActionModule - run().")


# Generated at 2022-06-21 03:14:00.662857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        def __init__(self, args):
            self.args = args

    class Task(object):
        def __init__(self):
            self.args = Options(
                {
                    'src': 'hello.txt',
                    'dest': '/hello/hello.txt',
                    'creates': 'hello.txt',
                    'decrypt': True,
                }
            )
            self.async_val = 10000
            self.notify = []
            self.run_once = False

    action = ActionModule(dummy_loader(), Task(), connection=None, play_context=None, only_if = None, when = None, )
    print(action)

# Generated at 2022-06-21 03:14:01.585070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ is not None

# Generated at 2022-06-21 03:14:02.156343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:14:03.743237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ans = ActionModule()
    assert ans.TRANSFERS_FILES == True

# Generated at 2022-06-21 03:14:06.506549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.TRANSFERS_FILES is True

test_ActionModule()

# Generated at 2022-06-21 03:14:49.219551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = mock.Mock(spec=dict)
    mock_task.args = { 'src': 'src', 'dest':'dest', 'remote_src': False, 'creates': None}
    mock_connection = mock.Mock()
    mock_task.args = {'src': 'src', 'dest':'dest', 'remote_src': False, 'creates': None}
    mock_module = ActionModule(mock_task, mock_connection)
    mock_module._connection = mock.Mock(spec=dict)
    mock_module._connection.tmpdir = "tmpdir"
    mock_module._execute_remote_stat = mock.Mock()
    #mock_module._execute_remote_stat.side_effect = AnsibleActionSkip("skipped, since")
    mock_module._remote_expand_

# Generated at 2022-06-21 03:14:50.822029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:00.744514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os, shutil
    from ansible.plugins import action
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.removed import removed

    # Create a mock action module definition from the provided parameter values
    def _create_mock_action_module(action_values):
        # Create a new ActionModule instance
        action_module = action.ActionModule(action_values['task'], action_values['connection'], action_values['play_context'], action_values['loader'], action_values['templar'], action_values['shared_loader_obj'])
        # Add the run method
        def run(tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = {}
            # Set

# Generated at 2022-06-21 03:15:01.720304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:03.046847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    print("ActionModule ", actionModule)

# Generated at 2022-06-21 03:15:09.755800
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import shutil

    from ansible.executor.task_result import TaskResult

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import merge_hash

    from ansible_collections.ansible.community.plugins.action.unarchive import ActionModule

    help(ActionModule)

    def get_playbook_config(loader, host_list):

        class Options(object):
            """
            Options class to replace the Ansible OptParser
            """
            verbosity = None
            inventory = None
            listhosts = None
           

# Generated at 2022-06-21 03:15:19.401646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run test in a clean environment
    # Persistent data will be stored in a sub files/ dir
    # This can effect results
    test_dir = os.path.basename(__file__).split('.')[0]
    root_test_dir = os.path.join(os.getcwd(),test_dir)
    if not os.path.isdir(root_test_dir):
        os.mkdir(root_test_dir)
    elif os.listdir(root_test_dir):
        print("ERROR, %s dir is not empty" % root_test_dir)

    os.chdir(root_test_dir)

    am = ActionModule(None, {'remote_src': True, 'src': 'test.txt', 'dest': '.'}, task_vars={})
    # Check to ensure this

# Generated at 2022-06-21 03:15:20.764937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("No unit tests available for class ActionModule and method run.")

# Generated at 2022-06-21 03:15:22.535327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('<test-playbook>', {})
    assert action_module is not None

# Generated at 2022-06-21 03:15:23.402705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'false' == 'false'

# Generated at 2022-06-21 03:16:38.645543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-21 03:16:39.538026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-21 03:16:47.409897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.copy as action_copy
    reload(action_copy)

    import ansible.module_utils.connection as connection

    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.system.network import get_all_interfaces

    connections = connection.Connection()
    if hasattr(connections, '_connections'):
        connections = connections._connections

    module_args = {}
    module_args['src'] = 'files/test.txt'
    module_args['dest'] = 'tmp/'
    module_args['remote_src'] = False
    module_args['creates'] = 'this/path/does/not/exist'
    module_args['decrypt'] = True

    context = PlayContext()
    context.connection = 'local'

# Generated at 2022-06-21 03:16:50.234891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-21 03:17:00.145845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Module that tests the run method of class ActionModule."""

    # Setup mock objects
    class MockConnection:
        class MockShell:
            def __init__(self):
                pass
            def tmpdir(self):
                return "X"
            def join_path(self, tmpdir, source):
                return tmpdir+"/"+source
        def __init__(self):
            self._shell = MockConnection.MockShell()
        def remote_file_exists(self, file_name):
            return file_name == 'creates'
        def remote_expand_user(self, path):
            return path
        def _remote_expand_user(self, path):
            return self.remote_expand_user(path)

# Generated at 2022-06-21 03:17:09.510024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase
    import ansible.plugins.action.unarchive
    # Constructor of this class will assign values to them.
    connection = None
    # We will mock these classes.
    ansible.plugins.action.unarchive.ActionBase = mock.MagicMock()
    ansible.plugins.action.unarchive.AnsibleModule = mock.MagicMock()
    ansible.plugins.action.unarchive.AnsibleModule.run.return_value = dict(msg='Hello World!')
    # Mock the constructor of the class.
    am = ansible.plugins.action.unarchive.ActionModule(connection, dict(src='src', dest='dest', decrypt=False, creates='creates'))

# Generated at 2022-06-21 03:17:10.342800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:17:14.594237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module.TRANSFERS_FILES == True, "Unarchive should transfer files."

# Generated at 2022-06-21 03:17:24.868600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text_to_dict import text_to_dict
    import unittest
    import unittest.mock
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create a dummy task object and assign our test values.
    task = text_to_dict('''{"args": {"dest": "/home/testrun/dest", "src": "/home/testrun/src", "creates": "/home/testrun/creates", "decrypt": "True", "remote_src": "True"}}''')

    # Create our ActionModule class.
    action = ActionModule(task, {})

    # Create a Mock for the class ActionBase and apply the method run.
    action_base = unittest.mock.Mock(ActionBase)
    action_

# Generated at 2022-06-21 03:17:26.698801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule(None, None, None)
    except Exception as e:
        assert False, str(e)


# Generated at 2022-06-21 03:20:21.255186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:20:22.944588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    # TODO: Test is incomplete, finish implementation
    #assert module.run() == "Hello World"

# Generated at 2022-06-21 03:20:23.699267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:20:24.907764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:20:32.559295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of ActionModule class.
    '''
    args = dict(
        src='test.src',
        dest='test.dest',
        remote_src=False,
        creates=None,
        decrypt=False
    )
    task = dict(
        args=args
    )
    tmp = None
    task_vars = dict()

    # Create ActionModule object.
    try:
        objActionModule = ActionModule(task, tmp, task_vars)
    except AnsibleAction as e:
        assert False, e.result

    # Check the attributes of the object.
    assert objActionModule._task.args == args
    assert objActionModule._task_vars == task_vars

# Generated at 2022-06-21 03:20:42.018105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the test
    action_module = ActionModule(None, None, None, None)
    task_vars = dict()
    action_module._task.args = dict()
    action_module._task.args['src'] = 'path/to/src'
    action_module._task.args['dest'] = 'path/to/dest'
    action_module._task.args['remote_src'] = False
    action_module._task.args['creates'] = 'path/to/existing/file'

    # Perform the test
    result = action_module.run(None, task_vars)

    # Verify the results
    assert result['skipped'] == False
    assert result['changed'] == True
    assert result['msg'] == 'skipped, since path/to/existing/file exists'

# Generated at 2022-06-21 03:20:48.196119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.unarchive'
    module_args = dict(
        #src='source/tmp.tar.gz', dest='/tmp'
        src=None, dest=None,
    )
    task_vars = dict(
        ansible_verbosity=0,
    )
    tmp = None

    action = ActionModule(task_vars=task_vars, tmp=tmp, module_name=module_name, module_args=module_args)
    action._connection = None
    action._task = None
    action._loader = None
    action._templar = None

    # CCTODO: Replace calls to these utilities with mocks.
    action._fixup_perms2 = None
    action._remove_tmp_path = None
    action._execute_module = None
   