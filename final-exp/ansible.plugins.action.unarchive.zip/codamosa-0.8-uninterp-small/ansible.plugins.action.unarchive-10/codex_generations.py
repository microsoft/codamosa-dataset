

# Generated at 2022-06-25 07:52:09.442825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (float_0, float_0, float_0)
    # Test the edge cases for this function.
    # Test the normal cases for this function.
    # Test the exception cases for this function.


# Generated at 2022-06-25 07:52:11.262089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # There is nothing to test in this method, the function is a stub.
    pass


# Generated at 2022-06-25 07:52:12.137756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert None

# Generated at 2022-06-25 07:52:22.322318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    string_0 = "e8X1%h~a!7m_]o&$0"
    unicode_0 = u"u{i-<p\uec27"
    boolean_0 = True
    dict_0 = dict()
    list_0 = [false, false]
    dict_0[0] = list_0
    dict_1 = dict()
    list_0.append(false)
    tuple_0 = ()
    tuple_1 = (dict_1, dict_0, dict_1)
    dict_0[0] = dict_0
    dict_1[0] = dict_0
    dict_0[unicode_0] = dict_0
    dict_1[1] = tuple_1
    dict_0[1] = dict_0

# Generated at 2022-06-25 07:52:25.510738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    unit_test_0 = ActionModule()
    tmp = tempfile.TemporaryDirectory()
    task_vars = {}

    # Run test to see if it throws an exception or not.
    # Initializes the class.
    unit_test_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:27.490161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:52:33.555497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Explicitly test for Python 3.x as unit test only tests Python 3.x
    if sys.version_info[0] >= 3:
        # Explicitly test for Python 3.x as unit test only tests Python 3.x
        if sys.version_info[0] >= 3:
            try:
                # initialize a ActionModule class
                test_case_ActionModule_class_0 = ActionModule()

                # set up parameters
                tmp = ""
                task_vars = test_case_0()

                # run the run method
                test_case_ActionModule_class_0.run(tmp, task_vars)

                # compare results
                test_case_0()
            except Exception as e:
                print("An error occured", e)

# Generated at 2022-06-25 07:52:34.122372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:52:37.145386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_obj_0 = ActionModule()
    task_vars_0 = test_case_0()
    test_var_0 = actionmodule_obj_0.run(task_vars=task_vars_0)

# Generated at 2022-06-25 07:52:42.569161
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Input
    tmp = None
    task_vars = None

    # Output
    result_output = {}
    result_output['changed'] = False

    # Unit test
    result = test_case_0()

    assert result['changed'] == False

# Generated at 2022-06-25 07:53:01.619163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  source = 'src'
  dest = 'dest'
  remote_src = True
  creates = 'creates'
  decrypt = False
  task_vars = 'task_vars'
  float_0 = 1000.0
  int_0 = 135
  tuple_0 = (int_0,)
  str_0 = '#)I!vTW0\x0c7\t'
  set_0 = {int_0, int_0, str_0}
  str_1 = 'i-=wgKjvrkc|gu'
  list_0 = [float_0, str_1, str_0, set_0]
  action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
  # testing ansible.

# Generated at 2022-06-25 07:53:08.435947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = int_0 = tuple_0 = str_1 = float_1 = float_2 = float_3 = None
    str_0 = set_0 = set_1 = list_0 = list_1 = list_2 = list_3 = None
    float_0 = float(input())
    tuple_0 = tuple(map(int, input().split()))
    str_0 = str(input())
    set_0 = set(map(int, input().split()))
    float_1 = float(input())
    list_0 = list(map(float, input().split()))
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_1, list_0)
    set_1 = action_module_0.run()

# Generated at 2022-06-25 07:53:14.277629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = 'source'
    dest = 'dest'
    remote_src = False
    creates = 'creates'
    decrypt = True
    action_module_0 = ActionModule(source, dest, remote_src, creates, decrypt)
    tmp = 'tmp'
    task_vars = {'set_0': {'str_0'}}
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:53:23.940551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    list_0 = [float_0, str_0, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    float_1 = 1000.0
    int_1 = 135
    tuple_1 = (int_0,)

# Generated at 2022-06-25 07:53:26.845921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:53:32.924573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:53:33.326869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-25 07:53:36.207183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")
    action_module_0 = ActionModule()
    assert action_module_0 is not None
    print("Done")


# Generated at 2022-06-25 07:53:43.872643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (135,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    action_module_0 = ActionModule(1000.0, tuple_0, str_0, set_0, 1000.0, list_0)


# Generated at 2022-06-25 07:53:44.918746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:54:13.120478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # float_0 = float(125.0)
    float_0 = float(125.0)
    tuple_0 = (action_module_0, action_module_0, str_0, str_0)
    str_0 = 'Kj;fW\x0bI-H'
    set_0 = {int_0, str_0, str_1}
    float_1 = float(125.0)
    list_0 = [action_module_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_1, list_0)
    var_0 = action_run()
    assert_equals(var_0, True)
    return var_0


# Generated at 2022-06-25 07:54:15.323967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:54:25.188446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:54:35.365286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    assert action_module_0.run(tmp='../ansible.cfg', task_vars='p|Jx>$;9=\x03') == {'skipped': True, 'changed': False}


# Unit

# Generated at 2022-06-25 07:54:37.778143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:54:47.482169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input:
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    # Output:
    var_0 = action_run()

# Generated at 2022-06-25 07:54:51.438670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)

# Generated at 2022-06-25 07:54:55.866423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    assert type(action_module_0) == ActionModule

# Generated at 2022-06-25 07:55:04.400316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3.141592
    int_0 = 16
    tuple_0 = (float_0,)

# Generated at 2022-06-25 07:55:16.120676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 159
    tuple_0 = (int_0,)
    str_0 = 'M`|X9M`|X9M`|X9M`|X9M`|X9'
    set_0 = {int_0, str_0, int_0}
    list_0 = [tuple_0, int_0, set_0]
    action_module_0 = ActionModule(int_0, tuple_0, str_0, set_0, int_0, list_0)
    assert action_module_0._task._args == action_module_0._task_args
    assert action_module_0._task._ds == action_module_0._task_ds
    assert action_module_0._task._uid == action_module_0._task_uid
    assert action_module_0._

# Generated at 2022-06-25 07:55:55.960697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 10
    str_0 = 'Nz(p3qj\x0c0'
    tuple_0 = (int_0, str_0, str_0, int_0, int_0)
    int_1 = 10
    str_1 = "^xO\x7f&\x0bV\x1d"

# Generated at 2022-06-25 07:56:02.439332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0.action_run()


# Generated at 2022-06-25 07:56:12.009327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __main__
    __main__.__builtins__.__dict__['_'] = str
    int_0 = 1000.0
    tuple_0 = (int_0,)
    str_0 = 'PfHv@zw?k8I`)C'
    action_module_0 = ActionModule(int_0, tuple_0, str_0, str_0, int_0, str_0)
    float_0 = 1000.0
    int_1 = 135
    tuple_1 = (int_1,)
    str_1 = '\x0f\x1b\n\x05\x1b\x1a\x0f\x05'
    set_0 = {int_1, int_1, str_1}

# Generated at 2022-06-25 07:56:17.440472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()
    assert var_0 is not None


# Generated at 2022-06-25 07:56:25.430044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    assert not action_module_0.TRANSFERS_FILES
    assert not action_module_0._supports_check_mode

    # Test exception AnsibleActionFail

    # Test exception AnsibleActionSkip

    #

# Generated at 2022-06-25 07:56:33.278852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0.run()
    return


# Generated at 2022-06-25 07:56:33.923025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:56:39.527332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    test_case_0()


# Generated at 2022-06-25 07:56:45.484161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:56:53.857150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up local variables
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0.run()
    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 2

# Generated at 2022-06-25 07:57:57.285355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass


# Generated at 2022-06-25 07:58:05.730969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)


# Generated at 2022-06-25 07:58:07.988780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('In test_ActionModule_run')


# Generated at 2022-06-25 07:58:15.435681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor of class ActionModule')
    float_0 = 0.013
    tuple_0 = (int)
    str_0 = 'o!Z\x05\x07\x16\x02\nxmk\n\x10'
    set_0 = {float_0, tuple_0, str_0}
    str_1 = 'sq/p|vmqpi{'
    list_0 = [float_0, float_0, set_0, str_1]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    print("type of action_module_0: ", type(action_module_0))


# Generated at 2022-06-25 07:58:21.671814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)


# Generated at 2022-06-25 07:58:30.368588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)


# Generated at 2022-06-25 07:58:34.693965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    assert action_module_0.run() == var_0

# Generated at 2022-06-25 07:58:38.664992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    test_case_0()

# Generated at 2022-06-25 07:58:48.814047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        raise AnsibleActionFail(msg)
    except Exception as e:
        raise AnsibleActionSkip(to_text(e))
        # CCTODO: Fix path for Windows hosts.
        if not remote_stat['exists'] or not remote_stat['isdir']:
            raise AnsibleActionFail("dest '%s' must be an existing dir" % dest)
        for key in ('decrypt',):
            if key in new_module_args:
                del new_module_args[key]
        for key in ('decrypt',):
            if key in new_module_args:
                del new_module_args[key]
        for key in ('decrypt',):
            if key in new_module_args:
                del new_module_args[key]

# Generated at 2022-06-25 07:58:49.513031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 08:01:22.607455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float('+5.5')
    tuple_0 = (((+(-23.719444444444447))),)
    str_0 = 'Zo\x14\x15\x14PQV'
    set_0 = {tuple_0[0][0], str_0[3::-1], 'h)!k\x0b'}
    float_1 = float('-2.0')
    list_0 = [(((float_1, float_0), float_0), float_0, float_0), float_1, float_0, float_0, float_1]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    action_module_0.run()

# Unit

# Generated at 2022-06-25 08:01:28.349809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    action_module_0 = ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:01:32.588558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments passed
    test_case_0()
    # Test with arguments
    # CCTODO: Add tests with arguments


# Generated at 2022-06-25 08:01:42.101517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ['\x00\x00', 'C_\x00\x00\x00\x00', 'C_\x00\x00\x00\x00', '\x00\x00']
    list_0[2] = '*\x00\x00\x00'
    list_0[1] = list_0[3]
    list_0[3] = list_0[2]
    str_0 = '-\x00\x00\x00'
    str_1 = list_0[0]
    str_2 = '\x00\x00'
    list_0[1] = '\x00\x00'
    tuple_0 = (str_2,)

# Generated at 2022-06-25 08:01:44.839918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:01:48.913720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    removed('', '')
# End unit test for method run of class ActionModule

# Generated at 2022-06-25 08:01:54.285310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1000.0
    int_0 = 135
    tuple_0 = (int_0,)
    str_0 = '#)I!vTW0\x0c7\t'
    set_0 = {int_0, int_0, str_0}
    str_1 = 'i-=wgKjvrkc|gu'
    list_0 = [float_0, str_1, str_0, set_0]
    print(ActionModule(float_0, tuple_0, str_0, set_0, float_0, list_0))