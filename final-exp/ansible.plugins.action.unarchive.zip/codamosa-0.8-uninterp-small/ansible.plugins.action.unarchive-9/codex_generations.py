

# Generated at 2022-06-25 07:52:07.398600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:13.656600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'GtE|J~&]l'
    float_0 = 0.583451
    action_module_0 = ActionModule(bool_0, str_0, str_0, float_0, str_0, float_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:52:16.604217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:52:22.537499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -454.72187
    action_module_0 = ActionModule(float_0)
    float_1 = -903.6572
    action_module_1 = ActionModule(float_1)
    bool_0 = False
    action_module_2 = ActionModule(bool_0)
    str_0 = 'ej:7VuD@Gzo/7VuD@Gzo'
    action_module_1.run(str_0)
    action_module_0.run(str_0, str_0)
    action_module_2.run(str_0, str_0)


# Generated at 2022-06-25 07:52:23.692549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule:")
    test_case_0()

# Generated at 2022-06-25 07:52:33.297704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -526.31722
    action_module_0 = ActionModule(True, '\tDLdF,ZB8kT', '\tDLdF,ZB8kT', float_0, '\tDLdF,ZB8kT', float_0)
    action_module_0.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:52:34.141811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:52:37.781977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '\tDLdF,ZB8kT'
    float_0 = -526.31722
    action_module_0 = ActionModule(bool_0, str_0, str_0, float_0, str_0, float_0)
    assert(action_module_0 is not None)


# Generated at 2022-06-25 07:52:41.202041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:52:45.301498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with real data
    bool_0 = True
    str_0 = '\tDLdF,ZB8kT'
    float_0 = -526.31722
    action_module_0 = ActionModule(bool_0, str_0, str_0, float_0, str_0, float_0)
    # Test with fake data
    bool_0 = False
    str_0 = '\'\\f\'"xf'
    float_0 = -525.85306
    action_module_1 = ActionModule(bool_0, str_0, str_0, float_0, str_0, float_0)


# Generated at 2022-06-25 07:52:53.106672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:52:54.852055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for class module ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:53:04.205436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_ActionModule_run:'
    var_0 = print(str_0)
    # var_0 = self._loader.get_real_file(self._find_needle('files', source), decrypt=decrypt)
    # var_1 = __AnsibleActionFail__(to_text(e))
    # self._transfer_file(source, tmp_src)
    # var_0 = not boolean(self._task.args.pop('copy'), strict=False)
    # var_0 = not remote_src:
    # var_0 = self._remote_expand_user(creates)
    # if var_0:
        # var_1 = __AnsibleActionSkip__('skipped, since %s exists' % var_0)
    # var_0 = self._remote_expand_

# Generated at 2022-06-25 07:53:06.728977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_ActionModule.run:'
    var_0 = print(str_0)


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:13.498455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_ActionModule:'
    var_0 = print(str_0)

# Generated at 2022-06-25 07:53:20.509093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0:
    ret_0 = test_case_0()
    if ret_0 < 0:
        exit(1)

if __name__ == '__main__':
    # Test 0:
    test_ActionModule()
    exit(0)

# Generated at 2022-06-25 07:53:21.878377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_ActionModule:'
    var_0 = print(str_0)


# Generated at 2022-06-25 07:53:23.472305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:53:26.218800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:53:29.197469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_ActionModule_run:'
    var_0 = print(str_0)

if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule_run()

# [EOF]

# Generated at 2022-06-25 07:53:39.590483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:53:43.645636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)



# Generated at 2022-06-25 07:53:51.016579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)


# Generated at 2022-06-25 07:53:52.573312
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Run method for class ActionModule
    action_module_0 = test_case_0()

# Generated at 2022-06-25 07:54:00.105433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x99\xfe\xa4\x85\xa3\x9a\x83\x9c\xb4\x99\x8f'
    str_1 = '\x9c\x98\xad\xad\xb1\xbd\x8c\x96\xb0\x9f\xb9\xb6\x84\x9c\x90\x8e\xa7\x84\x99\xbc\xb2\xa9\xa2\xbc'
    int_0 = 2922

# Generated at 2022-06-25 07:54:01.975968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:54:10.372606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    print(repr(action_module_0.task_vars))
    print(type(action_module_0.task_vars))
    print(repr(action_module_0.task_vars))
    print(type(action_module_0.task_vars))

# Generated at 2022-06-25 07:54:22.246759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\xfe=\xc5\xe0\xbd\xb5?\xf5'
    str_1 = 'Yb`#=srz\xecw'
    int_0 = 23700
    bytes_0 = b'\x17\x02\x83r\xd1+\xcc\x03'
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    dict_0 = dict()
    dict_1 = dict()
    str_2 = '\x9f\x89\x1e\x1d\xc4\x02\x91\x0b\xe8Q'

# Generated at 2022-06-25 07:54:28.650772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    var_0 = action_module_0.run(None)


# Generated at 2022-06-25 07:54:35.196388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = '0U&\n|N0Y({M'
    str_3 = 'au`KHR&o*ZsC'
    int_1 = 2480
    bytes_1 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_1 = False
    action_module_1 = ActionModule(str_3, int_1, bytes_1, str_3, bytes_1, bool_1)


# Generated at 2022-06-25 07:54:50.673609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:54:51.498046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:54:57.691025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x1b,\x1c\x1a\x0e\x0c\x14\x1c\x1b\x0b\x03\x19\x1c\x0b\x0e\x1a\x00\n\x01\x13\x03\x0a\x1b\x1a\x0e'
    str_1 = '\x1b\x0b\x03\x19\x1c\x0b\x0e\x1a\x00\n\x01\x13\x03\x0a\x1b\x1a\x0e\x1c'
    int_0 = 2480

# Generated at 2022-06-25 07:55:05.042594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'jkp.\x8eA\x87\xa0K'
    str_1 = '\x1a\xe7]:\xce)y\x8f'
    int_0 = 2590
    bytes_0 = b'\x97\xe7\xdc\x88\x8b\xb3\x15\xe5'
    bool_0 = True


# Generated at 2022-06-25 07:55:06.848608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make sure Exception is raised when ActionModule.ActionBase.run is not implemented.
    with pytest.raises(Exception):
        action_module_0 = ActionModule()
        action_module_0.run()

# Generated at 2022-06-25 07:55:15.128660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x91\x84\x8a\x1c\x88\xe6\x83\x8e'
    str_1 = 'Q'
    int_0 = 1056
    bytes_0 = b'\xd8\xec\xbc%\xf4\x1c\x8a\x86'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    dict_1 = dict()
    dict_1['\x8e\xed\x8eQ\xec\x12\xee'] = str_0
    dict_1['\xeb\x8c\x8e\xec\x88i\xe5\xfb'] = dict

# Generated at 2022-06-25 07:55:24.601720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    var_0 = action_module_0.run(str_0)

if __name__ == '__main__':
    import random
    import string
    random_str = ''.join(random.choice(string.ascii_letters) for i in range(10))

# Generated at 2022-06-25 07:55:34.154130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    method_of_class_instance = getattr(action_module_0, 'run')
    method_of_class_instance()


# Generated at 2022-06-25 07:55:44.877478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 's\xdc\x9a\x05\x0cZe\x99\xef\x03"'
    int_0 = 3246

# Generated at 2022-06-25 07:55:55.387932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'k}X#\x1a(H\x16u?l$I'
    str_3 = '\x7f}k\x1a\x1afA\x14'
    int_1 = 2517
    bytes_1 = b'\xea\xe0\xab\xbb\x8eF\xa6\x86'
    bool_1 = False
    action_module_1 = ActionModule(str_2, int_1, bytes_1, str_2, bytes_1, bool_1)

    if hasattr(action_module_1, '_task'):
        str_4 = 'L"\x07\x1b\x1c\x1c\x1a\x1cf\x1e\x1b'

# Generated at 2022-06-25 07:56:30.950200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False

    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)

    assert action_module_0.task == str_1
    assert action_module_0.connection == int_0
    assert action_module_0.play_context == bytes_0
    assert action_module_0.loader == str_1
    assert action_module_0.templar == bytes_0
    assert action_module_0.shared

# Generated at 2022-06-25 07:56:38.865714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'b%e&L'
    str_1 = '\x80\xec\x11\xd1'
    int_0 = 824
    bytes_0 = b'\x8d\xef\xdc\x92L\x7f\xa9'
    bool_0 = True
    assert_equal(ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0).action_shell_executable, '\x80\xec\x11\xd1')
    assert_equal(ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0).task_vars, 4)

# Generated at 2022-06-25 07:56:43.754451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('1Rt\x0e_&y', 7494, b'\xb7\x90\x89\x9d\x8d\x19\x11\xd1', 'r\x08\x05\x03\x07\x13', b'\xbf\x90\x0b\x83\xc8\x04\xd3\x9c\xca', True)
    # Patching the constructor variable action_module_0.run
    with patch('sources.unarchive._execute_module', return_value=dict()):
        assert_equals(action_module_0.run('tmp', dict()), dict())


# Generated at 2022-06-25 07:56:53.260668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Definition
    str_0 = '9"\x1b\xcb\t\x17\x07\x19\x17\x0b\r\x9elLC\x1f'
    str_1 = 'w\xed\xf0\xe5\xfd\x1d\xd2\x17\xbe\x1b\x03\xb3\xc6\xdb\xd1\x86\x9d'
    int_0 = 5102
    bytes_0 = b'\xc1j\xb2\x0e\x9c\xe4\x14\x15\x0a\xf1\xe8\xde\x13.\xa6\x9b$\x8c'
    bool_0 = True

# Generated at 2022-06-25 07:57:02.483249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'au`KHR&o*ZsC'

# Generated at 2022-06-25 07:57:08.023593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:57:16.563829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test case
    str_0 = '1C`82,y[wdTj&'
    str_1 = 's|FOT2&+%K/<'
    int_0 = 3238
    bytes_0 = b'\x9a\x04\x82\xee\xdb\xe6\xef\xb1'
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)

# Generated at 2022-06-25 07:57:21.265252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # There is no constructor for this class, so this is method will not be run.
    print("Test passed")


# Generated at 2022-06-25 07:57:31.718258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    print(action_module_0.task)
    print(action_module_0.connection)
    print(action_module_0.play_context)
    print(action_module_0.new_stdin)
    print(action_module_0.loader)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:57:43.177693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'a_\x03\x99\xd0'
    str_1 = '\xb3\xad\x07\xcf'
    int_0 = 4662
    bytes_0 = b'\xaa\x1d\x05\xa5\xdd\xc7\xd2\x91\xfc'
    bool_0 = True
    action_module_1 = ActionModule(str_0, int_0, bytes_0, str_0, bytes_0, bool_0)
    path = Path(str_1)
    str_2 = '\x9e\xe9\x89\x87\x06\xfc\xe6\xdd\xe0\x1f'
    int_1 = 4686

# Generated at 2022-06-25 07:58:50.063119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:58:51.120283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-25 07:58:58.207493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'l\xb4\xbe\n\x8e\x0c\x94'
    str_1 = '&\xfd\xe0\x00\x11\xea'
    int_0 = 1665
    bytes_0 = b'f\x8d\x1a\xb6!\xcc\x94\\Z'
    bool_0 = True
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)


# Generated at 2022-06-25 07:59:02.662476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0U&\n|N0Y({M'
    str_1 = 'au`KHR&o*ZsC'
    int_0 = 2480
    bytes_0 = b'\xb6\x9f\xc0\xfa\xdaHe\xed'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    var_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:59:10.059123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0e|"9+\x1a\x1c\x0b$\x10\x18\x0f\x1f'
    str_1 = 'b+p!\x11\x0b\x12\t\x00O\x06'
    int_0 = 3381
    bytes_0 = b'\x1f\x1b\x01u\xe6\x9f\x17'
    bool_0 = False
    action_module_0 = ActionModule(str_1, int_0, bytes_0, str_1, bytes_0, bool_0)
    action_module_0.run(str_0)


# Generated at 2022-06-25 07:59:20.828252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'V$}<'
    str_1 = 'h\x18\x98\xef\x17\xe6'
    int_0 = 2219
    bytes_0 = b'\x7f\x18\xa8\xc1`[\xd7\xda'
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, bytes_0, str_1, bytes_0, bool_0)

# Generated at 2022-06-25 07:59:29.001966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # noinspection PyTypeChecker
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert type(action_module_0) == ActionModule
    assert action_module_0.var_0 == None
    assert type(action_module_0.var_1) == int
    assert action_module_0.var_1 == -1
    assert type(action_module_0.var_2) == bytes
    assert action_module_0.var_2 == b''



# Generated at 2022-06-25 07:59:38.186109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'QxU6EiAg'
    str_1 = '\x9e\xe1W*\xa4g\xeb\xa3'
    int_0 = 7992
    bytes_0 = b'\x8f\x87'
    bool_0 = True
    int_1 = 7039
    float_0 = 6.7
    action_module_0 = ActionModule(str_0, int_0, bytes_0, str_0, bytes_0, bool_0)
    var_0 = action_module_0.run(int_1, float_0 if float_0 != 0 else float_0)
    assert var_0 == None

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:59:48.949855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W\xab\x1a\xafu\x8f\x1a\x13\x08\x1a\x1c\x0b\x12\x9b\x0b\x1d\x13\x1c\x1a\x12\x08\x1d\x0b\x13\x1d\x08\x1a\x1c\x0b\x12\x9b\x12\x08\x1a\x1c\x0b\x12\x9b\x0b\x1d\x13\x1c\x1a\x12\x08\x1d\x0b'

# Generated at 2022-06-25 07:59:49.708869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()