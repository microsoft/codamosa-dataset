

# Generated at 2022-06-25 07:52:15.627960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    int_0 = 1496
    str_0 = 'd'
    str_1 = '0W8\xde\xc5\xdc\xd9\xebU\xd4\x07\x03\x07\x99\x0b\xb6\xa7\x9d\x8aR\x93\x03\x0c\x8e\x87\xdc\x1c\x9a'

# Generated at 2022-06-25 07:52:22.700003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_ = ActionModule()
    ActionModule_.run(tmp = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)
    ActionModule_.run(tmp = None, task_vars = None)

# Generated at 2022-06-25 07:52:23.839111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    str_0 = obj_0.run()

# Generated at 2022-06-25 07:52:35.481149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = "copy"
    src = "/usr/bin/python3"
    dest = "/tmp/python"
    remote_src = False
    creates = None
    decrypt = True
    check_mode = True

    assert test_case_0() == 0

    # Testing argument types
    testclass = ActionModule(module_name=module_name, src=src, dest=dest, remote_src=remote_src, creates=creates, decrypt=decrypt, check_mode=check_mode)
    assert isinstance(testclass, ActionModule)

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:52:36.516066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:52:42.524120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(">> in test_ActionModule_run")
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    str_0 = ""
    str_1 = ""
    str_2 = ""
    str_3 = ""
    str_4 = ""
    str_5 = ""
    str_6 = ""
    str_7 = ""
    str_8 = ""
    str_9 = ""
    module = ActionModule(dict_0, dict_1, dict_2, dict_3, dict_4, str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9, b"\x00", b"\x00")

# Generated at 2022-06-25 07:52:46.761453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:50.009738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit tests for class ActionModule

# Generated at 2022-06-25 07:52:51.068453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:53:01.952577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule({}, {})
    obj.run()

if __name__ == '__main__':
    set_0 = {}

# Generated at 2022-06-25 07:53:12.517279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == True


# Generated at 2022-06-25 07:53:14.372007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:53:19.672659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # https://github.com/ansible/ansible/issues/43913
    action_module_0 = ActionModule()
    task_vars_0 = dict()
    tmp_0 = 'tmp'
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    print (result_0)


# Generated at 2022-06-25 07:53:20.790671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # Add code here
    action_module.run()

# Generated at 2022-06-25 07:53:23.160282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Parameters for ActionModule.run method
    tmp = None
    task_vars = None
    action_module_run_0 = ActionModule.run(tmp, task_vars)

# Generated at 2022-06-25 07:53:32.336071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task = type('', (), {})()
    action_module_1._task.args = {'src': None, 'dest': None}
    action_module_1._task.args['src'] = None
    action_module_1._task.args['dest'] = None
    action_module_1._task.args.update({'src': None, 'dest': None})
    action_module_1._task.args.update({'src': None, 'dest': None, 'creates': None})
    action_module_1._task.args.update({'src': None, 'dest': None, 'creates': None, 'decrypt': True})
    action_module_1.run()


# Generated at 2022-06-25 07:53:35.418149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test checks the working of constructor of class ActionModule.

    # Test case: valid
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:53:36.704417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:53:46.692996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task.args = dict(
        src='src',
        other_option=dict(
            a='a',
            b='b',
            c='c',
        )
    )
    action_module_0._task.action = 'ansible.builtin.copy'
    # Verify 'c' is not in action_module_0._task.args
    assert 'c' not in action_module_0._task.args
    # If some_dictionary.get(some_key) returns None, 'some_other' is set by default.
    if action_module_0._task.args.get('some_key') is None:
        action_module_0._task.args['some_other'] = None
    # Verify 'c' is not in action_

# Generated at 2022-06-25 07:53:49.539587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run(tmp=None, task_vars=None) is None
    assert False

# Generated at 2022-06-25 07:54:12.677285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    block_1 = """
    source     => /tmp/file.txt.tar.gz
    """
    block_2 = """
    dest       => /var/tmp/
    """
    block_3 = """
    creates    => /var/tmp/file.txt
    """
    block_4 = """
    content    => 'This is some content'
    """

    action_module_1 = ActionModule()
    action_module_1.run(block_1, block_2, block_3, block_4)
    action_module_2 = ActionModule()

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:54:15.643275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = null
    task_vars = dict()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:54:17.080444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:54:20.512412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    raise NotImplementedError


# Generated at 2022-06-25 07:54:23.949463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    # Test correct assignment of attribute '_name'
    assert action_module_0._name == 'unarchive'
    # Test correct assignment of attribute '_uses_shell'
    assert not action_module_0._uses_shell
    # Test correct assignment of attribute '_uses_atomic_transfer'
    assert action_module_0._uses_atomic_transfer


# Generated at 2022-06-25 07:54:34.452310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    module_name_0 = 'ansible.legacy.unarchive'
    source_0 = '/etc/ansible/roles/role_under_test/library/copy.py'
    dest_0 = 'dest'

# Generated at 2022-06-25 07:54:39.603756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:54:44.216175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:46.241265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check the class is not none
    assert test_case_0 is not None

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:54:47.482373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    action_module_0.run()

# Generated at 2022-06-25 07:55:06.876392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:55:14.412999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 604.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'pwqr'
    bytes_0 = b'\x1f'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:55:22.238438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1933.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'\x04\x1f@\x1b'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)


# Generated at 2022-06-25 07:55:34.276694
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:55:43.280298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'\t\x1eAv\xfa\xe2\x1f]\xf0\x06\xaa'
    dict_0 = {bytes_0: set_0}
    # Verify instance of class 'ActionModule'
    assert isinstance(ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0), ActionModule)


# Generated at 2022-06-25 07:55:45.563763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:51.291330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 4165.73577004103
    set_0 = {float_0, float_0, float_0}
    bool_0 = False
    str_0 = '^J\xfc\x0f'
    bytes_0 = b'}U'
    dict_0 = {bytes_0: set_0}
    answer = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    assert answer is not None


# Generated at 2022-06-25 07:55:54.769819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule( float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    except:
        print( "Error, not all arguments are specified.")


# Generated at 2022-06-25 07:56:01.669745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1796.5936673723444
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'invalid'
    bytes_0 = b'\x1d\xcb\xd1'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    var_0 = action_run(float_0, set_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:56:07.020130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 0, False, '', b'', 0)
    # TODO:
    #
    # Test with the following values:
    #
    #       tmp = 
    #       task_vars = 
    #
    #       Expected result:
    #       assert result == 
    #       assert not result.skipped
    #       assert result.exception is None
    #       assert result.failed is False
    #       assert result.parsed is not None
    #       assert result.parsed.get('changed', False)
    #
    #       Expected result:
    #       assert result == 
    #       assert result.skipped
    #       assert result.exception is None
    #       assert result.failed is False
    #       assert result.pars

# Generated at 2022-06-25 07:56:41.313416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = {'owner': 'dadmin'}
    action_module_0 = ActionModule(args_0)
    if isinstance(action_module_0, ActionModule):
        print("Test #0: SUCCESS")
    else:
        print("Test #0: FAILED")


# Generated at 2022-06-25 07:56:51.926335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 30.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'\xf4\x81;\x03\x97\x17'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:56:57.666920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)



# Generated at 2022-06-25 07:57:02.385220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    var_0 = action_run()
    if var_0:
        raise RuntimeError("Test failed.")

# Generated at 2022-06-25 07:57:05.378203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test ActionModule class')
    # Test constructor of class ActionModule
    TestCase(ActionModule)

if __name__ == '__main__':
    # Test class constructor
    test_ActionModule()

# Generated at 2022-06-25 07:57:10.504436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing if var_0 has been changed after executing 'action_run'
    assert var_0 == False, 'var_0 should have changed value but did not'

# Generated at 2022-06-25 07:57:16.893412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    tmp_0 = (b'h\xd4\x89\xcd\xe7\xdb\x0bE\xcd\x8b\xd1\xdc\xf9\x90\xcc\x07\xbe\x80')
    task_vars_0 = {str_0: tmp_0}
    var_0 = action

# Generated at 2022-06-25 07:57:18.132604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:57:18.567610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:57:20.717786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:58:30.486385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()
    print('Unit test for constructor of class ActionModule completed')


# Generated at 2022-06-25 07:58:35.681744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    method_0 = ActionModule.run

# Generated at 2022-06-25 07:58:38.761138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:58:43.442383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)


# Generated at 2022-06-25 07:58:50.856807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 649.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = '^u\x1d2\xf4\x1b\xdb'
    bytes_0 = b'\x00\x17\x1c\x1d\xb5\xec\x07K'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    assert float_0 == float_0
    assert set_0 == set_0
    assert bool_0 == bool_0
    assert str_0 == str_0
    assert bytes_0 == bytes_0
    assert dict_0

# Generated at 2022-06-25 07:58:52.667511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 07:58:54.947205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run(float_0, set_0)


# Generated at 2022-06-25 07:59:00.038251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object instance for class ActionModule
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    obj_ActionModule = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)

    # Call an instance method of obj_ActionModule
    action_module_0 = test_case_0()

    connect_0 = obj_ActionModule.connection
    connect_1 = obj_ActionModule.connection
    connect_2 = obj_ActionModule.connection
    connect_3 = obj_ActionModule.connection
    connect

# Generated at 2022-06-25 07:59:01.665148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()



# Generated at 2022-06-25 07:59:10.697528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()
    assert var_0 is None
    assert action_module_0.ACTION_VERSION == "2.0"
    assert action_module_0.run is not None
    assert action_module_0.result
    assert "tmp" in action_module_0.result
    assert "task_vars" not in action_module_0.result
    assert action_module_0.run is not None
    assert action_module_0.result
    assert "tmp" in action_module_0.result
    assert "task_vars" in action_module_0.result
    assert action_module_0.run is not None
    assert action_module_0.result
    assert "tmp" in action_module_0.result

# Generated at 2022-06-25 08:01:58.041178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1894.0
    set_0 = {float_0, float_0, float_0}
    bool_0 = True
    str_0 = 'filter'
    bytes_0 = b'_|\x04]\xfc'
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(float_0, set_0, bool_0, str_0, bytes_0, dict_0)
    var_0 = action_run()
    assert var_0 == 'PASS'