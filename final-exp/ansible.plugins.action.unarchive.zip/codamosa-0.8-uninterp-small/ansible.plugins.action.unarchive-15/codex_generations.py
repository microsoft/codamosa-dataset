

# Generated at 2022-06-25 07:52:08.916510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    action_module_1 = ActionModule(tmp, task_vars)
    action_module_1.run()



# Generated at 2022-06-25 07:52:14.992334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['ansible_connection'] = 'local'
    dict_0['ansible_inventory_sources'] = ['/usr/local/bin/hosts']
    dict_0['ansible_play_batch'] = ['all']
    dict_0['ansible_play_hosts'] = ['localhost']
    dict_0['ansible_playbook_python'] = '/usr/bin/python'
    dict_0['ansible_version'] = dict()
    dict_0['ansible_version']['full'] = '2.5.2'
    dict_0['ansible_version']['major'] = 2
    dict_0['ansible_version']['minor'] = 5
    dict_0['ansible_version']['revision'] = 2
    dict_

# Generated at 2022-06-25 07:52:18.716313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fill_object = ActionModule('src', 'dest')
    assert fill_object is not None
    assert fill_object is not None


# Generated at 2022-06-25 07:52:19.553540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:52:24.057217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'^\x92\xf3\x1b\xfb_\x9b'
    int_0 = 8462
    float_0 = -13.42
    bool_0 = False
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    test_case_0()

# Invoking run method of ActionModule class

# Generated at 2022-06-25 07:52:30.383945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case where cookie is not set
    bool_0 = True
    task_vars_0 = dict()
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    action_module_0.set_task_vars(task_vars_0)
    action_module_0.run()
    # Test case where cookie is not set
    bool_0 = True
    task_vars_0 = dict()
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    action_module_0.set_task_vars(task_vars_0)
    action_module_0.run()
    # Test case where cookie is not set

# Generated at 2022-06-25 07:52:35.627401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        bytes_0 = b'8\x92\xfb\x10N\xcb\x1f'
        int_0 = -1189
        float_0 = -237.3
        bool_0 = True
        action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
        test_case_0()
    except Exception:
        assert(False)

# Generated at 2022-06-25 07:52:37.554177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    test_case_0()
    print('Unit test finished')

# Import testcases for pytest-3.4

# Generated at 2022-06-25 07:52:47.287362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xbd\x8ey\x9b\xa1\x10\xa4\x8f4\xc3.\xfa\xa0\xd8'
    int_0 = -138
    float_0 = -1040.7
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    action_module_0.set_connection(float_0, int_0)
    action_module_0.set_become(float_0, float_0, float_0, float_0, float_0, float_0)

# Generated at 2022-06-25 07:52:56.297706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = 'dest'
    source = 'source'
    creates = 'creates'
    task_vars = {'dest': dest, 'source': source, 'creates': creates}
    action_module_0 = ActionModule(1.0, 'module_args', 1, 1.0, 1.0, True)
    action_module_0.run(task_vars=task_vars)
    del dest
    del source
    del creates
    del task_vars
    del action_module_0
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:07.960855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:53:14.464685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # class ActionModule:
    #     def run(self, tmp=None, task_vars=None):
    str_0 = 'src'
    action_module_0 = ActionModule(str_0, str_0)

    # Parameters tmp and task_vars have default values, test them
    result_1 = action_module_0.run()
    assert('unreachable' in result_1)
    assert(result_1['unreachable'] == False)

# Generated at 2022-06-25 07:53:15.925117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:53:19.855255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, str_0)
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert type(result_0) is dict


# Generated at 2022-06-25 07:53:28.759362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test ActionModule instance
    # Test action fail with missing source
    # Test action fail with missing destination
    # Test action fail with destination not directory
    # Source is a file
    # Source is a directory
    action_module_3 = ActionModule(str_0, str_0, module_args=dict(dest='/etc', src='/etc'))
    # Source is a directory when specifying remote_src
    action_module_4 = ActionModule(str_0, str_0, module_args=dict(dest='/etc', src='/etc', remote_src=True))
    # Test action skip with creates
    # Test action fail with requires


# Generated at 2022-06-25 07:53:32.304346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: ansible-strip-ungrouped-whitespace: nil
# vim: ansible-skip-file-resolver-warning: nil
# vim: ansible-skip-task-includes: nil
# vim: set expandtab ts=8 sts=4 sw=4 ft=python et noro norl cin si ai :

# Generated at 2022-06-25 07:53:32.954142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:53:34.302276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # Test for the case named "handler for unarchive operations"
    # TODO: test for the action module


# Generated at 2022-06-25 07:53:36.745382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Test case test_case_0 failed: " + str(err))

test_ActionModule()

# Generated at 2022-06-25 07:53:39.548035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:53:54.992401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:54:07.376802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    r_1 = action_module_1._execute_remote_stat('/home/kd4', {}, True)
    dest_1 = action_module_1._remote_expand_user('/home/kd4')
    source_1 = os.path.expanduser('/home/kd4/work')
    ansible_2 = ActionModule()
    ansible_2._loader.get_real_file(ansible_2._find_needle('files', '/home/kd4/work'), decrypt=True)
    ansible_3 = ActionModule()
    ansible_3._transfer_file('/home/kd4/work', '/home/kd4/work')
    ansible_4 = ActionModule()
    ansible_4._fixup_perms

# Generated at 2022-06-25 07:54:20.962104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # Test with the default args.
    task_vars = {}
    try:
        action_module_1.run(task_vars=task_vars)
    except AnsibleActionFail as exception_1:
        if exception_1.result['msg'].startswith("src (or content) and dest are required"):
            pass
        else:
            raise Exception('Unexpected AnsibleActionFail raised: {0}'.format(exception_1))
    # Test with the default args.
    task_vars = {'dest': 'dest'}

# Generated at 2022-06-25 07:54:22.149558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:31.678154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run method will only be tested with AnsibleAction and AnsibleActionSkip exceptions raised.
    # AnsibleActionFail will never be raised, because the case (creates and filename already exist)
    # will never be raised when testing.
    action_module_ = ActionModule()

    # AnsibleActionSkip test case.
    dest = "dest"
    creates = dest
    action_module_.run(None, {"creates": creates})

    # AnsibleAction test case.
    dest = "dest"
    action_module_.run(None, {"creates": dest})


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:33.772170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    assert action_module_0 is not action_module_1


# Generated at 2022-06-25 07:54:35.036874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:54:39.916035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = ActionModule()
    assert var.TRANSFERS_FILES == True


# Generated at 2022-06-25 07:54:41.659321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 == None

# Generated at 2022-06-25 07:54:43.876046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 07:55:15.221666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("")
    print("#############################")
    print("Test case 1: constructor")
    print("#############################")
    action_module_0 = ActionModule()
    if action_module_0 is not None:
        print("Test case passed")
    else:
        print("Test case failed")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:55:19.065988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module
    assert action_module.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:55:20.366077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()



# Generated at 2022-06-25 07:55:23.252384
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:55:34.332025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    to_text = ActionModule.__dict__["_to_text"]
    # Tests 1, 3, and 4 from https://github.com/ansible/ansible-modules-core/blob/devel/packaging/os/yum.py

# Generated at 2022-06-25 07:55:40.604367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert_action_module = "Ansible Action module"
    assert action_module.__str__() == assert_action_module, "The string returned by __str__() is not expected"
    assert action_module.__repr__() == assert_action_module, "The string returned by __repr__() is not expected"


# Generated at 2022-06-25 07:55:42.869717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test cases for constructor of class ActionModule")
    test_case_0()
    print("\n")



# Generated at 2022-06-25 07:55:44.960241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:55:46.446370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:55:56.019908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config_data = {'ANSIBLE_REMOTE_TMP': '/var/tmp',
                   'ANSIBLE_MODULE_PATH': '/home/ubuntu/qabot/test/integration/targets/module_utils',
                   'ANSIBLE_MODULE_UTILS': '/home/ubuntu/qabot/test/integration/targets/module_utils'}
    config_data['ANSIBLE_REMOTE_TMP'] = config_data['ANSIBLE_REMOTE_TMP'].format(config_data['ANSIBLE_REMOTE_TMP'])

    init = ActionModule()
    try:
        init.run(config_data)
    except Exception as err:
        #print("EXCEPTION RAISED: " + str(err))
        return False
   # print("\nSUCCESS: Initialized Action

# Generated at 2022-06-25 07:56:55.980982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    if action_module_1:
        print('Pass')
    else:
        print('Test Failed')


# Generated at 2022-06-25 07:56:59.815123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: Add test cases
    pass

if __name__ == '__main__':
    #test_ActionModule()
    #test_case_0()
    pass

# Generated at 2022-06-25 07:57:02.804647
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Initialize the class
    action_module_0 = ActionModule()
    assert(action_module_0 is not None)


# Generated at 2022-06-25 07:57:05.737192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dest = '/home/vagrant'
    action_module_0.run(task_vars={'ansible_check_mode': False})


# Generated at 2022-06-25 07:57:12.314284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """C05_ActionModule_run"""

    # Initialize the class
    action_module_0 = ActionModule()

    # Set up test inputs
    tmp = None
    task_vars = None

    # Perform the test
    result = action_module_0.run(
        tmp,
        task_vars
    )

    assert result is not None


# Generated at 2022-06-25 07:57:13.087814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:57:15.151352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:57:17.756698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case where src is None or dest is None throws AnsibleActionFail
    try:
        action_module_1 = ActionModule()
        action_module_1.run()
    except AnsibleActionFail:
        pass


# Generated at 2022-06-25 07:57:21.556725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

# vim: set noexpandtab ts=4 sw=4 :

# Generated at 2022-06-25 07:57:26.224424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run('tmp', task_vars='task_vars')


# Generated at 2022-06-25 07:58:30.865716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Header("Testing run")
    action_module_0 = ActionModule()
    result_0 = action_module_0.run()
    print("Testing run " + str(result_0))

# Generated at 2022-06-25 07:58:37.100792
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:58:42.085769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xae'
    int_0 = 4455
    float_0 = -2607.9
    bool_0 = False
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    return None


# Generated at 2022-06-25 07:58:48.785960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleActionFail):
        bytes_0 = b'\xa3\xcf\xf2\x183\xb2'
        int_0 = -23
        float_0 = -26.23
        bool_0 = True
        action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)


# Generated at 2022-06-25 07:58:54.803755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'8\xfb\x10N\xcb\x1f'
    int_0 = -1182
    float_0 = -237.3
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    var_0 = action_module_0.run()
    return var_0


# Generated at 2022-06-25 07:58:57.876468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'o\x13\x9b\xb1\xbc\xf3\x04'
    int_0 = -3117
    float_0 = -287.9
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, float_0, int_0, float_0, float_0, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 07:59:07.905518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf6\xa1\x1a\xb2\x9f'
    int_0 = -1116
    float_0 = -820.2
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    var_0 = action_module_0.run()
    float_0 = -10.3
    int_0 = -966
    bool_0 = False
    action_module_1 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    var_0 = action_module_1.run()
    int_0 = -1165

# Generated at 2022-06-25 07:59:11.096241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'8\xfb\x10N\xcb\x1f'
    int_0 = -1182
    float_0 = -237.3
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)


# Generated at 2022-06-25 07:59:19.006921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xab\xe0\x10\xc8(\x08\xd1\xeb\x06\xb4\xde\xe3'
    int_0 = -1474
    float_0 = -237.3
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, int_0, float_0, float_0, bool_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:59:20.918205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 08:01:50.735072
# Unit test for constructor of class ActionModule
def test_ActionModule():

    return None


# Generated at 2022-06-25 08:02:00.370119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # COMMON
    import sys
    import json
    import tempfile
    import subprocess
    import time
    
    # COMMON
    import ansible.constants as C
    import ansible.utils.template as template
    from ansible.utils.unicode import to_bytes, to_str
    from ansible.plugins.action import _configure_module_args
    from ansible.module_utils._text import to_text
    
    tmp = None
    task_vars = dict()
    
    source = None
    dest = None
    remote_src = False
    creates = None
    decrypt = True
    
    # run()
    if task_vars is None:
        task_vars = dict()
    
    result = super(ActionModule, self).run(tmp, task_vars)
    