

# Generated at 2022-06-25 07:52:02.605465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:52:08.665842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = test_case_0()
    task_vars = test_case_0()
    action = ActionModule()
    action.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:11.906163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(set_0)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 07:52:22.254931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cur_dir = os.getcwd()

# Generated at 2022-06-25 07:52:26.775993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = dict(src='test', dest='test')
    set_0 = {'test', 'test'}
    action_module = ActionModule(dict(action='foo', set_type='dict', multiline_items=set_0, remote_src=False, dest='test', register='test', content='test', src='test', always_run=False, delete='test', fail_on_missing=True, no_log=False, follow=True, chdir='test', creates='test', executable='test', ignore_errors=True, args='test', tmp='test', when='test', remote_user='test', diff_peek='test', free_form='test', task_vars=[dict_1]), dict(value=dict_0), dict_0)

# Generated at 2022-06-25 07:52:31.243728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=1, connection=2, play_context=3, loader=4, templar=5, shared_loader_obj=6)
    assert isinstance(action, ActionModule)



# Generated at 2022-06-25 07:52:37.413604
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # 1. test __init__
    action_module_0 = ActionModule.ActionModule(dict_0, set_0, dict_0)
    dict_0['validated'] = None
    dict_0['is_new'] = None
    dict_0['is_local'] = None
    dict_0['args'] = None
    dict_0['task'] = None
    dict_0['loader'] = None
    dict_0['templar'] = None
    dict_0['_diff'] = None
    dict_0['name'] = None
    dict_0['connection'] = None


# Generated at 2022-06-25 07:52:47.190240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests the method run() of class ActionModule
    # declare a instance for ActionModule
    test_ActionModule = ansible.plugins.action.ActionModule(module_name="module_name")

    # Tests if the method run is defined with the following args
    arg_types_list = [AnsibleActionFail, AnsibleActionSkip, AnsibleAction]
    # Tests if the method run is defined with the following arg types
    arg_type_dict = {"tmp": str, "task_vars": dict}
    for arg_type in arg_types_list:
        if not isinstance(arg_type(), type):
            raise AssertionError("test_ActionModule_run() arg_types_list initialization error")
    for key, value in arg_type_dict.items():
        if not isinstance(key, str):
            raise Assert

# Generated at 2022-06-25 07:52:50.058563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:52:59.110943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run_0()
    dict_0 = {}
    dict_1 = {'remote_src': False}
    dict_2 = {'dest': '/tmp/test_file', 'src': '/tmp/test_file_2'}
    dict_3 = {'dest': None, 'src': None}
    dict_4 = {'dest': '/tmp/test_file', 'src': '/tmp/test_file_2'}
    dict_5 = {'dest': None}
    dict_6 = {'dest': '/tmp/test_file', 'src': '/tmp/test_file_2'}
    dict_7 = {'dest': None, 'src': None}
    dict_8 = {'remote_src': False}

# Generated at 2022-06-25 07:53:07.601341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_instance = ActionModule()

# Generated at 2022-06-25 07:53:08.465021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:53:15.416874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # dest = self._task.args.get('dest', None)
    # remote_src = boolean(self._task.args.get('remote_src', False), strict=False)
    # creates = self._task.args.get('creates', None)
    # decrypt = self._task.args.get('decrypt', True)
    # source = self._task.args.get('src', None)
    # src = self._task.args.get('src', None)
    # Try to do a test with all args of run()
    #def run(self, tmp=None, task_vars=None):
    #assert action_module_0.run(tmp=None, task_vars=None) is None
    # Check that it pass example test from action module
    assert action_

# Generated at 2022-06-25 07:53:16.804957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()



# Generated at 2022-06-25 07:53:20.228456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n##### Testing constructor of ActionModule #####")

    if test_case_0() == None:
        print("Unit test for constructor of class ActionModule: Successful")
    else:
        print("Unit test for constructor of class ActionModule: Unsuccessful")


# Generated at 2022-06-25 07:53:21.629087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:53:24.381528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0 is not None)

    action_module_0.run(tmp=None, task_vars={'some_var': None})



# Generated at 2022-06-25 07:53:27.220730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # CCTODO: Build test.
    assert True


# Generated at 2022-06-25 07:53:30.686022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:36.952210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._remove_tmp_path()
    action_module_0._task.args = dict(
        content='string content',
        dest='string dest',
    )
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:57.213309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    source_0 = '/home/test_user/test_file'
    dest_0 = '/home/test_user/test_file'
    task_vars_0 = None
    result_0 = action_module_0.run(source_0, task_vars_0)
    assert result_0 == ['/home/test_user/test_file', '/home/test_user/test_file']


# Generated at 2022-06-25 07:53:58.292226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:01.338382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0)
    assert True

# Generated at 2022-06-25 07:54:02.908660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0 tests with no options
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:54:04.759567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:54:05.969961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_obj = ActionModule()
    except NameError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 07:54:09.206286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:54:10.146884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0

# Generated at 2022-06-25 07:54:22.080375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_0 = dict()
    action_module_0._task = task_0
    args_0 = dict()
    args_0['content'] = 'Hello World!'
    args_0['changed'] = True
    args_0['content_0'] = 'Hello World!'
    args_0['path'] = '/home/vagrant/test1.txt'
    args_0['path_0'] = '/home/vagrant/test1.txt'
    args_0['msg'] = '1 line written.'
    args_0['state'] = 'file'
    task_0['args'] = args_0
    tmp_0 = dict()
    task_vars_0 = dict()
    task_vars_0['state'] = 'Utah'
    result_0 = action_

# Generated at 2022-06-25 07:54:32.422760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Unit test for src - None
    task_vars_0 = dict()
    action_module_0._task.args = {'creates': None, 'remote_src': False, 'src': None}
    action_module_0._task.args['dest'] = "/home/dmartin/ansibleTest"
    with pytest.raises(AnsibleActionFail):
        action_module_0.run(None, task_vars_0)

    # Unit test for src - "/home/dmartin/ansibleTest/copy_dir"
    task_vars_1 = dict()
    action_module_0._task.args = {'creates': None, 'remote_src': False, 'src': "/home/dmartin/ansibleTest/copy_dir"}

# Generated at 2022-06-25 07:54:54.706213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run 'ansible.test_case_0' using action module 'ansible.test_case_0'
    ansible.test_case_0.test_case_0()
    assert {'failed': False} == var_0

# Generated at 2022-06-25 07:54:56.631465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:02.488895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)

# Generated at 2022-06-25 07:55:06.366898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:55:16.371219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test all exceptions for run.

    # Test action_fail exception.
    try:
        raise AnsibleActionFail("skipped, since %s exists" % creates)
    except AnsibleActionFail:
        print("AnsibleActionFail")

    # Test action_skip exception.
    try:
        raise AnsibleActionSkip("skipped, since %s exists" % creates)
    except AnsibleActionSkip:
        print("AnsibleActionSkip")

    # Test file not found exception.
    try:
        raise AnsibleActionFail("src (or content) and dest are required")
    except AnsibleActionFail:
        print("AnsibleActionFail: src (or content) and dest are required")

    # Test permission denied exception.

# Generated at 2022-06-25 07:55:19.026437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule...')
    test_case_0()
    print('Done')

test_ActionModule()

# Generated at 2022-06-25 07:55:25.968048
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Prepare
    action_module_0 = ActionModule(False, ('`\xfc', 172.5188, '3'), b'`\xfc', b'`\xfc', b'`\xfc', 'shutdown complete')

    # Verify
    assert action_module_0._task.args == {'backup': False, 'content': None, 'creates': None, 'decrypt': True, 'dest': None, 'group': None, 'mode': None, 'original_basename': None, 'owner': None, 'path': None, 'remote_src': False, 'selevel': None, 'serole': None, 'setype': None, 'seuser': None, 'src': None, 'unarchive_host': None}, 'Failed to create ActionModule object!'

    # Destroy
    action_module_0.__del__()

# Generated at 2022-06-25 07:55:34.087846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)


# Generated at 2022-06-25 07:55:41.708740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)


# Generated at 2022-06-25 07:55:52.571328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'\x1a'
    float_0 = 17.8
    str_0 = '\x1a'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    var_0 = action_module_0.run()
    print(var_0)  # CCTODO: There was a return call here. Return values are not supported.

# Generated at 2022-06-25 07:56:24.993565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:56:29.880908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    # Check that exception is thrown if the next two lines are uncommented
    # action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    # assert(action_module_0.FIXME(str_0) == str_1)


# Generated at 2022-06-25 07:56:33.348331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0._task.args == {})
    assert (action_module_0.TRANSFERS_FILES == True)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:56:36.646360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = None
    dest = None
    creates = None
    decrypt = True
    bool_0 = decrypt
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (source, dest, creates, decrypt)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)



# Generated at 2022-06-25 07:56:43.591717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:56:53.203299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests that the run() method returns a dictionary or None.
    # GIVEN
    action_module_0 = ActionModule()
    # WHEN
    var_0 = action_module_0.run()
    # THEN
    assert isinstance(var_0, ansible.collections.abc.Mapping) or var_0 is None
    # Tests that the run() method returns an empty dictionary when called with
    # no arguments.
    # GIVEN
    action_module_0 = ActionModule()
    # WHEN
    var_0 = action_module_0.run()
    # THEN
    assert var_0 == {}
    # Tests that the run() method returns an empty dictionary when called with
    # valid arguments.
    # GIVEN
    action_module_0 = ActionModule()
    valid_arguments = {}
    #

# Generated at 2022-06-25 07:56:54.000319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # CCTODO: Test not implemented.
    pass


# Generated at 2022-06-25 07:57:03.407831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['src'] = 'hadoop_submit.py'
    dict_1['dest'] = 'hadoop_submit.py'
    dict_1['remote_src'] = False
    dict_1['creates'] = 'hadoop_submit.py'
    dict_1['decrypt'] = True
   

# Generated at 2022-06-25 07:57:10.716417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    tuple_0 = (bool_0, )
    str_0 = '0o77'
    str_1 = '^'
    str_2 = 'D'
    str_3 = '.'
    action_module_0 = ActionModule(bool_0, tuple_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert_equal(type(action_module_0), ActionModule)
    assert_equal(action_module_0.supports_check_mode, False)
    assert_equal(action_module_0.bypass_checks, False)
    assert_equal(action_module_0.no_log, False)

# Generated at 2022-06-25 07:57:18.823692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:58:30.526175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test setup
    # Note: this test is not created with pytest. It creates the
    # _task and _connection variables on which pytest tests depend.

    # Execute the task's run method
    task_vars = dict()
    action_module_0 = ActionModule(dict(), task_vars)
    task_vars = dict()
    action = action_module_0.run()
    assert action == 'copy', "Unexpected result from run method: {action}"

# Generated at 2022-06-25 07:58:38.566820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    bytes_1 = b',\x17\xc3\x88\xcf'
    float_1 = 166.4534
    str_2 = 'u'
    tuple_1 = (bytes_1, float_1, str_2)
    action_module_1 = ActionModule()
    print(action_module_1.action_skip_message)
    print(action_module_1.ACTION_FLAGS)
    print(action_module_1.CONNECTION_PLUGIN_PATH)
    print(action_module_1.DISPATCH_PLUGIN_PATH)
    print(action_module_1.CACHE_PLUGIN_PATH)
    print(action_module_1.MODULE_CACHE_PLUGIN_PATH)

# Generated at 2022-06-25 07:58:45.541585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:58:48.153683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('>>> in test_ActionModule_run')
    test_case_0()
    print('<<< out test_ActionModule_run')


# Generated at 2022-06-25 07:58:49.981650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:58:53.507957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert any(result.get('failed', False) == True for result in run_module('action_module'))
    assert any(result.get('changed', False) for result in run_module('action_module'))

# Generated at 2022-06-25 07:58:57.807423
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Variables
    args_0 = {'dest': '|', 'src': '|'}
    task_vars_0 = {}
    tmp_0 = tmp
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    action_module_0.run(args_0)

# Generated at 2022-06-25 07:58:59.474438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # True and False are the expected results for the boolean method test
    assert True == True
    assert False == False

# Generated at 2022-06-25 07:59:10.545626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock for _Loader.get_real_file
    loader_0 = mock.MagicMock()
    loader_0.get_real_file.return_value = str_0

    # Create mock for _Task.args
    args_0 = mock.MagicMock()
    args_0.return_value = dict_0

    # Create mock for _Task.args
    args_1 = mock.MagicMock()
    args_1.return_value = dict_0

    # Create mock for _Task
    task_0 = mock.MagicMock()
    task_0.args = args_0
    task_0.args = args_1

    # Create mock for _Connection
    connection_0 = mock.MagicMock()

    # Create mock for _Connection
    connection_1 = mock.MagicMock()

    #

# Generated at 2022-06-25 07:59:19.754501
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bool_0 = False
    bytes_0 = b'`\xfc'
    float_0 = 172.5188
    str_0 = '3'
    tuple_0 = (bytes_0, float_0, str_0)
    str_1 = 'shutdown complete'
    action_module_0 = ActionModule(bool_0, tuple_0, bytes_0, bytes_0, bytes_0, str_1)
    var_0 = action_run()
    assert True
