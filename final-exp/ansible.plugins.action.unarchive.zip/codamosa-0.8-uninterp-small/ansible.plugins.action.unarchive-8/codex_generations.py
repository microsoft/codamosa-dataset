

# Generated at 2022-06-25 07:52:09.053788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:15.758268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        instance_0 = ActionModule()
        getattr(instance_0, '_transfer_file')
        getattr(instance_0, '_execute_module')
        getattr(instance_0, '_execute_remote_stat')
        getattr(instance_0, '_fixup_perms2')
        getattr(instance_0, '_find_needle')
        getattr(instance_0, '_remote_file_exists')
        getattr(instance_0, 'run')
        getattr(instance_0, '_remote_expand_user')
        getattr(instance_0, '_remove_tmp_path')
        # No exception was raised
    except Exception:
        print('Caught exception')

# End of class ActionModule tests


# Generated at 2022-06-25 07:52:16.430419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()


# Generated at 2022-06-25 07:52:21.359681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if '.' in __name__:
        cmd = "test_case_0"
    else:
        if __name__ == "test_case_0":
            cmd = "test_case_0"
        else:
            cmd = 'test_case_0'
    tmp = ""
    task_vars = None
    obj = ActionModule(tmp, task_vars)
    assert isinstance(obj, ActionModule)


# Generated at 2022-06-25 07:52:25.165274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object
    foo = ActionModule()
    # Assert that the test object is of the right type
    assert isinstance(foo,ActionModule)
    assert isinstance(foo,ActionBase)
    # Call the method run
    foo.run(tmp=None,task_vars=None)
    # Assert the method call results
    assert True


# Generated at 2022-06-25 07:52:37.122427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {bytes_0: dict_0}
    list_1 = [0]
    dict_0 = {set_0: list_1}
    dict_0 = {dict_0: dict_0}
    dict_0 = {list_1: dict_0}
    dict_0 = {set_0: dict_0}
    dict_0 = {list_1: dict_0}
    dict_0 = {str_0: dict_0}
    dict_0 = {dict_0: dict_0}
    dict_0 = {dict_0: dict_0}
    dict_0 = {dict_0: dict_0}
    dict_0 = {dict_0: dict_0}
    dict_0 = {dict_0: dict_0}

# Generated at 2022-06-25 07:52:41.943790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_0 = ActionModule()
    tmp = None
    task_vars = None
    ActionModule_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:48.425006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        _ActionModule = ActionModule(list_0, bytes_0, dict_0)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:52:51.927037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert test_case_0()
        print("Test Case 0 OK!")
    except Exception as e:
        print("Test Case 0 failed!")
        print(e)

test_ActionModule()
# Unit test end

# Generated at 2022-06-25 07:52:52.865687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:53:07.517502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    dict_0 = {'alias': 'wlan0', 'reject-default-route': False}
    set_1 = {dict_0, dict_0}
    list_1 = [bool_0, set_0, set_1, dict_0, dict_0]

# Generated at 2022-06-25 07:53:08.433930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    __tracebackhide__ = True
    OpenIn(test)

# Generated at 2022-06-25 07:53:14.642378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)


# Generated at 2022-06-25 07:53:23.813308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    action_module_0.action_run()
    action_module_0.__action_run()
    action_module_0.action_execute()
    action_module_0.__action_execute()
    action_module_0.run()
    action_module_0.__run()
    action_module_0.execute()


# Generated at 2022-06-25 07:53:32.976806
# Unit test for constructor of class ActionModule
def test_ActionModule():

    #  Testing the id of an instance to check whether a new instance is made or not.
    check_inst = ActionModule()
    assert id(ActionModule()) != id(check_inst)
    #  Testing the instantiation of class ActionModule
    #  Testing whether all the instance variables are initialized properly or not.
    assert isinstance(check_inst._display, ActionBase)
    assert isinstance(check_inst._loader, ActionBase)
    assert isinstance(check_inst._task, ActionBase)
    assert isinstance(check_inst._connection, ActionBase)
    assert isinstance(check_inst._templar, ActionBase)
    assert isinstance(check_inst._shared_loader_obj, ActionBase)
    assert isinstance(check_inst._action, ActionBase)

# Generated at 2022-06-25 07:53:33.940530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:53:39.318051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 07:53:45.107825
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Try with option1 empty.
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)

    # Try with option1 non-empty.
    bool_0 = True
    bool_1 = False
    set_0 = {bool_1, bool_0}
    set_1 = {bool_0, bool_0}
    list_0 = [set_1, set_0, bool_0, bool_1, set_1]

# Generated at 2022-06-25 07:53:55.570573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0}
    list_0 = [bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0]
    tuple_0 = ()
    str_0 = '$'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    file_0 = open('test.txt', 'w')
    action_module_0.run(file_0)
    file_0.close()
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0}

# Generated at 2022-06-25 07:53:56.425277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:54:19.475302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    assert not action_module_0._task is None

# Generated at 2022-06-25 07:54:21.881248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None
    # test_case_0()

# Unit tests for run() of class ActionModule

# Generated at 2022-06-25 07:54:30.596353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    var_0 = action_module_0.run()
    del var_0

# Generated at 2022-06-25 07:54:33.991331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ...
    # FIXME: Please add tests for ActionModule.run
    assert ... == var_0

# Generated at 2022-06-25 07:54:39.617959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    action_module_0.run()
    # ValueError
    # not enough values to unpack (expected 4, got 0)
    action_module_0.run((tuple_0, bool_0))
    # AssertionError
    # assert False
    action_module_0.run(tuple_0, {str_0: set_0})
    # AssertionError
    # assert

# Generated at 2022-06-25 07:54:43.823661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()

# Verify that the content of the test case matches the expected output.
test_case_0()

# Generated at 2022-06-25 07:54:52.991800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = bool
    set_0 = set
    list_0 = list
    tuple_0 = tuple
    str_0 = str
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    # Constructor should run without exception
    try :
        action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    except Exception as exception_0 :
        print(str(exception_0))
    # run() should run without exception
    try :
        action_module_0.run()
    except Exception as exception_1 :
        print(str(exception_1))

# Generated at 2022-06-25 07:55:00.836958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)

# Generated at 2022-06-25 07:55:07.102820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    bool_1 = int()
    bool_2 = bool_1
    dict_0 = dict()
    dict_1 = dict_0
    dict_0 = action_module_run(bool_2, dict_1)

# Generated at 2022-06-25 07:55:08.230547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_run')


# Generated at 2022-06-25 07:55:42.567592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()

    expected_result = dict()

    result = ActionModule(tmp, task_vars)
    assert result == expected_result

# Generated at 2022-06-25 07:55:43.812479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:55:47.635753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for arg_0, arg_1, arg_2, arg_3, arg_4, arg_5 in gen_list(6):
        obj_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
        var_0 = obj_0.run()


# Generated at 2022-06-25 07:55:54.209804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {True, False}
    list_0 = [set_0, True, False, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 07:55:55.544383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:55:57.157172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:55:59.562811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:56:10.645314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    assert action_module_0._task == bool_0
    assert action_module_0._connection == set_0
    assert action_module_0._play_context == list_0
    assert action_module_0._loader == tuple_0
    assert action_module_0._templar == str_0
    assert action_module_0._shared_loader_obj == tuple_0

# Unit test

# Generated at 2022-06-25 07:56:17.508269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:56:18.674621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

test_ActionModule_run()

# Generated at 2022-06-25 07:57:24.205679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)


# Generated at 2022-06-25 07:57:29.815735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    set_0 = set()
    list_0 = list()
    tuple_0 = (tuple(), tuple())
    str_0 = ''
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    var_0 = action_run(tuple_0, list_0)
    func_0(var_0)


# Generated at 2022-06-25 07:57:33.118014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Private class for managing individual actions of a Task.
    """
    action_module_0 = ActionModule()
    assert action_module_0._hash != None
    assert action_module_0._hash != ''

# Generated at 2022-06-25 07:57:38.436754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()
    assert var_0 == var_0

# Generated at 2022-06-25 07:57:47.034685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    bool_0 = {bool_0, bool_0}
    byte_0 = 'gM\x0b@H:'
    map_0 = {'byte_0': byte_0, 'byte_0': '', 'list_0': list_0, 'bool_0': '', 'set_0': bool_0, 'str_0': '', 'tuple_0': byte_0}


# Generated at 2022-06-25 07:57:47.887938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:57:53.711922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(set_0, set_0, list_0, tuple_0, str_0, tuple_0)


# Generated at 2022-06-25 07:57:58.289785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(1,2,3,4,5,6)
    result = action_module.run()
    assert(result == 1) #check return value

# Generated at 2022-06-25 07:58:01.639227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Unit tests for class ActionModule

# Generated at 2022-06-25 07:58:02.644040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 08:00:22.177573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'Xc2\x1d\x1f\x16k'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    tmp = None
    task_vars = None

    # Check before
    # assert some conditions here

    # Act
    var_0 = action_module_0.run(tmp, task_vars)

    # Check after
    # assert some conditions here

# Generated at 2022-06-25 08:00:24.827973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializes the class instance
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    # Checks if the return value is equal to the expected one
    assert action_module_0.run() == action_run()


# Generated at 2022-06-25 08:00:25.457538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: more tests needed
    assert False

# Generated at 2022-06-25 08:00:30.487969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_2 = True
    set_2 = {bool_2, bool_2}
    list_2 = [set_2, bool_2, bool_2, set_2]
    tuple_2 = ()
    str_2 = 'gM\x0b@H:'
    action_module_2 = ActionModule(bool_2, set_2, list_2, tuple_2, str_2, tuple_2)
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'

# Generated at 2022-06-25 08:00:40.510894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test args:
    tmp = None
    task_vars = None

    # Test expected exception:
    with pytest.raises(AnsibleActionFail) as excinfo:
        ActionModule().run(tmp, task_vars)

    # Test using the default values:
    tmp = None
    task_vars = None
    ActionModule().run(tmp, task_vars)

if __name__ == '__main__':
    # Test the module arguments
    test_ActionModule_run()


#class ActionModule(ActionBase):
#
#    TRANSFERS_FILES = True
#
#    def run(self, tmp=None, task_vars=None):
#        ''' handler for unarchive operations '''
#        if task_vars is None:
#            task_vars = dict()

# Generated at 2022-06-25 08:00:46.943761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    delegate_to = None
    action_base_instance = ActionBase(tmp, task_vars, delegate_to)
    module_name = None
    module_args = None
    task_vars = None
    action_module_instance = ActionModule(module_name, module_args, task_vars, action_base_instance)
    assert (action_module_instance.module_name == module_name)
    assert (action_module_instance.module_args == module_args)
    assert (action_module_instance.task_vars == task_vars)
    assert (action_module_instance.action_base_instance == action_base_instance)



# Generated at 2022-06-25 08:00:51.885513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()

# Generated at 2022-06-25 08:00:55.698970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    action_module_0.run()



if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:00:59.728180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    list_0 = [set_0, bool_0, bool_0, set_0]
    tuple_0 = ()
    str_0 = 'gM\x0b@H:'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    var_0 = action_run()
    assert var_0 == dict()

# Generated at 2022-06-25 08:01:03.407680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {True, True}
    list_0 = [True, True, True, True]
    tuple_0 = ()
    str_0 = '\x1bNX\x00\x10'
    action_module_0 = ActionModule(bool_0, set_0, list_0, tuple_0, str_0, tuple_0)
    assert action_module_0 == action_module_0
    action_module_0.run(None, None)
