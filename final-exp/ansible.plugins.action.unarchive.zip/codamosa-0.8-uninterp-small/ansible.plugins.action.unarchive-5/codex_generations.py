

# Generated at 2022-06-25 07:52:08.194811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    test_case_0()

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 07:52:11.341719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run()


# Generated at 2022-06-25 07:52:15.213924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'log'
    str_1 = '+S-RL?'
    set_0 = {str_0, str_1, str_1}
    bool_0 = True
    list_0 = [bool_0, set_0, bool_0]
    action_module_0 = ActionModule(str_0, str_1, set_0, set_0, bool_0, list_0)
    test_case_0()


# Generated at 2022-06-25 07:52:18.139233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dir'
    str_1 = 'zZ'
    set_0 = {str_1}
    set_1 = {str_0, str_1}
    action_module_0 = ActionModule(str_0, str_1, set_0, set_1, True, [True, True])
    assert not action_module_0.run()
    assert not action_module_0.run()


# Generated at 2022-06-25 07:52:23.149661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    # from ansible.errors import AnsibleAction, AnsibleActionFail, AnsibleActionSkip
    # from ansible.module_utils._text import to_text
    # from ansible.module_utils.parsing.convert_bool import boolean

    # obj = ActionModule(task_vars=dict())
    # obj.run()
    pass


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:24.790042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:52:27.405721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:52:33.888489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '@'
    str_3 = '+S-RL?F'
    list_2 = [str_0, str_0, str_0, str_0, str_0, str_0, str_0]
    str_6 = 'log'
    str_1 = '+S-RL?'
    set_0 = {str_6, str_1, str_1}
    bool_0 = True
    set_3 = set({str_3, str_0})
    str_5 = '^'
    list_0 = [bool_0, set_0, bool_0]
    dict_0 = {str_6: str_6, str_1: list_2, str_0: set_3, str_3: str_6, str_5: set_0}
    action_

# Generated at 2022-06-25 07:52:38.049979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'log'
    str_1 = '+S-RL?'
    set_0 = {str_0, str_1, str_1}
    bool_0 = True
    list_0 = [bool_0, set_0, bool_0]
    action_module_0 = ActionModule(str_0, str_1, set_0, set_0, bool_0, list_0)

# Generated at 2022-06-25 07:52:46.342861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'log'
    str_1 = '|F*Vu[$>9X&'
    set_0 = {str_1, str_0, str_1}
    bool_0 = False
    list_0 = [bool_0, set_0, bool_0]
    action_module_0 = ActionModule(str_0, str_1, set_0, set_0, bool_0, list_0)
    action_module_0.run()

    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:58.176811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with None argument
    test_case_0()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:02.007451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x5e4.\xc1\x8a'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = action_module_0.run()
    return var_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:53:08.609474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, False, None, False, None)
    bool_0 = True
    str_0 = 'y_'
    list_0 = ['L%<', 'Z,Fgf^', '@UX', 'y_', 'y_']
    tuple_0 = None
    str_1 = None

# Generated at 2022-06-25 07:53:17.510898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, b'mf\x9aPj\xf5\xcb\xc0\x8e\xb4\xfd\x18\x0c\x8e4\xe4\xbb', True, 0.0, True, 0.0)

# Generated at 2022-06-25 07:53:20.007536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:53:28.297338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_ActionModule()

from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip
#from ansible.module_utils.six.moves.urllib.parse import urlparse
from ansible.module_utils.six.moves.urllib.parse import urlsplit
from ansible.module_utils._text import to_text
from ansible.plugins.action import ActionBase
from ansible.utils.hashing import checksum
from ansible.utils.path import makedirs_safe
from ansible.utils.unicode import unicode_wrap

# Python 3: convert str to bytes
try:
    from __builtin__ import bytes
except ImportError:
    pass

#TODO: allow toggling checksum comparison of source and dest
#TOD

# Generated at 2022-06-25 07:53:31.678268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of the class ActionModule
    bool_0 = False
    str_0 = '#Y\'\xe3\x14X\xb0\x1a~'
    action_module_0 = ActionModule(str_0, str_0, bool_0, None, None, None)
    test_case_0()


# Generated at 2022-06-25 07:53:34.231236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print("ERR: caught exception" + str(e))
        var_0 = e

# Generated at 2022-06-25 07:53:41.570843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with bogus source and dest.
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    action_module_1 = ActionModule(tuple_0, list_0, str_1, action_module_0, tuple_0, bytes_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:53:46.017858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '6U\x1b'
    bytes_0 = b'\x99\x16\x11\x8e\xdbx'
    bool_0 = True
    float_0 = None
    bool_1 = False
    float_1 = None
    action_module_0 = ActionModule(str_0, bytes_0, bool_0, float_0, bool_1, float_1)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:54:07.200233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_dict = None
    bytes_dict = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    bool_dict = True
    float_dict = None
    action_module_dict = ActionModule(str_dict, bytes_dict, bool_dict, float_dict, bool_dict, float_dict)
    if action_module_dict is None:
        raise Exception("Unable to create ActionModule")


# Generated at 2022-06-25 07:54:10.295715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:54:11.469343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:54:22.750990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 't'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None

# Generated at 2022-06-25 07:54:26.781267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:54:32.403066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'r-8'
    list_0 = [str_0, str_0, str_0]
    int_0 = 99
    float_0 = None
    str_1 = 'src'
    bytes_0 = b'k\x1f\x1f\x1d\x97C\x08\x92\x9b\x07\x80\xff\xba\xb8\xc4\x03\x12\xdd'
    str_2 = 'ut'
    str_3 = 'ut'
    dict_0 = {str_1: str_2, str_3: int_0}
    tuple_0 = (str_3, bytes_0)

# Generated at 2022-06-25 07:54:38.702370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 07:54:41.146198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:54:50.944383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'x-x'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'w\x1b\xa4\xbf)\xcc|\xe3\x9c\x1dv\xad\xf1\xee\xd0\x83'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}

# Generated at 2022-06-25 07:54:52.604598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)


# Generated at 2022-06-25 07:55:26.574662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:37.790077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # default
    bool_0 = True
    str_0 = '&%*f4Ny.\x9b6\xef'
    list_0 = []
    tuple_0 = int()
    str_1 = None
    bytes_0 = b'\xc2M\xed\x18\x04f\x08'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, float_0, float_0, float_0, float_0)
    dict_0 = {tuple_0: bytes_0, tuple_0: float_0, tuple_0: bytes_0, tuple_0: float_0}
    tuple_1 = (bytes_0, list_0, tuple_0, dict_0)
    bool_1 = False
    action_module

# Generated at 2022-06-25 07:55:46.034134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 07:55:48.075489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as e:
        print("Error in function test_ActionModule_run: %s" % e)
        raise e

test_ActionModule_run()

# Generated at 2022-06-25 07:55:51.573814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

if __name__ == "__main__":
	print('Executing unit tests for ' + __file__)

	test_ActionModule()

# Generated at 2022-06-25 07:55:53.018304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit test runner

# Generated at 2022-06-25 07:56:03.454462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'w-5'
    list_0 = [str_0, bool_0]
    bool_1 = False
    str_1 = None
    bytes_0 = b"'\xde\xe8\x99\xb2r?\x86q\x03\x95\x1d\xbd\x08\x9dW\x99\xf0\x1c\x8a\xb2\xbc`\x91"
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)

# Generated at 2022-06-25 07:56:11.059552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '6gp`'
    list_0 = ['11', 'bJ']
    tuple_0 = list_0
    str_1 = '2f#'
    bytes_0 = b'\xd3\x07\x8b'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:56:15.941900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:56:17.924780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run for class ActionModule
    # Test the case where the action module fails
    pass
# end class ActionModule

# Generated at 2022-06-25 07:57:25.905361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 07:57:30.457591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(sys.version_info)
    print(sys.version)
    print(sys.path)
    print(sys._getframe().f_code.co_filename)
    print(os.path.realpath(__file__))
    print(os.path.dirname(os.path.realpath(__file__)))
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:57:41.803497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'c\x1e'
    list_0 = [bool_0, str_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\x1f\xcd'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    action_module_0.add_host()
    action_module_0.add_hosts(bool_0)
    var_0 = action_module_0.get_vault_password(float_0)
    action_module_0.on_any()
    var_1 = action_module_0.on_failed()
    var_2 = action_module_0.on

# Generated at 2022-06-25 07:57:50.135925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 07:57:53.042226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = None
    bytes_1 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    bool_2 = True
    float_1 = None
    bool_3 = True
    float_2 = None
    test_case_0()


# Generated at 2022-06-25 07:57:58.434817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(action_module_1, action_module_1, bool_1, action_module_0, list_0, action_module_0)
    test_case_0()

# Generated at 2022-06-25 07:58:05.818149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'r.c'
    list_0 = [str_0, bool_0]
    dict_0 = {bool_0: list_0, None: bool_0}
    tuple_0 = (dict_0, str_0)
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, bool_1, bool_0, bool_1, bool_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:58:08.991362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 10
    tuple_0 = (float_0, float_0, float_0)
    float_1 = float_0
    action_module_0 = ActionModule(tuple_0, tuple_0, float_1, float_1, float_1, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:58:11.846673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:58:14.297887
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()


if __name__ == '__main__':
   test_case_0()
   test_ActionModule()

# Generated at 2022-06-25 08:00:32.752653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_var = ActionModule('src')


# Generated at 2022-06-25 08:00:38.148028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 08:00:46.246215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'l-4'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\xf4fDC\xa7& \xbe1\xb1\x8a+%BG'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_1 = (bool_0, list_0, tuple_0, dict_0)
    bool_1 = False

# Generated at 2022-06-25 08:00:52.709958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9"j'
    bytes_0 = b'\x1e\xf4\xd5'
    float_0 = 0.5146047841442673
    file_0 = File(str_0, bytes_0)
    action_module_0 = ActionModule(file_0, bytes_0, float_0, float_0, float_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:00:54.517378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:00:55.277217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 08:00:56.090413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 08:00:59.706051
# Unit test for constructor of class ActionModule
def test_ActionModule():
  true = True
  false = False
  b'\x1c\x1b\xe0\xc2\xcd\xf7\xe2\x8a\x81\xb4\xee\xed\x8f\xbd\xeb\xfb'
  # (self: object, args: object, *kwargs: object) -> None
  test_case_0()

if __name__ == '__main__':
  test_ActionModule()

# Generated at 2022-06-25 08:01:05.115055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = ']\x9a\xee\xcc\xba\x8f\xa7g;\xe5\xd7'
    str_1 = '\xcc\xba\x8f\xa7g;\xe5\xd7'
    bytes_0 = b'[\x9a\xee\xcc\xba\x8f\xa7g;\xe5\xd7'
    list_0 = [str_0, bool_0]
    tuple_0 = (str_0, False)
    float_0 = 6.233
    action_module_0 = ActionModule(str_0, bytes_0)
    dict_0 = {str_0: set(), str_0: None, None: bytes_0, action_module_0: None}

# Generated at 2022-06-25 08:01:10.168526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'g-2'
    list_0 = [str_0, bool_0]
    tuple_0 = None
    str_1 = None
    bytes_0 = b'\x99F\x8f\x9a\x9f\xbf\xfb\x80\x88\xf6\x83\xa1\x8e\xea\xa6\x9e\xec\x98'
    float_0 = None
    action_module_0 = ActionModule(str_1, bytes_0, bool_0, float_0, bool_0, float_0)
    dict_0 = {action_module_0: bytes_0, bytes_0: float_0, tuple_0: tuple_0, bool_0: str_0}
    tuple_