

# Generated at 2022-06-25 07:52:15.710974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    tmp = 'tmp'
    task_vars = dict_0
    assert action_module_0._connection is None
    assert action_module_0._diff is None
    assert action_module_0._task is None
    assert action_module_0._task_vars is None
    assert action_module_0._tmp is None
    assert action_module_0.action_loader is None
    assert action_module_0.action_plugins is None
    assert action_module_0.action_results is None
    assert action_module_0.action_strings is None
    assert action_module_0.display is None
    assert action_module_0.loader is None
    assert action_module

# Generated at 2022-06-25 07:52:18.296722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'gY'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    action_module_0.run(tuple_0, dict_0)


# Generated at 2022-06-25 07:52:24.228871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    try:
        # Make sure the path exists and is a file.
        assert os.path.exists(path) and os.path.isfile(path)
    except AssertionError:
        print('Not a file: %s' % path)



# Generated at 2022-06-25 07:52:35.222097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ('q', '9', '_E>|lp-k{w~')
    tuple_1 = ('G#Hm@(=', '5', '%nd#.E~A<|')
    dict_0 = {tuple_0: tuple_1, 'J!^5o5r': '+P[tKw?A'}
    str_0 = '8]IWxDq3J'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)


# Generated at 2022-06-25 07:52:40.037664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        tuple_0 = ()
        dict_0 = {tuple_0: tuple_0}
        str_0 = ']EoSx8$YZMU'
        tuple_1 = ()
        action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_1)
        assert False, 'Unreachable'
    except AnsibleAction as e:
        assert str(e) == "A valid task or handler is required", 'incorrect instance message'


# Generated at 2022-06-25 07:52:40.690202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:52:45.391307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    with pytest.raises(AnsibleActionFail):
        action_module_0.run(*tuple_0, **dict_0)
#

# Generated at 2022-06-25 07:52:57.853442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    tuple_1 = (tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    tuple_2 = (tuple_0, dict_0)
    tuple_3 = (tuple_2,)
    # We need to use each of these test cases once so that the IDE doesn't think they are not used
    test_case_0()
    # Test for constructor of class ActionModule
    action_module_0 = ActionModule(*tuple_1)
    assert type(action_module_0) == ActionModule
    action_module_0.run(*tuple_3)

# Generated at 2022-06-25 07:53:04.290719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = '@'
    dict_1 = {str_0: tuple_0}
    action_module_0 = ActionModule(tuple_0, dict_0, dict_1, tuple_0, str_0, tuple_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:10.598282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_1 = (1, 2, 3)
    dict_1 = {'d4Wg4v': 3, tuple_1: 2, 'mSV88': 2, 'OQsD3': 3, 'A03b1': 1, 'X': 1, 'lLl': 1, 'gE': 1, 'bAaZ': 1}
    action_module_1 = ActionModule(tuple_1, dict_1, dict_1, tuple_1, ']EoSx8$YZMU', tuple_1)
    action_module_1.run()


# Generated at 2022-06-25 07:53:20.411049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: set fileencodings=utf-8:

# Generated at 2022-06-25 07:53:27.141613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    str_1 = 'compiled.'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_1 = ActionModule(str_1, str_0, str_0, str_0, str_0, str_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:53:29.450459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 07:53:30.236658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test0 = test_case_0()

# Generated at 2022-06-25 07:53:33.836435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:53:37.021671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.test_case_0()

# Generated at 2022-06-25 07:53:40.865475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('test', 'test', 'test', 'test', 'test', 'test')

# Generated at 2022-06-25 07:53:41.589744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for case 0
    test_case_0()

# Generated at 2022-06-25 07:53:46.588641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('blossom', 'undertake', 'intimidated', 'abductions', 'exemplifying', 'chubbiness')
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0.TRANSFERS_FILES == True


# Generated at 2022-06-25 07:53:48.040409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()



# Generated at 2022-06-25 07:54:05.030716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run(str_0, str_0)
    raise NotImplementedError("Test not implemented")


# Generated at 2022-06-25 07:54:15.173897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'drained'
    str_1 = 'bilieus'
    str_2 = 'Seine-et-Oise'
    str_3 = '-'
    str_4 = 'uncheery'
    tmp = str_2
    task_vars = str_0
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, str_4, str_3)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:54:24.638129
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # setup
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    tmp = None
    task_vars = None
    dict_0 = dict()

    # Test case
    result = action_module_0.run(tmp, task_vars)
    print(result)
    if not result:
        raise Exception("Test case failed!")

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:33.362834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    dict_0 = dict()
    # Create an instance of the ActionModule class using the constructor
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    # Get the method run from class ActionModule
    method_run = getattr(action_module_0, 'run', None)
    # Use the above method and use the result to compare with the expected result. If they are equal, the test passed.
    test_case_0()


# Generated at 2022-06-25 07:54:39.230709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'remote_src'
    str_1 = 'total'
    str_2 = 'file'
    str_3 = 'AnsibleAction'
    str_4 = 'rescue'
    str_5 = 'msg'
    str_6 = 'entries'
    str_7 = 'dest'
    str_8 = 'AnsibleActionFail'
    str_9 = 'up'
    str_10 = 'rc'
    str_11 = 'remote_stat'
    str_12 = 'exc_type'
    str_13 = 'delta'
    str_14 = 'cache_plugin'
    str_15 = 'register'
    str_16 = 'stat'
    str_17 = 'original_basename'
    str_18 = 'expires'

# Generated at 2022-06-25 07:54:50.799976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "f"
    str_1 = "creates"
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run()
    action_module_0.run(str_0)
    action_module_0.run(bool_0)
    action_module_0.run(bool_1, str_0)

# Generated at 2022-06-25 07:54:54.136258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'hadn\'t'
    str_1 = 'rediscovers'
    action_module_0 = ActionModule('99', str_0, 'breezes', str_1, str_0, 'wrapping')
    assert action_module_0.TRANSFERS_FILES == True # A variable of instance of class ActionModule


# Generated at 2022-06-25 07:54:56.902707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
# End unit test for method run of class ActionModule

# Generated at 2022-06-25 07:55:01.096868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:55:05.241770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'drained'
    tmp_0 = 'breathed'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run(tmp_0)  # Should run without error


# Generated at 2022-06-25 07:55:35.007662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule)

test_case_ActionModule = [test_ActionModule]
test_module_ActionModule = [test_case_ActionModule]

# unit test for class ActionModule

# Generated at 2022-06-25 07:55:45.108186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    str_0 = 'dest'
    dict_0 = {}
    dict_0['src'] = 'src'
    dict_0['dest'] = 'dest'
    dict_0['remote_src'] = False
    dict_0['creates'] = str_0
    dict_0['decrypt'] = True
    dict_0['copy'] = True
    dict_1 = {}
    dict_1[str_0] = 'dest'
    dict_1['exists'] = True
    dict_1['isdir'] = True
    dict_1['isfile'] = True
    dict_1['islnk'] = True
    dict

# Generated at 2022-06-25 07:55:47.138482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:48.330336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: set et ts=4 sw=4:

# Generated at 2022-06-25 07:55:55.282059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    str_1 = 'imagine'
    str_2 = 'reclaim'
    str_3 = 'lured'
    str_4 = 'imply'
    str_5 = 'explored'
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, str_4, str_5)
    action_module_0.run(str_3, str_3)

# Unit tests for other methods of class ActionModule

# Generated at 2022-06-25 07:56:02.980394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = 'dest'
    task_vars = dict()
    task_vars['result'] = dict()
    task_vars['result']['results'] = [dict()]
    task_vars['result']['results'][0]['stdout'] = 'stdout'
    task_vars['result']['results'][0]['stderr'] = 'stderr'
    task_vars['result']['results'][0]['returncode'] = 'returncode'
    task_vars['result']['results'][0]['rc'] = 'rc'
    task_vars['result']['results'][0]['start'] = 'start'
    task_vars['result']['results'][0]['end'] = 'end'

# Generated at 2022-06-25 07:56:12.555324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule('photo', 'isoceles', 'felon', 'cannabis', 'tampon', 'mythology')
    action_module_1._set_options('towel', 'offscreen', 'gymnast', 'mundane')
    action_module_1._load_params()
    action_module_1._task._ds = dict(lazy=dict(ignore='wilt', remote_src='puzzling', creates='appraisal', src='conciliatory'), become_user='enunciation')
    result = action_module_1.run()
    assert result == dict(msg='Could not find src in expected paths')

# Test case with invalid action name

# Generated at 2022-06-25 07:56:16.870355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    str_0 = 'drained'
    ansible_action_0 = AnsibleAction(str_0, str_0, str_0, str_0, str_0)
    str_1 = 'dormant'
    ansible_action_0 = action_module_0.run(str_0, str_1)

# Generated at 2022-06-25 07:56:25.098320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = ['tmp']

# Generated at 2022-06-25 07:56:34.372871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    e_0 = dict()
    e_0['tmp'] = None
    e_0['task_vars'] = dict()
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    assert action_module_0._task.args.get('src', None) is None
    assert action_module_0._task.args.get('dest', None) is None
    assert action_module_0._task.args.get('remote_src', False) is False
    assert action_module_0._task.args.get('creates', None) is None
    assert action_module_0._task.args.get('decrypt', True) is True

# Generated at 2022-06-25 07:57:01.550752
# Unit test for constructor of class ActionModule
def test_ActionModule():
   test_case_0()

# End of tests for constructor of class ActionModule
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:57:02.766303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Generated at 2022-06-25 07:57:10.396405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test action-module.py line 39
    str_0 = u'\x98P\x9d\x91\xa2\xa4\x1b\xafe\x87\x8d'
    try:
        # Test action-module.py line 40
        test_case_0()
    except:
        # Test action-module.py line 40
        # Test action-module.py line 40
        raise

# Generated at 2022-06-25 07:57:17.651949
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:57:21.321518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run()


# Generated at 2022-06-25 07:57:26.831606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 07:57:29.618610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'drained'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run()
    return



# Generated at 2022-06-25 07:57:31.490693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # CCTODO: Implement test
        pass
    except Exception as e:
        print(e)


# Generated at 2022-06-25 07:57:37.008490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    # Available functions: ActionModule, test_case_0

    tmp = None
    task_vars = None
    assert test_case_0.run(tmp, task_vars)  # TODO: There is an error here!

# Generated at 2022-06-25 07:57:42.101116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('a', 'a', 'a', 'a', 'a', 'a')
    tmp_0 = 'a'
    task_vars_0 = 'a'
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:58:20.432645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule->run()\n")
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'B?&#tb}@!{jVg'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:58:28.007703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    var_0 = action_module_0.run(tuple_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 07:58:36.574312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = '0=6'
    # Unit test for method run
    # Test case 0 with arguments: tmp=tuple_0, task_vars=dict_0
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    var_0 = action_module_0.run(tuple_0, dict_0)

# Generated at 2022-06-25 07:58:44.705085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables initialisation
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    str_1 = 'HHniEwYa86'
    str_2 = 't>k<ljh^1d'
    dict_1 = {str_1: str_2}
    str_3 = 'k.Z'
    str_4 = 'CcFwn1'
    str_5 = 'Mj>'
    tuple_1 = (str_3, str_4, str_5)

# Generated at 2022-06-25 07:58:47.817733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:58:53.139076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)


# Generated at 2022-06-25 07:58:59.395534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        tuple_0 = ()
        dict_0 = {tuple_0: tuple_0}
        str_0 = ']EoSx8$YZMU'
        action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
        action_module_0.run('', 0)
        action_module_0.run(0, '')

    except TypeError:
        return True
    except NameError:
        return True
    except ValueError:
        return True
    except AttributeError:
        return True
    except UnboundLocalError:
        return True

    return False


if __name__ == "__main__":
    import __main__
    import sys

# Generated at 2022-06-25 07:59:02.202161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)

# Generated at 2022-06-25 07:59:06.517274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)

# Generated at 2022-06-25 07:59:11.935598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   tuple_0 = ()
   dict_0 = {tuple_0: tuple_0}
   str_0 = '[l_7C'
   action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
   tmp_0 = None
   task_vars_0 = None
   var_0 = action_module_0.run(tmp_0, task_vars_0)
   return var_0

test_ActionModule_run()

# Generated at 2022-06-25 08:00:17.268334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 08:00:22.027502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    test_case_0()


# Generated at 2022-06-25 08:00:25.130882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = '^'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    var_0 = action_run(tuple_0, dict_0)


# Generated at 2022-06-25 08:00:25.816000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 08:00:32.477362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    test_case_str = 'test_case_0'
    str_0 = ']EoSx8$YZMU'
    tuple_1 = ()
    list_0 = [tuple_0, tuple_1, tuple_0]
    var_0 = list_0[2]
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, test_case_str, var_0)
    action_module_0.run(tuple_0, tuple_0)

if __name__ == '__main__':
    #test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:00:38.835348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ('P', '/nkY+')
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'p&8w,Y#{u'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    assert action_module_0.TRANSFERS_FILES
    action_module_0.run()
    assert action_module_0.run() == None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:00:45.527659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    dict_1 = dict_0.copy()
    dict_2 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    tuple_1 = (dict_1,)
    action_module_0 = ActionModule(tuple_1, dict_2, dict_0, tuple_0, str_0, tuple_0)
    assert action_module_0.action == tuple_1
    assert action_module_0.module_name == dict_2
    assert action_module_0.task_vars == dict_0
    assert action_module_0.tmp == tuple_0
    assert action_module_0.play_context == str_0
    assert action_module_0

# Generated at 2022-06-25 08:00:52.434225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ''
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:00:57.362798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ']EoSx8$YZMU'
    action_module_0 = ActionModule(tuple_0, dict_0, dict_0, tuple_0, str_0, tuple_0)



# Generated at 2022-06-25 08:01:05.951396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_2 = ()
    dict_2 = {tuple_2: tuple_2}
    str_2 = 'h_'
    tuple_3 = ()
    dict_3 = {tuple_3: tuple_3}
    str_3 = 'FwH\n'
    tuple_4 = ()
    dict_4 = {tuple_4: tuple_4}
    str_4 = 'gj\tW8z&^'
    tuple_5 = ()
    action_module_0 = ActionModule(tuple_2, dict_2, dict_3, tuple_3, str_3, tuple_4)
    #Assertion:  == (len(action_module_0.get_action_class(action_module_0._task.action)))
    var_0 = action_module_0.__init