

# Generated at 2022-06-25 07:52:15.602948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = "foo/bar"
    dest = "/tmp/foo/bar"
    creates = None
    decrypt = True
    _task = "foo/bar"
    tmp = None
    task_vars = dict()
    _find_needle = "foo/bar"
    _loader = "foo/bar"
    _execute_remote_stat = "foo/bar"
    _remote_expand_user = "foo/bar"
    _connection = "foo/bar"
    _remote_file_exists = "foo/bar"
    _transfer_file = "foo/bar"
    _fixup_perms2 = "foo/bar"
    _remove_tmp_path = "foo/bar"
    _execute_module = "foo/bar"

# Generated at 2022-06-25 07:52:22.165526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a0 = 0.4
    a1 = 40
    a2 = 400
    a3 = 4000
    a4 = 40000
    a5 = 400000
    a6 = 4000000
    a7 = 40000000
    a8 = 40000000
    a9 = 400000000
    action_module_0 = ActionModule('', a0, a1, a2, a3, a4)
    action_module_1 = ActionModule('', a5, a6, a7, a8, a9)
    action_module_2 = ActionModule('', a2, a0, a1, a8, a7)
    action_module_3 = ActionModule('', a9, a2, a1, a0, a8)

# Generated at 2022-06-25 07:52:23.043302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:52:25.579928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print('Ok!')
    except:
        print('test_ActionModule() ERROR')


# Test cases
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:32.879349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Parse the output of the lsb_release command.\n\n        Parameters:\n\n        * lines: Iterable through the lines of the lsb_release output.\n                 Each line must be a unicode string or a UTF-8 encoded byte\n                 string.\n\n        Returns:\n            A dictionary containing all information items.\n        '
    str_1 = 'luseradd'
    set_0 = {str_1}
    dict_0 = {}
    float_0 = 4363.03
    action_module_0 = ActionModule(str_0, str_1, set_0, dict_0, set_0, float_0)


# Generated at 2022-06-25 07:52:40.176288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Parse the output of the lsb_release command.\n\n        Parameters:\n\n        * lines: Iterable through the lines of the lsb_release output.\n                 Each line must be a unicode string or a UTF-8 encoded byte\n                 string.\n\n        Returns:\n            A dictionary containing all information items.\n        '
    str_1 = 'luseradd'
    set_0 = {str_1}
    dict_0 = {}
    float_0 = 4363.03
    action_module_0 = ActionModule(str_0, str_1, set_0, dict_0, set_0, float_0)
    action_module_0.run()


if __name__ == "__main__":
    test_case_0()
    test_

# Generated at 2022-06-25 07:52:44.454402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid argument types and valid return type

    # Run the action module
    test_case_0()
    # Test with invalid argument types

    # Test with invalid return type


test_cases = [
    (test_ActionModule_run,)
]

# Run tests
for test in test_cases:
    func = test[0]
    try:
        func()
    except Exception as e:
        print('FAILURE: test_' + func.__name__ + '() threw an exception!')
        print(e)
    else:
        print('SUCCESS: test_' + func.__name__ + '() completed.')

# Generated at 2022-06-25 07:52:51.831410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = '\n        Parse the output of the lsb_release command.\n\n        Parameters:\n\n        * lines: Iterable through the lines of the lsb_release output.\n                 Each line must be a unicode string or a UTF-8 encoded byte\n                 string.\n\n        Returns:\n            A dictionary containing all information items.\n        '
    str_3 = 'luseradd'
    set_1 = {str_3}
    dict_1 = {}
    float_1 = 4363.03
    action_module_1 = ActionModule(str_2, str_3, set_1, dict_1, set_1, float_1)
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}

# Generated at 2022-06-25 07:52:52.839062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:53:03.255232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n        Parse the output of the lsb_release command.\n\n        Parameters:\n\n        * lines: Iterable through the lines of the lsb_release output.\n                 Each line must be a unicode string or a UTF-8 encoded byte\n                 string.\n\n        Returns:\n            A dictionary containing all information items.\n        '
    str_1 = 'luseradd'
    set_0 = {str_1}
    dict_0 = {}
    float_0 = 4363.03
    action_module_0 = ActionModule(str_0, str_1, set_0, dict_0, set_0, float_0)
    action_module_0.FIXTURE_DIR = 'vA'
    action_module_0.DEFAULT_MODULE_UTILS

# Generated at 2022-06-25 07:53:17.082755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for the class
    test_ActionModule_obj_0 = ActionModule()

    # Unit test for the method run
    test_case_0()

# Call the method unit test function
test_ActionModule_run()

# Generated at 2022-06-25 07:53:21.159101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    result_0 = action_module_0.run(tmp=tmp_0)
    print('Testing method run of class ActionModule')
    print('Result:')
    print(result_0)
    print('Testing complete')
    print('\n')

# Testing method init of class ActionModule

# Generated at 2022-06-25 07:53:24.430607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule("Ok!")
    var_1 = "Ok!"
    var_2 = True
    var_3 = None
    var_4 = {}
    var_5 = {}
    var_6 = print(var_0.run(var_1, var_2, var_3, var_4, var_5))


# Generated at 2022-06-25 07:53:28.209091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global str_0
    global var_0
    test_case_0()
 
if __name__ == '__main__':
    py_0 = ActionModule()
    test_ActionModule()

# Generated at 2022-06-25 07:53:31.415591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert isinstance(var_0, ActionModule)


# Generated at 2022-06-25 07:53:34.805434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creates an object using the default constructor
    test_0 = ActionModule()


# Generated at 2022-06-25 07:53:36.510048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:53:42.670639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(tmp_0, task_vars_0)
    obj_0.run()


# Generated at 2022-06-25 07:53:48.268959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = 'src'
    dest = 'dest'
    remote_src = False
    creates = None
    decrypt = True
    tmp = None
    task_vars = dict()
    # test_case_0
    module_0 = ActionModule()
    module_0.ActionBase.run(tmp, task_vars)

# Generated at 2022-06-25 07:53:49.777352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:54:01.337415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.set_task(task=dict())
    return action_module_0



# Generated at 2022-06-25 07:54:02.908130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    # pass


# Generated at 2022-06-25 07:54:07.485569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = dict(
        action="copy",
        src="/foo/bar/baz.tgz"
    )
    action_module_1 = ActionModule(config=config)
    task_vars = [dict(ansible_user="bob"), dict(ansible_user="mike")]
    action_module_1.run(task_vars=task_vars)

# Generated at 2022-06-25 07:54:10.566212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    action_module = ActionModule()
    if type(action_module) is ActionModule:
        print("passed test")
    else:
        print("failed test")


# Generated at 2022-06-25 07:54:12.986080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:  ActionsBase runs these tests, investigate why we can't use them.
    pass


# Generated at 2022-06-25 07:54:16.432616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:22.900225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule), "ActionModule is not callable"
    assert isinstance(ActionModule, object), "ActionModule is not an instance of object"
    assert isinstance(ActionModule, ActionBase), "ActionModule is not an instance of ActionBase"
    assert hasattr(ActionModule, 'run') and callable(getattr(ActionModule, 'run')), "ActionModule has no run method"

# Generated at 2022-06-25 07:54:24.227083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:54:24.984415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:54:29.872476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    source_0 = ''
    dest_0 = ''
    task_vars_0 = {}
    action_module_0.run(source_0, dest_0, task_vars_0)


# Generated at 2022-06-25 07:54:39.696294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:54:43.827679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:54:46.944821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -100
    int_1 = -100
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(int_0, int_0, int_0, int_1, set_0, list_0)


# Generated at 2022-06-25 07:54:51.836536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:54:52.743793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(float, bool, int, int, set, list)



# Generated at 2022-06-25 07:55:01.418278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'J\t'
    float_0 = 725.0
    bool_0 = True
    int_0 = 583
    int_1 = 770
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0, action_module_0)


# Generated at 2022-06-25 07:55:03.212088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    pass


# Generated at 2022-06-25 07:55:12.102923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'n\tOB'
    float_0 = -2987.0
    bool_0 = False
    int_0 = -376
    int_1 = -534
    set_0 = frozenset()
    list_0 = []
    list_1 = []
    assert type(action_module_0) == ActionModule
    assert type(var_0) == dict


# Generated at 2022-06-25 07:55:16.608598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:55:23.287488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0.p\x1b'
    float_0 = -1939.5
    bool_0 = False
    int_0 = 568
    int_1 = 556
    set_0 = {'_\x16'}
    list_0 = [97, -1390, -1390, -1390]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:55:44.681136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    test_case_0(str_0, float_0, bool_0, int_0, int_1, set_0, list_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:55:55.318437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')h'
    set_0 = set()
    list_0 = []
    float_0 = -2060.0
    bool_0 = False
    int_0 = 3641
    int_1 = 739
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert_true(isinstance(action_module_0, ActionBase), message='Argument is not an instance of class "ActionBase"')
    assert_true(hasattr(action_module_0, '_task'), message='Attribute "_task" of class "ActionBase" is not set')
    # AssertionError: Attribute "_task" of class "ActionBase" is not set

# Generated at 2022-06-25 07:55:56.999870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run == '\n'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:56:07.746948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # From: https://github.com/python/cpython/blob/3.6/Lib/test/test_operations.py
    # Example: def test_truth(self):
    #          self.assertIs(True, True)
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)
    with pytest.raises(AssertionError):
        assert var_0 == True

    # Example: def test_

# Generated at 2022-06-25 07:56:11.292955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)


# Generated at 2022-06-25 07:56:18.555084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\tL\'\t'
    float_0 = -1778.0
    bool_0 = True
    int_0 = 1032
    int_1 = 0
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)
    assert var_0 is None
    assert isinstance(var_0, dict)

# Test class ActionModule - Unit test of method run

# Generated at 2022-06-25 07:56:25.802537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)
    assert isinstance(action_module_0, ActionModule) == True

if not os.path.exists('/tmp/ansible_unarchive_payload'):
    os.mkdir('/tmp/ansible_unarchive_payload', 493)



# Generated at 2022-06-25 07:56:27.392041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:56:36.296500
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:56:42.563665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert action_module_0.debug is False
    assert action_module_0.display is False
    assert int_0 == 474
    assert set_0 == 0
    assert list_0 == 0
    assert float_0 == -1175.0
    assert int_1 == 301
    assert bool_0 is False
    var_0 = action_module_run(str_0)


# Generated at 2022-06-25 07:57:18.682121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)
    assert (((var_0 + var_0) * -1175.0) == -9925.0)


# Generated at 2022-06-25 07:57:24.376134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    setup_function()
    int_0 = random.randint(-64, 64)
    int_1 = random.randint(0, 128)
    str_0 = ''
    for i in range(0, random.randint(3, 5)):
        str_0 += random.choice(string.ascii_letters)
    float_0 = random.uniform(-85.0, 85.0)
    list_0 = []
    for i in range(0, random.randint(4, 6)):
        list_0.append(random.choice(string.ascii_letters))
    tuple_0 = (list_0,)
    set_0 = set(tuple_0)

# Generated at 2022-06-25 07:57:29.551748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ['a', 'b', 'c']
    set_0 = set()
    int_1 = 69
    int_0 = 22
    bool_0 = False
    float_0 = 1.0
    dict_0 = dict()
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert(action_module_0.action_executor_type == 'module')
    assert(action_module_0.action_executor_plugin == '_multi_file')
    assert(action_module_0.action_loader_plugin == '_multi_file')
    assert(action_module_0.action_processors == ['_file_processor'])

# Generated at 2022-06-25 07:57:37.982286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define input parameters
    # Assign values to input parameters
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()

# Generated at 2022-06-25 07:57:40.566846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() is None

# Test Traitlet values and types

# Generated at 2022-06-25 07:57:41.855816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:57:50.181352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\rl\x0c'
    float_0 = -1336.0
    bool_0 = False
    int_0 = 0
    int_1 = 98
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert action_module_0._connection.connection_name == float_0
    assert action_module_0._task.action == bool_0
    assert action_module_0._task.args['which'].value == int_0
    assert int_1 == 98
    assert action_module_0.TRANSFERS_FILES == set_0
    assert action_module_0._shared_loader_obj == list_0

#

# Generated at 2022-06-25 07:57:55.786381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0.1'
    float_0 = -154.0
    bool_0 = True
    int_0 = 68
    int_1 = 768
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    float_0 = -154.0
    str_0 = './lib/ansible/plugins/action/unarchive.py'
    bool_0 = True
    int_0 = 519
    int_1 = 537
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)


# Generated at 2022-06-25 07:58:04.634113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = True
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert action_module_0.TRANSFERS_FILES == True
    str_1 = 'slide'
    task_vars_0 = {}
    var_0 = action_module_0.run(str_1, task_vars_0)

# Generated at 2022-06-25 07:58:15.055051
# Unit test for constructor of class ActionModule
def test_ActionModule():
  float_0 = float(0.87895076614)
  bool_0 = False
  int_0 = int(131)
  int_1 = int(601)
  set_0 = set(['m', 'T', 'x\x7f', '\x02V', '\x0e\x7f', '', '\x7f\x1d\x7f', '\n'])
  list_0 = ['\x1c', '\x0e\x7f', '']
  action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
  assert action_module_0.float_0 == float_0
  assert action_module_0.bool_0 == bool_0
  assert action_module_

# Generated at 2022-06-25 07:59:28.063420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_run(str_0)
    return var_0

# Generated at 2022-06-25 07:59:33.554722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(Exception):
        test_case_0()
    with pytest.raises(Exception):
        test_case_1()
    test_case_2()

# Generated at 2022-06-25 07:59:37.314754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert type(self, ActionModule) == type(ActionModule)
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 07:59:41.841226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\r'
    float_0 = -5392.33
    bool_0 = True
    int_0 = 0
    int_1 = 862
    set_0 = set('\r|\r>")\x0c')
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:59:45.493450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1175.0
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert isinstance(action_module_0.DRQQDA, float)


# Generated at 2022-06-25 07:59:54.142914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3.2
    bool_0 = True
    int_0 = 3
    int_1 = 3
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set(), [])
    assert isinstance(action_module_0.run(), dict)


# Generated at 2022-06-25 08:00:03.902741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    var_0 = action_module_0.run(str_0)
    assert var_0 == "H\x0f\x15\x12\x0b\x04\x16\x03\x1a\x0e\x1b\x1f\x06\x0a\x0c"

if __name__ == "__main__":
    test_case_0()
    test_

# Generated at 2022-06-25 08:00:10.509791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module_0
    str_0 = 'o\r\x0c'
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)

# Generated at 2022-06-25 08:00:17.598830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'n\x15\x1f'
    float_0 = 1.0
    bool_0 = False
    int_0 = 74
    int_1 = 945
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    dict_0 = dict()
    dict_1 = dict()
    action_run(str_0, dict_0, dict_1)


# Generated at 2022-06-25 08:00:23.341760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1175.0
    bool_0 = False
    int_0 = 474
    int_1 = 301
    set_0 = set()
    list_0 = []
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, set_0, list_0)
    assert_equal(action_module_0.TRANSFERS_FILES, True, 'action_module_0.TRANSFERS_FILES')
