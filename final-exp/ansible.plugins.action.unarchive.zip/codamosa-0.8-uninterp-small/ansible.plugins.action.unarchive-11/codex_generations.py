

# Generated at 2022-06-25 07:52:06.615763
# Unit test for constructor of class ActionModule
def test_ActionModule():
  test_case_0()

if __name__ == "__main__":
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:52:13.467934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    bool_0 = False
    tuple_0 = (list_0, str_1, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)

# Generated at 2022-06-25 07:52:16.255236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:52:24.697338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'rX3p}d(Nt#jG&P08zt'
    str_1 = 'UNH%ik1[YI&fJ8m'
    list_0 = [str_0, str_0]
    bool_0 = False
    tuple_0 = (list_0, str_0, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_0._action_id = 'Y9_A/7cwk?v0s@iV'
    action_module_0._play_context = 'm6Zo9'
    action_module_0._play = 'g'
    action_module_0._loader = 'pI$'
   

# Generated at 2022-06-25 07:52:30.777517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.errors import AnsibleActionFail
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    if True:
        from ansible.plugins.action.unarchive import ActionModule
        from ansible.module_utils.parsing.convert_bool import boolean
        from ansible.module_utils._text import to_text
        self_0 = ActionModule()
        task_vars_0 = dict()
        source_0 = 'p+t'
        dict_0 = dict()
        dict_0['decrypt'] = True

# Generated at 2022-06-25 07:52:33.578554
# Unit test for constructor of class ActionModule
def test_ActionModule():
  val_0 = '!o4.'
  val_1 = 'i5'
  val_2 = 'OE5'
  val_3 = ';x9'
  test_case_0()

# Generated at 2022-06-25 07:52:39.388525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fT7_`U6&~U6Zu'
    str_1 = 'n[%k^7V!bB!{w'
    list_0 = [str_1, str_1]
    bool_0 = False
    tuple_0 = (list_0, str_1, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    tmp = None
    task_vars = None
    assert not action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:45.191117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'w;<rPbh.Q{y*Yk'
    str_1 = '*'
    list_0 = [str_1, str_1]
    bool_0 = False
    tuple_0 = (list_0, str_1, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:52:54.952818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C)ZB/?E*h#f|pdD]t'
    str_1 = 'Gz?s;Y%sH{4t$_gQ'
    tuple_0 = ()
    list_0 = []
    bool_0 = True
    list_1 = [str_1, str_1]
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_1)
    assert isinstance(action_module_0.run(), dict)


# Generated at 2022-06-25 07:52:58.339024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print(err)
    finally:
        print('ActionModule test completed!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:53:16.646933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    assert action_module_0.tactics is tuple_0
    assert action_module_0.transport is str_1
    assert action_module_0.delegate_to is list_0
    assert action_module_0.name is str_0


# Generated at 2022-06-25 07:53:26.950401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
  str_1 = 'K$3s&o[+z!?k/um'
  list_0 = [str_1, str_1]
  str_2 = '1PWJ\x0b}V&>'
  bool_0 = False
  tuple_0 = (list_0, str_2, bool_0)
  action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
  var_0 = action_run()

# Generated at 2022-06-25 07:53:34.275311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '0'
    str_1 = 'h'
    list_0 = [str_1, str_0]
    str_2 = 'D'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    assert False


# Generated at 2022-06-25 07:53:41.820024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run = 'ActionModule.run'
    action_unarchive = 'ansible.legacy.unarchive'
    bool_0 = False
    bool_1 = False
    bool_2 = True
    bool_3 = False
    bool_4 = True
    bool_5 = False
    bool_6 = False
    bool_7 = False
    bool_8 = True
    bool_9 = False
    bool_10 = False
    bool_11 = False
    bool_12 = False
    bool_13 = True
    bool_14 = False
    bool_15 = False
    bool_16 = True
    bool_17 = False
    bool_18 = False
    bool_19 = False
    bool_20 = False
    bool_21 = True
    bool_22 = False
    bool_23 = True
    bool

# Generated at 2022-06-25 07:53:50.963439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)


# Generated at 2022-06-25 07:53:58.256936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)

    try:
        var_0 = action_run()
    except Exception:
        var_0 = {}



# Generated at 2022-06-25 07:54:02.241058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Call method run of class ActionModule")
    action_module_0 = ActionModule("")
    action_module_0.run("", "")

test_ActionModule_run()

# Generated at 2022-06-25 07:54:10.528676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    # print(action_module_0)
    action_module_0.run(list_0, list_0)

if __name__ == "__main__":
    # test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:54:16.006966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_4 = 'e;X%c6_bU6+{=0'
    list_1 = ['|\\1^\\>p\xc0', '6^\x11\x0c\x00b']
    str_5 = 'wz4\x1d[3E'
    bool_1 = False
    tuple_1 = (list_1, str_5, bool_1)
    action_module_1 = ActionModule(str_3, str_4, tuple_1, list_1, bool_1, list_1)
    var_1 = action_module_1.run()

# Generated at 2022-06-25 07:54:25.544399
# Unit test for constructor of class ActionModule
def test_ActionModule():
	str_0 = '&#4['
	str_1 = 'validate_certs'
	list_0 = [str_0, str_1, str_0]
	str_2 = 'AIW&`J=\x0bp'
	str_3 = 'I'
	str_4 = 'remote_src'
	bool_0 = True
	tuple_0 = (str_2, str_2, str_2)
	tuple_1 = (str_3, str_4, bool_0)
	action_module_0 = ActionModule(str_0, tuple_0, list_0, tuple_1, str_2, list_0, str_2)


# Generated at 2022-06-25 07:54:43.482543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:54:50.804855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'P!x_Hs|s"s~>V@f'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:54:51.217576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:54:53.644460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
        action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except:
        return


# Generated at 2022-06-25 07:55:04.153805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)

    var_0 = action_run()

    assert var_0 == 'x'
    assert action_module_0.tmp == 'x'
    assert action_module_0.task_vars == 'x'
    assert action_module_0.remote_user

# Generated at 2022-06-25 07:55:09.470781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'F1{v~a<Fy_'
    str_1 = 'zv&8L7W+$'
    list_0 = [str_0, str_1]
    str_2 = 'e>&9|4=l\x0c'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_0.run()
    action_module_1 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_1.run()

# Generated at 2022-06-25 07:55:17.935150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 != None
    assert action_module_0._connection.connection == 'ssh'
    assert action_module_0._task == 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    assert action_module_0.name == 'K$3s&o[+z!?k/um'
    assert action_module_0._loader.path_exists == False
    assert action_module_0._loader.list_collection_paths == ['1PWJ\x0b}V&>']
    assert action_module_0._loader.collection_requirements == {}
    assert action_module_0._loader.failed == False
    assert action_module_0._loader.warnings == []
    assert action_module_0._loader.collections_to_sync['ansible.builtin'] == False
   

# Generated at 2022-06-25 07:55:23.528220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    del list_0
    del tuple_0
    assert action_module_0.run() == None

# vim: syntax=python style=unix

# Generated at 2022-06-25 07:55:34.188672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "How many times must the cannon balls fly before they're forever banned?"
    str_1 = "fr1&!O3q%s"
    list_0 = [str_1, str_1]
    str_2 = "bKD>\x1c8'C"
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    # Undefined variable 'tmp'
    # Undefined variable 'task_vars'
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:55:44.093645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`$87.(}\x0bWzc%s'
    str_1 = '<2T?$'
    str_2 = '~?%cQ'
    bool_0 = True
    list_0 = [str_0, str_1, str_2, bool_0]
    str_3 = '5e7;'
    str_4 = '4M&'
    tuple_0 = (str_1, str_4)
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_3, tuple_0, list_0, bool_1)
    assert isinstance(action_module_0.run, object)


# Generated at 2022-06-25 07:56:15.999421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:56:24.698408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    assert action_module_0._task == str_2
    assert action_module_0._connection == bool_0
    assert action_module_0._play_context == list_0
    assert action_module_0._loader is None
    assert action_module_

# Generated at 2022-06-25 07:56:28.396939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'N>dQ\x0br.g\x7f'
    str_1 = 'h|mJ~Q?zvf}mB0'
    tuple_0 = (str_0, str_1)
    action_module_0 = ActionModule(str_0, str_0, tuple_0, str_1, str_1, str_1)
    var_0 = action_module_0.run(str_0)
    var_1 = action_module_0.run(str_0, str_0)

# Generated at 2022-06-25 07:56:35.148736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    str_0 = ""
    str_1 = "^e[ZjTT%Y\n"
    list_0 = [str_1, str_1]
    str_2 = "PxayZ[9(Y"
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    action_module_0.run()



# Generated at 2022-06-25 07:56:42.705604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'X{c%4.\x7fqeMd'
    str_1 = '\t;\x7f_+x-X'
    action_module_0 = ActionModule(str_0, str_1, tuple(), list(), True, list())
    var_0 = action_module_0.run()
    assert var_0 is None


# Generated at 2022-06-25 07:56:51.511483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Xy\'m\x7f4L\x01\n'
    str_1 = '\x1e\x1d\x1e'
    list_0 = [str_1, str_0]
    str_2 = '\x1e\x1d\x1e'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)


# Generated at 2022-06-25 07:56:59.318980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # a pytest style test.
    # for more info, see:
    # https://docs.pytest.org/en/latest/contents.html
    # https://docs.pytest.org/en/latest/assert.html
    # https://docs.pytest.org/en/latest/fixture.html
    # https://docs.pytest.org/en/latest/example/parametrize.html#parametrizing-test-methods
    # and for more on decorators, see:
    # https://docs.python.org/2/glossary.html#term-decorator
    import pytest
    pytest.main(['-q', 'test_action_module.py'])


# Generated at 2022-06-25 07:57:00.782080
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:57:04.631658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    # TODO: Figure out why this doesn't work.
    # tmp = None
    tmp = True
    task_vars = None
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:57:15.465295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    # assert action_module_0._task == str_0
    # assert action_module_0._connection == str_1
    # assert action_module_0._play_context == tuple_0
    # assert action_module_0._loader == list_0


# Generated at 2022-06-25 07:58:25.986056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
  str_1 = 'K$3s&o[+z!?k/um'
  list_0 = [str_1, str_1]
  str_2 = '1PWJ\x0b}V&>'
  bool_0 = False
  tuple_0 = (list_0, str_2, bool_0)
  action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
  var_0 = action_module_0.run()
  test_case_0(var_0)
  return var_0

# Generated at 2022-06-25 07:58:27.239316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We do not test this method
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:58:31.835939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = 'SjD<@H0Y.D\t'

# Generated at 2022-06-25 07:58:36.864602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#0`;xBk&\x0c#%\x0b'
    str_1 = '+Y=0v}L6%I8x{'

# Generated at 2022-06-25 07:58:42.267617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)
    # assert var_0 == expected
    # assert action_module_0.run == expected

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:58:50.773751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing a ActionModule object to test ActionModule.run
    str_0 = "str_0"
    str_1 = "str_1"
    tuple_0 = ("tuple_0", "tuple_0")
    list_0 = ["", "", ""]
    bool_0 = False
    list_1 = []
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_1)
    assert action_module_0._loader.__class__ == Loader
    assert action_module_0._action_loader is None
    assert action_module_0._shared_loader == False
    assert action_module_0._task is None
    assert action_module_0._task_vars is None
    assert action_module_0._play_context

# Generated at 2022-06-25 07:58:58.002201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
    list_1 = [str_1, str_1]
    var_0 = action_module_0.run(list_0, list_1)
    assert var_0 == list_1

if __name__ == '__main__':
    test_

# Generated at 2022-06-25 07:59:02.553314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
    str_1 = 'K$3s&o[+z!?k/um'
    list_0 = [str_1, str_1]
    str_2 = '1PWJ\x0b}V&>'
    bool_0 = False
    tuple_0 = (list_0, str_2, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)


# Generated at 2022-06-25 07:59:08.541924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#'
    str_1 = '\u0004'
    list_0 = [str_1, str_1]
    var_0 = ActionModule(str_0, str_1, list_0, list_0, False, list_0)
    var_0 = ActionModule(str_0, str_1, list_0, list_0, False, list_0)
    var_0 = ActionModule(str_0, str_1, list_0, list_0, False, list_0)


# Generated at 2022-06-25 07:59:14.304373
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'Validate collection integrity locally without contacting server for canonical manifest hash.'
  str_1 = 'K$3s&o[+z!?k/um'
  list_0 = [str_1, str_1]
  str_2 = '1PWJ\x0b}V&>'
  bool_0 = False
  tuple_0 = (list_0, str_2, bool_0)
  action_module_0 = ActionModule(str_0, str_1, tuple_0, list_0, bool_0, list_0)
  assert action_module_0.get_name() == 'Validate collection integrity locally without contacting server for canonical manifest hash.'
  assert action_module_0.get_connection() == 'K$3s&o[+z!?k/um'
  assert action_module