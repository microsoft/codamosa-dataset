

# Generated at 2022-06-25 07:52:12.838778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    dict_0 = {}
    int_1 = 1
    bytes_0 = b'\xaa'
    float_0 = 0.0
    action_module_0 = ActionModule(int_0, dict_0, int_1, bytes_0, float_0, bytes_0)
    action_module_0.run(bytes_0)

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:13.809134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:52:15.854635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run")

# Generated at 2022-06-25 07:52:16.509410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:52:18.130116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert False


# Generated at 2022-06-25 07:52:20.329751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Running test_ActionModule()')
    test_case_0()

if __name__ == '__main__':
    print('Running unit tests')
    test_ActionModule()

# Generated at 2022-06-25 07:52:21.213892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:52:29.666775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assigning value to variables for constructing class object
    int_0 = -1222
    dict_0 = {}
    int_1 = -3289
    bytes_0 = b'\x16XCz\x97\x12&\xfa\xaa\xd9\x0b\x0c\xdeU\xc9\x85\xadJQ\xb4'
    float_0 = 0.0
    action_module_0 = ActionModule(int_0, dict_0, int_1, bytes_0, float_0, bytes_0)
    test_case_0()
    print('Successful')


# Generated at 2022-06-25 07:52:38.035708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        action_module_1 = ActionModule()
    with pytest.raises(TypeError):
        action_module_2 = ActionModule(False)
    with pytest.raises(TypeError):
        action_module_3 = ActionModule(False, False)
    with pytest.raises(TypeError):
        action_module_4 = ActionModule(False, False, False)
    with pytest.raises(TypeError):
        action_module_5 = ActionModule(False, False, False, False)
    with pytest.raises(TypeError):
        action_module_6 = ActionModule(False, False, False, False, False)
    test_case_0()


# Generated at 2022-06-25 07:52:47.669618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0[0] = '\x0e\xf6\x12\xb8\x11\x80\x19\xd1\xa8H\xc2\x9a<\x14\xcd\xf8\xfb\xe1\xee\x90\xd1\x9b\x02\xa9\x88\x8d\x1c\xe2\x87\x18\xf8'

# Generated at 2022-06-25 07:52:57.354679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:52:58.446434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:52:59.999152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:53:03.310079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    print(result)


# Generated at 2022-06-25 07:53:06.830502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:12.363428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = 'test'
    dest = 'test2'
    remote_src = 'test3'
    creates = 'test4'
    decrypt = 'test5'
    action_module_0 = ActionModule()
    task_vars = {'test': 'test6', 'test2': 'test7'}
    result = action_module_0.run(None, task_vars)
    assert isinstance(result, dict)

# Generated at 2022-06-25 07:53:23.262392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for the class that tests the constructor of class ActionModule:
    class ConstructorTester(ActionModule):
        def __init__(self, config, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task_vars = None  # test initialization of instance variable
            self.tmp = None  # test initialization of instance variable
            super().__init__(config, task, connection, play_context, loader, templar, shared_loader_obj)
            # self._task.action = 'unarchive'  # action could not be set directly because it is a read-only member of the parent class
            # self._task.args = {'src': '~/.ansible/tmp/ansible-tmp-1467404048.79-142713120495623/source', 'dest':

# Generated at 2022-06-25 07:53:32.625868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test action_module_0.run()
    assert True == True

    action_module_0 = ActionModule()
    action_module_0._task = type('', (), {})()
    action_module_0._task.args = {"src": "/var/folders/7t/_2m4fh2x7z15xkx1w02t6xg200002h/T/tmp.pYpe20wh/source", "dest": "~/Desktop/ansible/examples/unarchive/dist", "remote_src": True, "decrypt": True, "creates": None}
    action_module_0._task.action = "unarchive"
    action_module_0._task.async_val = None
    action_module_0._task.loop = False

# Generated at 2022-06-25 07:53:35.756539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We test that the constructor of the action module can be created with no
    # problem.
    try:
        action_module_0 = ActionModule()
        return True
    except:
        return False


# Generated at 2022-06-25 07:53:40.225391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating an object of class ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:54.681941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 587.282
    int_0 = 1
    bool_0 = False
    str_0 = 'E4N7'
    dict_0 = {int_0: float_0, float_0: int_0, bool_0: float_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)


# Generated at 2022-06-25 07:53:55.884668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test ActionModule')
    test_case_0()

# Generated at 2022-06-25 07:54:07.983740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(action_module_0, ActionBase)
    assert not isinstance(action_module_0, AnsibleAction)
    assert not isinstance(action_module_0, AnsibleActionFail)
    assert not isinstance(action_module_0, AnsibleActionSkip)

# Generated at 2022-06-25 07:54:12.946217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 972.0
    int_0 = 32
    bool_0 = False
    str_0 = 'U$w6Wmok8Uv'
    dict_0 = {float_0: float_0, str_0: float_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:54:22.426719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        float_0 = 2659.0
        bool_0 = False
        int_0 = 65536
        list_0 = [float_0, 1, 3.0, '1', '3']
        str_0 = '1'
        dict_0 = {int_0: list_0, 'id': str_0, str_0: str_0}
        action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
        var_0 = action_module_0.run(str_0, list_0)
    except:
        print('1')
        raise


# Generated at 2022-06-25 07:54:25.878294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 07:54:27.681331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:54:39.185266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    assert action_module_0.action_module_0 == float_0
    assert action_module_0.action_module_0 == int_0
    assert action_module_0.action_module_0 == bool_0
    assert action_module_0.action_module_0 == str_0
    assert action_module_0.action_module_0 == dict_0
   

# Generated at 2022-06-25 07:54:45.952439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(module_args) is dict
    assert type(task_vars) is dict
    assert type(tmp) is str
    assert type(task_vars) is dict
    assert type(loader) is AnsibleLoader
    assert type(play_context) is PlayContext



# Generated at 2022-06-25 07:54:50.969985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3516.0
    int_0 = 131072
    bool_0 = True
    str_0 = 'Y_MkflB_tIR'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)

# Generated at 2022-06-25 07:55:16.534874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 22.1
    int_0 = -10
    bool_0 = False
    str_0 = 'I.\\_'
    dict_0 = {int_0: int_0, bool_0: bool_0, str_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    str_0 = 'QI6q3ou6-1'
    action_run(str_0)
    # Test the method with a variable from the local scope
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'

# Generated at 2022-06-25 07:55:18.493319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:55:25.639803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.3189814514160156
    int_0 = 128
    bool_0 = False
    str_0 = 'liaN_F_hN'
    dict_0 = {str_0: int_0, float_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)

# Generated at 2022-06-25 07:55:33.779728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)



# Generated at 2022-06-25 07:55:43.204306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        float_0 = 2659.0
        int_0 = 65536
        bool_0 = False
        str_0 = 'qqid7NJeK_Tb'
        dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
        action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
        test_case_0()
    except Exception as e:
        print (e)
        #assert False

#test_ActionModule()

# Generated at 2022-06-25 07:55:46.574437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:55:51.268560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)


# Generated at 2022-06-25 07:56:00.482236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    username = 'username'
    password = 'password'
    database = 'database'
    from_addr = 'from@example.com'
    to_addr_list = ['to@example.com']
    subject = 'subject'
    html_message = 'html message'
    smtp_server = 'smtp.example.com'

    # Check that function returns a value
    try:
        result = run(username, password, database, from_addr, to_addr_list, subject, html_message, smtp_server)
    except:
        assert False

    # Check that async does not return a value
    try:
        run(username, password, database, from_addr, to_addr_list, subject, html_message, smtp_server, True)
        assert False
    except:
        assert True

# Generated at 2022-06-25 07:56:06.820007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 =  'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)



# Generated at 2022-06-25 07:56:13.266095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2248.0
    int_0 = 196608
    bool_0 = False
    str_0 = 'z5Vu_S'
    dict_0 = {int_0: int_0, str_0: str_0, bool_0: str_0}
    dict_1 = {int_0: float_0, float_0: float_0, float_0: float_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_1)
    assert not action_module_0.run(float_0, int_0)


# Generated at 2022-06-25 07:56:52.231384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 358.0
    int_0 = 131072
    bool_0 = True
    str_0 = 'yQeOJiy-jW8u'
    dict_0 = {int_0: bool_0, bool_0: bool_0, float_0: bool_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:56:59.337003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import inspect
    import ansible.module_utils._text
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.errors import AnsibleError, AnsibleAction, AnsibleActionFail, AnsibleActionSkip
    from ansible.plugins.action import ActionBase

    float_0 = 5.043894044146907
    int_0 = 65536
    bool_0 = True
    str_0 = 'bbPfQQPdDxhX'
    dict_0 = {float_0: 'NEJgLmWY_', bool_0: int_0, int_0: bool_0}

# Generated at 2022-06-25 07:57:04.271619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:57:09.185350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3678.0
    int_0 = 65536
    bool_0 = True
    str_0 = 'xA8GJW'
    dict_0 = {float_0: float_0, int_0: float_0, str_0: str_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:57:14.745611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 85.3
    int_0 = 17
    bool_0 = False
    str_0 = 'R(lw1'
    dict_0 = {float_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    return action_module_0


# Generated at 2022-06-25 07:57:15.497849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 07:57:20.397214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 199.0
    int_0 = 23
    bool_0 = True
    str_0 = '>|3m'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_run(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:57:30.188869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_module_0.run(str_0, dict_0)
    assert var_0 == False


# Generated at 2022-06-25 07:57:38.393937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:57:45.800512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.unarchive'
    module_args = 'src='
    src = dict_0
    dest = 'copy='
    copy = var_0
    remote_src = int_0
    creates = 'isdir='
    isdir = int_0
    decrypt = str_0
    tmp = dict_0
    task_vars = dict_0

    action_module_0 = ActionModule(module_name, module_args, src, dest, copy, remote_src, creates, isdir, decrypt, tmp, task_vars)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:59:02.253808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 8922.0
    int_0 = 65536
    bool_0 = False
    str_0 = '3q_2Vf1xA6yMY'
    dict_0 = {str_0: int_0, int_0: boolean(float_0, str_0), bool_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:59:10.750459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 9077.0
    int_0 = 65536
    bool_0 = True
    str_0 = 'yWxxlF'
    dict_0 = {float_0: bool_0, bool_0: bool_0, int_0: bool_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    float_0 = float()
    float_1 = float()
    float_2 = float_1 - float_0
    float_1 = float()
    float_2 = float_0 + float_1
    float_1 = float()
    float_2 = float_1 - float_0
    float_2 = float()
    float_1 = float_0 + float_2
    float

# Generated at 2022-06-25 07:59:14.760389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule(1, 2, 3, 4, 5, 6) == None)


# Generated at 2022-06-25 07:59:23.653712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    assert repr(action_module_0) == "<ansible.plugins.action.ActionModule object at 0x7f7e115813d0>"
    assert str(action_module_0) == "ActionModule"
    assert action_module_0.run("5.5") == {'msg': '5.5', 'changed': False, 'failed': False}
    assert action_

# Generated at 2022-06-25 07:59:29.555243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 32.0
    int_0 = 16
    bool_0 = True
    str_0 = 'SbPhptquFk'
    dict_0 = {bool_0: int_0, int_0: int_0, float_0: str_0}
    dict_1 = {bool_0: int_0, int_0: int_0, float_0: str_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_1)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:59:37.725653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 508
    bool_0 = True
    str_0 = 'C4xF'
    dict_0 = {int_0: int_0, bool_0: str_0, str_0: str_0}
    action_module_0 = ActionModule(dict_0, dict_0, dict_0, int_0, int_0, float_0)
    float_0 = 2096.0
    float_1 = action_module_0.run(int_0, float_0)
    assert isinstance(float_1, float)
    assert float_1 == 2096


# Generated at 2022-06-25 07:59:39.841315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    var_0.update(var_0)

# Generated at 2022-06-25 07:59:48.586270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test test_ActionModule()")
    try:
        float_0 = 2659.0
        int_0 = 65536
        bool_0 = False
        str_0 = 'qqid7NJeK_Tb'
        dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
        action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    except Exception as e:
        print("ActionModule() Exception: ", e)
        print("Test test_ActionModule() Failed")
        return
    print("Test test_ActionModule() Passed")


# Generated at 2022-06-25 07:59:52.665091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3007.0
    int_0 = 65536
    bool_0 = True
    str_0 = 'eZJ.tT'
    dict_0 = {int_0: float_0, float_0: float_0, str_0: float_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)


# Generated at 2022-06-25 08:00:02.843572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2659.0
    int_0 = 65536
    bool_0 = False
    str_0 = 'qqid7NJeK_Tb'
    dict_0 = {float_0: int_0, bool_0: float_0, int_0: int_0}
    action_module_0 = ActionModule(float_0, int_0, bool_0, str_0, dict_0, dict_0)
    assert action_module_0._display is not None
    assert action_module_0._task is not None
    assert action_module_0._connection is not None
    assert action_module_0._loader is not None
    assert action_module_0._templar is not None
    assert action_module_0._shared_loader_obj is not None
    assert action_module_0