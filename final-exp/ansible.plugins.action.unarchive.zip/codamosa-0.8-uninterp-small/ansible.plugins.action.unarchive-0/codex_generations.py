

# Generated at 2022-06-25 07:52:14.329760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.environ['_ANSIBLE_SOURCE_DATE_EPOCH'] = "undefined"
    # test_case_0
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:52:20.295414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*'
    list_0 = [str_0, str_0]
    int_0 = -13
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 07:52:26.229745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'm9Y'
    list_0 = ['k6E', 'k6E', 'k6E', 'k6E']
    int_0 = 3105
    bool_0 = False
    list_1 = list(range(3))
    action_module_0 = ActionModule(str_0, list_0, int_0, list_1, bool_0, int_0)
    test_case_0()
    assert(repr(action_module_0) == "<ActionModule (m9Y)>")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:37.001971
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #
    # This is a generic test of the run() method.
    #

    # Arrange
    str_0 = '|'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    str_1 = 'o8'
    str_2 = 'Jo'
    execute_remote_stat_0 = None
    task_vars_0 = {str_1: str_2, str_2: execute_remote_stat_0}

    # Act
    result = action_module_0.run(None, task_vars_0)

    # Assert

# Generated at 2022-06-25 07:52:45.457564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/home/ansible/ansible'
    list_0 = ['v#x', '/home/ansible/ansible', 'v#x', '/home/ansible/ansible']
    int_0 = 6914
    list_1 = ['v#x', '/home/ansible/ansible', '/home/ansible/ansible', '/home/ansible/ansible']
    bool_0 = True
    int_1 = 1873
    action_module_0 = ActionModule(str_0, list_0, int_0, list_1, bool_0, int_1)


# Generated at 2022-06-25 07:52:54.130005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2005
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    tmp_0 = 'tmp'
    task_vars_0 = action_module_0.run(tmp_0)


# Generated at 2022-06-25 07:53:01.546935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '5'
  list_0 = ['c']
  int_0 = 894
  bool_0 = True
  action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
  str_1 = 'l'
  dict_0 = {str_1: str_1}
  action_module_0.run(dict_0)
  action_module_0.run()


# Generated at 2022-06-25 07:53:02.370444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:53:15.817311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ':S'
    list_0 = []
    list_0.append('xT')
    list_0.append('DD')
    list_0.append("HG'")
    list_0.append("x'")
    list_0.append("!")
    list_0.append("z'")
    list_0.append('@2')
    list_0.append("kp'")
    list_0.append("O")
    list_0.append('mQ')
    list_0.append("Kr'")
    list_0.append("TT")
    list_0.append("'V")
    list_0.append('D')
    list_0.append("~iL'")
    list_0.append("61'")
    list_0.append

# Generated at 2022-06-25 07:53:17.760368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:53:29.665012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    print("test_ActionModule:")
    print("test_case_0:", action_module_0.run())
    print("test_case_1:", action_module_1.run())


# Generated at 2022-06-25 07:53:35.165432
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()
    arguments = {'dest': '/tmp/test', 'src': 'tmp/test.txt'}
    check_mode = [True, False]
    remote_src = [True, False]
    task_vars = {'ansible_verbosity': 1, 'ansible_check_mode': check_mode, 'remote_src': remote_src}
    task_vars['ansible_check_mode'] = '1' # This isn't really needed.

    try:
        with pytest.raises(AnsibleActionFail):
            action_module_1.run(tmp='', task_vars=task_vars)
    except AnsibleActionFail as e:
        assert 'src (or content) and dest are required' in str(e)


# Generated at 2022-06-25 07:53:39.737158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None

# Generated at 2022-06-25 07:53:45.280723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'ansible.legacy.unarchive'
    module_args = dict()
    module_args['src'] = 'test_src'  # str |  (required)
    #  - Path to archive file to unpack.  If remote_src=yes,
    # this must be a file on the target server. An absolute path,
    # relative to the target servers home directory or relative to
    # the playbook being executed.
    module_args['dest'] = 'test_dest'  # str |  (required)
    #  - Location to unpack the archive file.  An absolute path,
    # relative to the target servers home directory or relative to
    # the playbook being executed.
    module_args['original_basename'] = 'test_original_basename'  # str | This is used to tell the module where to un

# Generated at 2022-06-25 07:53:47.422193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 0: constructor")
    action_module_0 = ActionModule()
    print("Testing completed for constructor")


# Generated at 2022-06-25 07:53:50.341825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # TODO: add unit test
    #assert False
    #assert action_module_0.run() == None


# Generated at 2022-06-25 07:53:54.992447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # TEST CASE: ActionModule.run()
    try:
        # TEST: The following must pass.
        action_module_0.run()
    except Exception as e:
        # TEST: The following must fail
        assert False, e.message
    # No exception thrown, the test passes.

# Generated at 2022-06-25 07:53:56.418555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:54:02.517406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.set_args({'content': "string"})

# Generated at 2022-06-25 07:54:10.709384
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test 1
    task_args_1 = {u'dest': u'/tmp', u'src': u'files/test_dir'}
    host_1 = {'action': u'unarchive', 'parameters': {u'dest': u'/tmp', u'src': u'files/test_dir'}, 'port': 22}
    tmp_1 = None
    path_info_1 = {'path': '/home/dmartin/ansible/test/test/test_tasks/', 'original_basename': 'test_tasks', 'real_path': '/home/dmartin/ansible/test/test/test_tasks/', 'basename': 'test_tasks', 'original_path': '/home/dmartin/ansible/test/test/test_tasks/'}

# Generated at 2022-06-25 07:54:35.850748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(tmp=None, task_vars=None)
    #assert action_module_0.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 07:54:41.894657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    # test_class_instance(self):
    assert isinstance(action_module, ActionModule)
    # test_super_class(self):
    assert isinstance(action_module, ActionBase)

    # test_class_variables(self):
    assert action_module.TRANSFERS_FILES == True



# Generated at 2022-06-25 07:54:51.335215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(action_module_0, 'run'), "Class ActionModule does not have attribute 'run'"
    assert hasattr(action_module_0, '_execute_module'), "Class ActionModule does not have attribute '_execute_module'"
    assert hasattr(action_module_0, '_fixup_perms2'), "Class ActionModule does not have attribute '_fixup_perms2'"
    assert hasattr(action_module_0, '_find_needle'), "Class ActionModule does not have attribute '_find_needle'"
    assert hasattr(action_module_0, '_remote_file_exists'), "Class ActionModule does not have attribute '_remote_file_exists'"

# Generated at 2022-06-25 07:54:52.861505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "Transfers files to the remote server." == ActionModule.__doc__

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:55:01.418138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # 1. Create an object for class ActionModule
    action_module_0 = ActionModule()
    # 2. Verify the object is of type ActionModule
    assert isinstance(action_module_0, ActionModule)
    # 3. Verify the object has the attributes
    # TRANSFERS_FILES
    assert hasattr(action_module_0, "TRANSFERS_FILES")
    # run()
    assert hasattr(action_module_0, "run")


# Generated at 2022-06-25 07:55:03.215002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:55:08.279864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    action_module_0.run(
        task_vars=None,
        creates=None
    )

# Generated at 2022-06-25 07:55:10.044002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:55:12.693928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:55:14.466970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test the method run of class ActionModule"""
    action_module = ActionModule()

# Generated at 2022-06-25 07:55:40.806166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialization
    str_0 = 'p'
    list_0 = [str_0, str_0, str_0, str_0]
    list_1 = [str_0, str_0, str_0, str_0]
    int_0 = 9635
    int_1 = 2254
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_1, bool_0, int_1)
    # Test attribute 'connection'
    assert action_module_0.connection is None
    # Test attribute '_action'
    assert action_module_0._action == str_0
    # Test attribute '_task_vars'
    assert action_module_0._task_vars == list_1
    # Test attribute '_loader'


# Generated at 2022-06-25 07:55:47.001772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing the following case:
    # <src> = 'v#x'
    # <dest> = 'v#x'
    # <content> = 'v#x'
    # <copy> = True
    # <remote_src> = False
    # <creates> = 'v#x'
    # <copy_remote_src> = False
    # <directory_mode> = 'v#x'
    # <follow> = True
    # <content> = 'v#x'
    # <other_args> = 'v#x'
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True

# Generated at 2022-06-25 07:55:51.458328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule('src', ['creates'], 'remote_src', 'dest', 10000, 100)
    assert(obj.module_name == 'src' and obj.task_vars['creates'] == 'creates' and bool(obj.module_args.get('remote_src')) == True and obj.module_args.get('dest') == 'dest' and obj._task.async_val == 10000 and obj.task_timeout == 100)


# Generated at 2022-06-25 07:55:55.544109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3se'
    list_0 = None
    int_0 = -1338
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)


# Generated at 2022-06-25 07:56:01.733982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check method run of class ActionModule
    str_0 = 'F$|I'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    action_module_0.run()
    var_0 = action_module_0.run('n%u9', '{;')
    var_1 = action_module_0.run('=s')


# Generated at 2022-06-25 07:56:09.339457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:56:16.318502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '^'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 288
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)


# Generated at 2022-06-25 07:56:23.001265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'mD'
    list_0 = [str_0, str_0, str_0]
    int_0 = 5984
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    str_1 = '''<requests.packages.urllib3.connectionpool.HTTPConnectionPool object at 0x7f9a7a5c5d90>'''
    var_0 = action_run(str_1)

# Generated at 2022-06-25 07:56:24.489799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:56:29.297754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#'
    list_0 = ['p', '#', 'd', '#', 'x']
    int_0 = 29
    list_1 = ['6', '8', 'z', '#', '6', 'x']
    bool_0 = True
    int_1 = 29
    action_module_0 = ActionModule(str_0, list_0, int_0, list_1, bool_0, int_1)
    assert isinstance(action_module_0, ActionModule)
    try:
        result_eval = action_run('')
        assert result_eval == None
    except:
        raise RuntimeError("unexpected exception")
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:57:08.413689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 1
    str_0 = 'g'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 1664
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    str_1 = 'Variable expansion'
    var_0 = action_run(str_1)
    assert var_0 == 'Variable expansion'


# Generated at 2022-06-25 07:57:10.680963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Unit test for method ActionModule.run')


# Generated at 2022-06-25 07:57:17.527314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'XKB'
    list_0 = [str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:57:21.094858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Test Runner
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 07:57:30.221644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    source = None
    dest = None
    remote_src = None
    creates = None
    decrypt = None
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run(source, dest, remote_src, creates, decrypt)
    print('\nvar_0:')
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('\nDone.')

# Generated at 2022-06-25 07:57:41.606633
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate class wih arguments
    action_module_0 = ActionModule('default connection', ['username', 'password', 'port'], -30447, ['connection'], True, -20255)
    dict_0 = dict(src = 'src', dest = 'dest', creates = 'creates', decrypt = 'decrypt')
    dict_0 = {'src': 'src', 'dest': 'dest', 'creates': 'creates', 'decrypt': 'decrypt'}
    dict_1 = dict(src = 'src', dest = 'dest', creates = 'creates', decrypt = 'decrypt')
    dict_1 = {'src': 'src', 'dest': 'dest', 'creates': 'creates', 'decrypt': 'decrypt'}

# Generated at 2022-06-25 07:57:45.469658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:57:53.158466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor signature of class ActionModule
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:58:00.608252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    action_module_0.run(tmp, task_vars)


# Unit tests for class module_utils.parsing.convert_bool.boolean
# Tests for method boolean of class module_utils.parsing.convert_bool

# Generated at 2022-06-25 07:58:01.416148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:59:22.088208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    some_input = 'v#x'
    some_list = ['a', 'b', 'c']
    some_int = 2
    some_other_list = [0, 1, 2]
    some_bool = False
    some_other_int = 3
    test_module = ActionModule(some_input, some_list, some_int, some_other_list, some_bool, some_other_int)
    test_run = test_module.run()
    assert test_run == None

# Generated at 2022-06-25 07:59:27.097924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 07:59:34.599035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'v#x'
    str_1 = '-h'
    str_2 = '-h'
    str_3 = '-v'
    str_4 = '-h'
    action_module_0 = ActionModule(str_0, [str_2, str_4], 0, [str_0, str_1, str_3], False, 0)
    action_module_0.run()

# Generated at 2022-06-25 07:59:40.524088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = "test_ActionModule_run"
    expected = "test_ActionModule_run"
    result = test_ActionModule_run()
    assert result == expected, \
        "Incorrect Result, expected %s, got %s" % (expected, result)
    print("%s - Test Passed" % module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 07:59:47.181621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{'
    list_0 = [str_0]
    int_0 = 2897
    list_1 = [str_0, str_0, str_0, str_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_1, bool_0, int_0)
    var_0 = action_module_run(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 07:59:50.203630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = random_string(65)
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)


# Generated at 2022-06-25 07:59:54.449027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    assert action_module_0.TRANSFERS_FILES

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:59:58.502282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v#x'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 2704
    bool_0 = True
    # create instance of class ActionModule for testing
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, bool_0, int_0)
    # check whether instance is created successfully
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:59:59.519194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()


# Generated at 2022-06-25 08:00:10.158007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 'v#x'
    var_1 = ['v#x', 'v#x', 'v#x', 'v#x']
    var_2 = 2704
    var_3 = ['v#x', 'v#x', 'v#x', 'v#x']
    var_4 = True
    var_5 = 2704
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = action_module_0.get_connection()
    print(var_6)
    var_7 = 'x>Z51'