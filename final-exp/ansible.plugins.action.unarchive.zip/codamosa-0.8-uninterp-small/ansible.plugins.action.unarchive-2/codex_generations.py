

# Generated at 2022-06-25 07:52:15.628352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'foo': 'bar'}
    dict_1 = {'foo': 'bar'}
    params = {'args': {'creates': 'foo', 'dest': 'bar', 'src': 'foo'}}
    ansible_play_0 = ansible.playbook.Play()
    ansible_play_0._ds = dict_0
    ansible_task_0 = ansible.playbook.Task()
    ansible_task_0._ds = dict_1
    ansible.errors.AnsibleAction.AnsibleAction._task = ansible_task_0
    ansible_task_0.action = 'foo'
    ansible.errors.AnsibleAction.AnsibleAction.task = ansible_task_0
    ansible_task_0._parent = ansible_play_0

# Generated at 2022-06-25 07:52:17.792156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:52:18.798124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:52:23.535874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule) is True
    assert isinstance(action_module_0, ActionBase) is True
    assert isinstance(action_module_0.error, AnsibleAction) is True
    assert isinstance(action_module_0.fail, AnsibleActionFail) is True
    assert isinstance(action_module_0.skip, AnsibleActionSkip) is True
    assert action_module_0.__class__ is ActionModule
    assert action_module_0.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 07:52:29.854089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    vars_0 = {
        'dir': 'dir',
        'dir': 'dir'
    }
    string_2 = 'source'
    vars_1 = vars_0
    string_0 = 'ansible.legacy.unarchive'
    string_1 = 'dest'
    vars_4 = {
        'file': 'file',
        'file': 'file'
    }
    vars_2 = vars_4
    vars_3 = vars_1
    vars_5 = vars_3
    bytes_0 = b'\x90\x98f<\xab\xde\xf4\xe6h\xdb'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    float_0 = -1071.6546

# Generated at 2022-06-25 07:52:30.941720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_instance = ActionModule()
    action_module_instance.run()


# Generated at 2022-06-25 07:52:32.033864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:52:39.561329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case for an empty string
    bytes_0 = b'\x1f{\x1c\x89\x8f\xd9'
    test_case_0()

    # Test case for an integer
    bytes_1 = b'\xab\xb9\xbd!'

    # Test case for a floating point value
    bytes_2 = b'\xdd\xcd\xdb\x9eC\xd7\xf1'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_2, bytes_0, bytes_2, bytes_0, bytes_2]
    set_2 = {int_0}

    # Test case for a dict

# Generated at 2022-06-25 07:52:40.774051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    test_case_0()
    assert obj != None
    print('Tests Passed')


# Generated at 2022-06-25 07:52:47.916982
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bytes_2 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'

# Generated at 2022-06-25 07:53:01.202223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # Create an instance of ActionModule
    actionmodule = ActionModule(tmp, task_vars)

    # Perform some actions
    result = actionmodule.run(tmp, task_vars)

    # Check the result
    assert result[0] == 0

# Generated at 2022-06-25 07:53:04.865793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = "/path/to/source"
    dest = "/path/to/dest"
    remote_src = "remote_src"
    creates = "creates"
    decrypt = "decrypt"
    tmp = "tmp"
    task_vars = "task_vars"
    am = ActionModule()
    am.run(tmp, task_vars)

# Generated at 2022-06-25 07:53:07.293056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b'\xa8'.join('\t')
    bytes_0 = bytearray(16)
    bytes_0[19] = 4
    bytes_0[9] = 1


# Generated at 2022-06-25 07:53:16.694575
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:53:19.268506
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    host = 'localhost'

    values = None

    # Test return value of method run
    result = ActionModule.run(values, host)
    assert result == None


# Generated at 2022-06-25 07:53:21.557156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'


# Generated at 2022-06-25 07:53:24.020663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    variables = dict()
    assert None == action_module.run(task_vars=variables)

# Generated at 2022-06-25 07:53:32.987141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test case attempts to install a program using the Windows Package
    # module and the apt package manager. If you want to run it, change
    # 'decrypt' value to True.
    import ansible.plugins.action.unarchive as unarchive
    decrypt = False
    remote_src = False
    # decrypt = True
    # remote_src = True

    # For testing the 2nd part of the test.
    creates = 'C:\\'
    dest = 'C:\\'
    # For testing the 1st part of the test.
    # creates = 'C:\\Users\\Dylan\\Downloads\\ansible'
    # dest = 'C:\\Users\\Dylan\\Downloads\\ansible'

    # Create an instance of the ActionModule class.
    task = unarchive.ActionModule()

    # Declare the test values for

# Generated at 2022-06-25 07:53:38.960979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except NameError as e:
        print(e)

if __name__ == '__main__':
    # test code if executed as a script
    try:
        test_ActionModule()
    except NameError as e:
        print('Caught exception: {}'.format(e))

# Generated at 2022-06-25 07:53:42.720952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ast.literal_eval('foo')
    ansible_module_test = ActionModule()
    ast.literal_eval('foo')
    ansible_module_test = ActionModule()
    ast.literal_eval('foo')
    ansible_module_test = ActionModule()

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:54:09.737671
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:54:16.057448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    last_call_env = dict()
    last_call_args = dict()
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'
    dict_0 = dict()

    def last_call(*args, **kwargs):
        last_call_args.clear()
        last_call_args.update(kwargs)
        last_call_args.update(args[0].__dict__)
        return last_call_env[args[1]]

    last_call_env['_execute_module'] = lambda src, module_name, module_args=None, task_vars=None: dict_0

# Generated at 2022-06-25 07:54:22.716384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This example uses the constructor to create a new ActionModule.
    # The constructor requires parameters to be passed as a tuple.
    # This is because the number of parameters you pass is not known beforehand.
    # The added flexibility of this approach comes at the cost of
    # having to use a tuple to represent the parameters.
    action_module_0 = ActionModule((ActionBase,))


# Generated at 2022-06-25 07:54:23.739330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run()


# Generated at 2022-06-25 07:54:28.616256
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Constructor test
    module = ActionModule()

    # We need to mock the remote_user, becuase the tmp path is based on that
    setattr(module, '_play_context', type('MockedContext', (object,), {'remote_user': 'user'}))

    # test invocation of run() with arguments
    assert len(module.run({}, {})) == 0


# Generated at 2022-06-25 07:54:39.209555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test 1')
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'
    ActionModule()
    print('test 2')
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'
    ActionModule()
    print('test 3')
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'
    ActionModule()
    print('test 4')

# Generated at 2022-06-25 07:54:49.751578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x92V\r\xcd\xff\x8d\x0c\x9d\xb7\xbc\x0b\x0c\r\xa3\xca'
    bytes_1 = b"\x9c\t\x8f\xbdk\x16'\xe1\x07\xf8\xd7\x08\x1b\xe8\xdc\xe7\x98\xd2\xde\x00\x92\xda\xe5\xeb\xed\x9e]\x13z\xd5\x94\xa5x\xfe\xd9\xfa\xf8\xd8"
    bytes_2 = b'\x10\xa2\x0f'

# Generated at 2022-06-25 07:54:56.434563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 0
    tmp_0 = None
    task_vars_0 = None
    actionmodule_0 = ActionModule(self.task_0, self.connection_0, self.play_context_0, loader=self.loader_0, templar=self.templar_0, shared_loader_obj=None)
    # test case 1
    tmp_1 = None
    task_vars_1 = None
    actionmodule_1 = ActionModule(self.task_0, self.connection_0, self.play_context_0, loader=self.loader_0, templar=self.templar_0, shared_loader_obj=None)
    # test case 2
    tmp_2 = None
    task_vars_2 = None

# Generated at 2022-06-25 07:55:04.533089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    bytes_0 = b'\xae\xd4\xf7\t\xfa\x1c\x92\xda\xe5\xeb\xed\x9e]'
    print(bytes_0.decode('latin-1'))
    print('\u00ae\u00d4\u00f7\t\u00fa\u001c\u0092\u00da\u00e5\u00eb\u00ed\u009e]'.encode('latin-1').decode('utf-8'))

# Generated at 2022-06-25 07:55:07.027815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()


# Generated at 2022-06-25 07:55:47.565356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test when module argument is null
    module_args = dict()
    action_module = ActionModule(task=AnsibleTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test when module type is module_name, different action_plugin
    module_args = dict()
    module_args['src'] = 'a/b/c'
    action_module = ActionModule(task=AnsibleTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._execute_module = mock_execute_module
    action_module.ACTION_WARNINGS = None
    action_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:55:52.445691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init an instance of ActionModule
    action_module_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Assert the instance is not None
    assert action_module_instance is not None


# Generated at 2022-06-25 07:56:03.454107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = { 'creates': 'file.txt',
             'decrypt': 'true',
             'dest': 'test_dest',
             'remote_src': 'false',
             'src': 'test_src'}

# Generated at 2022-06-25 07:56:05.027574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:56:13.922672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args0 = {}
    args0['remote_src'] = False
    args0['src'] = 'test_value_3'
    args0['creates'] = 'test_value_4'
    args0['decrypt'] = True
    args0['dest'] = 'test_value_6'
    tmp0 = None
    task_vars0 = {}
    task_vars0['ansible_check_mode'] = False
    task_vars0['ansible_syntax_check'] = False
    task_vars0['ansible_diff_mode'] = False
    task_vars0['ansible_verbose_always'] = True
    task_vars0['ansible_inventory_sources'] = []
    task_vars0['ansible_module_name'] = 'synchronize'
    task

# Generated at 2022-06-25 07:56:14.852376
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:56:22.541137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args_0 = {
        'decrypt': True,
        'dest': '0xa6b',
        'src': '0x1b1c8'
    }
    task_args_1 = {
        'decrypt': True,
        'dest': '0xa6b',
        'src': '0x1b1c8'
    }
    task_args_2 = {
        'decrypt': True,
        'dest': '0xa6b',
        'src': '0x1b1c8'
    }
    task_args_3 = {
        'decrypt': True,
        'dest': '0xa6b',
        'src': '0x1b1c8'
    }

# Generated at 2022-06-25 07:56:29.711669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule.TRANSFERS_FILES = True
    a = 641
    b = 12
    c = 65536
    d = 65536
    e = 0
    f = 0
    g = 16
    h = 16
    i = 7
    j = 17
    k = 17
    l = 23
    m = 23
    n = 32768
    o = 32768
    p = 32768
    q = 32768
    r = 2097152
    s = 2097152
    t = 2097152
    u = 2097152
    v = 33554432
    w = 33554432
    x = 33554432
    y = 33554432
    z = 4227858432
    A = 50331648
    B = 268435456
    C = 2577730048


# Generated at 2022-06-25 07:56:34.821571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # uint test for method run with invalid parameters
    source = 'test'
    dest = 'test'
    remote_src = False
    creates = 'test'
    decrypt = True
    action_module_obj.run(source, dest, remote_src, creates, decrypt)

# Generated at 2022-06-25 07:56:43.471751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    # Test variables
    tmp_0 = {'test_var_0': 'test_value_0', 'test_var_1': 'test_value_1'}
    task_vars_0 = {'test_var_0': 'test_value_0', 'test_var_1': 'test_value_1'}
    # Test execution of method run
    ActionModule.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:57:24.061800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:57:32.122513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # New object for class ActionModule
    action_module_0 = ActionModule(tuple(), bytes(), str(), dict(), int(), str())
    # AssertionError: None != 0
    assert action_module_0 != 0
    # AssertionError: False != True
    assert action_module_0 != True
    # AssertionError: True != False
    assert action_module_0 != False
    # AssertionError: 0 != 0
    assert action_module_0 != 0
    # AssertionError: 'DummyValue' != 'DummyValue'
    assert action_module_0 != 'DummyValue'
    # AssertionError: 42 != 42
    assert action_module_0 != 42
    # AssertionError: 42 != 42
    assert not action_module_0 == 42
    # AssertionError

# Generated at 2022-06-25 07:57:41.416575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:57:49.784020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:57:55.498139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = 3 + 1j
    dict_0 = {'a': complex_0, 'b': complex_0, 'c': complex_0}
    bool_0 = False
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = '#C'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'N\x87\x9b\x97\xea\xb3\xc3P\xed\xb8l\x14\x87\x12\x9b\xcb\x04\xd2b'
    str_2 = '=I'
    int_0 = -96

# Generated at 2022-06-25 07:57:56.294545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:58:06.162248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:58:12.677407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_2 = None
    dict_2 = None
    bool_2 = True
    tuple_2 = (dict_2, dict_2, bool_2)
    str_11 = ':,'
    str_12 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_2 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_13 = 'RU'
    int_2 = -74
    str_14 = '(!`=7dp/?'
    action_module_3 = ActionModule(tuple_2, bytes_2, str_13, dict_2, int_2, str_14)

# Generated at 2022-06-25 07:58:22.764207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:58:31.313125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:59:57.838849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 07:59:59.244606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 08:00:08.558044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'

    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)
    assert not hasattr(action_module_0, 'b37a')

    action_module_1

# Generated at 2022-06-25 08:00:18.185302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 08:00:28.243446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)
    action_module_0._make_tmp_path = lambda: str_0
    action_module_

# Generated at 2022-06-25 08:00:28.887871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Generated at 2022-06-25 08:00:40.485021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 08:00:47.896720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)

# Generated at 2022-06-25 08:00:59.004404
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:01:08.623474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (dict_0, dict_0, bool_0)
    str_0 = ':,'
    str_1 = 'Attempt to extend a documentation fragement, invalid type for %s'
    bytes_0 = b'\xf2\xff<\x98\\\x0c\x99I\xe4EM\xcb\x16'
    str_2 = 'RU'
    int_0 = -74
    str_3 = '(!`=7dp/?'
    action_module_0 = ActionModule(tuple_0, bytes_0, str_2, dict_0, int_0, str_3)