

# Generated at 2022-06-25 07:52:09.616261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    boolean("true")
    a = ActionModule("tmp", "task_vars")
    assert isinstance(a, ActionModule)
    a.run("tmp")


# Generated at 2022-06-25 07:52:12.550551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "AnsibleError" in str(test_case_0)

# Generated at 2022-06-25 07:52:23.006835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    dict_0 = collections.OrderedDict()
    dict_1 = collections.OrderedDict()
    set_0 = {dict_0, dict_1}
    set_1 = {str_0, dict_0, set_0, dict_1}
    str_1 = "dN$_X;G\x0e\x1c:S\x0cc\x13\x12]e\x19x\x0c\x16\x1b"
    str_2 = "(<H'\x0c\x0cZ\x17,\x1a\x0f"

# Generated at 2022-06-25 07:52:29.540459
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:52:38.530233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:52:43.713319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    str_0 = "qfgJQs=t<-,\x0bt'l(+\x0bm"
    set_0 = {tuple_0, str_0}
    set_1 = {str_0, dict_0, set_0}
    tuple_1 = ()
    dict_1 = {tuple_1: tuple_1, tuple_1: tuple_1, tuple_1: tuple_1}
    str_1 = "t,s>%V+j\x0b7\x0b8uwj+H\x0bh"
    set_2 = {set_0, tuple_1, dict_1, str_0}

# Generated at 2022-06-25 07:52:51.789938
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of the class ActionModule
    test_obj = ActionModule()

    # Run test for object test_obj
    test_case_0()

    # Unit test for method _check_conditions
    obj_class = test_obj._check_conditions()
    assert isinstance(obj_class, AnsibleActionSkip) is True

    # Unit test for method _check_mode
    obj_class = test_obj._check_mode()
    assert isinstance(obj_class, AnsibleActionSkip) is True

    # Unit test for method _checksum_remote_src
    obj_class = test_obj._checksum_remote_src()
    assert isinstance(obj_class, AnsibleActionFail) is True

    # Unit test for method _diff_remote_src
    obj_class = test_obj._diff_remote_src

# Generated at 2022-06-25 07:53:02.600910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    try:
        tmp = None
        task_vars = None
        try:
            assert action_module_0.run(tmp, task_vars) is None
        except AnsibleActionFail as e:
            assert e.result['msg'] == "src (or content) and dest are required"
        else:
            assert False
        try:
            assert action_module_0.run(tmp, task_vars) is None
        except AnsibleActionFail as e:
            assert e.result['msg'] == "src (or content) and dest are required"
        else:
            assert False
    except:
        assert False
    tmp_1 = None

# Generated at 2022-06-25 07:53:05.778499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'item': 'default value'}
    action_module_0 = ActionModule(task=task_vars, connection=task_vars, play_context=task_vars, loader=task_vars, templar=task_vars, shared_loader_obj=task_vars)


# Generated at 2022-06-25 07:53:09.443794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    param_0 = ActionModule()
    assert param_0._task == param_0._task
    assert param_0._connection == param_0._connection
    assert param_0._play_context == param_0._play_context
    assert param_0._loader == param_0._loader
    assert param_0._templar == param_0._templar
    assert param_0._shared_loader_obj == param_0._shared_loader_obj


# Generated at 2022-06-25 07:53:21.060644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:53:31.033590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    action_module_0.run()

    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)
    action_module_1.run()

    # CCTODO: Fix test data: test_case_0_test_case_0_test_case_0_test_case_0_test_case_0_test_case_0_test_case_0
    #tmp_0 = test_case_0_test_case_0_test_case_0_test_case_0_test_case_0_test_case_0_test_case_0.test_case_0_test_case_0_test_case_0_test_case_0_test_

# Generated at 2022-06-25 07:53:36.371514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    state, result = action_module.run({}, {})

    assert state is None
    assert result == {}


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:41.466921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()
    assert obj_ActionModule is not None


# Generated at 2022-06-25 07:53:42.170068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:53:46.179758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    assert action_module_0.run() == None
    assert action_module_1.run() == None


# Generated at 2022-06-25 07:53:48.430441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:53:49.924134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:53:58.327224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    tmp = None
    task_vars = {
        "any_errors_fatal": True,
        "ansible_check_mode": False,
        "ansible_verbosity": 2,
        "ansible_diff": True,
        "ansible_python_interpreter": "/usr/bin/python3",
        "ansible_host": "192.168.1.100",
        "ansible_user": "osboxes",
        "ansible_connection": "ssh",
        "ansible_ssh_pass": "osboxes.org"
    }

    result = action_module_0.run(tmp, task_vars)
    assert result["failed"] == False



# Generated at 2022-06-25 07:54:04.384121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = FakeActionModuleTask()
    action_module_0._task.args = {"dest": "./dest-test_ActionModule_run/", "src": "./src-test_ActionModule_run"}
    action_module_0.run()


# Generated at 2022-06-25 07:54:19.727004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:54:23.585704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    action_module_0.run()

# Generated at 2022-06-25 07:54:26.428796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case data
    args = "src"
    task_vars = "dest"

    # Test case execution
    result = ActionModule.run(args,task_vars)
    assert result == None

test_case_0()

# Generated at 2022-06-25 07:54:28.111718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:54:33.157360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()


# Generated at 2022-06-25 07:54:33.884881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:54:35.914586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        print('Testing constructor of class ActionModule')
        test_case_0()
        print('Constructor works correctly')
    except:
        print('Error during testing constructor of class ActionModule')


# Generated at 2022-06-25 07:54:47.154058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    list_0 = [int_0]
    float_0 = int_0
    float_1 = int_0
    float_2 = int_0
    float_3 = int_0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    assert action_module_0._task.args['src'] == float_3
    assert action_module_0._task.args['dest'] == int_0
    assert action_module_0._task.args['creates'] == list_0
    assert action_module_0._task.args['decrypt'] == float_2


# Generated at 2022-06-25 07:54:56.247015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    float_0 = -0
    int_0 = 0
    float_1 = 0.0
    float_2 = 0.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_module_0.run()
    assert var_0 == {}, "test_ActionModule_run case failed\n."

# Generated at 2022-06-25 07:55:02.955751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instance of class ActionModule
    action_module_0 = ActionModule()
    # Tests for a case where the ActionModule class' has a method that takes 5 parameters
    # (list_0, float_0, int_0, float_1, list_0, float_2)
    pass
    # Tests for a case where the ActionModule class' has a method that takes 1 parameters
    # (tmp)
    pass
    # Tests for a case where the ActionModule class' has a method that takes 2 parameters
    # (tmp, task_vars)
    pass

# Generated at 2022-06-25 07:55:26.572278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setup()
    try:
        test_case_0()
    except:
        raise
    finally:
        teardown()

test_result_10 = 0
test_result_11 = 0
test_result_12 = 0
test_result_13 = 0
test_result_14 = 0
test_result_15 = 0
test_result_16 = 0
test_result_17 = 0
test_result_18 = 0
test_result_19 = 0
test_result_20 = 0
test_result_21 = 0
test_result_22 = 0
test_result_23 = 0
test_result_24 = 0
test_result_25 = 0
test_result_26 = 0
test_result_27 = 0
test_result_28 = 0
test_result_29 = 0
test_result_30

# Generated at 2022-06-25 07:55:34.876215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 851.8
    float_1 = 0.95
    float_2 = 35.56
    list_0 = [float_0, float_2, float_2]
    float_3 = 0.3
    float_4 = -265.0
    float_5 = -11.0
    dict_0 = {
        'dest': float_5,
        'remote_src': float_3,
        'content': float_3,
        'src': float_2,
        'creates': float_4,
        'copy': float_4}

# Generated at 2022-06-25 07:55:36.522862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False


# Generated at 2022-06-25 07:55:42.522740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 270
    list_0 = [int_0]
    float_0 = -1000.56
    float_1 = -1880.83
    float_2 = -1173.13
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:55:45.562622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:47.813460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dest = None
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:55:54.010032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [2, 3]
    float_0 = 7.58
    int_0 = 5
    float_1 = 8.16
    list_1 = [float_1, int_0]
    float_2 = 7.98
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_1, float_2)


# Generated at 2022-06-25 07:55:55.281449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print (action_module_0)

# Generated at 2022-06-25 07:56:02.979672
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:56:11.964183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = 'src'
    arg_1 = 'dest'
    arg_2 = 'remote_src'
    arg_3 = 'creates'
    arg_4 = 'decrypt'
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, list_0, float_0, int_0, float_1, list_0, float_2)
    instance_0 = action_module_0.run()
    assert instance_0 is not None


# Generated at 2022-06-25 07:56:48.019259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule class...")
    assert callable(ActionModule)
    print("ActionModule class created successfully")


# Generated at 2022-06-25 07:56:57.211505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_module_0.run()
    pass


# Generated at 2022-06-25 07:57:03.199011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    # Expected output:
    #      <class 'ansible.plugins.action.ActionModule'>
    print(action_module_0.__class__)
    # Expected output:
    #      <class 'ansible.module_utils.basic.AnsibleModule'>
    print(action_module_0._task.args.__class__)
    action_module_0.run()


# Generated at 2022-06-25 07:57:05.038346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run')

    # TEST CASE: Running run yields correct result
    test_case_0()

# Generated at 2022-06-25 07:57:07.452020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:57:10.486446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception as e:
        print("Failed to create ActionModule object: {}".format(e))


# Generated at 2022-06-25 07:57:12.276666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()
    assert obj_ActionModule.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 07:57:17.897206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:57:23.253827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [623.0]
    float_0 = -920.03
    int_0 = 0
    float_1 = -0.21
    var_0 = ActionModule(list_0, float_0, int_0, float_1)


# Generated at 2022-06-25 07:57:29.339950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    # Should not fail
    test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:58:45.817366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()


# Generated at 2022-06-25 07:58:53.404929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:58:59.622020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    float_0 = -11.88167
    int_0 = -1582
    float_1 = 0.75
    int_1 = 12
    float_2 = -1117.45
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    assert (action_module_0._task.args.get('src') == None)
    assert (action_module_0._task.args.get('_ansible_no_log') == None)
    assert (action_module_0._task.args.get('dest') == None)
    assert (action_module_0._task.args.get('remote_src') == False)

# Generated at 2022-06-25 07:59:03.520654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    float_0 = -3.0
    int_0 = 1024
    float_1 = -1.0
    float_2 = 0.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    # code to execute
    # End of test case

# Generated at 2022-06-25 07:59:10.585744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    list_1 = ['a', 'b']
    action_module_0.run(tmp=list_1)

# Generated at 2022-06-25 07:59:13.599206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1
    list_0 = [int_0]
    float_0 = 2.0
    float_1 = 3.0
    float_2 = 4.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    return

# Generated at 2022-06-25 07:59:23.199935
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    try:
        action_module_0 = ActionModule('7')
        str_0 = action_module_0.run()
    except Exception as e:
        print(e)

    try:
        action_module_0 = ActionModule('7')
        str_0 = action_module_0.run()
    except Exception as e:
        print(e)

    try:
        action_module_0 = ActionModule('7')
        str_0 = action_module_0.run()
    except Exception as e:
        print(e)

    try:
        action_module_0 = ActionModule('7')
        str_0 = action_module_0.run()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 07:59:24.429835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    print(result)

# Generated at 2022-06-25 07:59:25.879568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Starting test_ActionModule...')
    test_case_0()
    print('Ending test_ActionModule...')

# Generated at 2022-06-25 07:59:30.941396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 852
    list_0 = [int_0]
    float_0 = -127.63
    float_1 = -1815.9108
    float_2 = -157.0
    action_module_0 = ActionModule(list_0, float_0, int_0, float_1, list_0, float_2)
    var_0 = action_module_0.run()

