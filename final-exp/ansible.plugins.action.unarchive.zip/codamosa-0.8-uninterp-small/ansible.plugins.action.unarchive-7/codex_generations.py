

# Generated at 2022-06-25 07:52:15.111863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#\x18\xed\x8c\xd0\xa6\x87\xf9\x9d\xdb\x10\x07'
    float_0 = 0.0
    str_1 = '4|B-9\x01\x0b\x1a\x12\x1a\x1d\n'
    float_0 = 0.0
    int_0 = 1
    bytes_0 = b'\xec\xa1\xc7\x9b\x0b\x18C'
    action_module_0 = ActionModule(str_0, float_0, str_1, float_0, int_0, bytes_0)

# Generated at 2022-06-25 07:52:23.064432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'AHV'
    float_0 = 0.0
    str_1 = 'QI\x0cLhO^n*`Y0!2&z'
    int_0 = 535
    bytes_0 = b'\xde\x8f\xc4.h\x1fT'
    action_module_0 = ActionModule(str_0, float_0, str_1, float_0, int_0, bytes_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result == {'changed': False, 'msg': ''}
    return result


# Generated at 2022-06-25 07:52:35.915534
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:52:37.128386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return


# Generated at 2022-06-25 07:52:41.251215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:42.569273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:52:50.349466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'qui\x02\\\x0f'
    float_0 = 5.5
    str_1 = 'C>|jq\x1b'
    int_0 = 39
    bytes_0 = b'\x10\xaf\x18\x12\xdb\xc2\x18\x1d\xd0\xf9\x1f\x19'
    action_module_0 = ActionModule(str_0, float_0, str_1, float_0, int_0, bytes_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:53:00.008980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'AHV'
    float_0 = 0.0
    str_1 = 'QI\x0cLhO^n*`Y0!2&z'
    int_0 = 535
    bytes_0 = b'\xde\x8f\xc4.h\x1fT'
    action_module_0 = ActionModule(str_0, float_0, str_1, float_0, int_0, bytes_0)
    action_module_0._execute_module()
    action_module_0._transfer_file()
    action_module_0._remote_expand_user()
    action_module_0._execute_remote_stat()
    action_module_0._find_needle()
    action_module_0._fixup_perms2()
    action_

# Generated at 2022-06-25 07:53:01.099057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:05.778212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'D'
    float_0 = 0.0
    str_1 = '\xb9\x8f\x1d\xdfw`\x0e\x8b\xde\xe5G\x9c'
    int_0 = 2
    bytes_0 = '\\'
    action_module_0 = ActionModule(str_0, float_0, str_1, float_0, int_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:53:24.499198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test values
    #
    # __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    # run(self, tmp=None, task_vars=None)
    test_args = {"src": "src", "dest": "dest", "remote_src": False, "creates": "creates", "decrypt": True}
    test_tmp = None

# Generated at 2022-06-25 07:53:25.707291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0.run(), dict)


# Generated at 2022-06-25 07:53:26.807881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:53:27.924219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:29.513116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:53:32.653600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule with
    action_module_instance = ActionModule()

    # Arrange:
    tmp = None
    task_vars = None

    # Action:
    result = action_module_instance.run(tmp, task_vars)

    # Assert:
    assert result is not None



# Generated at 2022-06-25 07:53:35.811455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing with bad parameters
    try:
        action_module_0 = ActionModule()
        action_module_0.run(tmp=None)
    except Exception as e:
        print(e)
        assert type(e) == TypeError
    # Testing with good parameters
    action_module_0 = ActionModule()
    action_module_0.run(tmp='tmp', task_vars='task_vars')
    
if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Test Finished Successfully')

# Generated at 2022-06-25 07:53:40.860744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_name = "ActionModule"
    class_instance = ActionModule()
    assert class_name == class_instance.__class__.__name__


# Generated at 2022-06-25 07:53:43.374503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:53:46.830835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test: constructor of class ActionModule')
    action_module_0 = ActionModule()
    print('End of test')

action_module_0 = ActionModule()
action_module_1 = ActionModule()


# Generated at 2022-06-25 07:54:04.947939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    str_1 = '--json'
    bool_1 = False
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_1, bool_1, float_0)
    str_2 = "src (or content) and dest are required"
    try:
        action_module_0.run()
    except AnsibleActionFail as e:
        assert e.result['msg'] == str_2


# Generated at 2022-06-25 07:54:09.241448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3
    bool_0 = True
    str_0 = '--json'
    float_0 = 4.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)

    var_0 = action_module_0.run()

    var_1 = action_run()



# Generated at 2022-06-25 07:54:13.182754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        raise AnsibleActionFail(None)
    except AnsibleActionFail:
        pass

if __name__ == '__main__':
    test_ActionModule_run()
#    test_case_0()

# Generated at 2022-06-25 07:54:22.043307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        int_0 = 775
        bool_0 = False
        str_0 = '--json'
        float_0 = 1.0
        action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
        action_module_0.run()
    except AnsibleAction as e:
        pass

    # Verify exception was thrown for the above method.
    assert(e.type == AnsibleAction)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:25.851705
# Unit test for method run of class ActionModule
def test_ActionModule_run():


    return


# Generated at 2022-06-25 07:54:31.010108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test: action_run
    """

    # Test with 'int' type.
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    str_1 = ''
    bool_1 = False
    float_0 = 1.0
    action_module = ActionModule(int_0, bool_0, str_0, str_1, bool_1, float_0)
    assert isinstance(action_module.run(), object)

# Generated at 2022-06-25 07:54:36.390823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 07:54:39.594588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:48.764444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run(str_0, dict())
    try:
        var_1 = action_module_0.run(str_0, dict())
    except TypeError as e:
        print("TypeError: ", e)
    except ValueError as e:
        print("ValueError: ", e)
    except Exception as e:
        print("Exception: ", e)

# Generated at 2022-06-25 07:54:51.990508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:55:13.968748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run()
    # AssertionError - Failed Assertion: (0,)==(1,)
    assert (0,) == (1,)


# Generated at 2022-06-25 07:55:20.288736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)


# Generated at 2022-06-25 07:55:23.958690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run()
    return var_0


# Generated at 2022-06-25 07:55:35.278565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Constructor'''

    # Parameterized constructor test
    '''Constructor with parameters'''
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    '''Check type'''
    assert isinstance(action_module_0, ActionModule)
    '''Test initialized values for parameters'''

# Generated at 2022-06-25 07:55:42.793079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run()
    print(str(var_0))

if __name__ == 'main':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:55:53.657734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)

# Generated at 2022-06-25 07:55:58.759085
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:56:05.254144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 2.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    task_vars_0 = dict()
    var_1 = action_module_0.run(str_0, task_vars_0)



# Generated at 2022-06-25 07:56:08.019664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:56:12.002862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_1 = 775
    t_2 = False
    t_3 = '--json'
    t_4 = '--json'
    t_5 = False
    t_6 = 1.0
    action_module_0 = ActionModule(t_1, t_2, t_3, t_4, t_5, t_6)

# check run()

# Generated at 2022-06-25 07:56:50.641209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    action_run()


# Generated at 2022-06-25 07:56:57.080517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_run()
    assert var_0 == "ActionModule.run is completed"

# Generated at 2022-06-25 07:56:58.423772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:57:02.051269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 43
    bool_0 = False
    str_0 = '3.6'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:57:08.815893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_2 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)

    try:
        action_module_2.run()
        assert True, "Exception not raised"
    except Exception as e:
        assert False, "No exception should be raised"
    except TypeError as e:
        assert True, "Exception type should be TypeError"
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-25 07:57:13.620541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare arguments and variables
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:57:18.434151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test the method run of class ActionModule")
    int_0 = 775
    bool_0 = False
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:57:20.517570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method_call = """
test_case_0()
"""
    with patch(module_name + action_run, return_value=int_0) as mock_method:
        assert action_run() == int_0
        assert mock_method.called

# Generated at 2022-06-25 07:57:24.364819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:57:32.183888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# python 3.5
# from ansible.module_utils.six.moves import builtins
# from ansible.errors import AnsibleError, AnsibleAction, AnsibleActionFail, AnsibleActionSkip
# from ansible.module_utils._text import to_text
# from ansible.module_utils.parsing.convert_bool import boolean
# from ansible.plugins.action import ActionBase
#
#
# class ActionModule(ActionBase):
#
#     TRANSFERS_FILES = True
#
#     def run(self, tmp=None, task_vars=None):
#         ''' handler for unarchive operations '''
#         if task_vars is None:
#             task_vars = dict()
#


# Generated at 2022-06-25 07:58:50.414804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:58:55.306097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(740, True, 'h', 'q', False, 0.7052309453435667)
    assert action_module_0
    assert action_module_0.TRANSFERS_FILES


# Generated at 2022-06-25 07:58:55.758248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()

# Generated at 2022-06-25 07:58:56.437817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:59:00.811778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 200
    bool_0 = False
    str_0 = 'dummy'
    str_1 = 'dummy'
    bool_1 = False
    float_0 = 1.1
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_1, bool_1, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:59:05.482375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define parameters.
    tmp = None
    task_vars = None

    # Execute method.
    result = ActionModule.run(tmp, task_vars)
#

# Generated at 2022-06-25 07:59:12.321893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(1, True, "TEST_STRING_TODO", "TEST_STRING_TODO", True, 0.1)
    tmp = "TEST_STRING_TODO"
    task_vars = "TEST_STRING_TODO"
    try:
        var_0 = action_module_0.run(tmp, task_vars)
    except Exception as exception:
        print("Exception in setup code:")
        traceback.print_exc()
    else:
        result = "PASS"
    assert(result == "PASS")

# Generated at 2022-06-25 07:59:18.765367
# Unit test for constructor of class ActionModule
def test_ActionModule():

    int_0 = 188
    bool_0 = True
    str_0 = '--json'
    float_0 = 0.78
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)


# Generated at 2022-06-25 07:59:21.480636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0._task)
    print(action_module_0._connection)
    print(action_module_0._play_context)
    print(action_module_0._loader)
    print(action_module_0._templar)
    print(action_module_0._shared_loader_obj)
    print(action_module_0._task.args)


# Generated at 2022-06-25 07:59:28.676579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    bool_0 = True
    str_0 = '--json'
    float_0 = 1.0
    action_module_0 = ActionModule(int_0, bool_0, str_0, str_0, bool_0, float_0)
    var_0 = action_module_0.run(var_0, var_0)
    assert var_0 is not None

if __name__ == '__main__':
    test_case_0()