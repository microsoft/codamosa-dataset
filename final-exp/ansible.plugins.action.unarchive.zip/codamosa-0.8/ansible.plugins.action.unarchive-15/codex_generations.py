

# Generated at 2022-06-11 12:39:26.237527
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # pylint: disable=invalid-name

    # Setup mocks
    test_module = 'ansible.actions.archive'
    test_class = 'ActionModule'
    test_method = 'run'
    test_tmp = 'path/to/tmp'
    test_task_vars = {}

    # Build mocks
    p = patch('%s.ActionBase.run' % test_module, autospec=True)
    p.start()

    p = patch('%s.os.path.expanduser' % test_module, autospec=True)
    mock_expanduser = p.start()

    p = patch('%s.os.path.expanduser' % test_module, autospec=True)
    mock_expanduser = p.start()


# Generated at 2022-06-11 12:39:27.006635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:39:29.392911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({"src": "/home/user/test.tar.gz", "dest": "/home/user/test_dest"}, [], [], [])
    assert module.run()

# Generated at 2022-06-11 12:39:39.275165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_src = "/tmp/ansible-test/src"
    test_dest = "/tmp/ansible-test/dest"
    test_task_vars = { 
        "test_src": test_src,
        "test_dest": test_dest,
    }

    # Test ActionModule.run()
    action_module = ActionModule(
        task = dict(
            args = dict(
                src = test_src,
                dest = test_dest,
                remote_src = False,
                creates = None,
                decrypt = True,
            ),
        ),
    )
    

# Generated at 2022-06-11 12:39:45.670063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='unarchive', src='source', dest='dest')),
        connection=MockConnection(),
        play_context=dict(remote_user='user', become=False, become_method='su', become_user='root', check_mode=False),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)
    assert isinstance(module, ActionModule)

# class used to mock the connection class. See _execute_remote_stat()

# Generated at 2022-06-11 12:39:46.698531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-11 12:39:49.205306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")
    print("Actions:")
    print(ActionModule.__dict__['actions'])
    print("")

test_ActionModule()

# Generated at 2022-06-11 12:39:50.644640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an ActionModule object
    class ActionModule(object):
        pass

    # Test ActionModule.run()
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-11 12:39:52.149344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a simple test to ensure that the ActionModule class constructs successfully"""

    action_module = ActionModule()
    print("Successfully constructed ActionModule class object")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:39:54.819103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(ActionBase(), task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:40:04.059036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    p = ActionModule()
    p.run(tmp=True)

# Generated at 2022-06-11 12:40:05.133666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-11 12:40:13.468588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host


# Generated at 2022-06-11 12:40:24.988721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _tmp = '/tmp/ansible_unarchive_payload'
    _task_vars = dict(inventory_dir='/etc/ansible/')
    _task_args = dict(src='/etc/ansible/main.yml', dest='/tmp', remote_src=False)

    # With python mock package
    from unittest.mock import patch
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    am = ActionModule(_task_args, _task_vars)
    am.connection._shell.join_path = lambda d, p: '%s/%s' % (d, p)
    am.connection._shell.tmpdir = '/tmp'
    am.connection._shell.exists = lambda p: False

# Generated at 2022-06-11 12:40:27.681685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_test = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module_test

# Generated at 2022-06-11 12:40:30.107327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()

if (__name__ == '__main__'):
    test_ActionModule()

# Generated at 2022-06-11 12:40:41.006150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dm = {}
    am = ActionModule(dm, 'dummy', task_vars={})

    # test that it returns expected empty result
    assert am.run() == {}, "Expected {}, got {}".format(
        {},
        am.run()
    )

    # test that it returns expected result
    dm['_execute_module'] = lambda *args: {'msg': 'hello'}
    assert am.run() == {'msg': 'hello'}, "Expected {}, got {}".format(
        {'msg': 'hello'},
        am.run()
    )

    # test that it 'returns' an AnsibleSkipException
    dm['_execute_remote_stat'] = lambda *args: {'msg': 'hello'}

# Generated at 2022-06-11 12:40:48.670689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module = ActionModule()
    # Set up a Mock object to replace the base class AnsibleAction
    def __init__(self, *args, **kwargs):
        pass
    # Mock object
    action_module = MockAnsibleAction()
    setattr(action_module, 'run', run)
    setattr(action_module, '__init__', __init__)
    # Set up a Mock object to replace the remote_file_exists method
    def remote_file_exists(self, fn):
        return True
    setattr(action_module, '_remote_file_exists', remote_file_exists)
    # Set up a Mock object to replace the remote_expand_user method
    def remote_expand_user(self, path):
        return path

# Generated at 2022-06-11 12:40:58.516057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import pytest
    import sys

    test_dirs = []
    test_cases = []
    src = None
    dest = None
    remote_src = False
    remote_src_ = None

    # Set up test cases where the action will not run because the file is already present

# Generated at 2022-06-11 12:41:08.174733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test dict for class ActionModule
    test_run_dict = dict(
         src='/home/testuser/testDir'
        ,dest='/home/testuser/testDir'
        ,remote_src=True
        ,creates=None
        ,decrypt=True
    )
    # Test dict for function _remote_expand_user
    test__remote_expand_user_dict = dict()
    # Test dict for function _remote_file_exists
    test__remote_file_exists_dict = dict()
    # Test dict for function _find_needle
    test__find_needle_dict = dict()
    # Test dict for function _execute_remote_stat
    test__execute_remote_stat_dict = dict(
         all_vars=dict()
        ,follow=True
    )


# Generated at 2022-06-11 12:41:23.693442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:41:24.299491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule)

# Generated at 2022-06-11 12:41:26.449149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test object
    am = ActionModule()

    # TODO: Build test cases

# Unit tests for class ActionModule

# Generated at 2022-06-11 12:41:27.710200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('ActionModule', {}, {}, None)
    pass

# Generated at 2022-06-11 12:41:30.809127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    __import__('ansible.plugins.action.unarchive')
    mod = sys.modules['ansible.plugins.action.unarchive']
    assert hasattr(mod, 'ActionModule')
    assert callable(mod.ActionModule)


# Generated at 2022-06-11 12:41:31.541689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:41:40.981726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-11 12:41:51.553908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize parameters - source, dest, remote_src, and creates
    source = 'ansible.tar.gz'
    dest = 'python/ansible'
    remote_src = False
    creates = 'python/ansible/'
    # Initialize the object and instantiate the values
    action_module = ActionModule()
    action_module._task.args['src'] = source
    action_module._task.args['dest'] = dest
    action_module._task.args['remote_src'] = remote_src
    action_module._task.args['creates'] = creates
    # Unit test of the run method
    print("\tRunning unit test on run method of ActionModule class")
    action_module.run()
    print("\tUnit test for run method of ActionModule class completed\n")


# Generated at 2022-06-11 12:41:59.602224
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Used to set-up ansible.cfg file to run this test
    test_case_setup()

    test_obj = ActionModule()

    import sys
    param = None
    if sys.version_info[0] == 2:
        if sys.version_info[1] < 6:
            from ansible.module_utils.basic import AnsibleModule
            param = AnsibleModule
        else:
            from ansible.utils.module_docs import AnsibleModule
            param = AnsibleModule

    # Create a mock class for the action base
    class MockClass_ActionBase:
        pass

    # Create a mock class for the connection class
    class MockClass_Connection:
        class Shell:
            def join_path(self, path1, path2):
                path = path1 + '/' + path2
                return path

        _

# Generated at 2022-06-11 12:42:01.316202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule()
    assert AM is not None


# Generated at 2022-06-11 12:42:38.899336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task=testing.mock_Task()
    m_action_base=testing.mock_ActionBase()
    m_action_base.run=mock.Mock(return_value={})
    m_action_module=testing.mock_ActionModule(m_task, m_action_base)
    m_action_module.run(tmp='/var/tmp',task_vars={})
    m_action_base.run.assert_called_once_with('/var/tmp',{})

# Generated at 2022-06-11 12:42:42.941255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    try:
        module.run()
    except AnsibleAction as e:
        assert "src (or content) and dest are required" in e.result.get('msg', '')
        assert e.result['failed']


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:42:43.647229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test ActionModule._execute_module()
    assert True == True

# Generated at 2022-06-11 12:42:44.180777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test is not None

# Generated at 2022-06-11 12:42:51.036904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import shutil
    from ansible.parsing.vault import VaultLib # This is imported to prevent a circular import.
    from ansible.plugins.action.unarchive import ActionModule

    # Create a sandbox directory to work in
    with tempfile.TemporaryDirectory() as sandbox:
        sandbox_tmp = os.path.join(sandbox, "tmp")
        sandbox_files = os.path.join(sandbox, "files")
        sandbox_vars = os.path.join(sandbox, "vars.yaml")

        # Create the directory structure
        os.mkdir(sandbox_tmp)
        os.mkdir(sandbox_files)

        # Create a password file for vault.
        vault_password_file = os.path.join(sandbox, "vault_password")
        open

# Generated at 2022-06-11 12:42:51.605228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:52.424874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-11 12:42:53.168557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:43:01.985265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    import shutil

    fake_loader = os
    fake_task = os
    test_dir = tempfile.mkdtemp()

    test_instance = ActionModule(fake_loader, fake_task)

    # NOTE: _find_needle() searches a list of directories and
    #       returns the first matching file. This means it's
    #       not very easy to test against. We'll just write
    #       a fake file to the test directory and ensure
    #       it is returned by _find_needle().
    test_file = 'test'
    test_path = os.path.join(test_dir, test_file)
    open(test_path, 'a').close()

    test_result = test_instance._find_needle('files', test_file)

    assert test_path

# Generated at 2022-06-11 12:43:10.941609
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:44:16.846020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-11 12:44:17.312221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:18.729675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_name = 'ansible.legacy.unarchive'
    ActionModule(action_module_name)

# Generated at 2022-06-11 12:44:26.792719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with multiple arguments of ActionModule class
    import os
    from ansible.errors import AnsibleAction, AnsibleActionFail, AnsibleActionSkip
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.utils.display import Display
    display = Display()

    # Defined a return_value for a method os.path.expanduser in os.path module
    def  mock_expanduser_1(path):
        return "/home/dalton/"+path
    # Defined a return_value for a method get_real_file in class FileFinder in file finder.py module

# Generated at 2022-06-11 12:44:28.448837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simplest possible constructor
    action = ActionModule({}, {}, {}, {})
    assert action is not None
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:44:29.727894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ansible.builtin.copy' == ActionModule.__name__

# Generated at 2022-06-11 12:44:31.025646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "ActionModule.run() unit test not implemented"



# Generated at 2022-06-11 12:44:34.284040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__
    assert 'ansible.plugins.action.unarchive' == ActionModule.__module__
    assert 'unarchive' == ActionModule.DEFAULT_SUFFIX
    assert 1 == ActionModule.RETRYABLE_ERRORS
    assert 'unarchive' == ActionModule.action_type

# Generated at 2022-06-11 12:44:35.336982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("TODO: Write a unit test for ActionModule.run()")

# Generated at 2022-06-11 12:44:37.333385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a ActionModule object
    action_module = ActionModule(None, dict())

    # Check class variables
    assert action_module.TRANSFERS_FILES == True

# Generated at 2022-06-11 12:47:10.883671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:47:11.723878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a=ActionModule()


# Generated at 2022-06-11 12:47:19.016704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import add_all_plugin_dirs
    import ansible.plugins.action.unarchive

    # Load action plugin
    add_all_plugin_dirs()

    # Create ActionModule object
    module = ansible.plugins.action.unarchive.ActionModule()

    # Create a AnsibleTask object
    task = AnsibleTask()

    # Create a AnsibleVariableManager object
    varmanager = AnsibleVariableManager()

    # Create connection object
    connection = AnsibleConnection()

    # Load connection object into ActionModule
    module._load_connection_info(connection)

    # Load AnsibleTask object into ActionModule
    module._task = task

    # Load AnsibleVariableManager object into ActionModule
    module._variable_manager = varmanager

    module.run()


# Generated at 2022-06-11 12:47:19.637003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:47:20.424064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-11 12:47:27.872470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    user = 'simon'
    password = 'secret'
    # fake connection variables
    class FakeConnection:
        def __init__(self, run_module):
            self.run_module = run_module
            self.become = False
            self.become_method = 'sudo'
            self.become_user = user
            self.no_log = True

        def exec_command(self, cmd, tmp_path, sudoable=True, executable='/bin/sh'):
            return True, '', ''

        def put_file(self, in_path, out_path):
            return True

        def fetch_file(self, in_path, out_path):
            return True


# Generated at 2022-06-11 12:47:35.790227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running test_ActionModule_run()")
    # Run this test with: python test/test_ActionModule.py test_ActionModule_run
    class TestTask(object):
        def __init__(self, args):
            self.args = args
    class TestTaskVars(object):
        def __init__(self, task_vars):
            self.vars = task_vars
    input_vars = dict(content="testarchive.tar.bz2", dest="/tmp")
    # Note: task_vars is not actually used in this method.
    ttv = TestTaskVars(task_vars={"test": "testvars"})
    tt = TestTask(args=input_vars)
    am = ActionModule()
    am.run(tt, ttv)
    # Ensure that

# Generated at 2022-06-11 12:47:37.472916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test that evaluates the method: ActionModule.run '''
    print('No unit test implemented for: test_ActionModule_run')

# Generated at 2022-06-11 12:47:46.544554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tasks = [
        dict(
            action=dict(
                module='unarchive',
                args=dict(
                    src='/home/mdehaan/foo.tgz',
                    dest='/home/mdehaan',
                ),
            ),
        ),
        dict(
            action=dict(
                module='unarchive',
                args=dict(
                    content='YXNzaWJsZXVwbG9hZHVwbG9hZAo=',
                    dest='/home/mdehaan',
                    remote_src=True,
                ),
            ),
        ),
    ]

    task_vars = dict(
        ansible_user='ruser',
        ansible_ssh_host='sshhost',
    )


# Generated at 2022-06-11 12:47:54.467514
# Unit test for method run of class ActionModule