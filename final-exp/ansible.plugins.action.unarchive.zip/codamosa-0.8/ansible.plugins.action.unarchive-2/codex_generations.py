

# Generated at 2022-06-11 12:39:19.233370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check if ActionModule is mainly empty.
    assert ActionModule.run is not None, \
        "ActionModule.run cannot be empty"


# Generated at 2022-06-11 12:39:28.756883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys

    # Instantiation of class ActionModule

# Generated at 2022-06-11 12:39:36.014620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for class ActionModule is called during loading module.
    # The only way to execute tests is to use python at command line:
    # ansible-playbook ... --vault-password-file .vault_pass.txt
    # python -m test.units.modules.network.eos.test_eos_eapi
    #
    # Since there is no instance of class ActionModule, the following test
    # is useless and will be removed in the future.

    # Create instance of class ActionModule
    action = ActionModule()

    # Validate instance created
    assert action is not None

# Generated at 2022-06-11 12:39:45.325517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up a tmp folder that is the same as what would be called by the
    # existing constructor. This would be "/tmp/ansible_unarchive_payload"
    # We will test/assure that this folder is removed as part of the base
    # class tearDown method.
    tmp = "/tmp/ansible_unarchive_payload"

    # Create a mock ActionModule object by passing in the tmp folder.
    # We will then run a couple of tests to confirm that the
    # attributes and methods match what we expect for this class.
    c = ActionModule(task=dict(args=dict()), connection=dict(), tmp=tmp)

    # assert that tmp matches our tmp folder we created above.
    assert c.tmp == tmp

    # assert that the tmp folder has been created.
    # Note: The python API did not include this folder automatically

# Generated at 2022-06-11 12:39:54.043113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = None
    templar = None
    hostvars = dict()

    variable_manager.set_host_variable('localhost', hostvars)

    task = Task()
    task.set_loader(loader)
    task.variable_manager = variable_manager
    task._templar = templar

    action_module = ActionModule(task, connection=None, play_context=None)

    def run(self, tmp=None, task_vars=None):
        pass

    # Call run
    action_module.run = run
    action_module.run()

# Generated at 2022-06-11 12:40:04.880492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    t = Task()
    t.action = 'copy'
    t.args = {'src': '/etc/hosts', 'dest': '/tmp/hosts'}
    a = ActionModule(t, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)
    assert a is not None


# Generated at 2022-06-11 12:40:13.330192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Pass a bogus action module that raises a generic AnsibleAction skip,
    # and make sure that we get back a Failed message & the correct exception
    str_action = """
    - unarchive:
      src: /path/to/source
      dest: /path/to/dest
      copy: True
      creates: /path/to/file
    """
    action_results = {'failed': False, 'changed': False}
    fake_task = {'args': {}}
    fake_task_vars = {'ansible_check_mode': False}
    fake_self = {'_task': fake_task, '_find_needle': lambda x, y: '/path/to/dest', '_remove_tmp_path': lambda x: None}

# Generated at 2022-06-11 12:40:14.224249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:25.496037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a module object to pass to test methods.
    module = ActionModule()

    # Verify that the module does not allow mutually exclusive parameters.
    module._task.args = dict()
    module._task.args['copy'] = 'true'
    module._task.args['remote_src'] = 'true'
    try:
        result = module.run()
    except AnsibleActionFail as e:
        assert "parameters are mutually exclusive" in to_text(e)
    else:
        assert False, "Should have raised an exception"

    # Verify that the module requires src and dest.
    module._task.args = dict()
    try:
        result = module.run()
    except AnsibleActionFail as e:
        assert "src (or content) and dest are required" in to_text(e)

# Generated at 2022-06-11 12:40:26.106043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:40:36.369901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('mock', dict(src='mock', dest='mock', remote_src='mock'))
    assert action_module

# Generated at 2022-06-11 12:40:37.205857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:37.814176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:40:40.298722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:40:47.292181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.legacy.plugins.action.unarchive import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible_collections.ansible.community.plugins.module_utils.connection.connection_loader import load_connection_from_play_context
    from ansible_collections.ansible.community.plugins.loader import callback_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 12:40:57.230460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    # Create a copy of the playbook_data module_data that ActionModule._execute_module takes.

# Generated at 2022-06-11 12:41:06.945179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.role.include
    import ansible.playbook.include
    import ansible.playbook. role.task_include
    play_context = ansible.playbook.play.Play()
    loader = ansible.plugins.loader.action_loader
    shared_loader = ansible.plugins.loader.ActionModuleLoader(play_context, loader)
    connection_loader = ansible.plugins.loader.connection_loader
    connection = ansible.plugins.connection.ConnectionBase()
    action_base = ansible.plugins.action.ActionBase(play_context, shared_loader, connection_loader, connection)


# Generated at 2022-06-11 12:41:13.359931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = '/tmp/test_ansible'
    source = 'test_ansible.zip'
    src_dir = os.path.dirname(os.path.abspath(__file__))
    src_path = os.path.join(src_dir, source)
    test_argv = ['-m', 'unarchive', '--args={0} dest={1}'.format(src_path, dest)]
    module_mock = ActionModule({'ANSIBLE_MODULE_ARGS': test_argv})
    assert module_mock.run() is not None

# Generated at 2022-06-11 12:41:15.025817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("TODO: implement test")


# Generated at 2022-06-11 12:41:24.105720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task1 = dict(
        name = 'test_ActionModule_run',
        args = dict(
            src = 'test_ActionModule_run_source',
            dest = 'test_ActionModule_run_destination',
            creates = 'test_ActionModule_run_creates',
            decrypt = 'test_ActionModule_run_decrypt',
            copy = 'test_ActionModule_run_copy',
            remote_src = 'test_ActionModule_run_remote_src',
            other = 'test_ActionModule_run_other'
        ),
    )
    connection = mock_connection(task1, dict(module_name='mock_module'))
    task_vars = dict(
        mock_module = dict(
            changed = True,
            failed = False
        )
    )

# Generated at 2022-06-11 12:41:40.206513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule(None, None)
    return test_ActionModule

# Generated at 2022-06-11 12:41:41.580938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert type(module) == ActionModule

# Generated at 2022-06-11 12:41:52.150807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ################################################################################
    # Test setting the parameter copy to False.
    #
    # Expectation: No error should be raised.
    ################################################################################
    hostname = 'hostname'
    port = 22
    username = 'username'
    password = 'password'
    remote_path = '/home/user'
    remote_dir = 'dir'
    source = 'source'
    args = {
        'copy': False,
        'dest': remote_dir,
        'src': source
    }
    runner = create_mock_runner(hostname, port, username, password, remote_path, args=args)
    to_patch = [
        #'module_name',
        'module_args',
        'task_vars'
    ]

# Generated at 2022-06-11 12:41:59.962859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule for testing.
    am = ActionModule()
    # Create an instance of AnsibleModule for testing.
    ansible_module = AnsibleModule()
    am._task.args = dict(src='src', dest='dest')
    am._task.args.update(ansible_module)
    # Create a new AnsibleAction object to test.
    # It doesn't matter if it's AnsibleActionFail, AnsibleActionSkip or both.
    # This is implemented here to test the line `del aa` inside the finally.
    aa = AnsibleActionFail('')
    # The finally block should be ignored.
    am.run()
    # The finally block should be ignored.
    am.run(tmp='/tmp')
    # Test the finally block when ansible_module is not valid.

# Generated at 2022-06-11 12:42:00.474978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:42:11.498380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    import os
    import shutil
    import tempfile
    import pytest

    vault_pass = tempfile.NamedTemporaryFile()
    vault_pass.write(b"123")
    vault_pass.flush()

    temp_cwd = tempfile.mkdtemp()

    temp_src = tempfile.NamedTemporaryFile()
    temp_src.write(os.urandom(10))
    temp_src.flush()

    inventory = dict(
        all=dict(
            vars=dict()
        ),
        _meta=dict(
            hostvars=dict()
        )
    )

    variable_manager = VariableManager()
   

# Generated at 2022-06-11 12:42:13.196838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES, "Must return True."

# Generated at 2022-06-11 12:42:16.654071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test for method run of class ActionModule')
    a = ActionModule()
    # Test 1
    '''
    Test the run method of class ActionModule with arguments: (tmp=None, task_vars=None).
    '''
    print('Test 1')

# Generated at 2022-06-11 12:42:23.681751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test intercepting of AnsibleActionSkip
    source = "file not in role directory"
    dest = "/tmp"
    remote_src = False
    creates = None
    decrypt = True
    module_args = {
        'src':source,
        'dest':dest,
        'remote_src': remote_src,
        'creates': creates,
        'decrypt': decrypt
    }
    task_vars = {}
    inject = {}
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_action_args = action.task_action_args(module_args, task_vars, inject=inject)
    assert task_action_args == module_args


# Generated at 2022-06-11 12:42:24.371069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:43:02.307722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {'src': 'test', 'dest': '/tmp/test'}
    task = {'args': data}

    # Test with both legacy and new style args
    tasks = [
        {'args': data},
        {'args': data, 'decrypt': 'yes'},
        {'args': data, 'decrypt': 'yes', 'task': task},
        {'args': data, 'decrypt': 'no', 'task': task},
    ]
    for task in tasks:
        a = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

        # not much to test here, the target class is tested well in the unarchive module
        # test that the constructor doesn't explode
        assert a is not None

# Generated at 2022-06-11 12:43:02.818441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0 == 1

# Generated at 2022-06-11 12:43:04.237138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('foo', 'bar', b_baz='froz', f_blarg=3.14)

# Generated at 2022-06-11 12:43:13.444543
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for the run method of ActionModule.
    # Test when everything goes fine.
    # This unit test is based on ansible2.8,
    # and because of that, it only contains the most basic code.
    #

    # Create the module object
    module = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={})

    # Create the test parameters
    tmp = None
    task_vars = {'inventory_hostname': 'localhost', 'group_names': ['all'], 'groups': {'all': ['localhost']},
                 'omit': '__omit_place_holder__1234567890'}
    module.noop_on_check(False)
    module.check_mode(False)

    # Call the method under test

# Generated at 2022-06-11 12:43:17.279560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module =  ActionModule(connection=None, 
        task_vars=dict(),
        loader=None, 
        templar=None, 
        shared_loader_obj=None)

    # TODO: write test
    pass

# Generated at 2022-06-11 12:43:26.432900
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test setting name of action
    action = ActionModule()
    assert(action._task.action == 'unarchive')

    # Test setting action's _attributes
    action = ActionModule()
    vars = {"ansible_connection": "winrm", "ansible_user": "User",
            "ansible_password": "Password", "ansible_port": 5986,
            "ansible_winrm_server_cert_validation": "ignore",
            "ansible_winrm_transport": ["kerberos", "certificate"]}
    action._add_action_attributes(vars)

    assert(action._connection._shell.DEFAULT_TRANSPORT == "winrm")
    assert(action._connection._shell.DEFAULT_USER == "User")

# Generated at 2022-06-11 12:43:27.009536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:43:34.110532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()
    task = "test_task"
    tmp = None
    task_vars = {}
    try:
        result = test_ActionModule.run(tmp=tmp, task_vars=task_vars)
        assert result is not None
    except Exception as e:
        assert "src (or content) and dest are required" in to_text(e)
    try:
        test_ActionModule.run(tmp=tmp, task_vars={'src':'src', 'dest':'dest'})
    except Exception as e:
        assert "dest 'dest' must be an existing dir" in to_text(e)

# Generated at 2022-06-11 12:43:44.509873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with src and dest paths set.
    _task = {'args': {'src': 'test_src', 'dest': 'test_dest'}}
    _loader = 'Test_Loader'
    _shared_loader_obj = None
    _action = 'Test_action'
    _task_vars = 'Test_Task_Vars'
    _play_context = 'Test_Play_Context'
    assert ActionModule(
        _task,
        _loader,
        _shared_loader_obj,
        _play_context,
        _connection,
        _action,
        _task_vars
    )

    # Test with src and dest paths not set.
    _task = {'args': {'src': None, 'dest': None}}

# Generated at 2022-06-11 12:43:46.539010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
# vim: set et sts=4 sw=4 :

# Generated at 2022-06-11 12:45:01.341865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    pass



# Generated at 2022-06-11 12:45:02.780878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am_action = ActionModule()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:45:05.516330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Unit test to re-create issue #22701

# Generated at 2022-06-11 12:45:14.191026
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:45:21.924623
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of ActionModule class
    actionmodule = ActionModule()

    # Check name value of ActionModule
    assert actionmodule.name == 'unarchive'
    assert actionmodule.transfers_files == True

    # Check the run function by using the following test case
    task = { 'args': { 'src': 'source', 'dest': 'destination'} }
    tmp = '/tmp/ansible'
    task_vars = { 'ansible_user': 'ansible'}

    result = actionmodule.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['invocation']['module_args_str'] == 'src=source dest=destination'
    assert result['invocation']['module_name'] == 'unarchive'

# Generated at 2022-06-11 12:45:27.425536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    # This currently fails for several reasons...
    p=Play().load('---\n- hosts: 127.0.0.1\n  gather_facts: no\n  tasks:\n    - debug: msg="Hello, world!"')
    t=p.get_tasks()[0]
    #from ansible.executor import TaskExecutor
    #t=TaskExecutor(p)
    ActionModule._task = t
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:45:36.389119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global_vars = { 'name': 'test' }
    action_module = ActionModule(task=global_vars, connection=global_vars, play_context=global_vars, loader=global_vars, templar=global_vars, shared_loader_obj=global_vars)
    assert action_module.task         == global_vars
    assert action_module.connection   == global_vars
    assert action_module.play_context == global_vars
    assert action_module.loader       == global_vars
    assert action_module.templar      == global_vars
    assert action_module._shared_loader_obj == global_vars
# end of unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:45:39.547842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test that basic construction and properties of ActionModule works
    """
    am = ActionModule({}, {}, {}, {}, {}, {})
    assert am.TRANSFERS_FILES
    assert am.SUPPORTED_FILTERS is not None

# Generated at 2022-06-11 12:45:49.394548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    loader = DataLoader()

# Generated at 2022-06-11 12:45:50.684564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-11 12:48:54.543851
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create instance of class ActionModule
    am = ActionModule(None, None, None)

    # Run method run of class ActionModule
    am.run()

# Generated at 2022-06-11 12:48:55.022196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:49:02.618741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import ansible.runner.connection_plugins.local
    from ansible.utils.shlex import shlex_split
    m = mock.Mock()
    m.run_command.return_value = (0, '', '')
    m.copy.return_value = (None, None)
    m.mkdtemp.return_value = 'tmpdir'
    m.expand_user.return_value = 'expanduser'
    a = ActionModule(connection=m, runner_connection='local')
    a.runner.cwd = None
    a._execute_module = mock.Mock()
    a._low_level_execute_command = mock.Mock(return_value=('stdout', 'stderr'))

# Generated at 2022-06-11 12:49:03.300799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:49:12.032963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    import re
    # tests for the method run of class ActionModule
    #
    # RUN: create ACTION_MODULE object
    action_module = ActionModule(
        connection=None,
        _task=None,
        _shell_type="csh",
        _shell_executable="/bin/csh",
    )
    # RUN: create arguments for run (kwargs)
    kwargs = dict()
    # RUN: assign tmp value
    kwargs['tmp'] = None
    # RUN: assign task_vars value
    kwargs['task_vars'] = dict(
        hostvars=dict(),
    )
    # RUN: assign _task value