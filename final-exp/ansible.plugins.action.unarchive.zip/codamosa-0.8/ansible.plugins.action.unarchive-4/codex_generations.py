

# Generated at 2022-06-11 12:39:25.380451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Imports for unit test.
    import tempfile
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.context import CLIARGS
    from ansible.cli import CLI
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    import mock


# Generated at 2022-06-11 12:39:34.641344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock for function _execute_module
    _execute_module_return = {"stdout": "", "stdout_lines": [""], "failed": False, "rc": 0, "reboot_required": False, "changed": True}
    def _execute_module_mock(module_name, module_args, task_vars):
        return _execute_module_return
    # Create mock for function _fixup_perms2
    def _fixup_perms2_mock(perms):
        return True
    # Create mock for function _transfer_file
    def _transfer_file_mock(source, dest):
        return True
    # Create mock for function _remove_tmp_path
    def _remove_tmp_path_mock(path):
        return True
    # Create mock for function _remote_expand_

# Generated at 2022-06-11 12:39:35.973626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:38.146366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None)
    assert actionModule is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:39:47.569833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection import ConnectionBase
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult

    p = PlayContext()

    my_task = Task()
    my_task.action = 'copy'
    my_task.args = dict(src='/home/test/test.txt', dest='/home/test/')
    my_task._ds = dict()
    my_task._ds['ansible_connection'] = 'local'
    my_task._ds['my_user'] = 'user'
    my_task._ds['my_home'] = '/home/test'

    res = TaskResult(host=None, task=my_task)


# Generated at 2022-06-11 12:39:57.475706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import copy
    from collections import namedtuple, MutableMapping
    from ansible.plugins.action.unarchive import ActionModule as Unarchive

    if sys.version_info[0] == 2:
        FileNotFoundError = OSError

    # emulated ActionBase._remote_expand_user
    def _remote_expand_user(s):
        if s.startswith('~/'):
            s = os.path.join(os.getcwd(), s[2:])
        return os.path.normpath(s)

    # emulated ActionBase._remote_file_exists
    def _remote_file_exists(path):
        path = path.replace('/', os.sep)
        if os.path.exists(path):
            return True


# Generated at 2022-06-11 12:40:09.023053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.unarchive import ActionModule
    class Args:
        src = "test"
        dest = "/home/x/y"
        remote_src = False
        creates = None
        decrypt = True
    args = Args()
    class Task:
        args = args
    class Play:
        connection = "local"
    task = Task()
    play = Play()
    class PlayContext:
        connection = "local"
    play_context = PlayContext()
    class VarsModule:
        pass
    vars_module = VarsModule()
    class ShellModule:
        tmpdir = "/root"
        def remote_expand_user(self,path):
            return path
        def exists(self,path):
            return True

# Generated at 2022-06-11 12:40:10.139940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creation of class instance tested in module_common
    assert True

# Generated at 2022-06-11 12:40:11.204930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-11 12:40:15.136688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play
    task = TaskInclude()
    assert isinstance(task, TaskInclude)

# Unit Test for method run()

# Generated at 2022-06-11 12:40:34.699981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        # source and dest file/directory names for testing
        tmpfile = '/tmp/test_file'
        srcfile = '/tmp/test_tar'
        desttar = '/tmp/test_tar.tar'
        destdir = '/tmp/test_dest'
        srcdir = '/tmp/test_source'

        import shutil
        import tarfile
        import os

        # test: check mode
        task_vars = {'ansible_check_mode': True}

        with open(tmpfile, 'w') as f:
            f.write("foo")

        with tarfile.open(desttar, "w") as tar:
            tar.add(tmpfile, arcname='test_file')

        os.mkdir(srcdir)
        os.mkdir(destdir)

        # test: run unarchive module
        action

# Generated at 2022-06-11 12:40:44.362790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    import os
    from ansible.utils.path import unfrackpath, makedirs_safe
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible

    # Creating a playbook, and a host
    # right now we hardcoded the location of ansible.cfg, for the sake of testing it
    cur_dir = os.path.dirname(unfrackpath(__file__))
    config

# Generated at 2022-06-11 12:40:45.418710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The function should not return anything
    assert None == ActionModule()

# Generated at 2022-06-11 12:40:47.477821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # CCTODO: Add unit test of this action module.
    print("CCTODO: Add unit test of this action module.")

# Generated at 2022-06-11 12:40:48.973260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, None, None).run() == {}

# Generated at 2022-06-11 12:40:58.800927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.constants as C
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 12:41:08.296999
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionModule = ActionModule(None, None, None, None, None)

    # test with params dest and src
    task_args = dict()
    task_args['src'] = "/tmp/dest"
    task_args['dest'] = "/tmp/src"
    result = actionModule.run(None, task_args)
    assert result['changed'] == False

    # test with params dest and src without extension
    task_args['dest'] = "/tmp/src.tar"
    result = actionModule.run(None, task_args)
    print(result)
    assert result['changed'] == False

    # test with params dest and src with extension
    task_args['dest'] = "/tmp/src.zip"
    result = actionModule.run(None, task_args)
    assert result['changed'] == False

    # test with

# Generated at 2022-06-11 12:41:12.867712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n\nTESTING ActionModule.py\n")
    # CCTODO: Finish testing ActionModule
    #am = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    #assert am
    print("\nFINISHED testing ActionModule.py\n\n")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:41:22.433531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This function creates a temp directory, copies the module under test,
    # and invokes it as a unit test.
    # It depends on the "Run Ansible Modules as a Unit Test" pattern found here:
    # https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html#run-ansible-modules-as-a-unit-test
    import json
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.unarchive import ActionModule as UnarchiveActionModule

    tmpdir = mkdtemp()
    print()
    print("Creating test directory at %s" % tmpdir)
    print()


# Generated at 2022-06-11 12:41:32.013704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Source: https://stackoverflow.com/questions/287871/print-in-terminal-with-colors
    # Reset
    ENDC = '\033[0m'

    # Regular Colors
    BLACK = '\033[0;30m'
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[0;33m'
    BLUE = '\033[0;34m'
    PURPLE = '\033[0;35m'
    CYAN = '\033[0;36m'
    WHITE = '\033[0;37m'

    # Bold
    BOLDBLACK = '\033[1;30m'
    BOLDRED = '\033[1;31m'
    B

# Generated at 2022-06-11 12:41:48.783568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()

# Generated at 2022-06-11 12:41:57.736619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from sos.plugins import AnsibleAction
    from sos.plugins import AnsibleActionFail
    from sos.plugins import AnsibleActionSkip
    from sos.plugins import ActionBase
    import os

    class MockedConnection(object):
        def __init__(self, shell):
            self._shell = shell

    class MockedShell(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def join_path(self, a, b):
            return os.path.join(a, b)

    class MockedLoader(object):
        def get_real_file(self, a, decrypt=True):
            return a

    class MockedModule(object):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-11 12:42:07.161268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import fetch_url
    from ansible.plugins.action import ActionBase
    from ansible.utils.connection_loader import verify_connection_user, load_provider
    from ansible.utils.display import Display
    from ansible.utils.hashing import secure_hash
    # Start test

# Generated at 2022-06-11 12:42:08.566437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Nothing to unit test as each method called is a library or other method.
    pass

# Generated at 2022-06-11 12:42:18.559387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase


    class TestCallbackModule(CallbackBase):
        pass

    class TestCallbackModule2(CallbackBase):
        pass


# Generated at 2022-06-11 12:42:20.893466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.unarchive as ua
    am = ua.ActionModule('task', 'play', 'play.yml')
    assert am.run() == 'Task is not implemented yet!'

# Generated at 2022-06-11 12:42:31.322348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import re
    from lib.ansible.plugins.action import ActionModule
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.playbook import Playbook
   

# Generated at 2022-06-11 12:42:38.803272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit testing for ActionModule:
    - ActionModule should always have the same name of the plugin in ActionBase
    - ActionModule constructor is a method NOT a variable/property
    - Task should be always defined for ActionModule
    - Task must be a variable/property
    """
    action_module = ActionModule()
    assert hasattr(action_module, "run")
    assert action_module.__class__.__name__ == action_module.NAME
    # assert action_module.TASK is None #TODO
    assert hasattr(ActionModule, "run")

# Generated at 2022-06-11 12:42:47.769446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for ActionModule"""
    yaml = "---\n- hosts: localhost\n  gather_facts: false\n  tasks:\n    - unarchive:\n        src: test.tgz\n        dest: /tmp/test\n"
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)

    play = Play().load(yaml, variable_manager=variable_manager, loader=loader)
    t = play.get_tasks()[0]

# Generated at 2022-06-11 12:42:57.068068
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.unarchive import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib

    # legacy testing

# Generated at 2022-06-11 12:43:31.421869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-11 12:43:32.836786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module != None

# Generated at 2022-06-11 12:43:36.599260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_am = ActionModule(connection=None,
                           task_vars=None,
                           tmp=None,
                           delete_remote_tmp=None,
                           connection_info=None)
    assert isinstance(test_am, ActionModule)


# Generated at 2022-06-11 12:43:38.097046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pdb
    #pdb.set_trace()
    return None

# Generated at 2022-06-11 12:43:49.655932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test a normal construction of the class
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(obj is not None)
    assert(isinstance(obj, ActionModule))

    # Test a construction of the class with an empty task, but the required
    # parameters are missing.
    try:
        obj2 = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        assert(False)
    except AnsibleAction:
        pass

    # Test a construction of the class with an empty task and the required
    # parameters.

# Generated at 2022-06-11 12:43:59.077337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    # Test 1 - Validate the task_vars passed in.
    # 1 - Test that the value of task_vars is preserved when a valid
    #     task_vars is passed in.
    # 2 - Test that the task_vars has default values when an empty
    #     task_vars is passed in.
    # 3 - Test that the task_vars has default values when an None
    #     task_vars is passed in.
    # 4 - Test that a AnsibleActionFail exception is thrown when an
    #     invalid task_vars is passed in.

# Generated at 2022-06-11 12:44:05.583739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate test object
    am = ActionModule(
        task=dict(action=dict(module_name=True, module_args=True)),
        connection=dict(module_implementation_preferences=True),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())

    # Check attributes were set correctly
    assert am is not None
    assert am._task == dict(action=dict(module_name=True, module_args=True))
    assert am._play_context == dict()
    assert am._loader == dict()
    assert am._templar == dict()
    assert am._shared_loader_obj == dict()
    assert isinstance(am._connection, dict)
    assert am._connection['module_implementation_preferences'] is True

# Generated at 2022-06-11 12:44:06.742442
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am is not None


# Generated at 2022-06-11 12:44:08.119895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert not action.run(tmp='', task_vars={})

# Generated at 2022-06-11 12:44:09.426518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Make unit test for ActionModule.run()
    assert 1 == 1



# Generated at 2022-06-11 12:45:26.453646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    :return:
    """

# Generated at 2022-06-11 12:45:27.357996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule() is not None)

# Generated at 2022-06-11 12:45:37.037380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    ActionModule(None, {'src': '/tmp/source/file.txt', 'dest': '/tmp/dest/file.txt'})

    # Test with missing module parameter(s)
    try:
        ActionModule(None, {'src': '/tmp/source/file.txt'})
        assert False
    except AnsibleActionFail as e:
        assert e.result['msg'] == "src (or content) and dest are required"

    try:
        ActionModule(None, {'dest': '/tmp/dest/file.txt'})
        assert False
    except AnsibleActionFail as e:
        assert e.result['msg'] == "src (or content) and dest are required"


# Generated at 2022-06-11 12:45:43.574689
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock parameters
    tmp = 'temp'
    task_vars = {}

    # Prepare mocks
    am = ActionModule()
    am._task = None
    am._task.args = {}
    am._task.args['src'] = None
    am._task.args['dest'] = None
    am._task.args['creates'] = None
    am._task.args['decrypt'] = True

    # Invoke method
    response = am.run(tmp, task_vars)

    # Checks
    assert response is not None

# Generated at 2022-06-11 12:45:44.156656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:45:54.149114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # -- Setup test data --
    result = {
        "invocation": {
            "module_name": "unarchive",
            "module_args": {
                "dest": "/etc",
                "remote_src": False,
                "src": "somefile"
            }
        },
        "stdout": "some remote_stat records"
    }
    task_vars = {}
    self = ActionModule(task=dict(args=dict(
        dest="/etc",
        remote_src=False,
        src="somefile"
    )))

# Generated at 2022-06-11 12:46:03.507985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import mock
    
    module = ActionModule()
    # Test init of ActionModule.connector
    assert isinstance(module._connection, mock.Mock), "_connection is not a mock, but %s" % type(module._connection)
    # Test init of ActionModule.tmp
    assert isinstance(module._tmp, mock.Mock), "_tmp is not a mock, but %s" % type(module._tmp)
    # Test init of ActionModule.loader
    assert isinstance(module._loader, mock.Mock), "_loader is not a mock, but %s" % type(module._loader)
    # Test init of ActionModule.task_vars

# Generated at 2022-06-11 12:46:04.592055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()


# Generated at 2022-06-11 12:46:13.483949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with non-existing file
    def test_1():
        task = dict(
            action=dict(
                module='unarchive'
            ),
            args=dict()
        )

        play_context = dict(
            remote_addr='192.168.1.113',
            remote_user='root',
            password='',
            connection='ssh'
        )

        action_module = ActionModule(task, play_context, None)
        res = action_module.run(None, None)
        assert res.get('failed') == True
        assert res.get('msg', None) == "src (or content) and dest are required"

    # Test with installed file

# Generated at 2022-06-11 12:46:21.309931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Test data that is then re-used several times
    import sys

    test_connection_info = dict(host='testhost', port=22, user='testuser')
    test_task_args = dict(src='testfile.tar.gz', dest='/test/path/dest')
    test_task_action_plugin_args = dict(creates='/test/path/dest/testfile.txt')
    test_task_vars = dict(testvar='varvalue')
    test_tmp = '/tmp/ansible/tmp.123'

    #Test code that runs as part of the test that is re-used several times
    #Code from: https://docs.pytest.org/en/latest/monkeypatch.html#monkeypatch-a-test-function
    import ansible.plugins.action.unarchive