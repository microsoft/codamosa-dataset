

# Generated at 2022-06-11 12:39:26.868149
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    import ansible.plugins.action.unarchive

    if ansible_version != '2.1.3.0':
        raise Exception("test_ActionModule_run() can only be run with Ansible 2.1.3.0, not " + ansible_version)

    import os
    import tempfile

    tmp = tempfile.mkdtemp(prefix='ansible_test_')

# Generated at 2022-06-11 12:39:31.355119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test class constructor."""
    params = {'src': 'test_src', 'dest': 'test_dest'}
    task = {'args': params}
    action = ActionModule(task, {})
    assert action._task == task
    assert action.task_vars is None
    assert action.tmp is None
    assert action._play_context is None


# Generated at 2022-06-11 12:39:39.157747
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test with no parameters
    with pytest.raises(AnsibleActionFail):
        result = {}
        action_module = ActionModule(None, None)
        action_module._task.args = dict()
        result = action_module.run(None, None)

    # Test with required parameters.
    result = {}
    action_module = ActionModule(None, None)
    action_module._task.args = dict(dest='/tmp/test_dest', src='/tmp/test_src')
    result = action_module.run(None, None)
    assert result['unarchive'] is True

# Generated at 2022-06-11 12:39:45.190007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the class
    test_object = ActionModule()

    # Create a bunch of mock objects for the run method
    tmp = 'tmp'
    task_vars = {'foo': 1, 'bar': 2}

    # Set the return values of the mock objects.
    ActionBase.run.return_value = {'a': 'b'}

    # Test call
    result = test_object.run(tmp, task_vars)
    assert result == {'a': 'b'}

# Generated at 2022-06-11 12:39:46.179675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Nothing to test')


# Generated at 2022-06-11 12:39:48.694002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup instance of class ActionModule
    # CCTODO: Add missing arguments
    am = ActionModule()
    # Verify that instance is created successfully
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:39:49.480620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert False, 'TestNotImplemented'  # implemented

# Generated at 2022-06-11 12:39:50.111037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: make unit test for ActionModule
    pass

# Generated at 2022-06-11 12:39:50.667803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:58.666592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(),  # task
                      connection=None,  # connection
                      play_context=None,  # play_context
                      loader=None,  # loader
                      templar=None,  # templar
                      shared_loader_obj=None)  # shared_loader_obj

    assert am._task == dict()
    assert am._connection is None
    assert am._play_context is None
    assert am._loader is None
    assert am._templar is None
    assert am._shared_loader_obj is None


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 12:40:14.602180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, dict(src='src',
                                     dest='dest'),
                                 'test_path',
                                 'test_module')

    module._remote_expand_user = lambda x: x
    module._remote_file_exists = lambda x: False
    module._execute_remote_stat = lambda x, y, z: {'exists': True, 'isdir': True}
    module._loader = {}
    module._find_needle = lambda x, y: y
    module._transfer_file = lambda x, y: True
    module._fixup_perms2 = lambda x: True
    module._remove_tmp_path = lambda x: True
    module._execute_module = lambda x, y, z: {'success': True}

    assert type(module.run()) == dict

# Generated at 2022-06-11 12:40:25.799367
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:40:37.251810
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Import required modules
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Set options to instantiate a play
    options = dict(
        connection='local',
        module_path=['/to/mymodules'],
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False
    )

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create an action module
    action_plugin = 'unarchive'
    action_

# Generated at 2022-06-11 12:40:41.829782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return_value = dict()
    return_value['rc'] = 0
    return_value['changed'] = False
    return_value['failed'] = False
    return_value['invocation'] = dict()
    return_value['invocation']['module_name'] = 'ansible.legacy.unarchive'
    return_value['invocation']['module_args'] = dict()
    return_value['invocation']['module_args']['src'] = '/root/source'
    return_value['invocation']['module_args']['dest'] = '/root/dest'
    return_value['invocation']['module_args']['remote_src'] = False
    return_value['invocation']['module_args']['creates'] = None

# Generated at 2022-06-11 12:40:42.473292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("ActionModule.run")
    # TODO

# Generated at 2022-06-11 12:40:43.445645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    # TODO: Write unit test
    assert False

# Generated at 2022-06-11 12:40:52.421081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = dict(ansible_connection='local', ansible_python_interpreter='/usr/bin/python')
    connection = Connection(host_vars)
    module = ActionModule(connection, '/tmp', '/tmp')

    # No test for existing archive
    assert not module.run(task_vars={})

    # Test with invalid archive
    assert not module.run(task_vars={}, source='tests/invalid.tgz')

    # Test with existing archive
    assert module.run(task_vars={}, source='tests/test.tgz')

    # Test with missing dest
    assert not module.run(task_vars={}, source='tests/test.tgz', dest='')

    # Test with existing destination dir

# Generated at 2022-06-11 12:40:53.781600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(action=dict())) == ActionModule


# Generated at 2022-06-11 12:41:03.785563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Empty input (empty dictionaries)
    input_task = {}
    input_connection = {}
    input_play_context = {}
    input_loader = {}
    input_templar = {}
    input_shared_loader_obj = {}

    # Use constructor to create object
    obj = ActionModule(input_task, input_connection, input_play_context, input_loader, input_templar, input_shared_loader_obj)

    # Test get_config() from inherited class
    config = obj.get_config()
    config_result = {}
    if not config == config_result:
        raise Exception('ActionModule.get_config() returned an incorrect value')

    # Test get_name() from inherited class
    name = obj.get_name()
    name_result = "Unarchive"

# Generated at 2022-06-11 12:41:12.824446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First, mock our connection object
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.synchronize
    class MockConnection:
        class _shell:
            class tmpdir:
                def __init__(self):
                    self.tmpdir = AnsibleUnsafeText(
                        'tmpdir')
                def __str__(self):
                    return self.tmpdir
                def __add__(self, other):
                    return AnsibleUnsafeText(self.tmpdir + AnsibleUnsafeText(str(other)))
        def _execute_remote_stat(self, dest, all_vars, follow):
            ''' This is a fake method for the test class. '''

# Generated at 2022-06-11 12:41:30.532413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:32.515210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action.TRANSFERS_FILES == True

# Generated at 2022-06-11 12:41:34.514398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test case for constructor of class ActionModule"""

    action_module_manager = ActionModule()
    assert action_module_manager is not None

# Generated at 2022-06-11 12:41:34.876676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:41:40.389499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.playbook.task import Task

    t = Task()
    t.args = dict()
    t._action = 'unarchive'
    t.args['src'] = 'source-file'
    t.args['dest'] = 'destination-file'
    t.args['creates'] = 'creates-file'
    t.args['remote_src'] = False
    t.args['decrypt'] = True

    am = ActionModule(t, context.CLIARGS)
    assert am is not None
    assert am.TRANSFERS_FILES == True

    assert am._task.args['src'] == 'source-file'
    assert am._task.args['dest'] == 'destination-file'

# Generated at 2022-06-11 12:41:50.960630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ##############################################
    # copy = False, remote_src = False
    ##############################################
    def mock_execute_remote_stat(path, all_vars, follow):
        if 'file' in path:
            return dict(
                exists=True,
                isdir=False)
        else:
            return dict(
                exists=True,
                isdir=True)
    def mock_module_name_exists_in_basedir(module_name, paths, ignore_missing):
        return True
    def mock_remove_tmp_path(self):
        pass
    def mock_fixup_perms2(self, path):
        pass
    def mock_transfer_file(self, source, dest):
        pass

# Generated at 2022-06-11 12:41:51.965319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:41:53.798440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule.
    """

    assert True

# Generated at 2022-06-11 12:42:00.897924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    module_loader = action_loader._create_action_loader(action_loader._get_actions_path())
    results = []

    play_context = PlayContext()
    play_context._options = Unsafe

# Generated at 2022-06-11 12:42:01.892598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# ========


# Generated at 2022-06-11 12:42:40.887726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, {})._task.args.get('remote_src')
    assert ActionModule(None, {'remote_src': 'True'})._task.args.get('remote_src')
    assert not ActionModule(None, {'copy': 'False'})._task.args.get('remote_src')

# Generated at 2022-06-11 12:42:43.996583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='unarchive', src='tmp', dest='tmp')))
    action.run(tmp='tmp', task_vars={'vars': 'vars'})

# Generated at 2022-06-11 12:42:50.941682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import yaml
    import json
    # Constructor
    a = ActionModule('/path/to/ansible/module',
                     '/path/to/ansible/module/context',
                     dict(module_name='module',
                          task_uuid='uuid',
                          task_vars=dict(t1='v1'),
                          loader=yaml.SafeLoader(),
                          play_context=dict(remote_addr='raddr'),
                          shared_loader_obj=None))
    # action_loader property
    assert a.action_loader=='/path/to/ansible/module/context'
    # action_name property
    assert a.action_name=='module'
    # task_uuid property
    assert a.task_uuid=='uuid'
    # task_

# Generated at 2022-06-11 12:43:00.046216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mocks
    class MockAnsibleAction:
        def __init__(self, result):
            self.result = result
    class MockAnsibleActionFail(MockAnsibleAction):
        pass
    class MockAnsibleActionSkip(MockAnsibleAction):
        pass
    class MockAnsibleError(AnsibleAction):
        def __init__(self, result):
            self.result = result

    # Code under test
    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self._task = kwargs['task']
            del kwargs['task']

        def run(self, *args, **kwargs):
            tmp = kwargs.get('tmp', None)

# Generated at 2022-06-11 12:43:08.749673
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import argparse
    import tempfile

    from ansible.plugins.action.unarchive import ActionModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    class Task():
        def __init__(self, args):
            self.args = args

    class Mock_Loader(object):
        def __init__(self):
            self.file = tempfile.mkdtemp()
            self.paths = [self.file]

        def get_real_file(self, needle, decrypt=True):
            return os.path.join(self.file, needle)

    class Mock_Runtime(object):
        def __init__(self):
            self.hostvars = {}
            self.taskvars = {}
           

# Generated at 2022-06-11 12:43:12.351033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test TypeError exception
    try:
        a = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except TypeError:
        pass

    # Test AnsibleError exception
    try:
        a = ActionModule(task=dict(foo=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except AnsibleError:
        pass

# Generated at 2022-06-11 12:43:22.299769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    source = "/home/user/sample.tar.gz"
    dest = "/home/user/samples"

    sequence = AnsibleSequence()
    sequence.append("dest")
    sequence.append("src")
    dictionary = AnsibleMapping()
    dictionary.update({ AnsibleUnsafeText("dest"): wrap_var(dest), AnsibleUnsafeText("src"): wrap_var(source) })
    task_args = {"args": dictionary}
    task

# Generated at 2022-06-11 12:43:28.625629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    test_ActionModule_run tests method run of class ActionModule.
    """
    # Initialize test variables
    expected_output = dict()
    task = dict()
    task['vars'] = dict()

    # Create object of ActionModule
    action = ActionModule(task, dict({'some_key': 'some_value'}))

    # Call run function
    output = action.run(None, dict())

    # Assert isinstance of output
    assert isinstance(output, dict)
    # Assert output equals expected_output
    assert output == expected_output

# Generated at 2022-06-11 12:43:31.912936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # assert isinstance(action_module_class.run(), dict)
    print("test_ActionModule_run")
    assert True

# Generated at 2022-06-11 12:43:32.529333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:45:03.745884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.unarchive import ActionModule
    #mock_task is an instance of MockTask
    mock_task = MockTask()
    mock_task.args = ImmutableDict(src='hello', dest='world')
    mock_task.args.remote_src = True
    mock_task.args.creates = 'world'
    mock_task.args.decrypt = True
    mock_task.args.copy = True
    #mock_connection is an instance of MockConnection
    mock_connection = MockConnection()
    #mock_loader is an instance of MockLoader
    mock_loader = MockLoader()
    #mock_action_base is an instance of MockActionBase

# Generated at 2022-06-11 12:45:04.265746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:09.114278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing import ansible.plugins.action.unarchive")

    print("Testing class ActionModule")
    t = ActionModule()
    print("Testing method run of class ActionModule")
    # TODO: Add test code
    print("Test arg dest type:", type(t.run(tmp=None, task_vars=None)['dest']), "should be", str)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:45:09.645394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:45:17.870640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("In function test_ActionModule_run")

    try:
        from ansible.plugins.action import ActionModule

        # Arrange
        test_args = {'creates': None, 'src': './test/test.zip', 'dest': '/tmp/'}
        test_task_vars = None
        test_tmp = None
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

        # Action
        result = action_module.run(test_tmp, test_task_vars)

        result_failed = False
    except Exception:
        result_failed = True
        pass

    # Assert
    assert result_failed == False

# Generated at 2022-06-11 12:45:22.608356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate the object of class ActionModule.
    class_object = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Make call to the method of the class object with arguments.
    result = class_object.run(tmp=None, task_vars=None)

    # Check result.assertEqual(expected, result)
    # (None, None)

# Generated at 2022-06-11 12:45:32.047501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test for class ActionModule
    """
    action_module = ActionModule(
        task=AnsibleTask(), play_context=PlayContext(),
        new_stdin="new-stdin"
    )
    #assert action_module == "ActionModule(task=AnsibleTask(name='task', action='action', args={}), new_stdin='new-stdin', play_context=PlayContext(remote_addr=None, port=None, remote_user=None, password=None, connection='smart', become=False, become_method=None, become_user=None, become_pass=None, become_exe=None, become_flags=None, become_ask_pass=False, environment=None, only_tags=None, skip_tags=None, check=False, diff=False, no_log=False, verbosity=

# Generated at 2022-06-11 12:45:40.986415
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #########################################################################################################
    ####
    #### NOTE: These tests should be split into separate cases as they're testing multiple areas
    ####       of the same API.
    ####

    # For testing set environment variable:
    # export TESTCASE=test_ActionModule_run

    import os
    import sys
    import pytest
    import tempfile
    import shutil
    import json
    import stat

    # Look for a file to test with (I'm assuming this code is in a playbook)
    playbook_dir  = os.path.dirname(os.path.realpath(__file__))
    playbook_root = os.path.dirname(playbook_dir)
    testfile_dir  = os.path.join(playbook_root, 'test/integration/testfile')

# Generated at 2022-06-11 12:45:43.666899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test to make sure the ActionModule class was constructed correctly
    """
    actionModule = ActionModule()
    assert actionModule.TRANSFERS_FILES == True

# Generated at 2022-06-11 12:45:46.614224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None