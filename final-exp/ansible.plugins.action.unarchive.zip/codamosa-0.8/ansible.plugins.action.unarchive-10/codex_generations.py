

# Generated at 2022-06-11 12:39:17.560161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-11 12:39:21.615325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    class ActionModuleTestCase(unittest.TestCase):
        def test_run(self):
            pass

    unittest.main()

if __name__ == '__main__':
    # Unit tests for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-11 12:39:25.071229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('unarchive', {'src': 'test/unarchive/src', 'dest': '/tmp/dest'})
    module.run()

if __name__ == '__main__':
    # Unit test code
    test_ActionModule_run()

# Generated at 2022-06-11 12:39:26.057176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-11 12:39:31.443942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(src='/tmp/my_copy_src', dest='/tmp/my_copy_dest', remote_src=False, remote_function='posix_copy_file'))
    )
    assert module
    module = ActionModule(
        task=dict(args=dict(src='/tmp/my_copy_src', dest='/tmp/my_copy_dest'))
    )
    assert module

# Generated at 2022-06-11 12:39:32.064355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:39:33.998572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = {}
    am = ActionModule(tmp, task_vars)
    # Should not crash.


# Generated at 2022-06-11 12:39:44.034857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    class MockModule(object):
        def __init__(self, args=None, class_name=None, module_name=None):
            self._args = (args, class_name, module_name)
        def run(self, tmp, task_vars):
            return (tmp, task_vars, self._args)
    class MockExecutor(object):
        def __init__(self):
            self._in_exec = False

# Generated at 2022-06-11 12:39:53.849626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO

    # A successful task is returned when a file does not exist to be unarchived.
    assert True == ActionModule.run(
        None,
        tmp=None,
        task_vars=None,
        _task=None,
        _connection=None,
        _play_context=None,
        _loader=None,
        _templar=None,
        _shared_loader_obj=None
    )

    # TODO: Unit test has to be improved.
    #assert False == ActionModule.run(
    #    None,
    #    tmp=None,
    #    task_vars=None,
    #    _task=None,
    #    _connection=None,
    #    _play_context=None,
    #    _loader=

# Generated at 2022-06-11 12:39:55.611847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test the constructor of ActionModule """
    mod = ActionModule()
    assert mod is not None

# Generated at 2022-06-11 12:40:12.984175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    # Creating an instance of Task
    data_loader = DataLoader()
    task = Task()
    task._role = None
    task.args = dict()
    task._role_name = None
    task._play = None

    # Creating an instance of ActionModule
    action_module = ActionModule(task, data_loader)

    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._task_vars, ImmutableDict)
    assert isinstance(action_module._nonpersistent_facts, dict)

# Generated at 2022-06-11 12:40:24.685636
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:40:30.055536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        Unit test for method run of class ActionModule
    """
    from ansible.module_utils.my_ansible_module import MyAnsibleModule
    my_ansible_module = MyAnsibleModule(action_module=ActionModule)

    # This is the standard way ansible-playbook executes the module
    my_ansible_module.execute()

# Generated at 2022-06-11 12:40:31.498625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize and run the class, then check for expected results
    raise NotImplementedError

# Generated at 2022-06-11 12:40:36.952735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    # CCTODO: What a terrible interface.
    # They don't even bother to document how to construct an object.
    import tempfile
    temp_path = tempfile.mkdtemp()
    os.environ['ANSIBLE_ROLES_PATH'] = temp_path
    transformer = ActionModule()
    print(transformer)

# Generated at 2022-06-11 12:40:37.427528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)

# Generated at 2022-06-11 12:40:41.749147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestObject:
        def __init__(self, dest):
            self.dest = dest

    args = {'src': '/tmp/src', 'dest': '/tmp/dest'}
    task_vars = dict()

    obj = ActionModule(TestObject('dummy'), args, task_vars)
    obj.run()

# Generated at 2022-06-11 12:40:45.782210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ AnsibleAction: Test for method - run """
    connection = Connection(None)
    task = Task('unarchive', None)
    task.args = {'dest':'C:/Users/example/Desktop', 'src':'example.txt'}
    action_module = ActionModule(connection, task, None, None)
    result = action_module.run()
    assert(result['failed'] == True)
    

# Generated at 2022-06-11 12:40:54.817561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    module_name = 'ansible.plugins.action.copy'
    module = __import__(module_name)
    module = getattr(module, module_name.split('.')[-1])
    module_name = 'ansible.plugins.action.unarchive'
    try:
        module = __import__(module_name)
        module = getattr(module, module_name.split('.')[-1])
        module_name = 'ansible.plugins.action.unarchive'
    except ImportError:
        module_name = 'ansible.plugins.action.unarchive'
    plugin_class = getattr(module, os.path.basename(module_name))
    ActionModule(plugin_class)

# Generated at 2022-06-11 12:40:55.420850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:14.661877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionBase)
    assert module.TRANSFERS_FILES == True

# Generated at 2022-06-11 12:41:18.967051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = "ansible.legacy.unarchive"
    module_args = dict(src="test", dest="test")
    task_vars = dict()
    action_base = ActionBase()
    action_module = ActionModule(action_base, task_vars, module_name, module_args)
    assert action_module != None

# Generated at 2022-06-11 12:41:28.136648
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # unit test imports
    import os
    import shutil

    from ansible.plugins.action.unarchive import ActionModule
    from ansible.module_utils import basic
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.inventory
    import ansible.utils.template
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy

    # ansible test modules imports
    from units.mock.loader import DictDataLoader
    from units.mock.executor import mock_executor

    # unit test variables
    # set environment variables
    os.environ["ANSIBLE_CONFIG"] = os.path.dirname(os.path.realpath(__file__)) + '/unittest_files/ansible.cfg'

    # mock

# Generated at 2022-06-11 12:41:37.388975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance ActionBase with fake task and connection
    result = dict(skipped=False, changed=False)
    task = FakeTask()
    connection = FakeConnection()
    action = ActionModule(Result(task, connection, result))

    # Create action module params
    params = dict(
        src = 'src',
        dest = 'dest',
        remote_src = 'remote_src',
        creates = 'creates',
        decrypt = 'decrypt',
    )

    # Create fake path to source file
    source = ''

    # Create fake result of method remote_expand_user(...)
    remote_expaned_user = 'remote_expaned_user'
    action._remote_expand_user = lambda x: remote_expaned_user

    # Create fake remote file stat of method _execute_remote_stat(

# Generated at 2022-06-11 12:41:48.171608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up a test environment of Ansible.
    # Most parameters are set to None.
    #
    # In this test, the only part tested is the constructor and its
    # parameter validation.
    mock_task = type('mock_task', (object,), {})()
    mock_task.args = {'src': 'test/data/archive/test.tar.gz', 'dest': '/tmp'}
    mock_task.action = 'unarchive'
    mock_task.action_args = {}
    
    action = ActionModule(mock_task, display=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Have to call run to ensure it is a valid action module.
    action.run(None, None)

    # If the code

# Generated at 2022-06-11 12:41:57.287925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = True
    connection = True
    task = True
    play_context = True
    loader = True
    templar = True
    shared_loader_obj = True
    def set_loader(obj):
        global loader
        loader = obj

    def set_templar(obj):
        global templar
        templar = obj

    def set_shared_loader_obj(obj):
        global shared_loader_obj
        shared_loader_obj = obj

    class MockModule:
        def __init__(self):
            return

    class MockConnection:
        def __init__(self):
            return

        def _new_shell_in_control_path(self):
            return MockShell()

    class MockShell:
        def __init__(self):
            return

# Generated at 2022-06-11 12:42:06.374463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        pass
    class TestActionModule_run():
        def test_run_exception_1(self):
            try:
                raise AnsibleActionFail("src (or content) and dest are required")
            except AnsibleAction as e:
                assert(str(e) == "AnsibleActionFail: src (or content) and dest are required")

        def test_run_exception_2(self):
            try:
                raise AnsibleActionSkip("skipped, since %s exists" % "src")
            except AnsibleAction as e:
                assert(str(e) == "AnsibleActionSkip: skipped, since src exists")


# Generated at 2022-06-11 12:42:09.642813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    b = ActionModule()
    if a == b:
        print('Test PASS: ActionModule() is working')
    else:
        print('Test FAIL: ActionModule() is not working')

# Generated at 2022-06-11 12:42:19.240044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sys.path.append("/home/miguel/Documents/Ansible/library/")
    import unarchive
    obj = unarchive.ActionModule()
    print("Test 1:", obj)
    print("Test 2:", obj.run(tmp="/tmp/toto", task_vars={}))
    print("Test 3:", obj.run(tmp="/tmp/toto", task_vars={"src": "toto"}))
    print("Test 4:", obj.run(tmp="/tmp/toto", task_vars={"dst": "toto"}))
    print("Test 5:", obj.run(tmp="/tmp/toto", task_vars={"copy": "false"}))

# Generated at 2022-06-11 12:42:28.007041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task = dict(dest='/tmp/css')
    source0 = dict(src='/tmp/css')
    source1 = dict(content='/tmp/css')
    module_args0 = dict(decrypt=True)
    module_args1 = dict(decrypt=True, remote_src=True)
    # Test args src and dest
    module.run(tmp=None, task_vars=None, task=task, source0=source0, module_args=module_args0)
    module.run(tmp=None, task_vars=None, task=task, source1=source1, module_args=module_args1)
    # Test args creates and dest

# Generated at 2022-06-11 12:43:06.491040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = 'Test Task'
    module._connection = object
    module._loader = 'Test Loader'
    module._shell = object
    module._remote_tmp = 'Test Remote Temp'
    module._ansible_tmp = 'Test Ansible Temp'
    module._task_vars = 'dummy task vars'
    module._tmp = 'dummy tmp'
    module._play_context = 'dummy play context'

    class Bunch(object):
        def __init__(self, adict):
            self.__dict__.update(adict)

    # Test for when a destination path is provided as a relative path
    args = {
        'src': 'Test Source',
        'dest': 'Test\Destination'
    }
    module._task.args = Bunch(args)

# Generated at 2022-06-11 12:43:16.348797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    import os
    # Create temporary directory and files as needed by test
    tmpdir = tempfile.mkdtemp()
    test_file_src = os.path.join(tmpdir, 'test_src.file')
    test_file_dest = os.path.join(tmpdir, 'test_dest.file')
    data = 'Test file contents'
    with open(test_file_src, 'wb') as f:
        f.write(data)
    # Create temporary ansible.cfg file so ansible configuration can be changed for test
    ansible_cfg = tempfile.NamedTemporaryFile(prefix="ansible_cfg_")

# Generated at 2022-06-11 12:43:25.379498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test action module run method with simple arguments.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context._setup_remote_tmp = lambda: '~/tmp'
    variable_manager = VariableManager()

    # Create ActionModule instance to run test
    action_module = ActionModule(task=None, connection=None, play_context=context, loader=None, templar=None, shared_loader_obj=None)

    # Create arguments to method run
    tmp = None
    task_vars = None

    # Create the expected result
    result = dict(skipped=False, changed=False, rc=0, stderr='', stdout='', failed=False)

    # Call the run method and check

# Generated at 2022-06-11 12:43:27.735980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Mocking up classes/objects/modules is outside of my current knowledge,
    # so I'm leaving this as a stub to be implemented later.
    pass


# Generated at 2022-06-11 12:43:30.174593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection = None, task = None, play_context = None, loader = None,
                                 templar = None, shared_loader_obj = None)

    assert action_module is not None


# Generated at 2022-06-11 12:43:31.604561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mymodule = ActionModule()
    assert mymodule is not None

# Generated at 2022-06-11 12:43:33.409418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for ActionModule (refer to test_ActionBase_run)
    pass

# Generated at 2022-06-11 12:43:37.853877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for action module unarchive module
    '''
    # Constructor test:
    unarchive = ActionModule.ActionModule(None, None, None, None, None)
    assert unarchive is not None, "Unarchive module constructor"
    assert unarchive.TRANSFERS_FILES is True, "Unarchive module constructor"

# Generated at 2022-06-11 12:43:41.283786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor of class ActionModule
    '''
    unarchive = ActionModule(None, None, None, None)

    assert unarchive.TRANSFERS_FILES == True

# Generated at 2022-06-11 12:43:43.055362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert action.TRANSFERS_FILES == True


# Generated at 2022-06-11 12:44:59.377945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' in globals()

# Generated at 2022-06-11 12:45:00.291142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()

# Generated at 2022-06-11 12:45:06.058487
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an object of the class ActionModule and call method run
    # with empty values for the arguments.
    am = ActionModule()
    result = am.run()

    assert isinstance(result, dict), "Return type of method run is not dict."

    assert len(result.keys()) == 1, "Return dict of method run contains more than one key."

    assert "failed" in result.keys(), "Return dict of method run does not contain key failed."

    assert isinstance(result.get("failed"), bool), "Return dict of method run does not contain key failed."


# Generated at 2022-06-11 12:45:14.745535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock ActionModule object
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock result dictionary
    result = dict()

    # Create a mock task dictionary
    task_vars = dict()
    task_vars['ansible_network_os'] = "IOS"

    # Set the mock task argument dictionary
    args = dict()
    args['src'] = "/home/nwproj/ansible-nwproj/networking-cisco/test/fixtures/ios_configs/nxos_facts_output.txt"
    args['dest'] = "/home/nwproj/ansible-nwproj/networking-cisco/test/fixtures/ios_configs/"
    args

# Generated at 2022-06-11 12:45:21.844500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """
    action_module = ActionModule()
    assert hasattr(action_module, 'run')
    assert hasattr(action_module, '_execute_module')
    assert hasattr(action_module, '_execute_remote_stat')
    assert hasattr(action_module, '_loader')
    assert hasattr(action_module, '_remove_tmp_path')
    assert hasattr(action_module, '_remote_expand_user')
    assert hasattr(action_module, '_remote_file_exists')
    assert hasattr(action_module, '_task')
    assert hasattr(action_module, '_transfer_file')

# Generated at 2022-06-11 12:45:31.125567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import unittest
    from ansible.plugins.action import ActionModule
    from ansible import context
    from ansible.module_utils.basic import AnsibleModule

    class BaseTest(object):
        def __init__(self, module):
            self.module = module
            self.msg = None
            self.failed = False

        def run(self):
            self.module.fail_json(msg=self.msg, failed=self.failed)

    class TestActionBase(BaseTest, ActionModule):
        def __init__(self, module):
            ActionModule.__init__(self, module)
            BaseTest.__init__(self, module)


# Generated at 2022-06-11 12:45:31.741816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:40.727411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import playbook_executor
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host

    class CallbackModule(CallbackBase):
        """A sample callback module for performing an action as results come in.
        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin.
        """
        CALLBACK_VERSION = 2.0

# Generated at 2022-06-11 12:45:50.818457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Creates an instance of ActionModule, passing it a fake task.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task_include import TaskInclude

    class Options:
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.remote_user = 'dummy'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None

# Generated at 2022-06-11 12:45:54.663409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict()
    am = ActionModule(task=dict(args=dict(dest="/foo/bar", src="/tmp/blurp", decrypt=False)))
    assert am is not None
    am.run(task_vars=dict(), result=result)
    assert result["msg"] == "dest must be an existing dir"

# Generated at 2022-06-11 12:49:12.715376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test method run of class ActionModule."""

    # Mocked connection
    class MockConnection():
        class _shell():
            """Mocked _shell class used to emulate a shell."""
            def __init__(self):
                self.tmpdir = b'/tmp'
            def join_path(self, directory, file):
                """Mocked join_path method."""
                return os.path.join(directory, file)

        def __init__(self):
            self._shell = MockConnection._shell()

    # Mocked module
    class MockModule():
        class _connection():
            """Mocked connection attribute of action module class."""
            def __init__(self):
                self._shell = MockConnection._shell()

        def __init__(self):
            self._connection = MockConnection()

    # Mocked action plugin
