

# Generated at 2022-06-17 09:54:12.342201
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:54:21.433807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': False, 'creates': None, 'decrypt': True}

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock module object
    module = MockModule()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock module_utils.basic object
    basic = MockBasic()

    # Create a mock module_utils.basic.AnsibleModule object
    ansible_module = MockAnsibleModule()

    # Create a mock module_utils

# Generated at 2022-06-17 09:54:28.851249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule()
    # Create a mock object of class Task
    task = MockTask()
    # Create a mock object of class Connection
    connection = MockConnection()
    # Set the connection attribute of the action_module object
    action_module._connection = connection
    # Set the task attribute of the action_module object
    action_module._task = task
    # Create a mock object of class Shell
    shell = MockShell()
    # Set the shell attribute of the connection object
    connection._shell = shell
    # Create a mock object of class AnsibleActionFail
    ansible_action_fail = MockAnsibleActionFail()
    # Set the AnsibleActionFail attribute of the action_module object
    action_module.AnsibleActionFail = ansible_action_fail
    # Create

# Generated at 2022-06-17 09:54:30.921829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:54:31.273755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:42.606717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:54:52.002131
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:54:52.642437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:54.984835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters.
    am = ActionModule()
    assert am.TRANSFERS_FILES == True
    assert am.run() == None

# Generated at 2022-06-17 09:55:04.237113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': False, 'creates': None, 'decrypt': True}

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = 'test_tmpdir'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, module, action_plugin)

    # Test the run method
    action_module.run()

    # Test the run method with a remote_src of True
   

# Generated at 2022-06-17 09:55:20.675063
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:55:28.960034
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:55:32.328566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:35.653402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:55:36.756513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:55:37.232308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:46.121208
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:55:56.003279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = MockTask()
    # Create a mock connection.
    connection = MockConnection()
    # Create a mock loader.
    loader = MockLoader()
    # Create a mock variable manager.
    variable_manager = MockVariableManager()
    # Create a mock action module.
    action_module = ActionModule(task, connection, loader, variable_manager)
    # Create a mock result.
    result = MockResult()
    # Create a mock tmp.
    tmp = MockTmp()
    # Create a mock task_vars.
    task_vars = MockTaskVars()
    # Create a mock remote_stat.
    remote_stat = MockRemoteStat()
    # Create a mock remote_stat_exists.
    remote_stat_exists = MockRemoteStatExists()
    # Create a mock

# Generated at 2022-06-17 09:56:03.299145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = MockTask()
    # Create a mock connection.
    connection = MockConnection()
    # Create a mock loader.
    loader = MockLoader()
    # Create a mock play context.
    play_context = MockPlayContext()
    # Create a mock action module.
    action_module = ActionModule(task, connection, play_context, loader)
    # Create a mock AnsibleAction.
    ansible_action = MockAnsibleAction()
    # Create a mock AnsibleActionFail.
    ansible_action_fail = MockAnsibleActionFail()
    # Create a mock AnsibleActionSkip.
    ansible_action_skip = MockAnsibleActionSkip()
    # Create a mock AnsibleError.
    ansible_error = MockAnsibleError()
    # Create a mock Ansible

# Generated at 2022-06-17 09:56:09.319630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class Connection
    connection = Connection()
    # Create an instance of class Shell
    shell = Shell()
    # Set the value of attribute tmpdir of class Shell
    shell.tmpdir = '/tmp'
    # Set the value of attribute _shell of class Connection
    connection._shell = shell
    # Set the value of attribute _connection of class PlayContext
    play_context._connection = connection
    # Set the value of attribute _play_context of class Task
    task._play_context = play_context
    # Set the value of attribute _task of class ActionModule
    action_module._task = task
   

# Generated at 2022-06-17 09:56:29.985969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()
    # Create an instance of class AnsibleAction
    aa = AnsibleAction()
    # Create an instance of class AnsibleActionFail
    aaf = AnsibleActionFail()
    # Create an instance of class AnsibleActionSkip
    aas = AnsibleActionSkip()
    # Create an instance of class AnsibleError
    ae = AnsibleError()
    # Create an instance of class AnsibleAction
    aa = AnsibleAction()
    # Create an instance of class AnsibleActionFail
    aaf = AnsibleActionFail()
    # Create an instance of class AnsibleActionSkip
    aas = AnsibleActionSkip()
    # Create an instance of class AnsibleError
    ae = AnsibleError()
    # Create an instance of class AnsibleAction
    aa

# Generated at 2022-06-17 09:56:31.415769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:56:36.519495
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:56:46.582268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils/urls.py file
    class MockModuleUtilsUrls:
        def __init__(self):
            self.urlparse = urlparse
            self.urlunparse = urlunparse
            self.urljoin = urljoin
            self.urllib_error = urllib_error
            self.parse_url = parse_url
            self.unquote = unquote
            self.quote = quote
            self.to_text = to_text
            self.to_bytes = to_bytes
            self.url_filename = url_filename
            self.is_url = is_url
            self.is_path = is_path
            self.is_archive_path = is_archive_path
            self.is_local_path = is_local_path
            self.is_local

# Generated at 2022-06-17 09:56:55.477692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('', (), {})()
    mock_module.params = {}
    mock_module.run_command = lambda x: (0, '', '')
    mock_module.fail_json = lambda x: None
    mock_module.exit_json = lambda x: None
    mock_module.check_mode = False
    mock_module.no_log = False

    # Create a mock object for the connection class
    mock_connection = type('', (), {})()
    mock_connection.shell = type('', (), {})()
    mock_connection.shell.tmpdir = '/tmp'
    mock_connection.shell.join_path = lambda x, y: x + '/' + y
    mock_connection.shell.exists = lambda x: True

# Generated at 2022-06-17 09:56:56.489472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:57:00.344921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-17 09:57:01.592319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:57:08.818723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock module_utils object
    module_utils = MockModuleUtils()
    # Create a mock action_base object
    action_base = MockActionBase()
    # Create a mock action_module object
    action_module = ActionModule(task, connection, loader, module_utils, action_base)
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock tmp object
    tmp = MockTmp()
    # Create a mock AnsibleAction object
    ansible_action = MockAnsibleAction()
    # Create a mock AnsibleActionFail object
    ansible_action_fail

# Generated at 2022-06-17 09:57:20.299335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:57:51.698831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:52.198185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:01.817159
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:58:03.784210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:58:14.059155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = MockTask()
    task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': False, 'creates': 'test_creates', 'decrypt': True}
    # Create a mock connection.
    connection = MockConnection()
    # Create a mock loader.
    loader = MockLoader()
    # Create a mock module_utils.
    module_utils = MockModuleUtils()
    # Create a mock action plugin.
    action_plugin = MockActionPlugin()
    # Create a mock action module.
    action_module = ActionModule(task, connection, loader, module_utils, action_plugin)
    # Run the method run of class ActionModule.
    action_module.run()
    # Check if the method run of class ActionModule was called.
   

# Generated at 2022-06-17 09:58:25.752903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection, then create an instance of ActionModule.
    task = MockTask()
    connection = MockConnection()
    action_module = ActionModule(task, connection)

    # Create a mock AnsibleActionFail exception.
    ansible_action_fail = MockAnsibleActionFail()

    # Create a mock AnsibleActionSkip exception.
    ansible_action_skip = MockAnsibleActionSkip()

    # Create a mock AnsibleError exception.
    ansible_error = MockAnsibleError()

    # Create a mock AnsibleAction exception.
    ansible_action = MockAnsibleAction()

    # Create a mock AnsibleActionFail exception.
    ansible_action_fail = MockAnsibleActionFail()

    # Create a mock AnsibleActionSkip exception.
    ansible_action_skip = MockAn

# Generated at 2022-06-17 09:58:31.987627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a task
    task = dict()

    # Create a task_vars
    task_vars = dict()

    # Create a result
    result = dict()

    # Create a tmp
    tmp = None

    # Create a source
    source = None

    # Create a dest
    dest = None

    # Create a remote_src
    remote_src = False

    # Create a creates
    creates = None

    # Create a decrypt
    decrypt = True

    # Create a new_module_args
    new_module_args = dict()

    # Create a remote_stat
    remote_stat = dict()

    # Create a remote_stat['exists']
    remote_stat['exists'] = True

    # Create a remote_stat['isdir

# Generated at 2022-06-17 09:58:43.223351
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:58:44.175269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:58:54.649835
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:00:08.903172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 10:00:09.703845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 10:00:10.618567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:13.895769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 10:00:16.597272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:00:24.023724
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:00:25.528624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 10:00:34.541640
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:00:46.036626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to use for testing
    mock_task = MockTask()
    mock_task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': False, 'creates': None, 'decrypt': True}

    # Create a mock connection to use for testing
    mock_connection = MockConnection()

    # Create a mock loader to use for testing
    mock_loader = MockLoader()

    # Create a mock action plugin to use for testing
    mock_action_plugin = MockActionPlugin()

    # Create a mock module to use for testing
    mock_module = MockModule()

    # Create a mock shell to use for testing
    mock_shell = MockShell()

    # Create a mock remote_stat to use for testing
    mock_remote_stat = MockRemoteStat()

    # Create a mock remote

# Generated at 2022-06-17 10:00:47.390048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 10:03:54.795050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v