

# Generated at 2022-06-17 09:54:06.527401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of class AnsibleActionSkip
    ansible_action_skip = AnsibleActionSkip()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of class AnsibleActionSkip
    ansible_action_skip = AnsibleActionSkip()

    # Create an instance of class AnsibleError

# Generated at 2022-06-17 09:54:07.846072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:08.968380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:54:12.398691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:54:21.435023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock module_utils object
    module_utils = MockModuleUtils()
    # Create a mock action plugin object
    action_plugin = MockActionPlugin()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock action module object
    action_module = ActionModule(task, connection, loader, module_utils, action_plugin, action_base)
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock tmp object
    tmp = MockTmp()
    # Create a mock result object
    result = MockResult()
    # Create a mock

# Generated at 2022-06-17 09:54:28.851087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = dict()
    task['args'] = dict()
    task['args']['src'] = 'src'
    task['args']['dest'] = 'dest'
    task['args']['remote_src'] = False
    task['args']['creates'] = None
    task['args']['decrypt'] = True

    # Create a mock connection.
    connection = dict()
    connection['_shell'] = dict()
    connection['_shell']['tmpdir'] = 'tmpdir'
    connection['_shell']['join_path'] = lambda a, b: a + '/' + b

    # Create a mock loader.
    loader = dict()
    loader['get_real_file'] = lambda a, b: a

# Generated at 2022-06-17 09:54:38.020190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()
    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()
    # Create an instance of class AnsibleActionSkip
    ansible_action_skip = AnsibleActionSkip()
    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()
    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()
    # Create an instance of class AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()
    # Create an instance of class AnsibleActionSkip
    ansible_action_skip = AnsibleActionSkip()
    # Create an instance of class AnsibleError

# Generated at 2022-06-17 09:54:39.082615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:54:49.617926
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:54:57.653437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'src': 'test_src', 'dest': 'test_dest', 'remote_src': False, 'creates': 'test_creates', 'decrypt': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, module_utils, action_plugin)

    # Call the run method of the action module
    action_module.run()

    # Assert that the remote_expand_user method was called with the correct parameter
    assert connection

# Generated at 2022-06-17 09:55:08.518546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:55:15.637184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                src='/tmp/src',
                dest='/tmp/dest',
                remote_src=False,
                creates='/tmp/creates',
                decrypt=True
            )
        )
    )
    assert action_module.TRANSFERS_FILES == True
    assert action_module._task.args['src'] == '/tmp/src'
    assert action_module._task.args['dest'] == '/tmp/dest'
    assert action_module._task.args['remote_src'] == False
    assert action_module._task.args['creates'] == '/tmp/creates'
    assert action_module._task.args['decrypt'] == True


# Generated at 2022-06-17 09:55:22.455019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock module_utils object
    module_utils = MockModuleUtils()
    # Create a mock module_utils.basic object
    basic = MockBasic()
    # Create a mock module_utils.basic.AnsibleModule object
    AnsibleModule = MockAnsibleModule()
    # Create a mock module_utils.basic.AnsibleModule.fail_json object
    fail_json = MockFailJson()
    # Create a mock module_utils.basic.AnsibleModule.exit_json object
    exit_json = MockExitJson()
    # Create a mock module_utils.basic.AnsibleModule.run_command object


# Generated at 2022-06-17 09:55:29.188049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, module_utils, action_plugin)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock AnsibleAction
    ansible_action = MockAnsibleAction()
    # Create a mock AnsibleActionFail
    ansible_action

# Generated at 2022-06-17 09:55:39.580101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    module = ActionModule(task=dict(action=dict(module='unarchive', args=dict(src='/tmp/test.tar.gz', dest='/tmp/test'))))
    assert module

    # Test with invalid parameters
    try:
        module = ActionModule(task=dict(action=dict(module='unarchive', args=dict(src='/tmp/test.tar.gz'))))
        assert False
    except AnsibleActionFail:
        assert True
    except:
        assert False

    try:
        module = ActionModule(task=dict(action=dict(module='unarchive', args=dict(dest='/tmp/test'))))
        assert False
    except AnsibleActionFail:
        assert True
    except:
        assert False

# Generated at 2022-06-17 09:55:40.357218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:55:46.835686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src or dest
    task_args = dict()
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed']
    assert result['msg'] == "src (or content) and dest are required"

    # Test with no dest
    task_args = dict(src='/tmp/src')
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:55:47.501958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:55.866374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('', (), {})()
    mock_module.params = {'src': 'source', 'dest': 'destination'}
    mock_module.run = ActionModule.run
    mock_module.run.__doc__ = ActionModule.run.__doc__

    # Create a mock object for the connection class
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()
    mock_connection._shell.tmpdir = 'tmpdir'
    mock_connection._shell.join_path = lambda x, y: x + '/' + y
    mock_connection._shell.exists = lambda x: True
    mock_connection._shell.isdir = lambda x: True

# Generated at 2022-06-17 09:56:03.179740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {
        'src': '/home/user/test.tar.gz',
        'dest': '/home/user/test',
        'remote_src': False,
        'creates': None,
        'decrypt': True
    }

    # Create a mock connection object
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = '/home/user/tmp'

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action module object
    action_module = ActionModule(task, connection, loader, action_plugin)

    # Test the run method
    result = action_module.run()

    # Ass

# Generated at 2022-06-17 09:56:28.602053
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:56:28.935850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 09:56:35.753432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = dict()
    task['args'] = dict()
    task['args']['src'] = 'src'
    task['args']['dest'] = 'dest'
    task['args']['remote_src'] = False
    task['args']['creates'] = None
    task['args']['decrypt'] = True

    # Create a mock connection.
    connection = dict()
    connection['_shell'] = dict()
    connection['_shell']['tmpdir'] = 'tmpdir'
    connection['_shell']['join_path'] = lambda a, b: a + '/' + b

    # Create a mock loader.
    loader = dict()
    loader['get_real_file'] = lambda a, b: a

# Generated at 2022-06-17 09:56:39.192816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:56:40.581057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:56:48.421612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = dict()
    task['args'] = dict()
    task['args']['src'] = 'test_src'
    task['args']['dest'] = 'test_dest'
    task['args']['remote_src'] = False
    task['args']['creates'] = 'test_creates'
    task['args']['decrypt'] = True

    # Create a mock connection.
    connection = dict()
    connection['shell'] = dict()
    connection['shell']['tmpdir'] = 'test_tmpdir'
    connection['shell']['join_path'] = lambda x, y: x + '/' + y

    # Create a mock loader.
    loader = dict()
    loader['get_real_file'] = lambda x, y: x + y

   

# Generated at 2022-06-17 09:56:51.096502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:56:52.507584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 09:57:00.560351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = type('', (), {})()
    task.args = {'src': 'test_src', 'dest': 'test_dest'}

    # Create a mock connection object
    connection = type('', (), {})()
    connection._shell = type('', (), {})()
    connection._shell.tmpdir = 'test_tmpdir'
    connection._shell.join_path = lambda x, y: x + y
    connection._shell.expand_user = lambda x: x
    connection._shell.exists = lambda x: True
    connection._shell.isdir = lambda x: True
    connection._shell.isfile = lambda x: True
    connection._shell.stat = lambda x: {'exists': True, 'isdir': True}
    connection._shell.remove = lambda x: True
   

# Generated at 2022-06-17 09:57:08.203562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid src and dest
    task_vars = dict()
    module_args = dict()
    module_args['src'] = 'test_src'
    module_args['dest'] = 'test_dest'
    module_args['remote_src'] = False
    module_args['creates'] = None
    module_args['decrypt'] = True
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    assert result['changed'] == True
    assert result['msg'] == 'unarchived'

    # Test with a valid src and dest
    task_vars = dict()
    module_args = dict

# Generated at 2022-06-17 09:57:45.224110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()
    # Create an instance of AnsibleTask
    at = AnsibleTask()
    # Create an instance of AnsibleTaskResult
    atr = AnsibleTaskResult()
    # Create an instance of AnsibleConnection
    ac = AnsibleConnection()
    # Create an instance of AnsibleShell
    ashell = AnsibleShell()
    # Create an instance of AnsibleModuleLoader
    aml = AnsibleModuleLoader()
    # Create an instance of AnsibleModule
    amod = AnsibleModule()
    # Create an instance of AnsibleFileSystem
    afs = AnsibleFileSystem()
    # Create an instance of AnsibleVault
    av = AnsibleVault()
    # Create an instance of AnsibleVaultEncryptedUnicode
    aveu = AnsibleVaultEnc

# Generated at 2022-06-17 09:57:52.990866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext
    play_context = PlayContext()

# Generated at 2022-06-17 09:58:02.466253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('', (), {})()
    mock_module.params = {}
    mock_module.params['src'] = 'test_src'
    mock_module.params['dest'] = 'test_dest'
    mock_module.params['remote_src'] = False
    mock_module.params['creates'] = 'test_creates'
    mock_module.params['decrypt'] = True

    # Create a mock object for the task class
    mock_task = type('', (), {})()
    mock_task.args = {}
    mock_task.args['src'] = 'test_src'
    mock_task.args['dest'] = 'test_dest'
    mock_task.args['remote_src'] = False
    mock_task.args['creates']

# Generated at 2022-06-17 09:58:13.422495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:58:25.531870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = MockTask()
    task.args = {'src': 'test_src', 'dest': 'test_dest'}

    # Create a mock connection.
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = 'test_tmpdir'
    connection._shell.join_path = lambda x, y: x + y

    # Create a mock loader.
    loader = MockLoader()
    loader.get_real_file = lambda x, y: x

    # Create a mock module_utils.
    module_utils = MockModuleUtils()

    # Create a mock action plugin.
    action_plugin = MockActionPlugin()

    # Create a mock action module.
    action_module = ActionModule(task, connection, loader, module_utils, action_plugin)



# Generated at 2022-06-17 09:58:35.373267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock ActionModule object
    action_module = ActionModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule object
    ansible

# Generated at 2022-06-17 09:58:36.400052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-17 09:58:38.265855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:58:39.325420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:58:49.867810
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:00:04.884237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = dict(
        action=dict(
            module_name='unarchive',
            module_args=dict(
                src='/path/to/source',
                dest='/path/to/dest',
                creates='/path/to/dest/file',
                remote_src=False,
                decrypt=True
            )
        )
    )

    # Create a mock connection object
    connection = dict(
        _shell=dict(
            tmpdir='/path/to/tmp',
            join_path=lambda *args: '/'.join(args)
        )
    )

    # Create a mock loader object
    loader = dict(
        get_real_file=lambda *args: args[0],
        path_dwim=lambda *args: args[0]
    )

   

# Generated at 2022-06-17 10:00:15.919094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 10:00:17.159325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 10:00:17.650050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:23.043748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Test with no args
    action_module = ActionModule()
    assert action_module is not None

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:00:34.031825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    module = ActionModule(
        task=dict(
            args=dict(
                src='/path/to/src',
                dest='/path/to/dest',
                remote_src=False,
                creates='/path/to/creates',
                decrypt=True
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module is not None

    # Test with invalid parameters

# Generated at 2022-06-17 10:00:35.742526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 10:00:36.488611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 10:00:39.948151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:00:47.499321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to pass to the ActionModule.
    task = mock.Mock()
    task.args = {'src': 'test_src', 'dest': 'test_dest'}

    # Create a mock connection to pass to the ActionModule.
    connection = mock.Mock()
    connection._shell.tmpdir = 'test_tmpdir'
    connection._shell.join_path.return_value = 'test_join_path'
    connection._shell.exists.return_value = True
    connection._shell.isdir.return_value = True
    connection._shell.stat.return_value = {'exists': True, 'isdir': True}
    connection._shell.expand_user.return_value = 'test_expand_user'
    connection._shell.remove.return_value = True

    # Create a

# Generated at 2022-06-17 10:03:45.694386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock module_utils object
    module_utils = MockModuleUtils()
    # Create a mock module_utils.basic object
    basic = MockBasic()
    # Create a mock module_utils.basic.AnsibleModule object
    ansible_module = MockAnsibleModule()
    # Create a mock module_utils.basic.AnsibleModule.fail_json object
    fail_json = MockFailJson()
    # Create a mock module_utils.basic.AnsibleModule.exit_json object
    exit_json = MockExitJson()
    # Create a mock module_utils.basic.AnsibleModule.run_command object

# Generated at 2022-06-17 10:03:55.832947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra