

# Generated at 2022-06-23 08:49:49.094529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Tester for constructor of the class ActionModule

    :return:
    '''
    module = ActionModule('localhost')
    assert module is not None

# Generated at 2022-06-23 08:49:52.905388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(src='.', dest='/tmp/')
    # TaskDefinition is a namedtuple, so can't create it directly,
    # so using its parent class, _TaskDefinition, instead.
    task_def = ActionBase._TaskDefinition(None, 'test', None)
    # AnsibleModule is an alias for AnsibleModuleApi
    ansible_module = {}
    remote_user = 'test_user'
    connection = {}
    action = ActionModule(task_def, ansible_module, remote_user, connection)
    assert action

# Generated at 2022-06-23 08:49:54.370644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:50:04.656347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test is based on Lib/ansible/plugins/action/copy.py
    # test_data/ansible_facts.json contains all the information you need
    # to mock a remote connection.
    config_path = path.join(path.dirname(__file__), 'test_data/ansible_facts.json')
    config = json.load(open(config_path))
    config['TERM'] = 'xterm'
    config['ANSIBLE_REMOTE_TEMP'] = '/home/user/.ansible/tmp'
    config['ANSIBLE_REMOTE_USER'] = 'user'
    config['ANSIBLE_REMOTE_PASS'] = 'pass'
    config['ANSIBLE_PERSISTENT_COMMAND_TIMEOUT'] = 0

# Generated at 2022-06-23 08:50:05.856626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:50:16.667779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import ansible.plugins.action
    global my_ActionModule
    global options
    global fake_executor
    global fake_task
    global fake_loader
    global fake_taskvars
    global fake_tmpdir
    global fake_module_vars
    global my_ActionBase
    global my_Action
    global my_ActionModuleFail
    global my_ActionModuleSkip
    global my_AnsibleError
    global my_AnsibleActionFail
    global my_AnsibleAction
    global my_AnsibleActionSkip
    fake_executor = object()
    fake_task = object()
    fake_loader = object()
    fake_taskvars = object()
    fake_tmpdir = object()
    fake_module_vars = object()

    # This is what get_action_plugin

# Generated at 2022-06-23 08:50:20.554447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for ActionModule class
    action_module = ActionModule()

    # Calling constructor of the superclass (ActionBase)
    action_base = ActionBase()

    # Checking the parameters of the constructor of the superclass
    if action_base != None:
        action_base == action_module

    return

# Generated at 2022-06-23 08:50:31.836859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = {}
    t['source'] = 'src'
    t['dest'] = 'dest'
    t['remote_src'] = False
    t['creates'] = 'creates'
    t['decrypt'] = True
    action = ActionModule()
    action._task = {}
    action._task.args = t
    action._connection = {}
    action._connection._shell = {}
    action._connection._shell.tmpdir = 'tmpdir'
    action._remote_expand_user = lambda _: 'remote_expand_user'
    action._remote_file_exists = lambda _: True
    action._task.args = {}
    action._task.args['src'] = 'src'
    action._task.args['dest'] = 'dest'
    action._task.args['remote_src'] = False
   

# Generated at 2022-06-23 08:50:33.630226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:50:34.562729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:50:35.273779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:50:42.042667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing functions in module ansible.plugins.action.unarchive')
    test_object = ActionModule({'src': 'test', 'dest': 'test'})
    print(test_object.run())
    print(test_object.run({'remote_src': False}))
    assert test_object.run() !=  test_object.run({'remote_src': False})

# Generated at 2022-06-23 08:50:49.139284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            args=dict(
                src="devel.tar.gz",
                dest="/home/dmartin",
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    return am

# Generated at 2022-06-23 08:50:52.519888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a dictionary "action_plugin" of ActionBase
    actionBase = ActionBase()

    # Test the constructor of ActionModule
    action = actionBase.load_action_plugin()

    assert isinstance(action, ActionModule), "Not instance of class ActionModule."
    assert action.__class__.__name__ == "ActionModule", \
        "__class__.__name__ is not ActionModule (%s)." % action.__class__.__name__



# Generated at 2022-06-23 08:50:54.262583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-23 08:51:03.809558
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    task_vars = {
        'role_path': './tests/lib/ansible/roles/test_role_unarchive',
        'my_var': 'my_value'
    }

    # test with a file value for 'src'
    task_args = {
        'src': './tests/lib/ansible/roles/test_role_unarchive/test_dir/test_file.tar',
        'dest': '/tmp/test_dest',
        'creates': '/tmp/test_dest/test_file',
        'remote_src': False
    }

    result = module.run(
        tmp='./tests/lib/ansible/roles/test_role_unarchive/test_dir/',
        task_vars=task_vars
    )



# Generated at 2022-06-23 08:51:06.477816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myHost = "localhost"
    myHost2 = "otherhost"
    myUser = "myuser"
    myRoot = '/tmp/'
    task = {'args': {'src': myHost, 'dest': myHost2, 'follow': True, 'creates': myUser}, 'delegate_to': myRoot}
    result = ActionModule(task, myHost).run()
    assert(result["invocation"])


# Generated at 2022-06-23 08:51:16.001872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This method is for unittest.
    There is no assert in this method.
    If this method works well, it returns normally.
    """
    # Testing following variables
    test_copy = False
    test_dest = '/home/ansible'
    test_remote_src = False
    test_src = '/etc/ansible'
    test_creates = 'test.txt'
    test_decrypt = True

    # Initialize an object of class ActionModule.
    am = ActionModule()

    class TestActionModule(object):
        args = {'src': test_src,
                'dest': test_dest,
                'remote_src': test_remote_src,
                'creates': test_creates,
                'decrypt': test_decrypt
                }


# Generated at 2022-06-23 08:51:26.539434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run()")

    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a connection for tests
    from ansible.plugins.connection.ssh import Connection

    # Create a task object for tests.
    task = Task()
    task._role = None
    task.args = {}
    task._task_vars = dict()
    task._variable_manager = VariableManager()
    task._loader = DataLoader()

    # Create an inventory for tests.
    inventory = InventoryManager(loader=task._loader, sources=['localhost'])
    inventory.subset("ungrouped")

    # Create a connection included in the inventory

# Generated at 2022-06-23 08:51:34.895758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(task=dict(args=dict(src='tests/test1.txt', dest='/home/test')), connection=None,
                                      play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert test_action_module._task.args['src'], 'tests/test1.txt'
    assert test_action_module._task.args['dest'], '/home/test'

# Generated at 2022-06-23 08:51:43.254962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_args = {'a': 'A', 'b': 'B'}
    test_task = {'action': 'test_unarchive', 'args': test_args}
    test_loader = {}
    test_templar = {}
    test_shared_loader_obj = None
    test_play_context = {'remote_addr': 'localhost', 'password': 'abc123'}
    test_connection = {}
    test_play = {'name': 'test_play', 'hosts': ['localhost']}
    test_set_remote_user = {}


# Generated at 2022-06-23 08:51:45.123984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-23 08:51:47.557589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = Mock()
    mock_task.args = {}
    my_action_module = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    my_action_module.run()

# Generated at 2022-06-23 08:51:55.970255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test of basic structure of ActionModule

    This is for illustration purposes only.
    """
    class connection(object): 
        """ 
        Basic structure of connection object 
        from ansible.executor.connection_info.Connection
        """
        def __init__(self):
            self._shell = shell()

        def _execute_remote_stat(self):
            pass

        def _execute_module(self):
            pass

        def _remote_expand_user(self):
            pass

        def _remote_file_exists(self):
            pass

        def _transfer_file(self):
            pass

        def _fixup_perms2(self):
            pass

        def _remove_tmp_path(self):
            pass
    

# Generated at 2022-06-23 08:52:04.435707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeModule:
        class Task:
            args = {'dest': '/tmp/mytestuser-20180801-041752-60367-25v2kh', 'src': '~/ansible-test-data/test.tar.gz', 'remote_src': True}
        class Connection:
            _shell = FakeShell()
        class PlayContext:
            check_mode = False
        name = 'mytestuser'

    mymodule = ActionModule(FakeModule())
    print('ActionModule:', mymodule)


# Class for supporting unit testing of ActionModule class

# Generated at 2022-06-23 08:52:14.743113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # AnsibleModule.__init__(
    #     self, argument_spec=dict(
    #         src=dict(type='path'),
    #         dest=dict(type='path', required=True),
    #         copy=dict(type='bool', default=False),
    #         creates=dict(type='path'),
    #         list_files=dict(type='bool', default=False, aliases=['list']),
    #     ),
    #     supports_check_mode=True
    # )


# Generated at 2022-06-23 08:52:17.008647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Tests instantiation of ActionModule.
    module = ActionModule()

    # Check that instance of ActionModule is correct type.
    assert(isinstance(module, ActionModule))

# Generated at 2022-06-23 08:52:28.273167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test class ActionModule
    '''

    import ansible.utils.template as template

    # create an ActionModule object
    am = ActionModule()

    # create a test dictionary to hold args for the run method
    args = dict()

    # create a test dictionary to hold temporary variables for the run method
    tmp = dict()

    # set a test value for the remote_src key in the args dictionary
    remote_src = True

    # set a test value for the copy key in the args dictionary
    copy = False

    # set a test value for the src key in the args dictionary
    src = None

    # create a test dictionary to hold task variables for the run method
    task_vars = dict()

    # create a test value for the 'all_vars' parameter of the _execute_remote_stat method
    all_v

# Generated at 2022-06-23 08:52:34.634092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate instance of ActionModule class
    action_module_instance = ActionModule(
        task=dict(action='copy'),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    # Test properties of instance
    assert action_module_instance.TRANSFERS_FILES == True

# Generated at 2022-06-23 08:52:42.533220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    class TestActionModuleRun(unittest.TestCase):
        def setUp(self):
            import os
            import tempfile
            self.tmpdir = tempfile.mkdtemp()
            self.tempdir = tempfile.mkdtemp(dir=self.tmpdir)
            self.testdir = tempfile.mkdtemp(dir=self.tmpdir)
            self.testfile = os.path.join(self.testdir, 'testfile')
            with open(self.testfile, 'w') as f:
                f.write('')
            self.unarchivedest = tempfile.mkdtemp(dir=self.tmpdir)
            self.unarchivedestfile = os.path.join(self.unarchivedest, 'testfile')

# Generated at 2022-06-23 08:52:44.954133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an empty instance of ActionModule
    # This does not call the base class constructor
    # as it's just used for type hinting and IDEs
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 08:52:48.976099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, {})
    assert action.TRANSFERS_FILES is True
    assert action.HAS_TEST is None

# Generated at 2022-06-23 08:52:57.868173
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import ActionModule
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class Executor(object):
        def __init__(self):
            self._hosts = [None, 'host1', 'host2']
            self._hosts_all = ['host1', 'host2']
            self._hosts_remaining = ['host1', 'host2']
            self._host_vars = {'host1' : {'ansible_os_family': 'RedHat'}, 'host2' : {'ansible_os_family': 'Debian'}}

# Generated at 2022-06-23 08:52:59.822987
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module = ActionModule()
  assert module is not None
  assert hasattr(module, 'action_implementation')

# Generated at 2022-06-23 08:53:07.181273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule and have it create a fake
    # remote_stat, and fake remote_expand_user.
    fake_execute_remote_stat = ActionModule(remote_expand_user=lambda self, dest: dest)
    fake_execute_remote_stat._execute_remote_stat = lambda self, dest, all_vars, follow: {'exists': True, 'isdir': True}

    # Create a module with params and have it assign this
    # fake remote_stat and remote_expand_user to the
    # _execute_remote_stat and _remote_expand_user.

# Generated at 2022-06-23 08:53:18.315440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import module_finder


# Generated at 2022-06-23 08:53:19.910670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:53:21.753416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert("ActionModule" in str(a))

# Generated at 2022-06-23 08:53:27.983605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
        'args': {
            'src': '../test-files/test.zip',
            'dest': '~/test/',
            'copy': 'no',
            'remote_src': 'no',
            'creates': '~/test/test.txt',
            'decrypt': 'yes',
        }
    }
    module = ActionModule(task, None)
    assert module._task == task


# Generated at 2022-06-23 08:53:39.312910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils
    import ansible.parsing.yaml
    import ansible.vars
    import ansible.constants
    import ansible.plugins.action
    import ansible.playbook.task

    # Create an instance of ActionModule class
    action_module = ansible.plugins.action.ActionModule()

    # Set the data structure to be used by the action plugin.
    result = ansible.utils.unsafe_proxy.AnsibleUnsafeProxy(ansible.utils.unsafe_proxy.UnsafeDict({
        'data': {}}))

    if not hasattr(ActionModule, '_execute_module'):
        action_module._execute_module = ansible.plugins.action.ActionModule._execute_module


# Generated at 2022-06-23 08:53:47.807422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = '/example/path/archive.tar.gz'
    dest = '/home/user/destination/dir'
    remote_src = False
    creates = None
    decrypt = True
    tmp = None
    task_vars = dict()

    # The first parameter, `tmp`, is ignored.
    action_module = ActionModule(None, {'src': source, 'dest': dest, 'remote_src': remote_src, 'creates': creates, 'decrypt': decrypt})
    action_module.run(tmp, task_vars)
    assert True

# Generated at 2022-06-23 08:53:55.528093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor class ActionModule
    '''
    module = ActionModule()
    assert module.run() == None
    assert module.run(tmp=True) == None
    assert module.run(tmp=False) == None
    assert module.run(tmp=100) == None
    assert module.run(tmp=0) == None
    assert module.run(tmp=1.0) == None
    assert module.run(tmp=1.0) == None
    assert module.run(tmp=1.0) == None

# Generated at 2022-06-23 08:53:57.008798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule('', '')
    am.run()

# Generated at 2022-06-23 08:54:04.147493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    # Setup ActionBase mock object
    actionBase = AnsibleActionBase()
    actionBase.setup(actionBase._connection)
    # Setup Task mock object
    task = AnsibleTask()
    task.setup(actionBase, task)
    # Setup ActionModule Object
    actionModule = ActionModule(task, actionBase._connection, actionBase._play_context, actionBase._loader, actionBase._templar, actionBase._shared_loader_obj)
    assert actionModule.run(tmp='', task_vars='haha')

# Generated at 2022-06-23 08:54:17.157209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os

    if os.path.exists("/tmp/ansible_unarchive_src"):
        os.remove("/tmp/ansible_unarchive_src")
    if os.path.exists("/tmp/ansible_unarchive_src2"):
        os.remove("/tmp/ansible_unarchive_src2")
    if os.path.exists("/tmp/ansible_unarchive_dest"):
        os.removedirs("/tmp/ansible_unarchive_dest")
    if os.path.exists("/tmp/ansible_unarchive_dest2"):
        os.removedirs("/tmp/ansible_unarchive_dest2")


# Generated at 2022-06-23 08:54:28.436853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running test_ActionModule_run")

    # Test throwing ActionFail error.
    print("Test throwing ActionFail error.")
    try:
        action_module = ActionModule()
        # Set attributes of ActionModule class
        action_module.action = 'unarchive'
        action_module._task = {}
        action_module._task.action = 'copy'
        action_module._task.args = {}
        action_module._task.args['src'] = 'src'
        action_module._task.args['dest'] = 'dest'
        action_module._task.args['chmod'] = 'chmod'

        action_module.run()
    except AnsibleActionFail as e:
        assert "Parameters are mutually exclusive" in str(e)

    # Test throwing ActionSkip error.
    print("Test throwing ActionSkip error.")


# Generated at 2022-06-23 08:54:29.889026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests are needed. This class is only a wrapper.
    assert True == True

# Generated at 2022-06-23 08:54:41.391106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test the action module with a (src, dest) tuple
    # CCTODO: This is not a functional unit test.
    action_module._task.args = {'src': '/path/to/src/dir', 'dest': '/path/to/dest/dir'}
    action_module._task.action = 'unarchive'
    action_module.run(task_vars={'ansible_ssh_user': 'root', 'ansible_ssh_pass': 'pass'})

    # Test the action module with a (remote_src, src, dest) tuple
    action_module._task.args = {'remote_src': True, 'src': '/path/to/src/dir', 'dest': '/path/to/dest/dir'}

# Generated at 2022-06-23 08:54:50.278721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Inventory object
    inventory = [{
        'host_name': 'example.com',
        'connection': 'local',
        'gather_facts': False,
        'name': 'example.com'
    }]

    # Task object
    task = [{
        'name': 'Test',
        'connection': 'local',
        'hosts': 'example.com',
        '${module}_options': {},
        'action': 'Test',
        'local_action': None,
        'args': {'src': '$path/to/file', 'dest': '$path/to/dir'}
    }]

    # Playbook object

# Generated at 2022-06-23 08:54:59.888872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock = {
        'user': 'testuser',
        'group': 'testgroup',
        'uid': '1001',
        'gid': '1001'
    }
    class ActionModuleTest(ActionModule):
        def _remote_expand_user(self, x):
            return x
        def _remote_file_exists(self, x):
            return boolean(x, strict=False)

        # Always return the mock stat data
        def _execute_remote_stat(self, x, all_vars=None, follow=False):
            return mock

        # Simulate this is a slow, remote connection
        def _execute_module(self, module_name=None, module_args=None, task_vars=None):
            return {'rc': 0}


# Generated at 2022-06-23 08:55:11.994029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from random import randint
    from unittest.mock import MagicMock
    from ansible.plugins.action.unarchive import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar


# Generated at 2022-06-23 08:55:22.623356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
    )

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='unarchive', src="file", dest="/tmp"), register='shell_out'),
            ]
        )


# Generated at 2022-06-23 08:55:29.213598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action
    am = action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not am.TRANSFERS_FILES

# Generated at 2022-06-23 08:55:36.078287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dest = 'test-test'
    source = './test-test/test-test/test'
    remote_src = False
    creates = 'test.txt'
    decrypt = True

    task = {'args': {'dest': dest, 'src': source, 'remote_src': remote_src, 'creates': creates, 'decrypt': decrypt}}
    am = ActionModule(task, None)
    am.run()

# Generated at 2022-06-23 08:55:46.867803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock

    class ActionModuleMock(ActionModule):
        def __init__(self, *args, **kwargs):
            self.tmp_paths = []
            super(ActionModuleMock, self).__init__(*args, **kwargs)

        def _fixup_perms2(self, paths):
            for path in paths:
                pass

        def _execute_module(self, module_name, module_args, task_vars):
            return {}

    class ConnectionMock(mock.MagicMock):
        def _shell(self):
            return '/tmp/'


# Generated at 2022-06-23 08:55:49.536667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Not implemented, as the class requires ansible.legacy.unarchive
    pass

# Generated at 2022-06-23 08:56:00.794450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate mock objects for testing.
    host_vars = dict()
    task_vars = dict(hostvars=host_vars)
    action_base = ActionBase()
    connection = action_base._shared_loader_obj.connection_loader.get('local', task_vars=task_vars)
    display = action_base._shared_loader_obj.display
    task = action_base._task
    args = {'dest': 'a', 'remote_src': True, 'creates': 'a', 'decrypt': False}
    task.args = args
    # Create the class object.
    action_module = ActionModule(connection=connection, display=display, task=task)
    # The task object has been initialized and the value of enables_plugins has been set.
    # The _execute_module method is being

# Generated at 2022-06-23 08:56:03.308467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No unit test is implemented for method run of class ActionModule"


# Generated at 2022-06-23 08:56:05.170248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing without the creation of a file.
    assert True



# Generated at 2022-06-23 08:56:13.392005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict()
    _task['action'] = dict()
    _task['action']['args'] = dict()
    _task['action']['module_name'] = 'ansible.legacy.unarchive'
    _inject = dict(task=_task, tmp=None, task_vars=None)
    _am = ActionModule(**_inject)
    _am.run()

# Generated at 2022-06-23 08:56:21.543103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # set up args to be passed to the AnsibleModule
    args = dict(
    )

    # set up ansible options
    opts = dict(
        connection='smart',
        module_path=['/to/mymodules'],
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
    )
    
    # run the action module unarchive
    action = ActionModule(
        connection=None,
        task_vars=dict(
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    
    action.run(args, opts)

# Generated at 2022-06-23 08:56:22.395690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError


# Generated at 2022-06-23 08:56:30.156860
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:56:31.174652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 08:56:44.167542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class DummyTask:
        pass

    class DummyVars:
        pass

    class DummyPlay:
        pass

    d = DummyTask()
    d.args = {}
    d.args['src'] = 'c:/mypath/myfile'
    d.args['remote_src'] = False
    d.args['dest'] = 'c:/tmp'
    d.args['creates'] = 'c:/tmp/test.txt'
    d.args['decrypt'] = True

    vars = DummyVars()
    vars.module_args = {'test': True}
    vars.task_vars = {'hostvars': {}}

    p = DummyPlay()
    am = ActionModule(d, p, vars=vars)
    result = am.run()

    assert result

# Generated at 2022-06-23 08:56:56.517141
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    dest = 'test/test_dir'
    source = 'test_dir.tar.gz'
    module_args = {
        'decrypt': 'yes',
        'dest': dest,
        'src': source,
        'remote_src': 'no',
        'creates': None
    }

    origin_remote_expand_user = ActionModule._remote_expand_user
    origin_remote_file_exists = ActionModule._remote_file_exists
    origin_execute_remote_stat = ActionModule._execute_remote_stat
    origin_find_needle = ActionModule._find_needle
    origin_transfer_file = ActionModule._transfer_file
    origin_fixup_perms2 = ActionModule._fixup_perms2
    origin_execute_module = ActionModule._execute_module
    origin_

# Generated at 2022-06-23 08:57:00.840868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    ActionModule.run() Test Case
    '''
    # Parameters:
    #   tmp=None
    #   task_vars=None

    # TODO: not implemented
    return None

# Generated at 2022-06-23 08:57:10.518750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    

# Generated at 2022-06-23 08:57:11.179535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:57:15.464141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    action_module = ActionModule(task, dict())
    assert action_module is not None
    assert action_module.TRANSFERS_FILES



# Generated at 2022-06-23 08:57:25.733546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import unittest.mock as mock
    import random
    import string

    random_test_string = lambda n: ''.join(
        random.choice(string.ascii_lowercase) for i in range(n))

    # mark module_utils._text as mock
    mock_text = mock.Mock()
    sys.modules['ansible.module_utils._text'] = mock_text

    # set up mock of class ActionBase
    mock_ActionBase = mock.Mock()
    mock_ActionBase.run = mock.Mock(return_value={})

    # set up mock of class ActionModule
    mock_ActionModule = mock.Mock()
    mock_ActionModule.__bases__ = (mock_ActionBase,)
    mock_ActionModule.run = mock_ActionModule.__bases

# Generated at 2022-06-23 08:57:31.255596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
        Constructor for ActionModule
    '''
    module = ActionModule({}, {})
    assert isinstance(module, ActionModule)



# Generated at 2022-06-23 08:57:43.163857
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:57:44.959213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    [summary]

    :return: [description]
    :rtype: [type]
    '''
    pass

# Generated at 2022-06-23 08:57:45.739232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-23 08:57:46.327036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:58:00.128536
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # https://github.com/ansible/ansible/issues/30268
    if not os.path.exists(os.path.join('test', 'lib', 'ansible_module_unarchive', 'test_data', 'gpl-3.0.txt')):
        raise AssertionError("Unit test test_ActionModule_run() requires the file 'test/lib/ansible_module_unarchive/test_data/gpl-3.0.txt'.")

    from ansible.plugins.terminal import TerminalPlugin
    from ansible.plugins.action import ActionBase
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    import ansible.release
    from ansible.module_utils.basic import AnsibleModule, missing

# Generated at 2022-06-23 08:58:12.444647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test for method run'''
    # Setup
    action = ActionModule()
    action._task = {}
    action._task.args = {}
    action._task.args['src'] = 'src'
    action._task.args['dest'] = 'dest'
    action._task.args['remote_src'] = False
    action._task.args['creates'] = None
    action._task.args['decrypt'] = True
    action._connection = {'_shell': {'join_path': join_path}}
    action._connection._shell.tmpdir = 'tmpdir'
    action._check_mode = False
    action._diff = False
    action._loader = {'get_real_file': get_real_file}
    action._remote_expand_user = remote_expand_user
    action._remote_

# Generated at 2022-06-23 08:58:18.972875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(), connection=dict(), play_context=dict(), loader=None,
        templar=None, shared_loader_obj=None)
    response = action.run(tmp='', task_vars=dict())

    assert(response == {})
    assert(action.TRANSFERS_FILES is True)

# Generated at 2022-06-23 08:58:30.908324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor takes a single argument - Task.
    # self._task.action = 'unarchive'
    # self._task.args = dict()
    # self._task.args['content'] = 'hello'
    # self._task.args['dest'] = 'world'
    # self._task.args['decrypt'] = 'True'
    # self._task.args['creates'] = 'woo'
    from ansible.task import Task
    from ansible.playbook.task import Task as TaskPlaybook
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    t = Task()
    t.action = 'unarchive'
    t.args = dict()
    t.args

# Generated at 2022-06-23 08:58:42.000812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run._original_unarchive_module = copy.deepcopy(unarchive_module)
    unarchive_module['args'] = {
        'dest': 'C:/Windows/Temp',
        'creates': 'C:\\Windows\\Temp\\tmp_file',
        'decrypt': False,
        'remote_src': False,
        'src': 'src/test_support/test_unarchive/test_module_unarchive.zip'
    }

# Generated at 2022-06-23 08:58:44.797612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

if __name__ == '__main__':
    import sys
    import unittest
    sys.exit(unittest.main())

# Generated at 2022-06-23 08:58:46.718192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:58:47.882919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule  # please pal, don't crash

# Generated at 2022-06-23 08:58:49.245726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:58:59.706864
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # pylint: disable=R0914
    '''Unit test for method run of class ActionModule.

    If this is called when the test data is present, this will run the
    module and show the difference in the results.

    The arguments are the same as the AnsibleModule.exit_json method.
    '''
    # pylint: disable=too-many-locals

    # Make this module run when the test data is present.
    if not os.environ.get('ANSIBLE_UNIT_TEST_DATA'):
        raise RuntimeError('ANSIBLE_UNIT_TEST_DATA is not in the environment')

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action.unarchive import ActionModule

    # Create an empty Mock for

# Generated at 2022-06-23 08:59:04.082909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    try:
        # Attempt to instantiate ActionModule object.
        action_module_obj = ActionModule(None, None, None, None)
    except Exception:
        # Raise exception if instantiated without AnsibleAction object.
        assert False, "Unit test for constructor of class ActionModule has failed."
        raise
    # Raise exception if instantiated without AnsibleAction object.
    assert True, "Unit test for constructor of class ActionModule has passed."

# Generated at 2022-06-23 08:59:15.974263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define variables
    setattr(ActionModule, '_connection', None)
    setattr(ActionModule, '_task', None)
    setattr(ActionModule, '_loader', None)
    setattr(ActionModule, '_templar', None)
    setattr(ActionModule, '_shared_loader_obj', None)
    setattr(ActionModule, '_filter_loader', None)
    setattr(ActionModule, '_action_loader', None)
    setattr(ActionModule, '_loader_cache', {})

    # Fails
    # Initialization method is not supposed to have arguments
    assert action_module.ActionModule(ActionModule, '_connection') == 1

    # Initialization method is not supposed to have arguments
    assert action_module.ActionModule() == 1

    # Should return a object of type '

# Generated at 2022-06-23 08:59:16.850927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-23 08:59:19.389352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule
    except NameError:
        assert False, "Unable to instantiate ActionModule"

# Generated at 2022-06-23 08:59:25.237877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    # Setup test
    # These are here to test the method.
    result = {}
    tmp = None
    task_vars = None
    new_module_args = {}
    # Run method
    ActionModule.run(result,tmp,task_vars,new_module_args)
    # Check results
   


# Generated at 2022-06-23 08:59:30.415918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, final_q=None, loader_cache=None)
    assert action_module is not None

# Generated at 2022-06-23 08:59:41.964267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.legacy.unarchive as unarchive

# Generated at 2022-06-23 08:59:48.948953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup args for testing
    test_args = {'src' : '/home/dylan/test_src',
                 'dest' : '/home/dylan/test_dest',
                 'remote_src' : 'False',
                 'copy' : 'False'
                }

    # create an instance of ActionModule
    test_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_instance._task.args = test_args

    # test the return from the run method
    assert test_instance.run()['failed'] == False