

# Generated at 2022-06-16 21:05:30.820021
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:41.378203
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None

    # Test with an invalid name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:05:45.054093
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:05:54.979309
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:00.708662
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()
    # Create a module_data
    module_data = b'#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n'
    # Call method scan_module
    ps_module_dep_finder.scan_module(module_data)
    # Assert that the ps_modules dict is not empty
    assert ps_module_dep_finder.ps_modules


# Generated at 2022-06-16 21:06:05.983365
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to ensure that scan_exec_script method of class PSModuleDepFinder works as expected
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("powershell_base")
    # Act
    ps_module_dep_finder.scan_exec_script("powershell_base")
    # Assert
    assert ps_module_dep_finder.exec_scripts["powershell_base"] is not None


# Generated at 2022-06-16 21:06:11.428238
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToXml"] is not None

# Generated at 2022-06-16 21:06:21.228867
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:24.928118
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented
    pass


# Generated at 2022-06-16 21:06:35.839907
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Setup
    finder = PSModuleDepFinder()

    # Test
    finder.scan_exec_script('basic')

    # Verify
    assert finder.exec_scripts['basic'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None

# Generated at 2022-06-16 21:06:52.845616
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a PSModuleDepFinder object
    finder = PSModuleDepFinder()
    # Create a module_data object
    module_data = b'#Requires -Module Ansible.ModuleUtils.{name}\n'
    # Call the scan_module method
    finder.scan_module(module_data)
    # Assert that the ps_modules dict is not empty
    assert finder.ps_modules


# Generated at 2022-06-16 21:06:57.707709
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"] is not None
    assert finder.exec_scripts["common"] != ""
    assert finder.exec_scripts["common"] != b''

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:06:59.422327
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented
    pass


# Generated at 2022-06-16 21:07:03.123469
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_name")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:07:15.532012
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#!/usr/bin/env pwsh\n\n')
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    # Test with a module that has a single dependency
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#!/usr/bin/env pwsh\n\n#Requires -Module Ansible.ModuleUtils.Test\n')


# Generated at 2022-06-16 21:07:26.280818
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:33.404721
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'#!/usr/bin/env powershell\n' \
                  b'\n' \
                  b'$ANSIBLE_METADATA = @{\n' \
                  b'    "status": ["preview"],\n' \
                  b'    "supported_by": "community",\n' \
                  b'    "metadata_version": "1.1"\n' \
                  b'}\n' \
                  b'\n' \
                  b'$ANSIBLE_MODULE_ARGS = @{\n' \
                  b'    "name": "test"\n' \
                  b'}\n' \
                  b'\n' \
                  b'Write-Output "Hello World!"\n'

    dep_finder = PSModuleDepFinder

# Generated at 2022-06-16 21:07:36.664279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_name")
        assert False, "AnsibleError was not raised"
    except AnsibleError:
        pass


# Generated at 2022-06-16 21:07:48.058380
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("ansible_powershell_common_invalid")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:07:56.203772
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:30.522069
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('win_command')
    assert dep_finder.exec_scripts['win_command'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertTo'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertFrom'] is not None

# Generated at 2022-06-16 21:08:42.621969
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:49.459080
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:00.733584
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ansible_powershell_common')
    assert finder.exec_scripts['ansible_powershell_common'] is not None
    assert len(finder.exec_scripts['ansible_powershell_common']) > 0
    assert finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert len(finder.ps_modules['Ansible.ModuleUtils.Common']['data']) > 0
    assert finder.ps_modules['Ansible.ModuleUtils.Common']['path'] is not None
    assert len(finder.ps_modules['Ansible.ModuleUtils.Common']['path']) > 0

    # Test with an invalid script

# Generated at 2022-06-16 21:09:15.226293
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:25.343430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.exec_scripts["common"] != ""

    # Test with an invalid name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_name")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:09:39.152300
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:50.657468
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:09:59.372291
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_powershell_common')
    assert dep_finder.exec_scripts['ansible_powershell_common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertTo'] is not None

# Generated at 2022-06-16 21:10:09.793803
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:43.396404
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_base')
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:10:55.987440
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test that the method scan_module of class PSModuleDepFinder
    # returns the expected value.
    #
    # Args:
    #   module_data: The module_data to pass to the method.
    #   fqn: The fqn to pass to the method.
    #   wrapper: The wrapper to pass to the method.
    #   powershell: The powershell to pass to the method.
    #
    # Returns:
    #   The expected value.

    # Test with module_data = '#Requires -Module Ansible.ModuleUtils.{name}'
    # and fqn = 'Ansible.ModuleUtils.{name}' and wrapper = False and powershell = True
    module_data = '#Requires -Module Ansible.ModuleUtils.{name}'

# Generated at 2022-06-16 21:10:59.279412
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:11:10.556089
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Create a module_data
    module_data = b'#Requires -Module Ansible.ModuleUtils.Test'

    # Call scan_module method of class PSModuleDepFinder
    ps_module_dep_finder.scan_module(module_data)

    # Assert that the ps_modules dict is not empty
    assert ps_module_dep_finder.ps_modules

    # Assert that the ps_modules dict contains the module_util

# Generated at 2022-06-16 21:11:18.384737
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFrom"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert finder

# Generated at 2022-06-16 21:11:32.267310
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for scan_module method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:11:42.894487
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

param()

Write-Host "Hello World"
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:11:46.335387
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:11:50.314710
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("powershell_base")
    except AnsibleError:
        assert False, "AnsibleError raised"


# Generated at 2022-06-16 21:12:00.329407
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Process"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Url"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Win32"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Win32.File"] is not None
    assert finder.ps_modules

# Generated at 2022-06-16 21:12:33.888123
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    # This method is used to scan a module for any dependencies
    # It is used to generate the module_utils.psm1 file for a module
    # It is also used by validate-modules to get a module's required utils in base and a collection.

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create a module_data string
    # This is the data that would be read from a module

# Generated at 2022-06-16 21:12:36.818585
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test is not currently implemented
    pass


# Generated at 2022-06-16 21:12:42.519213
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:54.415142
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("powershell.ps1")
    assert ps_module_dep_finder.exec_scripts["powershell.ps1"] == b'#!/usr/bin/env pwsh\n\n$ErrorActionPreference = "Stop"\n\n$PSVersionTable\n\n'
    assert ps_module_dep_finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]["data"] == b'#!/usr/bin/env pwsh\n\n$ErrorActionPreference = "Stop"\n\n$PSVersionTable\n\n'

# Generated at 2022-06-16 21:13:03.955339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_powershell_common')
    assert 'ansible_powershell_common' in dep_finder.exec_scripts
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.common' in dep_finder.ps_modules

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('ansible_powershell_common_invalid')
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:17.018594
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:26.742278
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:39.861094
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script("powershell_base")

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script("powershell_base")

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script("powershell_base")

    # Test that scan_exec_script does not

# Generated at 2022-06-16 21:13:46.278801
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script("basic")


# Generated at 2022-06-16 21:13:59.707464
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:15:00.669408
# Unit test for method scan_exec_script of class PSModuleDepFinder