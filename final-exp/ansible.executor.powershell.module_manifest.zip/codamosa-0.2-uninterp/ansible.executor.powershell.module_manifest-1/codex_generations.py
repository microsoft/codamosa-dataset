

# Generated at 2022-06-16 21:05:31.156300
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:05:42.794671
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:46.884521
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b'#!/usr/bin/env pwsh\n'


# Generated at 2022-06-16 21:05:52.378690
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:56.710053
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:05.216630
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a non-existent script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("non-existent-script")
        assert False, "Expected AnsibleError"
    except AnsibleError:
        pass

    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None

# Generated at 2022-06-16 21:06:18.028860
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:31.201265
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a unit test for the scan_exec_script method of the
    # PSModuleDepFinder class. It is used to test the functionality of the
    # method.
    #
    # Args:
    #    name (str): The name of the script to scan
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create a test script
    test_script = '#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test'

# Generated at 2022-06-16 21:06:34.573327
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() returns the expected value
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"#!/usr/bin/env pwsh\n"


# Generated at 2022-06-16 21:06:37.062516
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for scan_module
    #
    # Setup:
    #
    # Exercise:
    #
    # Verify:
    #
    # Cleanup:
    #
    # Result:
    pass


# Generated at 2022-06-16 21:07:02.051512
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:10.757013
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:15.731967
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        finder.scan_exec_script('not_a_script')


# Generated at 2022-06-16 21:07:26.326354
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:39.660066
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:52.110457
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
    #!/usr/bin/env powershell
    '''
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    # Test with a module that has a single dependency
    module_data = b'''
    #!/usr/bin/env powershell
    #Requires -Module Ansible.ModuleUtils.TestModule
    '''


# Generated at 2022-06-16 21:08:01.487824
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:08.839514
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:13.846151
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('powershell_base')
    assert ps_module_dep_finder.exec_scripts['powershell_base'] == b'#!/usr/bin/env pwsh\n\n'


# Generated at 2022-06-16 21:08:20.962573
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:08:45.128115
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:57.613482
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:05.935458
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:20.078079
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_wrapper")
    assert finder.exec_scripts["powershell_wrapper"]
    assert finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Errors"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.File"]
    assert find

# Generated at 2022-06-16 21:09:23.933554
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:09:37.578602
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_wrapper")
    assert dep_finder.exec_scripts["powershell_wrapper"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToYaml"]

# Generated at 2022-06-16 21:09:42.746551
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False
    except AnsibleError:
        assert True
    # Test that scan_exec_script does not raise an error when the script is found
    finder.scan_exec_script("powershell_base")
    assert True


# Generated at 2022-06-16 21:09:52.527537
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:00.472213
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:09.169689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_powershell_common')
    assert dep_finder.exec_scripts['ansible_powershell_common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common'] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('ansible_powershell_common_invalid')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:10:27.566510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')
    assert dep_finder.exec_scripts['test_script'] == b'Test script\n'

    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script('invalid_script')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:10:31.422620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    assert False


# Generated at 2022-06-16 21:10:39.076693
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('common')
    assert finder.exec_scripts['common'] is not None

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('invalid')
    except AnsibleError:
        assert True
    else:
        assert False



# Generated at 2022-06-16 21:10:47.999495
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:59.430678
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:01.616445
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:11:12.848609
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:15.037012
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test if the method scan_exec_script of class PSModuleDepFinder
    # can be called without error.
    # This is a dummy test.
    pass


# Generated at 2022-06-16 21:11:22.339186
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('not_a_script')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script adds the script to the exec_scripts dict
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')
    assert 'test_script' in dep_finder.exec_scripts.keys()

    # Test that scan_exec_script adds the script to the exec_scripts dict
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')

# Generated at 2022-06-16 21:11:34.256624
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:51.761367
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:55.810299
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test')
    assert finder.exec_scripts['test'] == b'#!/usr/bin/env python\n'
    assert finder.cs_utils_wrapper == {}
    assert finder.ps_modules == {}

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('invalid')
    except AnsibleError as e:
        assert str(e) == "Could not find executor powershell script for 'invalid'"
    else:
        assert False, "AnsibleError was not raised"


# Generated at 2022-06-16 21:12:06.170297
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:11.234976
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:12:15.039495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented
    pass


# Generated at 2022-06-16 21:12:26.302132
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False, "Expected an error to be raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert "test_script" in finder.exec_scripts.keys()

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert "test_script" in finder.exec_scripts.keys

# Generated at 2022-06-16 21:12:34.822425
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:44.179476
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.TestScript"] == {"data": b"test_script", "path": "test_script.psm1"}

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:12:55.424544
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:02.046377
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): name of the script to scan
    #
    # Raises:
    #    AnsibleError: if the script is not found
    #
    # Returns:
    #    None
    #
    # Example:
    #    name = 'script_name'
    #    scan_exec_script(name)
    pass


# Generated at 2022-06-16 21:13:25.616683
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:38.505804
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:48.189652
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:01.454685
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:13.631019
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:19.440973
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/python

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:14:28.497697
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that the method scan_exec_script of class PSModuleDepFinder
    # works as expected.

    # Arrange
    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Act
    # Call the method scan_exec_script of class PSModuleDepFinder
    dep_finder.scan_exec_script('test_script')

    # Assert
    # Check that the method scan_exec_script of class PSModuleDepFinder
    # works as expected.
    assert dep_finder.exec_scripts['test_script'] == b'Test script'


# Generated at 2022-06-16 21:14:40.551000
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_nice_formatted_text
    from ansible.module_utils.common.text.formatters import to_nice_csv
    from ansible.module_utils.common.text.formatters import to

# Generated at 2022-06-16 21:14:47.724455
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_wrapper")
    assert dep_finder.exec_scripts["powershell_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:14:53.133042
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_module_wrapper")
    assert dep_finder.exec_scripts["ansible_module_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True

