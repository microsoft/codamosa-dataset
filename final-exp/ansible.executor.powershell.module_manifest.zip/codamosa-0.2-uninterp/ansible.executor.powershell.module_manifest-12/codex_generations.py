

# Generated at 2022-06-16 21:05:36.044920
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:05:44.349555
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the case where the script is found
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test")
    assert dep_finder.exec_scripts["test"] == b"test"
    assert dep_finder.ps_modules["test"] == {"data": b"test", "path": "test"}

    # Test the case where the script is not found
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("test2")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'test2'" in to_text(e)
    else:
        assert False, "AnsibleError should have been raised"


# Generated at 2022-06-16 21:05:50.349368
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"#!/usr/bin/python\n"


# Generated at 2022-06-16 21:05:55.876345
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:04.487150
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:14.282503
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script_name")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:06:24.192940
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script returns the expected output
    # when given a valid input.
    #
    # Arrange
    #
    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Act
    #
    # Call scan_exec_script with a valid input
    ps_module_dep_finder.scan_exec_script("test")

    # Assert
    #
    # Check that the output is as expected
    assert ps_module_dep_finder.exec_scripts["test"] == b"#!/usr/bin/env powershell\n"


# Generated at 2022-06-16 21:06:35.543055
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:37.541795
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:06:43.432905
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    finder = PSModuleDepFinder()
    finder.scan_module(b'#!/usr/bin/python\n')
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin module_util
    finder = PSModuleDepFinder()
    finder.scan_module(b'#!/usr/bin/python\n#Requires -Module Ansible.ModuleUtils.Test')
    assert finder.ps_modules == {'Ansible.ModuleUtils.Test': {'data': b'#!/usr/bin/python\n', 'path': 'ansible/module_utils/Test.psm1'}}
   

# Generated at 2022-06-16 21:07:10.879530
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:22.763784
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Text"] is not None

# Generated at 2022-06-16 21:07:29.071791
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of PSModuleDepFinder class
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"#!/usr/bin/env pwsh\n"


# Generated at 2022-06-16 21:07:34.802981
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:48.680440
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:00.424572
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:08.154969
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:11.038860
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a test for the method scan_exec_script of class PSModuleDepFinder
    #
    # This test is not yet implemented.
    pass


# Generated at 2022-06-16 21:08:19.681993
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:30.919059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() correctly scans the powershell executor scripts
    # for any dependencies.
    #
    # This test is not exhaustive, it only tests the first dependency found in each
    # script.
    #
    # This test is also not testing the recursive nature of the scan_module() method
    # as that is tested in test_PSModuleDepFinder_scan_module().

    dep_finder = PSModuleDepFinder()

    # Test that the script is correctly loaded
    dep_finder.scan_exec_script("executor")
    assert dep_finder.exec_scripts["executor"] is not None

    # Test that the first dependency is found
    assert "Ansible.ModuleUtils.CommonUtils" in dep_finder.ps_modules.keys()

    # Test that the first dependency is found
    dep_finder

# Generated at 2022-06-16 21:08:47.979184
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:08:59.705898
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("does_not_exist")
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert "powershell_base" in finder.exec_scripts

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert "powershell_base" in finder.exec_scripts

# Generated at 2022-06-16 21:09:11.816599
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:09:25.257438
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:39.155040
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('does_not_exist')
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_base')
    assert 'powershell_base' in finder.exec_scripts

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    # and scans the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_base')

# Generated at 2022-06-16 21:09:40.998417
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:09:51.810143
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.1',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Output "Hello World"
'''
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)

    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

# Generated at 2022-06-16 21:09:59.985081
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:10.085787
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:23.655498
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Powershell.Common\n")
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Common']
    dep_finder.scan_module(b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.Common\n")
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Common']
    dep_finder.scan_module(b"#AnsibleRequires -PowerShell ansible_collections.test.test.plugins.module_utils.test\n")
    assert dep_finder.ps_modules['ansible_collections.test.test.plugins.module_utils.test']
    dep

# Generated at 2022-06-16 21:10:46.095396
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:58.265322
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFrom"] is not None

# Generated at 2022-06-16 21:11:04.569866
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "win_package"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts.get(name) is not None


# Generated at 2022-06-16 21:11:07.380466
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This is a test for the method scan_module of class PSModuleDepFinder
    # This test is not complete.
    # TODO: Complete this test.
    pass


# Generated at 2022-06-16 21:11:16.224917
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method of the PSModuleDepFinder class.
    #
    # Args:
    #     module_data (str): The module data to scan.
    #     fqn (str): The fully qualified name of the module.
    #     wrapper (bool): Whether the module is a wrapper.
    #     powershell (bool): Whether the module is a PowerShell module.
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    #
    # Example:
    #     test_PSModuleDepFinder_scan_module()
    #
    # Note:
    #     This method is not intended to be called directly.
    #
    # TODO:
    #     Add unit tests for this method.
    pass


# Generated at 2022-06-16 21:11:30.524460
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Output "Hello World"
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:11:39.099715
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:44.987599
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#!/usr/bin/env pwsh\n\nparam()\n')
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0

    # Test with a module that has a dependency on a builtin module_util
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#!/usr/bin/env pwsh\n\nparam()\n#Requires -Module Ansible.ModuleUtils.Foo\n')
    assert len(dep_finder.ps_modules) == 1

# Generated at 2022-06-16 21:11:56.051114
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:06.435298
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert finder.exec_scripts["exec_wrapper"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.File"]

# Generated at 2022-06-16 21:12:27.855324
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    #
    # Args:
    #     module_data (str): module data
    #     fqn (str): fully qualified name
    #     wrapper (bool): wrapper flag
    #     powershell (bool): powershell flag
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    #
    # Examples:
    #     None
    #
    # Test Cases:
    #     None
    #
    # Cleanup:
    #     None
    #
    # Comments:
    #     None
    #
    pass


# Generated at 2022-06-16 21:12:34.064262
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a test for the method scan_exec_script of class PSModuleDepFinder.
    # This test case is to test the functionality of the method scan_exec_script.
    #
    # This test case is to test the functionality of the method scan_exec_script.
    #
    # Returns:
    #
    #    None
    #
    # Raises:
    #
    #    None
    #
    pass


# Generated at 2022-06-16 21:12:44.678354
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

param(
    [Parameter(Mandatory=$true)]
    [string]
    $name
)

Write-Host "Hello $name"
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:12:55.696161
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:06.393806
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the method scan_exec_script of class PSModuleDepFinder
    # This method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    #
    # Input parameters:
    #   name: name of the script
    #
    # Expected result:
    #   None
    #
    # Possible side effects:
    #   None

    # Create an instance of the PSModuleDepFinder class
    ps_module_dep_finder = PSModuleDepFinder()

    # Call the method scan_exec_script with a valid name
    ps_module_dep_finder.scan_exec_script("ansible_module_common")

    # Call the method scan_exec_script with an invalid name

# Generated at 2022-06-16 21:13:18.742765
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFrom"] is not None

# Generated at 2022-06-16 21:13:27.734951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"] is not None

# Generated at 2022-06-16 21:13:35.925974
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"

    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:46.697516
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:00.025079
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:18.645197
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:30.008287
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a script that has no dependencies
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script_no_deps")
    assert dep_finder.exec_scripts["test_script_no_deps"] == b"test_script_no_deps"
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}

    # Test with a script that has a dependency
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script_with_deps")
    assert dep_finder.exec_scripts["test_script_with_deps"] == b"test_script_with_deps"
    assert dep_finder.ps

# Generated at 2022-06-16 21:14:42.287986
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:48.743927
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Url"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.WebRequest"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.WinRM"]

# Generated at 2022-06-16 21:14:55.113965
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("Ansible.ModuleUtils.Legacy.PSModule")
    assert finder.exec_scripts["Ansible.ModuleUtils.Legacy.PSModule"]
    assert finder.ps_modules["Ansible.ModuleUtils.Legacy.PSModule"]
    assert finder.ps_modules["Ansible.ModuleUtils.Legacy.PSModule"]["data"]
    assert finder.ps_modules["Ansible.ModuleUtils.Legacy.PSModule"]["path"]
    assert finder.ps_modules["Ansible.ModuleUtils.Legacy.PSModule"]["data"].startswith(b"#")

# Generated at 2022-06-16 21:14:57.119864
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:15:05.769330
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ansible_powershell_common')
    assert finder.exec_scripts['ansible_powershell_common'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Common'] is not None

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('ansible_powershell_common_invalid')
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass

