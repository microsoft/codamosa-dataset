

# Generated at 2022-06-16 21:05:42.796139
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:45.382348
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:52.920933
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error when the script is found
    try:
        finder.scan_exec_script("exec_wrapper")
    except AnsibleError:
        assert False, "AnsibleError raised"


# Generated at 2022-06-16 21:05:59.618251
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): The name of the script to scan
    #
    # Returns:
    #    None
    #
    # Raises:
    #    AnsibleError: If the script could not be found
    #
    # Examples:
    #    >>> from ansible.module_utils.powershell import PSModuleDepFinder
    #    >>> dep_finder = PSModuleDepFinder()
    #    >>> dep_finder.scan_exec_script('script_name')
    #
    pass



# Generated at 2022-06-16 21:06:05.905369
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:06:18.163990
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_real_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("powershell_base")
    except AnsibleError:
        assert False, "AnsibleError raised"

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:06:31.349133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test')
    assert dep_finder.exec_scripts['test'] == b'#!/usr/bin/env powershell\n'
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid')
    except AnsibleError as e:
        assert to_text(e) == "Could not find executor powershell script for 'invalid'"
    else:
        assert False, "AnsibleError was not raised"

    # Test with a

# Generated at 2022-06-16 21:06:37.780495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson.ConvertToJson"]

# Generated at 2022-06-16 21:06:43.615768
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = """
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Output $foo
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a single dependency

# Generated at 2022-06-16 21:06:50.262433
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This method is used to scan lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    #
    # Returns:
    #     None
    #
    # Raises:
    #     AnsibleError: If the script is not found
    pass


# Generated at 2022-06-16 21:07:28.390318
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not needed as the method is not used
    pass


# Generated at 2022-06-16 21:07:42.439955
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    finder = PSModuleDepFinder()
    finder.scan_module(b"#!/usr/bin/env powershell\n")
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util
    finder = PSModuleDepFinder()
    finder.scan_module(b"#!/usr/bin/env powershell\n#Requires -Module Ansible.ModuleUtils.Test\n")
    assert finder.ps_modules

# Generated at 2022-06-16 21:07:53.361160
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:05.282533
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:10.218554
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test case 1
    # Test that the scan_module method returns the correct module_utils
    # when scanning a module with no module_utils
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:08:19.043197
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:23.201787
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:08:29.034512
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = 'test'
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b'#!/usr/bin/env pwsh\n'


# Generated at 2022-06-16 21:08:35.211307
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module() method of PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Output $foo
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os

# Generated at 2022-06-16 21:08:46.069116
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    finder = PSModuleDepFinder()
    finder.scan_module(b'#!/usr/bin/env powershell\n')
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency
    finder = PSModuleDepFinder()
    finder.scan_module(b'#!/usr/bin/env powershell\n#Requires -Module Ansible.ModuleUtils.Test\n')

# Generated at 2022-06-16 21:09:16.610342
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test to ensure that the scan_module method of the PSModuleDepFinder class
    # works as expected.
    #
    # This test is not intended to be exhaustive, but rather to ensure that
    # the method works as expected.

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create a test module

# Generated at 2022-06-16 21:09:28.320697
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:42.192751
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:50.024486
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:58.923938
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:09.591371
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module with a module_data that has a C# util reference
    # and a PowerShell util reference
    module_data = b"""
#Requires -Module Ansible.ModuleUtils.Common
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.cs_util
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)

    assert finder.ps_modules == {
        'Ansible.ModuleUtils.Common': {
            'data': b'# This is a test\n',
            'path': 'ansible/module_utils/common.psm1',
        },
    }

# Generated at 2022-06-16 21:10:23.202063
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_script')
        assert False, "AnsibleError should be raised when script is not found"
    except AnsibleError:
        pass

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('script_loader')
    assert 'script_loader' in finder.exec_scripts.keys()

    # Test that scan_exec_script does not add the script to the exec_scripts dict
    # if it has already been added
    finder = PSModuleDepFinder()
    finder.scan_exec_script('script_loader')


# Generated at 2022-06-16 21:10:30.825015
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:42.867050
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson.ConvertToJson"]

# Generated at 2022-06-16 21:10:55.724770
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:21.026935
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a non-existent script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('non_existent_script')
        assert False, "AnsibleError was not raised"
    except AnsibleError:
        pass

    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script('basic')
    assert finder.exec_scripts['basic'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None

# Generated at 2022-06-16 21:11:27.198458
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): name of the script to scan
    #
    # Returns:
    #    None
    #
    # Raises:
    #    AnsibleError: if the script cannot be found
    #
    pass



# Generated at 2022-06-16 21:11:37.229075
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.cs_utils_wrapper["ansible_collections.ansible.builtin.plugins.module_utils.powershell.basic"] is not None
    assert dep_finder.cs_utils_wrapper["ansible_collections.ansible.builtin.plugins.module_utils.powershell.common"] is not None

# Generated at 2022-06-16 21:11:46.061038
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 1
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:11:56.983464
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create an instance of the PSModuleDepFinder class
    dep_finder = PSModuleDepFinder()

    # Scan the powershell script for the win_ping module
    dep_finder.scan_exec_script('win_ping')

    # Verify that the win_ping script was found
    assert 'win_ping' in dep_finder.exec_scripts

    # Verify that the win_ping script was found
    assert 'win_ping' in dep_finder.exec_scripts

    # Verify that the win_ping script was found
    assert 'win_ping' in dep_finder.exec_scripts

# Generated at 2022-06-16 21:12:07.262692
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:20.151603
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.1',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Host "Hello World"
'''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin module_util
    module_data

# Generated at 2022-06-16 21:12:30.576347
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo.String"]

# Generated at 2022-06-16 21:12:35.925187
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:41.561961
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import tempfile
    import shutil
    import sys
    import unittest

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import format_module_name
    from ansible.module_utils.common.text.formatters import format_module_utils_name
    from ansible.module_utils.common.text.formatters import format_powershell_module_name
    from ansible.module_utils.common.text.formatters import format_powershell_module_utils_name
    from ansible.module_utils.common.text.formatters import format_powershell_script_name

# Generated at 2022-06-16 21:13:16.773525
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a unit test for the method scan_exec_script of class PSModuleDepFinder
    # It is not meant to be run as part of the test suite
    #
    # To run this test, execute the following command:
    #
    #   python -m test.units.module_utils.powershell.test_PSModuleDepFinder
    #
    # The output of the test will be printed to the screen.
    #
    # If the test fails, the output will include a diff of the actual output
    # and the expected output.
    #
    # If the test succeeds, the output will be empty.

    # The following is the expected output of the test.
    expected_output = b''

    # The following is the actual output of the test.
    # If the test fails, a diff of the expected and actual output will be printed

# Generated at 2022-06-16 21:13:26.580885
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:33.932324
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"#!/usr/bin/python\n"


# Generated at 2022-06-16 21:13:45.790249
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test")
    assert finder.exec_scripts["test"] == b"#!/usr/bin/python\n"
    assert finder.ps_modules["Ansible.ModuleUtils.Test"]
    assert finder.ps_modules["Ansible.ModuleUtils.Test"]["data"] == b"#!/usr/bin/python\n"
    assert finder.ps_modules["Ansible.ModuleUtils.Test"]["path"] == "ansible/module_utils/test.psm1"

    # Test with an invalid script
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:13:58.919888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert finder.exec_scripts["test_script"] == b"Test script data"
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil"]["data"] == b"Test module util data"
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil"]["path"] == os.path.join(C.DEFAULT_MODULE_UTILS_PATH, "TestModuleUtil.psm1")
    assert finder.cs_utils_wrapper["ansible_collections.test_namespace.test_collection.plugins.module_utils.test_module_util"]["data"] == b"Test module util data"
   

# Generated at 2022-06-16 21:14:07.052701
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:16.062597
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_args

# Generated at 2022-06-16 21:14:28.176166
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:33.099218
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script with a valid name
    ps_module_dep_finder.scan_exec_script("common")

    # Test scan_exec_script with an invalid name
    try:
        ps_module_dep_finder.scan_exec_script("invalid")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:14:42.363124
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) > 0
    assert len(dep_finder.cs_utils_wrapper) > 0

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("ansible_powershell_common_invalid")
        assert False
    except AnsibleError:
        assert True

