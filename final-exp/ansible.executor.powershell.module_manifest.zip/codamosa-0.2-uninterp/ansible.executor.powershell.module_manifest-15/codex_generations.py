

# Generated at 2022-06-16 21:05:36.402155
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Url"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Win32"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Win32.Registry"]

# Generated at 2022-06-16 21:05:39.305077
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a unit test for method scan_exec_script of class PSModuleDepFinder
    # This test is not complete
    # TODO: Complete this unit test
    pass


# Generated at 2022-06-16 21:05:44.748281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script_data"

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:05:54.704901
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a non-existing script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("non-existing-script")
        assert False, "AnsibleError was not raised"
    except AnsibleError:
        pass

    # Test with a script that exists
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]

# Generated at 2022-06-16 21:06:03.320124
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:09.842922
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:13.467868
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test')
    assert finder.exec_scripts['test'] == b'#!/usr/bin/python\n'


# Generated at 2022-06-16 21:06:23.052746
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Foo')
    assert finder.ps_modules['Ansible.ModuleUtils.Foo']['data'] == b'#!/usr/bin/env powershell\n'
    assert finder.ps_modules['Ansible.ModuleUtils.Foo']['path'] == 'ansible/module_utils/powershell/Foo.psm1'

    finder = PSModuleDepFinder()
    finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo')
    assert finder.ps_modules['Ansible.ModuleUtils.Foo']['data'] == b'#!/usr/bin/env powershell\n'

# Generated at 2022-06-16 21:06:32.376506
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test function scan_exec_script of class PSModuleDepFinder
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test_script')
    assert finder.exec_scripts['test_script'] == b'#!/usr/bin/python\n'
    # Test with an invalid script name
    try:
        finder.scan_exec_script('invalid_script')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:06:39.742032
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_script')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('exec_wrapper')
    assert 'exec_wrapper' in finder.exec_scripts.keys()

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    # and scans the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script('exec_wrapper')
   

# Generated at 2022-06-16 21:07:01.557263
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:10.663217
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:22.574900
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:29.796709
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"
    assert dep_finder.ps_modules["test_module"] == {"data": b"test_module", "path": "test_module.psm1"}

    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-16 21:07:43.666496
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:47.905477
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not yet implemented
    pass


# Generated at 2022-06-16 21:07:55.096491
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None

    # Test with an invalid script
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:08:05.561761
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]["data"].startswith(b"#")
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]["path"].endswith(".psm1")
    assert finder.exec_scripts["common"].startswith(b"#")

    # Test with an invalid name
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:08:10.402245
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script('common')
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1
    assert len(finder.cs_utils_wrapper) == 1
    assert finder.ps_modules['Ansible.ModuleUtils.Common']['data'].startswith(b'#')
    assert finder.cs_utils_wrapper['Ansible.ModuleUtils.Common']['data'].startswith(b'using')
    assert finder.exec_scripts['common'].startswith(b'#')

    # Test with an invalid script
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:08:15.410741
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:08:47.736877
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = '''
    #!/usr/bin/env powershell
    '''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}

    # Test with a module that has a builtin dependency
    module_data = '''
    #!/usr/bin/env powershell
    #Requires -Module Ansible.ModuleUtils.Foo
    '''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)

# Generated at 2022-06-16 21:08:59.500888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_script')
        assert False, "AnsibleError not raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_base')
    assert 'powershell_base' in finder.exec_scripts

    # Test that scan_exec_script adds the script to the exec_scripts dict
    # and scans the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_base')
    assert 'powershell_base'

# Generated at 2022-06-16 21:09:14.520252
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    # This is a test for a module that has no dependencies
    module_data = b"#!/usr/bin/python\n\nprint 'hello world'"
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data)
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.ps_version is None
    assert ps_

# Generated at 2022-06-16 21:09:23.982353
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script_data"

    # Test with an invalid script
    try:
        dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:09:34.863821
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ansible_powershell_common')
    assert finder.exec_scripts['ansible_powershell_common'] is not None
    assert finder.ps_modules['Ansible.ModuleUtils.Common'] is not None

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('ansible_powershell_common_invalid')
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass


# Generated at 2022-06-16 21:09:40.999186
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert finder.exec_scripts["exec_wrapper"]
    assert finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToYaml"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromYaml"]


# Generated at 2022-06-16 21:09:47.790773
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert dep_finder

# Generated at 2022-06-16 21:09:58.274269
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case 1
    # Test case with no arguments
    # Expected result: AnsibleError
    try:
        PSModuleDepFinder().scan_exec_script()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")

    # Test case 2
    # Test case with argument name = 'test_name'
    # Expected result: AnsibleError
    try:
        PSModuleDepFinder().scan_exec_script('test_name')
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")

    # Test case 3
    # Test case with argument name = 'test_name'
    # Expected result: AnsibleError

# Generated at 2022-06-16 21:10:09.169547
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:11.082546
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name) of class PSModuleDepFinder
    # This is a private method and is not tested
    pass


# Generated at 2022-06-16 21:10:45.747032
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:57.154144
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host $foo
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin module_util
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    #Requires -Module Ansible.ModuleUtils.Foo
    Write-Host $foo
    """
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:11:05.285467
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:11:13.781804
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:22.243363
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has a dependency on a builtin module_util
    # and a collection module_util
    module_data = b"""#Requires -Module Ansible.ModuleUtils.TestModuleUtil
#AnsibleRequires -PowerShell ansible_collections.test.test_collection.plugins.module_utils.test_module_util
#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.test_module_util
"""
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)

    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_module) == 1

    # Test with a module that has a dependency on a builtin module_util
    # and a collection

# Generated at 2022-06-16 21:11:34.168399
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() raises an exception when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert "powershell_base" in finder.exec_scripts

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert "powershell_base" in find

# Generated at 2022-06-16 21:11:39.190329
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError should have been raised"

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script("exec_wrapper")



# Generated at 2022-06-16 21:11:47.321380
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"]

# Generated at 2022-06-16 21:11:57.462727
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:04.449924
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test")
    assert finder.exec_scripts["test"] == to_bytes("test")
    assert finder.ps_modules["test"] == {"data": to_bytes("test"), "path": "test"}
    # Test with an invalid name
    try:
        finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:12:31.943591
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:36.056710
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("executor")
    assert finder.exec_scripts["executor"] is not None

    # Test with an invalid name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:12:44.998550
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"#!/usr/bin/env powershell\n" \
                  b"# Test module\n" \
                  b"param()\n" \
                  b"Write-Host 'Hello World'"
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:12:55.887366
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:06.541911
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:09.031733
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is tested in test_module_utils_loader.py
    pass


# Generated at 2022-06-16 21:13:20.777583
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False
    except AnsibleError:
        assert True

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("basic")
        assert True
    except AnsibleError:
        assert False

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("basic")
        assert True
    except AnsibleError:
        assert False

    # Test that scan_exec

# Generated at 2022-06-16 21:13:23.118083
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:13:30.009172
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script()
    # Test scan_exec_script() method of PSModuleDepFinder class
    #
    # Args:
    #   None
    #
    # Returns:
    #   None
    #
    # Raises:
    #   None
    #
    # Example:
    #   test_PSModuleDepFinder_scan_exec_script()
    #
    # Note:
    #   None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script() method
    ps_module_dep_finder.scan_exec_script('powershell_base')
    assert ps_module_dep_finder.exec_scripts['powershell_base'] is not None

# Generated at 2022-06-16 21:13:42.697824
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert finder.exec_scripts["test_script"] == b"#!/usr/bin/python\n"
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil"]["data"] == b"#!/usr/bin/python\n"
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil"]["path"] == "ansible/module_utils/test_module_util.psm1"

    # Test with an invalid script name
    try:
        finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass

# Generated at 2022-06-16 21:14:10.357546
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test that the scan_module method of PSModuleDepFinder works as expected.
    # This is a unit test for the scan_module method of the PSModuleDepFinder class.
    # It tests that the scan_module method works as expected.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Create a module_data variable

# Generated at 2022-06-16 21:14:13.978162
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test if the method scan_exec_script of class PSModuleDepFinder
    # can be called without error.
    # This test does not assert any return value.
    PSModuleDepFinder().scan_exec_script("")


# Generated at 2022-06-16 21:14:17.144019
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:14:28.898441
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host $foo
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_module) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.exec_scripts) == 0

    # Test with a module that has a single dependency

# Generated at 2022-06-16 21:14:40.981379
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('win_command')
    assert finder.exec_scripts['win_command']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertToJson']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Text']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Windows']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.File']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Process']
   

# Generated at 2022-06-16 21:14:50.228053
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:15:02.784446
# Unit test for method scan_exec_script of class PSModuleDepFinder