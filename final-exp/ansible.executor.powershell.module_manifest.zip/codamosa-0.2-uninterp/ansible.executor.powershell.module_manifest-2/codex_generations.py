

# Generated at 2022-06-16 21:05:29.529335
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:35.625637
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_wrapper")
    assert dep_finder.exec_scripts["powershell_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"] is not None


# Generated at 2022-06-16 21:05:38.635890
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() returns the expected value
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"\n"


# Generated at 2022-06-16 21:05:45.743758
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("ansible_powershell_common_invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:05:55.481837
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

function Test-Module {
    Write-Output "Hello World"
}

Test-Module
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a single dependency
    module_data = b"""
#!/usr/bin/env powershell

#Requires -Module Ansible.ModuleUtils.Test

function Test-Module {
    Write-Output "Hello World"
}

Test-Module
"""
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:06:04.103368
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import tempfile
    import shutil
    import ansible.executor.powershell
    import ansible.module_utils.powershell
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.winrm

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a temporary powershell script
    with open(os.path.join(tmpdir, "test_PSModuleDepFinder_scan_exec_script.ps1"), "w") as f:
        f.write("#Requires -Module Ansible.ModuleUtils.Powershell\n")

# Generated at 2022-06-16 21:06:07.866215
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"\n"



# Generated at 2022-06-16 21:06:19.241957
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test that scan_module correctly finds the module_utils used in a module
    # and that it recursively drills into the module_utils to find any
    # additional module_utils.

    # Create a module with a module_util that uses another module_util
    # and a module_util that uses a module_util in a collection
    module_data = '''
#Requires -Module Ansible.ModuleUtils.Test.ModuleUtil1
#AnsibleRequires -PowerShell ansible_collections.test.test_collection.plugins.module_utils.Test.ModuleUtil2
'''
    module_util1_data = '''
#Requires -Module Ansible.ModuleUtils.Test.ModuleUtil3
'''

# Generated at 2022-06-16 21:06:22.817994
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:06:26.381921
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:06:51.974437
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:58.932414
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:04.069425
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert len(dep_finder.exec_scripts.keys()) == 1
    assert "powershell_base" in dep_finder.exec_scripts.keys()
    assert len(dep_finder.ps_modules.keys()) == 1
    assert "Ansible.ModuleUtils.Common" in dep_finder.ps_modules.keys()

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:07:11.444193
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:17.152276
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #     name:
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # TODO: Add unit test
    pass


# Generated at 2022-06-16 21:07:27.364749
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_base')
    assert dep_finder.exec_scripts['powershell_base'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertTo'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertFrom'] is not None
    assert dep_

# Generated at 2022-06-16 21:07:41.480204
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:52.768895
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:56.989145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a unit test for the method scan_exec_script of class PSModuleDepFinder.
    # It is used to test the functionality of the method.
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert name in ps_module_dep_finder.exec_scripts.keys()


# Generated at 2022-06-16 21:08:06.056414
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:45.815927
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test 1: Test the scan_exec_script method of the PSModuleDepFinder class
    #         with a valid script name
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Setup
    ps_module_dep_finder = PSModuleDepFinder()
    name = "common"

    # Test
    ps_module_dep_finder.scan_exec_script(name)

    # Verify
    assert name in ps_module_dep_finder.exec_

# Generated at 2022-06-16 21:08:57.707856
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:00.258058
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not yet implemented.
    pass


# Generated at 2022-06-16 21:09:15.175377
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a unit test for the scan_exec_script method of the
    # PSModuleDepFinder class.
    #
    # This test will verify that the scan_exec_script method correctly
    # scans the executor powershell scripts for any dependencies.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a new instance of the PSModuleDepFinder class
    dep_finder = PSModuleDepFinder()

    # Scan the win_ping.ps1 script for any dependencies
    dep_finder.scan_exec_script("win_ping")

    # Verify that the win_ping.ps1 script

# Generated at 2022-06-16 21:09:27.507530
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:41.475528
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import pytest
    import ansible.executor.powershell
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.powershell.common import (
        PS_MODULE_UTILS_PATH,
        PS_MODULE_UTILS_PATH_LEN,
        PS_MODULE_UTILS_PATH_LEN_PLUS_ONE,
    )
    from ansible.module_utils.powershell.converter import (
        to_ps,
        to_text,
    )
    from ansible.module_utils.powershell.executor import (
        get_ps_script_path,
        get_ps_script_text,
    )

# Generated at 2022-06-16 21:09:52.061307
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:57.751731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_module_wrapper')
    assert dep_finder.exec_scripts['ansible_module_wrapper'] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:10:08.669199
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts.get("common") is not None
    assert dep_finder.ps_modules.get("Ansible.ModuleUtils.Common") is not None
    assert dep_finder.ps_modules.get("Ansible.ModuleUtils.Powershell") is not None
    assert dep_finder.ps_modules.get("Ansible.ModuleUtils.Powershell.Convert") is not None
    assert dep_finder.ps_modules.get("Ansible.ModuleUtils.Powershell.ConvertToJson") is not None

# Generated at 2022-06-16 21:10:12.353152
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:11:14.408919
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:22.270265
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:24.529598
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Add unit test for method scan_exec_script of class PSModuleDepFinder
    pass


# Generated at 2022-06-16 21:11:28.894803
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #     name (str): The name of the script to scan
    #
    # Raises:
    #     AnsibleError: If the script cannot be found
    #
    # Returns:
    #     None
    pass


# Generated at 2022-06-16 21:11:38.142185
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:46.690369
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:57.240523
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:03.831678
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a unit test for the method scan_exec_script of class PSModuleDepFinder.
    # It is used to test the functionality of the method.
    # Arrange
    test_object = PSModuleDepFinder()
    name = "test_name"

    # Act
    test_object.scan_exec_script(name)

    # Assert
    assert test_object.exec_scripts[name] == b"test_name"


# Generated at 2022-06-16 21:12:10.961471
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:23.247003
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a unit test for the scan_exec_script method of the
    # PSModuleDepFinder class.
    #
    # This test is not complete.
    #
    # This test is not run by default.
    #
    # To run this test, execute the following command:
    #
    #   python -m test.unit.module_utils.powershell.common.test_PSModuleDepFinder --test-PSModuleDepFinder-scan_exec_script
    #
    ###########################################################################
    #
    # Setup
    #
    ###########################################################################
    #
    # Create a PSModuleDepFinder object.
    #
    ###########################################################################
    finder = PSModule

# Generated at 2022-06-16 21:14:24.121057
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:26.209273
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:34.310678
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"#!/usr/bin/env powershell\n" \
                  b"#Requires -Version 5.0\n" \
                  b"#AnsibleRequires -OSVersion 6.0\n" \
                  b"#AnsibleRequires -Become\n" \
                  b"#AnsibleRequires -Wrapper Test\n" \
                  b"\n" \
                  b"Write-Output 'Hello World'"
    finder = PSModuleDepFinder()
    finder.scan_module(module_data, fqn="test_module", wrapper=False, powershell=True)
    assert finder.ps_version == "5.0"
    assert finder.os_version == "6.0"
    assert finder.become is True


# Generated at 2022-06-16 21:14:38.465888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:14:39.143197
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-16 21:14:47.034142
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:54.262671
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"#!/usr/bin/env pwsh\n\n"


# Generated at 2022-06-16 21:15:03.407881
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_command")
    assert dep_finder.exec_scripts["win_command"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True
