

# Generated at 2022-06-16 21:05:34.992744
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'#!/usr/bin/python\n'
    module_data += b'from ansible.module_utils.basic import AnsibleModule\n'
    module_data += b'\n'
    module_data += b'def main():\n'
    module_data += b'    module = AnsibleModule(argument_spec=dict())\n'
    module_data += b'    module.exit_json(changed=False)\n'
    module_data += b'\n'
    module_data += b'if __name__ == \'__main__\':\n'
    module_data += b'    main()\n'

    finder = PSModuleDepFinder()
    finder.scan_module(module_data)

    assert finder.ps

# Generated at 2022-06-16 21:05:44.425904
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:54.424532
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:03.048922
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:06.313116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): The name of the script to scan
    #
    # Raises:
    #    AnsibleError: If the script is not found
    #
    # Returns:
    #    None
    pass


# Generated at 2022-06-16 21:06:16.445510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_real_script')
        assert False, 'AnsibleError not raised'
    except AnsibleError:
        pass

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script('powershell_base')

    # Test that scan_exec_script does not raise an error if the script is found
    finder.scan_exec_script('powershell_base')



# Generated at 2022-06-16 21:06:29.841133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script does not exist
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('does_not_exist')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error if the script exists
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('powershell_base')
    except AnsibleError:
        assert False, "AnsibleError raised"

    # Test that scan_exec_script does not raise an error if the script exists
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:06:35.331907
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:41.927520
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:53.006779
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:23.308997
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:07:28.395713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b""


# Generated at 2022-06-16 21:07:38.123832
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"] is not None
    assert len(finder.exec_scripts["ansible_powershell_common"]) > 0

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:07:51.047951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case 1
    # Test with a valid script name
    # Expected result:
    #   The script should be added to the exec_scripts dict
    #   The script should be scanned for any dependencies
    #   The script should be added to the ps_modules dict
    #   The script should be added to the cs_utils_wrapper dict
    #   The script should be added to the cs_utils_module dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test_script')

# Generated at 2022-06-16 21:07:53.287243
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:08:05.280571
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:10.143530
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host "Hello World"
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin util

# Generated at 2022-06-16 21:08:18.929242
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:30.558484
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:40.457290
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with a non-existent script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("non_existent_script")
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:09:04.047771
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import safe_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_yaml_allow_flow_style
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_json_allow_flow_style

# Generated at 2022-06-16 21:09:17.336559
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:23.439512
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:36.726059
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:48.818952
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = to_bytes("""
    #!/usr/bin/env powershell
    $a = 1
    """)
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin module_util
    module_data = to_bytes("""
    #!/usr/bin/env powershell
    #Requires -Module Ansible.ModuleUtils.Foo
    $a = 1
    """)
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps

# Generated at 2022-06-16 21:09:58.536645
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:09.421355
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:12.260297
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:10:25.595425
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:32.022767
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:56.519869
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:08.506612
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:17.065102
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to_bytes

# Generated at 2022-06-16 21:11:27.658956
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_wrapper")
    assert dep_finder.exec_scripts["powershell_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:11:37.581732
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:43.781964
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("basic")
    assert "basic" in finder.exec_scripts

    # Test that scan_exec_script adds the script to the exec_scripts dict
    # and scans the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script("basic")
    assert "basic" in finder.exec_scripts


# Generated at 2022-06-16 21:11:55.335144
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:05.672242
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test_PSModuleDepFinder_scan_module()
    # Test scan_module()
    #
    # Args:
    #   None
    #
    # Returns:
    #   None
    #
    # Raises:
    #   None

    # Test scan_module() with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test scan_module() with a module that has a dependency on a builtin util
    module_data

# Generated at 2022-06-16 21:12:18.782023
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:27.232978
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script_name")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:12:51.194329
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test to see if the scan_module method of PSModuleDepFinder class works as expected
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    module_data = b'#Requires -Module Ansible.ModuleUtils.TestModuleUtil'
    # Act
    ps_module_dep_finder.scan_module(module_data)
    # Assert
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.TestModuleUtil'] is not None


# Generated at 2022-06-16 21:12:57.597739
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("win_ping")
    assert finder.exec_scripts["win_ping"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:00.546060
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:13:08.968932
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:20.777090
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:28.959386
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:41.637361
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:49.583520
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found.
    #
    # Arrange
    dep_finder = PSModuleDepFinder()

    # Act
    try:
        dep_finder.scan_exec_script("does_not_exist")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script adds the script to the exec_scripts dictionary.
    #
    # Arrange
    dep_finder = PSModuleDepFinder()

    # Act
    dep_finder.scan_exec_script("ansible_module_utils.basic")

    # Assert
    assert "ansible_module_utils.basic" in dep_finder.exec_scripts

    # Test that scan_exec_script scans the script for dependencies.

# Generated at 2022-06-16 21:14:02.433003
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:13.974835
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:46.594765
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:48.816464
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:15:01.123511
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script('CommonUtils')
    assert depfinder.exec_scripts['CommonUtils']
    assert depfinder.cs_utils_wrapper['Ansible.ModuleUtils.CommonUtils']
    assert depfinder.ps_modules['Ansible.ModuleUtils.CommonUtils']
    assert depfinder.ps_modules['Ansible.ModuleUtils.Legacy']
    assert depfinder.ps_modules['Ansible.ModuleUtils.Legacy.ConvertTo-Json']
    assert depfinder.ps_modules['Ansible.ModuleUtils.Legacy.ConvertTo-JsonArray']

# Generated at 2022-06-16 21:15:09.344389
# Unit test for method scan_exec_script of class PSModuleDepFinder