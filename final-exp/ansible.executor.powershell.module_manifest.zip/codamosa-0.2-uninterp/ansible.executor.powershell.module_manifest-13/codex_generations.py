

# Generated at 2022-06-16 21:05:42.960973
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:53.474107
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() correctly scans a script for dependencies
    # and adds the script to the exec_scripts dict.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create a script with a dependency
    script_name = "test_script"
    script_data = "#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n"
    script_data += "Write-Host 'Hello World'"

    # Scan the script
    dep_finder.scan_exec_script(script_name)

    # Assert that the script is in the exec_scripts dict
    assert script_name in dep_finder

# Generated at 2022-06-16 21:05:56.592548
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-16 21:06:02.051779
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    #
    # Args:
    #     module_data (bytes): module data
    #     fqn (str): fully qualified name of the module
    #     wrapper (bool): whether the module is a wrapper
    #     powershell (bool): whether the module is a powershell module
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    pass


# Generated at 2022-06-16 21:06:04.180059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented
    pass


# Generated at 2022-06-16 21:06:10.348823
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_module_wrapper")
    assert dep_finder.exec_scripts["ansible_module_wrapper"] is not None
    assert len(dep_finder.exec_scripts["ansible_module_wrapper"]) > 0

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:06:20.729123
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:33.569468
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:35.362311
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to ensure that the scan_exec_script method of PSModuleDepFinder works properly
    # This test is not yet implemented
    assert False


# Generated at 2022-06-16 21:06:41.711016
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_module_common")
    assert dep_finder.exec_scripts["ansible_module_common"] is not None
    assert dep_finder.exec_scripts["ansible_module_common"] != ""
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] != ""

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:07:16.798468
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not really possible to do in a unit test.  It would require
    # mocking out the entire module_utils directory and the module_utils
    # directory of every collection.  This would be a lot of work and would
    # require a lot of maintenance.  The test would also not be very useful
    # since it would not be testing the actual code.  It would only be testing
    # the mocked out code.
    pass


# Generated at 2022-06-16 21:07:27.049198
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    #!/usr/bin/env powershell
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )
    Write-Host $foo
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:07:41.148796
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:52.557913
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:01.829785
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:09.545373
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:18.824122
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:24.760170
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:32.983045
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:44.354381
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:04.177163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:09:17.498482
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Test the scan_exec_script method
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Test the scan_exec_script method
    ps_module_dep_finder.scan_exec_script("exec_wrapper")

    # Test the scan_exec_script method

# Generated at 2022-06-16 21:09:23.632241
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:37.085564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the method scan_exec_script of class PSModuleDepFinder
    # This method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    #
    # Input parameters:
    #   name: name of the script
    #
    # Expected result:
    #   None
    #
    # Possible side effects:
    #   None

    # Create an instance of the class PSModuleDepFinder
    dep_finder = PSModuleDepFinder()

    # Call the method scan_exec_script with a valid name
    dep_finder.scan_exec_script("ansible_powershell_common")

    # Call the method scan_exec_script with an invalid name

# Generated at 2022-06-16 21:09:44.835731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToXml"]

# Generated at 2022-06-16 21:09:53.750596
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:04.450873
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')
    assert dep_finder.exec_scripts['test_script'] == b'#!/usr/bin/python\n'

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
    except AnsibleError as e:
        assert 'Could not find executor powershell script for \'invalid_script\'' in to_text(e)
    else:
        assert False, "AnsibleError not raised"



# Generated at 2022-06-16 21:10:07.905237
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:10:14.343564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert finder.exec_scripts["exec_wrapper"] is not None
    assert len(finder.exec_scripts["exec_wrapper"]) > 0
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert len(finder.ps_modules["Ansible.ModuleUtils.Common"]["data"]) > 0

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:10:19.315565
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module with a module that has no dependencies
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common')
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become

    # Test scan_module with a module that has a dependency
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:10:42.823086
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:50.535296
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a unit test for the scan_exec_script method of class PSModuleDepFinder.
    #
    # This test case is used to test the scan_exec_script method of class PSModuleDepFinder.
    #
    # Returns:
    #     None
    # Raises:
    #     None
    pass


# Generated at 2022-06-16 21:11:01.948718
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:13.136281
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:21.841528
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"] is not None

# Generated at 2022-06-16 21:11:33.852739
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:42.309639
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    #
    # Args:
    #     module_data (str): The module data to scan
    #     fqn (str): The fully qualified name of the module
    #     wrapper (bool): Whether or not the module is a wrapper
    #     powershell (bool): Whether or not the module is a powershell module
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    #
    # Examples:
    #     None
    #
    # Test Cases:
    #     None
    pass


# Generated at 2022-06-16 21:11:54.036394
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:56.494456
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:12:01.342311
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not really testing anything, it is just to make sure the
    # method is covered by unit tests.
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test')


# Generated at 2022-06-16 21:12:29.453301
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:36.770599
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson.ConvertToJson"]

# Generated at 2022-06-16 21:12:42.467552
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert "ansible_powershell_common" in dep_finder.exec_scripts
    assert "ansible_collections.ansible.builtin.plugins.module_utils.powershell.common" in dep_finder.ps_modules
    assert "ansible_collections.ansible.builtin.plugins.module_utils.powershell.common" in dep_finder.cs_utils_wrapper
    assert "ansible_collections.ansible.builtin.plugins.module_utils.powershell.common" in dep_finder.cs_utils_module

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:12:54.334885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Url"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Win32"] is not None

# Generated at 2022-06-16 21:13:05.221849
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:17.825521
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:27.154730
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a test for the scan_exec_script method of the PSModuleDepFinder
    # class. This method scans lib/ansible/executor/powershell for scripts used
    # in the module exec side. It also scans these scripts for any
    # dependencies.
    #
    # This test will check that the method scans the script and adds it to the
    # exec_scripts dict. It will also check that the method scans the script
    # for any dependencies and adds them to the ps_modules dict.

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Scan the script
    dep_finder.scan_exec_script('powershell_base')

    # Check that the script was

# Generated at 2022-06-16 21:13:40.231979
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:45.873623
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b"\n"


# Generated at 2022-06-16 21:13:59.081015
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script will raise an error if the script is not found
    # in the executor powershell directory
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'not_a_script'" in to_text(e)
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script will add the script to the exec_scripts dict
    # and scan the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert "test_script" in finder.exec_scripts.keys()

# Generated at 2022-06-16 21:14:56.848104
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() correctly finds the script and adds it to the exec_scripts dict
    # and that it correctly scans the script for dependencies
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a new instance of PSModuleDepFinder
    dep_finder = PSModuleDepFinder()

    # Scan the script
    dep_finder.scan_exec_script("common")

    # Check that the script was added to the exec_scripts dict
    assert "common" in dep_finder.exec_scripts.keys()

    # Check that the script was scanned for dependencies
    assert "Ansible.ModuleUtils.CommonUtils" in dep_finder.ps_modules.keys()



# Generated at 2022-06-16 21:15:07.034615
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_real_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert "exec_wrapper" in finder.exec_scripts.keys()

    # Test that scan_exec_script() adds the script to the exec_scripts dict
    # and scans the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")