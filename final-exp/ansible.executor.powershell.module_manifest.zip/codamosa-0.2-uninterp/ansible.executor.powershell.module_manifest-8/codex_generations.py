

# Generated at 2022-06-16 21:05:28.519253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an exception when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_valid_script")
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert "powershell_base" in finder.exec_scripts.keys()


# Generated at 2022-06-16 21:05:33.543119
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:41.125071
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("ansible_powershell_common_invalid")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:05:50.400676
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert "powershell_base" in dep_finder.exec_scripts
    assert "ansible_collections.ansible.builtin.plugins.module_utils.powershell.common" in dep_finder.ps_modules

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:05:55.898880
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:02.012775
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert finder.exec_scripts["exec_wrapper"] is not None
    assert len(finder.exec_scripts["exec_wrapper"]) > 0

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:06:09.040196
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:20.011179
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:33.223462
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:40.033934
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.test_script"] == {"data": b"test_script", "path": "test_script"}
    assert dep_finder.cs_utils_wrapper["Ansible.ModuleUtils.test_script"] == {"data": b"test_script", "path": "test_script"}

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:07:25.652215
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"]
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToXml"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Errors"]
   

# Generated at 2022-06-16 21:07:38.873545
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None

# Generated at 2022-06-16 21:07:51.507751
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:58.503495
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method of class PSModuleDepFinder
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Test a module with no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host "Hello World"
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.exec_scripts) == 0

# Generated at 2022-06-16 21:08:06.255704
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("script")
    assert finder.exec_scripts["script"] == b"#!/usr/bin/python\n"
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]["data"] == b"#!/usr/bin/python\n"

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'invalid_script'" in to_text(e)



# Generated at 2022-06-16 21:08:11.450176
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0

    # Test with a non-existent script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("non_existent")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:08:20.028416
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:31.091729
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:43.428944
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:47.027271
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:09:20.665621
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:29.691060
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:37.828087
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for scan_module
    #
    # Args:
    #    module_data (str): module data
    #    fqn (str): fully qualified name
    #    wrapper (bool): if the module is a wrapper
    #    powershell (bool): if the module is a powershell module
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None
    pass

# Generated at 2022-06-16 21:09:49.689351
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for scan_module method of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    module_data = b'#Requires -Module Ansible.ModuleUtils.Test'
    fqn = 'ansible_collections.test.test.plugins.modules.test'
    wrapper = False
    powershell = True
    # Act
    ps_module_dep_finder.scan_module(module_data, fqn, wrapper, powershell)
    # Assert

# Generated at 2022-06-16 21:09:57.358272
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:10:08.626147
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:14.931670
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:27.100733
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:32.983575
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not yet implemented.
    #
    # If you want to implement this test, please remove this line
    # and implement the test.
    raise NotImplementedError()


# Generated at 2022-06-16 21:10:44.134565
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:10.818879
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"] is not None
    assert finder.ps_modules

# Generated at 2022-06-16 21:11:15.796746
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    #
    # Returns:
    #
    # Raises:
    #     AnsibleError: Could not find executor powershell script for 'name'
    pass


# Generated at 2022-06-16 21:11:22.244926
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"] is not None
    assert dep_finder.exec_scripts["powershell_base"] != ""
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] != ""

    # Test with an invalid name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_name")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:11:34.168486
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:44.250681
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:54.168733
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ansible_powershell_common')
    assert finder.exec_scripts['ansible_powershell_common']
    assert finder.ps_modules['Ansible.ModuleUtils.Common']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell']

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('ansible_powershell_common_invalid')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:12:02.911403
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     name (str): The name of the script to scan
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    #
    # Example:
    #     None
    #
    # Test ID:
    #     None
    #
    # Requirement ID:
    #     None
    #
    # Covers:
    #     None
    #
    # Modifies:
    #     None
    #
    # Comment:
    #     None
    #
    pass


# Generated at 2022-06-16 21:12:05.900885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = 'name'

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] is not None


# Generated at 2022-06-16 21:12:19.167008
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.0',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Output "Hello World"
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None

# Generated at 2022-06-16 21:12:29.799228
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:53.418793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script('common')
    assert finder.exec_scripts['common']
    assert finder.ps_modules['Ansible.ModuleUtils.Common']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell']
    assert finder.ps_modules['Ansible.ModuleUtils.Process']
    assert finder.ps_modules['Ansible.ModuleUtils.Url']

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('invalid')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:13:04.402698
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:12.692304
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): The name of the script to scan
    #
    # Raises:
    #    AnsibleError: If the script is not found
    #
    # Returns:
    #    None
    #
    # Example:
    #    PSModuleDepFinder().scan_exec_script('name')
    pass


# Generated at 2022-06-16 21:13:19.862621
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert finder.exec_scripts["test_script"] == b"test_script_data"

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False, "AnsibleError not raised"
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:13:28.416110
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script will raise an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_real_script')
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script will add the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('exec_wrapper')
    assert len(finder.exec_scripts) == 1
    assert 'exec_wrapper' in finder.exec_scripts

    # Test that scan_exec_script will add the script to the exec_scripts dict
    # and scan the script for dependencies
    finder = PSModuleDepFinder()
    finder.scan_

# Generated at 2022-06-16 21:13:41.251239
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:48.159204
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:14:01.455176
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 21:14:11.175783
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to verify that the scan_exec_script method of PSModuleDepFinder class
    # returns the expected output.
    # Arrange
    name = 'Test'
    expected_output = b'Test'
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.exec_scripts = {'Test': b'Test'}
    # Act
    actual_output = ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert actual_output == expected_output


# Generated at 2022-06-16 21:14:23.074136
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:57.827160
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFromJson"] is not None
   