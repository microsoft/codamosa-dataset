

# Generated at 2022-06-16 21:05:43.931344
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None

# Generated at 2022-06-16 21:05:54.063352
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:59.112411
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('not_a_script')
    except AnsibleError as e:
        assert 'Could not find executor powershell script for \'not_a_script\'' in str(e)
    else:
        assert False, 'AnsibleError not raised'


# Generated at 2022-06-16 21:06:07.071889
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script does not raise an error if the script is found
    try:
        finder.scan_exec_script("powershell_base")
    except AnsibleError:
        assert False, "AnsibleError should not have been raised"

    # Test that scan_exec_script does not raise an error if the script is found

# Generated at 2022-06-16 21:06:18.738831
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:23.542005
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")
    assert finder.exec_scripts["exec_wrapper"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None


# Generated at 2022-06-16 21:06:35.273400
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#!/usr/bin/env powershell\n')
    assert psmdf.ps_modules == {}
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}
    assert psmdf.exec_scripts == {}
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False

    # Test with a module that has a builtin dependency
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#!/usr/bin/env powershell\n#Requires -Module Ansible.ModuleUtils.Foo\n')
   

# Generated at 2022-06-16 21:06:41.606957
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:51.747110
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:07:03.793116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() correctly scans a script for dependencies
    # and adds them to the exec_scripts dict.

    # Create a temporary script file
    with tempfile.NamedTemporaryFile(mode='w+b', suffix='.ps1') as f:
        f.write(b'#Requires -Module Ansible.ModuleUtils.Common\n')
        f.write(b'#Requires -Module Ansible.ModuleUtils.Legacy\n')
        f.write(b'#Requires -Module Ansible.ModuleUtils.Legacy.Arguments\n')
        f.write(b'#Requires -Module Ansible.ModuleUtils.Legacy.String\n')
        f.write(b'#Requires -Module Ansible.ModuleUtils.Legacy.File\n')

# Generated at 2022-06-16 21:07:37.851235
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.1',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Output "Hello World"
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None

# Generated at 2022-06-16 21:07:50.875825
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Url"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Win32"] is not None

# Generated at 2022-06-16 21:08:01.069242
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:08.556783
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:18.749781
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:30.519927
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:35.402605
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test')
    assert finder.ps_modules['Ansible.ModuleUtils.Test']
    assert not finder.cs_utils_module
    assert not finder.cs_utils_wrapper
    assert not finder.exec_scripts
    assert not finder.ps_version
    assert not finder.os_version
    assert not finder.become

    finder = PSModuleDepFinder()
    finder.scan_module(b'#AnsibleRequires -CSharpUtil Ansible.Test')
    assert not finder.ps_modules
    assert finder.cs_utils_module['Ansible.Test']
    assert not finder.cs_utils_wrapper
    assert not find

# Generated at 2022-06-16 21:08:46.175730
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:55.761626
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    #
    # Args:
    #     module_data (str):
    #         The module data to scan
    #
    #     fqn (str):
    #         The fully qualified name of the module
    #
    #     wrapper (bool):
    #         Whether the module is a wrapper
    #
    #     powershell (bool):
    #         Whether the module is a powershell module
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    pass


# Generated at 2022-06-16 21:09:04.728091
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:27.605449
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:37.305236
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('exec_wrapper')
    assert dep_finder.exec_scripts['exec_wrapper'] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:09:49.257162
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:58.618061
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:07.995569
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('win_ping')

    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script('invalid_script_name')
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")


# Generated at 2022-06-16 21:10:17.177506
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"]
    assert finder.ps_modules
    assert finder.cs_utils_wrapper

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:10:28.182785
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:40.518198
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError should be raised"



# Generated at 2022-06-16 21:10:48.901283
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:51.519825
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name) of class PSModuleDepFinder
    # This method is not tested as it is not used in the code base.
    pass


# Generated at 2022-06-16 21:11:18.771365
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Url"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.WebRequest"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Win32"]

# Generated at 2022-06-16 21:11:30.458854
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:11:39.080573
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:47.233534
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.0',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Output "Hello World"
"""

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)

    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with a module that has a single

# Generated at 2022-06-16 21:11:57.416667
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:06.304737
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_common")
    assert finder.exec_scripts["ansible_powershell_common"]
    assert finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]

    # Test with an invalid script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:12:19.888972
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()
    # Call the scan_exec_script method
    ps_module_dep_finder.scan_exec_script("ansible_powershell_common")
    # Check if the method returns the expected value

# Generated at 2022-06-16 21:12:30.415273
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:30.892475
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-16 21:12:35.737366
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script_data"

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:26.675461
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:36.574537
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script method
    ps_module_dep_finder.scan_exec_script("script")
    assert ps_module_dep_finder.exec_scripts["script"] is not None


# Generated at 2022-06-16 21:13:47.088682
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:50.485736
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not yet implemented.
    pass


# Generated at 2022-06-16 21:13:57.920695
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] is not None


# Generated at 2022-06-16 21:14:05.278746
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script works for a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert finder.cs_utils_wrapper["Ansible.ModuleUtils.Common"]

    # Test that scan_exec_script raises an error for an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:14:13.167792
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:24.761685
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
$a = 1
'''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util
    module_data = b'''
#Requires -Module Ansible.ModuleUtils.Foo
$a = 1
'''
    finder = PSModuleDepFinder()
    finder.scan_module

# Generated at 2022-06-16 21:14:34.098395
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Process"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None

# Generated at 2022-06-16 21:14:44.768400
# Unit test for method scan_module of class PSModuleDepFinder