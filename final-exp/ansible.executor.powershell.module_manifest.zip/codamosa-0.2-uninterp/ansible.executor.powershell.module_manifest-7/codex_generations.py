

# Generated at 2022-06-16 21:05:36.966521
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Process"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Url"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Win32"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Win32.File"] is not None
    assert finder.ps_

# Generated at 2022-06-16 21:05:45.455359
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:51.016221
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import tempfile
    import shutil
    import random
    import string
    import pkgutil
    import importlib
    import ansible.module_utils.powershell.module_utils.basic

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a collection
    collection_name = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    collection_path = os.path.join(tmpdir, collection_name)
    os.mkdir(collection_path)

    # Create a module in the collection
    module_name = ''.join(random.choice(string.ascii_lowercase) for i in range(10))

# Generated at 2022-06-16 21:05:55.368117
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:03.988127
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:08.880899
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None
    assert len(finder.exec_scripts["powershell_base"]) > 0
    assert len(finder.ps_modules) > 0

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-16 21:06:19.911726
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:32.238482
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test is to ensure that the scan_exec_script method of PSModuleDepFinder
    # class is working as expected.
    #
    # The test is done by creating an instance of PSModuleDepFinder class and
    # calling the scan_exec_script method with a valid script name.
    #
    # The test is successful if the scan_exec_script method returns without
    # raising any exception.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("common")


# Generated at 2022-06-16 21:06:38.693060
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("Common")
    assert dep_finder.exec_scripts["Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["data"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["path"] is not None

    # Test with an invalid name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("Invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:06:51.829638
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None

# Generated at 2022-06-16 21:07:23.069998
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"] is not None
    assert len(dep_finder.exec_scripts["powershell_base"]) > 0
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert len(dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["data"]) > 0
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["path"] is not None
    assert len(dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["path"]) > 0

    # Test with an invalid script
    dep

# Generated at 2022-06-16 21:07:31.754944
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:45.769419
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('win_command')
    assert finder.exec_scripts['win_command']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.File']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Format']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.IO']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Process']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Security']

# Generated at 2022-06-16 21:07:48.878153
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:08:00.576117
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a non-existing script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("non_existing_script")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'non_existing_script'" in to_text(e)
    else:
        assert False, "AnsibleError should be raised"

    # Test with an existing script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test_script")
    assert "test_script" in finder.exec_scripts
    assert "test_script" in finder.ps_modules
    assert "test_script" in finder.cs_utils_wrapper
    assert "test_script" in finder.cs_utils_module


# Generated at 2022-06-16 21:08:08.566051
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:12.730842
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not currently implemented.
    pass


# Generated at 2022-06-16 21:08:20.908651
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:23.922335
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a test for a method that is only used by the powershell
    # connection plugin.  It is not used by any other plugins.
    #
    # The method is tested by the powershell connection plugin unit tests.
    pass


# Generated at 2022-06-16 21:08:32.599461
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_base')
    assert dep_finder.exec_scripts['powershell_base']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertTo']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertFrom']

# Generated at 2022-06-16 21:09:06.780109
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("win_command")
    assert finder.exec_scripts["win_command"] is not None
    assert finder.exec_scripts["win_command"] != ""
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] != ""
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"] != ""
    assert finder.ps_modules["Ansible.ModuleUtils.Process"] is not None

# Generated at 2022-06-16 21:09:20.877598
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:29.813703
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder
    # This method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies

    # Create an instance of PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script with a valid script name
    script_name = "powershell_base"
    ps_module_dep_finder.scan_exec_script(script_name)
    assert script_name in ps_module_dep_finder.exec_scripts.keys()

    # Test scan_exec_script with an invalid script name
    script_name = "invalid_script"

# Generated at 2022-06-16 21:09:38.434999
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script returns the expected result
    # for the given input.
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("powershell_base")
    assert ps_module_dep_finder.exec_scripts["powershell_base"] == to_bytes(pkgutil.get_data("ansible.executor.powershell", "powershell_base.ps1"))


# Generated at 2022-06-16 21:09:50.162011
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert len(dep_finder.exec_scripts["exec_wrapper"]) > 0
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert len(dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["data"]) > 0
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["path"] is not None
    assert len(dep_finder.ps_modules["Ansible.ModuleUtils.Common"]["path"]) > 0

    # Test with an invalid script

# Generated at 2022-06-16 21:09:57.381086
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script('win_command')
    assert finder.exec_scripts['win_command'] is not None
    assert finder.exec_scripts['win_command'].startswith(b'#')

    # Test with an invalid name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('invalid_name')
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError should be raised"



# Generated at 2022-06-16 21:10:06.818631
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script_data"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.test_module_util"]["data"] == b"test_module_util_data"

    # Test with an invalid script
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False, "AnsibleError should have been raised"
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:10:10.661243
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #     name:
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    pass



# Generated at 2022-06-16 21:10:15.699105
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    # This method is tested in test_module_utils_loader.py
    pass


# Generated at 2022-06-16 21:10:27.532588
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:57.032888
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:09.045656
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.1',
    'status' => ['preview'],
    'supported_by' => 'community'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Host "Hello World!"
'''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_module == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None


# Generated at 2022-06-16 21:11:17.434057
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:31.405465
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = to_bytes('''
#!/usr/bin/python

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()
''')
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)

    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    assert len(finder.exec_scripts) == 0

    # Test with a module that has a builtin dependency

# Generated at 2022-06-16 21:11:42.530100
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:54.312710
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:56.800239
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"

    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:12:07.187210
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:20.106673
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.test_script"]["data"] == b"test_script"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.test_script"]["path"] == "ansible/module_utils/test_script.psm1"

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:12:30.540783
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:48.449895
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:12:50.799734
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name:
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None
    pass



# Generated at 2022-06-16 21:12:58.171345
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:07.708307
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module() with a module that requires a builtin module_util
    module_data = b"""
#Requires -Module Ansible.ModuleUtils.Foo

function Foo {
    Write-Host "Foo"
}
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {
        'Ansible.ModuleUtils.Foo': {
            'data': b'# Module util for Foo\n',
            'path': 'ansible/module_utils/Foo.psm1',
        },
    }

    # Test scan_module() with a module that requires a collection module_util

# Generated at 2022-06-16 21:13:11.013305
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("test")


# Generated at 2022-06-16 21:13:22.037925
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This method tests the scan_exec_script method of the PSModuleDepFinder class.
    #
    # The scan_exec_script method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Create a test script
    test_script = "TestScript.ps1"
    test_script_path = os.path.join(C.DEFAULT_MODULE_PATH[0], "windows", test_script)

# Generated at 2022-06-16 21:13:29.480300
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import sys
    import tempfile
    import textwrap
    import unittest

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format_module_name
    from ansible.module_utils.common.text.formatters import format_module_utils_path
    from ansible.module_utils.common.text.formatters import format_powershell_module_name
    from ansible.module_utils.common.text.formatters import format_powershell_module_utils_path
    from ansible.module_utils.common.text.formatters import format_powershell_module_utils_wrapper_path

# Generated at 2022-06-16 21:13:42.077536
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:53.456123
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host "Hello World"
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a builtin dependency

# Generated at 2022-06-16 21:14:04.561004
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:23.291754
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script returns the expected data
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = 'test_name'
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] is not None


# Generated at 2022-06-16 21:14:32.624268
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:35.187890
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:14:41.419117
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This method is used to scan lib/ansible/executor/powershell for scripts
    # used in the module exec side. It also scans these scripts for any
    # dependencies
    #
    # This test is not implemented yet
    pass


# Generated at 2022-06-16 21:14:48.270076
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:50.302116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:15:02.833555
# Unit test for method scan_module of class PSModuleDepFinder