

# Generated at 2022-06-16 21:05:35.476580
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test")
    assert dep_finder.exec_scripts["test"] == b"test"
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:05:45.209395
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script correctly finds the module_utils script
    # and scans it for dependencies.
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_wrapper')
    assert finder.ps_modules['Ansible.ModuleUtils.CommonUtils']['data']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert']['data']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertTo']['data']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertFrom']['data']
    assert finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertToJson']['data']

# Generated at 2022-06-16 21:05:52.436357
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] is not None
    assert len(finder.exec_scripts["powershell_base"]) > 0

    # Test with an invalid script
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:05:57.509019
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:59.782280
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:06:07.550738
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:18.993081
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:32.101086
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script()
    # Test scan_exec_script() method of class PSModuleDepFinder
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create an instance of PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script() method
    ps_module_dep_finder.scan_exec_script("script")

    # Test scan_exec_script() method with invalid script name
    try:
        ps_module_dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass

    # Test scan_exec_script() method with valid script name
   

# Generated at 2022-06-16 21:06:38.828274
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = to_bytes("""
#!/usr/bin/env powershell

param(
    [string]$foo
)

Write-Host $foo
""")
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a dependency on a builtin module_util

# Generated at 2022-06-16 21:06:51.829610
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:24.246680
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # This is a test for the scan_exec_script method of class PSModuleDepFinder
    # This method scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    #
    # Input parameters:
    #   name: name of the script
    #
    # Expected result:
    #   None
    #
    # Possible side effects:
    #   None

    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()

    # Act
    ps_module_dep_finder.scan_exec_script("ansible_module_wrapper")

    # Assert

# Generated at 2022-06-16 21:07:37.763351
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:50.785726
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when it cannot find the script
    # it is looking for
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("does_not_exist")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error when it finds the
    # script it is looking for
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("powershell_base")
    except AnsibleError:
        assert False, "AnsibleError raised"

    # Test that scan_exec_script does not raise an error when it finds the
    # script it is looking for
    finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:07:54.472946
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-16 21:08:03.299186
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:10.467122
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:19.208308
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')
    assert dep_finder.exec_scripts['test_script'] == b'#!/usr/bin/env python\n'
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:08:22.800568
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:32.085848
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:43.608689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('test_script')
    assert dep_finder.exec_scripts['test_script'] == b'#!/usr/bin/python\n'
    assert dep_finder.ps_modules['Ansible.ModuleUtils.TestModuleUtil']['data'] == b'#!/usr/bin/python\n'
    assert dep_finder.ps_modules['Ansible.ModuleUtils.TestModuleUtil']['path'] == 'ansible/module_utils/test_module_util.py'

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-16 21:09:15.227657
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:23.777212
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == "test_script"
    # Test with an invalid script name
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:09:37.471893
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    # This method is used to scan a module for any dependencies.
    # It is used by the module_utils/powershell/module_compiler.py to
    # determine what module_utils are required by a module.

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create a module with a dependency on a builtin module_util
    module_data = """
#Requires -Module Ansible.ModuleUtils.Common

function Test-Module {
    return "Test-Module"
}
"""

    # Scan the module for dependencies
    dep_finder.scan_module(module_data)

    # Verify that the module_util was added to the ps_modules dict
    assert "Ansible.ModuleUtils.Common" in dep_

# Generated at 2022-06-16 21:09:47.192038
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:09:54.838471
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('win_command')
    assert dep_finder.exec_scripts['win_command']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Process']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.WinSystem']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.WinVersion']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.WinUtils']

# Generated at 2022-06-16 21:10:06.819055
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToXml"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToYaml"] is not None

# Generated at 2022-06-16 21:10:11.979997
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:10:21.422724
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an instance of the class
    dep_finder = PSModuleDepFinder()
    # create a module_data
    module_data = b'#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n'
    # call the method scan_module
    dep_finder.scan_module(module_data)
    # assert that the module_util is added to the ps_modules
    assert dep_finder.ps_modules['Ansible.ModuleUtils.TestModuleUtil']


# Generated at 2022-06-16 21:10:29.795406
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_powershell_common')
    assert dep_finder.exec_scripts['ansible_powershell_common'] is not None
    assert len(dep_finder.exec_scripts['ansible_powershell_common']) > 0
    assert len(dep_finder.ps_modules) > 0
    assert len(dep_finder.cs_utils_wrapper) > 0

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('ansible_powershell_common_invalid')
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:10:35.766252
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    obj = PSModuleDepFinder()
    # Test scan_exec_script method
    obj.scan_exec_script("ansible_powershell_common")
    assert obj.exec_scripts["ansible_powershell_common"]

# Generated at 2022-06-16 21:10:56.526858
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script returns the expected value
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = 'test_name'
    # Act
    ps_module_dep_finder.scan_exec_script(name)
    # Assert
    assert ps_module_dep_finder.exec_scripts[name] == b'\n'


# Generated at 2022-06-16 21:11:07.747744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of the PSModuleDepFinder class
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Test scan_exec_script with a valid script
    dep_finder.scan_exec_script('win_package')

    # Test scan_exec_script with an invalid script
    try:
        dep_finder.scan_exec_script('invalid_script')
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")



# Generated at 2022-06-16 21:11:16.543280
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:30.685102
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script()
    # Test scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #   None
    #
    # Returns:
    #   None
    #
    # Raises:
    #   None

    # Create an instance of PSModuleDepFinder
    dep_finder = PSModuleDepFinder()

    # Test scan_exec_script with a valid script name
    dep_finder.scan_exec_script("powershell_base")

    # Test scan_exec_script with an invalid script name
    try:
        dep_finder.scan_exec_script("powershell_base_invalid")
    except AnsibleError:
        pass

# Generated at 2022-06-16 21:11:42.441039
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'not_a_script'" in str(e)
    else:
        assert False, "AnsibleError not raised"

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("basic")
    except AnsibleError as e:
        assert False, "AnsibleError raised: %s" % str(e)

    # Test that scan_exec_script does not raise an error when the script is found


# Generated at 2022-06-16 21:11:50.771332
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("test_script")
    assert dep_finder.exec_scripts["test_script"] == b"test_script"

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:12:00.813827
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:09.516046
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:22.266214
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    obj = PSModuleDepFinder()
    # Call method scan_exec_script with valid arguments
    obj.scan_exec_script('ansible_powershell_common')
    # Call method scan_exec_script with valid arguments
    obj.scan_exec_script('ansible_powershell_common')
    # Call method scan_exec_script with valid arguments
    obj.scan_exec_script('ansible_powershell_common')
    # Call method scan_exec_script with valid arguments
    obj.scan_exec_script('ansible_powershell_common')
    # Call method scan_exec_script with valid arguments
    obj.scan_exec_script('ansible_powershell_common')
    # Call method scan_exec_script with valid arguments

# Generated at 2022-06-16 21:12:29.754014
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with a script that does not exist
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:12:58.077029
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:07.646679
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a unit test for the scan_exec_script method of the PSModuleDepFinder class.
    #
    # This test will test the scan_exec_script method of the PSModuleDepFinder class.
    #
    # setup test
    dep_finder = PSModuleDepFinder()
    #
    # execute test
    dep_finder.scan_exec_script("win_package")
    #
    # verify results
    assert dep_finder.exec_scripts["win_package"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
   

# Generated at 2022-06-16 21:13:19.912142
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:26.805821
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:39.861155
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script
    #
    #     Test scan_exec_script method of class PSModuleDepFinder
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Test scan_exec_script with a valid script
    ps_module_dep_finder.scan_exec_script("test_script")
    assert "test_script" in ps_module_dep_finder.exec_scripts.keys()

    # Test scan_exec_script with an invalid script

# Generated at 2022-06-16 21:13:48.790324
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:01.754865
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:13.629792
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertTo"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertFrom"]

# Generated at 2022-06-16 21:14:19.286128
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_base')
    assert 'powershell_base' in dep_finder.exec_scripts
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.common' in dep_finder.ps_modules
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.base' in dep_finder.ps_modules

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script('invalid_script')
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:14:30.456345
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
#!/usr/bin/python

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()
"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Test with a module that has a builtin dependency

# Generated at 2022-06-16 21:14:50.850345
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"#!/usr/bin/python\n"
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.exec_scripts) == 0

    # Test with a module that has a dependency on a builtin module_util
    module_data = b"#!/usr/bin/python\n#Requires -Module Ansible.ModuleUtils.Foo\n"
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert len

# Generated at 2022-06-16 21:14:56.588066
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Legacy"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"] is not None


# Generated at 2022-06-16 21:15:06.867683
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script() returns the expected result.
    #
    # Args:
    #     name: The name of the script to scan.
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Test that scan_exec_script() returns the expected result.
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert dep_finder.exec_scripts["ansible_powershell_common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None