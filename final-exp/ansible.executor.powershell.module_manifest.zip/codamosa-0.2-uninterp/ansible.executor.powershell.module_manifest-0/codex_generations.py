

# Generated at 2022-06-16 21:05:43.222342
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:05:46.241390
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-16 21:05:55.834535
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:01.930722
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-16 21:06:08.989121
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:19.979319
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:33.223773
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:06:40.033981
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error if the script is not found.
    dep_finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        dep_finder.scan_exec_script("not_a_script")

    # Test that scan_exec_script adds the script to the exec_scripts dict.
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_ping")
    assert "win_ping" in dep_finder.exec_scripts

    # Test that scan_exec_script adds the script to the exec_scripts dict.
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_ping")
    assert "win_ping" in dep_finder.exec_scripts

    # Test that scan_exec

# Generated at 2022-06-16 21:06:48.760055
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("common")
    assert dep_finder.exec_scripts["common"] is not None

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-16 21:06:56.586987
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:17.777146
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test when name is not in self.exec_scripts.keys()
    # Test when name is in self.exec_scripts.keys()
    pass


# Generated at 2022-06-16 21:07:27.878685
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:41.972761
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:07:53.102588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid name
    finder = PSModuleDepFinder()
    finder.scan_exec_script("win_command")
    assert finder.exec_scripts["win_command"] is not None
    assert finder.exec_scripts["win_command"] != ""
    assert finder.exec_scripts["win_command"] != b""
    assert finder.exec_scripts["win_command"] != " "
    assert finder.exec_scripts["win_command"] != b" "
    assert finder.exec_scripts["win_command"] != "\n"
    assert finder.exec_scripts["win_command"] != b"\n"
    assert finder.exec_scripts["win_command"] != "\r"
    assert finder.exec_scripts["win_command"] != b"\r"
    assert finder

# Generated at 2022-06-16 21:08:05.243070
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Facts"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Security"]

# Generated at 2022-06-16 21:08:07.313989
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    obj = PSModuleDepFinder()
    # Call method scan_exec_script of PSModuleDepFinder class
    obj.scan_exec_script("name")


# Generated at 2022-06-16 21:08:12.394876
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert len(dep_finder.exec_scripts) == 1
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-16 21:08:20.195674
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell"] is not None

    # Test with an invalid script
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid_script")
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError was not raised"



# Generated at 2022-06-16 21:08:25.913169
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:08:31.225068
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")
    assert dep_finder.exec_scripts["exec_wrapper"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.RawExecute"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Safer"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.SaferPSData"]

# Generated at 2022-06-16 21:09:02.829579
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert dep_finder.exec_scripts["powershell_base"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToJson"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.ConvertToXml"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Powershell.Errors"]

# Generated at 2022-06-16 21:09:16.245055
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test if the method scan_exec_script of class PSModuleDepFinder
    # can find the script in lib/ansible/executor/powershell
    # and scan the script for any dependencies
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert finder.exec_scripts["common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell"]
    assert finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert finder.ps_modules["Ansible.ModuleUtils.Url"]
    assert finder.ps_modules["Ansible.ModuleUtils.Win32"]

# Generated at 2022-06-16 21:09:28.139402
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b'''
#!/usr/bin/env powershell

$ANSIBLE_METADATA = @{
    'metadata_version' => '1.0',
    'supported_by' => 'community',
    'status' => 'preview'
}

$ANSIBLE_MODULE_ARGS = @{
    'name' => 'foo'
}

Write-Output "Hello world"
'''
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)

    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
   

# Generated at 2022-06-16 21:09:42.151333
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:09:49.037762
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script
    #
    # Args:
    #    name (str): name of the script to scan
    #
    # Returns:
    #    None
    #
    # Raises:
    #    AnsibleError: if the script cannot be found
    #
    # Example:
    #    >>> test_PSModuleDepFinder_scan_exec_script()
    #
    pass



# Generated at 2022-06-16 21:09:52.313807
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented yet.
    pass


# Generated at 2022-06-16 21:09:55.316855
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # of class PSModuleDepFinder
    #
    # This test is not yet implemented.
    pass


# Generated at 2022-06-16 21:10:02.180988
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script of class PSModuleDepFinder
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "powershell_wrapper"

    # Act
    ps_module_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_module_dep_finder.exec_scripts[name] is not None


# Generated at 2022-06-16 21:10:07.957830
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a module that has no dependencies
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    Write-Host "foo is $foo"
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}

    # Test with a module that has a dependency on a builtin util
    module_data = b"""
    param(
        [Parameter(Mandatory=$true)]
        [string]$foo
    )

    #Requires -Module Ansible.ModuleUtils.Legacy
    Write-Host "foo is $foo"
    """

# Generated at 2022-06-16 21:10:21.611741
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This is a test for the scan_exec_script method of the PSModuleDepFinder
    # class. This method scans lib/ansible/executor/powershell for scripts used
    # in the module exec side. It also scans these scripts for any dependencies.
    #
    # This test will check that the method scans the correct file and that it
    # scans the file for dependencies.
    #
    # The test will also check that the method raises an error if the file
    # cannot be found.
    #
    # The test will also check that the method does not scan the file if it has
    # already been scanned.

    # Create a PSModuleDepFinder object
    dep_finder = PSModuleDepFinder()

    # Create

# Generated at 2022-06-16 21:10:46.653468
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    # of class PSModuleDepFinder
    #
    # This test is not implemented
    pass


# Generated at 2022-06-16 21:10:58.844911
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:10.072770
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to

# Generated at 2022-06-16 21:11:18.079513
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:32.020702
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:42.627507
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:49.050844
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-16 21:11:59.089842
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:08.623759
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:12:21.473371
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module method of class PSModuleDepFinder
    # Test with a module that has no dependencies
    finder = PSModuleDepFinder()
    module_data = b"#!/usr/bin/env powershell\n"
    finder.scan_module(module_data)
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}

    # Test with a module that has a dependency on a builtin module_util
    finder = PSModuleDepFinder()
    module_data = b"#!/usr/bin/env powershell\n" \
                  b"#Requires -Module Ansible.ModuleUtils.Foo\n"

# Generated at 2022-06-16 21:12:55.173783
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:06.103685
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:18.473460
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:26.425971
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("script")
    assert dep_finder.exec_scripts["script"] == b"#!/usr/bin/python\n"
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Common"] == {'data': b'#!/usr/bin/python\n', 'path': 'ansible/module_utils/common.psm1'}

    # Test with an invalid script name
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("invalid")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-16 21:13:39.329006
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:13:48.537811
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-16 21:14:01.561813
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script raises an error when the script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("not_a_script")
        assert False, "AnsibleError was not raised"
    except AnsibleError:
        pass

    # Test that scan_exec_script does not raise an error when the script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("powershell_base")
    except AnsibleError:
        assert False, "AnsibleError was raised"

    # Test that scan_exec_script adds the script to the exec_scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")

# Generated at 2022-06-16 21:14:13.628862
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_wrapper')
    assert dep_finder.exec_scripts['powershell_wrapper'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Common'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Process'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.Convert'] is not None
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ConvertToJson'] is not None
    assert dep_finder.ps

# Generated at 2022-06-16 21:14:19.441430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()
    # Call method scan_exec_script of PSModuleDepFinder class
    ps_module_dep_finder.scan_exec_script("ansible_module_common")
    # Check if the method scan_exec_script of PSModuleDepFinder class returns the expected result

# Generated at 2022-06-16 21:14:30.569713
# Unit test for method scan_exec_script of class PSModuleDepFinder