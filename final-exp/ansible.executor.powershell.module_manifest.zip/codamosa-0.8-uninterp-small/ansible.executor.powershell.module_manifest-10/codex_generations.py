

# Generated at 2022-06-24 18:57:39.413516
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = set()

    p_s_module_dep_finder_0.scan_exec_script("encoding")

    assert p_s_module_dep_finder_0.ps_modules["Ansible.ModuleUtils.Powershell._Encoding"]["path"] == "ansible/module_utils/powershell/_encoding.psm1"


# Generated at 2022-06-24 18:57:49.560048
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    new_module_0 = resource_from_fqcr("module_utils.module_utils_module", "ansible_collections.namespace.collection", "plugins")
    new_module_2 = resource_from_fqcr("module_utils.module_utils_module", "ansible_collections.namespace.collection", "plugins")
    new_module_1 = resource_from_fqcr("module_utils.module_utils_module", "ansible_collections.namespace.collection", "plugins")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Module utils used in a collection module_utils

# Generated at 2022-06-24 18:57:53.608552
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script('ansible_powershell_stdlib')
    assert p_s_module_dep_finder.exec_scripts['ansible_powershell_stdlib']


# Generated at 2022-06-24 18:58:00.607914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper")
    p_s_module_dep_finder_0.scan_exec_script("ps_exec_wrapper")
    # p_s_module_dep_finder_0.scan_exec_script("time_exec_wrapper")
    random_name = "not_a_real_script" + str(random.randint(0, 2147483647))

# Generated at 2022-06-24 18:58:10.823209
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 18:58:14.475087
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case_0()


# Generated at 2022-06-24 18:58:20.236365
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with short-circuit condiiton
    if p_s_module_dep_finder_0.exec_scripts:
        pass

    # Test with throw condiiton
    exec_script = p_s_module_dep_finder_0.scan_exec_script('name')
    if exec_script is None:
        exec_script = 1

    assert(exec_script == 1)


# Generated at 2022-06-24 18:58:23.266711
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "Init"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:30.311750
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = r'GenericModule'
    try:
        p_s_module_dep_finder_0.scan_exec_script(name);
    except (Exception) as err:
        raise Exception('Could not scan_exec_script(%s) for PSModuleDepFinder: %s' % (name, err));


# Generated at 2022-06-24 18:58:39.597302
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for module_data being a string when wrapper is False and powershell is True
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module("module_data", fqn=None, wrapper=False, powershell=True)

    # Test for module_data being a string when wrapper is False and powershell is False
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_2.scan_module("module_data", fqn=None, wrapper=False, powershell=False)

    # Test for module_data being a string when wrapper is True and powershell is True
    p_s_module_dep_finder_3 = PSModuleDepFinder()
    p_s_

# Generated at 2022-06-24 18:59:08.917216
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    try:
        p_s_module_dep_finder_0.scan_exec_script("Get-Random")
    except Exception as e:
        assert str(e) == "Could not find executor powershell script for 'Get-Random'"


# Generated at 2022-06-24 18:59:19.887154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Test the following case
    # Collects info on the dependencies of a PowerShell module.  It will recursively
    # scan a module and any module_utils included by that module, gathering the
    # names of each module util and its associated data.
    #
    # :arg module_data: The contents of a module to scan for dependencies.
    # :arg wrapper: Set this to True if this is an exec wrapper, False otherwise.
    # :arg powershell: Set this to False if the module is a CSharp module.
    #
    # The module_data will be parsed for lines with '#Requires -Module' or
    # '#AnsibleRequires -PowerShell'.  It will then load the associated resources
    # and recursively scan those modules until the full set

# Generated at 2022-06-24 18:59:24.587004
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    script_name="dot_net_version"
    p_s_module_dep_finder_1.scan_exec_script(script_name)
    assert p_s_module_dep_finder_1.exec_scripts["dot_net_version"] is not None


# Generated at 2022-06-24 18:59:35.350859
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    rand_int_seq = random.randint(1,100)
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b"#Requires -Module Ansible.ModuleUtils.Foo")
    p_s_module_dep_finder_1.scan_module(b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo")
    p_s_module_dep_finder_1.scan_module(b"#AnsibleRequires -PowerShell ansible_collections.test.test1.plugins.module_utils.Foo")
    p_s_modul

# Generated at 2022-06-24 18:59:39.086139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = 'exec_wrappy'
    p_s_module_dep_finder.scan_exec_script(name)


# Generated at 2022-06-24 18:59:44.985868
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = " # Requires -Module Ansible.ModuleUtils.MyPSModuleUtil\n"
    p_s_module_dep_finder_0.scan_module(module_data)


# Generated at 2022-06-24 18:59:54.487442
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 18:59:59.853088
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Mock method and attribute of class PSModuleDepFinder
    class PSModuleDepFinderMock():
        def __init__(self):
            self.ps_modules = dict()
            self.cs_utils_wrapper = dict()
            self.cs_utils_module = dict()
            self.ps_version = None
            self.os_version = None
            self.become = False

        def scan_exec_script(self, name):
            self.exec_scripts = dict()
            name = to_text(name)
            data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
            if data is None:
                raise AnsibleError("Could not find executor powershell script "
                                   "for '%s'" % name)

            b_data = to

# Generated at 2022-06-24 19:00:07.672574
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Input arguments
    fqn = "ansible_collections.ansible.builtin.ping"
    module_data = "Test data"
    wrapper = False
    powershell = True

    # Expected return
    # Return value
    return_1 = None

    # Call the method
    return_2 = p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)

    # Return value
    assert return_2 == return_1


# Generated at 2022-06-24 19:00:11.334798
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('network_cli')



# Generated at 2022-06-24 19:00:30.867303
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("utils")


# Generated at 2022-06-24 19:00:32.846137
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 19:00:39.141356
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('NotAnExecFile')


# Generated at 2022-06-24 19:00:44.767390
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def do_test(module_data, fqn=None, wrapper=False, powershell=True, expected=None):
        p_s_module_dep_finder = PSModuleDepFinder()
        actual = p_s_module_dep_finder.scan_module(module_data, fqn=fqn, wrapper=wrapper, powershell=powershell)
        assert actual == expected

    data = bytearray()
    do_test(data)

    data = bytearray()
    do_test(data)

    data = bytearray()
    do_test(data)

    data = bytearray()
    do_test(data)

    data = bytearray()
    do_test(data)


# Generated at 2022-06-24 19:00:49.938080
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    test_name = to_text('')
    p_s_module_dep_finder_1.scan_exec_script(test_name)


# Generated at 2022-06-24 19:00:55.030307
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script('Main') == None


# Generated at 2022-06-24 19:01:02.642346
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    data_0 = '# AnsibleRequires -PowerShell'
    fqn_0 = 'Ansible.windows.win_stat'
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(data_0, fqn_0, wrapper_0, powershell_0)
    data_1 = '# AnsibleRequires -PowerShell'
    fqn_1 = 'Ansible.windows.win_stat'
    wrapper_1 = False
    powershell_1 = True
    p_s_module_dep_finder_0.scan_module(data_1, fqn_1, wrapper_1, powershell_1)

# Generated at 2022-06-24 19:01:11.713658
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    finder = PSModuleDepFinder()

# Generated at 2022-06-24 19:01:16.977946
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert 'wrappers' in p_s_module_dep_finder_0.exec_scripts.keys()
    assert 'ansible_module_wrapper' in p_s_module_dep_finder_0.exec_scripts.keys()

# Test methods

# Generated at 2022-06-24 19:01:21.871388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = to_text(random.randint(0, 9), errors='surrogate_or_strict')
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:02:12.083027
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Network.Cisco.Ios.Config'
    # p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 19:02:19.615830
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Check for required module dependencies for the TaskEngine PowerShell script
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    expected_exec_scripts = {
        u'powershell_base': b'#ANSIBLE_METADATA\n{\n    "author": "Ansible, Inc.",\n    "metadata_version": "1.0",\n    "description": "",\n    "license": "GPLv3+",\n    "summary": "",\n    "version": "1.0"\n}\n\n#'
    }

# Generated at 2022-06-24 19:02:29.158044
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import base64
    import tempfile
    import os

    test_module_0 = '''\
#Requires -Module Ansible.ModuleUtils.Test1
#Requires -Module Test2
#Requires -Module Test3
'''
    expected_result_0 = set()

    tempdir_0 = tempfile.gettempdir()
    path_to_module_0 = os.path.join(tempdir_0, 'test_module.psm1')
    with open(path_to_module_0, 'w') as f:
        f.write(test_module_0)

    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:02:34.283236
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # 1)
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    name_2 = to_text("TestStr")
    with pytest.raises(AnsibleError):
        p_s_module_dep_finder_2.scan_exec_script(name_2)


# Generated at 2022-06-24 19:02:39.770467
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Define argument 'name'
    name = ''
  
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:02:44.166509
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("foo_1")
    # Add a test hook.
    p_s_module_dep_finder_1.scan_exec_script("foo_2")


# Generated at 2022-06-24 19:02:51.346596
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('get_tmp_path')
    assert p_s_module_dep_finder_0.exec_scripts.keys()[0] == 'get_tmp_path'


# Generated at 2022-06-24 19:02:59.788483
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    # Input data for unit test
    test_data = [
        {
            "script_name": "command_execution",
            "script_data": "blah blah blah"
        },
        {
            "script_name": "complex_nested_module_util",
            "script_data": "blah blah blah"
        }
    ]

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    for index, data in enumerate(test_data):
        # We add all of our scripts to the test_data, but we delete any
        # dictionary entries that weren't actually called in order to validate
        # that our method only added the expected scripts.
        if 'script_name' in data.keys():
            del data['script_name']

# Generated at 2022-06-24 19:03:06.043614
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Define input parameters
    name = 'powershell_script.ps1'

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:03:09.075506
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_str_0 = random.choice(string.ascii_letters)
    p_s_module_dep_finder_0.scan_exec_script(n_str_0)


# Generated at 2022-06-24 19:04:46.419110
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(to_bytes(''), fqn=None, wrapper=False, powershell=True)


# Generated at 2022-06-24 19:04:48.712803
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('something.ps1')


# Generated at 2022-06-24 19:04:59.841903
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_module(to_bytes("#Requires -Version 1"))
    p_s_module_dep_finder.scan_module(to_bytes("#Requires -Version 2"))
    p_s_module_dep_finder.scan_module(to_bytes("#Requires -Module Ansible.ModuleUtils.MyModule"))
    p_s_module_dep_finder.scan_module(to_bytes("#AnsibleRequires -PowerShell Ansible.ModuleUtils.YourModule"))
    p_s_module_dep_finder.scan_module(to_bytes("#AnsibleRequires -PowerShell Ansible.ModuleUtils.HisModule -Optional"))


# Generated at 2022-06-24 19:05:08.278908
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Case 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = (b' #Requires -Module  Ansible')
    fqn_0 = "Ansible.git"
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0,
                                        wrapper_0, powershell_0)

    # Case 1
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = (b' #AnsibleRequires -CSharpUtil ansible_collections.ansible.windows.plugins')
    fqn_1 = "Ansible.git"
    wrapper_1 = False
    powers

# Generated at 2022-06-24 19:05:10.987675
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'name_0'
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:05:16.940177
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'test_data', 'test_scan_exec_script.ps1')

    with open(test_file, 'rb') as f:
        data = f.read()

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(data, wrapper=True, powershell=True)


# Generated at 2022-06-24 19:05:21.089375
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    var_name_0 = p_s_module_dep_finder_0.scan_exec_script(name="testvalue1")


# Generated at 2022-06-24 19:05:31.454555
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # The first test case tests whether the function can handle normal data
    module_data0 = "#Requires -Module Ansible.ModuleUtils.Test0"
    module_data1 = "#AnsibleRequires -Powershell Ansible.ModuleUtils.Test1"
    module_data2 = "#AnsibleRequires -Powershell Ansible.ModuleUtils.Test2"
    module_data3 = "#AnsibleRequires -Wrapper Ansible.ModuleUtils.Test3"
    module_data4 = "#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test4"
    module_data5 = "#Requires -Version 5.1"
    module_data6 = "#AnsibleRequires -OsVersion 10.1"
    module_data7 = "#AnsibleRequires -Become"
    wrapper = True
    p_s

# Generated at 2022-06-24 19:05:37.409342
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = ''
    try:
        p_s_module_dep_finder.scan_exec_script(name)
    except Exception as e:
        assert True # desired state {'result': 'desired exception not caught'}
    else:
        assert False # desired state {'result': 'desired exception not caught'}


# Generated at 2022-06-24 19:05:44.357122
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn = 'ansible_collections.ansible.builtin.command'
    module_data = _slurp('test/fixtures/module_utils/command.psm1')
    p_s_module_dep_finder_0.scan_module(module_data, fqn)
    assert p_s_module_dep_finder_0.ps_modules['Ansible.ModuleUtils.CommonUtils']['path'] == 'lib/ansible/module_utils/common.psm1'
