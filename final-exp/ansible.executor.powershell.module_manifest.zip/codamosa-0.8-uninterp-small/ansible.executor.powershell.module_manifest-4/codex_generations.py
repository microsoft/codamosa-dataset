

# Generated at 2022-06-24 18:57:34.762825
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # str -> PSModuleDepFinder.scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    p_s_module_dep_finder_0.scan_module("", "", False, True)


# Generated at 2022-06-24 18:57:42.217126
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = base64.b64decode(b'IyBpbiBwZXJzaXN0IHN0b3JlLCBsaXN0IG9mIG1vZHVsZSB1dGlscyBpbXBvcnRlZApkZWZpbmUgX19yZXF1aXJlcygpeyM=')
    fqn_0 = 'my.collection.my_module'
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)
    assert True


# Generated at 2022-06-24 18:57:44.354110
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("data")


# Generated at 2022-06-24 18:57:48.930852
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    util_name_0 = 'util_name_0'
    # An exception should only be raised after a failed call to the method.
    # No exception should be raised here.
    p_s_module_dep_finder_0.scan_exec_script(util_name_0)


# Generated at 2022-06-24 18:57:54.214739
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'test'
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except:
        pass


# Generated at 2022-06-24 18:57:55.876413
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result = PSModuleDepFinder.scan_exec_script(["test_case_0"])


# Generated at 2022-06-24 18:58:05.659668
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    module_data = b"#Requires -Module Ansible.ModuleUtils.Basic"
    fqn = "Ansible.Windows.hpe"
    wrapper = True
    p_s_module_dep_finder.scan_module(module_data, fqn, wrapper)

# Generated at 2022-06-24 18:58:12.120984
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 18:58:26.258934
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("wrapper")
    p_s_module_dep_finder_0_exec_scripts = p_s_module_dep_finder_0.exec_scripts
    assert 1 == len(p_s_module_dep_finder_0_exec_scripts)
    p_s_module_dep_finder_0_exec_scripts_0 = p_s_module_dep_finder_0_exec_scripts["wrapper"]
    p_s_module_dep_finder_0_exec_scripts_0_version_info = p_s_module_dep_finder_0_exec_scripts_0.version_info

# Generated at 2022-06-24 18:58:39.411995
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    t_e_i_temp_file_0 = tempfile.NamedTemporaryFile()

# Generated at 2022-06-24 18:58:53.181364
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common')


# Generated at 2022-06-24 18:58:58.834782
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("powershell")

test_case_0()
test_PSModuleDepFinder_scan_exec_script()



# Generated at 2022-06-24 18:59:09.736235
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("shim_0")
    assert p_s_module_dep_finder_1.exec_scripts == {"shim_0": b"#!powershell\n$stdout.write(\"\"\"{\\\"msg\\\": \\\"shim_0\\\"}\\n\\n\"\"\")\n"}, "Expected %s, got %s" % ({"shim_0": b"#!powershell\n$stdout.write(\"\"\"{\\\"msg\\\": \\\"shim_0\\\"}\\n\\n\"\"\")\n"}, p_s_module_dep_finder_1.exec_scripts)


# Generated at 2022-06-24 18:59:20.714352
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = base64.b64decode('IyBSZXF1aXJlcyAtTW9kdWxlIEFuc2libGUuTW9kdWxlVXRpbHMucmVzb3VyY2U=')
    fqn_1 = 'ansible.windows.win_ping'
    p_s_module_dep_finder_1.scan_module(module_data_1, fqn_1)
    # test that the list ps_modules is not empty
    ps_modules_1 = p_s_module_dep_finder_1.ps_modules
    assert ps_modules_1
    # test that "Resource" key is in the ps_modules dictionary

# Generated at 2022-06-24 18:59:23.546218
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("my_exec_script")



# Generated at 2022-06-24 18:59:35.572331
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test 1
    dep_finder_1 = PSModuleDepFinder()
    from ansible_collections.ansible.posix.plugins.modules.setup import *
    dep_finder_1.scan_module(pkgutil.get_data("ansible_collections.ansible.posix.plugins.modules", "setup.psm1"))
    assert len(dep_finder_1.ps_modules) == 1
    assert len(dep_finder_1.cs_utils_wrapper) == 0
    assert len(dep_finder_1.cs_utils_module) == 0
    assert len(dep_finder_1.exec_scripts) == 0
    assert 'Ansible.ModuleUtils._ModuleUtil_common' in dep_finder_1.ps_modules
    assert dep_finder_1.ps_version is None

# Generated at 2022-06-24 18:59:38.260181
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    return


# Generated at 2022-06-24 18:59:49.069282
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes as _to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.error import URLError, HTTPError
    from ansible.module_utils.parsing.convert_bool import boolean
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = 'sample'
    # The following code will raise an URLError exception if the specified
    # URL doesn't exist, or an HTTPError exception if the server is down.

# Generated at 2022-06-24 18:59:54.620378
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("noop")


# Generated at 2022-06-24 18:59:58.074688
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_exec_script_0 = "test.ps1"

    p_s_module_dep_finder_0.scan_exec_script(test_exec_script_0)


# Generated at 2022-06-24 19:00:25.196962
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Set up execution environment
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # TODO: Invoke method with valid parameters
    # TODO: Validate method outputs


# Generated at 2022-06-24 19:00:31.927426
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_exec_script("FAKE_SCRIPT_NAME")
    except AnsibleError as error:
        assert "Could not find executor powershell script for 'FAKE_SCRIPT_NAME'" in error.message


# Generated at 2022-06-24 19:00:41.902604
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script('netbios')
    assert len(p_s_module_dep_finder.exec_scripts.keys()) == 1
    assert 'netbios' in p_s_module_dep_finder.exec_scripts.keys()
    assert len(p_s_module_dep_finder.ps_modules.keys()) == 5
    assert 'Ansible.PowerShell' in p_s_module_dep_finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Legacy' in p_s_module_dep_finder.ps_modules.keys()

# Generated at 2022-06-24 19:00:44.194725
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = "Test string"
    p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 19:00:52.105169
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Invoke method scan_module of the created instance

# Generated at 2022-06-24 19:00:56.662787
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a wrapper script that has no dependencies
    test_PSModuleDepFinder_scan_exec_script_0()
    # Test with a wrapper script that has a dependency on a PS Module util
    test_PSModuleDepFinder_scan_exec_script_1()
    # Test with a wrapper script that has a dependency on a CS Module util
    test_PSModuleDepFinder_scan_exec_script_2()


# Generated at 2022-06-24 19:01:00.739404
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_exec_script_name = "test_exec_script_name_1088861358"

    try:
        p_s_module_dep_finder_0.scan_exec_script(test_exec_script_name)
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:01:03.077158
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Test PSModuleDepFinder scan_module")
    ps_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 19:01:08.075665
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "name_0"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
        assert False
    except AnsibleError as err:
        pass


# Generated at 2022-06-24 19:01:13.593121
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case = PSModuleDepFinder()
    script_name = str(random.randint(0, 100))
    native_data = to_native(test_case.exec_scripts[script_name], errors='strict')


# Generated at 2022-06-24 19:02:05.483969
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    wrapper_name = "get_powershell_base64_wrapper"

    # calling scan_exec_script with args
    p_s_module_dep_finder_1.scan_exec_script(wrapper_name)



# Generated at 2022-06-24 19:02:10.306725
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script(".version")


# Generated at 2022-06-24 19:02:20.086928
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_module("#Requires -Modules Ansible.ModuleUtils.Foo") == None
    assert p_s_module_dep_finder_1.scan_module("#Requires -Modules Ansible.ModuleUtils.Bar") == None
    assert p_s_module_dep_finder_1.scan_module("using Ansible.ModuleUtils.Foo.Bar;") == None
    assert p_s_module_dep_finder_1.scan_module("using ansible_collections.ansible.foo.plugins.module_utils.Foo.Bar;") == None


# Generated at 2022-06-24 19:02:33.179050
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_0.scan_exec_script(name='nonexistent')
    assert 'Could not find executor powershell script for \'nonexistent\'' in to_native(excinfo.value)

    p_s_module_dep_finder_0.scan_exec_script('test_scan_exec_script')
    assert 'test_scan_exec_script.ps1' in p_s_module_dep_finder_0.exec_scripts.keys()


# Generated at 2022-06-24 19:02:43.272610
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {}
    p_s_module_dep_finder_0.cs_utils_wrapper = {}
    p_s_module_dep_finder_0.ps_modules = {}
    p_s_module_dep_finder_0.become = True
    p_s_module_dep_finder_0.ps_version = '2.9'
    p_s_module_dep_finder_0.os_version = '2.8'

# Generated at 2022-06-24 19:02:49.668007
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 19:02:59.141277
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create an instance of the PSModuleDepFinder class and set the ps_modules
    # instance variable to an empty dictionary to prevent the test from failing
    # during fetching of the module_utils.
    #
    # This test will check that the scan_exec_script method is fetching the
    # right powershell script and reading its content
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.ps_modules = {}
    p_s_module_dep_finder_1.scan_exec_script('powershell_script')

    # Assert that exec_scripts contains the 'powershell_script' script
    assert p_s_module_dep_finder_1.exec_scripts['powershell_script']
    # Assert that the content of the powershell_script

# Generated at 2022-06-24 19:03:09.906164
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Run the test for the added module_util and ensure that the new method
    # is being invoked.
    sample_module_util_path = os.path.join("test", "units", "module_utils", "test_module_utils", "sample_module_util.ps1")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_module_utils/sample_module_util")

    # Read the module_util and it's expected output, compute the SHA1 hash of
    # the module_util to ensure that the module util is being included as a
    # dependency.
    sample_module_util_data = _slurp(sample_module_util_path)
    sample_module_util_sha1 = _base64

# Generated at 2022-06-24 19:03:21.230277
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.WinCommon")
    assert(len(dep_finder.ps_modules) == 1)
    assert(b"Ansible.ModuleUtils.WinCommon" in dep_finder.ps_modules)
    assert(dep_finder.ps_version is None)
    assert(dep_finder.os_version is None)
    assert(dep_finder.become is False)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"#AnsibleRequires -Powershell Ansible.ModuleUtils.WinCommon -Optional")
    assert(len(dep_finder.ps_modules) == 1)

# Generated at 2022-06-24 19:03:28.613564
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test for a happy path case.
    p_s_module_dep_finder_0.scan_module("#AnsibleRequires -CSharpUtil Ansible.CollectionUtils.ArgumentSpec;\n")

    # Test for an unhappy path case.
    p_s_module_dep_finder_0.scan_module("#Requires -Modules Ansible.ModuleUtils.CommonUtils;\n")
