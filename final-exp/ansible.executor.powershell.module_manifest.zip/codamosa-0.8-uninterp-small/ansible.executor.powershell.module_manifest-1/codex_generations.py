

# Generated at 2022-06-24 18:57:30.727056
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ret_val_0 = None
    script_name = "test_script"
    def _test_mock_1():
        return script_name
    _test_mock_1 = _test_mock_1

    script_name = to_text(script_name)
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {
        to_text(script_name): ""
    }
    def _test_mock_0(mock_0, mock_1):
        assert mock_0 == to_text(script_name)
        assert mock_1 == script_name
        return

    _test_mock_0 = _test_mock_0


# Generated at 2022-06-24 18:57:32.602972
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module('\n')


# Generated at 2022-06-24 18:57:41.388105
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0._add_module("Ansible.ModuleUtils.Common", ".psm1", "ansible.collections.foo.bar.plugins.modules.baz", False)
    p_s_module_dep_finder_0._add_module("Ansible.ModuleUtils.Common", ".psm1", "ansible.collections.foo.bar.plugins.modules.baz", False)
    p_s_module_dep_finder_0._add_module("Ansible.ModuleUtils.Powershell", ".psm1", "ansible.collections.foo.bar.plugins.modules.baz", False)

# Generated at 2022-06-24 18:57:49.927638
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b'     #Requires -Modules Ansible.ModuleUtils.TestModuleUtil\n')
    p_s_module_dep_finder_1.scan_module(b'#AnsibleRequires -PowerShell: Ansible.ModuleUtils.TestModuleUtil\n')
    p_s_module_dep_finder_1.scan_module(b'#AnsibleRequires -PowerShell: ansible_collections.ns.coll.plugins.module_utils.TestModuleUtil')
    assert p_s_module_dep_finder_1.ps_modules.get('Ansible.ModuleUtils.TestModuleUtil') is not None
    assert p_s_module_dep

# Generated at 2022-06-24 18:57:53.608313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "ansible_module_b_a_s_e"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:57:54.925380
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name="wrapper")


# Generated at 2022-06-24 18:57:57.225512
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    var_0 = 'example_exec'
    p_s_module_dep_finder_0.scan_exec_script(var_0)


# Generated at 2022-06-24 18:58:03.159695
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script(): 
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    test_script = "test_script.ps1"

# Generated at 2022-06-24 18:58:10.719503
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = None
    # Input name is None, raises exception
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_0.scan_exec_script(name)
    assert "Could not find executor powershell script for ''" in str(excinfo.value)
    # Input name is empty string, raises exception
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_0.scan_exec_script("")
    assert "Could not find executor powershell script for ''" in str(excinfo.value)

    # Input name is valid module name and is not present, raises exception

# Generated at 2022-06-24 18:58:17.073718
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    collection_path = os.path.join(C.DEFAULT_COLLECTIONS_PATHS[0], 'ns', 'collection')
    # Get the path for the module which we will use for the test.
    module_path = resource_from_fqcr('ns.collection.test_module')

    # Create the PSModuleDepFinder instance which we will use in the test.
    p_s_module_dep_finder = PSModuleDepFinder()

    # Get the data from the module
    with open(module_path, 'rb') as m:
        module_data = m.read()

    # Get the data from the module_utils in the collection.

# Generated at 2022-06-24 18:58:37.654195
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Call method scan_module of class PSModuleDepFinder
    assert p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.MyModuleUtil')


# Generated at 2022-06-24 18:58:45.673111
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    filename_0 = "lib/ansible/executor/powershell/test.ps1"
    # Unit test for method scan_exec_script of class PSModuleDepFinder
    # Test with name lib/ansible/executor/powershell/test.ps1
    p_s_module_dep_finder_0.scan_exec_script(filename_0)


# Generated at 2022-06-24 18:58:56.273228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    pkgutil.get_data = lambda x, y: '{"a":1}'
    if not os.path.exists(os.path.expanduser('~/.ansible/test_ansible_tmp')):
        os.makedirs(os.path.expanduser('~/.ansible/test_ansible_tmp'))
    with open(os.path.expanduser('~/.ansible/test_ansible_tmp/test.json'), 'w') as f: f.write('{"k": "v"}')
    with open(os.path.expanduser('~/.ansible/test_ansible_tmp/test.ini'), 'w') as f: f.write('[s]\na=b\n')

# Generated at 2022-06-24 18:58:59.675948
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "ansible_powershell_cleanup"
    assert p_s_module_dep_finder_0.scan_exec_script(name_0) == None


# Generated at 2022-06-24 18:59:06.877983
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    from ansible.module_utils._text import to_bytes
    name = to_bytes('fake_name')
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
        assert 0, 'Exception should have been thrown'
    except AnsibleError:
        pass


# Generated at 2022-06-24 18:59:11.348255
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = "Test String"  # String to test the scan_module method with
    fqn_0 = "a_string"  # String to test the scan_module method with
    wrapper_0 = False  # Boolean value to test the scan_module method with
    powershell_0 = True  # Boolean value to test the scan_module method with
    p_s_module_dep_finder_0 = PSModuleDepFinder()  # Instance to call the scan_module method on
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)



# Generated at 2022-06-24 18:59:17.804306
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder_scan_exec_script_0()
    test_PSModuleDepFinder_scan_exec_script_1()
    test_PSModuleDepFinder_scan_exec_script_2()


# Generated at 2022-06-24 18:59:29.724846
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # test cases for method scan_module

# Generated at 2022-06-24 18:59:33.448851
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if not C.DEVELOPMENT:
        raise "not implemented"
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "foo"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:59:35.318564
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModu

# Generated at 2022-06-24 18:59:52.872386
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('powershell')


# Generated at 2022-06-24 19:00:03.092711
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell._redirection import HAS_SEND_ERROR
    HAS_SEND_ERROR = False
    import ansible.executor.powershell
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("_ansible_module_generated")
    assert(p_s_module_dep_finder_0.exec_scripts['_ansible_module_generated'].decode() == '#ANSIBLE_METADATA:{"status": ["stableinterface"], "supported_by": "core"}\n#ANSIBLE_METADATA:{"version": "2.8"}\n#!PSScriptAnalyzerDisableRule Invoke-CimMethodCannotProcessMultiple\n\n')


# Generated at 2022-06-24 19:00:08.070807
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "name_0"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError as e0:
        assert str(e0) == "Could not find executor powershell script for '{0}'".format(name_0)


# Generated at 2022-06-24 19:00:21.072654
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Auxiliary variables that are helpful to the test:

    # This is an example of a module that is written in PowerShell and directly uses a C# util.
    module = b"""\
#Requires -Module Ansible.ModuleUtils.Common
#AnsibleRequires -CSharpUtil Ansible.Basic
#AnsibleRequires -CSharpUtil ansible_collections.my.collection.plugins.module_utils.Crypto -Optional
function Do-Something {
    Write-Debug "[Powershell]: Do-Something"
}
"""

    # This is an example of a C# module that uses C# utils.

# Generated at 2022-06-24 19:00:25.653483
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ansible_powershell_common')
    print(json.dumps(p_s_module_dep_finder_0.__dict__, default=lambda o: o.__dict__))


# Generated at 2022-06-24 19:00:27.735131
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()


# Generated at 2022-06-24 19:00:38.467710
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import io

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {"module1": b"abcdefg"}

# Generated at 2022-06-24 19:00:41.764211
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_name = "common"
    p_s_module_dep_finder_0.scan_exec_script(module_name)
    p_s_module_dep_finder_0.scan_exec_script(module_name)
    p_s_module_dep_finder_0.scan_exec_script("missing")


# Generated at 2022-06-24 19:00:46.882648
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('script1')
    p_s_module_dep_finder_0.scan_exec_script('script2')
    p_s_module_dep_finder_0.scan_exec_script('script3')


# Generated at 2022-06-24 19:00:52.289089
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_exec_script("exec_wrapper") == None


# Generated at 2022-06-24 19:01:15.422479
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder class
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        # Calling the scan_exec_script method of PSModuleDepFinder class with
        # 'python_version' value passed as argument
        p_s_module_dep_finder_0.scan_exec_script("python_version")
        assert True
    except AnsibleError:
        assert False


# Generated at 2022-06-24 19:01:19.675674
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    ret = p_s_module_dep_finder.scan_exec_script(name = "test name")


# Generated at 2022-06-24 19:01:22.466819
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("common")


# Generated at 2022-06-24 19:01:25.925920
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("basic")
    except Exception:
        assert False


# Generated at 2022-06-24 19:01:29.057251
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # call scan_exec_script func
    assert p_s_module_dep_finder_0.scan_exec_script('one')



# Generated at 2022-06-24 19:01:34.108274
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    exec_script_0 = p_s_module_dep_finder_0.scan_exec_script("PSUtils.ps1")


# Generated at 2022-06-24 19:01:37.688819
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p = PSModuleDepFinder()
    # This test does not apply, because the C# function is not supported in Ansible 2.9
    # Test for a valid call to method scan_module of class PSModuleDepFinder
    assert p.scan_module("using Ansible.ModuleUtils.Powershell;\n") == "None"


# Generated at 2022-06-24 19:01:46.519177
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ctypes

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module("a" * 300)
    assert ctypes.sizeof(p_s_module_dep_finder_1.ps_modules) == 0
    assert ctypes.sizeof(p_s_module_dep_finder_1.cs_utils_wrapper) == 0
    assert ctypes.sizeof(p_s_module_dep_finder_1.cs_utils_module) == 0
    assert isinstance(p_s_module_dep_finder_1.ps_version, type(None)) is True
    assert isinstance(p_s_module_dep_finder_1.os_version, type(None)) is True
    assert p_s_module_dep_

# Generated at 2022-06-24 19:01:48.530329
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    result = p_s_module_dep_finder_0.scan_exec_script("Basic")
    assert result is None


# Generated at 2022-06-24 19:01:52.123614
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("Ansible.ModuleUtils.Legacy")


# Generated at 2022-06-24 19:02:05.400975
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()


# Generated at 2022-06-24 19:02:12.934532
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_PSModuleDepFinder_scan_exec_script_exec_name = 'win_ansible_module_wrapper'
    p_s_module_dep_finder_0.scan_exec_script(test_PSModuleDepFinder_scan_exec_script_exec_name)


# Generated at 2022-06-24 19:02:17.543902
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    data_0 = b'\n# requires -module Ansible.ModuleUtils.PSModule2,Ansible.ModuleUtils.PSModule3,Ansible.ModuleUtils.PSModule1\n\n'
    p_s_module_dep_finder_0.scan_module(data_0)


# Generated at 2022-06-24 19:02:22.113442
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Set up test values
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'name'

    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except Exception as e:
        raise AssertionError("Caught exception while executing function 'scan_exec_script': {0}".format(e))


# Generated at 2022-06-24 19:02:25.236666
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name = "powershell_script"
    n_name = to_text(n_name)
    p_s_module_dep_finder_0.scan_exec_script(n_name)


# Generated at 2022-06-24 19:02:37.749637
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 19:02:46.415874
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = _slurp('ansible/modules/cloud/azure/azure_rm_acrmodule.psm1')
    # answer_0 = p_s_module_dep_finder_0.scan_module(module_data_0)
    # assert set(answer_0) == set({"toto", "titi", "tutu"})
    assert 1 == 1


# Generated at 2022-06-24 19:02:50.686963
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("test_exec_script_0")


# Generated at 2022-06-24 19:02:54.277488
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("become_type_mapping")


# Generated at 2022-06-24 19:02:59.606492
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = random.randint(1000, 9999)
    p_s_module_dep_finder_0.scan_exec_script(name_0)
    assert p_s_module_dep_finder_0.exec_scripts.get(name_0) is not None


# Generated at 2022-06-24 19:03:16.951108
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    p_s_module_dep_finder_1.scan_exec_script(wrapper='ansible_powershell_wrapper')


# Generated at 2022-06-24 19:03:22.451960
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    base_path = os.path.join(C.TEST_DIR, 'unit/module_utils/ps_module_deps')
    fqn = 'a.module'

    module_data = load_fixture('test-moduleutils/ps_module_deps/test_file.ps1')
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data, fqn=fqn, wrapper=False,
                                        powershell=True)

    # Validate the module dependencies in test_file.ps1
    assert len(p_s_module_dep_finder_0.ps_modules) == 3
    assert len(p_s_module_dep_finder_0.cs_utils_module) == 1


# Generated at 2022-06-24 19:03:31.184330
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Assign values to variables
    fqn = "Ansible.ModuleUtils.Common.TestModule"
    wrapper = True
    module_data = "TestModule.psm1"
    powershell = True
    result = p_s_module_dep_finder_0.scan_module(module_data, fqn=fqn, wrapper=wrapper, powershell=powershell)

    assert result is None


# Generated at 2022-06-24 19:03:42.756467
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test result of PSModuleDepFinder().scan_exec_script()

    # Test no.1 - Default values
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("")
    assert os.path.isfile(r'C:\WINDOWS\system32\WindowsPowerShell\v1.0\Modules\Ansible.ModuleUtils.Progress.psd1')
    assert p_s_module_dep_finder_0.ps_version == '6.0'
    assert p_s_module_dep_finder_0.os_version == '10.0'
    assert p_s_module_dep_finder_0.become is True

# Generated at 2022-06-24 19:03:46.391318
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("default_wrapper")


# Generated at 2022-06-24 19:03:54.260291
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("run_command")

# Generated at 2022-06-24 19:03:59.613793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    ansible_executor_powershell_0 = p_s_module_dep_finder_1.scan_exec_script("./ansible_collections/ansible/os_windows/plugins/modules/win_ping_0")
    assert (ansible_executor_powershell_0 is None)


# Generated at 2022-06-24 19:04:03.619699
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('clixml')
    p_s_module_dep_finder_0.scan_exec_script('basic')


# Generated at 2022-06-24 19:04:08.499400
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_PSModuleDepFinder_scan_module_0()
    test_PSModuleDepFinder_scan_module_1()
    test_PSModuleDepFinder_scan_module_2()
    test_PSModuleDepFinder_scan_module_3()
    test_PSModuleDepFinder_scan_module_4()


# Generated at 2022-06-24 19:04:13.304238
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    data = to_bytes(b' #Requires -Module Ansible.ModuleUtils.Legacy')
    fqn = 'Ansible.Windows.WinUpdates'
    wrapper = False
    powershell = True
    p_s_module_dep_finder.scan_module(data, fqn, wrapper, powershell)


# Generated at 2022-06-24 19:04:43.954813
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize instance of class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Invoke instance method scan_exec_script with test data
    p_s_module_dep_finder_0.scan_exec_script(p_s_module_dep_finder_0, name="")


# Generated at 2022-06-24 19:04:50.965092
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 19:05:01.016208
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Test scan_module")
    # Create the object for PSModuleDepFinder
    try:
        psm_dep_finder = PSModuleDepFinder()
    except:
        print("Could not create object for PSModuleDepFinder")
        return False

    # define module name and module type
    mod_name = u'Test_Module'
    mod_type = u'.psm1'

    # module_data
    module_data = '#Requires -Module Ansible.ModuleUtils.{name}'

    psm_dep_finder.scan_module(module_data, fqn=mod_name)
    print(psm_dep_finder.ps_modules)
    return True
#
# test_PSModuleDepFinder_scan_module()



# Generated at 2022-06-24 19:05:05.988656
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = ""
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:05:11.273514
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script("pwsh_exec") is None
    assert p_s_module_dep_finder_0.exec_scripts["pwsh_exec"] is not None
    assert p_s_module_dep_finder_0.cs_utils_wrapper["ansible_collections.ansible.builtin.plugins.module_utils.urls"] is not None


# Generated at 2022-06-24 19:05:21.280513
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    
    # Simple case of calling the method
    module_data_0 = b'''#!/usr/bin/python
    import json
    import re
    import os
    import pkgutil
    import random
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.utils.collection_loader import resource_from_fqcr

    import pkgutil
    import random'''

    p_s_module_dep_finder_0.scan_module(module_data_0)

    # more complex case of calling the method

# Generated at 2022-06-24 19:05:24.407844
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "test"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:05:32.008074
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a PSModuleDepFinder object
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Create a str object
    s_0 = 'plugins/module_utils/ios/eos.py'

    # Call method scan_module with parameters: s_0
    p_s_module_dep_finder_0.scan_module(s_0)


# Generated at 2022-06-24 19:05:38.645227
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Using a library to generate random strings
    import random
    import string

    # Generate a test string
    test_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))

    try:
        PSModuleDepFinder.scan_exec_script(None, test_string)
        raise AssertionError("This scan_exec_script call should throw an exception.")
    except Exception:
        pass



# Generated at 2022-06-24 19:05:46.883443
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Testing scan_exec_script of PSModuleDepFinder")
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("Init_Ansible_Module_Util")
    p_s_module_dep_finder_1.scan_exec_script("Facts_Ansible_Module")
    p_s_module_dep_finder_1.scan_exec_script("Init_Ansible_Module_Util")
    if p_s_module_dep_finder_1.exec_scripts.keys() != set(['Init_Ansible_Module_Util', 'Facts_Ansible_Module']):
        raise ValueError("Wrong exec_scripts keys")


# Generated at 2022-06-24 19:06:21.632852
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # setup
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    module_data = """#!/usr/bin/python
import errno
import os
import pkgutil
import re
import sys
from ansible import constants as C
from ansible.errors import AnsibleError
from ansible.module_utils._text import to_bytes, to_native, to_text
from ansible.module_utils.compat.importlib import import_module
from ansible.plugins.loader import ps_module_utils_loader
from ansible.utils.collection_loader import resource_from_fqcr"""
    fqn = "test fqn"
    wrapper = 'test wrapper'
    powershell = 'test powershell'

    # exercise
    p_s_module_dep_finder_2.scan_module

# Generated at 2022-06-24 19:06:26.033657
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    name = "executor_wrapper"
    print("\nUnit tests for method scan_exec_script")
    print()
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except AnsibleError:
        print("AnsibleError occurred for scan_exec_script")
    else:
        print("scan_exec_script no exception")

# Generated at 2022-06-24 19:06:33.696528
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # These tests are commented out, because they throw an error due to
    # the way the Ansible environment is constructed.
    # Note that this is not a problem for the code in production
    #p_s_module_dep_finder_0.scan_exec_script('BinaryFile.ps1')
    #p_s_module_dep_finder_0.scan_exec_script('ScriptFile.ps1')
    #p_s_module_dep_finder_0.scan_exec_script('ScriptBlock.ps1')
    #p_s_module_dep_finder_0.scan_exec_script('ScriptLocation.ps1')
    #p_s_module_dep_finder_0.scan_exec_script('ScriptFile.ps1')


# Generated at 2022-06-24 19:06:39.655093
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'module_utils.basic'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:06:45.005871
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "lib/ansible/executor/powershell"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError as err:
        assert 'Could not find executor powershell script' in str(err)


# Generated at 2022-06-24 19:06:48.312264
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common')
    assert p_s_module_dep_finder_0.exec_scripts['common']
