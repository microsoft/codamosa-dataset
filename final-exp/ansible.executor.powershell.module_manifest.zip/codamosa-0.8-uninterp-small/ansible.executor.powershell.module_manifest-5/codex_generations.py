

# Generated at 2022-06-24 18:57:20.687579
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible
    ps_module_data = b'\n'.join([b'#Requires -Module Ansible.ModuleUtils.Test', b'#Requires -Module Ansible.ModuleUtils.Another'])
    module_index = ansible.module_utils._internal_index
    if 'Test' not in module_index:
        raise RuntimeError("Expected file 'Test.psm1' in module_utils._internal_index")
    if 'Another' not in module_index:
        raise RuntimeError("Expected file 'Another.psm1' in module_utils._internal_index")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(ps_module_data)

# Generated at 2022-06-24 18:57:29.599206
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a nonexistent script name
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.exec_scripts == dict()
    script_name_0 = "nonexistent_script"

    try:
        p_s_module_dep_finder_1.scan_exec_script(script_name_0)
    except AnsibleError as err:
        assert "Could not find executor powershell script " in err.message

    # Test with a valid script name
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    assert p_s_module_dep_finder_2.exec_scripts == dict()

    script_name_2 = "powershell_compatibility"

# Generated at 2022-06-24 18:57:35.744046
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert to_text(PSModuleDepFinder().scan_module(b'using Ansible.ModuleUtils.PowerShellTools;')) == ''


# Generated at 2022-06-24 18:57:39.979444
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_f_n_0 = PSModuleDepFinder()
    # Note: add code here to set up the test environment
    h_u_t_v_0 = p_s_module_dep_f_n_0.scan_exec_script("test")
    # Note: add code here to verify the expected results
    assert h_u_t_v_0 is None


# Generated at 2022-06-24 18:57:44.286392
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    expected_result_0 = None
    result_0 = p_s_module_dep_finder_1.scan_exec_script('basic_wrapper')
    assert result_0 == expected_result_0


# Generated at 2022-06-24 18:57:55.163397
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for invalid input for parameter name (string)
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        assert p_s_module_dep_finder_0.scan_exec_script()
        assert p_s_module_dep_finder_0.scan_exec_script(name=4)
        assert p_s_module_dep_finder_0.scan_exec_script(name=3.14)
        assert p_s_module_dep_finder_0.scan_exec_script(name=[])
        assert p_s_module_dep_finder_0.scan_exec_script(name={'a': 'b'})
        assert p_s_module_dep_finder_0.scan_exec_script(name='abc')


# Generated at 2022-06-24 18:57:59.979100
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert(isinstance(p_s_module_dep_finder_1, PSModuleDepFinder))
    try:
        p_s_module_dep_finder_1.scan_exec_script("abc")
    except AnsibleError:
        pass
    # scan_exec_script takes 1 positional arguments but 2 were given, this test should fail
    try:
        p_s_module_dep_finder_1.scan_exec_script("abc", "def")
    except TypeError:
        pass


# Generated at 2022-06-24 18:58:07.288691
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_name = 'abc'
    try:
        p_s_module_dep_finder_0.scan_exec_script(test_name)
    except:
        pass
    else:
        assert False, 'AssertionError'


# Generated at 2022-06-24 18:58:13.775091
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_scan_exec_script_mock = mocker.patch('ps_module_dep_finder_scan_exec_script_mocker_ansible_powershell_executor_powershell_ps1_mocker_ansible_powershell_executor_powershell_ps1')
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('test_value_2')
    p_s_module_dep_finder_scan_exec_script_mock.assert_called_with('test_value_2')


# Generated at 2022-06-24 18:58:20.932658
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        assert 1 == 1 # executed without error
    except:
        assert 1 == 0 # executed with error


# Generated at 2022-06-24 18:58:44.285483
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    random_int = random.randint(0, 10000)
    test_PSModuleDepFinder_scan_exec_script_0(random_int)


# Generated at 2022-06-24 18:58:49.696577
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    script_name = random.randrange(1000)
    try:
        p_s_module_dep_finder_0.scan_exec_script(script_name)
    except AnsibleError as e:
        assert 'Could not find executor powershell script for \'%d\'' % script_name in to_text(e)
    else:
        assert False, 'Expected AnsibleError'


# Generated at 2022-06-24 18:58:56.364256
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ret_obj = False
    p_s_module_dep_finder = PSModuleDepFinder()
    module_data = b'#Requires -Module Ansible.ModuleUtils.NetApp.Eseries.Common'
    ret_obj = p_s_module_dep_finder.scan_module(module_data)
    if ret_obj == True:
        return
    else:
        raise AssertionError("ret_obj does not match expected value")


# Generated at 2022-06-24 18:59:00.620553
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    exec_script = p_s_module_dep_finder_0.scan_exec_script('copy')
    assert exec_script is None, "The method scan_exec_script of class PSModuleDepFinder is failed"


# Generated at 2022-06-24 18:59:06.926195
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with a fixture file, we don't need to try all the different possible scenarios
    # as the actual code has its own unit tests.
    fqn = 'ansible_collections.somecoll.somecoll2.plugins.module_utils.test'
    fh, filename = tempfile.mkstemp()

    # We need the read the file contents in a way that preserves the newlines.

# Generated at 2022-06-24 18:59:09.141840
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'ansible_collections'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:59:16.672444
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = '#TEST STRING NOT USED'
    fqn_0 = 'TEST STRING NOT USED'
    optional = 'TEST STRING NOT USED'
    powershell = 'TEST STRING NOT USED'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, optional, powershell)


# Generated at 2022-06-24 18:59:22.094852
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    with open("C:\\dev\\ansibullbot\\ansibullbot\\tests\\data\\issue_templates\\issues\\12071\\ps_module_0.psm1") as file:
        p_s_module_dep_finder.scan_module((file.read()).encode('utf-8'))


# Generated at 2022-06-24 18:59:24.886358
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder_0 = PSModuleDepFinder()
    assert len(ps_module_dep_finder_0.scan_exec_script(to_bytes("powershell"))) == 0


# Generated at 2022-06-24 18:59:30.811694
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder = PSModuleDepFinder()

    # Test cases with valid input

    try:
        p_s_module_dep_finder.scan_exec_script('Test')
    except:
        print("Unexpected exception raised")
        assert False

    # Test cases with invalid input
    try:
        p_s_module_dep_finder.scan_exec_script(None)
        print("No exception raised")
        assert False
    except AnsibleError:
        pass
    except:
        print("Unexpected exception raised")
        assert False

    try:
        p_s_module_dep_finder.scan_exec_script(0)
        print("No exception raised")
        assert False
    except AnsibleError:
        pass
    except:
        print("Unexpected exception raised")

# Generated at 2022-06-24 18:59:46.935743
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "..", "..", "..", "lib", "ansible", "executor", "powershell", "ansible_powershell_script.ps1"), "r") as f:
        script = f.read()
    p_s_module_dep_finder_0.scan_exec_script(base64.b64encode(script.encode()).decode())


# Generated at 2022-06-24 18:59:52.511951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Case 0
    # Create an instance of class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Execute scan_exec_script with an argument of name = 'ansible_module_minecraft'
    p_s_module_dep_finder_0.scan_exec_script('ansible_module_minecraft')



# Generated at 2022-06-24 18:59:57.396663
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_0.scan_exec_script("ansible")
    assert "Could not find executor powershell script for 'ansible'" in str(excinfo)


# Generated at 2022-06-24 19:00:07.350312
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    script_name = 'ansible_module_0'
    script_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_script', script_name + '.ps1')
    if not os.path.exists(os.path.dirname(script_path)):
        os.makedirs(os.path.dirname(script_path))

    # write out a test script containing a random amount of script_data_0
    # lines
    with open(script_path, 'w') as f:
        script_data_0 = '# requires -module @{ModuleName=\'Ansible.ModuleUtils.Legacy'

# Generated at 2022-06-24 19:00:13.126089
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = None
    fqn = None
    wrapper = False
    powershell = True
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-24 19:00:19.587690
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('main')
    assert p_s_module_dep_finder_0.exec_scripts.keys()[0] == 'main'


# Generated at 2022-06-24 19:00:24.753715
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('main')


# Generated at 2022-06-24 19:00:29.291411
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script('csharp_runner') == None


# Generated at 2022-06-24 19:00:38.916221
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test 1: Parameter name has a valid value
    p_s_module_dep_finder_0.scan_exec_script('Basic')
    # Test 2: Parameter name has a valid value
    try:
        p_s_module_dep_finder_0.scan_exec_script('Basic')
    except Exception:
        AssertionError('Test2: Unexpected Exception')
    # Test 3: Parameter name has an invalid value
    try:
        p_s_module_dep_finder_0.scan_exec_script('InvalidValue')
        AssertionError('Test3: Expected Exception')
    except Exception:
        pass


# Generated at 2022-06-24 19:00:42.172907
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Prepare test data
    ps_module_dep_finder0 = PSModuleDepFinder()
    name = "name"

    # Perform the test
    ps_module_dep_finder0.scan_exec_script(name)


# Generated at 2022-06-24 19:01:03.736687
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_module is not None


# Generated at 2022-06-24 19:01:07.678426
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("./lib/ansible/executor/powershell/module_utils/{}")


# Generated at 2022-06-24 19:01:10.524478
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = 'powershell_script.ps1'
    # Call method scan_exec_script of class PSModuleDepFinder
    result = p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 19:01:18.580848
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test 1
    try:
        p_s_module_dep_finder_0.scan_exec_script("powershell_gateway_run")
    except Exception as e:
        raise AssertionError("Test 1: Failed to scan executor powershell script: " + str(e))

    # Test 2
    try:
        p_s_module_dep_finder_0.scan_exec_script("powershell_gateway_run")
    except Exception as e:
        raise AssertionError("Test 2: Failed to scan executor powershell script: " + str(e))

    # Test 3

# Generated at 2022-06-24 19:01:27.500694
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    file_name_0 = b'ansible_module_args.ps1'

    p_s_module_dep_finder_0.scan_exec_script(file_name_0)

    pkg_data_0 = pkgutil.get_data(b'ansible.executor.powershell', b'ansible_module_args.ps1')
    assert pkg_data_0 != None, \
        "Failed to get the package data from ansible executor powershell ansible_module_args.ps1"
    exec_script_0 = None
    if C.DEFAULT_DEBUG:
        exec_script_0 = pkg_data_0

# Generated at 2022-06-24 19:01:30.065025
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_file_0")


# Generated at 2022-06-24 19:01:34.433396
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create a new PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call the method scan_exec_script with a random value for argument name
    #
    # If it returns successfully, then the test succeeded
    p_s_module_dep_finder_0.scan_exec_script(random.choice(list(p_s_module_dep_finder_0.exec_scripts.keys())))


# Generated at 2022-06-24 19:01:45.817264
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for function scan_exec_script

    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:01:50.684634
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class MyTestCase:
        def __init__(self):
            pass
        def __eq__(self, other):
            return True

    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.exec_scripts = {'data': MyTestCase(), 'path': 'path'}
    my_test_case = MyTestCase()
    name = 'name'
    p_s_module_dep_finder._add_module = lambda x, y, z, o, w: True
    p_s_module_dep_finder.scan_exec_script(name)


# Generated at 2022-06-24 19:01:53.967374
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('foo.ps1')



# Generated at 2022-06-24 19:02:37.550383
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "TestName"
    # Test exception raised
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except Exception as err:
        assert issubclass(err.__class__, AnsibleError)


# Generated at 2022-06-24 19:02:47.271409
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    name = 'PowerShellExecutor'

    # Invoke method
    p_s_module_dep_finder_0.scan_exec_script(name)

    if C.DEFAULT_DEBUG:
        assert not p_s_module_dep_finder_0.exec_scripts[name].strip()
    else:
        assert not p_s_module_dep_finder_0.exec_scripts[name].strip().startswith(b'#') and \
               not p_s_module_dep_finder_0.exec_scripts[name].strip().endswith(b'#')


# Generated at 2022-06-24 19:02:57.726140
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ping')
    assert p_s_module_dep_finder_0.exec_scripts['ping']
    assert p_s_module_dep_finder_0.ps_modules['Ansible.ModuleUtils.Powershell.ScheduledTask']
    # Test with an invalid script name
    try:
        p_s_module_dep_finder_0.scan_exec_script('invalid_script_name')
    except AnsibleError as e:
        assert "Could not find executor powershell script" in to_native(e)


# Generated at 2022-06-24 19:03:00.523620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # input arguments for the  method scan_exec_script
    name = "placeholder"

    # instance to make the API call
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # make the API call through the instance
    p_s_module_dep_finder_0.scan_exec_script(name=name, )


# Generated at 2022-06-24 19:03:05.161721
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("script_1")
    # Test case 1
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("script_2")


# Generated at 2022-06-24 19:03:10.680353
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1._add_module = p_s_module_dep_finder_0._add_module
    p_s_module_dep_finder_1.ps_modules = p_s_module_dep_finder_0.ps_modules
    p_s_module_dep_finder_1.cs_utils_module = p_s_module_dep_finder_0.cs_utils_module
    p_s_module_dep_finder_1.cs_utils_wrapper = p_s_module_dep_finder_0.cs_utils_wrapper

# Generated at 2022-06-24 19:03:18.790682
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_sctipt = """#!/usr/bin/python
import json
import sys
import os
import base64
import random
import struct
import traceback
import errno
"""
    md = PSModuleDepFinder()
    md.scan_exec_script("testscript")
    for module in md.exec_scripts:
        if module == "testscript":
            assert md.exec_scripts[module] == test_sctipt


# Generated at 2022-06-24 19:03:23.090719
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('test_PSModuleDepFinder_scan_exec_script')


# Generated at 2022-06-24 19:03:31.768641
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Given
    expected_value = b'New-Item $scriptDir -ItemType Directory -Force;$commands = @();\n'
    actual_value = b''
    p_s_module_dep_finder = PSModuleDepFinder()
    name = 'Add-ToPathEnv'

    # When
    p_s_module_dep_finder.scan_exec_script(name)

    # Then
    for exec_script in p_s_module_dep_finder.exec_scripts.values():
        actual_value += exec_script
    assert expected_value == actual_value


# Generated at 2022-06-24 19:03:38.540270
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    base64_0 = base64.b64encode(to_bytes('test_name')).decode('ascii')
    p_s_module_dep_finder_0.exec_scripts = {base64_0: to_bytes('test_value')}
    p_s_module_dep_finder_0.scan_exec_script(base64_0)


# Generated at 2022-06-24 19:05:09.136881
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    test_case_number = 0
    test_case_0()

    # For test case 1, ensure that the scan_exec_script method is able to scan a powershell script in the Ansible
    # repository.
    # Expected:
    # The method should return None and print "Script successfully scanned".
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    executor_script_name = "pwsh_wrap"
    try:
        p_s_module_dep_finder_1.scan_exec_script(executor_script_name)
        print("Script successfully scanned")
    except:
        test_case_number = 1
        print("Test case " + str(test_case_number) + " failed.")

    # For test case 2, ensure that the scan_exec_script method is only able

# Generated at 2022-06-24 19:05:13.358811
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_0.scan_exec_script('name_uuuuuu')
    assert 'Could not find executor powershell script for \'name_uuuuuu\'' in str(excinfo.value)
    

# Generated at 2022-06-24 19:05:15.943998
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'test_name'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:05:26.242378
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test for '#Requires -Module Ansible.ModuleUtils.{name}\n'
    # Test for '#AnsibleRequires -Powershell Ansible.*' (or collections module_utils ref)
    p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.CommonUtils\n', wrapper=True, powershell=True)
    if p_s_module_dep_finder_0.ps_modules:
        print('ps_modules: %s' % p_s_module_dep_finder_0.ps_modules)

    # Test for '#AnsibleRequires -CSharpUtil Ansible.*' (or collections module_utils ref)
    # Test for 'using Ansible.*

# Generated at 2022-06-24 19:05:35.452961
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # We are testing the presence of the following two lines in a script
    #   #Requires -Module Ansible.ModuleUtils.AnsibleModule
    #   #requires -version 7.0
    #
    # The test framework will check the following attributes to ensure the
    # script has been scanned correctly:
    #   ps_version - this is required to be set to 7.0 or greater
    #   ps_modules - this is required to contain a reference to
    #                Ansible.ModuleUtils.AnsibleModule with correct data
    #                and path


    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_text('Invoke-Async'))
    assert p_s_module_dep_finder_0.ps_

# Generated at 2022-06-24 19:05:43.385626
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fqn = 'ansible_collections.test_collection.test_plugins.modules.test_module'
    module_data = '#Requires -Module Ansible.ModuleUtils.TestUtil1\n#Requires -Module Ansible.ModuleUtils.TestUtil2\n' \
                  '#AnsibleRequires -CSharpUtil ansible_collections.test_collection.test_plugins.module_utils.test_util'
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(module_data, fqn)


# Generated at 2022-06-24 19:05:51.952550
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:06:01.342718
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # AssertionError: AssertionError: Could not find executor powershell script for '__main__'
    try:
        p_s_module_dep_finder_0.scan_exec_script("__main__")
    except Exception as e:
        print("An exception of type %s occurred. Arguments:\n%s" % (type(e).__name__, e.args))
        try:
            if e.args[0] == "Could not find executor powershell script for '__main__'":
                raise AssertionError("AssertionError: Could not find executor powershell script for '__main__'") from e
        except IndexError:
            pass


# Generated at 2022-06-24 19:06:09.560769
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    return_val_1 = p_s_module_dep_finder_1.scan_module("#Requires -Module Ansible.ModuleUtils.ArgumentSpec.psm1")

# Generated at 2022-06-24 19:06:16.649402
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn_0 = 'test_fqn_0'
    name_0 = 'test_name_0'
    ext_0 = '.test_ext_0'
    module_util_data_0 = {}
    module_util_data_0['data'] = 'test_data_0'
    module_util_data_0['path'] = fqn_0
    p_s_module_dep_finder_0.cs_utils_wrapper[ext_0] = module_util_data_0
    name_1 = 'test_name_1'
    ext_1 = '.test_ext_1'
    module_util_data_1 = {}