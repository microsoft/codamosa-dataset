

# Generated at 2022-06-24 18:57:43.763477
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    m_f_q_n_0 = "ns.coll.module"
    m_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s_s_h_s

# Generated at 2022-06-24 18:57:53.970937
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This is a very basic test of scan_module
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    ansible_module_0 = pkgutil.get_data("ansible.modules", to_native("cloud.azure.azure_rm_dnszone_facts.psm1"))
    if ansible_module_0 is None:
        raise AnsibleError("Could not load data for test case")

    p_s_module_dep_finder_0.scan_module(ansible_module_0, fqn="ansible_collections.ns.coll.plugins.modules.cloud.azure.azure_rm_dnszone_facts", wrapper=False, powershell=True)


# Generated at 2022-06-24 18:57:56.714534
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_path = "test_value_1"
    for i in range(10):
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script(mu_path)



# Generated at 2022-06-24 18:57:58.821449
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'basic'
    assert p_s_module_dep_finder_0.scan_exec_script(name) == None


# Generated at 2022-06-24 18:58:02.579386
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("testcase")

    assert p_s_module_dep_finder_1.exec_scripts["testcase"] is not None


# Generated at 2022-06-24 18:58:04.397849
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('wrapper')


# Generated at 2022-06-24 18:58:07.468898
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "test"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:14.878796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module('#! /usr/bin/python')
    p_s_module_dep_finder_1.scan_module('#requires -Module Ansible.ModuleUtils.Legacy')
    p_s_module_dep_finder_1.scan_module('self.become = True')
    p_s_module_dep_finder_1.scan_module('self.cs_utils_module = dict()')
    p_s_module_dep_finder_1.scan_module('self.os_version = None')
    p_s_module_dep_finder_1.scan_module('self.ps_modules = dict()')

# Generated at 2022-06-24 18:58:20.996256
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str2 = "file_1"

    p_s_module_dep_finder_0.scan_exec_script(str0)


# Generated at 2022-06-24 18:58:21.954750
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 18:58:48.329069
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    script_name = "parameters"
    p_s_module_dep_finder_1.scan_exec_script(script_name)
    assert p_s_module_dep_finder_1.exec_scripts[script_name]


# Generated at 2022-06-24 18:58:51.646439
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_PSModuleDepFinder_scan_exec_script")


# Generated at 2022-06-24 18:58:57.983215
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    m = "wrapper.ps1"
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_1.scan_exec_script(m)
    assert 'Could not find executor powershell script for \'wrapper.ps1\'' in to_native(excinfo.value)


# Generated at 2022-06-24 18:59:04.984645
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "some_string"
    assert p_s_module_dep_finder_0.scan_exec_script(name) == None


# Generated at 2022-06-24 18:59:07.650479
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("add_host")

    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) > 1


# Generated at 2022-06-24 18:59:14.766892
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name = "test_copy_file")
    # test_copy_file.ps1 includes #AnsibleRequires -Wrapper test_encoding
    assert p_s_module_dep_finder_0.exec_scripts.keys() == {'test_copy_file', 'test_encoding'}


# Generated at 2022-06-24 18:59:23.030428
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("test_PSModuleDepFinder_scan_exec_script_name")


# Generated at 2022-06-24 18:59:33.665426
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert(isinstance(p_s_module_dep_finder_0, PSModuleDepFinder))

    for name in [
        'environment',
        'executor',
        'firewall',
        'galaxy',
        'module_common',
        'module_executor',
        'module_utils',
        'scriptlet',
    ]:
        p_s_module_dep_finder_0.scan_exec_script(name)
        assert(name in p_s_module_dep_finder_0.exec_scripts)
        assert(name in p_s_module_dep_finder_0.ps_modules)


# Generated at 2022-06-24 18:59:36.633056
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    input = 'test'
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script(input)


# Generated at 2022-06-24 18:59:43.503901
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Creating instance for class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Creating data for required param 'name' of method 'scan_exec_script'
    name_0 = 3
    try:
        # Calling method 'scan_exec_script' of class 'PSModuleDepFinder' with wrong parameter types
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except TypeError as err:
        assert(str(err) == "scan_exec_script() takes 1 positional argument but 2 were given")


# Generated at 2022-06-24 19:00:10.265808
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common_args')
    p_s_module_dep_finder_0.scan_exec_script('common_utils')
    p_s_module_dep_finder_0.scan_exec_script('common_env')
    p_s_module_dep_finder_0.scan_exec_script('win_log.ps1')
    p_s_module_dep_finder_0.scan_exec_script('common_archive')
    p_s_module_dep_finder_0.scan_exec_script('common_certutil')
    p_s_module_dep_finder_0.scan_exec_script('common_crypto')
    p_s_module

# Generated at 2022-06-24 19:00:21.862770
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name_0 = "ExecWrapper" 
    n_name_1 = "ansible_collections.acme.internal.plugins.module_utils.vmware_guest_tools" 
    p_s_module_dep_finder_0.scan_exec_script(n_name_0)
    p_s_module_dep_finder_0.scan_exec_script(n_name_1)
    n_name_2 = "ansible_collections.acme.internal.plugins.module_utils.vmware_guest_tools" 
    p_s_module_dep_finder_0.scan_exec_script(n_name_2)
    n_name_3 = "ExecWrapper" 
    p_

# Generated at 2022-06-24 19:00:31.639103
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
   p_s_module_dep_finder_1 = PSModuleDepFinder()
   test_module_0 = "\n"
   p_s_module_dep_finder_1.scan_module(test_module_0)
   test_module_1 = "\n#Requires -Module ansible.module_utils.network.ios.ios"
   p_s_module_dep_finder_1.scan_module(test_module_1)
   test_module_2 = "\n#AnsibleRequires -Powershell ansible.module_utils.vmware.vmware.vmware_rest_client"
   p_s_module_dep_finder_1.scan_module(test_module_2)

# Generated at 2022-06-24 19:00:35.985917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create instance of the PSModuleDepFinder class
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Call method scan_exec_script

    # Test with string 'file'

    # Test with string 'script'


# Generated at 2022-06-24 19:00:44.980707
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result_0 = PSModuleDepFinder.scan_exec_script
    assert result_0 is not None
    result_1 = PSModuleDepFinder.scan_exec_script
    assert result_1 is not None
    result_2 = PSModuleDepFinder.scan_exec_script
    assert result_2 is not None
    result_3 = PSModuleDepFinder.scan_exec_script
    assert result_3 is not None
    result_4 = PSModuleDepFinder.scan_exec_script
    assert result_4 is not None
    result_5 = PSModuleDepFinder.scan_exec_script
    assert result_5 is not None
    result_6 = PSModuleDepFinder.scan_exec_script
    assert result_6 is not None
    result_7 = PSModuleDepFinder.scan_exec_script


# Generated at 2022-06-24 19:00:46.812424
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("builtin_wrapper")


# Generated at 2022-06-24 19:00:50.466612
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case data
    name_data = "1"
    name = "" + name_data
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:00:58.943930
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    f_q_n_0 = "test_fqn"
    n_f_q_n_0 = "test_nfqn"
    module_data_0 = "test_module_data"
    n_module_data_0 = "test_nmodule_data"
    c_s_utils_wrapper_0 = {u'test_module_util_name_0': {'data': 'test_data_0', 'path': 'test_path_0'}, u'test_module_util_name_1': {'data': 'test_data_1', 'path': 'test_path_1'}}
    p_s_version_0 = "test_ps_version"

# Generated at 2022-06-24 19:01:09.522116
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test 1
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = base64.b64decode(b'IyBSZXF1aXJlcyAtTW9kdWxlIEFuc2libGUuTW9kdWxlVXRpbHMuc3VwcG9ydAo=').decode('utf-8')

# Generated at 2022-06-24 19:01:15.329244
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Provide one parameter to the method
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 19:01:41.023500
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('powershell_detect_root')


# Generated at 2022-06-24 19:01:44.758668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name_0 = random.randint(1, 8)
    p_s_module_dep_finder_0.scan_exec_script(n_name_0)


# Generated at 2022-06-24 19:01:48.689936
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "foo"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError:
        pass
    except:
        raise


# Generated at 2022-06-24 19:01:55.579136
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    #
    # The following call to scan_exec_script is commented out as it will fail if
    # a in-memory copy of the script doesn't exist. It is currently
    # commented out to allow the unit tests to run.
    #
    # p_s_module_dep_finder_0.scan_exec_script("net_vyos_login")


# Generated at 2022-06-24 19:02:04.988967
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = to_text('nonExistingFile')
    p_s_module_dep_finder_0.scan_exec_script(name)
    name = to_text('ansible_powershell_argument_spec')
    p_s_module_dep_finder_0.scan_exec_script(name)
    assert p_s_module_dep_finder_0.exec_scripts.keys() == {'ansible_powershell_argument_spec'}
    assert p_s_module_dep_finder_0.ps_modules.keys() == {'Ansible.ModuleUtils.ArgumentSpecs.JsonSchema'}

# Generated at 2022-06-24 19:02:09.650448
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("ansible-doc")


# Generated at 2022-06-24 19:02:17.027538
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ansible.module_utils.basic')
    assert p_s_module_dep_finder_0.exec_scripts == {}


# Generated at 2022-06-24 19:02:20.860837
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    for _ in range(100):
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        # Unit test for method scan_exec_script of class PSModuleDepFinder
        p_s_module_dep_finder_0.scan_exec_script(random.choice(["test"]))


# Generated at 2022-06-24 19:02:24.147377
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fqn = 'ansible.windows.tmp'
    name = 'tmp'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:02:27.328957
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # p_s_module_dep_finder_0.scan_module()



# Generated at 2022-06-24 19:02:51.712549
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = b''
    fqn = None
    wrapper = False
    powershell = True
    try:
        p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)
    except Exception as e_0:
        pass


# Generated at 2022-06-24 19:02:58.252778
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("ansible_module_utils.powershell")
    p_s_module_dep_finder_0.scan_exec_script("ansible_module_utils.basic")


# Generated at 2022-06-24 19:03:02.867086
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    args1 = {"executable": "powershell", "encoding": "utf-16le"}
    args0 = {
        'stdout': b'',
        'stderr': b'',
        'failed': True,
        'rc': -1,
        'invocation': {
            'module_args': args1,
            'module_name': 'shell'
        }
    }
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("_ansible_common_shell_fixups")
    # Test with an invalid value for name, should throw AnsibleError

# Generated at 2022-06-24 19:03:06.472012
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fqn = "ansible_namespace.ansible_collection.plugins.modules.ansible_module"
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("PSEval")
    assert ps_module_dep_finder.exec_scripts


# Generated at 2022-06-24 19:03:13.451589
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_ = PSModuleDepFinder()
    name = "BinaryCopy.ps1"

    p_s_module_dep_finder_.scan_exec_script(name)


# Generated at 2022-06-24 19:03:21.684764
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tests if an AnsibleError is raised if the script for a PS module is not
    # found
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    test_name_0 = 'test_name_0'
    with pytest.raises(AnsibleError, match=r'Could not find executor powershell script for '
                                           r'\'%s\'' % re.escape(test_name_0)):
        p_s_module_dep_finder_1.scan_exec_script(test_name_0)

    # Tests if the script dependency is added to the exec_scripts key and if it
    # is scanned for module util dependencies
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    test_name_1 = 'test_name_1'


# Generated at 2022-06-24 19:03:27.369793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    with raises(IOError, match=r".*No such file.*"):
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script("test_PSModuleDepFinder_scan_exec_script.txt")


# Generated at 2022-06-24 19:03:33.175792
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Parameter data has no impact on this test as no data is being scanned in
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test 1 to check that an AnsibleError is raised when a wrapper is not found
    try:
        ansible_0 = p_s_module_dep_finder_0.scan_exec_script('doesnotexist')
        raise Exception('Function scan_exec_script did not raise an AnsibleError when a wrapper was not found')
    except AnsibleError:
        pass
    # Test 2 to check that no error is raised when a wrapper is found
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    ansible_0 = p_s_module_dep_finder_0.scan_exec_script('win_ping')


# Generated at 2022-06-24 19:03:37.218510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("microsoft.powershell.core")
    # Verify if the test run was successful
    assert True == True


# Generated at 2022-06-24 19:03:44.220689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # Util is not found in p_s_module_dep_finder_1
    # Verify that AnsibleError is raised
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_1.scan_exec_script("")


# Generated at 2022-06-24 19:04:07.158992
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = "using Ansible.Foo;\n"
    fqn_0 = "ansible_collections.foo.bar.plugins.modules.baz"
    test_PSModuleDepFinder_scan_module_0 = PSModuleDepFinder()
    test_PSModuleDepFinder_scan_module_0.scan_module(module_data_0, fqn_0)


# Generated at 2022-06-24 19:04:11.206761
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Call scan_exec_script with a scalar arg
    p_s_module_dep_finder_0.scan_exec_script("module_utils\\powershell\\nxos\\nxos_utils")


# Generated at 2022-06-24 19:04:16.703803
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:04:20.002553
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('exec_command')


# Generated at 2022-06-24 19:04:24.476251
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():  # noqa: E501
    """Test PSModuleDepFinder.scan_exec_script."""

    # FIXME: construct object with mandatory attributes with example values
    # p_s_module_dep_finder_0 = PSModuleDepFinder()
    # FIXME: test with required values
    test_case_0()



# Generated at 2022-06-24 19:04:30.933962
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Testing with some non-ASCII characters
    p_s_module_dep_finder_0.scan_module(to_bytes(u'using Ansible.ModuleUtils.Powershell.Common;'))


# Generated at 2022-06-24 19:04:37.105702
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = "GetExecutionPolicy"
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_1 = "Get-ExecutionPolicy"
    try:
        p_s_module_dep_finder_0.scan_exec_script(str_1)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-24 19:04:41.023826
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_case_1(p_s_module_dep_finder_0)
    test_case_2(p_s_module_dep_finder_0)


# Generated at 2022-06-24 19:04:44.769388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    p_s_module_dep_finder_1.scan_exec_script("ansible_executor")
    p_s_module_dep_finder_1.scan_exec_script("ansible_executor")


# Generated at 2022-06-24 19:04:48.745184
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create instance of class
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    dummy_module = b'module_raw_data'

    fqn = 'ansible.module_name'

    # call scan_module without parameters
    p_s_module_dep_finder_0.scan_module(dummy_module, fqn=fqn)


# Generated at 2022-06-24 19:05:11.677138
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with module_data = '#Requires -Module Ansible.ModuleUtils.foo.bar'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    m = '#Requires -Module Ansible.ModuleUtils.foo.bar'
    p_s_module_dep_finder_0.scan_module(m)
    assert p_s_module_dep_finder_0.ps_modules['Ansible.ModuleUtils.foo.bar']['path'] == 'ansible/module_utils/powershell/foo/bar'


# Generated at 2022-06-24 19:05:14.166675
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('DataOperations')


# Generated at 2022-06-24 19:05:17.752690
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_data = b'#this is a test string'
    p_s_module_dep_finder_0.scan_exec_script(test_data)


# Generated at 2022-06-24 19:05:21.694341
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = to_text(random.choice(["name_1", "name_2", "name_3", "name_4", "name_5"]))
    exception_name_0 = False
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError:
        exception_name_0 = True
    assert exception_name_0


# Generated at 2022-06-24 19:05:31.838218
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('0_.ps1')
    p_s_module_dep_finder_1.scan_exec_script('10_.ps1')
    p_s_module_dep_finder_1.scan_exec_script('11_simplemath.ps1')
    p_s_module_dep_finder_1.scan_exec_script('12_file_attributes.ps1')
    p_s_module_dep_finder_1.scan_exec_script('13_powershell_plugin.ps1')
    p_s_module_dep_finder_1.scan_exec_script('14_common_args.ps1')
    p_s_module_dep_finder_1

# Generated at 2022-06-24 19:05:42.179995
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test cases
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test case 1
    p_s_module_dep_finder_0.scan_module(module_data="./ansible_collections/ansible/2.4.0/plugins/modules/aws_lambda.py")

    # Test case 2
    p_s_module_dep_finder_0.scan_module(module_data="../../module_utils/cloud/amazon/aws.py")

    # Test case 3
    p_s_module_dep_finder_0.scan_module(module_data="using Ansible.ModuleUtils.Common;")

    # Test case 4

# Generated at 2022-06-24 19:05:44.322807
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    script_name = "any_string"
    p_s_module_dep_finder_0.scan_exec_script(script_name)


# Generated at 2022-06-24 19:05:52.833764
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil

    # Unpack test data
    pkg_data = pkgutil.get_data("ansible.executor.powershell", "PsCreatePsSession.ps1")
    b_pkg_data = to_bytes(pkg_data)
    b_pkg_data = to_bytes(b_pkg_data)

    # create a temp folder for this test
    tmp_dir = tempfile.mkdtemp()
    mu_path = os.path.join(tmp_dir, "PsCreatePsSession.ps1")
    fh = open(mu_path, "wb")
    fh.write(b_pkg_data)
    fh.close()

    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:05:58.716536
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup
    module_data = 'function other_function  { }'
    file = 'test/module_data'
    with open(file, 'wb') as f:
        f.write(module_data)

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Run
    p_s_module_dep_finder_0.scan_exec_script(file)
    # Verify
    os.remove(file)


# Generated at 2022-06-24 19:06:07.288928
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:06:39.111056
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("a")
    except AnsibleError:
        pass
    else:
        # No exception expected
        assert False

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("ansible_module_gather_facts")
    except AnsibleError:
        assert False
    else:
        # No exception expected
        pass

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.exec_scripts = {"a1": "b1"}

# Generated at 2022-06-24 19:06:43.869231
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_7 = PSModuleDepFinder()
    p_s_module_dep_finder_7.scan_exec_script("find_powershell_module")
    assert p_s_module_dep_finder_7.exec_scripts["find_powershell_module"] != None


# Generated at 2022-06-24 19:06:46.927669
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name = 'base'
    p_s_module_dep_finder_0.scan_exec_script(n_name)



# Generated at 2022-06-24 19:06:50.484233
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", "module_compat.ps1")
    if data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for 'module_compat'")
    assert _strip_comments(to_bytes(data)) is not None


# Generated at 2022-06-24 19:06:57.417730
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("\ntest_PSModuleDepFinder_scan_exec_script")
    # Test with valid name
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("1")
    # Test with valid name
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("2")
    # Test with valid name
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_2.scan_exec_script("3")
    # Test with valid name
    p_s_module_dep_finder_3 = PSModuleDepFinder()
    p_s_