

# Generated at 2022-06-24 18:57:30.103075
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Returns a dict of name to executor script data.
    # Each script is stripped of comments.
    data = pkgutil.get_data("ansible.executor.powershell", "common.ps1")
    b_data = to_bytes(data)
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("common")
    name = to_text("common")
    p_s_module_dep_finder_1.exec_scripts[name]
    if C.DEFAULT_DEBUG:
        assert to_bytes(data) == p_s_module_dep_finder_1.exec_scripts[name]
    else:
        assert _strip_comments(b_data) == p_s_module_dep_finder_

# Generated at 2022-06-24 18:57:38.090330
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """See if scanning exec scripts find the required requires."""

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('endpoint')
    assert 'Ansible.ModuleUtils.PSRemoting' in p_s_module_dep_finder_1.ps_modules.keys()


# Generated at 2022-06-24 18:57:43.110352
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module("")


# Generated at 2022-06-24 18:57:53.802450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()

    # Test case 1:
    # Test where the name exists in the ansible.executor.powershell package
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("common_args")

# Generated at 2022-06-24 18:57:58.744749
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with a string representing the name of the module
    p_s_module_dep_finder_0.scan_exec_script("win_package")

    # No assertion in the function, just testing an exception
    with pytest.raises(AnsibleError) as e:
        p_s_module_dep_finder_0.scan_exec_script("non_existent")
    assert e.type == AnsibleError


# Generated at 2022-06-24 18:58:02.181591
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test case 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # p_s_module_dep_finder_0.scan_module(module_data, fqn = None, wrapper = False, powershell = True)


# Generated at 2022-06-24 18:58:04.535405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "win_command"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:12.538924
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # No data files needed for this test

    # test the case where the module is an empty file and the fqn is None.
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b"", fqn=None, wrapper=False, powershell=True)
    # test the case where the module is an empty file, the fqn is 'test_case_0'
    # and the extension is '.psm1'.
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_2.scan_module(b"", fqn='test_case_0', wrapper=False, powershell=True)
    # test the case where the module is a PowerShell module and the

# Generated at 2022-06-24 18:58:20.934723
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name = "name2"
    p_s_module_dep_finder_0.scan_exec_script(n_name)


# Generated at 2022-06-24 18:58:22.584835
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'net_ping'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:58:43.102877
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = random.choice(["2yc7", "R", "", "6U9", "3q"])
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:53.172841
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("        #Requires -Module Ansible.ModuleUtils.Log")
    assert 'Ansible.ModuleUtils.Log' in p_s_module_dep_finder_0.ps_modules.keys(), \
        "Incorrect keys in ps_modules"
    p_s_module_dep_finder_0.scan_module("        #AnsibleRequires -PowerShell ..module_utils.Example")
    assert '..module_utils.Example' in p_s_module_dep_finder_0.ps_modules.keys(), \
        "Incorrect keys in ps_modules"


# Generated at 2022-06-24 18:58:56.272711
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(to_bytes(''))


# Generated at 2022-06-24 18:59:04.336292
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    pwd_1 = os.getcwd()
    os.chdir("/home/parallels/ansible/test/units/module_utils/test_powershell")
    try:
        p_s_module_dep_finder_0.scan_module("#Requires -Module Ansible.ModuleUtils.MyUtil\n#AnsibleRequires -CSharpUtil ansible_collections.ns1.coll1.plugins.module_utils.MyUtil2", "TestModule")
        p_s_module_dep_finder_0.scan_exec_script("MyWrapper")
        assert True
    except AnsibleError:
        assert False
    os.chdir(pwd_1)


# Generated at 2022-06-24 18:59:06.379694
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    file_name = ''
    p_s_module_dep_finder_0.scan_exec_script(file_name)



# Generated at 2022-06-24 18:59:09.142700
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script("0", "1")
    except Exception as e:
        assert False, type(e).__name__


# Generated at 2022-06-24 18:59:11.628959
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("core")
    p_s_module_dep_finder_1.scan_exec_script("netcore")


# Generated at 2022-06-24 18:59:18.011318
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "InventoryPsWrapper"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:59:26.548887
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = random.random()
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError as e_0:
        print("Caught Exception: %s" % str(e_0))


# Generated at 2022-06-24 18:59:32.239546
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    result = p_s_module_dep_finder_0.scan_exec_script("ansible_module_exec")
    assert result == None


# Generated at 2022-06-24 18:59:48.334037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('example_exec_script')


# Generated at 2022-06-24 18:59:59.886500
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Read a PowerShell module file into memory
    module_path = os.path.join(
        C.DEFAULT_MODULE_PATH[0],
        'network',
        'win',
        'net_virtual_interface.psm1'
    )
    with open(module_path, 'rb') as f:
        module_data = f.read()

    # Find the module dependencies
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data)

    # Assert that we found the dependencies
    assert 'Ansible.ModuleUtils.ArgumentCompleter' in p_s_module_dep_finder_0.ps_modules
    assert 'Ansible.ModuleUtils.Common' in p_s_module

# Generated at 2022-06-24 19:00:03.865089
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "name"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:00:07.639186
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Testcase 1
    # Constructing a PSModuleDepFinder object
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Calling method scan_module of class PSModuleDepFinder
    p_s_module_dep_finder_0.scan_module(module_data)


# Generated at 2022-06-24 19:00:16.434919
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Secret input
    secret_with_no_default = "Hello World!"
    # Example output
    expected_0 = set()
    p_s_module_dep_finder_0.scan_exec_script(secret_with_no_default)
    assert p_s_module_dep_finder_0.exec_scripts == expected_0



# Generated at 2022-06-24 19:00:21.916922
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = p_s_module_dep_finder_0.exec_scripts.keys()[0]
    # The method does not change the data in the dict, so return the same value
    p_s_module_dep_finder_0.scan_exec_script(name)
    assert p_s_module_dep_finder_0.exec_scripts.keys()[0] == name


# Generated at 2022-06-24 19:00:25.392777
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("exec_wrapper")


# Generated at 2022-06-24 19:00:30.205048
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    with pytest.raises(AnsibleError) as error_info:
        test_obj = PSModuleDepFinder()
        test_name = "test"
        test_obj.scan_exec_script(test_name)


# Generated at 2022-06-24 19:00:40.268377
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Tests the scan_module method when calling it with a 'module_data' variable that is a type of string.

    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Test 1: Calling the scan_module method when passing a string argument with no matching requires
    module_data = "{some_string}"
    p_s_module_dep_finder_1.scan_module(module_data, fqn=None, wrapper=False, powershell=True)

    # Test 2: Calling the scan_module method when passing a string argument with matching Requires
    module_data = "{some_string}\n#Requires -Module Ansible.ModuleUtils.Some_Module"

# Generated at 2022-06-24 19:00:45.328956
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'test'
    exception = None
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except Exception as e:
        exception = e
    assert exception is not None
    assert exception.args[0] == 'Could not find executor powershell script for \'test\''


# Generated at 2022-06-24 19:01:27.586005
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # In this test we assume that the collection ps_modules is
    # located in /src/collections/ansible_collections/test_collection/test_ns/test_coll/plugins/modules/test_module.psm1
    # and the module in:
    # /src/lib/ansible/modules/test_module.py
    cur_path = os.path.dirname(os.path.realpath(__file__))
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # PS module contains '#Requires -Module Ansible.ModuleUtils.{name}
    # PS module contains '#AnsibleRequires -Powershell Ansible.*' (or collections module_utils ref)
    # PS module contains '#AnsibleRequires -CSharpUtil Ansible.*' (or collections module_

# Generated at 2022-06-24 19:01:32.154081
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case = 0 # for traceback
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = ""
    fqn_0 = None
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 19:01:35.896989
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('ansible_script_wrapper')


# Generated at 2022-06-24 19:01:46.218583
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test general functionality.
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:01:49.160528
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = '''
        '''
    p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 19:01:54.491712
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Verify error raised when module_data is not a string
    with pytest.raises(AnsibleError) as e_info:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_module(b'\n', fqn=None, wrapper=False, powershell=True)
    assert "Could not find imported module support code for 'Ansible.ModuleUtils.Networking.Legacy.Params'" in e_info.value.message


# Generated at 2022-06-24 19:01:59.316981
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "python3"
    result_val = p_s_module_dep_finder_0.scan_exec_script(name)
    assert True


# Generated at 2022-06-24 19:02:10.100604
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Initializing a PSModuleDepFinder
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # Validating the type of p_s_module_dep_finder_1 (PSModuleDepFinder)
    assert isinstance(p_s_module_dep_finder_1, PSModuleDepFinder), \
        "The value of p_s_module_dep_finder_1 should be a PSModuleDepFinder"
    # Validating the type of module_data (bytes)
    assert isinstance(module_data, bytes), "The value of module_data should be a bytes"
    # Reading contents of the file klab_resources/module_data_scan_module.psm1

# Generated at 2022-06-24 19:02:16.095196
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("")
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module("", "", False, True)


# Generated at 2022-06-24 19:02:23.599258
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_data = dict(
        # Use a random string for the name so we can easily regenerate this
        # test if the output changes in the future
        name="random_%s" % str(random.random()),
        name_utf8=to_bytes(u"\u00FC"),
        fetch_url_utf8=to_bytes(u"https://\u00FC.com/test.ps1")
    )

    dep_finder = PSModuleDepFinder()

    # Make sure that scripts can be imported with a non Windows filename
    dep_finder.scan_exec_script(test_data['name_utf8'])
    assert dep_finder.exec_scripts.get(test_data['name_utf8'], None) is not None

    # We can't really check the contents of this resource to see if it is the
   

# Generated at 2022-06-24 19:03:23.956867
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
   # c_module_data_0 = random.randint(0, 1000)
   # c_module_data_0 = None
   # c_module_data_0 = 0
   # c_module_data_0 = ""
   # c_module_data_0 =
   # c_module_data_0 = "Ansible.ModuleUtils.Legacy_PowerShell"
    c_module_data_0 = "Ansible.ModuleUtils.Legacy_PowerShell"
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data=c_module_data_0)


# Generated at 2022-06-24 19:03:28.651351
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(to_bytes("\n"))


# Generated at 2022-06-24 19:03:30.657415
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # PSModuleDepFinder().scan_module
    assert True


# Generated at 2022-06-24 19:03:35.700660
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test to see if its getting the path of Ansible.ModuleUtils.Common
    ansible_coll_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
    expected_1 = r"{}\lib\ansible\module_utils\common".format(ansible_coll_path)

    # Test to see if its reading the .psm1 file
    test_path = r"{}\test\units\module_utils\test_data\test_ps.psm1".format(ansible_coll_path)
    with open(test_path, 'rb') as test_file:
        test_data = test_file.read()
    p_s_module_

# Generated at 2022-06-24 19:03:42.906345
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with open('/home/runner/work/ansible/ansible-test/lib/ansible/module_utils/network/cloudengine/ce/test_utils_ps.psm1', 'rb') as fd:
        module_data = fd.read()
    p_s_module_dep_finder_0.scan_module(module_data)


# Generated at 2022-06-24 19:03:47.821547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_0 = C.DEFAULT_HASH_DISTINCT_MAGIC
    assert p_s_module_dep_finder_1.scan_exec_script(name_0)


# Generated at 2022-06-24 19:03:56.752762
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # set up test data
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:04:07.291084
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    valid_input = {
        # psmodule without requirement
        "test_module_0": to_bytes("#!powershell.exe\n"),
        # psmodule with various requirement
        "test_module_1": to_bytes("#!powershell.exe\n"
                                  "#Requires -Module Ansible.ModuleUtils.Legacy.PS\n"
                                  "#AnsibleRequires -PowerShell Ansible.ModuleUtils.Legacy.PS -Optional\n"
                                  "#AnsibleRequires -CSharpUtil Ansible.DummyCollection.plugins.module_utils.DummyUtil")
    }

# Generated at 2022-06-24 19:04:09.299538
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = b""
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(module_data)


# Generated at 2022-06-24 19:04:14.935979
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:05:12.824357
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script("script_name")


# Generated at 2022-06-24 19:05:17.706052
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    m_data = '''
#This is a test
    '''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn = 'test'
    wrapper = False
    powershell = True
    p_s_module_dep_finder_0.scan_module(m_data, fqn=fqn, wrapper=wrapper, powershell=powershell)


# Generated at 2022-06-24 19:05:23.554160
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    j0_0 = "amzn_linux"
    ansible_collections_0 = "ansible_collections"
    p0_0 = "cloud_ami"
    j2_0 = "init"
    Ansible_0 = "Ansible"
    j1_0 = "ansible_collections"

# Generated at 2022-06-24 19:05:27.826270
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # 'data' string is empty by default.
    ansible_module_data_0 = ''
    assert p_s_module_dep_finder_0.scan_module == AnsibleError
    assert p_s_module_dep_finder_0.scan_module == p_s_module_dep_finder_0.scan_module



# Generated at 2022-06-24 19:05:32.636369
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        # There is no need of unit testing this method, as it is for internal use in the module.
        p_s_module_dep_finder_0.scan_exec_script("test_name_0")
    except Exception as err:
        print("Exception caught in test_PSModuleDepFinder_scan_exec_script: %s" % err)


# Generated at 2022-06-24 19:05:38.242270
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test cases for string method scan_exec_script of class PSModuleDepFinder
    # Test case where data is not present in the powershell resource.
    try:
        p_s_module_dep_finder_0.scan_exec_script("invalid_script")
    except:
        pass
    # Test case where data is present in the powershell resource.
    p_s_module_dep_finder_0.scan_exec_script("basic")
    assert "basic" in p_s_module_dep_finder_0.exec_scripts
    # Test case with no statements in the powershell script.
    p_s_module_dep_finder_0.scan_exec_script("empty")
    assert "empty" in p_s_module_

# Generated at 2022-06-24 19:05:44.974899
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()

    resource = "WinRM"
    name = "ansible.netcommon.plugins.modules.win_ping"
    module_data = resource_from_fqcr(name,
                                     cache_resource=False,
                                     resource_type="module")
    p_s_module_dep_finder.scan_module(module_data,
                                      fqn=name,
                                      wrapper=False,
                                      powershell=True)

    assert resource in p_s_module_dep_finder.cs_utils_module


# Generated at 2022-06-24 19:05:52.946067
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()

    # Test 1
    # Expected result:
    #     -
    p_s_module_dep_finder.exec_scripts = {u'you': 'me'}
    p_s_module_dep_finder.scan_exec_script('you')
    assert p_s_module_dep_finder.exec_scripts == {u'you': 'me'}
    assert p_s_module_dep_finder.cs_utils_wrapper == {}

    # Test 2
    # Expected result:
    #     -
    p_s_module_dep_finder.exec_scripts = {}
    p_s_module_dep_finder.cs_utils_wrapper = {u'you': 'me'}
    p_s_module_dep_finder.scan

# Generated at 2022-06-24 19:05:54.060335
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False


# Generated at 2022-06-24 19:05:57.386744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = '0'
    assert not p_s_module_dep_finder_0.scan_exec_script(name_0)
