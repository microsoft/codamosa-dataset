

# Generated at 2022-06-24 18:57:27.275706
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_exec_script("invalid_name")
    except AnsibleError as a_e_obj_0:
        assert a_e_obj_0.message == 'Could not find executor powershell script for \'invalid_name\''


# Generated at 2022-06-24 18:57:30.516610
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_1 = p_s_module_dep_finder_1.scan_exec_script("powershell_manager")
    assert isinstance(name_1, type(None))


# Generated at 2022-06-24 18:57:36.127126
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_bytes("test_str"))


# Generated at 2022-06-24 18:57:39.542074
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cmd_class_0 = PSModuleDepFinder()
    assert cmd_class_0 is not None
    test_file = 'get-ansible-plugins.ps1'
    result = cmd_class_0.scan_exec_script(command_name=test_file)
    assert result is None


# Generated at 2022-06-24 18:57:41.395050
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b'\n#Requires -Module Ansible.ModuleUtils.Windows.Utils\n')


# Generated at 2022-06-24 18:57:47.852299
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.collection_loader import _get_collection_loader

    # Set up the test and make a module_data for a collections module.
    loader_0 = _get_collection_loader()

    m_0 = resource_from_fqcr('ansible_collections.ansible.builtin.win_command')[0]

    m_data_0 = to_bytes(m_0.content())

    # Test that scan_exec_script raises the correct error
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script(to_text(b'foo'))
    except AnsibleError as err:
        if "Could not find executor powershell script" in str(err):
            pass


# Generated at 2022-06-24 18:57:52.270939
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_PSModuleDepFinder_scan_exec_script_0()
    test_case_PSModuleDepFinder_scan_exec_script_1()
# Unit test 0 for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 18:57:57.696798
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Initialization
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = b''
    data = base64.standard_b64decode(module_data)
    module_data = to_bytes(data, errors='surrogate_or_strict')
    fqn = None
    wrapper = False
    powershell = True

    # Execution
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-24 18:58:01.208174
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_1 = 'whoami'
    p_s_module_dep_finder_1.scan_exec_script(name_1)


# Generated at 2022-06-24 18:58:10.887528
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(
        '#Requires -Module Ansible.ModuleUtils.Powershell'
    )
    p_s_module_dep_finder_0.scan_module(
        '#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.CommonUtils'
    )
    collection = "my_a"
    namespace = "my_b"
    p_s_module_dep_finder_0.scan_module(
        'using Ansible.ModuleUtils.CommonUtils;',
        fqn=namespace + '.' + collection + '.plugins.modules.my_0',
        wrapper=True,
        powershell=False
    )
    p_s_

# Generated at 2022-06-24 18:58:26.354480
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = u'become'
    assert p_s_module_dep_finder_0.scan_exec_script(name) == p_s_module_dep_finder_1.scan_exec_script(name)
    return True


# Generated at 2022-06-24 18:58:31.308456
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    string_0 = to_bytes(random.choice(['helper', 'test_string', 'string_2']))
    p_s_module_dep_finder_0.scan_exec_script(string_0)


# Generated at 2022-06-24 18:58:39.348938
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()

    try:
        depfinder.scan_exec_script('not_exists')
    except Exception as e:
        assert type(e).__name__ == "AnsibleError"

    depfinder.scan_exec_script('powershell_override_args')

    assert to_text(depfinder.exec_scripts['powershell_override_args']) == to_text(open(C.DEFAULT_LOCAL_TMP + '/exec_scripts/powershell_override_args.ps1', 'rb').read())

    assert to_text(depfinder.exec_scripts['powershell_override_args']) != to_text('')


# Generated at 2022-06-24 18:58:45.459157
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Given
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "1"

    # When
    p_s_module_dep_finder_0.scan_exec_script(name_0)

    # Then
    assert True


# Generated at 2022-06-24 18:58:49.270486
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_exec_script("")
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 18:58:53.422028
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_1 = "test name"

    # Call the method in question
    p_s_module_dep_finder_1.scan_exec_script(name_1)


# Generated at 2022-06-24 18:58:57.680389
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("get_process_list")
    # assert len(p_s_module_dep_finder.exec_scripts) == 1


# Generated at 2022-06-24 18:59:08.959843
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'testfile'
    # unit test for scan_exec_script

    # call with
    # name = 'testfile'
    # with following args:
    # p_s_module_dep_finder_0.scan_exec_script(name_0)

    # verify results
    assert isinstance(p_s_module_dep_finder_0.exec_scripts, dict)
    assert not p_s_module_dep_finder_0.exec_scripts

    assert isinstance(p_s_module_dep_finder_0.ps_modules, dict)
    assert not p_s_module_dep_finder_0.ps_modules


# Generated at 2022-06-24 18:59:15.503262
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test with a random name generated
    name_0 = "".join(chr(random.randrange(32, 126)) for i in range(0, random.randrange(5, 100)))
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:59:29.473211
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # These are the full paths to the executor scripts,
    # we don't really care about the path but just if it can find them

# Generated at 2022-06-24 18:59:56.731380
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()

    # test with name as string input
    assert p_s_module_dep_finder.scan_exec_script("azure_rm_virtualmachine") != None
    assert p_s_module_dep_finder.scan_exec_script("not_a_module") == None



# Generated at 2022-06-24 18:59:58.872736
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert p_s_module_dep_finder_0.scan_exec_script('init_wrapper') == None


# Generated at 2022-06-24 19:00:05.958602
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("common")
    p_s_module_dep_finder.scan_exec_script("common")
    p_s_module_dep_finder.scan_exec_script("common")
    assert p_s_module_dep_finder.exec_scripts["common"] != None


# Generated at 2022-06-24 19:00:20.147257
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = to_bytes(
        '#Requires -Module Ansible.ModuleUtils.basic\n'
        '#Requires -Module Ansible.ModuleUtils.common_redhat\n'
        '#Requires -Module Ansible.ModuleUtils.network.common.utils\n'
        '#Requires -Module Ansible.ModuleUtils.network.common.config\n'
        '#Requires -Module Ansible.ModuleUtils.network.common.facts\n'
        '#Requires -Module Ansible.ModuleUtils.network.ios.facts\n'
        '#Requires -Module Ansible.ModuleUtils.network.ios.ios\n'
    )
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_

# Generated at 2022-06-24 19:00:24.224312
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('')



# Generated at 2022-06-24 19:00:32.647664
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name="basic")
    p_s_module_dep_finder_0.scan_exec_script(name="basic")
    p_s_module_dep_finder_0.scan_exec_script(name="basic")
    p_s_module_dep_finder_0.scan_exec_script(name="basic")


# Generated at 2022-06-24 19:00:40.176713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_scan_exec_script_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_scan_exec_script_0.scan_exec_script("")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:00:42.096597
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 19:00:46.204565
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("Basic")


# Generated at 2022-06-24 19:00:54.829816
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test 1: use a simple module with a single builtin util dependency
    #         and test that it's returned in the module_utils
    module_text_0 = u'''
#Requires -Module Ansible.ModuleUtils.Basic
#Requires -Module Ansible.ModuleUtils.Url

#Requires -Module Ansible.ModuleUtils.Basic
$a = Get-ChildItem -Path ..
Write-Output $a'''

    module_bytes_0 = to_bytes(module_text_0)

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_bytes_0)
    p_s_module_dep_finder_0.scan_exec_script("AbsPath")
    p_s_module_dep_finder_0

# Generated at 2022-06-24 19:01:19.854559
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("#Requires -Module Ansible.ModuleUtils.VMTools")


# Generated at 2022-06-24 19:01:22.541731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    print("waiting for scan_exec_script method to be implemented")


# Generated at 2022-06-24 19:01:26.963840
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    args = (
        "",
        "test_fqn",
        False,
        True,
    )

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(*args)


# Generated at 2022-06-24 19:01:34.553708
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "main.ps1"
    data = pkgutil.get_data("ansible.executor.powershell", name)
    if data is None:
        assert False
    else:
        b_data = to_bytes(data)
        commentless_data = _strip_comments(b_data)
        p_s_module_dep_finder_0.exec_scripts[name] = commentless_data
        p_s_module_dep_finder_0.scan_module(b_data, False)
        assert name in p_s_module_dep_finder_0.exec_scripts
        assert p_s_module_dep_finder_0.exec_scripts[name] == commentless_data

# Generated at 2022-06-24 19:01:38.284718
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # NOTE: if a module requires a specific PS version, a test will need to
    # be included here to detect that
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = to_bytes('test_case_0.ps1')
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:01:44.925028
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Bad module name
    p_s_module_dep_finder = PSModuleDepFinder()
    try:
        p_s_module_dep_finder.scan_exec_script("foo")
        assert False
    except AnsibleError:
        pass

    # Good module name, but one that is not found
    try:
        p_s_module_dep_finder.scan_exec_script("_bar")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:01:48.027600
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_6 = PSModuleDepFinder()
    p_s_module_dep_finder_6.scan_exec_script(name_0=to_text("test_0"))


# Generated at 2022-06-24 19:01:50.505434
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    res = PSModuleDepFinder().scan_exec_script(to_text(u'psmoduleloader'))
    assert res == None


# Generated at 2022-06-24 19:01:57.641569
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder.scan_exec_script("test_ansible_executor_powershell.ps1")
    assert to_text(excinfo.value) == "Could not find executor powershell script for 'test_ansible_executor_powershell.ps1'"


# Generated at 2022-06-24 19:02:02.178663
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call method scan_exec_script of class PSModuleDepFinder
    p_s_module_dep_finder_0.scan_exec_script("_load_module_dependencies")
# ---- END ----


# Generated at 2022-06-24 19:02:58.253197
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("test_PSModuleDepFinder_scan_module")

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    test_fqn_1 = "Foo.Bar.Baz.Quux"
    test_data_1 = to_bytes("""
#Requires -Module Microsoft.PowerShell.Management
#AnsibleRequires -Powershell ansible_collections.ansible.builtin.plugins.module_utils.wait_for
#AnsibleRequires -CSharpUtil ansible_collections.ansible.builtin.plugins.module_utils.wait_for
""")
    p_s_module_dep_finder_1.scan_module(test_data_1, fqn=test_fqn_1)
    

# Generated at 2022-06-24 19:03:06.936979
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    from ansible.module_utils.compat.collection_loader import _get_loader

    module_path = os.path.join(os.environ['ANSIBLE_COLLECTIONS_PATHS'], 'test_namespace/test_collection/plugins/modules/test_module')
    module_data = _slurp(module_path)

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(module_data, 'test_namespace.test_collection.plugins.module_utils.test_module')

    loader = _get_loader()
    collection = 'test_namespace.test_collection'
    plugin_type = 'module_utils'
    name = 'test_module'


# Generated at 2022-06-24 19:03:15.861010
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = 'hello'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert not p_s_module_dep_finder_0.exec_scripts
    with pytest.raises(AnsibleError) as ae:
        p_s_module_dep_finder_0.scan_exec_script(name)
        assert ae == 'Could not find executor powershell script ' + name


# Generated at 2022-06-24 19:03:22.792681
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        b_data_0 = p_s_module_dep_finder_0.scan_exec_script('comparisons')
        assert b_data_0 == None
    except Exception as e:
        assert False


# Generated at 2022-06-24 19:03:32.783466
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    #
    # unit tests for AnsibleModule DepsFinder
    #

    # The following should create deps:
    #  - Ansible.ModuleUtils.C#.Custom
    #  - Ansible.ModuleUtils.C#.FileSystem
    #  - Ansible.ModuleUtils.C#.PSCustomObject
    #  - Ansible.ModuleUtils.C#.PSTypeConverter
    #  - Ansible.ModuleUtils.C#.System.Management.Automation.Dictionary
    #  - Ansible.ModuleUtils.C#.System.Management.Automation.PSReference
    #  - Ansible.Windows.FileSystem
    #  - .CommonSpec
    #  - .CommonSpec.Hive

# Generated at 2022-06-24 19:03:44.321116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # unit tests for method scan_exec_script of class PSModuleDepFinder arguments: name
    # Test case 1
    p_s_module_dep_finder_0.scan_exec_script("test.ps1")
    # Test case 2
    p_s_module_dep_finder_0.scan_exec_script("test.ps1")
    # Test case 3
    p_s_module_dep_finder_0.scan_exec_script(str(random.randint(0,9999)))
    # Test case 4
    p_s_module_dep_finder_0.scan_exec_script(str(random.randint(0,9999)))



# Generated at 2022-06-24 19:03:48.138600
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_0 = u'wrapper_module'
    p_s_module_dep_finder_1.scan_exec_script(name_0)


# Generated at 2022-06-24 19:03:54.349755
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # get data
    data = pkgutil.get_data("ansible.executor.powershell", "win_command.ps1")
    if data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for '%s'" % name)

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        exec_script = data
    else:
        exec_script = _strip_comments(data)

    # test default
    p_s_module_dep_finder_1.scan_exec_script("win_command.ps1")


# Generated at 2022-06-24 19:04:04.595874
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    data = p_s_module_dep_finder_0.scan_exec_script("powershell")
    assert (data == None)

    data = p_s_module_dep_finder_0.scan_exec_script("powershell_7")
    assert (data == None)

    data = p_s_module_dep_finder_0.scan_exec_script("powershell_core")
    assert (data == None)

    data = p_s_module_dep_finder_0.scan_exec_script("powershell_core_7")
    assert (data == None)

    data = p_s_module_dep_finder_0.scan_exec_script("powershell_core")
    assert (data == None)

    data = p

# Generated at 2022-06-24 19:04:08.176837
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_3 = PSModuleDepFinder()

    result = p_s_module_dep_finder_3.scan_exec_script("test")

    assert(result == None)


# Generated at 2022-06-24 19:05:05.185546
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('base')
    if (p_s_module_dep_finder_0.become != True):
        raise Exception("assert fail")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('net')
    if (p_s_module_dep_finder_0.exec_scripts['net'] != '{\r\n  Import-Module NetConnection\r\n}\r\n'):
        raise Exception("assert fail")


# Generated at 2022-06-24 19:05:13.079818
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Creating object of class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Creating a module named powershell_0.ps1 to test scan_exec_script method of class PSModuleDepFinder
    ansible_executor_powershell_1 = pkgutil.get_data("ansible.executor.powershell", to_native("powershell_0.ps1"))
    if ansible_executor_powershell_1 is None:
        raise AnsibleError("Could not find executor powershell script ")

    # Asserting if the execution of scan_exec_script method is correct
    assert ansible_executor_powershell_1 == p_s_module_dep_finder_0.scan_exec_script("powershell_0.ps1")


# Generated at 2022-06-24 19:05:15.641268
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ansible_wrapper')


# Generated at 2022-06-24 19:05:26.039604
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script("Find-File") == None
    assert p_s_module_dep_finder_0.scan_exec_script("PSVersion") == None
    assert p_s_module_dep_finder_0.scan_exec_script("Get-CommonParams") == None
    assert p_s_module_dep_finder_0.scan_exec_script("ansible.powershell.common.strings") == None
    assert p_s_module_dep_finder_0.scan_exec_script("ansible.powershell.common.ansible_strings") == None

# Generated at 2022-06-24 19:05:32.485872
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'#AnsibleRequires -PowerShell ansible.module_utils.common.os_path'
    fqn_0 = None
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 19:05:42.439594
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name) of class PSModuleDepFinder
    # Task: Test to see if we can find and scan a powershell script in lib/ansible/executor/powershell
    # Result: The script 'ansible_module_wrapper.ps1' is found, parsed and the required file 'module_common.ps1'
    #         is added inside the ps_modules dict of PSModuleDepFinder object
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ansible_module_wrapper')
    p_s_module_dep_finder_0.ps_modules.keys() == {'Ansible.ModuleUtils.Common'}


# Generated at 2022-06-24 19:05:46.626086
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("get_powershell_version")
    assert p_s_module_dep_finder_0.exec_scripts == {'get_powershell_version': b'$version = Get-Host | Select-Object -ExpandProperty Version\nWrite-Output $version.Major, $version.Minor\n'}
    assert p_s_module_dep_finder_0.become is False


# Generated at 2022-06-24 19:05:52.662600
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # noinspection PyProtectedMember
    with open(os.path.join(C.DEFAULT_LOCAL_TMP, "test_file_test_case_0"), 'w') as test_file:
        test_file.write("test package_name")

    assert p_s_module_dep_finder_0.scan_module("test module_data") is None
    assert p_s_module_dep_finder_0.scan_module("test module_data", fqn="test fqn", wrapper=False, powershell=False) is None


# Generated at 2022-06-24 19:05:58.320524
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    if True:
        name_0 = to_text("name_0")
        # Value to return
        return_value_0 = None
        # Call method
        p_s_module_dep_finder_0.scan_exec_script(name_0)
        # Check return value
        assert return_value_0 == None


# Generated at 2022-06-24 19:06:01.229923
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    p_s_module_dep_finder.scan_exec_script(name)
