

# Generated at 2022-06-24 18:57:29.494517
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    expected_result = p_s_module_dep_finder_1.scan_exec_script("__init__")
    assert not expected_result


# Generated at 2022-06-24 18:57:36.421811
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_PSModuleDepFinder_scan_exec_script")


# Generated at 2022-06-24 18:57:41.169411
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    b_data = to_bytes(pkgutil.get_data("ansible_collections.ansible.builtin.plugins.module_utils.network.fortios", "fortios.psm1"))
    dep_finder.scan_module(b_data)

    assert dep_finder.ps_modules
    assert dep_finder.cs_utils_module
    assert dep_finder.cs_utils_wrapper
    assert dep_finder.exec_scripts



# Generated at 2022-06-24 18:57:43.597790
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script('Test-ModuleManifest')


# Generated at 2022-06-24 18:57:44.480233
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-24 18:57:55.335780
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.network.common import get_diff
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.utils.collection_loader import resource_from_fqcr
    import pkgutil, os, errno

    def _slurp(path):
        with open(path, 'rb') as fp:
            return to_native(fp.read())

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = b'\n'
    fqn = None
    wrapper = False
    powershell = True
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)

# Generated at 2022-06-24 18:58:01.761437
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 18:58:10.918735
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Creating a PSModuleDepFinder object to test
    p_s_module_dep_finder = PSModuleDepFinder()
    # Creating a string to test
    string = "#Requires -Module Ansible.PowerShell.DSC"
    string_1 = "#AnsibleRequires -PowerShell Ansible.ModuleUtils.PAM"
    # Calling scan_module method to test
    p_s_module_dep_finder.scan_module(string)
    p_s_module_dep_finder.scan_module(string_1)
    assert(p_s_module_dep_finder.ps_modules['Ansible.PowerShell.DSC'] != None)
    assert(p_s_module_dep_finder.ps_modules['Ansible.ModuleUtils.PAM'] != None)



# Generated at 2022-06-24 18:58:16.091793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('s2s')
    assert to_native(p_s_module_dep_finder_0.exec_scripts['s2s']) == ''
    # This should error with a walkback so the next assert should never run.
    # p_s_module_dep_finder_0.scan_exec_script('s3s')
    # assert to_native(p_s_module_dep_finder_0.exec_scripts['s3s']) == ''


# Generated at 2022-06-24 18:58:23.121166
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import sys
    from ansible_collections.all.not_real.tests.unit.plugins.modules.utils import _test_data_path

    test_data_path = _test_data_path()
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test the builtin modules
    p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.Pester')
    assert 'Ansible.ModuleUtils.Pester' in p_s_module_dep_finder_0.ps_modules
    # Test collection modules

# Generated at 2022-06-24 18:58:45.254273
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_text('ansible_powershell.psm1', errors='surrogate_or_strict'))


# Generated at 2022-06-24 18:58:52.721953
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    module_data = """
    #Requires -Module Ansible.ModuleUtils.Foo
    #Requires -Module Ansible.ModuleUtils.Bar
    """
    p_s_module_dep_finder_1.scan_module(module_data)

# Generated at 2022-06-24 18:59:01.962760
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 18:59:05.831349
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script("hello")
    except Exception as e:
        assert type(e) == AnsibleError


# Generated at 2022-06-24 18:59:11.875805
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Basic')
    assert len(p_s_module_dep_finder_0.ps_modules) == 1
    p_s_module_dep_finder_0.scan_module(b'#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.basic')
    assert len(p_s_module_dep_finder_0.ps_modules) == 2
    p_s_module_dep_finder_0.scan_module(b'#AnsibleRequires -PowerShell ..module_utils.basic')

# Generated at 2022-06-24 18:59:23.157395
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("test_PSModuleDepFinder_scan_exec_script")
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 18:59:25.819969
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "name"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:59:30.313940
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder();
    assert p_s_module_dep_finder_1.scan_exec_script("");


# Generated at 2022-06-24 18:59:38.839986
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "powershell_invocation"
    p_s_module_dep_finder_0.scan_exec_script(name_0)

# Generated at 2022-06-24 18:59:49.109413
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tests if scan_exec_script of class PSModuleDepFinder successfully scan the library
    try :
        p_s_module_dep_finder_1 = PSModuleDepFinder()
    except :
        print("Constructor of PSModuleDepFinder throws exception")
        return False
    try :
        p_s_module_dep_finder_1.scan_exec_script('common')
    except:
        print("Scan_exec_script throws exception")
        return False
    if not isinstance(p_s_module_dep_finder_1.exec_scripts, dict):
        print("exec_scripts is not a dictionary")
        return False
    if not isinstance(p_s_module_dep_finder_1.ps_modules, dict):
        print("ps_modules is not a dictionary")
        return False

# Generated at 2022-06-24 19:00:05.793091
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("shim")


# Generated at 2022-06-24 19:00:10.248815
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:00:16.137826
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script(to_text("yep it works", errors='surrogate_or_strict')) is None


# Generated at 2022-06-24 19:00:21.970779
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = 'test_ansible_string_0'
    assert p_s_module_dep_finder_0.exec_scripts.keys() != None
    # Delete the key in dict.
    del p_s_module_dep_finder_0.exec_scripts[str_0]
    assert str_0 in p_s_module_dep_finder_0.exec_scripts.keys() == False


# Generated at 2022-06-24 19:00:31.221574
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for all exec scripts
    import os
    from ansible.executor.powershell.powershell import _remove_byte_order_marker

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    scripts_folder = os.path.join(os.path.dirname(__file__), 'scripts')
    for script in os.listdir(scripts_folder):
        if not script.endswith('.ps1'):
            continue
        script_path = os.path.join(scripts_folder, script)
        with open(script_path) as f:
            p_s_module_dep_finder_1.scan_exec_script(_remove_byte_order_marker(f.read()))



# Generated at 2022-06-24 19:00:38.992744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script('test_exec_script')
    except AnsibleError as e:
        assert False, "Cannot test scan_exec_script with valid exec script"
    try:
        p_s_module_dep_finder_0.scan_exec_script('test_exec_script_invalid')
        assert False, "Expected an exception when invalid exec script passed to scan_exec_script"
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:00:42.655367
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for function scan_exec_script of class PSModuleDepFinder
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_exec_script("powershell_wrapper") == None


# Generated at 2022-06-24 19:00:50.196845
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils import powershell

    if not powershell.HAS_POWERSHELL:
        return

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    name_1 = "exec_module"

    p_s_module_dep_finder_0.scan_exec_script(name_1)

    expected_value_for_exec_scripts = {}
    expected_value_for_exec_scripts['exec_module'] = to_bytes('')

    assert p_s_module_dep_finder_0.exec_scripts == expected_value_for_exec_scripts


# Generated at 2022-06-24 19:00:58.296886
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Create an instance of the mock class for the class module_utils.
    class MockClassName_0(object):

        def __init__(self, ):
            self.ps_modules = {}

        # Return a bytearray of the module_util_data for the module_util with name string name
        def get_module_util_data_bytearray(self, module_util):
            if module_util == "Ansible.ModuleUtils.ArgumentSpec":
                return b"#Requires -Module Ansible.ModuleUtils.ArgumentSpec"

# Generated at 2022-06-24 19:01:04.394645
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'ansible.module_utils.powershell.basic'
    name = to_text(name) if not isinstance(name, text_type) else name
    assert isinstance(name, text_type)
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:01:33.874403
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common')
    assert type(p_s_module_dep_finder_0.exec_scripts) is dict
    assert type(p_s_module_dep_finder_0.exec_scripts['common']) is bytes
    assert "try" in str(p_s_module_dep_finder_0.exec_scripts['common'])
    assert len(p_s_module_dep_finder_0.ps_modules.keys()) > 0
    assert "Ansible.ModuleUtils.Common" in p_s_module_dep_finder_0.ps_modules.keys()


# Generated at 2022-06-24 19:01:38.744246
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = u'ansible.module_utils.ansible_powerpath_module.PowerPath'
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_1.scan_exec_script(name)
    assert u"Could not find executor powershell script for 'ansible.module_utils.ansible_powerpath_module.PowerPath'" in to_native(excinfo.value)


# Generated at 2022-06-24 19:01:44.434831
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'test_script'
    data_0 = '#AnsibleRequires -PowerShell Ansible.Utils'
    p_s_module_dep_finder_0.scan_exec_script(name_0, data_0)


# Generated at 2022-06-24 19:01:53.465204
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = '0'
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_0 = '1'
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_0 = '2'
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_0 = '3'
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_0 = '4'
    p_s_module_dep_finder_0.scan_exec_script(str_0)
    str_0 = '5'
    p_s_

# Generated at 2022-06-24 19:01:57.536286
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("ps_script_name")


# Generated at 2022-06-24 19:02:05.883586
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Return a random integer between 0 and 10
    randint = random.randint(0,10)
    mod_data_0 = randint
    fqn_1 = 'ansible.builtin.raw'
    wrapper_2 = True
    powershell_3 = True
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0._re_cs_module, ["Ansible.ModuleUtils.{name}"]
    assert p_s_module_dep_finder_0._re_cs_module, ["ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}"]
    assert p_s_module_dep_finder_0._re_cs_in_ps_module, ["Ansible.{name}"]

# Generated at 2022-06-24 19:02:18.361188
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0

    # line 1
    name_0 = 'Util_Code'

    data_0 = b'#requires -version 5.0\r\rif ($PSBoundParameters[\'Color\']) {\r\t$Host.UI.RawUI.ForegroundColor = $Color\r}\r\rif ($PSBoundParameters[\'Message\']) {\r\tWrite-Host $Message\r}\r\r'

    assert data_0

    data_1 = pkgutil.get_data('ansible.executor.powershell', to_native(name_0 + ".ps1"))


# Generated at 2022-06-24 19:02:22.573499
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("test")
    assert True


# Generated at 2022-06-24 19:02:25.974274
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = 'test'
    # exception=AnsibleError("Could not find executor powershell script for 'test'")
    # p_s_module_dep_finder.scan_exec_script(name)
    p_s_module_dep_finder.scan_exec_script("test")


# Generated at 2022-06-24 19:02:31.364920
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('Get-SystemCommand')
    assert p_s_module_dep_finder_1.exec_scripts['Get-SystemCommand']


# Generated at 2022-06-24 19:03:21.502310
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ps_init')
    dep_finder.scan_exec_script('ps_run_section')
    dep_finder.scan_exec_script('ps_run_playbook')


# Generated at 2022-06-24 19:03:30.761408
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
        Test case for testing scan_module method of class PSModuleDepFinder
    '''
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:03:35.434240
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        exc_raised = False
        p_s_module_dep_finder_0.scan_exec_script('foo')
    except Exception as e:
        exc_raised = True
    assert exc_raised == True


# Generated at 2022-06-24 19:03:38.958059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_exec_script_name_0")



# Generated at 2022-06-24 19:03:50.947606
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # instantiate an object of type PSModuleDepFinder
    p_s_module_dep_finder = PSModuleDepFinder()

    # There is no file named 'Simple.psm1' in the test dir. Hence, error will be thrown.
    try:
        p_s_module_dep_finder.scan_module(to_bytes(""), "Simple.psm1")
        assert 1 == 0, "Expected an exception to be thrown"
    except Exception as err:
        assert "Could not find imported module support code" in str(err), "Expected an AnsibleError"

    p_s_module_dep_finder.scan_module(to_bytes(""), "Test.psm1")

# Generated at 2022-06-24 19:03:59.213092
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name_0 = random.randint(1, 100000000)

    try:
        # Note that this test case does not currently run the scan_module method.
        # In the future, we could update this test case to scan the script it
        # found and verify the module_util dependencies found match what we
        # expect.
        p_s_module_dep_finder_0.scan_exec_script(n_name_0)
    except AnsibleError as e:
        if str(e) != 'Could not find executor powershell script for \'%d\'' % n_name_0:
            raise e
    except ImportError as e:
        if str(e) != 'No package data found':
            raise e


# Generated at 2022-06-24 19:04:03.618988
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(random.choice([
        'script_1',
        'script_2',
        'script_3',
        'script_4']))


# Generated at 2022-06-24 19:04:08.062690
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test for exception: AnsibleError
    with pytest.raises(AnsibleError):
        p_s_module_dep_finder_0.scan_exec_script("fake_name")


# Generated at 2022-06-24 19:04:13.164500
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
    except:
        print("Issue when processing arguments.")
        return

    p_s_module_dep_finder_0.scan_exec_script("DefaultArgProcessing")
    assert p_s_module_dep_finder_0.exec_scripts.get('DefaultArgProcessing')

# used when we want to make sure the utils are tested

# Generated at 2022-06-24 19:04:18.019152
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_module(1)
    except TypeError:
        pass
