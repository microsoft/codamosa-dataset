

# Generated at 2022-06-24 18:57:35.414088
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("1.0.0", "2")
    #assert p_s_module_dep_finder_0.scan_exec_script("0") == ""


# Generated at 2022-06-24 18:57:42.376578
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible.module_utils.powershell.builtin_commands
    import ansible.module_utils.powershell.process
    import ansible.module_utils.powershell.security
    import ansible.module_utils.powershell.text_xml_objectmodel
    import ansible.module_utils.powershell.win_dsc
    import ansible.module_utils.powershell.win_file_dacl

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    module_data_0 = to_bytes(ansible.module_utils.powershell.process.__doc__)
    module_data_1 = to_bytes(ansible.module_utils.powershell.win_file_dacl.__doc__)

# Generated at 2022-06-24 18:57:44.875508
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_exec_script('module')


# Generated at 2022-06-24 18:57:55.664891
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 18:57:58.176144
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # ERROR: no module_data for scan_module
    with pytest.raises(AnsibleError):
        p_s_module_dep_finder_0.scan_module()


# Generated at 2022-06-24 18:58:01.813177
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = b'Ansible.ModuleUtils.Windows.Networking\n'
    fqn_4 = 'ansible_collections.community.windows.plugins.modules.win_ping'
    p_s_module_dep_finder_1.scan_module(module_data_1, fqn_4)


# Generated at 2022-06-24 18:58:09.574776
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_3 = PSModuleDepFinder()
    with open('test_data/test_PSModuleDepFinder_scan_exec_script.data', 'r') as f:
        data = f.read()
        lines = data.rstrip().split('\n')
        for line in lines:
            test_args, expected_result = line.split('<<<')
            test_args = test_args.rstrip()
            p_s_module_dep_finder_0.scan_module(base64.b64decode(test_args))

# Generated at 2022-06-24 18:58:16.063354
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test with 0.
    p_s_module_dep_finder_0.scan_exec_script(to_text(0))
    # Test with 1.
    p_s_module_dep_finder_0.scan_exec_script(to_text(1))
    # Test with 2.
    p_s_module_dep_finder_0.scan_exec_script(to_text(2))
    # Test with 3.
    p_s_module_dep_finder_0.scan_exec_script(to_text(3))
    # Test with 4.
    p_s_module_dep_finder_0.scan_exec_script(to_text(4))
    # Test with 5.
    p_s_module_

# Generated at 2022-06-24 18:58:18.430343
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("Some test string")


# Generated at 2022-06-24 18:58:26.380006
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    _v = vars()
    _v.update(locals())
    module_data_0 = '#Requires -Module Ansible.ModuleUtils.legacy'
    module_data_0 = to_bytes(module_data_0)
    fqn_0 = 'ansible_collections.special.special_default.plugins.modules.ping'
    print('Calling function scan_module with parameters: {}'.format(locals()))
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0)


# Generated at 2022-06-24 18:58:44.325832
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Case 0
    # TODO: Add test code for this use case
    p_s_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 18:58:47.022931
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module('MyString', 'MyFqn', True, False)


# Generated at 2022-06-24 18:58:50.946845
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name="test_value")


# Generated at 2022-06-24 18:58:54.335523
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pkgutil
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name = 'script')


# Generated at 2022-06-24 18:58:59.303543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    if not (p_s_module_dep_finder_0.scan_exec_script('connection_wrapper')):
        raise AssertionError('test case 0 failed: p_s_module_dep_finder_0.scan_exec_script(\'connection_wrapper\')')


# Generated at 2022-06-24 18:59:06.236070
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # AssertionError: Could not find executor powershell script for 'copy-file'
    try:
        p_s_module_dep_finder_0.scan_exec_script("copy-file")
    except AssertionError:
        pass


# Generated at 2022-06-24 18:59:08.501107
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'name_0'
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:59:12.218848
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("exec")
    assert p_s_module_dep_finder_0.exec_scripts[b"exec"] == b"\n\n"
    assert p_s_module_dep_finder_0.ps_modules == {'Ansible.ModuleUtils.Basic': {'data': b"\n\n", 'path': '...module_utils/basic.psm1'}}


# Generated at 2022-06-24 18:59:16.554915
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('0')


# Generated at 2022-06-24 18:59:21.966359
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test string")


# Generated at 2022-06-24 18:59:38.457066
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "test_value"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:59:46.133359
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common._collections_compat import to_bytes
    from ansible.module_utils.common._collections_compat import to_text
    from ansible.module_utils.six import PY3

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_3 = PSModuleDepFinder()
    # Test for exceptions
    module_data = 'not bytes'
    if PY3:
        module_data = to_bytes(module_data, errors='surrogate_or_strict')

# Generated at 2022-06-24 18:59:48.012719
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "Ansible.ModuleUtils.Legacy_1"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:59:59.529466
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_text("module_compat"))
    exec_scripts_0 = p_s_module_dep_finder_0.exec_scripts
    # Verify the size of the map exec_scripts after method scan_exec_script execution
    assert len(exec_scripts_0) == 1, "Incorrect number of elements in exec_scripts after scan_exec_script"
    # Verify that the value of element exec_scripts_0[to_text("module_compat")] after method scan_exec_script execution is "XXX" using base64 encoding

# Generated at 2022-06-24 19:00:04.021626
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqcr = 'ansible.builtin.spot_module_utils.module_utils.module_utils_loader.load_module_utils'
    s_module_data_0 = to_bytes('')
    p_s_module_dep_finder_0.scan_module(s_module_data_1, fqcr)
    s_module_data_1 = to_bytes('')
    p_s_module_dep_finder_0.scan_module(s_module_data_0, fqcr)


# Generated at 2022-06-24 19:00:09.882279
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        module_data_0 = ""
        fqn_0 = None
        wrapper_0 = False
        powershell_0 = True
        p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)
    except Exception as exception:
        assert False, 'unexpected exception raised %s' % exception.__class__.__name__
    else:
        assert True


# Generated at 2022-06-24 19:00:16.341312
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        p_s_module_dep_finder_0.scan_exec_script("doesnotexist")
    p_s_module_dep_finder_0.scan_exec_script("win_command")
    assert p_s_module_dep_finder_0.exec_scripts['win_command']
    assert len(p_s_module_dep_finder_0.ps_modules) > 0


# Generated at 2022-06-24 19:00:18.943828
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = ''
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except:
        raise Exception()


# Generated at 2022-06-24 19:00:25.041059
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:00:33.034690
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    byte_module_data_0 = b'\n'
    str_fqn_0 = None
    bool_wrapper_0 = False
    bool_powershell_0 = True
    p_s_module_dep_finder_0.scan_module(byte_module_data_0, str_fqn_0, bool_wrapper_0, bool_powershell_0)



# Generated at 2022-06-24 19:00:47.700942
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test 1: basic
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("executor")
    assert p_s_module_dep_finder_1 is not None


# Generated at 2022-06-24 19:00:58.048278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Testing with framework.ps1 as input
    p_s_module_dep_finder_0.scan_exec_script("framework")

    # Testing with framework_base64.ps1 as input
    p_s_module_dep_finder_0.scan_exec_script("framework_base64")

    # Testing with framework_random.ps1 as input
    p_s_module_dep_finder_0.scan_exec_script("framework_random")

    # Testing with framework_safe.ps1 as input
    p_s_module_dep_finder_0.scan_exec_script("framework_safe")


# Generated at 2022-06-24 19:01:01.675167
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test empty case when module_data is ''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_module('', fqn=None, wrapper=False, powershell=True)
    except:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-24 19:01:07.916281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'test_name_0'
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except AnsibleError as e:
        print(e)
        assert 'Could not find executor powershell script for \'%s\'' % name_0 in e.message


# Generated at 2022-06-24 19:01:12.908441
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test")


# Generated at 2022-06-24 19:01:15.952495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = ""
    result = PSModuleDepFinder.scan_exec_script(name)
    print('result: ' + str(result))


# Generated at 2022-06-24 19:01:25.922370
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn = 'ansible_collections.namespace.collection.plugins.modules.test'
    module_data = b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.CommonUtils\n'
    bad_module_util_import = b'#AnsibleRequires -PowerShell Bad.ModuleUtil.Name\n'
    bad_wrapper_import = b'#AnsibleRequires -Wrapper Bad.PowerShell.Name\n'
    fqn_cs_module_util = b'#AnsibleRequires -CSharpUtil .ModuleUtils.CommonUtils\n'

# Generated at 2022-06-24 19:01:27.600926
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script("None")


# Generated at 2022-06-24 19:01:33.793672
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test 1: Add a module
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('psm1_file_0')
    assert "psm1_file_0" in p_s_module_dep_finder_1.exec_scripts



# Generated at 2022-06-24 19:01:35.795928
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("win_stat.ps1")


# Generated at 2022-06-24 19:01:53.871059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with only argument.
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common')

    # Test with multiple arguments.
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('common')


# Generated at 2022-06-24 19:02:01.569564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        # noinspection PyUnusedLocal
        test_value = False

        # test if empty script name throws an exception
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script("")

    except ValueError as err:
        if err.args[0] == "empty script name":
            test_value = True
    assert test_value


# Generated at 2022-06-24 19:02:05.528093
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create class instance
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call method scan_exec_script on class instance
    p_s_module_dep_finder_0.scan_exec_script('test')
    return


# Generated at 2022-06-24 19:02:16.496595
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper")
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper_ssl")
    p_s_module_dep_finder_0.scan_exec_script("json_compat")
    p_s_module_dep_finder_0.scan_exec_script("pwsh_compat")
    p_s_module_dep_finder_0.scan_exec_script("winrm_compat")


# Generated at 2022-06-24 19:02:22.178449
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    m = PSModuleDepFinder()
    m.scan_module(pkgutil.get_data("ansible.module_utils.powershell", to_native("basic.psm1")))
    assert len(m.ps_modules) == 3
    assert 'Ansible.ModuleUtils.Basic' in m.ps_modules
    assert 'Ansible.ModuleUtils.PoshRSJob' in m.ps_modules
    assert 'Ansible.ModuleUtils.CommonCmdlets' in m.ps_modules


# Generated at 2022-06-24 19:02:27.683132
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script("posix_wrapped_exec_script")
    assert "posix_wrapped_exec_script" in f.exec_scripts
    assert os.path.normpath("Ansible.ModuleUtils.NetApp.Ansible.ModuleUtils.NetApp.ElementsWbem.Ansible.ModuleUtils.NetApp.ElementsWbem.Module") == os.path.normpath(resource_from_fqcr(f.ps_modules["ansible_collections.netapp.netapp.plugins.modules.na_elementswf_client.Ansible.ModuleUtils.NetApp.ElementsWbem"]['path']))


# Generated at 2022-06-24 19:02:33.310091
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script(to_text("posix"))

    assert(p_s_module_dep_finder_0.exec_scripts.keys() == {to_text("posix")})


# Generated at 2022-06-24 19:02:39.908747
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Create a fake powershell script to test scanning of
    # This is to test that when a file is not found we error correctly
    try:
        p_s_module_dep_finder_0.scan_exec_script(b"fakefile.ps1")
    except AnsibleError as e:
        assert e.message == "Could not find executor powershell script for 'fakefile.ps1'"


# Generated at 2022-06-24 19:02:41.475038
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert p_s_module_dep_finder_0.scan_exec_script("foo") == None


# Generated at 2022-06-24 19:02:42.912596
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()


# Generated at 2022-06-24 19:02:59.560417
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    mock_name_0 = 'str'

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    assert p_s_module_dep_finder_0.scan_exec_script(mock_name_0) == None


# Generated at 2022-06-24 19:03:04.994601
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = "example"
    fqn_0 = "example"
    wrapper_0 = False
    powershell_0 = True
    return_value_0 = p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)
    assert return_value_0 == None, "Expected return value to be None."


# Generated at 2022-06-24 19:03:05.877879
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False



# Generated at 2022-06-24 19:03:12.775283
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test parameters
    dummy_PSModuleDepFinder = PSModuleDepFinder()
    dummy_PSModuleDepFinder.ps_modules = dict()
    dummy_PSModuleDepFinder.cs_utils_wrapper = dict()
    dummy_PSModuleDepFinder.ps_version = None
    dummy_PSModuleDepFinder.os_version = None
    dummy_PSModuleDepFinder.become = False
    test_name = "Connect"
    dummy_PSModuleDepFinder.exec_scripts = dict()
    # Expected result
    expected = None

    # Test execution
    dummy_PSModuleDepFinder.scan_exec_script(test_name)

    # Test final result
    actual = dummy_PSModuleDepFinder.exec_scripts.keys()
    expected = ["Connect", "run_command"]
    assert actual

# Generated at 2022-06-24 19:03:21.439082
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # From the ansible source tree
    fqn = 'ansible_collections.ansible.builtin.win_ping'
    resource = resource_from_fqcr(fqn, 'module')
    data = to_bytes(resource.read())
    p_s_module_dep_finder_0.scan_module(data, fqn)

    # Assertions
    # CS utils
    assert to_text('ansible_collections.ansible.builtin.plugins.module_utils.ansible_module_common') in p_s_module_dep_finder_0.cs_utils_module

# Generated at 2022-06-24 19:03:25.303992
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = "anyString"
    p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 19:03:28.886625
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script('_text')
    except Exception as err:
        print(str(err))


# Generated at 2022-06-24 19:03:39.824876
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = base64.b64decode('IyBBbnNpYmxlUmVxdWlyZXMgLSBQb3dlclNoZWxsIEFuc2libGUu'
                                     'TW9kdWxlVXRpbHMuc3RyaW5nCicnIHN0cmluZyMgRmlyc3RMaW5lIG'
                                     'FyZSBkZWxpbWl0ZXJzCiMgQW5zaWJsZVJlcXVpcmVzIC1Qb3dlclN'
                                     'oZWxsIEFuc2libGUuTW9kdWxlVXRpbHMuYWN0aW9u')
    p_s_module_dep_finder_0 = PSModule

# Generated at 2022-06-24 19:03:44.670420
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name_0 = "Invoke-Test"
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:03:49.567913
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Run un-parameterized test case
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name_0 = "test_module"
    p_s_module_dep_finder_0.scan_exec_script(n_name_0)


# Generated at 2022-06-24 19:04:11.997081
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        p_s_module_dep_finder_1 = PSModuleDepFinder()
    except NameError:
        p_s_module_dep_finder_1 = PSModuleDepFinder()

    try:
        p_s_module_dep_finder_2 = PSModuleDepFinder()
    except NameError:
        p_s_module_dep_finder_2 = PSModuleDepFinder()

    try:
        p_s_module_dep_finder_3 = PSModuleDepFinder()
    except NameError:
        p_s_module_dep_finder_3 = PSModuleDepFinder()

    try:
        ansible_collections_test_collection_test_plugins_module_utils_test_module_1 = PSModuleDepFinder()
    except NameError:
        ansible_collections_

# Generated at 2022-06-24 19:04:17.449947
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('dummy-1')


# Generated at 2022-06-24 19:04:19.789600
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Put test here
    assert True


# Generated at 2022-06-24 19:04:26.545632
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = '#Requires -Module Ansible.ModuleUtils.Legacy'
    fqn = 'Ansible.ModuleUtils.Legacy'
    extension = '.psm1'
    wrapper = False
    powershell = True
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(module_data, fqn, wrapper, powershell)
    # Check returned value
    #assert p_s_module_dep_finder_1.ps_modules ==
    # Check if all of the code paths are tested
    # TODO: Add some asserts here


# Generated at 2022-06-24 19:04:32.129363
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = b''
    p_s_module_dep_finder.scan_exec_script(name)


# Generated at 2022-06-24 19:04:42.085797
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # test_PSModuleDepFinder_scan_exec_script_0
    p_s_module_dep_finder_0.scan_exec_script("powershell_base")
    # test_PSModuleDepFinder_scan_exec_script_1
    p_s_module_dep_finder_0.scan_exec_script("powershell_base")
    # test_PSModuleDepFinder_scan_exec_script_2
    p_s_module_dep_finder_0.scan_exec_script("powershell_base")
    # test_PSModuleDepFinder_scan_exec_script_3
    p_s_module_dep_finder_0.scan_exec_script("powershell_base")
    # test_PSModuleDep

# Generated at 2022-06-24 19:04:49.764646
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Load test case data from files
    this_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_path = os.path.join(this_dir, "test_cases", "test_PSModuleDepFinder_scan_exec_script")


# Generated at 2022-06-24 19:04:50.914613
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()


# Generated at 2022-06-24 19:04:52.932316
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"")


# Generated at 2022-06-24 19:04:58.940696
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = None
    fqn_0 = None
    wrapper_0 = None
    powershell_0 = None
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 19:05:14.030049
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.x'
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:05:16.461900
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("Common")


# Generated at 2022-06-24 19:05:22.795765
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = base64.b64decode(_DATA_0)
    fqn = r'ansible-collections.testing.test.plugins.modules.test_module'
    wrapper = False
    powershell = True
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-24 19:05:32.775136
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Starting test test_PSModuleDepFinder_scan_module")
    if __name__ != '__main__':
        module_data = pkgutil.get_data(__package__, 'module_utils/network/cloudengine/ce.psm1')
    else:
        with open("./tests/module_utils/network/cloudengine/ce.psm1", "r") as f:
            module_data = f.read()
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    return_value = p_s_module_dep_finder_0.scan_module(module_data)
    return_value_expected = None
    assert return_value == return_value_expected, 'Expected {}, but got {}'.format(return_value_expected, return_value)
    print

# Generated at 2022-06-24 19:05:33.900844
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()



# Generated at 2022-06-24 19:05:39.583126
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # FIXME: this is a very weak test, it only checks that the method
    # actually returns
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("test")
    except (AnsibleError, ImportError):
        pass
    except Exception:
        raise


# Generated at 2022-06-24 19:05:43.953346
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common')

    assert('Ansible.ModuleUtils.Common' in p_s_module_dep_finder_0.ps_modules)


# Generated at 2022-06-24 19:05:50.139524
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:05:55.413509
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    command_text = p_s_module_dep_finder_0.scan_exec_script(name="file_info")
    assert p_s_module_dep_finder_0.exec_scripts["file_info"] is not None


# Generated at 2022-06-24 19:05:58.245180
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = b''
    p_s_module_dep_finder_0.scan_module(module_data)


# Generated at 2022-06-24 19:06:27.135505
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Network.CloudEngine'
    f_qn_0 = None
    p_s_module_dep_finder_0.scan_module( module_data_0, f_qn_0 )
    assert p_s_module_dep_finder_0.cs_utils_wrapper == {}

# Generated at 2022-06-24 19:06:35.833095
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # !!!!! str object has no attribute encode
    # module_data = str.encode()
    # !!!!! object has no attribute split
    # lines = module_data.split()
    module_utils = set()
    # !!!!! object has no attribute keys
    # cs_utils = self.cs_utils_wrapper.keys()
    # !!!!! object has no attribute keys
    # cs_utils = self.cs_utils_module.keys()
    p_s_module_dep_finder_0.scan_module(module_utils)


# Generated at 2022-06-24 19:06:41.886668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    name = "invoke_dummy_wrapper.ps1"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:06:50.197361
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:06:52.732002
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn_0 = "test_0.test_0"
    data_0 = "import lib1\n"
    p_s_module_dep_finder_0.scan_module(data_0, fqn_0)
