

# Generated at 2022-06-24 18:57:18.870483
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0 is not None

    module_data_0 = _slurp(resource_from_fqcr("ansible_collections.foo.bar.plugins.powershell.get_info.psm1"))
    assert module_data_0 is not None

    p_s_module_dep_finder_0.scan_module(module_data_0)
    assert len(p_s_module_dep_finder_0.ps_modules) == 1


# Generated at 2022-06-24 18:57:22.402257
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script('script-name-0')
    except Exception as err:
        print(err)


# Generated at 2022-06-24 18:57:25.974045
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script('test')


# Generated at 2022-06-24 18:57:30.293557
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Write your code here to test the case
    # TODO: Fix this test
    # ps_module_dep_finder_0.scan_exec_script('module_args_ansible_collection_json_encoder_json_mixin___init__')
    pass


# Generated at 2022-06-24 18:57:37.454642
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test #0
    # fqn = None
    # wrapper = None
    # powershell = None
    module_data = None
    # p_s_module_dep_finder_0.scan_module(module_data)



# Generated at 2022-06-24 18:57:49.486778
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Run test case with the following inputs
    p_s_module_dep_finder_4 = PSModuleDepFinder()

# Generated at 2022-06-24 18:57:54.023317
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Init of PSModuleDepFinder class
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # p_s_module_dep_finder_0.scan_exec_script('', '0.0')
    p_s_module_dep_finder_0.scan_exec_script('Ansible.ModuleUtils.CommonUtils')


# Generated at 2022-06-24 18:57:56.208899
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # this should throw an exception since script doesn't exist
    try:
        test_case_0()
    except (AnsibleError, ImportError):
        assert True



# Generated at 2022-06-24 18:58:01.091180
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "test_str"

    # Test case 0
    ps_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:01.978948
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case_0()



# Generated at 2022-06-24 18:58:24.382152
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        if 'exec_scripts' not in dir(p_s_module_dep_finder_0):
            print('method scan_exec_script was not found in the class')
            print('FAIL')
            return
    except:
        print('class PSModuleDepFinder is not defined')
        print('FAIL')
        return

# Generated at 2022-06-24 18:58:26.048311
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('')


# Generated at 2022-06-24 18:58:28.692949
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("[*] Running test_PSModuleDepFinder_scan_exec_script...")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "executor"

    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:36.070754
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    args = (to_bytes(random.choice(["Script1", "Script2", "Script3"]), errors='surrogate_or_strict'), )
    # No exception should be thrown
    p_s_module_dep_finder_1.scan_exec_script(*args)


# Generated at 2022-06-24 18:58:45.364360
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case: Find script and scan for dependencies
    # Assertion: The script is found and scan_module is called.
    # Verify: The script is found and scan_module is called.
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_name_0 = to_bytes("TestExecScript")
    p_s_module_dep_finder_0.scan_exec_script(test_name_0)
    assert p_s_module_dep_finder_0.exec_scripts[test_name_0] is not None


# Generated at 2022-06-24 18:58:46.658637
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    id = 1
    # TODO: Some test cases are written in this method.




# Generated at 2022-06-24 18:58:58.024228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    exec_script_content = """#!/usr/bin/env ansible-test
#
# Description: test code.
#
# usage: script [-h|--help]
#
#
# Requires -Copyright "Copyright (c) 2016 Ansible Project"
# Requires -Version 3.2
# Requires -Modules psake
#
# Copyright (c) 2016 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# Issue the command to run the psake script
$PSCommand = "Invoke-psake Build.ps1"
Invoke-Expression $PSCommand
"""
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_

# Generated at 2022-06-24 18:59:03.358401
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Just verify we don't hit any exceptions in scan_exec_script
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("core")
    p_s_module_dep_finder_1.scan_exec_script("data_structures")
    p_s_module_dep_finder_1.scan_exec_script("executor")
    p_s_module_dep_finder_1.scan_exec_script("json")


# Generated at 2022-06-24 18:59:06.596445
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_module = import_module("ansible_collections.notmintest.not_a_real_collection.plugins.modules.win_mapped_drive")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("win_mapped_drive")


# Generated at 2022-06-24 18:59:10.040383
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    r = random.random()
    if (r < 0.5):
        ret = p_s_module_dep_finder.scan_exec_script("xxx")  # RandomStr
    else:
        ret = p_s_module_dep_finder.scan_exec_script("xxx")  # RandomStr


# Generated at 2022-06-24 18:59:34.054152
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    fd, path = tempfile.mkstemp(prefix="module", suffix=".ps1")
    _f = os.fdopen(fd, "w+")
    _f.write("#requires -version 5.1\n")
    _f.write("#ansiblerequires -wrapper get-content\n")
    _f.write("#ansiblerequires -wrapper joe\n")
    _f.write("#ansiblerequires -wrapper joe2\n")
    _f.write("#ansiblerequires -csharputil ansible_collections.microsoft.windows.plugins.module_utils.powershell.netconnection\n")

# Generated at 2022-06-24 18:59:40.850520
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    
    # Create object for PSModuleDepFinder()
    # Create variable fqn of type str with value 'hello.world'
    fqn = 'hello.world'

    # Call function scan_module of p_s_module_dep_finder_0, with args: module_data, fqn=fqn, wrapper=False, powershell=True
    # Call function scan_module of p_s_module_dep_finder_0, with args: module_data, fqn=fqn, wrapper=False, powershell=False
    # Call function scan_module of p_s_module_dep_finder_0, with args: module_data, fqn=fqn, wrapper=True, powershell=True


# Generated at 2022-06-24 18:59:46.445217
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = '#Requires -Module Ansible.ModuleUtils.Powershell'
    fqn_0 = 'ansible_collections.my.my_collection'
    wrapper_0 = False
    powershell_0 = False
    expected_0 = None
    assert expected_0 == p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 18:59:51.100629
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    from ansible.plugins.action.synchronize import ActionModule

    sync_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    fqcr = 'ansible.builtin.synchronize'
    module_data = resource_from_fqcr(sync_module._shared_loader_obj, fqcr).data
    p_s_module_dep_finder.scan_module(module_data, fqn='ansible.builtin.synchronize')

    assert 'Ansible.ModuleUtils.Powershell.Clone' in p_s_module_dep_finder.ps

# Generated at 2022-06-24 18:59:54.952129
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('win_xml')


# Generated at 2022-06-24 18:59:58.911243
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = to_bytes(base64.b64decode(''))
    fqn_0 = 'ansible_collections.ns.coll.plugins.modules.yum'
    PSModuleDepFinder.scan_module(fqn_0, module_data_0)


# Generated at 2022-06-24 19:00:08.332207
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil
    import codecs
    test_dir = tempfile.mkdtemp()

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fd, n_path = tempfile.mkstemp(prefix='psm0_', suffix='.ps1', dir=test_dir)

# Generated at 2022-06-24 19:00:18.816265
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # The following code will raise an exception.
    with pytest.raises(AnsibleError) as excinfo:
        p_s_module_dep_finder_scan_module_0 = p_s_module_dep_finder_0.scan_module([b'sample_bytes'])
    assert 'Could not find imported module support code for \'Ansible.ModuleUtils.Powershell.Data\'' in to_native(excinfo.value.message)


# Generated at 2022-06-24 19:00:20.732205
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("ansible_managed")


# Generated at 2022-06-24 19:00:27.424511
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = b''
    fqn_1 = None
    wrapper_1 = False
    powershell_1 = True
    ret_val_1 = p_s_module_dep_finder_1.scan_module(module_data_1, fqn_1, wrapper_1, powershell_1)
    assert ret_val_1 is None


# Generated at 2022-06-24 19:00:47.573841
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    n_name_0 = "Test"
    try:
        arg_0 = n_name_0
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        p_s_module_dep_finder_0.scan_exec_script(arg_0)
        return True
    except:
        return False


# Generated at 2022-06-24 19:00:54.340683
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  p_s_module_dep_finder_0 = PSModuleDepFinder()
  p_s_module_dep_finder_0.scan_module("test_string_0")


# Generated at 2022-06-24 19:00:58.094917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    result = p_s_module_dep_finder_0.scan_exec_script("exec.ps1")
    assert result is None

    result = p_s_module_dep_finder_0.scan_exec_script("exec.ps1")
    assert result is None


# Generated at 2022-06-24 19:01:09.041551
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Get the value of a const
    C_DEFAULT_DEBUG_0 = C.DEFAULT_DEBUG

    # Get the content of a file
    path_0 = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../executor/powershell/pswrap.ps1')
    p_swrap_ps1_0 = _slurp(path_0)

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Call the method with a basic argument
    p_s_module_dep_finder_0.scan_exec_script('pswrap')

    # Verify the result
    if p_s_module_dep_finder_0.exec_scripts['pswrap'] != p_swrap_ps1_0:
        raise Assertion

# Generated at 2022-06-24 19:01:15.061048
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = random.randint(-100, 100)
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:01:18.390924
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class_0 = PSModuleDepFinder()
    class_0.scan_module({})


# Generated at 2022-06-24 19:01:22.604692
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ps_compat')

# Generated at 2022-06-24 19:01:31.664054
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fqn_n = "/path/to/collection/namespace/coll/module.psm1"
    fqn_o = "/path/to/collection/othernamespace/coll/module.psm1"
    fqn_p = "/path/to/othercollection/namespace/coll/module.psm1"
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'\n    #Requires -Module Ansible.ModuleUtils.ExtraModule\n'
    module_data_1 = b'\n    #AnsibleRequires -Powershell Ansible.ModuleUtils.ExtraModule\n'

# Generated at 2022-06-24 19:01:39.814340
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ansible_collections = {
        'ns0.coll0': ['module_utils/basic.psm1', 'plugins/modules/basic_module.ps1'],
        'ns1.coll1': ['plugins/modules/basic_module_1.ps1']
    }

    # Populate module_utils
    for collection, files in ansible_collections.items():
        for f in files:
            if f.startswith('module_utils'):
                fqcr = '%s.%s' % (collection, f.replace("/", "."))
                module_util_name = fqcr.replace("module_utils.", "")
                module_util_path = resource_from_fqcr(fqcr)
                module_util_data = _slurp(module_util_path)
                module

# Generated at 2022-06-24 19:01:43.495771
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("script_0")


# Generated at 2022-06-24 19:02:00.486947
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("my_exec_script")


# Generated at 2022-06-24 19:02:09.006489
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Initialize instance of our class
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    
    # Check that docstring is preserved, needed for coverage

# Generated at 2022-06-24 19:02:13.813450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "gather-facts"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:02:21.135863
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = "some data"
    fqn = "ps_module_0"
    wrapper = False
    powershell = True
    return_value_0 = p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)
    assert return_value_0 is None


# Generated at 2022-06-24 19:02:26.081974
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('script')


# Generated at 2022-06-24 19:02:28.754763
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('FooBar')


# Generated at 2022-06-24 19:02:34.644778
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_0 = b'#Requires -Module Ansible.ModuleUtils.PowerShell\nNew-ADComputer'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    retval_0 = p_s_module_dep_finder_0.scan_module(test_module_0)
    expected_0 = None
    assert retval_0 == expected_0


# Generated at 2022-06-24 19:02:43.014268
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 19:02:45.692598
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name = to_bytes('posix')
    p_s_module_dep_finder_0.scan_exec_script(n_name)


# Generated at 2022-06-24 19:02:56.444894
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # init
    p_s_module_dep_finde_0 = PSModuleDepFinder()
    # set up parameters
    module_data_0 = "PowerShell module here"
    fqn_0 = "Fully Qualified Collection Name"
    ps_module_data_0 = "PowerShell module stuff"
    ps_module_data_1 = ".cs module stuff"
    cs_module_data_0 = ".cs module stuff"
    cs_module_data_1 = ".psm1 module stuff"
    ps_module_data_2 = "stuff"
    ps_module_data_3 = "stuff"
    ps_module_data_4 = "stuff"
    # test
    p_s_module_dep_finde_0.scan_module(module_data_0, fqn_0)
   

# Generated at 2022-06-24 19:03:14.901524
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_exec_script("ansible")
    except AnsibleError as e:
        print(e)
        rc = 1
    else:
        rc = 0
    assert rc == 0


# Generated at 2022-06-24 19:03:21.050131
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script("invalid-module") == None


# Generated at 2022-06-24 19:03:27.060646
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("ping")
    assert p_s_module_dep_finder_0.exec_scripts["ping"] is not None, "Failed to scan script ping"


# Generated at 2022-06-24 19:03:35.009986
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # test case 0
    try:
        p_s_module_dep_finder_0.scan_exec_script('does_not_exist')
    except AnsibleError as e:
        assert e.message == "Could not find executor powershell script for 'does_not_exist'"
    else:
        assert False, "expected error"

    p_s_module_dep_finder_0.scan_exec_script('exec_wrapper')
    assert p_s_module_dep_finder_0.exec_scripts == {'exec_wrapper': b'#ArgumentList -ArgumentList $it\r\n', 'async_wrapper': b'$arguments += "& {}"'}

# Generated at 2022-06-24 19:03:39.338195
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test case 1
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # invalid input
    assert p_s_module_dep_finder_1.scan_exec_script('test_case_1') == None


# Generated at 2022-06-24 19:03:44.221942
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if test_PSModuleDepFinder_scan_exec_script.__name__ == '__main__':
        p_s_module_dep_finder_1 = PSModuleDepFinder()
        test_filepath_0 = 'testfile'


# Generated at 2022-06-24 19:03:50.935156
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder = PSModuleDepFinder()
        p_s_module_dep_finder.scan_exec_script('CommandUtil')
        assert len(p_s_module_dep_finder.exec_scripts) > 0
    except Exception as e:
        print(e)
        raise Exception('Unit test failure')


# Generated at 2022-06-24 19:03:55.933693
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Parameters
    p_name = "example"
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Actual call to the method
    p_s_module_dep_finder_1.scan_exec_script(p_name)


# Generated at 2022-06-24 19:03:58.593368
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script(u'_json') == None


# Generated at 2022-06-24 19:04:04.164490
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    script_name = string_random(7)

    try:
        result = p_s_module_dep_finder_0.scan_exec_script(script_name)
    except AnsibleError as e:
        print('Could not find executor powershell script for \'' + script_name + '\'')
        pass


# Generated at 2022-06-24 19:04:44.766503
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # p_s_module_dep_finder_0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # module_data_0
    module_data_0 = to_bytes("""
    #AnsibleRequires -PowerShell 5.1
    #AnsibleRequires -CSharpUtil Ansible.ModuleUtils.PowerShell.Software.Utils
    """)
    # fqn_0
    fqn_0 = to_text("Ansible.ModuleUtils.PowerShell.Software.ProgramData")
    # wrapper_0
    wrapper_0 = False
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0)

    # p_s_module_dep_finder_1
    p_s

# Generated at 2022-06-24 19:04:48.462187
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of class PSModuleDepFinder to test method scan_exec_script
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    
    # Test method scan_exec_script of class PSModuleDepFinder with a valid value
    p_s_module_dep_finder_0.scan_exec_script("0")



# Generated at 2022-06-24 19:04:53.016069
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # p_s_module_dep_finder_0 obj was created using the constructor
    # PSModuleDepFinder()
    assert isinstance(p_s_module_dep_finder_0.scan_exec_script(name_0), NoneType)


# Generated at 2022-06-24 19:04:57.808238
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('rand_id')
    p_s_module_dep_finder_0.scan_exec_script('powershell.ps1')


# Generated at 2022-06-24 19:05:00.547446
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name="find_powershell_modules")


# Generated at 2022-06-24 19:05:03.489022
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_package_module")
    assert 'ansible.module_utils.ansible_release' in dep_finder.ps_modules


# Generated at 2022-06-24 19:05:06.602651
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("env")


# Generated at 2022-06-24 19:05:14.249642
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    with open("test/ansible_collections/ns1/coll1/powershell/plugins/_test/module_utils/test_module_utils.psm1", "rb") as file_data_0:
        test_data_0 = file_data_0.read()

    p_s_module_dep_finder_0.scan_module(test_data_0)

    test_data_1 = b"#Requires -Module Ansible.ModuleUtils.TestDependency"

    p_s_module_dep_finder_0.scan_module(test_data_1)

    assert len(p_s_module_dep_finder_0.ps_modules) == 1


# Generated at 2022-06-24 19:05:22.120880
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # The script referenced by the name argument is not guaranteed to be returned as the tests may not be run in the same
    # environment as the called method.
    name = "test_case_test_PSModuleDepFinder_scan_exec_script_0"
    name = to_text(name)
    p_s_module_dep_finder_0.scan_exec_script(name)
    assert name in p_s_module_dep_finder_0.exec_scripts.keys()


# Generated at 2022-06-24 19:05:26.697123
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Init the class
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test the method
    # TODO: Test the method without passing a specific name.
    val = p_s_module_dep_finder_0.scan_exec_script("Pwd")


# Generated at 2022-06-24 19:06:47.940959
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_cases = []
    lines = []
    lines.append(('#Requires -Module Ansible.ModuleUtils.MyUtil1', 'Ansible.ModuleUtils.MyUtil1'))
    lines.append(('#AnsibleRequires -PowerShell Ansible.ModuleUtils.MyUtil2', 'Ansible.ModuleUtils.MyUtil2'))
    lines.append(('#AnsibleRequires -PowerShell ansible_collections.Foo.Bar.plugins.module_utils.MyUtil3', 'ansible_collections.Foo.Bar.plugins.module_utils.MyUtil3'))