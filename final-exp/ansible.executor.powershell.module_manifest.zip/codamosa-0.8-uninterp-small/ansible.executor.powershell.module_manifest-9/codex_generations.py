

# Generated at 2022-06-24 18:57:30.641245
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    f_s_module_data_0 = "ansible-powershell-shell-0"
    p_s_module_dep_finder_0.scan_exec_script(f_s_module_data_0)

# Generated at 2022-06-24 18:57:32.748450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('Microsoft.PowerShell.Utility')


# Generated at 2022-06-24 18:57:36.720982
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_name = 'some_module_name'
    p_s_module_dep_finder_0.scan_exec_script(module_name)


# Generated at 2022-06-24 18:57:40.682543
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0: PSModuleDepFinder = PSModuleDepFinder()
    module_data: str = "module_data"
    fqn: str = "fqn"
    wrapper: bool = False
    powershell: bool = True
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-24 18:57:45.749547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell import _powershell_from_path as _powershell_from_path_0_0
    from ansible.module_utils.powershell import _from_ps1_to_psm1 as _from_ps1_to_psm1_0_0

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("null")
    except AnsibleError:
        pass
    c_s_1_0 = len(p_s_module_dep_finder_0.exec_scripts)
    c_s_1_1 = len(p_s_module_dep_finder_0.cs_utils_wrapper)
    c_s_1_2 = _powershell_

# Generated at 2022-06-24 18:57:48.811524
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_0 = "powershell_runner"
    p_s_module_dep_finder_1.scan_exec_script(name_0)


# Generated at 2022-06-24 18:57:53.353610
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("ansible_module_generated")


# Generated at 2022-06-24 18:57:55.447246
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('')


# Generated at 2022-06-24 18:58:00.635742
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('test_case')


# Generated at 2022-06-24 18:58:05.806999
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes, to_native
    finder = PSModuleDepFinder()

    # remove the exec script for testing
    if os.path.isfile(os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_test_exec_script.ps1")):
        os.unlink(os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_test_exec_script.ps1"))

    # create a test file
    test_data_b = to_bytes("#AnsibleRequires -Wrapper TestWrapper\r\n")


# Generated at 2022-06-24 18:58:40.904400
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test raise exception
    with pytest.raises(AnsibleError) as err:
        p_s_module_dep_finder_0.scan_exec_script(None)
        assert str(err) == "Could not find executor powershell script for 'None'"

    # Test raise exception
    with pytest.raises(AnsibleError) as err:
        p_s_module_dep_finder_0.scan_exec_script('')
        assert str(err) == "Could not find executor powershell script for ''"


# Generated at 2022-06-24 18:58:49.794218
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    assert p_s_module_dep_finder_0.exec_scripts.get('./json_serializer.ps1') is None, \
           "PSModuleDepFinder didn't return expected value for scan_exec_script()"

    p_s_module_dep_finder_0.scan_exec_script('./json_serializer.ps1')

    assert p_s_module_dep_finder_0.exec_scripts.get('./json_serializer.ps1') is not None, \
           "PSModuleDepFinder didn't return expected value for scan_exec_script()"


# Generated at 2022-06-24 18:58:51.163386
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()


# Generated at 2022-06-24 18:59:01.249429
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with 0 args
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # noinspection PyUnusedLocal
    test_data_0 = p_s_module_dep_finder_0.ps_modules
    # noinspection PyUnusedLocal
    test_data_1 = p_s_module_dep_finder_0.exec_scripts
    # noinspection PyUnusedLocal
    test_data_2 = p_s_module_dep_finder_0.ps_version
    # noinspection PyUnusedLocal
    test_data_3 = p_s_module_dep_finder_0.become
    # noinspection PyUnusedLocal
    test_data_4 = p_s_module_dep_finder_0.os_version
    test_data_5 = p

# Generated at 2022-06-24 18:59:05.773387
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test fixture 0: standard case
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "executor"
    p_s_module_dep_finder_0.scan_exec_script(name_0)



# Generated at 2022-06-24 18:59:11.850251
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Resetting global variables to ensure test stability
    PSModuleDepFinder.exec_scripts = dict()
    PSModuleDepFinder.cs_utils_wrapper = dict()
    PSModuleDepFinder.ps_version = None
    PSModuleDepFinder.os_version = None
    PSModuleDepFinder.become = False

    # Defining module_data to be tested

# Generated at 2022-06-24 18:59:16.554107
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('base')


# Generated at 2022-06-24 18:59:27.065780
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test when name is in self.exec_scripts
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.exec_scripts = {
        "ModuleName": b"ModuleData"
    }
    assert p_s_module_dep_finder_1.scan_exec_script("ModuleName") == None
    assert p_s_module_dep_finder_1.exec_scripts == {
        "ModuleName": b"ModuleData"
    }
    # Test when pkgutil.get_data doesn't find pkg_data
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    p_s_module_dep_finder_2.exec_scripts = {}
    p_s_module_dep_finder_2.scan_

# Generated at 2022-06-24 18:59:29.020696
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    assert True


# Generated at 2022-06-24 18:59:31.832564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data_0 = pkgutil.get_data("ansible.executor.powershell", "script0.ps1")
    f_2 = to_bytes(data_0)
    assert f_2.__class__ == bytes
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("script0")


# Generated at 2022-06-24 19:00:34.977823
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiate the class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call the method scan_exec_script of class PSModuleDepFinder
    result = p_s_module_dep_finder_0.scan_exec_script('_ansible_common')
    assert result is None
    p_s_module_dep_finder_0.scan_exec_script('_ansible_main')
    assert result is None


# Generated at 2022-06-24 19:00:44.390762
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Generate random number between 9 ~ 99
    # Then, convert the number to string
    random_number_1 = str(random.randint(9, 99))
    random_number_2 = str(random.randint(9, 99))
    test_module_1 = to_bytes("Ansible." + random_number_1 + "." + random_number_2)
    test_module_2 = to_bytes("Ansible." + random_number_1 + ".module.plugin")
    module_data_1 = to_bytes("#AnsibleRequires -CSharpUtil " + test_module_1)
    module_data_2 = to_bytes("#AnsibleRequires -CSharpUtil " + test_module_2)
    p_s_module_dep_finder_1 = PSModuleDepFinder()


# Generated at 2022-06-24 19:00:49.398817
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("pwshCompatibility")


# Generated at 2022-06-24 19:00:56.644914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_cases = [
        ("", ""),
    ]
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    for t in test_cases:
        assert(isinstance(t[0], str))
        assert(isinstance(t[1], str))
        p_s_module_dep_finder_0.scan_exec_script(t[0], t[1])


# Generated at 2022-06-24 19:01:01.886473
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # valid input for p_s_module_dep_finder_0.scan_exec_script()

    p_s_module_dep_finder_0.scan_exec_script('')

    # invalid input for p_s_module_dep_finder_0.scan_exec_script()
    try:
        p_s_module_dep_finder_0.scan_exec_script('')
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:01:08.971152
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Make sure the ansible executor powershell dir exists
    if not pkgutil.exists('ansible.executor.powershell'):
        raise AssertionError("ansible executor powershell directory does not exist")

    # Create instance of PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call method scan_exec_script of PSModuleDepFinder
    # p_s_module_dep_finder_0.scan_exec_script("win_debug")


# Generated at 2022-06-24 19:01:12.161491
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    try:
        psmd.scan_exec_script("TEST_NOT_EXIST")
        assert False, "No exception is raised when invalid script name is given"
    except AnsibleError:
        assert True, "AnsibleError is raised when invalid script name is given"



# Generated at 2022-06-24 19:01:15.743212
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        test_case_0()
    except Exception as error:
        print("Error occurred: %s" % error)
    else:
        print("All tests passed")


# Generated at 2022-06-24 19:01:25.756912
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Executing test_PSModuleDepFinder_scan_module")
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_0 = p_s_module_dep_finder_1
    test_case_0()
    test_case_1(p_s_module_dep_finder_0)
    test_case_2(p_s_module_dep_finder_0)
    test_case_3(p_s_module_dep_finder_0)
    test_case_4(p_s_module_dep_finder_0)
    test_case_5(p_s_module_dep_finder_0)
    test_case_6(p_s_module_dep_finder_0)

# Generated at 2022-06-24 19:01:30.797128
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    b_module_name = to_bytes("TestModule")
    with ps_module_utils_loader.do_not_load():
        resource_from_fqcr(to_text("ansible.builtin.TestModule"))
        p_s_module_dep_finder_1.scan_module(b_module_name)


# Generated at 2022-06-24 19:02:29.174482
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 19:02:32.110705
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = b'1'
    result = p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:02:38.598731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Just testing that a file can be found inside lib/ansible/executor/powershell
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    result = p_s_module_dep_finder_0.scan_exec_script('basic')
    assert (result == None)
    assert (p_s_module_dep_finder_0.exec_scripts['basic'] != None)


# Generated at 2022-06-24 19:02:40.757429
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()


# Generated at 2022-06-24 19:02:45.086313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data0 = 'ansible.executor.powershell'
    name0 = 'Ansible.ModuleUtils.Aws'
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script(name0)


# Generated at 2022-06-24 19:02:50.994828
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('wrapper')


# Generated at 2022-06-24 19:02:56.320938
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Set args for test
    arg_0 = "text"
    arg_1 = None
    arg_2 = False
    arg_3 = True
    p_s_module_dep_finder_0.scan_module(arg_0, arg_1, arg_2, arg_3)


# Generated at 2022-06-24 19:03:00.138020
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Test
    p_s_module_dep_finder_1.scan_exec_script("powershell_script_1")

    return


# Generated at 2022-06-24 19:03:05.161336
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mock_name = random.randrange(1, 10)
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script(mock_name)
    except AnsibleError as err:
        assert err.message == "Could not find executor powershell script for '%s'" % mock_name
        return

    assert False, "AnsibleError not raised"


# Generated at 2022-06-24 19:03:07.407799
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'testname'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:04:08.948530
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # We will import the module util package to load the module_utils path.
    # We need a module_util that has no dependencies so we will use the
    # ansible_builtin 'Ansible.ModuleUtils.Legacy' util.
    ps_module_deps = import_module('Ansible.ModuleUtils.Legacy.Windows')
    ps_module_deps.scan_exec_script('basic')
    assert 1 == 1

# Generated at 2022-06-24 19:04:15.723422
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_p_s_module_0 = "AnsibleModule"
    with open(test_p_s_module_0, "r") as test_p_s_module_0_f:
        test_p_s_module_0_data = test_p_s_module_0_f.read()
    p_s_module_dep_finder_0.scan_module(data=test_p_s_module_0_data, fqn="Ansible.Test", wrapper=False, powershell=True)



# Generated at 2022-06-24 19:04:25.504193
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils import connection

    # New way of referencing a builtin and collection module_util
    # '#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}'
    # '#AnsibleRequires -PowerShell ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}'
    # '#AnsibleRequires -PowerShell ..module_utils.{name}'
    module_data_0 = '''
    #AnsibleRequires -PowerShell Ansible.ModuleUtils.Connection
    #AnsibleRequires -PowerShell ansible_collections.acme.example.plugins.module_utils.connection
    #AnsibleRequires -PowerShell ..ansible.module_utils.connection
    '''
    p_s_module_dep_finder_0 = PSModule

# Generated at 2022-06-24 19:04:29.047350
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    with open("ansible_mitogen_0.psm1") as module_data:
        p_s_module_dep_finder_1 = PSModuleDepFinder()
        p_s_module_dep_finder_1.scan_module(module_data.read())


# Generated at 2022-06-24 19:04:34.528146
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    capture_data = b"""
    # AnsibleRequired -Wrapper ansible_collections.somens.somemodule.plugins.module_utils.somescript

    """
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_module(capture_data, wrapper=True)
    p_s_module_dep_finder.scan_module(capture_data, wrapper=True)



# Generated at 2022-06-24 19:04:44.562057
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # single module
    p_s_module_dep_finder_1.scan_exec_script("json")
    assert p_s_module_dep_finder_1.exec_scripts["json"] is not None
    # multiple modules
    p_s_module_dep_finder_1.scan_exec_script("dict2items")
    assert p_s_module_dep_finder_1.exec_scripts["dict2items"] is not None
    assert p_s_module_dep_finder_1.exec_scripts["json"] is not None
    # test that scanning a module twice will not add another copy
    p_s_module_dep_finder_1.scan_exec_script("json")
    assert p_s_module_dep_finder_1

# Generated at 2022-06-24 19:04:47.794578
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(b'wrapper')
    p_s_module_dep_finder_0.scan_exec_script(b'identity')


# Generated at 2022-06-24 19:04:52.187362
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    util_name = "abc"
    p_s_module_dep_finder_0.scan_exec_script(util_name)


# Generated at 2022-06-24 19:05:02.197361
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fqn = 'my_ns.my_coll.my_plugin'

    # Test for module_data is not given and fqn is given
    try:
        PSModuleDepFinder().scan_module(None, fqn)
    except SystemExit as e:
        ex = e
    assert ex.code == 1

    # Test for module_data is not given, fqn is None and wrapper is given
    try:
        PSModuleDepFinder().scan_module(None, None, True)
    except SystemExit as e:
        ex = e
    assert ex.code == 1

    # Test for module_data is given and fqn is None
    try:
        PSModuleDepFinder().scan_module('any text', None)
    except SystemExit as e:
        ex = e

# Generated at 2022-06-24 19:05:11.566839
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    p_s_module_dep_finder = PSModuleDepFinder()

    # Test invoking scan_module with module_data=b'\n' and fqn=None and wrapper=False and powershell=True (Type: bool)
    p_s_module_dep_finder.scan_module(module_data=b'\n', fqn=None, wrapper=False, powershell=True)

    # Test invoking scan_module with module_data=b'\n' and fqn=None and wrapper=False and powershell=False (Type: bool)
    p_s_module_dep_finder.scan_module(module_data=b'\n', fqn=None, wrapper=False, powershell=False)

    # Test invoking scan_module with module_data=b

# Generated at 2022-06-24 19:06:10.817075
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn = "TestFqn"
    module_data = '#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test;'
    p_s_module_dep_finder_0.scan_module(module_data, fqn)
    assert "Ansible.ModuleUtils.Test" in p_s_module_dep_finder_0.ps_modules.keys()


# Generated at 2022-06-24 19:06:13.098003
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    set_module_0 = set()
    p_s_module_dep_finder_0.scan_module('string')


# Generated at 2022-06-24 19:06:23.324432
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_cases = [
        0,
    ]
    for case_id in test_cases:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        if case_id == 0:
            __exp_result = None
            __call_func = p_s_module_dep_finder_0.scan_exec_script
            __params = (
                "Microsoft.PowerShell.Management",
            )
        __result = __call_func(*__params)
        if __result != __exp_result:
            raise AssertionError('Received result {} instead of expected result {}'.format(__result, __exp_result))


# Generated at 2022-06-24 19:06:33.431029
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    
    #store.set('shell', '', 'ps3')
    p_s_module_dep_finder_0.scan_module(module_data=b'#Test module\n')
    assert p_s_module_dep_finder_0.exec_scripts == {}
    assert p_s_module_dep_finder_0.ps_modules == {}
    assert p_s_module_dep_finder_0.cs_utils_module == {}
    assert p_s_module_dep_finder_0.cs_utils_wrapper == {}
    assert p_s_module_dep_finder_0.ps_version is None
    assert p_s_module_dep_finder_0.os_version is None
    assert p_s_module_

# Generated at 2022-06-24 19:06:39.411891
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("minion.ps1")


# Generated at 2022-06-24 19:06:45.482457
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = ('''#Requires -Module Ansible.ModuleUtils.Basic
#Requires -Module Ansible.ModuleUtils.Network
#Requires -Module Ansible.ModuleUtils.Powershell
#Requires -Module Ansible.ModuleUtils.Url''')
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 19:06:50.519796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert p_s_module_dep_finder_0.ps_modules == {}

    p_s_module_dep_finder_0.scan_module(module_data_0, fqn=None, wrapper=False, powershell=True)

    assert p_s_module_dep_finder_0.ps_modules == {'Ansible.ModuleUtils.Test': {'data': module_data_1, 'path': path_1}}

