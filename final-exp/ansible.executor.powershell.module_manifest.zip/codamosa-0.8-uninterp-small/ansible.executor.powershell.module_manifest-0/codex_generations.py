

# Generated at 2022-06-24 18:57:25.199634
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case with no assertions
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:57:30.923594
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "win_command"
    # Test with p_s_module_dep_finder_0.exec_scripts (dictionary):
    if name_0 not in p_s_module_dep_finder_0.exec_scripts:
        p_s_module_dep_finder_0.exec_scripts[name_0] = b""
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:57:41.308443
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # unittest/Ansible/module_utils/powershell/module_dep_finder_test.py
    # Data from unittest/Ansible/module_utils/powershell/module_dep_finder_test.py
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test with an invalid C# type, it should be ignored since it's not imported
    # by the module
    p_s_module_dep_finder_0.scan_exec_script(to_text("csharp_example"))
    # Test with an invalid module, it should be ignored since it's not imported
    # by the module
    p_s_module_dep_finder_0.scan_exec_script(to_text("ps_example"))
    # Test with the base module_utils.basic import
    p_

# Generated at 2022-06-24 18:57:49.859033
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {}
    class AnsibleError:
        def __init__(self, message):
            self.message = message
    p_s_module_dep_finder_0.AnsibleError = AnsibleError
    p_s_module_dep_finder_0.wrapper = "executable"
    p_s_module_dep_finder_0.become = False
    p_s_module_dep_finder_0.scan_exec_script(p_s_module_dep_finder_0.wrapper)

# Generated at 2022-06-24 18:57:58.025469
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder = PSModuleDepFinder()
    # Test for a case where filename of the module is specified
    fqcr = "ansible.netcommon.a10"
    loader, mod_path, mod_desc = resource_from_fqcr(fqcr)
    module_data = to_bytes(_slurp(mod_path))
    p_s_module_dep_finder.scan_module(module_data)
    assert p_s_module_dep_finder.ps_modules['Ansible.NetCommon.Json']
    assert p_s_module_dep_finder.cs_utils_module['ansible_collections.ansible.netcommon.plugins.module_utils.a10.a10_delegation_rules']

    # Test for a case where filename of the module is not

# Generated at 2022-06-24 18:58:00.607450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = random.randint(1,9999)
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 18:58:10.823213
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn_0 = "ansible.builtin.archive"

# Generated at 2022-06-24 18:58:12.892339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Calling with an empty string
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("")


# Generated at 2022-06-24 18:58:21.495494
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Check if there is a exception when trying to load a non-existent script
    try:
        p_s_module_dep_finder_0.scan_exec_script("nonesense")
        raise AssertionError("AnsibleError was not raised")
    except AssertionError:
        raise
    except AnsibleError:
        pass

    # Check if the p_s_module_dep_finder_0._add_module private method is called
    # for each of the referenced scripts
    assert(p_s_module_dep_finder_0.exec_scripts.keys() == {"powershell_scripting_constants", "common_functions"})


# Generated at 2022-06-24 18:58:27.780569
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {}
    p_s_module_dep_finder_0.cs_utils_wrapper = {}
    p_s_module_dep_finder_0.cs_utils_module = {}
    p_s_module_dep_finder_0.become = False
    name = "ping"
    p_s_module_dep_finder_0.scan_exec_script(name)
    assert p_s_module_dep_finder_0.exec_scripts == {}
    assert p_s_module_dep_finder_0.cs_utils_wrapper == {}
    assert p_s_module_dep_finder_0.cs_utils_module == {}
    assert p_s_module

# Generated at 2022-06-24 18:59:14.846287
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('some_name')


# Generated at 2022-06-24 18:59:23.086055
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    n_name = string()
    p_s_module_dep_finder_1.scan_exec_script(n_name)


# Generated at 2022-06-24 18:59:29.925149
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    scan_module_0_path = resource_from_fqcr(u'ansible.builtin.get_url', u'module_utils', u'basic', u'_urlretrieve.py')
    fqn_0 = u'ansible.builtin.get_url'
    wrapper_0 = False
    powershell_0 = True

    scan_module_0_module_data = _slurp(scan_module_0_path)
    decode_0_return = base64.b64decode(scan_module_0_module_data)
    fqn_1 = u'ansible.builtin.get_url'
    wrapper_1 = False
    powershell_1 = True

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep

# Generated at 2022-06-24 18:59:37.734570
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # UNIT TEST SETUP
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # UNIT TEST START
    p_s_module_dep_finder_0.scan_exec_script("test_script")
    # UNIT TEST VALIDATION
    # validate that the wrapper script test_script was added to the exec scripts
    assert p_s_module_dep_finder_0.exec_scripts["test_script"] is not None
    p_s_module_dep_finder_0.scan_exec_script("test_script")
    assert p_s_module_dep_finder_0.exec_scripts["test_script"] is not None
    # UNIT TEST TEARDOWN


# Generated at 2022-06-24 18:59:41.174702
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder().scan_exec_script(name='Test Name')


# Generated at 2022-06-24 18:59:52.256242
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing for exception raised by scan_exec_script()
    # assertRaisesRegexp(exception_type, regexp)
    try:
        p_s_module_dep_finder_1 = PSModuleDepFinder()
        test_name = 'invalid-script'
        p_s_module_dep_finder_1.scan_exec_script(test_name)
    except AnsibleError as e:
        print(e)
        assert to_text(e).find('Could not find executor powershell script for \'invalid-script\'') != -1

    # Testing for no exception raised
    p_s_module_dep_finder_2 = PSModuleDepFinder()
    test_name = 'json_args'

# Generated at 2022-06-24 19:00:02.470549
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:00:05.998978
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # init
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # test
    p_s_module_dep_finder_1.scan_exec_script("windows_basic")


# Generated at 2022-06-24 19:00:09.075801
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('')


# Generated at 2022-06-24 19:00:12.797899
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("script_name")



# Generated at 2022-06-24 19:01:22.775181
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script((b'A'))


# Generated at 2022-06-24 19:01:26.839329
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case 0: run a powershell script that has no module_utils
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("script_no_module_utils")


# Generated at 2022-06-24 19:01:34.464697
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    assert p_s_module_dep_finder_0 is not None
    assert p_s_module_dep_finder_0.ps_modules is not None
    assert p_s_module_dep_finder_0.exec_scripts is not None
    assert p_s_module_dep_finder_0.cs_utils_wrapper is not None
    assert p_s_module_dep_finder_0.cs_utils_module is not None

    assert p_s_module_dep_finder_0.ps_version is None
    assert p_s_module_dep_finder_0.os_version is None
    assert not p_s_module_dep_finder_0.become

    name = 'test.name'

# Generated at 2022-06-24 19:01:45.957948
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("ansible.executor.powershell.ps_helper")
    assert len(p_s_module_dep_finder_1.exec_scripts) == 1
    assert len(p_s_module_dep_finder_1.ps_modules) == 1
    assert p_s_module_dep_finder_1.ps_modules.get("Ansible.ModuleUtils.ActiveDirectory")
    assert "Ansible.ModuleUtils.ActiveDirectory" in p_s_module_dep_finder_1.ps_modules.keys()
    assert p_s_module_dep_finder_0

# Generated at 2022-06-24 19:01:48.361338
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_exec_script("ansible.module_utils.basic") is None


# Generated at 2022-06-24 19:01:58.742523
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # wrap_hosts_file will be an object of class PSModuleDepFinder.
    wrap_hosts_file = PSModuleDepFinder()

    # To call the method //scan_exec_script of class PSModuleDepFinder
    wrap_hosts_file.scan_exec_script('async', 'async.ps1')

    # To call the method //scan_exec_script of class PSModuleDepFinder
    wrap_hosts_file.scan_exec_script('async')

    # To call the method //scan_exec_script of class PSModuleDepFinder
    wrap_hosts_file.scan_exec_script('async')




# Generated at 2022-06-24 19:02:04.845915
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'a_string'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:02:08.526681
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = 'ansible_collections.community.general.plugins.modules.win_chocolatey'
    p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 19:02:15.713906
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    script_name = 'hello_world'
    p_s_module_dep_finder_0.scan_exec_script(script_name)


# Generated at 2022-06-24 19:02:19.459635
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    assert p_s_module_dep_finder_1.scan_exec_script("foo") == None


# Generated at 2022-06-24 19:04:36.178875
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with open(os.path.join(C.ROOT_PATH, 'lib', 'ansible', 'modules', 'cloud', 'azure', 'azure_rm_publicipaddress_facts.ps1'), 'rb') as f:
        module_data = f.read()

    p_s_module_dep_finder_0.scan_module(module_data)

    with open(os.path.join(C.ROOT_PATH, 'lib', 'ansible', 'module_utils', 'powershell', 'cloud', 'azure', 'azure_rm_common.psm1'), 'rb') as f:
        module_data = f.read()

    p_s_module_dep_finder_0.scan_module(module_data)



# Generated at 2022-06-24 19:04:40.847575
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = 'ansible.module_utils.basic'

    # execute
    p_s_module_dep_finder_1.scan_exec_script(name)
    # verify
    # ensure there are no assert failures


# Generated at 2022-06-24 19:04:45.962162
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    h_u_m = resource_from_fqcr('ansible_collections.test.test_collection.plugins.modules.test_module')
    p_s_module_dep_finder_0.scan_module(to_bytes(pkgutil.get_data(h_u_m[0], h_u_m[1])))


# Generated at 2022-06-24 19:04:50.591245
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Replace argument module_data:
    module_data = 'module_data'

    # Replace optional argument fqn:
    fqn = None

    # Replace optional argument wrapper:
    wrapper = False

    # Replace optional argument powershell:
    powershell = True

    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-24 19:04:54.393675
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "test"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:05:03.607344
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Setup some mock data for the dependent module_utils
    def _mock_get_data(loader, module_name, resource_name, *args, **kwargs):
        return base64.b64encode(to_bytes("Hello %s %s" % (module_name, resource_name)))

    def _mock_find_plugin(module_name, resource_name):
        # Make it look like we did not find the plugin on purpose
        return None

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Mock get_data and find_plugin
    pkgutil.get_data = _mock_get_data
    ps_module_utils_loader.find_plugin = _mock_find_plugin

    # Call the method being tested
    p_s_module_dep_finder_0

# Generated at 2022-06-24 19:05:09.284950
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Uncomment these lines to run a specific test case
    # Test 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = to_text('test_name')
    test_value_0 = to_bytes('test_value')
    test_case_0_data = test_value_0
    test_case_0(name_0, test_case_0_data)


# Generated at 2022-06-24 19:05:13.520200
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'example.ps1'
    p_s_module_dep_finder_0.scan_exec_script(name_0)
    name_0 = 'example.ps1'
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:05:15.163290
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('test_script_0')


# Generated at 2022-06-24 19:05:25.691474
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test with more than one collection util