

# Generated at 2022-06-24 18:57:30.897448
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Randomness not seeded for unit tests.
    random.seed()
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    str_0 = "c8nbh"

    p_s_module_dep_finder_0.scan_exec_script(str_0)


# Generated at 2022-06-24 18:57:40.619469
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_filepath_0 = '../ansible_collections/azure/azcollection/plugins/modules/azure_rm_aks_facts.py'
    fqn_0 = 'ansible_collections.azure.azcollection.plugins.modules.azure_rm_aks_facts'
    with open(n_filepath_0, 'rb') as f_0:
        b_data_0 = f_0.read()
    p_s_module_dep_finder_0.scan_module(b_data_0, fqn_0, wrapper=False, powershell=True)


# Generated at 2022-06-24 18:57:49.701074
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    ansible_collections_namespace = "ansible_collections"
    ansible_collections_collection = "ansible_collections"
    ansible_collections_ansible_plugins_module_utils_module_utils = "ansible_collections.ansible_collections.ansible_plugins.module_utils.module_utils"
    ansible_collections_ansible_plugins_module_utils_module_utils_ps_module_utils = "ansible_collections.ansible_collections.ansible_plugins.module_utils.module_utils.ps_module_utils"

# Generated at 2022-06-24 18:57:52.686365
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    script = "test_script"
    p_s_module_dep_finder.scan_exec_script(script)


# Generated at 2022-06-24 18:57:58.475598
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = b'# Requires -Module Ansible.ModuleUtils.Utility'
    name = 'Ansible.ModuleUtils.Utility'
    ext = '.psm1'
    fqn = None
    optional = False
    wrapper = False

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0._add_module(name, ext, fqn, optional, wrapper)
    result = p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, True)
    assert result is None


# Generated at 2022-06-24 18:58:07.609525
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Assign parameter values
    module_data_0 = 'root/test_data/foo.psm1'

    # Call method
    try:
        p_s_module_dep_finder_0.scan_module(module_data_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 18:58:08.698223
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    global num_runs
    if num_runs == 0:
        test_case_0()
    num_runs += 1


# Generated at 2022-06-24 18:58:12.892885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected = u'''
    $AnsibleModule = [Ansible.Common.AnsibleModule]::new('''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(u'ansible_module_common')
    assert(expected in p_s_module_dep_finder_0.exec_scripts[u'ansible_module_common'])


# Generated at 2022-06-24 18:58:20.913148
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    model_dep_finder_0 = PSModuleDepFinder() 
    model_dep_finder_0.scan_module("using System.Management.Automation;\nusing System.Text.RegularExpressions;\n")


# Generated at 2022-06-24 18:58:23.711488
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    putil_name = "BasicPsUtil"
    p_s_module_dep_finder_0.scan_exec_script(putil_name)


# Generated at 2022-06-24 18:58:51.838785
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = '#AnsibleRequires -Powershell ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}'
    p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 18:58:58.148746
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    name = "test_name"
    try:
        p_s_module_dep_finder.scan_exec_script(name)
    except AnsibleError as e:
        if "Could not find executor powershell script" not in e.message:
            raise e
    p_s_module_dep_finder.scan_exec_script(name)



# Generated at 2022-06-24 18:59:03.548313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_module")

# Generated at 2022-06-24 18:59:08.723195
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 18:59:11.161660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: fix this test
    pass
    # p_s_module_dep_finder_0 = PSModuleDepFinder()
    # p_s_module_dep_finder_0.scan_exec_script("ps_invoke_executor_legacy")


# Generated at 2022-06-24 18:59:22.884335
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test when content is not found
    with open('temp_path', 'w') as temp_path:
        with pytest.raises(AnsibleError):
            p_s_module_dep_finder_0.scan_exec_script('temp_path')

    # Test when content is found
    with open('temp_path', 'w') as temp_path:
        temp_path.write('\n#Requires -Module Ansible.ModuleUtils.ansible.module_common\n')
    p_s_module_dep_finder_0.scan_exec_script('temp_path')
    assert p_s_module_dep_finder_0.exec_scripts['temp_path'] == b'\n\n'
    assert not p_

# Generated at 2022-06-24 18:59:29.803593
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    _exec_script_name_0 = 'test_name'
    _exec_script_data_0 = 'test_exec_script'

    def mock_pkgutil_get_data(mock_PkgUtil, module_name, script_name):
        if module_name == 'ansible.executor.powershell' and script_name == _exec_script_name_0 + '.ps1':
            return _exec_script_data_0

        return None

    module_mock = mock.MagicMock()
    module_mock.return_value = mock.MagicMock(
        pkgutil=mock.MagicMock(
            get_data=mock_pkgutil_get_data,
        ),
    )
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p

# Generated at 2022-06-24 18:59:35.993191
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = to_bytes('import_module_util_from_ansible Ansible.Windows.{name}')
    fqn_0 = to_text('Ansible.Windows.ModuleUtils.WinRM')
    wrapper_0 = False
    powershell_0 = True
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 18:59:44.814468
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'\n#Requires -Module Ansible.ModuleUtils.Pester\n'
    try:
        p_s_module_dep_finder_0.scan_module(module_data_0)
    except AnsibleError:
        print('caught exception')

    module_data_0 = b'#Requires -Module Ansible.ModuleUtils.MySQLServer\n'
    p_s_module_dep_finder_0.scan_module(module_data_0)

    module_data_0 = b'#AnsibleRequires -Powershell Ansible.ModuleUtils.MySQLServer\n'

# Generated at 2022-06-24 18:59:46.077835
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder = PSModuleDepFinder()
    PSModuleDepFinder.scan_exec_script("script_file")


# Generated at 2022-06-24 19:00:05.410881
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('test')
    assert 'test' in p_s_module_dep_finder_0.exec_scripts
    assert p_s_module_dep_finder_0.exec_scripts['test'] != b''


# Generated at 2022-06-24 19:00:10.653941
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("data_json_dumps.ps1")


# Generated at 2022-06-24 19:00:22.023755
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Generate random string
    exec_script_name = ''.join([random.choice('abcdefghijklmnopqrstuvwxyz1234567890') for n in range(15)])

    # Create an empty file
    path = os.path.dirname(__file__)
    path = os.path.join(path, "test")
    path = os.path.join(path, exec_script_name + ".ps1")
    with open(path, "w"):
        pass

    p_s_module_dep_finder_1 = PSModuleDepFinder()

    # Execute function scan_exec_script
    result = p_s_module_dep_finder_1.scan_exec_script(exec_script_name)

    # Remove class object
    del p_s_module_dep_finder

# Generated at 2022-06-24 19:00:30.739925
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data = to_bytes(base64.b64decode('Iz1SZXF1aXJlcyAtTW9kdWxlIEFuc2libGUuTW9kdWxlVXRpbHMuY29tbWFuZA=='))
    fqn = to_text(base64.b64decode('c29tZS5tb2R1bGU='))
    wrapper = False
    powershell = True
    p_s_module_dep_finder_1.scan_module(module_data, fqn, wrapper, powershell)

# Generated at 2022-06-24 19:00:34.825964
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_exec_script("find_module")
    except AnsibleError:
        pass


# Generated at 2022-06-24 19:00:39.986764
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    result = PSModuleDepFinder.scan_module(p_s_module_dep_finder_0, module_data=module_data_0, fqn=fqn_0, wrapper=wrapper_0, powershell=powershell_0)


# Generated at 2022-06-24 19:00:44.397053
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_0 = to_text("version_default")
    actual_0 = p_s_module_dep_finder_1.scan_exec_script(name_0)
    expected_0 = None
    assert actual_0 == expected_0


# Generated at 2022-06-24 19:00:49.700568
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Parameters
    name = b'Test_Module'

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:00:55.308945
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("    #Requires -Module Ansible.ModuleUtils.Aegis", )


# Generated at 2022-06-24 19:01:02.797180
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = to_bytes(base64.b64decode('IyBBbiBQb3dlclNoZWxsIE1vZHVsZQojIFJlcXVpcmVzIC1Nb2R1bGUgQW5zaWJsZS5Nb2R1bGVVdGlscy5UZXN0TW9kdWxlCg=='))
    fqn_0 = 'Ansible.TestModule'
    wrapper_0 = False
    powershell_0 = True
    assert p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0) is None

    module_data_1

# Generated at 2022-06-24 19:01:36.853832
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create instance of class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Mock the value of the Ansible.ModuleUtils.{name} file
    mock_module_util_0 = random.choice(["Lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing", "elit", "ut", "aliquam"])

    # Mock the value that was used to compare if exception was raised
    mock_fqn_0 = random.choice(["Lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing", "elit", "ut", "aliquam"])

    # Mock the value that was used to compare if exception was raised
    mock

# Generated at 2022-06-24 19:01:41.270139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_text(''))


# Generated at 2022-06-24 19:01:44.064391
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # create object PSModuleDepFinder
    obj = PSModuleDepFinder()

    # TODO - add test for for scan_module
    assert False



# Generated at 2022-06-24 19:01:52.944521
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn_0 = to_bytes("ansible.builtin.win_command")
    p_s_module_dep_finder_0.exec_scripts["ansible.builtin.win_command"] = fqn_0
    p_s_module_dep_finder_0.scan_exec_script("ansible.builtin.win_command")


# Generated at 2022-06-24 19:02:03.725160
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    success = 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    exception_caught1 = False
    exception_caught2 = False
    try:
        p_s_module_dep_finder_0.scan_exec_script('run_isolated')
    except AnsibleError:
        exception_caught1 = True
    else:
        success += 1

    try:
        p_s_module_dep_finder_0.scan_exec_script('run_isolated')
    except AnsibleError:
        exception_caught2 = True

    if exception_caught1 and not exception_caught2:
        success += 1

    assert success == 2, "Expected success == 2, but got success == %s" % success


# Generated at 2022-06-24 19:02:06.491685
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script('win_ping')


# Generated at 2022-06-24 19:02:18.776565
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Exec function
    print('---- Executing test_PSModuleDepFinder_scan_exec_script() ----')

    # Set vars
    ansible_collection_paths = []
    ansible_base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    plugin_paths = []
    C.ANSIBLE_COLLECTIONS_PATHS = ansible_collection_paths
    C.DEFAULT_MODULE_PATH = os.path.join(ansible_base_path, 'lib', 'ansible', 'modules')
    C.DEFAULT_MODULE_UTILS_PATH = os.path.join(ansible_base_path, 'lib', 'ansible', 'module_utils')
    C.DEFAULT_PLUGIN_PATH

# Generated at 2022-06-24 19:02:25.302578
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Getting the path of the test module
    test_module_path = resource_from_fqcr("test_module_utils.module_utils.test_module", "")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Calling method scan_module of class PSModuleDepFinder
    p_s_module_dep_finder_0.scan_module(_slurp(test_module_path), wrapper=False, powershell=True)

# Generated at 2022-06-24 19:02:31.102774
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Invoke method
    p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.Logging')

    # Check return type
    # Check return value
    # Check target method invoked


# Generated at 2022-06-24 19:02:34.121374
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # atm it's not something that can be unit tested
    pass


# Generated at 2022-06-24 19:03:07.147799
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Make sure the module_data has all the references to the required module utils.
    module_data_references = r'#AnsibleRequires -Powershell ..module_utils.crypto_utils -Optional'
    module_data = '''%s
Write-Output "Hello World"
    ''' % module_data_references

    # Make sure the module_data has a Powershell and a C# reference.
    p_s_module_dep_finder_scan_module_0 = PSModuleDepFinder()
    p_s_module_dep_finder_scan_module_0.scan_module(module_data)

    # Test if ps_modules contains the module_utils.crypto_utils and check their data.

# Generated at 2022-06-24 19:03:16.368942
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Start by building an AnsibleModule object that can be used to gather
    # module arguments from the task.
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # Move on to building the request body.
    p_s_module_dep_finder_1.scan_module(None, fqn=None, wrapper=False, powershell=True)
    p_s_module_dep_finder_1.scan_module(None, fqn=None, wrapper=False, powershell=False)


# Generated at 2022-06-24 19:03:17.921061
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script(name="win_path")


# Generated at 2022-06-24 19:03:20.065445
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Test for case_0:
    test_PSModuleDepFinder_scan_exec_script_case_0(ps_module_dep_finder_0)


# Generated at 2022-06-24 19:03:26.685217
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup mock data and ensure that the mock data is used.
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data=None, fqn=None, wrapper=None, powershell=None)
    assert True


# Generated at 2022-06-24 19:03:31.644554
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = 'common'
    p_s_module_dep_finder_0.scan_exec_script(str_0)


# Generated at 2022-06-24 19:03:38.801779
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_script_name = "ps_utils"
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(test_script_name)

    assert "ps_utils" in p_s_module_dep_finder_0.exec_scripts.keys()
    assert "PscxModule_x64" in p_s_module_dep_finder_0.ps_modules.keys()


# Generated at 2022-06-24 19:03:43.105391
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script(p_s_module_dep_finder_1)


# Generated at 2022-06-24 19:03:47.303142
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("", "", False, True)


# Generated at 2022-06-24 19:03:49.615524
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('some_name')


# Generated at 2022-06-24 19:04:47.441342
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    util_name_str_0 = 'exec_ps1'
    util_name_str_1 = 'exec_ps1'
    util_name_str_2 = 'exec_ps1'
    util_name_str_3 = 'exec_ps1'
    util_name_str_4 = 'exec_ps1'
    util_name_str_5 = 'exec_ps1'
    util_name_str_6 = 'exec_ps1'
    util_name_str_7 = 'exec_ps1'
    util_name_str_8 = 'exec_ps1'
    util_name_str_9 = 'exec_ps1'
    util_name_str_10 = 'exec_ps1'
    util_

# Generated at 2022-06-24 19:04:58.990317
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:05:05.148962
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script(name="")
    except AnsibleError:
        pass

    # module_data is not used
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_1.scan_module(module_data="", fqn="", wrapper=False, powershell=True)
    except AnsibleError:
        pass



# Generated at 2022-06-24 19:05:08.421622
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("../execution.ps1")
    assert p_s_module_dep_finder_0.exec_scripts != {}



# Generated at 2022-06-24 19:05:16.748796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import unittest
    # Set up mock
    test_module_file_0 = 'C:\\WinPkgs\\Microsoft.PowerShell.5.ReferenceAssemblies.1.1.1.nupkg|module_utils\\' \
    'powershell\\module_utils\\network\\cloudstack\\cs\\cs.psm1|#AnsibleRequires -PowerShell ansible_collections.' \
    'cloudstack.cloudstack.plugins.module_utils.cloudstack.cloudstack.cs_securitygroup'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.ps_modules = dict()
    p_s_module_dep_finder_0.cs_utils_wrapper = dict()
    p_s_module_dep_finder_0.cs

# Generated at 2022-06-24 19:05:26.702315
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with fqn="ansible.collections.amazon.aws.plugins.modules.iam", wrapper=True, powershell=True
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    resource_name_0 = "module_utils.common"
    n_package_name_0 = "ansible.module_utils"
    n_resource_name_0 = to_native(resource_name_0 + ".psm1")
    module_util_0 = import_module(n_package_name_0)
    pkg_data_0 = pkgutil.get_data(n_package_name_0, n_resource_name_0)
    util_fqn_0 = to_text("%s.%s " % (n_package_name_0, resource_name_0))

# Generated at 2022-06-24 19:05:34.021532
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name = to_bytes('ps_wrapper')
    #
    # The code to be tested goes here.
    #
    p_s_module_dep_finder_0.scan_exec_script(n_name)


# Generated at 2022-06-24 19:05:43.880419
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:05:48.878986
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    mock_module_data_0 = pkgutil.get_data("ansible.executor.powershell", "script.ps1")

    if (mock_module_data_0):
        p_s_module_dep_finder_0.scan_module(mock_module_data_0, fqn=None, wrapper=False, powershell=True)
    else:
        raise AssertionError("p_s_module_dep_finder_0.scan_module() raises AssertionError exception")


# Generated at 2022-06-24 19:05:58.206846
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Case 1: the script is file_compare.ps1
    if 'file_compare.ps1' in p_s_module_dep_finder_0.exec_scripts:
        print('Error: file_compare.ps1 already in exec_scripts')
    # Case 2: the script is ansible_module_convert.ps1
    if 'ansible_module_convert.ps1' in p_s_module_dep_finder_0.exec_scripts:
        print('Error: ansible_module_convert.ps1 already in exec_scripts')
