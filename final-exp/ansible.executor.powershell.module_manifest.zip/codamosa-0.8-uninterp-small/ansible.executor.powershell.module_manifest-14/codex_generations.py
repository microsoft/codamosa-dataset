

# Generated at 2022-06-24 18:57:17.386015
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # established that script is present
    assert p_s_module_dep_finder_0.scan_exec_script("test_script_to_find") == None
    assert len(p_s_module_dep_finder_0.exec_scripts) == 1
    assert p_s_module_dep_finder_0.exec_scripts["test_script_to_find"]


# Generated at 2022-06-24 18:57:19.544643
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data="module_data", fqn=None,wrapper=False, powershell=True)


# Generated at 2022-06-24 18:57:22.687926
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'test'
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:57:27.543495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_args = []
    test_kwargs = {
        'name': '',
    }
    try:
        p_s_module_dep_finder_0.scan_exec_script(*test_args, **test_kwargs)
    except AnsibleError as e:
        assert "Could not find executor powershell script for ''" in str(e)


# Generated at 2022-06-24 18:57:30.452767
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("0f8cc2e0c67a75b2")


# Generated at 2022-06-24 18:57:37.470071
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script(name="test_case_0")
    except AnsibleError as e:
        assert e.message.startswith("Could not find executor ")



# Generated at 2022-06-24 18:57:42.584286
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("\n====================== PSModuleDepFinder_scan_exec_script ===========================")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_1 = p_s_module_dep_finder_0
    n_name_1 = "ansible_module_pwsh"
    p_s_module_dep_finder_1.scan_exec_script(n_name_1)
    for v_k_2 in p_s_module_dep_finder_1.exec_scripts.keys():
        print(v_k_2)


# Generated at 2022-06-24 18:57:44.353861
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p = PSModuleDepFinder()
    name = "common.psm1"
    p.scan_exec_script(name)


# Generated at 2022-06-24 18:57:48.338327
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    def test_scan_exec_script_0():
        name = 'ansible_winrm_exec'
        p_s_module_dep_finder_0.scan_exec_script(name)
        return True


# Generated at 2022-06-24 18:57:58.042705
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module("""#VERINFO: rsc.cloud.azure_rm_virtualmachine_info 1.2.0""", fqn="rsc.cloud.azure_rm_virtualmachine_info")
    p_s_module_dep_finder_0.scan_module("""#VERINFO: rsc.cloud.azure_rm_virtualmachine_info 1.2.0""", fqn="rsc.cloud.azure_rm_virtualmachine_info")
    p_s_module_dep_finder_0.scan_module("""#Requires -Version 6.1""", fqn="rsc.cloud.azure_rm_virtualmachine_info")
    p_s_module

# Generated at 2022-06-24 18:58:14.409861
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True



# Generated at 2022-06-24 18:58:20.727476
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with 'fqn' parameter
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = to_bytes("#Requires -Module Ansible.ModuleUtils.TestModuleUtilA\n"
                             "#Requires -Module Ansible.ModuleUtils.TestModuleUtilB\n")
    fqn_1 = "Ansible.TestModule"
    p_s_module_dep_finder_1.scan_module(module_data_1, fqn=fqn_1)


# Generated at 2022-06-24 18:58:22.790871
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script('powershell_async')


# Generated at 2022-06-24 18:58:26.669886
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script(name = "begin")
    p_s_module_dep_finder.scan_exec_script(name = "get_modules")


# Generated at 2022-06-24 18:58:29.229989
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('test3')


# Generated at 2022-06-24 18:58:31.364971
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('command')


# Generated at 2022-06-24 18:58:36.273897
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("parse_json")
    p_s_module_dep_finder_0.scan_exec_script("parse_json")


# Generated at 2022-06-24 18:58:40.937133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    result = p_s_module_dep_finder_0.scan_exec_script(name_0)
    assert result is None


# Generated at 2022-06-24 18:58:46.199752
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("module_wrapper")
    except Exception as exc:
        print("Unit test case failed: {0}".format(exc))


# Generated at 2022-06-24 18:58:49.762194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of the class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call the method scan_exec_script of the class PSModuleDepFinder
    p_s_module_dep_finder_0.scan_exec_script("0")


# Generated at 2022-06-24 18:59:05.993451
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Testing PSModuleDepFinder.scan_exec_script")
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("script_0")


# Generated at 2022-06-24 18:59:12.027463
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 18:59:22.302533
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()

    fqn = "ansible.builtin.patch"
    wrapper = False
    powershell = True

    # This module references a util in ansible.module_utils but not in a collection.
    data = ("#Requires -Module Ansible.ModuleUtils.Common\n"
            "#Requires -Module Ansible.ModuleUtils.Legacy.Common\n"
            "#Requires -Module Ansible.ModuleUtils.Legacy.Unix\n"
            "#Requires -Module Ansible.ModuleUtils.Legacy.Windows\n"
            "#Requires -Module Ansible.ModuleUtils.Win32\n")


# Generated at 2022-06-24 18:59:26.609819
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", "basic.ps1")
    b_data = to_bytes(data)
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script("basic")


# Generated at 2022-06-24 18:59:31.702607
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()

    name = "Common"

    p_s_module_dep_finder.scan_exec_script(name)


# Generated at 2022-06-24 18:59:39.372104
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("ansiblessh_runner")
    except (AnsibleError) as err:
        print("%s: %s" % (type(err), err))


# Generated at 2022-06-24 18:59:44.549734
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('common')
    p_s_module_dep_finder_0.scan_exec_script('debug')
    assert p_s_module_dep_finder_0.become == True


# Generated at 2022-06-24 18:59:46.174118
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    p_s_module_dep_finder = PSModuleDepFinder()

    name = 'win_nssm'
    p_s_module_dep_finder.scan_exec_script(name)


# Generated at 2022-06-24 18:59:47.722879
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    m_name = None
    p_s_module_dep_finder_1.scan_exec_script(m_name)


# Generated at 2022-06-24 18:59:52.223211
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("chocolatey_install")


# Generated at 2022-06-24 19:00:20.193111
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Test 0: Default arguments
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(b"set-stuff\n#ansiblerequires -powershell some_module_util")
    # Test 1: All arguments
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b"set-stuff\n#ansiblerequires -powershell some_module_util", "some_module_util", False, True)
    # Test 2: All arguments
    p_s_module_dep_finder_2 = PSModuleDepFinder()

# Generated at 2022-06-24 19:00:23.421253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = 'name'
    # Raises a generic exception
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 19:00:26.191344
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'common'
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:00:37.938946
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fp = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_PSModuleDepFinder_scan_exec_script.txt')
    fp = to_bytes(fp, errors='surrogate_or_strict')
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.exec_scripts = {"ansible_test_PSModuleDepFinder_scan_exec_script": to_bytes(b'hello world', errors='surrogate_or_strict')}
    p_s_module_dep_finder_1.scan_exec_script("ansible_test_PSModuleDepFinder_scan_exec_script")


# Generated at 2022-06-24 19:00:44.506170
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class TestCase:
        def __init__(self, name):
            self.name = name

        def test(self):
            try:
                print("\n{0}: ".format(self.name), end='')
                call_function = self.call_function
                set_function = self.set_function
                p_s_module_dep_finder_0 = PSModuleDepFinder()
                p_s_module_dep_finder_0.scan_exec_script('ansible.module_utils.powershell.runspace_wrappers')
            except NotImplementedError:
                print("{0}: not implemented".format(self.name))


# Generated at 2022-06-24 19:00:51.133671
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    n_name_0 = 'random_string'
    assert n_name_0 not in p_s_module_dep_finder_0.exec_scripts.keys()
    p_s_module_dep_finder_0.scan_exec_script(n_name_0)
    assert n_name_0 in p_s_module_dep_finder_0.exec_scripts.keys()


# Generated at 2022-06-24 19:00:59.437660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    with open('test_cases.json', 'r') as tc_file:
        tc = json.load(tc_file)
    test_case = tc['test_cases'][0]

    # Code to be tested
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script('ansible_powershell.ps1')

    assert p_s_module_dep_finder_0.cs_utils_module == test_case['expected_cs_utils_module']
    assert p_s_module_dep_finder_0.cs_utils_wrapper == test_case['expected_cs_utils_wrapper']
    assert p_s_module_dep_finder_0.exec_scripts == test_case['expected_exec_scripts']
    assert p_s_

# Generated at 2022-06-24 19:01:07.513611
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = dict()
    p_s_module_dep_finder_0.scan_exec_script("exec_status")
    module_data_0 = p_s_module_dep_finder_0.exec_scripts["exec_status"]
    print("Searched for _get_windows_powershell_path.ps1")
    assert len(module_data_0) > 0


# Generated at 2022-06-24 19:01:09.988543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result = dict()

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.exec_scripts = {"InstallSoftwareComponent": "test"}

    with pytest.raises(AnsibleError):
        p_s_module_dep_finder_0.scan_exec_script("InstallSoftwareComponent")


# Generated at 2022-06-24 19:01:14.974155
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(str(1))


# Generated at 2022-06-24 19:02:10.451438
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test to validate that if the module has no module_util imports,
    # the set will be empty
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_module_data_0 = b'#!/usr/bin/env pwsh\n\n# this is a test module\n'
    test_fqn_0 = b'ansible_collections.foo.bar.plugins.modules.nada'
    test_wrapper_0 = False
    test_powershell_0 = True
    p_s_module_dep_finder_0.scan_module(test_module_data_0, test_fqn_0, test_wrapper_0, test_powershell_0)
    assert p_s_module_dep_finder_0.ps_modules == dict()
    assert p

# Generated at 2022-06-24 19:02:14.802139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "Test_name"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:02:20.470017
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing values
    name = 'PowerShell6Wrapper'
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script(name)
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-24 19:02:22.308776
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script((100*random.random()))


# Generated at 2022-06-24 19:02:24.946278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name_1 = "module_1"
    p_s_module_dep_finder_1.scan_exec_script(name_1)


# Generated at 2022-06-24 19:02:29.589107
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(random.choice(['test_script_0', 'test_script_1', 'test_script_2']))


# Generated at 2022-06-24 19:02:35.357843
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test passing invalid argument type
    with pytest.raises(AnsibleError) as exec_info:
        p_s_module_dep_finder_0.scan_module(object())
    assert exec_info.value.args[0].endswith(" requires a byte string for argument module_data")


# Generated at 2022-06-24 19:02:43.033388
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:02:44.406325
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0 is not None


# Generated at 2022-06-24 19:02:51.548039
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder_scan_exec_script_0 = p_s_module_dep_finder.scan_exec_script('NetworkModuleUtils')
    assert isinstance(p_s_module_dep_finder_scan_exec_script_0, None)


# Generated at 2022-06-24 19:04:29.305050
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    s_module_data_0 = '#AnsibleRequires -Wrapper myModule'
    fqn_0 = 'ansible_collections.my.collection.plugins.modules.my_module'

    p_s_module_dep_finder_0.scan_module(s_module_data_0, fqn=fqn_0)

try:
    import powergen.models.module as module_0
except ImportError:
    _import_error = True
else:
    _import_error = False

if not _import_error:
    from powergen.models.module import Module

# Generated at 2022-06-24 19:04:36.931520
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import random

    # Generate a non-empty dict
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    while (True):
        if (p_s_module_dep_finder_0.exec_scripts):
            break

    # Generate a random string of length (1,10)
    s = ''.join([random.choice('qwertyuiopasdfghjklzxcvbnm') for i in range(random.randint(1,10))])
    p_s_module_dep_finder_0.scan_exec_script(s)


# Generated at 2022-06-24 19:04:41.873593
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    module_data = '#Requires -Module Ansible.ModuleUtils.{name}'
    p_s_module_dep_finder_0.scan_module(module_data,fqn='',wrapper=False,powershell=True)


# Generated at 2022-06-24 19:04:44.558899
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    n_name_0 = p_s_module_dep_finder_0.scan_exec_script("ad_spec")


# Generated at 2022-06-24 19:04:51.034002
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(name = "wrapper")


# Generated at 2022-06-24 19:04:55.267638
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = to_text("some_wrapper")
    assert False== p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:04:59.245699
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()

    test_input = '''Module name,'''

    expected = None

    p_s_module_dep_finder.scan_exec_script(to_text(test_input))

    actual = None

    assert actual == expected


# Generated at 2022-06-24 19:05:07.790921
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b'#Requires -Module Ansible.ModuleUtils.Legacy'
    module_data_1 = b'#Requires -Module Ansible.ModuleUtils.Legacy\n#Requires -Module Ansible.ModuleUtils.Legacy.Text\n#Requires -Module Ansible.ModuleUtils.Legacy.Windows'
    module_data_2 = b'#Requires -Module Ansible.ModuleUtils.Legacy\n#Requires -Module Ansible.ModuleUtils.Legacy.Text\n#Requires -Module Ansible.ModuleUtils.Legacy.Windows\n#Requires -Module Ansible.ModuleUtils.Legacy.WinRM'

# Generated at 2022-06-24 19:05:13.503838
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = str()
    try:
        # p_s_module_dep_finder_0.scan_exec_script(name_0)
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-24 19:05:17.754258
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # calling scan_exec_script()
    try:
        test_name = 'files'
        p_s_module_dep_finder_0.scan_exec_script(test_name)

        assert False
    except Exception as e:
        assert True
