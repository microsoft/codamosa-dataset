

# Generated at 2022-06-24 18:57:27.423063
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    import tempfile
    import os

    # Test without optional requirements
    fd, test_file = tempfile.mkstemp(prefix='ansible_test_PSModuleDepFinder_scan_module', suffix='.ps1')
    os.close(fd)

# Generated at 2022-06-24 18:57:34.505303
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0._re_cs_module.match(to_bytes("using ansible_collections.ns.coll.plugins.module_utils.network.netcli.nxos.netcli;\n")) is not None
    assert p_s_module_dep_finder_0._re_cs_in_ps_module.match(to_bytes("#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.network.netcli.nxos.netcli\n")) is not None
    assert p_s_module_dep_finder_0._re_ps_module.match(to_bytes("#Requires -Module Ansible.ModuleUtils.Powershell\n"))

# Generated at 2022-06-24 18:57:37.853366
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "windows_service"
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 18:57:43.368128
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('script_name')


# Generated at 2022-06-24 18:57:54.149194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'test_name_0'
    test_script = b"#some test script\r\n#ansiblerequires -powershell test_dep\r\n"

    def pkgutil_get_data_mock(lib_name, script_name):
        assert lib_name == 'ansible.executor.powershell'
        assert script_name == 'test_name_0.ps1'

        return test_script
    pkgutil.get_data = pkgutil_get_data_mock

    # Add a mock for the loop into _add_module
    def _add_module_mock(_name, _ext, _fqn, _optional, _wrapper=False):
        assert _name == 'test_dep'

# Generated at 2022-06-24 18:58:01.094441
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-24 18:58:02.722417
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('run_powershell')


# Generated at 2022-06-24 18:58:10.580851
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if C.DEFAULT_DEBUG:
        return None

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("__init__")

# Generated at 2022-06-24 18:58:11.332250
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-24 18:58:16.034468
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script(name='test')


# Generated at 2022-06-24 18:58:35.498268
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Call scan_exec_script method of class PSModuleDepFinder
    p_s_module_dep_finder_0.scan_exec_script('Ansible.ModuleUtils.Common')


# Generated at 2022-06-24 18:58:37.494247
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    # Pass
    p_s_module_dep_finder.scan_exec_script("hello")


# Generated at 2022-06-24 18:58:43.926213
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_0.scan_exec_script("test")
    except Exception as e:
        raise("Exception: {0}".format(e))


# Generated at 2022-06-24 18:58:51.853460
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("")
    assert len(p_s_module_dep_finder_0.exec_scripts) == 0

    p_s_module_dep_finder_0.scan_exec_script("jmespath")
    assert len(p_s_module_dep_finder_0.exec_scripts) == 1
    assert "jmespath" in p_s_module_dep_finder_0.exec_scripts.keys()

    p_s_module_dep_finder_0.scan_exec_script("jmespath")
    assert len(p_s_module_dep_finder_0.exec_scripts) == 1
    assert "jmespath" in p_s_module_

# Generated at 2022-06-24 18:58:58.201551
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('ansible_module_wrapper')


# Generated at 2022-06-24 18:59:07.650395
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    name_0 = 'Parsing'
    p_s_module_dep_finder_0.scan_exec_script(name_0)

    name_1 = 'Parsing'
    p_s_module_dep_finder_0.scan_exec_script(name_1)

    name_2 = 'Parsing'
    p_s_module_dep_finder_0.scan_exec_script(name_2)


# Generated at 2022-06-24 18:59:09.639009
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data="module_data_0")


# Generated at 2022-06-24 18:59:20.594040
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper")
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper_windows")
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper_ansible_collections")
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper_ansible_collections_windows")
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper_ansible_collections_windows_parameters")

# Generated at 2022-06-24 18:59:23.101652
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p = PSModuleDepFinder()
    p.scan_exec_script("win_package")
    assert "win_package" in p.exec_scripts


# Generated at 2022-06-24 18:59:26.810938
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("win_command")
    assert p_s_module_dep_finder_0.exec_scripts["win_command"].startswith("<#")


# Generated at 2022-06-24 19:00:00.918434
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = b"Ansible.CommonUtils.CreateTemporaryFile"
    fqn_0 = None
    wrapper_0 = False
    powershell_0 = False
    try:
        p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)
    except Exception as e:
        raise Exception("Error invoking method 'scan_module' of class 'PSModuleDepFinder' with arguments %s, exception %s" % (repr((module_data_0, fqn_0, wrapper_0, powershell_0)), repr(e)))


# Generated at 2022-06-24 19:00:07.702652
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common')
    if len(p_s_module_dep_finder_0.ps_modules.keys()) != 1:
        raise AssertionError("Expected length of keys to be 1, but it was %s" % len(p_s_module_dep_finder_0.ps_modules.keys()))


# Generated at 2022-06-24 19:00:15.951130
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    file_path = resource_from_fqcr(u"ansible_collections.ansible.builtin", u"plugins", u"module_utils", u"powershell", u"basic.psm1")
    with open(file_path, 'rb') as f:
        data = f.read()

    p = PSModuleDepFinder()
    p.scan_exec_script(u"init")


# Generated at 2022-06-24 19:00:18.555633
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if C.DEFAULT_DEBUG:
        print('in test_PSModuleDepFinder_scan_exec_script')
    PSModuleDepFinder_instance = test_case_0()
    # PSModuleDepFinder_instance.scan_exec_script(a0, a1)


# Generated at 2022-06-24 19:00:28.740726
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create instance of class PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    try:
        # store value for exec_scripts
        p_s_module_dep_finder_0.exec_scripts = {}
        try:
            # Call method scan_exec_script with name "become.ps1"
            p_s_module_dep_finder_0.scan_exec_script("become.ps1")
        except (AnsibleError) as ae:
            print(ae.message)
    except (AssertionError) as ae:
        print(ae.message)


# Generated at 2022-06-24 19:00:35.812144
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = 'Ansible.ModuleUtils.Common.List'
    fqn_0 = 'fqn'
    wrapper_0 = False
    powershell_0 = False
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn_0, wrapper_0, powershell_0)


# Generated at 2022-06-24 19:00:44.705880
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn = 'test_fqn'
    wrapper_0 = False
    powershell_0 = True
    # Test without data
    # Test with data
    # Test with module_data: '#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.{name}'
    # Test with module_data: '#AnsibleRequires -CSharpUtil ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}'
    # Test with module_data: '#AnsibleRequires -CSharpUtil ..module_utils.{name}'
    # Test with module_data: 'using Ansible.ModuleUtils.{name}'
    # Test with module_data: 'using ansible_col

# Generated at 2022-06-24 19:00:54.652900
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test for case where fqn is not provided
    try:
        result = p_s_module_dep_finder_0.scan_module('module_data', 'fqn', False, True)
    except:
        pass

    # Test for case where wrapper is not provided
    try:
        result = p_s_module_dep_finder_0.scan_module('module_data', 'fqn', 'wrapper', True)
    except:
        pass

    # Test for case where powershell is not provided
    try:
        result = p_s_module_dep_finder_0.scan_module('module_data', 'fqn', False, 'powershell')
    except:
        pass



# Generated at 2022-06-24 19:01:02.467832
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    for i in range(10):
        p_s_module_dep_finder_0 = PSModuleDepFinder()

        try:
            p_s_module_dep_finder_0.scan_exec_script(fqn="ansible_collections.my.my_collection.plugins.modules.my_module.py", name="my_module")
        except AnsibleError:
            pass

        try:
            p_s_module_dep_finder_0.scan_exec_script(fqn="ansible_collections.", name="my_module")
        except IndexError:
            pass

        p_s_module_dep_finder_0.scan_exec_script(fqn="ansible_collections.my.my_collection.plugins.modules.my_module.ps1", name="my_module.ps1")

# Generated at 2022-06-24 19:01:06.910925
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    file_data = """a line
#Requires -Module Ansible.ModuleUtils.Basic
"""
    p_s_module_dep_finder_0.scan_module(file_data)


# Generated at 2022-06-24 19:01:31.707677
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    executor_script = pkgutil.get_data("ansible.executor.powershell", to_native("become.ps1"))
    assert executor_script is not None, "become.ps1 was not found in executor powershell"

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("become")


# Generated at 2022-06-24 19:01:34.805601
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()


# Generated at 2022-06-24 19:01:42.285234
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    script_name = "ping"

    assert isinstance(script_name, tuple)

    return_value = p_s_module_dep_finder_0.scan_exec_script(script_name)

    return return_value


# Generated at 2022-06-24 19:01:53.287636
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    doc = '''
- name: with_items module
  hosts: localhost
  gather_facts: False
  tasks:
    - name: test
      shell: echo i={{item}}
      with_items:
      - 1
      - 2
      - 3
      - 4
      - 5
      - 6
      - 7
      - 8
      - 9
      - 10
'''

    p_s_module_dep_finder_1 = PSModuleDepFinder()

    fqn = "ansible_collections.my.collection.plugins.modules.mymodule"
    p_s_module_dep_finder_1.scan_module(to_bytes(doc), fqn=fqn, powershell=True)


# Generated at 2022-06-24 19:01:57.916134
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(to_text("powershell_script"))
    pass


# Generated at 2022-06-24 19:02:06.016457
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_cs_module_data = 'using ansible_collections.namespace.collection.plugins.module_utils.module_util_name;\n'
    test_ps_module_data = '#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.module_util_name'
    test_name = 'test_name'

    p_s_module_dep_finder_2 = PSModuleDepFinder()
    try:
        p_s_module_dep_finder_2.scan_exec_script(test_name)
        assert False, "Expected AnsibleError for line '{}'.".format(test_name)
    except AnsibleError:
        pass

# Generated at 2022-06-24 19:02:10.012970
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(" ")


# Generated at 2022-06-24 19:02:20.502863
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps_module_dep_finder = PSModuleDepFinder()

    # Test case where the second line of a module contains a C# module reference
    module = b'$ErrorActionPreference = $PSCmdlet.GetVariableValue("ErrorActionPreference")\n\
        #requires -module ansible.module_utils.facts\n\
        #requires -module ansible_collections.my_namespace.my_collection.plugins.module_utils.other_util\n'
    ps_module_dep_finder.scan_module(module)

    # Test case where the second line of a module contains a C# module reference

# Generated at 2022-06-24 19:02:23.337469
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Call scan_exec_script with parameters:
    #  - name: 'runs_once'
    try:
        p_s_module_dep_finder_0.scan_exec_script('runs_once')

    # Raises exception
    except:
        assert False



# Generated at 2022-06-24 19:02:34.776634
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    r'''PSModuleDepFinder.scan_exec_script(name)
    '''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "powershell_init.ps1"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except Exception as err_0:
        print("Caught exception.  Caller traceback is:\n%s"
              % to_text(format_exc()))
        print("Exception is:\n%s\n" % to_text(str(err_0)))
        print("Exception is:\n%s\n" % to_text(err_0))
    else:
        print("No exception.")


# Generated at 2022-06-24 19:02:50.831657
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if os.getenv('TEST_PS_MODULE_DEP_FINDER') is not None:
        # Run tests
        test_0()
        test_1()
        test_2()
        print('All tests completed successfully')


# Generated at 2022-06-24 19:02:57.760750
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with a non-existing script
    try:
        p_s_module_dep_finder_0.scan_exec_script("non-existing_script")
        assert False, "Should have raised AnsibleError"
    except AnsibleError:
        pass

    # Test with an existing script
    p_s_module_dep_finder_0.scan_exec_script("exec_wrapper")
    assert True

# Test method PSModuleDepFinder._add_module()

# Generated at 2022-06-24 19:02:59.567772
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = "TestString"
    p_s_module_dep_finder_0.scan_exec_script(name)



# Generated at 2022-06-24 19:03:03.266696
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("test_PSModuleDepFinder_0")


# Generated at 2022-06-24 19:03:11.585629
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case = 0
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = "\n   # Requires -Module Ansible.ModuleUtils.A\n      #AnsibleRequires -PowerShell Ansible.ModuleUtils.A -Optional\n  using Ansible.ModuleUtils.A;\n\n"
    fqn_0 = 'lib/ansible/modules/test/test_A'
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn=fqn_0)
    fqn_1 = 'lib/ansible/modules/test/test_B'

# Generated at 2022-06-24 19:03:13.939838
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('module.ps1')


# Generated at 2022-06-24 19:03:21.901266
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0.scan_exec_script("") is None
    assert p_s_module_dep_finder_0.scan_exec_script("apr1") is None
    assert p_s_module_dep_finder_0.scan_exec_script("b64encdec") is None
    assert p_s_module_dep_finder_0.scan_exec_script("base64") is None
    assert p_s_module_dep_finder_0.scan_exec_script("common_util") is None
    assert p_s_module_dep_finder_0.scan_exec_script("compress") is None

# Generated at 2022-06-24 19:03:31.602783
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("AddPath")

# Generated at 2022-06-24 19:03:35.519064
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("common")
    assert len(p_s_module_dep_finder_0.exec_scripts) == 1


# Generated at 2022-06-24 19:03:48.065569
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = '''#Requires -Module CSharpExample
                    #AnsibleRequires -CSharpUtil Ansible.CollectionUtil
                    #AnsibleRequires -CSharpUtil .../CollectionUtil2
                    #AnsibleRequires -CSharpUtil .CollectionUtil3
                    #Requires -Version 6.1.0
                    #AnsibleRequires -OSVersion 8.1
                    #AnsibleRequires -Become
    '''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data, wrapper=False)


# Generated at 2022-06-24 19:04:11.686220
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pseudo_exec_script = '''
$file = Join-Path -Path $p
    '''.encode('utf-8')

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(pseudo_exec_script)


# Generated at 2022-06-24 19:04:18.861405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "Add-ReturnCode"
    try:
        p_s_module_dep_finder_0.scan_exec_script(name_0)
    except:
        pass


# Generated at 2022-06-24 19:04:23.450450
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(to_bytes('#Requires -Module Ansible.ModuleUtils.Logic'), fqn=None, wrapper=False, powershell=True)


# Generated at 2022-06-24 19:04:29.378182
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # p_s_module_dep_finder_0 is an instance of PSModuleDepFinder
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # name is str
    name = random.choice([
        'interpreter',
        'executor',
    ])
    # test if no error is thrown when function is called with these parameters
    p_s_module_dep_finder_0.scan_exec_script(name)


# Generated at 2022-06-24 19:04:35.685699
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test 1
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data_1 = "#Requires -Module Ansible.ModuleUtils.CommonPS1.psm1"
    fqn_1 = "Ansible.ModuleUtils.CommonPS1.psm1"
    test_1 = p_s_module_dep_finder_1.scan_module(module_data_1, fqn=fqn_1)
    assert test_1 is None
    assert p_s_module_dep_finder_1.ps_modules["Ansible.ModuleUtils.CommonPS1"] is not None


# Generated at 2022-06-24 19:04:44.561791
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    class MockModulePlugin(object):
        def _load_module_source(self, conn, module_name, module_style, mod_args=None, timeout=10):
            return b'#!/bin/bash'

    p_s_module_dep_finder_0.scan_exec_script('hello')
    assert len(p_s_module_dep_finder_0.exec_scripts) == 1
    assert len(p_s_module_dep_finder_0.exec_scripts['hello']) != 0
    assert 'hello' in p_s_module_dep_finder_0.exec_scripts


# Generated at 2022-06-24 19:04:52.795636
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as err:
        p_s_module_dep_finder_0.scan_exec_script("")
    assert "Could not find executor powershell script for ''" in str(err.value)


# Generated at 2022-06-24 19:04:56.453926
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("async_wrapper")


# Generated at 2022-06-24 19:05:01.056106
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    module_data = b''
    fqn = None
    wrapper = False
    powershell = True
    p_s_module_dep_finder_1.scan_module(module_data, fqn=fqn, wrapper=wrapper, powershell=powershell)


# Generated at 2022-06-24 19:05:03.934932
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = 'pwsh'
    assert p_s_module_dep_finder_0.scan_exec_script(str_0) is None


# Generated at 2022-06-24 19:05:32.696158
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    test_module_name_0 = 'TestModule'
    test_module_data_0 = '''#AnsibleRequires -Powershell Ansible.ModuleUtils.JMESPath
#AnsibleRequires -Wrapper TestModule
#AnsibleRequires -Version 7
#AnsibleRequires -OSVersion 6.2

function Invoke-TestModule
{
    Echo "This is the test module."
}
'''
    p_s_module_dep_finder_1.scan_module(test_module_data_0, fqn=test_module_name_0, wrapper=False, powershell=True)

# Generated at 2022-06-24 19:05:34.021810
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case_0()


# Generated at 2022-06-24 19:05:42.524617
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    ret_count_0 = p_s_module_dep_finder_0.scan_exec_script(b'_ansible_compatibility')
    value = "ansible_collections.ansible.posix.plugins.module_utils.network.cloudengine.ce"
    assert value in p_s_module_dep_finder_0.ps_modules
    value = "ansible_collections.ansible.network.plugins.module_utils.network.cloudengine.ce"
    assert value in p_s_module_dep_finder_0.cs_utils_wrapper


# Generated at 2022-06-24 19:05:44.910145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script(b"run_command")


# Generated at 2022-06-24 19:05:52.917967
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.loader import ps_module_utils_loader

    mu_path = "lib/ansible/module_utils/basic.py"
    module_util_data = _slurp(mu_path)

    p_s_module_dep_finder = PSModuleDepFinder()
    # the ps_module_utils_loader.find_plugin was being called inside the scan_module
    # which required os.environ['ANSIBLE_COLLECTIONS_PATHS']='' to pass. So we are doing
    # it here itself and mocking the result of it to pass. So that we dont have to
    # set the env variable to '' explicitly in all tests.

# Generated at 2022-06-24 19:05:58.430901
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('_ansible_module_wrapper')
    p_s_module_dep_finder_0.scan_exec_script('_ansible_module_wrapper')
    p_s_module_dep_finder_0.scan_exec_script('_ansible_module_wrapper')


# Generated at 2022-06-24 19:06:01.652107
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_boolean_1 = p_s_module_dep_finder_0.scan_exec_script("powershell_base")


# Generated at 2022-06-24 19:06:06.267956
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with data =  (byte)0x10
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = p_s_module_dep_finder_0.exec_scripts
    lineno_0 = p_s_module_dep_finder_0.scan_exec_script

    p_s_module_dep_finder_0.scan_exec_script("")


# Generated at 2022-06-24 19:06:09.490369
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # Input parameters:
    name = "test"
    # Return type: None
    p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 19:06:14.534465
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("Ansible.ArgumentSpec")
    p_s_module_dep_finder_0.scan_exec_script("Ansible.CommonSpec")
    p_s_module_dep_finder_0.scan_exec_script("Ansible.NetSpec")
    p_s_module_dep_finder_0.scan_exec_script("Ansible.UtilSpec")
