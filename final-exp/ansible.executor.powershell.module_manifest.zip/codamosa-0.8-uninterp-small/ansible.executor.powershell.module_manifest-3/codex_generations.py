

# Generated at 2022-06-24 18:57:19.594454
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-24 18:57:26.535725
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("/tmp/ansible_powershell_exec_payload_x4exbx.ps1")


# Generated at 2022-06-24 18:57:33.911207
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    runner = TestRunner(test_case_0, print_output=True, stop_on_error=False)

# Generated at 2022-06-24 18:57:37.293401
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Parameters:
    #   name:  (type: )
    # 
    # Return Value:
    #   (type: )
    # 
    # Exceptions:
    #   AnsibleError: 
    pass


# Generated at 2022-06-24 18:57:44.109186
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('winrm')

    assert p_s_module_dep_finder_0.exec_scripts.keys() == ['winrm']


# Generated at 2022-06-24 18:57:46.789370
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    j_message = "this is a simple string"
    assert j_message == 'this is a simple string'

# Unit tests for method _slurp of class PSModuleDepFinder

# Generated at 2022-06-24 18:57:52.628944
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Basic case, no optional parameter passed
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    test_name_0 = 'test_name_0'
    p_s_module_dep_finder_0.scan_exec_script(test_name_0)


# Generated at 2022-06-24 18:57:57.225290
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a valid function(module_data,fqn,wrapper,powershell)
    fqn = "ansible.example.plugins.module_utils.test"
    module_data = "using ansible.example.plugins.module_utils"
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(module_data,fqn,False,True)



# Generated at 2022-06-24 18:58:01.340260
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    fqn_0 = to_bytes(random.choice(["test_0", "test_1", "test_2"]))
    module_data_0 = to_bytes(random.choice(["test_3", "test_4", "test_5"]))
    p_s_module_dep_finder_0.scan_module(module_data_0, fqn=fqn_0, wrapper=False, powershell=random.choice([True, False]))


# Generated at 2022-06-24 18:58:05.567952
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    exception_failure = False
    try:
        p_s_module_dep_finder_0.scan_exec_script('module_common.ps1')
    except AnsibleError:
        exception_failure = True
    if exception_failure:
        print("Error: Test for unit testing of method 'scan_exec_script' failed due to exception!")
        raise


# Generated at 2022-06-24 18:58:22.072866
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name = ""
    p_s_module_dep_finder_0.scan_exec_script(name)
    print("")


# Generated at 2022-06-24 18:58:28.161724
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing to ensure script name is not already in exec_scripts before adding
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 18:58:36.390718
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_0 = '''#Author: John Doe\n#Version: 0.1\n#Requires -Module Ansible.ModuleUtils.Logger,Ansible.ModuleUtils.Configuration\n'''
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(module_data_0)


# Generated at 2022-06-24 18:58:46.987511
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    fqn = "ansible_collections.vmware.vmware_rest.plugins.modules.vcenter_host_drs_rule"
    module_data = pkgutil.get_data("ansible_collections.vmware.vmware_rest.plugins.modules", fqn + ".psm1")
    p_s_module_dep_finder_1.scan_module(module_data, fqn)

# Generated at 2022-06-24 18:58:51.328289
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_0 = PSModuleDepFinder()
        result_0 = p_s_module_dep_finder_0.scan_exec_script("")
    except Exception as err:
        raise
    assert result_0 is None


# Generated at 2022-06-24 18:58:55.036871
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('test_PSModuleDepFinder_scan_exec_script')


# Generated at 2022-06-24 18:59:02.378020
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert p_s_module_dep_finder_0 is not None

    p_s_module_dep_finder_0.scan_exec_script('microsoft.powershell.management.utilities')
    p_s_module_dep_finder_0.scan_exec_script('ansible.windows.utils')

    assert 'microsoft.powershell.management.utilities' in p_s_module_dep_finder_0.exec_scripts
    assert 'ansible.windows.utils' in p_s_module_dep_finder_0.exec_scripts



# Generated at 2022-06-24 18:59:06.372274
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = 'test_exec_script'
    p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 18:59:15.708522
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Implementation note:
    #   The following code is a simple first approach for unit testing the scan_exec_script method
    #   of PSModuleDepFinder. It is by no means complete.
    #   Please feel free to update it with any other additional test cases.
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # If method scan_exec_script raises AnsibleError, we should look into it.
    try:
        p_s_module_dep_finder_0.scan_exec_script("some_awesome_script_that_will_never_exist")
    except AnsibleError:
        pass
    except:
        raise
    else:
        assert False, "This should have raised AnsibleError()"


# Generated at 2022-06-24 18:59:26.769489
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # ensure the script doesn't have any requirements and strip out any comments
    def _stripped_script(script):
        script_data = ''
        for line in script.split('\n'):
            stripped_line = re.sub(r'(?i)^\s*#.*$', '', line)
            if stripped_line != '':
                script_data += stripped_line + '\n'
        return script_data

    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("ansible_collections.ansible.builtin.plugins.module_utils.powershell.base")
    assert p_s_module_dep_finder_1.ps_modules.keys() == []
    assert p_s_module_dep

# Generated at 2022-06-24 18:59:57.885731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(b"module_utils.powershell")
    assert p_s_module_dep_finder_1.ps_version is None
    assert p_s_module_dep_finder_1.os_version is None



# Generated at 2022-06-24 19:00:02.257660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Declare function arguments
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = 'hello'

    # Call function and test return value
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:00:04.800193
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('Starting test_PSModuleDepFinder_scan_exec_script')
    test_case_0()
    print('Test passed')


# Generated at 2022-06-24 19:00:16.577815
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:00:20.821367
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_test = PSModuleDepFinder()
    p_s_module_dep_finder_test.scan_exec_script("ansible_server")
    assert(p_s_module_dep_finder_test.exec_scripts['ansible_server'] != None)


# Generated at 2022-06-24 19:00:24.173561
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    # The p_s_module_dep_finder_1.scan_exec_script() should not raise an error
    try:
        p_s_module_dep_finder_1.scan_exec_script(name="ping")
    except Exception as e:
        assert False



# Generated at 2022-06-24 19:00:35.441963
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('wrapper')
    assert p_s_module_dep_finder_0.exec_scripts.__contains__('wrapper')
    p_s_module_dep_finder_0.scan_exec_script('testscript')
    assert p_s_module_dep_finder_0.exec_scripts.__contains__('testscript')
    p_s_module_dep_finder_0.scan_exec_script('powershell')
    assert p_s_module_dep_finder_0.exec_scripts.__contains__('powershell')



# Generated at 2022-06-24 19:00:43.039787
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # test with invalid filename
    try:
        p_s_module_dep_finder_0.scan_exec_script("foo")
    except AnsibleError as err:
        assert re.match("^Could not find executor powershell script for 'foo'$", to_native(err)) is not None
    else:
        raise Exception("AnsibleError not raised")
    # test with a valid filename
    p_s_module_dep_finder_0.scan_exec_script("ExecScriptModule")


# Generated at 2022-06-24 19:00:47.079806
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test error handling code
    try:
        p_s_module_dep_finder_0.scan_exec_script("test_value")
    except Exception as e:
        if isinstance(e, AnsibleError) and (e.args == ("Could not find executor powershell script for 'test_value'",)):
            pass
        else:
            raise


# Generated at 2022-06-24 19:00:55.327874
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test 1: Check that the util files are added while scanning the module without utils
    p_s_module_dep_finder = PSModuleDepFinder()
    data = b'''
    #Requires -Module Ansible.ModuleUtils.AnsibleModule
    #Requires -Module Ansible.ModuleUtils.AnsibleModuleUtils
    '''
    fqn = 'ansible.builtin.script'
    p_s_module_dep_finder.scan_module(data, fqn=fqn)

# Generated at 2022-06-24 19:01:12.155463
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # pass


# Generated at 2022-06-24 19:01:15.012256
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Check for the exception being thrown
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as exception:
        p_s_module_dep_finder_0.scan_exec_script('ping.ps1')


# Generated at 2022-06-24 19:01:22.563920
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with param 0 for argument *name = 'test'
    test_PSModuleDepFinder_test1 = 'test'

    p_s_module_dep_finder_0.exec_scripts = {'test':'asdf'}
    p_s_module_dep_finder_0.scan_exec_script(test_PSModuleDepFinder_test1)
    assert p_s_module_dep_finder_0.exec_scripts['test'] == 'asdf'


# Generated at 2022-06-24 19:01:23.772583
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_case_0()


# Generated at 2022-06-24 19:01:30.140185
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script(
        'test_scan_exec_script'
    )
    assert p_s_module_dep_finder_1.exec_scripts == dict()

    #TODO fix this
    # assert p_s_module_dep_finder_1.cs_utils_wrapper == dict()
    # assert p_s_module_dep_finder_1.ps_modules == dict()


# Generated at 2022-06-24 19:01:35.252795
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with invalid value for param name.
    # Expected result: throws AnsibleError
    try:
        p_s_module_dep_finder_0.scan_exec_script(name='')
    except AnsibleError:
        pass
    else:
        raise Exception("Expected AnsibleError")

    # Test with valid value for param name.
    p_s_module_dep_finder_0.scan_exec_script(name='communicator_powershell.ps1')


# Generated at 2022-06-24 19:01:41.427356
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    name = "a_random_name"
    p_s_module_dep_finder_1.scan_exec_script(name)


# Generated at 2022-06-24 19:01:52.829039
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
	p_s_module_dep_finder_0 = PSModuleDepFinder()
	fqn_0 = [fqn_0]
	optional_0 = [optional_0]
	module_data_0 = [module_data_0]
	powershell_0 = [powershell_0]
	wrapper_0 = [wrapper_0]
	module_data_0 = [module_data_0]
	powershell_0 = [powershell_0]
	wrapper_0 = [wrapper_0]
	fqn_0 = [fqn_0]
	optional_0 = [optional_0]
	module_data_0 = [module_data_0]
	powershell_0 = [powershell_0]
	wrapper_0 = [wrapper_0]

# Generated at 2022-06-24 19:01:57.208476
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder = PSModuleDepFinder()
    p_s_module_dep_finder.scan_exec_script(name = "ansible_facts")


# Generated at 2022-06-24 19:02:01.169862
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    name_0 = "Dummy"
    p_s_module_dep_finder_0.scan_exec_script(name_0)


# Generated at 2022-06-24 19:02:20.315686
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    p_s_module_dep_finder_0.scan_exec_script("Executor")
    assert p_s_module_dep_finder_0.exec_scripts == {'Executor': b'<script>\n#Requires -Version 3.0\n\n<script-body>\n'}


# Generated at 2022-06-24 19:02:34.688675
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-24 19:02:43.013923
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test:
    # `PSModuleDepFinder.scan_module()` with exception

    # test

# Generated at 2022-06-24 19:02:56.498284
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = pkgutil.get_data("ansible.module_utils.powershell", "basic.ps1")
    p_s_module_dep_finder_0.scan_module(str_0)
    assert len(p_s_module_dep_finder_0.ps_modules.keys()) == 1
    # Test the case where there are duplicate module_utils. It should consume the first one it finds and ignore
    # the duplicates.
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    str_0 = pkgutil.get_data("ansible.module_utils.powershell", "dup_dep_test.ps1")
    p_s_module_dep_finder_0.scan_module

# Generated at 2022-06-24 19:03:05.643265
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    scanner = PSModuleDepFinder()

    module_name = "TestModule"
    module_data = '''
#Requires -Module Ansible.ModuleUtils.TestMU
#Requires -Module Ansible.ModuleUtils.TestMU2
#Requires -Module Ansible.ModuleUtils.TestMU3
$TestVar = 5
    '''
    scanner.scan_module(module_data, fqn=module_name, wrapper=True)

    assert len(scanner.ps_modules) == 3
    assert ("Ansible.ModuleUtils.TestMU", ".psm1") in scanner.ps_modules.keys()
    assert ("Ansible.ModuleUtils.TestMU2", ".psm1") in scanner.ps_modules.keys()
    assert ("Ansible.ModuleUtils.TestMU3", ".psm1")

# Generated at 2022-06-24 19:03:12.527278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # This is used so that we can control the randomness that is used
    # by the module to encode the script so that we can reproduce the
    # same pattern every time for the unit test
    random_0 = random.Random()
    random_0.seed(987541212)

    for name_0_0 in ["test_exec_script_0.ps1", "test_exec_script_1.ps1"]:
        p_s_module_dep_finder_0.scan_exec_script(to_text(name_0_0))

    assert 'test_exec_script_0.ps1' in p_s_module_dep_finder_0.exec_scripts
    test_exec_script_0_ps1_0_0 = p

# Generated at 2022-06-24 19:03:17.375711
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    assert(not p_s_module_dep_finder_0.scan_module("", fqn="", wrapper=False, powershell=True))


# Generated at 2022-06-24 19:03:19.740351
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('new_child_process')
    assert "new_child_process" in p_s_module_dep_finder_0.exec_scripts


# Generated at 2022-06-24 19:03:25.699923
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # value = name = "hello"
    name = "hello"
    try:
        result = p_s_module_dep_finder_0.scan_exec_script(name)
        assert result is None
    except:
        raise Exception()


# Generated at 2022-06-24 19:03:33.396044
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_input = '\n'
    test_fqn = '\n'
    test_wrapper = False
    test_powershell = True

    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(test_input, test_fqn, test_wrapper, test_powershell)


# Generated at 2022-06-24 19:03:51.627630
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Test case for test_case_0 (0)
    p_s_module_dep_finder_0.scan_module(to_bytes(''))


# Generated at 2022-06-24 19:03:57.880224
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        p_s_module_dep_finder_1 = PSModuleDepFinder()
        print("Using script: jinja2")
        p_s_module_dep_finder_1.scan_exec_script("jinja2")
        print("Using script: returncode")
        p_s_module_dep_finder_1.scan_exec_script("returncode")
    except AnsibleError as e:
        print("Error while scanning exec_script: " + str(e))


# Generated at 2022-06-24 19:04:08.291438
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_case_0()

    # Test case with valid data
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("one")
    p_s_module_dep_finder_1.scan_exec_script("two")
    assert p_s_module_dep_finder_1.exec_scripts == {'two': b'\r\n', 'one': b'\r\n'}
    assert p_s_module_dep_finder_1.ps_modules == {}
    assert p_s_module_dep_finder_1.cs_utils_wrapper == {}
    assert p_s_module_dep_finder_1.cs_utils_module == {}

# Generated at 2022-06-24 19:04:15.550537
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fqn = 'ansible_collections.microsoft.azure.plugins.module_utils.azure_rm_common'
    name = 'azure_rm_common.psm1'
    data = pkgutil.get_data("ansible_collections.microsoft.azure.plugins.module_utils.azure_rm_common", name)
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(data, fqn)



# Generated at 2022-06-24 19:04:25.395295
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Set up parameters
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.exec_scripts = {}
    p_s_module_dep_finder_1.ps_modules = {}
    p_s_module_dep_finder_1.cs_utils_wrapper = {}
    p_s_module_dep_finder_1.cs_utils_module = {}

    # Method invoked with name: 'common'
    p_s_module_dep_finder_1.scan_exec_script('common')
    assert(len(p_s_module_dep_finder_1.exec_scripts) == 1)
    assert(len(p_s_module_dep_finder_1.cs_utils_wrapper) == 1)

# Generated at 2022-06-24 19:04:32.534762
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # initialize
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    import ansible_collections.softwareon_demand.ssh_user_key.plugins.module_utils.common_utils as common_utils_0
    import ansible_collections.softwareon_demand.ssh_user_key.plugins.module_utils.ssh_user_key_utils as ssh_user_key_utils_0
    resource_path_0 = resource_from_fqcr(common_utils_0)

    pkg_data_0 = {'path': resource_path_0, 'data': pkgutil.get_data(common_utils_0.__name__, 'common.psm1')}

# Generated at 2022-06-24 19:04:35.557092
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_module(module_data=" # Requires -Module Ansible.ModuleUtils.Windows.Registry")


# Generated at 2022-06-24 19:04:45.506497
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    # Invalid parameter: name not a string
    with pytest.raises(AnsibleError) as e_info:
        p_s_module_dep_finder_0.scan_exec_script(None)
    # Invalid parameter: name not a string
    with pytest.raises(AnsibleError) as e_info:
        p_s_module_dep_finder_0.scan_exec_script(100)
    # Invalid parameter: name not a string
    with pytest.raises(AnsibleError) as e_info:
        p_s_module_dep_finder_0.scan_exec_script(0)
    # Invalid parameter: name not a string

# Generated at 2022-06-24 19:04:56.543113
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()

    # Test with invalid args
    try:
        p_s_module_dep_finder_0.scan_module('')
    except TypeError as e:
        if "String or buffer expected" in e.args[0]:
            pass
        else:
            raise e
    except Exception as e:
        raise e

    # Test with valid args
    try:
        p_s_module_dep_finder_0.scan_module('test_module_data')
    except Exception as e:
        raise e


# Generated at 2022-06-24 19:04:57.223525
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-24 19:05:27.484145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script("0")


# Generated at 2022-06-24 19:05:35.242451
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data = _make_random_string()
    fqn = _make_random_string()
    wrapper = _make_random_bool()
    powershell = _make_random_bool()
    p_s_module_dep_finder_0.scan_module(module_data, fqn, wrapper, powershell)



# Generated at 2022-06-24 19:05:43.880698
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as ex:
        p_s_module_dep_finder_1.scan_exec_script(None)
    assert str(ex.value) == 'Must provide a script name'
    with pytest.raises(AnsibleError) as ex:
        p_s_module_dep_finder_1.scan_exec_script('test')
    assert str(ex.value) == 'Could not find executor powershell script for \'test\''
    result = p_s_module_dep_finder_1.scan_exec_script('common')
    assert result is None


# Generated at 2022-06-24 19:05:47.460527
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_exec_script('default_args')



# Generated at 2022-06-24 19:05:48.698735
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing Exception with invalid name value
    test_case_0()

# Generated at 2022-06-24 19:05:59.561668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is called from scan_module.
    # This test case is supposed to check the scenarios where scan_module is called
    # A dummy scan_module method is introduced in classes and named as scan_module_test.
    # As scan_module_test is supposed to call scan_exec_script, dummy scan_exec_script is introduced
    # in classes and named as scan_exec_script_test.
    # This unit test is written to test dummy scan_exec_script_test
    #
    # The script Ansible.ModuleUtils.powershell.NetTCPIP should exist in lib/ansible/executor/powershell directory
    # Check whether the script called existed in directory is not None.
    p_s_module_dep_finder_0 = PSModuleDepFinder()

# Generated at 2022-06-24 19:06:05.150052
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_1 = PSModuleDepFinder()
    p_s_module_dep_finder_1.scan_exec_script("import_ps1_exe")
    assert p_s_module_dep_finder_1.exec_scripts.__len__() == 1
    p_s_module_dep_finder_1.scan_exec_script("exec_exe_1")
    assert p_s_module_dep_finder_1.exec_scripts.__len__() == 2


# Generated at 2022-06-24 19:06:09.400497
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    module_data_0 = 'foo\n#AnsibleRequires -CSharpUtil ansible_collections.microsoft.windows.plugins.module_utils.powershell.common\nbar\n'
    fqn_0 = 'foo'

    p_s_module_dep_finder_0.scan_module(module_data_0, fqn=fqn_0)
    pass


# Generated at 2022-06-24 19:06:11.083490
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    p_s_module_dep_finder_0.scan_module(
        module_data=''
    )


# Generated at 2022-06-24 19:06:17.762045
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p_s_module_dep_finder_0 = PSModuleDepFinder()
    codeobj_0 = to_bytes(base64.b64decode("IyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIwojICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICMgCiMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIyA="))

    fqn_0 = "my.collection.sync"
    p_s_module_dep