

# Generated at 2022-06-22 20:04:36.334127
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.network.netvisor.argspec.vrf_static_routes.vrf_static_routes import ArgumentSpec as vrf_static_routes_ArgumentSpec

    playbook_path = u'/home/centos/ansible/test_standalone/test_module/test_module.yml'
    args = dict()
    args[u'ansible_module_name'] = u'netvisor.vrf_static_routes.vrf_static_routes'

# Generated at 2022-06-22 20:04:48.672339
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-22 20:05:00.920985
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import types
    import unittest

    class TestArgs(object):

        def __init__(self):
            self.module_data = None
            self.fqn = None
            self.wrapper = False
            self.powershell = True

        def __eq__(self, other):
            if self.module_data != other.module_data:
                return False

            if self.fqn != other.fqn:
                return False

            if self.wrapper != other.wrapper:
                return False

            if self.powershell != other.powershell:
                return False

            return True

    class TestPSModuleDepFinder(PSModuleDepFinder):

        def __init__(self):
            super(TestPSModuleDepFinder, self).__init__()

            self.scan_modules = list

# Generated at 2022-06-22 20:05:12.667701
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()

    assert ps_dep_finder.ps_modules == {}
    assert ps_dep_finder.exec_scripts == {}
    assert ps_dep_finder.cs_utils_wrapper == {}
    assert ps_dep_finder.cs_utils_module == {}
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert not ps_dep_finder.become

    assert len(ps_dep_finder._re_cs_module) == 1

# Generated at 2022-06-22 20:05:21.400391
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    name = 'test.psm1'
    with open(name) as f:
        finder.scan_module(f.read())
    import json
    print(json.dumps(finder.exec_scripts, indent=4))
    print(json.dumps(finder.ps_modules, indent=4))
    print(json.dumps(finder.cs_utils_wrapper, indent=4))
    print(json.dumps(finder.cs_utils_module, indent=4))

# Generated at 2022-06-22 20:05:27.720881
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0


# Generated at 2022-06-22 20:05:37.370323
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ibmdec.ibmdec.plugins.module_utils.mydec import decode_string

    print("Testing ansible-doc - mydec.powershell.ps1")
    print("Running test_PSModuleDepFinder_scan_exec_script")

    # Testing Module
    x = decode_string('asfdsafsafasfdsfs')
    print(x)
    print("Testing ansible-doc - mydec.powershell.ps1")
    print("Running test_PSModuleDepFinder_scan_exec_script")

    # Testing Module
    y = decode_string('aSFDSFSFSFSFSFSFDF')
    print(y)

# Generated at 2022-06-22 20:05:50.008269
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)
    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert isinstance(ps_module_dep_finder._re_cs_module, list)

# Generated at 2022-06-22 20:06:01.445851
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module = """#Requires -Version '4.1'
#AnsibleRequires -Powershell Ansible.ModuleUtils.Basic
#AnsibleRequires -Powershell ansible_collections.foo.bar.plugins.module_utils.blah
#AnsibleRequires -Powershell ..module_utils.blah"""
    expected_ps_modules = {'Ansible.ModuleUtils.Basic': {'data': b'', 'path': ''},
                           'ansible_collections.foo.bar.plugins.module_utils.blah': {'data': b'', 'path': ''},
                           'module_utils.blah': {'data': b'', 'path': ''}}
    expected_cs_utils_wrapper = {}
    expected_cs_utils_module = {}

# Generated at 2022-06-22 20:06:11.501099
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:25.650047
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test scan_module() method of class PSModuleDepFinder() with valid inputs
    """
    test_module_data = "##Requires -Version 3.0\n#AnsibleRequires -CSharpUtil Ansible.Windows.ConfigureRemotingForAnsible\n#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.test1\n"
    test_module_data_scalar = to_bytes(test_module_data)
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_module(test_module_data_scalar, 'test_fqn')
    assert set(ps_module_finder.ps_modules) == set([])
    assert set(ps_module_finder.cs_utils_module)

# Generated at 2022-06-22 20:06:27.677200
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # Test the constructor
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-22 20:06:40.033834
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:47.610354
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import mock
    import ansible.plugins.loader
    m = mock.Mock()
    m.return_value.decode.return_value = "stub"
    m.return_value.__bool__.return_value = True
    with mock.patch('ansible.plugins.loader.pkgutil.get_data', m):
        a = PSModuleDepFinder()
        a.scan_exec_script("Simple")
        assert a.exec_scripts["Simple"] == b'stub'
        m.return_value.__bool__.return_value = False
        with pytest.raises(AnsibleError) as exc:
            a.scan_exec_script("Simple")
        assert exc.value.message == "Could not find executor powershell script for 'Simple'"


# Generated at 2022-06-22 20:06:56.054000
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.AnsibleModuleUtils')

    assert dep_finder.ps_modules['Ansible.ModuleUtils.AnsibleModuleUtils']
    assert 'ansible_collections.ansible_collections_module_utils.AnsibleModuleUtils' not in dep_finder.ps_modules

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#AnsibleRequires -PowerShell ansible_collections.ansible_collections_module_utils.AnsibleModuleUtils')

    assert not dep_finder.ps_modules['Ansible.ModuleUtils.AnsibleModuleUtils']

# Generated at 2022-06-22 20:07:07.065456
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder
    from ansible.module_utils.powershell import _slurp

    txt_data = '''
    #Requires -Module Ansible.ModuleUtils.Foo

    #AnsibleRequires -Powershell Ansible.ModuleUtils.Bar -Optional

    #AnsibleRequires -CSharpUtil ..module_utils.Bar
    #AnsibleRequires -CSharpUtil ansible_collections.blah.custom_utils.plugins.module_utils.Baz

    Write-Host "I am running!"
    '''
    b_data = to_bytes(txt_data)

    module_finder = PSModuleDepFinder()
    module_finder.scan_module(b_data)


# Generated at 2022-06-22 20:07:15.636546
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script('json_serializer')
    dep_finder.scan_exec_script('packer_detection')
    dep_finder.scan_exec_script('threaded_ping')
    dep_finder.scan_exec_script('winrs_connection')

    assert len(dep_finder.exec_scripts) == 4
    assert len(dep_finder.cs_utils_wrapper) > 1

# Generated at 2022-06-22 20:07:23.751236
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psf = PSModuleDepFinder()
    module_data = _slurp("../test/unit/modules/windows/test_win_ping.psm1")
    psf.scan_module(module_data, fqn="test.win_ping")

    # Assert correct number of module_utils added
    assert len(psf.ps_modules) == 2
    assert 'Ansible.ModuleUtils.Basic' in psf.ps_modules
    assert 'Ansible.ModuleUtils.Powershell' in psf.ps_modules
    
    # Assert that the collection util was found
    assert len(psf.cs_utils_module) == 1
    assert 'Microsoft.PowerShell.Utility.Text.Xml' in psf.cs_utils_module

    # Assert that the ps versions are correct

# Generated at 2022-06-22 20:07:26.961528
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    x = PSModuleDepFinder()
    x.scan_exec_script(wrapper_match.group(1).rstrip())

# Generated at 2022-06-22 20:07:29.894018
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)

# Exercise the method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:07:34.982587
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # CHECKME: Do we want to test the whole dependency graph or just a single module
    # with one dependency?
    import tempfile
    import os
    import shutil
    import random
    import string
    randomchars = ''.join(random.choice(string.ascii_letters) for _ in range(8))
    testdir = tempfile.mkdtemp(suffix='ansible_test_ps_dep_finder_%s' % randomchars, dir=os.path.dirname(__file__))

# Generated at 2022-06-22 20:07:43.412291
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    random_name = str(random.randint(0, 9999))
    try:
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(to_bytes('Ur_Wrong_Name_' + random_name))
    except AnsibleError:
        # Expected to get the AnsibleError here.
        # Do nothing here.
        pass
    else:
        raise AssertionError('PSModuleDepFinder should raise AnsibleError on wrong module name')



# Generated at 2022-06-22 20:07:53.623130
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    input = {
        'ps_module': '''
#!powershell
Get-ChildItem 
''',
        'cs_module': '''
using System;

public class Hello1
{
   public static void Main()
   {
      Console.WriteLine("Hello, World!");
   }
}
''',
    }
    want = {
        'ps_module': '''
Get-ChildItem 
''',
        'cs_module': '''
using System;

public class Hello1
{
   public static void Main()
   {
      Console.WriteLine("Hello, World!");
   }
}
''',
    }
    got = PSModuleDepFinder()
    got.scan_exec_script(input)

    assert got == want

# Generated at 2022-06-22 20:08:03.804167
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    a = PSModuleDepFinder()
    # The following should not throw an exception
    for x in [a.ps_modules, a.exec_scripts, a.cs_utils_wrapper, a.cs_utils_module]:
        assert isinstance(x, dict)
        assert not x
    assert a._re_cs_module
    assert a._re_cs_in_ps_module
    assert a._re_ps_module
    assert a._re_wrapper
    assert a._re_ps_version
    assert a._re_os_version
    assert a._re_become
    assert a.ps_version is None
    assert a.os_version is None
    assert not a.become


# Generated at 2022-06-22 20:08:06.982267
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert bool(finder)
    assert isinstance(finder, object)


# Generated at 2022-06-22 20:08:19.726466
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test to ensure that non-ps modules don't get scanned
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_module('TestCSModules', wrapper=True,
                                 powershell=False)
    assert not any(ps_module_finder.cs_utils_wrapper)
    # test to ensure that non-cs modules don't get scanned
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_module('TestPSModules', wrapper=True,
                                 powershell=False)
    assert not any(ps_module_finder.ps_modules)
    # normal test
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_module('TestPSModules')

# Generated at 2022-06-22 20:08:23.814281
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    This unit test will test the basic usage of the method scan_module of PSModuleDepFinder class.
    """
    pdm_dep_finder = PSModuleDepFinder()
    pdm_dep_finder.scan_module(data, fqn=None, wrapper=False, powershell=True)

# Generated at 2022-06-22 20:08:34.070421
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.loader.ps_module_utils_loader as mulu_loader
    plugin_loader._module_cache = {}
    mulu_loader._module_cache = {}

    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:36.240892
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()

# tests _add_module

# Generated at 2022-06-22 20:08:44.582749
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    powershell_wrapper_data = to_bytes(
                """# ansiblerequires -wrapper ansible_powershell_wrapper
# ansiblerequires -csharputil ansible.module_utils.basic
# ansiblerequires -powershell ansible.module_utils.parsing
""")
    powershell_module_data = to_bytes(
                """# ansiblerequires -powershell ansible.module_utils.basic
# ansiblerequires -csharputil ansible.module_utils.parsing""")

    psmodule_depfinder = PSModuleDepFinder()

    # The module_util 'ansible.module_utils.basic' will be added twice
    # One as PS module and one as CS wrapper module
    psmodule_depfinder.scan_exec_script("ansible_powershell_wrapper")
    psmodule_depfinder

# Generated at 2022-06-22 20:08:47.418916
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps = PSModuleDepFinder()
    assert isinstance(ps, PSModuleDepFinder)


# strip out comments from scripts for the exec wrappers

# Generated at 2022-06-22 20:08:52.871079
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test that constructor will properly set up the class variables
    assert PSModuleDepFinder().cs_utils_wrapper == dict()
    assert PSModuleDepFinder().cs_utils_module == dict()
    assert PSModuleDepFinder().ps_modules == dict()
    assert PSModuleDepFinder().exec_scripts == dict()


# Generated at 2022-06-22 20:08:56.020742
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_runner')
    dep_finder.exec_scripts.get('ansible_runner')
    assert dep_finder.exec_scripts.get('ansible_runner') is not None


# Generated at 2022-06-22 20:09:06.941547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # test that it finds the base64 module in the same package
    finder.scan_exec_script("base64")
    assert finder.exec_scripts
    assert "base64" in finder.exec_scripts
    assert finder.cs_utils_wrapper
    assert "Ansible.ModuleUtils.Powershell.Convert" in finder.cs_utils_wrapper

    # test that it finds the base64 module from a collection
    finder.scan_exec_script("ansible_collections.vmware.vmware_rest.plugins.executor.base64")
    assert len(finder.exec_scripts) == 2
    assert "ansible_collections.vmware.vmware_rest.plugins.executor.base64" in finder.exec_scripts

# Generated at 2022-06-22 20:09:17.118133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Mock out the get_data to return custom text/data.
    # On code change, this should be updated so the unit test is valid.
    def mock_get_data(*args, **kwargs):
        test_data = b"#Requires -Modules Ansible.ModuleUtils.Legacy"
        return test_data
    with patch('pkgutil.get_data', mock_get_data):
        finder = PSModuleDepFinder()
        finder.scan_exec_script('foo')
        assert finder.ps_modules == {"Ansible.ModuleUtils.Legacy": {"data": test_data, "path": "Ansible.ModuleUtils.Legacy.psm1"}}



# Generated at 2022-06-22 20:09:21.750512
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_powershell_stdlib")
    assert finder.exec_scripts
    assert finder.cs_utils_wrapper
    assert finder.ps_modules



# Generated at 2022-06-22 20:09:32.883667
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # These imports are required for unit testing.
    import packaging.version


# Generated at 2022-06-22 20:09:38.574297
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class MockPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            self.ps_modules = dict()
            self.exec_scripts = dict()
            self.cs_utils_wrapper = dict()
            self.cs_utils_module = dict()
            self.ps_version = None
            self.os_version = None
            self.become = False
            self._re_cs_module = [
                re.compile(u'(?i)^using\s((Ansible\..+)|'
                           u'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')
            ]

# Generated at 2022-06-22 20:09:45.311103
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp_mock(path):
        # The first element in the list is the input for the method
        # The second element is the output of the method
        slurp_outputs = [
            ("ansible_collections.ns.coll.plugins.modules.ping.ps1", b"this is a ps1 file"),
            ("ansible_collections.ns.coll.plugins.module_utils.test.ps1", b"this is a module_utils ps1 file"),
        ]
        return slurp_outputs[0][1]

    # Mock the _slurp method
    def _slurp_mock_decorator(function):
        def function_wrapper(path):
            return _slurp_mock(path)
        return function_wrapper

    # Monkey patch _slurp to provide deterministic

# Generated at 2022-06-22 20:09:57.459076
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    # This module doesn't contain any #Requires
    finder.scan_module(b'function test_module( $var1 ) {\n'
                       b'    Write-Host $var1\n'
                       b'}')
    assert finder.ps_modules == {}

    # This module contains a #Requires with optional and required utilities
    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:10:09.594433
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()
    assert ps_module_dep_finder.cs_utils_wrapper == dict()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert not ps_module_dep_finder.become

# Generated at 2022-06-22 20:10:20.877200
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create dummy ps1 file for the test and put it under executor folder
    # this test does not need to validate the content of the ps1 file
    # only check if the file is read properly
    executor_dir = os.path.dirname(os.path.realpath(__file__))
    dummy_file = os.path.join(executor_dir, "test.ps1")
    with open(dummy_file, "w") as f:
        f.writelines("This is test")

    # to_native is used internally to convert a string to file path
    # on windows, '/' is converted to '\'
    # on linux, '/' is used
    dummy_file = to_native(dummy_file)

    dep = PSModuleDepFinder()
    dep.scan_exec_script("test")
    #

# Generated at 2022-06-22 20:10:29.488110
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.common import PSModuleDepFinder
    from ansible import constants as C
    C.DEFAULT_DEBUG = False
    C.DEFAULT_KEEP_REMOTE_FILES = False
    psmodule_depfinder = PSModuleDepFinder()
    psmodule_depfinder.scan_exec_script('test_script')
    assert (psmodule_depfinder.exec_scripts['test_script'] == b"\x00")

# Generated at 2022-06-22 20:10:32.844207
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('net_facts')


# Generated at 2022-06-22 20:10:34.178532
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert(PSModuleDepFinder() is not None)


# Generated at 2022-06-22 20:10:40.603500
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    info = {
        'name': 'ansible_module_name',
        'args': 'ansible_module_args',
        'cwd': 'ansible_cwd',
        '_ansible_version': 'ansible_ansible_version',
        '_ansible_sysinfo': 'ansible_ansible_sysinfo',
        '_ansible_no_log': 'ansible_no_log'
    }

    # basic PS module
    # PS module contains '#Requires -Module Ansible.ModuleUtils.*'

# Generated at 2022-06-22 20:10:42.991543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    PSModuleDepFinder_instance = PSModuleDepFinder()

    name = ''
    PSModuleDepFinder_instance.scan_exec_script(name)



# Generated at 2022-06-22 20:10:49.603550
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert not ps_module_dep_finder.ps_modules
    assert not ps_module_dep_finder.exec_scripts
    assert not ps_module_dep_finder.cs_utils_wrapper
    assert not ps_module_dep_finder.cs_utils_module
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert not ps_module_dep_finder.become


# Generated at 2022-06-22 20:10:54.021917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.psmodule import PSModuleDepFinder
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("connection_winrm")
    depfinder.scan_exec_script("connection_winrm")
    assert(len(depfinder.exec_scripts) == 1)


# Generated at 2022-06-22 20:10:56.180515
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(to_text("base"))

# Generated at 2022-06-22 20:11:04.154466
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()


# Generated at 2022-06-22 20:11:16.418441
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    md = PSModuleDepFinder()

    # Test a module that has no dependencies

# Generated at 2022-06-22 20:11:20.678650
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md is not None
    assert md.ps_modules == {}
    assert md.cs_utils_wrapper == {}
    assert md.cs_utils_module == {}


# Generated at 2022-06-22 20:11:30.647126
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module == [
        re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]

# Generated at 2022-06-22 20:11:44.664840
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    from ansible.module_utils.powershell import _load_powershell_module_defs

    data = pkgutil.get_data('ansible.module_utils.powershell', 'Basic.psm1')
    m = re.search(b"^\[Version\([0-9]+(\.[0-9]+){0,3}\)\]", data, re.MULTILINE)
    version = None if m is None else to_text(m.group(0).rstrip(), errors='surrogate_or_strict')

    module_utility = PSModuleDepFinder()
    module_utility.scan_module(data)

    assert "Ansible.ModuleUtils.TestHelper" in module_utility.ps_modules

# Generated at 2022-06-22 20:11:57.541631
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    def _test_regex(finder):
        assert len(finder._re_cs_module) == 1

        pattern = r'^using\s((Ansible\..+)|' \
                  r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'
        assert finder._re_cs_module[0].pattern == pattern

        assert len(finder._re_cs_in_ps_module) == 1


# Generated at 2022-06-22 20:12:07.617402
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Coverage tests should generate a random 16 character string
    # to append to any resources used so that it is
    # unique per invocation
    rand = to_native(base64.b64encode(os.urandom(12), b'-_'))[:16]

    base_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_ps_module_dep_finder')
    os.makedirs(base_path)
    script_path = os.path.join(base_path, 'test_script%s.ps1' % rand)

    with open(script_path, 'wb') as script:
        script.write(to_bytes('''#Requires -Version 4.0
$var = Get-VersionVerbose
Write-Host $var.Major
'''))

    expected

# Generated at 2022-06-22 20:12:08.722051
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder


# Generated at 2022-06-22 20:12:15.182364
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a new PSModuleDepFinder object
    module_deps = PSModuleDepFinder()
    module_deps.scan_exec_script('ps_get_domain')
    assert len(module_deps.exec_scripts) == 1
    assert len(module_deps.ps_modules) == 2
    assert len(module_deps.cs_utils_wrapper) == 1


# Generated at 2022-06-22 20:12:24.497227
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert isinstance(dep.ps_modules, dict)
    assert isinstance(dep.exec_scripts, dict)
    assert isinstance(dep.cs_utils_wrapper, dict)
    assert isinstance(dep.cs_utils_module, dict)
    assert dep.ps_version is None
    assert dep.os_version is None
    assert dep.become is False
    assert isinstance(dep._re_cs_module, list)
    assert isinstance(dep._re_cs_module[0], re._pattern_type)
    assert isinstance(dep._re_ps_module, list)
    assert isinstance(dep._re_ps_module[0], re._pattern_type)
    assert isinstance(dep._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:12:30.672269
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('ansible_test_script')
    assert (psmdf.exec_scripts['ansible_test_script'].decode("utf-8") == pkgutil.get_data("ansible.executor.powershell", "ansible_test_script.ps1").decode("utf-8"))



# Generated at 2022-06-22 20:12:31.619077
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # @todo unit test for method scan_module of class PSModuleDepFinder
    pass


# Generated at 2022-06-22 20:12:42.459580
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of PSModuleDepFinder
    # module_data = '#Requires -Module Ansible.ModuleUtils.{name}'
    # fqn = 'ansible.module_utils.name'
    # wrapper = False
    # powershell = True
    psmd = PSModuleDepFinder()
    module_data = '#Requires -Module Ansible.ModuleUtils.{name}'
    fqn = 'ansible.module_utils.name'
    wrapper = False
    powershell = True
    # call the method scan_module
    psmd.scan_module(module_data, fqn, wrapper, powershell)

# Generated at 2022-06-22 20:12:55.346039
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.ps_modules = dict()
    finder.exec_scripts = dict()
    finder.cs_utils_wrapper = dict()
    finder.cs_utils_module = dict()
    finder.ps_version = None
    finder.os_version = None
    finder.become = False
    finder.scan_exec_script(['PS_Version_5'],'PS_Version_5')
    assert finder.ps_modules == {'PS_Version_5': {'data': b'# Script with PSVersion 5\n#Requires -Version 5.0\n', 'path': 'ansible.executor.powershell.PS_Version_5'}}

# Generated at 2022-06-22 20:12:58.162880
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # pd = PSModuleDepFinder()
    # pd.scan_exec_script("network")
    pass


# Generated at 2022-06-22 20:13:09.759918
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Object setup
    obj = PSModuleDepFinder()

    # In case of no requires
    m_data = b"#ANSIBLE_METADATA={\n#\t\"supported_by\": \"community\",\n#\t\"status\": [\n#\t\t\"preview\"\n#\t]\n#}"
    obj.scan_module(m_data)
    assert obj.ps_modules == {}
    assert obj.cs_utils_module == {}
    assert obj.become is False

    # In case of Requires -Module
    m_data = b"#Requires -Module Ansible.ModuleUtils.SomeModule"
    obj.scan_module(m_data)

# Generated at 2022-06-22 20:13:13.833633
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_template')
    assert 'powershell_template' in finder.exec_scripts
    assert 'powershell_template' in finder.ps_modules



# Generated at 2022-06-22 20:13:15.534924
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)



# Generated at 2022-06-22 20:13:23.706133
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Some test cases
    manual_test_cases = {}
    # Add your test cases here
    # manual_test_cases['test_case_name'] = {
    #     'module_data': '''
    #     #Requires -Module Ansible.ModuleUtils.{name}
    #     #Requires -Module Ansible.ModuleUtils.{name1}
    #     #Requires -Module Ansible.ModuleUtils.{name2}
    #     ''',
    #     'expected': {
    #         'cs_utils_module': {},
    #         'cs_utils_wrapper': {},
    #         'ps_modules': {},
    #         'exec_scripts': {},
    #         'ps_version': None,
    #         'os_version': None,
    #         'become': False

# Generated at 2022-06-22 20:13:35.865230
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("\nIn method test_PSModuleDepFinder_scan_module")
    finder = PSModuleDepFinder()
    finder.scan_module("""#Requires -Module Ansible.ModuleUtils.Powershell.Common
#Requires -Module Ansible.ModuleUtils.Powershell.IO
#Requires -Module Ansible.ModuleUtils.Legacy.Util
#Requires -Module Ansible.ModuleUtils.Powershell.Convert
#Requires -Module Ansible.ModuleUtils.Legacy.Version
#Requires -Module Ansible.ModuleUtils.Legacy.Process
""", "ansible.builtin.win_package")
    assert len(finder.ps_modules.keys()) == 7
    assert "Ansible.ModuleUtils.Powershell.Common" in finder.ps_modules.keys()
   

# Generated at 2022-06-22 20:13:39.105721
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # TODO: Implement tests
    assert True

# Code from https://stackoverflow.com/a/2117329

# Generated at 2022-06-22 20:13:42.803867
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_powershell')
    assert dep_finder.exec_scripts['ansible_powershell'] is not None



# Generated at 2022-06-22 20:13:49.573993
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert not dep_finder.ps_modules
    assert not dep_finder.exec_scripts
    assert not dep_finder.cs_utils_wrapper
    assert not dep_finder.cs_utils_module
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become == False

    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2


# Generated at 2022-06-22 20:14:01.134878
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    exec_script = "/path/to/powershell/module_utils/command.ps1"
    module_data = pkgutil.get_data("test_ps_module_deps", exec_script)
    if module_data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for '%s'" % exec_script)

    ps_module_deps = PSModuleDepFinder()
    ps_module_deps.scan_exec_script(exec_script)

    assert exec_script in ps_module_deps.exec_scripts

# Generated at 2022-06-22 20:14:10.456925
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False

    re_c_sharp_module = r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'


# Generated at 2022-06-22 20:14:23.120064
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os.path
    import pytest
    from collections import namedtuple

    PSModuleDepFinderObj = PSModuleDepFinder
    resource_path_tuple = namedtuple('ResourcePath', ('fqcr', 'path'))

# Generated at 2022-06-22 20:14:24.078864
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, 'Test not implemented'



# Generated at 2022-06-22 20:14:36.272832
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    import psutil
    import tempfile
    import shutil
    import pytest

    # create shell scripts with dependencies to use as modules
    modules_with_dependencies = {
        # name                        # requires               # requires               # requires
        'frobnicate': ['ansible.module_utils.basic',     'ansible.module_utils.urls', 'ansible.module_utils.parsing'],
        'unfrobnicate': ['ansible.module_utils.basic', 'ansible.module_utils.urls'],
    }

    # create C# code with dependencies to use as modules