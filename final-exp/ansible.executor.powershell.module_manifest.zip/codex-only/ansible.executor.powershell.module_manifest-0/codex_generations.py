

# Generated at 2022-06-22 20:04:34.164671
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  with pytest.raises(AnsibleError) as excinfo:
    finder = PSModuleDepFinder()
    finder.scan_module("")
    assert "Could not find imported module support code for 'Ansible.ModuleUtils.{name}'" in str(excinfo.value)


# Generated at 2022-06-22 20:04:47.288262
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:04:51.636192
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Constructor without parameters
    dep_finder = PSModuleDepFinder()

    assert dep_finder is not None

    assert len(dep_finder.ps_modules) == 0



# Generated at 2022-06-22 20:05:01.620397
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()

    assert md.ps_modules == dict()
    assert md.exec_scripts == dict()
    assert md.cs_utils_wrapper == dict()
    assert md.cs_utils_module == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert not md.become
    assert len(md._re_cs_module) == 1
    assert len(md._re_ps_module) == 2
    assert len(md._re_wrapper) == 1
    assert len(md._re_ps_version) == 1
    assert len(md._re_os_version) == 1
    assert len(md._re_become) == 1


# Generated at 2022-06-22 20:05:10.430947
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    import os
    import tempfile
    import shutil
    import traceback
    from ansible_galaxy.models.repository import get_repo_tmp_path
    from ansible_galaxy.models.repository import InstalledRepository
    from ansible_galaxy.models.repository import CacheContext
    from ansible_galaxy.models.collection_artifact import CollectionArtifact

    import ansible_galaxy.galaxy_exceptions as ge
    import ansible_galaxy.utils as utils

    log = utils.get_logger(__name__)

    # --
    # example
    # --

    tmp_dir = tempfile.mkdtemp(prefix='ansible_galaxy-unittest_main-')
    # FIXME: galaxy_context should be per test,

# Generated at 2022-06-22 20:05:15.391187
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test when name is present in exec_scripts
    # 0
    finder = PSModuleDepFinder()
    mock_name = 'test'
    finder.exec_scripts = {mock_name: 'test'}
    finder.scan_exec_script(mock_name)
    assert finder.exec_scripts == {mock_name: 'test'}
    # test when name is not present exec_scripts
    # 1
    finder = PSModuleDepFinder()
    finder.scan_exec_script(mock_name)
    assert finder.exec_scripts == {'command.ps1': b'powershell.exe -nologo -noexit -sta -NonInteractive -ExecutionPolicy Unrestricted -InputFormat None -File'}


# Generated at 2022-06-22 20:05:23.789731
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:05:25.667125
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TO DO
    return


# Generated at 2022-06-22 20:05:29.780253
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Test for method scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    # Test #1
    finder = PSModuleDepFinder()
    mod_data = """using SomeUtil;
using SomeOther;
using WhatEver.Foo
using ansible.module_utils.module_name
using ansible_collections.foo.bar.plugins.module_utils.something
using Ansible.ModuleUtils.Foo
"""

    finder.scan_module(mod_data, fqn="Full.Qual.Name")
    assert len(finder.ps_modules.keys()) == 0
    assert len(finder.cs_utils_module.keys()) == 4
    assert len(finder.cs_utils_wrapper.keys()) == 0

# Generated at 2022-06-22 20:05:35.397436
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == dict()
    assert f.exec_scripts == dict()
    assert f.cs_utils_wrapper == dict()
    assert f.cs_utils_module == dict()
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False


# Generated at 2022-06-22 20:05:40.960795
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('posh-winrm')
    assert (len(dep_finder.exec_scripts)==1)
    assert (len(dep_finder.exec_scripts.get('posh-winrm')) > 1 )
    assert (len(dep_finder.exec_scripts.get('posh-winrm')) == len(dep_finder.exec_scripts.get('posh-winrm')))


# Generated at 2022-06-22 20:05:52.256742
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:04.431471
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:05.672412
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
	pass


# Generated at 2022-06-22 20:06:13.805547
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depFinder = PSModuleDepFinder()
    depFinder.scan_module('#Requires -Module Ansible.ModuleUtils.Pester')
    assert 'Ansible.ModuleUtils.Pester' in depFinder.ps_modules, 'Ansible.ModuleUtils.Pester should be in the ps_modules'
    assert 'Ansible.ModuleUtils.Pester' not in depFinder.cs_utils_module, 'Ansible.ModuleUtils.Pester should not be in the cs_utils_module'

    depFinder.scan_module('#AnsibleRequires -PowerShell ansible_collections.microsoft.windows.plugins.module_utils.aem.aem_psmodule')
    assert 'ansible_collections.microsoft.windows.plugins.module_utils.aem.aem_psmodule'

# Generated at 2022-06-22 20:06:16.073881
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:06:17.579246
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder



# Generated at 2022-06-22 20:06:18.295011
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()


# Generated at 2022-06-22 20:06:22.124292
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script('Microsoft.PowerShell.Management')
    assert(psmd.exec_scripts['Microsoft.PowerShell.Management'])



# Generated at 2022-06-22 20:06:23.738358
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-22 20:06:31.492304
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    sample_cs_module = '''
using Ansible.ModuleUtils.{name};
using Ansible.ModuleUtils.{name};
using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};
using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};
using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};
using Ansible.ModuleUtils.{name};
using System.Management.Automation;
    '''.format(name="Network.Common", namespace="namespace", collection="collection")


# Generated at 2022-06-22 20:06:34.316177
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()

# return a base64 string suitable for embedding

# Generated at 2022-06-22 20:06:45.203960
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os 
    import re
    import json
    import shutil
    import tempfile

    from ansible.module_utils.common.powershell import get_ps_script_path, get_ps_version

    from ansible.module_utils.common.powershell_abstract import get_system_powershell_version
    from ansible.module_utils.common.process import is_executable_file_strict
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.json import to_json
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common._text import to_bytes, to_text
    from ansible.module_utils.common.powershell import module_manifest_to_dict

# Generated at 2022-06-22 20:06:50.930741
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
        finder = PSModuleDepFinder()
        name = "win_ping"
        finder.scan_exec_script(name)
        assert name in finder.exec_scripts


# Generated at 2022-06-22 20:07:00.364144
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:07:08.344550
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('update_opts')
    assert 'update_opts' in finder.exec_scripts.keys()
    assert 'unicode_wrap' in finder.ps_modules.keys()
    assert resource_from_fqcr(finder.ps_modules['unicode_wrap']['path'], 'ansible.module_utils') is not None
    assert not finder.become
    assert finder.ps_version is None
    assert finder.os_version is None


# Generated at 2022-06-22 20:07:09.573981
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p



# Generated at 2022-06-22 20:07:21.662047
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:07:33.966972
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Get an instance of the class
    obj = PSModuleDepFinder()
    # Constructor arguments
    module_data = pkgutil.get_data("ansible.modules.windows.win_copy", "ANSIBLE_MODULE_UTILS.psm1")
    # Method call (simulate validation.py passing a ps module)
    obj.scan_module(module_data, fqn="ansible.modules.windows.win_copy", wrapper=False, powershell=True)

    # Get an instance of the class
    obj = PSModuleDepFinder()
    # Constructor arguments
    module_data = pkgutil.get_data("ansible.plugins.action.copy", "copy.ps1")
    # Method call (simulate validation.py passing a ps module)

# Generated at 2022-06-22 20:07:46.987077
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:07:52.496094
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected_ps_version = '1.2.3'
    expected_os_version = '10.0.123'
    expected_become = True

    finder = PSModuleDepFinder()

    # mock the module data, this should match the executor powershell script in _test_data

# Generated at 2022-06-22 20:08:01.074367
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the _read_module_text method.
    file_path = 'module_utils_module.psm1'
    with open(file_path, 'rb') as f:
        content = f.read()

    util = PSModuleDepFinder()
    util.scan_module(content)

    assert util.ps_modules['Ansible.ModuleUtils.Powershell.Facts']['data'] == _slurp('module_utils_module.psm1.dep')
    assert util.ps_modules['Ansible.ModuleUtils.Powershell.Facts']['path'] == 'module_utils_module.psm1.dep'

    # This util is marked as optional, so it shouldn't be included in the results.

# Generated at 2022-06-22 20:08:13.573641
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Given a module and the location of where it can be found on disk
    # the scan_module method should scan the file for any PS module dependencies.
    # These dependencies are converted to text (.psm1 extensions) and their
    # contents are scanned for any more dependencies. This allows a user to
    # write inline powershell in a python module.
    ps_finder = PSModuleDepFinder()

    module_data = b"#Requires -Module Ansible.ModuleUtils.TestModule"
    fqn = 'ansible_collections.my_ns.my_coll.plugins.modules.my_module'

    ps_finder.scan_module(module_data, fqn=fqn)

    assert len(ps_finder.ps_modules.keys()) == 1

# Generated at 2022-06-22 20:08:15.365566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for scan_exec_script() without a wrapper
    assert 0


# Generated at 2022-06-22 20:08:27.589124
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    str_data = u'''#Requires -Module Ansible.ModuleUtils.Facter
#Requires -Module ansible_collections.ns.coll.plugins.module_utils.something
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Facter
#AnsibleRequires -PowerShell Ansible.ModuleUtils.SomethingElse
#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.something
#AnsibleRequires -PowerShell ..module_utils.something_else
#AnsibleRequires -PowerShell ..module_utils.something_else -Optional
#AnsibleRequires -CSharpUtil ..module_utils.something
'''
    psmdf = PSModuleDepFinder()
    # scan module returns nothing

# Generated at 2022-06-22 20:08:40.012592
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def _strip_comments(data):
        data = to_bytes(data)
        # remove non-terminating comments so we can turn them into
        # terminating comments to avoid having to process the data to
        # find the end of a line
        data = re.sub(br'(\s*#[^$].*)\r?', br'\1\n', data)
        # turn non-terminating comments into terminating ones
        data = re.sub(br'(\s*#.*)\n', br'\1\n#', data)
        # remove all other comments and blank lines
        data = re.sub(br'^\s*#.*\n?', b'', data)
        data = re.sub(br'^\s*\n', b'', data)
        return data


# Generated at 2022-06-22 20:08:49.648202
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a test for defect PS#6518
    def mock_get_data_executor_powershell(*args, **kwargs):
        return "test"

    finder = PSModuleDepFinder()
    name = "test"
    finder.scan_exec_script(name)
    if name in finder.exec_scripts:
        assert True
    else:
        assert False


    # Set the pkgutil.get_data to a custom method to get the behavior
    # we want.
    pkgutil.get_data = mock_get_data_executor_powershell
    name = "test"
    try:
        finder.scan_exec_script(name)
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-22 20:09:00.355809
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
    Unit test for method scan_module of class PSModuleDepFinder
    '''
    test_file_name = "test_PSModuleDepFinder_scan_module.psm1"
    test_data = "#AnsibleRequires -Powershell Ansible.ModuleUtils.Utils.psm1\n"
    test_file = open(test_file_name, "w")
    test_file.write(test_data)
    test_file.close()
    C.DEFAULT_MODULE_UTILS_PATH = os.path.dirname(test_file_name)

# Generated at 2022-06-22 20:09:11.678505
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_path = os.path.join(
        to_text(os.path.dirname(__file__), errors='surrogate_or_strict'),
        'data', 'module_utils', 'test_module.ps1'
    )
    test_module = to_bytes(_slurp(test_module_path), errors='surrogate_or_strict')

    depfinder = PSModuleDepFinder()
    depfinder.scan_module(test_module, fqn='test_module', wrapper=False, powershell=True)

    assert 'Ansible.ModuleUtils.TestModuleUtil' in depfinder.ps_modules.keys()



# Generated at 2022-06-22 20:09:20.905688
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    finder = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", to_native("executor.ps1"))

    finder.scan_exec_script("executor")
    csum = _get_py_csum(to_bytes(data))
    wrapped_csum = _get_py_csum(finder._add_exec_script_wrapper(to_bytes(data)))
    assert csum != wrapped_csum

# Generated at 2022-06-22 20:09:26.643948
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    result = PSModuleDepFinder().scan_module(b'using ansible_collections.oracle.oci.plugins.module_utils.oci_helpers;\n')
    assert result == {'ansible_collections.oracle.oci.plugins.module_utils.oci_helpers': {'path': 'ansible_collections/oracle/oci/plugins/module_utils/oci_helpers.psm1', 'data': b'Import-Module ansible.builtin.datetime\n\n'}}


# Generated at 2022-06-22 20:09:31.024482
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


_NON_COMMENT_RE = re.compile(br'#.*$|^\s*$')



# Generated at 2022-06-22 20:09:41.350512
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_module[0].pattern) > 0
    assert finder._re_cs_module[0].pattern.startswith(b'(?i)^using\\s((Ansible\\.')
    assert finder._re_cs_module[0].pattern.endswith(b'plugins\\.module_utils\\.[\\w\\.]+));\\s*$')


# Generated at 2022-06-22 20:09:46.450615
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    test_exec_script_is_added()
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible')
    assert len(dep_finder.cs_utils_wrapper) > 0


# Generated at 2022-06-22 20:09:49.006779
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Currently we have no way to unit test this class.
    pass

# helper to return the contents of a file as bytes

# Generated at 2022-06-22 20:10:01.247835
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import sys
    sys.path.insert(0, os.getcwd())

    ps_module_dep_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:10:03.585668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    test_obj.scan_exec_script("zzz123")



# Generated at 2022-06-22 20:10:08.585451
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # idb_path = pkgutil.get_data("ansible.module_utils.powershell.Ansible.ModuleUtils", "idb_template.ps1")
    module_data = AnsibleModule.load_module_data(module_name="iam_trail", module_args="")

    # ps_module_finder = PSModuleDepFinder()
    # ps_module_finder.scan_module(module_data, fqn="AWS.PowerShell.cloudtrail", powershell=True)
    # ps_module_finder.scan_module(module_data, fqn="AWS.PowerShell.cloudtrail", powershell=False)
    # ps_module_finder.scan_module(module_data, fqn="AWS.PowerShell.cloudtrail", wrapper=True, powershell=True)

# Generated at 2022-06-22 20:10:20.118711
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:10:32.779061
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    modules = """#Requires -Module Ansible.ModuleUtils.MyUtil
#Requires -Module ansible_collections.namespace.collection.plugins.module_utils.AnotherUtil
#Requires -Module Ansible.ModuleUtils.MyUtil2
#Requires -Module ansible_collections.namespace.collection.plugins.module_utils.AnotherUtil2
"""
    ps_modules = dict.fromkeys([
        "Ansible.ModuleUtils.MyUtil",
        "Ansible.ModuleUtils.MyUtil2",
    ])
    cs_modules = dict.fromkeys([
        "ansible_collections.namespace.collection.plugins.module_utils.AnotherUtil",
        "ansible_collections.namespace.collection.plugins.module_utils.AnotherUtil2",
    ])

    psm

# Generated at 2022-06-22 20:10:39.810223
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Ensure that PSModuleDepFinder.scan_module returns correct results.
    """
    psmdf = PSModuleDepFinder()

    test_data = b"""
        using System;
        using System.Collections.Generic;
        using System.Management.Automation;

        using ansible_collections.namespace.collection.plugins.module_utils.some_utils;
        using Ansible.ModuleUtils.Some_other_util;

        #Requires -Module Ansible.ModuleUtils.Some_util
        #Requires -Module Ansible.ModuleUtils.Some_other_util

        namespace Ansible.Some_namespace {
        }
  """

    psmdf.scan_module(test_data)

    assert len(psmdf.ps_modules) == 2

# Generated at 2022-06-22 20:10:50.483407
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    PSModuleDepFinder._add_module = lambda self, name, ext, fqn, optional, wrapper=False: True
    PSModuleDepFinder.scan_module(PSModuleDepFinder, b"#Requires -Module Ansible.ModuleUtils.Test", fqn="Test", wrapper=False, powershell=True)
    PSModuleDepFinder.scan_module(PSModuleDepFinder, b"#Requires -Module Ansible.ModuleUtils.Test", fqn="Test", wrapper=False, powershell=False)
    PSModuleDepFinder.scan_module(PSModuleDepFinder, b"#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.Test", fqn="Test", wrapper=False, powershell=True)
    PSModuleDepFinder.scan_

# Generated at 2022-06-22 20:11:00.038941
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:12.841853
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()

    assert len(psModuleDepFinder.ps_modules) == 0
    assert len(psModuleDepFinder.cs_utils_wrapper) == 0
    assert len(psModuleDepFinder.cs_utils_module) == 0
    assert len(psModuleDepFinder.exec_scripts) == 0


# Generated at 2022-06-22 20:11:22.767599
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.parsing.yaml.objects import AnsibleMapping

    def _get_base_module_data(powershell):
        if powershell:
            module_data = file = "# ANSIBLE_METADATA\n"
            module_data += "# ================\n"
            module_data += "# metadata_version: '2.1'\n"
            module_data += "# powershell: '5.1'\n"
            module_data += "# import_version: '2.0.0'\n"
            module_data += "# short_description: Some test module\n"
            module_data += "# author: Author\n"
            module_data += "# description: Longer test description\n"
            module_data += "# options:\n"

# Generated at 2022-06-22 20:11:33.893796
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:45.839229
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

# Generated at 2022-06-22 20:11:58.696048
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder

    finder = AnsibleCollectionFinder()

    current_dir = os.path.dirname(os.path.abspath(__file__))
    collection_paths = [os.path.join(current_dir, "../../../../../galaxy/ansible-collections/ansible_collections/collection1"),
                        os.path.join(current_dir, "../../../../../galaxy/ansible-collections/ansible_collections/collection2")]

    loader = AnsibleCollectionLoader(finder, collection_paths)
    action_loader._create

# Generated at 2022-06-22 20:12:06.882307
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Just check that we don't hit any exceptions for each module we scan.
    finder = PSModuleDepFinder()
    for module in C.MODULE_UTILS_PATH:
        for file_name in os.listdir(module):
            if not file_name.endswith('.psm1'):
                continue

            full_path = os.path.join(module, file_name)
            finder.scan_module(_slurp(full_path))


# Generated at 2022-06-22 20:12:09.686438
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script("script1")


# Generated at 2022-06-22 20:12:11.452886
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-22 20:12:17.091318
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Without any module data, initialization of the PSModuleDepFinder class
    ensures that all dictionaries and other class attributes are
    initialized properly.
    """
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False



# Generated at 2022-06-22 20:12:27.269640
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # test wrapper
    finder.scan_exec_script("Test")
    assert finder.exec_scripts['Test'] == to_bytes(_slurp("lib/ansible/executor/powershell/Test.ps1"))
    assert finder.cs_utils_wrapper['Ansible.ModuleUtils.Pester']['data'] == to_bytes(pkgutil.get_data("ansible.executor.powershell", "Ansible.ModuleUtils.Pester.psm1"))
    assert finder.cs_utils_wrapper['Ansible.ModuleUtils.Pester']['path'] == to_text("lib/ansible/executor/powershell/Ansible.ModuleUtils.Pester.psm1")
    assert finder.ps_version is None


# Generated at 2022-06-22 20:12:37.321926
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    if os.path.isdir(C.DEFAULT_LOCAL_TMP) and os.access(C.DEFAULT_LOCAL_TMP, os.W_OK):
        C.C.DEFAULT_LOCAL_TMP = C.DEFAULT_LOCAL_TMP
    else:
        C.C.DEFAULT_LOCAL_TMP = "/tmp"

    C.C.DEFAULT_REMOTE_TMP = "/tmp"

    try:
        dep_finder = PSModuleDepFinder()
    except Exception as err:
        print("Failed to instantiate PSModuleDepFinder exception: %s" % err)
        assert False

    assert dep_finder is not None



# Generated at 2022-06-22 20:12:42.672253
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    try:
        finder.scan_exec_script('foo')
    except AnsibleError:
        pass
    else:
        raise Exception("Exception not raised when attempting to scan for a non-existent script")



# Generated at 2022-06-22 20:12:55.566291
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert isinstance(ps_module_dep_finder._re_cs_module, list)
    assert isinstance(ps_module_dep_finder._re_cs_in_ps_module, list)
    assert isinstance

# Generated at 2022-06-22 20:13:08.145037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    # It calls the scan_exec_script method at least once
    module_data = to_bytes("#AnsibleRequires -Wrapper some_name")
    dep_finder.scan_exec_script = MagicMock(name="scan_exec_script")
    dep_finder.scan_module(module_data, wrapper=True, powershell=True)
    dep_finder.scan_exec_script.assert_called_once_with(to_text("some_name"))

    dep_finder.scan_exec_script.reset_mock()

    # With no data
    dep_finder.scan_module(None, wrapper=True, powershell=True)
    assert not dep_finder.scan_exec_script.called

    dep_finder.scan_exec_script.reset_mock()

# Generated at 2022-06-22 20:13:10.517779
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pmdf = PSModuleDepFinder()
    pmdf.scan_exec_script("Logging")


# Generated at 2022-06-22 20:13:12.547637
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_mod_finder = PSModuleDepFinder()



# Generated at 2022-06-22 20:13:20.905331
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test Cases for scan_module method
    
    # test case for powershell module with #requires
    test_module_data ="#Requires -Module Ansible.ModuleUtils.AAA\n#Requires -Module Ansible.ModuleUtils.BBB\n#Requires -Module Ansible.ModuleUtils.BBB\n" 
    test_obj = PSModuleDepFinder()
    test_obj.scan_module(test_module_data, fqn="test", wrapper=False, powershell=True)
    assert len(test_obj.ps_modules.keys()) == 2
    assert sorted(test_obj.ps_modules.keys()) == ["AAA", "BBB"]

    # test case for powershell module with #ansiblerequires

# Generated at 2022-06-22 20:13:33.725214
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    for line in lines:
        for check in checks:
            for pattern in check[0]:
                match = pattern.match(line)
                if match:
                    # tolerate windows line endings by stripping any remaining
                    # newline chars
                    module_util_name = to_text(match.group(1).rstrip())
                    match_dict = match.groupdict()
                    optional = match_dict.get('optional', None) is not None

                    if module_util_name not in check[1].keys():
                        module_utils.add((module_util_name, check[2], fqn, optional))

                    break

        if powershell:
            ps_version_match = self._re_ps_version.match(line)

# Generated at 2022-06-22 20:13:38.413297
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()

    depfinder.scan_exec_script("Ansible.PowerShell.AnsibleModule")
    assert depfinder.exec_scripts["Ansible.PowerShell.AnsibleModule"] is not None
    assert depfinder.ps_modules["Ansible.ModuleUtils.Common"] is not None


# Generated at 2022-06-22 20:13:46.403952
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('win_module_async_wrapper')
    assert psmdf.exec_scripts
    assert len(psmdf.exec_scripts) == 1
    assert 'win_module_async_wrapper' in psmdf.exec_scripts
    assert psmdf.ps_modules
    assert len(psmdf.ps_modules) == 1
    assert 'Ansible.ModuleUtils.Powershell' in psmdf.ps_modules


# Generated at 2022-06-22 20:13:48.923928
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script("Get-ANSIBLEVersion")



# Generated at 2022-06-22 20:14:00.478431
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    import unittest
    from collections import defaultdict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_text
    from ansible.module_utils.compat.ipaddress import ip_address

    class PSModuleDepFinderTest(unittest.TestCase):

        def test__add_module(self):
            from ansible_collections.ns.coll.plugins.module_utils.module_utils_1 import Foo
            from ansible_collections.ns.coll.plugins.module_utils.module_utils_2 import Bar

            # Will create a new instance of PSModuleDepFinder (and __init__ will be called)
            self.frontend = AnsibleModule(argument_spec=defaultdict(lambda: defaultdict(lambda: defaultdict(dict))))


# Generated at 2022-06-22 20:14:09.829014
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2
    assert dep_finder._re_ps_version.match("#requires -version 1")
    assert dep_finder._re_ps_version.match("#requires -version 1.2")
    assert dep_finder._re_ps_version.match("#requires -version 1.2.3")
    assert dep_finder._re_ps_version.match("#requires -version 1.2.3.4")
    assert dep_finder._re_ps_version.match("#requires -version 1.2.3.4.5")
    assert dep_finder._re

# Generated at 2022-06-22 20:14:14.219968
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: This is pretty hard to unit test as it requires too much setup
    p = PSModuleDepFinder()
    p.scan_exec_script("await")


# Generated at 2022-06-22 20:14:24.225773
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import io
    import io
    test_module_util = io.BytesIO(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Util1\nsome script')
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_module(test_module_util.read())

    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Util1']['data'].decode('utf-8') == "#Requires -Module PowerShellGet\n#Requires -Module PowerShell.Modules\n#Requires -Module PowerShell.SemanticLogging\n#Requires -Module PowerShell.VersionRecognizer", "Test PSModuleDepFinder constructor failed"


# Generated at 2022-06-22 20:14:31.671133
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    m = PSModuleDepFinder()
    assert isinstance(m, PSModuleDepFinder)
    assert m.ps_modules == {}
    assert m.exec_scripts == {}
    assert m.cs_utils_wrapper == {}
    assert m.cs_utils_module == {}
    assert m.ps_version is None
    assert m.os_version is None
    assert m.become is False
