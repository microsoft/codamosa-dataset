

# Generated at 2022-06-22 20:04:43.438987
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    ps_dep_finder = PSModuleDepFinder()
    text_expected = "Hello world"
    data = to_bytes(text_expected)
    name = "test"
    path = "ansible/executor/powershell/test.ps1"
    pkg_data = { path: data}
    pkgutil.get_data = MagicMock(side_effect=lambda package,resource: pkg_data[package+'/'+resource])

    # Act
    ps_dep_finder.scan_exec_script(name)

    # Assert
    assert ps_dep_finder.exec_scripts[name] == data


# Generated at 2022-06-22 20:04:51.367034
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    m = PSModuleDepFinder()
    assert m.ps_modules == dict()
    assert m.exec_scripts == dict()

    assert m.cs_utils_wrapper == dict()
    assert m.cs_utils_module == dict()

    assert m.ps_version is None
    assert m.os_version is None
    assert m.become is False

    assert m._re_ps_module is not None
    assert m._re_cs_in_ps_module is not None

    assert m._re_cs_module is not None
    assert m._re_wrapper is not None
    assert m._re_ps_version is not None
    assert m._re_os_version is not None
    assert m._re_become is not None


# Generated at 2022-06-22 20:05:01.973887
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    expected = b'function Empty(){}'
    data = finder.scan_exec_script("empty")
    assert data == expected, "%s != %s" % (data, expected)

    expected = b'function Get-FileSize{'
    data = finder.scan_exec_script("Get-FileSize")
    assert data[:27] == expected, "%s != %s" % (data[:27], expected)

    # This is testing to make sure a util is only added once
    expected_len = len(finder.ps_modules)
    data = finder.scan_exec_script("Get-FileSize")
    assert len(finder.ps_modules) == expected_len, "%s != %s" % (len(finder.ps_modules), expected_len)



# Generated at 2022-06-22 20:05:10.607329
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = " # Requires -Module Ansible.SomeModule\n"

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)

    assert dep_finder.ps_modules['ansible.somemodule']['data'].startswith(b'\xef\xbb\xbf<#')

    # Constructor should always initialize ps_modules and cs_utils_module
    assert isinstance(dep_finder.ps_modules, dict)
    assert isinstance(dep_finder.cs_utils_module, dict)


# Generated at 2022-06-22 20:05:12.871624
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_util_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:05:19.987328
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = '#AnsibleRequires -PowerShell Ansible.ModuleUtils.TestModule\n'\
                  '#AnsibleRequires -CSharpUtil TestUtil'
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(to_bytes(module_data))
    assert 'ansible.module_utils.testmodule' in ps_module_dep_finder.ps_modules.keys()
    assert 'ansible_collections.namespace.collection.plugins.module_utils.testutil' in ps_module_dep_finder.cs_utils_module.keys()



# Generated at 2022-06-22 20:05:21.375144
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    #with pytest.raises(Exception):
    assert True

# Generated at 2022-06-22 20:05:35.119177
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module = pkgutil.get_data("ansible.modules.system.win_reboot", to_native("main.py"))
    module_data = to_bytes(module)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_finder.become
    assert b"Ansible.Windows.Powershell" in dep_finder.ps_modules
    assert b"Ansible.Windows.ScheduledTask" in dep_finder.ps_modules
    assert b"Ansible.Windows.WinEventLog" in dep_finder.ps_modules
    assert b"Ansible.Windows.WinReg" in dep_finder.ps_modules
    assert b"Ansible.Windows.WinRM" in dep_finder.ps_modules

# Generated at 2022-06-22 20:05:48.233608
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Unit test for method scan_module and utility method _add_module of class PSModuleDepFinder
    """
    ps_module_dep_finder = PSModuleDepFinder()
    
    # case: .cs module contains 'using Ansible.ModuleUtil.*'
    mock_name = "Ansible.ModuleUtil.test_module_util"
    mock_ext = ".cs"
    ps_module_dep_finder.ps_modules = {}
    ps_module_dep_finder.scan_module("using " + mock_name + ";", fqn=mock_name, wrapper=False, powershell=False)
    assert mock_name in ps_module_dep_finder.ps_modules

    # case: .psm1 module contains '#AnsibleRequires -CSharpUtil ansible_collections.test

# Generated at 2022-06-22 20:06:00.860968
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()
    assert ps_module_dep_finder.cs_utils_wrapper == dict()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become == False
    assert isinstance(ps_module_dep_finder._re_cs_module, list)
    assert isinstance(ps_module_dep_finder._re_cs_in_ps_module, list)

# Generated at 2022-06-22 20:06:11.220679
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:16.073902
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert hasattr(PSModuleDepFinder, 'scan_module')
    assert hasattr(PSModuleDepFinder, 'scan_exec_script')


# Generated at 2022-06-22 20:06:20.253909
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ps_base')
    assert 'ps_base' in dep_finder.exec_scripts.keys()


# Generated at 2022-06-22 20:06:30.658989
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method with an empty module_data parameter.
    # Arrange
    m_obj = PSModuleDepFinder()
    module_data = b""
    fqn = None
    wrapper = False
    powershell = True
    expected_result = 0

    # Act
    m_obj.scan_module(module_data, fqn, wrapper, powershell)
    actual_result = len(m_obj.ps_modules)

    # Assert
    assert expected_result == actual_result

    # Test the scan_module method with an invalid module_util import statement.
    # Arrange
    m_obj = PSModuleDepFinder()
    module_data = b"using ABCD.EFG;\n"
    fqn = None
    wrapper = False
    powershell = True

    # Act

# Generated at 2022-06-22 20:06:39.006112
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup
    psmdf = PSModuleDepFinder()

    # Exercise
    psmdf.scan_exec_script("common")

    # Verify
    assert len(psmdf.exec_scripts) == 1
    assert psmdf.exec_scripts["common"]
    assert len(psmdf.ps_modules) == 1
    assert psmdf.ps_modules["Ansible.ModuleUtils.Common"]["data"]


# Generated at 2022-06-22 20:06:39.733964
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:06:47.459709
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module = _module_util_module()
    name = 'testmodule'
    wrapper = False
    powershell = True
    fqn = None
    optional = False
    ext = '.psm1'
    m = PSModuleDepFinder()
    m._add_module(name, ext, fqn, optional, wrapper)
    assert m.ps_modules['testmodule']['path'].endswith('testmodule.psm1')
    assert m.ps_modules['testmodule']['data'] == module

    module_data = _slurp('testmodule.psm1')
    m.scan_module(module_data, fqn, wrapper, powershell)
    assert m.ps_modules['testmodule']['path'].endswith('testmodule.psm1')

# Generated at 2022-06-22 20:06:58.081582
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test1')
    assert(md.ps_modules['Ansible.ModuleUtils.Test1']['path'] == "./test/units/module_utils/test1.psm1")
    assert(b'#Requires -Module Ansible.ModuleUtils.Test1' not in md.ps_modules['Ansible.ModuleUtils.Test1']['data'])
    assert(b'#Requires -Module Ansible.ModuleUtils.Test2' in md.ps_modules['Ansible.ModuleUtils.Test1']['data'])

    md.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test3')

# Generated at 2022-06-22 20:07:03.045735
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.connection import Connection
    dep_finder = PSModuleDepFinder()
    conn = Connection("local://")
    dep_finder.scan_exec_script("executor/script_wrapper")

    # Returns nothing and has no side effects
    dep_finder.scan_exec_script("executor/script_wrapper")



# Generated at 2022-06-22 20:07:08.509478
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # code borrowed from unit test from validate-modules.
    # This is a duplicate of the constructor.
    f = PSModuleDepFinder()
    assert type(f.ps_modules) is dict
    assert type(f.exec_scripts) is dict
    assert type(f.cs_utils_wrapper) is dict
    assert type(f.cs_utils_module) is dict



# Generated at 2022-06-22 20:07:11.954375
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes('''#AnsibleRequires -PowerShell Ansible.Builtin.AnsibleModuleUtil'''))
    assert dep_finder.ps_modules['Ansible.Builtin.AnsibleModuleUtil'] is not None


# Generated at 2022-06-22 20:07:15.855835
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder_object = PSModuleDepFinder()
    assert ps_module_dep_finder_object is not None

# Helper function for unit test for scan_module function of class PSModuleDepFinder.

# Generated at 2022-06-22 20:07:23.101374
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # initialize the class
    # param: 1. powershell module data
    #        2. the name of the powershell module (nested modules will have a
    #           different name than the file itself)
    #        3. determines whether to scan the ps module for C# utils that are
    #           referenced
    #        4. determines whether to look for a wrapper reference
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.One', 'Ansible.BuildTools.Tools')
    dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Awesome', 'Ansible.BuildTools.Tools')

# Generated at 2022-06-22 20:07:23.962822
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder().__class__ == PSModuleDepFinder


# Generated at 2022-06-22 20:07:35.918872
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # random version to compare in dictionary
    random_v = random.randint(1, 100000000)
    # create a instance of PSModuleDepFinder
    psModuleDepFinder = PSModuleDepFinder()
    # If a script is not provided, the function should return nothing
    assert psModuleDepFinder.scan_exec_script('') == None
    # Random Name to test the function
    random_name = 'random_'+str(random_v)
    # Check if the script is found in the directory ansible/executor/powershell
    assert psModuleDepFinder.scan_exec_script(random_name) == None
    # The scan_module function is called from scan_exec_script with parameters
    # psModuleDepFinder: instance of class PSModuleDepFinder
    # random_name : Name of the script
   

# Generated at 2022-06-22 20:07:38.162823
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-22 20:07:48.041289
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_object = PSModuleDepFinder()

    assert test_object.ps_modules == dict()
    assert test_object.exec_scripts == dict()
    assert test_object.cs_utils_wrapper == dict()
    assert test_object.cs_utils_module == dict()
    assert test_object.ps_version is None
    assert test_object.os_version is None
    assert test_object.become is False
    assert isinstance(test_object._re_cs_module, list)
    assert isinstance(test_object._re_cs_in_ps_module, list)
    assert isinstance(test_object._re_ps_module, list)
    assert isinstance(test_object._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:07:58.576953
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md.ps_modules == dict()
    assert md.cs_utils_wrapper == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False
    assert len(md._re_cs_module) == 1
    assert md._re_cs_module[0].pattern == to_bytes(r"(?i)^using\s((Ansible\..+)|"
                                                   r"(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$")
    assert len(md._re_cs_in_ps_module) == 1

# Generated at 2022-06-22 20:08:11.245220
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:18.868297
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == dict()
    assert f.exec_scripts == dict()
    assert f.cs_utils_wrapper == dict()
    assert f.cs_utils_module == dict()
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False
    assert len(f._re_cs_module) == 1
    assert len(f._re_cs_in_ps_module) == 1
    assert len(f._re_ps_module) == 2
    assert f._re_wrapper is not None
    assert f._re_ps_version is not None
    assert f._re_os_version is not None
    assert f._re_become is not None



# Generated at 2022-06-22 20:08:29.922673
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # Regular case
    finder.scan_exec_script("powershell_executor")

    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1
    assert finder.ps_modules["ansible.module_utils.ansible_release"] is not None
    assert finder.ps_modules["ansible.module_utils.ansible_release"]["path"] == "ansible_powershell_module_utils.psm1"
    assert finder.exec_scripts["powershell_executor"] is not None
    assert len(finder.exec_scripts["powershell_executor"]) > 0

    # Call again to make sure it doesn't add the same module_util
    finder.scan_exec_script("powershell_executor")



# Generated at 2022-06-22 20:08:42.505570
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mu1_text = '#Requires -Module Ansible.ModuleUtils.Main\n'
    mu2_text = '#Requires -Module Ansible.ModuleUtils.Sub\n'
    mu3_text = 'import-module Ansible.ModuleUtils.Sub\n'
    mu4_text = '#Requires -Module ansible_collections.namespace1.collection1.plugins.module_utils.Sub\n'
    mu5_text = '#Requires -Module ansible_collections.namespace1.collection1.plugins.module_utils.Sub -Optional'
    mu6_text = '#Requires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.Sub -Optional'

# Generated at 2022-06-22 20:08:52.914793
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # load a ps module and its deps

# Generated at 2022-06-22 20:09:03.823178
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:05.048882
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:09:15.458415
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    single_ref_module = u"""#! /usr/bin/env powershell
# Requires -Module Ansible.ModuleUtils.Foo
# Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz
"""

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes(single_ref_module))
    assert dep_finder.ps_modules[u"Ansible.ModuleUtils.Foo"]
    assert dep_finder.ps_modules[u"Ansible.ModuleUtils.Bar"]
    assert dep_finder.ps_modules[u"Ansible.ModuleUtils.Baz"]



# Generated at 2022-06-22 20:09:27.316345
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    fqn = 'ansible_collections.community.general.plugins.modules.win_copy'
    package_name = to_native(fqn, errors='surrogate_or_strict')
    module_util_loader = resource_from_fqcr(fqn)
    module_base_path = os.path.join(module_util_loader.package_path, 'plugins', 'modules', 'win_copy.psm1')

    try:
        data = _slurp(module_base_path)
    except Exception as err:
        raise AnsibleError("Could not find module '%s' for dependency check: %s" % (package_name, to_native(err)))

    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:09:33.935455
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert not finder.ps_modules
    assert not finder.cs_utils_wrapper
    assert not finder.cs_utils_module
    assert not finder.exec_scripts
    assert not finder.ps_version
    assert not finder.os_version
    assert not finder.become


# Create a module file to test the PSModuleDepFinder finder methods

# Generated at 2022-06-22 20:09:40.083512
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    assert isinstance(PSModuleDepFinder().ps_modules, Mapping)
    assert isinstance(PSModuleDepFinder().exec_scripts, Mapping)
    assert isinstance(PSModuleDepFinder().cs_utils_wrapper, Mapping)
    assert isinstance(PSModuleDepFinder().cs_utils_module, Mapping)
    assert PSModuleDepFinder().ps_version is None
    assert PSModuleDepFinder().os_version is None
    assert not PSModuleDepFinder().become
    assert isinstance(PSModuleDepFinder()._re_cs_module, list)
    assert isinstance(PSModuleDepFinder()._re_cs_module[0], re.Pattern)

# Generated at 2022-06-22 20:09:46.121787
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_arg = "key"
    test_item_key = "list"
    test_item_list = ["test1", "test2"]
    test_item = {test_item_key: test_item_list}
    test_dict = {test_arg: test_item}

    def _slurp_mock(filename):
        return b"test"

    def _import_module_mock(name):
        return import_module(name)

    pkgutil.get_data = _slurp_mock
    import_module = _import_module_mock

    # run method and assert on results
    target = PSModuleDepFinder()
    target.scan_module(test_arg, test_arg, test_arg)

    # assert results

# Generated at 2022-06-22 20:09:58.478688
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of the class we want to test
    psmdf = PSModuleDepFinder()

    # test a standard use case, where the script exists and is added to the dictionary
    psmdf.scan_exec_script('ansible_powershell_wrapper')
    assert 'ansible_powershell_wrapper' in psmdf.exec_scripts
    assert 'ansible_powershell_wrapper' in psmdf.ps_modules.keys()

    # test a case where the script doesn't exist and an exception is raised
    try:
        psmdf.scan_exec_script('not_a_real_script')
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'not_a_real_script'" in to_native(e)




# Generated at 2022-06-22 20:10:00.973073
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    class_obj = PSModuleDepFinder()

    assert(isinstance(class_obj, PSModuleDepFinder))



# Generated at 2022-06-22 20:10:13.356510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible_collections.ns.coll.plugins.module_utils.ns_coll import PSModuleDepFinder

    psmdf = PSModuleDepFinder()

    test_data = u'# AnsibleRequires -Wrapper pscode'
    psmdf.scan_exec_script(test_data)
    assert 'pscode' in psmdf.exec_scripts.keys()
    assert psmdf.exec_scripts['pscode'] == b"Import-Module -Name 'C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\Modules\\ANSIB~1.PSD\\ANSIB~1.PSM'"

    psmdf.scan_module(test_data)
    assert 'pscode' in psmdf.exec_scripts

# Generated at 2022-06-22 20:10:16.118290
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    assert(md.scan_module(to_bytes('')) == None)

# Generated at 2022-06-22 20:10:25.744485
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert ps_module_finder.ps_modules == {}
    assert ps_module_finder.exec_scripts == {}
    assert ps_module_finder.cs_utils_wrapper == {}
    assert ps_module_finder.cs_utils_module == {}
    assert ps_module_finder.ps_version == None
    assert ps_module_finder.os_version == None
    assert ps_module_finder.become == False


# Unit tests for scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:37.865503
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_data = '''#Requires -Version 2.0
#AnsibleRequires -PowerShell Ansible.{name}.psm1
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.{name}
#AnsibleRequires -Wrapper {name}
#AnsibleRequires -OSVersion 3.0
#AnsibleRequires -Become
'''
    test_filename = "test_module.psm1"
    test_fqn = "ansible_collections.namespace.collection.plugins.modules.test_module"
    mu_data_1 = "Ansible util 1"
    mu_data_2 = "Ansible util 2"
    mu_data_3 = "Ansible util 3"

    ph = PSModuleDepFinder()

# Generated at 2022-06-22 20:10:50.223193
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == dict()
    assert pmdf.exec_scripts == dict()
    assert pmdf.cs_utils_wrapper == dict()
    assert pmdf.cs_utils_module == dict()
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False
    assert pmdf._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                     r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:10:59.784349
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:01.796182
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder is not None
    assert ".psm1" in depfinder.ps_modules


# Generated at 2022-06-22 20:11:14.881681
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    testcase = {
        "module_data": "#ansiblerequires -wrapper winrm\n#Requires -Module Ansible.ModuleUtils.OtherModules\n",
        "fqn": "module_name",
        "wrapper": True,
        "ps_module": False,
        "ps_modules": {"Ansible.ModuleUtils.OtherModules": True},
        "cs_utils": {},
        "exec_scripts": {"winrm": True},
    }

    dep_finder = PSModuleDepFinder()

    dep_finder.scan_module(testcase["module_data"], fqn=testcase["fqn"], wrapper=wrapper, powershell=testcase["ps_module"])

    assert dep_finder.ps_modules == testcase["ps_modules"]
    assert dep_finder.cs_utils_module

# Generated at 2022-06-22 20:11:18.612246
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Prepare test
    psmf = PSModuleDepFinder()

    # Run method
    psmf.scan_exec_script(b"powershell")

    # Verify that the method has the expected behavior
    assert psmf.exec_scripts[b"powershell"]


# Generated at 2022-06-22 20:11:21.748325
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_PSModuleDepFinder = PSModuleDepFinder()
    my_PSModuleDepFinder.scan_exec_script("Common")
    assert "Common" in my_PSModuleDepFinder.exec_scripts


# Generated at 2022-06-22 20:11:22.454775
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:11:23.298871
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass


# Generated at 2022-06-22 20:11:27.289432
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os.path
    post_module_data = b"#Requires -Module Ansible.ModuleUtils.LegacyAnsibleModule\r\n"

# Generated at 2022-06-22 20:11:37.128390
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the method scan_module of class PSModuleDepFinder with an example
    # module.
    import os
    import binascii
    from ansible.plugins.loader import find_plugin
    from ansible.module_utils.common.text.converters import to_bytes
    from units.compat import unittest

    import ansible.module_utils.powershell as powershell
    from ansible.module_utils.powershell.converter import to_ps

    class TestClass(unittest.TestCase):

        def _load_module_util(self):
            # Load the module_utils used by the test module
            module_util = find_plugin('Ansible.ModuleUtils.Legacy.BinaryFile')

# Generated at 2022-06-22 20:11:43.373103
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    assert 'testing_exec_script' not in psmdf.exec_scripts.keys()
    psmdf.scan_exec_script('testing_exec_script')
    assert 'testing_exec_script' in psmdf.exec_scripts.keys()
    assert 'testing_exec_script' in psmdf.ps_modules.keys()


# Generated at 2022-06-22 20:11:44.357625
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert None

# Generated at 2022-06-22 20:11:49.795605
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    finder = PSModuleDepFinder()
    exec_script = finder.exec_scripts
    finder.scan_exec_script("exe_wrapper")

    assert exec_script["exe_wrapper"] != None
    # fails to find the script
    assert exec_script["batscript"] == None


# Generated at 2022-06-22 20:12:00.843987
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    config = ParserConfig()
    config.set_setting('PSScriptRoot', os.path.normpath(os.path.join(os.path.dirname(__file__), "../../")))

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Core/executor.ps1')

# Generated at 2022-06-22 20:12:10.197582
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf, PSModuleDepFinder)
    assert isinstance(psmdf.ps_modules, dict)
    assert isinstance(psmdf.cs_utils_wrapper, dict)
    assert isinstance(psmdf.cs_utils_module, dict)
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False
    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_cs_in_ps_module, list)
    assert isinstance(psmdf._re_ps_module, list)
    assert isinstance(psmdf._re_wrapper, type(re.compile('')))

# Generated at 2022-06-22 20:12:10.805514
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:12:21.427876
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:27.268817
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()
    assert psmdf.ps_version is None
    assert psmdf.os_version is None



# Generated at 2022-06-22 20:12:34.535620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_cases = [
        'FooBar',
        'CopyItem',
    ]

    for test_case in test_cases:
        ps_module_dep_finder = PSModuleDepFinder()
        ps_module_dep_finder.scan_exec_script(test_case)

        assert ps_module_dep_finder.exec_scripts.get(test_case, None) is not None

# Unit tests for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:38.890101
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Success case 1
    f = PSModuleDepFinder()
    assert type(f._re_ps_module) == list
    assert type(f._re_cs_in_ps_module) == list
    assert type(f._re_ps_version) == _sre.SRE_Pattern
    assert type(f._re_os_version) == _sre.SRE_Pattern
    assert type(f._re_become) == _sre.SRE_Pattern
    assert type(f._re_wrapper) == _sre.SRE_Pattern
    assert f.ps_modules == dict()
    assert f.exec_scripts == dict()
    assert type(f.cs_utils_wrapper) == dict
    assert type(f.cs_utils_module) == dict
    assert f.ps_version == None

# Generated at 2022-06-22 20:12:52.345607
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell import PSModuleDepFinder

    # The first test is with **ps_version** and **os_version** commented out in the file.
    psmdf = PSModuleDepFinder()

    psmdf.scan_exec_script('win_logger')
    assert (psmdf.ps_version is None)

    psmdf.scan_exec_script('win_stat')
    assert (psmdf.os_version is None)
    assert (psmdf.become is False)

    # The second test is with **ps_version** and **os_version** uncommented but commented out **become** in the file.
    psmdf = PSModuleDepFinder()

    psmdf.scan_exec_script('win_logger')

# Generated at 2022-06-22 20:13:00.683544
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Define module_data string
    module_data = b"#Requires -Module Ansible.ModuleUtils.ps1"

    # Instantiate PSModuleDepFinder
    psmdf = PSModuleDepFinder()

    # Test scan_module method
    psmdf.scan_module(module_data, fqn=None, wrapper=False, powershell=True)
    assert psmdf.ps_modules["Ansible.ModuleUtils.ps1"]["path"] == "ansible_collections/ansible/module_utils/ps1.psm1"



# Generated at 2022-06-22 20:13:04.672913
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the case where an executor powershell script is not found
    dep_finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        dep_finder.scan_exec_script('UnknownExecutor')

# Generated at 2022-06-22 20:13:11.013702
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = pkgutil.get_data("ansible.executor.powershell", "Invoke-Ansible.ps1")
    fqn = 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.ExecutionPolicy'
    m = PSModuleDepFinder()
    m.scan_module(module_data, fqn)
    assert m.scan_exec_script("Invoke-Ansible") == None
    assert m.scan_exec_script("Invoke-Ansible") == None

# Generated at 2022-06-22 20:13:20.378622
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:13:30.308398
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Arrange
    dep_finder = PSModuleDepFinder()
    module_data = b'#Requires -Module Microsoft.PowerShell.Archive\n#Requires -Module Ansible.Quoting'
    wrapper = 'require_wrapper'
    powershell = True

    # Act
    dep_finder.scan_module(module_data, wrapper=wrapper, powershell=powershell)

    # Assert
    assert dep_finder.ps_modules['Ansible.Quoting']['data'] is not None
    assert dep_finder.cs_utils_wrapper is None



# Generated at 2022-06-22 20:13:41.318628
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder is not None
    assert len(ps_module_dep_finder._re_cs_module) == 1
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1
    assert len(ps_module_dep_finder._re_ps_module) == 2
    assert len(ps_module_dep_finder._re_wrapper) == 1
    assert len(ps_module_dep_finder._re_ps_version) == 1
    assert len(ps_module_dep_finder._re_os_version) == 1
    assert len(ps_module_dep_finder._re_become) == 1



# Generated at 2022-06-22 20:13:50.023067
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md_finder = PSModuleDepFinder()
    assert(set(md_finder.ps_modules.keys()) == set())
    assert(set(md_finder.cs_utils_wrapper.keys()) == set())
    assert(set(md_finder.cs_utils_module.keys()) == set())

    assert(md_finder.ps_version is None)
    assert(md_finder.os_version is None)
    assert(md_finder.become is False)

    assert len(md_finder._re_cs_module) == 1
    assert len(md_finder._re_cs_in_ps_module) == 1
    assert len(md_finder._re_ps_module) == 2
    assert md_finder._re_wrapper is not None
    assert md_finder._re_ps_version is not None

# Generated at 2022-06-22 20:14:01.525834
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test fixture to register test module
    from ansible.plugins.loader import module_loader
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_data/powershell/test_ps_module_dep_finder'))
    from ansible.plugins.loader import module_loader

    # Test module with one module_util
    m_dep_finder = PSModuleDepFinder()
    m_dep_finder.scan_module(to_bytes(module_loader.find_plugin('test_module', '.psm1')))
    assert m_dep_finder.ps_modules
    assert not m_dep_finder.exec_scripts

    # Test module with one module_util and one execscript
    m_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:14:10.783912
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    simple_module_data = '''#Requires -Version 3.0
#Requires -Module Ansible.ModuleUtils.Something
    '''
    mf = PSModuleDepFinder()
    mf.scan_module(to_bytes(simple_module_data))
    assert mf.ps_modules["Ansible.ModuleUtils.Something"]["data"].startswith(to_bytes('#Requires -Version 3.0'))

    ps_module_data = '''#Requires -Version 3.0
#Requires -Module Ansible.ModuleUtils.Something
#Requires -Module Ansible.ModuleUtils.SomethingElse

#Requires -Module Ansible.ModuleUtils.FooBar
    '''
    mf = PSModuleDepFinder()
    mf.scan_module(to_bytes(ps_module_data))

# Generated at 2022-06-22 20:14:17.540329
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:14:26.749155
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_ps_version = '5.0.7'
    test_os_version = '1.0.7'
    ps_dep_finder = PSModuleDepFinder()
    assert ps_dep_finder.ps_version == None
    assert ps_dep_finder.os_version == None
    assert ps_dep_finder.become == False

    ps_dep_finder.scan_module('#Requires -Version %s' % test_ps_version)
    assert ps_dep_finder.ps_version == test_ps_version
    assert ps_dep_finder.os_version == None
    assert ps_dep_finder.become == False

    ps_dep_finder.scan_module('#AnsibleRequires -OsVersion %s' % test_os_version)
    assert ps_dep_finder.ps_version == test

# Generated at 2022-06-22 20:14:30.488951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('frozen')
    assert finder.scan_exec_script('frozen')



# Generated at 2022-06-22 20:14:33.836008
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script does not fail on non-existing exec script
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("dummy")
