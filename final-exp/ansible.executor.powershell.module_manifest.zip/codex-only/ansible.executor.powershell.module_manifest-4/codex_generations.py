

# Generated at 2022-06-22 20:04:44.820638
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.basic import AnsibleModule

    def _get_module():
        module_data = """
        #Requires -Module Ansible.ModuleUtils.MyUtil

        class MyModule(AnsibleModule):
            pass

        """
        return AnsibleModule(argument_spec={}, supports_check_mode=True)._load_params()

    test_module = _get_module()

    # Create a resource file with the module data.
    fname = to_text(base64.b64encode(os.urandom(24)), 'utf-8')
    with open(fname, 'wb') as module_desc:
        module_desc.write(to_bytes(module_data))


# Generated at 2022-06-22 20:04:55.517175
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    assert mdf

    ps_modules = mdf.ps_modules
    assert ps_modules
    assert isinstance(ps_modules, dict)
    assert len(ps_modules) == 0

    cs_utils_wrapper = mdf.cs_utils_wrapper
    assert cs_utils_wrapper
    assert isinstance(cs_utils_wrapper, dict)
    assert len(cs_utils_wrapper) == 0

    assert mdf.ps_version is None
    assert mdf.os_version is None
    assert mdf.become is False



# Generated at 2022-06-22 20:04:57.643891
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)



# Generated at 2022-06-22 20:05:07.633049
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    for ext, pattern in [
        (".psm1", re.compile(r'(?i)^#\s*requires\s+\-module(?:s?)\s*(Ansible\.ModuleUtils\..+)')),
        (".cs", re.compile(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]:
        finder = PSModuleDepFinder()
        assert finder._re_cs_in_ps_module[0] == pattern
        assert finder._re_ps_module[0] == pattern
        fqn = 'ns.coll.plugins.module_utils.foo'


# Generated at 2022-06-22 20:05:20.005847
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("\n === Test case 1: to test after updating the script name to fileutil.cs ===")
    import os
    import pprint
    finder = PSModuleDepFinder()
    resource = resource_from_fqcr("myns.mycoll", "plugins", "modules", "my_module.psm1")
    print("Testing the file under %s" % resource)
    filename = resource.get_filename()
    print("Path of the file after get_filename call is %s" % filename) 
    pprint.pprint(finder.ps_modules)
    print("Module util file name to be serached is %s" % finder.ps_modules['.module_utils.fileutil']['path'])

# Generated at 2022-06-22 20:05:24.303351
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)
    assert not ps_module_dep_finder.ps_modules
    assert not ps_module_dep_finder.cs_utils_module
    assert not ps_module_dep_finder.cs_utils_wrapper
    assert not ps_module_dep_finder.ps_version
    assert not ps_module_dep_finder.os_version
    assert not ps_module_dep_finder.become


# Generated at 2022-06-22 20:05:33.668335
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.utils.plugin_docs import read_docstring
    module_obj = PSModuleDepFinder()
    module_data1 = read_docstring(test_source_code1)
    module_obj.scan_module(module_data1)
    assert(module_obj.ps_modules['Ansible.ModuleUtils.Basic'] is not None)
    assert(module_obj.cs_utils_module['ansible_collections.test_label.test_collection.plugins.module_utils.test_module_utils.test_cs_module_utils'] is not None)

# Generated at 2022-06-22 20:05:46.765527
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_data = b'#Requires -Modules Ansible.ModuleUtils.Service\nimport-module Ansible.ModuleUtils.Service;'
    ps_module_dep_finder.scan_module(ps_module_data)
    assert ps_module_dep_finder.ps_modules[
               'Ansible.ModuleUtils.Service']['path'] == '/ansible/ansible/plugins/module_utils/service.psm1'
    assert b'function Get-ServiceDescription' in ps_module_dep_finder.ps_modules[
        'Ansible.ModuleUtils.Service']['data']


# Generated at 2022-06-22 20:05:50.095258
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    Finder = PSModuleDepFinder()
    Finder.scan_exec_script(to_text('AnsibleModule'))
    assert 'AnsibleModule' in Finder.exec_scripts.keys()


# Generated at 2022-06-22 20:06:01.491539
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Find the data folder containing our test data
    __dirname = os.path.abspath(os.path.dirname(__file__))
    data_folder = os.path.join(__dirname, '../test_data/powershell/module_utils')

    dir_contents = {}
    # Grab the contents of the directory and store it in the dir_contents variable
    with os.scandir(data_folder) as it:
        for entry in it:
            if not entry.name.startswith('.') and entry.is_file():
                if entry.name.endswith('.cs'):
                    with open(os.path.join(data_folder, entry.name), 'rb') as file:
                        dir_contents[entry.name] = file.read()

    finder = PSModuleDep

# Generated at 2022-06-22 20:06:11.534854
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_obj = PSModuleDepFinder()
    params_name = "name"
    result = PSModuleDepFinder_obj.scan_exec_script(params_name)
    assert result is None

# Generated at 2022-06-22 20:06:25.650665
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    modDepFinder = PSModuleDepFinder()

    assert isinstance(modDepFinder.ps_modules, dict)
    assert isinstance(modDepFinder.cs_utils_wrapper, dict)
    assert isinstance(modDepFinder.cs_utils_module, dict)
    assert isinstance(modDepFinder.exec_scripts, dict)

    assert modDepFinder.ps_version is None
    assert modDepFinder.os_version is None
    assert modDepFinder.become is False

    assert isinstance(modDepFinder._re_cs_module, list)
    assert isinstance(modDepFinder._re_cs_in_ps_module, list)
    assert isinstance(modDepFinder._re_ps_module, list)

# Generated at 2022-06-22 20:06:34.175079
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2

    assert isinstance(finder._re_wrapper, re._pattern_type)
    assert isinstance(finder._re_ps_version, re._pattern_type)

# Generated at 2022-06-22 20:06:37.621170
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    P = PSModuleDepFinder()
    assert P.ps_version is None
    assert P.os_version is None
    assert P.become is False


# Generated at 2022-06-22 20:06:46.626046
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class obj:
        def __init__(self):
            self._re_wrapper = None
            self._re_cs_module = None
            self._re_ps_module = None

            self.cs_utils_wrapper = {}
            self.cs_utils_module = {}

            self.ps_modules = {}

        def scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
            return None

    obj = obj()
    p = PSModuleDepFinder()
    p.scan_exec_script = obj.scan_exec_script
    p._re_wrapper = obj._re_wrapper
    p._re_cs_module = obj._re_cs_module
    p._re_ps_module = obj._re_ps_module

# Generated at 2022-06-22 20:06:50.504102
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder();
    assert(finder.scan_exec_script("Dummy") == 0);

# Generated at 2022-06-22 20:06:53.148382
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)



# Generated at 2022-06-22 20:07:03.182605
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    import ansible.plugins.loader
    import ansible.module_utils.powershell


# Generated at 2022-06-22 20:07:12.797581
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # testing with invalid module data
    try:
        PSModuleDepFinder().scan_module(None)
        assert False, "AnsibleError exception was not raised"
    except AnsibleError:
        pass

    # testing with invalid name
    try:
        PSModuleDepFinder().scan_module(b"#Requires -Module Ansible.ModuleUtils.NotExisting")
        assert False, "AnsibleError exception was not raised"
    except AnsibleError:
        pass

    # testing with invalid version
    try:
        PSModuleDepFinder().scan_module(b"#Requires -Version 1")
        assert False, "AnsibleError exception was not raised"
    except AnsibleError:
        pass

    # testing with invalid Os version

# Generated at 2022-06-22 20:07:22.446275
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_finder

    def register_modules():
        module_finder.add_directory(os.path.join(os.path.dirname(__file__), 'test_data', 'plugins'), with_subdir=True)
        module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_data', 'plugins'), with_subdir=True)

    # Find all the modules in the `test_data` directory
    register_modules()

    # One of the modules in `test_data` references
    # TestModuleUtils.psm1 so assert that module was found.
    module_data = module_loader.find_plugin('TestModule', mod_type='module')

# Generated at 2022-06-22 20:07:26.303746
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: add unit tests here, ref: http://doc.pytest.org/en/latest/goodpractices.html#test-discovery
    pass


# Generated at 2022-06-22 20:07:31.230429
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = ""
    fqn=None
    wrapper=False
    powershell=True
    PSModuleDepFinder_instance = PSModuleDepFinder()
    PSModuleDepFinder_instance.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-22 20:07:43.372057
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    modules = []
    check_idx = {}


# Generated at 2022-06-22 20:07:48.179819
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    assert len(mdf.exec_scripts) == 0
    mdf.scan_exec_script('ExecuteCommon')
    assert len(mdf.exec_scripts) == 1
    assert len(mdf.cs_utils_wrapper) == 1
    assert len(mdf.ps_modules) == 0


# Generated at 2022-06-22 20:07:58.702631
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # verify that if a C# module does not contain a reference to another
    # C# module_util, an empty list is returned
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'using System;')
    assert ps_module_dep_finder.cs_utils_module == {}

    # verify that if a C# module does contain 1 reference to another C#
    # module_util, that module_util is returned
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(
        b'using ansible_collections.my.collection.plugins.module_utils.my_module;')

# Generated at 2022-06-22 20:08:11.243319
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    def test_util_data(util):
        return b'#%s module_util' % to_bytes(util)

    ps_util_data_1 = test_util_data(u'ps_util_1')
    ps_util_data_2 = test_util_data(u'ps_util_2')

    cs_util_data_1 = test_util_data(u'cs_util_1')
    cs_util_data_2 = test_util_data(u'cs_util_2')

    module_data_1 = b'#Requires -Module Ansible.ModuleUtils.ps_util_1'
    module_data_2 = b'#Requires -Module Ansible.ModuleUtils.ps_util_2'

    cs_module_data_1

# Generated at 2022-06-22 20:08:14.820091
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    assert isinstance(instance, PSModuleDepFinder)
    name = 'test'
    assert isinstance(instance.scan_exec_script(name), None)


# Generated at 2022-06-22 20:08:27.078961
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

    # Both of the following tests will fail if the value of the dict is not a valid default value.
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    assert type(dep_finder._re_cs_in_ps_module[0]) == re._pattern_type
    assert type(dep_finder._re_cs_module[0]) == re._pattern_type

# Generated at 2022-06-22 20:08:28.166982
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    return None

# Generated at 2022-06-22 20:08:32.863289
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    for key in ps_module_dep_finder.__dict__:
        if not key.startswith("_"):
            assert getattr(ps_module_dep_finder, key) is not None


# Generated at 2022-06-22 20:08:44.601221
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common import load_platform_subclass
    PSModuleDepFinder.__bases__ = (load_platform_subclass(os.path.basename(__file__), "PSModuleDepFinder"),)
    obj = PSModuleDepFinder()
    print("Testing scan_module")

# Generated at 2022-06-22 20:08:54.538686
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # ps_modules should be set to set(). Same for cs_utils_wrapper and cs_utils_module
    ps_modules = set()
    cs_utils_wrapper = set()
    cs_utils_module = set()

    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn't needed
    cs_utils_wrapper = {}
    cs_utils_module = {}

    ps_version = None
    os_version = None
    become = False

    # _re_cs_module should look for #AnsibleRequires -CSharpUtil command
    # _re_ps_module should look for #AnsibleRequires -PowerShell command

# Generated at 2022-06-22 20:09:05.933135
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # line = b'#Requires -Module Ansible.ModuleUtils.{name}'
    line = b'#Requires -Module Ansible.ModuleUtils.CLI'
    ret = PSModuleDepFinder._re_ps_module[0].match(line)
    assert ret.group(1) == b'Ansible.ModuleUtils.CLI'

    # line = b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}'
    line = b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.CLI'
    ret = PSModuleDepFinder._re_ps_module[1].match(line)
    assert ret.group(1) == b'Ansible.ModuleUtils.CLI'

    # line = b'#AnsibleRequires -PowerShell ansible_

# Generated at 2022-06-22 20:09:16.920323
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:20.743456
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_md = PSModuleDepFinder()
    ps_md.scan_exec_script('basic')
    assert type(ps_md.exec_scripts['basic'])==bytes


# Generated at 2022-06-22 20:09:29.818939
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import OrderedDict
    basic._ANSIBLE_ARGS = OrderedDict()
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes(pkgutil.get_data("ansible_collections.community.trello", "plugins/modules/trello.psm1").decode('utf-8').replace("\r\n", "\n")))
    assert len(dep_finder.ps_modules) == 4
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0

# Generated at 2022-06-22 20:09:40.594305
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        from ansible.executor.powershell import PSModuleDepFinder
    except ImportError:
        # Fails in Python 3.4 on Travis, where the ps module and therefore ps_module_utils_loader are not available
        return

    module_finder = PSModuleDepFinder()
    module_finder.scan_exec_script('exec_wrapper')
    assert len(module_finder.exec_scripts.keys()) == 1

    # scan_exec_script should result in the "exec_wrapper.ps1" script to have
    # been loaded
    assert module_finder.exec_scripts['exec_wrapper'].startswith(b'[CmdletBinding()]')

    # This script should require the following module_utils
    assert len(module_finder.ps_modules.keys()) == 6

    # Scanning an invalid script should

# Generated at 2022-06-22 20:09:53.400556
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    _f = PSModuleDepFinder
    # This function tests that the method scan_exec_script() of class PSModuleDepFinder executes correctly
    # and that it adds the given executable scripts to the attribute "exec_scripts" of the instance.

    # Create an instance of class PSModuleDepFinder
    module_dep_finder = PSModuleDepFinder()

    # call the method scan_exec_script with the parameter "wrapper_copy"
    # This adds the executable script "wrapper_copy.ps1" to the attribute "exec_scripts" of the instance.
    module_dep_finder.scan_exec_script("wrapper_copy")

    # Create the base64 encoded text in a file

# Generated at 2022-06-22 20:10:04.686055
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:14.127136
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_dep_finder = PSModuleDepFinder()
    assert psmodule_dep_finder.ps_modules == dict()
    assert psmodule_dep_finder.exec_scripts == dict()
    assert psmodule_dep_finder.cs_utils_wrapper == dict()
    assert psmodule_dep_finder.cs_utils_module == dict()
    assert psmodule_dep_finder.ps_version == None
    assert psmodule_dep_finder.os_version == None
    assert psmodule_dep_finder.become == False


# Generated at 2022-06-22 20:10:17.549016
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    for j in range(4):
        obj = PSModuleDepFinder()
        name = to_text(random.randint(1, 8))
        obj.scan_exec_script(name)



# Generated at 2022-06-22 20:10:25.292778
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md.ps_modules == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False


# Generated at 2022-06-22 20:10:27.571580
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import types
    assert isinstance(PSModuleDepFinder(), types.ModuleType)


# Generated at 2022-06-22 20:10:39.326656
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test for the exec script with no dependencies
    moddepfinder = PSModuleDepFinder()
    random_string = to_text(base64.b64encode(os.urandom(32)))
    random_ps_script = to_bytes("""
        param($_ansible_module_wrapper)
        #Does nothing
        Write-Output "%s"
    """ % random_string)

    script_name = 'test_scan_exec_script_%d' % random.randint(0, 100000)
    setattr(moddepfinder, 'exec_scripts', {})
    setattr(moddepfinder, 'ps_modules', {})

    p = import_module("ansible.executor.powershell")
    setattr(p, script_name + ".ps1", random_ps_script)


# Generated at 2022-06-22 20:10:50.402121
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    md = PSModuleDepFinder()
    assert not md.ps_modules
    assert not md.exec_scripts
    assert not md.cs_utils_wrapper
    assert not md.cs_utils_module
    assert md.ps_version is None
    assert md.os_version is None
    assert not md.become

    # Test the scan_exec_script() method which loads a script from the
    # executor/powershell path and scans it for dependencies.
    #
    # This test is written in such a way that if the script being tested is
    # modified, the test will fail.
    #
    # Note when testing that you must scan the script first before scanning
    # any other ps1 file since the script may contain dependencies that need
    # to be resolved.
    script_name = "powershell_script0"

# Generated at 2022-06-22 20:10:59.970568
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:11:07.616411
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.AnotherTest')
    assert dep_finder.ps_modules['Ansible.ModuleUtils.AnotherTest']
    dep_finder.scan_module(b'#Requires -Module Test')
    assert dep_finder.ps_modules['Ansible.ModuleUtils.AnotherTest']


# Generated at 2022-06-22 20:11:13.436650
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    scanner = PSModuleDepFinder()
    assert scanner.ps_modules == dict()
    assert scanner.exec_scripts == dict()
    assert scanner.cs_utils_wrapper == dict()
    assert scanner.cs_utils_module == dict()
    assert scanner.ps_version is None
    assert scanner.os_version is None
    assert not scanner.become


# Generated at 2022-06-22 20:11:17.758241
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ansible_module = {}
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("script")
    assert dep_finder.exec_scripts["script"] == b"#!/usr/bin/python\n"


# Generated at 2022-06-22 20:11:21.571488
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	failure = 1
	psmod = PSModuleDepFinder()
	psmod.scan_exec_script(b"ok")
	failure = 0
	return failure


# Generated at 2022-06-22 20:11:29.225867
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # PSModuleDepFinder.scan_module([bytes, str, str, bool, bool])
    # This is an autogenerated test to verify that the method returns the correct result for example inputs
    # The function should be compatible with the following types:
    #     module_data: bytes
    #     fqn: str
    #     wrapper: bool
    #     powershell: bool

    # No example inputs to verify, just verify that it doesn't fail with None
    args = (None, None, None, None)
    result = PSModuleDepFinder().scan_module(*args)
    assert result is None


# Generated at 2022-06-22 20:11:34.384941
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Unit test for method scan_module of class PSModuleDepFinder
    """
    print('Testing method scan_module of class PSModuleDepFinder')

    # Initialize the instance we want to test
    test_class = PSModuleDepFinder()

    # test#1: known working module
    try:
        test_class.scan_module(pkgutil.get_data("ansible.plugins.modules", "raw.ps1"))
    except Exception as e:
        print("Failed to scan module with error: {0}".format(e))
        assert False
    else:
        print("Successfully scan module")
        assert True



# Generated at 2022-06-22 20:11:38.332447
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module = 'psversion_3_0'
    psd = PSModuleDepFinder()
    psd.scan_exec_script(module)
    assert module in psd.exec_scripts.keys()


# Generated at 2022-06-22 20:11:47.846557
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder._re_cs_module is not None
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper is not None
    assert finder._re_ps_version is not None
    assert finder._re_os_version is not None
    assert finder._re_become is not None

# Unit

# Generated at 2022-06-22 20:11:48.755905
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)


# Generated at 2022-06-22 20:11:58.221109
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Exec script used in the module exec wrapper
    psmf = PSModuleDepFinder()
    psmf.scan_exec_script("ansible_powershell_common")

    # We should have the ansible_powershell_common exec script
    assert "ansible_powershell_common" in psmf.exec_scripts

    # We should have one C# util in the module
    assert len(psmf.cs_utils_wrapper) == 1

    # We should have no PS utils
    assert len(psmf.ps_modules) == 0



# Generated at 2022-06-22 20:12:04.749766
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules) == 0, \
        "Initialization of the variable `ps_modules` failed."
    assert len(ps_module_dep_finder.exec_scripts) == 0, \
        "Initialization of the variable `exec_scripts` failed."
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0, \
        "Initialization of the variable `cs_utils_wrapper` failed."
    assert len(ps_module_dep_finder.cs_utils_module) == 0, \
        "Initialization of the variable `cs_utils_module` failed."

# Generated at 2022-06-22 20:12:11.899810
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    # ps_modules
    expected = {}
    assert dep_finder.ps_modules == expected, "Expected %s, found %s" % (expected, dep_finder.ps_modules)

    # cs_utils_wrapper
    expected = {}
    assert dep_finder.cs_utils_wrapper == expected, "Expected %s, found %s" % (expected, dep_finder.cs_utils_wrapper)

    # ps_version
    expected = None
    assert dep_finder.ps_version == expected, "Expected %s, found %s" % (expected, dep_finder.ps_version)

    # os_version
    expected = None

# Generated at 2022-06-22 20:12:19.159339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp(path):
        with open(path, 'rb') as f:
            return f.read()

    # simulate script with no dependencies
    module_data = """
    function do_something {
        return 1;
    }
    """
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script("no_requires")

    # simulate script with a dependency on a builtin util
    module_data = """
    #AnsibleRequires -Powershell Ansible.ModuleUtils.TestUtil
    function do_something {
        return 1;
    }
    """
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script("wrapped")

    # simulate script with a dependency on a collection util

# Generated at 2022-06-22 20:12:19.864157
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:12:31.923793
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:35.842085
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()

# Returns the 'module_code' passed in with all comments stripped out, unless
# 'module_code' is None in which case an empty string is returned.

# Generated at 2022-06-22 20:12:36.909288
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:12:43.062310
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp(path):
        with open(path, 'rb') as f:
            return f.read()
    #_slurp = MagicMock()
    p = PSModuleDepFinder()
    name = ""
    actual = p.scan_exec_script(name)
    assert actual == None


# Generated at 2022-06-22 20:12:43.607872
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass
    # TODO


# Generated at 2022-06-22 20:12:56.576448
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def compare_files(file_a, file_b, ps_dep_finder):
        # The files in the test/unit/executor/powershell directory and
        # lib/ansible/executor/powershell are expected to be identical.  Ensure
        # they actually are.  We also want to verify that the dependency resolver
        # is actually stripping out all comments so compare the files after
        # having the dep resolver strip comments as well.
        data_a = _slurp(file_a)
        data_b = _slurp(file_b)

        # The string replacement in this file may look odd but that's because of
        # how `re.sub` works.  The first argument is the string to replace
        # with, the second argument is the regex for the string to replace, and
        # the third argument is the string to

# Generated at 2022-06-22 20:13:08.225214
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Example 1: expected to return nothing as an empty string does not require a module_util
    test_string = b''
    assert PSModuleDepFinder().scan_module(test_string) == None

    # Example 2: expected to find a dependency on a builtin module_util
    test_string = b'''#Requires -Module Ansible.ModuleUtils.AnsibleModule
$foo = "bar"
'''
    assert PSModuleDepFinder().scan_module(test_string) == None

    # Example 3: expected to find a dependency on a builtin module_util and another module_util in the same file

# Generated at 2022-06-22 20:13:18.802681
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Need to import these to register the plugin loaders with AnsiblePluginLoader
    from ansible.plugins.loader import module_loader, ps_plugin_loader
    from ansible.plugins.ps_module_utils import powershell_loader
    test_data_path = os.path.join(C.TEST_DIR, 'unit', 'plugins', 'ps_module_utils')
    test_data_path = os.path.normpath(os.path.abspath(test_data_path))
    C.MODULE_UTILS_PATH.append(os.path.join(test_data_path, 'module_utils'))
    C.MODULE_UTILS_PATH.append(os.path.join(test_data_path, 'module_utils2.0'))

    # seed with current pkg_resources.working_set


# Generated at 2022-06-22 20:13:31.541143
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module = to_text(pkgutil.get_data('ansible_collections.ansible.builtin', 'exec_async.ps1'))
    finder.scan_module(module)

    assert len(finder.ps_modules) == 12
    assert 'Ansible.ModuleUtils.Powershell' in finder.ps_modules
    assert 'Ansible.ModuleUtils.Powershell.Convert' in finder.ps_modules
    assert 'Ansible.ModuleUtils.Powershell.Transport' in finder.ps_modules
    assert 'Ansible.ModuleUtils.Powershell.Utils' in finder.ps_modules
    assert 'Ansible.ModuleUtils.Powershell.WinRM' in finder.ps_modules


# Generated at 2022-06-22 20:13:36.645820
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False



# Generated at 2022-06-22 20:13:44.701691
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    success = False

# Generated at 2022-06-22 20:13:51.183807
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()

    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False


# Generated at 2022-06-22 20:13:57.933335
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder
    psmd = PSModuleDepFinder()
    # Call the scan_exec_path with powershell/windows in order to populate the ps_modules and exec_scripts dicts
    psmd.scan_exec_script('powershell/windows')
    # Assert that the ps_modules and exec_scripts dictionaries have data
    assert(len(psmd.ps_modules) > 0)
    assert(len(psmd.exec_scripts) > 0)

# Generated at 2022-06-22 20:14:08.671862
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fake_data = b"""
# AnsibleRequires -CSharpUtil ansible_collections.my_ns.my_coll.plugins.module_utils.my_util.cs
import-module -name Foo.Util

# AnsibleRequires -CSharpUtil ansible_collections.my_ns.my_coll.plugins.module_utils.my_util.cs
"""

    fake_data_fail = b"""
# AnsibleRequires -CSharpUtil ansible_collections.my_ns.my_coll.plugins.module_utils.my_util.cs

import-module -name Foo.Util
"""

    finder = PSModuleDepFinder()
    finder.scan_exec_script("foo")
    assert len(finder.cs_utils_wrapper.keys()) == 1

    finder = PSModuleDepFinder

# Generated at 2022-06-22 20:14:09.777988
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass
# Unit test to verify that PSModuleDepFinder object is created with default values

# Generated at 2022-06-22 20:14:10.979147
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()



# Generated at 2022-06-22 20:14:17.742231
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import base64

    # Base64 for powershell script for very simple powershell module

# Generated at 2022-06-22 20:14:18.442740
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:14:27.272620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def load_test_data(test_name):
        test_path = os.path.join('test/units/module_utils/test_PSModuleDepFinder/testdata', test_name)
        with open(test_path, 'rb') as f:
            return f.read()

    def update_dict(target_dict, other_dict):
        for k, v in other_dict.items():
            if k not in target_dict:
                target_dict[k] = v
            elif v != target_dict[k]:
                raise AssertionError('key \'%s\' should have the content \'%s\' but actually has \'%s\''
                                     % (k, target_dict[k], v))


# Generated at 2022-06-22 20:14:35.808262
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()

    data = u"using Ansible.ModuleUtils.some_module;\nusing ansible_collections.not.a.real.collection.plugins.module_utils.some_other_module;\n"
    psmdf.scan_module(data)
    assert sorted(psmdf.cs_utils_wrapper.keys()) == sorted([u'Ansible.ModuleUtils.some_module', u'ansible_collections.not.a.real.collection.plugins.module_utils.some_other_module'])

