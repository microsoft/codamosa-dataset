

# Generated at 2022-06-22 20:04:47.031383
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # In the event validation fails, we get all the error information here
    error_info = {}
    error_info["traceback"] = ""
    error_info["error_message"] = ""
    error_info["error_type"] = ""


# Generated at 2022-06-22 20:04:49.161020
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''unit tests for PSModuleDepFinder scan_exec_script'''
    pass

# Generated at 2022-06-22 20:05:00.228673
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This test is used to test the method PSModuleDepFinder.scan_module

    # We know the method scan_module needs to be tested with parameters module_data and fqn.
    # So we need to create parameters to simulate these parameters.

    # Create parameter module_data
    module_data = None

    # Create parameter fqn
    fqn = None

    # Create parameter wrapper
    wrapper = True

    # Create parameter powershell
    powershell = True

    # Create a PSModuleDepFinder object and do the test
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-22 20:05:09.267450
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Set up for test cases
    mu_path = os.path.join(C.DEFAULT_MODULE_UTILS_PATH, 'ansible_collections',
                           'community', 'general', 'plugins', 'module_utils', 'win_acl.psm1')
    ps_version = ps_module_utils_loader.find_plugin('Ansible.ModuleUtils.Legacy', '.psm1')
    cs_version = ps_module_utils_loader.find_plugin('Ansible.ModuleUtils.Common', '.cs')
    os_version = ps_module_utils_loader.find_plugin('Ansible.Common.Util.WinOS', '.cs')
    ps_version = to_bytes(_slurp(ps_version))
    cs_version = to_bytes(_slurp(cs_version))

# Generated at 2022-06-22 20:05:21.304588
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class mock_data:
        def __init__(self, data):
            self.data = data

        def split(self, sep):
            return self.data.split(sep)

    snmp_module_data = mock_data(b'\n#Requires -Version 4.0\n#Requires -Module Ansible.ModuleUtils.SNMP\n#Requires -Module Ansible.ModuleUtils.Network\n#Requires -Module Ansible.ModuleUtils.Network.Junos\n#Requires -Module Ansible.ModuleUtils.Network.F5.Common\n#Requires -Module Ansible.ModuleUtils.Network.F5.Bigip\n#Requires -Module Ansible.ModuleUtils.Network.F5.Bigiq\n')

# Generated at 2022-06-22 20:05:26.066925
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.scan_exec_script('common') == None


# Generated at 2022-06-22 20:05:32.927351
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    d = PSModuleDepFinder()
    assert type(d) == PSModuleDepFinder
    assert len(d.ps_modules) == 0
    assert len(d.cs_utils_wrapper) == 0
    assert len(d.cs_utils_module) == 0
    assert d.ps_version is None
    assert d.os_version is None
    assert d.become is False

# Test scan_module in case of missing data

# Generated at 2022-06-22 20:05:36.053002
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert pkgutil.get_data("ansible.executor.powershell", "common.ps1") is not None


# Generated at 2022-06-22 20:05:47.788480
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()

    assert len(p.ps_modules) == 0
    assert len(p.cs_utils_wrapper) == 0
    assert len(p.cs_utils_module) == 0
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become is False

    assert len(p._re_cs_module) == 1
    assert len(p._re_cs_in_ps_module) == 1
    assert len(p._re_ps_module) == 2
    assert p._re_wrapper
    assert p._re_ps_version
    assert p._re_os_version
    assert p._re_become



# Generated at 2022-06-22 20:05:57.308347
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    This function tests the scan_module method of the PSModuleDepFinder class
    :return: None
    """
    from ansible.module_utils.common.process import get_bin_path
    import subprocess
    import os

    def _slurp(path):
        with open(path, 'rb') as f:
            return f.read()

    # This is the test module, it requires the Ansible.ModuleUtils.Legacy.AnsibleModule util
    test_module = os.path.join(C.TESTS_DIR, 'sanity/codecheck/test_module/test_module.ps1')

    if not get_bin_path('powershell'):
        # If we don't have PowerShell, just skip this test
        return

    # Run the test module

# Generated at 2022-06-22 20:06:08.593270
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.module_utils.basic import AnsibleModule

    # Create a hardcoded file_contents for testing
    file_contents = "#Requires -Module Ansible.ModuleUtils.{name}\n#Requires -Ansible -Version 2.3\n"
    file_contents += "#AnsibleRequires -CSharpUtil ..module_utils.{name}\n"
    file_contents += "#AnsibleRequires -CSharpUtil ..module_utils.{name}\n"
    file_contents += "#AnsibleRequires -Wrapper Execute{name}\n"
    file_contents += "#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}\n"
    file_contents += "#AnsibleRequires -PowerShell ..module_utils.{name}\n"

# Generated at 2022-06-22 20:06:18.702559
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmodule_depfinder = PSModuleDepFinder()
    psmodule_depfinder.scan_exec_script("executionwrapper")

# Generated at 2022-06-22 20:06:21.320455
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_deps = PSModuleDepFinder()
    module_deps.scan_exec_script("WinRMConnect")
    assert len(module_deps.exec_scripts) == 1



# Generated at 2022-06-22 20:06:22.910145
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder() is not None


# Generated at 2022-06-22 20:06:34.424518
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.exec_scripts, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)

    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper.pattern is not None
    assert finder._re_ps_version.pattern is not None
    assert finder._re_os_version.pattern is not None
   

# Generated at 2022-06-22 20:06:45.204839
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def read_file_mock_factory(data):
        def m():
            with open(mu_path, 'rb') as f:
                return f.read()
        return m

    mu_data = b"#Requires -Module Ansible.ModuleUtils.ArgumentSpec\nabc"
    mu_path = 'Ansible.ModuleUtils.ArgumentSpec.psm1'
    # Ansible.ModuleUtils.ArgumentSpec.psm1 exists
    dep_finder = PSModuleDepFinder()
    dep_finder._add_module = read_file_mock_factory(mu_data)
    dep_finder.scan_exec_script('exec_script')
    data = dep_finder.exec_scripts['exec_script']
    assert data == b"\nabc\n"


# Generated at 2022-06-22 20:06:52.500465
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test that exec scripts are properly scanned for dependencies
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ExecutionManager')
    assert 'ExecutionManager' in dep_finder.exec_scripts
    assert 'ValidatePSVersion' in dep_finder.ps_modules


# Generated at 2022-06-22 20:07:02.543372
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup
    import sys
    from ansible.module_utils.powershell.releases import ps_versions, ps_releases
    powershell = import_module('ansible.module_utils.powershell')
    powershell_env = powershell.get_env_dict(ps_versions, ps_releases)
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    sys.path.insert(0, root_dir)

    # Execute
    test_object = PSModuleDepFinder()
    test_object.scan_exec_script(powershell_env['ansible_module_exec_wrapper'])
    # Verify
    assert 'ansible_module_exec_wrapper' in test_

# Generated at 2022-06-22 20:07:12.266802
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    name = "test_module_name"

    ps_module_dep = PSModuleDepFinder()

    assert isinstance(ps_module_dep.ps_modules, dict)
    assert isinstance(ps_module_dep.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep.cs_utils_module, dict)
    assert ps_module_dep.ps_version is None
    assert ps_module_dep.os_version is None
    assert ps_module_dep.become is False
    assert ps_module_dep._re_cs_module[0].match("using ansible.module_utils.tcp.tcp_connection;")

# Generated at 2022-06-22 20:07:22.168810
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This can be used to test PSModuleDepFinder, just run this python script by itself.
    import json
    import pprint
    s = PSModuleDepFinder()
    # fqn of the module to find module_utils for
    # Use /usr/share/ansible/modules/*/ as the base path
    fqn = 'ansible_collections.amazon.aws.plugins.module_utils.core'
    lib_path = '/usr/share/ansible/modules/core'
    fqn_path = lib_path + "/" + fqn.replace('.', '/') + '.py'
    data = _slurp(fqn_path)
    s.scan_module(to_bytes(data), fqn=fqn)

    # Now get the same module_utils for the module in a

# Generated at 2022-06-22 20:07:34.514026
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    import difflib

    # returns a diff of the two strings in unified format
    def diff(expected, actual):
        return '\n'.join(difflib.unified_diff(expected.splitlines(), actual.splitlines()))

    # reads in a file as a string
    def slurp(fname):
        return to_bytes(open(fname).read())

    # reads in a file as a string
    def extract_from_file(fname, re_pattern):
        try:
            data = slurp(fname)
            for line in data.split(b'\n'):
                m = re_pattern.match(line)
                if m:
                    return to_text(m.group(1)).rstrip()
        except Exception:
            pass



# Generated at 2022-06-22 20:07:36.435950
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pytest.skip("TODO: test is not implemented")


# Generated at 2022-06-22 20:07:43.030020
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False


# Generated at 2022-06-22 20:07:45.330456
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # assert test_object.scan_exec_script("win_dsc") == "win_dsc"
    return



# Generated at 2022-06-22 20:07:55.965005
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_module = MagicMock(return_value=None)
    finder.scan_exec_script('ExecScript1')
    finder.scan_exec_script('ExecScript2')

    assert len(finder.exec_scripts) == 2
    assert finder.exec_scripts['ExecScript1'] == b'ExecScript1'
    assert finder.exec_scripts['ExecScript2'] == b'ExecScript2'

    # tests proper handling of script not found
    with pytest.raises(AnsibleError) as excinfo:
        finder.scan_exec_script('ExecScript3')

    # tests proper handling of script not found

# Generated at 2022-06-22 20:08:08.989866
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Declare a few sample cs/ps module_utils
    cs_module_utils = [
        'ansible_collections.namespace.collection.plugins.module_utils.foo',
        'ansible_collections.other.other.plugins.module_utils.bar',
        'ansible_collections.network.other.plugins.module_utils.baz',
        'ansible_collections.network.other.plugins.module_utils.qux',
    ]

    ps_module_utils = [
        'Ansible.ModuleUtils.foo',
        'Ansible.ModuleUtils.bar'
    ]

    # Declare a sample ps module which uses a cs util that in turn uses other cs utils

# Generated at 2022-06-22 20:08:16.190262
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder.__bases__ == (object,)
    assert PSModuleDepFinder.__doc__ == None
    assert PSModuleDepFinder.__init__.__doc__ == None

    assert PSModuleDepFinder.__init__.__defaults__ == ()
    assert PSModuleDepFinder.__init__.__kwdefaults__ == None
    assert PSModuleDepFinder.__init__.__annotations__ == {}



# Generated at 2022-06-22 20:08:27.164245
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    ps_modules_keys_expected = set(['Ansible.ModuleUtils.ActiveDirectory',
                                    'Ansible.ModuleUtils.Common',
                                    'Ansible.ModuleUtils.Powershell',
                                    'Ansible.ModuleUtils.Common',
                                    'Ansible.ModuleUtils.Common',
                                    'Ansible.ModuleUtils.Common'])
    if set(pmdf.ps_modules.keys()) != ps_modules_keys_expected:
        raise AssertionError("Expected keys %s but got %s" % (ps_modules_keys_expected, set(pmdf.ps_modules.keys())))


# Generated at 2022-06-22 20:08:38.735339
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # sample1 is a psm1 file referencing 2 other module_utils
    data = base64.b64decode(_SAMPLE1_B64)
    mu = PSModuleDepFinder()
    mu.scan_module(data)
    # should have added 2 utils
    assert len(mu.ps_modules) == 2
    assert len(mu.cs_utils_wrapper) == 0
    assert len(mu.cs_utils_module) == 0

    # sample2 is a psm1 file referencing 2 other module_utils
    data = base64.b64decode(_SAMPLE2_B64)
    mu = PSModuleDepFinder()
    mu.scan_module(data)
    # should have added 1 utils
    assert len(mu.ps_modules) == 1

# Generated at 2022-06-22 20:08:44.083502
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.cs_utils_module == {}
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False


# Generated at 2022-06-22 20:08:55.265638
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:08:59.912693
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = 'test'
    data = b'#requires -module ansible.moduleutils.test'
    finder.scan_exec_script(name)
    assert finder.exec_scripts['test'] == data



# Generated at 2022-06-22 20:09:08.662837
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # param: module_data: The data of a module to parse for module_utils.
    #
    # param: fqn: The name of the module.
    #
    # param: wrapper: If True, will scan for C# utils used by an Ansible Module.
    #
    # param: powershell: If False, will scan for C# utils used by a C# util.
    #
    # returns: void
    raise NotImplementedError()

# Generated at 2022-06-22 20:09:21.057559
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import types

    # Test with a file that does not exist
    f = PSModuleDepFinder()
    try:
        f.scan_exec_script('idontexist')
        raise Exception("Expected an AnsibleError")
    except AnsibleError as e:
        if "pathexist" not in str(e):
            raise

    # Now load a script that exists and make sure it also loads any
    # dependencies. We will use common.ps1 in the executor for this test
    f.scan_exec_script('common')

    # common.ps1 contains the following comment
    # # AnsibleRequires -Powershell Ansible.ModuleUtils.Basic
    # which will load the Basic module_util
    assert 'Ansible.ModuleUtils.Basic' in f.ps_modules

    # Make sure the fqn of common

# Generated at 2022-06-22 20:09:31.201753
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:36.484712
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Function to unit test scan_exec_script of class PSModuleDepFinder
    """
    # output to test

# Generated at 2022-06-22 20:09:46.039921
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("test_PSModuleDepFinder_scan_module")
    # setup
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules = {}
    dep_finder.cs_utils_wrapper = {}
    dep_finder.cs_utils_module = {}
    dep_finder.ps_version = None
    dep_finder.os_version = None
    dep_finder.become = False
    module_data = r'''
#Requires -Module Ansible.ModuleUtils.PowerShell
#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.PowerShell.Windows
'''


# Generated at 2022-06-22 20:09:58.133413
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    expected_ps_modules = {
        'Ansible.ModuleUtils.Endpoint': {'data': None, 'path': ''},
        'Ansible.ModuleUtils.Powershell': {'data': None, 'path': ''},
        'Ansible.ModuleUtils.Powershell.Convert': {'data': None, 'path': ''},
        'Ansible.ModuleUtils.Powershell.Strings': {'data': None, 'path': ''},
        'Ansible.ModuleUtils.Powershell.Win32': {'data': None, 'path': ''},
        'Ansible.ModuleUtils.PowerShell.Win32': {'data': None, 'path': ''}
    }


# Generated at 2022-06-22 20:10:10.079460
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile

    ps_module = {
        '#Requires -Module Ansible.ModuleUtils.Foo': [],
        '#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo': [],
    }

    cs_module = {
        '#Requires -Module .ModuleUtils.Foo': [],
        '#AnsibleRequires -CSharpUtil .ModuleUtils.Foo': [],
    }

# Generated at 2022-06-22 20:10:18.480298
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module('using test1')
    psmdf.scan_module('#Requires -Module test2')
    psmdf.scan_module('#AnsibleRequires -CSharpUtil test3')
    psmdf.scan_module('#AnsibleRequires -PowerShell test4')
    assert len(psmdf.ps_modules.keys()) == 2
    assert len(psmdf.cs_utils_module.keys()) == 2


# Generated at 2022-06-22 20:10:19.424616
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass



# Generated at 2022-06-22 20:10:24.749089
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script('ANSIBLE0004')
    assert mdf.exec_scripts['ANSIBLE0004']
    assert 'ansible.module_utils.basic' in mdf.cs_utils_wrapper

# Generated at 2022-06-22 20:10:36.983611
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    util_name = "Ansible.ModuleUtils.Powershell.Convert"
    module_data = b'\n#Requires -Module Ansible.ModuleUtils.Powershell.Convert'
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data, fqn="test.test", wrapper=False, powershell=True)
    assert dep_finder.ps_modules.keys() == {util_name}

    util_name = "Ansible.ModuleUtils.Powershell.ActiveDirectoryDsc"
    module_data = b'\n#AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.ActiveDirectoryDsc'
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:10:42.821749
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a mock module
    mock_module = MagicMock(spec_set=dict)

    # Create the class to test
    defs = PSModuleDepFinder()
    defs.scan_module(mock_module)

    # Validate the function call with the mock
    # assert_called_once_with()
    # Not sure how to check this, scan_module is also called via _add_module
    # assert_called_once_with()


# Generated at 2022-06-22 20:10:52.295344
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    fqn = 'some.module'

# Generated at 2022-06-22 20:10:54.277722
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert ps_module_finder is not None


# Generated at 2022-06-22 20:11:02.993387
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError
    from ansible.utils.collection_loader import collection_finder
    from ansible.module_utils.powershell import _get_codecs

    finder = PSModuleDepFinder()
    finder.scan_module(to_bytes(''), fqn='test_fqn')
    # path here doesn't really matter, so it can just be some test script.
    module_utils_path = os.path.join(collection_finder._get_collection_paths()[0], 'testcoll', 'plugins', 'module_utils', 'test_module_utils.psm1')

    assert 'test_module_utils' not in finder.ps_modules

# Generated at 2022-06-22 20:11:10.234412
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'')
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False



# Generated at 2022-06-22 20:11:16.634370
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    with open('/home/james/git/ansible/lib/ansible/modules/cloud/vmware/vsphere_guest.py', 'rb') as f:
        module = f.read()

    md = PSModuleDepFinder()
    md.scan_module(module)

    assert md.ps_modules[u'Ansible.ModuleUtils.Common.AnsibleVMwareConnection']['data'] is not None

# Generated at 2022-06-22 20:11:28.218403
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_wrapper.pattern == to_bytes(r'(?i)^#\s*ansiblerequires\s+-wrapper\s+(\w*)')

# Generated at 2022-06-22 20:11:37.838579
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('ansible_module_common')

# Generated at 2022-06-22 20:11:47.563966
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # We don't want to execute the actual PowerShell code being tested in these
    # unit tests, so we use this fake executable
    os.environ['ANSIBLE_EXECUTABLE'] = to_native(os.path.join(
        os.getcwd(), 'test/unit/test_utils/fake_executable.exe'))

    # We need a default collection dir so this gets setup to use the one
    # included in the test directory
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = to_native(os.path.join(
        os.getcwd(), 'test/unit/test_utils/ansible_collections'))

    # Initialize the class and perform the scan
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:11:59.769355
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()

# def _get_deps_for_collection(collection_name, module_name, module_path, cache_key=None, data=None):
#     dep_finder = PSModuleDepFinder()
#
#     if data is None:
#         if cache_key and get_plugin_cache().has_key(cache_key):
#             data = get_plugin_cache()[cache_key]
#         else:
#             data = _slurp(module_path)
#             get_plugin_cache()[cache_key] = data
#
#     dep_finder.scan_module(data, fqn=module_name)
#
#     deps = dep_finder.ps_modules.keys()
#     wrapper_deps = dep_finder.cs_utils_wrapper.keys

# Generated at 2022-06-22 20:12:10.357240
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    m = PSModuleDepFinder()
    m.scan_exec_script("start-filetransfer")
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.commonps' in m.ps_modules
    assert to_text(m.exec_scripts['start-filetransfer']) == to_text(pkgutil.get_data("ansible.executor.powershell", "start-filetransfer.ps1"))

    # test that we can call scan_exec_script twice without blowing up
    m.scan_exec_script("start-filetransfer")


# Generated at 2022-06-22 20:12:18.387164
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    with open("./test_data/PSModuleDepFinder/test_scan_module.txt") as f:
        module_data = f.read()
    finder.scan_module(module_data.encode())

    # unit test various attributes of finder to ensure they were modified
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil1"] == finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil2"]
    assert finder.ps_modules["Ansible.ModuleUtils.TestModuleUtil3"]["path"].endswith("Ansible.ModuleUtils.TestModuleUtil3.psm1")

# Generated at 2022-06-22 20:12:27.440891
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_MockPSModuleDepFinder = MockPSModuleDepFinder()
    fqn_count, fqn_len, fqn_opt = test_MockPSModuleDepFinder.scan_module()
    assert fqn_len == 6
    assert len(test_MockPSModuleDepFinder.ps_modules) == 3
    assert fqn_count == 5
    assert len(test_MockPSModuleDepFinder.cs_utils_module) == 2
    assert len(test_MockPSModuleDepFinder.cs_utils_wrapper) == 1
    assert len(test_MockPSModuleDepFinder.exec_scripts) == 1


# Generated at 2022-06-22 20:12:35.951856
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()

    assert isinstance(module_dep_finder, PSModuleDepFinder)
    assert module_dep_finder.ps_version is None
    assert module_dep_finder.os_version is None
    assert module_dep_finder.become is False

    assert module_dep_finder.ps_modules == dict()
    assert module_dep_finder.cs_utils_wrapper == dict()
    assert module_dep_finder.cs_utils_module == dict()
    assert module_dep_finder.exec_scripts == dict()



# Generated at 2022-06-22 20:12:48.766163
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    sample_module_data = (
        "#Requires -Version 4.1\n"
        "#AnsibleRequires -PowerShell Ansible.ModuleUtils.Common;\n"
        "#Requires -Module Ansible.ModuleUtils.Common2\n"
        "#AnsibleRequires -Powershell ansible_collections.ns.coll.plugins.module_utils.foo.bar;\n"
        "#AnsibleRequires -PowerShell ..module_utils.bar2\n"
        "#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Common3;\n"
    )

    class FakeModule(object):
        def __init__(self, name, ext, fqn, optional):
            self.name = name
            self.ext = ext
            self.fqn = fqn
            self.optional

# Generated at 2022-06-22 20:12:50.712820
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	assert True == False


# Generated at 2022-06-22 20:13:02.302036
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    module = u'''
#Requires -Module Ansible.ModuleUtils.Something
    '''.encode('utf-8')

    finder.scan_module(module)
    assert len(finder.ps_modules) == 1

    module = u'''
#Requires -Module Ansible.ModuleUtils.Something

#Requires -Module Ansible.ModuleUtils.Other
    '''.encode('utf-8')

    finder.scan_module(module)
    assert len(finder.ps_modules) == 2

    module = u'''
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Something

#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.other
    '''.encode('utf-8')

   

# Generated at 2022-06-22 20:13:09.008933
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # catch all errors
    import traceback
    try:
        # create the instance
        finder = PSModuleDepFinder()
        
        # call method
        finder.scan_exec_script('Microsoft.PowerShell.Management')

    # catch exceptions
    except Exception as e:
        # print the traceback and the error message
        traceback.print_exc()
        print(e)
        # if the test fails, throw an error
        assert False

# Generated at 2022-06-22 20:13:17.907972
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:25.150419
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:36.773701
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:42.280452
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psutil = PSModuleDepFinder()
    assert psutil.ps_modules == {}
    assert psutil.cs_utils_wrapper == {}
    assert psutil.cs_utils_module == {}
    assert psutil.come == False
    assert psutil.ps_version == None
    assert psutil.os_version == None


# Generated at 2022-06-22 20:13:50.680500
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Test with a simple module
    module_data = "#Requires -Module Ansible.ModuleUtils.FunctionsUtils\n#Requires -Module PowerShellGet\n"
    finder.scan_module(module_data)

# Generated at 2022-06-22 20:13:59.518163
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psdep_finder = PSModuleDepFinder()
    
    data = r'''using System;
using Ansible.Common;
using Ansible.Common.PowerShell;
using Ansible.Test.ModuleUtils.TestUtils;

#ansiblerequires -csharputil Ansible.ModuleUtils.TestUtils
#ansiblerequires -csharputil ansible_collections.namespace.collection.plugins.module_utils.TestUtils
#ansiblerequires -csharputil .TestUtils
public class TestClass {
}'''
    with open("/tmp/testmodule.cs", "w") as f:
        f.write(data)
    module_data = to_bytes(data)
    fqn = "ansible_collections.namespace.collection.plugins.modules.testmodule"


# Generated at 2022-06-22 20:14:09.452405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a constant that we can use as the path to our fixtures.
    FIXTURES_PATH = os.path.join(os.path.dirname(__file__), 'unit/fixtures')
    
    # Create a constant that we will use to store a temporary location for the test.
    TEMP_PATH = os.path.join(os.path.dirname(__file__), 'unit/temp')
    temp_file_name = os.path.join(TEMP_PATH, 'test_PSModuleDepFinder_scan_exec_script')
    if os.path.exists(TEMP_PATH):
        shutil.rmtree(TEMP_PATH)
    os.makedirs(TEMP_PATH)
    
    # Create a constant for the fixture for this test.
    TEST_FIXTURE = os.path

# Generated at 2022-06-22 20:14:16.619257
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Run the same test on both wrapper and non-wrapper files
    for wrapper in [True, False]:
        # This test is copied to the win_firewall module since it's pretty
        # comprehensive in checking C# and PowerShell utils
        data = pkgutil.get_data("ansible", "modules/network/windows/win_firewall.psm1")
        if not data:
            raise Exception("Could not find win_firewall.psm1 module")

        if not wrapper:
            data = to_bytes(_strip_comments(data))

        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(data, wrapper=wrapper)

        # Ansible.ModuleUtils.Powershell.Network.Win32_pnpsigneddriver.psm1
        # Ansible.ModuleUtils.Powershell.Active

# Generated at 2022-06-22 20:14:19.550605
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:14:27.819052
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup test requirements and results
    data = {
        "name": "Test Module",
        "api_version": 1,
        "supported_by": "community",
        "metadata_version": "1.1",
        "short_description": "Test Module",
        "version": "0.1",
        "author": "Ansible, Inc.",
        "requirements": [
            {
                "python": "python >= 2.6"
            }
        ],
        "extends_documentation_fragment": [
            "cloud"
        ],
        # [snip-]
    }

    # Do the test
    ps_modules = dict()
    cs_utils = dict()
    ps_util = PSModuleDepFinder()

# Generated at 2022-06-22 20:14:37.888125
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance
    scanner = PSModuleDepFinder()
    scanner.scan_exec_script("Files")

    # check that the ansible_powershell_files_exec_script attribute is set with the correct data