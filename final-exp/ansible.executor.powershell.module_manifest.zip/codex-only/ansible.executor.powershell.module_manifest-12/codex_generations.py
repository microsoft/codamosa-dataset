

# Generated at 2022-06-22 20:04:36.779236
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)
    #assert set(finder.cs_utils_wrapper) == set()
    #assert set(finder.ps_modules) == set()


# Generated at 2022-06-22 20:04:48.982564
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_data = dict()

# Generated at 2022-06-22 20:04:56.139429
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psd = PSModuleDepFinder()
    assert not psd.ps_modules
    assert not psd.exec_scripts
    assert not psd.cs_utils_wrapper
    assert not psd.cs_utils_module
    assert psd.ps_version is None
    assert psd.os_version is None
    assert not psd.become



# Generated at 2022-06-22 20:05:05.360711
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert len(md.ps_modules) == 0
    assert len(md.exec_scripts) == 0
    assert len(md.cs_utils_wrapper) == 0
    assert len(md.cs_utils_module) == 0
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False

# Helper function for commenting out lines in a string
# A 'comment char' is added to the start of p_lines
# lines with '{' or '}' are commented out to avoid issues
# with brackets being used for the actual module code.

# Generated at 2022-06-22 20:05:10.333147
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # In order to run this unit test, add the below to test/units/loader/module_plugin.py
    #
    #import sys
    #sys.path.append("lib")
    #from ansible.plugins.loader.powershell.ps_module_utils import PSModuleDepFinder
    #PSModuleDepFinder().test()

    pass



# Generated at 2022-06-22 20:05:18.761716
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ''' Test PSModuleDepFinder constructor
    '''
    ps_dep_finder = PSModuleDepFinder()

    for checker in ps_dep_finder._re_cs_module:
        assert(isinstance(checker, re._pattern_type))

    for checker in ps_dep_finder._re_cs_in_ps_module:
        assert(isinstance(checker, re._pattern_type))

    for checker in ps_dep_finder._re_ps_module:
        assert(isinstance(checker, re._pattern_type))

    assert(isinstance(ps_dep_finder._re_wrapper, re._pattern_type))
    assert(isinstance(ps_dep_finder._re_ps_version, re._pattern_type))

# Generated at 2022-06-22 20:05:29.885016
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Need to upgrade to pytest

   
    # Build the test fixture classes
    class _TestData(object):
        def __init__(self):
            self.test_data = dict()
            self.test_data["simple_module"] = dict()


    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass
    class ModuleDeprecationWarning(Exception):
        pass
    class AnsibleParserError(Exception):
        pass


    class _ActionBase(object):
        pass

    class _ModuleUtilsCommonArguments(_ActionBase):
        def __init__(self):
            self.argument_spec = dict()
            self._ansible_module = None
            self._client = None


# Generated at 2022-06-22 20:05:41.822463
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ############################################################################################################
    # Test the PSModuleDepFinder.scan_module() method
    ############################################################################################################

    # Set target object
    target = PSModuleDepFinder()

    # Set test data

# Generated at 2022-06-22 20:05:42.531065
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:05:45.255132
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder() is not None

# unit test for function _strip_comments

# Generated at 2022-06-22 20:05:50.360595
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # PSModuleDepFinder.scan_exec_script() with args
    # ('get_privileges_exe',)
    # do we need to test this?

    # PSModuleDepFinder.scan_exec_script() with args
    # ('test_module',)
    # do we need to test this?

    pass

# Generated at 2022-06-22 20:05:57.267552
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert isinstance(pmdf, PSModuleDepFinder)
    assert pmdf.ps_modules == dict()
    assert pmdf.exec_scripts == dict()
    assert pmdf.cs_utils_wrapper == dict()
    assert pmdf.cs_utils_module == dict()
    assert isinstance(pmdf.ps_version, (type(None), basestring))
    assert isinstance(pmdf.os_version, (type(None), basestring))
    assert isinstance(pmdf.become, bool)


# Generated at 2022-06-22 20:06:02.441706
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Initialization of class PSModuleDepFinder
    i = PSModuleDepFinder()

    # Unit test for method scan_exec_script of class PSModuleDepFinder
    i.scan_exec_script(name="basic")
    assert(i.exec_scripts["basic"] == b"")

# Generated at 2022-06-22 20:06:11.892793
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_mod_dep_finder = PSModuleDepFinder()

    assert isinstance(ps_mod_dep_finder.cs_utils_module, dict)
    assert isinstance(ps_mod_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_mod_dep_finder.ps_modules, dict)
    assert isinstance(ps_mod_dep_finder.exec_scripts, dict)
    assert ps_mod_dep_finder.ps_version is None
    assert ps_mod_dep_finder.os_version is None
    assert ps_mod_dep_finder.become is False

    assert isinstance(ps_mod_dep_finder._re_cs_module, list)
    assert isinstance(ps_mod_dep_finder._re_cs_module[0], re._pattern_type)

# Generated at 2022-06-22 20:06:25.697837
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile, shutil
    import ansible.executor.powershell

    temp_dir = tempfile.mkdtemp()
    temp_ps_file = os.path.join(temp_dir, "temp_powershell.ps1")

# Generated at 2022-06-22 20:06:28.145313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script('netca_install') == None


# Generated at 2022-06-22 20:06:35.880469
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    
    finder = PSModuleDepFinder()
    module = '\n'.join([
        '#Requires -Module Ansible.ModuleUtils.Foo',
        '#Requires -Module Ansible.ModuleUtils.Bar',
        '#Requires -Module Ansible.ModuleUtils.Baz'
    ]).encode('utf-8')
    finder.scan_module(module, None)
    assert finder.ps_modules
    for f in ['Foo', 'Bar', 'Baz']:
        assert f in finder.ps_modules


# Generated at 2022-06-22 20:06:38.005981
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:06:46.808085
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert(dep.ps_modules == dict())
    assert(dep.cs_utils_wrapper == dict())
    assert(dep.cs_utils_module == dict())
    assert(dep.ps_version is None)
    assert(dep.os_version is None)
    assert(dep.become is False)
    assert(len(dep._re_cs_module) == 1)
    assert(len(dep._re_cs_in_ps_module) == 1)
    assert(len(dep._re_ps_module) == 2)
    assert(dep._re_wrapper is not None)
    assert(dep._re_ps_version is not None)
    assert(dep._re_os_version is not None)
    assert(dep._re_become is not None)

#

# Generated at 2022-06-22 20:06:53.288542
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md_finder = PSModuleDepFinder()
    assert md_finder.ps_modules == {}
    assert md_finder.cs_utils_wrapper == {}
    assert md_finder.cs_utils_module == {}
    assert md_finder.ps_version == None
    assert md_finder.os_version == None
    assert md_finder.become == False


# Generated at 2022-06-22 20:06:59.138774
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("unix.ps1")
    finder.scan_exec_script("winrm.ps1")
    finder.scan_exec_script("pipelining.ps1")
    assert finder.exec_scripts


# Generated at 2022-06-22 20:07:09.496029
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp(filename):
        with open(filename, 'rb') as f:
            return f.read()
    name = 'become'
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script(name)
    # Test using the wrapper.ps1 file from ansible/executor/powershell folder as the fixture data
    assert _slurp('lib/ansible/executor/powershell/become.ps1') == ps_module_dep_finder.exec_scripts[name]
    # Test the wrapper doesn't require any module_util
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0

# Generated at 2022-06-22 20:07:19.141920
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    def _get_call_args(m_add_module, index):
        return m_add_module.call_args_list[index][0]

    def _get_ps_modules():
        '''
        Output of this should match the expected output of scan_module
        '''
        ps_modules = finder.ps_modules
        return [t[0] for t in ps_modules.items()]

    def _get_cs_utils():
        '''
        Output of this should match the expected output of scan_module
        '''
        cs_utils = finder.cs_utils_module
        return [t[0] for t in cs_utils.items()]

    # Add two PS module_utils

# Generated at 2022-06-22 20:07:22.020553
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p = PSModuleDepFinder()
    p.scan_exec_script("basic")


# Generated at 2022-06-22 20:07:30.676210
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

# Taken from Python's test.support._fake_streams in pypy and modified to return
# bytes.

# Generated at 2022-06-22 20:07:33.040786
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)

# Unit tests for scan_module() of class PSModuleDepFinder

# Generated at 2022-06-22 20:07:34.881769
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()

PSMODULEDEPFINDER = PSModuleDepFinder()



# Generated at 2022-06-22 20:07:42.195471
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    checker = PSModuleDepFinder()
    assert checker.ps_version is None
    assert checker.os_version is None
    assert checker.become is False
    assert checker.ps_modules == dict()
    assert checker.exec_scripts == dict()
    assert checker.cs_utils_wrapper == dict()
    assert checker.cs_utils_module == dict()


# Generated at 2022-06-22 20:07:43.544805
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Implement this test
    assert False


# Generated at 2022-06-22 20:07:45.112758
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()



# Generated at 2022-06-22 20:07:55.735376
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan_module in class PSModuleDepFinder
    # Arrange
    # Arrange
    module_folder = u"tests/modules"
    module_data = _slurp(u"%s/test_module.psm1" % module_folder)
    pmdf = PSModuleDepFinder()
    expected_module_utils = frozenset()

    # Act
    pmdf.scan_module(module_data)

    # Assert
    assert expected_module_utils == pmdf.ps_modules.keys()

    # Test scan_module with modules that have modules imported
    # Arrange
    module_data = _slurp(u"%s/win_group.psm1" % module_folder)
    pmdf = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:08.648095
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Starting test_PSModuleDepFinder_scan_exec_script")
    mod_name = "Ansible.Test"
    mod_ext = ".psm1"
    mod_fqn = "ansible_collections.microsoft.powershell.modules.%s" % mod_name

    pmdf = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:21.210595
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pkgutil
    import ansible.executor.powershell
    # this test case refer to the ps1 file below
    """
    # some comment
    cls
    # AnsibleRequires -PowerShell module_utils.somemodule
    # AnsibleRequires -CSharpUtil module_utils.someothermodule
    cls
    # another comment
    cls
    """
    exec_script_data = pkgutil.get_data("ansible.executor.powershell", "ansible_test.ps1")
    psm = PSModuleDepFinder()
    psm.scan_exec_script('ansible_test.ps1')
    assert psm.exec_scripts['ansible_test.ps1'] == exec_script_data, \
        "The ps1 file does not match expected content"

# Generated at 2022-06-22 20:08:24.412136
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_utils = PSModuleDepFinder()
    # Expected the module_utils is the instance of PSModuleDepFinder
    assert isinstance(module_utils, PSModuleDepFinder)


# Generated at 2022-06-22 20:08:37.264689
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert type(ps_dep_finder.cs_utils_wrapper) is dict
    assert type(ps_dep_finder.ps_modules) is dict
    assert type(ps_dep_finder.cs_utils_module) is dict
    assert type(ps_dep_finder.exec_scripts) is dict
    assert type(ps_dep_finder.become) is bool
    assert type(ps_dep_finder.os_version) is type(None)
    assert type(ps_dep_finder.ps_version) is type(None)
    assert type(ps_dep_finder._re_wrapper) is _sre.SRE_Pattern
    assert type(ps_dep_finder._re_cs_in_ps_module) is list

# Generated at 2022-06-22 20:08:41.898789
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf_obj = PSModuleDepFinder()
    psmdf_obj.scan_exec_script("win_acls")
    assert psmdf_obj.exec_scripts["win_acls"] == "exec_scripts/win_acls.ps1"

# Generated at 2022-06-22 20:08:52.408747
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:03.409833
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    test_data = (
        ('compare-version.psm1', {
            'ps_version': '6.0.0',
        }, {
            'cs_utils_wrapper': {
                'ansible_collections.ansible.builtin.plugins.module_utils.compare_version.compare_version': {
                    'path': 'test/unit/module_utils/test_compare-version.psm1',
                    'data': '# TEST_COMPARE_VERSION\r\n',
                }
            }
        }),
    )


# Generated at 2022-06-22 20:09:08.243895
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test is a bit of an odd ball because there's no way to mock the
    # required data. The only way to test this is to create a real tempdir
    # and dump the data into it for testing.
    pass

# Generated at 2022-06-22 20:09:20.420957
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Test case 1
    # all good
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('psrp_wrapper')
    # dep_finder.scan_module(data, wrapper=True, powershell=True)

# Generated at 2022-06-22 20:09:23.648423
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  ps_module_dep_finder = PSModuleDepFinder()
  ps_module_dep_finder.scan_module(module_data, fqn=None, wrapper=False, powershell=True)


# Generated at 2022-06-22 20:09:37.052374
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _strip_comments(data):

        # strip comments from the module data so we don't detect UTIL comments
        # in the module itself
        comment_re = re.compile(b'^\\s*#')
        data = b"\n".join([line for line in data.split(b"\n") if not comment_re.match(line)])
        return data


# Generated at 2022-06-22 20:09:43.723469
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules.keys()) == 0
    assert len(ps_module_dep_finder.exec_scripts.keys()) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper.keys()) == 0
    assert len(ps_module_dep_finder.cs_utils_module.keys()) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False



# Generated at 2022-06-22 20:09:48.365566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.ps_module_utils_loader import PSModuleUtilsLoader
    ps_loader = PSModuleUtilsLoader()
    # Load all utilities
    ps_loader.get_collection_list('ansible_collections.ansible.builtin')
    ps_loader.get_all()
    util_list = ps_loader.module_utils
    ps_dep_finder = PSModuleDepFinder()
    for util in util_list:
        if hasattr(util, 'DATA') and isinstance(util.DATA, str):
            ps_dep_finder.scan_module(to_text(util.DATA).encode(errors='surrogate_or_strict'), fqn=util.fqname)

# Generated at 2022-06-22 20:10:00.461531
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """Ensure that the PSModuleDepFinder class is properly constructed."""
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict(), "Actual: %s. Expected: dict()" % finder.ps_modules
    assert finder.exec_scripts == dict(), "Actual: %s. Expected: dict()" % finder.exec_scripts
    assert finder.cs_utils_wrapper == dict(), "Actual: %s. Expected: dict()" % finder.cs_utils_wrapper
    assert finder.cs_utils_module == dict(), "Actual: %s. Expected: dict()" % finder.cs_utils_module
    assert finder.ps_version is None, "Actual: %s. Expected: None" % finder.ps_version
    assert find

# Generated at 2022-06-22 20:10:10.177154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Use a real PowerShell module to get all the references from
    module_data = pkgutil.get_data('ansible_collections.ansible.builtin.plugins.module_utils.common.network.network',
                                   'ntp.psm1')

    finder = PSModuleDepFinder()
    finder.scan_module(module_data, fqn='ntp')
    assert finder.ps_modules
    assert finder.cs_utils_module
    assert finder.ps_version
    assert finder.os_version
    
if __name__ == '__main__':
    test_PSModuleDepFinder_scan_module()

# Generated at 2022-06-22 20:10:21.324387
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    call_args = []
    call_kwargs = []

    class MockPsModuleDepFinder(PSModuleDepFinder):
        def scan_module(self, *args, **kwargs):
            call_args.append(args)
            call_kwargs.append(kwargs)

    psmdf = MockPsModuleDepFinder()
    psmdf.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo')
    assert call_args[0][0] == b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo'
    assert call_kwargs[0]['wrapper'] == False
    assert call_kwargs[0]['powershell'] == True


# Generated at 2022-06-22 20:10:31.313159
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert repr(ps_module_dep_finder) == "PSModuleDepFinder()"
    assert not ps_module_dep_finder.ps_modules
    assert not ps_module_dep_finder.cs_utils_wrapper
    assert not ps_module_dep_finder.cs_utils_module
    assert not ps_module_dep_finder.ps_version
    assert not ps_module_dep_finder.os_version
    assert not ps_module_dep_finder.become



# Generated at 2022-06-22 20:10:32.844310
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:10:37.964480
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    # Check if module finder is instantiated.
    assert ps_module_finder.ps_modules == dict()
    assert ps_module_finder.exec_scripts == dict()
    assert ps_module_finder.cs_utils_wrapper == dict()
    assert ps_module_finder.cs_utils_module == dict()
    assert ps_module_finder.ps_version == None
    assert ps_module_finder.os_version == None
    assert ps_module_finder.become == False
    assert len(ps_module_finder._re_cs_module) == 1
    assert len(ps_module_finder._re_cs_in_ps_module) == 1
    assert len(ps_module_finder._re_ps_module) == 2
    assert ps_module_finder

# Generated at 2022-06-22 20:10:44.212126
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test method scan_exec_script in class PSModuleDepFinder"""

    ps = PSModuleDepFinder()
    # Assert
    with pytest.raises(AnsibleError):
        ps.scan_exec_script('test')



# Generated at 2022-06-22 20:10:49.079767
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    path = "ansible.executor.powershell.basic"
    obj.scan_exec_script(path)
    assert obj.exec_scripts[path]
    assert obj.ps_modules['Ansible.ModuleUtils.ProcessCommon']
    assert obj.ps_modules['Ansible.ModuleUtils.Basic']


# Generated at 2022-06-22 20:10:51.456572
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('raw')
    assert 'raw' in finder.exec_scripts.keys()



# Generated at 2022-06-22 20:11:00.958133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import os.path
    import pkgutil
    import random
    import shutil
    import tempfile

    import pytest

    import ansible.errors
    import ansible.executor.powershell
    import ansible.module_utils
    import ansible.module_utils.powershell.base

    from ansible.module_utils.powershell.base import PSModuleDepFinder, convert_slashes

    @pytest.fixture()
    def temp_dir(request):
        temp_dir = tempfile.mkdtemp()

        request.addfinalizer(lambda: shutil.rmtree(temp_dir, ignore_errors=True))
        return temp_dir


# Generated at 2022-06-22 20:11:13.640382
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.module_utils.basic import AnsibleModule    # noqa
    from ansible.module_utils.six import iteritems          # noqa
    from ansible.module_utils.common.collections import ImmutableDict  # noqa

    ps_module = '''
    #Requires -Module Ansible.ModuleUtils.TestModuleUtil
    #Requires -Module Ansible.ModuleUtils.TestModuleUtil2
    #Requires -Module Ansible.ModuleUtils.TestModuleUtil3 -Version 2.0
    #AnsibleRequires -Powershell ansible_collections.ns.coll.plugins.module_utils.testmoduleutil -Optional
    '''


# Generated at 2022-06-22 20:11:15.710116
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test method scan_module():
    # todo: implement
    pass

# Generated at 2022-06-22 20:11:25.817046
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import os
    import shutil
    import tempfile

    from ansible.module_utils._text import to_bytes, to_native

    from ansible.module_utils.common.process import get_bin_path
    from ansible.executor.powershell import find_powershell_script_paths
    from ansible.plugins.loader import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    test_psm1_data = """
#Requires -Module Ansible.ModuleUtils.Posh-SSH
#AnsibleRequires -CSharpUtil ansible_collections.ansible.windows.plugins.module_utils.rightscale_util
#ansiblerequires -powershell .powershell.ansible_module_tools
#Requires -Module Foo
    """

    test_data = b

# Generated at 2022-06-22 20:11:26.913337
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:11:36.787929
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.plugins.loader import ps_module_utils_loader
    collection_config = AnsibleCollectionConfig()

    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fh, abs_path = tempfile.mkstemp(dir=tmpdir)
    new_file = open(abs_path, 'w')

    # This file is the content of unit test test_PSModuleDepFinder_scan_module
    # Write data to the temporary file

# Generated at 2022-06-22 20:11:46.977791
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder()
    module_depfinder = PSModuleDepFinder()

    # Test with module with wrapped solutions
    data = """#PowerShell wrapper for module Ansible.ModuleUtils.NetApp.ONTAP
#AnsibleRequires -Module Ansible.ModuleUtils.NetApp.ONTAP
#AnsibleRequires -Wrapper ..library.ps1"""
    module_depfinder.scan_module(data)

    assert module_depfinder.ps_modules.keys() == set(['Ansible.ModuleUtils.NetApp.ONTAP'])

    # Test with module with C# utilities

# Generated at 2022-06-22 20:11:50.484952
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    name = ''
    assert not instance.scan_exec_script(name)


# Generated at 2022-06-22 20:12:01.287741
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Declare variables to test with
    module_data = """
#Requires -Module Ansible.ModuleUtils.Foo
#AnsibleRequires -Powershell Ansible.ModuleUtils.Bar
#AnsibleRequires -Powershell ansible_collections.this.does.not.Exist.plugins.module_utils.Baz
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.PowerShell.CSharpUtil
#AnsibleRequires -CSharpUtil ansible_collections.this.does.not.Exist.plugins.module_utils.PowerShell.CSharpUtil
#Requires -Version 6.1.0
#AnsibleRequires -OSVersion 10.0.0
#AnsibleRequires -Become
#AnsibleRequires -Wrapper Foo
"""
    finder = PSModuleDepFinder

# Generated at 2022-06-22 20:12:10.526932
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    module_data = pkgutil.get_data("ansible_collections.not_a_real_collection.plugins.modules",
                                   "include_vars.psm1")
    try:
        finder.scan_module(module_data, fqn='not_a_real_collection.plugins.modules.include_vars')
    except Exception as e:
        raise AssertionError("Could not scan the module data for include_vars: %s" % to_native(e))


# Generated at 2022-06-22 20:12:21.161351
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    import unittest
    import tempfile
    import shutil
    import ansible.executor.powershell
    import ansible.module_utils
    import os

    mocked_import = unittest.mock.MagicMock()
    mocked_import.__path__ = ansible.executor.powershell.__path__

    @unittest.mock.patch('ansible.module_utils', mocked_import)
    def run_scan_exec_script(self):

        with tempfile.TemporaryDirectory() as tmp_module_root:

            ansible_executor_powershell_path = ansible.executor.powershell.__path__[0]

            # Copy necessary assets to temporary directory.

# Generated at 2022-06-22 20:12:32.358143
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mocked_ansible_executor_powershell_ps1 = b'\n\n[System.Management.Automation.ScriptBlock]::Create($Script)\n'
    with mock.patch.object(pkgutil, 'get_data', return_value=mocked_ansible_executor_powershell_ps1) as get_data:
        # bootstrap a class to test
        psmdf = PSModuleDepFinder()
        psmdf.ps_modules = {}
        psmdf.exec_scripts = {}
        psmdf.cs_utils_wrapper = {}
        psmdf.cs_utils_module = {}
        psmdf.ps_version = None
        psmdf.os_version = None
        psmdf.become = False

# Generated at 2022-06-22 20:12:45.407838
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    filename = "test_data/test_module.psm1"
    with open(filename, 'rb') as f:
        module_data = f.read()

    # test import of PowerShell module_utils
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 2

    assert finder.ps_modules["Ansible.ModuleUtils.PowerShell.Convert"]
    assert finder.ps_modules["Ansible.ModuleUtils.PowerShell.WebRequest"]

    # test import of C# module_utils from a PowerShell module
    finder = PSModuleDepFinder()
    finder.scan_module(module_data, powershell=False)
    assert len(finder.cs_utils_module) == 0

    # test import of

# Generated at 2022-06-22 20:12:58.367335
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes

    test_module_path = "test/unit/utils/powershell/test_module_deps_finder/test_module.psm1"
    test_module = to_bytes(_slurp(test_module_path))

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(test_module)

    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {"Ansible.TestUtil": {'path': 'test/unit/utils/powershell/data/Ansible.TestUtil.cs', 'data': b'#Ansible\n'}}

# Generated at 2022-06-22 20:13:09.173868
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmd = PSModuleDepFinder()
    fqn = 'ansible_collections.ns.coll.plugins.module_utils.ps_mod_utils'
    data = pkgutil.get_data(fqn, 'synchronize.psm1')
    ps_mod_util_data = to_bytes(data)
    ps_mod_util_data = to_bytes(data)

# Generated at 2022-06-22 20:13:18.036479
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    with open('test/unit/module_utils/ps_module_1.ps1', 'rb') as f:
        m = f.read()
    d = PSModuleDepFinder()
    d.scan_module(m)
    assert d.ps_version == '1.1.1.1' and d.os_version is None and d.become is False
    assert d.ps_modules.keys() == {'Ansible.ModuleUtils.OtherTest'}
    assert d.cs_utils_module == {}
    assert d.exec_scripts == {}
    assert len(d.ps_modules['Ansible.ModuleUtils.OtherTest']['data']) > 10


# Generated at 2022-06-22 20:13:25.221112
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder is not None
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_module) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.exec_scripts) == 0
    assert len(finder._re_cs_module) == 1
    assert finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')
    assert len(finder._re_cs_in_ps_module) == 1

# Generated at 2022-06-22 20:13:36.824427
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:13:47.458868
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 20:13:50.939979
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(finder.ps_modules == dict())
    assert(finder.cs_utils_wrapper == dict())
    assert(finder.cs_utils_module == dict())


# Generated at 2022-06-22 20:13:51.512318
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-22 20:13:57.406675
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder.ps_modules == {}
    assert depfinder.exec_scripts == {}
    assert depfinder.cs_utils_wrapper == {}
    assert depfinder.cs_utils_module == {}
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False



# Generated at 2022-06-22 20:14:08.390444
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:14:17.272298
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    deps_finder = PSModuleDepFinder()
    assert deps_finder.ps_version is None
    assert deps_finder.os_version is None
    assert not deps_finder.become

    assert len(deps_finder.ps_modules.keys()) == 0
    assert len(deps_finder.exec_scripts.keys()) == 0

    assert len(deps_finder.cs_utils_wrapper.keys()) == 0
    assert len(deps_finder.cs_utils_module.keys()) == 0


# Generated at 2022-06-22 20:14:18.836120
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Write unit test for this function
    pass

# Generated at 2022-06-22 20:14:25.109412
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # initialize
    psmd = PSModuleDepFinder()
    psmd.exec_scripts = {"foo": "1", "bar": "2"}
    # act
    psmd.scan_exec_script("foo")
    psmd.scan_exec_script("bar")
    # assert
    assert len(psmd.exec_scripts) == 2
    assert psmd.exec_scripts["foo"] == "1"
    assert psmd.exec_scripts["bar"] == "2"



# Generated at 2022-06-22 20:14:36.788352
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'''
#requires -module Ansible.ModuleUtils.Foo
#ansiblerequires -powershell Ansible.ModuleUtils.Foo
#ansiblerequires -wrapper Foo
#ansiblerequires -csharputil ansible_collections.ansible.test.plugins.module_utils.testmodule
''')

    finder.scan_module(b'''
#ansiblerequires -powershell ansible_collections.ansible.test.plugins.module_utils.testmodule
#ansiblerequires -powershell ansible_collections.ns.collection.plugins.module_utils.testmodule
#ansiblerequires -powershell .testmodule
''')
