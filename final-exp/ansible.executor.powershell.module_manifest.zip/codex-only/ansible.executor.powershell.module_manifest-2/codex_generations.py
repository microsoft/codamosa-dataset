

# Generated at 2022-06-22 20:04:41.918380
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Test the script to strip comments and empty lines

# Generated at 2022-06-22 20:04:48.118845
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become == False


# Generated at 2022-06-22 20:05:00.557654
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:05:01.502640
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:05:12.673915
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from hypothesis import given
    from hypothesis.strategies import integers, text
    import os
    import types
    import tempfile
    # we need to find a way with hypothesis to batch the tests

# Generated at 2022-06-22 20:05:15.625760
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fixture = _PSModuleDepFinder()
    fixture._add_module = Mock(return_value=None)
    fixture.ps_modules = {'Ansible.ModuleUtils.PowerShell.Convert': {}}
    fixture.scan_exec_script('convert')
    fixture._add_module.assert_called_once_with('Ansible.ModuleUtils.PowerShell.Convert', '.psm1', None, False)


# Generated at 2022-06-22 20:05:22.661701
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class Options(object):
        debug = False

    class AnsibleModule(object):
        _debug = False

    class AnsibleCollectionConfig(object):
        _config = None

    C.config = AnsibleCollectionConfig()
    C.config._config = {"ANSIBLE_DEBUG": False}
    C.options = Options()
    module = AnsibleModule()
    pmf = PSModuleDepFinder()
    module_data = b'#Requires -Module Ansible.ModuleUtils.Foo\n#Requires -Module Ansible.ModuleUtils.Foo.Bar'
    pmf.scan_module(module_data)


# Generated at 2022-06-22 20:05:35.467851
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # mock to_text()
    to_text = mock.Mock()
    to_text.side_effect = ["ansible", "script_name.ps1"]

    # mock to_native()
    to_native = mock.Mock()
    to_native.side_effect = ["ansible.executor.powershell", "script_name.ps1"]

    # Mock pkgutil.get_data()
    mock_data = mock.Mock(return_value="#AnsibleRequires -CSharpUtil module_util.cs")
    pkgutil.get_data = mock_data

    # mock pkgutil.get_data()
    mock_data = mock.Mock(return_value="#requires -module Ansible.ModuleUtils.module_util.psm1")
    pkgutil.get_data = mock

# Generated at 2022-06-22 20:05:48.480520
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with package_data
    md = PSModuleDepFinder()

    md.scan_exec_script("powershell.ps1")
    assert md.exec_scripts['powershell.ps1']

    # Test with file
    md = PSModuleDepFinder()

    md.scan_exec_script("powershell2.ps1")
    assert md.exec_scripts['powershell2.ps1']

    # Test with non-existing file
    md = PSModuleDepFinder()
    try:
        md.scan_exec_script("powershell3.ps1")
        assert False, "Unexpected successful return from powershell3.ps1"
    except Exception as e:
        assert 'Could not find executor powershell script for' in str(e), "Unexpected error from powershell3.ps1 : %s" % e



# Generated at 2022-06-22 20:05:57.819458
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import io
    import unittest
    from ansible.module_loader.powershell.common import PSModuleDepFinder
    from ansible.module_loader.powershell.common import _slurp

    class TestPSModuleDepFinder(unittest.TestCase):
        def test_scan_module(self):
            fh = io.BytesIO()

            # Create a powershell file with a module util dependency
            ps_file_content = to_bytes(u'''
                #Requires -Module Ansible.ModuleUtils.Something
            ''')
            fh.write(to_bytes(ps_file_content))
            fh.seek(0)

            finder = PSModuleDepFinder()
            finder.scan_module(fh.getvalue())

            # Make sure we got the module util

# Generated at 2022-06-22 20:06:07.091252
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.become == False
    assert finder.exec_scripts == {}
    assert finder.os_version is None
    assert finder.ps_version is None
    assert finder.ps_modules == {}
    assert finder.cs_utils_module == {}
    assert finder.cs_utils_wrapper == {}
    name = 'module_utils/powershell/caching'
    name1 = 'module_utils/powershell/basic'
    finder.scan_exec_script(name)
    assert finder.become == False
    assert len(finder.exec_scripts) == 1
    finder.scan_exec_script(name1)
    assert len(finder.exec_scripts) == 2
    assert finder.os_version is None
    assert finder

# Generated at 2022-06-22 20:06:16.893484
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import collections
    import string
    import random
    import sys
    import os

    sys.path.append(os.path.dirname(__file__))
    import ps_module_util_loader
    loader = ps_module_util_loader.PSModuleUtilsLoader()
    loader.set_dirs(['test/unit/data/module_utils/powershell'])
    loader.load_plugins('.psm1')

    test_cases = collections.OrderedDict()


# Generated at 2022-06-22 20:06:22.136263
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    b_data = to_bytes("#AnsibleRequires -CSharpUtil ansible.netcommon.netcommon")
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("foo")
    assert ps_module_dep_finder.exec_scripts
    assert ps_module_dep_finder.cs_utils_wrapper


# Generated at 2022-06-22 20:06:23.159022
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # pylint: disable=unused-variable
    psmdf = PSModuleDepFinder()



# Generated at 2022-06-22 20:06:28.427667
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:35.850620
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    # Test PSModuleDepFinder object is initialized correctly
    assert len(dep_finder.ps_modules.keys()) == 0
    assert len(dep_finder.cs_utils_wrapper.keys()) == 0
    assert len(dep_finder.cs_utils_module.keys()) == 0
    assert len(dep_finder.exec_scripts.keys()) == 0

    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2


# Generated at 2022-06-22 20:06:45.682058
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class MockModuleUtilsResource(object):
        def __init__(self):
            self.data = None
            self.path = None

    class MockModuleUtilsResources(dict):
        def add(self, name, data, path):
            self[name] = MockModuleUtilsResource()
            self[name].data = data
            self[name].path = path

    class MockPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            super(MockPSModuleDepFinder, self).__init__()
            self.ps_modules = MockModuleUtilsResources()
            self.cs_utils_module = MockModuleUtilsResources()
            self.cs_utils_wrapper = MockModuleUtilsResources()


# Generated at 2022-06-22 20:06:49.977533
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()

PS_MODULE_DEP_FINDER = PSModuleDepFinder()



# Generated at 2022-06-22 20:06:55.940161
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Test 1.
    # Test with valid executor powershell script
    # Should return a dict object
    md = PSModuleDepFinder()
    md.scan_exec_script(to_text('windows_common_inner'))

    # Test 2.
    # Test with invalid executor powershell script
    # Should raise an error
    md = PSModuleDepFinder()
    md.scan_exec_script(to_text('invalid_windows_common_inner'))

# Generated at 2022-06-22 20:07:07.065798
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = to_text('''\
#Requires -Module X, Y, Z

#AnsibleRequires -PowerShell a, b, c

#AnsibleRequires -Wrapper d
#Blah
line''')

    datagen = (x for x in enumerate((data,), 1))

    class sample_find_plugin:
        fqn_to_path_map = {}

        @classmethod
        def find_plugin(cls, fqn, ext=''):
            return cls.fqn_to_path_map[fqn]

    class sample_ps_module_dep_finder(PSModuleDepFinder):
        def __init__(self):
            # need these as they are checked in _add_module
            self.ps_modules = {}
            self.exec_scripts = {}

       

# Generated at 2022-06-22 20:07:15.727983
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from sys import modules
    PSModuleDepFinder = modules[__name__].PSModuleDepFinder
    ps_module_utils_loader = modules[__name__].ps_module_utils_loader
    scanner = PSModuleDepFinder()
    module_data = b"#Requires -Version 5.1"
    scanner.scan_module(module_data)
    assert scanner.ps_version == "5.1.0"
    assert scanner.os_version is None
    assert scanner.become is False
    assert scanner.ps_modules == {}
    assert scanner.cs_utils_wrapper == {}
    assert scanner.cs_utils_module == {}
    assert scanner.exec_scripts == {}

    module_data = b"#AnsibleRequires -OSVersion 6.2"
    scanner.scan_module(module_data)

# Generated at 2022-06-22 20:07:23.102436
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Set up the internal data structures of PSModuleDepFinder to simulate a module_name.psm1 that calls a module_util
    # named module_util_name
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping

    f_name = 'test_PSModuleDepFinder_scan_module' + str(random.randint(0, 10000000))
    fd, f_path = tempfile.mkstemp(prefix=f_name, suffix='.psm1')
    os.close(fd)

# Generated at 2022-06-22 20:07:29.671213
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder._re_ps_module) == 2
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1
    assert len(ps_module_dep_finder._re_cs_module) == 1


# Returns the data from the given path

# Generated at 2022-06-22 20:07:31.064716
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True == True



# Generated at 2022-06-22 20:07:35.870868
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pd = PSModuleDepFinder()
    assert pd.ps_modules == {}
    assert pd.cs_utils_wrapper == {}
    assert pd.cs_utils_module == {}
    assert pd.ps_version is None
    assert pd.os_version is None
    assert pd.become is False



# Generated at 2022-06-22 20:07:39.134175
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert(isinstance(f, PSModuleDepFinder))


# Generated at 2022-06-22 20:07:43.032878
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert '.' in psmdf._re_cs_module[0].pattern
    assert '.' in psmdf._re_cs_in_ps_module[0].pattern
    assert '.' in psmdf._re_ps_module[0].pattern


# Generated at 2022-06-22 20:07:53.569912
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest

    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b"#Requires -Module Ansible.ModuleUtils.CommonUtils\n")
    assert psmdf.ps_modules
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}

    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b"#AnsibleRequires -PowerShell ansible_collections.geerlingguy.windows.plugins.module_utils.geerlingguy.windows")
    assert psmdf.ps_modules
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}

    psmdf = PSModuleDepFinder()
    psmdf.scan_

# Generated at 2022-06-22 20:07:55.494627
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    df = PSModuleDepFinder()
    assert isinstance(df, PSModuleDepFinder)



# Generated at 2022-06-22 20:08:01.073647
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = 'Test_PSModuleDepFinder_scan_exec_script'

    content = '# executor script test'
    exec_script_path = os.path.join(C.DEFAULT_LOCAL_TMP, name + '.ps1')

    with open(exec_script_path, 'w') as f:
        f.write(to_text(content))

    finder.scan_exec_script(name)

    assert finder.exec_scripts[name] == to_bytes(content)



# Generated at 2022-06-22 20:08:13.763891
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:08:23.214689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for issue https://github.com/ansible/ansible/issues/54541

    class TestPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            self.cs_utils_wrapper = dict()
            self.exec_scripts = dict()

        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            # _add_module is called with wrapper=True, but because the module
            # being scanned is in the executor package, the plugin loader
            # will find it and set wrapper=False in the resulting call to
            # scan_module, causing this error to occur.
            assert not optional

    finder = TestPSModuleDepFinder()

# Generated at 2022-06-22 20:08:26.833807
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('powershell_base')
    assert 'powershell_base.ps1' in psmdf.exec_scripts
    assert psmdf.exec_scripts['powershell_base.ps1']



# Generated at 2022-06-22 20:08:32.257128
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(to_text("Pipeline"))
    assert psmdf.exec_scripts.get(to_text("Pipeline")) is not None
    assert len(psmdf.exec_scripts.get(to_text("Pipeline"))) > 0


# Generated at 2022-06-22 20:08:44.084379
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_dep_finder = PSModuleDepFinder()

    assert psmodule_dep_finder
    assert psmodule_dep_finder.ps_modules
    assert psmodule_dep_finder.exec_scripts
    assert psmodule_dep_finder.cs_utils_wrapper
    assert psmodule_dep_finder.cs_utils_module
    assert psmodule_dep_finder.ps_version is None
    assert psmodule_dep_finder.os_version is None
    assert psmodule_dep_finder.become is False
    assert psmodule_dep_finder._re_cs_module
    assert psmodule_dep_finder._re_cs_in_ps_module
    assert psmodule_dep_finder._re_ps_module
    assert psmodule_dep_finder._re_wrapper
    assert psmodule_dep_finder._re_ps_

# Generated at 2022-06-22 20:08:54.143818
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    # Make a temporary directory for the collection
    col_dir = tempfile.mkdtemp()
    # Create a module util file
    module_util_file = os.path.join(col_dir, 'plugins', 'module_utils', 'foo.psm1')
    os.makedirs(os.path.dirname(module_util_file))
    with open(module_util_file, 'wb') as f:
        f.write(b"#AnsibleRequires -CSharpUtil bar")
    # Create a csharp module util in the same collection
    cs_util_file = os.path.join(col_dir, 'plugins', 'module_utils', 'bar.cs')
    os.makedirs(os.path.dirname(cs_util_file))

# Generated at 2022-06-22 20:08:55.051156
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:08:56.004818
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:09:00.857778
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder class
    ps_module_dep_finder = PSModuleDepFinder()
    
    # Assert the return value for sample value of name
    assert ps_module_dep_finder.scan_exec_script('name').__class__.__name__ == 'NoneType'


# Generated at 2022-06-22 20:09:13.685752
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Test module scan_module with valid and invalid inputs"""

    # Module path of the test file
    path_of_module = 'test/units/module_utils/test_module.ps1'

    # Sample data to test scan_module method

# Generated at 2022-06-22 20:09:18.656420
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Arrange
    mdf = PSModuleDepFinder()
    module_data = ""
    # Act
    mdf.scan_module(module_data)
    # Assert
    assert mdf.ps_modules == {}


# Generated at 2022-06-22 20:09:19.793069
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:09:27.938655
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.cs_utils_module == {}

    assert pmdf._re_cs_module
    assert pmdf._re_cs_in_ps_module
    assert pmdf._re_ps_module
    assert pmdf._re_wrapper
    assert pmdf._re_ps_version
    assert pmdf._re_os_version
    assert pmdf._re_become


# Test _strip_comments and _slurp in module_utils/powershell/_utils.py

# Generated at 2022-06-22 20:09:34.118297
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is an unit test script written to ensure that the functionality of the method scan_exec_script of class PSModuleDepFinder doesn't break.
    fqn = u"namespace.collection.module"
    import ansible.module_utils.powershell.core as core
    mod_dep_finder = PSModuleDepFinder()
    mod_dep_finder.scan_exec_script("win_ping")


# Generated at 2022-06-22 20:09:43.068804
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for PSModuleDepFinder.scan_module
    #
    # Assertion 1
    # Test when 'Ansible.ModuleUtils.CommonArgs' is found in a powershell
    # module, it gets added to `self.ps_modules`

    # Arrange
    # Create an instance of PSModuleDepFinder
    ps_dep_finder = PSModuleDepFinder()

    # Act
    # Call `scan_module` for the following input
    ps_dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.CommonArgs\n')

    # Assert
    # assert that Ansible.ModuleUtils.CommonArgs has been added to
    # self.ps_modules.

# Generated at 2022-06-22 20:09:44.006191
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Add test code here
    raise Exception("Test not implemented")


# Generated at 2022-06-22 20:09:55.658651
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf1 = PSModuleDepFinder()
    if psmdf1.ps_modules != dict():
        raise AssertionError()
    if psmdf1.exec_scripts != dict():
        raise AssertionError()
    if psmdf1.cs_utils_wrapper != dict():
        raise AssertionError()
    if psmdf1.cs_utils_module != dict():
        raise AssertionError()
    if psmdf1.ps_version is not None:
        raise AssertionError()
    if psmdf1.os_version is not None:
        raise AssertionError()
    if psmdf1.become is not False:
        raise AssertionError()


# Generated at 2022-06-22 20:10:07.666286
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    @mock.patch('ansible.module_utils.powershell.PSModuleDepFinder._add_module',
                new_callable=Mock, return_value=(None,))
    @mock.patch('__builtin__.open', new_callable=mock_open, read_data="")
    def test_with_data(mock_open, mock_add_module):
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_exec_script('test_script')

        assert mock_open.call_count == 1
        assert mock_open.call_args[0][0] == '/path/to/lib/ansible/executor/powershell/test_script.ps1'
        assert mock_open.call_args[0][1] == 'rb'

        assert mock_add_

# Generated at 2022-06-22 20:10:19.590038
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pd = PSModuleDepFinder()
    ps_module = """#!/usr/bin/env powershell
#Requires -Module Ansible.ModuleUtils.Config
#Requires -Module Ansible.ModuleUtils.Config
#Requires -Module Ansible.ModuleUtils.Config
#Requires -Module Ansible.ModuleUtils.Config
import-module ansible_collections.foo.bar.plugins.module_utils.config
#Requires -Module Ansible.ModuleUtils.Config
#Requires -Module Ansible.ModuleUtils.Config

$a = @(1,2,3)
$b = $a | where {$_ -eq 2}
$b | write-output"""
    pd.scan_module(ps_module.encode('utf-8'))
    assert len(pd.ps_modules.keys()) == 1
   

# Generated at 2022-06-22 20:10:32.844336
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.collections import ImmutableDict
    # Create mock of parameter module_util_data

# Generated at 2022-06-22 20:10:42.212437
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = to_bytes('''#AnsibleRequires -wrapper some_module
#Requires -Module Ansible.ModuleUtils.Something
#Requires -Module Ansible.ModuleUtils.SomethingElse
''')
    x = PSModuleDepFinder()
    x.scan_module(module_data, wrapper=True)
    assert 'some_module' in x.exec_scripts.keys()
    assert 'ansible.module_utils.something' in x.ps_modules.keys()
    assert 'ansible.module_utils.somethingelse' in x.ps_modules.keys()
    assert 'ansible.module_utils.something' in x.ps_modules.keys()


# Generated at 2022-06-22 20:10:51.678455
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:57.064527
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert not dep_finder.ps_modules
    assert not dep_finder.exec_scripts
    assert not dep_finder.cs_utils_wrapper
    assert not dep_finder.cs_utils_module
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become


# Generated at 2022-06-22 20:11:04.682334
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder._re_cs_module == [
        re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]

# Generated at 2022-06-22 20:11:09.583813
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:12.289265
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Invoke-BitsTransfer')

# Generated at 2022-06-22 20:11:22.453870
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Given
    dep_finder = PSModuleDepFinder()
    dep_finder._re_cs_module = [
        re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]

# Generated at 2022-06-22 20:11:28.725781
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # test PSModuleDepFinder constructor
    finder = PSModuleDepFinder()
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False



# Generated at 2022-06-22 20:11:31.617304
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("test_module")

# Generated at 2022-06-22 20:11:44.793841
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    unit test for
    scan_exec_script
    '''
    # This is also used by validate-modules to get a module's required utils in base and a collection.
    ps_modules = dict()
    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn't needed
    cs_utils_wrapper = dict()
    cs_utils_module = dict()
    exec_scripts = dict()
    name='CommonUtils'

    module_data = pkgutil.get_data("ansible.module_utils.common.powershell", to_native(name + ".ps1"))
    b_data = to_bytes(module_data)
    if C.DEFAULT_DEBUG:
            exec_script = b_data


# Generated at 2022-06-22 20:11:48.690617
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    x = PSModuleDepFinder()
    assert x.ps_version == None
    assert x.os_version == None
    assert x.become == False


# Generated at 2022-06-22 20:12:00.129382
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script('raw_script')

# Generated at 2022-06-22 20:12:12.885487
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    # initialize the class instance
    finder = PSModuleDepFinder()

    # mock the pkgutil.get_data() function
    with patch("pkgutil.get_data", return_value=b"abc\nansible") as mock_get_data, \
            patch("ansible.errors.AnsibleError"):
        finder.scan_exec_script("test_file")
        mock_get_data.assert_called_once_with("ansible.executor.powershell", "test_file.ps1")

    # test AnsibleError
    with patch("pkgutil.get_data", return_value=None), \
            patch("ansible.errors.AnsibleError") as mock_AnsibleError:
        finder.scan_exec_script("test_file")
        mock_AnsibleError

# Generated at 2022-06-22 20:12:17.837381
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test the constructor of class PSModuleDepFinder with default arguments
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-22 20:12:28.134751
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Test PS module which doesn't import any module_utils
    finder.scan_module(b"#!/usr/bin/env powershell", fqn="random.module",
                       wrapper=False, powershell=True)
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None

    # Test PS module which imports a builtin module_util using old syntax
    finder.scan_module(b"#!/usr/bin/env powershell\n#Requires -Module Ansible.ModuleUtils.Foo1",
                       fqn="random.module", wrapper=False, powershell=True)

# Generated at 2022-06-22 20:12:39.864388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text

    def _mock_get_data(package_name, resource_name):
        if resource_name == 'testmodule.psm1':
            return '#Requires -Module Ansible.ModuleUtils.testmodule'
        elif resource_name == 'othermodule.psm1':
            return '#Requires -Module Ansible.ModuleUtils.othermodule'
        elif resource_name == 'othermodule.cs':
            return 'using Ansible.ModuleUtils.othermodule;'
        else:
            raise AssertionError("Unexpected resource name: " + resource_name)


# Generated at 2022-06-22 20:12:53.252767
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Test fixture values.
    ps_module_fixture_1_contents = b"""#Requires -Module Ansible.ModuleUtils.Module1\nThis is a test file.\n"""
    ps_module_fixture_2_contents = b"""#Requires -Module Ansible.ModuleUtils.Module1\n#Requires -Module Ansible.ModuleUtils.Module2\nThis is a test file.\n"""
    ps_module_fixture_3_contents = b"""#Requires -Module Ansible.ModuleUtils.Module1\n#AnsibleRequires -Powershell Ansible.ModuleUtils.Module2\nThis is a test file.\n"""

    # Set up the object on which to run the tests.
    ps_module_dep_finder = PSModuleDepFinder()

    # Get the class attribute values

# Generated at 2022-06-22 20:13:06.019996
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    lines = [
        "# REQUIRES -Module Ansible.ModuleUtils.PowerShell",
        "# REQUIRES -Module Ansible.ModuleUtils.Legacy",
        "# REQUIRES -Module Ansible.ModuleUtils.Powershell.SecurityPolicy",
        "# REQUIRES -Module collection.foobar.plugins.module_utils.CommonUtils",
        "# REQUIRES -Module ABC.NetCoreUtil",
        "# REQUIRES -Module ModuleUtils.Test",
        "# REQUIRES -Version 7.0"
    ]

    mu_finder = PSModuleDepFinder()

    mu_finder.scan_module('\n'.join(lines).encode('utf-8'))

    assert len(mu_finder.ps_modules) == 5

# Generated at 2022-06-22 20:13:08.101072
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder is not None


# Generated at 2022-06-22 20:13:10.469410
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(isinstance(finder, PSModuleDepFinder))


# Generated at 2022-06-22 20:13:20.077916
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:32.078443
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert not finder.become
    assert finder._re_cs_module
    assert finder._re_cs_in_ps_module
    assert finder._re_ps_module
    assert finder._re_wrapper
    assert finder._re_ps_version
    assert finder._re_os_version
    assert finder._re_become


# Generated at 2022-06-22 20:13:37.018300
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Remove this test after Ansible is able to support new CSUtil dep finder
    # The new dep finder is able to determine the CS module dependencies for the old
    # PowerShell modules. This test is here to confirm that we don't get any error
    # during the migration from the old process.
    from ansible.executor.powershell import module_runner, shell_runner
    from ansible.module_utils.common._collections_compat import Mapping

    def _fake_runner(self, conn, tmp, module_name, module_args, inject, complex_args=None, **kwargs):
        # Remove the complex_args since it is only introduced in 2.9, which means
        # we can't use this test with 2.9
        pass


# Generated at 2022-06-22 20:13:41.136130
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell import ps_main
    assert ps_main is not None
    assert callable(ps_main)


# Generated at 2022-06-22 20:13:49.991781
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    testcase = "{0}_{1}".format('PSModuleDepFinder', 'scan_module')

    psmdf = PSModuleDepFinder()

# Generated at 2022-06-22 20:14:00.078053
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize finder
    finder = PSModuleDepFinder()
    # Run scan_exec_script
    finder.scan_exec_script('Microsoft.PowerShell.Archive')
    # Assert finder.exec_scripts has a entry for the script
    assert 'Microsoft.PowerShell.Archive' in finder.exec_scripts
    # Assert finder.exec_scripts['Microsoft.PowerShell.Archive'] is the contents of the script
    assert finder.exec_scripts['Microsoft.PowerShell.Archive'] == pkgutil.get_data('ansible.executor.powershell', 'Microsoft.PowerShell.Archive.ps1')

# Generated at 2022-06-22 20:14:09.801987
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method and ensure it captures the expected data.
    class TestData(object):
        def __init__(self):
            self.mods_data = dict()

        def add_module(self, m, data):
            self.mods_data[m] = data

    def load_json_data(fqn, optional=False, powershell=True):
        # Helper function to load data from the tests/module_utils_data.json
        # file.
        fqn = to_native(fqn)
        if fqn not in test_data.mods_data.keys():
            raise AnsibleError('Could not find module \'%s\' in data file' % fqn)

        json_data = test_data.mods_data[fqn]


# Generated at 2022-06-22 20:14:22.583249
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder._re_cs_module[0].match(b"using Ansible.ModuleUtils.Common;")
    assert ps_module_dep_finder._re_cs_module[0].match(b"using ansible_collections.namespace.collection.plugins.module_utils.common;")
    assert ps_module_dep_finder._re_cs_in_ps_module[0].match(b"#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Common")
    assert ps_module_dep_finder._re_cs_in_ps_module[0].match(b"#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.common")
    assert ps

# Generated at 2022-06-22 20:14:26.427093
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf is not None

# Function to return the random value
# This is used when running multiple containers at the same time
# to avoid a race condition

# Generated at 2022-06-22 20:14:37.730883
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # init PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()
    # create a sample module to test scan_module
    data = "#Requires -Module Ansible.ModuleUtils.Basic\n#Requires -Module Ansible.ModuleUtils.Test\n\n" \
           "#AnsibleRequires -PowerShell ansible_collections.test.test_collection.plugins.module_utils.test\n" \
           "#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test"
    # call scan_module
    ps_module_dep_finder.scan_module(data)
    # check if the ansible module utilities were added to ps_modules
    assert('Ansible.ModuleUtils.Basic' in ps_module_dep_finder.ps_modules.keys())