

# Generated at 2022-06-22 20:04:33.402753
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    m = PSModuleDepFinder()
    m.scan_exec_script('Windows_Firewall')
    assert isinstance(m.exec_scripts['Windows_Firewall'], bytes)



# Generated at 2022-06-22 20:04:46.537652
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from collections import namedtuple
    module_data = pkgutil.get_data('ansible.plugins.action', to_native('windows_group.ps1', errors='surrogate_or_strict'))
    assert module_data is not None
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:04:49.058766
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None


# Generated at 2022-06-22 20:05:01.142261
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils import basic
    from ansible.module_utils import url
    from ansible.module_utils.urls import fetch_url, open_url
    from ansible.module_utils.six.moves.urllib_parse import urlsplit, urlunsplit
    from ansible.module_utils.urls import basic as basic_url
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import pkgutil
    import re
    import base64
    import json
    import random
    import errno
    import textwrap
    import types
    import string

    # initialize module variables
    ps_modules = dict()
    exec_scripts = dict()
    cs_utils_wrapper = dict()
    cs_utils_module = dict()
    ps

# Generated at 2022-06-22 20:05:06.736846
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p._re_ps_module[0].match(b"#  requires -modules Ansible.ModuleUtil.Test") is not None
    assert p.ps_modules == {}
    assert p.cs_utils_wrapper == {}
    assert p.cs_utils_module == {}
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become is False


# Generated at 2022-06-22 20:05:12.045965
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    testdep = PSModuleDepFinder()
    with open('test/module_utils_test.psm1', 'rb') as f:
        data = f.read()
    assert data
    testdep.scan_module(data)
    assert testdep.ps_modules.keys() == set(['Ansible.ModuleUtils.Docker.Common', 'Ansible.ModuleUtils.Docker.Swarm'])



# Generated at 2022-06-22 20:05:22.272807
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Mock imports
    import_module_orig = import_module
    pkgutil_get_data_orig = pkgutil.get_data
    pkgutil_get_data_return = b"#Requires -Module Ansible.Builtin\r\n\r\nclass TestModule(AnsibleModule):\r\n      return"
    def import_moduleMock(arg1, package=None):
        return Mock()
    def pkgutil_get_dataMock(arg1, arg2):
        return pkgutil_get_data_return
    # import_module = import_moduleMock
    pkgutil.get_data = pkgutil_get_dataMock
    # Test
    PSModuleDepFinderObj = PSModuleDepFinder()

# Generated at 2022-06-22 20:05:26.066041
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_obj = PSModuleDepFinder()
    assert isinstance(module_obj, object)


# Generated at 2022-06-22 20:05:36.944254
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import pkgutil
    try:
        import __main__
    except ImportError:
        __main__ = None
    import ansible.executor.powershell
    test = PSModuleDepFinder()

    # We want to test a non-standard location for module_utils
    custom_path = os.path.join(os.path.dirname(__file__), '..', 'module_utils')
    if os.path.isdir(custom_path):
        # Make sure we don't have a custom path already
        if custom_path not in sys.path:
            sys.path.append(custom_path)

        if __main__ is not None:
            # Make sure we don't have a custom path in main module
            if custom_path not in __main__.__path__:
                __main__.__

# Generated at 2022-06-22 20:05:49.657086
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Test scan_module method
    ps_module_dep_finder = PSModuleDepFinder()
    assert(ps_module_dep_finder.ps_modules == {})

    # Run proper code
    data = pkgutil.get_data("ansible.plugins.action", to_native("win_ping.ps1"))
    ps_module_dep_finder.scan_module(to_bytes(data))

    # Verify results

# Generated at 2022-06-22 20:05:58.754994
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(len(finder.ps_modules) == 0)
    assert(len(finder.exec_scripts) == 0)
    assert(len(finder.cs_utils_wrapper) == 0)
    assert(len(finder.cs_utils_module) == 0)
    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)
    assert(len(finder._re_cs_module) == 1)
    assert(len(finder._re_cs_in_ps_module) == 1)
    assert(len(finder._re_ps_module) == 2)
    assert(finder._re_wrapper is not None)
    assert(finder._re_ps_version is not None)

# Generated at 2022-06-22 20:06:09.471486
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper
    assert finder._re_ps_version
    assert finder._re_os_version
    assert finder._re_become


# Generated at 2022-06-22 20:06:19.509369
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:24.658995
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('PowershellCore')
    assert len(ps_module_dep_finder.exec_scripts.keys()) == 1
    assert 'PowershellCore' in ps_module_dep_finder.exec_scripts



# Generated at 2022-06-22 20:06:28.552339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    sample_path = "test_data/ps_exec_wrappers/sample_wrapper.ps1"
    module_data = _slurp(sample_path)
    test_obj = PSModuleDepFinder()
    test_obj.scan_module(module_data)
    return test_obj.exec_scripts


# Generated at 2022-06-22 20:06:37.073175
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit tests strictly for the scan_module() method of the PSModuleDepFinder
       class.

       These tests are designed to run in parallel, and thus must use a different
       random seed than other tests.
    """

    from ansible.module_utils._text import to_text
    from ansible.module_utils.powershell import PSModuleDepFinder
    from ansible.module_utils.common._collections_compat import Mapping

    def _slurp(path):
        with open(path, 'rb') as f:
            return f.read().decode()

    # test helper to generate a unique valid random module name
    def _random_module_name():
        return ''.join(chr(random.randint(97, 122)) for x in range(random.randint(8, 12)))

    # test helper to

# Generated at 2022-06-22 20:06:46.345654
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_object = PSModuleDepFinder()
    assert mu_object.exec_scripts == {}
    mu_object.scan_exec_script("powershell_base")

# Generated at 2022-06-22 20:06:56.772970
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # This name may not exist
    finder.scan_exec_script('test_scan_exec_script')
    finder.scan_exec_script('ansible_module_run')
    finder.scan_exec_script('ansible_module_exec_fail')
    finder.scan_exec_script('ansible_module_exec_unreachable')
    finder.scan_exec_script('ansible_module_exec_skipped')
    finder.scan_exec_script('ansible_module_exec_b_success')
    finder.scan_exec_script('ansible_module_exec_b_fail')


# Generated at 2022-06-22 20:07:07.742327
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    
    data = pkgutil.get_data("ansible.plugins.test.ps_modules.test_module", to_native("test_module.ps1"))
    b_data = to_bytes(data)
    module_utils = finder.scan_module(b_data, fqn=to_text('test_module'), wrapper=False, powershell=True)
    assert len(module_utils) == 0

    # Test the case where the module_utils is optional
    data = pkgutil.get_data("ansible.plugins.test.ps_modules.optional_module_util", to_native("optional_module_util.ps1"))
    b_data = to_bytes(data)

# Generated at 2022-06-22 20:07:09.414207
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert isinstance(md, PSModuleDepFinder)



# Generated at 2022-06-22 20:07:19.080049
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:07:24.138919
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    try:
        psmdf = PSModuleDepFinder()
        assert True
    except Exception:
        assert False

# Examples for test of _is_import_line_csharp_module
# Pass over all the patterns and test them first

# Generated at 2022-06-22 20:07:36.436009
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("init.ps1")
    print("Output: " + json.dumps(finder.exec_scripts["init.ps1"]))
    
    finder = PSModuleDepFinder()
    finder.scan_exec_script("user_profile.ps1")
    print("Output: " + json.dumps(finder.exec_scripts["user_profile.ps1"]))

    finder = PSModuleDepFinder()
    finder.scan_exec_script("tmp_dir.ps1")
    print("Output: " + json.dumps(finder.exec_scripts["tmp_dir.ps1"]))

    finder = PSModuleDepFinder()
    finder.scan_exec_script("short_paths.ps1")

# Generated at 2022-06-22 20:07:44.617079
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert _test_PSModuleDepFinder_scan_exec_script.__doc__ == '''Test scan_exec_script(self, name)'''
    module_obj = _test_PSModuleDepFinder_scan_exec_script()
    name = "AuthenticodeSignModule"
    path = 'lib/ansible/executor/powershell/AuthenticodeSignModule.psm1'
    module_data = _slurp(path)
    module_obj.scan_exec_script(name)
    assert module_obj.exec_scripts[name] == module_data


# Generated at 2022-06-22 20:07:45.944090
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:07:52.040096
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()

    assert(mdf.ps_modules == {})
    assert(mdf.exec_scripts == {})
    assert(mdf.cs_utils_wrapper == {})
    assert(mdf.cs_utils_module == {})

    assert(mdf.ps_version is None)
    assert(mdf.os_version is None)
    assert(mdf.become is False)


# Generated at 2022-06-22 20:07:58.865105
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert len(ps_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_dep_finder.cs_utils_module) == 0
    assert len(ps_dep_finder.ps_modules) == 0
    assert len(ps_dep_finder.exec_scripts) == 0
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert ps_dep_finder.become is False



# Generated at 2022-06-22 20:08:08.398936
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # We will invoke scan_exec_script(name) method of class PSModuleDepFinder
    # This method scans module executor scripts
    # Lets create a object for PSModuleDepFinder class
    psmdf = PSModuleDepFinder()
    # Lets generate a random value for name argument
    name = ''.join(random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz") for i in range(10))
    # Lets call scan_exec_script method with name as argument
    psmdf.scan_exec_script(name)

# Generated at 2022-06-22 20:08:21.019927
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test a fails due to parsing
    exception_msg = "Could not find imported module support code for 'Ansible.ModuleUtils.MsOnline.MsOnline'"
    filename = 'PsModuleDepFinder_scan_module_fails_for_Ansible.ModuleUtils.MsOnline.MsOnline.txt'
    finder = PSModuleDepFinder()
    with open(filename) as f:
        data = f.read()
    try:
        finder.scan_module(data)
    except AnsibleError:
        assert(True)
    except Exception as e:
        assert(False)

    # test b fails due to parsing
    exception_msg = "Could not find imported module support code for 'Ansible.ModuleUtils'"

# Generated at 2022-06-22 20:08:32.922274
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert type(dep.ps_modules) == dict
    assert type(dep.cs_utils_wrapper) == dict
    assert type(dep.cs_utils_module) == dict
    assert dep.ps_version is None
    assert dep.os_version is None
    assert dep.become is False
    assert type(dep._re_cs_module) == list
    assert type(dep._re_cs_in_ps_module) == list
    assert type(dep._re_ps_module) == list
    assert type(dep._re_wrapper) == _sre.SRE_Pattern
    assert type(dep._re_ps_version) == _sre.SRE_Pattern
    assert type(dep._re_os_version) == _sre.SRE_Pattern

# Generated at 2022-06-22 20:08:34.006204
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()


# Generated at 2022-06-22 20:08:41.635690
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    l = PSModuleDepFinder()
    l.scan_module(b"""
# requires -version 5.0

Write-Host "This is a test"

# requires -Module Ansible.ModuleUtils.Test

""")
    assert to_text(l.ps_modules['Ansible.ModuleUtils.Test']['data']).strip() == "# Test required module"
    assert l.ps_version == '5.0'


# Generated at 2022-06-22 20:08:43.574887
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    result = {}
    depfinder = PSModuleDepFinder()
    # depfinder.scan_module()

    assert result == {}
    pass

# Generated at 2022-06-22 20:08:46.200812
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    name = random.choice(string.ascii_letters)
    obj.scan_exec_script(name)

# Generated at 2022-06-22 20:08:49.732373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("net_raw")
    # check if the required module is present
    assert(to_native("Ansible.ModuleUtils.netcommon") in finder.ps_modules)


# Generated at 2022-06-22 20:08:51.731845
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_deps = PSModuleDepFinder()
    assert ps_deps is not None


# Generated at 2022-06-22 20:08:57.574242
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('ServerCore')

    assert len(psmdf.exec_scripts) == 1
    assert 'servercore' in psmdf.exec_scripts
    assert 'ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.splitter' in psmdf.cs_utils_wrapper



# Generated at 2022-06-22 20:09:03.334218
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert type(ps_module_dep_finder) is PSModuleDepFinder
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.become == False
    assert ps_module_dep_finder.os_version == None
    assert ps_module_dep_finder.ps_version == None


# Generated at 2022-06-22 20:09:15.524537
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()

    cs_util_types = [
        'cs_utils_module',
        'cs_utils_wrapper',
    ]

    for util_type in cs_util_types:
        assert getattr(finder, util_type) == dict()

    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-22 20:09:17.530886
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:09:27.192490
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(to_bytes("""#Requires -Module xyz\n#Requires -Module ABC\n"""),
                                     to_text("test.test_module"), wrapper=False, powershell=True)

    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0

# Reads a file of a given path and returns a bytes object

# Generated at 2022-06-22 20:09:38.571365
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:45.389565
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with no errors
    class PSModuleDepFinderWrapper(PSModuleDepFinder):
        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            return

    dep_finder = PSModuleDepFinderWrapper()

    # Note that the path is not actually parsed, so we can just return a value
    dep_finder.scan_module(b"# Requires -Module Ansible.ModuleUtils.ArgumentSpec")
    dep_finder.scan_module(b"# Requires -Module Ansible.ModuleUtils.PositionalArgumentSpec")

    # Test with a few errors
    dep_finder = PSModuleDepFinderWrapper()


# Generated at 2022-06-22 20:09:47.490395
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
   dep_finder = PSModuleDepFinder()
   assert hasattr(dep_finder, 'ps_modules')


# Generated at 2022-06-22 20:09:59.705568
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a test object of the class we want to test
    AnsiPSDepFinder = PSModuleDepFinder()

    # Test a few possible values we expect to get back when calling this method;
    #   Powershell modules that we expect to find
    #   Powershell modules that we expect not to find
    #   Powershell modules that we expect to cause error

    # Powershell modules that we expect to find
    assert type(AnsiPSDepFinder.scan_exec_script("Pester")) is None
    assert type(AnsiPSDepFinder.scan_exec_script("PSUtil")) is None
    assert type(AnsiPSDepFinder.scan_exec_script("Shell")) is None

    # Powershell modules that we expect not to find
    AnsiPSDepFinder.exec_scripts = dict()

# Generated at 2022-06-22 20:10:04.146664
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    PSModuleDepFinder._add_module = lambda self, m, ext, fqn, optional, wrapper=False: self._add_module_mock(m, ext, fqn, optional, wrapper)
    PSModuleDepFinder.scan_module = lambda self, module_data, fqn=None, wrapper=False, powershell=True: self._scan_module_mock(module_data, fqn, wrapper, powershell)
    PSModuleDepFinder.scan_exec_script = lambda self, name: self._scan_exec_script_mock(name)


# Generated at 2022-06-22 20:10:09.156774
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2
    assert len(dep_finder._re_ps_version) == 1
    assert len(dep_finder._re_os_version) == 1

# Generated at 2022-06-22 20:10:20.585373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = to_bytes("""#this is an executor script""")
    fp = open('test_exec_script.ps1', 'wb')
    fp.write(data)
    fp.close()
    data = to_bytes("""#AnsibleRequires -Wrapper test_exec_script""")
    fp = open('test.psm1', 'wb')
    fp.write(data)
    fp.close()
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('test_exec_script')
    assert ps_module_dep_finder.exec_scripts['test_exec_script'].decode('utf-8') == "#this is an executor script"
    os.remove('test_exec_script.ps1')

# Generated at 2022-06-22 20:10:22.137213
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()

    assert dep



# Generated at 2022-06-22 20:10:32.844517
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False



# Generated at 2022-06-22 20:10:33.919724
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()
    assert True



# Generated at 2022-06-22 20:10:37.684792
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder
    assert isinstance(finder, PSModuleDepFinder)

# Unit tests for private function _strip_comments

# Generated at 2022-06-22 20:10:39.182651
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-22 20:10:46.976372
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    m = PSModuleDepFinder()
    m.scan_module(b"#Requires -Module Ansible.ModuleUtils.Something")
    m.scan_module(b"#Requires -Module Ansible.ModuleUtils.SomethingElse")
    m.scan_module(b"#Requires -Module Ansible.ModuleUtils.Something")
    m.scan_module(b"#AnsibleRequires -Powershell ..module_utils.Something")
    m.scan_module(b"#AnsibleRequires -Powershell ..module_utils.SomethingElse")
    assert m.ps_modules[b"Ansible.ModuleUtils.Something"]['path']
    assert m.ps_modules[b"Ansible.ModuleUtils.SomethingElse"]['path']

# Generated at 2022-06-22 20:10:57.022504
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test C# module_util support
    finder = PSModuleDepFinder()
    finder.scan_module(base64.b64decode(b'IyBhbnNpYmxlcmVxdWlyZXMgLS1wb3dlcnNoZWxsIEFuc2libGUuTW9kdWxlVXRpbHMuQ29tbW9uCg=='))
    assert finder.ps_modules == {'Ansible.ModuleUtils.Common': {'data': _slurp('lib/ansible/module_utils/powershell/common.psm1'), 'path': 'lib/ansible/module_utils/powershell/common.psm1'}}
    assert finder.cs_utils_module == {}
    assert finder.cs_utils_wrapper == {}
   

# Generated at 2022-06-22 20:11:01.575156
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of class PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()
    # test when name is not in self.exec_scripts.keys()
    name = 'enum'
    ps_module_dep_finder.scan_exec_script(name)
    assert name in ps_module_dep_finder.exec_scripts.keys()
    assert name in ps_module_dep_finder.ps_modules.keys()



# Generated at 2022-06-22 20:11:14.619256
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Get resource data from file.
    # /usr/share/ansible_collections/ansible/community/plugins/module_utils/system/__init__.py
    ansible_collections_path = resource_from_fqcr(u'ansible.community.plugins.module_utils.system',
                                                  u'/usr/share/ansible_collections/')
    data = pkgutil.get_data(u'ansible_collections.ansible.community.plugins.module_utils.system', u'__init__.py')
    data = to_bytes(data, errors='surrogate_or_strict')
    name = u'system'

    # Ensure that ps_modules contains ansible.module_utils.system
    # /usr/share/ansible_collections/ansible/community/plugins/module

# Generated at 2022-06-22 20:11:15.295259
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:11:25.329611
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(finder.ps_modules == dict())
    assert(finder.cs_utils_module == dict())
    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)
    assert(isinstance(finder._re_cs_module[0], re._pattern_type))
    assert(isinstance(finder._re_ps_module[0], re._pattern_type))
    assert(isinstance(finder._re_wrapper, re._pattern_type))
    assert(isinstance(finder._re_ps_version, re._pattern_type))
    assert(isinstance(finder._re_os_version, re._pattern_type))
    assert(isinstance(finder._re_become, re._pattern_type))


# Generated at 2022-06-22 20:11:26.808735
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-22 20:11:34.028913
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    psModuleDepFinder = PSModuleDepFinder()

    # test psm1 script with no Requires
    psModuleDepFinder.scan_exec_script(name='PowershellExecutor')
    assert psModuleDepFinder.exec_scripts['PowershellExecutor'] is not None

    # test psm1 script with a Requires
    psModuleDepFinder.scan_exec_script(name='TestPowershellExecutor')
    assert psModuleDepFinder.exec_scripts['TestPowershellExecutor'] is not None



# Generated at 2022-06-22 20:11:39.106997
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test1'.encode())
    assert len(finder.ps_modules.keys()) == 1
    assert 'Ansible.ModuleUtils.Test1' in finder.ps_modules.keys()


    finder = PSModuleDepFinder()
    finder.scan_module('#AnsibleRequires -PowerShell AnsiBle.ModuleUtils.Test1'.encode())
    assert len(finder.ps_modules.keys()) == 1
    assert 'AnsiBle.ModuleUtils.Test1' in finder.ps_modules.keys()

    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:11:40.049878
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-22 20:11:42.895853
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    instance = PSModuleDepFinder()
    assert instance.scan_module("#Requires -Version 6.0.0-beta.2") == None


# Generated at 2022-06-22 20:11:49.591663
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Ensure that modules, utils and executors are not required multiple times
    finder = PSModuleDepFinder()
    finder.scan_exec_script("wrapper")

# Generated at 2022-06-22 20:12:00.699925
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:03.506880
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    instance.scan_exec_script("Test")


# Generated at 2022-06-22 20:12:05.356543
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert(PSModuleDepFinder())


# Generated at 2022-06-22 20:12:16.055691
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    base64_string = b'VGhpcyBpcyB0ZXN0IGRhdGE='
    decoded_string = base64.b64decode(base64_string)
    obj = PSModuleDepFinder()
    fqn = "ansible.builtin.win_ping"
    obj.scan_module(decoded_string, fqn=fqn)
    assert obj.ps_modules == {}

# Generated at 2022-06-22 20:12:25.034391
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import io
    import mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.powershell.psmodulefinder import PSModuleDepFinder

    # Test normal operation
    with mock.patch('pkgutil.get_data', create=True) as mock_pkgutil_get_data:
        mock_pkgutil_get_data.return_value = io.BytesIO(to_bytes(u''))
        with mock.patch('ansible.module_utils.powershell.psmodulefinder.PSModuleDepFinder._add_module') as add_module:
            # Test with a simple script name
            finder = PSModuleDepFinder()
            finder.scan_exec_script('azure')
            mock

# Generated at 2022-06-22 20:12:27.926389
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:12:39.656487
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.test.test_powershell_loader", "test_find_module_deps.psm1")
    finder.scan_module(data)

    # Check that the module_util file was loaded correctly and is a list of
    # dictionaries
    assert isinstance(finder.ps_modules, dict)
    assert len(finder.ps_modules) == 1
    myutil = finder.ps_modules["Ansible.ModuleUtils.MyUtil"]
    assert isinstance(myutil, dict)
    assert len(myutil) == 2
    assert "data" in myutil.keys()
    assert "path" in myutil.keys()
    assert isinstance(myutil["data"], bytes)

# Generated at 2022-06-22 20:12:53.049729
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    s = PSModuleDepFinder()
    assert isinstance(s.ps_modules, dict)
    assert isinstance(s.exec_scripts, dict)
    assert isinstance(s.cs_utils_wrapper, dict)
    assert isinstance(s.cs_utils_module, dict)
    assert s.ps_version is None
    assert s.os_version is None
    assert not s.become
    assert isinstance(s._re_cs_module[0], re._pattern_type)
    assert isinstance(s._re_cs_in_ps_module[0], re._pattern_type)
    assert isinstance(s._re_ps_module[0], re._pattern_type)
    assert isinstance(s._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:13:05.838223
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.dotdict import dotdict
    from ansible.module_utils._text import to_bytes

    test_path = to_bytes('/tmp/ansible/lib/ansible/modules/comm/win_command.psm1')
    with open(test_path, 'r') as f:
        test_data = to_bytes(f.read())

    data0 = to_bytes('''
#Requires -Module Ansible.ModuleUtils.Pester
#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.ShellLegacy
''')

# Generated at 2022-06-22 20:13:16.626233
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps = PSModuleDepFinder()
    ps.scan_module(b"#Requires -Module Ansible.ModuleUtils.Network")
    assert len(ps.ps_modules) == 1
    assert "Ansible.ModuleUtils.Network" in ps.ps_modules

    ps = PSModuleDepFinder()
    ps.scan_module(b"#AnsibleRequires -Powershell Ansible.ModuleUtils.Network")
    assert len(ps.ps_modules) == 1
    assert "Ansible.ModuleUtils.Network" in ps.ps_modules

    ps = PSModuleDepFinder()
    ps.scan_module(b"#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Network")
    assert len(ps.cs_utils_module) == 1

# Generated at 2022-06-22 20:13:20.904989
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = b"#AnsibleRequires -Wrapper TestWrapper"
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(name=dep_finder._re_wrapper.match(module_data).group(1).rstrip())

    assert(dep_finder.exec_scripts) == b"#Comment1\n$comment2 = \"This is a test comment\"\n"



# Generated at 2022-06-22 20:13:25.677242
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psModuleDepFinder = PSModuleDepFinder()

    module_data = b''
    fqn = None
    wrapper = False
    powershell = True
    psModuleDepFinder.scan_module(module_data, fqn, wrapper, powershell)



# Generated at 2022-06-22 20:13:34.348332
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # pylint: disable=protected-access
    ps = PSModuleDepFinder()
    assert len(ps._re_cs_module) > 0
    assert len(ps._re_ps_module) > 0
    assert len(ps._re_cs_in_ps_module) > 0
    assert len(ps._re_wrapper) > 0
    assert len(ps._re_ps_version) > 0
    assert len(ps._re_os_version) > 0
    assert len(ps._re_become) > 0


# Generated at 2022-06-22 20:13:35.787072
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_mod_dep_finder = PSModuleDepFinder()
    ps_mod_dep_finder.scan_module("This is a test")


# Generated at 2022-06-22 20:13:47.168643
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # scan_module is called from the constructor, so it implicitly tests the
    # scan_module method
    data_string = '''
        #AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.ConvertTo-Json
        #AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.Win32

        #Requires -Module Ansible.ModuleUtils.Powershell.ConvertTo-Json
        #Requires -Module Ansible.ModuleUtils.Powershell.Win32

        #AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Network.Wrapper
    '''

    md = PSModuleDepFinder()
    md.scan_module(data_string, fqn="ansible_collections.foo.bar.plugins.modules.ping")


# Generated at 2022-06-22 20:13:57.723748
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_content = (
        "#requires -module Ansible.ModuleUtils.One\n"
        "#Requires -module Ansible.ModuleUtils.Two\n"
        "#requires -module Ansible.ModuleUtils.Three\n"
        "#requires -module Ansible.ModuleUtils.Four\n"
        "#requires -module Ansible.ModuleUtils.Five\n"
        "#requires -module Ansible.ModuleUtils.Six\n"
        "#requires -module Ansible.ModuleUtils.Seven\n"
        "#requires -module Ansible.ModuleUtils.Eight\n"
        "#requires -module Ansible.ModuleUtils.Nine\n"
    )

    # Create a temporary file to write the module test content in
    fd, temp_file_path = tempfile.mkstemp()

# Generated at 2022-06-22 20:14:04.361120
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder.ps_modules == {}
    assert depfinder.exec_scripts == {}
    assert depfinder.cs_utils_wrapper == {}
    assert depfinder.cs_utils_module == {}
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False


# Generated at 2022-06-22 20:14:11.886791
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def _test_scan_module(content, expected_direct_deps, expected_indirect_deps=None):
        test_deps = PSModuleDepFinder()

        # direct dependencies
        test_deps.scan_module(to_bytes(content))
        test_direct_deps = [d[0] for d in test_deps.ps_modules.items()]
        assert sorted(test_direct_deps) == sorted(expected_direct_deps)

        # indirect dependencies
        if expected_indirect_deps:
            test_indirect_deps = [d[0] for d in test_deps.cs_utils_module.items()]
            assert sorted(test_indirect_deps) == sorted(expected_indirect_deps)

    # test data
    test_content_ps_

# Generated at 2022-06-22 20:14:23.640921
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import math

    # use the sample module to test with
    ps_module_src = to_bytes(base64.b64decode("IyBSZXF1aXJlcyAtTW9kdWxlIEFucy5HdWlkZQoKZnVuY3Rpb24gZ2V0X2dlbm9tZV9udW1iZXIoKQp7CiAgICByZXR1cm4gKE5hTik7Cn0KCm1haW4KCnsKICAgIHN5c3RlbS5vdXQucHJpbnRsbigiR2VuIG51bWJlciBpcyAiICsgZ2V0X2dlbm9tZV9udW1iZXIoKSk7Cn0K"))
   

# Generated at 2022-06-22 20:14:35.940308
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf.ps_modules == {}
    assert psmdf.exec_scripts == {}
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}
    assert psmdf.ps_version == None
    assert psmdf.os_version == None
    assert psmdf.become == False
    assert psmdf._re_cs_module is not None
    assert psmdf._re_cs_in_ps_module is not None
    assert psmdf._re_ps_module is not None
    assert psmdf._re_wrapper is not None
    assert psmdf._re_ps_version is not None
    assert psmdf._re_os_version is not None
    assert psmdf._re_