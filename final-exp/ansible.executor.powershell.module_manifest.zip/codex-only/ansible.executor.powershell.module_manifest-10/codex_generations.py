

# Generated at 2022-06-22 20:04:34.824123
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md.ps_modules == dict()
    assert md.exec_scripts == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False

# Unit tests for function modify_powershell_to_module

# Generated at 2022-06-22 20:04:47.834189
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder
    from ansible_collections.testns.testcoll.plugins.modules.test_ps_module import ps_module_data

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(ps_module_data, fqn="ansible_collections.testns.testcoll.plugins.modules.test_ps_module")

    assert dep_finder.become is True
    assert dep_finder.ps_version == '5.1'
    assert dep_finder.os_version == '6.1'
    assert len(dep_finder.ps_modules.keys()) == 9
    assert len(dep_finder.cs_utils_module.keys()) == 1


# Generated at 2022-06-22 20:04:56.028768
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    assert len(psmdf.exec_scripts.keys()) == 0
    psmdf.scan_exec_script("executor")
    assert len(psmdf.exec_scripts.keys()) == 1
    assert "executor" in psmdf.exec_scripts.keys()
    assert psmdf.exec_scripts["executor"].startswith(b"param(")


# Generated at 2022-06-22 20:04:57.694299
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-22 20:05:07.779839
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    pdmf = PSModuleDepFinder()


# Generated at 2022-06-22 20:05:13.582408
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp(path):
        with open(path, 'rb') as f:
            data = f.read()
        return data

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('basic')


# Generated at 2022-06-22 20:05:22.236409
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Setup
    ps_module_dep_finder = PSModuleDepFinder()

    # Run
    ps_module_dep_finder.scan_exec_script('power.py')
    assert ps_module_dep_finder.exec_scripts['power.py'] is not None

    ps_module_dep_finder.scan_exec_script('winrm_base.psm1')
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Win32.PowerShell.Base'] is not None
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.NewModuleManifest'] is not None
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Powershell.ScheduledTask'] is not None
    assert ps_

# Generated at 2022-06-22 20:05:28.008660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    check_PSModuleDepFinder_scan_exec_script = PSModuleDepFinder()
    string = check_PSModuleDepFinder_scan_exec_script.scan_exec_script(name)
    assert string

# Generated at 2022-06-22 20:05:38.203041
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ansible_module = import_module("ansible.modules.windows.psmodule_dep_finder")
    ansible_executor_powershell_module = import_module("ansible.executor.powershell")

    PSModuleDepFinder = ansible_module.PSModuleDepFinder
    psmodule_dep_finder = PSModuleDepFinder()

    name = "ansible_module_init"
    if name not in psmodule_dep_finder.exec_scripts.keys():
        psm1_data = pkgutil.get_data(ansible_executor_powershell_module.__name__, name + ".ps1")
        psmodule_dep_finder.scan_module(psm1_data, wrapper=True, powershell=True)
        assert len(psmodule_dep_finder.ps_modules) == 3

       

# Generated at 2022-06-22 20:05:50.443191
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Backwards compatibility with ansible
    exec_script_path = 'ansible/executor/powershell/'
    if not os.path.exists(exec_script_path):
        exec_script_path = 'lib/ansible/executor/powershell/'
    exec_script_data = _slurp(os.path.join(exec_script_path, 'invoke_powershellscript.ps1'), False)
    exec_script_data_mod = _strip_comments(exec_script_data)
    script_hash = _get_hash(exec_script_data_mod)
    assert script_hash == '066d4c7377ea4cd147e8c8563b1a6ff9a96f9e57'
    obj = PSModuleDepFinder()

# Generated at 2022-06-22 20:05:56.832572
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an object of class PSModuleDepFinder:
    dep_finder = PSModuleDepFinder()

    # Store the name of the file to be loaded:
    filename = "net_setup"

    # Call function scan_exec_script with name net_setup.ps1 and assert that the call is successful:
    dep_finder.scan_exec_script(filename)
    assert(filename in dep_finder.exec_scripts.keys())


# Generated at 2022-06-22 20:06:05.876591
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    m = 'ansible_collections.testns.testcoll.plugins.module_utils.testmodule'
    ext = '.psm1'
    data = to_bytes(pkgutil.get_data(m, 'testmodule' + ext))
    finder.scan_module(data, fqn=m)
    assert finder.ps_modules[m]['data'] == data
    assert finder.ps_modules[m]['path'] == os.path.join(resource_from_fqcr(m), 'testmodule' + ext)



# Generated at 2022-06-22 20:06:10.570453
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    expected_exec_scripts = {
        "AwxDebug": b"# This is the data inside the powershell script",
    }

    def mock_get_data(package, data):
        assert package == "ansible.executor.powershell", "Wrong package name"
        assert data == "AwxDebug.ps1", "Wrong data name"
        return b"# This is the data inside the powershell script"

    with mock.patch("ansible.module_utils.powershell.PSModuleDepFinder.scan_module") as mock_sm:
        with mock.patch("pkgutil.get_data") as mock_gd:
            mock_gd.side_effect = mock_get_data
            psmd.scan_exec_script("AwxDebug")
            mock_sm

# Generated at 2022-06-22 20:06:14.076739
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_mod_dep_finder = PSModuleDepFinder()
    module_data = ''
    fqn = ''
    wrapper = ''
    powershell = ''
    obj = ps_mod_dep_finder.scan_module(module_data, fqn, wrapper, powershell)
    assert obj == None, "Return value: %s" % obj

# Generated at 2022-06-22 20:06:16.705807
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # for now nothing to do here, maybe later
    print('')



# Generated at 2022-06-22 20:06:28.443552
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script() uses the following asserts:
    # assertIsInstance(), assertListEqual(), assertEqual(), assertTrue(),
    # assertIn()
    finder = PSModuleDepFinder()
    # Test a scenario where the module is not found.
    try:
        finder.scan_exec_script("unittest_01")
    except AnsibleError as err:
        assertIsInstance(err, AnsibleError)
        assertTrue("Could not find executor powershell script" in to_text(err))
    # Test a scenario where the module is found
    finder.scan_exec_script("exec_psmodule_support")
    # Test the generated list of exec scripts

# Generated at 2022-06-22 20:06:29.641792
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-22 20:06:36.425917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fd = PSModuleDepFinder()
    for x in range(10):
        fd.scan_exec_script(x)
        if x % 2 == 0:
            assert fd.scan_module(x, x)
        else:
            assert fd.scan_module(x, x, wrapper=True)


# Generated at 2022-06-22 20:06:46.003698
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # find out the number of executor powershell scripts in the current installed binary
    # and add a new script for unit testing.
    num_exec_scripts = len(ps_module_utils_loader.get_all_plugin_loaders())
    current_exe_script = 'executorshell_' + str(random.randint(1000, 9999))

    # Add an new executor powershell script with some comments in the the executor powershell folder
    # and add a reference to this script in the unit test file.
    new_exec_script = '#Requires -Module ansible.module_utils.powershell \n ' \
                      '#AnsibleRequires -Wrapper {0} \n'.format(current_exe_script)


# Generated at 2022-06-22 20:06:57.949303
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible import constants as C
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.psrp.common import psrp_module_utils_loader
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.utils.collection_loader import resource_from_fqcr

    # create test classes
    class MockPs(object):

        def __init__(self):
            self._exec_modules = dict()

        def _add_exec_module(self, name, script):
            self._exec_modules[name] = script

        def get_exec_module(self, name):
            return self._exec_modules[name]


# Generated at 2022-06-22 20:07:01.757469
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    a = PSModuleDepFinder()
    path = to_bytes(resource_from_fqcr(a.ps_modules, "Ansible.ModuleUtils.AclModuleUtils"))
    assert path


# Generated at 2022-06-22 20:07:03.495623
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("Basic")


# Generated at 2022-06-22 20:07:05.996193
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:07:09.931076
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell.ps1')
    assert finder.exec_scripts['powershell.ps1'] != b''
    assert finder.exec_scripts['powershell.ps1'] != None
    
    

# Generated at 2022-06-22 20:07:21.691163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    os.chdir(os.path.join(C.ROLE_TESTS_PATH, 'test-module-utils'))
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script('windows_platform')
    assert psmd.exec_scripts
    assert psmd.exec_scripts.get('windows_platform')
    assert psmd.exec_scripts.get('windows_platform').startswith(b'function Get-WindowsVersion')
    assert 'Ansible.ModuleUtils.Basic' in psmd.ps_modules
    assert psmd.ps_modules.get('Ansible.ModuleUtils.Basic').get('data').startswith(b'function Write-AnsibleModuleMetadata')
    assert 'Ansible.ModuleUtils.CommonSpec' in psmd

# Generated at 2022-06-22 20:07:23.205761
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert 0


# Generated at 2022-06-22 20:07:25.160893
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is difficult to test as the expected instantiation of
    # PSModuleDepFinder can only be triggered in the powershell connection plugin
    # tests or in the module module.
    pass


# Generated at 2022-06-22 20:07:27.297057
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder() is not None


# Generated at 2022-06-22 20:07:38.545240
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    class_object = PSModuleDepFinder()

    # Tests for regex used

# Generated at 2022-06-22 20:07:48.645254
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # tests for compatibility with older PS versions
    # powershell requires we set the version on PS 5.1 and above
    # we need to test that the version is set when detecting if PS is 5.1 or above
    # but not set in versions below 5.1
    pdmdf = PSModuleDepFinder()
    assert pdmdf.ps_modules == dict()
    assert pdmdf.exec_scripts == dict()
    assert pdmdf.cs_utils_wrapper == dict()
    assert pdmdf.cs_utils_module == dict()
    assert pdmdf.ps_version is None
    assert pdmdf.os_version is None
    assert pdmdf.become is False



# Generated at 2022-06-22 20:07:55.594240
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # GIVEN
    # WHEN
    psmdf = PSModuleDepFinder()
    # THEN
    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()

    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become



# Generated at 2022-06-22 20:08:08.449900
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    class PSModuleDepFinderTest(PSModuleDepFinder):
        # A fake class to test the constructor of the parent class
        def __init__(self):
            super(PSModuleDepFinderTest, self).__init__()

    mu_finder = PSModuleDepFinderTest()
    assert isinstance(mu_finder.ps_modules, dict)
    assert isinstance(mu_finder.cs_utils_wrapper, dict)
    assert isinstance(mu_finder.cs_utils_module, dict)
    assert isinstance(mu_finder.exec_scripts, dict)
    assert mu_finder.ps_version is None
    assert mu_finder.os_version is None
    assert mu_finder.become is False
    assert len(mu_finder._re_cs_module) == 1

# Generated at 2022-06-22 20:08:11.838645
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.module_utils.common.win_servermanager_psm1 as win_servermanager_psm1
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_servermanager")
    assert dep_finder.exec_scripts["win_servermanager"] == win_servermanager_psm1.__data__


# Generated at 2022-06-22 20:08:14.556593
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # create instance of PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    assert psmdf is not None


# Generated at 2022-06-22 20:08:23.690356
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Since the constructor of PSModuleDepFinder is empty and it mainly
    # added class variables, we just assert the type of each class variable
    finder = PSModuleDepFinder()

    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.exec_scripts, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)

    assert isinstance(finder.ps_version, type(None))
    assert isinstance(finder.os_version, type(None))
    assert isinstance(finder.become, bool)

    assert isinstance(finder._re_cs_module, list)
    assert isinstance(finder._re_cs_in_ps_module, list)

# Generated at 2022-06-22 20:08:33.186703
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected_exec_scripts = "{(u'ansible.executor.powershell.InvokeAnsible', {'data': b'\\r\\n#pragma strict\\r\\n\\r\\n'}), (u'ansible.executor.powershell.AnsibleInvocation', {'data': b'#pragma strict\\r\\n\\r\\n'}), (u'ansible.executor.powershell.AnsibleTaskBuilder', {'data': b'#pragma strict\\r\\n\\r\\n'}), (u'ansible.executor.powershell.AsyncFile', {'data': b'\\r\\n#pragma strict\\r\\n\\r\\n'})}"


# Generated at 2022-06-22 20:08:44.904926
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert not ps_module_dep_finder.ps_modules
    assert not ps_module_dep_finder.exec_scripts
    assert not ps_module_dep_finder.cs_utils_wrapper
    assert not ps_module_dep_finder.cs_utils_module

    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert not ps_module_dep_finder.become

    # check regex are valid
    for r in ps_module_dep_finder._re_cs_module:
        assert r.pattern
    for r in ps_module_dep_finder._re_cs_in_ps_module:
        assert r.pattern

# Generated at 2022-06-22 20:08:52.874129
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    content = pkgutil.get_data("ansible_collections.ansible.kubernetes.plugins.modules", to_native("k8s.psm1"))
    module_utils = set()
    class_obj = PSModuleDepFinder()
    class_obj.scan_module(to_bytes(content))
    assert 'Ansible.ModuleUtils.Powershell.Convert' in class_obj.ps_modules
    assert 'ansible_collections.ansible.kubernetes.plugins.module_utils.k8s_common' in class_obj.cs_utils_module

# Generated at 2022-06-22 20:08:59.768101
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(finder.ps_modules == {})
    assert(finder.exec_scripts == {})
    assert(finder.cs_utils_wrapper == {})
    assert(finder.cs_utils_module == {})
    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)
    assert(finder._re_wrapper.pattern == r'(?i)^#\s*ansiblerequires\s+-wrapper\s+(\w*)')
    assert(finder._re_ps_version.pattern == r'(?i)^#requires\s+\-version\s+([0-9]+(\.[0-9]+){0,3})$')

# Generated at 2022-06-22 20:09:09.384353
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#Requires -Module Ansible.ModuleUtils.ASM')
    assert 'Ansible.ModuleUtils.ASM' in psmdf.ps_modules
    ng_psmdf = PSModuleDepFinder()
    ng_psmdf.scan_module(b'#Requires -Module Ansible.ModuleUtils.ASM')
    assert 'Ansible.ModuleUtils.ASM' in ng_psmdf.ps_modules



# Generated at 2022-06-22 20:09:20.959939
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psf = PSModuleDepFinder()
    psf.scan_module(base64.b64decode(b'I3JlcXVpcmVzIC1Nb2R1bGUgQW5zaWJsZS5Nb2R1bGVVdGlscy5JbmNpZGVudGlhbC5UZXN0U2NyaXB0Iw=='),
                    fqn='mock.fqn')
    assert len(psf.ps_modules.keys()) == 1
    assert 'Ansible.ModuleUtils.Internal.TestScript' in psf.ps_modules.keys()
    assert len(psf.cs_utils_module.keys()) == 0



# Generated at 2022-06-22 20:09:29.933143
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()

    # test built-in module_utils
    obj.scan_module(b'#Requires -Module Ansible.ModuleUtils.CommonVM')
    assert to_text(obj.ps_modules['Ansible.ModuleUtils.CommonVM']['path']) == 'ansible/module_utils/common/vmware.psm1'

    # test collection module_utils
    obj.scan_module(b'#Requires -Module ansible_collections.test_namespace.test_collection.plugins.module_utils.test')
    assert to_text(obj.ps_modules['ansible_collections.test_namespace.test_collection.plugins.module_utils.test']['path']) == 'test/test/plugins/module_utils/test.psm1'

    # test relative

# Generated at 2022-06-22 20:09:40.677194
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest

    @pytest.fixture
    def TestPSModuleDepFinder(tmpdir):

        class TestClass(PSModuleDepFinder):

            def __init__(self):
                super(TestClass, self).__init__()

            def scan_module(self, *args, **kwargs):
                return super(TestClass, self).scan_module(*args, **kwargs)

            def scan_exec_script(self, *args, **kwargs):
                return super(TestClass, self).scan_exec_script(*args, **kwargs)

            def _add_module(self, *args, **kwargs):
                return super(TestClass, self)._add_module(*args, **kwargs)


# Generated at 2022-06-22 20:09:53.446244
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps = PSModuleDepFinder()
    ps.scan_module(b'#Requires -Module Ansible.ModuleUtils.Foo')
    assert ps.ps_modules == {'Ansible.ModuleUtils.Foo': {'data': b'', 'path': ''}}
    assert ps.cs_utils_module == {}
    assert ps.cs_utils_wrapper == {}
    assert ps.exec_scripts == {}
    assert ps.ps_version is None
    assert ps.os_version is None
    assert ps.become is False

    ps.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo -Optional')
    assert ps.ps_modules == {'Ansible.ModuleUtils.Foo': {'data': b'', 'path': ''}}

# Generated at 2022-06-22 20:10:04.730078
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_dep_finder = PSModuleDepFinder()
    # k is a string
    k = "PSDesiredStateConfiguration"
    my_dep_finder.exec_scripts = { k: "value" }
    # k1 is a string
    k1 = "PSDesiredStateConfiguration2"
    my_dep_finder.exec_scripts = { k1: "value" } 
    # k2 is a string
    k2 = "PSDesiredStateConfiguration3"
    my_dep_finder.exec_scripts = { k2: "value" } 
    # k3 is a string
    k3 = "PSDesiredStateConfiguration4"
    my_dep_finder.exec_scripts = { k3: "value" } 
    # k4 is a string
    k4 = "PSDesiredStateConfiguration5"
   

# Generated at 2022-06-22 20:10:13.083099
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a non-existent script, to ensure an exception is raised
    finder = PSModuleDepFinder()
    name = '__random_script__'
    try:
        finder.scan_exec_script(name)
    except Exception as err:
        assert(str(err) == "Could not find executor powershell script for '{}'".format(name))
        return

    raise Exception("No exception was raised for a non-existent script")


# Generated at 2022-06-22 20:10:14.958353
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)

# Generated at 2022-06-22 20:10:17.006296
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depFinder = PSModuleDepFinder()
    assert depFinder is not None


# Generated at 2022-06-22 20:10:25.008959
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import unittest
    import ansible.module_utils.powershell.basic


# Generated at 2022-06-22 20:10:30.061210
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create the object using its constructor
    psmdf = PSModuleDepFinder()
    
    # Call the method scan_exec_script of your class
    psmdf.scan_exec_script(name="name_of_the_script")
    # Compare the values obtained and the expected ones
    assert psmdf

# Generated at 2022-06-22 20:10:35.222065
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    '''Test for constructor of class PSModuleDepFinder'''
    # Test empty object
    m = PSModuleDepFinder()

    assert bool(m) is False
    assert m.ps_modules == {}
    assert m.exec_scripts == {}
    assert m.cs_utils_wrapper == {}
    assert m.cs_utils_module == {}



# Generated at 2022-06-22 20:10:46.547253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def mocked_get_data(name1, name2):
        class MockPkgData:
            @staticmethod
            def get_data(name1, name2):
                if name2 in results[name1]:
                    return results[name1][name2]
                return None
        return MockPkgData


# Generated at 2022-06-22 20:10:49.341316
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder.scan_exec_script("ModuleBuilder")
    assert "ModuleBuilder" in depFinder.exec_scripts

# Generated at 2022-06-22 20:10:58.926315
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Using temporary directory for testing, to keep test independent from
    # module_utils path of system.
    with AnsibleExitJson, TemporaryDirectory() as tmp_dir:
        tmp_module_utils_csharp_dir = os.path.join(tmp_dir, "module_utils", "csharp")
        tmp_module_utils_powershell_dir = os.path.join(tmp_dir, "module_utils", "powershell")
        tmp_modules_dir = os.path.join(tmp_dir, "modules")
        os.makedirs(tmp_module_utils_csharp_dir)
        os.makedirs(tmp_module_utils_powershell_dir)
        os.makedirs(tmp_modules_dir)

        # Test module with multiple dependencies

# Generated at 2022-06-22 20:11:00.873007
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This test case checks if the method scan_module of ps_module_dep_finder
    # is working correctly
    pass


# Generated at 2022-06-22 20:11:13.543264
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup
    mu_finder = PSModuleDepFinder()

    from ansible_collections.ansible.community.plugins.modules.module_utils.network.cloudengine.ce import ce_argument_spec

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    empty_module = os.path.join(fixture_path, 'foo.psm1')
    with open(empty_module, 'w') as f:
        f.write("\n")

    empty_module_data = _slurp(empty_module)

    # Execute
    mu_finder.scan_module(empty_module_data)

    # Verify
    assert len(mu_finder.ps_modules) == 0

    # Setup
    mu_finder = PSModuleDepFinder()
   

# Generated at 2022-06-22 20:11:21.088525
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    #test scan_exec_script not in self.exec_scripts
    name = 'test_name'
    try:
        finder.scan_exec_script(name)
        assert False, 'AnsibleError not raised'
    except AnsibleError as e:
        assert 'Could not find executor powershell script' in e.message

    #test scan_exec_script in self.exec_scripts
    finder.exec_scripts[name] = 'test_data'
    finder.scan_exec_script(name)



# Generated at 2022-06-22 20:11:30.900597
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:44.711687
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print('--------------')
    from ansible.module_utils._text import to_bytes
    from ansible.modules.windows.win_copy import win_copy
    from ansible.plugins.without_module_test_plugin import ActionModule as win_copy_action
    from ansible.plugins.loader import ps_module_utils_loader
    import sys
    import inspect
    import six
    import json
    import textwrap
    import base64
    import os.path
    import os
    import shutil

    t_global_vars = dict()

    t_global_vars['ansible_version'] = LooseVersion("2.8.5")
    t_global_vars['ansible_module_generated'] = False
    t_global_vars['ansible_check_mode'] = False
    t_global_vars

# Generated at 2022-06-22 20:11:55.354604
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fn = os.path.join(
        'test',
        'units',
        'module_utils',
        'test_module_deps_finder_scan_module.psm1')
    with open(fn, 'rb') as mod_utils_file:
        mod_utils_file_data = mod_utils_file.read()

    finder = PSModuleDepFinder()
    finder.scan_module(mod_utils_file_data, fqn="foo.bar")

    assert(len(finder.ps_modules) == 3)
    assert(len(finder.cs_utils_module) == 2)



# Generated at 2022-06-22 20:11:59.982125
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # GIVEN a scenario where a psm1 file is requested for as an exec script
    psmd = PSModuleDepFinder()
    # WHEN the method scan_exec_script is called
    try:
        psmd.scan_exec_script('init')
    # THEN no exception is thrown
    except:
        assert False


# Generated at 2022-06-22 20:12:12.838534
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def check_name(dep_finder, check_name, cls_name):
        assert check_name in getattr(dep_finder, cls_name).keys()

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(pkgutil.get_data("ansible.builtin.powershell", to_native("Internet.psm1")))

    check_name(dep_finder, 'Ansible.netcommon', 'ps_modules')
    check_name(dep_finder, 'Ansible.powershell', 'ps_modules')
    check_name(dep_finder, 'Ansible.module_utils.powershell.network.Common.Internet', 'cs_utils_wrapper')

# Generated at 2022-06-22 20:12:23.007934
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test that the required regular expressions match the given strings
    assert PSModuleDepFinder()._re_ps_module[0].search("#Requires -Module Ansible.ModuleUtils.MyModule")
    assert PSModuleDepFinder()._re_ps_module[1].search("#AnsibleRequires -PowerShell Ansible.ModuleUtils.MyModule")
    assert PSModuleDepFinder()._re_cs_in_ps_module[0].search("#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.MyModule")
    assert PSModuleDepFinder()._re_cs_module[0].search("using ansible_collections.ansible.builtins.plugins.module_utils.MyModule;")

    # Test that the regular expressions do not match given strings
    assert not PSModuleDepFinder()._re_ps_

# Generated at 2022-06-22 20:12:26.790869
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("Basic")

    assert isinstance(dep_finder.exec_scripts, dict)
    assert len(dep_finder.exec_scripts) == 1


# Generated at 2022-06-22 20:12:28.236461
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:12:33.749514
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_powershell_common")
    assert "ansible_powershell_common" in dep_finder.exec_scripts.keys()
    assert "ansible_powershell_common" in dep_finder.cs_utils_wrapper.keys()


# Generated at 2022-06-22 20:12:36.478665
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # if no modules are defined, we should not have any defined
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()



# Generated at 2022-06-22 20:12:49.736493
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p1 = PSModuleDepFinder()
    data = to_bytes("#Requires -Module Ansible.ModuleUtils.ScheduledTask \n#AnsibleRequires -CSharpUtil Ansible.CSharp\n")
    p1.scan_module(data)
    assert isinstance(p1.ps_modules,dict)
    assert isinstance(p1.cs_utils_wrapper,dict)
    assert isinstance(p1.cs_utils_module,dict)
    assert isinstance(p1.ps_version,NoneType)
    assert isinstance(p1.os_version,NoneType)
    assert p1.become == False
    assert isinstance(p1._re_cs_module,list)
    assert isinstance(p1._re_ps_module,list)

# Generated at 2022-06-22 20:12:54.592988
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def mocked_scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
        pass

    def mocked_import_module(name):
        if name == 'ansible_collections.test.test_collection.plugins.module_utils.test_module_utils':
            class MockedModule(object):
                __path__ = ['/path/to/ansible_collections/test/test_collection/plugins/module_utils/test_module_utils']

            return MockedModule()
        else:
            raise ImportError("No module named %s" % name)

    def mocked_get_data(package_name, resource_name):
        return base64.b64decode(
            b'aGVyZSBpcyBzb21lIGRhdGE=')

    pd_b

# Generated at 2022-06-22 20:12:56.682733
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(finder is not None)


# Generated at 2022-06-22 20:12:59.081749
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-22 20:13:05.650724
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test some error cases
    finder = PSModuleDepFinder()
    for wrapper in (True, False):
        for powershell in (True, False):
            # Test that a module which requires an invalid util returns an error
            with pytest.raises(AnsibleError):
                finder.scan_module(b"#Requires -Module Ansible.DoesntExist", wrapper=wrapper, powershell=powershell)



# Generated at 2022-06-22 20:13:16.452589
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:24.433978
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # setup
    mu_1 = random.randint(1, 1000)
    mu_2 = random.randint(1000, 100000)
    mu_3 = random.randint(100000, 1000000)
    mu_4 = random.randint(1000000, 10000000)
    mu_5 = random.randint(10000000, 100000000)
    mu_6 = random.randint(100000000, 1000000000)
    mu_7 = random.randint(1000000000, 10000000000)


# Generated at 2022-06-22 20:13:28.585771
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
	p = PSModuleDepFinder()
	p.scan_module()
	
if __name__ == "__main__":
	test_PSModuleDepFinder_scan_module()

# Generated at 2022-06-22 20:13:30.685229
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mod = PSModuleDepFinder()
    assert not mod.ps_modules


# Generated at 2022-06-22 20:13:42.891924
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This tests method scan_exec_script of class PSModuleDepFinder
    # in module plugins.loader.module_loader
    def __init__(self):
        pass
    pass_arg = [
        '#',
        'ansiblerequires',
        '-wrapper',
        'powershell.ps1'
    ]
    def exec_script_name(passed_arg):
        for i in range(len(pass_arg)):
            print(pass_arg[i])
        return pass_arg[i]
        pass_arg[4] = "powershell.ps1"
        pass_arg[2] = "-wrapper"
        pass_arg[3] = "-wrapper"
        pass_arg[1] = "ansiblerequires"
        pass_arg[0] = "#"

# Generated at 2022-06-22 20:13:55.918077
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.is_valid_dep_name('.version.ps1') is True
    assert finder.is_valid_dep_name('ansible_collections.ns.coll.plugins.module_utils.version.ps1') is True
    # Test both local ps1 and cs module_utils in ansible.module_utils.version
    assert finder.is_valid_dep_name('ansible_collections.ns.coll.plugins.version.ps1') is True
    assert finder.is_valid_dep_name('ansible.module_utils.version.ps1') is True
    assert finder.is_valid_dep_name("ansible.module_utils.version.ps1_dne") is False



# Generated at 2022-06-22 20:14:05.132464
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_path = os.path.join(sys.prefix, "Lib", "site-packages", "ansible", "executor", "powershell", "ansible_async.ps1")
    pkg_data = pkgutil.get_data("ansible.executor.powershell", "ansible_async.ps1")
    module_util_data = to_bytes(pkg_data, errors='surrogate_or_strict')

# Generated at 2022-06-22 20:14:08.419531
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Remove the test_PSModuleDepFinder_scan_exec_script test as it is covered by another test.
    # TODO Remove this test after Ansible 2.6
    assert False


# Generated at 2022-06-22 20:14:09.278905
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass




# Generated at 2022-06-22 20:14:16.485780
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    temp_base_path = '/Users/Philip/projects/personal/ansible-test/test-data/test_modules/test'
    module_name = 'test_id'
    fqn = 'test._test'

    # Load a module and export the module_utils from it.
    mod_path = resource_from_fqcr(temp_base_path, fqn, module_name)
    with open(to_bytes(mod_path), 'rb') as module_file:
        module_data = module_file.read()

    # Create a PSModuleDepFinder and scan the module_utils contents.
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data, fqn)

    # Get the discovered module_utils.
    found_module_utils = dep_finder

# Generated at 2022-06-22 20:14:26.134271
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:14:37.317824
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Borrowed from Ansible's own test_powershell.py
    def _load_powershell_data(name):
        data = pkgutil.get_data("ansible.module_utils.powershell", to_native(name))
        if data is None:
            raise AnsibleError("Could not find executor powershell script "
                               "for '%s'" % name)
        return data
