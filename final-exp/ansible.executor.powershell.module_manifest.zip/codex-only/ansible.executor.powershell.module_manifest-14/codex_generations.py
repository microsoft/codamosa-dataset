

# Generated at 2022-06-22 20:04:46.943316
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:04:59.639530
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    module_data = ("#Requires -Module Ansible.ModuleUtil.one\n"
                   "#Requires -Module Ansible.ModuleUtil.two\n")
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 2
    assert 'Ansible.ModuleUtil.one' in finder.ps_modules
    assert 'Ansible.ModuleUtil.two' in finder.ps_modules
    assert finder.ps_modules['Ansible.ModuleUtil.one']['data'].startswith(b'#')
    assert finder.ps_modules['Ansible.ModuleUtil.two']['data'].startswith(b'#')


# Generated at 2022-06-22 20:05:05.978576
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = pkgutil.get_data("ansible.plugins.win_dsc", os.path.join("module_utils", "dsc_common.psm1"))
    b_data = to_bytes(data)

    finder = PSModuleDepFinder()
    finder.scan_module(b_data)

    assert set(finder.ps_modules.keys()) == set(("Ansible.ModuleUtils.DSC.Logging",))
    assert finder.become is False


# Generated at 2022-06-22 20:05:15.259187
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.urls import open_url
    from ansible.plugins.loader import replace_loader, module_loader
    from ansible.module_utils.parsing.convert_bool import boolean
    import os
    import pkgutil
    import pytest
    import re
    import shutil
    import sys
    import tempfile
    import time
    import yaml
    from ansible.errors import AnsibleError

    finder = PSModule

# Generated at 2022-06-22 20:05:23.668804
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_depfinder = PSModuleDepFinder()
    assert isinstance(psmodule_depfinder._re_cs_in_ps_module, list), "PSModuleDepFinder._re_cs_in_ps_module is not a list"
    assert len(psmodule_depfinder._re_cs_in_ps_module) == 1, "PSModuleDepFinder._re_cs_in_ps_module is not 1 item long"
    assert isinstance(psmodule_depfinder._re_cs_in_ps_module[0], re.Pattern), "PSModuleDepFinder._re_cs_in_ps_module[0] is not a re.Pattern"
    assert isinstance(psmodule_depfinder._re_cs_module, list), "PSModuleDepFinder._re_cs_module is not a list"
    assert len

# Generated at 2022-06-22 20:05:35.916478
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.plugins.loader import module_loader
    from ansible.utils import context_objects as co

    module_data = module_loader._get_module_data(
        'systemd',
        co.GlobalCLI().basedir,
        co.GlobalCLI().collection_paths
    )

    module_data = to_text(module_data, errors='surrogate_or_strict')
    module_data = base64.b64decode(module_data)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_finder.ps_version == '5.0'
    assert dep_finder.os_version == '6.3'
    assert dep_finder.become is True

    module_data = module_loader._get_module_

# Generated at 2022-06-22 20:05:38.016684
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder is not None


# Generated at 2022-06-22 20:05:40.350488
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmoddepfinder = PSModuleDepFinder()
    name = "name"
    psmoddepfinder.scan_exec_script(name)


# Generated at 2022-06-22 20:05:51.936902
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('Ansible.ModuleUtils.CommonArgs')
    ps_module_dep_finder.scan_exec_script('Ansible.ModuleUtils.PowerShell.PowerShell')
    ps_module_dep_finder.scan_exec_script('Ansible.ModuleUtils.Pester')
    ps_module_dep_finder.scan_exec_script('Ansible.ModuleUtils.Pester.TestRunner')
    ps_module_dep_finder.scan_exec_script('Ansible.ModuleUtils.Splatting')

    # We create an empty file and pass the path of this file to the function scan_exec_script and expect AnsibleError to be thrown

# Generated at 2022-06-22 20:06:04.050542
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
    Test the scan_module method of class PSModuleDepFinder
    '''


# Generated at 2022-06-22 20:06:08.981850
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Testing scan_exec_script")
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(b"get-windows-version")
    print(psmdf.exec_scripts)
    assert psmdf.exec_scripts[b"get-windows-version"] != b""
    print("Done")
    
    

# Generated at 2022-06-22 20:06:13.587313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test with fully qualified module name
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("ansible_collections.ns1.coll1.plugins.module_utils.common_utils")

# Generated at 2022-06-22 20:06:26.843929
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module("#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n#Requires -Module Ansible.ModuleUtils.AnotherModuleUtil")
    assert(len(finder.ps_modules.keys()) == 2)
    assert("Ansible.ModuleUtils.TestModuleUtil" in finder.ps_modules.keys() and "Ansible.ModuleUtils.AnotherModuleUtil" in finder.ps_modules.keys())

    finder = PSModuleDepFinder()
    finder.scan_module("#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n#AnsibleRequires -PowerShell Ansible.ModuleUtils.AnotherModuleUtil")
    assert(len(finder.ps_modules.keys()) == 2)

# Generated at 2022-06-22 20:06:29.596521
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Testing scan_exec_script() of class PSModuleDepFinder\n")
    obj = PSModuleDepFinder()
    assert obj.scan_exec_script("common") is None


# Generated at 2022-06-22 20:06:41.968678
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_utils_path = os.path.join(os.path.dirname(C.__file__), 'module_utils')
    module_data = _slurp(os.path.join(module_utils_path, 'powershell', 'basic.psm1'))
    finder = PSModuleDepFinder()
    finder.scan_module(module_data, 'test.basic')
    assert len(finder.ps_modules) == 6
    assert len(finder.cs_utils_module) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.exec_scripts) == 0
    assert finder.ps_version == '4.0'
    assert finder.os_version == '10.0'


# Generated at 2022-06-22 20:06:48.530478
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-22 20:06:50.404525
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert(hasattr(PSModuleDepFinder, "__init__"))


# Generated at 2022-06-22 20:06:57.204349
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Prepare test data
    module_data0 = b'#Requires -Module Ansible.ModuleUtils.Legacy\n'
    # Required by module data0
    module_data1 = b'#Requires -Module Ansible.ModuleUtils.Common\n'
    # Required by module data0
    module_data2 = b'#Requires -Module Ansible.ModuleUtils.Legacy\n'
    # Required by module data2
    module_data3 = b'#Requires -Module Ansible.ModuleUtils.Common\n'
    # Required by module data2
    module_data4 = b'#Requires -Module Ansible.ModuleUtils.Powershell\n'

    # Test 0 - call scan_module(module_data0)
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:07:02.715003
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder.scan_exec_script('powershell_script_template')
    assert len(depFinder.exec_scripts.keys()) == 1
    assert len(depFinder.cs_utils_wrapper.keys()) == 1
    assert "Ansible.ModuleUtils.Powershell.Raw" in depFinder.cs_utils_wrapper.keys()


# Generated at 2022-06-22 20:07:05.813024
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # In this unit test we just check if the object is created correctly
    p = PSModuleDepFinder()
    assert p

# Test if 'strip_comments' function works correctly

# Generated at 2022-06-22 20:07:14.444422
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf.ps_modules, dict)
    assert isinstance(psmdf.cs_utils_wrapper, dict)
    assert isinstance(psmdf.cs_utils_module, dict)
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become
    assert psmdf._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                      r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')
    assert psmdf._re_cs_in_ps_module[0].pattern == to_

# Generated at 2022-06-22 20:07:16.955730
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, object)


# Generated at 2022-06-22 20:07:20.303500
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test for ansible.module_utils._text.to_bytes
    """
    psm = PSModuleDepFinder()
    psm.scan_exec_script('random')
    return psm.exec_scripts

# Generated at 2022-06-22 20:07:22.769468
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf


# Generated at 2022-06-22 20:07:35.047530
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert(finder.ps_modules == {})
    assert(finder.exec_scripts == {})
    assert(finder.cs_utils_wrapper == {})
    assert(finder.cs_utils_module == {})

    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)

    assert(finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                        '(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))

# Generated at 2022-06-22 20:07:43.452069
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = read_binary_file(MODULE_DATA_PATH)
    finder.scan_module(module_data)
    assert finder.ps_modules["Ansible.ModuleUtils.Basic"]
    assert finder.ps_modules["Ansible.ModuleUtils.CommonTools"]
    assert finder.cs_utils_module["ansible_collections.ns.coll.plugins.module_utils.common_tools"]


# Generated at 2022-06-22 20:07:54.129915
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:02.321029
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md._re_cs_module
    assert md._re_cs_in_ps_module
    assert md._re_ps_module
    assert md._re_wrapper
    assert md._re_ps_version
    assert md._re_os_version
    assert md._re_become
    assert md.ps_modules == dict()
    assert md.exec_scripts == dict()
    assert md.cs_utils_wrapper == dict()
    assert md.cs_utils_module == dict()



# Generated at 2022-06-22 20:08:04.510992
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    assert test_obj is not None


# Generated at 2022-06-22 20:08:15.452030
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == {}
    assert pmdf.exec_scripts == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.cs_utils_module == {}
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False
    assert pmdf._re_cs_module
    assert pmdf._re_cs_in_ps_module
    assert pmdf._re_ps_module
    assert pmdf._re_wrapper
    assert pmdf._re_ps_version
    assert pmdf._re_os_version
    assert pmdf._re_become



# Generated at 2022-06-22 20:08:19.282850
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module("")
    # No error in executing the method


# Generated at 2022-06-22 20:08:23.187727
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:27.091354
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # pick a random module to test with
    module_name = random.choice(list(finder.ps_modules.keys()))
    finder.scan_module(finder.ps_modules[module_name]['data'])
    assert module_name in finder.ps_modules.keys()


# Generated at 2022-06-22 20:08:30.695792
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(b'Get-WindowsFeature')
    assert psmdf.exec_scripts.get(b'Get-WindowsFeature') is not None



# Generated at 2022-06-22 20:08:41.167277
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pattern = re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'

                                r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))
    f = open("test/test_utils_module/ansible/module_utils/network/cloudengine/ce/__init__.py", mode='r')
    module_data = f.read()
    line_count = len(module_data.split("\n"))
    PSModuleDepFinder.scan_module(pattern, module_data)

# Generated at 2022-06-22 20:08:42.546171
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder is not None


# Generated at 2022-06-22 20:08:53.127626
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('NativeSystemInfo')
    assert psmdf.exec_scripts['NativeSystemInfo']
    assert psmdf.ps_modules['Ansible.ModuleUtils.NativeSystemInfo']['path'] == 'ansible/module_utils/powershell/Ansible.ModuleUtils.NativeSystemInfo.psm1'
    assert psmdf.ps_modules['Ansible.ModuleUtils.NativeSystemInfo']['data']
    assert psmdf.ps_modules['Ansible.ModuleUtils.NativeSystemInfo']['data'].startswith(b"\nparam(\n")

# Generated at 2022-06-22 20:09:04.329077
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    #
    # This unit test was automatically generated by TestGenerator. Please add
    # your own tests for the unittest framework.
    #

    # Ignore warnings during development
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning) 
    warnings.filterwarnings("ignore", category=PendingDeprecationWarning) 
    warnings.filterwarnings("ignore", category=ResourceWarning) 

    # Import test modules
    import tempfile

    # Functions and classes used on this file

    # Our class to be tested
    class_to_test = 'PSModuleDepFinder'

    # Create a list of all functions and variables, sorted by line number
    # This allows us to easily identify functions and class methods

# Generated at 2022-06-22 20:09:15.824475
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module('using Ansible.ModuleUtils.Common;\n#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.asd.as; #AnsibleRequires -Wrapper asd;\n#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Common.DataConversion;')

# Generated at 2022-06-22 20:09:18.533240
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    # Just make sure we don't raise any error while instantiating
    # ps_module_dep_finder object.
    assert isinstance(finder, PSModuleDepFinder)

# Unit test to make sure we don't raise any unexpected exception when we
# call scan_module() by passing an empty or partial data.

# Generated at 2022-06-22 20:09:28.625204
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(b'# AnsibleRequires -Wrapper abc')
    assert to_text(md.exec_scripts['abc']) == '# AnsibleRequires -Wrapper abc'

    md = PSModuleDepFinder()
    md.scan_module(b'# AnsibleRequires -CSharpUtil Ansible.ModuleUtils.MoreUtils')
    assert to_text(list(md.cs_utils_module.keys())[0]) == 'Ansible.ModuleUtils.MoreUtils'

    md = PSModuleDepFinder()
    md.scan_module(b'# AnsibleRequires -CSharpUtil Ansible.MoreUtils')

# Generated at 2022-06-22 20:09:38.794739
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p.ps_modules == dict()
    assert p.cs_utils_wrapper == dict()
    assert p.cs_utils_module == dict()
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become == False
    assert len(p._re_cs_module) == 1
    assert len(p._re_cs_in_ps_module) == 1
    assert len(p._re_ps_module) == 2
    assert p._re_wrapper.pattern
    assert p._re_ps_version.pattern
    assert p._re_os_version.pattern
    assert p._re_become.pattern


# Generated at 2022-06-22 20:09:41.499901
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    f = PSModuleDepFinder()
    assert f.ps_modules == {}
    assert f.cs_utils_wrapper == {}
    assert f.cs_utils_module == {}
    assert f.ps_version == None
    assert f.os_version == None

# Generated at 2022-06-22 20:09:42.611614
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass # no test available

# Generated at 2022-06-22 20:09:47.993373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.helpers import load_from_module
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible_collections.ansible.builtin.plugins.module_utils.common.jsonify
    import ansible_collections.ansible.builtin.plugins.module_utils.common.validation
    import ansible_collections.ansible.builtin.plugins.module_utils.common.utils
    from ansible.module_utils.common.utils import random_pw, to_bytes
    from ansible_collections.ansible.builtin.plugins.module_utils.common.jsonify import AnsibleModuleBase

# Generated at 2022-06-22 20:09:52.833009
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class psModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            self.exec_scripts = ['test-cmd']

    result = psModuleDepFinder().scan_exec_script('test-cmd')
    assert(result is None)


# Generated at 2022-06-22 20:10:04.191414
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing scan_exec_script of class PSModuleDepFinder
    x = PSModuleDepFinder()
    x.scan_exec_script("PScribo")
    x.scan_exec_script("PScribo")
    x.scan_exec_script("PSUtil")
    assert x.exec_scripts["PScribo"].decode("UTF-8") == open(os.path.join(os.path.dirname(__file__), "..", "..", "executor", "powershell", "PScribo.ps1"), "r").read().strip()

# Generated at 2022-06-22 20:10:17.208480
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:25.118712
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    random_name = "".join(
        [random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(128)]
    )
    dep_finder.scan_exec_script(random_name)
    assert dep_finder.exec_scripts == {}

    saved_exec_scripts = dep_finder.exec_scripts
    dep_finder.scan_exec_script("test-script-non-existent")
    assert dep_finder.exec_scripts == saved_exec_scripts

    dep_finder.scan_exec_script("test-script-1")
    assert (
        random_name
        in dep_finder.exec_scripts
    )

    dep_finder.scan_exec_script("test-script-2")

# Generated at 2022-06-22 20:10:37.347774
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:38.443793
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass


# Generated at 2022-06-22 20:10:44.252612
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.plugins.loader

    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script('Ansible.PowerShell')
    assert 'Ansible.PowerShell' in dep_finder.exec_scripts


# Generated at 2022-06-22 20:10:53.970918
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test 1:
    # Test method scan_exec_script with an executor script that has no dependencies
    util_scanner = PSModuleDepFinder()
    util_scanner.scan_exec_script("script")
    assert util_scanner.exec_scripts == {'script': {}}
    assert util_scanner.ps_modules == {}

    # Test 2:
    # Test method scan_exec_script with an executor script that has 1 dependency
    util_scanner = PSModuleDepFinder()
    util_scanner.scan_exec_script("ps_executor_script")
    assert util_scanner.exec_scripts == {'ps_executor_script': {}}
    assert util_scanner.ps_modules == {'Ansible.ModuleUtils.Powershell.Executor': {}}

    # Test

# Generated at 2022-06-22 20:11:01.959177
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    # Test if the lists are empty
    assert not dep_finder.ps_modules
    assert not dep_finder.exec_scripts
    assert not dep_finder.cs_utils_wrapper
    assert not dep_finder.cs_utils_module

    # Test if the regexes are correct
    assert dep_finder._re_cs_module
    assert dep_finder._re_cs_in_ps_module
    assert dep_finder._re_ps_module
    assert dep_finder._re_wrapper
    assert dep_finder._re_ps_version
    assert dep_finder._re_os_version
    assert dep_finder._re_become


# Generated at 2022-06-22 20:11:14.619258
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    random_number = str(random.random())
    test_data = {'test': random_number}
    expected_result = {'test.ps1': base64.b64encode(to_bytes(json.dumps(test_data)))}

    def _get_exec_script(name):
        return json.dumps(test_data).encode()

    original_get_data = pkgutil.get_data

    try:
        pkgutil.get_data = _get_exec_script
        test_class = PSModuleDepFinder()
        test_class.scan_exec_script('test')
        assert test_class.exec_scripts == expected_result
    finally:
        pkgutil.get_data = original_get_data


# Generated at 2022-06-22 20:11:25.090646
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an instance of the class to be tested
    dep_finder = PSModuleDepFinder()

    # create a mock module_info

# Generated at 2022-06-22 20:11:27.336350
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_utils = PSModuleDepFinder()

    assert module_utils
    assert isinstance(module_utils, PSModuleDepFinder)


# Generated at 2022-06-22 20:11:37.159013
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep = PSModuleDepFinder()

    assert isinstance(ps_dep, PSModuleDepFinder)
    assert len(ps_dep.ps_modules) == 0
    assert len(ps_dep.cs_utils_wrapper) == 0
    assert len(ps_dep.cs_utils_module) == 0
    assert ps_dep.ps_version is None
    assert ps_dep.os_version is None
    assert ps_dep.become is False

    assert isinstance(ps_dep._re_cs_module, list)
    assert isinstance(ps_dep._re_cs_module[0], _sre.SRE_Pattern)
    assert isinstance(ps_dep._re_cs_in_ps_module, list)

# Generated at 2022-06-22 20:11:47.219098
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()

    assert module_finder is not None
    assert module_finder.ps_modules is not None
    assert module_finder.exec_scripts is not None
    assert module_finder.cs_utils_wrapper is not None
    assert module_finder.cs_utils_module is not None
    assert module_finder.ps_version is None
    assert module_finder.os_version is None
    assert module_finder.become is False

    assert len(module_finder._re_cs_module) == 1
    assert len(module_finder._re_cs_in_ps_module) == 1
    assert len(module_finder._re_ps_module) == 2

    assert module_finder._re_cs_module[0] is not None
    assert module_finder._re_cs_in_ps_

# Generated at 2022-06-22 20:11:59.511526
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmd_finder = PSModuleDepFinder()
    assert isinstance(psmd_finder.ps_modules, dict)
    assert isinstance(psmd_finder.exec_scripts, dict)
    assert isinstance(psmd_finder.cs_utils_wrapper, dict)
    assert isinstance(psmd_finder.cs_utils_module, dict)
    assert psmd_finder.ps_version is None
    assert psmd_finder.os_version is None
    assert psmd_finder.become is False
    assert len(psmd_finder._re_cs_module) == 1
    assert len(psmd_finder._re_cs_in_ps_module) == 1
    assert len(psmd_finder._re_ps_module) == 2

# Generated at 2022-06-22 20:12:12.757121
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()

    assert isinstance(psModuleDepFinder._re_cs_module, list)
    assert isinstance(psModuleDepFinder._re_cs_module[0], re._pattern_type)
    assert isinstance(psModuleDepFinder._re_cs_in_ps_module, list)
    assert isinstance(psModuleDepFinder._re_cs_in_ps_module[0], re._pattern_type)
    assert isinstance(psModuleDepFinder._re_ps_module, list)
    assert isinstance(psModuleDepFinder._re_ps_module[0], re._pattern_type)
    assert isinstance(psModuleDepFinder._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:12:14.614119
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depFinder = PSModuleDepFinder()
    assert isinstance(depFinder, PSModuleDepFinder)


# Generated at 2022-06-22 20:12:20.288344
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_finder = PSModuleDepFinder()
    # prepare data for testing
    module_name = 'test_module'
    data_input = '#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test'
    data_input_2 = '#requires -version 1.2.3'
    data_input_3 = '#ansiblerequires -osversion 6.1'
    data_input_4 = '#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test'
    data_input_5 = 'using ansible_collections.ansible.builtin.plugins.module_utils.Test;'
    data_input_6 = '#AnsibleRequires -CSharpUtil ansible_collections.ansible.builtin.plugins.module_utils.Test'

# Generated at 2022-06-22 20:12:32.187593
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    from six import string_types

    dep_finder = PSModuleDepFinder()
    
    # Test error cases
    with pytest.raises(AnsibleError) as excinfo:
        dep_finder.scan_module(None)
    assert 'Could not find imported module support code' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        dep_finder.scan_module('')
    assert 'Could not find imported module support code' in str(excinfo.value)

    module_data = 'some data'
    dep_finder.scan_module(module_data)
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.exec_scripts == dict()
   

# Generated at 2022-06-22 20:12:34.540212
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    assert True is True

# Generated at 2022-06-22 20:12:46.853935
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create instance for PSModuleDepFinder class
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ps_convert_to_base64")
    assert len(dep_finder.exec_scripts) == 1
    assert list(dep_finder.exec_scripts.keys())[0] == "ps_convert_to_base64"
    assert to_text(dep_finder.exec_scripts["ps_convert_to_base64"], errors='surrogate_or_strict').startswith(
        "function ConvertTo-Base64")
    assert "Ansible.ModuleUtils.Powershell.Convert" in dep_finder.ps_modules

# Generated at 2022-06-22 20:12:52.244876
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    obj.scan_module(arg1, arg2, arg3, arg4, arg5)

# Generated at 2022-06-22 20:12:55.782849
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert type(ps_module_dep_finder) == PSModuleDepFinder
    ps_module_dep_finder.scan_module()


# Generated at 2022-06-22 20:13:07.766970
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_depfinder = PSModuleDepFinder()
    ps_depfinder.scan_exec_script('GetFileEncoding')
    filename = resource_from_fqcr('ansible_collections.testns.testcoll.plugins.module_utils.test_ps_module_utils.test_ps_module_utils')
    with open(filename, 'rb') as test_ps_module_utils:
        ps_depfinder.scan_module(test_ps_module_utils.read(), None)

# Generated at 2022-06-22 20:13:18.401488
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()

    # Assert that each of the attributes of the PSModuleDepFinder class
    # are initialized as expected
    assert len(md.ps_modules) == 0, 'Failed to initialize ps_modules'
    assert len(md.exec_scripts) == 0, 'Failed to initialize exec_scripts'
    assert len(md.cs_utils_wrapper) == 0, 'Failed to initialize cs_utils_wrapper'
    assert len(md.cs_utils_module) == 0, 'Failed to initialize cs_utils_module'
    assert md.ps_version is None, 'Failed to initialize ps_version'
    assert md.os_version is None, 'Failed to initialize os_version'
    assert md.become is False, 'Failed to initialize become'

    # Assert that the regex

# Generated at 2022-06-22 20:13:22.859906
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Powershell")
    assert ps_module_dep_finder.ps_modules.get('Ansible.ModuleUtils.Powershell') is not None



# Generated at 2022-06-22 20:13:34.661792
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert isinstance(finder._re_ps_module[0], re._pattern_type)
    assert isinstance(finder._re_cs_in_ps_module[0], re._pattern_type)
    assert isinstance(finder._re_wrapper, re._pattern_type)
    assert isinstance(finder._re_ps_version, re._pattern_type)
    assert isinstance(finder._re_os_version, re._pattern_type)
    assert isinstance(finder._re_become, re._pattern_type)



# Generated at 2022-06-22 20:13:46.134316
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Because method scan_module depends on attributes such as ps_modules etc.
    # It is not easy to test it alone. The test_scan_module method will test
    # it. Here we only test scan_exec_script method.
    # Because of the same reason, we will only test scan_exec_script method
    # here.
    import ansible.executor.powershell
    from ansible.module_utils.powershell import ps_script_add_args
    from ansible.module_utils.powershell import ps_script_append_wrapper_args

    finder = PSModuleDepFinder()
    finder.scan_exec_script('ps_script_add_args')

# Generated at 2022-06-22 20:13:52.598432
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes('''
        #Requires -Module Ansible.ModuleUtils.Cloud
        #Requires -Module Ansible.ModuleUtils.Facts
        #Requires -Module Ansible.ModuleUtils.Powershell
        #AnsibleRequires -Powershell Ansible.ModuleUtils.Network.F5.Common
    '''))
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Cloud']['data']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Facts']['data']
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Powershell']['data']

# Generated at 2022-06-22 20:14:02.671415
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    # test scan_module() with powershell, checking the len of required modules
    module_data = to_bytes(u'#Requires -Module Ansible.ModuleUtils.facts\n#Requires -Module ansible_collections.ns.coll.plugins.module_utils.facts\n')
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 2

    # test scan_module() with cs, checking the len of required modules
    module_data = to_bytes(u'using Ansible.Test.module_utils.test;\nusing ansible_collections.ns.coll.plugins.module_utils.test;\n')
    finder.scan_module(module_data, powershell=False)

# Generated at 2022-06-22 20:14:11.085742
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    args = dict()
    args['module_data'] = b'#Requires -Module Ansible.ModuleUtils.{name}'
    args['fqn'] = 'name'
    args['wrapper'] = False
    args['powershell'] = True

    # mock module_utils.power_shell
    power_shell = sys.modules['ansible.module_utils.power_shell']
    power_shell.to_native = lambda x:x
    power_shell.ps_module_utils_loader = None
    power_shell.import_module = lambda x:x

    # mock ansible.module_utils.powershell.ps_module_utils_loader
    ps_module_utils_loader = sys.modules['ansible.module_utils.powershell.ps_module_utils_loader']
    ps_module_utils_loader.find

# Generated at 2022-06-22 20:14:16.125894
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    '''
    This function tests the constructor of the class PSModuleDepFinder
    '''
    finder = PSModuleDepFinder()
    # Check if an instance is created
    assert isinstance(finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:14:19.494739
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    success = False
    try:
        finder = PSModuleDepFinder()
    except Exception:
        assert False, "Unexpected exception raised when creating PSModuleDepFinder object"
    return True


# Generated at 2022-06-22 20:14:27.789136
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # pylint: disable=protected-access
    assert not hasattr(PSModuleDepFinder, "_re_cs_module")
    assert PSModuleDepFinder._re_cs_module[0].groups == 3
    assert PSModuleDepFinder._re_cs_module[0].groupindex == {}
    assert PSModuleDepFinder._re_ps_module[0].groups == 3
    assert PSModuleDepFinder._re_ps_module[0].groupindex == {'optional': 4}
    assert PSModuleDepFinder._re_cs_in_ps_module[0].groups == 4
    assert PSModuleDepFinder._re_cs_in_ps_module[0].groupindex == {'optional': 5}
    assert PSModuleDepFinder._re_wrapper.groups == 1

    dep_finder = PSModuleDepFinder

# Generated at 2022-06-22 20:14:37.887785
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == {}
    assert f.exec_scripts == {}
    assert f.cs_utils_wrapper == {}
    assert f.cs_utils_module == {}
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False
    assert f._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')