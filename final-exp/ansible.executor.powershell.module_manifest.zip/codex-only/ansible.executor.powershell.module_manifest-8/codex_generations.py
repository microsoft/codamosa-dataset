

# Generated at 2022-06-22 20:04:36.495156
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # testing signature
    input_1 = "RandomPowerShellScript"
    test_instance = PSModuleDepFinder()
    fingerprint = random.getrandbits(128)
    test_instance.exec_scripts = {fingerprint: "RandomValue" + str(random.getrandbits(128))}
    test_instance.scan_exec_script(input_1)
    assert test_instance.exec_scripts[input_1] is not None


# Generated at 2022-06-22 20:04:48.775315
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test_PSModuleDepFinder_scan_module()
    # test that each of the scanning methods scan_module, scan_exec_script, and
    # _add_module can find module_utils that use any form of syntax used in Ansible

    # this is the easiest way to create an instance of the PSModuleDepFinder()
    ps_dep_finder = PSModuleDepFinder()

    # test data, each array item is a test case
    # function name is the function to call in PSModuleDepFinder to scan data
    # path is the path of the module in the collection
    # module is the fully qualified name of the module
    # wrapper is a boolean indicating if this is a wrapper
    # powershell is a boolean indicating if this is a powershell module_util
    # expected is the expected return value from the PSModuleDepFinder
    test_

# Generated at 2022-06-22 20:05:00.998339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is to do unit test for scan_exec_script of class PSModuleDepFinder
    # mock_get_data is a mock function for pkgutil.get_data
    # The mock_get_data returns file text from test_exec_script_data.ps1 file
    def mock_get_data(*args, **kwargs):
        with open('./test_data/test_exec_script_data.ps1', 'r') as myfile:
            return myfile.read()

    # mock_scan_module is a mock function for scan_module of class PSModuleDepFinder
    # The mock_scan_module returns nothing
    def mock_scan_module(*args, **kwargs):
        return

    # patch pkgutil.get_data and scan_module

# Generated at 2022-06-22 20:05:10.054414
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def mock_ps_module_utils_loader_find_plugin(module_name):
        module_path = to_text(module_name) + ".psm1"
        return os.path.join(module_finder_test_dir, module_path)

    def mock_get_data(package_name, resource_name):
        return pkgutil.get_data(package_name, resource_name)

    # Setup the test
    module_finder_test_dir = os.path.dirname(__file__)
    psmodule_dep_finder = PSModuleDepFinder()

    # Patch the loader and pkgutil functions so that they load the data from the test directory.
    orig_ps_module_utils_loader_find_plugin = ps_module_utils_loader.find_plugin
    orig_get_data = pkgutil

# Generated at 2022-06-22 20:05:21.762205
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    x = PSModuleDepFinder()

    assert(len(x.ps_modules) == 0)
    assert(len(x.cs_utils_module) == 0)
    assert(len(x.cs_utils_wrapper) == 0)
    assert(len(x.exec_scripts) == 0)

    with open(os.path.join(C.TEST_DIR, 'units', 'module_utils', 'powerShell', 'Tests', 'module_import_order.ps1')) as f:
        ps_module_data = to_bytes(f.read())
    x.scan_module(ps_module_data, powershell=True)

    assert(len(x.ps_modules) == 2)

# Generated at 2022-06-22 20:05:35.343508
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_file = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/network/cloud/aws/ec2_vpc_subnet.ps1')
    #with open(test_file, 'rb') as f:
    #    data = f.read()

    ps_version_matched_regex = re.compile(r'(?i)^#Requires\s+\-Version\s+(.*)')
    ps_version_matched_regex = re.compile(r'(?i)^#Requires\s+\-Version\s+([0-9]+(\.[0-9]+){0,3})$')

# Generated at 2022-06-22 20:05:42.818384
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    #This is a unit test for the scan_module method.
    ps_module_util = PSModuleDepFinder()
    ps_module_util.scan_module("using a.b.c.d;")
    assert ps_module_util.cs_utils_module == {'a.b.c.d': {'data': to_bytes("using a.b.c.d;"), 'path': to_text("a.b.c.d")}}



# Generated at 2022-06-22 20:05:49.020081
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import lib.ansible.executor.powershell
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("log")
    assert ps_module_dep_finder.exec_scripts['log'] == b'#requires -version 4.0\r\n'



# Generated at 2022-06-22 20:06:01.038129
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    base_module_fqcr = 'ansible.builtin.win_command'
    base_module_data = resource_from_fqcr(base_module_fqcr)
    base_module_wrapper_data = resource_from_fqcr('ansible.executor.powershell.wrappers.exec')
    test_module_fqcr = 'ansible_collections.ns.coll.plugins.modules.win_dns_record'
    test_module_data = resource_from_fqcr(test_module_fqcr)
    test_module_util_fqcr = 'ansible_collections.ns.coll.plugins.module_utils.win_dns_client'
    test_module_util_data = resource_from_fqcr(test_module_util_fqcr)
    test

# Generated at 2022-06-22 20:06:11.221265
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    # Module type should be powershell
    assert ps_dep_finder.ps_modules == {}
    # Module type should be cs module
    assert ps_dep_finder.cs_utils_wrapper == {}
    # Module type should be cs wrapper
    assert ps_dep_finder.cs_utils_module == {}
    assert ps_dep_finder.ps_version == None
    assert ps_dep_finder.os_version == None
    assert ps_dep_finder.become == False


# Generated at 2022-06-22 20:06:15.254608
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdeps = PSModuleDepFinder()
    assert mdeps
    assert mdeps.ps_modules == dict()
    assert mdeps.exec_scripts == dict()
    assert mdeps.cs_utils_wrapper == dict()
    assert mdeps.cs_utils_module == dict()
    assert mdeps.ps_version is None
    assert mdeps.os_version is None
    assert mdeps.become is False


# Generated at 2022-06-22 20:06:27.724704
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # importing this module outside of unit test mode causes recursion error
    import ansible.plugins.action.powershell

    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(b'ansible_collections.foo.bar.plugins.module_utils.win_path')
    # test_exec_scripts = dict()
    assert isinstance(psmdf.exec_scripts.get(b'ansible_collections.foo.bar.plugins.module_utils.win_path', None), bytes)
    assert "ansible_collections.foo.bar.plugins.module_utils.win_path.ps1" in psmdf.cs_utils_wrapper.keys()

# Generated at 2022-06-22 20:06:35.691788
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with empty wrapper name
    test_obj = PSModuleDepFinder()
    try:
        test_obj.scan_exec_script('')
    except Exception as err:
        assert isinstance(err, AnsibleError)
        assert to_text(err) == 'Could not find executor powershell script for \'\''

    # Test with invalid wrapper name
    try:
        test_obj.scan_exec_script('invalid')
    except Exception as err:
        assert isinstance(err, AnsibleError)
        assert to_text(err) == 'Could not find executor powershell script for \'invalid\''

    # Test with valid wrapper name
    test_obj.scan_exec_script('Ansible.Process.Wrapper')

# Generated at 2022-06-22 20:06:41.532649
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    PSModuleDepFinder_scan_module = PSModuleDepFinder()
    with open("./module_utils/ansible.module_utils.basic.py") as f:
      module_utils_data = f.read()
      PSModuleDepFinder_scan_module.scan_module(module_utils_data)
    assert PSModuleDepFinder_scan_module.ps_modules.get('Basic') != None


# Generated at 2022-06-22 20:06:52.713828
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    with open(os.path.join(C.ROOT_DIR, 'lib/ansible/module_utils/basic.py'), 'rb') as f:
        basic_data = to_bytes(f.read())
    with open(os.path.join(C.ROOT_DIR, 'lib/ansible/module_utils/facts/system/os.py'), 'rb') as f:
        os_data = to_bytes(f.read())
    with open(os.path.join(C.ROOT_DIR, 'lib/ansible/module_utils/facts/system/os/windows.py'), 'rb') as f:
        win_data = to_bytes(f.read())

# Generated at 2022-06-22 20:07:04.146970
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # I could have generated data for a lot of the different types of modules and tested
    # each one but then I would also have to generate a library full of modules to test as well
    # and it becomes a difficult thing to maintain.
    #
    # Instead, I am going to write a test that at least shows that scan_module works in some fashion.
    # I will also generate test data and compare it to what is laid out in the rest of the file.
    # I will also update with tests as I find issues

    r = PSModuleDepFinder()

    # the example PS module that ansible provides on their site
    example_ps = "/usr/lib/python3.6/site-packages/ansible/modules/windows/win_ping.psm1"

# Generated at 2022-06-22 20:07:13.439667
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiate an instance of PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    assert psmdf.exec_scripts == {}
    assert psmdf.cs_utils_module == {}
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.ps_modules == {}
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become

    # Call scan_exec_script to ensure it does not fail
    psmdf.scan_exec_script('ansible_module_utils')
    assert 'ansible_module_utils' in psmdf.exec_scripts
    assert 'internet_options' in psmdf.ps_modules
    assert 'basetypes' in psmdf.cs_utils_module
   

# Generated at 2022-06-22 20:07:17.154665
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_obj = PSModuleDepFinder()
    result = PSModuleDepFinder_obj.scan_exec_script("test_exec_path")


# Generated at 2022-06-22 20:07:22.307810
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.ps_version, object)
    assert isinstance(ps_module_dep_finder.os_version, object)
    assert isinstance(ps_module_dep_finder.become, bool)



# Generated at 2022-06-22 20:07:34.613634
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert isinstance(ps_module_dep_finder._re_cs_module, list)
    assert isinstance(ps_module_dep_finder._re_cs_in_ps_module, list)
    assert isinstance(ps_module_dep_finder._re_ps_module, list)
    assert isinstance(ps_module_dep_finder._re_ps_version, re._pattern_type)

# Generated at 2022-06-22 20:07:35.757838
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:07:47.917850
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    util_mock = PSModuleDepFinder()

    # Test _re_ps_module
    assert len(util_mock._re_ps_module) == 2
    assert util_mock._re_ps_module[0].match("#Requires -Module Ansible.ModuleUtils.Foo")
    assert util_mock._re_ps_module[0].match("#Requires -Modules Ansible.ModuleUtils.Foo1 and Ansible.ModuleUtils.Foo2")
    assert util_mock._re_ps_module[1].match("#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo")
    assert util_mock._re_ps_module[1].match("#AnsibleRequires -PowerShell ansible_collections.namespace.collection.module_utils.Foo")

   

# Generated at 2022-06-22 20:07:58.448691
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # scanner = PSModuleDepFinder()
    # noinspection PyUnresolvedReferences
    assert to_native(_slurp(resource_from_fqcr('test.testmodule'))) == 'test content 1'
    # scanner.scan_module(to_bytes(_slurp(resource_from_fqcr('test.testmodule'))))
    # assert scanner.ps_modules['Ansible.ModuleUtils.Test']
    # assert scanner.ps_modules['Ansible.ModuleUtils.Test']['data']
    # assert b'test content 2' in scanner.ps_modules['Ansible.ModuleUtils.Test']['data']
    # assert scanner.cs_utils_wrapper['ansible_collections.test.test.plugins.module_utils.test']
    # assert scanner.cs_utils_wrapper

# Generated at 2022-06-22 20:08:10.800423
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = b"#Requires -Module Ansible.ModuleUtils.Powershell\n#AnsibleRequires -CSharpUtil ansible_collections.test.sub.plugins.module_utils.test\n"
    finder.scan_module(module_data)
    # check empty set if no requirements
    assert finder.ps_modules == {'Ansible.ModuleUtils.Powershell': {'data': b'', 'path': ''}}
    assert finder.cs_utils_module == {'ansible_collections.test.sub.plugins.module_utils.test': {'data': b'', 'path': ''}}
    assert finder.cs_utils_wrapper == {}
    assert finder.ps_version is None
    assert finder.os_version

# Generated at 2022-06-22 20:08:23.058304
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Initialize an instance of PSModuleDepFinder
    test_object = PSModuleDepFinder()

    module_data = "This is an arbitrary string of bytes\n"
    test_object.scan_module(module_data)

    module_data = "#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n"
    test_object.scan_module(module_data)

    module_data = "#AnsibleRequires -PowerShell Ansible.ModuleUtils.TestModuleUtil\n"
    test_object.scan_module(module_data)

    module_data = "#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.TestModuleUtil\n"
    test_object.scan_module(module_data)

    # Reference C# module_util in another C# util, this must always be the

# Generated at 2022-06-22 20:08:35.484981
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:08:36.112266
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:08:41.049466
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Initialize with the default values of PSModuleDepFinder
    module_data="""using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};"""
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.cs_utils_module is not None
    assert finder.ps_modules is None
    assert finder.cs_utils_wrapper is None
    

# Generated at 2022-06-22 20:08:50.923056
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module = "ansible_collections.test.test_module"
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(to_bytes(test_module))
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    # test_module.ps1 is a PS module for testing.

# Generated at 2022-06-22 20:08:56.689628
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    data = b'#\n# ns.coll.module_name\n#\n# Requires -Module ansible.module_utils.some_module\n'
    depFinder = PSModuleDepFinder()
    depFinder.scan_module(data, "ns.coll.module_name")
    assert "ansible.module_utils.some_module" in depFinder.ps_modules



# Generated at 2022-06-22 20:08:59.129048
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    p = PSModuleDepFinder()
    p.scan_exec_script(name='powershell_script')
    assert p != None


# Generated at 2022-06-22 20:08:59.952764
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass # TODO

# Generated at 2022-06-22 20:09:13.214543
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    md = PSModuleDepFinder()
    md.ps_modules = {
        'Ansible.ModuleUtils.Basic': {
            'data': b'',
            'path': 'path/to/basic.psm1',
        },
    }
    md.cs_utils_wrapper = {
        'ansible_collections.test.test_ns.plugins.module_utils.other_cs_util': {
            'data': b'',
            'path': 'path/to/other_cs_util.cs',
        },
    }

# Generated at 2022-06-22 20:09:21.022431
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_scanner = PSModuleDepFinder()

    # Test scanning of PS module with both new and old style
    # Requires/AnsibleRequires

# Generated at 2022-06-22 20:09:21.710506
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:09:22.514619
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Implement this test
    pass

# Generated at 2022-06-22 20:09:26.432010
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder.exec_scripts.keys() == []
    psModuleDepFinder.scan_exec_script('common')
    assert psModuleDepFinder.exec_scripts.keys() != []


# Generated at 2022-06-22 20:09:28.877654
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script("script1") is None



# Generated at 2022-06-22 20:09:40.064443
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_md_finder = PSModuleDepFinder()
    assert len(ps_md_finder.ps_modules) == 0

    ps_md_finder = PSModuleDepFinder()
    assert len(ps_md_finder.ps_modules) == 0

    ps_md_finder = PSModuleDepFinder()
    assert len(ps_md_finder.ps_modules) == 0

    ps_md_finder = PSModuleDepFinder()

    assert len(ps_md_finder.ps_modules) == 0
    assert 0 == len(ps_md_finder.exec_scripts)
    assert len(ps_md_finder.cs_utils_wrapper) == 0
    assert len(ps_md_finder.cs_utils_module) == 0
    assert ps_md_finder.ps_version is None
    assert ps_md_

# Generated at 2022-06-22 20:09:52.679685
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class DummyPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self, *args, **kwargs):
            return super(DummyPSModuleDepFinder, self).__init__(*args, **kwargs)

        def _add_module(self, *args, **kwargs):
            return True

    psmd = DummyPSModuleDepFinder()

    # Test various comments and dependencies, and make sure scanning doesn't
    # break if it sees a line that does not match.

# Generated at 2022-06-22 20:10:04.048436
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:09.078681
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:20.543335
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.os_version is None
    assert dep_finder.ps_version is None
    assert dep_finder.become is False
    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2
    assert dep_finder._re_wrapper is not None
    assert dep_finder._re_ps_version is not None
    assert dep_finder._re_os_version is not None

# Generated at 2022-06-22 20:10:33.229492
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_obj = PSModuleDepFinder()
    module_data = base64.b64decode('IyBSZXF1aXJlcyAtTW9kdWxlIEFuc2libGUuTW9kdWxlVXRpbHMuaW50ZWxsaXB0DQojIFJlcXVpcmVzIC1Nb2R1bGUgQW5zaWJsZS5Nb2R1bGVVdGlscy5wcm9jZWR1cmU=')
    test_obj.scan_module(module_data, fqn='ansible_collections.namespace.collection.plugins.modules.module_name', wrapper=False, powershell=True)

# Generated at 2022-06-22 20:10:43.921697
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    test_file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_files', 'PSModuleDepFinder_scan_module', 'test_psm1'))
    dep_finder.scan_module(open(test_file_path, 'rb').read(), fqn='fake_fqn')

    assert len(dep_finder.ps_modules.keys()) == 4
    assert len(dep_finder.cs_utils_wrapper.keys()) == 1
    assert len(dep_finder.cs_utils_module.keys()) == 1
    assert len(dep_finder.exec_scripts.keys()) == 1

    assert dep_finder.ps_version == '6.2.1'
    assert dep_finder.os

# Generated at 2022-06-22 20:10:49.646325
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    module_name = os.path.join(os.path.dirname(__file__), '../../module_utils/network/cloud/meraki/meraki.psm1')
    with open(module_name, 'rb') as f:
        psmdf.scan_module(to_bytes(f.read()))
    assert 'ansible_collections.notdefault.notdefault.plugins.module_utils.network.common.command' in set(psmdf.ps_modules)
    assert 'Ansible.ModuleUtils.Common.FormatData' in set(psmdf.ps_modules)
    assert psmdf.ps_version == '3.0'
    assert psmdf.os_version == '6.2'
    assert psmdf.become is False

# Generated at 2022-06-22 20:10:59.225457
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:11:03.637216
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_name = "test_PSModuleDepFinder_scan_exec_script"
    test_dep_finder = PSModuleDepFinder()
    test_name = "ansible.module_utils.common.json"
    test_dep_finder.scan_exec_script(test_name)
    assert "ansible.module_utils.common.json" in test_dep_finder.exec_scripts.keys()


# Generated at 2022-06-22 20:11:06.784507
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    assert type(mdf) == PSModuleDepFinder


# Generated at 2022-06-22 20:11:09.172597
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()
    module_data = to_bytes("#Requires -Module Ansible.ModuleUtils.Test\n# AnsibleRequires -PowerShell ..test.test")
    psModuleDepFinder.scan_module(module_data, fqn="test")
    assert len(psModuleDepFinder.ps_modules.keys()) == 2



# Generated at 2022-06-22 20:11:19.678102
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False
    assert finder._re_cs_module[0] == re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                           r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))

# Generated at 2022-06-22 20:11:23.901339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # create instance for the class
    obj = PSModuleDepFinder()

    # call the method
    obj.scan_exec_script("")

    # assert the return type
    assert isinstance(obj.exec_scripts, dict)



# Generated at 2022-06-22 20:11:34.575279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("wrapper")

    print("exec_scripts:%s" % ps_module_dep_finder.exec_scripts)

# Generated at 2022-06-22 20:11:45.995293
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-22 20:11:53.202059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script(): 
    finder = PSModuleDepFinder() 
    finder.scan_exec_script(name='ansible_process') 
    assert getattr(finder, 'exec_scripts', None) is not None 
    assert isinstance(finder.exec_scripts.keys(), list)
    assert  len(finder.exec_scripts.keys()) > 0 



# Generated at 2022-06-22 20:11:56.341376
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('test')
    assert 'test' in psmdf.exec_scripts


# Generated at 2022-06-22 20:11:59.021013
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert(isinstance(ps_module_dep_finder, PSModuleDepFinder))



# Generated at 2022-06-22 20:12:04.576135
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test method scan_exec_script of class PSModuleDepFinder when
    # module_data is mocked to be None.
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("m1")



# Generated at 2022-06-22 20:12:11.926131
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder._re_cs_module is not None
    assert finder._re_cs_in_ps_module is not None
    assert finder._re_ps_module is not None
    assert finder._re_wrapper is not None
    assert finder._re_ps_version is not None
    assert finder._re_os_version is not None
    assert finder._re_become is not None



# Generated at 2022-06-22 20:12:17.865338
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class AnsibleModule(object):
        def __init__(self):
            self.fail_json = lambda: None

    ansible_module = AnsibleModule()
    ps_dep_finder = PSModuleDepFinder()
    module_data = pkgutil.get_data("ansible.executor.powershell", "base_wrapper.ps1")
    ps_dep_finder.scan_exec_script("base_wrapper")

    assert to_native(module_data) == to_native(ps_dep_finder.exec_scripts["base_wrapper"])


# Generated at 2022-06-22 20:12:26.951888
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module("#!/usr/bin/python\n#Requires -Module Ansible.ModuleUtils.CommonUtilities\n"
                       "#Requires -Module Ansible.ModuleUtils.Network.Junos.Junos\n")
    finder.scan_module("#!\\bin\\python\n#Requires -Module Ansible.ModuleUtils.Network.Junos.Junos\n"
                       "#Requires -Module Ansible.ModuleUtils.CommonUtilities\n")
    with open("output.json", "w") as f:
        json.dump(finder.ps_modules, f, indent=4, sort_keys=True)


# Generated at 2022-06-22 20:12:28.433800
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert(finder is not None)


# Generated at 2022-06-22 20:12:40.169346
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  import tempfile
  from pytest import raises

  from ansible.module_utils.powershell.module_common import PSModuleDepFinder
  from ansible.module_utils.powershell.module_common import _slurp

  # Test basic functionality
  with tempfile.NamedTemporaryFile(mode="wb+") as f:
    f.write(b'hi')
    f.seek(0)
    assert _slurp(f.name) == b'hi'

  with tempfile.NamedTemporaryFile(mode="wb+") as f:
    f.write(b'hi')
    f.seek(0)
    assert _slurp(f) == b'hi'

  # Test with invalid data

# Generated at 2022-06-22 20:12:53.395804
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.exec_scripts) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert not psmdf.ps_version
    assert not psmdf.os_version
    assert not psmdf.become

    assert len(psmdf._re_cs_module) == 1
    assert len(psmdf._re_cs_in_ps_module) == 1
    assert len(psmdf._re_ps_module) == 2
    assert psmdf._re_wrapper
    assert psmdf._re_ps_version
    assert psmdf._re_os_version

# Generated at 2022-06-22 20:13:00.951618
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # test initialization
    dep_finder = PSModuleDepFinder()

    assert(dep_finder.ps_modules == dict())
    assert(dep_finder.exec_scripts == dict())
    assert(dep_finder.cs_utils_wrapper == dict())
    assert(dep_finder.cs_utils_module == dict())
    assert(dep_finder.ps_version == None)
    assert(dep_finder.os_version == None)
    assert(dep_finder.become == False)


# Generated at 2022-06-22 20:13:12.653877
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    tp = PSModuleDepFinder()
    tp.scan_module(pkgutil.get_data("ansible.modules.network.win_shell", "win_shell.psm1"), "network.win_shell")

# Generated at 2022-06-22 20:13:13.245711
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:13:22.342045
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert isinstance(md, PSModuleDepFinder)

# Generated at 2022-06-22 20:13:34.912826
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import tempfile

    from ansible.module_utils.powershell.common import get_env_from_config
    from ansible.module_utils.powershell import PSModuleDepFinder

    from ansible_collections.ns.coll.plugins.module_utils.test_module_utils.test_util_3 import do_test_3
    from ansible.module_utils.test_module_utils.test_util_1 import do_test_1
    from ansible.module_utils.test_module_utils.test_util_2 import do_test_2


# Generated at 2022-06-22 20:13:46.370580
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = (
        '#Requires -Version 1.0\n'
        '#AnsibleRequires -Version 2.0\n'
        '#AnsibleRequires -OSVersion 5.1\n'
        '#AnsibleRequires -OSVersion 5.2\n'
        '#Requires -Module Ansible.ModuleUtils.Foo\n'
        '#Requires -Module Ansible.ModuleUtils.Bar\n'
        '#AnsibleRequires -PowerShell Ansible.ModuleUtils.Baz\n'
    ).encode('ascii')

    finder.scan_module(module_data)
    finder.ps_version == "2.0"
    finder.os_version == "5.2"
    finder.ps_modules

# Generated at 2022-06-22 20:13:52.735670
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mod_dep = PSModuleDepFinder()
    assert mod_dep.ps_modules == dict()
    assert mod_dep.exec_scripts == dict()
    assert mod_dep.cs_utils_wrapper == dict()
    assert mod_dep.cs_utils_module == dict()
    assert mod_dep.ps_version is None
    assert mod_dep.os_version is None
    assert mod_dep.become is False
    assert mod_dep._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                         r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:13:55.272261
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup environment to call scan_module()
    d = PSModuleDepFinder()
    d.scan_module("test")


# Generated at 2022-06-22 20:13:56.816732
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False # TODO: implement your test here



# Generated at 2022-06-22 20:13:58.885096
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder() is not None

# Unit-test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:14:08.418901
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_depfinder = PSModuleDepFinder()

    assert psmodule_depfinder.ps_modules == dict()
    assert psmodule_depfinder.exec_scripts == dict()
    assert psmodule_depfinder.cs_utils_wrapper == dict()
    assert psmodule_depfinder.cs_utils_module == dict()
    assert psmodule_depfinder.ps_version is None
    assert psmodule_depfinder.os_version is None
    assert psmodule_depfinder.become is False

    # _re_cs_module

# Generated at 2022-06-22 20:14:20.862663
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common._collections_compat import UserDict
    from collections import namedtuple

    ModulePath = namedtuple('ModulePath', ['name', 'ext'])

    def _add_module(name, ext, fqn):
        # This method is just for mocking out the real method
        pass

    def _scan_module(self, dep_finder):
        # This method is just for mocking out the real method
        pass

    def _slurp(path):
        # This method is just for mocking out the real method
        return b''

    def _strip_comments(data, hash='#'):
        # This method is just for mocking out the real method
        return b''

    def _import_module(module_name):
        # This method is just for mocking out the real method
        return User

# Generated at 2022-06-22 20:14:34.597557
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.powershell import ps_module_dep_finder
    import unittest

    class TestPSModuleDepFinder(unittest.TestCase):
        def setUp(self):
            self.ps = ps_module_dep_finder.PSModuleDepFinder()

        def test_scan_exec_script(self):
            self.ps.scan_exec_script('powershell_script_wrapper')
            self.assertEqual(self.ps.exec_scripts['powershell_script_wrapper'], b'#!/usr/bin/env pwsh\n$PSVersionTable')
            self.ps.scan_exec_script('powershell_script_wrapper')