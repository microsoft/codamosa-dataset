

# Generated at 2022-06-22 20:04:35.315481
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert(p.ps_modules == dict())
    assert(p.cs_utils_wrapper == dict())
    assert(p.cs_utils_module == dict())
    assert(p.ps_version is None)
    assert(p.os_version is None)
    assert(p.become is False)


# Generated at 2022-06-22 20:04:48.158847
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def _test_module_util_wrapper_ref(module_data, expected_output, version, os_version, become,
                                      wrapper_id=None):
        finder = PSModuleDepFinder()
        finder.scan_module(to_bytes(module_data, errors='surrogate_or_strict'),
                           fqn="ansible_collections.invalid.plugins.module_utils.test_module_util", wrapper=True,
                           powershell=True)

        actual_output = finder.ps_modules
        actual_exec_scripts = finder.exec_scripts
        actual_cs_utils = finder.cs_utils_wrapper
        actual_version = finder.ps_version
        actual_os_version = finder.os_version
        actual_become = finder.become

       

# Generated at 2022-06-22 20:04:48.912590
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-22 20:05:01.037862
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:05:02.968512
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-22 20:05:14.191286
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Test start")
    from ansible.executor.powershell import powershell
    from ansible.module_utils._text import to_bytes
    import tempfile
    d = PSModuleDepFinder()
    d.scan_module(b'\n#AnsibleRequires -PowerShell Ansible.ModuleUtils.PowerShell\n#AnsibleRequires -wrapper is_docker\n    ')
    assert len(d.ps_modules) == 1
    assert len(d.exec_scripts) == 1
    assert d.exec_scripts[to_native('is_docker')] is not None
    assert d.ps_modules[to_native('Ansible.ModuleUtils.PowerShell')] is not None
    print("Test successful")

# Generated at 2022-06-22 20:05:22.836112
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    # Ensure that the finder has defined it's dependencies:
    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.exec_scripts, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert isinstance(finder._re_cs_module, list)
    assert isinstance(finder._re_cs_in_ps_module, list)
    assert isinstance(finder._re_ps_module, list)

# Generated at 2022-06-22 20:05:32.776972
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #ToDo What if the script does not exist.
    class FakePSModuleDepFinder:
        def scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
            return "FakeScan"

    P = PSModuleDepFinder()
    P.scan_exec_script = FakePSModuleDepFinder.scan_module

    name = "FakeScript"
    P.exec_scripts = {name: "FakeScriptData" }
    P.scan_exec_script(name)
    assert name in P.exec_scripts.keys()


# Generated at 2022-06-22 20:05:38.954502
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to raise exception if no script is found for exec side

    f = PSModuleDepFinder()
    name = 'test_module'

    try:
        f.scan_exec_script(name)
    except Exception as e:
        assert 'Could not find executor powershell script for %r' % name in e.message



# Generated at 2022-06-22 20:05:44.528105
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('noop')
    assert ps_module_dep_finder.exec_scripts['noop'].startswith(b'#requires -Version 5.0')


# Generated at 2022-06-22 20:05:45.698091
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:05:55.951871
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == dict()
    assert pmdf.exec_scripts == dict()
    assert pmdf.cs_utils_wrapper == dict()
    assert pmdf.cs_utils_module == dict()
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False
    assert len(pmdf._re_cs_module) == 1
    assert len(pmdf._re_cs_in_ps_module) == 1
    assert len(pmdf._re_ps_module) == 2
    assert pmdf._re_wrapper is not None
    assert pmdf._re_ps_version is not None
    assert pmdf._re_os_version is not None
    assert pmdf._re_become is not None

# Generated at 2022-06-22 20:05:57.104697
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder



# Generated at 2022-06-22 20:06:08.417288
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_bytes

    module_utils = set()
    module_utils.add(('Ansible.ModuleUtils.Automation', ".psm1", "ec2", False))
    module_utils.add(('Ansible.ModuleUtils.Common', ".psm1", "ec2", False))
    module_utils.add(('ansible.module_utils.ec2.common', ".psm1", "ec2", False))
    module_utils.add(('Ansible.ModuleUtils.Database', ".psm1", "ec2", False))

# Generated at 2022-06-22 20:06:13.271848
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup test
    test_obj = PSModuleDepFinder()

    # test
    test_obj.scan_exec_script("script.ps1")

    # assert
    assert test_obj.exec_scripts["script.ps1"] == to_bytes("exec_script_data")



# Generated at 2022-06-22 20:06:16.438594
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    _assert_finder(finder)


# Generated at 2022-06-22 20:06:18.402591
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf



# Generated at 2022-06-22 20:06:20.415575
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder



# Generated at 2022-06-22 20:06:24.297517
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script(b'TestExecWrpper')
    assert depfinder.exec_scripts[b'TestExecWrpper'] == b'123456789'


# Generated at 2022-06-22 20:06:29.260280
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    exec_script = "ansible/executor/powershell"
    exec_script_path = "/" + exec_script + "/Ansible.Powershell.Wrapper.ps1"
    assert PSModuleDepFinder.scan_exec_script(exec_script_path) == "Ansible.Powershell.Wrapper.ps1"


# Generated at 2022-06-22 20:06:38.115840
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # test module code with no dependencies and then check the result
    test_module_no_dep = """#!/usr/bin/env ansible-test-wrapper
# start_line: 0
# end_line: 1
# start_col: 0
# end_col: 2
# name:
#   - test_no_dep
# short-description: Test module with no dependencies
# description: Test module with no dependencies
# options:
#   var:
#     description: nothing
#     type: int
#     required: False
#   required_var:
#     description: This variable is required
#     type: string
#     required: True
"""

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes(test_module_no_dep))

# Generated at 2022-06-22 20:06:44.750432
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = b'''#Requires -Module Ansible.ModuleUtils.SomeModUtil
#Requires -Module Ansible.ModuleUtils.AnotherOne
#AnsibleRequires -Powershell Ansible.ModuleUtils.YetAnotherModUtil
#Requires -Module Ansible.ModuleUtils.LastOne
#AnsibleRequires -CSharpUtil Ansi
'''
    md = PSModuleDepFinder()
    md.scan_module(data)
    assert len(md.ps_modules) == 4



# Generated at 2022-06-22 20:06:51.264760
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None
    assert dep_finder.ps_modules is not None
    assert dep_finder.cs_utils_module is not None
    assert dep_finder.cs_utils_wrapper is not None


# Generated at 2022-06-22 20:06:56.259132
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  ps_module_dep_finder=PSModuleDepFinder()
  assert ps_module_dep_finder.cs_utils_module == {}
  assert ps_module_dep_finder.ps_modules == {}
  assert ps_module_dep_finder.exec_scripts == {}
  assert ps_module_dep_finder.ps_version == None
  assert ps_module_dep_finder.os_version == None
  assert ps_module_dep_finder.become == False
  assert ps_module_dep_finder.cs_utils_wrapper == {}


# Generated at 2022-06-22 20:07:04.423827
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test that a module with no dependencies loads
    dep_finder = PSModuleDepFinder()
    my_module_data = to_bytes(u"""
    #!POWERSHELL
    #Requires -Version 5.0
    #Requires -Module Ansible.ModuleUtils.PSAssembly
    class MyTest {
        """
    )
    dep_finder.scan_module(my_module_data)
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version == '5.0'


# Generated at 2022-06-22 20:07:07.146261
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("Command")



# Generated at 2022-06-22 20:07:10.010955
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("ansible_powershell_common")
    assert len(depfinder.exec_scripts) == 1



# Generated at 2022-06-22 20:07:15.676091
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test for method scan_module of class PSModuleDepFinder"""
    # No exception should be raised
    data = '#Requires -Module Ansible.ModuleUtils.NetApp.Common'
    PSModuleDepFinder().scan_module(data)


# Generated at 2022-06-22 20:07:18.323052
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert 'exec' == PSModuleDepFinder().scan_exec_script('exec')

# Generated at 2022-06-22 20:07:20.053378
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("basic")


# Generated at 2022-06-22 20:07:33.321258
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder._re_cs_module[0].pattern == re.compile('(?i)^using\s((Ansible\..+)|(ansible_collections\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$').pattern

# Generated at 2022-06-22 20:07:39.711242
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    exp_calls = [
        #call(b"using ansible_collections.foo.bar.plugins.module_utils.baz;", "foo.bar.plugins.module_utils.baz"),
        #call(b"using ansible_collections.foo.bar.plugins.modules.baz;", "foo.bar.plugins.modules.baz"),
    ]

    return True


# Generated at 2022-06-22 20:07:43.834602
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    module_data = to_bytes(u'#Requires -Module Ansible.ModuleUtils.Network.Common.Utils\n'
                           u'#Requires -Module Ansible.ModuleUtils.Foo\n'
                           u'#Requires -Module Ansible.ModuleUtils.Network.Cisco.Nxos\n')

    dep_finder.scan_module(module_data)

    assert len(dep_finder.ps_modules.keys()) == 3
    assert dep_finder.ps_modules.keys() == set([u'Ansible.ModuleUtils.Network.Common.Utils',
                                                u'Ansible.ModuleUtils.Foo',
                                                u'Ansible.ModuleUtils.Network.Cisco.Nxos'])


# Generated at 2022-06-22 20:07:54.351307
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import ansible_bolt

    class TestPSModuleDepFinder(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_scan_module(self):
            psmdf = PSModuleDepFinder()

            module_data = u'#Requires -Module Ansible.ModuleUtils.Legacy.User\n#Requires -Module Ansible.ModuleUtils.Legacy.CommonArgs\n'
            psmdf.scan_module(module_data)
            with open(os.path.join(ansible_bolt.__path__[0], "module_utils", "legacy", "user.psm1"), "rb") as file:
                data = file.read()

# Generated at 2022-06-22 20:07:55.506971
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test = PSModuleDepFinder()
    test.scan_exec_script("common")

# Generated at 2022-06-22 20:08:01.994808
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-22 20:08:14.554232
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Set up necessary test data
    collection_path = os.path.expanduser('~/.ansible/collections/ansible_collections/testorg/testcoll')
    os.makedirs(os.path.join(collection_path, 'plugins', 'module_utils'), exist_ok=True)

    cs_file = os.path.join(collection_path, 'plugins', 'module_utils', 'testutil.cs')

# Generated at 2022-06-22 20:08:23.496536
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    code = pkgutil.get_data("ansible_collections.ansible.netcommon.plugins.modules.net_command",
                            "ansible_collections.ansible.netcommon.plugins.modules.net_command.psm1")
    md.scan_module(code, fqn='ansible_collections.ansible.netcommon.plugins.modules.net_command')
    assert len(md.ps_modules.keys()) > 0
    assert 'Ansible.ModuleUtils.Common' in md.ps_modules.keys()



# Generated at 2022-06-22 20:08:33.732293
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Create PSModuleDepFinder object
    module_dep_finder = PSModuleDepFinder()

    # Create module_data
    module_data = b'#Requires -Module Ansible.ModuleUtils.ModuleUtils'

    # Run scan_module function
    module_dep_finder.scan_module(module_data)

    # Check ps_modules keys, it should be 1
    assert len(module_dep_finder.ps_modules) == 1

    # Create module_data
    module_data = b'#Requires -Module Ansible.ModuleUtils.ModuleUtils_2'

    # Run scan_module function
    # This will add the key 'Ansible.ModuleUtils.ModuleUtils_2' to ps_modules
    module_dep_finder.scan_module(module_data)

    # Check ps_modules keys,

# Generated at 2022-06-22 20:08:37.086494
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder_inst = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder_inst, PSModuleDepFinder)


# Generated at 2022-06-22 20:08:44.178684
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert issubclass(PSModuleDepFinder, object)
    assert PSModuleDepFinder().ps_modules == {}
    assert PSModuleDepFinder().exec_scripts == {}
    assert PSModuleDepFinder().cs_utils_wrapper == {}
    assert PSModuleDepFinder().cs_utils_module == {}
    assert PSModuleDepFinder().ps_version is None
    assert PSModuleDepFinder().os_version is None
    assert PSModuleDepFinder().become is False



# Generated at 2022-06-22 20:08:54.174450
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False

    # _re_cs_module
    expected_re_cs_module_0 = re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                   r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))
    assert psmdf._re

# Generated at 2022-06-22 20:09:05.728768
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os

    root_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')

    md = PSModuleDepFinder()

    md.scan_exec_script('InvokePowerShellScript')
    assert md.exec_scripts['InvokePowerShellScript']
    assert md.ps_modules['Ansible.ModuleUtils.Common']

    md = PSModuleDepFinder()

    md.scan_exec_script('InvokePowerShellScript')
    assert md.exec_scripts['InvokePowerShellScript']
    assert md.ps_modules['Ansible.ModuleUtils.Common']

    module_file = os.path.join(root_dir, 'lib/ansible/modules/packaging/os/chocolatey.ps1')

# Generated at 2022-06-22 20:09:10.763593
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    script = "example"
    ps_module_dep_finder.scan_exec_script(script)
    assert ps_module_dep_finder.exec_scripts[script] == "example"


# Generated at 2022-06-22 20:09:15.700643
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:26.855556
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is used to create a text fixture to test the method scan_exec_script
    ps_module_finder = PSModuleDepFinder()
    powershell_script_name = "exec_ps.ps1"
    powershell_script_content = "#Requires -Module ansible_collections.ns.coll.plugins.module_utils.string\n"\
                                "Write-Host \"this is a test\""
    module_utils = set()
    module_utils.add(('ansible_collections.ns.coll.plugins.module_utils.string', '.psm1', '.psm1', False))
    return module_utils, ps_module_finder, powershell_script_name, powershell_script_content


# Generated at 2022-06-22 20:09:38.298097
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:45.243978
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Input data for the unit test.
    ps_module = to_bytes("""#Requires -Module Ansible.ModuleUtils.basic
#Requires -Module Ansible.ModuleUtils.powershell""")

    # Expected result of the unit test.
    expected_result = {
        'Ansible.ModuleUtils.basic': {
            'data': to_bytes(code_for_basic_psm1),
            'path': to_text(path_for_basic_psm1)
        },
        'Ansible.ModuleUtils.powershell': {
            'data': to_bytes(code_for_powershell_psm1),
            'path': to_text(path_for_powershell_psm1)
        }
    }


# Generated at 2022-06-22 20:09:47.381427
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder


# Generated at 2022-06-22 20:09:59.599242
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:11.711958
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = b'#Requires -Module Ansible.ModuleUtils.foo' + \
                  b'#Requires -Module Ansible.ModuleUtils.bar' + \
                  b'#AnsibleRequires -Powershell Ansible.ModuleUtils.baz' + \
                  b'#AnsibleRequires -Powershell ansible_collections.my_namespace.my_collection.plugins.module_utils.bat -Optional' + \
                  b'#AnsibleRequires -CSharpUtil ansible_collections.my_namespace.my_collection.plugins.module_utils.baz'

# Generated at 2022-06-22 20:10:13.195260
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()


# Generated at 2022-06-22 20:10:15.926283
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:10:24.437120
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():  # pragma: no cover
    import sys
    import unittest

    class TestPSModuleDepFinder(unittest.TestCase):

        def test_PSModuleDepFinder_constructor_initializes_correctly(self):
            finder = PSModuleDepFinder()
            self.assertEqual(finder._re_cs_module, [re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))])

# Generated at 2022-06-22 20:10:25.357916
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True == True

# Generated at 2022-06-22 20:10:36.479196
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:45.421349
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile

    finder = PSModuleDepFinder()
    finder.ps_modules = dict()
    # This is also used by validate-modules to get a module's required utils in base and a collection.
    finder.exec_scripts = dict()

    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn't needed
    finder.cs_utils_wrapper = dict()
    finder.cs_utils_module = dict()

    finder.ps_version = None
    finder.os_version = None
    finder.become = False


# Generated at 2022-06-22 20:10:54.852959
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = 'get_default_parser'
    data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
    b_data = to_bytes(data)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(name)
    exec_script = _strip_comments(b_data)
    # exec script string comparison using assertEqual fails if the string contains non-ascii characters.
    # Hence the base64 encoding
    assert exec_script == to_bytes(base64.b64decode(dep_finder.exec_scripts[name])), \
            "The value of attribute 'exec_scripts' for an object of class PSModuleDepFinder is incorrect."


# Generated at 2022-06-22 20:11:03.387361
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf.ps_modules == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()

    assert psmdf._re_cs_module[0].pattern.decode() == '(?i)^using\\s((Ansible\\..+)|(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$'

# Generated at 2022-06-22 20:11:05.900752
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f



# Generated at 2022-06-22 20:11:17.000577
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module("#Requires \"Ansible.ModuleUtils.{0}\" -Verbose\n".format('name'))
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.name'] == 'path'
    ps_module_dep_finder.scan_module("#AnsibleRequires -Powershell Ansible.", ext=".psm1", fqn="module_util.submodule", optional=False, wrapper=False, powershell=True)
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.'] == 'path'

# Generated at 2022-06-22 20:11:27.242372
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    c = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.module_utils.basic", "test_module.psm1")
    c.scan_module(data)
    assert c.cs_utils_module == {
        'ansible_collections.test.test_ns.plugins.module_utils.test_module_util': {
            'data': b'\n'
                    b'# noop\n'
                    b'\n'
                    b'',
            'path': 'ansible_collections/test/test_ns/plugins/module_utils/test_module_util.cs',
        },
    }
    assert c.cs_utils_wrapper == {}

# Generated at 2022-06-22 20:11:31.189155
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)

# _slurp is used to load the data from a file
# So that pkgutil.get_data can be mocked in unit tests

# Generated at 2022-06-22 20:11:39.722793
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module = """
#ansiblerequires -wrapper connect-utility
#ansiblerequires -powershell ansible.module_utils.basic
#requires -module ansible.module_utils.legacy
#ansiblerequires -csharputil ansible_collections.my_namespace.my_collection.plugins.module_utils.my_util.cs

param()
"""
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(test_module)

# Generated at 2022-06-22 20:11:48.329972
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder.ps_modules == {}
    assert depfinder.exec_scripts == {}
    assert depfinder.cs_utils_wrapper == {}
    assert depfinder.cs_utils_module == {}
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False
    assert depfinder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:11:50.548756
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)



# Generated at 2022-06-22 20:11:52.332001
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    df = PSModuleDepFinder()
    assert(df)


# Generated at 2022-06-22 20:12:03.714597
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder._re_ps_module) > 0

    dep_finder = PSModuleDepFinder()
    module_data = '#Requires -Module Ansible.ModuleUtils.Common'
    dep_finder.scan_module(module_data)
    assert isinstance(dep_finder.ps_modules, dict)

    dep_finder = PSModuleDepFinder()
    module_data = "#AnsibleRequires -CSharpUtil ansible.test.test_module_utils.test_module_utils.test_utils"
    dep_finder.scan_module(module_data)
    assert isinstance(dep_finder.cs_utils_module, dict)

    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:12:04.550125
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  # Placeholder for unit test
  pass

# Generated at 2022-06-22 20:12:14.575220
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps = PSModuleDepFinder()
    assert isinstance(ps, PSModuleDepFinder)
    assert ps._re_cs_module[0].match(b'using Ansible.Networking.Acl.Acl;')
    assert ps._re_cs_module[0].match(b'using ansible_collections.test.test.plugins.module_utils.network.common.utils;')
    assert ps._re_cs_module[0].match(b'using Ansible.ModuleUtils.Test1;')
    assert ps._re_cs_module[0].match(b'using ansible_collections.test.test.plugins.module_utils.test1;')


# Generated at 2022-06-22 20:12:24.109905
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.errors import AnsibleError
    import os, sys
    import pkgutil
    import random
    import re
    import string

    # import module snippets
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3, iteritems, string_types
    from ansible.module_utils.six.moves import shlex_quote
    import ansible.module_utils.facts.virtual
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.system import Distro, System

# Generated at 2022-06-22 20:12:24.902646
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:12:36.820672
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:42.508920
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    fd = PSModuleDepFinder()

    assert fd.ps_modules == {}
    assert fd.exec_scripts == {}
    assert fd.cs_utils_wrapper == {}
    assert fd.cs_utils_module == {}

# Unit tests for scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:49.102026
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # the PSModuleDepFinder should have empty dicts for ps_modules, cs_utils_wrapper, and cs_utils_module
    ps_dep_finder = PSModuleDepFinder()

    assert type(ps_dep_finder.ps_modules) == dict
    assert type(ps_dep_finder.cs_utils_wrapper) == dict
    assert type(ps_dep_finder.cs_utils_module) == dict


# Generated at 2022-06-22 20:13:01.214882
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible.plugins.loader
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.powershell.pwsh_common import PWSHLibrary, PSScriptExecArg
    from ansible.module_utils.azure_rm_common import AzureRMModuleBase
    from ansible_collections.cloudbaseinit.cloudbaseinit.plugins.module_utils.cloudbaseinit import (
    CloudbaseinitModule, 
    cloudbaseinit_common_argument_spec,
    )
    from ansible_collections.cloudbaseinit.cloudbaseinit.plugins.module_utils.cloudbaseinit import keystone
    from ansible_collections.cloudbaseinit.cloudbaseinit.plugins.module_utils.cloudbaseinit import osutils

# Generated at 2022-06-22 20:13:13.107304
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_mdf = PSModuleDepFinder()
    assert ps_mdf.ps_modules == dict()
    assert ps_mdf.exec_scripts == dict()
    assert ps_mdf.cs_utils_wrapper == dict()
    assert ps_mdf.cs_utils_module == dict()
    assert ps_mdf.ps_version is None
    assert ps_mdf.os_version is None
    assert ps_mdf.become is False

    assert len(ps_mdf._re_cs_module) == 1
    assert len(ps_mdf._re_cs_in_ps_module) == 1
    assert len(ps_mdf._re_ps_module) == 2
    assert ps_mdf._re_wrapper
    assert ps_mdf._re_ps_version
    assert ps_mdf

# Generated at 2022-06-22 20:13:20.290465
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test PSModuleDepFinder constructor with default values
    test_dep_finder = PSModuleDepFinder()
    assert type(test_dep_finder) == PSModuleDepFinder
    assert isinstance(test_dep_finder.ps_modules, dict)
    assert isinstance(test_dep_finder.exec_scripts, dict)
    assert isinstance(test_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(test_dep_finder.cs_utils_module, dict)
    assert test_dep_finder.ps_version is None
    assert test_dep_finder.os_version is None
    assert test_dep_finder.become is False


# Generated at 2022-06-22 20:13:33.180174
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()

# Generated at 2022-06-22 20:13:44.769063
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(b'#Requires -Module foo.psm1')
    md.scan_module(b'#Requires -Module ansible_collections.foo.bar.plugins.module_utils.baz.psm1')
    md.scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.foo.bar.plugins.module_utils.baz.cs')
    md.scan_module(b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Powershell.cs')
    md.scan_module(b'#Requires -Module Ansible.ModuleUtils.Powershell.cs')
    md.scan_module(b'#Requires -Module Ansible.ModuleUtils.Powershell')
    md.scan_module

# Generated at 2022-06-22 20:13:51.907843
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os.path
    import sys
    import unittest

    test_case_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(test_case_dir, 'test_data/module_dep_finder')

    def reload_module(mod):
        # Reload from test case dir since it doesn't have the plugins
        # loaded from the test working dir.
        orig_module_path = sys.modules[mod].__path__

        del sys.modules[mod]

        import_module("ansible_collections.test.test_plugins.targets.test_module_dep_finder")
        for path in orig_module_path:
            sys.modules[mod].__path__.append(path)

    # We need to call this to get the ModuleDepFinder class which

# Generated at 2022-06-22 20:13:55.640595
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    b = to_bytes("Foo")
    assert md.scan_module(b) is None
    assert md.scan_exec_script("Random") is None



# Generated at 2022-06-22 20:14:04.945292
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule
    import ansible_collections.testns.testcoll.plugins.module_utils.test_utils

    PSModuleDepFinder_obj = PSModuleDepFinder()
    named_tuple_module_deps = namedtuple(
        "module_deps",
        [
            "ps_modules",
            "cs_utils_wrapper",
            "cs_utils_module"
        ]
    )

# Generated at 2022-06-22 20:14:05.709449
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psdf = PSModuleDepFinder()
    assert psdf



# Generated at 2022-06-22 20:14:12.609024
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    data = b'using ansible_collections.ns.coll.plugins.module_utils.name;'
    finder.scan_module(data, wrapper=False, powershell=False)
    assert finder.cs_utils_module == {'ansible_collections.ns.coll.plugins.module_utils.name': {'data': data, 'path': None}}
    assert 'ansible_collections.ns.coll.plugins.module_utils.name' in finder.cs_utils_module.keys()

    data = b'using ansible.name;'
    finder.scan_module(data, wrapper=False, powershell=False)
    assert finder.cs_utils_module == {'ansible.name': {'data': data, 'path': None}}

# Generated at 2022-06-22 20:14:19.775680
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()

    assert isinstance(p.ps_modules, dict)
    assert isinstance(p.cs_utils_wrapper, dict)
    assert isinstance(p.cs_utils_module, dict)
    assert isinstance(p.exec_scripts, dict)
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become is False



# Generated at 2022-06-22 20:14:25.393786
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test case for PSModuleDepFinder.scan_module
    # Test scan_module()
    data = "abc\n#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.CSharpUtil\n"
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(data, wrapper=False, powershell=True)
    assert(dep_finder.ps_modules["Ansible.ModuleUtils.CSharpUtil"] is not None)

# Generated at 2022-06-22 20:14:28.584600
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script('posh-base') == None
