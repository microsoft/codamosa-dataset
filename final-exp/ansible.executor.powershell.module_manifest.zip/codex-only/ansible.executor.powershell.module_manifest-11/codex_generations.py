

# Generated at 2022-06-22 20:04:31.765718
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("collect_server_info")



# Generated at 2022-06-22 20:04:38.891395
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder._re_cs_module is [
        re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]

# Generated at 2022-06-22 20:04:50.279738
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This is just a simple unit test and uses the method's docstring to generate assertions.
    # It won't currently check that all parameters are covered, just the first one.
    assert hasattr(PSModuleDepFinder, "scan_module"), "PSModuleDepFinder doesn't have a method named scan_module"
    method = getattr(PSModuleDepFinder, "scan_module")
    assert method.__doc__, "scan_module doesn't have a docstring"
    assert isinstance(method.__doc__, str), "scan_module docstring isn't a string"
    lines = [line.strip() for line in method.__doc__.split() if line.strip().startswith("param")]
    assert lines, "scan_module doesn't have any param lines"

# Generated at 2022-06-22 20:04:56.543534
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == {}
    assert pmdf.cs_utils_module == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False


# Generated at 2022-06-22 20:05:02.974170
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Some type of hacky unit test, but it was the best we could come up with.
    """
    finder = PSModuleDepFinder()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # TODO: test all the builtin patterns with a module, module_utilities, and a collection module/module_util.
    # Since this probably means building a test collection and there are some flaky
    # tests in the validate-modules script, we'll get back to this later.


# Generated at 2022-06-22 20:05:14.811492
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test that scan_module detects when a module depends on a module_util
    and the module_util depends on another module_util.
    :return:
    """

    module_with_dependency = b"""
$PSVersionTable
    #Requires -Module Ansible.ModuleUtils.Foo
    #Requires -Module Ansible.ModuleUtils.Bar
    #Requires -Module NotAnsible.ModuleUtils.Baz

    # AnsibleRequires -PowerShell Ansible.ModuleUtils.Bacon
"""

# Generated at 2022-06-22 20:05:23.326980
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    remove_me = ('module_utils/powerdelivery.py',
                 'module_utils/basic.py',
                 'module_utils/common.py',
                 'module_utils/net_tools.py',
                 'module_utils/network.py',
                 'module_utils/networking_utils.py',
                 'module_utils/shell.py',
                 'module_utils/storage.py',
                 'module_utils/system.py')

    class PSModuleDepFinderForTest(PSModuleDepFinder):
        def __init__(self):
            super(PSModuleDepFinderForTest, self).__init__()

        def _add_module(self, name, ext, fqn, optional):
            pass

        def scan_exec_script(self, name):
            pass

    ps_util = PS

# Generated at 2022-06-22 20:05:35.843536
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()
    assert ps_module_dep_finder.cs_utils_wrapper == dict()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_version == None
    assert ps_module_dep_finder.os_version == None
    assert ps_module_dep_finder.become == False
    assert isinstance(ps_module_dep_finder._re_cs_module, type([]))

# Generated at 2022-06-22 20:05:37.958495
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:05:44.641037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("common")
    assert(mdf.exec_scripts["common"])
    assert(mdf.exec_scripts["common"].startswith(b'# Common module'))
    assert(mdf.ps_modules['Ansible.ModuleUtils.Powershell'])


# Generated at 2022-06-22 20:05:48.384589
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert isinstance(ps_module_finder, PSModuleDepFinder)

# Test to ensure importing a module_util from a collection works successfully

# Generated at 2022-06-22 20:05:49.746487
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)


# Generated at 2022-06-22 20:05:58.818664
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    x = PSModuleDepFinder()
    x.scan_exec_script('powershell')

# Generated at 2022-06-22 20:06:07.036616
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test scan_exec_script
    test_obj = PSModuleDepFinder()
    test_input = '/tmp/ansible_test_playbook.yaml'
    with pytest.raises(AnsibleError) as excinfo:
        test_obj.scan_exec_script(test_input)

    # test scan_exec_script
    test_obj = PSModuleDepFinder()
    test_input = 'ansible_test_playbook.yaml'
    test_obj.scan_exec_script(test_input)



# Generated at 2022-06-22 20:06:16.864813
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cwd = os.getcwd()
    os.chdir("/tmp/ansible_powershell_payload_test/")
    data1 = pkgutil.get_data("ansible.executor.powershell", "exec_wrapper.ps1")
    data2 = pkgutil.get_data("ansible.executor.powershell", "debug.ps1")
    os.chdir(cwd)
    assert data1 is not None
    assert data2 is not None
    data1 = to_bytes(data1)
    data2 = to_bytes(data2)
    data = data1 + b"\n" + data2
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec_wrapper")

# Generated at 2022-06-22 20:06:21.529695
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # params
    module_data = ''
    fqn = None
    wrapper = False
    powershell = True
    # execution
    obj = PSModuleDepFinder()
    # assert
    assert obj.scan_module(module_data, fqn, wrapper, powershell) is None


# Generated at 2022-06-22 20:06:31.800956
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # iterate over the body of module_utils/basic.psm1
    for line in pkgutil.get_data('ansible.module_utils', 'basic.psm1').split(b'\n'):
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(line)
        assert dep_finder.ps_modules == {}
    
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(line, wrapper=True)
        assert dep_finder.ps_modules == {}
    # iterate over the body of module_utils/basic.psm1
    for line in pkgutil.get_data('ansible', 'module_utils/common/netcommon.psm1').split(b'\n'):
        dep_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:06:37.469421
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a sample module from Ansible
    from ansible.modules.system import import_role
    test_scanner = PSModuleDepFinder()
    test_scanner.scan_module(import_role.__doc__)


# Generated at 2022-06-22 20:06:46.553470
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup
    random_seed = random.randrange(1, 9999999)
    random.seed(random_seed)
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.ps_modules = dict()
    ps_module_dep_finder.exec_scripts = dict()
    ps_module_dep_finder.cs_utils_wrapper = dict()
    ps_module_dep_finder.cs_utils_module = dict()
    ps_module_dep_finder.ps_version = None
    ps_module_dep_finder.os_version = None
    ps_module_dep_finder.become = False
    name = 'wrapper'
    # run code
    ps_module_dep_finder.scan_exec_script(name)
    # fixup random seed

# Generated at 2022-06-22 20:06:58.039142
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:06:59.747691
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # this method is tested in test_gather_facts.py
    assert True



# Generated at 2022-06-22 20:07:01.287578
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf is not None


# Generated at 2022-06-22 20:07:09.320834
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Check the initial attributes of the instance
    finder = PSModuleDepFinder()

    # check that they are the correct types
    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.exec_scripts, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert isinstance(finder._re_cs_module, list)
    assert isinstance(finder._re_cs_in_ps_module, list)
    assert isinstance(finder._re_ps_module, list)
    assert isinstance(finder._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:07:19.016195
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module is not None
    assert dep_finder._re_cs_in_ps_module is not None
    assert dep_finder._re_ps_module is not None
    assert dep_finder._re_wrapper is not None
    assert dep_finder._re_ps_version is not None
    assert dep_finder._re_os_version is not None
    assert dep_

# Generated at 2022-06-22 20:07:25.558982
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmd = PSModuleDepFinder()
    assert psmd.ps_modules == {}
    assert psmd.exec_scripts == {}
    assert psmd.cs_utils_wrapper == {}
    assert psmd.cs_utils_module == {}
    assert psmd.ps_version is None
    assert psmd.os_version is None
    assert psmd.become is False
    assert list(psmd._re_cs_module) == [re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                             r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))]

# Generated at 2022-06-22 20:07:28.962490
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:07:29.673713
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-22 20:07:34.769341
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # test a specific module
    module_finder = PSModuleDepFinder()
    fqn = 'ansible_collections.asm.asm.plugins.modules.asm_sslvpn_user'

    try:
        module = resource_from_fqcr(module_finder, fqn)
    except (IOError, OSError):
        # module doesn't exist
        pass
    else:
        for name, module_data in module.items():
            module_finder.scan_module(module_data, name)

    # test all powershell modules
    module_finder = PSModuleDepFinder()
    path = 'powershell'

    try:
        modules = ps_module_utils_loader.all(path)
    except (IOError, OSError):
        # module_utils path doesn't exist
        pass

# Generated at 2022-06-22 20:07:47.395686
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()

    try:
        pmdf.scan_module(b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.TestModule1\n")
        assert False
    except AnsibleError:
        pass

    try:
        pmdf.scan_module(b"#AnsibleRequires -PowerShell ansible_collection.some.collection.plugins.module_utils.TestModule1\n")
        assert False
    except AnsibleError:
        pass

    try:
        pmdf.scan_module(b"#AnsibleRequires -PowerShell ..TestModule1\n")
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-22 20:07:57.935185
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    
    @pytest.fixture()
    def psmoduledepfinder(monkeypatch):
        import ansible.plugins.loader as loader
        monkeypatch.setattr(loader, "ps_module_utils_loader", None)
        from ansible.module_utils.powershell.internal.ps_module_dep_finder import PSModuleDepFinder
        psmoduledepfinder = PSModuleDepFinder()
        return psmoduledepfinder
    

# Generated at 2022-06-22 20:08:02.211814
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psf = PSModuleDepFinder()
    psf.scan_exec_script('Native/Ansible.Windows')
    assert b'function Test-HasAdmin' in psf.exec_scripts['Native/Ansible.Windows']


# Generated at 2022-06-22 20:08:14.731960
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import os.path
    dep_finder = PSModuleDepFinder()

    # Test 1
    # Test if index_module_utils function can read a file
    # and populate the ps_modules dictionary

    # Make an evilly named directory, that contains a file
    module_util_data = dep_finder.ps_modules.get('Test.ModuleUtils.Util', None)
    if module_util_data:
        del dep_finder.ps_modules['Test.ModuleUtils.Util']
    test_dep_finder_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'TestModuleUtils', 'plugins', 'module_utils')
    test_dep_finder_file = os.path.join(test_dep_finder_path, 'util.psm1')

# Generated at 2022-06-22 20:08:20.630566
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    version, os_version, become = PSModuleDepFinder().parse_module_metadata(
        "/usr/lib/python2.7/site-packages/ansible/modules/system/setup.ps1")

    assert version == '5.1'
    assert os_version == '10.0.14393.0'
    assert become



# Generated at 2022-06-22 20:08:32.865414
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # mock os.path.exists
    orig_exists = os.path.exists
    def mock_exists(path):
        if path.startswith("lib/ansible/executor/powershell/TestExecScript"):
            return True
        else:
            return orig_exists(path)
    os.path.exists = mock_exists

    # mock open
    orig_open = open
    def mock_open(path, *args, **kwargs):
        if path.startswith("lib/ansible/executor/powershell/TestExecScript"):
            class FakeFile(object):
                def __init__(self, path):
                    self.path = path
                    self.data = "edx = "+path
                def read(self):
                    return self.data

# Generated at 2022-06-22 20:08:42.841037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    import os
    import sys
    import unittest

    # Disabling too-many-lines for test case, as the unittest itself is getting huge
    # disabling too-many-public-methods, as this is a unittest class
    # pylint: disable=too-many-lines, too-many-public-methods
    #
    # Test case for method scan_exec_script of class PSModuleDepFinder
    # including the following test_cases
    # 01 - Test case for exec_script when fails to find script
    #

# Generated at 2022-06-22 20:08:43.882757
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:08:45.297189
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-22 20:08:48.958885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    module_data = """#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.CSharpUtil"""
    finder.scan_module(module_data, wrapper=True, powershell=True)


# Generated at 2022-06-22 20:08:57.390887
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import os
    import random
    import uuid
    from ansible.parsing.utils.data import data_merge
    from ansible.utils.collection_loader import AnsibleCollectionLoader, _load_collections

    collection_dir = os.path.join(os.getcwd(), "collection_dir_{0}".format(random.randint(0, 10000)))
    if not os.path.exists(collection_dir):
        os.makedirs(collection_dir)
        os.makedirs(os.path.join(collection_dir, "ansible_namespace"))
        os.makedirs(os.path.join(collection_dir, "ansible_collection"))
        os.makedirs(os.path.join(collection_dir, "ansible_collection", "plugins"))
        os.makedirs

# Generated at 2022-06-22 20:09:01.379511
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()



# Generated at 2022-06-22 20:09:08.765444
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_md = PSModuleDepFinder()
    ps_md.ps_version = "6.1.0"
    ps_md.os_version = "6.2.0"
    ps_md.become = True

    ps_md.scan_exec_script("win_ping")

    print(json.dumps(ps_md._serialize_deps()))



# Generated at 2022-06-22 20:09:11.726951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The function '_slurp' can't be tested without knowing the path of an existing file
    # TODO: Need to implement a function to mock '_slurp'
    pass


# Generated at 2022-06-22 20:09:14.965497
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test instantiating the PSModuleDepFinder class.
    test_finder = PSModuleDepFinder()
    assert test_finder is not None



# Generated at 2022-06-22 20:09:26.897349
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:38.343475
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    m = PSModuleDepFinder()
    assert len(m.cs_utils_wrapper) == 0
    assert len(m.cs_utils_module) == 0
    assert len(m.exec_scripts) == 0
    assert len(m.ps_modules) == 0

    expected_dictionaries = {
        'cs_utils_wrapper': {},
        'cs_utils_module': {},
        'exec_scripts': {},
        'ps_modules': {},
    }

    assert m.ps_version is None
    assert m.os_version is None
    assert m.become is False

    # TODO: How does it differ from the object instantiation
    for dictionary in vars(m).keys():
        check_dictionary = expected_dictionaries.get(dictionary, None)

# Generated at 2022-06-22 20:09:41.557550
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for class PSModuleDepFinder
    :param module_data: py file with ansible module code to test
    :return: None
    """
    
    dep = PSModuleDepFinder()
    dep.scan_exec_script('ansibe_powershell_converter')

    return dep

# Generated at 2022-06-22 20:09:48.087181
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p.ps_modules == dict()
    assert p.exec_scripts == dict()
    assert p.cs_utils_wrapper == dict()
    assert p.cs_utils_module == dict()
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become is False


# Generated at 2022-06-22 20:09:57.085859
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible_collections.some.namespace.plugins.module_utils.common.utils import dir_exists
    finder = PSModuleDepFinder()
    assert len(finder.exec_scripts) == 0
    finder.scan_exec_script('WinCommon')
    assert len(finder.exec_scripts) == 1
    assert to_text(finder.exec_scripts['WinCommon']) == to_text(dir_exists(b'C:\\Windows').encode('utf-8'))

# Generated at 2022-06-22 20:10:01.292925
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import tempfile
    import shutil
    import os

    md = PSModuleDepFinder()

    # Test the script is found
    assert(md.scan_exec_script('ansible_wrapper') is None)

    # We have no way to mock pkgutil.get_data so we create a temp directory
    # and add it to sys.path and move the actual script into it from
    # lib/ansible/executor/powershell/

    # Make a temp dir
    temp_dir = tempfile.mkdtemp()
    # Add to sys.path so we can use pkgutil
    sys.path.append(temp_dir)
    # Move the script into the temp dir

# Generated at 2022-06-22 20:10:03.884044
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pmdf = PSModuleDepFinder()
    module_data = b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.Pam\n"
    pmdf.scan_module(module_data, fqn="abc.abc", wrapper=False)
    assert pmdf.ps_modules == {'Ansible.ModuleUtils.Pam': {'data': b'byte_data', 'path': 'path'}}



# Generated at 2022-06-22 20:10:08.911216
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test all the exec scripts here so that if any are updated, we know that we
    # are tracking them.
    from ansible.module_utils.common._json_compat import _b_decode, _b_encode

    # This is copied from ps_module_utils_loader.find_plugin.
    # We can't reuse the code directly as it uses the module_utils_loader
    # rather than the module_dep_finder.
    def _get_lost_utils(util_list, util_dir):
        found_list = []
        missing_list = []

        for util in util_list:
            util_path = os.path.join(util_dir, util + '.psm1')
            if os.path.exists(util_path):
                found_list.append(util)
            else:
                missing

# Generated at 2022-06-22 20:10:20.417649
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Update this test to load from a file not a string
    ps_module_util_name = 'Ansible.ModuleUtils.Hyperv'
    ps_module_util_extn = '.psm1'
    csharp_module_util_name = 'ansible_collections.microsoft.hyperv.plugins.module_utils.hyperv.base_v2'
    csharp_module_util_extn = '.cs'
    module_content = '''#Requires -Module {0}
#Requires -Module {1}
    '''.format(ps_module_util_name, csharp_module_util_name)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_content)
    assert ps_module_util_name in dep_finder.ps_modules

# Generated at 2022-06-22 20:10:33.137558
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:40.070945
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import os
    import tempfile

    def cleanup():
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Generated at 2022-06-22 20:10:45.699630
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder
    # scan_exec_script executes script to import module
    # test for the powershell script exception
    # test for the powershell script exception
    test_instance = PSModuleDepFinder()
    # Call the method to scan the script data
    test = test_instance.scan_exec_script('invalid-script-name')
    # Assert error message
    assert test == AnsibleError('Could not find executor powershell script '
                                'for \'invalid-script-name\'')


# Generated at 2022-06-22 20:10:50.860177
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version == None
    assert dep_finder.become == False
    assert isinstance(dep_finder._re_cs_in_ps_module, list)
    assert isinstance(dep_finder._re_ps_module, list)
    assert dep_finder._re_wrapper != None
    assert dep_finder._re_ps_version != None
    assert dep_finder._re_os_version != None
    assert dep_finder._re_become != None


# Slurp a file and return the data

# Generated at 2022-06-22 20:11:00.375790
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_deps = PSModuleDepFinder()
    assert psmodule_deps.ps_modules == dict(), "Failed to create PSModuleDepFinder object with valid value"
    assert psmodule_deps.exec_scripts == dict(), "Failed to create PSModuleDepFinder object with valid value"
    assert psmodule_deps.cs_utils_wrapper == dict(), "Failed to create PSModuleDepFinder object with valid value"
    assert psmodule_deps.cs_utils_module == dict(), "Failed to create PSModuleDepFinder object with valid value"
    assert psmodule_deps.ps_version == None, "Failed to create PSModuleDepFinder object with valid value"
    assert psmodule_deps.os_version == None, "Failed to create PSModuleDepFinder object with valid value"
   

# Generated at 2022-06-22 20:11:12.892224
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"module_util: 'Ansible.ModuleUtils.Test'")
    assert "Ansible.ModuleUtils.Test" in dep_finder.ps_modules
    dep_finder.scan_module(b"module_util: 'ansible-collections.ansible.pod.plugins.module_utils.test'")
    assert "ansible-collections.ansible.pod.plugins.module_utils.test" in dep_finder.ps_modules
    dep_finder.scan_module(b"module_util: '..module_utils.test'")
    assert "..module_util.test" in dep_finder.ps_modules

# Generated at 2022-06-22 20:11:16.069947
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    d = PSModuleDepFinder()
    d.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test')
    assert d.ps_modules


# Generated at 2022-06-22 20:11:27.963241
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os

    test_module_path = os.path.dirname(os.path.realpath(__file__)) + '/test_module_util_deps.psm1'
    test_module_data = _slurp(test_module_path)
    assert test_module_data

    finder = PSModuleDepFinder()
    finder.scan_module(test_module_data, fqn='test.module_util_deps')


# Generated at 2022-06-22 20:11:34.548769
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper.pattern == r'(?i)^#\s*ansiblerequires\s+-wrapper\s+(\w*)'

# Generated at 2022-06-22 20:11:42.746468
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # run the tested method with pre-filled data
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("AnsiblePowerShell")
    # assert that the expected values are returned
    assert depfinder.exec_scripts['AnsiblePowerShell'] is not None
    assert depfinder.exec_scripts['AnsiblePowerShell'] == pkgutil.get_data("ansible.executor.powershell", "AnsiblePowerShell.ps1").replace(b'#', b'')



# Generated at 2022-06-22 20:11:46.433838
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #arrange
    dep_finder = PSModuleDepFinder()
    name = b"ExecPowerShellModule"
    #act
    dep_finder.scan_exec_script(name)
    #assert
    assert "ExecPowerShellModule" in dep_finder.exec_scripts


# Generated at 2022-06-22 20:11:59.072713
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test with a PS module with a C# module_util import
    f = PSModuleDepFinder()

# Generated at 2022-06-22 20:12:09.010938
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Starting test test_PSModuleDepFinder_scan_module")
    obj = PSModuleDepFinder()
    data = b"#Requires -Module Ansible.ModuleUtils.Powershell\n#Requires -Module Ansible.ModuleUtils.Network"
    obj.scan_module(data)
    assert obj.ps_modules.keys() == {'Ansible.ModuleUtils.Network', 'Ansible.ModuleUtils.Powershell'}
    print("test_PSModuleDepFinder_scan_module succeeded")


# Generated at 2022-06-22 20:12:20.202285
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Check that scan_module properly adds the ps_modules and cs_utils_wrapper
    # when scanning a C# module util.  Note that this test method assumes there
    # are no existing files in the test_dir directory.
    #
    # If you modify this test, you must also update
    # test/units/plugins/test_.module_utils.collection.test_ansible.module_utils.common.plugin_dir
    #

    assert test_dir.startswith('t/test_dir/')

# Generated at 2022-06-22 20:12:32.188144
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test scan_module with a test module having the given dependencies.
    """
    # Test module with 2 dependencies, one of which is optional.
    module_data = """#Requires -Module Ansible.ModuleUtils.One
                     #Requires -Module Ansible.ModuleUtils.Two
                     #Requires -Module Ansible.ModuleUtils.Three -Optional
                     #Requires -Module Ansible.ModuleUtils.Four -Optional
                     #Requires -Module Ansible.ModuleUtils.Five -Optional"""

    def _slurp_string(name):
        return name

    mdf = PSModuleDepFinder()
    mdf.scan_module(module_data)

    # One of the dependencies shall be optional, so only 4 instead of 5.
    assert len(mdf.ps_modules) == 4
    # Check the page size

# Generated at 2022-06-22 20:12:45.186235
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import random
    
    from ansible.module_utils.common.process_common import FindFile
    from ansible.module_utils.common import libcloud_version

    object = PSModuleDepFinder()
    libcloud_version_value = str(libcloud_version())
    libcloud_version_value_strip_zero = libcloud_version_value.rstrip("0")
    if libcloud_version_value_strip_zero.endswith('.'):
        libcloud_version_value_strip_zero = libcloud_version_value_strip_zero[:-1]

    if not os.path.isfile(FindFile('ansible_collections/ansible/community/plugins/modules/aws_s3.py')):
        raise AssertionError("aws_s3.py is not a file")

# Generated at 2022-06-22 20:12:46.792175
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_variable = "test"
    assert test_variable == "test"

# Generated at 2022-06-22 20:12:54.226947
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # NOTE: In order for this test to run, you need to have a directory called
    # C:\Users\brian\ansible\ansible-test that has a clone of the
    # ansible/ansible repo, with your current working directory being the
    # root of that repo.
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script("init")

# Method _add_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:02.992686
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2


# Generated at 2022-06-22 20:13:14.780210
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing load of executor powershell script
    finder = PSModuleDepFinder()
    script_name = "Test_GetDefaultIgnorePatterns"
    script_exists = pkgutil.get_data("ansible.executor.powershell", script_name + ".ps1")
    assert script_exists is not None, "Executor powershell script does not exist"
    # If the psm is not loaded yet, the checks should be None
    assert finder.exec_scripts.get(script_name, None) is None
    finder.scan_exec_script(script_name)
    # Verify the powershell script is loaded
    assert finder.exec_scripts.get(script_name, None) is not None
    # Verify loading of a module util

# Generated at 2022-06-22 20:13:16.876542
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Test that the method "scan_exec_script" of class PSModuleDepFinder can be called.
    raise NotImplementedError()


# Generated at 2022-06-22 20:13:24.714974
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import pkgutil
    import sys
    import tempfile

    # Insert the current plugin path at the front of sys.path so we can import it
    # while running the tests.
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

    from ansible.plugins.loader import ps_module_utils_loader
    ps_module_utils_loader.add_directory(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'module_utils'))

    tf = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-22 20:13:28.410126
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:13:40.541509
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Constructor
    mdf = PSModuleDepFinder()
    assert mdf.ps_version is None
    assert mdf.os_version is None
    assert mdf.become is False

    module_data = u'''#Requires -Version 5.0

#Requires -Module Ansible.ModuleUtils.PowerShell
'''
    mdf.scan_module(to_bytes(module_data), fqn=u'Ansible.Windows.WinRM')
    assert LooseVersion(mdf.ps_version) == LooseVersion('5.0')
    assert mdf.os_version is None
    assert mdf.become is False


# Generated at 2022-06-22 20:13:44.925588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    assert isinstance(obj, PSModuleDepFinder)
    obj.scan_exec_script('Windows')
    obj.scan_exec_script('Unix')
    assert obj.exec_scripts.keys() == set(['Windows', 'Unix'])


# Generated at 2022-06-22 20:13:47.829371
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test ps_version, os_version, and become initialization
    finder = PSModuleDepFinder()
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False


# Generated at 2022-06-22 20:13:55.009079
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test class initialization
    finder = PSModuleDepFinder()

    # No modules should be added at this time
    assert(len(finder.ps_modules) == 0)
    assert(len(finder.cs_utils_wrapper) == 0)
    assert(len(finder.cs_utils_module) == 0)
    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)

# Test the _add_module function

# Generated at 2022-06-22 20:14:04.146335
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    t = PSModuleDepFinder()
    assert t.ps_modules is not None
    assert t.exec_scripts is not None
    assert t.cs_utils_wrapper is not None
    assert t.cs_utils_module is not None
    assert t.ps_version is None
    assert t.os_version is None
    assert t.become is False
    assert t._re_cs_module is not None
    assert t._re_cs_in_ps_module is not None
    assert t._re_ps_module is not None
    assert t._re_wrapper is not None
    assert t._re_ps_version is not None
    assert t._re_os_version is not None
    assert t._re_become is not None


# Generated at 2022-06-22 20:14:10.688754
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()
    
    module_data = '#Requires -Module Ansible.ModuleUtils.Powershell.Convert'
    ps_dep_finder.scan_module(module_data)
    assert len(ps_dep_finder.ps_modules) == 1
    assert ps_dep_finder.ps_modules[0].get('data') is not None
    assert 'Convert.psm1' in ps_dep_finder.ps_modules[0].get('path')
    

# Generated at 2022-06-22 20:14:23.165046
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()
    assert module_dep_finder.ps_modules == {}
    assert module_dep_finder.cs_utils_wrapper == {}
    assert module_dep_finder.cs_utils_module == {}
    assert module_dep_finder.ps_version is None
    assert module_dep_finder.os_version is None
    assert module_dep_finder.become is False
    assert len(module_dep_finder._re_cs_module) == 1
    assert len(module_dep_finder._re_cs_in_ps_module) == 1
    assert len(module_dep_finder._re_ps_module) == 2
    # A random key for wrapped script generated for the first time
    assert len(module_dep_finder.exec_scripts) == 1


# Generated at 2022-06-22 20:14:29.056723
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # psscriptrunner is a wrapper dependency of winrm.py not a module dependency.
    finder.scan_exec_script('psscriptrunner')
    assert 'psscriptrunner' in finder.exec_scripts.keys()
