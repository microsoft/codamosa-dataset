

# Generated at 2022-06-22 20:04:38.035198
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # mock power shell script that uses the umask module_util
    module_data = b"""#Requires -Module Ansible.ModuleUtils.umask
#AnsibleRequires -CSharpUtil ansible_collections.amazon.aws.plugins.module_utils.core"""

    # call the scan_module method of the PSModuleDepFinder instance
    mu_finder = PSModuleDepFinder()
    mu_finder.scan_exec_script('example_script')

    assert 'umask' in mu_finder.ps_modules.keys()
    assert 'core' in mu_finder.cs_utils_wrapper.keys()


# Generated at 2022-06-22 20:04:45.882415
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(open("test/sanity/code/powershell/TestData/FizzBuzz/Library/FizzBuzz.psm1").read())
    assert finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]["data"] != None

# Utility function to strip comments from JSON (but only if not in debug mode)

# Generated at 2022-06-22 20:04:50.443233
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_mdf = PSModuleDepFinder()
    ps_mdf.scan_exec_script('test_script')
    assert ps_mdf.exec_scripts['test_script']


# Generated at 2022-06-22 20:04:58.791532
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

# Adds a unique prefix and suffix to each line of the input data.
# The result is returned as a UTF-8 encoded bytestring.

# Generated at 2022-06-22 20:05:00.826284
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("ansible_powershell_convert")


# Generated at 2022-06-22 20:05:10.487625
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    module_data = pkgutil.get_data("ansible_collections.microsoft.windows.plugins.modules", to_native("win_ping.ps1"))
    module_data1 = pkgutil.get_data("ansible_collections.microsoft.windows.plugins.modules", to_native("win_service.ps1"))
    depfinder.scan_module(module_data)
    depfinder.scan_module(module_data1)
    assert depfinder.cs_utils_wrapper
    assert depfinder.ps_modules

# Generated at 2022-06-22 20:05:12.414529
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for the scan_exec_script method of class PSModuleDepFinder, which
    # scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    pass



# Generated at 2022-06-22 20:05:14.820537
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False



# Generated at 2022-06-22 20:05:16.542417
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('command')


# Generated at 2022-06-22 20:05:22.427070
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    name = 'powershell'
    dep_finder.scan_exec_script(name)
    assert dep_finder.exec_scripts[name]
    assert dep_finder.exec_scripts['env_vars']
    assert dep_finder.ps_modules['ansible_collections.ansible.collections_test.plugins.module_utils.common_json']


# Generated at 2022-06-22 20:05:35.426603
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Helper function used to test scan_exec_script of class PSModuleDepFinder.
    # This function just checks for few lines at the beginning and at the end of
    # the script wrapped by the test file.
    def find_line_in_script(line):
        # Variable containing the entire script content.
        the_script = None
        # Open the script file.
        script_file = open("my_test_script.ps1","r")
        # Read the script file one line at a time.
        while True:
            line_read = script_file.readline()
            # Test if line read is empty String.
            if not line_read:
                break
            # Add line read to the script content.
            the_script += line_read
        # Close the script file.
        script_file.close()
        #

# Generated at 2022-06-22 20:05:38.788620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():    
    finder = PSModuleDepFinder()
    finder.scan_exec_script("LocalCommand")
    assert finder.exec_scripts['LocalCommand']



# Generated at 2022-06-22 20:05:50.822181
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	psmdf = PSModuleDepFinder()
	psmdf.scan_exec_script("data")
	assert psmdf.exec_scripts["data"] == b"# encoding: ascii\n# This will be deleted by the clean-module-utils playbook\n\n"
	assert psmdf.ps_modules == {}
	assert psmdf.cs_utils_wrapper == {}
	assert psmdf.cs_utils_module == {}
	assert psmdf.ps_version == None
	assert psmdf.os_version == None
	assert psmdf.become == False

# Generated at 2022-06-22 20:06:02.638119
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.powershell.common import PSModuleDepFinder
    from ansible.module_utils.powershell.common import _strip_comments
    import os
    import pkgutil
    def _slurp(path):
        fd = None
        try:
            fd = open(path, 'rb')
            data = fd.read()
        finally:
            if fd is not None:
                fd.close()
        return data
    def _dump(path, data):
        fd = None

# Generated at 2022-06-22 20:06:12.036915
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert not dep_finder.ps_version
    assert not dep_finder.os_version
    assert not dep_finder.become

    for item in dep_finder._re_ps_module:
        assert isinstance(item, re.Pattern)

    for item in dep_finder._re_cs_in_ps_module:
        assert isinstance(item, re.Pattern)

    for item in dep_finder._re_cs_module:
        assert isinstance(item, re.Pattern)


# Generated at 2022-06-22 20:06:20.141384
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    name = "basic"
    mdf.scan_exec_script(name)
    assert len(mdf.exec_scripts) == 1
    assert name in mdf.exec_scripts
    assert mdf.exec_scripts[name] is not None

_re_space = re.compile(b'[\s]+')



# Generated at 2022-06-22 20:06:22.229727
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("basic")


# Generated at 2022-06-22 20:06:33.782349
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # assuming that the module name is given and that we are in the correct directory for the module

    mdf = PSModuleDepFinder()
    # a module that does not have any requires. this should not add anything to the module_utils dict in PSModuleDepFinder
    # should not raise any errors
    mdf.scan_module(b'# this is a module without a requires')

    # a module that has one requires. module_utils should contain the module_util this module requires
    mdf.scan_module(b'#Requires -Module Ansible.ModuleUtils.Other')
    assert mdf.ps_modules["Ansible.ModuleUtils.Other"] is not None

    # multiple requires. module_utils should contain the requires for this module and all requires that required module has

# Generated at 2022-06-22 20:06:44.835047
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder, _strip_comments
    f = PSModuleDepFinder()
    ps_module = to_bytes("""
#AnsibleRequires -OSVersion 7.0
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo
#AnsibleRequires -CSharpUtil ansible_foo_bar_module_utils.CSharpTest
""")

    f.scan_module(ps_module)
    assert f.os_version == '7.0'
    assert 'Ansible.ModuleUtils.Foo' in f.ps_modules
    assert 'ansible_foo_bar_module_utils.CSharpTest' in f.cs_utils_module
    assert f.become == False


# Generated at 2022-06-22 20:06:52.502049
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    name = 'Preexec.ps1'
    dep_finder.scan_exec_script(name)
    assert name in dep_finder.exec_scripts
    assert dep_finder.exec_scripts[name].startswith(b'param($path, $scriptblock, $script, $params')
    


# Generated at 2022-06-22 20:07:02.593817
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert(dep_finder.ps_modules == {})
    assert(dep_finder.cs_utils_wrapper == {})
    assert(dep_finder.cs_utils_module == {})
    assert(dep_finder.exec_scripts == {})
    assert(dep_finder.ps_version is None)
    assert(dep_finder.os_version is None)
    assert(not dep_finder.become)
    assert(dep_finder._re_ps_module != [])
    assert(dep_finder._re_cs_module != [])
    assert(dep_finder._re_cs_in_ps_module != [])
    assert(dep_finder._re_wrapper != None)
    assert(dep_finder._re_ps_version != None)

# Generated at 2022-06-22 20:07:09.891601
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('sudo_wrapper')

    for ps_module in ['PowerShellVersion', 'Ansible.PowerShell.Common', 'Ansible.ModuleUtils.PowerShell.ConvertToJson', 'Ansible.ModuleUtils.PowerShell.ConvertFromJson', 'Ansible.ModuleUtils.PowerShell.Logging', 'Ansible.ModuleUtils.PowerShell.Text']:
        assert ps_module in finder.ps_modules

# Generated at 2022-06-22 20:07:14.852767
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils import basic

    p = PSModuleDepFinder()
    p.scan_exec_script("script.ps1")
    assert p.exec_scripts["script.ps1"]


# Generated at 2022-06-22 20:07:19.447107
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}


# Generated at 2022-06-22 20:07:23.898945
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script()
    # This function is tested by most of the other tests as it is used during
    # the construction of the other tests
    pass

# Generated at 2022-06-22 20:07:35.865065
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module = to_bytes('''
#Requires -Module Ansible.ModuleUtils.Interop
#Requires -Module TestCollection.ModuleUtils.Foo
#Requires -Module TestCollection2.ModuleUtils.Bar
#Requires -Module TestCollection3.ModuleUtils.Baz

function foo() {
    TestCollection.ModuleUtils.Foo.bar()
}

function bar() {
    TestCollection2.ModuleUtils.Bar.baz()
}

function baz() {
    # I like to put spaces around the '.' to ensure it matches.
    TestCollection3 . ModuleUtils . Baz . foo()
}
    ''')


# Generated at 2022-06-22 20:07:40.550006
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("Powershell")
    assert finder.exec_scripts.get("Powershell") is not None

# Generated at 2022-06-22 20:07:50.000497
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}

# Generated at 2022-06-22 20:07:56.500402
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-22 20:08:02.925199
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    tests = [
        {
            "name": "good",
            "module_data": b"# AnsibleRequires -wrapper test_script\n",
            "expected": b"",
        },
        {
            "name": "bad",
            "module_data": b"# AnsibleRequires -wrapper test_script_bad\n",
            "expected": b"Could not find executor powershell script for 'test_script_bad'",
        }
    ]

    def _slurp_mock(function, path):
        if os.path.basename(path) == "test_script.ps1":
            return b"some data"

        return None

    def _import_module_mock(name):
        # pretend we have a package at a path
        module = import_module(name)
        module.__path

# Generated at 2022-06-22 20:08:15.118647
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules = dict()
    dep_finder.cs_utils_wrapper = dict()
    dep_finder.cs_utils_module = dict()

    # Test case 1
    filename = os.path.join(C.DEFAULT_MODULE_PATH[0], 'cloud/azure/azure_rm_deployment.py')
    with open(filename, 'rb') as f:
        dep_finder.scan_module(f.read())
    assert 'Ansible.ModuleUtils.AzureRm' in dep_finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Azure' in dep_finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Common' in dep_finder.ps_modules

# Generated at 2022-06-22 20:08:27.381782
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert type(ps_module_dep_finder.ps_modules) is dict
    assert type(ps_module_dep_finder.exec_scripts) is dict
    assert type(ps_module_dep_finder.cs_utils_wrapper) is dict
    assert type(ps_module_dep_finder.cs_utils_module) is dict
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert type(ps_module_dep_finder._re_cs_module) is list
    assert type(ps_module_dep_finder._re_cs_in_ps_module) is list

# Generated at 2022-06-22 20:08:27.995723
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-22 20:08:40.495931
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.ps_module_dep_finder import PSModuleDepFinder as PSModuleDepFinder_1
    ps1_file_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible.executor.powershell/Library.ps1')
    with open(ps1_file_path, 'w') as f:
        f.write('Write-Host "Hello world"')
    ps_module_dep_finder = PSModuleDepFinder_1()
    ps_module_dep_finder.scan_exec_script('Library')
    assert len(ps_module_dep_finder.exec_scripts) == 1
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module)

# Generated at 2022-06-22 20:08:46.392700
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# unit test for _parse_version_match function

# Generated at 2022-06-22 20:08:58.348214
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ansible_executor_executor_module_loader_module_utils_string_helper_path = os.path.join(os.path.dirname(__file__), '..', 'executor', 'powershell', 'module_utils', 'string_helper.cs')
    ansible_executor_executor_file_helper_path = os.path.join(os.path.dirname(__file__), '..', 'executor', 'powershell', 'file_helper.ps1')
    ansible_executor_executor_executor_helper_path = os.path.join(os.path.dirname(__file__), '..', 'executor', 'powershell', 'executor_helper.ps1')
    ansible_executor_executor_json_helper_path = os.path

# Generated at 2022-06-22 20:09:08.555522
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    module_data = b'\n'.join(
        [
            b'#Requires -Module Ansible.FooUtil',
            b'#Requires -Module Ansible.BarUtil',
            b'#Requires -Module Ansible.BazUtil'
        ]
    )
    depfinder.scan_module(module_data)
    assert 'Ansible.FooUtil' in depfinder.ps_modules
    assert 'Ansible.BarUtil' in depfinder.ps_modules
    assert 'Ansible.BazUtil' in depfinder.ps_modules

# Generated at 2022-06-22 20:09:10.718811
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # create a new PSModuleDepFinder class
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None


# Generated at 2022-06-22 20:09:18.686523
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_result import TaskResultSummary
    from ansible.executor.task_queue_manager import TaskQueueManager
    import pytest

    sc_instance = PSModuleDepFinder()
    # Testing module_data, fqn=None, wrapper=False, powershell=True

    module_data = "module_data"
    assert sc_instance.scan_module(module_data, fqn=None, wrapper=False, powershell=True) == None

   

# Generated at 2022-06-22 20:09:21.675470
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder=PSModuleDepFinder()

    assert isinstance(depfinder.ps_version, type(None))
    assert isinstance(depfinder.os_version, type(None))
    assert isinstance(depfinder.become, bool)
    assert not depfinder.become



# Generated at 2022-06-22 20:09:30.320628
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mock_module_data = pkgutil.get_data("ansible.executor.powershell", "TestModule.ps1")
    mock_module_data = to_bytes(mock_module_data)
    # remove comments to reduce the payload size
    mock_module_data = _strip_comments(mock_module_data)

    test_depfinder = PSModuleDepFinder()
    test_depfinder.scan_module(mock_module_data, wrapper=True, powershell=True)
    # Expecting a reference to ansible_collections.network.fortinet.fortios.plugins.module_utils.network.fortios.fortios

# Generated at 2022-06-22 20:09:40.918615
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:51.968317
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # func is a function defined in this to test the functionalities of PSModuleDepFinder.scan_exec_script
    dependency_finder_obj = PSModuleDepFinder()
    dependency_finder_obj.scan_exec_script('psmodule')
    assert dependency_finder_obj.exec_scripts['psmodule'] is not None
    assert dependency_finder_obj.ps_modules['Ansible.ModuleUtils.Powershell.Tools'] is not None
    # Following assert is to check for additional dependency psmodule has on psmodule_common
    assert dependency_finder_obj.ps_modules['Ansible.ModuleUtils.Powershell.PsModuleCommon'] is not None


# Private helper functions

# Generated at 2022-06-22 20:09:54.995296
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tests the following cases:
    # - Script is not found
    # - Script is found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("non_existing_script")
    except Exception as e:
        assert "Could not find executor powershell script for 'non_existing_script'" in str(e)
    finder.scan_exec_script("Common.ps1")
    # Make sure that the script is correctly stored in the finder
    assert "Common.ps1" in finder.exec_scripts


# Generated at 2022-06-22 20:10:06.939821
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep = PSModuleDepFinder()
    # PS executor scripts have no dependencies
    scripts = [
        'ansible_powershell_common',
        'ansible_powershell_invocation',
        # should be able to handle modules that are a mix of Windows and Linux
        'ansible_posix_common',
        'ansible_posix_invocation',
        # test scripts that don't end in .ps1
        'ansible_posix_find',
    ]

    for name in scripts:
        dep.scan_exec_script(name)

    assert len(dep.ps_modules) == 0
    assert len(dep.cs_utils_wrapper) == 0

    # Make sure we can handle linux executor scripts
    dep.scan_exec_script('ansible_posix_common')

# Generated at 2022-06-22 20:10:17.056775
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    file_name = "exec_module"
    file_data = "data"
    import_module_name = "lib.ansible.executor.powershell"
    import_module_name_ret = "lib.ansible.executor.powershell.ps1"
    # Mocking
    with mock.patch.object(pkgutil, "get_data", return_value=import_module_name_ret):
        # Act
        # Assert
        ps_module_dep_finder = ps_module_dep_finder_cls()
        ps_module_dep_finder.scan_exec_script(file_name)


# Generated at 2022-06-22 20:10:30.010405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible.utils.collection_loader._psmodule_dep_finder import PSModuleDepFinder

    # Test a function in a module_utils of a collection

# Generated at 2022-06-22 20:10:35.190561
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    t = "ansible-doc"
    finder.scan_exec_script(t)
    assert t in finder.exec_scripts
    try:
        t = "ansible-doesnotexist"
        finder.scan_exec_script(t)
    except Exception as e:
        assert t in str(e)


# Generated at 2022-06-22 20:10:44.829272
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def check_scan_exec_script(name):
        """scan_exec_script works"""
        fqn = 'ansible_collections.{namespace}.{collection}.plugins.modules.expect'.format(namespace=namespace, collection=collection)
        module_data = pkgutil.get_data(fqn, to_native(name + ".ps1"))
        assert module_data

        b_data = to_bytes(module_data)
        md = PSModuleDepFinder().scan_exec_script(name)
        if C.DEFAULT_DEBUG:
            assert md.exec_scripts[name] == b_data
        else:
            assert md.exec_scripts[name] == _strip_comments(b_data)

    namespace = 'testns'
    collection = 'testcoll'

# Generated at 2022-06-22 20:10:50.241931
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict

    finder = PSModuleDepFinder()
    # 1st case: ps_module
    name = 'Add-Base64User'
    expected_output = ImmutableDict(dict(
        data=pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1")),
        path=os.path.join(C.DEFAULT_MODULE_PATH[0], 'executor', 'powershell', name + '.psm1')
    ))
    finder.scan_exec_script(name)
    assert(finder.exec_scripts.get(name) == expected_output['data'])

# Generated at 2022-06-22 20:10:55.450601
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder
    assert {} == finder.ps_modules
    assert {} == finder.exec_scripts
    assert {} == finder.cs_utils_wrapper
    assert {} == finder.cs_utils_module
    assert None == finder.ps_version
    assert None == finder.os_version
    assert False == finder.become



# Generated at 2022-06-22 20:11:03.790861
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()

    # test module_data contains '#AnsibleRequires -CSharpUtil ansible_collections.ansible.misc.plugins.module_utils.remote_management.iDRAC.redfish' and
    # it recursively drills into each Requires to see if there are any more
    # requirements

# Generated at 2022-06-22 20:11:12.948432
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        f.scan_exec_script("foo")

    with pytest.raises(AnsibleError):
        f.scan_exec_script("module_utils.basic")

    assert f.scan_exec_script("module_utils.basic.powershell")

    assert "module_utils.basic.powershell" in f.exec_scripts

    assert "module_utils.basic.common" in f.ps_modules



# Generated at 2022-06-22 20:11:22.888918
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader.ps_module_utils_loader import import_module_util_from_source
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    import ansible.executor.powershell
    from ansible.module_utils.common._text import to_bytes, to_text

    # Test scan_module method
    mdf = PSModuleDepFinder()


# Generated at 2022-06-22 20:11:31.693935
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = to_bytes("""\
#Requires -Version 1.0
#Requires -Module Ansible.ModuleUtils.Test
#Requires -Module Ansible.Another.ModuleUtil
#Requires -Module Ansible.YetAnother.ModuleUtil
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.module_util
#AnsibleRequires -CSharpUtil ..module_utils.module_util
""")

    obj = PSModuleDepFinder()
    obj.scan_module(module_data)

    assert len(obj.ps_modules) == 3
    assert len(obj.cs_utils_wrapper) == 0


# Generated at 2022-06-22 20:11:44.793497
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common')
    assert dep_finder.ps_modules == {'Ansible.ModuleUtils.Common':
                                         {'data': 'Stub2', 
                                          'path': ''}}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#AnsibleRequires -CSharpUtil ..module_utils.Common')
   

# Generated at 2022-06-22 20:11:56.771838
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _mock_get_data(package, resource):
        return b'#Requires -Module Ansible.ModuleUtils.Something'

    pkgutil_save = pkgutil.get_data
    pkgutil.get_data = _mock_get_data

    finder = PSModuleDepFinder()
    finder.scan_exec_script('a')

    assert finder.exec_scripts == {'a': b'#Requires -Module Ansible.ModuleUtils.Something'}
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    pkgutil.get_data = pkgutil_save


# Generated at 2022-06-22 20:12:06.998867
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = b"""#Requires -Module Ansible.ModuleUtils.SomeUtil
#Requires -Version 6.0
#AnsibleRequires -PowerShell Ansible.ModuleUtils.CommonUtils
#AnsibleRequires -PowerShell ..module_utils.CommonModuleUtil
#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.CommonCollectionUtil -Optional
#AnsibleRequires -CSharpUtil Ansible.SomeUtil
#AnsibleRequires -Wrapper SomeExecWrapper
"""
    d = PSModuleDepFinder()
    d.scan_module(module_data)

    assert d.ps_version == "6.0.0"
    assert d.ps_modules["Ansible.ModuleUtils.SomeUtil"]

# Generated at 2022-06-22 20:12:17.128978
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.ps_version == None
    assert ps_module_dep_finder.os_version == None
    assert ps_module_dep_finder.become == False

    assert isinstance(ps_module_dep_finder._re_cs_module[0], re._pattern_type)

    assert len(ps_module_dep_finder._re_cs_module[0].groupindex) == 4
    assert ps_module_dep_finder._re_cs_

# Generated at 2022-06-22 20:12:17.776900
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:12:26.128838
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps_dep_finder = PSModuleDepFinder()
    data = pkgutil.get_data('ansible_collections.ansible.builtin.plugins.modules.log_plays', to_native('win_eventlog.psm1'))
    if data is None:
        raise AnsibleError("Could not find win_eventlog.psm1")

    b_data = to_bytes(data)
    ps_dep_finder.scan_module(b_data)
    assert ps_dep_finder.ps_version == '1.0'
    assert len(ps_dep_finder.ps_modules) == 15

# Generated at 2022-06-22 20:12:34.742978
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('Pipeline')
    assert finder.exec_scripts is not None and finder.exec_scripts['Pipeline'] is not None
    assert finder.cs_utils_wrapper is not None
    assert finder.ps_modules is not None
    assert finder.cs_utils_module is not None
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-22 20:12:37.740345
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print('Testing scan_module of class PSModuleDepFinder')

    instance = PSModuleDepFinder()
    instance.scan_module('')
    assert isinstance(instance, PSModuleDepFinder)


# Generated at 2022-06-22 20:12:51.090199
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()

    # Test for successful completion of function when module_data is not defined
    # GIVEN:
    test_obj.scan_module = MagicMock(return_value=None)
    test_obj.exec_scripts = {u"pswrap_exec": b"", u"pswrap_async": b""}
    test_name = "pswrap_exec"

    # WHEN:
    result = test_obj.scan_exec_script(test_name)

    # THEN:
    test_obj.scan_module.assert_called_with(b"", wrapper=True, powershell=True)
    assert result is None
    assert test_obj.exec_scripts[to_text(test_name)] == b""



# Generated at 2022-06-22 20:12:56.127729
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    parser = PSModuleDepFinder()
    # Test default input
    data = to_bytes("#Requires -Module Ansible.ModuleUtils.PathUtils\n#Requires -Module Ansible.ModuleUtils.BasicUtils")
    parser.scan_module(data)
    assert len(parser.ps_modules) == 2
    assert len(parser.cs_utils_wrapper) == 0
    assert len(parser.cs_utils_module) == 0
    assert len(parser.exec_scripts) == 0

    # Test builtin utils with -Optional

# Generated at 2022-06-22 20:12:57.269483
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-22 20:13:08.829604
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:19.335145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    mu = PSModuleDepFinder()
    mu.scan_exec_script(to_text("powershell_version_check"))

# Generated at 2022-06-22 20:13:22.856279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    executor_script_name = 'basic'
    instance = PSModuleDepFinder()
    instance.scan_exec_script(executor_script_name)
    assert executor_script_name in instance.exec_scripts


# Generated at 2022-06-22 20:13:35.347586
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_util_path = os.path.dirname(__file__)

    module_data1 = to_bytes(_slurp(os.path.join(C.DEFAULT_MODULE_PATH,
                                               "cloud/azure/azure_rm_networkinterface.psm1")))
    module_data2 = to_bytes(_slurp(os.path.join(C.DEFAULT_MODULE_PATH,
                                               "cloud/azure/azure_rm_networkinterface_facts.psm1")))
    module_data3 = to_bytes(_slurp(os.path.join(C.DEFAULT_MODULE_PATH,
                                               "windows/win_command.psm1")))

# Generated at 2022-06-22 20:13:42.280671
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Tests for scan_exec_script method of class PSModuleDepFinder
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(name='win_package')
    assert dep_finder.exec_scripts.__len__() > 0


# unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:13:50.518256
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p = PSModuleDepFinder()
    import ansible.executor.ps_module_utils as ps_module_utils
    ps_module_utils_dir = os.path.dirname(ps_module_utils.__file__)
    test_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')
    test_data_dir = os.path.abspath(test_data_dir)
    assert to_native(test_data_dir).endswith('test/unit/plugins/modules/test_data')
    for f in os.listdir(test_data_dir):
        if not f.endswith('.psm1'):
            continue
        m = os.path.join(test_data_dir, f)



# Generated at 2022-06-22 20:13:57.691435
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup function arguments
    name = "../test_data/test_data_PSModuleDepFinder/data"

    # setup test class object
    ps_Module_Dep_Finder = PSModuleDepFinder()

    # run function
    ps_Module_Dep_Finder.scan_exec_script(name)

    # setup expected output
    # expect_output = {}

    # assert result
    # assert ps_Module_Dep_Finder.exec_scripts == expect_output, "Expect output is {}".format(expect_output)



# Generated at 2022-06-22 20:14:08.178642
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder_scan_exec_script_asserts = [
        (
            'Test-ModuleManifest',
            {
                'data': "data",
                'path': 'path',
            }
        ),
    ]

    psmdf = PSModuleDepFinder()
    psmdf.scan_module = lambda x: None
    psmdf.exec_scripts = {}
    for test_args, expected in test_PSModuleDepFinder_scan_exec_script_asserts:
        psmdf.scan_exec_script(test_args)
        actual = psmdf.exec_scripts.get(test_args)
        assert actual == expected, "Actual = " + to_native(json.dumps(actual))


# Generated at 2022-06-22 20:14:09.742952
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: implement unit test for method scan_module of class PSModuleDepFinder
    pass


# Generated at 2022-06-22 20:14:12.934814
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    test_name = 'test_name'
    obj.scan_exec_script(test_name)
    expected_exec_scripts = {'test_name': obj.exec_scripts['test_name']}
    assert obj.exec_scripts == expected_exec_scripts



# Generated at 2022-06-22 20:14:24.017174
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''Test scan_module of PSModuleDepFinder'''
    import tempfile
    import shutil

    ps_file = os.path.join(os.path.dirname(os.path.realpath(__file__)),"..","..","lib","ansible","module_utils","powershell","win_package.psm1")

    # test scan_module with a multi-line data
    data_multi = '''
#
#
#Requires -Module Ansible.ModuleUtils.Common.Logging
#
#
#Requires -Module Ansible.ModuleUtils.Common.Process
#
'''
    data_multi = _strip_comments(data_multi)
    data_multi = _strip_blank_lines(data_multi)

    pdmf = PSModuleDepFinder()

# Generated at 2022-06-22 20:14:27.740373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup test data
    name = "test"
    # Execute the code to be tested
    actual = PSModuleDepFinder.scan_exec_script(name)


# Generated at 2022-06-22 20:14:38.373642
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    assert isinstance(dep_finder._re_cs_module, list)
    assert isinstance(dep_finder._re_ps_module, list)
    assert isinstance(dep_finder._re_wrapper, re._pattern_type)
    assert isinstance(dep_finder._re_ps_version, re._pattern_type)
    assert isinstance(dep_finder._re_os_version, re._pattern_type)