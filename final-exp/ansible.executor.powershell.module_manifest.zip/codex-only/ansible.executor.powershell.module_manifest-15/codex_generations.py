

# Generated at 2022-06-22 20:04:39.453190
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

# Unit tests for PSModuleDepFinder._add_module() which is a private method
# This method is tested indirectly by other methods in the class

# Unit tests for PSModuleDepFinder._parse_version_match() which is a private method
# This method is tested indirectly by other methods in the class


# Generated at 2022-06-22 20:04:50.504430
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def get_fqn():
        return 'ansible.builtin.ping'
    # Get overrides
    save_ansible_module_utils = C.DEFAULT_MODULE_UTILS_PATH
    save_ansible_powershell_utils = C.DEFAULT_POWERSHELL_UTILS_PATH
    save_ansible_powershell_modules = C.DEFAULT_POWERSHELL_MODULES_PATH

# Generated at 2022-06-22 20:04:53.847452
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    try:
        PSModuleDepFinder()
    except Exception:
        assert False, "Object creation for class PSModuleDepFinder failed."
    assert True



# Generated at 2022-06-22 20:05:00.949836
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('connection_winrm')
    assert finder.exec_scripts['connection_winrm']
    # Test that a non existing script is not raising an explicit error but an AnsibleError
    try:
        finder.scan_exec_script('non_existing_script')
    except AnsibleError:
        pass
    else:
        assert False


# Generated at 2022-06-22 20:05:09.983357
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module = PSModuleDepFinder()
    cSharpModule = PSModuleDepFinder()

    ps_module.scan_module(to_bytes("# requires -module Ansible.ModuleUtils.CodeCoverage"))

    ps_module.scan_module(to_bytes("# ansiblerequires -powershell ansible_collections.ansible.builtin.plugins.module_utils.common.validation"))

    cSharpModule.scan_module(to_bytes("using ansible_collections.ansible.builtin.plugins.module_utils.common.validation;"), ext=".cs", powershell=False)


# Generated at 2022-06-22 20:05:21.761882
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:05:35.342275
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()

    # _re_ps_module
    assert len(mdf._re_ps_module) == 2
    assert isinstance(mdf._re_ps_module[0], type(re.compile('')))
    assert isinstance(mdf._re_ps_module[1], type(re.compile('')))

    # _re_cs_in_ps_module
    assert len(mdf._re_cs_in_ps_module) == 1
    assert isinstance(mdf._re_cs_in_ps_module[0], type(re.compile('')))

    # _re_cs_module
    assert len(mdf._re_cs_module) == 1

# Generated at 2022-06-22 20:05:48.338847
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)
    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.exec_scripts, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert isinstance(finder._re_cs_module[0], type(re.compile("")))
    assert isinstance(finder._re_cs_in_ps_module[0], type(re.compile("")))
    assert isinstance(finder._re_ps_module[0], type(re.compile("")))

# Generated at 2022-06-22 20:05:57.743777
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected_result = {}
    expected_result['ansible_module_wrapper'] = to_bytes(b'function ansible_module_wrapper {throw "DO NOT CALL THIS FUNCTION"}')
    expected_result['ansible_module_wrapper_ansible_powershell_core'] = to_bytes(b'function ansible_module_wrapper {throw "DO NOT CALL THIS FUNCTION"}')
    expected_result['ansible_module_wrapper_ansible_powershell_gather_info'] = to_bytes(b'function ansible_module_wrapper {throw "DO NOT CALL THIS FUNCTION"}')
    expected_result['ansible_module_wrapper_ansible_powershell_json'] = to_bytes(b'function ansible_module_wrapper {throw "DO NOT CALL THIS FUNCTION"}')

# Generated at 2022-06-22 20:06:08.940843
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    from unittest.mock import patch

    # Simulate module_data does not exist
    def mock_read_module_data(module_name):
        return None

    # Simulate pkgutil.get_data does not find the script
    def mock_pkgutil_get_data(package, script):
        return None

    ps_module_dep_finder = PSModuleDepFinder()

    # test case 1, neither module_data nor pkgutil.get_data finds the script

# Generated at 2022-06-22 20:06:19.233162
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_obj = PSModuleDepFinder()

    assert isinstance(test_obj.cs_utils_module, dict)
    assert len(test_obj.cs_utils_module.keys()) == 0
    assert isinstance(test_obj.cs_utils_wrapper, dict)
    assert len(test_obj.cs_utils_wrapper.keys()) == 0
    assert isinstance(test_obj.ps_modules, dict)
    assert len(test_obj.ps_modules.keys()) == 0
    assert isinstance(test_obj.exec_scripts, dict)
    assert len(test_obj.exec_scripts.keys()) == 0
    assert test_obj.ps_version is None
    assert test_obj.os_version is None
    assert test_obj.become is False


# Generated at 2022-06-22 20:06:29.799419
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Create an instance of PSModuleDepFinder class
    psmoduledepfinder = PSModuleDepFinder()
    test_files_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'PSModuleDepFinder')
    test_module_data_tmp_file = tempfile.NamedTemporaryFile(delete=False, dir=test_files_path)
    test_module_data_tmp_file.write(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.ModuleUtilsTest')
    test_module_data_tmp_file.close()
    test_module_data = open(test_module_data_tmp_file.name, 'rb').read()

    # Test scan_module with when '#Requires -Module Ansible.ModuleUt

# Generated at 2022-06-22 20:06:42.586166
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    # Ensure _re_cs_module is always the first entry in _re_ps_module
    assert obj._re_cs_module == obj._re_ps_module[:1]

    # we are just checking that these are there. The actual behavior is tested
    # in the test_base.py test_module_utils
    obj.scan_module(b'#Requires -Module Ansible.ModuleUtils.Legacy')
    assert obj.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Legacy' in obj.ps_modules

    obj.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test')
    assert obj.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Test' in obj.ps_modules


# Generated at 2022-06-22 20:06:53.407946
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = """#Requires -Module Ansible.ModuleUtils.Test
#Requires -Module Ansible.ModuleUtils.Test
#Requires -Module Ansibl.ModuleUtils.Test
#Requires -Module Ansibl.ModuleUtils.Test
#AnsibleRequires -Wrapper Test"""
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.exec_scripts) == 0


# Generated at 2022-06-22 20:07:04.267142
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    test_data = [
        {"name": "", "expected": "Could not find executor powershell script for ''"},
        {"name": "name", "expected_keys": ["name"]}
    ]

    for test in test_data:
        finder = PSModuleDepFinder()
        try:
            result = finder.scan_exec_script(test["name"])
            if "expected" in test:
                assert False, "AnsibleError expected for the test case {}".format(test)
            if "expected_keys" in test:
                for key in test["expected_keys"]:
                    assert key in finder.exec_scripts
        except AnsibleError as e:
            assert test["expected"] == str(e)


# Generated at 2022-06-22 20:07:13.534406
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    args_1 = 'name'
    expected_1 = None

    def get_pkg_data_1(package_name_1, resource_name_1):
        return b'#! python\n# -*- coding: utf-8 -*-'
    pkgutil_get_data_1 = pkgutil.get_data
    pkgutil.get_data = get_pkg_data_1

    def get_pkg_data_2(package_name_2, resource_name_2):
        if package_name_2 == 'ansible.executor.powershell' and resource_name_2 == 'name.ps1':
            return b'a'
    pkgutil_get_data_2 = pkgutil.get_data
    pkgutil.get_data = get_pkg_data_2


# Generated at 2022-06-22 20:07:22.710263
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    The method scan_module is used by ps_wrapper and ps_resource_cmd to obtain a list of modules,
    powershell scripts, and C# utils needed to load a given module.

    Returns:
        dict:
            ps_modules (dict): a map of powershell module_utils keyed by their
                fully qualified name (FQN)
            cs_utils_wrapper (dict): a map of C# module_utils keyed by their
                FQN
            cs_utils_module (dict): a map of C# module_utils keyed by their
                FQN
            exec_scripts (dict): a map of powershell scripts keyed by their
                name

    """
    # Build a basic barebones module

# Generated at 2022-06-22 20:07:35.001414
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:07:47.516477
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    class AnsibleModule(object):
        def __init__(self):
            self.params = {
                'terms': []
            }

            self._ansible_facts = {
                'ansible_version': {
                    'full': '2.9.11'
                }
            }
            return

        def fail_json(self, msg="ERROR"):
            raise Exception(msg)

    ps_deps = PSModuleDepFinder()

    ps_script = pkgutil.get_data("ansible.module_utils.powershell", "basic.psm1")
    ps_deps.scan_module(ps_script)
    assert 'Ansible.ModuleUtils.Powershell' in ps_deps.ps_modules

    module = AnsibleModule()
    cs_script = pkgutil.get_data

# Generated at 2022-06-22 20:07:48.234175
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  pass

# Generated at 2022-06-22 20:07:58.753954
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def _strip_comments(data):
        lines = data.split(b'\n')
        for line in lines:
            if line.strip().startswith(b'#'):
                lines.remove(line)
        return b'\n'.join(lines)
    _strip_comments.stypy_localization = u"C:\\Users\\Angela\\AppData\\Local\\Continuum\\Anaconda2\\envs\\py37\\lib\\site-packages\\ansible\\plugins\\loader.py"
    _strip_comments.stypy_type_of_self = None
    _strip_comments.stypy_type_store = module_type_store
    _strip_comments.stypy_function_name = u'_strip_comments'

# Generated at 2022-06-22 20:08:01.026343
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test_exec_script')
    assert len(finder.ps_modules.keys()) == 1
    assert 'Ansible.ModuleUtils.Test' in finder.ps_modules
    assert len(finder.cs_utils_wrapper.keys()) == 1
    assert 'Ansible.Test' in finder.cs_utils_wrapper



# Generated at 2022-06-22 20:08:13.572485
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False


# Generated at 2022-06-22 20:08:20.002231
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf._re_cs_module
    assert pmdf._re_cs_in_ps_module
    assert pmdf._re_ps_module
    assert pmdf._re_wrapper
    assert pmdf._re_ps_version
    assert pmdf._re_os_version
    assert pmdf._re_become
    assert pmdf.ps_modules == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.cs_utils_module == {}



# Generated at 2022-06-22 20:08:21.172021
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True == True



# Generated at 2022-06-22 20:08:33.014265
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:35.109614
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # FIXME: Add unit tests
    pass

# Generated at 2022-06-22 20:08:35.886975
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-22 20:08:44.306093
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the method scan_exec_script of class PSModuleDepFinder
    # We aren't testing the contents of the files, that is tested in each modules test file.
    # We just test to make sure we can get the file and that it parses correctly.

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('win_acl')
    assert dep_finder.exec_scripts['win_acl']
    assert 'win_acl.cs' in dep_finder.cs_utils_wrapper
    assert 'win_acl.psm1' in dep_finder.ps_modules

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('win_chocolatey')
    assert dep_finder.exec_scripts['win_chocolatey']

# Generated at 2022-06-22 20:08:46.915932
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Check that calls to scan_module work without issue
    md = PSModuleDepFinder()
    md.scan_module("This is a test string")


# Generated at 2022-06-22 20:08:56.144100
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = to_bytes(r"""
#Requires -Module Ansible.ModuleUtils.Basic
#Requires -Module Ansible.ModuleUtils.Powershell
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Powershell
#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.my_util
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.my_csharp_util
#AnsibleRequires -Wrapper foo
#Requires -Version 6.0.0
#AnsibleRequires -OSVersion 10.0.0
#AnsibleRequires -Become
""")

# Generated at 2022-06-22 20:08:59.326208
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    PSModuleDepFinder_scan_module_instance = PSModuleDepFinder()
    module_data = "Test"
    fqn = "Test1"
    wrapper = False
    powershell = True
    assert PSModuleDepFinder_scan_module_instance.scan_module(module_data, fqn, wrapper, powershell) == None


# Generated at 2022-06-22 20:09:11.999266
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    # Make sure getter and setter for ps_version and os_version work as expected
    finder.ps_version = "2.0.0.0"
    assert finder.ps_version == "2.0.0.0"
    finder.os_version = "6.3"
    assert finder.os_version == "6.3"


# Generated at 2022-06-22 20:09:13.645400
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()



# Generated at 2022-06-22 20:09:15.300989
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), object)



# Generated at 2022-06-22 20:09:27.254855
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible_collections

    data_config_file = "ansible_collections/ansible/os_windows/plugins/modules/win_command.json"
    test_PSModuleDepFinder_scan_exec_script.data = pkgutil.get_data("ansible_collections.ansible.os_windows", data_config_file)
    data = json.loads(to_text(test_PSModuleDepFinder_scan_exec_script.data))

    module = data['module']
    fqn = data['namespace'] + "." + data['collection'] + ".plugins.modules." + module

    found_type = None


# Generated at 2022-06-22 20:09:34.683294
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # Test making a new instance of PSModuleDepFinder
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False

# Unit tests for scan_module method of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:39.198678
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p.ps_modules == dict()
    assert p.cs_utils_wrapper == dict()
    assert p.cs_utils_module == dict()
    assert p.become == False


# Get C# module name from the content of PowerShell module

# Generated at 2022-06-22 20:09:45.641270
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for a random filename, should fail
    name = str(random.randint(100000, 1000000))
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script(name)
        assert False, "PSModuleDepFinder.scan_exec_script did not raise exception on unknown script"
    except AssertionError as e:
        raise
    except AnsibleError:
        pass
    except Exception as e:
        raise AssertionError("PSModuleDepFinder.scan_exec_script unexpected exception '%s'" % e)

    # Test for known script, should succeed
    name = 'basic_module'
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script(name)
    except Exception as e:
        raise AssertionError

# Generated at 2022-06-22 20:09:48.779875
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # This test only tests for checking the instance creation of PSModuleDepFinder
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.cs_utils_module == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.exec_scripts == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False



# Generated at 2022-06-22 20:10:01.065164
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:13.520569
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    assert isinstance(psmdf, PSModuleDepFinder)
    assert isinstance(psmdf.ps_modules, dict)
    assert isinstance(psmdf.exec_scripts, dict)
    assert isinstance(psmdf.cs_utils_wrapper, dict)
    assert isinstance(psmdf.cs_utils_module, dict)
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False
    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_cs_in_ps_module, list)
    assert isinstance(psmdf._re_ps_module, list)

# Generated at 2022-06-22 20:10:23.215822
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # Test a normal module and make sure the extension is .psm1.
    expected_ps_modules = {
        'Ansible.ModuleUtils.Foo': {
            'data': b'Fake module util data\n',
            'path': '/ansible/lib/ansible/module_utils/foo.psm1',
        },
    }
    expected_cs_utils_module = {}
    expected_cs_utils_wrapper = {}
    expected_exec_scripts = {}
    expected_ps_version = None
    expected_os_version = None
    expected_become = False

    input_module_data = b'''
        #Requires -Module Ansible.ModuleUtils.Foo

        # Some Comment
        Import-Module Foo
    '''

    dep_finder = PSModuleDepFinder()
    dep_

# Generated at 2022-06-22 20:10:25.348172
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()


# Generated at 2022-06-22 20:10:29.957277
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup test
    finder = PSModuleDepFinder()

    # Execute method
    name = "exec_wrapper_script_here"
    finder.scan_exec_script(name)

    # Verify results
    assert name in finder.exec_scripts.keys()

# Generated at 2022-06-22 20:10:33.201775
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    tc = PSModuleDepFinder()
    tc.scan_exec_script('exec-wrapper')
    assert 'powershell' in tc.exec_scripts.keys()


# Generated at 2022-06-22 20:10:40.118589
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Test method scan_exec_script of class PSModuleDepFinder
    :return:
    '''
    name = "Test_PSModuleDepFinder_scan_exec_script"
    script = "powershell -Command \"& { Write-Output 'Hello' }\"\n"
    mdep = PSModuleDepFinder()
    try:
        mdep.scan_exec_script(name)
    except:
        pass
    else:
        assert False, "Failed to raise error when testing scan_exec_script"
    with open("./module_utils/TestModule.ps1", "w") as f:
        f.write(script)
    mdep.scan_exec_script(name)
    assert name in mdep.exec_scripts.keys(), "Failed to add script to exec_scripts"



# Generated at 2022-06-22 20:10:41.813573
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    pass


# Generated at 2022-06-22 20:10:43.140839
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:10:49.428736
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder
    PD = PSModuleDepFinder()
    assert PD._re_cs_in_ps_module
    assert PD._re_cs_module
    assert PD._re_ps_module
    assert PD._re_ps_version
    assert PD._re_os_version
    assert PD._re_wrapper
    assert PD.cs_utils_wrapper
    assert PD.cs_utils_module
    assert PD.ps_modules
    assert PD.exec_scripts


# Generated at 2022-06-22 20:10:59.012682
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = """#Requires -Module Ansible.ModuleUtils.something
#AnsibleRequires -PowerShell Ansible.ModuleUtils.something
#Requires -Module Ansible.ModuleUtils.module_common
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.something
import module_util
using namespace.collection.plugins.module_utils.something;
"""
    finder.scan_module(to_bytes(module_data))

# Generated at 2022-06-22 20:11:01.883702
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_exec_script = import_module('unit_tests.powershell.test_module_utils.test_exec_script')
    assert test_exec_script.PSModuleDepFinder_scan_exec_script(PSModuleDepFinder)



# Generated at 2022-06-22 20:11:14.932610
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()
    assert len(module_dep_finder.ps_modules) == 0
    assert len(module_dep_finder.exec_scripts) == 0
    assert len(module_dep_finder.cs_utils_wrapper) == 0
    assert len(module_dep_finder.cs_utils_module) == 0
    assert module_dep_finder.ps_version is None
    assert module_dep_finder.os_version is None
    assert not module_dep_finder.become

    assert len(module_dep_finder._re_cs_module) == 1
    assert len(module_dep_finder._re_cs_in_ps_module) == 1
    assert len(module_dep_finder._re_ps_module) == 2

# Generated at 2022-06-22 20:11:22.906739
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_data = {
        "module_data": b'',
        "expected_ps_modules": {},
        "expected_module_utils": {},
        "expected_cs_utils_wrapper": {},
        "expected_cs_utils_module": {},
        "expected_exec_scripts": {}
    }
    test_data1 = {
        "module_data": b'#Requires -Module Ansible.ModuleUtils.Test',
        "expected_ps_modules": {},
        "expected_module_utils": {},
        "expected_cs_utils_wrapper": {},
        "expected_cs_utils_module": {},
        "expected_exec_scripts": {}
    }

# Generated at 2022-06-22 20:11:23.629634
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-22 20:11:34.485196
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    b64_cs_util = base64.b64encode(b'using System;\r\n').decode()
    b64_cs_util_new_line = base64.b64encode(b'using System;\n').decode()
    b64_cs_util_ansible = base64.b64encode(b'using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};\r\n').decode()

    b64_ps_util = base64.b64encode(b'#Requires -Module Ansible.ModuleUtils.{name}\r\n').decode()

# Generated at 2022-06-22 20:11:45.917277
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dm = PSModuleDepFinder()

    assert set(dm._re_cs_module) == set([re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                      r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))])


# Generated at 2022-06-22 20:11:51.999881
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-22 20:12:03.560113
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import unittest
    import sys

    sys.path.insert(1, '..')

    class AnsibleCollectionLoaderMock(object):
        def get_collection_fqns(self):
            return 'ansible_collections/foo/bar'
    class AnsibleOptionsMock(object):
        def __init__(self):
            self.tree = '.'
            self.config = None
    class AnsibleCollectionFinderMock(object):
        def __init__(self):
            self.module_utils = dict()
            self.exec_scripts = dict()
            self.module_utils['ansible_collections.foo.bar.plugins.module_utils.blah'] = 'blah'
            self.module_utils['Ansible.ModuleUtils.foo'] = 'foo'
            self.exec_scripts

# Generated at 2022-06-22 20:12:09.218658
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()


# Generated at 2022-06-22 20:12:20.431816
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for case when ps_modules
    module_data = b'#Requires -Module Ansible.ModuleUtils.Legacy;'
    finder = PSModuleDepFinder()

    finder.scan_module(module_data)
    assert finder.ps_modules['Ansible.ModuleUtils.Legacy']['data'] == b' '

    # Test for case when cs_utils_module
    module_data = b'using ansible_collections.ns.coll.plugins.module_utils.other;'
    finder = PSModuleDepFinder()

    finder.scan_module(module_data)
    assert finder.cs_utils_module['ansible_collections.ns.coll.plugins.module_utils.other']['data'] == b' '

    # Test for case when cs_utils_wrapper

# Generated at 2022-06-22 20:12:32.233154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Creating an object of type PSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()
    # Creating a ps_module_utils dictionary to store ps module utils
    ps_module_util = {}
    # Create a random string of about 30 digits
    random_string = str(random.randint(100000, 1000000000))
    # Create an ansible.module_utils.powershell.common.psDictType object
    ps_dict_object = ansible.module_utils.powershell.common.psDictType(PsDict=ps_module_util)
    # Create an ansible.module_utils.powershell.common.psParamsType object
    ps_params_object = ansible.module_utils.powershell.common.psParamsType(PsData=ps_dict_object)
   

# Generated at 2022-06-22 20:12:45.241912
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:50.606383
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Given
    psmdf = PSModuleDepFinder()

    # When
    name = random.choice([
        'a',
        'b',
        'c',
    ])

    # Then
    assert name in ['a', 'b', 'c']


# Generated at 2022-06-22 20:13:02.207959
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    module_data = to_bytes(textwrap.dedent("""
    #Requires -Module Ansible.ModuleUtils.KeyVault.KeyVault
    #Requires -Module Ansible.ModuleUtils.Network.Network
    #Requires -Module Ansible.ModuleUtils.Network.SCCM
    #Requires -Module Ansible.ModuleUtils.Powershell.Helper
    """))

    expected_dependencies = {
        'Ansible.ModuleUtils.KeyVault.KeyVault',
        'Ansible.ModuleUtils.Network.Network',
        'Ansible.ModuleUtils.Network.SCCM',
        'Ansible.ModuleUtils.Powershell.Helper'
    }

    finder.scan_module(module_data)

    assert expected

# Generated at 2022-06-22 20:13:03.368702
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False


# Generated at 2022-06-22 20:13:04.457655
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass



# Generated at 2022-06-22 20:13:15.670067
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#Requires -Module Ansible.ModuleUtils.FakeUtil1')
    assert psmdf.ps_modules == {'Ansible.ModuleUtils.FakeUtil1': {'data': b'Test data', 'path': b'/fake/path'}}
    psmdf.scan_module(b'#AnsibleRequires -Powershell Ansible.ModuleUtils.FakeUtil2')
    assert psmdf.ps_modules == {'Ansible.ModuleUtils.FakeUtil1': {'data': b'Test data', 'path': b'/fake/path'}, 'Ansible.ModuleUtils.FakeUtil2': {'data': b'Test data', 'path': b'/fake/path'}}
    psm

# Generated at 2022-06-22 20:13:22.580433
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False

# Helper function to remove comments from powershell file.
# Comments in powershell start with the # char.  This function creates a list
# of lines, and then removes any lines that start with the #.

# Generated at 2022-06-22 20:13:26.075505
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-22 20:13:33.952798
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Test1\n#Requires -Module Ansible.ModuleUtils.Test2')

    assert b'#Requires -Module Ansible.ModuleUtils.Test1' in dep_finder.ps_modules.keys()
    assert b'#Requires -Module Ansible.ModuleUtils.Test2' in dep_finder.ps_modules.keys()

# Generated at 2022-06-22 20:13:37.357315
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmod_dep_finder = PSModuleDepFinder()
    assert psmod_dep_finder.ps_modules == dict()
    assert psmod_dep_finder.exec_scripts == dict()
    assert psmod_dep_finder.cs_utils_wrapper == dict()
    assert psmod_dep_finder.cs_utils_module == dict()
    assert psmod_dep_finder.ps_version is None
    assert psmod_dep_finder.os_version is None
    assert psmod_dep_finder.become is False


# Generated at 2022-06-22 20:13:38.313305
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-22 20:13:48.410767
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import tempfile

    # test_PSModuleDepFinder_scan_exec_script()
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = to_text(tmpdir)
        input_script = u'#Requires -version 5.1\n#this is an exec script\n$test=1'
        input_module = u'#Requires -Module Ansible.ModuleUtils.Powershell.Core\n#this is a module'

        script_name = os.path.join(tmpdir, u'test_script.ps1')
        with open(script_name, 'w') as f:
            f.write(input_script)
        module_name = os.path.join(tmpdir, u'test_module.psm1')

# Generated at 2022-06-22 20:13:58.219716
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.utils.collection_loader import _collection_folder_name
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common.text_transform import to_bytes, to_text
    from ansible.module_utils._text import to_bytes, to_text

    collection_name = 'azure'
    collection_version = '0.7.0'
    collection_fqn = "%s.%s" % (collection_name, collection_version)
    collection_folder_name = _collection_folder_name(collection_fqn)
    collection_basepath = 'collections/%s' % collection_folder_name
    collection_path = os.path.join(os.getcwd(), 'lib/ansible', collection_basepath)

# Generated at 2022-06-22 20:14:08.672210
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()

    # simple example module
    source_module_data = to_bytes('#Requires -Module Ansible.ModuleUtils.Common.psm1')
    depFinder.scan_module(source_module_data)
    assert len(depFinder.ps_modules) == 1
    assert 'Ansible.ModuleUtils.Common' in depFinder.ps_modules.keys()

    # example module with a dependency on a module in another collection
    source_module_data = to_bytes('#Requires -Module Ansible.ModuleUtils.Common.psm1\n'
                                  '#AnsibleRequires -PowerShell ansible_collections.notdefault.test.plugins.module_utils.test_module.psm1')

# Generated at 2022-06-22 20:14:14.673072
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test method scan_exec_script of class PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("win_acls")
    assert "win_acls" in psmdf.exec_scripts
    assert "copy" in psmdf.ps_modules


# Generated at 2022-06-22 20:14:25.075345
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import_mock = mock.Mock(
        return_value='',
        side_effect=mock.Mock(
            __path__=["path"]
        )
    )

    get_data_mock = mock.Mock(return_value="data")

    def side_effect(*args):
        if args[0] == "invalid":
            raise ImportError()
        return import_mock(*args)

    finder = PSModuleDepFinder()


# Generated at 2022-06-22 20:14:29.870500
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    moduleDepFinder = PSModuleDepFinder()
    moduleDepFinder.scan_exec_script('auth.windows')
    assert moduleDepFinder.exec_scripts.get('auth.windows') is not None


# Generated at 2022-06-22 20:14:39.377623
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell.powerShell import PsModuleFinder

    ps_module_data = _slurp(os.path.join(C.DEFAULT_LOCAL_TMP, 'test_PSModuleDepFinder', 'win_example.psm1'))
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(ps_module_data)

    # verify that modules were added