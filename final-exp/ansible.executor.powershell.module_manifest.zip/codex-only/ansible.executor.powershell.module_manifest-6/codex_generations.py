

# Generated at 2022-06-22 20:04:37.567715
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert re.match(r'PSModuleDepFinder\(\)', str(ps_dep_finder)) is not None

# Unit tests for _add_module() method of class PSModuleDepFinder

# Generated at 2022-06-22 20:04:38.808255
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()
    assert isinstance(psModuleDepFinder, PSModuleDepFinder)

# Test the GenerateFileName method of the wrapper

# Generated at 2022-06-22 20:04:50.220730
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import os
    import shutil

    # create a temporary directory to write our test files to
    tmpdir = tempfile.mkdtemp()

    # use a try/finally block to make sure we clean up the tmpdir

# Generated at 2022-06-22 20:04:51.751696
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()



# Generated at 2022-06-22 20:05:02.131413
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class AnsibleModuleUT(object):
        params = {'_ansible_verbosity': 2}
        _ansible_version = '2.10.0'

    class ModuleDepFinderUT(PSModuleDepFinder):
        def __init__(self):
            # We can construct this instance of PSModuleDepFinder because it does not depend on any other classes
            PSModuleDepFinder.__init__(self)

# Generated at 2022-06-22 20:05:12.675622
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Powershell module with no dependencies
    module = [
        "# POWERSHELL_COMMON",
        "Write-Host \"Hello world\"",
    ]
    finder.scan_module("\n".join(module))
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_module) == 0
    # Powershell module with builtin dependency
    module = [
        "# POWERSHELL_COMMON",
        "#Requires -Module Ansible.ModuleUtils.Legacy",
        "Write-Host \"Hello world\"",
    ]
    finder.scan_module("\n".join(module))
    assert len(finder.ps_modules) == 1
    assert len(finder.cs_utils_module) == 0
    # Powershell module

# Generated at 2022-06-22 20:05:16.135037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_module('#AnsibleRequires -CSharpUtil ansible.module_utils.common.ansible_module_common')
    assert finder.cs_utils_wrapper['ansible.module_utils.common.ansible_module_common']



# Generated at 2022-06-22 20:05:24.138078
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.ssh_utils import split_args

    md = PSModuleDepFinder()
    md.scan_module(b"#Requires -Module Ansible.ModuleUtils.Util1\r\n#Requires -Module Ansible.ModuleUtils.Util2")
    assert len(md.ps_modules) == 2

    md = PSModuleDepFinder()
    md.scan_module(b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.Util1\r\n#AnsibleRequires -PowerShell Ansible.ModuleUtils.Util2")
    assert len(md.ps_modules) == 2

    md = PSModuleDepFinder()

# Generated at 2022-06-22 20:05:31.017069
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    caller = PSModuleDepFinder()
    module_data = b'\n'.join([
        b"#Requires -CSharpShell",
        b"#AnsibleRequires -Wrapper Net35",
        b""
    ])
    caller.scan_module(module_data, wrapper=True, powershell=False)
    assert 'Net35' in caller.exec_scripts


# Generated at 2022-06-22 20:05:40.417049
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()
    assert module_finder._re_cs_module[0].match(b"using ansible_collections.some.collection.plugins.module_utils.some_util;")
    assert module_finder._re_cs_module[0].match(b"using Ansible.SomeUtil;")
    assert not module_finder._re_cs_module[0].match(b"using Ansible.SomeUtil")
    assert not module_finder._re_cs_module[0].match(b"using ansible_collections.some.collection.plugins.module_utils.some_util")
    assert not module_finder._re_cs_module[0].match(b"using ansible_collections.some.collection.plugins.module_utils.some_util\n")
    assert not module_finder

# Generated at 2022-06-22 20:05:50.333481
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2

test_PSModuleDepFinder()


# Generated at 2022-06-22 20:06:01.752650
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils import basic
    import ansible.executor.powershell.shared as shared


# Generated at 2022-06-22 20:06:03.339756
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Test this"

# Generated at 2022-06-22 20:06:11.643814
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Posh-SSH') == None
    assert dep_finder.scan_module(b'#AnsibleRequires -Powershell \
                                Ansible.ModuleUtils.PModelinux') == None
    assert dep_finder.scan_module(b'using Ansible.ModuleUtils.Network.Libvirt.Libvirt;') == None
    assert dep_finder.scan_module(b'#AnsibleRequires -CSharpUtil \
                                ansible_collections.Network.Libvirt.plugins.module_utils.Libvirt;') == None


# Generated at 2022-06-22 20:06:14.113889
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Can't find a way to create a good test case.
    pass

# Generated at 2022-06-22 20:06:27.167463
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test cases for PowerShell modules can only be supported in python3
    try:
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        pass
    else:
        # FIXME: need to work out a way to import the collections compiler
        # so the references to "OtherCollection" below can be fixed
        ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:06:34.950510
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    data = _slurp(os.path.join(os.path.dirname(__file__), 'testdata', 'module_util_imports.ps1'))
    b_data = to_bytes(data)
    finder.scan_module(b_data, "ansible_collections.my_namespace.my_collection.plugins.modules.my_module")

    assert finder.ps_modules['Ansible.ModuleUtils.PSVersionOperators']['data'] == _slurp(os.path.join(
        C.DEFAULT_MODULE_UTILS_PATH[0], 'PSVersionOperators.psm1'))


# Generated at 2022-06-22 20:06:45.336573
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()

    assert module_dep_finder.ps_modules == dict()
    assert module_dep_finder.exec_scripts == dict()
    assert module_dep_finder.cs_utils_wrapper == dict()
    assert module_dep_finder.cs_utils_module == dict()

# This test requires the file ansible_collections/ansible/test/plugins/module_utils/test_module_utils.psm1
# to be present on the filesystem and uses this file as the parameter module_data.
# It then checks if the scan_module function does indeed read the Requires statement inside this file
# and add the module_util to the ps_modules dict.
#
# The test_module_utils.psm1 contains the following lines:
#
# #AnsibleRequires -PowerShell ansible_

# Generated at 2022-06-22 20:06:57.601139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with invalid value for parameter name.
    obj = PSModuleDepFinder()
    assert "Insufficient number of arguments for method scan_exec_script" in str(obj.scan_exec_script)
    # Test with parameter name value as None.
    assert "Argument 'name' may not be None" in str(obj.scan_exec_script(None))
    # Test with parameter name value as empty string.
    assert "Argument 'name' may not be None" in str(obj.scan_exec_script(""))
    # Test with invalid value for parameter name.
    assert "Could not find executor powershell script for 'non_existing_script'" in \
        str(obj.scan_exec_script("non_existing_script"))
    # Test with valid value for parameter name.

# Generated at 2022-06-22 20:07:07.281166
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False, no_log=False,
            check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
            required_one_of=None, required_by=None):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive or []
            self.required_together = required_together or []
            self.required_one_of = required_one_of or []
            self.required

# Generated at 2022-06-22 20:07:17.184522
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert ps_dep_finder.ps_modules == {}
    assert ps_dep_finder.exec_scripts == {}
    assert ps_dep_finder.cs_utils_wrapper == {}
    assert ps_dep_finder.cs_utils_module == {}
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert not ps_dep_finder.become
    assert isinstance(ps_dep_finder._re_cs_module, list)
    assert isinstance(ps_dep_finder._re_cs_in_ps_module, list)
    assert isinstance(ps_dep_finder._re_ps_module, list)
    assert isinstance(ps_dep_finder._re_wrapper, re._pattern_type)

# Generated at 2022-06-22 20:07:23.276008
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an instance of the PSModuleDepFinder class
    ps_module_dep_finder = new_PSModuleDepFinder_instance()
    module_data = """
        #AnsibleRequires -Wrapper Get-Path
        #AnsibleRequires -CSharpUtil ansible_collections.test_ns.test_coll.plugins.module_utils.test_cs_utils;
        #AnsibleRequires -PowerShell ps_util
        #Requires -Module Ansible.ModuleUtils.CommonUtils;
    """
    wrapper = False
    powershell = True
    ps_module_dep_finder.scan_module(module_data, wrapper, powershell)
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.CommonUtils']['data']
    assert ps_module_dep_finder

# Generated at 2022-06-22 20:07:29.728033
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import pytest

    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert len(psmdf.exec_scripts) == 0
    assert psmdf.ps_version is None
    assert psmdf.become is False

    # Test '_re_cs_module'
    m = psmdf._re_cs_module[0].match(b'using ansible.module_utils.')
    assert m

    m = psmdf._re_cs_module[0].match(b'using ansible_collections.my_namespace.my_collection.plugins.module_utils.')
    assert m


# Generated at 2022-06-22 20:07:42.247077
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    assert mdf.ps_modules == dict()
    assert mdf.cs_utils_wrapper == dict()
    assert mdf.cs_utils_module == dict()
    assert mdf.ps_version is None
    assert mdf.os_version is None
    assert mdf.become is False

    expected_re_cs_module = [re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                 r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))]
    assert expected_re_cs_module == mdf._re_cs_module


# Generated at 2022-06-22 20:07:50.499252
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()
    assert not module_dep_finder.ps_modules
    assert not module_dep_finder.cs_utils_wrapper
    assert not module_dep_finder.cs_utils_module

    assert not module_dep_finder._re_cs_module
    assert not module_dep_finder._re_cs_in_ps_module
    assert not module_dep_finder._re_ps_module
    assert not module_dep_finder._re_wrapper
    assert not module_dep_finder._re_ps_version
    assert not module_dep_finder._re_os_version
    assert not module_dep_finder._re_become



# Generated at 2022-06-22 20:08:00.293289
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Unit test for method scan_module of class PSModuleDepFinder
    scanner = PSModuleDepFinder()

# Generated at 2022-06-22 20:08:12.925201
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    def _mock_ansible_module(path, args=None, check_invalid_arguments=None, **kw):
        return AnsibleModule(argument_spec=dict(), **kw)

    def _mock_ansible_runner(connection,
                             become_method,
                             become_user,
                             become,
                             check,
                             diff,
                             private_data_dir,
                             stdin_add_newline,
                             module_path,
                             module_name,
                             module_args,
                             tmpdir,
                             task_uuid,
                             **private_data_dir_options):
        print(private_data_dir_options)


# Generated at 2022-06-22 20:08:23.889670
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper
    assert finder._re_ps_version
    assert finder._re_os_version
    assert finder._re_become



# Generated at 2022-06-22 20:08:33.581564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('Ansible.PowerShell.Common')
    assert psmdf.exec_scripts['Ansible.PowerShell.Common']
    assert psmdf.ps_modules['Ansible.PowerShell.Common.ModuleUtils.Common']
    assert psmdf.ps_modules['Ansible.PowerShell.Core']
    assert psmdf.ps_modules['Ansible.PowerShell.Execution']
    assert psmdf.ps_modules['Ansible.PowerShell.DataTypes']

# Generated at 2022-06-22 20:08:35.932061
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    finder.scan_exec_script('win_file')



# Generated at 2022-06-22 20:08:44.354337
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test scan module with simple file with one dependency
    data = bytearray(b'', encoding='utf-8')
    data += b'\n'
    data += b'#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.web'
    data += b'\n'
    dep_finder = PSModuleDepFinder()
    name, ext, fqn, optional = "ansible_collections.ns.coll.plugins.module_utils.web", "psm1", "ns.coll.module_name", False
    dep_finder.scan_module(data)
    assert len(dep_finder.ps_modules) == 1
    assert name in dep_finder.ps_modules

# Generated at 2022-06-22 20:08:55.690262
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert isinstance(ps_module_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_finder.cs_utils_module, dict)
    assert isinstance(ps_module_finder.ps_modules, dict)
    assert isinstance(ps_module_finder.exec_scripts, dict)
    assert isinstance(ps_module_finder.ps_version, str)
    assert isinstance(ps_module_finder.os_version, str)
    assert isinstance(ps_module_finder.become, bool)

    assert isinstance(ps_module_finder._re_cs_module, list)
    assert isinstance(ps_module_finder._re_cs_in_ps_module, list)

# Generated at 2022-06-22 20:08:57.710375
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # TODO: write a unit test for this class
    pass


# Generated at 2022-06-22 20:09:08.246283
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def _slurp_data(filename, module_name):
        # slurp in the data
        with open(filename, 'rb') as f:
            data = f.read()

        data = to_bytes(data)
        # replace Requires using the module, with a Requires using the
        # temp module_utils file to prevent recursion
        # data = re.sub(
        #     re.compile(to_bytes(r'(^#\s*requires\s+\S*\s+' + module_name + '\S*\s*)',
        #                               re.IGNORECASE)), b'', data, flags=re.MULTILINE)
        # data = re.sub(
        #     re.compile(to_bytes(r'(^#\s*ansiblerequires\s+\S*

# Generated at 2022-06-22 20:09:10.711411
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Utility function for removing comments from PowerShell data

# Generated at 2022-06-22 20:09:23.299721
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test for method scan_module of class PSModuleDepFinder"""

# Generated at 2022-06-22 20:09:31.020487
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
        This is the unit test for method scan_module of class PSModuleDepFinder.
    '''
    loader = PSModuleDepFinder()
    module_data = "#! /bin/some_directory/some_shell\n#Requires -Version 5.1"
    fqn = "some_namespace.some_collection.some_module"
    loader.scan_module(module_data, fqn)
    assert loader.ps_version == '5.1'

    module_data = "#! /bin/some_directory/some_shell\n#AnsibleRequires -OsVersion 6.1"
    fqn = "some_namespace.some_collection.some_module"
    loader.scan_module(module_data, fqn)
    assert loader.os_version == '6.1'

   

# Generated at 2022-06-22 20:09:36.282957
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Make sure the scan_module method finds the correct number of module_utils that are
    present in a module.
    """
    psmdf = PSModuleDepFinder()
    # test a module that uses builtin module_utils
    module_data = pkgutil.get_data("ansible.builtin.win_copy", "win_copy.psm1")
    psmdf.scan_module(module_data, fqn="ansible.builtin.win_copy", wrapper=False, powershell=True)
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_module) == 3
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.exec_scripts) == 0
    assert psmdf.ps_

# Generated at 2022-06-22 20:09:44.146507
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:09:50.777650
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    x = PSModuleDepFinder()
    assert x.ps_modules == dict()
    assert x.exec_scripts == dict()
    assert x.cs_utils_wrapper == dict()
    assert x.cs_utils_module == dict()
    assert x.ps_version is None
    assert x.os_version is None
    assert x.become is False


# Generated at 2022-06-22 20:09:56.600964
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    # pylint: disable=unused-variable
    class MockModuleDepFinder(PSModuleDepFinder):
        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            pass

    module_dep_finder = PSModuleDepFinder()
    assert module_dep_finder.__class__ == PSModuleDepFinder


# Generated at 2022-06-22 20:10:08.687478
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-22 20:10:20.251803
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module("""\
#Import module util
#Requires -Module Ansible.ModuleUtils.CommonUtils
#Import collection module util
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.CommonUtils2
#Require local module util
#AnsibleRequires -CSharpUtil ..module_utils.CommonUtils3
""", fqn="ansible.module_utils.CommonUtils")

    assert finder.cs_utils_module == {
        'ansible_collections.ns.coll.plugins.module_utils.CommonUtils2': {},
        'ansible.module_utils.CommonUtils': {},
        'ansible.module_utils.CommonUtils3': {},
    }


# Generated at 2022-06-22 20:10:32.948263
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_fixture = {
        'name': 'test',
        'exec_script': b'\n#Requires -Modules Ansible.ModuleUtils.ExtraDummyModule, Ansible.ModuleUtils.DummyModule\n'
                       b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Logger\n'
                       b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.TestModuleLib\n'
                       b'#AnsibleRequires -CSharpUtil ansible_collections.extra.dummy.module_utils.TestModule2',
    }
    # name = test, wrapper = true, powershell = True
    expected_exec_script = {
        'test': b'\n\n\n\n',
    }

    finder = PSModuleDepFinder()
   

# Generated at 2022-06-22 20:10:39.942245
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_exec_script_name = "TestExecScript"
    test_exec_script_data = b'#AnsibleRequires -PowerShell .some_module_util'
    pkgutil.get_data_mock = MagicMock(return_value=test_exec_script_data)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(test_exec_script_name)

    assert dep_finder.exec_scripts[test_exec_script_name] == test_exec_script_data
    assert dep_finder.ps_modules[b'.some_module_util'] == {
        'data': b'',
        'path': to_text(os.path.join(C.DEFAULT_MODULE_PATH, b'.some_module_util.psm1')),
    }

# Generated at 2022-06-22 20:10:44.830458
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False



# Generated at 2022-06-22 20:10:49.920427
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Assert that the collection_loader will load the required module_utils
    assert resource_from_fqcr('ansible_collections.netapp.ontap.plugins.module_utils.netapp.ontap.na_ontap_execscript')

    from ansible.module_utils.basic import AnsibleModule

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("hello")

    assert not dep_finder.become
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None

    for script, data in dep_finder.exec_scripts.items():
        assert isinstance(data, bytes)
        assert to_text(data).strip().startswith("param([string]$input")

    assert 'hello' in dep_finder.exec_scripts.keys

# Generated at 2022-06-22 20:10:51.590098
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    m = PSModuleDepFinder()
    assert m
    assert isinstance(m, PSModuleDepFinder)



# Generated at 2022-06-22 20:11:01.075892
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import base64
    import json
    import shutil
    import tempfile
    import unittest
    import ansible
    # import ansible.plugins.loader as pl
    # import ansible.plugins.module_utils as mod_utils

    class TestPSModuleDepFinder(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.root_dir = os.path.join(self.temp_dir, 'an')
            self.test_home = os.path.join(self.root_dir, 'ansible')
            self.test_coll = os.path.join(self.test_home, 'collections')

# Generated at 2022-06-22 20:11:07.828635
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('reboot')

    exec_wrapper = psmdf.exec_scripts['reboot']
    assert isinstance(exec_wrapper, bytes)

    assert 'function reboot' in to_text(exec_wrapper)


# Generated at 2022-06-22 20:11:15.283461
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expectedResult1 = _slurp(os.path.join(os.path.dirname(__file__), "data", "test.ps1"))
    expectedResult2 = _slurp(os.path.join(os.path.dirname(__file__), "data", "test2.ps1"))
    assert PSModuleDepFinder().scan_exec_script('test') == expectedResult1
    assert PSModuleDepFinder().scan_exec_script('test2') == expectedResult2

# Generated at 2022-06-22 20:11:25.378011
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    def _get_module_data(module_name):
        module_data = b''
        with open(os.path.join(C.DEFAULT_LOCAL_TMP, 'test_module_'+ module_name), 'rb') as f:
            for line in f:
                module_data += line
        return module_data

    def _compare_list(list_a, list_b):
        """
        Check list_a and list_b contains same elements.
        :param list_a: list
        :param list_b: list
        :return: bool
        """
        if not list_a and not list_b:
            return True
        elif len(list_a) != len(list_b):
            return False

        list_a.sort()
        list_b.sort()

# Generated at 2022-06-22 20:11:30.377613
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()
    mdf.scan_module(b"#Requires -Module Ansible.ModuleUtils.Common\n", powershell=True)
    assert len(mdf.ps_modules) == 1
    assert mdf.ps_modules.get("Ansible.ModuleUtils.Common")


# Generated at 2022-06-22 20:11:32.114477
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# unit test for scan_module

# Generated at 2022-06-22 20:11:40.953773
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    # Ensure scan_exec_script() returns a valid script for the specified powershell script.
    #
    # No particular reason for selecting this one.
    #

    dep_finder = PSModuleDepFinder()

    script_type = 'ansible_runner'
    scripts = dep_finder.scan_exec_script(script_type)

    assert scripts is not None
    assert isinstance(scripts, bytes)
    assert len(scripts) > 0



# Generated at 2022-06-22 20:11:48.827100
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:00.324557
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False

    # test that the regular expression checks use the proper extensions
    assert '.cs' in ps_module_dep_finder._re_cs_module[0].pattern
    assert '.cs' in ps_module_dep_finder._re_cs_in_ps_module[0].pattern
    assert '.psm1' in ps_module_dep_finder._re_ps_module[0].pattern
    assert '.psm1' in ps_module_dep_finder._re_ps_module[1].pattern

    # test that the regular expressions are valid

# Generated at 2022-06-22 20:12:01.542425
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:12:10.553981
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Test data
    ps_module = {}
    cs_utils_wrapper = {}

    data = pkgutil.get_data('test_ansible_powershell.test_get_module_path', 'GetModulePath.ps1')
    b_data = to_bytes(data)
    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        exec_script = b_data
    else:
        exec_script = _strip_comments(b_data)
    ps_module['test_ansible_powershell.test_get_module_path.ps1'] = to_bytes(exec_script)

    # Unit test code
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-22 20:12:11.783208
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-22 20:12:22.141841
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Pester.4.0.1', fqn='test')
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Pester.4.0.1']
    assert dep_finder.wrapper['Ansible.ModuleUtils.Pester.4.0.1']

    # This can't find the test module_util file in collection_loader.base_file_system
    # dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Pester3', fqn='test')
    # assert dep_finder.ps_modules['Ansible.ModuleUtils.Pester.4.0.1']


# Generated at 2022-06-22 20:12:25.485209
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("enable_psremoting")
    finder.scan_exec_script("powershell_execution")
    assert finder.exec_scripts

# Generated at 2022-06-22 20:12:37.465790
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == dict()
    assert f.cs_utils_wrapper == dict()
    assert f.cs_utils_module == dict()
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False

# def _strip_comments(powershell_code):
#     """strip the embedded comments in a powershell script because the PSA module in Ansible
#     does not like commented out lines."""
#     # strip the embedded comments in a powershell script because the
#     # PSA module in Ansible does not like commented out lines
#     # there are a few known types of comments
#     comment_removers = [
#         re.compile(br'#.*$', re.M),
#         re.compile(

# Generated at 2022-06-22 20:12:39.863880
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()
    assert module_dep_finder



# Generated at 2022-06-22 20:12:53.251017
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:12:54.741929
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-22 20:13:06.968488
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PDMDF = PSModuleDepFinder()
    # This test case uses a modified version of lib/ansible/executor/powershell/module_utils/powerpack.ps1.
    # The comments have been removed to reduce payload size, and the `ScriptBlock` class constructor has
    # been removed to avoid a dependency on a later PowerShell version that is not installed by default
    # on Windows 7.

# Generated at 2022-06-22 20:13:17.647454
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert(md.ps_modules == dict())
    assert(md.exec_scripts == dict())
    assert(md.cs_utils_wrapper == dict())
    assert(md.cs_utils_module == dict())
    assert md._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:13:25.004441
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    for re_cs_module in dep_finder._re_cs_module:
        assert re_cs_module.match(b'using ansible_collections.ns.coll.plugins.module_utils.name;')
        assert re_cs_module.match(b'using Ansible.Name;')
        assert not re_cs_module.match(b'using namespace ansible_collections.ns.coll.plugins.module_utils;')
        assert not re_cs_module.match(b'using Ansible;')
        assert not re_cs_module.match(b'using Ansible.Name')


# Generated at 2022-06-22 20:13:36.646316
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder
    from ansible.executor.module_common import get_platform_subclass
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    platform_cls = get_platform_subclass('windows')

    #
    # Test scan_module
    #

    # test with no requirements
    no_reqs_data = "Something to say\nwith multiple lines"
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(to_bytes(no_reqs_data))
    assert len(psmdf.ps_modules.keys()) == 0
    assert len(psmdf.cs_utils_wrapper.keys()) == 0

# Generated at 2022-06-22 20:13:38.845624
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('basic')


# Generated at 2022-06-22 20:13:48.696150
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    :return:
    """
    m = PSModuleDepFinder()
    assert m._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                  r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-22 20:14:00.169002
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-22 20:14:09.802960
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test _add_module method of class PSModuleDepFinder.
    # Test input: module_data, fqn=None, wrapper=False, powershell=True
    # Expected output: None
    ps_module_dep_finder = PSModuleDepFinder()
    test_data_dir = "test/unit/module_utils/powershell/"
    module_data = _slurp(test_data_dir + "module_utils_module.psm1")
    fqn = None
    wrapper = False
    powershell = True

    ps_module_dep_finder.scan_module(module_data, fqn, wrapper, powershell)
    assert len(ps_module_dep_finder.ps_modules) == 3
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
   

# Generated at 2022-06-22 20:14:22.627203
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    if True:
        # This is also used by validate-modules to get a module's required utils in base and a collection.
        self.ps_modules = dict()
        self.exec_scripts = dict()

        # by defining an explicit dict of cs utils and where they are used, we
        # can potentially save time by not adding the type multiple times if it
        # isn't needed
        self.cs_utils_wrapper = dict()
        self.cs_utils_module = dict()

        self.ps_version = None
        self.os_version = None
        self.become = False


# Generated at 2022-06-22 20:14:35.102870
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = to_bytes("""
#Requires -Module Ansible.ModuleUtils.First
#Requires -Module Ansible.ModuleUtils.Second
#Requires -Module ansible_collections.namespace.collection.plugins.module_utils.Third
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Fourth
#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.Fifth
#AnsibleRequires -PowerShell ..module_utils.Sixth

#Requires -Module Ansible.ModuleUtils.Seven

#Requires -Version 3.5.1
#AnsibleRequires -OSVersion 4.0
#AnsibleRequires -Become
""")

    moddepfinder = PSModuleDepFinder()
    moddepfinder.scan_module(module_data)

    assert len