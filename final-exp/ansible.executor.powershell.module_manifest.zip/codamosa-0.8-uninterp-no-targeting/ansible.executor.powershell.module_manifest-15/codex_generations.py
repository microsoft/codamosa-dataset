

# Generated at 2022-06-20 14:15:56.889595
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create instance of class PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    # call scan_exec_script
    psmdf.scan_exec_script("azure_rm_common")
    # assert the number of keys in exec_scripts
    assert 2 == len(psmdf.exec_scripts)
    # assert the key of exec_scripts
    assert 'AzureRM.Netcore.Base' == list(psmdf.exec_scripts)[0]
    # assert the key of exec_scripts
    assert 'azure_rm_common' == list(psmdf.exec_scripts)[1]
    # assert the value of exec_scripts

# Generated at 2022-06-20 14:16:02.315237
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  # Instantiate PSModuleDepFinder object
  psModuleDepFinder = PSModuleDepFinder()
  # Execute scan_exec_script method on PSModuleDepFinder object
  psModuleDepFinder.scan_exec_script('test_name')


# Generated at 2022-06-20 14:16:03.831878
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    assert PSModuleDepFinder


# Generated at 2022-06-20 14:16:07.946964
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert "ModeUtil" not in finder.exec_scripts
    finder.scan_exec_script("ModeUtil")
    assert "ModeUtil" in finder.exec_scripts



# Generated at 2022-06-20 14:16:12.010306
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import pytest

    def get_module_data(module):
        base_path = os.path.dirname(os.path.abspath(__file__))
        module_path = os.path.join(base_path, "module_data",
                                   "module_utils_module_loader", module)
        with open(module_path, "r") as f:
            return f.read()

    def assert_module_data(m, data):
        assert data[m]["data"] == (get_module_data(m).encode('utf-8')
                                   if m.endswith(".cs") else
                                   get_module_data(m))
        assert data[m]["path"].endswith(m)


# Generated at 2022-06-20 14:16:25.190815
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from io import BytesIO
    import sys
    import unittest
    import ansible.module_utils.powershell.ansible_module
    # This import prevents the patching of sys.path in this test case from showing warnings about missing __init__.py
    # files for the ansible.executor.powershell package.
    import ansible.executor.powershell

    class AnsibleModuleStub(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False):
            self.argument_spec = argument_spec
            self.params = {}


# Generated at 2022-06-20 14:16:39.558956
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Check that a bad fqn raises AnsibleError
    with pytest.raises(AnsibleError):
        finder.scan_module("#AnsibleRequires -CSharpUtil Bad.Path")
    # Check that a builtin util that is not found raise a AnsibleError
    with pytest.raises(AnsibleError):
        finder.scan_module("#Requires -Module Ansible.ModuleUtils.Bad.Path")
    # Check that a collection util that is not found raise a AnsibleError
    with pytest.raises(AnsibleError):
        finder.scan_module("#AnsibleRequires -Powershell ansible_collections.bad.collection.plugins.module_utils.path")
    # Check that a collection util that is optional and not found is

# Generated at 2022-06-20 14:16:41.534102
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder  # sanity check that the module is constructed

# Generated at 2022-06-20 14:16:49.087385
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible_collections.fortinet.fortios.plugins.module_utils import fortios_exec
    from ansible_collections.fortinet.fortios.plugins.module_utils.fortios_exec import FortiOSExec
    from ansible_collections.fortinet.fortios.tests.unit.compat import unittest

    class MyTests(unittest.TestCase):
        def setUp(self):
            self.ps_module_dep_finder = PSModuleDepFinder()
            self.exec_wrapper = fortios_exec.FortiOSExecModule

        def test_ps_module_dep_finder(self):
            try:
                # call function to test
                self.ps_module_dep_finder.scan_exec_script(self.exec_wrapper.__name__)
            except Exception as e:
                self

# Generated at 2022-06-20 14:16:54.835499
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Legacy.Common')
    assert to_text(dep_finder.exec_scripts['Legacy.Common']) == to_text(_slurp(os.path.join(os.path.dirname(__file__), '../../executor/powershell/Legacy.Common.ps1')))



# Generated at 2022-06-20 14:17:15.223757
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  assert True == True

# Generated at 2022-06-20 14:17:20.821655
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj_class = PSModuleDepFinder()
    obj_class.scan_module = lambda x, y, z, k: None
    obj_class.scan_exec_script("become_ps_wrapper")
    assert obj_class.exec_scripts["become_ps_wrapper"] == b"\n"


# Generated at 2022-06-20 14:17:21.501259
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-20 14:17:27.002110
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    resolver = PSModuleDepFinder()
    data = to_bytes("#Requires -Version 5.1 #Requires -Module Ansible.ModuleUtils.Fake")

    resolver.scan_module(data)
    assert resolver.ps_modules["Ansible.ModuleUtils.Fake"] == "5.1"
    assert resolver.ps_version == "5.1"



# Generated at 2022-06-20 14:17:30.366161
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('WinRM')
    psmdf.scan_exec_script('WinRM')
    psmdf.scan_exec_script('')


# Generated at 2022-06-20 14:17:36.875482
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the method scan_module of class PSModuleDepFinder (os_required is not set)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.PowerShell\n#AnsibleRequires -Powershell Ansible.ModuleUtils.MyModule')
    assert len(dep_finder.ps_modules) == 2
    assert "Ansible.ModuleUtils.PowerShell" in dep_finder.ps_modules
    assert "Ansible.ModuleUtils.MyModule" in dep_finder.ps_modules
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become

    # Test the method scan_module of class PSModuleDepFinder (os_required is not set

# Generated at 2022-06-20 14:17:45.373489
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_cs_module) == 1
    assert len(finder._re_ps_module) == 2
    assert len(finder._re_wrapper) == 1
    assert len(finder._re_ps_version) == 1
    assert len(finder._re_os_version) == 1
    assert len(finder._re_become) == 1



# Generated at 2022-06-20 14:17:47.140872
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-20 14:17:55.910750
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'#Requires -Modules Ansible.ModuleUtils.Pending')
    assert('Ansible.ModuleUtils.Pending' in finder.ps_modules.keys())



# Generated at 2022-06-20 14:18:07.160812
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    # TODO: This should be done using a temp file and with the appropriate base64 in place
    data = """
#Requires -Version 1.1

$n = [int]::Parse('1e5')

function random
{
    return Get-Random -Minimum 1 -Maximum $n
}

$total = 0

for($i=0; $i -lt 100; $i++)
{
    $total += random
}

$ansible_module_results = @{
    "total" = $total
}
"""
    data = to_text(base64.b64encode(to_bytes(data)))

    module = AnsibleModule(argument_spec={})
    depfinder = PS

# Generated at 2022-06-20 14:18:26.567997
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become == False


# Generated at 2022-06-20 14:18:33.032443
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    data = PSModuleDepFinder()
    assert data.ps_modules == dict()
    assert data.exec_scripts == dict()
    assert data.cs_utils_wrapper == dict()
    assert data.cs_utils_module == dict()
    assert data.ps_version is None
    assert data.os_version is None
    assert data.become is False

    for regex in data._re_cs_module:
        assert regex.pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                         r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')


# Generated at 2022-06-20 14:18:37.662157
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
   finder = PSModuleDepFinder()
   # exec_script = getattr(finder, '_PSModuleDepFinder__exec_script')
   exec_script = None
   name = "test_name"
   exec_script_data = to_native(b'\n'.join([to_bytes("#doesn't matter")]))
   finder.scan_exec_script("name")
   assert getattr(finder, 'exec_scripts', None) == {'name': exec_script_data}


# Generated at 2022-06-20 14:18:40.104799
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    obj.scan_exec_script('win_psmodule')


# Generated at 2022-06-20 14:18:42.463579
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert None is None and 'Invalid test argument for test_PSModuleDepFinder_scan_exec_script'



# Generated at 2022-06-20 14:18:50.504251
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup
    psModuleDepFinder = PSModuleDepFinder()

    def scan_module(module_data, fqn=None, wrapper=False, powershell=True):
        psModuleDepFinder.module_utils = set()
        pass


    def _add_module(name, ext, fqn, optional, wrapper=False):
        psModuleDepFinder.module_utils = set()

    psModuleDepFinder._add_module = _add_module


    # Invoke the method
    test_module_data = None
    psModuleDepFinder.scan_module(module_data=test_module_data)


# Generated at 2022-06-20 14:19:03.000640
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder() object
    ps_module_dep_finder = PSModuleDepFinder()
    # Create a temporary file to fill with data for the unit test.
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write(u'#!/usr/bin/env python\n')
        f.write(u'# -*- coding: utf-8 -*-')
        f.write(u'\n')
        f.write(u'"""')
        f.write(u'\n')
        f.write(u'This module is a temporary module to be used in the unit tests')
        f.write(u'\n')
        f.write(u'"""')
        f.write(u'\n')

# Generated at 2022-06-20 14:19:09.403131
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    if not isinstance(f, PSModuleDepFinder):
        raise AssertionError("PSModuleDepFinder constructor not working")
# Unit test end


# Generated at 2022-06-20 14:19:20.479083
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()

    # PSModuleDepFinder.__init__()
    assert isinstance(f.ps_modules, dict)
    assert isinstance(f.cs_utils_wrapper, dict)
    assert isinstance(f.cs_utils_module, dict)
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False

    assert isinstance(f._re_cs_module, list)
    assert isinstance(f._re_cs_in_ps_module, list)
    assert isinstance(f._re_ps_module, list)
    assert isinstance(f._re_wrapper, type(re.compile('.')))
    assert isinstance(f._re_ps_version, type(re.compile('.')))

# Generated at 2022-06-20 14:19:22.590141
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()


# Generated at 2022-06-20 14:19:45.255838
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder._re_cs_module == [
        re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')),
    ]

# Generated at 2022-06-20 14:19:46.068557
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-20 14:19:58.836538
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.ps_modules = {}
    finder.cs_utils_wrapper = {}
    finder.cs_utils_module = {}
    finder.exec_scripts = {}
    finder.ps_version = None
    finder.os_version = None
    finder.become = False


# Generated at 2022-06-20 14:20:08.913175
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#AnsibleRequires -CSharpUtil Ansible.Test')
    assert 'Ansible.Test' in dep_finder.ps_modules
    assert 'Ansible.Test' in dep_finder.cs_utils_wrapper
    assert 'Ansible.Test' not in dep_finder.cs_utils_module

    dep_finder.scan_module(b'using Ansible.Test;')
    assert 'Ansible.Test' in dep_finder.ps_modules
    assert 'Ansible.Test' in dep_finder.cs_utils_wrapper
    assert 'Ansible.Test' in dep_finder.cs_utils_module


# Generated at 2022-06-20 14:20:21.714807
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # define a psm1 and cs module_util as test data
    psdata = u'''
#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#AnsibleRequires -PowerShell Ansible.ModuleUtils.FooBar
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.FooBar
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.FooBar
#AnsibleRequires -CSharpUtil ..module_utils.FooBar
'''


# Generated at 2022-06-20 14:20:23.774696
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    d = PSModuleDepFinder()
    d.scan_exec_script('fix_json')


# Generated at 2022-06-20 14:20:37.191829
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()
    mdf.ps_modules = dict()
    mdf.cs_utils_wrapper = dict()
    mdf.cs_utils_module = dict()
    fqn = "ansible_collections.ansible.foo.plugins.module_utils.module_utils"
    name = "module_utils"

# Generated at 2022-06-20 14:20:45.875504
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible_collections.not_a_real_collection.no_real_collection.plugins.module_utils.dummy_ps_module_utils import DummyPsModuleUtilClass

    dep_finder = PSModuleDepFinder()

    ################
    # Test Example2
    ################
    # This is an example of a PowerShell module that references multiple
    # module_utils (ps and c#), as well as an executor script, and a C#
    # module_util that references other C# module_utils.

    # Example2's module:

# Generated at 2022-06-20 14:20:50.201198
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(bytes(random.getrandbits(256)))
    print('Success: test_PSModuleDepFinder_scan_module')



# Generated at 2022-06-20 14:20:59.120569
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tested the module scan, module find and module utils find

    r = random.choice('abcdefghijklmnopqrstuvwxyz')
    module_data = '''#Requires -Module Ansible.ModuleUtils.ModuleTest, Ansi''' + r + '''ble.ModuleUtils.Network.#AnsibleRequires -Powershell Ansible.ModuleUtils.Network, #ansiblerequires -powershell ansible_collections.namespace.foo.plugins.module_utils.legacy, #ansiblerequires -powershell ..module_utils.legacy'''
    m = PSModuleDepFinder()
    m.scan_module(to_bytes(module_data))
    assert r not in m.ps_modules.keys()

# Generated at 2022-06-20 14:21:14.571088
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('windows_command')
    assert 'windows_command' in finder.exec_scripts
    assert len(finder.ps_modules)>2
    assert ('Ansible.ModuleUtils.Common', '.psm1', None, False) in finder.ps_modules


# Generated at 2022-06-20 14:21:21.865816
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test a module that has no dependencies
    module_data = to_bytes(u'#!/usr/bin/python')
    pmdf = PSModuleDepFinder()
    pmdf.scan_module(module_data)
    result = {
        'ps_version': None,
        'os_version': None,
        'become': False,
        'ps_modules': {},
        'cs_utils_wrapper': {},
        'exec_scripts': {},
        'cs_utils_module': {},
    }
    assert pmdf.__dict__ == result
    # Test a module that has a single powershell dependency
    module_data = to_bytes(u'#!/usr/bin/python\n#AnsibleRequires -Powershell ..module_utils.test_module')
    pmdf = PSModuleDepF

# Generated at 2022-06-20 14:21:28.765733
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert not p.ps_modules
    assert not p.cs_utils_wrapper
    assert not p.cs_utils_module
    assert not p.ps_version
    assert not p.os_version
    assert not p.become
    assert len(p._re_cs_module) == 1
    assert len(p._re_cs_in_ps_module) == 1
    assert len(p._re_ps_module) == 1

# Unit tests for scan_module function of class PSModuleDepFinder

# Generated at 2022-06-20 14:21:37.542426
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version == None
    assert dep_finder.os_version == None
    assert dep_finder.become == False


# Generated at 2022-06-20 14:21:48.181515
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert len(psmdf.exec_scripts) == 0
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False
    assert len(psmdf._re_cs_module) == 1
    assert len(psmdf._re_cs_in_ps_module) == 1
    assert len(psmdf._re_ps_module) == 2

# Generated at 2022-06-20 14:21:53.941922
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmoduledepfinder = PSModuleDepFinder()
    assert len(psmoduledepfinder.exec_scripts.keys()) == 0
    psmoduledepfinder.scan_exec_script("CommonEcho")
    assert len(psmoduledepfinder.exec_scripts.keys()) == 1
    assert all(key in psmoduledepfinder.exec_scripts.keys() for key in ['CommonEcho'])

# Generated at 2022-06-20 14:21:58.514800
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script("ps_common")
    assert "ps_common" in psmd.exec_scripts.keys()
    assert "ps_common" in psmd.ps_modules.keys()


# Generated at 2022-06-20 14:22:07.096618
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-20 14:22:21.273618
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # pylint: disable=too-many-locals
    from ansible.plugins.loader import powershell_loader
    
    random_int = random.randrange(1, 255, 1)
    pow_script_name = 'test_PSModuleDepFinder_scan_exec_script_%d.ps1' % random_int
    cp_script_name = 'test_PSModuleDepFinder_scan_exec_script_%d.cs' % random_int
    # Create a test powershell module and module_utils
    # pylint: disable=unused-variable
    # pylint: disable=unsubscriptable-object
    ansible_powershell_path = os.path.join(os.path.dirname(powershell_loader.__file__), 'lib')

# Generated at 2022-06-20 14:22:33.236649
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # First, test the required utils declarations without the version constraints.
    # The declarations will be ignored since no version is specified.
    test_case01 = dict()
    test_case01['module'] = '''
#Requires -Module Ansible.ModuleUtils.PAM
#AnsibleRequires -PowerShell ansible_collections.microsoft.windows.plugins.module_utils.win_psmodule
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.PsUtils
#AnsibleRequires -CSharpUtil ..module_utils.common_utils
'''
    test_case01['module_utils'] = dict()

# Generated at 2022-06-20 14:22:51.969577
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps = PSModuleDepFinder()
    assert ps._re_cs_module is not None
    assert ps._re_ps_module is not None
    assert ps._re_wrapper is not None
    assert ps._re_ps_version is not None
    assert ps._re_os_version is not None
    assert ps._re_become is not None



# Generated at 2022-06-20 14:22:54.453213
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder is not None


# Generated at 2022-06-20 14:23:05.597762
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible
    file_name = "ping.ps1"
    dir_path = os.path.dirname(ansible.__file__) + "/executor/powershell"
    file_path = os.path.join(dir_path, file_name)
    assert os.path.isfile(file_path), "Make sure ping.ps1 exists"

    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_exec_script(file_name)
    assert file_name in ps_module_finder.exec_scripts
    assert "ansible_collections.ansible.builtin.plugins.module_utils.basic" in ps_module_finder.ps_modules
    assert "ping.ps1" in ps_module_finder.cs_utils_wrapper


# Generated at 2022-06-20 14:23:08.930757
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_name = ''
    module_data = ''
    fqn = None
    powershell = True
    assert False # TODO implement your test here


# Generated at 2022-06-20 14:23:14.645863
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert not finder.become
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper.pattern == re.compile(to_bytes(r'(?i)^#\s*ansiblerequires\s+-wrapper\s+(\w*)')).pattern



# Generated at 2022-06-20 14:23:25.094729
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder
    from random import choice

    md = PSModuleDepFinder()
    assert md.ps_modules == {}
    assert md.cs_utils_wrapper == {}
    assert md.cs_utils_module == {}
    assert md.ps_version == None
    assert md.os_version == None
    assert md.become == False

    def _test_module(name, contents, fqn='', wrapper=False, powershell=True):
        md.scan_module(contents, fqn, wrapper, powershell)
        assert md.ps_modules[name]['path'] == os.path.join(C.DEFAULT_MODULE_PATH, name + ".psm1")

    # Test a basic module_util requires

# Generated at 2022-06-20 14:23:29.330568
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('cs_native_executor')
    assert 'cs_native_executor' in ps_module_dep_finder.exec_scripts


# Generated at 2022-06-20 14:23:38.912355
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, object)
    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert isinstance(ps_module_dep_finder._re_cs_module, list)

# Generated at 2022-06-20 14:23:51.276557
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_cases = []
    for test_case in test_cases:
        ps_module_finder = PSModuleDepFinder()
        ps_module_finder.scan_module(test_case['ps_module'], test_case['fqn'], test_case['wrapper'],
                                     test_case['powershell'])
        assert ps_module_finder.cs_utils_module == test_case['cs_utils_modules']
        assert ps_module_finder.cs_utils_wrapper == test_case['cs_utils_wrappers']
        assert ps_module_finder.ps_modules == test_case['ps_modules']
        assert ps_module_finder.ps_version == test_case['ps_version']
        assert ps_module_finder.os_version == test_case['os_version']
        assert ps_module

# Generated at 2022-06-20 14:23:52.436559
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-20 14:24:17.736765
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tests scan_exec_script of class PSModuleDepFinder
    assert True



# Generated at 2022-06-20 14:24:30.084879
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:24:40.912676
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()

# Generated at 2022-06-20 14:24:52.281649
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.six import StringIO

    ####
    # setup:
    ####
    def dependency_mock_func(mod_list, fqn=None, wrapper=False, powershell=True):
        pass


    dependency_mock = "dependency_mock"
    pkg_mock_data = {
        dependency_mock: dependency_mock_func
    }

    data = '''
        #Requires -Module Ansible.ModuleUtils.first
        #Requires -Module Ansible.ModuleUtils.second
    '''

    ####
    # exercise:
    ####
    module_scanner = PSModuleDepFinder()
    module_scanner.scan_module = dependency_mock_func

    ####
    # verify:
    ####
    assert module_

# Generated at 2022-06-20 14:24:55.921814
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}



# Generated at 2022-06-20 14:24:57.589014
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Write unit tests
    pass


# Generated at 2022-06-20 14:25:02.671713
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_deps = PSModuleDepFinder()
    assert(ps_module_deps)
    assert(ps_module_deps.ps_modules == {})
    assert(ps_module_deps.cs_utils_module == {})
    assert(ps_module_deps.cs_utils_wrapper == {})


# Generated at 2022-06-20 14:25:10.071055
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # fix issue with test_module_deps/fixtures/module_deps_data.json where
    # C# wrapper path is incorrect
    from ansible.module_utils.powershell import \
        basic, json_encode_command
    from ansible.module_utils.common.json_encoder import JSONEncoder
    basic._ENCODE_COMMAND = json_encode_command
    basic.JSONEncoder = JSONEncoder

    from ansible.module_utils.powershell.executor.module_deps import \
        PSModuleDepFinder
    from ansible.module_utils.powershell.common import \
        _strip_comments

    md = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", "basic.ps1")

# Generated at 2022-06-20 14:25:24.566670
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    module_name = 'ansible_collections.misc.plugins.module_utils.miscSriov'
    module_data = pkgutil.get_data(module_name, 'miscSriov.psm1')

    # Test case 1: Scan a module and find module dependencies from inside and outside a collection
    finder.scan_module(module_data)
    assert(finder.ps_modules['Ansible.ModuleUtils.ActiveDirectory']['data'] ==
           to_bytes(pkgutil.get_data('ansible.module_utils.common.network', 'ActiveDirectory.psm1')))