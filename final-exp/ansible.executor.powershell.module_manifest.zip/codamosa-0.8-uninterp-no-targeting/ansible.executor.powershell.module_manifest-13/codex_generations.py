

# Generated at 2022-06-20 14:15:57.317301
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def execscript_data(name):
        data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
        return to_bytes(data, errors='surrogate_or_strict')

    def stub_get_loader(self, path):
        return self.mock_loader

    def mock_get_data(self, path):
        return self.data

    data = to_bytes("Foo")
    dep_finder = PSModuleDepFinder()

    dep_finder.mock_loader = type(b"MockLoader", (object,),
                                  {'get_data': mock_get_data})

    mock_loader_class = type(b"MockLoader", (object,),
                             {'get_data': mock_get_data})
   

# Generated at 2022-06-20 14:16:08.950555
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf, PSModuleDepFinder)
    assert isinstance(psmdf.ps_modules, dict)
    assert isinstance(psmdf.cs_utils_wrapper, dict)
    assert isinstance(psmdf.cs_utils_module, dict)
    assert isinstance(psmdf.exec_scripts, dict)
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False

    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_cs_in_ps_module, list)
    assert isinstance(psmdf._re_ps_module, list)

# Generated at 2022-06-20 14:16:14.788933
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Unit test for PSModuleDepFinder class
    :return:
    """
    ps_module_dep_finder = PSModuleDepFinder()

    # Unit test parse_version_match method
    version = "2.0"
    ps_module_dep_finder._parse_version_match(match=version, attribute="ps_version")
    assert ps_module_dep_finder.ps_version == version


# Generated at 2022-06-20 14:16:22.059095
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_exec_base = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_ps_module_utils')
    shutil.rmtree(mu_exec_base, ignore_errors=True)
    os.makedirs(mu_exec_base)
    mu_file = os.path.join(mu_exec_base, 'test_ps_module_utils.psm1')
    with open(mu_file, 'wb') as f:
        f.write(b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.MyCoolModuleUtil')
    os.environ['ANSIBLE_MODULE_UTILS'] = mu_exec_base

# Generated at 2022-06-20 14:16:33.232553
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert(dep_finder.ps_modules == dict())
    assert(dep_finder.cs_utils_module == dict())
    assert(dep_finder.cs_utils_wrapper == dict())
    assert(dep_finder.ps_version == None)
    assert(dep_finder.os_version == None)
    assert(dep_finder.become == False)

    for pattern in dep_finder._re_cs_module:
        match = pattern.match("using Ansible.ModuleUtils.Powershell;\n")
        assert(match.group(1) == "Ansible.ModuleUtils.Powershell")
        assert(match.group(2) == "Ansible.ModuleUtils.Powershell")
        assert(match.group(3) == None)

       

# Generated at 2022-06-20 14:16:38.936216
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder



# Generated at 2022-06-20 14:16:45.264796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    with pytest.raises(AnsibleError) as excinfo:
        finder = PSModuleDepFinder()
        finder.scan_module(b"#AnsibleRequires -CSharpUtil Ansible.Unavailable")

    assert excinfo.match('Could not find imported module support code for \'Ansible.Unavailable\'')


# Generated at 2022-06-20 14:16:48.071176
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmd_find = PSModuleDepFinder()
    assert pmd_find is not None


# Generated at 2022-06-20 14:16:57.418828
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    finder = PSModuleDepFinder()
    from ansible.errors import AnsibleError
    try:
        finder.scan_exec_script("pshell")
    except AnsibleError as ex:
        if os.path.join("lib", "ansible", "executor", "powershell", "pshell.ps1") not in str(ex):
            raise ex
    else:
        raise Exception("AnsibleError not raised")

    from ansible.module_utils import basic
    test_data = open(resource_from_fqcr(basic.__name__, "basic.py"), "rb").read()
    finder.scan_module(test_data, "test_module_name", wrapper=False, powershell=True)

# Generated at 2022-06-20 14:17:05.067402
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert(p.ps_modules == {})
    assert(p.ps_version is None)
    assert(p.os_version is None)
    assert(p.become == False)
    assert(p.cs_utils_wrapper == {})
    assert(p.cs_utils_module == {})
    assert(p.exec_scripts == {})

# Unit test to scan a PowerShell module

# Generated at 2022-06-20 14:17:34.706536
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    args = ['$input', '$input.Remove("Version")']
    obj = PSModuleDepFinder()
    data = ""
    fqn = None
    wrapper=False
    powershell=True
    obj.scan_module(data, fqn, wrapper, powershell)
    assert obj.ps_modules == {}
    assert obj.exec_scripts == {}
    assert obj.cs_utils_wrapper == {}
    assert obj.cs_utils_module == {}

# Generated at 2022-06-20 14:17:47.232298
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module
    assert dep_finder._re_cs_in_ps_module
    assert dep_finder._re_ps_module
    assert dep_finder._re_wrapper
    assert dep_finder._re_ps_version
    assert dep_finder._re_os_version
    assert dep_finder._re_become


# Finds the dependencies of module_data, which can be a

# Generated at 2022-06-20 14:17:58.298095
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import psutil
    ps = PSModuleDepFinder()
    assert len(ps.exec_scripts) == 0
    ps.scan_exec_script('powershell')
    assert len(ps.exec_scripts) == 1
    assert ps.exec_scripts['powershell'] == pkgutil.get_data("ansible.executor.powershell", "powershell.ps1")



# Generated at 2022-06-20 14:18:08.550928
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    path = resource_from_fqcr('ansible.plugins.action', 'jboss', 'jboss.py')
    data = _slurp(path)
    finder.scan_module(data, fqn=to_text('ansible_collections.jboss.jboss.plugins.action.jboss'))

    assert to_native(finder.ps_modules['Ansible.ModuleUtils.JBoss.Utils']['path']).endswith(
        '/ansible/plugins/module_utils/jboss/utils.psm1') is True


# Generated at 2022-06-20 14:18:15.376191
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    from ansible.module_utils._text import to_text

    class ModuleData(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, name, ps_modules_added, cs_modules_added, cs_wrappers_added, exec_scripts_added):
            self.name = name
            self._ps_modules_added = ps_modules_added
            self._cs_modules_added = cs_modules_added
            self._cs_wrappers_added = cs_wrappers_added
            self._exec_scripts_added = exec_scripts_added

        @property
        def data(self):
            return pkgutil.get_data('ansible.plugins.modules', self.name)


# Generated at 2022-06-20 14:18:22.713259
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = to_bytes("""
$MyGlobal = 1
# AnsibleRequires -PowerShell Ansible.ModuleUtils.Windows
# AnsibleRequires -CSharpUtil ansible_collections.community.general.plugins.module_utils.windows
# AnsibleRequires -CSharpUtil ..module_utils.windows_defs
# Requires -Module Ansible.ModuleUtils.Windows
# Requires -Module Ansible.ModuleUtils.GoodModule
# Requires -Module Ansible.ModuleUtils.CSharp
Add-MyFunction -Argument MyArgument
""")

# Generated at 2022-06-20 14:18:32.355214
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module("""
#Requires -Module Ansible.ModuleUtils.common_utils
#Requires -Module Ansible.ModuleUtils.compare_utils
#Requires -Module Ansible.ModuleUtils.helpers
#Requires -Module Ansible.ModuleUtils.network_utils
#Requires -Module Ansible.ModuleUtils.powerstate
#Requires -Module Ansible.ModuleUtils.connection_plugins_common
#Requires -Module Ansible.ModuleUtils.windows_vars
#Requires -Module Ansible.ModuleUtils.windows_compat
#Requires -Module Ansible.ModuleUtils.powershell.compat
""", wrapper=True)

    assert len(finder.ps_modules) == 8

    finder = PSModuleDepFinder()
    finder.scan_module

# Generated at 2022-06-20 14:18:36.972510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    name = "test_name"
    try:
        test_obj.scan_exec_script(name)
    except Exception as e:
        print(e)


# Generated at 2022-06-20 14:18:48.059068
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def run_command_mock(self, cmd, args, prompt, answer, checkrc=True, executable=None):
        # NOTE: this removes the dependency on ansible.utils.module_docs_fragments
        if args['_raw_params'] == '$PSVersionTable':
            return json.dumps({'PSVersion': '5.1.17134.590'})
        elif args['_raw_params'] == "Get-Command ConvertTo-Json":
            # indicate if ConvertTo-Json without an output encoding param is available
            return 'ConvertTo-Json' if self._use_convertto_json_without_encoding else ''

        # NOTE: this removes the dependency on ansible.modules.remote_management.azure

# Generated at 2022-06-20 14:18:56.706259
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become == False

    assert len(finder._re_cs_module) == 1
    for pattern in finder._re_cs_module:
        assert pattern.match(b'using Ansible.ModuleUtils.{name};') is not None
        assert pattern.match(b'using ansible_collections.{namespace}.{collection}.plugins.module_utils.{name};') is not None


# Generated at 2022-06-20 14:19:13.537308
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert hasattr(PSModuleDepFinder, 'ps_modules')



# Generated at 2022-06-20 14:19:23.222291
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # ensure that we can catch errors with ps module
    def _load_module_util_fail(name, *args, **kwargs):
        raise IOError()

    module_script = """#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz"""
    module_data = to_bytes(module_script, errors='surrogate_or_strict')

    finder = PSModuleDepFinder()

    def test_bad_module_util(module_data):
        # use a fake import to trigger success on all but the last module util
        finder.ps_modules = {
            "Ansible.ModuleUtils.Foo": {},
            "Ansible.ModuleUtils.Bar": {},
        }


# Generated at 2022-06-20 14:19:23.719191
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-20 14:19:25.469786
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    result = psmdf.scan_exec_script('with_random')
    assert(result == None)

# Generated at 2022-06-20 14:19:37.038900
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Assert that the attributes that are initialized inside the constructor
    # actually exist
    ps_module_dep_finder = PSModuleDepFinder()
    assert hasattr(ps_module_dep_finder, 'ps_modules')
    assert hasattr(ps_module_dep_finder, 'exec_scripts')
    assert hasattr(ps_module_dep_finder, 'cs_utils_wrapper')
    assert hasattr(ps_module_dep_finder, 'cs_utils_module')
    assert hasattr(ps_module_dep_finder, 'ps_version')
    assert hasattr(ps_module_dep_finder, 'os_version')
    assert hasattr(ps_module_dep_finder, 'become')



# Generated at 2022-06-20 14:19:47.110083
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.basic import AnsiballzArchive, AnsiballzError
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.plugins.loader import ps_module_utils_loader
    FQCN = 'network.nxos.nxos_ping'

    module_name = to_bytes(os.path.basename(FQCN))
    module_args = dict(
        dest=to_bytes('foo'),
        msg=to_bytes('test message')
    )
    conn_info = dict()

    from ansible.plugins.loader import action_loader

    action_plugin = action_loader.get(FQCN, connection=None)
    action_plugin

# Generated at 2022-06-20 14:19:52.939610
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    c = PSModuleDepFinder()
    assert c.ps_modules == dict()
    assert c.ps_version is None
    assert c.os_version is None
    assert c.become is False
    assert c.cs_utils_wrapper == dict()
    assert c.cs_utils_module == dict()


# Generated at 2022-06-20 14:19:58.726033
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)



# Generated at 2022-06-20 14:20:08.693832
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()


# Generated at 2022-06-20 14:20:21.637853
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    mu_data_0_1 = to_bytes(b'#Requires -Module Ansible.ModuleUtils.Legacy.ModuleUtils.0.1\n#Requires -Version 5.1\n')
    mu_data_0_2 = to_bytes(b'#Requires -Module Ansible.ModuleUtils.Legacy.ModuleUtils.0.2')

    mu_data_0_1_psv = to_bytes(b'#Requires -Module Ansible.ModuleUtils.Legacy.ModuleUtils.0.1\n#Requires -Version 5.1')
    mu_data_0_2_psv = to_bytes(b'#Requires -Module Ansible.ModuleUtils.Legacy.ModuleUtils.0.2\n#Requires -Version 6.0\n')

    ps_module_data_0_1

# Generated at 2022-06-20 14:20:43.918964
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    scanner = PSModuleDepFinder()
    scanner.scan_module(b'#AnsibleRequires -PowerShell ansible_collections.testns.testcoll.plugins.module_utils.testmodu2')
    assert scanner.ps_modules == {
        'ansible_collections.testns.testcoll.plugins.module_utils.testmodu2': {
            'data': b'TestModule2\n#Requires -Version 4\n',
            'path': 'ansible_collections.testns.testcoll.plugins.module_utils.testmodu2',
        }
    }
    assert scanner.cs_utils_module == {}
    assert scanner.cs_utils_wrapper == {}
    assert scanner.ps_version is None
    assert scanner.os_version is None
    assert scanner.become is False


# Unit

# Generated at 2022-06-20 14:20:49.829738
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    scanner = PSModuleDepFinder()
    scanner.scan_module(b'#ansiblerequires -wrapper module_common', fqn="ansible_collections.namespace.collection.plugins.modules.module_common", wrapper=True, powershell=True)
    actual = scanner.exec_scripts['module_common']
    expected = b'\r\n$oForm = New-Object System.Windows.Forms.Form `\r\n    -Property @{Width=500; Height=200}\r\n$oForm.ShowDialog()\r\n'
    assert actual.rstrip() == expected


# Generated at 2022-06-20 14:20:51.453097
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # There is currently no unit test for this method
    pass

# Generated at 2022-06-20 14:20:57.821981
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print()
    print("testing 'PSModuleDepFinder.scan_exec_script'")
    print()
    data = pkgutil.get_data("ansible.executor.powershell", "basic.ps1")
    print("data:", to_text(data))
    print()
    p = PSModuleDepFinder()
    print("scanning basic.ps1 script")
    p.scan_exec_script("basic")
    print()
    print("scanning basic.ps1 script again")
    p.scan_exec_script("basic")
    print()


# Generated at 2022-06-20 14:21:03.914611
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ''' Unit test for constructor of class PSModuleDepFinder '''
    pmdf = PSModuleDepFinder()
    assert isinstance(pmdf.ps_modules, dict)
    assert isinstance(pmdf.exec_scripts, dict)
    assert len(pmdf.ps_modules) == 0
    assert len(pmdf.exec_scripts) == 0


# Generated at 2022-06-20 14:21:14.996170
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    required_properties = list()

    f = PSModuleDepFinder()
    for prop in "ps_modules exec_scripts cs_utils_wrapper cs_utils_module ps_version os_version become".split():
        required_properties.append(prop)
        if not hasattr(f, prop):
            raise AssertionError("The '%s' property is not set" % prop)

    if hasattr(f, "some_other_property"):
        raise AssertionError("The class has an extra property that is not needed")

    for prop in required_properties:
        delattr(f, prop)
        if hasattr(f, prop):
            raise AssertionError("The '%s' property could not be removed" % prop)
    f.__init__()


# Generated at 2022-06-20 14:21:21.918419
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Assert 'data' in class PSModuleDepFinder.scan_exec_script
    test0 = b"#!/usr/bin/env powershell\r\n"
    test1 = b"# Use PowerShell Core\r\n"
    test2 = b"# Use PowerShell Core\r\n"
    test3 = b"# Use PowerShell Core\r\n"
    test4 = b"# Use PowerShell Core\r\n"
    buffer = test0 + test1 + test2 + test3 + test4
    expected = {('stdout', buffer)}
    actual = _slurp(r"./ansible_collections/ansible/windows/plugins/modules/win_command/exec_wrapper.ps1")
    assert expected == actual



# Generated at 2022-06-20 14:21:31.067249
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    MU_PATH = 'test_PSModuleDepFinder_scan_module_MU_PATH'

    # First, we remain backward compat with the original way of requiring a module_util.
    # We also test the alternate casing of Requires, AnsibleRequires and CSharpUtil
    module_input = '''\
#Requires -Module Ansible.ModuleUtils.Test1

#AnsibleRequires -Powershell Ansible.ModuleUtils.Test2
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test3

#Requires -Modules Ansible.ModuleUtils.Test4

#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test5
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test6'''


# Generated at 2022-06-20 14:21:37.280946
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    # Unit test for method scan_exec_script of class PSModuleDepFinder
    #
    # Confirm that scan_exec_script returns expected result.
    #
    output = PSModuleDepFinder().scan_exec_script("powershell_plugin")
    assert output is None


# Generated at 2022-06-20 14:21:48.121775
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # constructor test
    module_dep_finder = PSModuleDepFinder()

    # test if the class is instantiated correctly
    assert isinstance(module_dep_finder, PSModuleDepFinder)
    assert module_dep_finder.ps_modules == dict()
    assert module_dep_finder.exec_scripts == dict()
    assert module_dep_finder.cs_utils_wrapper == dict()
    assert module_dep_finder.cs_utils_module == dict()
    assert module_dep_finder.ps_version is None
    assert module_dep_finder.os_version is None
    assert module_dep_finder.become is False

    # test the regexs
    assert isinstance(module_dep_finder._re_cs_module, list)
    assert isinstance(module_dep_finder._re_ps_module, list)

# Generated at 2022-06-20 14:22:15.777518
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module("""#Requires -Module Ansible.ModuleUtils.{name}
#Requires -Module Ansible.ModuleUtils.{name}
#Requires -Module ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}""")
    assert psmdf.ps_modules == {'Ansible.ModuleUtils.{name}': {'data': '', 'path': ''},
                                'ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}':
                                    {'data': '', 'path': ''}}
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}
    psmdf = PSModuleDepFinder()
   

# Generated at 2022-06-20 14:22:23.036614
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md.ps_modules == dict()
    assert md.cs_utils_wrapper == dict()
    assert md.cs_utils_module == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False



# Generated at 2022-06-20 14:22:29.278715
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    testargs = dict()
    testargs['name'] = u"win_service"
    psmoduledepfinder = PSModuleDepFinder()
    testargs['name'] = u'win_feature'
    psmoduledepfinder.scan_exec_script(testargs['name'])
    assert psmoduledepfinder.exec_scripts[u'win_feature']

# Generated at 2022-06-20 14:22:41.896140
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = "data"
    name = "name"
    mock_find_plugin = MagicMock(return_value="psm1")
    with patch.object(ps_module_utils_loader, 'find_plugin', mock_find_plugin):
        with patch.object(pkgutil, "get_data", autospec=True, return_value=data):
            with patch.object(PSModuleDepFinder, "scan_module", autospec=True) as mock_scan_module:
                dep_finder = PSModuleDepFinder()
                dep_finder.exec_scripts = {}
                dep_finder.scan_exec_script(name)
                mock_scan_module.assert_any_call(data, wrapper=True, powershell=True)
                assert dep_finder.exec_scripts == {name: to_bytes(data)}



# Generated at 2022-06-20 14:22:44.795800
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	# Call the method and test the output
	PSModuleDepFinder.scan_exec_script('nonexistent_file')


# Generated at 2022-06-20 14:22:57.533124
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for scan_module() method of class PSModuleDepFinder
    # Args:
    #    module_data (str): Module data used to find dependencies
    #    fqn (str): Fully qualified name of the module
    #    wrapper (bool): True if it is a wrapper
    #    powershell (bool): True if it is a powershell module

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module("#AnsibleRequires -PowerShell Ansible.ModuleUtils.PowerShell.Archive")
    assert len(ps_module_dep_finder.ps_modules.keys()) == 1
    assert not ps_module_dep_finder.cs_utils_module
    assert not ps_module_dep_finder.cs_utils_wrapper

    ps_module_dep_

# Generated at 2022-06-20 14:22:58.845330
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)


# Generated at 2022-06-20 14:23:09.872163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_name=os.path.basename(__file__)
    print("*** running test {}".format(test_name))
    script_name = "pskube.ps1"
    finder = PSModuleDepFinder()
    finder.scan_exec_script(script_name)

    assert script_name in finder.exec_scripts.keys()
    assert len(finder.exec_scripts.keys()) > 0

    # if the finder finds a dependency it calls scan_module on it.
    # this particular script does not have any dependencies
    assert len(finder.cs_utils_module.keys()) == 0


# Generated at 2022-06-20 14:23:18.720535
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_md = PSModuleDepFinder()
    # Exec script exists and should return
    ps_md.scan_exec_script('serial_json')
    assert ps_md.exec_scripts['serial_json'] is not None
    # Exec script does not exist, should throw an error
    try:
        ps_md.scan_exec_script('blah')
    except AnsibleError as e:
        assert "Could not find executor powershell script" in to_text(e)
    else:
        assert False


# Generated at 2022-06-20 14:23:30.374061
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import mock
    import ansible.executor.powershell

    finder = PSModuleDepFinder()
    
    assert finder.exec_scripts == {}

    finder.exec_scripts["TestScript"] = "test"

    assert finder.exec_scripts == {"TestScript":"test"}

    with mock.patch.object(ansible.executor.powershell, 'pkgutil') as mock_pkgutil:
        # Test branch where pkg_data is not None
        mock_pkgutil.get_data.return_value = "test"
        finder.scan_exec_script("TestScript")

        assert finder.exec_scripts == {"TestScript":"test"}


# Generated at 2022-06-20 14:23:53.256979
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:59.515607
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert '#Requires -Module Ansible.ModuleUtils.A' in dep_finder._re_ps_module[0].pattern
    assert '#AnsibleRequires -PowerShell Ansible.ModuleUtils.A' in dep_finder._re_ps_module[1].pattern
    assert 'using Ansible.A;' in dep_finder._re_cs_in_ps_module[0].pattern
   

# Generated at 2022-06-20 14:24:08.850171
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

    assert dep_finder._re_cs_module[0].replace(b"\\", b"") == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                                       r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-20 14:24:09.888113
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-20 14:24:18.083847
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:30.277774
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import json
    import shutil
    # It's not possible to pass param `fqn` from here
    # as we don't know the module's FQN
    # While running this test, pls make sure you set the value of
    # `module_name` to valid module's FQN
    module_name = 'test_module'

# Generated at 2022-06-20 14:24:40.695190
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    import types
    import warnings

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping

    from ansible.module_utils.plugins.powershell.objects import SharedGeneratedModule
    from ansible.module_utils.powershell import psutil

    import pytest

    from units.compat import unittest

    class TestPSModuleDepFinderScanModule(unittest.TestCase):
        """
        A class that contains a series of unit tests for the method scan_module of class PSModuleDepFinder
        """
        def setUp(self):
            # As scan_module() is an instance method of class PSModuleDepFinder, the instantiation of this class
            # needed to be done only once.
            self.ps_

# Generated at 2022-06-20 14:24:44.976044
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    assert b"\r\n" in psModuleDepFinder.scan_exec_script("Scripts_GetAnsibleModule")


# Generated at 2022-06-20 14:24:49.147859
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script of class PSModuleDepFinder
    test = PSModuleDepFinder()
    test.scan_exec_script("posh-winrm")
    assert test.exec_scripts["posh-winrm"]

# Generated at 2022-06-20 14:24:59.997633
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert not finder.become
    assert isinstance(finder._re_cs_module, list)
    assert isinstance(finder._re_cs_in_ps_module, list)
    assert isinstance(finder._re_ps_module, list)
    assert isinstance(finder._re_wrapper, re._pattern_type)
    assert isinstance(finder._re_ps_version, re._pattern_type)
    assert isinstance(finder._re_os_version, re._pattern_type)

# Generated at 2022-06-20 14:25:13.551570
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder
    assert isinstance(finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:25:20.743854
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Not a full test, just coverage for constructor

    from ansible.plugins.ps_module_utils import ps_module_utils_loader
    from ansible.plugins.loader import ps_module_loader

    ps_module_utils_loader.reload()
    ps_module_loader.reload()

    PSModuleDepFinder()
