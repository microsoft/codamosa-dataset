

# Generated at 2022-06-20 14:15:58.461993
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()



# Generated at 2022-06-20 14:16:02.428480
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('TestModule')
    assert set(dep_finder.exec_scripts) == {'TestModule'}


# Generated at 2022-06-20 14:16:09.040358
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert ps_dep_finder.ps_modules == dict()
    assert ps_dep_finder.cs_utils_wrapper == dict()
    assert ps_dep_finder.cs_utils_module == dict()
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert not ps_dep_finder.become
    assert len(ps_dep_finder.exec_scripts) == 0



# Generated at 2022-06-20 14:16:13.592009
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    TestModuleDeps = PSModuleDepFinder()
    assert TestModuleDeps.ps_modules == dict()
    assert TestModuleDeps.exec_scripts == dict()
    assert TestModuleDeps.cs_utils_wrapper == dict()
    assert TestModuleDeps.cs_utils_module == dict()



# Generated at 2022-06-20 14:16:15.461053
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result = PSModuleDepFinder().scan_exec_script(name="test")
    assert result is None


# Generated at 2022-06-20 14:16:20.046644
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arguments of type dict are passed by reference
    bypass_dict = dict()
    bypass_dict['exec_scripts_result'] = dict()
    bypass_dict['exec_scripts_result']['name'] = 'exec_scripts_result'
    bypass_dict['exec_scripts_result']['data'] = 'exec_scripts_result_data'
    bypass_dict['exec_scripts_result']['path'] = 'exec_scripts_result_path'
    bypass_dict['exec_scripts_result']['optional'] = True

    bypass_dict['exec_scripts_result']['scan_module_result'] = dict()
    bypass_dict['exec_scripts_result']['scan_module_result']['name'] = 'scan_module_result_name'

# Generated at 2022-06-20 14:16:24.425287
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Test instantiation of the PSModuleDepFinder class
    """
    dep_finder = PSModuleDepFinder()

    assert isinstance(dep_finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:16:38.792539
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for method scan_exec_script of class PSModuleDepFinder"""
    # This method unit test tests the scan_exec_script method of
    # PSModuleDepFinder class, which is responsible for scanning executor
    # powershells for scripts used in the module exec side. It also scans
    # these scripts for any dependencies.
    #
    # The scan_exec_script method is called from the scan_module method if
    # the module contains '#AnsibleRequires -Wrapper'

    # Create an instance of PSModuleDepFinder
    psm_depfinder = PSModuleDepFinder()
    assert psm_depfinder.exec_scripts == dict()

    # Test scan_exec_script(self, name) with a valid name
    name = 'Utils'

# Generated at 2022-06-20 14:16:52.560661
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:17:07.984048
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import module_loader
    from ansible.executor.powershell.impl_base import Base

    def _slurp(path):
        with open(path, "rb") as f:
            return f.read()

    def _strip_comments(data):
        data = re.sub(b'#.*\n', b'\n', data)
        data = re.sub(b'\n\s*\n', b'\n', data)
        data = re.sub(b'\n[ \t]*\n', b'\n', data)
        return data


# Generated at 2022-06-20 14:17:32.584640
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    data = b'# Requires -Modules Ansible.ModuleUtils.Common'
    psmdf.scan_module(data, fqn='ansible_collections.foo.bar')
    assert psmdf.ps_modules['Ansible.ModuleUtils.Common']['data'].startswith(b'#')
    assert psmdf.ps_modules['Ansible.ModuleUtils.Common']['path'].endswith('.psm1')


# Generated at 2022-06-20 14:17:46.045823
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 14:17:54.050945
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    output = []
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('powershell_common')
    output.append(psmdf.exec_scripts['powershell_common'].split())
    output.append(psmdf.ps_modules.keys())

# Generated at 2022-06-20 14:18:06.262603
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Manually create the dep finder and load in the required utils. This is the
    # equivalent of calling the init() method.
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("action_plugins")
    dep_finder.scan_exec_script("connection_plugins")
    dep_finder.scan_exec_script("lookup_plugins")
    dep_finder.scan_exec_script("shell_plugins")
    dep_finder.scan_exec_script("test_plugins")

    # Manually create the list of expected results to check against.

# Generated at 2022-06-20 14:18:22.583110
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    m = {"type": "ansible", "collection": "collection-name", "module_name": "module_name", }

    # Wrapper module
    finder.scan_module(b'#AnsibleRequires -Wrapper', fqn='ansible.module_utils.module_name')

    assert finder.exec_scripts == {'module_name': b''}

    # Wrapper module with comments
    finder.scan_module(b'#AnsibleRequires -Wrapper', fqn='ansible.module_utils.module_name')

    assert finder.exec_scripts == {'module_name': b''}

    # Wrapper module with a comment

# Generated at 2022-06-20 14:18:36.077562
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:18:47.641745
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # check the base C# module_utils
    module_util_data = pkgutil.get_data("ansible.module_utils.basic", "basic.cs")
    finder.scan_module(module_util_data, wrapper=False, powershell=False)
    assert len(finder.cs_utils_module) == 1
    assert 'Ansible.ModuleUtils.Basic' in finder.cs_utils_module
    # check the base PowerShell module_utils
    module_util_data = pkgutil.get_data("ansible.module_utils.basic", "basic.psm1")
    finder.scan_module(module_util_data, wrapper=False, powershell=True)
    assert len(finder.ps_modules) == 4

# Generated at 2022-06-20 14:19:01.765311
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:19:16.335252
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    test_module = to_bytes("""#! /usr/bin/env ansible-runner
#ansiblerequires -csharputil Ansible.TestModule
#ansiblerequires -powershell Ansible.TestModule
#ansiblerequires -powershell .TestModule
#ansiblerequires -powershell ansible_collections.testns.testcoll.plugins.module_utils.TestModule
""")
    finder = PSModuleDepFinder()
    fqn = to_text("ansible_collections.testns.testcoll.plugins.modules.test_module")
    finder.scan_module(test_module, fqn=fqn)
    assert finder.ps_modules[to_text("Ansible.TestModule")]
    assert finder.ps_modules[to_text(".TestModule")]

# Generated at 2022-06-20 14:19:24.673418
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:19:38.017102
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdep = PSModuleDepFinder()


# Generated at 2022-06-20 14:19:40.199148
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # There is no unit test for this method
    pass

# Generated at 2022-06-20 14:19:47.009772
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()

    psmd.exec_scripts = {}

    try:
        psmd.scan_exec_script('not_found')

    except AnsibleError as e:
        assert 'Could not find executor powershell script for \'not_found\'' == e.message
        assert {} == psmd.exec_scripts

    # Now try to find a script
    psmd.scan_exec_script('executor')

    assert 1 == len(psmd.exec_scripts)
    assert 'executor' in psmd.exec_scripts



# Generated at 2022-06-20 14:19:53.728907
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    d = PSModuleDepFinder()
    assert len(d.ps_modules) == 0
    assert len(d.cs_utils_wrapper) == 0
    assert len(d.cs_utils_module) == 0
    assert d.ps_version is None
    assert d.os_version is None
    assert d.become is False


# https://stackoverflow.com/a/11592227

# Generated at 2022-06-20 14:19:55.780995
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    instance = PSModuleDepFinder()
    assert instance


# Generated at 2022-06-20 14:20:06.722084
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    sut = PSModuleDepFinder()
    sut.scan_exec_script("win_service")
    assert isinstance(sut.exec_scripts['win_service'], bytes)
    assert sut.exec_scripts['win_service'].startswith(b'<#')
    assert sut.exec_scripts['win_service'].endswith(b'#>\n')
    assert sut.become

    assert 'ansible.module_utils.ansible_free_space' in sut.ps_modules.keys()
    # assert 'ansible_collections.ansible.builtin.plugins.module_utils.network.common.utils' in sut.ps_modules.keys()

# Generated at 2022-06-20 14:20:20.479363
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def test_scan_module(ps_module_dep_finder, module_data, fqn, powershell, wrapper):
        ps_module_dep_finder.scan_module(to_bytes(module_data), to_text(fqn), wrapper=wrapper, powershell=powershell)

    def test_scan_exec_script(ps_module_dep_finder, script_name):
        ps_module_dep_finder.scan_exec_script(to_bytes(script_name))

    #
    # Test PSModuleDepFinder.scan_exec_script()
    #

    ps_module_dep_finder = PSModuleDepFinder()

    # Verify scan_exec_script() can successfully find a script
    test_scan_exec_script(ps_module_dep_finder, "basic")

    # Verify scan_exec_script

# Generated at 2022-06-20 14:20:29.467116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder.scan_exec_script("docker_common")
    assert depFinder.exec_scripts.get("docker_common")
    assert depFinder.cs_utils_wrapper.get("ansible_collections.community.general.plugins.module_utils.docker_utils")


# Generated at 2022-06-20 14:20:31.264934
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_obj = PSModuleDepFinder()
    assert True



# Generated at 2022-06-20 14:20:37.818294
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # We do not generate code coverage for unit tests because of time taken to run the tests
    # As the utils are tested using code coverage when the modules are run we just
    # need to ensure the methods of the utils are exposed
    # There is no code coverage in the unit tests.
    assert PSModuleDepFinder.scan_exec_script is not None

test_PSModuleDepFinder_scan_exec_script()

# Generated at 2022-06-20 14:20:54.552537
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()

    scripts = ["basic", "command", "debug", "json", "powershell", "script", "shell", "win_command", "win_shell"]
    for s in scripts:
        mdf.scan_exec_script(s)

    assert len(mdf.exec_scripts.keys()) == len(scripts)


# Generated at 2022-06-20 14:20:55.409505
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True



# Generated at 2022-06-20 14:21:06.371879
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    # add comments
    assert '#Requires -Module x' == to_text(_add_comment('#Requires -Module x'))
    assert '#Requires -Module x\n# Requires -Module y' == to_text(_add_comment('#Requires -Module x\n#Requires -Module y'))
    assert '#Requires -Module x\n# Requires -Module y\n#Requires -Module z' == to_text(_add_comment('#Requires -Module x\n#Requires -Module y\n#Requires -Module z'))

    # strip comments
    assert '#Requires -Module x' == to_text(_strip_comments(b'#Requires -Module x'))

# Generated at 2022-06-20 14:21:15.712166
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup a basic PSModuleDepFinder and add an exec script
    ps = PSModuleDepFinder()
    name = 'Test'
    ps.scan_exec_script(name)

    # Ensure the script was added
    assert name in ps.exec_scripts
    # Ensure the script was scanned properly
    assert ps.exec_scripts[name] == b'Initialize-ModuleUtil -PipelineState $PSCmdlet.GetVariableValue(\'$script:PipelineState\') -ModuleWrapperPath $MyInvocation.MyCommand.Path'

    # Ensure no error occurs if the script is added again
    ps.scan_exec_script(name)


# Generated at 2022-06-20 14:21:27.440345
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:21:44.246253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script("powershell.ps1")

    # assert expected exec_scripts
    assert len(psModuleDepFinder.exec_scripts) == 1
    assert "powershell.ps1" in psModuleDepFinder.exec_scripts
    assert b'powershell.ps1' in psModuleDepFinder.exec_scripts['powershell.ps1']

    # assert expected ps_modules
    assert len(psModuleDepFinder.ps_modules) == 2
    assert "Ansible.ModuleUtils.Common.Errors" in psModuleDepFinder.ps_modules
    assert "Ansible.ModuleUtils.Common.Match" in psModuleDepFinder.ps_modules

    # assert expected cs_utils_wrapper

# Generated at 2022-06-20 14:21:54.910387
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    # This test is for scan_exec_script in anisble.module_utils.powershell.PSModuleDepFinder
    # The test generates a random string as a script name
    # It adds the file name to PSModuleDepfinder.exec_scripts
    # The test then checks if the file object is present in PSModuleDepfinder.exec_scripts
    # If the file object is present, the test returns True, else False
    #
    # This test cannot be run in Windows
    #

    if C.DEFAULT_JINJA2_NATIVE:
        pytest.skip("Skipped on windows. This test cannot be run on Windows as it deals with file names that are not Windows friendly")

    psmdf = PSModuleDepFinder()

# Generated at 2022-06-20 14:22:05.243523
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _strip_comments(b_data):
        new_data = b''
        in_string = False
        in_char = False
        in_comment = False
        in_here_string = False

        prev_char = b''
        for c in b_data:
            if in_string:
                if c == b'"' and prev_char != b'\\':
                    in_string = False
            elif in_char:
                if c == b"'" and prev_char != b'\\':
                    in_char = False
            elif in_here_string:
                if c == b'@' and prev_char == b'@':
                    if not in_comment:
                        in_here_string = False
                    in_comment = False
            elif c == b'#':
                in_comment = True


# Generated at 2022-06-20 14:22:17.573867
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common._collections_compat import OrderedDict

    class AnsiblePSModuleDepFinder:
        ps_modules = OrderedDict()
        cs_utils_wrapper = OrderedDict()

    ansible_ps_module_dep_finder = AnsiblePSModuleDepFinder()
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_module(b'#AnsibleRequires -Powershell ..module_utils.package1.module1.psm1')
    assert ansible_ps_module_dep_finder.ps_modules.keys() == ['.module_utils.package1.module1.psm1'], "Test #1"


# Generated at 2022-06-20 14:22:25.627282
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert dict() == ps_module_dep_finder.ps_modules
    assert dict() == ps_module_dep_finder.exec_scripts

    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn't needed
    assert dict() == ps_module_dep_finder.cs_utils_wrapper
    assert dict() == ps_module_dep_finder.cs_utils_module

    assert None is ps_module_dep_finder.ps_version
    assert None is ps_module_dep_finder.os_version
    assert False is ps_module_dep_finder.become


# Generated at 2022-06-20 14:22:44.136942
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    # PS module contains '#Requires -Module Ansible.ModuleUtils.{name}
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.TestUtil')
    assert len(dep_finder.ps_modules.keys()) == 1
    assert "Ansible.ModuleUtils.TestUtil" in dep_finder.ps_modules.keys()

    # PS module contains '#AnsibleRequires -Powershell Ansible.*' (or collections module_utils ref)
    dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.TestUtil')
    assert len(dep_finder.ps_modules.keys()) == 2
    assert "Ansible.ModuleUtils.TestUtil" in dep_finder

# Generated at 2022-06-20 14:22:46.312485
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()
    assert isinstance(module_finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:22:58.648245
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:59.441319
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True



# Generated at 2022-06-20 14:23:10.517724
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    print(psmdf)
    print(psmdf.ps_modules)
    print(psmdf.cs_utils_wrapper)
    print(psmdf.cs_utils_module)
    print(psmdf._re_cs_module)
    print(psmdf._re_cs_in_ps_module)
    print(psmdf._re_ps_module)
    print(psmdf._re_wrapper)
    print(psmdf._re_ps_version)
    print(psmdf._re_os_version)
    print(psmdf._re_become)


# Generated at 2022-06-20 14:23:16.228559
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("win_helper")
    assert "powershell_base64_decode" in psmdf.cs_utils_wrapper
    assert "/ansible/executor/powershell/win_helper.ps1" in psmdf.cs_utils_wrapper['powershell_base64_decode']['path']


# Generated at 2022-06-20 14:23:25.859940
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_data = b"""
#Requires -Module Microsoft.PowerShell.Management

#Requires
# -Module Microsoft.PowerShell.Management

#Requires -Module Ansible.ModuleUtils.PSVersion

#Requires -Module Ansible.Windows

using System;
using System.Net.Sockets;
using System.Net.WebSockets;
using Microsoft.PowerShell.Management;
using Ansible.Common.Collections;
using System.Net;
using System.About;

#Requires -Module Ansible.ModuleUtils.PSVersion

"""

# Generated at 2022-06-20 14:23:33.961304
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps_mod_finder = PSModuleDepFinder()
    ps_mod_data = b"""#Requires -Module Ansible.ModuleUtils.Facts
    #This is a test comment
    #AnsibleRequires -CSharpUtil ansible_collections.test.test.plugins.module_utils.test
    #AnsibleRequires -PowerShell ..module_utils.test
    #Requires -Module Ansible.ModuleUtils.Legacy
    #AnsibleRequires -Wrapper Test
    #AnsibleRequires -PowerShell Ansible.ModuleUtils.Test
    #Requires -Version 5.0.0
    #AnsibleRequires -CSharpUtil ..module_utils.test -Optional
    #AnsibleRequires -OSVersion 6.0.0
    #AnsibleRequires -Become
    """

    ps_mod_finder

# Generated at 2022-06-20 14:23:40.975373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")

# Generated at 2022-06-20 14:23:45.670586
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    m = PSModuleDepFinder()
    assert isinstance(m, PSModuleDepFinder)
    assert m.ps_modules == dict()
    assert m.cs_utils_wrapper == dict()
    assert m.cs_utils_module == dict()



# Generated at 2022-06-20 14:24:10.814595
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    try:
        md.scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.qa.test.module_utils.dummy')
    except Exception as err:
        assert False, "Unexpected exception scanning module: %s" % str(err)

    try:
        md.scan_module(b'#AnsibleRequires -Powershell Ansible.ModuleUtils.Dummy')
    except Exception as err:
        assert False, "Unexpected exception scanning module: %s" % str(err)

    try:
        md.scan_module(b'#AnsibleRequires -Powershell Ansible.ModuleUtils.Dummy -Optional')
    except Exception as err:
        assert False, "Unexpected exception scanning module: %s" % str(err)

# Generated at 2022-06-20 14:24:18.638415
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:30.503213
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.compat.tests import unittest

    class PSModuleDepFinderTestCase(unittest.TestCase):
        def setUp(self):
            self.ps_module_dep_finder = PSModuleDepFinder()

        @unittest.skipIf(not C.DEFAULT_DEBUG, "exec module checks are skipped unless debug is enabled")
        def test_scan_module_wrapper_powershell_true(self):
            data = b'\n#AnsibleRequires -Wrapper Test.ps1\n#AnsibleRequires -CSharpUtil Test.cs\n'
            self.ps_module_dep_finder.scan_module(data, wrapper=True, powershell=True)

            self.assertIn(b'Test.ps1', self.ps_module_dep_finder.exec_scripts)

       

# Generated at 2022-06-20 14:24:47.403600
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    # Test: Both the PS and CS module dependency are added when both are defined
    with open('test/files/PSModuleDepFinder_module_deps_both.psm1') as f:
        module_data = f.read().encode('utf-8')
    ps_module_dep_finder._re_cs_module = [re.compile(r'(?i)^using\s((Ansible\..+)|'
                                                     r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')]

# Generated at 2022-06-20 14:24:59.916260
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Execute the constructor without arguments to test the default values
    dep_finder = PSModuleDepFinder()

    # Verify default values
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module[0].match(to_bytes(r'using ansible_collections.namespace.collection.plugins.module_utils.module_util;')) is not None

# Generated at 2022-06-20 14:25:08.852250
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fmt = '(?!\.\.|ansible_collections).*?{}$'
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.drupal')
    assert 'Ansible.ModuleUtils.drupal' in dep_finder.ps_modules
    assert not dep_finder.cs_utils_module

    dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.drupal')
    assert 'Ansible.ModuleUtils.drupal' in dep_finder.ps_modules
    assert not dep_finder.cs_utils_module


# Generated at 2022-06-20 14:25:13.028278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # testing exec script scanning using a script known to have utils it references
    psdf = PSModuleDepFinder()
    psdf.scan_exec_script('basic')
    assert len(psdf.cs_utils_wrapper.keys()) == 1
    assert 'ansible.module_utils.basic' in psdf.cs_utils_wrapper



# Generated at 2022-06-20 14:25:26.374102
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # The test input is a sample of AnsibleModule.psm1. This test only checks for
    # the first Requires
    input_module_data = to_bytes("""
# Requires -Module Ansible.ModuleUtils.{name}
    """)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(input_module_data)
    # check that there are 5 utils in the dict
    assert len(dep_finder.ps_modules) == 5, "%d != 5" % len(dep_finder.ps_modules)
    # check that the first Require is in the dict