

# Generated at 2022-06-20 14:15:58.809073
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Testing method scan_module of class PSModuleDepFinder")
    #we define a basic psm1 module which returns 'Hello World'
    psm1_module = """# Requires -Module Ansible.ModuleUtils.MockModule

return "Hello World"
    """
    psm1_module_b64 = base64.b64encode(to_bytes(psm1_module))

    # we define a C# module which prints 'Hello World'

# Generated at 2022-06-20 14:16:01.120192
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert isinstance(pmdf, PSModuleDepFinder)


# Generated at 2022-06-20 14:16:06.596173
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script(name='Common')
    assert len(ps_module_dep_finder.exec_scripts) > 0


# Generated at 2022-06-20 14:16:17.458125
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scanning an executor script correctly sets the variables in the PSModuleDepFinder instance

    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:16:21.120310
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'')
    assert dep_finder.ps_modules == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become

# Generated at 2022-06-20 14:16:30.134351
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert ps_module_dep_finder._re_cs_module
    assert ps_module_dep_finder._re_cs_in_ps_module
    assert ps_module_dep_finder._re_ps_module
    assert ps_module_dep_finder._re_wrapper

# Generated at 2022-06-20 14:16:45.680990
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _init_scan_exec_script(scan_exec_script):
        def _scan_exec_script(name, *args, **kwargs):
            name_text = to_text(name)
            if name_text in self.exec_scripts.keys():
                return
            if name_text == 'test_exec_script':
                self.exec_scripts['test_exec_script'] = b'This is a test script'
                self.scan_module('Scan this text for additional dependencies', *args, **kwargs)
            else:
                raise AnsibleError("Could not find executor powershell script "
                                   "for '%s'" % name)
        return _scan_exec_script


# Generated at 2022-06-20 14:16:56.549649
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    def get_module_path(*args, **kwargs):
        module = os.path.realpath(__file__.replace('lib/ansible/modules/windows/win_uri.py', 'module_utils/pypsrp'))
        return module

    # Mock get_module_path function
    import ansible.module_utils.basic
    ansible.module_

# Generated at 2022-06-20 14:17:08.757998
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()

    assert depfinder.ps_modules == {}
    assert depfinder.exec_scripts == {}
    assert depfinder.cs_utils_wrapper == {}
    assert depfinder.cs_utils_module == {}
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False

    assert isinstance(depfinder._re_ps_module, list)
    assert len(depfinder._re_ps_module) == 2

    assert isinstance(depfinder._re_cs_in_ps_module, list)
    assert len(depfinder._re_cs_in_ps_module) == 1

    assert isinstance(depfinder._re_cs_module, list)
    assert len(depfinder._re_cs_module) == 1

   

# Generated at 2022-06-20 14:17:20.590781
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script("TestExecScript")
    assert(len(f.exec_scripts) == 1)
    assert(f.exec_scripts["TestExecScript"])
    assert(len(f.ps_modules) == 2)
    assert(f.ps_modules["Ansible.ModuleUtils.Foo"]['data'])
    assert(f.ps_modules["Ansible.ModuleUtils.Foo"]['path'])
    assert(f.ps_modules["Ansible.ModuleUtils.Bar"]['data'])
    assert(f.ps_modules["Ansible.ModuleUtils.Bar"]['path'])


# Generated at 2022-06-20 14:17:39.281407
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This test does not work without the file existing, so just skip it.
    # assert False
    pass


# Generated at 2022-06-20 14:17:49.464418
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    name = "GetFileInfo"
    try:
        ps_module_dep_finder.scan_exec_script(name)
    except AnsibleError as e:
        if "Could not find executor powershell script for '%s'" % name not in str(e):
            raise Exception("Expected exception message did not match")

    module_data = pkgutil.get_data("ansible.executor.powershell", "GetFileInfo.ps1")
    if module_data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for '%s'" % name)
    b_data = to_bytes(module_data)
    if C.DEFAULT_DEBUG:
        exec_script = b_data

# Generated at 2022-06-20 14:17:55.274154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = '''
    #Requires -Module Ansible.ModuleUtils.CM
    #Requires -Module Ansible.ModuleUtils.CM.Util
    #Requires -Module Ansible.ModuleUtils.CM
    '''
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data=module_data)
    assert ps_module_dep_finder.ps_modules == {'Ansible.ModuleUtils.CM': {'data': b'Test', 'path': 'Ansible.ModuleUtils.CM'},
                                               'Ansible.ModuleUtils.CM.Util': {'data': b'Test', 'path': 'Ansible.ModuleUtils.CM.Util'}}


# Generated at 2022-06-20 14:18:06.823415
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup test vars
    # Note that these tests are using the collection psdbp.powershell
    # So do not change any files like ps_module_utils_loader.py that are in the collections

    # Create dependent files used in the tests
    # Note Tests may not always be the same order
    # So the files need to be created on the fly
    m_fqn = 'psdbp.powershell.test_module'
    m_name = 'Test_Module'
    m_ext = '.psm1'
    m_path = 'lib/ansible/modules/windows/{m_name}/{m_name}{m_ext}'.format(**locals())

# Generated at 2022-06-20 14:18:15.865941
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # Scan an existing script and ensure we get data back
    finder.scan_exec_script('posh_base.ps1')
    assert len(finder.exec_scripts.keys()) == 1
    assert finder.exec_scripts['posh_base.ps1'] is not None


# Generated at 2022-06-20 14:18:17.074150
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()



# Generated at 2022-06-20 14:18:18.670829
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert (PSModuleDepFinder()) is not None


# Generated at 2022-06-20 14:18:26.841206
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder._re_cs_module
    assert ps_module_dep_finder._re_cs_in_ps_module
    assert ps_module_dep_finder._re_ps_module
    assert ps_module_dep_finder._re_wrapper
    assert ps_module_dep_finder._re_ps_version
    assert ps_module_dep_finder._re_os_version
    assert ps_module_dep_finder._re_become


# Generated at 2022-06-20 14:18:33.102121
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import copy
    import pytest

    from ansible.plugins.loader import ps_module_utils_loader

    pytestmark = pytest.mark.psmodule_depfinder

    # load a PS module and its deps
    data = pkgutil.get_data("ansible.plugins.modules", "test_ps_module.ps1")
    b_data = to_bytes(data)
    lines = b_data.split(b'\n')

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        data = b_data
    else:
        data = _strip_comments(b_data)


# Generated at 2022-06-20 14:18:35.083857
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test to cover PSModuleDepFinder.scan_module"""
    assert random.choice([True, False]), 'Randomly generated test failed'


# Generated at 2022-06-20 14:19:19.039098
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:19:29.441727
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    sut = PSModuleDepFinder()
    sut.scan_module(b"#Requires -Version 3.0\n#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.foo\n")
    assert 1 == len(sut.ps_modules)
    assert "ansible_collections.ns.coll.plugins.module_utils.foo" in sut.ps_modules
    assert "3.0" == sut.ps_version

# Generated at 2022-06-20 14:19:33.093442
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert(dep_finder is not None)

_BASE64_NUL = base64.b64encode(b'\x00').decode('ascii')
_BASE64_BEGIN = "BEGIN ANSIBLE MANAGED BLOCK\n"
_BASE64_END = "END ANSIBLE MANAGED BLOCK"
_COMMENT_PREFIX = '#' * 70



# Generated at 2022-06-20 14:19:40.584307
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    output_data = "test_data/output_scan_exec_script"
    output_data = open(output_data)
    data = output_data.read()
    data = data.split("\n", 1)
    assert data[1] == "    $copy_src_to_tmp_file = $null;"
    assert data[0] == "System.String"


# Method parse_version_match of class PSModuleDepFinder

# Generated at 2022-06-20 14:19:56.544762
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # build up the data from resources.psd1
    m = PSModuleDepFinder()
    data = _slurp("ansible_collections/ansible/fortios/plugins/module_utils/network/fortios/fortios.psd1")
    d = json.loads(to_text(data))
    for resource in d['Resources']:
        if resource["Name"].endswith("psm1"):
            m.scan_module(to_bytes(resource["Name"]), fqn="ansible_collections.ansible.fortios.plugins.module_utils.network.fortios.fortios")
    # Scan all the module_utils (and their module_utils) that we need to properly
    # handle the fortios module

# Generated at 2022-06-20 14:19:58.623574
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder_obj = PSModuleDepFinder()
    assert finder_obj

# Generated at 2022-06-20 14:20:01.311232
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None
    assert isinstance(dep_finder, object)


# Generated at 2022-06-20 14:20:17.273398
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    assert psmdf.ps_modules == {}
    assert psmdf.exec_scripts == {}
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become
    assert len(psmdf._re_cs_module) == 1
    assert len(psmdf._re_cs_in_ps_module) == 1
    assert len(psmdf._re_ps_module) == 2
    assert psmdf._re_wrapper.pattern != ''
    assert psmdf._re_ps_version.pattern != ''
    assert psmdf._re_os_version.pattern != ''


# Generated at 2022-06-20 14:20:27.023600
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # This test is based on the assumption that the constructor of this class
    # has not been changed.
    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert len(psmdf.exec_scripts) == 0
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False



# Generated at 2022-06-20 14:20:27.861279
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()


# Generated at 2022-06-20 14:20:57.509264
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None
    assert isinstance(dep_finder.ps_modules, dict)
    assert isinstance(dep_finder.cs_utils_module, dict)
    assert isinstance(dep_finder.cs_utils_wrapper, dict)
    assert isinstance(dep_finder.ps_version, type(None))
    assert isinstance(dep_finder.os_version, type(None))
    assert isinstance(dep_finder.become, bool)
    assert isinstance(dep_finder._re_cs_module, list)
    assert isinstance(dep_finder._re_cs_in_ps_module, list)
    assert isinstance(dep_finder._re_ps_module, list)

# Generated at 2022-06-20 14:21:03.059467
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script("CommandBasedPowerShellHost")

    assert len(psmd.exec_scripts.keys()) == 1
    assert len(psmd.ps_modules.keys()) == 6
    assert len(psmd.cs_utils_wrapper.keys()) == 0



# Generated at 2022-06-20 14:21:14.444914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil
    import os

    class AnsibleModule(object):
        def __init__(self, module_data, fqn=None, wrapper=False, powershell=True):
            self.lines = module_data.split('\n')
            self.module_utils = set()
            if wrapper:
                self.cs_utils = self.cs_utils_wrapper
            else:
                self.cs_utils = self.cs_utils_module


# Generated at 2022-06-20 14:21:15.048755
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True



# Generated at 2022-06-20 14:21:22.137083
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This test case is trying to test the function scan_module of class PSModuleDepFinder from power_loader.
    # Test case is mentioned in test_load_module_util_in_python2_or_python3_without_ansible_module_utils
    with open("test/ansible_collections/ansible/test1/plugins/module_utils/a.psm1", "wb") as f:
        f.write(b'# Requires -Module Ansible.ModuleUtils.b\n')
    with open("test/ansible_collections/ansible/test1/plugins/module_utils/b.psm1", "wb") as f:
        f.write(b'# Requires -Module Ansible.ModuleUtils.c\n')

# Generated at 2022-06-20 14:21:31.219853
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder for testing
    psmdf = PSModuleDepFinder()
    # Ensure that the set of PowerShell module utils is empty
    assert len(psmdf.ps_modules) == 0
    # Ensure that the set of C# module utils is empty
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    # Ensure that the set of executor powershell scripts is empty
    assert len(psmdf.exec_scripts) == 0
    # Ensure the powershell version is unset
    assert psmdf.ps_version is None
    # Ensure the operating system version is unset
    assert psmdf.os_version is None
    # Ensure become is unset
    assert not psmdf.become

   

# Generated at 2022-06-20 14:21:33.645963
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    cs_wrappers = mdf.cs_utils_wrapper
    ps_module_utils = mdf.ps_modules
    assert set(cs_wrappers.keys()) == set()
    assert set(ps_module_utils.keys()) == set()



# Generated at 2022-06-20 14:21:46.066861
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_psm1 = load_fixture("powershell_test.psm1").read()
    finder = PSModuleDepFinder()
    test_ps_modules = {
        'Ansible.ModuleUtils.Common': {'data': load_fixture("Ansible.ModuleUtils.Common.psm1").read(),
                                       'path': 'c:\\temp\\Ansible.ModuleUtils.Common.psm1'}
    }
    finder.ps_modules = test_ps_modules
    finder.scan_module(test_psm1, fqn='ansible.module_package.module_name')
    finder.cs_utils_module = {
    }
    assert finder.ps_modules == test_ps_modules



# Generated at 2022-06-20 14:21:57.662370
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an instance of class PSModuleDepFinder with its default constructor
    dep_finder = PSModuleDepFinder()
    # Test with a module with an import of a builtin util
    module_data = '#requires -Module Ansible.ModuleUtils.Foo'
    dep_finder.scan_module(to_bytes(module_data),fqn=None)
    assert to_bytes(module_data) in dep_finder.ps_modules.values()
    # Test with no imports
    module_data = '#Nothing imported'
    dep_finder.scan_module(to_bytes(module_data), fqn=None)
    assert dep_finder.ps_modules == {}
    # Test multiple imports

# Generated at 2022-06-20 14:22:06.642627
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test for not setting ps_version, os_version, become
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}

    # Test for setting ps_version, os_version, become
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_version = "5.0"
    dep_finder.os_version = "10.0"
    dep_finder.become = True
    assert dep_finder.ps_version == "5.0"
   

# Generated at 2022-06-20 14:22:39.494590
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-20 14:22:53.234758
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module('''#AnsibleRequires -CSharpUtil ..module_utils.foo;''', fqn='ansible_collections.foo.bar.plugins.modules.baz')
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {'ansible_collections.foo.bar.plugins.module_utils.foo': {'path': 'ansible_collections.foo.bar.plugins.module_utils.foo', 'data': b''}}
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.ps

# Generated at 2022-06-20 14:23:04.373486
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()
    ps_module_data = '''
        function foo{
         #Requires -Module Ansible.ModuleUtils.foo
        }
        '''
    ps_dep_finder.scan_module(ps_module_data)
    assert ps_dep_finder.ps_modules['Ansible.ModuleUtils.foo']
    assert not ps_dep_finder.cs_utils_wrapper
    assert not ps_dep_finder.cs_utils_module
    assert 'foo' not in ps_dep_finder.ps_modules


# Generated at 2022-06-20 14:23:16.189844
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible_collections import mock
    from ansible.plugins.loader import test_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    import_module(mock.__name__)
    import_module(test_loader.__name__)
    import_module(AnsibleCollectionLoader.__name__)

    # noinspection PyUnresolvedReferences
    import ansible_collections
    # noinspection PyUnresolvedReferences
    import ansible.plugins.loader
    # noinspection PyUnresolvedReferences
    import ansible.utils.collection_loader

    # noinspection PyTypeChecker
    finder = PSModuleDepFinder()

    assert finder.ps_modules is not None
    assert finder.exec_scripts is not None


# Generated at 2022-06-20 14:23:20.414934
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)


# Generated at 2022-06-20 14:23:30.779202
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class MockModuleData:
        def __init__(self):
            self.data = ''

        def __enter__(self):
            return self.data

        def __exit__(self, *args):
            pass

    mock_module_data = MockModuleData()

    class MockPsModuleLoader:
        def __init__(self):
            self.mock_module_data = mock_module_data
            self.called = False

        @classmethod
        def find_plugin(cls, module_name, ext):
            cls.called = True
            module_names = ["ansible.module_utils.test", "ansible_collections.test.test_collection.plugins.module_utils.test_other"]
            if module_name not in module_names:
                return None
            else:
                return module_name



# Generated at 2022-06-20 14:23:33.994382
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Unit test for method scan_exec_script of class PSModuleDepFinder
    test_object = PSModuleDepFinder()
    test_object.scan_exec_script("bz2")

# Generated at 2022-06-20 14:23:40.995980
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup the mock file system
    mockfile_path = "ansible_collections/Collection/plugins/module_utils/test.cs"
    mockfile_data = "using namespace System.Management.Automation;"
    mockfile_path_abs = os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_module_utils", mockfile_path)
    os.makedirs(os.path.dirname(mockfile_path_abs))

    with open(mockfile_path_abs, "wb") as f:
        f.write(mockfile_data)


# Generated at 2022-06-20 14:23:52.671563
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Scan Module
    # finder.scan_module(b"testing string\n#Requires -Module Ansible.ModuleUtils.MyModule\n#Requires -version 1.0.0\n")
    # assert finder.ps_version == '1.0.0'
    # assert len(finder.ps_modules) == 1
    # assert finder.ps_modules.get('Ansible.ModuleUtils.MyModule', False)
    # finder.scan_module(
    #     b"testing string\n#Requires -Module Ansible.ModuleUtils.MyModule\n#Requires -version 1.0.0\n#requires -version 3.0.1\n")
    # assert finder.ps_version == '3.0.1'
    # assert len(finder

# Generated at 2022-06-20 14:24:00.609584
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()

    depFinder.scan_exec_script('test_name')

    assert len(depFinder.exec_scripts) == 1
    assert 'test_name' in depFinder.exec_scripts.keys()

# Generated at 2022-06-20 14:24:34.173607
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()


# Generated at 2022-06-20 14:24:48.656620
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    test PSModuleDepFinder constructor
    """
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert len(dep_finder._re_cs_module) == 1
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2

# Generated at 2022-06-20 14:24:59.956784
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:25:10.247037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Define the name for the executor powershell script that is used for this test.
    script_name = "test_script"
    # Define the content to be written to the script.
    script_content = "Test content from unit test."
    # Create a PSModuleDepFinder object.
    ps_module_dep_finder = PSModuleDepFinder()
    # Call the scan_exec_script method with the script_name as the parameter.
    ps_module_dep_finder.scan_exec_script(script_name)
    # Assert that the content of the script_name is the same as the script_content
    assert script_content in ps_module_dep_finder.exec_scripts[script_name]



# Generated at 2022-06-20 14:25:20.951720
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # It should return proper module_utils from ps_module
    src_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    dest_path = os.path.join(src_path, '..', '..')
    test_data = os.path.join(src_path, 'windows', 'data', 'powershell_module')
    with open(os.path.join(test_data, 'foss_util.psm1')) as f:
        req_module = f.read()
    def _slurp(pathname):
        with open(pathname) as f:
            data = f.read()
        return data
