

# Generated at 2022-06-20 14:15:59.856064
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    fqcr = 'ansible_collections.ns.coll.plugins.modules.user'
    resource = resource_from_fqcr(fqcr)
    module_path = resource.collection.module_utils_path
    path = os.path.join(module_path, fqcr, 'user.json')
    with open(path, 'r') as f:
        module_data = to_bytes(f.read())
    ps_module_dep_finder.scan_module(module_data)
    ps_module_dep_finder.scan_exec_script('Basic')
assert ps_module_dep_finder.exec_scripts

# Generated at 2022-06-20 14:16:10.305543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # Test parsing of ps_version
    finder.scan_exec_script("exec_wrapper")
    assert finder.ps_version == "4.0"
    assert finder.become

    # Make sure a second pass doesn't change anything
    finder.scan_exec_script("exec_wrapper")
    assert finder.ps_version == "4.0"
    assert finder.become

    # Test parsing of os_version
    finder.scan_exec_script("exec_wrapper_os")
    assert finder.os_version == "6.1.0"
    assert finder.become

    # Test parsing of C# module_util in ps module in exec
    finder.scan_exec_script("exec_wrapper_deps")

# Generated at 2022-06-20 14:16:12.400483
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    pytest.skip('this module is not yet covered by unit tests')


# Generated at 2022-06-20 14:16:15.507783
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)

# This shouldn't be called directly by anyone else.  It should only be used by the
# powershell_module_compile function below.

# Generated at 2022-06-20 14:16:16.249054
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    lib = PSModuleDepFinder()
    assert lib



# Generated at 2022-06-20 14:16:30.583330
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mu_name_1 = to_bytes("Ansible.ModuleUtils.Ab1.Module2.psm1")
    mu_data_1 = to_bytes("#Requires -Module Ansible.ModuleUtils.Ab1.Module1.psm1\n")

    mu_path_2 = os.path.join(C.DEFAULT_MODULE_UTILS_PATH, "Ab1", "Module1.psm1")
    mu_data_2 = to_bytes("#Requires -Module Ansible.ModuleUtils.Ab1.Module0.psm1\n")

    mu_path_3 = os.path.join(C.DEFAULT_MODULE_UTILS_PATH, "Ab1", "Module0.psm1")

# Generated at 2022-06-20 14:16:37.492942
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test will fail if any exception escapes.
    #
    # Arrange
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('microsoft.powershell.core.windows')



# Generated at 2022-06-20 14:16:44.998705
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(pkgutil.get_data("ansible.builtin.win_copy", to_native("win_copy.psm1")))
    assert len(dep_finder.ps_modules) == 1
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.exec_scripts) == 0

# Generated at 2022-06-20 14:16:56.275618
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import collections
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("network_common")
    assert isinstance(psmdf.exec_scripts, collections.abc.Mapping)
    assert len(psmdf.exec_scripts['network_common']) > 0
    assert isinstance(psmdf.ps_modules, collections.abc.Mapping)
    assert len(psmdf.ps_modules) == 1
    assert psmdf.ps_modules['Ansible.ModuleUtils.CommonUtils']["data"].startswith(b'#')
    assert psmdf.ps_modules['Ansible.ModuleUtils.CommonUtils']["path"].endswith("CommonUtils.psm1")

# Generated at 2022-06-20 14:17:04.628698
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of class PSModuleDepFinder
    obj = PSModuleDepFinder()

    # Unit test for method scan_exec_script of class PSModuleDepFinder
    if not isinstance(obj, PSModuleDepFinder):
        raise AssertionError("`PSModuleDepFinder` object does not match expectations")

    # Test if method scan_exec_script of class PSModuleDepFinder raises an Exception
    obj.scan_exec_script(name="foo")



# Generated at 2022-06-20 14:17:46.080012
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes

    # We need to inject this fake pkgutil.get_data in order to support the tests without
    # a proper python installation.
    # This is needed because this file is in a subdirectory of lib/ansible/module_utils/ and
    # pkgutil.get_data has the following code:
    #       caller_path = os.path.abspath(caller_path)
    #       caller_dir = os.path.dirname(caller_path)
    #       pkgpath = self.get_loader(package or '__main__').get_filename(caller_dir)
    # with caller_path being the full path of this file.
    # Since the real call is made from lib/ansible/executor/powershell, getting the directory of this file


# Generated at 2022-06-20 14:17:52.516290
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    assert ps_dep_finder.ps_modules == {}
    assert ps_dep_finder.exec_scripts == {}
    assert ps_dep_finder.cs_utils_wrapper == {}
    assert ps_dep_finder.cs_utils_module == {}
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert ps_dep_finder.become is False
    assert len(ps_dep_finder._re_cs_module) == 1
    assert len(ps_dep_finder._re_cs_in_ps_module) == 1
    assert len(ps_dep_finder._re_ps_module) == 2
    assert ps_dep_finder._re_wrapper is not None
    assert ps_dep_finder._

# Generated at 2022-06-20 14:18:05.365291
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)
    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert isinstance(ps_module_dep_finder._re_cs_module, list)

# Generated at 2022-06-20 14:18:13.170224
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder is not None
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)
    assert isinstance(ps_module_dep_finder.ps_modules, dict)
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_module_dep_finder.cs_utils_module, dict)
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False

# Generated at 2022-06-20 14:18:15.710173
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("wrapper_main")
    assert type(psmdf.exec_scripts["wrapper_main"]) == type(b'')


# Generated at 2022-06-20 14:18:19.521668
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf
    assert 'scan_module' in dir(pmdf)
    assert 'scan_exec_script' in dir(pmdf)



# Generated at 2022-06-20 14:18:23.813917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert scan_exec_script(self, name) == fail, 'test fail'
    assert scan_exec_script(self, name) == fail, 'test fail'
    assert scan_exec_script(self, name) == fail, 'test fail'


# Generated at 2022-06-20 14:18:26.750452
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print(PSModuleDepFinder().scan_module(b'#AnsibleRequires -CSharpUtil Ansible.Windows.ConfigureRemotingForAnsible;'))


# Generated at 2022-06-20 14:18:33.032015
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mu1 = """using System;
    using ansible_collections.ac.ac_abc.plugins.module_utils.ac_abc_util;

    namespace Ansible
    {
        public class AcModule : AnsibleModule
        {
            private static AcAbcUtil util = new AcAbcUtil();

            public void Main()
            {
                util.Execute();
            }
        }
    }
    """


# Generated at 2022-06-20 14:18:37.192361
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    # test data
    
    
    
    
    
    
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script(name="module_defaults")
    psmd.scan_exec_script(name="exec_wrapper")
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    pass



# Generated at 2022-06-20 14:18:56.717688
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.exec_scripts) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert len(dep_finder._re_cs_in_ps_module) == 1
    assert len(dep_finder._re_ps_module) == 2
    assert len(dep_finder._re_cs_module) == 1
    assert dep_finder._re_wrapper is not None
    assert dep_finder._re_ps_version is not None
    assert dep_finder

# Generated at 2022-06-20 14:19:03.099820
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_mod_dep_finder = PSModuleDepFinder()
    assert ps_mod_dep_finder.ps_modules == dict()
    assert ps_mod_dep_finder.cs_utils_wrapper == dict()
    assert ps_mod_dep_finder.ps_version is None
    assert ps_mod_dep_finder.os_version is None
    assert ps_mod_dep_finder.become is False



# Generated at 2022-06-20 14:19:17.757219
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()
    assert obj._re_ps_module[0].pattern == b'(?i)^#\\s*requires\\s+\\-module(?:s?)\\s*(Ansible\\.ModuleUtils\\..+)'
    assert obj._re_cs_in_ps_module[0].pattern == b'(?i)^#\\s*ansiblerequires\\s+-csharputil\\s+((Ansible\\.[\\w\\.]+)|(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+)|(\\.[\\w\\.]+))(?P<optional>\\s+-Optional){0,1}'

# Generated at 2022-06-20 14:19:19.853799
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(None, fqn=None)
    assert True


# Generated at 2022-06-20 14:19:26.851207
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Minimal PS module
    import_module_util_module_data = to_bytes("""
#Requires -Module Ansible.ModuleUtils.LoggingPrereq
""")

    # Minimal CS module
    import_module_util_module_data_cs = to_bytes("""
// C# module_util reference in another C# util
using ansible_collections.test.test.plugins.module_utils.LoggingPrereq;
""")

    # Minimal CS module with relative path
    import_module_util_module_data_cs_rel = to_bytes("""
// C# module_util reference in another C# util
using ..module_utils.LoggingPrereq;
""")

    # Minimal CS module with absolute path

# Generated at 2022-06-20 14:19:39.950905
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pmdf = PSModuleDepFinder()
    pmdf.scan_exec_script("basic")
    assert pmdf.exec_scripts["basic"].startswith(b"$hostname = [System.Net.Dns]::GetHostName()")
    assert pmdf.ps_modules["Ansible.ModuleUtils.Basic"]["data"].startswith(b"# Requires -Modules Ansible.ModuleUtils.Powershell")
    assert pmdf.ps_modules["Ansible.ModuleUtils.Basic"]["path"].endswith("ansible/module_utils/powershell/basic.psm1")
    assert pmdf.cs_utils_wrapper["ansible_collections.microsoft.powershell.plugins.module_utils.basic"]["data"].startswith(b"# Load system modules")

# Generated at 2022-06-20 14:19:46.285679
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf is not None
    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_ps_module, list)
    assert isinstance(psmdf.cs_utils_wrapper, dict)
    assert isinstance(psmdf.cs_utils_module, dict)
    assert isinstance(psmdf.ps_modules, dict)
    assert isinstance(psmdf.exec_scripts, dict)



# Generated at 2022-06-20 14:19:54.031279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('generic')
    assert psmdf.exec_scripts.keys() == ['generic']
    assert psmdf.ps_modules['Ansible.ModuleUtils.Basic']['path'] == resource_from_fqcr('Ansible.ModuleUtils.Basic', '.', 'psm1')
    assert len(psmdf.cs_utils_wrapper.keys()) == 0


# Generated at 2022-06-20 14:20:00.015314
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert(dep_finder.ps_modules == dict())
    assert(dep_finder.ps_version is None)
    assert(dep_finder.os_version is None)
    assert(dep_finder.become is False)
    assert(dep_finder.exec_scripts == dict())



# Generated at 2022-06-20 14:20:09.246217
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common._text import to_bytes
    from ansible.module_utils.powershell.common import ps_module_utils_loader
    # test case 1:
    # PS module contains '#Requires -Module Ansible.ModuleUtils.*'
    # PS module contains '#AnsibleRequires -Powershell Ansible.*' (or collections module_utils ref)
    my_finder1 = PSModuleDepFinder()

# Generated at 2022-06-20 14:20:37.869433
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    args = dict()
    args['module_data'] = ''
    args['wrapper'] = 'False'
    args['powershell'] = 'True'
    args['fqn'] = None
    args['name'] = 'Ansible.ModuleUtils.SqlServer'
    args['ext'] = '.psm1'
    args['optional'] = 'False'
    x = PSModuleDepFinder()
    x._add_module(**args)

# Generated at 2022-06-20 14:20:38.978587
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-20 14:20:46.862625
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _mock_slurp():
        return ""

    def _mock_get_data(pkg, name):
        return name

    def _mock_ps_module_utils_loader(module_name, module_type, ignore_deprecated=True):
        return "/path/to/%s" % module_name

    def _mock_import_module(module):
        class MockModule(object):
            def __init__(self, module_name):
                self.__path__ = module_name

        return MockModule(module)

    import sys
    import warnings
    import tempfile
    import zipfile
    from ansible.plugins.loader import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.path import mkdir_tmp

# Generated at 2022-06-20 14:20:57.897634
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    # pylint: disable=protected-access
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert set(dep_finder._re_cs_module) == set([
        re.compile(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')])

# Generated at 2022-06-20 14:21:05.222917
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test AnsibleError case
    md = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as exc:
        md.scan_exec_script('does_not_exist')
    assert "Could not find executor powershell script for" in to_text(exc.value)

    # Test coverage case
    md.scan_exec_script('Test-FileExists')
    assert 'Test-FileExists' in md.exec_scripts

# Generated at 2022-06-20 14:21:14.015749
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert(finder.exec_scripts == {})
    assert(len(finder.ps_modules) == 0)
    finder.scan_exec_script("wrapper")
    assert(len(finder.ps_modules) == 2)
    assert(finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"])
    assert(finder.ps_modules["Ansible.ModuleUtils.Powershell.Common"])
    assert(len(finder.exec_scripts) == 1)
    assert(finder.exec_scripts["wrapper"])


# Generated at 2022-06-20 14:21:19.931709
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()

    # there is no method to fetch 'ps_version', it is only set by calling scan_module
    #assert finder.ps_version == None
    # there is no method to fetch 'os_version', it is only set by calling scan_module
    #assert finder.os_version == None
    assert finder.become == False


# Generated at 2022-06-20 14:21:25.901630
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_instance = PSModuleDepFinder()

    assert(test_instance.ps_modules == dict())
    assert(test_instance.cs_utils_module == dict())
    assert(test_instance.cs_utils_wrapper == dict())

    assert(test_instance.ps_version == None)
    assert(test_instance.os_version == None)
    assert(test_instance.become == False)



# Generated at 2022-06-20 14:21:32.923262
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # run with: nosetests --attr=test_PSModuleDepFinder_scan_exec_script tests/unit/plugins/loader/test_ps_module_finder.py:TestPSModuleDepFinder
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_exec_script('standard_creds')

    assert "standard_creds" in ps_module_dep_finder.exec_scripts
    assert ps_module_dep_finder.exec_scripts['standard_creds'].startswith(b'param(')
    assert len(ps_module_dep_finder.ps_modules) == 1
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0

# Generated at 2022-06-20 14:21:36.187284
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    scan_exec_script = PSModuleDepFinder().scan_exec_script
    assert scan_exec_script("Select-Object") == None


# Generated at 2022-06-20 14:22:16.922386
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:22:22.823865
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module("#AnsibleRequires -CSharpUtil ansible_collections.ansible.builtin.plugins.module_utils.windows.dotnet.Microsoft.Web.Administration.dll")
    assert dep_finder.cs_utils_module.keys() == {'ansible_collections.ansible.builtin.plugins.module_utils.windows.dotnet.Microsoft.Web.Administration.dll'}

# Generated at 2022-06-20 14:22:23.953810
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-20 14:22:25.535617
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # TODO:
    assert False


# Generated at 2022-06-20 14:22:31.630852
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # arrange
    test_obj = PSModuleDepFinder()
    data = to_bytes(r'''
        using ansible_collections.test_namespace.test_collection.plugins.module_utils.test_module;
        #Requires -Module Ansible.ModuleUtils.test_module2
        #ansiblerequires -powershell ansible_collections.test_namespace.test_collection.plugins.module_utils.test_module3
        #ansiblerequires -powershell .test_module4
        #ansiblerequires -wrapper test_exec_script
        #requires -version 10.8.0.0
        #ansiblerequires -osversion 1.8.0.0
        #ansiblerequires -become
        ''')
    # act
    test_obj.scan_module(data)
    # assert

# Generated at 2022-06-20 14:22:42.715075
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    assert PSModuleDepFinder()._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                                     r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-20 14:22:46.369568
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiate the class
    class_instance = PSModuleDepFinder()

    # Test calling the method scan_exec_script of the class
    class_instance.scan_exec_script('a')



# Generated at 2022-06-20 14:22:47.316776
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # check if constructor is running
    assert PSModuleDepFinder()


# Generated at 2022-06-20 14:22:59.473500
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    class TestClass():
        def test_ps_modules(self):
            ps_modules = {"Ansible.ModuleUtils.ModuleUtil": {"path": "ansible/module_utils/ModuleUtil.psm1", "data": "Ansible.ModuleUtils.ModuleUtil"}}
            results = ps_modules
            assert results == ps_modules
            
        def test_cs_utils_wrapper(self):
            cs_utils_wrapper = {"Ansible.ModuleUtils.DummyUtil": {"path": "ansible/plugins/loaders/cs_module_utils/DummyUtil.cs", "data": "Ansible.ModuleUtils.DummyUtil"}}
            results = cs_utils_wrapper
            assert results == cs_utils_wrapper
            

# Generated at 2022-06-20 14:23:08.725946
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import unittest
    import tempfile
    import os
    import shutil
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six import b, PY3
    from ansible.module_utils.compat import ipaddress
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.compat.os import path
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.ps_module_utils_loader import PSModuleDepFinder

    try:
        ps_module_utils_loader = import_module("ansible.module_utils.powershell.ps_module_utils_loader")
    except ImportError:
        raise unittest.SkipTest

# Generated at 2022-06-20 14:24:24.617452
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data='module_data', fqn='fqn', wrapper=False, powershell=True)


# Generated at 2022-06-20 14:24:26.400888
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-20 14:24:34.846072
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    pmdf = PSModuleDepFinder()
    assert pmdf.ps_modules == dict()
    assert pmdf.cs_utils_wrapper == dict()
    assert pmdf.cs_utils_module == dict()
    assert pmdf.ps_version == None
    assert pmdf.os_version == None
    assert pmdf.become == False


# Generated at 2022-06-20 14:24:49.200602
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:51.483676
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # TODO: Write a test for PSModuleDepFinder.scan_exec_script(name)


# Generated at 2022-06-20 14:25:01.742041
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import unittest

    class TestPSModuleDepFinder(unittest.TestCase):
        def setUp(self):
            self.pd = PSModuleDepFinder()

        def test_init(self):
            self.assertEqual(dict, type(self.pd.ps_modules))
            self.assertEqual(dict, type(self.pd.exec_scripts))
            self.assertEqual(dict, type(self.pd.cs_utils_wrapper))
            self.assertEqual(dict, type(self.pd.cs_utils_module))

            self.assertEqual(None, self.pd.ps_version)
            self.assertEqual(None, self.pd.os_version)
            self.assertEqual(False, self.pd.become)


# Generated at 2022-06-20 14:25:07.505833
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_PSModuleDepFinder = PSModuleDepFinder()
    file_path = "C:\\Users\\prady\\workspace\\ansible\\lib\\ansible\\executor\\powershell\\winrm.ps1"
    my_PSModuleDepFinder.scan_exec_script(file_path)
    assert my_PSModuleDepFinder.exec_scripts[0] == "PS  #Requires -Version 5.0\n"


# Generated at 2022-06-20 14:25:18.072171
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder._re_cs_module is not None
    assert finder._re_ps_module is not None
    assert finder._re_wrapper is not None
    assert finder._re_ps_version is not None
    assert finder._re_os_version is not None
    assert finder._re_become is not None
