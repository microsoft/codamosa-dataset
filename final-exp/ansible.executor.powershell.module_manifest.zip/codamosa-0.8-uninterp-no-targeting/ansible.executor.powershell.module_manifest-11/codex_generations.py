

# Generated at 2022-06-20 14:15:48.333543
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder is not None


# Generated at 2022-06-20 14:15:55.634561
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    fqn = "ansible_collections.ops.shared.module_utils.module_utils"
    module_data = 'using ansible_collections.ops.shared.module_utils.module_utils;'.encode('utf-8')
    finder.scan_module(module_data, fqn=fqn, wrapper=False, powershell=False)
    assert fqn in finder.cs_utils_module.keys()


# Generated at 2022-06-20 14:16:08.326742
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    def _test_requirements(depfinder, expected_file, expected_line):
        assert expected_file == depfinder.ps_modules[name]['path']
        assert expected_line == depfinder.ps_modules[name]['data']

    depfinder = PSModuleDepFinder()
    name = 'Ansible.ModuleUtils.Foo'

# Generated at 2022-06-20 14:16:18.443405
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Ensure that _slurp works
    """
    # Get the module path, this is the directory where the unit tests reside.
    module_path = os.path.dirname(os.path.abspath(__file__))
    test_util = os.path.join(module_path, "test", "support", "test_module_utils", "TestModuleUtil.psm1")

    data = to_bytes(ps_module_utils_loader.find_plugin("TestModuleUtil"))
    data = _slurp(data)
    test_util_data = _slurp(test_util)
    # Test the _slurp method
    assert data == test_util_data

    # Verify scan_module works
    util_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:16:27.186056
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell as powershell
    def _find_plugin(m, ext):
        return "Ansible.ModuleUtils.{0}/{0}.{1}".format(m, ext)
    ps_module_utils_loader.find_plugin = _find_plugin
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_exec_script("powershell_script")
    assert to_text(module_dep_finder.exec_scripts["powershell_script"]).find("Comment Based Help") == 0


# Generated at 2022-06-20 14:16:28.343255
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
   assert False == True



# Generated at 2022-06-20 14:16:43.283784
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # The ps_module_data, must have a valid #AnsibleRequires -Powershell line.
    # The cs_module_data, must have a valid #AnsibleRequires -CSharpUtil line.
    ps_module_data = b"""
        #Requires -Module Ansible.ModuleUtils.BuiltIn.Powershell.Utils, Ansible.ModuleUtils.BuiltIn.Powershell.Logging, Ansible.ModuleUtils.BuiltIn.Powershell.Json
        #AnsibleRequires -PowerShell ansible_collections.my_namespace.my_collection.plugins.module_utils.my_module_util2
        #My Module
        param ()
        """

# Generated at 2022-06-20 14:16:55.481298
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def mock_scan_module(*args, **kwargs):
        self.scan_module_args = args
        self.scan_module_kwargs = kwargs

    self.scan_module_args = []
    self.scan_module_kwargs = {}

    # Need to assign mocked function here as _add_module is a generator and
    # __init__() is done before this point.
    self._add_module = mock_scan_module
    self._parse_version_match = lambda x, y: None

    # Run the test
    self.scan_module(b"#Require -Module test")
    assert self.scan_module_kwargs == {'wrapper': False, 'powershell': True}
    assert self.scan_module_args == (b'test', '.psm1', None, False)

    # Replace the

# Generated at 2022-06-20 14:17:02.008484
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    bool_value = 'false'
    assert bool_value.__class__ == str
    assert bool_value in ['false','true']
    assert bool(bool_value) == False

    bool_value = 'true'
    assert bool_value.__class__ == str
    assert bool_value in ['false','true']
    assert bool(bool_value) == True

    bool_value = '0'
    assert bool_value.__class__ == str
    assert bool_value in ['false','true']
    assert bool(bool_value) == False

    bool_value = '1'
    assert bool_value.__class__ == str
    assert bool_value in ['false','true']
    assert bool(bool_value) == True

    bool_value = 0
    assert bool_value.__class__ == int
    assert bool_

# Generated at 2022-06-20 14:17:09.273131
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.errors import AnsibleError
    from ansible.module_utils.power_shell.common import PS_VERSION, IS_WINDOWS
    from ansible.module_utils.parsing.convert_bool import boolean

    mand_env_vars = (
        ("ANSIBLE_PS_EXECUTABLE", "powershell"),
        ("ANSIBLE_PS_MODULE_PATH", "ansible_test/test_utils/powershell"),
    )
    for v, p in mand_env_vars:
        if v not in os.environ:
            os.environ[v] = p
        else:
            assert os.environ[v] == p

    # TEST CASE: scan_exec_script - raises on invalid script name
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:17:44.639400
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:17:46.732043
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass # unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:17:54.339358
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The following unit test for the method scan_exec_script of class PSModuleDepFinder
    # assumes that the PowerShell script pwsh-shell.ps1 is present in directory
    # lib/ansible/executor/powershell which is the expected location when the
    # ansible package is installed using pip. If ansible is not installed using
    # pip and pwsh-shell.ps1 is not found, unit test returns before execution.

    # creating object of class PSModuleDepFinder
    dep_finder = PSModuleDepFinder()


# Generated at 2022-06-20 14:17:55.654828
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)



# Generated at 2022-06-20 14:17:59.679267
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('basic')
    assert dep_finder.exec_scripts == {'basic': b'# some contents\n'}


# Generated at 2022-06-20 14:18:07.876767
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_file = """
$module_name = 'test_module'
$module_args = @{greeting='hello'}
$module_return_value = MSFT_testmodule $module_args
$module_json_value = ConvertTo-Json -InputObject $module_return_value
Write-Output $module_json_value
"""
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_module(test_file)
    # Assert that the PSModuleDepFinder class created a dictionary containing parsed data
    assert isinstance(psModuleDepFinder.ps_modules, dict)



# Generated at 2022-06-20 14:18:09.278489
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()



# Generated at 2022-06-20 14:18:22.968627
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    _name = 'module_utils.module_indexer'
    _module_indexer = import_module(_name)
    _module_indexer.UNIT_TESTING = True
    _module_indexer.LOG = 0
    _module_indexer.log_debug = lambda *args, **kwargs: False
    _module_indexer.log_info = lambda *args, **kwargs: False
    _module_indexer.log_warning = lambda *args, **kwargs: False

    module_indexer = _module_indexer.ModuleIndexer()
    dep_finder = module_indexer.dep_finder

    _m_name = 'ansible_collections.ansible.posix.plugins.module_utils.common'
    _p_name = 'ansible_collections.ansible.posix.plugins'

# Generated at 2022-06-20 14:18:24.083594
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module = PSModuleDepFinder()
    return module is not None


# Generated at 2022-06-20 14:18:33.214109
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    from ansible.executor.module_common import get_argspec
    from ansible.module_utils import basic


# Generated at 2022-06-20 14:19:02.223600
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    PSModuleDepFinder = import_module('.PSModuleDepFinder', package=resource_from_fqcr('ansible.utils.module_docs_fragments'))
    PSModuleDepFinder = PSModuleDepFinder.PSModuleDepFinder
    # Arguments:
    # args:
    #   module_data (str): String containing module code
    #   fqn=None (str): Fully qualified name of the module being checked
    #   wrapper=False (bool): Indicates if this is a wrapper module or not
    #   powershell=True (bool): Indicates if this is a powershell module or not
    # Returns:
    #    None

    # 1) Test small CS module without any imports
    ps_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:19:16.747976
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_name = "Test_PSModuleDepFinder_scan_module.psm1"
    finder.scan_module(_slurp(os.path.join(C.TEST_DIR, 'units', 'module_utils', module_name)))
    assert len(finder.ps_modules) == 3
    assert "Ansible.ModuleUtils.ExampleModuleUtil" in finder.ps_modules
    assert "Ansible.MyPowerShellModuleUtil" in finder.ps_modules
    assert "ansible_collections.ns.coll.plugins.module_utils.my_module_util" in finder.ps_modules
    assert len(finder.exec_scripts) == 2
    assert "MyPwshModuleUtilExecWrapper" in finder.exec_scripts


# Generated at 2022-06-20 14:19:30.910536
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:19:33.346462
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psm_find = PSModuleDepFinder()
    psm_find.scan_exec_script("test_exec_script")

    # use the specified name
    expected = psm_find.exec_scripts["test_exec_script"]
    actual = psm_find.exec_scripts["test_exec_script"]
    assert expected == actual

# Generated at 2022-06-20 14:19:34.032100
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-20 14:19:45.130103
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test scan_module of class PSModuleDepFinder
    """
    def random_str(length):
        return to_bytes(''.join(random.choice("abcdefghijklmnoprstuwxyz") for i in range(length)))

    # Create PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # Create required data
    # Create a random module util name
    module_util_name="ansible_collections.my_namespace.my_collection.plugins.module_utils." + random_str(10)
    # Get module util data

# Generated at 2022-06-20 14:19:49.284120
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(name="Powershell")
    assert finder.exec_scripts.get('Powershell', None) is not None
    assert finder.exec_scripts.get('Powershell', None).startswith(b"#")
    assert finder.ps_modules.get('Ansible.ModuleUtils.Powershell', None) is not None


# Generated at 2022-06-20 14:20:01.875846
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize the results of the unit test
    results = {
        "passed": 0,
        "failed": 0,
        "executed": 0,
    }

    # Create the PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()

    # initialize the test variables
    name = "TestExecScript"

    # Execute the test function
    try:
        # we expect this to raise an error because we have not created the file
        ps_module_dep_finder.scan_exec_script(name)
        # increment the number of failed tests if we get here
        results["failed"] += 1

    except AnsibleError:
        # increment the number of passed tests if we get here
        results["passed"] += 1
    finally:
        results["executed"] += 1

    # Return the

# Generated at 2022-06-20 14:20:03.091073
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-20 14:20:10.851220
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:36.446728
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psdf = PSModuleDepFinder()
    module = open(__file__).read()
    psdf.scan_module(module)
    assert psdf.ps_modules.keys() == set()
    assert psdf.cs_utils_module.keys() == set()
    assert psdf.ps_version is None
    assert psdf.os_version is None
    assert not psdf.become

    module = """
        #Requires -Module Ansible.ModuleUtils.Common
        #Requires -Module Ansible.ModuleUtils.TestUtils
        #Requires -Module Ansible.ModuleUtils.Legacy
    """
    psdf.scan_module(module)

# Generated at 2022-06-20 14:20:45.465707
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import connection_loader
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.text.converters import (to_str)
    import tempfile
    import os
    import datetime
    import json
    import ansible_collections.ansible.posix.plugins.modules.batch as batch
    import batch_module_utils
    import ansible_collections.ansible.posix.plugins.module_utils.module_common as module_common

    batch_util = batch_module_utils.BatchModuleUtils()


# Generated at 2022-06-20 14:20:57.253517
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiate PSModuleDepFinder
    dep_finder = PSModuleDepFinder()

    # Import powershell-module-utils from namespace ansible.executor.powershell
    powershell_module_utils = import_module('ansible.executor.powershell')

    # Get a list of the name of all the ps1 files in the ansible.executor.powershell package
    stream, _, _ = pkgutil.walk_packages(
        path=powershell_module_utils.__path__,
        prefix=powershell_module_utils.__name__ + ".",
        onerror=lambda x: None
    )

    random_module = to_native(random.choice(list(stream)).name, errors='surrogate_or_strict')
    # Get the ps1 file
    get_module_util_data = p

# Generated at 2022-06-20 14:21:09.988127
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:21:11.150992
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test1 = PSModuleDepFinder()
    test1.scan_exec_script("common")
    assert test1.exec_scripts["common"] is not None


# Generated at 2022-06-20 14:21:11.795421
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-20 14:21:20.152888
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # ensure that there are no PSCustomObjects in the output
    unit_test_only_skip_if_missing_package('pscustomobject')

    finder = PSModuleDepFinder()

    module_util_name = "Ansible.Test.ModuleUtils.Foo"
    module_path = 'test/unit/module_utils/ansible_test_module_utils_foo.psm1'
    module_data = _slurp(module_path)
    module_data = module_data.replace(b'Ansible.Test.ModuleUtils.Foo', to_bytes(module_util_name))

    finder.scan_module(module_data)

    # verify that the Ansible.Test.ModuleUtils.Foo module was added

# Generated at 2022-06-20 14:21:29.668012
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:21:32.747157
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_instance = PSModuleDepFinder()
    expected_result_msg = "No package data found"
    expected_result_code = 1
    try:
        PSModuleDepFinder_instance.scan_exec_script(name)
    except Exception as e:
        assert expected_result_msg in str(e)
        assert expected_result_code == e.errno
    
    

# Generated at 2022-06-20 14:21:45.985115
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    exec_script = b'#!AnsibleExecWrapper\n#Requires -Module Ansible.ModuleUtils.CommonUtils\n\n'
    exec_script_name = 'foo'
    # implicit dependencies of this exec script (ps version, os version)
    ps_version = '5.0'
    os_version = '10.0.14393'
    # wrapper (unused in the test)
    wrapper = False
    # module dependencies
    module_dependencies = {
        'Ansible.ModuleUtils.CommonUtils': '.psm1'
    }
    # version
    # require PowerShell 5.0 or newer
    # require Windows 10 or newer
    powershell_version = '5.0'
    os_version = '10.0.14393'

    test = PSModuleDepFinder()


# Generated at 2022-06-20 14:22:06.701773
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # object creation
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf, PSModuleDepFinder)

    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()

    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False

    # _re_cs_module
    assert isinstance(psmdf._re_cs_module, list)
    assert len(psmdf._re_cs_module) == 1
    assert isinstance(psmdf._re_cs_module[0], type(re.compile('(.*)')))

    #

# Generated at 2022-06-20 14:22:20.903352
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:32.988776
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # arrange
    module_dep_finder = PSModuleDepFinder()
    module_data = "#Requires -Module Ansible.ModuleUtils.Test"
    module_data_cs = "using Ansible.ModuleUtils.Test;"
    module_data_cs_2 = "using ansible_collections.namespace.collection.plugins.module_utils.Test;"
    module_data_cs_3 = "using ansible_collections.namespace.collection.plugins.module_utils.subfolder.Test;"

    # act
    module_dep_finder.scan_module(module_data)
    module_dep_finder.scan_module(module_data_cs)
    module_dep_finder.scan_module(module_data_cs_2)
    module_dep_finder.scan_module(module_data_cs_3)



# Generated at 2022-06-20 14:22:37.855559
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False, "Bun for unit test for method scan_module of class PSModuleDepFinder is not implemented"


# Generated at 2022-06-20 14:22:40.260771
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.exec_scripts == {}
    finder.scan_exec_script(name='_text')
    assert finder.exec_scripts != {}


# Generated at 2022-06-20 14:22:44.314145
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    instance = PSModuleDepFinder()
    assert isinstance(instance, PSModuleDepFinder)

_re_comment = re.compile(to_bytes(r'#.*$'))



# Generated at 2022-06-20 14:22:50.144955
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == {}
    assert f.cs_utils_wrapper == {}
    assert f.cs_utils_module == {}
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False


# Generated at 2022-06-20 14:23:00.950895
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    random.seed(42)
    finds = []
    for _ in range(100):
        finds.append(bool(random.randint(0, 1)))
    finds = tuple(finds)

    base64_input = to_bytes(base64.b64encode(to_bytes("Hello world".encode('utf-8'))))
    class MockPkgutil:
        def get_data(self, *args, **kwargs):
            if finds:
                return base64_input
        def __getattribute__(self, name):
            if name == 'get_data':
                return MockPkgutil.get_data
            return object.__getattribute__(self, name)
    import ansible.executor
    saved = ansible.executor.powershell
    ansible.executor.powershell = MockPkgutil

# Generated at 2022-06-20 14:23:04.453455
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    arg1 = 'TestValue'
    PSModuleDepFinder().scan_exec_script(arg1)


# Generated at 2022-06-20 14:23:15.273522
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = pkgutil.get_data("ansible_collections.ansible.builtin.plugins.module_utils", "powershell.psm1")

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(data)

    assert dep_finder.ps_modules['Ansible.ModuleUtils.Encryption.Encryption'] == {
        'data': pkgutil.get_data("ansible_collections.ansible.builtin.plugins.module_utils", "Encryption/Encryption.psm1"),
        'path': os.path.join(C.DEFAULT_MODULE_UTILS_PATH, 'Encryption/Encryption.psm1'),
    }


# Generated at 2022-06-20 14:23:33.681860
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    old_value = finder.exec_scripts
    finder.exec_scripts = {}
    finder.scan_exec_script("Test")
    assert len(finder.exec_scripts) == 1
    assert "Test" in finder.exec_scripts
    assert len(finder.ps_modules) > 0
    assert old_value is not finder.exec_scripts


# Generated at 2022-06-20 14:23:40.848540
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    # Create a module_data
    module_data = pkgutil.get_data("ansible.modules.system", to_native("core.psm1"))
    # Call scan_module
    psmdf.scan_module(module_data)
    # Assert that ps_modules is not empty
    assert len(psmdf.ps_modules) > 0
    # Assert that cs_utils_wrapper is empty
    assert len(psmdf.cs_utils_wrapper) == 0
    # Assert that cs_utils_module is not empty
    assert len(psmdf.cs_utils_module) > 0
    # Assert that exec_scripts is empty
    assert len(psmdf.exec_scripts) == 0
   

# Generated at 2022-06-20 14:23:49.619930
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = '#Requires -Version 5.1\n' \
                  '#Requires -Module Ansible.ModuleUtils.CommonUtils\n'
    psdepfinder = PSModuleDepFinder()
    psdepfinder.ps_modules = {'Ansible.ModuleUtils.CommonUtils': 'powershell_data'}
    psdepfinder.scan_exec_script(module_data)
    assert psdepfinder.ps_modules == {'Ansible.ModuleUtils.CommonUtils': 'powershell_data'}


# Generated at 2022-06-20 14:23:58.049744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected_return_value = None
    return_value = None

    # set default values
    module_name = None

    # actual
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(module_name)

    # verify results
    assert return_value == expected_return_value



# Generated at 2022-06-20 14:24:02.390253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdep = PSModuleDepFinder()
    mdep.scan_exec_script("powershell_wrapper")
    assert mdep.exec_scripts
    assert mdep.ps_modules
    assert mdep.cs_utils_wrapper


# Generated at 2022-06-20 14:24:09.962933
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-20 14:24:13.539545
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell.ps1')
    assert len(dep_finder.exec_scripts.keys())
    assert 'powershell.ps1' in dep_finder.exec_scripts.keys()


# Generated at 2022-06-20 14:24:14.378171
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder.__init__


# Generated at 2022-06-20 14:24:16.264322
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # 1. the method expects to receive a name that is of type string
    finder = PSModuleDepFinder()
    finder.scan_exec_script("1")


# Generated at 2022-06-20 14:24:18.749346
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('Test')


# Generated at 2022-06-20 14:24:35.192730
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder


# Generated at 2022-06-20 14:24:38.119557
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-20 14:24:48.906365
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Initialize object
    finder = PSModuleDepFinder()
    # Add valid test data
    finder.ps_modules = dict()
    finder.cs_utils_wrapper = dict()
    finder.cs_utils_module = dict()
    finder.become = False
    finder.ps_version = None
    finder.os_version = None

    
    
    
    
    
    
    
    # valid test data

# Generated at 2022-06-20 14:24:58.686623
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import json, re
    import ansible.module_utils.powershell as powershell
    powershell.ps_script_version = 1
    powershell.ps_script_version += 1
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'powershell', 'script_version.ps1')
    with open(path) as f:
        script_version = int(re.search(r'^\d+', f.read()).group(0))
    assert script_version == powershell.ps_script_version



# Generated at 2022-06-20 14:25:10.017779
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    params_path = 'plugins/modules/win_package/latest.py'
    params_path = resource_from_fqcr('ansible.builtin.win_package.latest', params_path)
    params_path = to_native(params_path)

    data_module = open(params_path).read()
    data_module = to_bytes(data_module)
    dep_finder.scan_module(data_module)

    assert len(dep_finder.ps_modules.keys()) == 4
    assert 'Ansible.ModuleUtils.Common.TargetModule' in dep_finder.ps_modules
    assert 'Ansible.ModuleUtils.Common.WinPSModule' in dep_finder.ps_modules

# Generated at 2022-06-20 14:25:24.855455
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder_object = PSModuleDepFinder()
    ps_module_dep_finder_object.scan_exec_script(name='start_connection')