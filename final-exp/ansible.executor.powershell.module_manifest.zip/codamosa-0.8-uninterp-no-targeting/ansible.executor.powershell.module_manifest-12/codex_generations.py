

# Generated at 2022-06-20 14:15:59.160648
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:03.995519
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "No unit tests implemented"

# Generated at 2022-06-20 14:16:14.447611
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    example_scripts=['win_ping','win_command','win_copy','win_stat']
    tmp_module_data = {}
    for example_script in example_scripts:
        data = pkgutil.get_data('ansible.executor.powershell', to_native(example_script + ".ps1"))
        tmp_module_data[example_script] = to_bytes(data)
    p = PSModuleDepFinder()

    for example_script in example_scripts:
        p.scan_module(tmp_module_data[example_script],name=example_script,wrapper=True,powershell=True)
        assert p.exec_scripts[example_script] is not None



# Generated at 2022-06-20 14:16:15.461049
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    d = PSModuleDepFinder()


# Generated at 2022-06-20 14:16:17.456457
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:16:22.160480
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    fqn = "test_collection.test_namespace.test_name"

# Generated at 2022-06-20 14:16:28.458744
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False


# Generated at 2022-06-20 14:16:43.484924
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert type(dep_finder.ps_modules) is dict
    assert type(dep_finder.exec_scripts) is dict
    assert type(dep_finder.cs_utils_wrapper) is dict
    assert type(dep_finder.cs_utils_module) is dict
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module[0].pattern == r"(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$"
    assert dep_finder._re_cs_in_ps_module[0].pattern == r

# Generated at 2022-06-20 14:16:55.588719
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import stat
    import tempfile

    from ansible.module_utils.powerShell.deprecation import DeprecationMixin
    from ansible.module_utils.powerShell.executor import PowerShellExecutor
    from ansible.module_utils.powerShell.snippet import PowerShellSnippet


# Generated at 2022-06-20 14:17:02.043517
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  import yaml

  yaml_filedata = '''
    Ansible:
      Python:
        version: '2.7'
        executable: /usr/bin/python
        include:
          - /usr/include/python2.7
      Constants:
        DEFAULT_DEBUG: true
        DEFAULT_KEEP_REMOTE_FILES: false
      bin: '/usr/bin/ansible'
      VERSION: 2.9.11
  '''

  metadata = yaml.safe_load(yaml_filedata)

  psmdf = PSModuleDepFinder()
  psmdf.scan_module("#Requires -Module Ansible.ModuleUtils.Something.psm1")
  psmdf.scan_module("#Requires -Modules Ansible.ModuleUtils.Something.psm1")


# Generated at 2022-06-20 14:17:27.946668
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    my_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-20 14:17:35.757914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    input_module_data = '''{
	"ansible_facts": {
		"discovered_interpreter_python": "/usr/bin/python"
	},
	"changed": false,
	"module_setup": true
}'''

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script(input_module_data)
    assert len(ps_module_dep_finder.exec_scripts) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 1
    assert len(ps_module_dep_finder.ps_modules) == 4


# Generated at 2022-06-20 14:17:47.864401
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    res = list()
    res.append({
        'test_data':
        {
            'data': "function foo() { Write-Host -NoNewline '1' }",
            'name': 'foo.py'
        },
        'expected_data':
        {
            'data': "function foo() { Write-Host -NoNewline '1' }",
            'name': 'foo.py'
        },
        'expected_status': True
    })

    for test_data in res:
        test_data['actual_data'] = PSModuleDepFinder().scan_exec_script(test_data['test_data']['data'], test_data['test_data']['name'])


# Generated at 2022-06-20 14:17:50.210225
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder().ps_modules, dict)
    assert isinstance(PSModuleDepFinder().exec_scripts, dict)


# Generated at 2022-06-20 14:18:04.198227
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert not ps_module_dep_finder.become
    assert len(ps_module_dep_finder._re_cs_module) == 1
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1
    assert len(ps_module_dep_finder._re_ps_module) == 2
    assert ps_module_dep_finder._re

# Generated at 2022-06-20 14:18:09.173967
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup
    dep_finder = PSModuleDepFinder()
    name = "base.psm1"
    # test
    dep_finder.scan_exec_script(name)
    # assert
    assert to_native(dep_finder.exec_scripts[name]) == \
    "function foo(){return 'bar'}"


# Generated at 2022-06-20 14:18:14.433682
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:18:26.750951
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()
    # Test that ps_modules dictionary is initialized with empty value
    assert ps_dep_finder.ps_modules == dict()
    # Test that cs_utils_wrapper and cs_utils_module dictionaries are initialized with empty values
    assert ps_dep_finder.cs_utils_wrapper == dict()
    assert ps_dep_finder.cs_utils_module == dict()
    # Test that ps_version, os_version and become attributes are initialized with None values
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert ps_dep_finder.become is False
    # Test that _re_cs_module and _re_ps_module are initialized as a list

# Generated at 2022-06-20 14:18:34.953344
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import re
    import tempfile
    import sys

    # Set all inputs to PSModuleDepFinder to valid values.
    ps_module_dep_finder = PSModuleDepFinder()
    ps_script_paths = tempfile.mkdtemp()
    ps_script_name = 'Test_PSModuleDepFinder_scan_module'

    # Create powershell script to test PSModuleDepFinder.scan_module()
    f = open(os.path.join(ps_script_paths, ps_script_name + ".psm1"), 'w')
    f.write("function function_a() {\n")
    f.write("    Write-Host \"success\"\n")
    f.write("}\n")
    f.write("function function_b() {\n")

# Generated at 2022-06-20 14:18:42.072841
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_module) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.exec_scripts) == 0
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False



# Generated at 2022-06-20 14:19:17.447384
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/etc/ansible/collections:/usr/share/ansible/collections"
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become



# Generated at 2022-06-20 14:19:19.674349
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep = PSModuleDepFinder()
    assert isinstance(ps_module_dep, PSModuleDepFinder)


# Generated at 2022-06-20 14:19:23.345551
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    md = PSModuleDepFinder()
    scripts = md.exec_scripts

    md.scan_exec_script("common")
    assert "common" in scripts.keys()
    assert scripts["common"] is not None

    md.scan_exec_script("common")
    assert len(scripts.keys()) == 1
    

# Generated at 2022-06-20 14:19:29.191342
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Testing scan_module")
    print("Testing scan_module")
    finder = PSModuleDepFinder()
    finder.scan_module(
        b'#requires -module Foo\n#ansiblerequires -powershell ansible.module_utils.foo\n#requires -version 5.0\n',
        fqn="foo",
        wrapper=True,
        powershell=True)
    assert finder.ps_modules == {u'ansible.module_utils.foo': {'data': b'#requires -module Foo\n#ansiblerequires -powershell ansible.module_utils.foo\n#requires -version 5.0\n', 'path': u'foo'}}

# Generated at 2022-06-20 14:19:36.283371
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False



# Generated at 2022-06-20 14:19:41.480452
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
   
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ExecutionContext_Powershell")
   
    assert "ExecutionContext_Powershell" in dep_finder.exec_scripts.keys()
    assert len(dep_finder.ps_modules.keys()) > 0



# Generated at 2022-06-20 14:19:57.930256
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mu_path = '/fake/path/to/ps_module.psm1'
    with open(mu_path, 'rb') as mu_file:
        module_data = mu_file.read()
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_module(module_data, 'ansible_collections.acme.foo')
    assert module_dep_finder.ps_modules['Ansible.ModuleUtils.Test']['data'] == module_data
    assert module_dep_finder.ps_modules['Ansible.ModuleUtils.Test']['path'] == mu_path
    assert module_dep_finder.cs_utils_wrapper['Ansible.Test']['data'] == module_data

# Generated at 2022-06-20 14:20:06.847426
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()
    assert isinstance(module_finder, PSModuleDepFinder)
    assert isinstance(module_finder.ps_modules, dict)
    assert isinstance(module_finder.exec_scripts, dict)
    assert isinstance(module_finder.cs_utils_wrapper, dict)
    assert isinstance(module_finder.cs_utils_module, dict)
    assert isinstance(module_finder.ps_version, type(None))
    assert isinstance(module_finder.os_version, type(None))
    assert isinstance(module_finder.become, bool)

# Test for _add_module function. Not a possible test case

# Generated at 2022-06-20 14:20:09.122998
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Add some tests
    raise NotImplementedError()

# Generated at 2022-06-20 14:20:12.647314
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_obj = PSModuleDepFinder()
    assert PSModuleDepFinder_obj.scan_exec_script("") is None


# Generated at 2022-06-20 14:20:58.004545
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an instance of PSModuleDepFinder
    test_module_dep_finder = PSModuleDepFinder()
    # create mock data for module_data
    data = \
        b'#Requires -Module Ansible.ModuleUtils.MyFooUtil\n' \
        b'#Requires -Module Ansible.ModuleUtils.MyBarUtil\n' \
        b'#Requires -Module Ansible.ModuleUtils.MyBazUtil\n'
    # set the return value of _add_module to True
    with patch('ansible.module_utils.powershell._ps_module_utils.PSModuleDepFinder._add_module') as mock_module:
        mock_module.return_value = True
        # call scan_module method
        test_module_dep_finder.scan_module(data)
       

# Generated at 2022-06-20 14:21:10.625968
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dut = PSModuleDepFinder()
    assert dut.ps_modules == dict()
    assert dut.exec_scripts == dict()
    assert dut.cs_utils_wrapper == dict()
    assert dut.cs_utils_module == dict()
    assert dut.ps_version is None
    assert dut.os_version is None
    assert dut.become is False

    # We don't test _re_cs_module which is used in scan_module(), because _re_cs_module is used in
    # two different methods in _add_module(), which will be covered in test_scan_module().
    assert len(dut._re_cs_in_ps_module) == 2

# Generated at 2022-06-20 14:21:12.390530
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("script")


# Generated at 2022-06-20 14:21:14.058049
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # PSModuleDepFinder_scan_exec_script() => None
    pass


# Generated at 2022-06-20 14:21:14.852654
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-20 14:21:22.021747
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert len(f.ps_modules) == 0
    assert not f.become
    assert f.ps_version is None
    assert len(f.cs_utils_module) == 0
    assert len(f.cs_utils_wrapper) == 0

    assert len(f._re_cs_module) == 1
    assert isinstance(f._re_cs_module[0], re._pattern_type)
    assert len(f._re_cs_in_ps_module) == 1
    assert isinstance(f._re_cs_in_ps_module[0], re._pattern_type)
    assert len(f._re_ps_module) == 2
    assert isinstance(f._re_ps_module[0], re._pattern_type)

# Generated at 2022-06-20 14:21:31.129373
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import io
    import os
    import pytest
    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data', 'PSModuleDepFinder')
    # initialize a PSModuleDepFinder object
    psmdf = PSModuleDepFinder()

    # read in the contents of test_data/PSModuleDepFinder/ModuleUtils1.psm1
    with open(os.path.join(test_data_dir, 'ModuleUtils1.psm1'), 'rb') as f:
        ModuleUtils1 = f.read()

    # read in the contents of test_data/PSModuleDepFinder/ModuleUtils2.psm1

# Generated at 2022-06-20 14:21:38.737540
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules) == 0
    assert len(psmdf.cs_utils_wrapper) == 0
    assert len(psmdf.cs_utils_module) == 0
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become



# Generated at 2022-06-20 14:21:46.803294
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # in this test code, we will not run scan_module() and scan_exec_script() of
    # the PSModuleDepFinder, so the values of ps_modules, exec_scripts,
    # cs_utils_wrapper, and cs_utils_module should be empty here.
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()


# Generated at 2022-06-20 14:21:58.229453
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # test PSModuleDepFinder.scan_module
    psmdf = PSModuleDepFinder()


# Generated at 2022-06-20 14:22:36.705301
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    try:
        ps_module_dep_finder.scan_exec_script("foo")
        assert False
    except AnsibleError as ex:
        assert str(ex) == "Could not find executor powershell script for 'foo'"
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("stdout")
    assert isinstance(ps_module_dep_finder.exec_scripts, dict)
    assert len(ps_module_dep_finder.exec_scripts) == 1
    assert isinstance(ps_module_dep_finder.exec_scripts['stdout'], bytes)
    assert len(ps_module_dep_finder.ps_modules) == 1

import pytest


# Generated at 2022-06-20 14:22:45.407368
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test PSModuleDepFinder.scan_module
    """
    def read_module(name):
        return read_file(os.path.join('lib','ansible','modules','windows','%s.ps1' % name))

    dep_finder = PSModuleDepFinder()

    dep_finder.scan_module(read_module('win_service'))
    dep_finder.scan_module(read_module('win_ping'))

    # Make sure we reference the module_util more than once to test the dedupe code
    dep_finder.scan_module(read_module('win_service'))

    assert len(dep_finder.ps_modules) == 2

    dep_finder.scan_module(read_module('win_ping'))
    assert len(dep_finder.ps_modules) == 2

    # Make

# Generated at 2022-06-20 14:22:57.964439
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test PSModuleDepFinder objects and their variable assignments
    md_finder = PSModuleDepFinder()

    # assert the member variable equalities
    assert isinstance(md_finder.ps_modules, dict)
    assert isinstance(md_finder.exec_scripts, dict)
    assert isinstance(md_finder.cs_utils_wrapper, dict)
    assert isinstance(md_finder.cs_utils_module, dict)
    assert isinstance(md_finder.ps_version, (type(None), str))
    assert isinstance(md_finder.os_version, (type(None), str))
    assert isinstance(md_finder.become, bool)

    # assert the regular expression objects

# Generated at 2022-06-20 14:23:07.912614
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder.ps_modules == dict()
    assert depfinder.exec_scripts == dict()
    assert depfinder.cs_utils_wrapper == dict()
    assert depfinder.cs_utils_module == dict()
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False
    assert len(depfinder._re_cs_module) == 1
    assert depfinder._re_cs_module[0].match(b'using ansible_collections.foo.bar.plugins.module_utils.baz;\n')
    assert depfinder._re_ps_version.match(b'#requires -version 5.1\n')

# Generated at 2022-06-20 14:23:12.598808
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("windows_package")
    assert dep_finder.exec_scripts["windows_package"] is not None

# Unit tests for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:22.876310
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()

    # test regular invocation
    mock_name = C.DEFAULT_DEBUG = "win_copy"
    test_obj.scan_exec_script(mock_name)
    assert mock_name in test_obj.exec_scripts

    # test for exception
    mock_name = C.DEFAULT_DEBUG = "no_such_file"
    try:
        test_obj.scan_exec_script(mock_name)
        assert False
    except AnsibleError as e:
        assert "Could not find executor powershell script for" in to_text(e)



# Generated at 2022-06-20 14:23:29.037835
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    # Test for two finders
    assert len(ps_module_dep_finder._re_ps_module) == 2
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1

    # Test for two finders
    assert len(ps_module_dep_finder._re_cs_module) == 1


# Generated at 2022-06-20 14:23:38.731849
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a PSModuleDepFinder object
    repo = PSModuleDepFinder()
    # get data from the test module
    data = _slurp("./test_module.psm1")
    # invoke scan_module
    repo.scan_module(data)
    # verify that the data from the test module was parsed correctly
    assert len(repo.ps_modules) == 3
    assert b"Ansible.ModuleUtils.CommonUtils" in repo.ps_modules
    assert b"ansible_collections.ns.coll_name.plugins.module_utils.test" in repo.ps_modules
    assert b"ansible_collections.ns.coll_name.plugins.module_utils.test2" in repo.ps_modules
    # verify that the data from the test wrapper was parsed correctly

# Generated at 2022-06-20 14:23:46.361168
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test to confirm that objects are initialized to the correct values
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-20 14:23:52.927724
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert(len(psmdf.ps_modules.keys()) == 0)
    assert(len(psmdf.cs_utils_wrapper.keys()) == 0)
    assert(len(psmdf.cs_utils_module.keys()) == 0)
    assert(psmdf.ps_version is None)
    assert(psmdf.os_version is None)
    assert(psmdf.become is False)


# Generated at 2022-06-20 14:24:26.129471
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('Ansible.ArgumentSpec')
    assert len(finder.exec_scripts.keys()) == 1
    assert 'Ansible.ArgumentSpec' in finder.exec_scripts

    finder.scan_exec_script('Ansible.ArgumentSpec')
    assert len(finder.exec_scripts.keys()) == 1
    assert 'Ansible.ArgumentSpec' in finder.exec_scripts


# Generated at 2022-06-20 14:24:35.931559
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.plugins.loader import ps_module_utils_loader

    ps_module_utils_loader._find_plugins()
    from ansible_collections import mycollection
    from ansible_collections.mycollection.plugins.module_utils import myutil
    from ansible.module_utils import myutil2

    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_exec_script("shell_wrapper")

    assert set(ps_module_dep_finder.exec_scripts.keys()) == {"shell_wrapper"}

    if not isinstance(myutil, type(myutil2)):
        print("myutil and myutil2 are not the same type [%s, %s]" % (type(myutil), type(myutil2)))
        assert False


# Generated at 2022-06-20 14:24:49.936521
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create instances of the class
    finder = PSModuleDepFinder()

    # Create the following directory structure:
    # - home/test_executor_ps1
    # - home/test_executor_ps1/ansible
    # - home/test_executor_ps1/ansible/executor
    # - home/test_executor_ps1/ansible/executor/powershell
    # - home/test_executor_ps1/ansible/executor/powershell/test_script.ps1
    test_dir = os.path.join("test_executor_ps1", "ansible", "executor", "powershell")

    if not os.path.exists("test_executor_ps1"):
        os.mkdir("test_executor_ps1")


# Generated at 2022-06-20 14:25:00.070503
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("microsoft.wsman.management.invokescript")

    assert 'Microsoft.WSMan.Management.InvokeScript' in depfinder.cs_utils_wrapper.keys()
    assert 'Ansible.ModuleUtils.Microsoft.WSMan.Management.InvokeScript' in depfinder.ps_modules.keys()

# Generated at 2022-06-20 14:25:10.056693
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    my_finder = PSModuleDepFinder()
    assert my_finder.ps_modules == dict()
    assert my_finder.exec_scripts == dict()
    assert my_finder.cs_utils_wrapper == dict()
    assert my_finder.cs_utils_module == dict()
    assert my_finder.ps_version is None
    assert my_finder.os_version is None
    assert my_finder.become is False

    assert len(my_finder._re_cs_module) == 1
    assert len(my_finder._re_cs_in_ps_module) == 1
    assert len(my_finder._re_ps_module) == 2


# Generated at 2022-06-20 14:25:11.725768
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()



# Generated at 2022-06-20 14:25:25.472615
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    def assert_dict_contains_keys(d, keys):
        missing_keys = [k for k in keys if k not in d]
        assert len(missing_keys) == 0, "dict %s is missing keys: %s" % (d, missing_keys)

    module_dep_finder = PSModuleDepFinder()  # noqa: F841

    assert isinstance(module_dep_finder.ps_modules, dict), "ps_modules should be a dict"
    assert isinstance(module_dep_finder.cs_utils_wrapper, dict), "cs_utils_wrapper should be a dict"
    assert isinstance(module_dep_finder.cs_utils_module, dict), "cs_utils_module should be a dict"