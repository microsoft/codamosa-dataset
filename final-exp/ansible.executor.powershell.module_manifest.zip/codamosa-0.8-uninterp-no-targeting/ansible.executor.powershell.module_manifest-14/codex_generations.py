

# Generated at 2022-06-20 14:16:10.147832
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.List\n')
    assert finder.ps_modules['Ansible.ModuleUtils.List']['path'][-17:] == 'plugins/module_utils/list.psm1'


# Generated at 2022-06-20 14:16:19.675451
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    assert finder._re_cs_module[0].pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                        r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-20 14:16:23.644586
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    temp_finder = PSModuleDepFinder()  # create an instance of the class to test
    temp_finder.scan_exec_script('connect-ip')
    assert temp_finder.exec_scripts['connect-ip']



# Generated at 2022-06-20 14:16:37.759440
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:50.978127
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    @returns None
    :rtype: None
    """
    finder = PSModuleDepFinder()
    powershell_module = '''
        #Requires -Module Ansible.ModuleUtils.CommonUtils
        #Requires -Module Ansible.ModuleUtils.MyUtil
        #Requires -Version 1.0.0

        Write-Output "this is a test"
        '''
    finder.scan_module(powershell_module, 'test.psm1')
    assert finder.ps_modules.keys() == ['Ansible.ModuleUtils.CommonUtils', 'Ansible.ModuleUtils.MyUtil']
    assert finder.ps_version == '1.0.0'


# Generated at 2022-06-20 14:17:06.506686
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # read in a mock powershell script
    import sys
    import os
    import json
    import mock
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.dirname(test_dir))
    with open(os.path.join(test_dir, 'data', 'library', 'powerdns', 'module_utils', 'powerdns.psm1'), 'rb') as f:
        module_data = f.read()

    finder = PSModuleDepFinder()
    # Test with mock ansible_powershell_host
    sys.modules['ansible.module_utils.ansible_powershell_host'] = mock.Mock()
    finder.scan_module(module_data)

# Generated at 2022-06-20 14:17:16.350897
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()

    dir_path = os.path.dirname(os.path.realpath(__file__))
    module_dir = os.path.join(dir_path, 'mockdir')
    module_dir_manager = None

# Generated at 2022-06-20 14:17:25.240762
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell.regexes import _re_cs_in_ps_module
    from ansible.module_utils.powershell.regexes import _re_ps_module
    from ansible.module_utils.regexes import _re_cs_module
    from ansible.module_utils.powershell.regexes import _re_wrapper
    from ansible.module_utils.powershell.regexes import _re_ps_version
    from ansible.module_utils.powershell.regexes import _re_os_version
    from ansible.module_utils.powershell.regexes import _re_become
    from ansible.module_utils.powershell._module_utils import powershell_module_utils

# Generated at 2022-06-20 14:17:26.695339
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), object)



# Generated at 2022-06-20 14:17:27.766115
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Test not implemented"


# Generated at 2022-06-20 14:17:50.310384
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Test with a valid module_util name
    finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Test.psm1")
    assert "Ansible.ModuleUtils.Test" in finder.ps_modules

    # Test with a valid module_util name with whitespace between directives and filename
    finder.scan_module(b"#Requires -Module     Ansible.ModuleUtils.Test.psm1")
    assert "Ansible.ModuleUtils.Test" in finder.ps_modules

    # Test with a valid module_util name with optional
    finder.scan_module(b"#AnsibleRequires -PowerShell    Ansible.ModuleUtils.Test.psm1 -Optional")

# Generated at 2022-06-20 14:18:04.233126
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    # test the init method
    assert psmdf.ps_modules.keys() == [], "PSModuleDepFinder.ps_modules not empty after init"
    assert psmdf.exec_scripts.keys() == [], "PSModuleDepFinder.exec_scripts not empty after init"
    assert psmdf.cs_utils_wrapper.keys() == [], "PSModuleDepFinder.cs_utils_wrapper not empty after init"
    assert psmdf.cs_utils_module.keys() == [], "PSModuleDepFinder.cs_utils_module not empty after init"
    assert psmdf.ps_version == None, "PSModuleDepFinder.ps_version not None after init"

# Generated at 2022-06-20 14:18:10.477095
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder._re_cs_module is not None
    assert ps_module_dep_finder._re_ps_module is not None

    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become == False



# Generated at 2022-06-20 14:18:14.043241
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Only test that the constructor doesn't throw an exception.
    # The generator code is not used.
    dep_finder = PSModuleDepFinder()


# Generated at 2022-06-20 14:18:26.474000
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module("""#Requires -Module Ansible.ModuleUtils.Pester
#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.test_module
""")

    assert md.ps_modules['Ansible.ModuleUtils.Pester']
    assert md.cs_utils_module['ansible_collections.test.test_collection.plugins.module_utils.test_module']

    md = PSModuleDepFinder()
    md.scan_module("""#Requires -Module Ansible.ModuleUtils.Pester
#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.test_module
#AnsibleRequires -Wrapper test_module
""")



# Generated at 2022-06-20 14:18:27.078109
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-20 14:18:35.226515
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Prepare
    m = PSModuleDepFinder()

    # Should match version string
    match1 = m._re_ps_version.match(b"#Requires -Version 1")
    match2 = m._re_ps_version.match(b"#Requires -Version 1.2")
    match3 = m._re_ps_version.match(b"#Requires -Version 1.2.3")
    match4 = m._re_ps_version.match(b"#Requires -Version 1.2.3.4")
    match5 = m._re_os_version.match(b"#AnsibleRequires -OSVersion 1")
    match6 = m._re_os_version.match(b"#AnsibleRequires -OSVersion 1.2")

# Generated at 2022-06-20 14:18:36.491384
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert(PSModuleDepFinder)



# Generated at 2022-06-20 14:18:47.879171
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = """
#Requires -Module Ansible.ModuleUtils.Powershell
#Requires -Module Ansible.ModuleUtils.SomeOtherUtil
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.util1
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.util2
#AnsibleRequires -PowerShell ..module_utils.util3
#AnsibleRequires -PowerShell ..module_utils.util4
#AnsibleRequires -PowerShell ..module_utils.util4
"""
    test_deps = PSModuleDepFinder()
    test_deps.scan_module(module_data)

# Generated at 2022-06-20 14:19:01.816729
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass
    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)
    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class ModuleTest(object):
        def __init__(self, exit_json=exit_json, fail_json=fail_json):
            self.exit_json = exit_json
            self.fail_json = fail_json

    def get_module_path():
        import os
        return os.path.dirname(os.path.dirname(__file__))



# Generated at 2022-06-20 14:19:58.135175
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Generated at 2022-06-20 14:20:01.965700
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = 'WinRM'
    assert name not in finder.exec_scripts
    finder.scan_exec_script(name)
    assert name in finder.exec_scripts


# Generated at 2022-06-20 14:20:10.358502
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_utils = set()
    print("Define the test module")

# Generated at 2022-06-20 14:20:23.124130
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depFinder = PSModuleDepFinder()
    depFinder.ps_modules = dict()
    depFinder.cs_utils_module = dict()
    depFinder.cs_utils_wrapper = dict()
    depFinder.exec_scripts = dict()
    depFinder.ps_version = None
    depFinder.os_version = None
    depFinder.become = False

    # Testing scan_module for PS module
    depFinder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Foo")
    depFinder.scan_module(b"#AnsibleRequires -Powershell Ansible.ModuleUtils.Foo")

# Generated at 2022-06-20 14:20:26.219511
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    find the module's dependencies
    """
    # execute tests
    runner = Runner()
    runner.run()


# Generated at 2022-06-20 14:20:39.193537
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    path_name = '../test/sanity/code-smell/test-module-deps-2/'
    ps_module_data = _slurp(path_name + '/library/test_module.psm1')
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(ps_module_data)

# Generated at 2022-06-20 14:20:46.977066
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mu = PSModuleDepFinder()
    mu.scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.util_1\n'
                   b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Util2\n'
                   b'#AnsibleRequires -PowerShell ansible_collections.test_namespace.test_collection.plugins.module_utils.util_3\n'
                   b'#AnsibleRequires -PowerShell ..module_utils.util_4\n'
                   b'#AnsibleRequires -CSharpUtil  ..module_utils.util_5\n'
                   b'#AnsibleRequires -Wrapper util_6')

# Generated at 2022-06-20 14:20:57.179004
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_cs_in_ps_module, list)
    assert isinstance(psmdf._re_ps_module, list)
    assert isinstance(psmdf._re_wrapper, type(re.compile(b'')))
    assert isinstance(psmdf._re_ps_version, type(re.compile(b'')))
    assert isinstance(psmdf._re_os_version, type(re.compile(b'')))
    assert isinstance(psmdf._re_become, type(re.compile(b'')))


# Generated at 2022-06-20 14:21:09.882169
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    import types
    import unittest
    from unittest.mock import patch

    class PSModuleDepFinderSpec(unittest.TestCase):
        #@patch("ansible.module_utils.powershell.PSModuleDepFinder.are_required_versions_present", spec_set=True, autospec=True)
        #@patch("ansible.module_utils.powershell.PSModuleDepFinder.is_platform_compatible", spec_set=True, autospec=True)
        @patch("ansible.module_utils.powershell.PSModuleDepFinder.scan_module", spec_set=True, autospec=True)
        def test_scan_module(self, scan_module_patch):
            subject = PSModuleDepFinder()

# Generated at 2022-06-20 14:21:18.774284
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    import os

    def _assert_module(module_data, expected_module_utils, expected_exec_scripts, expected_ps_version=None, expected_os_version=None, expected_become=None):
        module_name = 'module_utils/module_to_test'
        fqn = 'name.space.collection.%s' % module_name
        finder = PSModuleDepFinder()

        # verify initial values
        assert not finder.ps_modules
        assert not finder.exec_scripts
        assert not finder.cs_utils_wrapper
        assert not finder.cs_utils_module
        assert finder.ps_version is None
        assert finder.os_version is None
        assert finder.become is False

        finder

# Generated at 2022-06-20 14:21:59.021109
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmd = PSModuleDepFinder()
    assert isinstance(psmd._re_wrapper, re._pattern_type)
    assert isinstance(psmd._re_ps_module, list)
    assert isinstance(psmd._re_cs_module, list)
    assert isinstance(psmd._re_cs_in_ps_module, list)
    assert isinstance(psmd._re_ps_version, re._pattern_type)
    assert isinstance(psmd._re_os_version, re._pattern_type)
    assert isinstance(psmd._re_become, re._pattern_type)


# Generated at 2022-06-20 14:22:06.421147
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'''Add-Foo(){\r\nImport-Module Ansible.ModuleUtils.Test.Foo\r\n}''')
    assert set(finder.ps_modules.keys()) == {'Ansible.ModuleUtils.Test.Foo'}
    finder = PSModuleDepFinder()
    finder.scan_module(b'''Add-Foo(){\r\nImport-Module ..module_utils.Foo\r\n}''')
    assert finder.ps_modules.keys() == {'../module_utils.Foo'}


# Generated at 2022-06-20 14:22:18.011811
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_utils = PSModuleDepFinder()
    # The first argument is the script name, the second argument is the module data.
    module_utils.scan_exec_script("Test_script", "#Requires -Module Ansible.ModuleUtils.Test_module")
    assert len(module_utils.exec_scripts.keys()) == 1
    assert module_utils.exec_scripts["Test_script"] == "".encode('utf-8')
    assert len(module_utils.ps_modules.keys()) == 1
    assert module_utils.ps_modules['Ansible.ModuleUtils.Test_module']['data'] == "#Requires -Module Ansible.ModuleUtils.Test_module".encode('utf-8')

# Generated at 2022-06-20 14:22:31.624902
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()
    assert obj.ps_modules == dict()
    assert obj.exec_scripts == dict()
    assert obj.cs_utils_wrapper == dict()
    assert obj.cs_utils_module == dict()
    assert obj.ps_version is None
    assert obj.os_version is None
    assert obj.become is False
    assert len(obj._re_cs_module) == 1
    assert len(obj._re_ps_module) == 2
    assert obj._re_wrapper is not None
    assert obj._re_ps_version is not None
    assert obj._re_os_version is not None
    assert obj._re_become is not None


# Generated at 2022-06-20 14:22:42.782632
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:48.537012
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Unit test for constructor of class PSModuleDepFinder
    """
    ps_mod_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_mod_dep_finder, PSModuleDepFinder)
    assert isinstance(ps_mod_dep_finder.ps_modules, dict)
    assert isinstance(ps_mod_dep_finder.cs_utils_wrapper, dict)
    assert isinstance(ps_mod_dep_finder.cs_utils_module, dict)
    assert ps_mod_dep_finder.ps_version is None
    assert ps_mod_dep_finder.os_version is None
    assert ps_mod_dep_finder.become is False


# Generated at 2022-06-20 14:22:59.856797
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:05.298888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()
    mu.scan_exec_script('JsonSerializer')
    # The JsonSerializer module has a dependency on the GeneratorUtil module
    assert mu.ps_modules[u'Ansible.GeneratorUtil']['data'] is not None


# Generated at 2022-06-20 14:23:12.651297
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ''' _scan_exec_script - scans lib/ansible/executor/powershell for scripts used in the module exec side. It also scans these scripts for any dependencies'''
    # Initializes an object of the class PSModuleDepFinder
    p = PSModuleDepFinder()
    # Runs the method scan_exec_script with the valid arguments
    p.scan_exec_script(name="Ansible.ModuleUtils.CommonArgs")

# Generated at 2022-06-20 14:23:16.484396
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.executor.powershell
    mod = PSModuleDepFinder()
    mod.scan_exec_script('ExecutionFramework')
    assert isinstance (mod.exec_scripts, Mapping)


# Generated at 2022-06-20 14:23:55.711412
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)
    dep_finder.scan_module(b'#Requires -Modules Ansible.ModuleUtils.AnotherModule')
    assert b'Ansible.ModuleUtils.AnotherModule' in dep_finder.ps_modules
    assert b'Ansible.ModuleUtils.Powershell' in dep_finder.ps_modules
    assert b'Ansible.ModuleUtils.CSharp' in dep_finder.ps_modules
    dep_finder.scan_module(b'#Requires -Modules Ansible.ModuleUtils.CSharp -Version 1.1')
    assert dep_finder.ps_version == '1.1.0'

# Generated at 2022-06-20 14:24:08.501420
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import shutil
    import textwrap

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _create_temp_file(data):
        fd, path = tempfile.mkstemp(text=False)
        os.close(fd)
        _write_file(path, data)
        return path

    def _cleanup_temp_file(path):
        try:
            os.unlink(path)
        except OSError:
            pass


# Generated at 2022-06-20 14:24:21.942745
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Multiple calls to scan_module should keep the dependencies
    dep_finder = PSModuleDepFinder()
    # Builtin module_util reference
    dep_finder.scan_module('#Requires -Module Ansible.ModuleUtils.Mocks')
    # Builtin module_util reference 2
    dep_finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.Mocks')
    # Collection module_utils reference
    dep_finder.scan_module('#Requires -Module ansible_collections.ansible.builtin.plugins.module_utils.powershell.common')
    # Collection module_utils reference 2
    dep_finder.scan_module('#AnsibleRequires -PowerShell ansible_collections.ansible.builtin.plugins.module_utils.powershell.common')
    # Builtin module_util reference

# Generated at 2022-06-20 14:24:24.059564
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    x = PSModuleDepFinder()
    assert type(x) is PSModuleDepFinder



# Generated at 2022-06-20 14:24:29.655470
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("Test Started")
    mod_dep_finder = PSModuleDepFinder()
    mod_dep_finder.scan_exec_script('ansible.module_utils.network.common.utils')
    assert "ansible.module_utils.network.common.utils" in mod_dep_finder.exec_scripts.keys()
    print("Test Completed")



# Generated at 2022-06-20 14:24:40.673276
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder_scan_module_object = PSModuleDepFinder()
    test_PSModuleDepFinder_scan_exec_script_var_name = 'TestPSModuleDepFinderScanExecScriptVar'
    test_PSModuleDepFinder_scan_exec_script_var_value = 'TestPSModuleDepFinderScanExecScriptVarValue'
    os.environ[test_PSModuleDepFinder_scan_exec_script_var_name] = test_PSModuleDepFinder_scan_exec_script_var_value

# Generated at 2022-06-20 14:24:52.195980
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psf = PSModuleDepFinder()

    psmodule_data = """
#AnsibleRequires -Powershell Ansible.ModuleUtils.PowerShell.EvaluateEnvPath
#Requires -Module Ansible.ModuleUtils.PSCore
#Requires -Module Ansible.ModuleUtils.CommonUtils
"""
    psf.scan_module(psmodule_data)

    assert set(psf.ps_modules.keys()) == {"Ansible.ModuleUtils.PowerShell.EvaluateEnvPath",
                                          "Ansible.ModuleUtils.PSCore",
                                          "Ansible.ModuleUtils.CommonUtils"}


# Generated at 2022-06-20 14:25:01.949738
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test verifies the scanning of executor powershell scripts
    finder = PSModuleDepFinder()
    name = "test_script"
    # checks a script which does not exist
    try:
        finder.scan_exec_script(name)
        assert False
    except AnsibleError:
        pass
    else:
        assert False

    # checks a script which exists
    finder.scan_exec_script("wait_for")
    assert finder.exec_scripts["wait_for"] is not None
    assert b"ansible.module_utils.six" in finder.cs_utils_wrapper
    assert b"ansible.module_utils.six" not in finder.cs_utils_module



# Generated at 2022-06-20 14:25:07.208799
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    name = "eval"
    ps_module_dep_finder.scan_exec_script(name)
    assert(ps_module_dep_finder.exec_scripts["eval"])

# Generated at 2022-06-20 14:25:20.742817
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()
    assert ps_module_dep_finder.cs_utils_wrapper == dict()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
