

# Generated at 2022-06-20 14:15:49.407064
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder.__name__ == "PSModuleDepFinder"

# Generated at 2022-06-20 14:15:58.783310
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:09.666417
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.FooBar")
    dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Phantom")
    dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.FooBar")
    assert len(dep_finder.ps_modules) == 2
    assert dep_finder.ps_modules[u'Ansible.ModuleUtils.FooBar']['data'].startswith(b"#foo")
    assert dep_finder.ps_modules[u'Ansible.ModuleUtils.Phantom']['data'].startswith(b"#phantom")
    # Unit test for method scan_module of class PSModuleDep

# Generated at 2022-06-20 14:16:10.369567
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-20 14:16:19.805200
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_modules = dict()
    ps_samples = dict()
    extra_module_paths = list()
    for root, dirs, files in os.walk(C.DEFAULT_MODULE_PATH):
        if root.endswith('module_utils'):
            extra_module_paths.append(root)
    ps_module_utils_loader.add_directory(extra_module_paths)
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:16:31.428720
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:47.677948
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():  # noqa: F541
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, object)
    assert isinstance(dep_finder.ps_modules, dict)
    assert isinstance(dep_finder.exec_scripts, dict)
    assert isinstance(dep_finder.cs_utils_wrapper, dict)
    assert isinstance(dep_finder.cs_utils_module, dict)
    assert isinstance(dep_finder.ps_version, None)
    assert isinstance(dep_finder.os_version, None)
    assert isinstance(dep_finder.become, False)
    assert isinstance(dep_finder._re_cs_module[0], type(re.compile("")))

# Generated at 2022-06-20 14:16:57.269772
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module("test" + os.linesep + "#AnsibleRequires -CSharpUtil Ansible.network.common.winrm")
    assert finder.cs_utils_module["Ansible.network.common.winrm"]
    finder.scan_module("test" + os.linesep + "#AnsibleRequires -CSharpUtil ansible_collections.ns.collection.plugins.module_utils.name")
    assert finder.cs_utils_module["ansible_collections.ns.collection.plugins.module_utils.name"]
    finder.scan_module("test" + os.linesep + "#AnsibleRequires -CSharpUtil .module_utils.name")
    assert finder.cs_utils_module[".module_utils.name"]


# Generated at 2022-06-20 14:17:04.163390
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmd_finder = PSModuleDepFinder()
    assert psmd_finder.ps_modules == {}
    assert psmd_finder.cs_utils_wrapper == {}
    assert psmd_finder.ps_version is None
    assert psmd_finder.os_version is None
    assert psmd_finder.become is False


# Generated at 2022-06-20 14:17:09.052729
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Unit test that ensures all methods of the PSModuleDepFinder class
    are found and it is safe to call the scan_module method.
    :return: None
    """
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module('Some module data.', 'FQCN', False, True)
    assert dep_finder is not None


# Generated at 2022-06-20 14:17:26.400596
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmd = PSModuleDepFinder()
    assert pmd is not None


# Generated at 2022-06-20 14:17:31.110186
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.moduledeps_found_in_executor_scripts = set()
    module_dep_finder.scan_exec_script('Common')
    assert module_dep_finder.moduledeps_found_in_executor_scripts == set()

# Generated at 2022-06-20 14:17:45.009959
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # tests the scan_exec_script method of PSModuleDepFinder. This method
    # scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies

    # create a basic PSModuleDepFinder
    tmp_dir = tempfile.mkdtemp()
    mock_file_system = {}
    mock_file_system['ansible_collections.namespace.collection.plugins.module_utils.util.psm1'] = '\n'.join([
        '#Requires -Module Ansible.ModuleUtils.Util2',
        '#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.CSUtil1'
    ])

# Generated at 2022-06-20 14:17:54.374224
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from collections import defaultdict
    from ansible.module_utils.basic import AnsibleModule

    # ansible_collections.microsoft.powershell.core.windows
    # microsoft.powershell.core.windows.tests.unit.compat
    # microsoft.powershell.core.windows.plugins.module_utils.module_base
    # microsoft.powershell.core.windows.plugins.module_utils.win_module_utils
    # microsoft.powershell.core.powershell_runner

    def _real_module_dep_finder(name, *args):
        return json.loads(PSModuleDepFinder().scan_module(MODULES[name]))

    PSModuleDepFinder.module_dep_finder = _real_module_dep_finder

# Generated at 2022-06-20 14:18:07.524685
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    s = PSModuleDepFinder()
    m1 = "unit_test_module_a.psm1"
    m2 = "unit_test_module_b.psm1"
    m3 = "unit_test_module_c.psm1"
    m4 = "unit_test_module_d.psm1"
    m5 = "unit_test_module_e.psm1"
    m6 = "unit_test_module_f.psm1"

    # create a module that references each of the others, even if they do not
    # exist
    m1_data = "#requires -Module %s\n#requires -Module %s\n#requires -Module %s" % (m2, m3, m4)

    # create a module that references another module and an invalid module
    m2_

# Generated at 2022-06-20 14:18:14.601805
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert all(re.match(r'(?i)^#\s*ansiblerequires\s+-powershell\s+(.*)', x.pattern) for x in dep_finder._re_ps_module)
    assert all(re.match(r'(?i)^#\s*ansiblerequires\s+-powershell\s+(.*)', x.pattern) for x in dep_finder._re_cs_in_ps_module)
    assert all(re.match(r'(?i)^using\s(Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+);\s*$', x.pattern) for x in dep_finder._re_cs_module)

# Generated at 2022-06-20 14:18:21.059389
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = b"""#
# Paging and remote text file support
#

$PSScriptRoot = Split-Path $script:MyInvocation.MyCommand.Path -Parent
$ScriptPath = $PSScriptRoot + '\module_utils\basic.psm1'
. $ScriptPath

"""
    assert scan_exec_script(data) == data

# Generated at 2022-06-20 14:18:27.768898
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder._add_module = MockModuleUtil()
    finder.scan_exec_script("ansible_powershell.dll")
    assert "ansible_powershell.dll" in finder.exec_scripts.keys()
    assert os.path.exists(os.path.dirname(__file__) + "/../../lib/ansible/executor/powershell/ansible_powershell.dll")



# Generated at 2022-06-20 14:18:35.722046
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # init the object
    ps_module_dep_finder = PSModuleDepFinder()

    # test the scan_module with a module data, fqn and wrapper.

# Generated at 2022-06-20 14:18:47.096087
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module("#Requires -Module Ansible.ModuleUtils.Windows.Version")
    assert(ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Windows.Version']['path'] is None)
    assert(ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Windows.Version']['data'] is None)
    assert(ps_module_dep_finder.ps_version is None)
    assert(ps_module_dep_finder.os_version is None)
    assert(ps_module_dep_finder.become is None)
    assert(ps_module_dep_finder.exec_scripts is {})


# Generated at 2022-06-20 14:19:42.728685
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:19:49.054052
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_util_example = '''
    #AnsibleRequires -Wrapper Ansible.ModuleUtils.{name}
    #AnsibleRequires -PowerShell ..module_utils.{name}
    #AnsibleRequires -CSharpUtil Ansible.{name}
    '''
    ps_module_util_example = '''
    #AnsibleRequires -Wrapper Ansible.ModuleUtils.{name}
    #AnsibleRequires -PowerShell ..module_utils.{name}
    #AnsibleRequires -CSharpUtil Ansible.{name}
    '''

# Generated at 2022-06-20 14:19:50.969938
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  # TODO: test
  return None


# Generated at 2022-06-20 14:20:03.174548
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()

    assert psmdf.ps_version == None
    assert psmdf.os_version == None
    assert psmdf.become == False

    assert len(psmdf._re_cs_module) == 1
    assert len(psmdf._re_cs_in_ps_module) == 1
    assert len(psmdf._re_ps_module) == 2
    assert len(psmdf._re_wrapper) == 1
    assert len(psmdf._re_ps_version) == 1

# Generated at 2022-06-20 14:20:07.509279
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
  finder = PSModuleDepFinder ()

  assert finder.ps_modules == {}
  assert finder.cs_utils_wrapper == {}
  assert finder.cs_utils_module == {}
  assert finder.ps_version == None
  assert finder.os_version == None
  assert finder.become == False


# Generated at 2022-06-20 14:20:13.524447
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_finder = PSModuleDepFinder()
    ps_finder.scan_exec_script("ping")

    assert len(ps_finder.exec_scripts.keys()) == 1
    assert "ping" in ps_finder.exec_scripts.keys()



# Generated at 2022-06-20 14:20:23.764707
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create PSModuleDepFinder object
    obj = PSModuleDepFinder()
    # add test case data to the class
    obj.cs_utils_wrapper = dict()
    obj.cs_utils_wrapper['my_cs_util'] = {}
    obj.exec_scripts = dict()
    obj.exec_scripts['my_script'] = 'data'
    # call the method with the required parameters
    assert obj.scan_exec_script('my_script') == None
    # validate return data
    # This only tests one case, needs more testing
    assert obj.cs_utils_wrapper['my_cs_util'] == {}
    assert obj.exec_scripts['my_script'] == 'data'

# Generated at 2022-06-20 14:20:26.891844
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)

# Unit tests for method scan_module

# Generated at 2022-06-20 14:20:37.868970
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert not f.ps_modules
    assert not f.exec_scripts
    assert not f.cs_utils_wrapper
    assert not f.cs_utils_module
    assert not f.ps_version
    assert not f.os_version
    assert not f.become
    assert len(f._re_cs_module) == 1
    assert len(f._re_cs_in_ps_module) == 1
    assert len(f._re_ps_module) == 2
    assert f._re_wrapper
    assert f._re_ps_version
    assert f._re_os_version
    assert f._re_become



# Generated at 2022-06-20 14:20:46.243901
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:21:46.025879
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module("#Requires -Module Ansible.ModuleUtils.Foo", 'foo.bar')

# Generated at 2022-06-20 14:21:48.282472
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert type(finder) is PSModuleDepFinder


# Generated at 2022-06-20 14:21:56.252021
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = to_bytes("# AnsibleRequires -PowerShell Ansible.ModuleUtils.Legacy.dll\n"
                           "# AnsibleRequires -PowerShell Ansible.ModuleUtils.SqlServer")
    finder.scan_module(module_data)

    assert finder.ps_modules.keys() == {
        "Ansible.ModuleUtils.Legacy.dll",
        "Ansible.ModuleUtils.SqlServer",
    }


# Generated at 2022-06-20 14:21:59.228578
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmod_dep_finder = PSModuleDepFinder()
    name = 'some_name'
    psmod_dep_finder.scan_exec_script(name)
    assert psmod_dep_finder.exec_scripts[name]



# Generated at 2022-06-20 14:22:03.797709
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = "this is the data".encode('utf-8')
    def get_data(name):
        if name == "name.ps1":
            return data
        else:
            return None

    test_finder = PSModuleDepFinder()
    test_finder.scan_exec_script("name")

    assert test_finder.exec_scripts["name"] == data


# Generated at 2022-06-20 14:22:16.857374
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    depfinder = PSModuleDepFinder()
    assert depfinder._re_cs_module is not None
    assert depfinder._re_cs_in_ps_module is not None
    assert depfinder._re_ps_module is not None
    assert depfinder._re_wrapper is not None
    assert depfinder._re_ps_version is not None
    assert depfinder._re_os_version is not None
    assert depfinder._re_become is not None
    assert depfinder.ps_modules is not None
    assert depfinder.cs_utils_wrapper is not None
    assert depfinder.cs_utils_module is not None
    assert depfinder.exec_scripts is not None
    assert depfinder.ps_version is None
    assert depfinder.os_version is None
    assert depfinder.become is False


# Generated at 2022-06-20 14:22:25.344872
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test name for the module_util file
    module_util_name = 'test_module_util'

    # Test module_util data
    module_util_data = b'#Requires -Module Ansible.NoSuchModule\n'

    # Create module_util in tests/support/module_utils/
    module_util_path = os.path.join(C.DEFAULT_MODULE_UTILS_PATH, module_util_name + C.DEFAULT_MODULE_UTILS_PATH[-1] + ".psm1")
    with open(module_util_path, "wb") as f:
        f.write(module_util_data)

    # Test module data
    module_data = b'#Requires -Module Ansible.ModuleUtils.%s\n' % to_bytes(module_util_name)

   

# Generated at 2022-06-20 14:22:36.950037
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:41.351715
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert hasattr(PSModuleDepFinder, "scan_module")
    assert hasattr(PSModuleDepFinder, "scan_exec_script")
    assert hasattr(PSModuleDepFinder, "_add_module")
    assert hasattr(PSModuleDepFinder, "_parse_version_match")



# Generated at 2022-06-20 14:22:54.966938
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import json
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(('#Requires -Module Ansible.ModuleUtils.Logic') + ('\n') + ('#Requires -Module Ansible.ModuleUtils.OperatingSystem'))
    expect = {'Ansible.ModuleUtils.Logic': {'data': '', 'path': ''}, 'Ansible.ModuleUtils.OperatingSystem': {'data': '', 'path': ''}}
    #assert psmdf.ps_modules == json.dumps(expect)
    assert psmdf.ps_modules == expect
    psmdf.scan_module(('#Requires -Module Ansible.ModuleUtils.Logic') + ('\n') + ('#Requires -Module Ansible.ModuleUtils.OperatingSystem'))

# Generated at 2022-06-20 14:24:39.511674
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:51.559214
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # what version of PowerShell to set the wrapper to use
    wrapper_ps_version = '5.1'

    # create the required util directories
    lib_utils_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'module_utils', 'powershell')
    lib_exec_utils_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'executor', 'powershell')
    collection_utils_dir = tempfile.mkdtemp()

    # create a collection (and add it to the module search path) which contains the module and the module_utils it depends upon
    collection_name = 'test_collection'
    collection_dir = os.path.join

# Generated at 2022-06-20 14:25:01.848252
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.loader import ansible_module_finder

    fakepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fake_modules')
    fake_mod_finder = ansible_module_finder.ModuleFinder(fakepath)
    fake_mod_finder._re_mod_patt = [re.compile(b'(?i)^(?P<name>\w+).(?P<ext>py|ps1)(.in)?$')]
    fake_mod_finder._load_plugins_from_path(fakepath)
    fake_module_list = fake_mod_finder._plugins
    fake_module = fake_module_list['fake_module_with_deps']
    fake_module_data = fake_module['data']

    ps

# Generated at 2022-06-20 14:25:11.311889
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test scan_exec_script of class PSModuleDepFinder.

    Parameters
    ----------
    :param Ansible: An Ansible object.

    :returns: No return.
    """
    dummy_dep_finder = PSModuleDepFinder()
    dummy_dep_finder.scan_exec_script("powershell.ps1")
    dummy_dep_finder.scan_exec_script("Network.ps1")
    dummy_dep_finder.scan_exec_script("Windows.ps1")
    dummy_dep_finder.scan_exec_script("winrm.ps1")
    dummy_dep_finder.scan_exec_script("ConfigureRemotingForAnsible.ps1")



# Generated at 2022-06-20 14:25:13.327156
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('CommonUtils')

# Generated at 2022-06-20 14:25:24.855497
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    import unittest

    class TestPSModuleDepFinderScanModule(unittest.TestCase):

        def test_PSModuleDepFinder_scan_module_fail(self):
            with self.assertRaises(AnsibleError):
                PSModuleDepFinder().scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.test.test.plugins.module_utils.test')

    unittest.main()

    # unittest.main()
