

# Generated at 2022-06-20 14:15:53.666279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Change the above scandit function to a testing function for this unit test.
    # This is needed since scan_exec_script doesn't return anything.
    if not hasattr(PSModuleDepFinder, '_scan_exec_script_for_test'):
        PSModuleDepFinder._scan_exec_script_for_test = PSModuleDepFinder.scan_exec_script
        PSModuleDepFinder.scan_exec_script = PSModuleDepFinder._scan_exec_script_for_test
        del PSModuleDepFinder._scan_exec_script_for_test
    wrapper_name = "unit-test"
    module_dep_finder = PSModuleDepFinder()
    # Check that scan_exec_script adds a name to the self.exec_scripts dict

# Generated at 2022-06-20 14:15:54.996873
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder_obj = PSModuleDepFinder()
    psModuleDepFinder_obj.scan_exec_script(name="powershell_5x")
    assert True


# Generated at 2022-06-20 14:16:08.228993
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Arrange
    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:16:16.458830
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:23.407611
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_object = PSModuleDepFinder()
    my_object.scan_exec_script('main')
    assert my_object.exec_scripts

# Generated at 2022-06-20 14:16:24.587764
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	pass


# Generated at 2022-06-20 14:16:31.315512
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    # noinspection PyUnusedLocal
    def mock_scan_module(module_data, fqn=None, wrapper=False, powershell=True):
        return pathlib.Path(__file__).parent / "mock_modules" / "mock_cs_module_deps_simple.cs"

    module_dep_finder.scan_module = mock_scan_module
    module_dep_finder.scan_exec_script("mock_name")
    # expected_exec_scripts = {"mock_name": "mock_exec_script_data"}
    expected_exec_scripts = {"mock_name": None}
    assert module_dep_finder.exec_scripts == expected_exec_scripts


# Generated at 2022-06-20 14:16:35.614066
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.powershell.powerShellUtil import create_exec_wrapper_script, create_cmdlet_wrapper_script  # noqa

    # create a test module to test the dependecy finder.

# Generated at 2022-06-20 14:16:40.058256
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert len(dep_finder.exec_scripts) == 0
    dep_finder.scan_exec_script("executor.ps1")
    assert len(dep_finder.exec_scripts) > 0

            # Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:48.057340
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    assert len(finder._re_cs_module) == 1
    assert len(finder._re_cs_in_ps_module) == 1
    assert len(finder._re_ps_module) == 2
    assert finder._re_wrapper is not None
    assert finder._re_ps_version is not None
    assert finder._re_os_version is not None
    assert finder._re_become is not None

#

# Generated at 2022-06-20 14:17:03.178202
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:17:03.870903
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-20 14:17:14.392880
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # For now a manual test for validation.
    p = PSModuleDepFinder()
    p.scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.ns.collect.plugins.module_utils.foo')
    p.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.foo')
    p.scan_module(b'#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.foo')
    p.scan_module(b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.foo')
    p.scan_module(b'#AnsibleRequires -CSharpUtil ..module_utils.foo')

# Generated at 2022-06-20 14:17:26.053623
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import sys
    import json
    import base64

# Generated at 2022-06-20 14:17:27.045486
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # TODO
    pass



# Generated at 2022-06-20 14:17:28.992884
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("script")
    assert finder.exec_scripts == {'script': {}}


# Generated at 2022-06-20 14:17:36.335524
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    # Type check for PSModuleDepFinder.scan_module
    assert is_instance(PSModuleDepFinder().scan_module(None), None)
    assert is_instance(PSModuleDepFinder().scan_module(None, fqn=None, wrapper=False, powershell=True), None)
    assert is_instance(PSModuleDepFinder().scan_module(None, fqn=None, wrapper=True, powershell=False), None)

# Generated at 2022-06-20 14:17:48.091907
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()

# Generated at 2022-06-20 14:17:53.998483
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module = PSModuleDepFinder()
    module.scan_module(to_bytes('''#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz
#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Version 1
#Requires -Version 1.0.0
#Requires -Version 1.1.1
#Requires -Version 2.0.0
#Requires -Version 5
'''), wrapper=False)

# Generated at 2022-06-20 14:17:58.151707
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    name = 'base'
    if name in ps_module_dep_finder.exec_scripts.keys():
        pass
    

# Generated at 2022-06-20 14:18:13.949007
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()

# Generated at 2022-06-20 14:18:19.575935
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup test data
    finder = PSModuleDepFinder()
    name = 'Add-AnsibleGroupMember'

    # Execute the code to be tested
    finder.scan_exec_script(name)

    # Verify the result
    assert finder.exec_scripts[name]


# Generated at 2022-06-20 14:18:24.772804
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()
    assert f.ps_modules == dict()
    assert f.ps_version is None
    assert f.os_version is None
    assert f.exec_scripts == dict()
    assert f.cs_utils_wrapper == dict()
    assert f.cs_utils_module == dict()



# Generated at 2022-06-20 14:18:27.200264
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmodule_finder = PSModuleDepFinder()
    assert isinstance(psmodule_finder, PSModuleDepFinder)



# Generated at 2022-06-20 14:18:35.275813
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ansible_collections')
    fqn_module = 'ansible_collections.openstack.openstack.plugins.modules.ironic_port'
    module, fqn = resource_from_fqcr(fqn_module)
    module_data = get_data(module)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data, fqn)
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder.cs_utils_module == {}

# Generated at 2022-06-20 14:18:47.142788
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    print(obj.scan_exec_script(name='ansible.builtin.basic'))
    print(obj.scan_exec_script(name='ansible.builtin.copy'))
    print(obj.scan_exec_script(name='ansible.builtin.debug'))
    print(obj.scan_exec_script(name='ansible.builtin.get_url'))
    print(obj.scan_exec_script(name='ansible.builtin.uri'))
    print(obj.scan_exec_script(name='ansible.builtin.git'))
    print(obj.scan_exec_script(name='ansible.builtin.shell'))
    print(obj.scan_exec_script(name='ansible.builtin.win_template'))
   

# Generated at 2022-06-20 14:18:52.890468
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to ensure that if scan_exec_script is called with invalid
    # script name then the exception is raised
    test_instance = PSModuleDepFinder()
    try:
        test_instance.scan_exec_script("invalid_script_name")
    except AnsibleError:
        pass

    # Test to ensure that if scan_exec_script is called with valid
    # script name then the execution is successful
    test_instance.scan_exec_script("test_script")



# Generated at 2022-06-20 14:18:56.074397
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('ExecutionWrapper')



# Generated at 2022-06-20 14:19:02.750018
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert len(dep_finder._re_cs_module) > 0
    assert len(dep_finder._re_cs_in_ps_module) > 0
    assert len(dep_finder._re_ps_module) > 0

    assert isinstance(dep_finder._re_cs_module[0], re._pattern_type)
    assert isinstance(dep_finder._re_cs_in_ps_module[0], re._pattern_type)
    assert isinstance(dep_finder._re_ps_module[0], re._pattern_type)

    assert isinstance(dep_finder._re_wrapper, re._pattern_type)
    assert isinstance(dep_finder._re_ps_version, re._pattern_type)

# Generated at 2022-06-20 14:19:17.351235
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import ansible.executor.powershell
    # test for function scan_exec_script when name is present in exec_scripts
    pmdf = PSModuleDepFinder()
    pmdf.exec_scripts = {
        'powershell_runner':'file1',
        'powershell':'file2'
    }
    assert pmdf.scan_exec_script('powershell_runner') is None
    # test for when name is not present and data is not None
    pmdf = PSModuleDepFinder()
    assert pmdf.scan_exec_script('powershell') is None
    # test for when data is None and err.errno is errno.ENOENT
    import errno
    pmdf = PSModuleDepFinder()
    pmdf.scan_exec_script('powershell_runner')

# Generated at 2022-06-20 14:19:44.879167
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    db = PSModuleDepFinder()

    # Test the CS module is parsed correctly
    cs_module_filename = os.path.join(os.path.dirname(__file__), "cs_module_utils", "test_module_utils.cs")
    with open(cs_module_filename, "rb") as f:
        module_data = f.read()

    db.scan_module(module_data, wrapper=False, powershell=False)

# Generated at 2022-06-20 14:19:51.158165
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_fixture = '''\
#foo bar
# requires -version 2.0
#ansiblerequires -wrapper common
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test1
#AnsibleRequires -PowerShell ansible_collections.test.test_collection.plugins.module_utils.test2 -Optional
#AnsibleRequires -CSharpUtil ..module_utils.test3
#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.test4
#Requires -Module Ansible.ModuleUtils.Test5
#end of module
'''


# Generated at 2022-06-20 14:19:53.238461
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Any non-empty module_data should be OK
    module_data = b'# Requires -Module Ansible.ModuleUtils.CommonUtils'
    module_finder = PSModuleDepFinder()
    module_finder.scan_module(module_data)
    assert len(module_finder.ps_modules) == 1


# Generated at 2022-06-20 14:20:05.132161
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder._re_cs_module[0].search(to_bytes('using Ansible.ModuleUtils.Common;\n'))
    assert dep_finder._re_cs_in_ps_module[0].search(to_bytes('#AnsibleRequires -CSharpUtil "Ansible.ModuleUtils.Common"\n'))
    assert dep_finder._re_ps_module[0].search(to_bytes('#Requires -Module Ansible.ModuleUtils.Common\n'))
    assert dep_finder._re_ps_module[1].search(to_bytes('#AnsibleRequires -PowerShell "Ansible.ModuleUtils.Common"\n'))

# Generated at 2022-06-20 14:20:19.134966
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test reading a module which requires a module_util and an executor script
    import ansible.executor.powershell
    dep_finder = PSModuleDepFinder()
    ps_module_data = pkgutil.get_data("ansible.modules.windows.win_command", "win_command.ps1")

    dep_finder.scan_module(ps_module_data)

    assert 'Ansible.ModuleUtils.Legacy' in dep_finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Argument' in dep_finder.ps_modules.keys()

    assert 'Ansible.ModuleUtils.Legacy' in dep_finder.cs_utils_module.keys()
    assert 'Ansible.ModuleUtils.Argument' in dep_finder.cs_utils_module.keys()

# Generated at 2022-06-20 14:20:27.827957
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_module(
        b'''#Requires -Module Ansible.ModuleUtils.Windows
#AnsibleRequires -CSharpUtil ansible.module_utils.microsoft.winrm''',
        to_text("ansible.plugins.test_module"),
        wrapper=False,
        powershell=True
    )

    assert len(dep_finder.ps_modules) == 1
    assert dep_finder.ps_modules[to_text('Ansible.ModuleUtils.Windows')]['path'].endswith('Ansible.ModuleUtils.Windows.psm1')

    assert len(dep_finder.cs_utils_module) == 1

# Generated at 2022-06-20 14:20:29.273315
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-20 14:20:41.058553
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    assert len(mdf.ps_modules) == 0
    assert len(mdf.cs_utils_wrapper) == 0
    assert len(mdf.cs_utils_module) == 0
    assert len(mdf.exec_scripts) == 0
    assert mdf.ps_version is None
    assert mdf.os_version is None
    assert mdf.become is False
    assert len(mdf._re_cs_module) == 1
    assert len(mdf._re_cs_in_ps_module) == 1
    assert len(mdf._re_ps_module) == 2

# Generated at 2022-06-20 14:20:48.653688
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:58.609393
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.executor.powershell.payloads import _strip_comments
    from ansible.module_utils._text import _slurp
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import ConnectionError, OpenSSLObject, get_connection
    from ansible.plugins.loader import module_loader
    
    # This is also used by validate-modules to get a module's required utils in base and a collection.
    ps_modules = dict()
    exec_scripts = dict()

    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn

# Generated at 2022-06-20 14:21:18.316728
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mod_data = """#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo
#AnsibleRequires -PowerShell ansible_collections.mynamespace.mycollection.plugins.module_utils.MyModuleUtil"""

# Generated at 2022-06-20 14:21:19.136150
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-20 14:21:24.360598
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()
    assert module_finder.ps_modules == dict()
    assert module_finder.cs_utils_wrapper == dict()
    assert module_finder.cs_utils_module == dict()
    assert module_finder.ps_version is None
    assert module_finder.os_version is None
    assert module_finder.become is False


# Generated at 2022-06-20 14:21:27.396763
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(
        b"""#Requires -Module ansible.module_utils.basic
""")

    assert finder.ps_modules["ansible.module_utils.basic"]

# Generated at 2022-06-20 14:21:44.244840
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False

# Generated at 2022-06-20 14:21:51.354072
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # given
    module_data = 'using Ansible.ModuleUtils.Common;\nusing Ansible.ModuleUtils.Common.System;\n'
    dep_finder = PSModuleDepFinder()

    # when
    dep_finder.scan_module(module_data)

    # then
    assert 'Ansible.ModuleUtils.Common' in dep_finder.cs_utils_module
    assert 'Ansible.ModuleUtils.Common.System' in dep_finder.cs_utils_module


# Generated at 2022-06-20 14:22:02.104636
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder.ps_modules, dict)
    assert isinstance(dep_finder.cs_utils_wrapper, dict)
    assert isinstance(dep_finder.cs_utils_module, dict)
    assert dep_finder.ps_version is None
    assert dep_finder.become is False
    for pattern in dep_finder._re_cs_in_ps_module:
        assert isinstance(pattern, re._pattern_type)
    for pattern in dep_finder._re_ps_module:
        assert isinstance(pattern, re._pattern_type)
    assert isinstance(dep_finder._re_wrapper, re._pattern_type)
    assert isinstance(dep_finder._re_ps_version, re._pattern_type)

# Generated at 2022-06-20 14:22:15.879400
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # initialize
    import os
    import tempfile
    import random
    import string

    # prepare outline of a module
    # new-line at the file end is needed to avoid the following error upon deserialization of the file:
    #    "ValueError: Expecting , delimiter: line 1 column 3 (char 2)"
    # file_outline = '\n#Requires -Module Ansible.ModuleUtils.{name}\n'
    file_outline = '\n#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}\n'

    # add tear down method
    import atexit
    # remove files created in /tmp
    def delete_files(files):
        for f in files:
            os.remove(f)
    atexit.register(delete_files, files=[])

    # generate a module name


# Generated at 2022-06-20 14:22:17.013807
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test
    assert True



# Generated at 2022-06-20 14:22:25.434908
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("\nValidating the method scan_module of class PSModuleDepFinder")

    psmdf = PSModuleDepFinder()

    # script that uses a collection module util

# Generated at 2022-06-20 14:22:42.260534
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()

    assert isinstance(obj.ps_modules, dict)
    assert isinstance(obj.ps_version, type(None))
    assert isinstance(obj.os_version, type(None))
    assert isinstance(obj.become, bool)
    assert isinstance(obj.exec_scripts, dict)
    assert isinstance(obj.cs_utils_wrapper, dict)
    assert isinstance(obj.cs_utils_module, dict)


# Helper function to slurp a file given an absolute file path

# Generated at 2022-06-20 14:22:44.734246
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert not p.ps_modules
    assert not p.exec_scripts



# Generated at 2022-06-20 14:22:57.446676
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Test PSModuleDepFinder class
    """
    PSModuleDepFinder()

# Get dependency finder object
finder = PSModuleDepFinder()

# This file is used both by the module code and by a check to see if the Python
# module code requires a new module code file to be generated.  We don't want
# to generate it for the check.
try:
    fqn = 'ansible.plugins.action.ping'
    module_data = resource_from_fqcr(to_text(fqn), 'action_plugins')
except AnsibleError:
    # The data argument likely isn't set, we're just going to use the default
    # ping module packaged with Ansible.
    module_data = None


# Generated at 2022-06-20 14:23:01.832602
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module = '''
    #Requires -Module Ansible.ModuleUtils.CommonUtils
    function test_function()
    {
        Write-Host 'test'
    }
    '''

    cs_module = '''
    using Ansible.Common.Collections;
    using Ansible.ModuleUtils.CommonUtils;
    using Ansible.ModuleUtils.PowerShell;

    public class MockModule : PowerShellModule
    {
        public MockModule() : base("", "")
        {
        }

        public static string Run(params object[] objects)
        {
            return null;
        }
    }
    '''


# Generated at 2022-06-20 14:23:08.129885
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()
    ps_dep_finder.scan_module('#Requires -modules ansible.builtin.win_copy')
    ps_dep_finder.scan_module('#AnsibleRequires -Powershell ansible.builtin.win_copy')
    ps_dep_finder.scan_module('#AnsibleRequires -CSharpUtil ansible_collections.test.test.plugins.module_utils.test')


# Generated at 2022-06-20 14:23:09.263188
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()


# Generated at 2022-06-20 14:23:12.181327
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dept_finder = PSModuleDepFinder()
    assert ps_module_dept_finder is not None


# Generated at 2022-06-20 14:23:24.396640
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()

    # Test what happens when an invalid C# module is called in a PowerShell module
    with pytest.raises(AnsibleError) as excinfo:
        psmdf.scan_module("#AnsibleRequires -CSharpUtil Not.A.Module;", fqn="Not.A.Module")
    excinfo.match("Could not find collection imported module support code for 'Not.A.Module'")

    # Test what happens when an invalid PowerShell module is called in a PowerShell module
    with pytest.raises(AnsibleError) as excinfo:
        psmdf.scan_module("#AnsibleRequires -PowerShell Not.A.Module;", fqn="My.Module")
    excinfo.match("Could not find imported module support code for 'Not.A.Module'")

# Generated at 2022-06-20 14:23:37.512079
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mdf = PSModuleDepFinder()
    assert mdf
    assert mdf.ps_modules
    assert mdf.cs_utils_module
    assert mdf.cs_utils_wrapper
    assert mdf._re_cs_module
    assert mdf._re_cs_in_ps_module
    assert mdf._re_ps_module
    assert mdf._re_wrapper
    assert mdf._re_ps_version
    assert mdf._re_os_version
    assert mdf._re_become
    assert mdf.opts == {}

# Tests for the function _strip_comments()
# Input:
# test_comment = 'Hi there, I am a comment\n'
# test_comment += 'and a multiline comment\n'
# test_comment += 'This is a comment with a # hash in

# Generated at 2022-06-20 14:23:40.159140
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_utils = PSModuleDepFinder()
    assert module_utils is not None


# Utility functions

# Generated at 2022-06-20 14:23:59.225051
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    assert len(re.findall(r'(?im)^#ansiblerequires\s+-powershell\s+',
                          b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell')) == 1
    assert len(re.findall(r'(?im)^#ansiblerequires\s+-powershell\s+',
                          b'     #AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell')) == 1
    assert len(re.findall(r'(?im)^#ansiblerequires\s+-powershell\s+',
                          b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell -Optional')) == 1

# Generated at 2022-06-20 14:24:11.664728
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:27.789622
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_module_data = to_bytes("""#
# Some comment
#

# Requires -Module Ansible.ModuleUtils.Something
# Requires -Module Some_Other.Thing
# Requires -Module Another.Thing
# AnsibleRequires -CSharpUtil Something
# AnsibleRequires -CSharpUtil Some_Other.Thing""")
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules["Ansible.ModuleUtils.Something"] = {"name": "Ansible.ModuleUtils.Something", "path": "/tmp/Ansible.ModuleUtils.Something.psm1"}
    dep_finder.ps_modules["Another.Thing"] = {"name": "Another.Thing", "path": "/tmp/Another.Thing.psm1"}
    dep_finder.cs_utils_

# Generated at 2022-06-20 14:24:31.129191
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-20 14:24:40.943335
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_module("""
#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
""")
    assert sorted(ps_module_dep_finder.ps_modules) == ['Ansible.ModuleUtils.Bar', 'Ansible.ModuleUtils.Foo']

    cs_module_dep_finder = PSModuleDepFinder()


# Generated at 2022-06-20 14:24:44.230023
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()

    print("PSModuleDepFinder object created with no issues.")


# Generate a random module name

# Generated at 2022-06-20 14:24:53.490914
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_dep_finder = PSModuleDepFinder()

    # Test regex patterns in PSModuleDepFinder
    # original way of referencing a builtin module_util
    assert ps_dep_finder._re_ps_module[0].match(b'''# Requires -Module Ansible.ModuleUtils.Powershell.Windows'''), \
        "original way of referencing a builtin module_util"

    # new way of referencing a builtin and collection module_util
    assert ps_dep_finder._re_ps_module[1].match(b'''# AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.Windows'''), \
        "new way of referencing a builtin and collection module_util"


# Generated at 2022-06-20 14:25:04.783725
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    name = 'TestModule'
    ext = '.psm1'
    # PS Module
    module_data="""#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.test.test
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.test.test_wrapper
#AnsibleRequires -CSharpUtil Ansible.Test_CS
#Requires -Version 2.0
#AnsibleRequires -Wrapper test_wrapper
#AnsibleRequires -OSVersion 6.3"""

    finder.scan_module(to_bytes(module_data), fqn=name, wrapper=False, powershell=True)


# Generated at 2022-06-20 14:25:10.976351
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Given an instance of a PSModuleDepFinder class
    ps_module_dep = PSModuleDepFinder()
    # When I call the scan_exec_script method, with a ps1 script name
    result = ps_module_dep.scan_exec_script("get_ps_version")
    # Then the result should be the ps1 script content
    assert 'Get-Item Env:PSVersionTable' in str(result)



# Generated at 2022-06-20 14:25:25.089792
# Unit test for method scan_module of class PSModuleDepFinder