

# Generated at 2022-06-20 14:15:55.880968
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # PSModuleDepFinder class object
    finder_obj = PSModuleDepFinder()

    # Locally created AnsibleModule class object
    ansible_module_obj = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str')
        ),
        supports_check_mode=True
    )

    try:
        finder_obj.scan_exec_script(ansible_module_obj.params['name'])
    except AnsibleError as e:
        ansible_module_obj.fail_json(msg=to_native(e))



# Generated at 2022-06-20 14:16:02.433742
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert len(PSModuleDepFinder().ps_modules) == 0
    assert len(PSModuleDepFinder().exec_scripts) == 0
    assert len(PSModuleDepFinder().cs_utils_wrapper) == 0
    assert len(PSModuleDepFinder().cs_utils_module) == 0



# Generated at 2022-06-20 14:16:06.722526
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == dict()
    assert ps_module_dep_finder.exec_scripts == dict()
    assert ps_module_dep_finder.cs_utils_wrapper == dict()
    assert ps_module_dep_finder.cs_utils_module == dict()
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become == False


# Generated at 2022-06-20 14:16:17.581737
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Unit tests for PSModuleDepFinder.scan_module
    """
    dep_finder = PSModuleDepFinder()
    dep_finder._add_module = Mock()

    dep_finder.scan_module(to_bytes('''#Requires -Module Ansible.ModuleUtils.Test,
#Requires -Module Ansible.ModuleUtils.Test'''))
    assert dep_finder._add_module.call_count == 1

    dep_finder._add_module.reset_mock()
    dep_finder.scan_module(to_bytes('''#Requires -Module Ansible.ModuleUtils.Test,
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test'''))
    assert dep_finder._add_module.call_count == 1

    dep_finder._add_module.reset_mock()

# Generated at 2022-06-20 14:16:22.260684
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()
    assert md.ps_modules == dict()
    assert md.exec_scripts == dict()
    assert md.cs_utils_wrapper == dict()
    assert md.cs_utils_module == dict()
    assert md.ps_version is None
    assert md.os_version is None
    assert md.become is False
    assert md._re_cs_module[0].pattern.decode() == '(?i)^using\\s((Ansible\\..+)|' \
                                                  '(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$'

# Generated at 2022-06-20 14:16:32.306543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    # Read the contents of a script and then call the scan_exec_script method with the script's name
    #
    dep_finder = PSModuleDepFinder()
    s_name = "win_command.py"
    data = pkgutil.get_data("ansible.module_utils.powershell_loader", to_native(s_name, errors='surrogate_or_strict'))
    assert dep_finder.scan_exec_script(s_name)==None
    assert dep_finder.exec_scripts[s_name]==data
    assert dep_finder.become == False
    assert dep_finder.ps_version == None
    assert dep_finder.os_version == None

# Generated at 2022-06-20 14:16:40.950381
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Test that initialization of class generates the correct attributes
    """
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

# Unit Test for loading module dependencies into class instance

# Generated at 2022-06-20 14:16:42.826920
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-20 14:16:45.328706
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    t = PSModuleDepFinder()
    t.scan_exec_script('powershell_exec')


# Generated at 2022-06-20 14:16:56.429787
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_dep_finder = PSModuleDepFinder()

    assert not module_dep_finder.ps_modules
    assert not module_dep_finder.cs_utils_wrapper
    assert not module_dep_finder.cs_utils_module

    # check that the module and cs util dicts exist and are empty
    assert module_dep_finder.ps_modules == dict()
    assert module_dep_finder.cs_utils_wrapper == dict()
    assert module_dep_finder.cs_utils_module == dict()

    # check that the regex checks are setup correctly
    assert module_dep_finder._re_cs_module
    assert module_dep_finder._re_cs_in_ps_module
    assert module_dep_finder._re_ps_module
    assert module_dep_finder._re_wrapper
    assert module_dep_finder._

# Generated at 2022-06-20 14:17:18.605547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    scanner = PSModuleDepFinder()

    scanner.scan_exec_script('test_exec')
    assert b'# ' in scanner.exec_scripts[u'test_exec']
    assert 'test_exec' in scanner.ps_modules

# Generated at 2022-06-20 14:17:27.716523
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module = C.PERSISTENT_TMP_DIR + "/" + str(random.randint(0, 999999999)) + ".psm1"
    with open(C.TEST_DATA_ROOT + os.sep + 'data' + os.sep + 'support' + os.sep + 'PsModuleParserTestData.psm1', 'rb') as f:
        test_data = f.read()
    with open(test_module, 'wb') as f:
        f.write(test_data)

    def slurp(filename):
        return to_bytes(open(filename, 'rb').read())

    def test_case(module_name, expected_result):
        depfinder = PSModuleDepFinder()
        depfinder.scan_module(slurp(module_name))
        result

# Generated at 2022-06-20 14:17:29.735383
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_obj = PSModuleDepFinder()
    assert ps_module_obj != None

# Support utils

# Generated at 2022-06-20 14:17:35.029246
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # call test module to be scanned
    module_name = 'test_module'
    module_data = _slurp(module_name)
    module_data_decoded = base64.b64decode(module_data)
    finder.scan_module(module_data_decoded, fqn='test_module')

# Generated at 2022-06-20 14:17:45.988411
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_finder = PSModuleDepFinder()
    assert module_finder is not None
    assert isinstance(module_finder._re_cs_module, list)
    assert isinstance(module_finder._re_cs_in_ps_module, list)
    assert isinstance(module_finder._re_ps_module, list)
    assert isinstance(module_finder._re_wrapper, re._pattern_type)
    assert isinstance(module_finder._re_ps_version, re._pattern_type)
    assert isinstance(module_finder._re_os_version, re._pattern_type)
    assert isinstance(module_finder._re_become, re._pattern_type)


# Generated at 2022-06-20 14:17:52.339217
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    executor_data = pkgutil.get_data("ansible.executor.powershell", "executor.ps1")
    if executor_data is None:
        raise Exception("Could not find executor powershell script")
    module_util_data = to_bytes(executor_data)

    finder = PSModuleDepFinder()
    finder.scan_exec_script('executor')
    assert finder.exec_scripts['executor'] == module_util_data
    assert finder.become
    assert finder.ps_version == "5.0"



# Generated at 2022-06-20 14:18:03.668500
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = b"""#!/usr/bin/python
# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()
"""

    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert finder.ps_modules["Ansible.ModuleUtils.Basic"]['data']
    assert finder.ps_modules["Ansible.ModuleUtils.Basic"]['path'] == 'ansible/module_utils/basic.psm1'
    assert list(finder.ps_modules.keys()) == ["Ansible.ModuleUtils.Basic"]


# Generated at 2022-06-20 14:18:12.058098
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import time
    import inspect
    import imp
    from ansible.module_utils import basic
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.local import LocalAnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.module_utils.compat.importlib import import_module
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.urls import open_url

    # private functions to support method scan_exec_script
    def _append(result, key, value):
        if key is not None:
            result[key] = value


# Generated at 2022-06-20 14:18:25.558434
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    df = PSModuleDepFinder()

# Generated at 2022-06-20 14:18:29.193439
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True


# Generated at 2022-06-20 14:18:50.740923
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cls = PSModuleDepFinder()

    cls.exec_scripts['tmp_script'] = to_bytes(b"Test script\n#AnsibleRequires -PowerShell ansible.module_utils.test")
    cls.ps_modules['ansible.module_utils.test'] = {'data': None, 'path': "path/to/file"}
    name = to_bytes(b"tmp_script")

    cls.scan_exec_script(name)
    assert name in cls.exec_scripts
    assert to_text(name) in cls.ps_modules



# Generated at 2022-06-20 14:18:51.966128
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder


# Generated at 2022-06-20 14:18:56.074337
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()
    module_data = "#AnsibleRequires -Wrapper Test"
    module_utils = set()
    mu.scan_module(module_data)
    assert len(mu.exec_scripts)==1

# Generated at 2022-06-20 14:19:06.251222
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test case for method scan_exec_script of class PSModuleDepFinder."""
    # Set up things needed for the test, create an instance of class
    # PSModuleDepFinder and create a dict named ps_modules to store module utils
    # scan_exec_script should find
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules = dict()

    # Call scan_exec_script method for exec_script 'ps1'
    dep_finder.scan_exec_script('ps1')

    # Assert the result with the expected module utils

# Generated at 2022-06-20 14:19:12.295499
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.six import StringIO
    import inspect
    import shutil
    import tempfile
    from ansible.module_utils.ansible_release import __version__
    from collections import namedtuple

    # Create temporary directory for the test
    tmpdir = tempfile.mkdtemp()

    # Create the base module_utils to be imported
    os.makedirs(os.path.join(tmpdir, 'ansible', 'module_utils'))
    with open(os.path.join(tmpdir, 'ansible', 'module_utils', 'ping.py'), 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("ANSIBLE_METADATA = {'status': ['stableinterface'], 'supported_by': 'core'}\n")
        f

# Generated at 2022-06-20 14:19:14.963300
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    MU = PSModuleDepFinder()
    assert MU.scan_exec_script('common'), "Error in scan_exec_script()"


# Generated at 2022-06-20 14:19:20.435994
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    inst = PSModuleDepFinder()
    ps_script_data = pkgutil.get_data(to_text("ansible.executor.powershell"), to_text("common.psm1"))
    inst.scan_exec_script(to_text("common"))
    assert inst.exec_scripts['common'].decode('utf-8') == ps_script_data.decode('utf-8')



# Generated at 2022-06-20 14:19:27.238560
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Write tests
    # FIXME: pylint complains about this "Unable to import 'ansible.module_utils.cloud.get_cloud_platforms' [import-error]".
    # FIXME: pylint complains about this "Module 'ansible.module_utils.cloud' has no '_cloud_platforms' member [no-member]".
    return False

if __name__ == '__main__':
    test_PSModuleDepFinder_scan_module()

# Make a symlink that resolves to the lib path
try:
    os.symlink(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))), "lib")
except OSError:
    pass



# Generated at 2022-06-20 14:19:28.540876
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()
    assert isinstance(mdf, PSModuleDepFinder)
    return



# Generated at 2022-06-20 14:19:40.274493
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    s = PSModuleDepFinder()
    s.scan_module(to_bytes(r'#Requires -Module Ansible.ModuleUtils.foo'))
    s.scan_module(to_bytes(r'#AnsibleRequires -PowerShell Ansible.ModuleUtils.foo'))
    s.scan_module(to_bytes(r'#AnsibleRequires -PowerShell ansible_collections.foo.bar.plugins.module_utils.foo'))
    s.scan_module(to_bytes(r'#Requires -Module Ansible.ModuleUtils.foo'))
    s.scan_module(to_bytes(r'#Requires -Module Ansible.ModuleUtils.foo -Optional'))


# Generated at 2022-06-20 14:19:58.972346
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("basic")

    assert "basic" in dep_finder.exec_scripts.keys()


# Generated at 2022-06-20 14:20:08.913154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = open("/home/ansible/ansible/lib/ansible/modules/cloud/azure/azure_rm_roleassignment.psm1", "rb").read()
    # module_data = to_bytes(
    #             # "/home/ansible/ansible/lib/ansible/modules/cloud/azure/azure_rm_roleassignment.psm1",
    #             # "rb"
    #         )
    # # module_data = open("/home/ansible/ansible/lib/ansible/modules/windows/win_azure_rm_roleassignment.psm1", "rb").read()
    # print(module_data)
    d = PSModuleDepFinder()
    module_data = to_bytes(module_data)

# Generated at 2022-06-20 14:20:21.714655
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import shutil
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.connection import ConnectionError

# Generated at 2022-06-20 14:20:28.929812
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert pmdf
    assert pmdf.ps_modules == {}
    assert pmdf.exec_scripts == {}
    assert pmdf.cs_utils_wrapper == {}
    assert pmdf.cs_utils_module == {}
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False
    assert pmdf._re_cs_module
    assert pmdf._re_cs_in_ps_module
    assert pmdf._re_ps_module
    assert pmdf._re_wrapper
    assert pmdf._re_ps_version
    assert pmdf._re_os_version
    assert pmdf._re_become



# Generated at 2022-06-20 14:20:40.938840
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = dict(exec_scripts=dict(), cs_utils_wrapper=dict())
    obj = PSModuleDepFinder()
    obj.scan_exec_script('executor')
    obj.scan_exec_script('pure_log_writer')
    obj.scan_exec_script('job_message_writer')
    obj.scan_exec_script('job_debug_writer')
    obj.scan_exec_script('job_result_writer')
    for key, value in obj.__dict__.items():
        data[key] = value

    # verify data to ensure the test case is correct
    assert len(data['exec_scripts']) == 5
    assert len(data['cs_utils_wrapper']) == 5
    assert data['ps_version'] == '3.0'


# Generated at 2022-06-20 14:20:48.510536
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # run the 'test_' method of class PSModuleDepFinder
    test_pSMD = PSModuleDepFinder()

    # create test module content
    test_module = "#AnsibleRequires -PowerShell ..module_utils.one\n #AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.test_one"

    # run the method on the test content
    test_pSMD.scan_module(test_module,fqn="test.test_collection.plugins.modules.test_module", wrapper=False, powershell=True)

    #assert that the method ran as expected

# Generated at 2022-06-20 14:20:57.270858
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible_collections.community.general.plugins.module_utils.module_helper as mh
    module_util_instance_obj = PSModuleDepFinder()
    module_util_instance_obj.scan_exec_script('ansible_collections.community.general.plugins.module_utils.module_helper')
    assert len(module_util_instance_obj.cs_utils_wrapper) == 0
    assert len(module_util_instance_obj.cs_utils_module) == 0
    assert len(module_util_instance_obj.ps_modules) == 1
    assert module_util_instance_obj.ps_modules['Ansible.ModuleUtils.ModuleHelper'] is not None

# Generated at 2022-06-20 14:21:00.098091
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Test scan_exec_script method of class PSModuleDepFinder
    '''
    ps_finder = PSModuleDepFinder()


# Generated at 2022-06-20 14:21:12.525795
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.facts.system.system import DistributionInfo, Distribution
    assert env_fallback(b'TEST_PS_VER', b'4.0.0') == b'4.0.0'
    assert env_fallback(b'TEST_OS_VER', b'6.1.7601') == b'6.1.7601'
    assert env_fallback(b'TEST_BECOME', b'1') == b'1'
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script(b'common')
    assert b'common' in psmd.exec_scripts.keys()
    assert psmd.exec_scripts[b'common']
    assert psmd.ps_

# Generated at 2022-06-20 14:21:20.612817
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script by importing the script used with
    # AnsibleExecutor which imports a C# util and has a PS wrapper
    # which itself imports another C# util.
    #
    # The C# utilities are loaded from a collection, so we need to
    # ensure that collectioin is registered.
    resource_from_fqcr('ansible_collections.test_namespace.collection.plugins.module_utils.cs_module_utils.util1')
    resource_from_fqcr('ansible_collections.test_namespace.collection.plugins.module_utils.cs_module_utils.util2')
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ansible_executor')
    # We expect to find the following:
    # - a PS module which imports

# Generated at 2022-06-20 14:22:03.198508
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_cs_modules = {
        'ansiblens.testcollection.plugins.module_utils.foobar': '',
        '..module_utils.foobar': '',
        'Ansible.ModuleUtils.FooBar': '',
    }

    test_ps_modules = {
        'ansiblens.testcollection.plugins.module_utils.foobar': '',
        '..module_utils.foobar': '',
        'Ansible.ModuleUtils.FooBar': '',
    }

    # Test C# module
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:22:08.702737
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.compat import exec_wrapper

    finder = PSModuleDepFinder()
    finder.scan_exec_script(exec_wrapper.EXEC_DEFAULT_WRAPPER)



# Generated at 2022-06-20 14:22:15.618363
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()
    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become is False



# Generated at 2022-06-20 14:22:18.238904
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    d = PSModuleDepFinder()
    d.scan_exec_script("script")
    assert d.exec_scripts == {'script': b'#!/bin/bash\n'}



# Generated at 2022-06-20 14:22:19.579378
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert PSModuleDepFinder()


# Generated at 2022-06-20 14:22:27.390227
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder for testing
    finder = PSModuleDepFinder()

    module_data = (
        b'#Requires -Module ansible.module_utils.some_module\n'
        b'#Requires -Module ansible.module_utils.some_other_module\n'
        b'#Requires -Module ansible.module_utils.some_module\n'
        b'#Requires -Module ansible_collections.other.things.plugins.module_utils.other_module\n'
    )

    # Scan the module
    finder.scan_module(module_data)

    # Assert that the ps_modules dict is as expected

# Generated at 2022-06-20 14:22:37.840606
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an object of class PSModuleDepFinder
    obj = PSModuleDepFinder()
    # Test with a single-line script
    script = u'# Requires -Modules AzureRM.Profile, AzureRM.Resources\n'
    script += u'New-AzureRmResourceGroup -Name foo -Location local\n'
    obj.scan_exec_script(script)
    assert obj.exec_scripts.keys()[0] == 'tmp/ansible_powershell_executor.ps1'
    # Test with a multi-line script
    script = u'# Requires -Modules AzureRM.Profile, AzureRM.Resources\n'
    script += u'if (Get-Module -ListAvailable AzureRM.Profile) {\n'
    script += u'   Import-Module -Name AzureRM.Profile\n'
    script += u

# Generated at 2022-06-20 14:22:46.028947
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:50.023469
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)
    assert dep_finder.ps_modules == {}


# Generated at 2022-06-20 14:22:55.724906
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        psmdf.scan_exec_script(b"")
    name = "blah"
    with pytest.raises(AnsibleError):
        psmdf.scan_exec_script(name)


# Generated at 2022-06-20 14:23:13.112511
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    name = 'TestName'
    module_dep_finder.scan_exec_script(name)
    assert name in module_dep_finder.exec_scripts.keys()


# Generated at 2022-06-20 14:23:24.399947
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    path = 'ansible_collections.test.test_ns.plugins.modules.test_module'
    result = {
        'data': b'TestModule',
        'path': os.path.join(C.DEFAULT_MODULE_PATH[0], path) + '.psm1',
    }
    data = b'#Requires -Module %s\n' % to_bytes(result['path'])
    psmdf = PSModuleDepFinder()
    psmdf._add_module = lambda a, b, c, d: psmdf.ps_modules.update({a: result})
    psmdf.scan_module(data, fqn=path)

    assert psmdf.ps_modules == {'Ansible.Test.Test_ns.Test_module': result}



# Generated at 2022-06-20 14:23:33.439844
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'module_util')
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()

    # Test a PowerShell module that has no dependencies
    module_data = b'$true'
    finder.scan_module(module_data)
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()

    # Test a PowerShell module that has a PowerShell module util as a dependency
    module_data = b'#Requires -Module Ansible.ModuleUtils.Example'
    finder.scan_module(module_data)
    assert finder.ps_

# Generated at 2022-06-20 14:23:40.705291
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    directory_path = os.path.dirname(os.path.realpath(__file__))
    print("Current working directory : %s" % directory_path)
    file_path = os.path.join(directory_path, "test_data", "ansible.psm1")
    file_path_exec = os.path.join(directory_path, "test_data", "test_hosts_file.ps1")
    if os.path.exists(file_path) and os.path.exists(file_path_exec):
        print("File exists at path : %s" % file_path)
        print("File exists at path : %s" % file_path_exec)
        with open(file_path, 'r') as f:
            data = f.read()
        ps_module_dependency_finder

# Generated at 2022-06-20 14:23:42.933216
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, PSModuleDepFinder)



# Generated at 2022-06-20 14:23:48.928482
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    test_PSModuleDepFinder_scan_exec_script
    Test if the scan_exec_script method scan the scripts
    """
    module_dep_finder = PSModuleDepFinder()
    wrapper = module_dep_finder.scan_exec_script("ps_base_wrapper")
    assert wrapper



# Generated at 2022-06-20 14:23:56.999399
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:59.238538
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert isinstance(dep_finder, object)


# Generated at 2022-06-20 14:24:11.692452
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()
    assert obj.ps_modules == dict()
    assert obj.exec_scripts == dict()

    assert obj.cs_utils_wrapper == dict()
    assert obj.cs_utils_module == dict()

    assert obj.ps_version is None
    assert obj.os_version is None
    assert obj.become is False

    # _re_cs_module
    assert len(obj._re_cs_module) == 1
    assert obj._re_cs_module[0] == re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                         r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))
    # _re_cs

# Generated at 2022-06-20 14:24:27.789405
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common import load_platform_subclass
    from ansible.module_utils.powershell.WinRM import Connection

    # Load the platform subclass for Windows
    class_name = load_platform_subclass(Connection)
    winrm_connection = class_name()

    csharp_util_a = b"using ansible_collections.csharp.test_module_util_a.plugins.module_utils.module_util_a;"
    csharp_util_b = b"using ansible_collections.csharp.test_module_util_b.plugins.module_utils.module_util_b;"

    # A C# module which imports another C# module
    data = b"\n".join((csharp_util_a, csharp_util_b))
    finder = PSModuleDepFinder

# Generated at 2022-06-20 14:24:52.281462
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p._re_cs_module[0].pattern == '(?i)^using\\s((Ansible\\..+)|(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$'
    assert p._re_cs_in_ps_module[0].pattern == '(?i)^#\\s*ansiblerequires\\s+-csharputil\\s+((Ansible\\.[\\w\\.]+)|(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+)|(\\.[\\w\\.]+))(?P<optional>\\s+-Optional){0,1}'
    assert p._re_ps_

# Generated at 2022-06-20 14:24:57.004618
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    dep_finder = PSModuleDepFinder()
    name = 'ansible_module_pwsh'

    # Act
    dep_finder.scan_exec_script(name)

    # Assert
    assert dep_finder.exec_scripts[name] is not None

# Generated at 2022-06-20 14:24:58.575676
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert len(PSModuleDepFinder.__doc__) > 0



# Generated at 2022-06-20 14:25:08.234713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    x = PSModuleDepFinder()
    x.scan_exec_script("win_file.ps1")
    assert "win_file.ps1" in x.exec_scripts
    assert "microsoft.powershell.management" in x.cs_utils_wrapper
    assert "microsoft.powershell.utility" in x.cs_utils_wrapper
    assert "microsoft.powershell.security" in x.cs_utils_wrapper
    assert "ansible.windows.file" in x.cs_utils_wrapper
    assert "ansible.windows.win_acl" in x.cs_utils_wrapper
    assert "ansible.windows.win_path" in x.cs_utils_wrapper
    assert "ansible.windows.win_stat" in x.cs_utils_wrapper


# Generated at 2022-06-20 14:25:17.917277
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    script_path = os.path.join(os.path.dirname(__file__), 'data', 'test_script.ps1')
    module_data = _slurp(script_path)
    finder.scan_module(module_data)
    assert finder.ps_modules['Ansible.ModuleUtils.Legacy']['data'] is not None
    assert finder.cs_utils_wrapper['ansible_collections.ns.coll.plugins.module_utils.Legacy']['data'] is not None

