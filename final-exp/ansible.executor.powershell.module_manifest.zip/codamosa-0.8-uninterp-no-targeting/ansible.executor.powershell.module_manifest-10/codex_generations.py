

# Generated at 2022-06-20 14:16:08.453266
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # These tests are designed to test the _re_ps_module and
    # _re_cs_in_ps_module regular expressions.
    d = PSModuleDepFinder()
    # import a builtin module_util and one from a collection
    # The module_utils should be referenced in the order they are listed in the
    # test input.

# Generated at 2022-06-20 14:16:16.623803
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible_collections.foo.bar.plugins.module_utils.baz import qux
    from ansible_collections.foo.bar.plugins.module_utils.baz.quux import corge
    from ansible_collections.foo.bar.plugins.module_utils.baz.quux.grault import garply

    import ansible_collections.foo.bar.plugins.module_utils.baz
    import ansible_collections.foo.bar.plugins.module_utils.baz.quux
    import ansible_collections.foo.bar.plugins.module_utils.baz.quux.grault
    import ansible.module_utils.basic

    def get_test_module_util_data(path):
        return b' ". %s" ' % to_bytes(path)

    ps_

# Generated at 2022-06-20 14:16:28.006713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder=PSModuleDepFinder()
    name= 'ansible/executor/powershell'
    psModuleDepFinder.scan_exec_script(name)
    assert psModuleDepFinder.ps_modules == dict()
    assert psModuleDepFinder.cs_utils_wrapper == dict()
    assert psModuleDepFinder.cs_utils_module == dict()
    assert psModuleDepFinder.ps_version == None
    assert psModuleDepFinder.os_version == None
    assert psModuleDepFinder.become == False


# Generated at 2022-06-20 14:16:37.492984
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.exec_scripts == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-20 14:16:45.380318
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        data = pkgutil.get_data("ansible.modules.packaging.os", to_native("apt.psm1"))
    except (OSError, IOError):
        # If it doesn't exist we cannot find the utils it requires
        return
    b_data = to_bytes(data)
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_module(b_data, fqn="ansible.modules.packaging.os.apt", wrapper=True, powershell=True)
    # assert that the module has been added
    assert "Ansible.BasicModuleUtils" in module_dep_finder.ps_modules.keys()



# Generated at 2022-06-20 14:16:46.758819
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    assert instance.scan_exec_script(name='no_power.psm1') == None

# Generated at 2022-06-20 14:16:57.024507
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    finder.scan_module(b"""
#Requires -Module Ansible.ModuleUtils.Powershell
#AnsibleRequires -Powershell Ansible.ModuleUtils.Foo
#AnsibleRequires -Powershell ansible_collections.namespace.collection.plugins.module_utils.Bar
#AnsibleRequires -Powershell ..module_utils.baz
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Baz
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.Bar
""")
    assert finder.ps_modules['Ansible.ModuleUtils.Foo']['path'].endswith('ansible/module_utils/powershell/foo.psm1')


# Generated at 2022-06-20 14:16:59.956328
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize
    p = PSModuleDepFinder()
    p.scan_exec_script('script_name')


# Generated at 2022-06-20 14:17:09.292980
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_exec_script('test')
    # Result
    assert module_dep_finder.exec_scripts == {'test': None}
    assert module_dep_finder.cs_utils_wrapper == {}
    assert module_dep_finder.cs_utils_module == {}
    assert module_dep_finder.ps_modules == {}
    assert module_dep_finder.ps_version is None
    assert module_dep_finder.os_version is None
    assert module_dep_finder.become is False


# Generated at 2022-06-20 14:17:14.534477
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = to_bytes("#Requires -Module Ansible.ModuleUtils.Common")
    finder.scan_module(module_data, powershell=True)
    assert set(finder.ps_modules.keys()) == set(['Ansible.ModuleUtils.Common'])

# Generated at 2022-06-20 14:17:35.185210
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test for Ansible 2.6+
    mod_scanner = PSModuleDepFinder()
    mod_scanner.scan_module(to_bytes(u'#Requires -Module Ansible.ModuleUtils.Legacy'))
    assert mod_scanner.ps_modules[u'Ansible.ModuleUtils.Legacy']['data'] != b''
    assert mod_scanner.ps_modules[u'Ansible.ModuleUtils.Legacy']['data'] != b''

    # Test for Ansible 2.5-
    mod_scanner = PSModuleDepFinder()
    mod_scanner.scan_module(to_bytes(u'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Legacy'))

# Generated at 2022-06-20 14:17:47.560429
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pmdf = PSModuleDepFinder()
    assert isinstance(pmdf, PSModuleDepFinder)
    assert isinstance(pmdf.ps_modules, dict)
    assert isinstance(pmdf.exec_scripts, dict)
    assert isinstance(pmdf.cs_utils_wrapper, dict)
    assert isinstance(pmdf.cs_utils_module, dict)
    assert pmdf.ps_version is None
    assert pmdf.os_version is None
    assert pmdf.become is False
    assert isinstance(pmdf._re_cs_module, list)
    assert isinstance(pmdf._re_cs_in_ps_module, list)
    assert isinstance(pmdf._re_ps_module, list)
    assert isinstance(pmdf._re_wrapper, re._pattern_type)

# Generated at 2022-06-20 14:17:49.268005
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pdm = PSModuleDepFinder()
    assert pdm is not None


# Generated at 2022-06-20 14:17:51.597562
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False


# Generated at 2022-06-20 14:18:04.669200
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This should be called just once
    PSModuleDepFinder.__init__(PSModuleDepFinder)
    # ensure that each required util contains '_load_params' which is the
    # starting point of module_utils (powershell, C#, etc)
    loader = PSModuleDepFinder()
    # We are going to test these modules
    modules = ['aws_opsworks_stack', 'gcp_compute_disk', 'gcp_compute_network', 'gcp_compute_instance', 'gcp_dns_resource_record_set']
    for module in modules:
        fqcr = 'ansible.modules.cloud.%s' % module
        resource_path, _ = resource_from_fqcr(fqcr)

# Generated at 2022-06-20 14:18:05.974194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Unit test not implemented"


# Generated at 2022-06-20 14:18:22.527848
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    scriptpath = pkgutil.get_loader("ansible.modules.windows.win_ping").get_filename()
    module_data = open(scriptpath, 'r', -1, 'utf-8').read()
    depfinder = PSModuleDepFinder()
    depfinder.scan_module(module_data, fqn='ansible.modules.windows.win_ping')


# Generated at 2022-06-20 14:18:30.436373
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Given
    ps_module_dep_finder = PSModuleDepFinder()

    # When
    assert hasattr(ps_module_dep_finder, "ps_modules")
    assert hasattr(ps_module_dep_finder, "cs_utils_wrapper")
    assert hasattr(ps_module_dep_finder, "cs_utils_module")
    assert hasattr(ps_module_dep_finder, "ps_version")
    assert hasattr(ps_module_dep_finder, "os_version")
    assert hasattr(ps_module_dep_finder, "become")



# Generated at 2022-06-20 14:18:32.870005
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder


# Generated at 2022-06-20 14:18:34.492950
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False

# Generated at 2022-06-20 14:19:02.120959
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    class TestPSModuleDepFinder(PSModuleDepFinder):
        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            pass

        def scan_exec_script(self, name):
            pass

    finder = TestPSModuleDepFinder()

    finder._add_module('Ansible.ModuleUtils.MockModuleUtil', '.psm1', '', False)
    assert finder.ps_modules['Ansible.ModuleUtils.MockModuleUtil']['data'] == _slurp(
        os.path.join(os.path.dirname(__file__), "../../../../../test/units/module_utils/MockModuleUtil.psm1"))


# Generated at 2022-06-20 14:19:16.600543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Testing #Requires -Module Ansible.ModuleUtils
    class TestModuleDepFinder1(PSModuleDepFinder):

        def __init__(self):
            super(TestModuleDepFinder1, self).__init__()
            self.ps_modules = dict()

    # Testing #AnsibleRequires -PowerShell Ansible.ModuleUtils
    class TestModuleDepFinder2(PSModuleDepFinder):

        def __init__(self):
            super(TestModuleDepFinder2, self).__init__()
            self.ps_modules = dict()

    # Testing #AnsibleRequires -CSharpUtil Ansible.*
    class TestModuleDepFinder3(PSModuleDepFinder):

        def __init__(self):
            super(TestModuleDepFinder3, self).__init__()
            self.cs

# Generated at 2022-06-20 14:19:30.909355
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == {}
    assert finder.exec_scripts == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False

    name = "Test"
    path = "mod/path/%s" % name
    fqn = "my_ns.my_coll.%s" % name
    random_data = base64.b64encode(bytes([random.randrange(0, 256) for _ in range(0, 512)]))
    random_data = to_bytes(random_data, errors='surrogate_or_strict')

    finder.scan_module

# Generated at 2022-06-20 14:19:42.191502
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_finder = PSModuleDepFinder()

    assert(ps_finder.ps_modules == {})
    assert(ps_finder.cs_utils_module == {})
    assert(ps_finder.exec_scripts == {})
    assert(ps_finder._re_cs_in_ps_module is not None)
    assert(ps_finder._re_cs_module is not None)
    assert(ps_finder._re_ps_module is not None)
    assert(ps_finder._re_wrapper is not None)
    assert(ps_finder._re_ps_version is not None)
    assert(ps_finder._re_os_version is not None)
    assert(ps_finder._re_become is not None)


# Generated at 2022-06-20 14:19:48.682734
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():

    ps_dep_finder = PSModuleDepFinder()

    assert ps_dep_finder.ps_modules == {}
    assert ps_dep_finder.exec_scripts == {}
    assert ps_dep_finder.cs_utils_wrapper == {}
    assert ps_dep_finder.cs_utils_module == {}
    assert ps_dep_finder.ps_version is None
    assert ps_dep_finder.os_version is None
    assert ps_dep_finder.become is False

    assert isinstance(ps_dep_finder._re_cs_module, list)
    assert isinstance(ps_dep_finder._re_cs_in_ps_module, list)
    assert isinstance(ps_dep_finder._re_ps_module, list)


# Generated at 2022-06-20 14:20:01.456977
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test some valid examples
    finder = PSModuleDepFinder()
    finder.scan_module(to_bytes("#Requires -Module Ansible.ModuleUtils.Common"))
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]['path'].find("ansible/plugins/module_utils/powershell/common.psm1") >= 0

    finder = PSModuleDepFinder()
    finder.scan_module(to_bytes("#AnsibleRequires -PowerShell Ansible.ModuleUtils.Common"))
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]['path'].find("ansible/plugins/module_utils/powershell/common.psm1") >= 0

    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:20:12.636796
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_mod_dep_finder = PSModuleDepFinder()
    ps_mod_dep_finder.scan_exec_script("PowerShell")
    assert len(ps_mod_dep_finder.exec_scripts) == 1
    assert b"PowerShell" in ps_mod_dep_finder.exec_scripts.keys()
    assert len(ps_mod_dep_finder.ps_modules) >= 1
    assert b"Ansible.ModuleUtils.Common" in ps_mod_dep_finder.ps_modules.keys()

# Generated at 2022-06-20 14:20:13.869995
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-20 14:20:24.974789
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:32.351348
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md_finder = PSModuleDepFinder()
    assert md_finder is not None
    assert hasattr(md_finder, 'ps_modules')
    assert hasattr(md_finder, 'exec_scripts')
    assert hasattr(md_finder, 'cs_utils_wrapper')
    assert hasattr(md_finder, 'cs_utils_module')


# Generated at 2022-06-20 14:20:53.379992
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script("netstat")
    assert len(ps.exec_scripts) == 1
    assert len(ps.cs_utils_wrapper) > 0


# Generated at 2022-06-20 14:21:00.067502
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder is not None
    assert dep_finder.ps_modules is not None
    assert dep_finder.cs_utils_wrapper is not None
    assert dep_finder.cs_utils_module is not None
    assert dep_finder.exec_scripts is not None
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False
    assert dep_finder._re_cs_module is not None
    assert dep_finder._re_cs_in_ps_module is not None
    assert dep_finder._re_ps_module is not None
    assert dep_finder._re_wrapper is not None
    assert dep_finder._re_ps_version is not None
    assert dep_finder._re_os_

# Generated at 2022-06-20 14:21:07.048835
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from string import Formatter
    from ansible.module_utils.common._collections_compat import Mapping
    fmt = Formatter()
    mod = fmt.parse('{a}')[0][0]

    assert isinstance(mod, basestring)

    # Test that we can iterate through all of it's subclasses
    for i in Mapping.__subclasses__():
        assert isinstance(mod, basestring)


# Generated at 2022-06-20 14:21:17.510576
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module = PSModuleDepFinder()
    assert module.ps_modules == dict(), "ps_modules dict is not empty"
    assert module.exec_scripts == dict(), "exec_scripts dict is not empty"
    assert module.cs_utils_wrapper == dict(), "cs_utils_wrapper dict is not empty"
    assert module.cs_utils_module == dict(), "cs_utils_module dict is not empty"
    assert module.ps_version is None, "ps_version is not None"
    assert module.os_version is None, "os_version is not None"
    assert not module.become, "become is not False"


# Generated at 2022-06-20 14:21:23.416458
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test: Check that scan_module raise an error if module_util cannot be found
    # Note: To test this case we need to fake that PSModuleDepFinder._add_module return an error.
    #       For this we need to monkey patch PSModuleDepFinder._add_module.
    from ansible.utils.path import module_loader
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import ps_module_utils_loader
    import re
    import os
    import sys

    name = 'ansible_test_module'
    lib_dir = os.path.dirname(__file__) + "/../../../module_utils"
    m_path = os.path.join

# Generated at 2022-06-20 14:21:26.505283
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # We just need to see that no exception is raised by the method scan_exec_script
    finder = PSModuleDepFinder()
    # The following should be a file that exists with the given extension.
    finder.scan_exec_script("foo.ps1")
    # Also test that we don't get an error if we call scan_exec_script twice on the same dep.
    finder.scan_exec_script("foo.ps1")



# Generated at 2022-06-20 14:21:31.676333
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Sending a fake powershell module with a wrong name
    # the powershell module should not be scanned
    finder = PSModuleDepFinder()
    fake_data = to_bytes('#Requires -Module Ansible.ModuleUtils.DateTime')
    assert finder.exec_scripts == {}
    finder.scan_exec_script("test_PSModuleDepFinder_scan_exec_script")
    assert finder.exec_scripts == {"test_PSModuleDepFinder_scan_exec_script": fake_data}


# Generated at 2022-06-20 14:21:45.300579
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    random_int = random.randint(0, 999999)
    random_str = base64.b64encode(str(random_int).encode())
    file_name = "tempScript"+str(random_str)[2:8]+".ps1"
    file_path = os.path.join(C.DEFAULT_LOCAL_TMP, file_name)
    file = open(file_path, "w")
    file.write("")
    file.close()
    file_data = None
    with open(file_path, 'rb') as f:
        file_data = f.read()
    os.remove(file_path)
    # test success
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:21:56.787562
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.SomeModule\n")
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.SomeModule']
    assert not ps_module_dep_finder.become
    assert not ps_module_dep_finder.os_version
    assert not ps_module_dep_finder.ps_version

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b"#requires -module Ansible.ModuleUtils.SomeModule -Optional\n")
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.SomeModule']
    assert not ps_

# Generated at 2022-06-20 14:22:06.091562
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:27.530510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = 'ansible_module_pipelining'
    finder.scan_exec_script(name)
    assert name in finder.exec_scripts.keys()


# Generated at 2022-06-20 14:22:32.982753
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Ensure #11630 works by testing different module exec scripts."""

    # A simple dummy test module that depends on a module_exec script

# Generated at 2022-06-20 14:22:39.977067
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    name = 'foo'
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script(name)
    assert any(name in item for item in ansible.executor.powershell.__all__) or name == '__init__' or name.startswith('_')

# Generated at 2022-06-20 14:22:52.826481
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('In test_PSModuleDepFinder_scan_exec_script')
    psModuleDepFinder = PSModuleDepFinder()
    # Case 1:
    # Test scan_exec_script with name = "default", returns nothing
    # Caution: test_data should be updated when the file 'default.ps1' is changed
    test_data = open('testdata/PSModuleDepFinder/default.ps1', 'rb').read()
    test_data_without_comments = _strip_comments(test_data)
    psModuleDepFinder.scan_exec_script('default')
    assert psModuleDepFinder.exec_scripts['default'].decode() == test_data_without_comments.decode()



# Generated at 2022-06-20 14:22:57.445800
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Basic smoke test
    finder = PSModuleDepFinder()
    assert finder.exec_scripts == {}
    finder.scan_exec_script("default_wrapper")
    assert finder.exec_scripts != {}
    assert "default_wrapper" in finder.exec_scripts.keys()



# Generated at 2022-06-20 14:23:07.569286
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test for the method scan_module of class PSModuleDepFinder."""
    import os
    import re

    # Testing is a pain with this because there is no way to reset the object
    # so each test has to create a new object and re-setup the test data
    # This is especially painful since we are testing a class that is used by
    # other classes
    class TestPSModuleDepFinder(PSModuleDepFinder):
        """Class to test the PSModuleDepFinder class."""

        def __init__(self):
            super(TestPSModuleDepFinder, self).__init__()
            # Mock the data inside the main class
            self.ps_modules = {
                "Ansible.ModuleUtils.ModuleBase": {
                    "data": b"module_util_data"
                },
            }
            self

# Generated at 2022-06-20 14:23:13.319716
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('win_command')
    assert 'win_command' in ps_module_dep_finder.exec_scripts.keys()
    assert 'common' in ps_module_dep_finder.ps_modules.keys()



# Generated at 2022-06-20 14:23:24.513159
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing the scan_exec_script method is a bit tricky as we need to simulate
    # the pkgutil.get_data method.  We will do this by monkey patching the
    # pkgutil.get_data method and remove the patch after the test has run
    import unittest.mock as mock
    get_data = 'ansible.executor.powershell.{}.ps1'.format
    with mock.patch('ansible.module_utils.common.powershell.PSModuleDepFinder.scan_module') as scan_module:
        scan_module.return_value = None

# Generated at 2022-06-20 14:23:33.508668
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  test_object = PSModuleDepFinder()
  test_object._add_module = _add_module
  test_object._parse_version_match = _parse_version_match
  test_object._re_cs_module = [re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))]

# Generated at 2022-06-20 14:23:40.755069
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    if os.path.exists('/tmp/powershell_module_utils'):
        shutil.rmtree('/tmp/powershell_module_utils')
    shutil.copytree(C.DEFAULT_MODULE_TEMPLATE_PATH, '/tmp/powershell_module_utils')
    #
    # [0] generate module dep info
    #

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(to_bytes(_slurp(os.path.join('/tmp/powershell_module_utils', 'basic', 'basic.psm1'))),
                                     fqn='ansible_collections.test.test_collection.basic',
                                     wrapper=False,
                                     powershell=True)
    #
    # [1]

# Generated at 2022-06-20 14:24:03.646642
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    module_data1 = b"""#Requires -Module Ansible.ModuleUtils.SomeModuleUtil
#Requires -Module Ansible.ModuleUtils.AnotherModuleUtil
#AnsibleRequires -Powershell Ansible.ModuleUtils.SomeModuleUtil
#AnsibleRequires -Powershell ansible_collections.blah.blah.plugins.module_utils.SomeModuleUtil
#AnsibleRequires -Powershell ..module_utils.foo.bar
#AnsibleRequires -CSharpUtil Ansible.SomeModuleUtil
#AnsibleRequires -CSharpUtil ansible_collections.blah.blah.plugins.module_utils.SomeModuleUtil
#AnsibleRequires -CSharpUtil ..module_utils.foo.bar
"""
    psmdf

# Generated at 2022-06-20 14:24:14.361585
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    am = AnsibleModule(conditionally_spaced_args=False)
    am._load_params()

    psm = PSModuleDepFinder()

    # Set the encoding so we can use str(...) and catch the exception
    # if conversion fails
    reload(sys)
    sys.setdefaultencoding('utf8')

    # Test the Exception 'Could not find executor powershell script' raised.
    try:
        psm.scan_exec_script("invalid_name")
    except AnsibleError as err:
        assert str(err) == "Could not find executor powershell script for 'invalid_name'"
    else:
        assert False, "AnsibleError exception not thrown for invalid executor script name"

    # Test the success of loading

# Generated at 2022-06-20 14:24:27.902172
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_finder = PSModuleDepFinder()
    fqn = 'ansible_collections.basic.basic.plugins.module_utils.basic_module'

    # test the regexes

# Generated at 2022-06-20 14:24:36.946006
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    from ansible.module_utils import basic

    class TestClass(object):
        def __init__(self):
            self.attr1 = None
            self.attr2 = None

    assert TestClass().attr1 is None
    assert TestClass().attr2 is None

    ansible_collections = random.choice(['foo', 'bar', 'baz'])
    namespace = random.choice(['foo', 'bar', 'baz'])
    collection = random.choice(['foo', 'bar', 'baz'])
    name = random.choice(['foo', 'bar', 'baz'])
    ps_module_util_name = 'Ansible.ModuleUtils.%s' % name
    cs_module_util_name = 'ansible_collections.%s.%s.plugins.module_utils.%s'

# Generated at 2022-06-20 14:24:48.881667
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    args = {}
    # assuming here that imports are removed
    # when a module is wrapped, so no module_utils
    # will be imported.
    args['name'] = "test.ps1"
    args['data'] = b'# test \n #Requires -Version 2.0'
    args['data'] = args['data'] + b'\n$var = "test"'
    testobj = PSModuleDepFinder()
    testobj.scan_exec_script(args['name'])
    assert args['name'] in testobj.exec_scripts
    data = testobj.exec_scripts[args['name']]
    assert len(data) == len(args['data'])
    assert data.count(b'\n') == 2
    assert data.count(b'$var') == 1

# Generated at 2022-06-20 14:24:50.355380
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)



# Generated at 2022-06-20 14:24:54.787155
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-20 14:25:05.983876
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    mu_data_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_module_utils')
    mu_data_path = os.path.abspath(mu_data_path)
    mu_path = os.path.join(mu_data_path, 'first_module_util.psm1')
    module_util_data = to_bytes(_slurp(mu_path))

    with open(mu_path, 'r') as module_util:
        module_util_contents = module_util.read()

    dep_finder = PSModuleDepFinder()

    # validate that if we pass in a module_util file, this can be processed
    # successfully
    dep_finder.scan_module(module_util_data)

# Generated at 2022-06-20 14:25:19.915122
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This is a unit test for the PSModuleDepFinder.scan_module() method.
    # Creates a PSModuleDepFinder, and tests that the scan_module method parses the module_data string properly.
    psdf = PSModuleDepFinder()
    module_data = """#Requires -Module Ansible.ModuleUtils.CustomModuleUtil
    #AnsibleRequires -Powershell Ansible.ModuleUtils.AnotherCustomModuleUtil -Optional
    #Requires -Module Ansible.ModuleUtils.CustomModuleUtil
    #Requires -Version 5.1
    #AnsibleRequires -Wrapper Test-RandomData
    #Uses CSharpUtil"""

    # Tests that scan_module properly parses the module_data string
    psdf.scan_module(module_data)