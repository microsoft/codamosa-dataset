

# Generated at 2022-06-20 14:15:47.612325
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass

# Unit tests for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:15:49.772035
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    assert obj.scan_exec_script(name="name")

# Generated at 2022-06-20 14:15:54.496591
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    name = "MyModule"

# Generated at 2022-06-20 14:16:00.763404
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    # Unit test with single line comment
    assert finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.CliTools') == {(b'Ansible.ModuleUtils.CliTools', b'.psm1', None, False)}

    # Unit test with multi line comment
    assert finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.CliTools\n#Requires -Module Ansible.ModuleUtils.UnixTime') == {(b'Ansible.ModuleUtils.CliTools', b'.psm1', None, False), (b'Ansible.ModuleUtils.UnixTime', b'.psm1', None, False)}

    # Unit test with alternatives to Requires -Module

# Generated at 2022-06-20 14:16:10.870316
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    a = PSModuleDepFinder()
    with open('../ansible_collections/tests/sample_data/ansible_collections/collection/plugins/module_utils/a.psm1', 'rb') as f:
        a.scan_module(f.read())
    from ansible.utils.path import unfrackpath

    base_path = unfrackpath('./ansible_collections/tests/sample_data')
    for m in a.ps_modules:
        util = a.ps_modules[m]
        assert util["path"] == unfrackpath('%s/%s' % (base_path, m.replace('.', '/') + '.psm1'))

    for m in a.cs_utils_wrapper:
        util = a.cs_utils_wrapper[m]

# Generated at 2022-06-20 14:16:20.083325
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from tests.modules.testutils import set_module_args, AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class TestPSModuleDepFinder(ModuleTestCase):
        def setUp(self):
            super(TestPSModuleDepFinder, self).setUp()
            self.module = import_module('ansible.modules.windows.setup')
            self.path_backup = self.module.os.path
            self.module.os.path = import_module('%s.os.path' % self.__module__)
            self.path_exists_value = True
            self.path_isfile_value = True
            self.path_isdir_value = False
            self.path_islink_value = False


# Generated at 2022-06-20 14:16:31.687142
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    content = b'''# This is a ps module

#Requires -Module Ansible.ModuleUtils.SomeUtil
#Requires -Module Ansible.ModuleUtils.SomeOtherUtil
#AnsibleRequires -PowerShell Ansible.ModuleUtils.PowerShell.Arguments
#AnsibleRequires -CSharpUtil ansible_collections.foo.bar.plugins.module_utils.baz
#AnsibleRequires -PowerShell ..module_utils.another.util -Optional
#AnsibleRequires -CSharpUtil .module_utils.xyz
#Requires -Version 4.0.0
'''
    finder = PSModuleDepFinder()
    finder.scan_module(content, None)
    assert finder.ps_version == '4.0.0'

# Generated at 2022-06-20 14:16:33.405744
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False, "test not implemented"
# Mocks for the unit test of PSModuleDepFinder.scan_module

# Generated at 2022-06-20 14:16:38.209312
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    This function will test the scan_exec_script fuction of class PSModuleDepFinder
    """
    # Defining an object of PowershellPluginLoader class
    from ansible.plugins.loader import powershell_plugin_loader

    powershell_plugin_loader_object = powershell_plugin_loader.PowershellPluginLoader()
    # Defining an object of PSModuleDepFinder class
    ps_module_dep_finder_object = PSModuleDepFinder()
    # Calling scan_exec_script method with name as 'executor'
    ps_module_dep_finder_object.scan_exec_script("executor")

    # Checking the return value i.e. the wrapper ansible_collections.ansible.powershell.plugins.module_utils.ansible_module_common.ps1
    assert ps_module_dep_finder

# Generated at 2022-06-20 14:16:46.394620
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module('#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.module_util_name;')
    assert 'module_util_name' in dep_finder.cs_utils_module
    assert len(dep_finder.cs_utils_module) == 1
    assert dep_finder.become == False

    dep_finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.module_util_name')
    assert 'module_util_name' in dep_finder.ps_modules
    assert len(dep_finder.ps_modules) == 1
    assert dep_finder.become == False


# Generated at 2022-06-20 14:17:12.131220
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder.ps_modules == dict()
    assert psModuleDepFinder.exec_scripts == dict()
    assert psModuleDepFinder.cs_utils_wrapper == dict()
    assert psModuleDepFinder.cs_utils_module == dict()
    assert psModuleDepFinder.ps_version is None
    assert psModuleDepFinder.os_version is None
    assert psModuleDepFinder.become == False
    assert len(psModuleDepFinder._re_cs_module) == 1
    assert len(psModuleDepFinder._re_cs_in_ps_module) == 1
    assert len(psModuleDepFinder._re_ps_module) == 2

# Generated at 2022-06-20 14:17:22.635320
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The fake module data that is used to test the scan_module method of
    # PSModuleDepFinder class
    b_fakedata = to_bytes(pkgutil.get_data("ansible.module_utils.basic", "messaging.psm1"))
    pmdf = PSModuleDepFinder()
    pmdf.scan_module(b_fakedata)
    assert "ansible_collections.ansible.builtin.plugins.module_utils.basic.basic.json" in pmdf.ps_modules.keys()



# Generated at 2022-06-20 14:17:28.210789
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), PSModuleDepFinder)

_expr_re = re.compile(b'^#exp(?:ort)? (?P<expr>.*)')
_import_re = re.compile(b'^#imp(?:ort)? (?P<name>.*)')
_strip_comments_re = re.compile(b'(?m)^([^#]*)#.*')


# Generated at 2022-06-20 14:17:44.650011
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mod_finder = PSModuleDepFinder()
    mod_name = 'foo'
    mod_data = to_bytes(
        """#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.{mod_name}
#AnsibleRequires -Powershell ansible_collections.ns.coll.plugins.module_utils.baz
#AnsibleRequires -CSharpUtil ..module_utils.boo
#AnsibleRequires -CSharpUtil ..module_utils.boo -Optional
#requires -version 5.1.0
#ansiblerequires -osversion 10.0.17763.0
#ansiblerequires -become
#AnsibleRequires -Wrapper foo
""".format(mod_name=mod_name))


# Generated at 2022-06-20 14:17:53.297311
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("\nTest running test_PSModuleDepFinder_scan_module()")

    # PS module contains '#Requires -Module Ansible.ModuleUtils.*'
    # PS module contains '#AnsibleRequires -Powershell Ansible.*' (or collections module_utils ref)
    # PS module contains '#Requires -Version'
    # PS module contains '#Requires -OSVersion'
    # PS module contains '#AnsibleRequires -Become'
    module_data = '''
# Requires -Module Ansible.ModuleUtils.Test1
# Requires -Version 1.0
# AnsibleRequires -Powershell Ansible.ModuleUtils.Test2
# Requires -OSVersion 10.0.0
# AnsibleRequires -Become
'''
    mdf = PSModuleDepFinder()
    scan_result = mdf.scan

# Generated at 2022-06-20 14:18:05.773359
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.module_utils.powershell import _get_encoded_script
    # TODO: Add unit tests for _get_encoded_script get_encoded_script = _get_encoded_script

    module_utils = PSModuleDepFinder()

    # TODO: Add unit tests for scan_module module_utils.scan_module = scan_module

    def _add_module(self, name, ext, fqn, optional, wrapper=False):
        return
    module_utils._add_module = _add_module
    data = pkgutil.get_data("ansible.executor.powershell", to_native("exec.ps1"))
    if data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for '%s'" % "exec.ps1")
    b

# Generated at 2022-06-20 14:18:13.483114
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    md = PSModuleDepFinder()


# Generated at 2022-06-20 14:18:26.151675
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert not finder.become
    assert finder._re_cs_module[0].pattern.decode().startswith('(?i)^using\\s((Ansible\\.')
    assert finder._re_cs_in_ps_module[0].pattern.decode().startswith('(?i)^#\\s*ansiblerequires\\s+-csharputil\\s+((Ansible\\.')
    assert finder._re_ps_

# Generated at 2022-06-20 14:18:28.272256
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    foo = PSModuleDepFinder()
    assert foo.ps_modules == dict()
    assert foo.exec_scripts == dict()
    assert foo.cs_utils_wrapper == dict()
    assert foo.cs_utils_module == dict()
    assert foo.ps_version is None
    assert foo.os_version is None
    assert foo.become == False


# Generated at 2022-06-20 14:18:38.345318
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    name = 'test'

    data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
    if data is None:
        return

    b_data = to_bytes(data)
    b_data1 = b'#requires -version 2.0'

    ps.scan_exec_script(name)
    assert ps.exec_scripts['test'] == b_data
    assert ps.ps_version == '2.0'
    assert ps.os_version is None


# Generated at 2022-06-20 14:19:47.975436
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.modules.windows.win_command import __ansible_module_build__
    #### test input arguments

    # valid types
    name = to_text("hello")

    #### test execution and assertions

    # create a PSModuleDepFinder instance and execute scan_exec_script method with arguments
    analyser = PSModuleDepFinder()
    analyser.scan_exec_script(name)
    # check if name was added to instance dict
    assert analyser.exec_scripts != dict()


# Generated at 2022-06-20 14:20:00.799000
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    Test that PSModuleDepFinder can handle regular and optional C# module_util
    references in both a PowerShell module and recorded script.
    """
    # These are random chars to make sure the utils are not already part of
    # the import, but we need to ensure they are valid file names on all OS.
    cs_module_util = "ansible_collections.zp.zp3.plugins.module_utils.{0}"
    cs_module_util_template = "namespace ansible_collections.zp.zp3.plugins.module_utils.{0}\n{{\n  namespace {0}\n  {{\n    public class SomeClass\n    {{\n    }}\n  }}\n}}"

    # Generate unique names for the C# module utils so we don't conflict with
    # existing

# Generated at 2022-06-20 14:20:17.263222
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False

    for re_cs_module in finder._re_cs_module:
        assert re_cs_module.pattern == to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                                r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$')

# Generated at 2022-06-20 14:20:26.643117
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:39.547587
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pd = PSModuleDepFinder()

# Generated at 2022-06-20 14:20:50.744992
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script("TestScript1")
    ps.scan_exec_script("TestScript2")
    assert ps.exec_scripts["TestScript1"] == "Script1Data"
    assert ps.exec_scripts["TestScript2"] == "Script2Data"
    assert ps.cs_utils_wrapper == {"Ansible.Module.TestScript": {"data": "Script1Data", "path": '/path/to/Script1.ps1'}}


# Generated at 2022-06-20 14:20:52.684743
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)



# Generated at 2022-06-20 14:20:57.457033
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == {}
    assert dep_finder.exec_scripts == {}
    assert dep_finder.cs_utils_wrapper == {}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-20 14:21:10.222586
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:21:14.145310
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module("module", fqn=None, wrapper=False, powershell=True)
    ps_module_dep_finder.scan_exec_script("")


# Base64 encode a string

# Generated at 2022-06-20 14:22:20.590367
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmod = PSModuleDepFinder()
    assert psmod



# Generated at 2022-06-20 14:22:32.757719
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = to_bytes("""
#Requires -Module Ansible.ModuleUtils.PoshRSJob
#Requires -Module Posh-SSH
#Requires -Module Ansible.ModuleUtils.PowerShellVersion
#Requires -Module Ansible.ModuleUtils.WinRM
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Winner
#Requires -Version 2.3.1
#AnsibleRequires -OSVersion 10.0.1809.0
#AnsibleRequires -Become
""")

    finder = PSModuleDepFinder()
    finder.scan_module(module_data)


# Generated at 2022-06-20 14:22:44.156664
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:46.549814
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.become is False


# Generated at 2022-06-20 14:22:58.845771
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # prepare a mock wrapper script
    mock_module_util = to_text("# requires -module Ansible.ModuleUtils.TestHelper", errors='surrogate_or_strict')
    mock_script = to_text("%s\nWrite-Output '{{ \"NAME\": \"Test\" }}'| ConvertTo-Json" % mock_module_util,
                          errors='surrogate_or_strict')
    mock_wrapper_data = to_bytes(mock_module_util + "\n" + mock_script)

    # this is base64 encoded, but so is the data in the module_utils
    mock_encoded = base64.b64encode(mock_wrapper_data)
    mock_name = "Test"

    # prepare a mock hash of the module_utils

    mock_module_util_psm1

# Generated at 2022-06-20 14:23:08.400565
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = 'win_copy.ps1'
    finder.scan_exec_script(name)
    assert finder.exec_scripts[name] is not None

# Generated at 2022-06-20 14:23:20.293225
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:25.659217
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder._add_module = MagicMock()
    module_data = "#AnsibleRequires -PowerShell a b c"
    finder.scan_module(module_data)
    finder._add_module.assert_called_once_with("a", ".psm1", "", False, wrapper=False)

# Generated at 2022-06-20 14:23:37.583745
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.exec_scripts == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False


# Generated at 2022-06-20 14:23:50.492604
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    res = PSModuleDepFinder()
    assert res.ps_modules == {}
    assert res.exec_scripts == {}
    assert res.cs_utils_wrapper == {}
    assert res.cs_utils_module == {}
    assert res.ps_version is None
    assert res.os_version is None
    assert res._re_cs_module[0].pattern == b'(?i)^using\\s((Ansible\\..+)|' \
                                           b'(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$'

# Generated at 2022-06-20 14:24:34.516172
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    tester = PSModuleDepFinder()
    assert tester



# Generated at 2022-06-20 14:24:45.586033
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Test method scan_module of class PSModuleDepFinder"""
    # make sure the AnsibleError exception is raised for Ansible.ModuleUtils.TestModuleUtil.psm1
    mdf = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as excinfo:
        mdf.scan_module("""#Requires -Module Ansible.ModuleUtils.TestModuleUtil""")
    assert str(excinfo.value) == 'Could not find imported module support code for \'Ansible.ModuleUtils.TestModuleUtil\''



# Generated at 2022-06-20 14:24:51.071749
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.TestModuleUtil\n')

    assert ps_module_dep_finder.ps_modules.keys() == {'Ansible.ModuleUtils.TestModuleUtil'}



# Generated at 2022-06-20 14:25:01.130009
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    test_fqn = 'ansible.builtin.test'
    test_module = sys.modules[test_fqn]
    test_module_data = pkgutil.get_data('ansible.builtin', 'test.py')
    test_module_data = to_bytes(test_module_data, errors='surrogate_or_strict')
    test_instance = PSModuleDepFinder()
    test_instance.scan_module(test_module_data, fqn=test_fqn)
    assert set(test_instance.ps_modules.keys()) == set(['Ansible.ModuleUtils.powershell.Network'])

# Generated at 2022-06-20 14:25:07.137327
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    p = PSModuleDepFinder()
    assert p.ps_modules == dict()
    assert p.exec_scripts == dict()
    assert p.cs_utils_wrapper == dict()
    assert p.cs_utils_module == dict()
    assert p.ps_version is None
    assert p.os_version is None
    assert p.become is False

# Unit test method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:25:22.418667
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        ps_module_dep_finder = PSModuleDepFinder()
    except NameError as e:
        raise Exception('Could not initialize class "PSModuleDepFinder"')

    # Check that a non existing script returns None
    assert ps_module_dep_finder.scan_exec_script('no_such_script.ps1') is None

    # Check that an existing script is returned
    assert (ps_module_dep_finder.scan_exec_script('base_wrapper.ps1') ==
            'exec_wrapper.ps1' or 'exec_wrapper.ps1' == ps_module_dep_finder.scan_exec_script('base_wrapper.ps1'))

