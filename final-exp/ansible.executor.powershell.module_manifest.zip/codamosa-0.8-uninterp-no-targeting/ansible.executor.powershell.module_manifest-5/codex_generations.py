

# Generated at 2022-06-20 14:15:56.584694
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pmdf = PSModuleDepFinder()
    expected_dict = {}
    expected_dict['CommonUtils'] = b'# Common Content'
    pmdf.scan_exec_script('CommonUtils')
    assert expected_dict == pmdf.exec_scripts



# Generated at 2022-06-20 14:16:04.136169
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_ps")
    assert "ansible_collections.my_namespace.my_collection.plugins.module_utils.foo" in finder.cs_utils_wrapper
    assert "ansible_collections.my_namespace.my_collection.plugins.module_utils.bar" in finder.cs_utils_wrapper



# Generated at 2022-06-20 14:16:15.693500
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert not dep_finder.become

    # Test compiled regexes
    assert dep_finder._re_cs_module[0] is not None
    assert dep_finder._re_cs_in_ps_module is not None
    assert dep_finder._re_wrapper is not None
    assert dep_finder._re_ps_version is not None
    assert dep_finder._re_os_version is not None
    assert dep_finder._re_become is not None


# Unit

# Generated at 2022-06-20 14:16:20.027478
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert isinstance(dep, PSModuleDepFinder) == True



# Generated at 2022-06-20 14:16:31.632793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.module_utils import basic
    import mock
    from ansible.module_utils.powershell.executor import (
        ps_module_dep_finder,
        ps_module_utils_loader,
    )

    # Make sure we start with a fresh class for all of these tests
    ps_module_dep_finder.PSModuleDepFinder = PSModuleDepFinder

    # py3 hack to convert the __loader__ magic to a proper mock
    mock_loader = mock.MagicMock(
        spec=ps_module_utils_loader,
        find_plugin=lambda x, y: x,
    )
    basic.__loader__ = mock_loader

    # Any module that is not available in basic will be mocked and return a
    # random set of bytes so we do not have to worry about it's contents.

# Generated at 2022-06-20 14:16:39.382910
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    with pytest.raises(AnsibleError, match=r"Could not find executor powershell script for 'foo'"):
        instance.scan_exec_script('foo')
    instance.scan_exec_script('helpers')
    # add more test cases


# Generated at 2022-06-20 14:16:51.824618
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """ test scan module method of PSModuleDepFinder class """
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_data = pkgutil.get_data(
        "ansible_collections.test.test_collection.plugins.modules", "win_ping"
    )
    ps_module_dep_finder.scan_module(ps_module_data)
    util_data = ps_module_dep_finder.ps_modules.get(
        "ansible_collections.test.test_collection.plugins.module_utils.win_psrp_connectivity_check"
    )
    assert b"Ping-PSRPHost" in util_data.get("data")



# Generated at 2022-06-20 14:16:58.862515
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    
    ps_module = """#Requires -Module Ansible.ModuleUtils.SomethingElse
#Requires -Version 1.0.0.0
#AnsibleRequires -CSharpUtil ansible_collections.test.test.plugins.module_utils.test_module_util
# Requires -Module Ansible.ModuleUtils.SomeModule
#AnsibleRequires -PowerShell Ansible.ModuleUtils.AnotherModule
# AnsibleRequires -PowerShell Ansible.ModuleUtils.AnotherModule -Optional
#AnsibleRequires -PowerShell .module_util

"""
    depfinder.scan_module(ps_module, fqn="ansible_collections.test.test.plugins.modules.ps_module", wrapper=False, powershell=True)
    

# Generated at 2022-06-20 14:17:02.591358
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    a_PSModuleDepFinder = PSModuleDepFinder()
    assert a_PSModuleDepFinder is not None


# Generated at 2022-06-20 14:17:12.733073
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:17:48.070279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class Test(object):
        def __init__(self, home, file_name, code_object_sequence, arg_spec, bufsize,
                     encoding, errors, newline, op_arg, op_name, qualname,
                     random_bytes_func, refcount,
                     *args, **kwargs):
            self.filename = file_name
    class MagicMock(object):
        def __init__(self, home, file_name, code_object_sequence, arg_spec, bufsize,
                     encoding, errors, newline, op_arg, op_name, qualname,
                     random_bytes_func, refcount,
                     *args, **kwargs):
            self.filename = file_name
        def __getattr__(self, name):
            if name == '_vm':
                return self

# Generated at 2022-06-20 14:17:48.880119
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True  # TODO: implement your test here


# Generated at 2022-06-20 14:17:55.516789
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    obj = PSModuleDepFinder()

    # Test what happens when no usable module data is provided.
    obj.scan_module(b'')
    assert obj.ps_modules == {}
    assert obj.cs_utils_module == {}
    assert obj.cs_utils_wrapper == {}
    assert obj.ps_version is None
    assert obj.os_version is None
    assert obj.become is False

    # Test what happens when module data is provided.

# Generated at 2022-06-20 14:18:06.969071
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Arrange
    psmd = PSModuleDepFinder()

# Generated at 2022-06-20 14:18:09.361406
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # If the class does not exist, the test will fail.
    assert PSModuleDepFinder



# Generated at 2022-06-20 14:18:22.968339
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Tests for methods scan_module and _add_module
    # of class PSModuleDepFinder to ensure that it
    # correctly identifies dependencies and adds them
    # to the appropriate data structure

    # A ps1 file without any includes that should return
    # an empty set of dependencies
    test_module_a = """import-module ansible.windows
    $ErrorActionPreference = 'stop'
    $AnsibleModule = $env:ANSIBLE_MODULE_UTILS_MODULE_OBJ
    if ($AnsibleModule.ansible_version -match 'devel') {
        $AnsibleModule.display('Deprecated', 'ansible.windows supports Ansible 2.9 and higher')
    }
    """

    # A ps1 file that includes builtins and collections

# Generated at 2022-06-20 14:18:28.665134
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("microsoft.powershell.management")
    assert b'#Requires -Module Ansible.ModuleUtils.Powershell.Management' in dep_finder.exec_scripts["microsoft.powershell.management"]
    assert dep_finder.exec_scripts["microsoft.powershell.management"].startswith(b'#region generated')


# Generated at 2022-06-20 14:18:33.887325
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Just testing the raise since this method is called from more than one
    # place and any valid input is tested in those places.
    fd = PSModuleDepFinder()
    fd.scan_module(b"#Requires -Version 2")


# Generated at 2022-06-20 14:18:39.566226
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('PortableExecuteModule')
    assert len(dep_finder.cs_utils_wrapper) == 16
    assert len(dep_finder.ps_modules) == 59
    assert len(dep_finder.exec_scripts) == 1


# Generated at 2022-06-20 14:18:50.395628
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    f = PSModuleDepFinder()

    assert f.ps_modules is not None
    assert f.exec_scripts is not None
    assert f.cs_utils_module is not None
    assert f.cs_utils_wrapper is not None
    assert f.ps_version is None
    assert f.os_version is None
    assert f.become is False
    for pattern in f._re_cs_module:
        assert len(pattern.pattern) != 0

    for pattern in f._re_cs_in_ps_module:
        assert len(pattern.pattern) != 0

    for pattern in f._re_ps_module:
        assert len(pattern.pattern) != 0

    assert len(f._re_wrapper.pattern) != 0
    assert len(f._re_ps_version.pattern) != 0

# Generated at 2022-06-20 14:19:20.352069
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-20 14:19:27.202939
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    f = PSModuleDepFinder()
    module_data = to_bytes("""
# Requires -Module Ansible.ModuleUtils.Test
# Requires -Module Ansible.ModuleUtils.Test1
# AnsibleRequires -Powershell Ansible.ModuleUtils.Test2
# AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Test3
# AnsibleRequires -CSharpUtil ansible_collections.Test.Test.plugins.module_utils.Test4
# AnsibleRequires -CSharpUtil ansible_collections.Test.Test.plugins.module_utils.Test5 -Optional
# AnsibleRequires -CSharpUtil .Test6 -Optional
# AnsibleRequires -CSharpUtil .Test7
# AnsibleRequires -Wrapper Test
    """)

    f.scan_module(module_data)
    assert f

# Generated at 2022-06-20 14:19:38.396035
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    c = PSModuleDepFinder()
    assert c.ps_modules == {}
    assert c.cs_utils_wrapper == {}
    assert c.cs_utils_module == {}
    assert c.ps_version is None
    assert c.os_version is None
    assert c.become is False
    assert len(c._re_cs_module) == 1
    assert len(c._re_cs_in_ps_module) == 1
    assert len(c._re_ps_module) == 2
    assert c._re_wrapper is not None
    assert c._re_ps_version is not None
    assert c._re_os_version is not None
    assert c._re_become is not None


# Generated at 2022-06-20 14:19:48.093672
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:00.009456
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """
    test_PSModuleDepFinder: test for constructor of class PSModuleDepFinder
    """
    psmdf = PSModuleDepFinder()
    assert (isinstance(psmdf, PSModuleDepFinder))
    assert (psmdf.ps_modules == dict())
    assert (psmdf.cs_utils == dict())
    assert (psmdf._re_ps_module)
    assert (psmdf._re_cs_module)
    assert (psmdf._re_wrapper)
    assert (psmdf._re_ps_version)
    assert (psmdf._re_os_version)
    assert (psmdf._re_become)

# Unit test function for function _strip_comments

# Generated at 2022-06-20 14:20:09.246881
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a PSModuleDepFinder object
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module('#AnsibleRequires -CSharpUtil collection.package.plugins.module_utils.test_util')
    assert 'collection.package.plugins.module_utils.test_util' in ps_module_dep_finder.cs_utils_module.keys()

    # Add a new C# util
    ps_module_dep_finder.scan_module('#AnsibleRequires -CSharpUtil collection.package.plugins.module_utils.test_util2')
    assert 'collection.package.plugins.module_utils.test_util2' in ps_module_dep_finder.cs_utils_module.keys()

# Generated at 2022-06-20 14:20:22.831848
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'script.ps1')

# Generated at 2022-06-20 14:20:24.228917
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    scanner = PSModuleDepFinder()
    assert True

# Generated at 2022-06-20 14:20:37.715874
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    output = {}

# Generated at 2022-06-20 14:20:40.863110
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    """ This only tests that the class can be initialized. Most of the internal
        state values are tested in other functions.
    """
    finder = PSModuleDepFinder()
    assert finder



# Generated at 2022-06-20 14:21:20.932293
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    mf = PSModuleDepFinder()
    assert mf.ps_version is None
    assert mf.os_version is None
    assert mf.become is False
    assert len(mf.cs_utils_wrapper.keys()) == 0
    assert len(mf.cs_utils_module.keys()) == 0
    assert len(mf.ps_modules.keys()) == 0

# unit test for method scan_module

# Generated at 2022-06-20 14:21:30.360358
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = """#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz
#Requires -Module ..module_utils.foo
#Requires -Version 2.0
#AnsibleRequires -PowerShell ..module_utils.bar
#AnsibleRequires -CSharpUtil ..module_utils.baz
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.secret
#AnsibleRequires -Wrapper test
#AnsibleRequires -OSVersion 2.0
#AnsibleRequires -Become
""".encode('utf-8')
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_

# Generated at 2022-06-20 14:21:44.504755
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    m = PSModuleDepFinder()
    module_data = '''#Requires -Module Ansible.ModuleUtils.SomeModule
#Requires -Module Ansible.ModuleUtils.AnotherModule
#Requires -Version 5.4
#AnsibleRequires -PowerShell Ansible.ModuleUtils.YetAnother
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.yet_another
'''
    m.scan_module(module_data)
    assert 'Ansible.ModuleUtils.SomeModule' in m.ps_modules.keys()
    assert 'Ansible.ModuleUtils.AnotherModule' in m.ps_modules.keys()
    assert 'Ansible.ModuleUtils.YetAnother' in m.ps_modules.keys()

# Generated at 2022-06-20 14:21:55.437852
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:05.387181
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:17.585676
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    obj = PSModuleDepFinder()

    # Convert a string to bytes
    module_data = to_bytes("""#! /usr/bin/env

# Requires -Module Ansible.ModuleUtils.MyModule
# Requires -Module Ansible.ModuleUtils.AnotherModule
# AnsibleRequires -Powershell ..module_utils.submodule
# AnsibleRequires -CSharpUtil MyCSharpUtil
# AnsibleRequires -CSharpUtil AnotherCSharpUtil
# AnsibleRequires -CSharpUtil ansible_collections.myns.mycoll.plugins.module_utils.another
# AnsibleRequires -Wrapper MyExecScript
""")

    # Call scan_module
    result = obj.scan_module(module_data)

    # Asserts

# Generated at 2022-06-20 14:22:18.487721
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert dep

# Generated at 2022-06-20 14:22:26.165895
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Test module_utils use cases
    ps_module_finder = PSModuleDepFinder()

    # Test required psm1 use cases
    ps_module_finder.scan_module('#Requires -Module Ansible.ModuleUtils.SPB')
    assert 'Ansible.ModuleUtils.SPB' in ps_module_finder.ps_modules.keys()

    # Test optional psm1 use cases
    ps_module_finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.SPB -Optional')
    assert 'Ansible.ModuleUtils.SPB' in ps_module_finder.ps_modules.keys()

    # Test required cs use cases for a module

# Generated at 2022-06-20 14:22:32.214767
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert len(psmdf.ps_modules.keys()) == 0
    assert len(psmdf.cs_utils_module.keys()) == 0
    assert len(psmdf.cs_utils_wrapper.keys()) == 0
    assert len(psmdf.exec_scripts.keys()) == 0
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert not psmdf.become


# Generated at 2022-06-20 14:22:43.554742
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
#
# Ensure the method scan_module of class PSModuleDepFinder return the correct result
#
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.netcommon.utils import validate_certs, compare_dicts
    import tempfile, os
    myfinder = PSModuleDepFinder()
    tmpdir = tempfile.mkdtemp()
    base_dir = os.path.join(tmpdir, "ansible_collections", "ansible", "netcommon")
    os.makedirs(base_dir)
    module_dir = os.path.join(base_dir, "plugins", "modules")
    os.makedirs(module_dir)
    module_utils_dir = os.path.join(base_dir, "plugins", "module_utils")

# Generated at 2022-06-20 14:23:10.414228
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()
    assert isinstance(psmdf, PSModuleDepFinder)
    assert psmdf.ps_modules == dict()
    assert psmdf.exec_scripts == dict()
    assert psmdf.cs_utils_wrapper == dict()
    assert psmdf.cs_utils_module == dict()
    assert psmdf.ps_version is None
    assert psmdf.os_version is None
    assert psmdf.become == False
    assert isinstance(psmdf._re_cs_module, list)
    assert isinstance(psmdf._re_cs_in_ps_module, list)
    assert isinstance(psmdf._re_ps_module, list)
    assert isinstance(psmdf._re_wrapper, re._pattern_type)

# Generated at 2022-06-20 14:23:23.196503
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:31.760584
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible_collections.my.my_collection.plugins.module_utils.powershell.common import Common

    finder = PSModuleDepFinder()
    finder.scan_exec_script("hello_exec")

    assert finder.ps_modules[Common.ANSIBLE_MODULE_UTILS_BASE].data
    assert finder.ps_modules[Common.ANSIBLE_MODULE_UTILS_BASE].path
    assert finder.ps_modules[Common.ANSIBLE_MODULE_UTILS_PSUTILS].data
    assert finder.ps_modules[Common.ANSIBLE_MODULE_UTILS_PSUTILS].path



# Generated at 2022-06-20 14:23:39.778833
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass
    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)
    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)
    class ModuleTest(object):
        def __init__(self):
            self.fail_json = fail_json
            self.exit_json = exit_json
    module = ModuleTest()
    def load_json(data):
        return json.loads(data)
    def get_platform():
        return 'linux'

# Generated at 2022-06-20 14:23:52.920331
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    # No dependencies
    module_data = '''
$a = 1
Write-Output PSVersion
Write-Host "Hello"
    '''
    finder.scan_module(module_data)

    assert not finder.ps_modules
    assert not finder.cs_utils_module
    assert not finder.cs_utils_wrapper
    assert not finder.exec_scripts

    # ps_module
    module_data = '''
#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
$a = 1
Write-Output PSVersion
Write-Host "Hello"
    '''

    finder.scan_module(module_data)

    assert 'Ansible.ModuleUtils.Foo' in finder.ps_

# Generated at 2022-06-20 14:23:54.553891
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.exec_scripts = {"abc": "abc"}
    dep_finder.scan_exec_script("abc")
    assert not dep_finder.exec_scripts


# Generated at 2022-06-20 14:24:07.609667
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = b'List of lines\n' \
        b'#AnsibleRequires -CSharpUtil Ansible.{name}\n' \
        b'#Requires -Module Ansible.ModuleUtils.{name}\n' \
        b'#Requires -Module Ansible.ModuleUtils.{name} -Option\n' \
        b'#AnsibleRequires -CSharpUtil Ansible.{name} -Optional\n' \
        b'#AnsibleRequires -CSharpUtil ansible_collections.{namespace}.{collection}.plugins.module_utils.{name}\n' \
        b'#AnsibleRequires -CSharpUtil ansible_collections.{namespace}.{collection}.plugins.module_utils.{name} -Optional\n'

# Generated at 2022-06-20 14:24:16.477078
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 14:24:17.716795
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert isinstance(PSModuleDepFinder(), object)

# Generated at 2022-06-20 14:24:30.036966
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:25:03.872127
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # initialize a PSModuleDepFinder object
    obj = PSModuleDepFinder()

    # set up the fixture data
    fqn = "ns.coll.module"
    fqn_underscores = "ns_coll_module"
    module_data = b'''#! usr/bin/python
# Copyright: (c) 2017, Ansible Project
# Copyright: (c) 2017, Red Hat, Inc.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}


DOCUMENTATION = '''

# Generated at 2022-06-20 14:25:10.547475
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell.compat import HAS_PS_MODULE_UTILS
    if HAS_PS_MODULE_UTILS:
        # file "test_ansible_module_data.psm1" contains a single '#Requires -Module Ansible.ModuleUtils.Powershell'
        test_module_data = pkgutil.get_data(
            "ansible.module_utils.powershell", "test_ansible_module_data.psm1"
        )
        assert test_module_data is not None

        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(test_module_data, fqn='ansible_collections.test.test_name')

        # Check that the module support util ('Powershell') was found and added

# Generated at 2022-06-20 14:25:18.740495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for check powershell script for module_utils
    script_data = pkgutil.get_data("ansible.module_utils.powershell", "common.psm1")
    if script_data is None:
        return
    md = PSModuleDepFinder()
    md.scan_module(script_data, wrapper=True, powershell=True)
    assert(md.ps_modules)


# Generated at 2022-06-20 14:25:32.644797
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    def _slurp(fu):
        with open(fu, 'rb') as fo:
            return to_bytes(fo.read())

    os_module_util_finder = PSModuleDepFinder()
    os_module_util_finder.scan_module(_slurp(os.path.join(C.DEFAULT_MODULE_PATH[0], 'os_server.py')), fqn='os_server')
    # Test method scan_exec_script of class PSModuleDepFinder
    assert 'Ansible.ModuleUtils.Common' in os_module_util_finder.ps_modules
    # Test method scan_exec_script of class PSModuleDepFinder