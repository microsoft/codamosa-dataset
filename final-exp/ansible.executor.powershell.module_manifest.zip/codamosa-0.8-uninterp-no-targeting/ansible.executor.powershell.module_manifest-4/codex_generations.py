

# Generated at 2022-06-20 14:15:46.777836
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO
    return



# Generated at 2022-06-20 14:15:57.556307
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    pass

# PSModuleDepFinder.scan_module()
MODULE_IMPORT_STRING_PSM1 = b"""
#AnsibleRequires -Wrapper win_system.ps1
#AnsibleRequires -PowerShell ansible_collections.example.collection.plugins.module_utils.foo
#AnsibleRequires -CSharpUtil ansible_collections.example.collection.plugins.module_utils.bar
#AnsibleRequires -PowerShell ansible_collections.example.collection.plugins.module_utils.baz
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo
"""


# Generated at 2022-06-20 14:16:09.085424
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # init
    # read and base64 encode module file
    mod_path = "%s/../../../lib/ansible/modules/cloud/azure/azure_rm_virtualmachine.psd1" % os.path.dirname(__file__)
    mod_data = base64.b64encode(open(mod_path, 'r').read().encode('utf-8')).decode('utf-8')

    # read and base64 encode required module file
    mod_req_path = "%s/../../../lib/ansible/modules/cloud/azure/azure_rm_common_base.psm1" % os.path.dirname(__file__)

# Generated at 2022-06-20 14:16:20.245667
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:16:21.457304
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-20 14:16:32.774754
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # generate a random name for the temporary module
    tmp_module_name = "tmp_" + ''.join(random.choice('0123456789ABCDEF') for i in range(16))
    tmp_module_path = os.path.join(C.DEFAULT_LOCAL_TMP, tmp_module_name + ".psm1")

    # test module data

# Generated at 2022-06-20 14:16:38.176334
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("common")
    assert(True)


# Generated at 2022-06-20 14:16:49.255363
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_deps_finder = PSModuleDepFinder()
    assert ps_deps_finder._re_cs_module is not None
    assert ps_deps_finder._re_cs_in_ps_module is not None
    assert ps_deps_finder._re_ps_module is not None
    assert ps_deps_finder._re_wrapper is not None
    assert ps_deps_finder._re_ps_version is not None
    assert ps_deps_finder._re_os_version is not None
    assert ps_deps_finder._re_become is not None



# Generated at 2022-06-20 14:16:57.887528
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
   p = PSModuleDepFinder()
   #ps1 = """ # PowerShell Version: 5.1
# Executable: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
# Executable Arguments: -ExecutionPolicy Unrestricted -File
# Working Directory: C:\Users\dan\AppData\Local\Temp\ansible-tmp-1583560055.02-12583476243061\ansible_powershell_payload_cu9X9S
# Execution Timeout: 30


# Generated at 2022-06-20 14:17:09.549674
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''Testing scan_module method of class PSModuleDepFinder'''
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from mock import patch

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('Basic')
    assert 'Basic' in ps_module_dep_finder.exec_scripts

    with patch.object(PSModuleDepFinder, 'scan_module') as mock_scan_module:
        ps_module_dep_finder.scan_module('test_module_data', fqn='test_fqn', wrapper=False, powershell=False)

# Generated at 2022-06-20 14:17:34.538872
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Test for method scan_exec_script of class PSModuleDepFinder not yet implemented"

# Generated at 2022-06-20 14:17:47.105554
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils.powershell import csharp_call_cmdlet
  from ansible.module_utils.powershell import csharp_to_powershell_type_spec
  from ansible.module_utils.powershell import csharp_type_spec_to_powershell_type
  from ansible.module_utils.powershell import generate_powershell_remote_tempdir
  from ansible.module_utils.powershell import is_powerstate_installed
  from ansible.module_utils.powershell import is_powershell_installed
  from ansible.module_utils.powershell import is_pscore_installed
  from ansible.module_utils.powershell import is_psdsc_installed
  from ansible.module_utils.powershell import is_ps

# Generated at 2022-06-20 14:18:03.669540
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes, to_text

    # test regular script
    with tempfile.NamedTemporaryFile(mode='w+b', delete=False) as tf:
        tf.write(to_bytes(u"[DscLocalConfigurationManager()]\nconfiguration Sample_Example\n{\n}", errors='surrogate_or_strict'))
        tf.flush()

    mdf = PSModuleDepFinder()
    mdf.scan_exec_script(to_text(tf.name))

    os.unlink(tf.name)

    assert len(mdf.ps_modules) != 0


# Generated at 2022-06-20 14:18:04.203638
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True



# Generated at 2022-06-20 14:18:12.576581
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # init an instance
    dep_finder = PSModuleDepFinder()

    # init test data
    data = b'''#Requires -Module Ansible.ModuleUtils.test_module
#Requires -Module Ansible.ModuleUtils.test_module2
#AnsibleRequires -PowerShell Ansible.ModuleUtils.test_module3
#AnsibleRequires -PowerShell ansible_collections.test.test_col.plugins.module_utils.test_module4
#AnsibleRequires -PowerShell ..module_utils.test_module5
#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.test_module6
#AnsibleRequires -CSharpUtil ansible_collections.test.test_col.plugins.module_utils.test_module7'''
    # call scan_module

# Generated at 2022-06-20 14:18:26.009245
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()

    # test a simple case with no deps
    bad_module = """
# this is an ansible module

$x = "hello world"
"""
    depfinder.scan_module(to_bytes(bad_module))
    assert depfinder.ps_modules == {}
    assert depfinder.cs_utils_module == {}

    # test a simple case with one dep
    good_module = """
# this is an ansible module

$x = "hello world"
#Requires -Module Ansible.ModuleUtils.Dep1
#Requires -Module Ansible.ModuleUtils.Dep2
#Requires -Module Ansible.ModuleUtils.Dep3
"""
    depfinder.scan_module(to_bytes(good_module))

# Generated at 2022-06-20 14:18:34.711284
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Given
    ps_mod_dep_finder = PSModuleDepFinder()
    ps_mod_dep_finder.scan_exec_script(name="powershell_version")
    # When
    result = ps_mod_dep_finder.exec_scripts
    # Then
    assert result["powershell_version"] != ""


# Generated at 2022-06-20 14:18:37.570841
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_util = PSModuleDepFinder()
    return module_util.scan_exec_script(name="WindowsFeature")


# Generated at 2022-06-20 14:18:49.158741
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.errors import AnsibleError
    from ansible.plugins import ps_module_utils_loader
    from ansible.module_utils.six import b, PY3

    def _mock_find_plugin(name, extension):
        if name == 'Ansible.ModuleUtils.TestModule' and extension == '.psm1':
            return 'TEST.psm1'
        return None

    ps_module_utils_loader.find_plugin = _mock_find_plugin

    mock_slurp = 'function slupr() { return "test" }'


# Generated at 2022-06-20 14:19:02.019230
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
# Start test of method scan_module of class PSModuleDepFinder with the following arguments: module_data: 
    # tested - expected response
    test_passed = False

# Generated at 2022-06-20 14:19:19.710558
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    test_obj = PSModuleDepFinder()
    assert test_obj is not None


# Generated at 2022-06-20 14:19:20.899962
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
    :return:
    '''


# Generated at 2022-06-20 14:19:25.853326
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmd = PSModuleDepFinder()
    assert psmd


# Generated at 2022-06-20 14:19:29.272581
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert type(ps_module_dep_finder).__name__ == "PSModuleDepFinder"


# Generated at 2022-06-20 14:19:31.475059
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

# Test for scan_module

# Generated at 2022-06-20 14:19:32.121319
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-20 14:19:42.148576
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module = PSModuleDepFinder()
    ps1_data = to_bytes(u'''#$PSVersionTable
#requires -Module Ansible.ModuleUtils.Powershell
#AnsibleRequires -PowerShell Ansible.ModuleUtils.MyUtil
''')
    module.scan_module(ps1_data)
    module_util_name = u'Ansible.ModuleUtils.Powershell'
    module_util_name2 = u'Ansible.ModuleUtils.MyUtil'
    assert module_util_name in module.ps_modules
    assert module_util_name2 in module.ps_modules


# Generated at 2022-06-20 14:19:46.740298
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False


# Unit tests for function _slurp

# Generated at 2022-06-20 14:19:54.219698
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_obj = PSModuleDepFinder()
    module_data = '#AnsibleRequires -PowerShell Foo.psm1\n'
    fqn = mock.MagicMock()
    wrapper = mock.MagicMock()
    powershell = mock.MagicMock()
    assert test_obj.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-20 14:19:56.950208
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep_finder = PSModuleDepFinder()

    # The test will pass if no exception occurs.



# Generated at 2022-06-20 14:20:12.517618
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
	ps_module_dep_finder = PSModuleDepFinder()
	actual = ps_module_dep_finder.scan_module('module_data', 'fqn', 'wrapper')
	assert actual == None

# Generated at 2022-06-20 14:20:16.528173
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script('PowerShellExecutor')

    assert f.exec_scripts['PowerShellExecutor'] is not None



# Generated at 2022-06-20 14:20:26.229560
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # content of test module
    module_data = b'''
        #AnsibleRequires -PowerShell ansible_collections.
        #AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Common
        #AnsibleRequires -PowerShell C:\\Temp
        #AnsibleRequires -CSharpUtil ansible_collections.microsoft.windows.plugins.module_utils.foo.bar
        #AnsibleRequires -CSharpUtil C:\\Temp
        #AnsibleRequires -PowerShell ..module_utils.common
        #AnsibleRequires -CSharpUtil ..module_utils.common
    '''
    expected_ps_modules = ['ansible_collections.', 'C:\\Temp', '..module_utils.common']

# Generated at 2022-06-20 14:20:32.644716
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import re
    md = PSModuleDepFinder()
    md.scan_module(b'#Requires -Module Ansible.ModuleUtils.LoremIpsum')
    assert 'Ansible.ModuleUtils.LoremIpsum' in md.ps_modules.keys()

# Generated at 2022-06-20 14:20:43.106753
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # assumes that _strip_comments() works

    ps_data_with_cs_util_ref = b"""#Requires -Module Ansible.ModuleUtils.Name
#AnsibleRequires -CSharpUtil Ansible.UtilName
some_code_here
"""

    ps_data_with_cs_collection_util_ref = b"""#Requires -Module Ansible.ModuleUtils.Name
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.UtilName
some_code_here
"""

    ps_data_with_ps_util_ref = b"""#Requires -Module Ansible.ModuleUtils.Name
#AnsibleRequires -PowerShell ..module_utils.UtilName
some_code_here
"""


# Generated at 2022-06-20 14:20:43.883839
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-20 14:20:56.170362
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:21:07.557497
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:21:15.083314
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert(ps_module_finder.ps_modules == dict())
    assert(ps_module_finder.exec_scripts == dict())
    assert(ps_module_finder.cs_utils_wrapper == dict())
    assert(ps_module_finder.cs_utils_module == dict())
    assert(ps_module_finder.ps_version is None)
    assert(ps_module_finder.os_version is None)
    assert(ps_module_finder.become == False)


# Generated at 2022-06-20 14:21:15.969365
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    assert not hasattr(PSModuleDepFinder(), 'module_utils')


# Generated at 2022-06-20 14:21:44.141602
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fd = PSModuleDepFinder()
    m = """#Requires -Module Ansible.ModuleUtils.Test.psm1
#Requires -Module Ansible.ModuleUtils.Test2
#AnsibleRequires -PowerShell Ansible.ModuleUtils.Test3
#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.1
#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.2 -Optional
#AnsibleRequires -CSharpUtil Ansible.Testr
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.3
#AnsibleRequires -CSharpUtil ansible_collections.namespace.collection.plugins.module_utils.4 -Optional"""
    f

# Generated at 2022-06-20 14:21:51.248459
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False


# Generated at 2022-06-20 14:22:02.002789
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from mock import patch
    from ansible.module_utils._text import to_text

    dep_finder = PSModuleDepFinder()
    assert dep_finder.ps_modules == dict()
    assert dep_finder.cs_utils_wrapper == dict()
    assert dep_finder.cs_utils_module == dict()
    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None
    assert dep_finder.become is False


# Generated at 2022-06-20 14:22:15.829816
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Testing PSModuleDepFinder_scan_module")

    b_data = to_bytes("""#Requires -Module Ansible.ModuleUtils.Foo.Bar
#AnsibleRequires -PowerShell ..module_utils.Foo.Bar
#AnsibleRequires -PowerShell ansible_collections.microsoft.azure.plugins.module_utils.Foo.Bar
#AnsibleRequires -CSharpUtil ..module_utils.Foo.Bar
#AnsibleRequires -CSharpUtil ansible_collections.microsoft.azure.plugins.module_utils.Foo.Bar
#AnsibleRequires -CSharpUtil Ansible.Foo.Bar
#AnsibleRequires -Wrapper Foo.Bar""")

    md = PSModuleDepFinder()
    md.scan_module(b_data)


# Generated at 2022-06-20 14:22:17.316663
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Not any unit tests for this method for now
    pass

# Generated at 2022-06-20 14:22:25.624339
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # collect_version is a required util by default.
    utils = PSModuleDepFinder()
    utils.scan_module(to_bytes(''))
    assert 'Ansible.ModuleUtils.Powershell.CollectVersion' in utils.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.Common.ArgumentSpec' in utils.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.Convert' in utils.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.ConvertTo' in utils.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.Deserialize' in utils.ps_modules.keys()

# Generated at 2022-06-20 14:22:36.340388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    assert 'EnablePSRemoting' not in module_dep_finder.exec_scripts
    # scan the exec script
    module_dep_finder.scan_exec_script('EnablePSRemoting')
    assert 'EnablePSRemoting' in module_dep_finder.exec_scripts
    assert module_dep_finder.exec_scripts['EnablePSRemoting'] is not None
    # scan the exec script again, it should return immediately
    module_dep_finder.scan_exec_script('EnablePSRemoting')
    assert 'EnablePSRemoting' in module_dep_finder.exec_scripts
    assert module_dep_finder.exec_scripts['EnablePSRemoting'] is not None



# Generated at 2022-06-20 14:22:44.117740
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # sample response from _slurp
    string1 = "tutorial"
    # sample response from pkgutil.get_data
    string2 = "tutorial"
    # sample response from pkgutil.get_data
    string3 = "tutorial"
    # sample response from import_module
    string4 = "tutorial"
    # sample response from pkgutil.get_data
    string5 = "tutorial"
    # set module_utils
    module_utils = set(["tutorial", "tutorial", "tutorial", "tutorial", "tutorial"])

    # sample AnsibleError error message
    string6 = "Could not find imported module support code for \'tutorial\'"
    # sample AnsibleError error message
    string7 = "Could not find imported module support code for \'tutorial\'"
    # sample Ans

# Generated at 2022-06-20 14:22:55.023015
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_finder = PSModuleDepFinder()
    assert hasattr(ps_module_finder, '_re_cs_module')
    assert hasattr(ps_module_finder, '_re_cs_in_ps_module')
    assert hasattr(ps_module_finder, '_re_ps_module')
    assert hasattr(ps_module_finder, '_re_wrapper')
    assert hasattr(ps_module_finder, '_re_ps_version')
    assert hasattr(ps_module_finder, '_re_os_version')
    assert hasattr(ps_module_finder, '_re_become')



# Generated at 2022-06-20 14:23:05.892293
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # create an object of PSModuleDepFinder class
    obj = PSModuleDepFinder()
    # create a module_data for testing the scan_module method of class PSModuleDepFinder
    module_data = '#Requires -Module Ansible.ModuleUtils.ConnectionWindows, Ansible.ModuleUtils.Powershell, Ansible.ModuleUtils.WinRM, Ansible.ModuleUtils.Compression'
    assert obj.scan_module(module_data) == None



# Generated at 2022-06-20 14:23:26.854236
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.executor import PSWorker
    import tempfile
    test_file_path = tempfile.mkstemp()
    test_file = test_file_path[1]
    test_file_handle = test_file_path[0]

# Generated at 2022-06-20 14:23:33.044692
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import io
    import sys
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    # NOTE: ps_version and os_version is a mock for _parse_version_match
    #       which is a private method. _parse_version_match is tested in
    #       test_PSModuleDepFinder_scan_module
    module_path = 'Build/TestData/Modules/Windows/Legacy/Graph/Edge/AzureAD.psm1'
    module_wrapper = 'Build/TestData/Modules/Windows/Legacy/Graph/Edge/AzureAD-exec-wrapper.psm1'
    redir_stdout = io.StringIO()
    redir_stderr = io.StringIO()
    sys.stdout = redir_stdout
    sys.st

# Generated at 2022-06-20 14:23:39.035022
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_object = PSModuleDepFinder()
    test_object.scan_exec_script(name='title')


# Generated at 2022-06-20 14:23:43.281657
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder.ps_modules, dict)
    assert isinstance(finder.cs_utils_wrapper, dict)
    assert isinstance(finder.cs_utils_module, dict)


# Generated at 2022-06-20 14:23:49.617813
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fixture = PSModuleDepFinder()
    fixture.scan_exec_script('common')
    assert fixture.exec_scripts['common'] == pkgutil.get_data('ansible.executor.powershell', 'common.ps1')
    assert 'Ansible.ModuleUtils.Common.AnsibleModule' in fixture.ps_modules.keys()

# Generated at 2022-06-20 14:24:04.932717
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    import pytest
    from ansible_collections.ansible.netcommon.tests.unit.data import PS_MODULE_DATA

    # test constructor
    d = PSModuleDepFinder()
    assert d.ps_modules == {}
    assert d.cs_utils_wrapper == {}
    assert d.cs_utils_module == {}
    assert d.exec_scripts == {}
    assert d.ps_version == None
    assert d.os_version == None
    assert d.become == False

    # test _parse_version_match
    d._parse_version_match(match=d._re_ps_version.match(b'#requires -Version 1.2.3'), attribute='ps_version')
    assert d.ps_version == '1.2.3'

# Generated at 2022-06-20 14:24:16.981796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-20 14:24:27.841324
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    psmdf = PSModuleDepFinder()

    # Constructor creates dicts for the C# utils and the PS modules
    assert(isinstance(psmdf.cs_utils_wrapper, dict))
    assert(isinstance(psmdf.cs_utils_module, dict))
    assert(isinstance(psmdf.ps_modules, dict))
    assert(isinstance(psmdf.exec_scripts, dict))

    # Constructor sets the ps_version and os_version to None
    assert(psmdf.ps_version is None)
    assert(psmdf.os_version is None)
    assert(psmdf.become is False)


# Generated at 2022-06-20 14:24:36.917482
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module('#Requires -Module Ansible.ModuleUtils.ArgumentSpec.ArgumentSpec')
    assert('Ansible.ModuleUtils.ArgumentSpec.ArgumentSpec' in finder.ps_modules)

    finder = PSModuleDepFinder()
    finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.ArgumentSpec.ArgumentSpec')
    assert('Ansible.ModuleUtils.ArgumentSpec.ArgumentSpec' in finder.ps_modules)

    finder = PSModuleDepFinder()
    finder.scan_module('#AnsibleRequires -PowerShell ansible_collections.namespace.collection.plugins.module_utils.ArgumentSpec.ArgumentSpec')

# Generated at 2022-06-20 14:24:39.324704
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    try:
        PSModuleDepFinder()
    except Exception as err:
        assert False, err


# Generated at 2022-06-20 14:25:09.561994
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_info = PSModuleDepFinder()
    assert(module_info.ps_modules == {})
    assert(module_info.exec_scripts == {})
    assert(module_info.cs_utils_module == {})
    assert(module_info.cs_utils_wrapper == {})
    assert(module_info.ps_version is None)
    assert(module_info.os_version is None)
    assert(module_info.become == False)
    assert (module_info._re_cs_module != [])
    assert (module_info._re_cs_in_ps_module != [])
    assert (module_info._re_ps_module != [])
    assert (module_info._re_wrapper is not None)
    assert (module_info._re_ps_version is not None)

# Generated at 2022-06-20 14:25:20.637817
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.ps_modules = { 'ansible.module_utils.powershell.common': {},
                          'ansible.module_utils.powershell.win_dsc': {},
                          'ansible.module_utils.powershell.windows': {},
                          'ansible.module_utils.powershell.text': {},
                          'ansible.module_utils.powershell.base': {},
                          'ansible.module_utils.powershell.webadministration': {}
                        }
    finder.scan_exec_script('ps_exec')

    assert 'ps_exec' in finder.exec_scripts
    assert 'ansible.module_utils.powershell.common' in finder.ps_modules