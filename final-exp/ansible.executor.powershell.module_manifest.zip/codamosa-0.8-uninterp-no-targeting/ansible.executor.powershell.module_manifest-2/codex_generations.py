

# Generated at 2022-06-20 14:15:56.925978
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.cs_utils_module == {}
    assert ps_module_dep_finder.cs_utils_wrapper == {}
    assert len(ps_module_dep_finder._re_ps_module) == 2
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1
    assert len(ps_module_dep_finder._re_cs_module) == 1
    assert len(ps_module_dep_finder._re_cs_in_ps_module) == 1
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep

# Generated at 2022-06-20 14:16:06.099506
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    src_path = "/tmp/ansible_test_PSModuleDepFinder_scan_module"
    try:
        with open(src_path, "rb") as f:
            f_data = f.read()
            ps_mdf = PSModuleDepFinder()
            ps_mdf.scan_module(f_data)
            ps_mdf.scan_module(f_data, fqn="test.module")
            ps_mdf.scan_module(f_data, fqn="test.module", wrapper=True)
    finally:
        pass


# Generated at 2022-06-20 14:16:17.074796
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()

# Generated at 2022-06-20 14:16:18.050163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Add tests for method PSModuleDepFinder.scan_exec_script()
    pass

# Generated at 2022-06-20 14:16:19.228398
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.removed import removed_module
    removed_module(removed_in="2.10")


# Generated at 2022-06-20 14:16:22.956987
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = "powershell.exe"
    finder.scan_exec_script(name)
    assert finder.exec_scripts[name]

# Generated at 2022-06-20 14:16:31.323781
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Copy nested dict to avoid changing the original data
    wrapper_dict = PSModuleDepFinder().exec_scripts.copy()
    ps_module_dep_finder = PSModuleDepFinder()
    ps_scripts = 'ansible.executor.powershell'
    wrapper_dict['common.ps1'] = pkgutil.get_data(ps_scripts, 'common.ps1')
    ps_module_dep_finder.exec_scripts = wrapper_dict
    ps_module_dep_finder.scan_exec_script('common')
    assert True


# Generated at 2022-06-20 14:16:37.818464
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_instance = PSModuleDepFinder()
    output = test_instance.scan_exec_script("Get-Credential")
    print("test_PSModuleDepFinder_scan_exec_script() output: %s" % output)


# Generated at 2022-06-20 14:16:39.875085
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("script_name")


# Generated at 2022-06-20 14:16:53.347350
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    # Create an instance of PSModuleDepFinder
    finder = PSModuleDepFinder()

    # Assert that _re_cs_in_ps_module is a list
    assert type(finder._re_cs_in_ps_module) is list
    # Assert that _re_cs_module is a list
    assert type(finder._re_cs_module) is list
    # Assert that _re_ps_module is a list
    assert type(finder._re_ps_module) is list

    # Assert that ps_modules is a dictionary
    assert type(finder.ps_modules) is dict
    # Assert that exec_scripts is a dictionary
    assert type(finder.exec_scripts) is dict
    # Assert that cs_utils_wrapper is a dictionary
    assert type(finder.cs_utils_wrapper) is dict

# Generated at 2022-06-20 14:17:23.222772
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()

    assert ps_module_dep_finder is not None
    assert ps_module_dep_finder._re_ps_version is not None
    assert ps_module_dep_finder._re_os_version is not None
    assert ps_module_dep_finder._re_become is not None
    assert ps_module_dep_finder._re_wrapper is not None
    assert ps_module_dep_finder._re_ps_module is not None
    assert ps_module_dep_finder._re_cs_module is not None
    assert ps_module_dep_finder._re_cs_in_ps_module is not None
    assert ps_module_dep_finder.ps_modules == {}
    assert ps_module_dep_finder.cs_utils_module == {}

# Generated at 2022-06-20 14:17:30.387047
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = """Hey there, I'm a module.
#AnsibleRequires -PowerShell Ansible.ModuleUtils.OtherModule
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.AnotherModule"""

    m = PSModuleDepFinder()
    assert m.ps_modules == dict()
    assert m.cs_utils_wrapper == dict()
    assert m.cs_utils_module == dict()

    m.scan_module(module_data)

    assert m.ps_modules == dict()
    assert m.cs_utils_wrapper == dict()
    assert m.cs_utils_module == dict()


# Generated at 2022-06-20 14:17:35.420141
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_data = "data/powershell/ansible_powershell_module_deps.data"

    def run_test_PSModuleDepFinder_scan_module(lines, expected_result, expected_os_version, expected_ps_version, expected_become):
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(lines)
        assert dep_finder.cs_utils_wrapper == expected_result
        assert dep_finder.os_version == expected_os_version
        assert dep_finder.ps_version == expected_ps_version
        assert dep_finder.become == expected_become


# Generated at 2022-06-20 14:17:47.672836
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    dep = PSModuleDepFinder()
    assert dep
    assert len(dep.ps_modules) == 0
    assert len(dep.exec_scripts) == 0
    assert len(dep.cs_utils_wrapper) == 0
    assert len(dep.cs_utils_module) == 0
    assert dep.ps_version is None
    assert dep.os_version is None
    assert dep.become is False
    assert len(dep._re_cs_module) == 1
    assert len(dep._re_cs_in_ps_module) == 1
    assert len(dep._re_ps_module) == 2
    assert dep._re_wrapper is not None
    assert dep._re_ps_version is not None
    assert dep._re_os_version is not None
    assert dep._re_become is not None



# Generated at 2022-06-20 14:17:54.373616
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import ps_module_loader
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class TestPSModuleDepFinder(unittest.TestCase):

        def setUp(self):
            # Build a dict of all the supported collections and their module_utils
            self.collection_module_utils = {}
           

# Generated at 2022-06-20 14:17:56.608322
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pytest.skip("skip this test for now")


# Generated at 2022-06-20 14:18:03.994347
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()
    assert isinstance(finder, PSModuleDepFinder)
    assert finder.ps_modules == dict()
    assert finder.exec_scripts == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.ps_version == None
    assert finder.os_version == None
    assert finder.become == False


# Generated at 2022-06-20 14:18:11.750809
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    
    module_data = '#Requires -Module Ansible.ModuleUtils.{name}'
    fqn = 'Ansible.ModuleUtils.{name}'
    ps_modules = {
        r'Ansible.ModuleUtils.{name}': {
            'data': '{data}',
            'path': r'{path}',
        }
    }
    cs_utils = psmdf.cs_utils_wrapper if wrapper else psmdf.cs_utils_module 
    
    lines = module_data.split('\n')
    module_utils = set()
    ps_version = psmdf.ps_version
    os_version = psmdf.os_version
    become = psmdf.become
    
    # Replace import

# Generated at 2022-06-20 14:18:25.279577
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    loader = PSModuleDepFinder()
    results = {}
    sample_module = '''
    [CmdletBinding()]
    param()

    process {
        Write-Output "Hello"
    }
    '''
    results['ps_modules'] = {}
    results['cs_utils_module'] = {}
    results['cs_utils_wrapper'] = {}
    results['exec_scripts'] = {}
    results['ps_version'] = None
    results['os_version'] = None
    results['become'] = False

    loader.scan_module(to_bytes(sample_module))


# Generated at 2022-06-20 14:18:33.887518
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pmdf = PSModuleDepFinder()
    pmdf.scan_module('')
    assert pmdf.ps_modules == dict()
    assert pmdf.exec_scripts == dict()
    assert pmdf.cs_utils_wrapper == dict()
    assert pmdf.cs_utils_module == dict()
    assert pmdf.ps_version is None
    assert pmdf.become is False
    assert pmdf._re_cs_module[0].pattern == b'(?i)^using\\s((Ansible\\..+)|(ansible_collections\\.\\w+\\.\\w+\\.plugins\\.module_utils\\.[\\w\\.]+));\\s*$'

# Generated at 2022-06-20 14:19:29.433877
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder_obj = PSModuleDepFinder()
    setattr(ps_module_dep_finder_obj, 'ps_version', '1.2.3')
    setattr(ps_module_dep_finder_obj, 'os_version', '10.0.0.1')
    setattr(ps_module_dep_finder_obj, 'become', True)
    assert getattr(ps_module_dep_finder_obj, 'ps_version') == '1.2.3'
    assert getattr(ps_module_dep_finder_obj, 'os_version') == '10.0.0.1'
    assert getattr(ps_module_dep_finder_obj, 'become') is True


# Generated at 2022-06-20 14:19:42.190794
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    tester = PSModuleDepFinder()


# Generated at 2022-06-20 14:19:44.501411
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    path = finder.scan_exec_script("hello.ps1")
    assert path is not None

# Generated at 2022-06-20 14:19:57.223942
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script('ansible_module_wrapper')

    # There is no way to determine how many C# utils will be used
    # so if the count changes, update this test
    assert len(ps.cs_utils_wrapper) > 0

    # There is no way to determine the exact count of ps module_utils but
    # since we are using the test Ansible module, it should be more than 0
    assert len(ps.ps_modules) > 0

    assert len(ps.exec_scripts) == 1
    assert 'ansible_module_wrapper.ps1' in ps.exec_scripts.keys()
    assert ps.exec_scripts['ansible_module_wrapper.ps1'] is not None


# Generated at 2022-06-20 14:20:07.631810
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Load the test data from the data directory
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    data_dir = os.path.join(curr_dir, 'unit', 'powershell', 'data')
    powershell_script = os.path.join(data_dir, 'test_powershell_script.ps1')

    with open(powershell_script, 'rb') as f:
        data = f.read()

    # Create a PSModuleDepFinder
    psModuleDepFinder = PSModuleDepFinder()

    # Create expected output
    expected_exec_scripts = {u'test_powershell_script': data}

# Generated at 2022-06-20 14:20:19.473872
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.removal import RemovalNotice
    ansible_module_utils_common_removal_check_unsupported_version(
        'ansible.module_utils.powershell.common', RemovalNotice(2.11))

    # NOTE: This test is not able to fully test the this method, it needs to be
    # modified to work outside of the powershell ansible environment. The
    # exec_scripts is not getting set and the code can not be run in a separate
    # python process, it would require the execution of windows code.

    ps = PSModuleDepFinder()
    ps.scan_exec_script("00_ps_base")


# Generated at 2022-06-20 14:20:28.002676
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module("""
#Requires -Module Ansible.ModuleUtils.LoggingPrereqs
#Requires -Module Ansible.ModuleUtils.Powershell
#Requires -Module Ansible.ModuleUtils.CommonArgs
#Requires -Module Ansible.ModuleUtils.TestBuilder
#Requires -Module Ansible.ModuleUtils.TestRunner
#Requires -Module Ansible.ModuleUtils.TestArgumentSpec
""")

# Generated at 2022-06-20 14:20:40.307918
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    finder = PSModuleDepFinder()

    assert finder.ps_modules == dict(), "start value of ps_modules should be empty dict"
    finder.ps_modules['Ansible.ModuleUtils.Test'] = {
        'data': b'some data',
        'path': 'c:\\test.psm1',
    }

# Generated at 2022-06-20 14:20:54.910701
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:20:58.487692
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_df = PSModuleDepFinder()
    assert ps_df._re_cs_module
    assert ps_df._re_ps_module
    assert ps_df._re_wrapper
    assert ps_df._re_cs_in_ps_module
    assert ps_df._re_ps_version
    assert ps_df._re_os_version
    assert ps_df._re_become



# Generated at 2022-06-20 14:22:18.365655
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    ps_module_dep_finder = PSModuleDepFinder()
    assert isinstance(ps_module_dep_finder, PSModuleDepFinder)


# Generated at 2022-06-20 14:22:26.141180
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-20 14:22:37.306414
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module_data = to_bytes("""
#Requires -Module Ansible.ModuleUtils.Powershell
#Requires -Module Ansible.ModuleUtils.Powershell.Extensions
#Requires -Module Ansible.ModuleUtils.Powershell.SecurityPolicy
#Requires -Module Ansible.ModuleUtils.LegacyWindows
#Requires -Module Ansible.ModuleUtils.WinSystem
#Requires -Module Ansible.ModuleUtils.UCS
#Requires -Version 6.2.3
    """)
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data, fqn="ansible_test_module")

# Generated at 2022-06-20 14:22:40.172870
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("integration")



# Generated at 2022-06-20 14:22:54.047785
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    module = PSModuleDepFinder()

    assert module.ps_modules == dict()
    assert module.cs_utils_wrapper == dict()
    assert module.cs_utils_module == dict()
    assert module.ps_version is None
    assert module.os_version is None
    assert module.become is False
    assert len(module._re_cs_module) == 1
    assert len(module._re_ps_module) == 2
    assert module._re_wrapper is not None
    assert module._re_ps_version is not None
    assert module._re_os_version is not None
    assert module._re_become is not None

    # assert that all regexes match
    # regex 1

# Generated at 2022-06-20 14:23:09.650600
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import sys
    import tempfile
    import unittest

    class TestPSModuleDepFinderScanExecScript(unittest.TestCase):
        def setUp(self):
            self.dep_finder = PSModuleDepFinder()
            self.path = None
            self.rand = random.randint(1, 1000000)

        def tearDown(self):
            if self.path is not None and os.path.exists(self.path):
                os.unlink(self.path)

        def test_PSModuleDepFinder_scan_exec_script(self):
            self.path = self._create_file("""
                #Requires -Module Ansible.ModuleUtils.Powershell._common
                #ansiblerequires -powershell .module_utils.common_required
            """)

            self.dep

# Generated at 2022-06-20 14:23:22.630835
# Unit test for constructor of class PSModuleDepFinder

# Generated at 2022-06-20 14:23:24.396432
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ## test_PSModuleDepFinder_scan_module ##
    # TODO
    pass


# Generated at 2022-06-20 14:23:27.754174
# Unit test for constructor of class PSModuleDepFinder
def test_PSModuleDepFinder():
    PSModuleDepFinder()


# Generated at 2022-06-20 14:23:37.949841
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-20 14:24:39.125305
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    scan_module(data, fqn=None, wrapper=False, powershell=True)
    """

    def test_scan_module_no_requirements_psm1(self):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'wb') as f:
            f.write(to_bytes(''))

        mdf = PSModuleDepFinder()
        mdf.scan_module(to_bytes(''),
                        fqn="Ansible.ModuleUtils.Common.TestModule.Test")
        self.assertFalse(mdf.ps_modules)

    def test_scan_module_found_psm1(self):
        fd, path = tempfile.mkstemp()

# Generated at 2022-06-20 14:24:48.930521
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Test case for ``PSModuleDepFinder.scan_module`` method."""
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Something')
    assert ps_module_dep_finder.ps_modules == {
        'Ansible.ModuleUtils.Something': {'data': b'Something\n', 'path': 'Ansible.ModuleUtils.Something.psm1'}
    }
    ps_module_dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Something')

# Generated at 2022-06-20 14:25:01.852620
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text_encoder import JSONConfigTextEncoder
    from collections import OrderedDict

    for module_name in ['basic-ansible', 'other-ansible', 'other-collection-ansible']:
        def _make_module_data(module_name, lines):
            return to_bytes(C.MODULE_REQUIRE_ARGS + '\n' + module_name + '\n' + '\n'.join(lines))

        module_data = _make_module_data(module_name, ['#Requires -Module Ansible.ModuleUtils.basic_example'])
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_module(module_data)
        assert len(dep_finder.ps_modules) == 1
        assert dep_finder.ps_modules

# Generated at 2022-06-20 14:25:12.002139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Unit test for method scan_exec_script of class PSModuleDepFinder
    '''

    # TODO: Disable insufficiently isolated tests warning
    # pylint: disable=R0801
    import pkg_resources

    obj = PSModuleDepFinder()

    # Path to random powershell script
    test_script_name = 'exec_async_wrapper'
    test_script_path = 'ansible/executor/powershell/exec_async_wrapper.ps1'
    exec_script = pkg_resources.resource_filename('ansible.executor.powershell', test_script_path)
    test_script = open(exec_script, "r").read().encode('utf-8')

    # Execute test with script name
    obj.scan_exec_script(test_script_name)



# Generated at 2022-06-20 14:25:25.667405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _slurp(path):
        with open(path) as f:
            return f.read()

    obj = PSModuleDepFinder()

    # test_ps_modules
    obj.ps_modules = dict()
    obj.exec_scripts = dict()
    for module_name in ["powershell_script", "powershell_script_wrapper"]:
        obj.scan_exec_script(module_name)

    # map of required scripts and the source code
    ps_modules = {}
    for module_name in ["powershell_script", "powershell_script_wrapper"]:
        ps_modules[module_name] = _slurp("./module_utils/powershell/%s.ps1" % module_name)

    assert obj.ps_modules == {}
    assert set(obj.exec_scripts.keys())