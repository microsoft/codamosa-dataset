

# Generated at 2022-06-10 23:23:29.974908
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create a sample module data to scan
    module_data = pkgutil.get_data("ansible.executor.powershell", "StandardWrapper.ps1")

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("StandardWrapper")

    assert ps_module_dep_finder.exec_scripts["StandardWrapper"] == to_bytes(module_data)

    module_data = pkgutil.get_data("ansible.executor.powershell", "ScriptWrapper.ps1")

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("ScriptWrapper")

    assert ps_module_dep_finder.exec_scripts["ScriptWrapper"] == to_bytes(module_data)

# Generated at 2022-06-10 23:23:37.022831
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test when executor powershell script is not found
    scanner = PSModuleDepFinder()
    test_data1 = scanner.scan_exec_script('dummyfile')
    assert test_data1 is None
    # Test when executor powershell script is found
    test_data2 = scanner.scan_exec_script('basic')
    assert test_data2 is None


# Generated at 2022-06-10 23:23:46.921156
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class _PSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            PSModuleDepFinder.__init__(self)
            self.exec_scripts = {
                "foo": 'some text',
            }

        def scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
            pass

        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            pass

        def _parse_version_match(self, match, attribute):
            pass

    dep_finder = _PSModuleDepFinder()

    assert dep_finder.scan_exec_script("foo") is None

# Generated at 2022-06-10 23:23:56.556578
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
  from ansible.errors import AnsibleError
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.compat.version import LooseVersion
  psmdf = PSModuleDepFinder()
  try:
    psmdf.scan_module(to_bytes("#Requires -Module Ansible.ModuleUtils.Network.F5.Common\n"))
    if psmdf.ps_modules.get("Ansible.ModuleUtils.Network.F5.Common") is None:
      raise AssertionError("Expected Ansible.ModuleUtils.Network.F5.Common to be present in ps_modules")
  except (AnsibleError, AssertionError) as ex:
    print("Exception: {}".format(ex))

# Generated at 2022-06-10 23:24:02.138388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # PsModuleDepFinder.scan_exec_script
    finder.scan_exec_script('powershell_base')
    assert finder.exec_scripts['powershell_base'] == pkgutil.get_data('ansible.executor.powershell', 'powershell_base.ps1')
    assert finder.exec_scripts['powershell_base'] != None
    assert finder.ps_modules['Ansible.ModuleUtils.Process'] == {'data': pkgutil.get_data('ansible.module_utils.powershell', 'Process.psm1'), 'path': '/usr/lib/python2.7/site-packages/ansible/module_utils/powershell/Process.psm1'}
    finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:24:05.155844
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    PSModuleDepFinder_obj = PSModuleDepFinder()
    module_data = ''
    PSModuleDepFinder_obj.scan_module(module_data)

# Generated at 2022-06-10 23:24:14.416433
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # check if class instantiation works as expected
    # test normal case
    depfinder = PSModuleDepFinder()

    # tests for method scan_exec_script of class PSModuleDepFinder
    # test normal case
    depfinder.scan_exec_script("powershell.exe")

    # test case where the Executable powershell.exe could not be found
    # test when an exception is raised
    try:
        depfinder.scan_exec_script("test")
    except AnsibleError as e:
        assert str(e.message) == "Could not find executor powershell script for 'test'"


# Generated at 2022-06-10 23:24:15.972699
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("test")



# Generated at 2022-06-10 23:24:25.244830
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import inspect
    from ansible.executor.powershell import module_manifest
    from ansible.module_utils.common.parameters import get_platform_subclass
    p = get_platform_subclass()

    # This is required to get the additional powershell module_utils
    module_manifest.get_ps_version = lambda: '5.1'

    finder = PSModuleDepFinder()
    finder.scan_exec_script('pswrap')

    # Now let's make sure the script contains the additional utils

# Generated at 2022-06-10 23:24:26.271338
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:24:53.722833
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a PSModuleDepFinder instance
    finder = PSModuleDepFinder()
    # test scan_exec_script() with exec script name ps
    finder.scan_exec_script(name = 'ps')

    assert finder.exec_scripts is not None

# Generated at 2022-06-10 23:24:58.474338
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            self.params = dict()

    # The tests below are only testing a small number of lines of code
    # out of this function. The rest of the function has already been
    # tested in the test_scan_module in test_module_utils_loader.
    my_finder = PSModuleDepFinder()
    my_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.AnsibleModule")
    dm = DummyModule()
    my_finder.populate_module_utils(dm)
    assert dm.params['ps_module_utils'] == "AnsibleModule"

    my_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:25:04.739236
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for method scan_exec_script of class PSModuleDepFinder."""
    pass

    # sample data
    data = """
    import sys
    import os
    import traceback
    import ansible.module_utils.powershell

    if __name__ == '__main__':
        try:
            main()
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stderr)
            sys.exit(1)
        sys.exit(0)
    """

    # set up
    ps_module_dep_finder = PSModuleDepFinder()

    # run

# Generated at 2022-06-10 23:25:16.665544
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:25:17.579384
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:25:24.679635
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mock_name = 'foo'
    mock_data = 'bar'
    pkgutil.get_data = mock_data

    mock_module_data = 'baz'
    PSModuleDepFinder.scan_module = mock_module_data

    PSModuleDepFinder.exec_scripts = {}

    PSModuleDepFinder.scan_exec_script(mock_name)
    assert mock_name in PSModuleDepFinder.exec_scripts



# Generated at 2022-06-10 23:25:30.343801
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", "test.ps1")
    if data is None:
        raise AnsibleError("Could not find executor powershell script for 'test'")
    
    b_data = to_bytes(data)
    finder = PSModuleDepFinder()
    finder.scan_module(b_data, wrapper=True, powershell=True)
    assert True

# Generated at 2022-06-10 23:25:36.436785
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fixture_path = "tests/fixtures/executor/powershell/"
    for exec_script in os.listdir(fixture_path):
        if exec_script.endswith(".ps1"):
            ps_module_dep_finder = PSModuleDepFinder()
        yield check_scan_exec_script, ps_module_dep_finder, exec_script


# Generated at 2022-06-10 23:25:50.875885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def _strip_comments():
        pass

    def _test_scan_module():
        pass

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.exec_scripts = dict()
    ps_module_dep_finder.ps_modules = dict()
    ps_module_dep_finder.cs_utils_module = dict()
    ps_module_dep_finder.cs_utils_wrapper = dict()
    ps_module_dep_finder.ps_version = None
    ps_module_dep_finder.os_version = None
    ps_module_dep_finder.become = False
    args = ['name','ext','fqn','optional','wrapper=False']
    args[2] = None
    args[4] = None
    args[2] = None

# Generated at 2022-06-10 23:25:54.843635
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mocker, obj = test_set_up_PSModuleDepFinder()
    mocker.patch('ansible.executor.powershell.ps_script')
    obj.scan_exec_script('ScriptName')



# Generated at 2022-06-10 23:26:11.106618
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("common.ps1")


# Generated at 2022-06-10 23:26:24.236715
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:26:32.090189
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # This is also used by validate-modules to get a module's required utils in base and a collection.
    ps_modules = dict()

    # by defining an explicit dict of cs utils and where they are used, we
    # can potentially save time by not adding the type multiple times if it
    # isn't needed
    cs_utils_wrapper = dict()

    ps_version = None
    os_version = None
    become = False


# Generated at 2022-06-10 23:26:38.215973
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    data = ('#Requires -Module Ansible.ModuleUtils.Common'
            '#Requires -Module Ansible.ModuleUtils.Common2'
            '#Requires -Module Ansible.ModuleUtils.Common3')
    obj.scan_module(data)
    assert 'Ansible.ModuleUtils.Common' in obj.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Common2' in obj.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Common3' in obj.ps_modules.keys()


# Generated at 2022-06-10 23:26:40.466901
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder().scan_exec_script('execute_powershell')



# Generated at 2022-06-10 23:26:51.769971
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test uses a slightly different approach as we need to test scan_exec_script
    # which, calls scan module using a different pattern. 
    import tempfile
    # write module data to a temp file
    expected_result = "\n#Requires -Module Ansible.ModuleUtils.Pester\n"
    with tempfile.NamedTemporaryFile(delete=False) as module_file:
        module_file.write(expected_result)
        module_file.seek(0)
        psModule = PSModuleDepFinder()
        psModule.scan_exec_script('pester')

    # assert that the module gets added to the ps_modules object
    assert psModule.ps_modules.has_key("Ansible.ModuleUtils.Pester")


# Generated at 2022-06-10 23:27:06.197639
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import shutil
    import tempfile
    import time

    ps_dep_finder = PSModuleDepFinder()

    # Test that if no script exists we get an error
    try:
        ps_dep_finder.scan_exec_script('fake_script')
        assert False
    except:
        pass

    # Test that an empty script exists
    ps_dep_finder.scan_exec_script("common_web")

    # Test a script that does have an import
    # Note that this method may be running on python 3, but the tests don't
    # care about that. We just need to run the code, so the fact that the
    # code runs is the test.
    ps_dep_finder.scan_exec_script("test_test")

# Generated at 2022-06-10 23:27:09.982546
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("service_common")
    assert depfinder.exec_scripts is not None

# Generated at 2022-06-10 23:27:18.595588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # this module_util has no deps
    name = 'TestModuleUtil'
    scan_exec_script_func = getattr(PSModuleDepFinder, 'scan_module')

    # Test if the name passed for the script, when using pkgutil.get_data,
    # gives the same result as the original function where it uses the CURRENT_DIR
    # variable, which doesn't actually exist, but it still works in the original
    # function.
    old_data = _slurp(os.path.join(C.DEFAULT_LOCAL_TMP, 'exec_scripts', name + '.ps1'))
    new_data = scan_exec_script_func(name)
    assert new_data == old_data

# Generated at 2022-06-10 23:27:30.218686
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    fqn = "ansible.module_utils.name"
    # a starter module with no deps
    module_data = to_bytes("""
    #!/usr/bin/python""")
    finder.scan_module(module_data, fqn=fqn)
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    # a module with no comments of any kind
    module_data = to_bytes("""
    #!/usr/bin/python

    # this comment is not a dependency
    import sys

    # more meaningless comments
    print('Hello world')
    """)

# Generated at 2022-06-10 23:27:50.606941
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_data = '#requires -version 3.0\n'
    fqdn = 'windows.win_ping'
    depFinder = PSModuleDepFinder()
    depFinder.scan_exec_script(fqdn)
    assert depFinder.exec_scripts[fqdn] == test_data
    assert depFinder.become



# Generated at 2022-06-10 23:27:51.428507
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:28:01.340429
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    d = PSModuleDepFinder()
    d.scan_module(b'''#Requires -Module Ansible.ModuleUtils.NetApp.ElementsWCF
#Requires -Module Ansible.ModuleUtils.NetApp.ONTAP
#Requires -Module Ansible.ModuleUtils.Legacy.Deploy.NetApp
#Requires -Module Ansible.ModuleUtils.NetApp.Common
''')
    assert d.ps_modules['Ansible.ModuleUtils.NetApp.ElementsWCF']['data'][:34] == b'# <summary>\n# This module is '
    assert d.ps_modules['Ansible.ModuleUtils.NetApp.ONTAP']['data'][:34] == b'# <summary>\n# This module is '

# Generated at 2022-06-10 23:28:04.270550
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder.scan_exec_script("ansible.module_utils.powershell.api") == None

# Generated at 2022-06-10 23:28:12.360320
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class ModuleUtilTest(object):

        def __init__(self):
            self.name = None
            self.data = None
            self.path = None
            self.fqn = None
            self.optional = None

    def mock_import_module(package):
        if package == 'ansible_collections.namespace.collection.plugins.module_utils.foo':
            return 'module_util'
        else:
            raise ImportError('No module named %s', package)

    def mock_get_data_from_package(package, resource):
        if package == 'module_util' and resource == 'bar.cs':
            return '1'
        else:
            raise IOError('Could not find %s %s', package, resource)


# Generated at 2022-06-10 23:28:19.613801
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('in test_PSModuleDepFinder_scan_exec_script')
    # test should pass
    try:
        import ansible.executor.powershell
        # powershell/HttpsCall.ps1
        # powershell/ScriptHelper.ps1
        module_depfinder = PSModuleDepFinder()
        module_depfinder.scan_exec_script(name='ScriptHelper')
    except Exception as ex:
        return False
    return True


# Generated at 2022-06-10 23:28:30.903108
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    runner = Runner('')
    runner.module_name = 'test'
    runner.module_args = '{"foo":"bar"}'
    finder = PSModuleDepFinder()

    # Case 1: script found
    finder.scan_exec_script('win_psexec')
    assert 'win_psexec' in finder.exec_scripts
    assert 'network' in finder.ps_modules
    exec_script_value = finder.exec_scripts.get('win_psexec')
    assert exec_script_value is not None
    assert b'# Get Network Speed' in exec_script_value

    # Case 2: script not found

# Generated at 2022-06-10 23:28:37.732032
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ##################################################
    # if wrapper not in self.exec_script.keys():
    #   if data is None:
    #      raise AnsibleError("Could not find executor powershell script for '%s'" % name)
    #
    ##################################################
    # case 1: wrapper in self.exec_script.keys()
    # assert True:
    #    return
    ##################################################
    # case 2: wrapper not in self.exec_script.keys()
    # if data is None:
    #    raise AnsibleError("Could not find executor powershell script for '%s'" % name)
    ###################################################

    # case 1:
    PSModuleDepFinder_obj = PSModuleDepFinder()
    name = "Test"

# Generated at 2022-06-10 23:28:45.992165
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    obj.scan_exec_script("generate-ansible-vars")
    assert obj.exec_scripts["generate-ansible-vars"] == "$ansible_module = $PSBoundParameters.ContainsKey('AnsibleModule') ? $PSBoundParameters['AnsibleModule'] : $AnsibleModule\n"
    with pytest.raises(AnsibleError):
        obj.scan_exec_script("generate-ansible-vars.test")


# Generated at 2022-06-10 23:28:56.464802
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    from ansible.plugins.loader import powershell_loader

    # Create a temp file for the test. Its content will be the content of
    # ansible/lib/modules/windows/foo.psm1 from the root of this repo.
    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-10 23:29:20.915116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = """
#requires -version 6
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.mycsutil.cs
"""
    finder = PSModuleDepFinder()
    with mock.patch.object(finder, 'scan_module'):
        finder.scan_exec_script('myscript')
        finder.scan_module.assert_called_with(b'#requires -version 6\n#AnsibleRequires '
                                              b'-CSharpUtil ansible_collections.ns.coll.plugins.module_utils.mycsutil.cs\n',
                                              wrapper=True, powershell=True)


# Generated at 2022-06-10 23:29:32.630629
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = to_bytes(b'#ansiblerequires -wrapper powershell')
    fqn = None
    wrapper = False
    powershell = True
    instance = PSModuleDepFinder()

    PSModuleDepFinder_scan_module = instance.scan_module
    def test_impl(module_data, fqn=None, wrapper=False, powershell=True):
        PSModuleDepFinder_scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-10 23:29:36.180631
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    assert len(mdf.scan_exec_script('Ansible.Legacy.Basic')) == 0


# Generated at 2022-06-10 23:29:40.704044
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_playbook")
    assert "ansible_playbook" in dep_finder.exec_scripts.keys()


# Generated at 2022-06-10 23:29:43.530368
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script("New-Item") == None


# Generated at 2022-06-10 23:29:54.433993
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Any os_version < 10 will trigger the win_reboot dependency to be added
    # which is used by the unit test below.
    os_version = '9.99'
    finder = PSModuleDepFinder()
    finder.os_version = os_version

    finder.scan_exec_script('Reboot')
    assert finder.exec_scripts['Reboot'] is not None

    found_reboot = False
    for required_util in finder.ps_modules['Ansible.ModuleUtils.Powershell.Standard.Reboot']['data'].splitlines():
        if b'#AnsibleRequires' in required_util:
            assert b'Ansible.ModuleUtils.Powershell.Win32.WinReboot' in required_util
            found_reboot = True
            break

   

# Generated at 2022-06-10 23:29:59.958014
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", "powershell_base.ps1")
    b_data = to_bytes(data)
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell_base")
    assert b_data == to_bytes(_slurp(dep_finder.exec_scripts["powershell_base"]))

# Generated at 2022-06-10 23:30:05.417631
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    module_data = _slurp('./test_data/ansible.windows.win_group.psm1')

    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_module(module_data)

    assert len(module_dep_finder.ps_modules) == 1
    assert module_dep_finder.ps_modules["Ansible.ModuleUtils.Common"]['data']

# Unit test to verify that if a module_util imports an optional module_util, it will not cause
# a failure if the optional module_util doesn't exist.

# Generated at 2022-06-10 23:30:16.158466
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    collection = "ansible_collections.ns.coll"
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("%s.plugins.module_utils.test.test2" % collection)
    assert ps_module_dep_finder.exec_scripts[to_text(
        "%s.plugins.module_utils.test.test2" % collection)].decode('utf-8').strip() == '''#!/usr/bin/env powershell
$string = 'test'
'''.strip()

# Generated at 2022-06-10 23:30:17.579511
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True


# Generated at 2022-06-10 23:30:43.684433
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of class PSModuleDepFinder
    ps_module_dep_finder_instance = PSModuleDepFinder()
    # Call method scan_exec_script with arguments name="win_service"
    ps_module_dep_finder_instance.scan_exec_script(name="win_service")


# Generated at 2022-06-10 23:30:55.318275
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil
    import ansible.executor.powershell.become
    ps_mdf = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", "become.ps1")
    if data is None:
        raise AnsibleError("Could not find executor powershell script become.ps1")
    # create temp dir and file
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, "become.ps1")
    with open(temp_file, 'wb') as f:
        f.write(data)
    # call scan_module
    ps_mdf.scan_exec_script("become")
    # cleanup temp dir and file

# Generated at 2022-06-10 23:30:56.593594
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert 1 == 1


# Generated at 2022-06-10 23:30:59.087668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_object = PSModuleDepFinder()
    name = "test_name"
    test_object.scan_exec_script(name)


# Generated at 2022-06-10 23:31:02.117568
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create a mock of the class
    mock_obj = PSModuleDepFinder()

    # create the arguments of the method
    name = 'test name'

    # do the test
    mock_obj.scan_exec_script(name)


# Generated at 2022-06-10 23:31:12.564999
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import powershell

    depfinder = PSModuleDepFinder()
    try:
        depfinder.scan_exec_script("this_script_does_not_exist")
    except Exception as e:
        assert type(e) is AnsibleError

    depfinder.scan_exec_script("win_ping")
    assert 'ping' in depfinder.exec_scripts.keys()

    dummy_module = to_bytes(pkgutil.get_data(powershell.__name__, to_text("dummy_module.psm1", errors='surrogate_or_strict')))
    depfinder.scan_module(dummy_module)
    assert len(depfinder.ps_modules.keys()) == 1

# Generated at 2022-06-10 23:31:18.421194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test if exception is raised when executor script is not found
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("DoesntExist")
    except AnsibleError as e:
        assert e.args[0] == "Could not find executor powershell script for 'DoesntExist'"

test_PSModuleDepFinder_scan_exec_script()


# Generated at 2022-06-10 23:31:23.138981
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('pipelining')
    # print dir(dep_finder)
# make this code work with python2.6
from io import open


# Generated at 2022-06-10 23:31:35.768052
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pytest
    import ansible.module_utils
    # We need to create a unique wrapper name to make sure the powershell module
    # doesn't already have it
    # TODO: replace with mock module
    ps_wrapper_name = "".join(chr(random.randint(ord("a"), ord("z"))) for i in range(10))
    ps_wrapper_data = b"# AnsibleRequires -wrapper " + to_bytes(ps_wrapper_name) + b'\n# Requires -Module ansible.module_utils.basic\n'
    ps_wrapper_data += pkgutil.get_data("ansible.module_utils", to_native("basic.ps1"))

    # Mock the data pkgutil returns for the powershell wrapper
    saved_pkgutil_data = pkgutil.get_data
    p

# Generated at 2022-06-10 23:31:44.606411
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class DummyConfig:
        def __init__(self):
            self.ansible_module_data = b''
        def get_config_value(self, val):
            if val == 'DEFAULT_DEBUG':
                return False
    class DummyRes:
        def __init__(self, data):
            self.data = data
    module = import_module('ansible_collections.test.test_collection.plugins.modules.test_module')
    fqn = module.TestModule.__module__
    pmdf = PSModuleDepFinder()
    pmdf.scan_module(DummyRes(DummyConfig().ansible_module_data).data, fqn=fqn)
    assert pmdf.ps_modules == {}
    assert pmdf.become == False

# Generated at 2022-06-10 23:32:41.055229
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmod = PSModuleDepFinder()

    # name
    name = 'Python27'
    n_name = name.lower()

    psmod.scan_exec_script(name)
    # check that the script has been added to exec_scripts
    assert psmod.exec_scripts[n_name]
    # check that no additional modules have been added
    assert len(psmod.ps_modules.keys()) == 0
    assert len(psmod.cs_utils_wrapper.keys()) == 0
    assert len(psmod.cs_utils_module.keys()) == 0

    # name
    name = 'PowerShell51'
    n_name = name.lower()

    psmod.scan_exec_script(name)
    # check that the script has been added to exec_scripts

# Generated at 2022-06-10 23:32:47.493438
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup variables
    psmdf = PSModuleDepFinder()
    name = "test"
    psmdf.scan_exec_script(name)
    assert psmdf.exec_scripts.__len__() == 1
    # check scan_module() invocation
    assert psmdf.ps_modules.__len__() == 4


# Generated at 2022-06-10 23:32:53.775163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # [Line: 194]
    # [Test: exec_script_ps_module_with_no_requires,
    #        exec_script_cs_module_with_no_requires]
    # [Email: syedseth@microsoft.com, pengguan@microsoft.com,
    #         wangzhen@microsoft.com, xiaoyongr@microsoft.com]
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script("ansible_powershell")
    psmd.scan_exec_script("ansible_module_build")
    # [Line: 207]
    # [Test: exec_script_ps_module_with_requires,
    #        exec_script_cs_module_with_requires]
    # [Email: syedseth@microsoft.com, pengguan

# Generated at 2022-06-10 23:33:02.509450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError
    ps_module_dep_finder = PSModuleDepFinder()
    name = "main"
    with pytest.raises(AnsibleError) as excinfo:
        ps_module_dep_finder.scan_exec_script(name)
    excinfo.match("Could not find executor powershell script for")
    assert excinfo.match("Could not find executor powershell script for '%s'" % name)
    # sample error: ansible.errors.AnsibleError: Could not find executor powershell script for 'main'
