

# Generated at 2022-06-10 23:23:29.923304
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._json_compat import dumps

    name = 'Invoke-PSInject'
    data = pkgutil.get_data("ansible.module_utils.powershell.powershell", name + ".psm1")
    if data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for '%s'" % name)

    b_data = to_bytes(data)
    b_data = _strip_comments(b_data)
    wrappers = dict()
    wrappers[name] = b_data

    mdf = PSModuleDepFinder()

# Generated at 2022-06-10 23:23:42.220567
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:23:46.221208
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as exc:
        finder.scan_exec_script("test")

    assert "Could not find executor powershell script for 'test'" == str(exc.value)


# Generated at 2022-06-10 23:23:56.124660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    base_data = _slurp(resource_from_fqcr('ansible_collections.namespace.collection.plugins.modules.module'))
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible-generated_wrapper")
    dep_finder.scan_exec_script("ansible-generated_wrapper_generated")

# Generated at 2022-06-10 23:23:56.842451
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO
    assert True



# Generated at 2022-06-10 23:24:05.216985
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("powershell_base")
    assert finder.exec_scripts["powershell_base"] == _slurp(finder.exec_scripts["powershell_base"])
    assert finder.ps_modules["Ansible.ModuleUtils.Common"]["data"] == _slurp(finder.ps_modules["Ansible.ModuleUtils.Common"]["path"])


# Generated at 2022-06-10 23:24:17.191050
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    from io import StringIO

    from ansible.module_utils.common.text.converters import to_text

    import ansible.module_utils.common.text.converters as conv

    with open('psmodule_sample.psd1', 'rb') as f:
        data = f.read()

    module_data = to_text(data, convert_newlines=False, errors='surrogate_or_strict')
    assert data == conv.to_bytes(module_data)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data, fqn="test_ps")
    assert sorted(dep_finder.ps_modules.keys()) == ['PSWindows']

# Generated at 2022-06-10 23:24:31.783283
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # initializing
    ps_module_depfinder = PSModuleDepFinder()
    ps_module_data = "#AnsibleRequires -PowerShell Ansible.ModuleUtils.Powershell.ConvertTo-Json"
    assert ps_module_depfinder.ps_modules == {}
    assert ps_module_depfinder.cs_utils_wrapper == {}
    assert ps_module_depfinder.cs_utils_module == {}
    assert ps_module_depfinder.ps_version == None
    assert ps_module_depfinder.os_version == None
    assert ps_module_depfinder.become == False

    # running the method
    ps_module_depfinder.scan_module(ps_module_data, wrapper=False, powershell=True)

    # compares

# Generated at 2022-06-10 23:24:40.957596
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()

    assert mu.exec_scripts == {}

    mu.scan_exec_script('powershell.ps1')
    mu.scan_exec_script('powershell_wrapper.ps1')

    assert len(mu.exec_scripts) == 2

    # Test that the C# utils are found in the scripts
    assert 'Ansible.ModuleUtils.Helper' in mu.cs_utils_wrapper
    assert 'Ansible.ModuleUtils.Common' in mu.cs_utils_wrapper
    assert 'Ansible.ModuleUtils.Helper' in mu.cs_utils_module
    assert 'Ansible.ModuleUtils.Common' in mu.cs_utils_module
    assert 'Ansible.ModuleUtils.Legacy' not in mu.cs_utils_module

# Generated at 2022-06-10 23:24:49.418748
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible.test.test_plugins.test_powershell
    t_module_data = pkgutil.get_data(ansible.test.test_plugins.test_powershell.__name__, 'ping.ps1')
    module_data = to_bytes(t_module_data, errors='surrogate_or_strict')

    ps_dep_finder = PSModuleDepFinder()
    ps_dep_finder.scan_module(module_data)
    assert len(ps_dep_finder.ps_modules) == 3


# Generated at 2022-06-10 23:25:16.665703
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # the main powershell script is shipped as a single file and just contains
    # a few lines for shebanging but we need to test to make sure it does
    # something
    finder.scan_exec_script('main')
    assert 'main' in finder.exec_scripts
    assert b'#!bin/powershell\n' == finder.exec_scripts['main']

    # this is a script that includes a reference to a #Requires -Module
    # ansible.powershell so we use it to test that scan_exec_script recursively
    # scans the scripts
    finder.scan_exec_script('test')
    assert 'test' in finder.exec_scripts
    assert b'require -module ansible.powershell' in finder.exec_scripts['test']



# Generated at 2022-06-10 23:25:23.488166
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible.module_utils.powershell.basic")
    assert dep_finder.exec_scripts['ansible.module_utils.powershell.basic'].startswith(b'#')
    assert dep_finder.ps_modules['Ansible.ModuleUtils.Basic']['data'].startswith(b'#requires -version')


# Generated at 2022-06-10 23:25:32.665240
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("run_pwsh_with_encoded_script")
    assert finder.exec_scripts["run_pwsh_with_encoded_script"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.PSUtils"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Crypto"] is not None
    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Formatting"] is not None
    assert finder.ps

# Generated at 2022-06-10 23:25:38.216321
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    # Return value of the test method
    return_value = obj.scan_module(
        module_data=0,
        fqn=1,
        wrapper=2,
        powershell=3,
    )

    # Return value of this method
    assert return_value is None


# Generated at 2022-06-10 23:25:43.694137
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder = PSModuleDepFinder()
    name = "Test"
    ps_module_dep_finder.scan_exec_script(name)
    assert name in ps_module_dep_finder.exec_scripts.keys()


# Generated at 2022-06-10 23:25:44.815132
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Add unit tests
    return



# Generated at 2022-06-10 23:25:53.618650
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  _module = AnsibleModule({})
  # For now, there isn't any import to the exec scripts because it is all internal.
  # A future change will remove this hardcoded file.
  ps_module_dep_finder = PSModuleDepFinder()
  ps_module_dep_finder.scan_exec_script('../../executor/powershell/ansible_module_wrapper.ps1')

  assert(ps_module_dep_finder.exec_scripts['../../executor/powershell/ansible_module_wrapper.ps1'] ==
         to_bytes(pkgutil.get_data("ansible.executor.powershell", "ansible_module_wrapper.ps1")))


# Generated at 2022-06-10 23:26:03.727388
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # pylint: disable=unused-argument
    def exec_script_data(*args):
        return b'a'
    finder.scan_exec_script = exec_script_data
    finder.exec_scripts = {}
    ps_module_name = b'foo'
    finder.scan_exec_script(ps_module_name)
    assert len(finder.exec_scripts) == 1
    assert list(finder.exec_scripts.keys())[0] == ps_module_name.decode()
    assert list(finder.exec_scripts.values())[0] == b'a'


# Generated at 2022-06-10 23:26:08.097563
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    name = "win_command"

    with pytest.raises(AnsibleError) as error:
        obj.scan_exec_script(name)
    assert "Could not find executor powershell script for 'win_command'" in error.value


# Generated at 2022-06-10 23:26:21.197915
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def mock_get_data(*args, **kwargs):
        return '#Requires -Module Ansible.ModuleUtils.TestUtil1\n' \
                '#Requires -Module Ansible.ModuleUtils.TestUtil2\n' \
                'function something() {\n' \
                '}\n'

    pkgutil_get_data_mock = 'ansible.module_utils.powershell.PSModuleDepFinder.pkgutil.get_data'
    with patch(pkgutil_get_data_mock, mock_get_data):
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_exec_script(name='test_name')

    assert dep_finder.exec_scripts.keys() == {'test_name'}

# Generated at 2022-06-10 23:26:38.068660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-10 23:26:50.337505
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(to_bytes("#AnsibleRequires -PowerShell Ansible.ModuleUtils.NetApp.ElementsWAPI"))
    assert len(psmdf.ps_modules) == 1, "Failed to add one module support package"
    assert "Ansible.ModuleUtils.NetApp.ElementsWAPI" in psmdf.ps_modules
    assert len(psmdf.ps_modules['Ansible.ModuleUtils.NetApp.ElementsWAPI']['data']) > 0, "Failed to add module support package data"
    assert len(psmdf.ps_modules['Ansible.ModuleUtils.NetApp.ElementsWAPI']['path']) > 0, "Failed to add module support package path"

# Generated at 2022-06-10 23:26:51.336282
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:26:56.348829
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # This test case require a powershell script in test folder
    f = PSModuleDepFinder()
    f.scan_exec_script("TestScript")
    assert("TestScript" in f.exec_scripts)
    assert("TestScript" in f.ps_modules)


# Generated at 2022-06-10 23:26:59.221839
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    finder = PSModuleDepFinder()

    finder.scan_exec_script("ansible_runner")
    assert finder.exec_scripts["ansible_runner"]



# Generated at 2022-06-10 23:27:12.246737
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import tempfile
    import collections.abc
    import pytest
    import ansible.module_utils.powershell

    # Since we are testing with real modules, we should use the correct basedir so we can find real modules
    os.environ['ANSIBLE_BASEDIR'] = '/usr/share/ansible'
    dep_finder = ansible.module_utils.powershell.PSModuleDepFinder()
    # get_module_path should not be used during this test because it can be affected by
    # ANSIBLE_CONFIG and testing with a non-standard basedir path
    dep_finder.get_module_path = lambda module: os.path.join('/usr/share/ansible', module)

    # Test the default script
    dep_finder.scan_exec_script('default')

# Generated at 2022-06-10 23:27:20.921645
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    dep_finder = PSModuleDepFinder()

    # get module with no requires
    module_file_name = to_bytes('get_windows_version.psm1')
    fqn = resource_from_fqcr('ansible_collections.ansible.windows.plugins.modules.{}'.format(module_file_name))
    module_data = _slurp(fqn)
    dep_finder.scan_module(module_data)
    assert len(dep_finder.ps_modules.keys()) == 0
    assert len(dep_finder.cs_utils_wrapper.keys()) == 0
    assert len(dep_finder.cs_utils_module.keys()) == 0

    assert dep_finder.ps_version is None
    assert dep_finder.os_version is None

# Generated at 2022-06-10 23:27:32.692588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test only the module_utils part, not the wrapper.
    # scan_exec_script of class PSModuleDepFinder with valid name
    # expected: module_util is added to self.exec_scripts
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("pwsh")
    assert (len(ps_module_dep_finder.exec_scripts) == 1)

    # scan_exec_script of class PSModuleDepFinder with invalid name
    # expected: AnsibleError is raised
    ps_module_dep_finder = PSModuleDepFinder()
    try:
        ps_module_dep_finder.scan_exec_script("abc")
        assert False, "AnsibleError not raised"
    except AnsibleError:
        assert True

    # scan

# Generated at 2022-06-10 23:27:43.365676
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:27:53.445021
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # mock data
    n_package_name = 'mock_package_name'
    n_resource_name = 'mock_resource_name'
    n_package_data = b'mock_package_data'
    
    # mock module
    mock_sys = Mock()
    mock_sys.version_info = (3, 5)

# Generated at 2022-06-10 23:28:12.254457
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    md = PSModuleDepFinder()
    md.scan_exec_script("powershell_script_runner")
    if 'powershell_script_runner' not in md.exec_scripts.keys() and 'powershell_script_runner.ps1' not in md.exec_scripts['powershell_script_runner']:
        raise AssertionError("powershell_script_runner not present in PSModuleDepFinder")


# Generated at 2022-06-10 23:28:12.913005
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:28:24.918323
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    ps_module = to_bytes(pkgutil.get_data("ansible.modules.windows.win_command", to_native("win_command.psm1")))
    finder.scan_module(ps_module)
    assert finder.ps_modules
    assert finder.ps_modules['Ansible.ModuleUtils.Common']
    assert not finder.cs_utils_wrapper
    assert not finder.cs_utils_module
    assert not finder.become
    assert not finder.exec_scripts
    assert finder.ps_version == '2.3.3'
    assert finder.os_version == '6.0.0'

    finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:28:32.504596
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('ExecutionWrapper')
    # The ordered dict has keys() and values() in Python 3 but not in Python 2.
    try:
        assert all(key in psmdf.exec_scripts for key in (b'ExecutionWrapper.ps1', b'ansible_module.ps1'))
    except AttributeError:
        assert all(key in psmdf.exec_scripts for key in ('ExecutionWrapper.ps1', 'ansible_module.ps1'))

# Generated at 2022-06-10 23:28:36.894277
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    _x = PSModuleDepFinder()
    _x.scan_exec_script('win_message')
    assert _x.exec_scripts['win_message'] == b'function win_message {param([array]$args)}\n\n'



# Generated at 2022-06-10 23:28:44.840566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_module__missing_module
    try:
        PSModuleDepFinder.scan_exec_script(PSModuleDepFinder(), None)
        assert False
    except:
        assert True

    # test_PSModuleDepFinder_scan_module__nonexistent_module
    try:
        PSModuleDepFinder.scan_exec_script(PSModuleDepFinder(), "non.existent")
        assert False
    except:
        assert True



# Generated at 2022-06-10 23:28:55.815283
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of PSModuleDepFinder with multiple arguments.
    # Arrange
    ps_modules = dict()
    exec_scripts = dict()
    os_version = None
    ps_version = None
    cs_utils_wrapper = dict()
    cs_utils_module = dict()
    become = False
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder._re_cs_module = []
    ps_module_dep_finder._re_cs_in_ps_module = []
    ps_module_dep_finder._re_ps_module = []
    ps_module_dep_finder._re_ps_version = []
    ps_module_dep_finder._re_os_version = []
    ps_module_dep_finder._re_become

# Generated at 2022-06-10 23:29:08.297797
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    payload = dict()
    payload['module_name'] = "win_get_url"
    payload['module_dep_finder'] = PSModuleDepFinder()
    payload['module_data'] = b"# this is for win_get_url"
    payload['name'] = 'win_get_url'
    payload['require_script'] = 'win_get_url'
    ansible_module = AnsibleModule(argument_spec={})

    # Manually set a value for this attribute (we cannot use the set_ansible_module_attributes
    # since powershell_loader.py is not yet in the module_utils list
    ansible_module.ansible_module_generated_args['module_dep_finder'] = payload['module_dep_finder']

    # Run the code to be tested
    powershell_ansible_module_

# Generated at 2022-06-10 23:29:09.014474
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:29:09.601305
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-10 23:29:27.647720
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("Checkpoint")
    assert len(finder.exec_scripts.keys()) == 1
    assert "Checkpoint" in finder.exec_scripts.keys()



# Generated at 2022-06-10 23:29:31.304366
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.IIS') == set(["Ansible.ModuleUtils.IIS"])


# Generated at 2022-06-10 23:29:35.021378
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Script.ps1')
    assert dep_finder


# Generated at 2022-06-10 23:29:36.526889
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  assert False # TODO: implement your test here


# Generated at 2022-06-10 23:29:45.311740
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Unit test for method scan_exec_script of class PSModuleDepFinder
    '''
    myPSModuleDepFinder = PSModuleDepFinder()
    # happy path, valid input
    assert len(myPSModuleDepFinder.exec_scripts) == 0
    myPSModuleDepFinder.scan_exec_script('Library')
    assert len(myPSModuleDepFinder.exec_scripts) == 1
    assert myPSModuleDepFinder.exec_scripts.get('Library') is not None
    myPSModuleDepFinder.scan_exec_script('Module')
    assert len(myPSModuleDepFinder.exec_scripts) == 2
    assert myPSModuleDepFinder.exec_scripts.get('Module') is not None
    # invalid file name

# Generated at 2022-06-10 23:29:50.147864
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    # TODO 'ansible_collections.system.windows.plugins.module_utils.ansible_free_space' is not yet supported
    assert not instance.scan_exec_script('ansible_collections.system.windows.plugins.module_utils.ansible_free_space')

# Generated at 2022-06-10 23:30:00.371882
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def test_default(name):
        name = to_text(name)
        if name in self.exec_scripts.keys():
            return

        data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
        if data is None:
            raise AnsibleError("Could not find executor powershell script "
                               "for '%s'" % name)

        b_data = to_bytes(data)

        # remove comments to reduce the payload size in the exec wrappers
        if C.DEFAULT_DEBUG:
            exec_script = b_data
        else:
            exec_script = _strip_comments(b_data)
        self.exec_scripts[name] = to_bytes(exec_script)

# Generated at 2022-06-10 23:30:06.432776
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    output = finder.scan_exec_script("script1")
    assert output is None

    # Test that script2 doesn't exist
    output = "ansible.errors.AnsibleError: Could not find executor powershell script for '%s'" % "script2"
    with pytest.raises(AnsibleError, match=output):
        finder.scan_exec_script("script2")


# Generated at 2022-06-10 23:30:17.685220
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:30:22.384015
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    # This has a dependency on TestModuleUtils.psm1
    dep_finder.scan_exec_script('test')
    assert(set(['ansible.module_utils.test_utils']) == set(dep_finder.ps_modules.keys()))

# Generated at 2022-06-10 23:30:37.494031
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    obj.scan_exec_script("test_sample")

# Generated at 2022-06-10 23:30:47.174386
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script() -> None :
    mdfinder = PSModuleDepFinder()
    assert mdfinder.exec_scripts == dict()
    mdfinder.scan_exec_script('Ansible.ArgumentSpec')

# Generated at 2022-06-10 23:30:51.116484
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    suite = unittest.TestSuite()
    suite.addTest(PSModuleDepFinder_scan_exec_script("test_PSModuleDepFinder_scan_exec_script_exec_wrapper_nonexist"))
    return suite


# Generated at 2022-06-10 23:30:59.133184
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    This test case is testing the functionality of the scan_exec_script function.
    The data variable is used to represent the input of the function with a ps script that
    contains an import of another ps module. the function will scan the script and create a 
    dictionary that maps the key to the file path of the module it is referencing.
    """
    data = "#Requires -Module Ansible.ModuleUtils.something"
    finder = PSModuleDepFinder()
    finder.scan_exec_script("something")
    assert finder.exec_scripts == {}
    assert finder.ps_modules == {}

# Generated at 2022-06-10 23:31:00.608777
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd_finder = PSModuleDepFinder()
    psmd_finder.scan_exec_script('win_ping')
    assert "win_ping" in psmd_finder.exec_scripts


# Generated at 2022-06-10 23:31:03.589206
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test = PSModuleDepFinder()
    name = "test_module"
    test.scan_exec_script(name)
    assert name in test.exec_scripts
    assert name in test.ps_modules


# Generated at 2022-06-10 23:31:13.015549
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    tester = PSModuleDepFinder()
    tester.scan_module(b"""using Ansible.Foo;""", fqn=None, wrapper=None, powershell=None)
    tester.scan_module(b"""using ansible_collections.abc.xyz.plugins.module_utils.Bar;""", fqn=None, wrapper=None, powershell=None)
    tester.scan_module(b"""#Requires -Module Ansible.Fizz,""", fqn=None, wrapper=None, powershell=None)
    tester.scan_module(b"""#AnsibleRequires -Powershell Ansible.Buzz,""", fqn=None, wrapper=None, powershell=None)

# Generated at 2022-06-10 23:31:17.677363
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data_failed = None
    data_failed_expect = None
    data_passed = None
    data_passed_expect = None
    expected = None
    name = None
    obj = PSModuleDepFinder()
    # No real test for this method
    pass


# Generated at 2022-06-10 23:31:31.919202
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fixture = PSModuleDepFinder()
    fixture.scan_exec_script(name="basic_ps_wrapper")

# Generated at 2022-06-10 23:31:33.758581
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	PSModuleDepFinder().scan_exec_script("compat")


# Generated at 2022-06-10 23:31:52.481405
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("get_daemon_logs")
    assert finder


# Generated at 2022-06-10 23:32:02.946820
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # 1. Test scan_exec_script when file is found
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('TestUtil')

    # Test that lib/ansible/executor/powershell/TestUtil.ps1 was loaded
    assert(b'$a = 1' in psmdf.exec_scripts['TestUtil'])
    # Test that this module was scanned and added to ps_modules
    assert(len(psmdf.ps_modules) == 1)
    assert(psmdf.ps_modules.keys() == set(['Ansible.ModuleUtils.TestUtil']))
    assert(psmdf.ps_modules['Ansible.ModuleUtils.TestUtil']['data'].startswith(b'# Generated by Ansible'))

   

# Generated at 2022-06-10 23:32:12.344997
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Setup
    module_code = b"#AnsibleRequires -Module Ansible.ModuleUtils.Common"
    fake_module_name = "fake_module_name"
    expected = {fake_module_name: module_code}

    # Execute
    finder = PSModuleDepFinder()
    finder.ps_modules[fake_module_name] = {"data": module_code, "path": "fake_module_path"}
    finder.scan_exec_script("fake_module_name")

    # Assert
    assert finder.exec_scripts == expected

# Generated at 2022-06-10 23:32:19.677777
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # PSModuleDepFinder::scan_exec_script()
    stderr = os.dup(2)
    os.close(2)
    os.open(os.devnull, os.O_RDWR)
    PSModuleDepFinder().scan_exec_script("win_package")
    os.dup2(stderr, 2)
    os.close(stderr)

# Generated at 2022-06-10 23:32:20.966433
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:32:23.378244
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result = PSModuleDepFinder().scan_exec_script('_CommonWrapper')
    assert result is None



# Generated at 2022-06-10 23:32:26.477644
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("test")
    assert finder.exec_scripts["test"]

# Generated at 2022-06-10 23:32:40.261175
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test 1: psm1 file that has no comment with using ansible_collections
    # data = pkgutil.get_data("ansible.executor.powershell", "win_feature.ps1")
    # b_data = to_bytes(data)
    f = open("../lib/ansible/executor/powershell/win_feature.ps1", "rb")
    b_data = f.read()
    f.close()
    test_obj = PSModuleDepFinder()
    test_obj.scan_exec_script("win_feature")
    assert test_obj.exec_scripts == {}
    assert test_obj.cs_utils_wrapper == {"ansible_collections.ansible.builtin.plugins.module_utils.basic": {'data': b_data, 'path': ''}}
    assert test_

# Generated at 2022-06-10 23:32:54.946422
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    class TestModule(object):
        pass

    test_module = TestModule()

    # We are not testing the data of the ansible executor scripts, but we are
    # testing that the module can find and scan the scripts.
    ps_version = "5.1.18362.752"
    scan_req = PSModuleDepFinder()
    scan_req.scan_exec_script("TestUtil")

    # There are already lots of tests that ensure the module deps are
    # correctly added. We will ensure that they are added in the exec_scripts
    # and all the module deps are in the exec_scripts, wrapper_data,
    # and ps_modules.
    assert 'TestUtil.ps1' in scan_req.exec_scripts

    wrapper_data = scan_req.exec_scripts['TestUtil.ps1']