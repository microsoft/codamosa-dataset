

# Generated at 2022-06-10 23:23:48.121499
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        from ansible.executor.powershell.module_utils.module_compat import _get_module_path
    except ImportError:
        _get_module_path = lambda x: x
    try:
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        Mapping = dict

    obj = PSModuleDepFinder()
    obj.scan_exec_script('basic')
    assert obj.exec_scripts.get('basic') is not None
    assert obj.ps_modules.get('Ansible.ModuleUtils.ArgumentCompleter') is not None
    assert obj.ps_modules.get('Ansible.ModuleUtils.ArgumentCompleter').get('data') is not None

# Generated at 2022-06-10 23:23:51.971785
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script(b"asdf")
    print("test_PSModuleDepFinder_scan_exec_script executed successfully")


# Generated at 2022-06-10 23:24:04.984811
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    #module_data = pkgutil.get_data('ansible.module_utils.facts.system', 'hardware.fact')
    #module_data = pkgutil.get_data('ansible.module_utils.facts.system', 'system.fact')
    #module_data = pkgutil.get_data('ansible.module_utils.facts.system', 'distribution.fact')
    #module_data = pkgutil.get_data('ansible.module_utils.facts.hardware', 'systemprofiler.py')
    module_data = pkgutil.get_data('ansible.module_utils.facts.hardware', 'sep.py')

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)


# Generated at 2022-06-10 23:24:09.677742
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_module(b"""#Requires -Module Ansible.ModuleUtils.MyModule""", "MyModule")
    assert(finder.exec_scripts["MyModule"] == b'MyModule_exec_script')


# Generated at 2022-06-10 23:24:15.643893
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("pswrap_ps_linux")
    assert finder.exec_scripts["pswrap_ps_linux"] == _slurp(os.path.join("lib", "ansible", "module_utils", "powershell", "pswrap_ps_linux.ps1"))
    assert finder.ps_modules.keys() == {"Ansible.ModuleUtils.PSModulePath", "Ansible.ModuleUtils.PSUtils", "Ansible.ModuleUtils.PSModuleParser"}
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0


# Generated at 2022-06-10 23:24:30.170588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    psmdf = PSModuleDepFinder()

    def assert_call(mocker, name, data):
        pmfn = "ansible.module_utils.powershell.PSModuleDepFinder._add_module"
        mocker.patch("ansible.module_utils.powershell.PSModuleDepFinder.scan_module", return_value=None)
        mocker.patch("ansible.module_utils.powershell.ps_module_utils_loader.find_plugin", return_value=data)
        mocker.spy(psmdf, "_add_module")

        psmdf.scan_exec_script(name)

        psmdf._add_module.assert_called_once_with("Ansible.ModuleUtils.{}.psm1".format(name), ".psm1", "", False, False)

       

# Generated at 2022-06-10 23:24:40.107362
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible_collections.ns.coll.plugins.module_utils import _text as collection_text
    from ansible.module_utils import _text as core_text

    # test "ns.coll.plugins.module_utils"
    PD = PSModuleDepFinder()
    PD.scan_exec_script('ns.coll.plugins.module_utils.argspec')
    assert ("ns.coll.plugins.module_utils.argspec" in PD.exec_scripts)
    assert ("ns.coll.plugins.module_utils.argspec" in PD.cs_utils_wrapper)
    assert (collection_text in PD.exec_scripts['ns.coll.plugins.module_utils.argspec'])

# Generated at 2022-06-10 23:24:52.000358
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # NoSuchModuleUtilException
    with pytest.raises(AnsibleError):
        finder = PSModuleDepFinder()
        data = to_bytes("#Requires -Module Ansible.ModuleUtils.NoSuchModuleUtil")
        finder.scan_module(data)

    # NoSuchWrapperException
    with pytest.raises(AnsibleError):
        finder = PSModuleDepFinder()
        data = to_bytes("#AnsibleRequires -Wrapper NoSuchWrapper")
        finder.scan_module(data)

    # NoSuchCsUtilImport
    with pytest.raises(AnsibleError):
        finder = PSModuleDepFinder()
        data = to_bytes("using NoSuchCsUtil;")
        finder.scan_module(data, wrapper=True)

# Generated at 2022-06-10 23:25:03.003657
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: is this a unit test? Shouldn't it be an integration test?
    def _test(test_input, test_input2, expected_return, expected_output):
        # Test method scan_exec_script of class PSModuleDepFinder
        test_input = base64.b64decode(test_input)
        test_input2 = base64.b64decode(test_input2)
        expected_return = base64.b64decode(expected_return)
        expected_output = base64.b64decode(expected_output)

        try:
            import ansible.executor.powershell
        except ImportError:
            test_success = None
            msg = "Cannot import ansible.executor.powershell"

# Generated at 2022-06-10 23:25:09.026727
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  # Note that this is a test for a unit, not the class as a whole
  # Also note that the unit under test must be a method (or other callable)
  psModuleDepFinder = PSModuleDepFinder()
  with pytest.raises(AnsibleError):
    psModuleDepFinder.scan_exec_script("unknown")
  # To be extended ...


# Generated at 2022-06-10 23:25:57.210238
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('example')
    assert(len(finder.exec_scripts) == 1)

# Generated at 2022-06-10 23:26:03.473311
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("Copy.ps1")
    assert finder.exec_scripts["Copy.ps1"] == _strip_comments(pkgutil.get_data("ansible.executor.powershell", "Copy.ps1"))
    assert finder.become
# End unit test for method scan_exec_script of class PSModuleDepFinder


# Generated at 2022-06-10 23:26:08.186429
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for method scan_exec_script of class PSModuleDepFinder"""
    # First, create an instance of the class we want to test
    psmdf = PSModuleDepFinder()
    # Assert that calling scan_exec_script() does not raise an exception
    psmdf.scan_exec_script('powershell_base')

# Generated at 2022-06-10 23:26:11.153677
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # initialize
    dep_finder = PSModuleDepFinder()

    # test
    dep_finder.scan_exec_script("powershell.psm1")


# Generated at 2022-06-10 23:26:24.322687
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.loader import powershell_loader
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.powershell.ps_module_utils_loader import PSModuleDepFinder
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.common.parameters import _get_custom_class_or_type
    from ansible.module_utils import basic

    # per module:
    #
    # ps_modules:
    #   module_name: {'path':

# Generated at 2022-06-10 23:26:30.721428
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import_data = "This is the ps1 file data"
    util = PSModuleDepFinder()
    util.scan_exec_script = lambda x: None
    util.scan_module = lambda x: None

    pkgutil.get_data = lambda x, y: import_data
    util.scan_exec_script("test_module")
    assert isinstance(util.exec_scripts["test_module"], bytes)
    assert util.exec_scripts["test_module"] == to_bytes(import_data)

    # Test exception
    util.scan_exec_script("not_a_module")



# Generated at 2022-06-10 23:26:38.942305
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    import inspect

    if sys.version_info < (3, 5, 0):
        print("The unit test requires python 3.5 or higher.")
        sys.exit(0)

    def get_line_number(fqn):
        frame = inspect.stack()[1]
        return frame[2]

    # We are going to fake the ps_module_utils_loader.find_plugin to return the path
    # from within the unit test directory to the same name of the module_util(with .psm1)
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules = dict()
    dep_finder.cs_utils_wrapper = dict()


# Generated at 2022-06-10 23:26:43.221743
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create test class
    item = PSModuleDepFinder()

    # Create test data
    name = "random_name"

    # Test
    ret = item.scan_exec_script(name)

    # Verify results
    assert ret == None



# Generated at 2022-06-10 23:26:46.282988
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = 'foo.py'
    inst = PSModuleDepFinder()
    assert inst.scan_exec_script(name) == None


# Generated at 2022-06-10 23:26:48.213426
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Test')


# Generated at 2022-06-10 23:28:10.687081
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Generate a random name for the script
    script_name = "test_%s" % to_text(base64.urlsafe_b64encode(to_bytes(random.randint(0, 1000000))))
    data = b"#Requires -Module Ansible.ModuleUtils.SomeModule\n" \
           b"#Requires -Version 5.1\n"

    pdf = PSModuleDepFinder()
    pdf.scan_exec_script(script_name)

    # Assert that the script was loaded
    assert script_name in pdf.exec_scripts.keys()
    assert pdf.ps_modules

    # Assert that the script data was loaded
    assert pdf.exec_scripts[script_name] == data

    # Test the comment stripping
    old_debug = C.DEFAULT_DEBUG
    C.DEFAULT_DEBUG

# Generated at 2022-06-10 23:28:21.853100
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_data = """\
    # TestModule.psm1
    #Requires -Module Ansible.ModuleUtils.TestModuleUtils

    #Requires -Version 5.1

    function Get-Test {
    }

    #Requires -Module Ansible.ModuleUtils.AnotherTestModuleUtils

    function Invoke-Test {
    }
    """

    cs_module_data = """\
    // TestModule.cs
    using Ansible.ModuleUtils.TestModuleUtils;

    using ansible_collections.microsoft.windows.plugins.module_utils.PowerShell;
    using System;
    using System.IO;
    """

    expected_ps_modules = dict()
    expected_ps_modules["Ansible.ModuleUtils.TestModuleUtils"] = {'data': None, 'path': None}


# Generated at 2022-06-10 23:28:24.852870
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script('test_exec_script')
    assert False



# Generated at 2022-06-10 23:28:34.679751
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:28:47.354088
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This function currently only tests that the docstring examples work.
    from ansible.module_utils.common.collections import to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_str
    from ansible.module_utils.powershell.payload import PSModuleDepFinder
    ps_module_finder = PSModuleDepFinder()
    print("Running scan_exec_script()...")
    return_value = None
    example_script_name = "test_script.ps1"
    example_script_import = "Ansible.ModuleUtils.Test"
    with open(example_script_name, 'w') as f:
        f.write(example_script_import)

# Generated at 2022-06-10 23:28:52.839502
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup arguments and call function under test
    scan_module_finder = PSModuleDepFinder()
    module_data = _slurp("test/units/module_utils/test_utils.psm1")
    scan_module_finder.scan_module(module_data)

    # Assert
    assert len(scan_module_finder.ps_modules) == 3



# Generated at 2022-06-10 23:28:57.534737
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_util = PSModuleDepFinder()
    ps_module_util.scan_exec_script('../module_utils.ps_archive')
    assert "archive" in ps_module_util.exec_scripts
    assert to_native(ps_module_util.exec_scripts['archive']) == to_native(pkgutil.get_data("ansible.executor.powershell", "archive.ps1"))


# Generated at 2022-06-10 23:29:10.271221
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:19.033935
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import shutil
    import os
    def _get_collection_name():
        random_string = ''.join(random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') for _ in range(8))
        return "test_%s" % random_string
    def create_temp_contents(contents):
        tmp_dir = tempfile.mkdtemp()
        for module_name, module_data in contents.items():
            module_file = os.path.join(tmp_dir, module_name)
            with open(module_file, "wb") as f:
                f.write(to_bytes(module_data))
        return tmp_dir

# Generated at 2022-06-10 23:29:30.606557
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def _slurp(path):
        with open(path, "rb") as f:
            data = f.read()
        return data

    def _strip_comments(data):
        lines = data.split(b'\n')
        stripped_lines = []

        for line in lines:
            line = line.strip()
            if line and not line.startswith(b"#"):
                stripped_lines.append(line)

        return b'\n'.join(stripped_lines)

    def test_scan_exec_script(self):
        self.scan_exec_script("ansible_powershell_script")
        data = pkgutil.get_data("ansible.executor.powershell", "ansible_powershell_script.ps1")
        if C.DEFAULT_DEBUG:
            assert_

# Generated at 2022-06-10 23:31:40.377432
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dep_finder = PSModuleDepFinder()
    ps_dep_finder.scan_exec_script("Ansible.PowerShell.Internal.LocalData")
    assert ps_dep_finder.exec_scripts["Ansible.PowerShell.Internal.LocalData"]


# Generated at 2022-06-10 23:31:49.886786
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
        # Read module data from files
        with open('../test_data/test_module_data/test_ps_module_1.psm1', 'rb') as tm1:
            test_module_1_data = tm1.read()

        with open('../test_data/test_module_data/test_ps_module_2.psm1', 'rb') as tm2:
            test_module_2_data = tm2.read()

        with open('../test_data/test_module_data/test_ps_module_3.psm1', 'rb') as tm3:
            test_module_3_data = tm3.read()

        with open('../test_data/test_module_data/test_cs_module_1.cs', 'rb') as cm1:
            test

# Generated at 2022-06-10 23:31:57.020955
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of the class
    dep_finder = PSModuleDepFinder()
    # call the method with arg 'test_wrap'
    dep_finder.scan_exec_script('test_wrap')
    # assert that the executor script was found
    assert 'test_wrap' in dep_finder.exec_scripts
    assert '.TestModule' in dep_finder.ps_modules


# Generated at 2022-06-10 23:32:05.066079
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dep_finder = PSModuleDepFinder()
    ps_dep_finder.scan_exec_script('basic')

# Generated at 2022-06-10 23:32:05.855993
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:32:06.960416
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert 1 == 2

# Generated at 2022-06-10 23:32:20.899244
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    name = 'module_wrapper'
    data = pkgutil.get_data("ansible.executor.powershell", name + ".ps1")
    b_data = to_bytes(data)

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        exec_script = b_data
    else:
        exec_script = _strip_comments(b_data)

    finder.exec_scripts[name] = to_bytes(exec_script)
    finder.scan_module(b_data, wrapper=True, powershell=True)

    assert finder.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]["data"] is not None

# Generated at 2022-06-10 23:32:28.664499
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # check imports
    mu_lib = os.path.join(C.DEFAULT_MODULE_PATH[0], 'library')
    check_enable_bootstrap = os.path.join(mu_lib, 'check_enable_bootstrap.psm1')
    cs_lib = os.path.join(C.DEFAULT_MODULE_PATH[0], 'community', 'general', 'win_psmodule')
    check_psmodule = os.path.join(cs_lib, 'check_psmodule.cs')
    psutil = os.path.join(C.DEFAULT_MODULE_PATH[0], 'community', 'general', 'win_psmodule', 'module_utils', 'psutil.cs')

    # test check_enable_bootstrap.psm1
    m = PSModuleDepFinder()
    m.scan_

# Generated at 2022-06-10 23:32:41.606278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Read in the file to be parsed
    fd = open('./test/unit/module_utils/test_data/PSModuleDepFinder/TestScanExecScript.ps1')
    file_contents = fd.read()
    fd.close()

    # Instantiate the parser object
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('TestScanExecScript')

    # Create the expected vars
    expected_cs_utils_wrapper = {}
    expected_cs_utils_module = {'Ansible.ModuleUtils.Common': {'data': file_contents.encode('utf-8'), 'path': ':TestScanExecScript.ps1'}}

# Generated at 2022-06-10 23:32:42.298040
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass