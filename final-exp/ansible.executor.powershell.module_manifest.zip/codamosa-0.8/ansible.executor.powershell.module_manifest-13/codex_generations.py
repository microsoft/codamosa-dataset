

# Generated at 2022-06-10 23:23:25.535704
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''TODO:'''
    PSModuleDepFinder()


# Generated at 2022-06-10 23:23:31.870311
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test case for the scan_module method of class PSModuleDepFinder
    # This tests that the scan_module method scans a module for
    # module_utils and pulls them in

    files_to_prepare = ('module_util_scan_module.psm1',)

    fq_paths = []
    for path in files_to_prepare:
        with open(path, 'rb') as f:
            data = f.read()
            # replace the "scan file place holder" with a valid ps1 file
            # so the basic module_util scan works
            data = re.sub(r'\[scan file place holder\]', 'scanned_file.ps1', to_text(data))
            if not os.path.exists(path):
                dir_path = os.path.dirname(path)
               

# Generated at 2022-06-10 23:23:43.801714
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    finder.scan_module('#AnsibleRequires -PowerShell ansible_collections.mydomain.mycollection.plugins.module_utils.my_util')

# Generated at 2022-06-10 23:23:52.561507
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test case 1:
    # Test with the valid script name, Ensure script is added to exec scripts dict
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ElevationManager')
    assert finder.exec_scripts['ElevationManager'] is not None

    # Test case 2:
    # Test exception case, Test with non-existant script name
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('script_not_exist')
    except AnsibleError:
        assert True
    except:
        assert False

    return

# Generated at 2022-06-10 23:23:55.781176
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        s = PSModuleDepFinder()
        assert s.scan_exec_script('Basic/Common') == None
    except ImportError as err:
        print(err)

# Generated at 2022-06-10 23:24:08.822916
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a temporary file with dummy content
    with tempfile.NamedTemporaryFile(mode='w+b', delete=False) as f:
        f.write(b"# AnsibleRequires:-Wrapper asdf")
        f.write(b"# AnsibleRequires:-Wrapper ghjkl")
    expect = {"asdf": "", "ghjkl": ""}
    psmoduledepfinder = PSModuleDepFinder()
    psmoduledepfinder.scan_exec_script(b"asdf")
    psmoduledepfinder.scan_exec_script(b"ghjkl")
    assert sorted(list(psmoduledepfinder.exec_scripts.keys())) == sorted(list(expect.keys()))
    os.unlink(f.name)


# Generated at 2022-06-10 23:24:20.639713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.common.parameters import get_default_argspec

    obj = PSModuleDepFinder()
    obj.cs_utils_wrapper = {}
    obj.cs_utils_module = {}
    obj.ps_modules = {}

    obj.scan_exec_script(name = "ansible_powershell_common")

    obj.scan_exec_script(name = "Get-AnsibleModulesMetadata")

    obj.scan_exec_script(name = "Get-AnsibleTargets")

    obj.scan_exec_script(name = "Get-AnsibleModuleConstant")


# Generated at 2022-06-10 23:24:31.049507
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("Common")

# Generated at 2022-06-10 23:24:40.674444
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    finder = PSModuleDepFinder()
    # this file is always present
    finder.scan_module(pkgutil.get_data("ansible.utils.ps_module_utils", "basic.psm1"))
    assert len(finder.ps_modules) > 0
    assert "Ansible.Basic" in finder.ps_modules
    assert len(finder.cs_utils_module) == 0
    assert len(finder.cs_utils_wrapper) == 0

    # scan a c# util
    finder.scan_module(pkgutil.get_data("ansible.module_utils.basic", "json_preprocess.cs"))
    assert len(finder.cs_utils_module) > 0

# Generated at 2022-06-10 23:24:52.761907
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(
        b'# ansiblerequires -powershell ansible.module_utils.powershell.base_execution_environment'
    )
    assert b'base_execution_environment' in dep_finder.ps_modules
    assert b'base_execution_environment' not in dep_finder.cs_utils_module
    assert b'base_execution_environment' not in dep_finder.cs_utils_wrapper
    assert b'base_execution_environment' not in dep_finder.exec_scripts

    dep_finder.scan_module(
        b'# ansiblerequires -csharputil ansible_collections.netapp.netapp.plugins.module_utils.netapp_module'
    )

# Generated at 2022-06-10 23:25:23.383951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    lib_path = os.path.join(get_test_dir(), 'lib', 'ansible', 'executor', 'powershell')
    if not os.path.exists(lib_path):
        os.makedirs(lib_path)
    file_path = os.path.join(lib_path, 'TestModule.ps1')
    with open(file_path, 'w+') as f:
        f.write('This is the test module')
    md = PSModuleDepFinder()
    md.scan_exec_script('TestModule')
    assert len(md.exec_scripts) == 1
    assert len(md.cs_utils_wrapper) == 0
    assert len(md.ps_modules) == 0



# Generated at 2022-06-10 23:25:28.672072
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_text
    p = PSModuleDepFinder()
    # Some real data
    p.scan_exec_script('modules_common')
    # Some pseudo data
    p.scan_exec_script('my_script')

    assert p.exec_scripts['my_script'] == '#!/usr/bin/env python'


# Generated at 2022-06-10 23:25:41.301872
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()

    # Case 1: scan_module should successfully add the module util
    # Case 2: scan_module should raise error as the module util is not found
    # Case 3: scan_module should successfully add the module util and its dependencies
    # Case 4: scan_module should successfully add the module util and its dependencies which are optional
    # Case 5: scan_module should successfully add the module util and its dependencies which are
    #         within the collection
    # Case 6: scan_module should successfully add the module util and its dependencies. The util
    #         to be added is a C# util

# Generated at 2022-06-10 23:25:43.383720
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert PSModuleDepFinder().scan_module() == "module_utils/module.py"

# Generated at 2022-06-10 23:25:45.984092
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_find = PSModuleDepFinder()
    dep_find.scan_exec_script('Posh-SSH')



# Generated at 2022-06-10 23:25:52.236552
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    depfinder.scan_module(b"using Ansible.ModuleUtil.A; using Ansible.ModuleUtil.B; #Requires -Version 3.4")
    assert depfinder.ps_modules.keys() == {'Ansible.ModuleUtil.A', 'Ansible.ModuleUtil.B'}
    assert depfinder.ps_version == "3.4"


# Generated at 2022-06-10 23:25:55.077239
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    path = ansible.module_utils.powershell.PSModuleDepFinder.scan_exec_script(self, name)
    assert path is not None


# Generated at 2022-06-10 23:25:55.773423
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:26:03.767547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    ansible_module_utils = os.path.join(os.getcwd(), 'lib', 'ansible', 'module_utils')
    sys.path.append(ansible_module_utils)
    if not os.path.isdir(ansible_module_utils):
        raise Exception("{} is not a directory".format(ansible_module_utils))
    test_obj.scan_exec_script("script")
    test_obj.scan_exec_script("script")


# Generated at 2022-06-10 23:26:14.869956
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # this method is meant to be a unit test for class PSModuleDepFinder's method scan_exec_script

    # setup test
    psmd = PSModuleDepFinder()
    dummy_data = 'This is some dummy text'

    # run method under test
    psmd.scan_exec_script('non_existent.ps1')

    # assert result
    assert psmd.exec_scripts == {}

    # setup test
    psmd = PSModuleDepFinder()
    script_name = 'exec_debug.ps1'
    script_path = os.path.join('lib','ansible','executor','powershell',script_name)
    with open(script_path,"r") as exec_script:
        dummy_data = exec_script.read()
    print(dummy_data)

    # run method under

# Generated at 2022-06-10 23:26:26.393812
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:26:27.859538
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Module DepFinder, responsible for finding module and script dependencies

# Generated at 2022-06-10 23:26:37.874122
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class AnsibleExitJson(Exception):

        def __init__(self, obj):
            self.obj = obj


    class AnsibleFailJson(Exception):

        def __init__(self, obj):
            self.obj = obj


    class ModuleMock(object):

        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(kwargs)

        def exit_json(self, *args, **kwargs):
            raise AnsibleExitJson(kwargs)



# Generated at 2022-06-10 23:26:43.061790
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_module_data = '''
    # AnsibleRequires -Wrapper winrm
    '''
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(test_module_data)
    assert 'winrm' in dep_finder.exec_scripts.keys()


# Generated at 2022-06-10 23:26:53.668124
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    # TODO: Add a unit test for method _check_exec_scripts_for_deps in class PSModuleDepFinder
    def test_PSModuleDepFinder_check_exec_scripts_for_deps():
        test_script = "ansible_module_wrapper.ps1"
        module_dep_finder._check_exec_scripts_for_deps(test_script)
        wrapper_name = "ansible_module_wrapper"
        test_script = "ansible_module_instance.ps1"
        module_dep_finder._check_exec_scripts_for_deps(test_script, wrapper_name)
        teardown_wrapper = "ansible_module_wrapper"
        test_script = "ansible_module_wrapper.ps1"
        module

# Generated at 2022-06-10 23:26:54.936298
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  pass


# Generated at 2022-06-10 23:26:55.761140
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:27:07.044080
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Make sure that only C# deps are added when scanning a PowerShell module
    # Make sure that only PowerShell deps are added when scanning a PowerShell module
    # Make sure that only C# deps are added when scanning a C# module
    psmdf = PSModuleDepFinder()
    psmdf.scan_module("#AnsibleRequires -CSharpUtil ansible_collections.my_namespace.my_collection.plugins.module_utils.my_util")
    assert len(psmdf.cs_utils_wrapper) == 1
    assert len(psmdf.cs_utils_module) == 0
    assert len(psmdf.ps_modules) == 0

    psmdf = PSModuleDepFinder()

# Generated at 2022-06-10 23:27:15.050008
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:27:16.680547
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script
    assert 1 == 1


# Generated at 2022-06-10 23:27:31.702198
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    path = pkgutil.get_data('ansible.executor.powershell', "pwsh-exec.ps1")
    assert(PSModuleDepFinder().scan_module(path, wrapper=True, powershell=True))


# Generated at 2022-06-10 23:27:42.441278
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    """
    test_PSModuleDepFinder_scan_exec_script.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 by Joe Fennell.
    :license: Apache 2.0, see LICENSE for more details.
    """
    
    finder = PSModuleDepFinder()
    # Testing with a normal .ps1 file
    finder.scan_exec_script("executor.ps1")
    assert finder.exec_scripts == {"executor": to_bytes(b'# |----------------------------------------------------------------------------------...')}

# Generated at 2022-06-10 23:27:57.238812
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.powershell.common import MISSING_POWERSHELL_MODULES
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(b'ssh')
    assert b'ssh' in psmdf.exec_scripts
    assert b'ansible_collections.ansible.builtin.plugins.module_utils.basic' in psmdf.ps_modules
    assert b'ansible_collections.ansible.builtin.plugins.module_utils.basic' in psmdf.ps_modules
    assert b'ansible_collections.ansible.builtin.plugins.module_utils.common.process' in psmdf.ps_modules

# Generated at 2022-06-10 23:28:00.080715
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test that if no exec_scripts are passed it will return None
    assert PSModuleDepFinder().scan_exec_script(None) == None

# Generated at 2022-06-10 23:28:02.509256
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a nonexisting script
    # Test with an existing script
    # Test that the modules were absolutely required
    pass

# Generated at 2022-06-10 23:28:11.435916
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    params = dict(
        item=dict(
            key1=dict(
                key1a="value",
                key2a=dict(
                    key3a="value"
                )
            ),
            key2="value",
            key3=5,
            key4=True,
            key5=False
        ),
        item2="value2"
    )

    module = AnsibleModule(argument_spec=dict(complex=dict(type='complex'), complex_list=dict(type='complex', elements='dict')))
    module.params = params

    # Inject the imported module into the module_utils namespace so it is visible when we execute the
    # test module
    import ansible.module_utils.compat.module_utils_internal_path

# Generated at 2022-06-10 23:28:23.387673
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test for a error being raised if the file cannot be found
    def test_PSModuleDepFinder_scan_exec_script_file_not_found():
        dep_finder = PSModuleDepFinder()
        with pytest.raises(AnsibleError) as ex:
            dep_finder.scan_exec_script('does-not-exist')
        assert 'Could not find executor powershell script for' in to_native(ex.value)

    def test_PSModuleDepFinder_scan_exec_script_no_requires():
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_exec_script('dummy')
        assert dep_finder.ps_modules == {}
        assert dep_finder.cs_utils_module == {}


# Generated at 2022-06-10 23:28:33.721477
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.ps_modules = dict()
    finder.exec_scripts = dict()
    finder.scan_exec_script("Ansible.ModuleUtils.Legacy")
    assert finder.ps_modules
    assert finder.exec_scripts
    assert finder.ps_modules.keys() == {'Ansible.ModuleUtils.Legacy'}
    assert finder.exec_scripts.keys() == {'Ansible.ModuleUtils.Legacy'}
    assert finder.ps_modules['Ansible.ModuleUtils.Legacy']['path'].endswith('ansible/plugins/module_utils/powershell/Ansible.ModuleUtils.Legacy.psm1')

# Generated at 2022-06-10 23:28:42.673448
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.executor import PowerShellModuleExecutor

    finder = PSModuleDepFinder()
    finder.scan_exec_script("ps_module_utils")

    # The test environment, when no collection is present, will not have any
    # collection-specific module_utils, so we won't find the following
    assert finder.cs_utils_wrapper == {}

    expected_keys = {
        "ps_module_utils",
        "ps_base",
        "ps_utils",
    }
    assert set(finder.ps_modules) == expected_keys


# Generated at 2022-06-10 23:28:53.462540
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # check default
    # create object
    module_finder = PSModuleDepFinder()
    assert isinstance(module_finder, PSModuleDepFinder)
    # This is the only unit test we are able to write for this.
    # If a module_util is able to be used by the test framework and can be
    # loaded, then the unit test will be able to run.  Since module_utils are
    # required by the test framework, things are not so simple.  What we could
    # do is create a fake module_util that does nothing, then use that for
    # testing.
    # TODO(nitzmahone): Write that unit test

# Unit tests for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:18.460679
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test if the function returns the expected results.
    # This function is covered by tests/unit/module_utils/powershell/test_module_deps.py
    pass

# Generated at 2022-06-10 23:29:20.170796
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script('basic')



# Generated at 2022-06-10 23:29:28.761414
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("executor")
    assert "executor" in psmdf.exec_scripts.keys()
    assert (b"Ansible.ModuleUtils.CommonUtils" in psmdf.ps_modules.keys()
            or b"ansible_collections.ansible.builtin.plugins.module_utils.common.common" in psmdf.ps_modules.keys())
    assert psmdf.cs_utils_wrapper == psmdf.cs_utils_module

# Generated at 2022-06-10 23:29:39.351716
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    flake8_checks = []

    ### tests for scan_exec_script method
    # Check whether the scan_exec_script method throws an AnsibleError when no data is provided

    PSModuleDepFinder_object = PSModuleDepFinder()
    try:
        PSModuleDepFinder_object.scan_exec_script(None)
    except AnsibleError as e:
        assert "Could not find executor powershell script" in to_native(e)

    # Check whether the scan_exec_script method throws an AnsibleError when no data is provided

    PSModuleDepFinder_object = PSModuleDepFinder()
    try:
        PSModuleDepFinder_object.scan_exec_script("test")
    except AnsibleError as e:
        assert "Could not find executor powershell script" in to_native(e)




# Generated at 2022-06-10 23:29:41.677572
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    md4 = PSModuleDepFinder()
    md4.scan_exec_script(u"ExecutionWrapper")


# Generated at 2022-06-10 23:29:47.715925
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell_wrapper')

# Generated at 2022-06-10 23:29:58.367302
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.exec_scripts = {'foo': b'module_utils dependency', 'bar': b'more module_utils dependencies'}
    dep_finder.cs_utils_wrapper = {'module_utils': b'', 'module_utils dependency': b''}
    dep_finder.exec_scripts = {'foo': b'', 'bar': b'', 'module_utils dependency': b''}
    dep_finder.scan_module = Mock(return_value=None)
    dep_finder.scan_exec_script('foo')
    dep_finder.scan_module.assert_called_with(b'module_utils dependency', fqn=None, wrapper=True, powershell=True)
    dep_finder.exec_scripts = {'module_utils dependency': b''}


# Generated at 2022-06-10 23:30:05.757067
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    file_name = 'test_file.ps1'
    exec_utils = [
        'exec_util1',
        'exec_util2',
    ]
    module_utils = [
        'module_util1',
        'module_util2',
    ]
    exec_script_data = '\n'.join([
        '#AnsibleRequires -Wrapper %s' % u for u in exec_utils
    ])
    for u in exec_utils:
        exec_script_data = '\n'.join([
            exec_script_data,
            '#AnsibleRequires -Wrapper %s' % u
        ])
        exec_script_data = '\n'.join([
            exec_script_data,
            '#AnsibleRequires -CSharpUtil %s' % u
        ])
       

# Generated at 2022-06-10 23:30:16.833817
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile

    p = PSModuleDepFinder()

    with tempfile.NamedTemporaryFile(delete=False) as foo:
        foo.write(b"#Requires -Module Ansible.ModuleUtils.Foo")
        foo.seek(0)
        p.scan_module(foo.read())

    with tempfile.NamedTemporaryFile(delete=False) as bar:
        bar.write(b"#Requires -Module Ansible.ModuleUtils.Bar")
        bar.seek(0)
        p.scan_module(bar.read())

    # ensure we have both modules listed
    assert len(p.ps_modules) == 2
    assert len(p.cs_utils_wrapper) == 0
    assert len(p.cs_utils_module) == 0

# Generated at 2022-06-10 23:30:28.248876
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #import os
    from ansible.module_utils.powershell.executor import Powershell
    from ansible.module_utils.powershell import (
        ps_version_supported,
        ps_version,
    )
    from ansible.module_utils.compat import os
    if ps_version_supported() and ps_version() >= "5.1.17763.1":
        import pytest
        pytest.skip('FIX THIS PENDING AFAIK')
    # Create a new instance of PSModuleDepFinder
    ps_mod_dep_finder_obj = PSModuleDepFinder()
    # Create a new instance of Powershell
    ps_obj = Powershell()
    # Get the home directory of the user running the tests
    home_dir_path = os.path.expanduser('~')
    # Create a

# Generated at 2022-06-10 23:31:20.799261
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Test case with no #Requires -Module
    finder.scan_module("this is not a module")
    assert len(finder.ps_modules) == 0

    # Test case with #Requires -Module
    finder.scan_module("#Requires -Module Ansible.ModuleUtils.Basic")
    assert len(finder.ps_modules) == 1

    # Test case with #Requires -Module with newlines in front
    finder.scan_module("#Requires -Module Ansible.ModuleUtils.Basic\n#Requires -Module Ansible.ModuleUtils.PoshREST")
    assert len(finder.ps_modules) == 2


# Generated at 2022-06-10 23:31:34.731025
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of PSModuleDepFinder
    instance = PSModuleDepFinder()
    print(instance)
    print(instance.ps_modules)
    print(instance.exec_scripts)
    print(instance.cs_utils_wrapper)
    print(instance.cs_utils_module)
    print(instance.ps_version)
    print(instance.os_version)
    print(instance.become)
    print(instance._re_cs_module)
    print(instance._re_cs_in_ps_module)
    print(instance._re_ps_module)
    print(instance._re_wrapper)
    print(instance._re_ps_version)
    print(instance._re_os_version)
    print(instance._re_become)
    # Test get_ps_module method

# Generated at 2022-06-10 23:31:43.478717
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
    unit testing of scan_module
    '''

# Generated at 2022-06-10 23:31:44.289769
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True == True

# Generated at 2022-06-10 23:31:50.172060
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    from ansible.plugins.test.test_module_utils import TestModuleUtil

    module_data = """
' Test Module

#Requires -Module TestModuleUtil

function test() {{
    Write-Output "Foo!"
}}
"""

    # Create a temporary file for the test module
    fd, t_path = tempfile.mkstemp(suffix=".psm1")
    os.write(fd, to_bytes(module_data))
    os.close(fd)

    # Create a temporary file for the test module_util
    fd, u_path = tempfile.mkstemp(suffix=".psm1")
    os.write(fd, to_bytes(TestModuleUtil.ps1))
    os.close(fd)

    o_deps = PSModuleDepF

# Generated at 2022-06-10 23:31:51.344272
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:32:02.424869
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data = b'#Requires -Module Ansible.ModuleUtils.SomeModule\n#Requires -Module Ansible.ModuleUtils.AnotherModule'

    ps_modules = dict()
    ps_modules["Ansible.ModuleUtils.SomeModule"] = {
        'data': b'SomeData',
        'path': 'path/to/SomeModule.psm1'
    }
    ps_modules["Ansible.ModuleUtils.AnotherModule"] = {
        'data': b'AnotherData',
        'path': 'path/to/AnotherModule.psm1'
    }

    def _add_module(name, ext, fqn, optional):
        m = to_text(name)
        if m == "Ansible.ModuleUtils.SomeModule":
            check_data = b'SomeData'


# Generated at 2022-06-10 23:32:14.436953
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('windows.ps1')
    assert dep_finder.exec_scripts is not None

# Generated at 2022-06-10 23:32:18.147976
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder_obj = PSModuleDepFinder()
    ps_module_dep_finder_obj.scan_exec_script('test_name')

# Generated at 2022-06-10 23:32:27.520791
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def test(module_data, expected, dep=None):
        if dep is None:
            dep = PSModuleDepFinder()

        dep.scan_module(module_data, fqn='testmodule')

        assert dep.ps_modules == expected[0]
        assert dep.cs_utils_wrapper == expected[1]
        assert dep.cs_utils_module == expected[2]
