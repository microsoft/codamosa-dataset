

# Generated at 2022-06-10 23:23:52.573173
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Unit test for method scan_exec_script of class PSModuleDepFinder
    """
    import ansible.executor.powershell

    test_module = PSModuleDepFinder()
    setattr(test_module, "exec_scripts", dict())

    # when name is not in exec_scripts
    name = "mock_name"
    test_module.scan_exec_script(name)
    assert name in test_module.exec_scripts

    # when name is in exec_scripts
    name = "mock_name"
    test_module.scan_exec_script(name)
    assert name in test_module.exec_scripts

    # when name is not in exec_scripts and error
    name = "mock_name2"

# Generated at 2022-06-10 23:23:53.612202
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:24:06.529421
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # ----
    # test_data_1
    # ----
    test_data_1_name = "Test-PSVersion.ps1" # name of the test data

    data = pkgutil.get_data("ansible.executor.powershell", to_native(test_data_1_name))

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        test_data_1 = to_text(data)
    else:
        test_data_1 = to_text(_strip_comments(to_bytes(data)))

    # ----
    # test_data_2
    # ----
    test_data_2_name = "Remove-WmiObject.ps1" # name of the test data


# Generated at 2022-06-10 23:24:10.335917
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import tempfile
    import shutil
    from ansible.module_utils.six.moves import configparser

    PSModuleDepFinder_obj = PSModuleDepFinder()
    PSModuleDepFinder_obj.scan_module("""#Requires -Module Ansible.ModuleUtils.Module.psm1""")
    assert PSModuleDepFinder_obj.ps_modules["Ansible.ModuleUtils.Module.psm1"]


# Generated at 2022-06-10 23:24:17.601802
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    # Test scan_exec_script function
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("basic")
    assert dep_finder.exec_scripts["basic"] == pkgutil.get_data("ansible.executor.powershell","basic.ps1").strip()

if __name__ == '__main__':
    # Unit test for class PSModuleDepFinder
    test_PSModuleDepFinder_scan_exec_script()

# Generated at 2022-06-10 23:24:18.244362
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TBD
    pass


# Generated at 2022-06-10 23:24:24.896225
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    psmdf = PSModuleDepFinder()
    name = 'ansible_powershell_cmdlets'
    
    # Act
    psmdf.scan_exec_script(name)

    # Assert
    assert psmdf.exec_scripts != {}
    assert name in psmdf.exec_scripts



# Generated at 2022-06-10 23:24:30.952913
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    with open("./module_utils/win_package/manifest_module.psm1", 'rb') as f:
        data = f.read()
    finder = PSModuleDepFinder()
    finder.scan_module(data)
    print(finder.ps_modules)



# Generated at 2022-06-10 23:24:40.588689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.module_utils.common.powershell import PSModuleDepFinder
    from ansible.module_utils.common.powershell import PSModuleUtil
    import time

    test_file_name = "test_%s" % time.time()

    # arrange
    test_file = os.path.join(tempfile.gettempdir(), test_file_name)
    test_file_handle = open(test_file, "w")

# Generated at 2022-06-10 23:24:45.686826
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    A test for the scan_exec_script method of class PSModuleDepFinder
    """
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(name=u"MyScript")
    assert u"MyScript" in psmdf.exec_scripts

# Generated at 2022-06-10 23:25:15.730249
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing PSModuleDepFinder.scan_exec_script method
    filename = resource_from_fqcr('ansible_collections/test_namespace/test_collection/plugins/module_utils/ps_module_utils/module.psm1')
    assert os.path.exists(filename)
    with open(filename, "rb") as ps_module_utils_file:
        module_utils = ps_module_utils_file.read()
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_module(module_utils)
    assert 'Ansible.Builtin.Process' in module_dep_finder.ps_modules, \
        "Ansible.Builtin.Process should be available in ps_modules after scan_module()"

# Generated at 2022-06-10 23:25:27.326543
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # loads a plugin and then calls scan_module to parse it for deps
    # parses module_utils and plugins that a given plugin requires
    # wrapper should not be set as we only want to test scan_exec_script
    # no powershell should be set so we don't parse powershell module_utils
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('Ansible.ModuleUtils.Legacy.ScheduledTask')
    assert isinstance(dep_finder.exec_scripts, dict)
    assert isinstance(dep_finder.ps_modules, dict)
    assert not dep_finder.cs_utils_module
    assert not dep_finder.cs_utils_wrapper

# Generated at 2022-06-10 23:25:34.889215
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    for filepath in [f for f in os.listdir(os.path.join(C.DEFAULT_LOCAL_TMP, ".ansible")) if f.endswith(".psm1")]:
        os.remove(os.path.join(C.DEFAULT_LOCAL_TMP, ".ansible", filepath))
    assert psmdf.exec_scripts == dict()
    psmdf.scan_exec_script("test")
    assert len(psmdf.exec_scripts) == 1
    assert psmdf.exec_scripts.keys()[0] == 'test'
    mock_module_data = "ansible_collections.test.test.plugins.module_utils.test"

# Generated at 2022-06-10 23:25:35.611916
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:25:49.147362
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()
    ansible_module_data = "#AnsibleRequires -Module Ansible.ModuleUtils.AnsibleModuleUtil"
    ps_dep_finder.scan_module(to_bytes(ansible_module_data, errors='surrogate_or_strict'))
    assert len(ps_dep_finder.ps_modules) == 2
    assert to_text(list(ps_dep_finder.ps_modules.keys())[0]) == "Ansible.ModuleUtils.AnsibleModuleUtil"
    assert to_text(list(ps_dep_finder.ps_modules.keys())[1]) == "Ansible.ModuleUtils.Common"


# Generated at 2022-06-10 23:25:55.911024
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:25:58.468124
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    module_dep_finder.scan_exec_script('foo')

# Generated at 2022-06-10 23:26:04.928313
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psm = PSModuleDepFinder()

    ansible_modules_path = resource_from_fqcr('ansible_collections.ansible.builtin.plugins.modules')
    if not os.path.exists(ansible_modules_path):
        raise AnsibleError("Could not find builtin module path at %s" % ansible_modules_path)

    module_files = []

    for dirpath, dirnames, filenames in os.walk(ansible_modules_path, topdown=False):
        for filename in filenames:
            if os.path.splitext(filename)[1].lower() == '.psm1':
                module_files.append(os.path.join(dirpath, filename))

    # Randomly select a subset to use.
    random.shuffle(module_files)
    module

# Generated at 2022-06-10 23:26:16.787253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if not os.path.exists(C.DEFAULT_LOCAL_TMP):
        os.makedirs(C.DEFAULT_LOCAL_TMP)
    tmp_fname = os.path.join(C.DEFAULT_LOCAL_TMP, "dep_finder_test.ps1")
    f = open(tmp_fname, 'wb')
    f.close()
    fqn = 'ansible.builtin.test'
    wrapper = False
    powershell = True
    m = PSModuleDepFinder()
    result = m.scan_module(b'\n', tmp_fname, wrapper, powershell)
    assert result is None
    result = m.scan_exec_script('test')
    assert result is None


# Generated at 2022-06-10 23:26:21.236247
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.module_utils.powershell.argspec.powershell_argspec import PSArgSpecParser, PowerShellModuleSpec
    from ansible_test.test_util.testcase import AnsibleTestCase
    from ansible.module_utils.powershell.compat import os_dict
    from ansible.module_utils.powershell.compat import NoSuchFileError

    class AnsibleTestCase_test_PSModuleDepFinder_scan_exec_script(AnsibleTestCase):
        @staticmethod
        def _filter_and_scan(module_path, check, data, base_name=None, fqn=None, wrapper=False, powershell=True):
            if fqn is None:
                fqn = base_name
            # The code we need to test does not expect the data to be a byte string, so we

# Generated at 2022-06-10 23:26:42.956575
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initializing the test object.
    test_object = PSModuleDepFinder()
    assert test_object
    # Executing the method scan_exec_script.
    result = test_object.scan_exec_script("Test Name")
    assert len(result) == 10



# Generated at 2022-06-10 23:26:47.044670
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    dep_finder = PSModuleDepFinder()
    name = 'test'
    dep_finder.scan_exec_script(name)
    assert dep_finder.exec_scripts[name]


# Generated at 2022-06-10 23:26:48.033557
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:26:49.244638
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Test not implemented"


# Generated at 2022-06-10 23:26:56.668354
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Unit test for method scan_exec_script of class PSModuleDepFinder
    """
    from ansible.module_utils.powershell.converter.powershell_script import _strip_comments
    # We are using a sample dummy file for testing

# Generated at 2022-06-10 23:26:57.539586
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:27:00.247149
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("CreateCimSession")


# Generated at 2022-06-10 23:27:01.968976
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass


# Generated at 2022-06-10 23:27:12.428017
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Expect failure for missing module utils
    with pytest.raises(AnsibleError):
        PSModuleDepFinder().scan_module(b'string with missing util',
                                        'ansible_collections.plugin.module_utils.string')

    # Expect success for present builtin module utils
    PSModuleDepFinder().scan_module(b'string with util',
                                    'ansible_collections.ansible.builtin_module_utils.string')

    # Expect success for present collection module utils
    PSModuleDepFinder().scan_module(b'string with util',
                                    'ansible_collections.plugin.module_utils.string')

# Generated at 2022-06-10 23:27:14.757728
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert PSModuleDepFinder().scan_exec_script == 'ansible'



# Generated at 2022-06-10 23:27:32.602804
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:27:36.628351
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('executor')
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 16


# Generated at 2022-06-10 23:27:45.605730
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.version_check import Version

    def test_params():
        return dict(
            name="test_name",
            wrapper=False,
            powershell=True,
        )

    def get_module_data():
        data = u"#Comment"
        data += u"\n" + u"#AnsibleRequires -CSharpUtil ansible_collections.asd.asd.plugins.module_utils.asd"
        data += u"\n" + u"#AnsibleRequires -CSharpUtil asd.asd"
        data += u"\n" + u"#AnsibleRequires -CSharpUtil asd.asd.asd"

# Generated at 2022-06-10 23:27:59.289960
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Set up a library of ps1 scripts we can use when testing
    library = dict()
    with open('test/unit/plugins/modules/windows/ps_module_utils/test_foo.ps1') as f:
        library['test_foo'] = f.read()
    with open('test/unit/plugins/modules/windows/ps_module_utils/test_bar.ps1') as f:
        library['test_bar'] = f.read()


    # Setup some data for C# utils we can use when testing
    cs_library = dict()
    with open('test/unit/plugins/modules/windows/cs_module_utils/GreetingModule.cs') as f:
        cs_library['ansible.module_utils.greeting'] = f.read()

# Generated at 2022-06-10 23:28:09.029156
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test with no Requires (empty)
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#Test')
    assert len(ps_module_dep_finder.ps_modules) == 0
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0

    # test with Requires -Module - single
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#Requires -Module ansible.module_utils.powershell.common\n#Test')

# Generated at 2022-06-10 23:28:19.731989
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    # Now set the finder attributes with proper data
    finder.ps_version = "5.1.18362.145"
    finder.os_version = "10.0.17763.134"
    finder.become = False
    # Valid data to be passed as module_data

# Generated at 2022-06-10 23:28:31.005001
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    # Test scan_module with a PowerShell module
    with open(resource_from_fqcr('ansible_collections.foo.bar', 'plugins', 'modules', 'example.ps1'), 'rb') as f:
        finder.scan_module(f.read())
        assert finder.ps_version == '1.0.0'
        assert finder.os_version == '1.0.0'
        assert set(finder.cs_utils_module.keys()) == {'ansible_collections.foo.bar.plugins.module_utils.cs_util'}
        assert set(finder.cs_utils_wrapper.keys()) == {'ansible_collections.foo.bar.plugins.module_utils.cs_util'}

# Generated at 2022-06-10 23:28:33.832429
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("in test_PSModuleDepFinder_scan_exec_script")
    obj = PSModuleDepFinder()
    obj.scan_exec_script("powershell_executor")


# Generated at 2022-06-10 23:28:46.137926
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    import os.path
    import sys
    import tempfile
    import textwrap

    # noinspection PyUnresolvedReferences
    import pytest

    from units.compat.mock import MagicMock, mock_open, patch
    from ansible.module_utils._text import to_bytes

    from ansible.plugins.loader import ps_module_utils_loader

    def _slurp(module_path):
        with open(to_native(module_path), 'rb') as module_file:
            module_data = module_file.read()
        return module_data

    # This is based off of Ansible.ModuleUtils.Facts.AnsibleFacts.

# Generated at 2022-06-10 23:28:49.232491
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    name = 'check_powershell'
    module_dep_finder.scan_exec_script(name)

# Generated at 2022-06-10 23:29:08.736194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(b"test_exec_script")
    # Assert here ...


# Generated at 2022-06-10 23:29:12.556682
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('Common')
    assert 'Common' in finder.exec_scripts
    assert 'ansible.executor.powershell.Common.ps1' in finder.exec_scripts['Common']


# Generated at 2022-06-10 23:29:20.568773
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:32.260430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    # Import errno to use for mocking OSError
    import errno
    # Import builtins for mocking open for reading module_util data
    import builtins
    # Import os to check if the module_util data is read from the file
    import os
    # Import os.path to check if the module_util data is read from the file
    import os.path
    PSModuleDepFinder_instance = PSModuleDepFinder()

    # Path to the powershell module_util, this is where the ansible_collections.ansible.builtin.plugins.module_utils
    # is present

# Generated at 2022-06-10 23:29:36.313081
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    finder = PSModuleDepFinder()
    finder.scan_exec_script("win_command.ps1")

#Unit test for the private method _add_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:45.203930
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", to_native("posh-vmware.ps1"))
    if data is None:
        raise AnsibleError("Could not find executor powershell script "
                           "for 'posh-vmware'")

    b_data = to_bytes(data)

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        exec_script = b_data
    else:
        exec_script = _strip_comments(b_data)
    #self.exec_scripts[name] = to_bytes(exec_script)
    print(len(b_data))
    print(len(exec_script))

# Generated at 2022-06-10 23:29:56.154973
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Required imports for testing
    from ansible.module_utils import basic

    # Create PSModuleDepFinder object
    obj = PSModuleDepFinder()

    # Create a random module name
    module_name = ''.join(random.choice('ABCD') for _ in range(20)) + ".psm1"

    # Create a dummy module data
    module_data = "#Requires -Module ansible.module_utils.basic".encode('utf-8')

    # Scan the dummy module data
    obj.scan_module(module_data, module_name, wrapper=False, powershell=True)

    # Check if the module was fetched by the scan_module method
    if not 'ansible.module_utils.basic' in obj.ps_modules.keys():
        raise AssertionError('Failed to scan the dummy module data')



# Generated at 2022-06-10 23:29:57.177180
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:30:02.123345
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = pkgutil.get_data("ansible.executor.powershell", "ansible_module_test_module.ps1")
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 3
    assert finder.become is False
    assert finder.ps_version is None
    assert finder.os_version is None


# Generated at 2022-06-10 23:30:08.018280
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create a PSModuleDepFinder object for unit testing
    ps_module_dep_finder = PSModuleDepFinder()
    # a script to use in the unit test
    script = \
"""function Get-Test {
    "hello world"
}

function Invoke-Test {
    return $PSItem
}

function Invoke-Test2 {
    return Get-Test
}
"""
    # a script to use in the unit test
    script2 = \
"""function Get-Test2 {
    "hello world 2"
}

function Invoke-Test3 {
    return $PSItem
}

function Invoke-Test4 {
    return Get-Test
}
"""
    # a script to use in the unit test

# Generated at 2022-06-10 23:30:33.261622
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.urllib.parse import urlparse, quote, urlsplit, urlunsplit
    from ansible.module_utils.six.moves.urllib.request import url2pathname
    from ansible.module_utils.urls import open_url, url_argument_spec

    valid_names

# Generated at 2022-06-10 23:30:37.438695
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    FQCR = 'ansible_collections.namespace.collection.plugins.modules.module'
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('posh-vault')


# Generated at 2022-06-10 23:30:38.077508
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:30:43.774200
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test method scan_exec_script of class PSModuleDepFinder.

    Args:
        self: (object) PSModuleDepFinder
        name: (string)
    """
    try:
        # Scan for the exec script for a powershell module
        assert True == False
    except Exception as e:
        # Raise the exception if any encountered
        raise


# Generated at 2022-06-10 23:30:50.545870
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a valid script name
    module_dep_finder = PSModuleDepFinder()
    powershell_script_name = "execution.ps1"
    result = module_dep_finder.scan_exec_script(powershell_script_name)
    assert result == None
    assert module_dep_finder.exec_scripts.get(powershell_script_name) != None


# Generated at 2022-06-10 23:30:52.752668
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("powershell_base")



# Generated at 2022-06-10 23:31:00.559744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test 1
    x = PSModuleDepFinder()
    x.scan_exec_script("Awin_Module")
    assert isinstance(x.exec_scripts, dict)
    assert len(x.exec_scripts) >= 1
    assert x.exec_scripts["Awin_Module"].startswith(to_bytes("#"))

    # Test 2
    # Non Existing Exec Script
    try:
        x.scan_exec_script("Non_Exist_Script")
    except AnsibleError:
        pass
    else:
        assert False, "Did not expect AnsibleError to be raised"



# Generated at 2022-06-10 23:31:07.963289
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    with open(os.path.join(os.path.dirname(__file__), "data", "module_utils", "basic.psm1"), "rb") as f:
        finder.scan_module(f.read())
    assert "Ansible.ModuleUtils.BasicModuleUtil" in finder.ps_modules
    assert finder.ps_modules["Ansible.ModuleUtils.BasicModuleUtil"]["data"].startswith(b"function foo {")
    with open(os.path.join(os.path.dirname(__file__), "data", "module_utils", "test.psm1"), "rb") as f:
        finder.scan_module(f.read())

# Generated at 2022-06-10 23:31:09.797145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    name = "test"
    obj.scan_exec_script(name)


# Generated at 2022-06-10 23:31:16.213164
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    text = '''
#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.Cloud.Azure.Powershell.NetApp;
#Requires -Version 7.1

#Requires -Module Ansible.ModuleUtils.PKI;


#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.Cloud.Azure.Powershell.Common;

#Requires -Module Ansible.ModuleUtils.Powershell.Management;

#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.Cloud.Azure.Powershell.Common;
'''


# Generated at 2022-06-10 23:31:34.421865
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Does nothing!
    pass


# Generated at 2022-06-10 23:31:36.881040
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test scan_exec_script of class PSModuleDepFinder
        :param module_data: The data of the module to parse for the C# util references
        :returns: A data structure containing the found references
    """
    pass


# Generated at 2022-06-10 23:31:45.515028
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:31:57.965362
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell')

# Generated at 2022-06-10 23:32:02.320253
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test when data is None
    module_dep_finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError) as execinfo:
        module_dep_finder.scan_exec_script("DummyName")
    assert 'Could not find executor powershell script for' in str(execinfo.value)


# Generated at 2022-06-10 23:32:03.292167
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert None

# Generated at 2022-06-10 23:32:15.424867
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_mdf = PSModuleDepFinder()
    ps_mdf.scan_exec_script("get_powershell_version")
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.get_powershell_version' in ps_mdf.ps_modules
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.os_windows' in ps_mdf.ps_modules
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.get_powershell_version' in ps_mdf.cs_utils_module
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.os_windows' in ps_mdf.cs_utils_module

# Generated at 2022-06-10 23:32:24.673993
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:32:38.664447
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.params['with_cs'] = False
            self.params['with_ps'] = False
            self.params['with_become'] = False
            self.params['with_os_version'] = False
            self.params['with_ps_version'] = False
            self.params['with_version'] = False
            self.params['with_ps_version_no_match'] = False


        def fail_json(self, msg):
            self.msg = msg

        def exit_json(self, **kwargs):
            self.params.update(kwargs)



# Generated at 2022-06-10 23:32:48.591607
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils import six
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collection_loader import read_module_utils

    data = """# A comment
#AnsibleRequires -Wrapper Foo
# Another comment
#Requires -Module Ansible.ModuleUtils.Test
"""

    obj = PSModuleDepFinder()
    obj.scan_module(to_bytes(data, errors='surrogate_or_strict'), fqn=to_text('', errors='surrogate_or_strict'), wrapper=True, powershell=True)