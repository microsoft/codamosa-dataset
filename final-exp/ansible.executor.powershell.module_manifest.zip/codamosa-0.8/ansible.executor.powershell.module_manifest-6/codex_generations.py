

# Generated at 2022-06-10 23:23:43.019404
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    name = 'moduletest'
    ext = '.psm1'
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../fixtures', name + ext)
    module_data = _slurp(file_path)
    finder.scan_module(module_data, fqn=name, wrapper=False)
    assert(name in finder.ps_modules)
    assert(len(finder.ps_modules) == 2)
    assert('Ansible.ModuleUtils.ArgumentSpec' in finder.ps_modules)
    assert(finder.ps_version == "5.0.1024.18392")
    assert(finder.os_version == "10.0.17134")

# Generated at 2022-06-10 23:23:46.863283
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('basic')
    assert ps_module_dep_finder.exec_scripts['basic'] is not None


# Generated at 2022-06-10 23:23:56.513966
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    if not unittest.case.skipUnless(pkgutil, "pkgutil must be available to run this test"):
        module_utils = PSModuleDepFinder()
        test_script = " Powershell script without extension"
        with patch.object(pkgutil, "get_data") as patched_get_data:
            patched_get_data.return_value = test_script
            with patch.object(PSModuleDepFinder, "scan_module") as patched_scan_module:
                patched_scan_module.return_value = None

# Generated at 2022-06-10 23:24:02.093985
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    from six import PY3
    from ansible.module_utils.six.moves.urllib.request import urlopen
    import tempfile

    assert PY3


# Generated at 2022-06-10 23:24:08.764087
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_arg_data = pkgutil.get_data("ansible.executor.powershell", "test_arg_data.ps1")
    test_arg_data = to_text(test_arg_data)
    t = PSModuleDepFinder()
    t.scan_exec_script("test_arg_data")
    assert t.exec_scripts['test_arg_data'] == test_arg_data


# Generated at 2022-06-10 23:24:12.979037
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor import powershell
    name = "TestPSModuleDepFinder"
    p = PSModuleDepFinder()
    p.scan_exec_script(name)
    assert(name in p.exec_scripts)



# Generated at 2022-06-10 23:24:23.533449
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:24:36.137296
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()
    m = pkgutil.get_data("ansible.plugins.modules", "script.ps1").decode("utf-8")
    mdf.scan_module(m)
    assert mdf.ps_modules["Ansible.ModuleUtils.CommonUtils"]["data"][:4] == "#COMM"
    assert mdf.ps_modules["Ansible.ModuleUtils.Powershell.Convert"]["data"][:4] == "#COMM"
    mdf.scan_module(m, fqn="test.test", wrapper=True)
    assert mdf.cs_utils_wrapper["test.test.test.test"]["data"][:4] == "/// "

# Generated at 2022-06-10 23:24:49.374728
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This tests the scan_exec_script method of class PSModuleDepFinder
    random_number = random.randint(10000000, 99999999)
    random_number_string = str(random_number)

    # Create a PSModuleDepFinder instance
    obj = PSModuleDepFinder()

    # It should fail without a name
    try:
        obj.scan_exec_script(None)
        assert 0, "An exception should have been thrown"
    except AnsibleError:
        pass

    # It should fail with an empty name
    try:
        obj.scan_exec_script('')
        assert 0, "An exception should have been thrown"
    except AnsibleError:
        pass

    # It should fail with a non-existing name

# Generated at 2022-06-10 23:25:00.996820
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import sys
    import unittest
    import munch
    # pylint: disable=import-error
    from ansible.module_utils.common.text.formatters import (
        bytes_to_human,
    )

    class FakeModule:
        def __init__(self):
            self.params = {}

    class FakeHost:
        def __init__(self):
            self.name = "localhost"
            self.vars = munch.Munch({"ansible_connection": "local"})

        def get_vars(self):
            return self.vars

    class FakeTask:
        def __init__(self):
            self.name = "fake_task"
            self.action = "fake_action"


# Generated at 2022-06-10 23:25:47.731026
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.powershell.wrapper import create_powershell_wrapper

    random_value = random.randint(0, 0xffff)

    # Generate test module
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Generate test util
    util = """
    #Requires -Version {vers}
    Get-Item $env:PSModulePath
    """.format(vers=str((random_value + 1) / 2))
    mu_path = 'test_module_utils.psm1'
    util_file = open(to_bytes(mu_path), 'wb')
    util_file.write(to_bytes(util))
    util_file.flush()
    util_file.close()

    # Generate

# Generated at 2022-06-10 23:25:58.889143
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import types
    import unittest

    class FakeModuleFinder:
        def __init__(self):
            self.ps_modules = {
                'Ansible.Builtin.Test1': 'builtin',
                'Ansible.Builtin.Test2': 'builtin',
                'collections.ns.coll.Test1': 'collection',
                'collections.ns.coll.Test2': 'collection',
            }
            self.cs_utils_wrapper = {
                'Ansible.Builtin.Test1': 'builtin',
                'Ansible.Builtin.Test2': 'builtin',
                'collections.ns.coll.Test1': 'collection',
                'collections.ns.coll.Test2': 'collection',
            }

# Generated at 2022-06-10 23:26:10.275389
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    ps_module_data = '''
#Requires -Module Ansible.ModuleUtils.CommonUtils
#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Module Ansible.ModuleUtils.Powershell
#AnsibleRequires -PowerShell Ansible.ModuleUtils.AnotherOne
#AnsibleRequires -CSharpUtil ansible_collections.test.test_collection.plugins.module_utils.CSharpUtil
#AnsibleRequires -CSharpUtil ..module_utils.CSharpUtil2

#Requires -Version 6.0
#AnsibleRequires -OSVersion 5.2
'''
    depfinder.scan_module(ps_module_data)
    assert len(depfinder.ps_modules) == 4

# Generated at 2022-06-10 23:26:23.537708
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    submodules = [
        (to_text('Test_Module'), to_text('')),
    ]
    m = PSModuleDepFinder()
    module_data = pkgutil.get_data("ansible.modules.windows.test.test_module_loader", to_text("Test_Module.psm1"))
    m.scan_module(module_data, submodules)
    assert(len(m.ps_modules.keys()) == 1)

    # Test C# in PS module
    submodules = [
        (to_text('Test_Module'), to_text('')),
    ]
    m = PSModuleDepFinder()
    module_data = pkgutil.get_data("ansible.modules.windows.test.test_module_loader", to_text("Test_Module_CSharp.psm1"))
   

# Generated at 2022-06-10 23:26:26.512027
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create the object with secret keys
    depfinder = PSModuleDepFinder()
    # The following values will be used to test the method
    name = 'Not-None'
    depfinder.scan_exec_script(name)



# Generated at 2022-06-10 23:26:37.223500
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    samples = [
        {'input': 'ansible.executor.powershell.implicit_remoting'},
        {'input': 'ansible.executor.powershell.native'},
        {'input': 'ansible.executor.powershell.psexec'},
        {'input': 'ansible.executor.powershell.winrm'}
    ]
    for sample in samples:
        import sys
        import ctypes
        from ansible.module_utils import powershell

        #Python 2
        if sys.version_info < (3,):
            import imp
            f, pathname, description = imp.find_module('ansible.executor.powershell.%s' % sample['input'])

# Generated at 2022-06-10 23:26:42.152468
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''Test scan_exec_script method of class PSModuleDepFinder'''
    ps_module_finder = PSModuleDepFinder()
    ps = ps_module_finder.scan_exec_script('common')
    assert isinstance(ps, dict)


# Generated at 2022-06-10 23:26:53.051400
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(b'''#Requires -Module Ansible.ModuleUtils.TestModuleUtil
#Requires -Module Ansible.ModuleUtils.OtherModuleUtil
#Requires -Module Ansible.ModuleUtils.OtherModuleUtil2
''')
    assert md.ps_modules['Ansible.ModuleUtils.TestModuleUtil']
    assert md.ps_modules['Ansible.ModuleUtils.OtherModuleUtil']
    assert md.ps_modules['Ansible.ModuleUtils.OtherModuleUtil2']
    assert len(md.ps_modules) == 3

    md = PSModuleDepFinder()

# Generated at 2022-06-10 23:26:58.732929
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # 1. Create instance of class PSModuleDepFinder
    # 2. Call function scan_exec_script with valid arguments and observe output (if any)
    finder = PSModuleDepFinder()

    script_name = "script_1"
    finder.scan_exec_script(script_name)

    assert len(finder.exec_scripts) == 1
    assert script_name in finder.exec_scripts.keys()


# Generated at 2022-06-10 23:27:12.061461
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: These tests need to move to the test/units/plugins/modules/test_module_utils/test_powershell.py to use
    # TODO: the mock modules and test the data of the module_utils as well.
    finder = PSModuleDepFinder()

    # Use a random string to test the regex
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    data = to_bytes("#AnsibleRequires -PowerShell Ansible.ModuleUtils.{}\n".format(random_string))
    finder.scan_module(data)
    assert finder.ps_modules.keys() == set([random_string])

    # Test with no module_utils

# Generated at 2022-06-10 23:27:27.105835
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    scanner = PSModuleDepFinder()
    scanner.scan_module(b"#Requires -Module Ansible.ModuleUtils.Test")
    assert scanner.ps_modules['Ansible.ModuleUtils.Test'] == {
        'data': b'Test',
        'path': 'ansible\module_utils\Test.psm1'
    }


# Generated at 2022-06-10 23:27:28.663531
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: mock to_text and _slurp
    pass

# Generated at 2022-06-10 23:27:33.031281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    text = '<?xml version="1.0" encoding="utf-8"?><configuration><appSettings><add key="MyKey" value="MyValue"/></appSettings></configuration>'
    assert text == '<?xml version="1.0" encoding="utf-8"?><configuration><appSettings><add key="MyKey" value="MyValue"/></appSettings></configuration>'

test_PSModuleDepFinder_scan_exec_script()

# Generated at 2022-06-10 23:27:43.619020
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:27:50.739997
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    name = "../testdata/executor/powershell/dummy_script.ps1"
    finder.scan_exec_script(name)

    assert "Hello World" in finder.exec_scripts[name].decode("utf-8")


# Function to read contents of a file to a string

# Generated at 2022-06-10 23:28:01.113232
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_name = "exec_script_check"
    test_cases = []

    # This is the first test case in the method. The first test case is always
    # also a 'boundary case', meaning, it tests an edge case or an extreme case
    # that could cause issues, like a negative input or a null.
    test_case = {}
    test_case["test_name"] = test_name
    test_case["input"] = {
    }
    test_case["exception"] = AnsibleError
    test_case["exception_message"] = "Could not find executor powershell script for \'csharpwrapper\'"
    test_cases.append(test_case)

    # Now we add some 'normal cases', this could for example be testing a loop
    # with many iterations, or other normal cases
    test_case = {}

# Generated at 2022-06-10 23:28:10.640882
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ansible_executor_powershell = pkgutil.get_loader('ansible.executor.powershell')
    # AnsibleExecutor powershell package available in script path
    if ansible_executor_powershell is None:
        raise ImportError('could not import package ansible.executor.powershell')
    # initialize the object
    ps_mod_dep_finder = PSModuleDepFinder()
    # ps_mod_dep_finder.scan_exec_script will scan lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    ps_mod_dep_finder.scan_exec_script('Basic')
    assert len(ps_mod_dep_finder.exec_scripts) == 1

# Generated at 2022-06-10 23:28:13.551534
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()
    mu.scan_exec_script("test")
    assert "test" in mu.exec_scripts
    assert "test" in mu.ps_modules


# Generated at 2022-06-10 23:28:25.831059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    from ansible.module_utils.six import StringIO

    # Set up temporary directory for use in scan_module.
    module_tmp_dir = tempfile.mkdtemp()

    # Create temporary files for testing
    for filename in ("test_module_1.py", "test_module_2.py"):
        # Create a temporary file
        with tempfile.NamedTemporaryFile(mode='w', dir=module_tmp_dir, delete=False) as temp_file:
            # Create a file handle to be used with the temporary file
            temp_fp = open(temp_file.name, 'w')
            if 'test_module_1.py' in filename:
                temp_fp.write("#!/usr/bin/python\n\n")
                temp_fp.write("try:\n")
               

# Generated at 2022-06-10 23:28:30.271266
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    ps_find_bin = get_bin_path('powershell')
    if ps_find_bin is None:
        raise AssertionError("Could not find powershell.exe")

    # normal case is the powershell module, but we need to make sure unit tests
    # can execute this without a random module name

# Generated at 2022-06-10 23:28:44.304471
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:28:55.432784
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class mock_pkgutil:
        @staticmethod
        def get_data(package, resource):
            if package == "ansible.executor.powershell" and resource == "test.ps1":
                return b"#Requires -Module Ansible.ModuleUtils.Other\n#AnsibleRequires -CSharpUtil Ansible.Other\n"

    orig_pkgutil_get_data = pkgutil.get_data
    pkgutil.get_data = mock_pkgutil.get_data

    def cleanup():
        pkgutil.get_data = orig_pkgutil_get_data

    this_module = sys.modules[__name__]
    orig_depfinder = getattr(this_module, "PSModuleDepFinder")

    depfinder = PSModuleDepFinder()

# Generated at 2022-06-10 23:28:59.609660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    finder.scan_module('# ansiblerequires -wrapper example')
    # assert finder.exec_scripts == {'example', to_bytes('#Requires -Module Ansible.ModuleUtils.PSCore;\n')}

    finder.scan_module('# ansiblerequires -wrapper example')
    # assert finder.exec_scripts == {'example', to_bytes('#Requires -Module Ansible.ModuleUtils.PSCore;\n')}



# Generated at 2022-06-10 23:29:05.368789
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #
    c = PSModuleDepFinder()
    c.scan_exec_script('pwsh_invocation')
    assert c.cs_utils_wrapper == {'Ansible.ModuleUtils.Common': {'data': b'cls code to be tested', 'path': 'file/path'}}

# Generated at 2022-06-10 23:29:12.170576
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    p = PSModuleDepFinder()

    module_util_file = "../../lib/ansible/module_utils/facts/system/windows/dotnet.psm1"
    with open(module_util_file, 'rb') as f:
        module_util = f.read()
    p.scan_module(module_util)
    assert p.ps_modules["Ansible.ModuleUtils.Facts.System.Windows.DotNet"]


# Generated at 2022-06-10 23:29:19.550204
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    # http://docs.pytest.org/en/latest/example/parametrize.html
    param_list = [
        ("ansible.module_utils.basic", False),
        ("ansible.module_utils.six", True),
        ("ansible.module_utils.network.common.utils", False),
        ("ansible.module_utils.network.common.utils2", True),
    ]
    for input in param_list:
        try:
            f.scan_exec_script(input[0])
            if input[1]:
                assert False
        except Exception as e:
            if not input[1]:
                assert False


# Generated at 2022-06-10 23:29:23.286770
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("NewExecScript")

    assert "NewExecScript" in ps_module_dep_finder.exec_scripts


# Generated at 2022-06-10 23:29:26.056929
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Create a mock file and see that the method scans it
    pass


# Generated at 2022-06-10 23:29:27.139594
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:29:33.270566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(name="basic")
    assert(len(finder.exec_scripts) == 1)
    assert(len(finder.ps_modules) == 0)
    assert(len(finder.cs_utils_wrapper) == 0)
    assert(finder.ps_version is None)
    assert(finder.os_version is None)
    assert(finder.become is False)

# Generated at 2022-06-10 23:29:56.480342
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import os
    import json
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-10 23:30:03.628371
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('common')

    assert 'common' in ps_module_dep_finder.exec_scripts.keys()
    assert 'skeleton' in ps_module_dep_finder.exec_scripts.keys()

    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.common' in ps_module_dep_finder.ps_modules.keys()
    assert 'ansible_collections.ansible.builtin.plugins.module_utils.powershell.skeleton' in ps_module_dep_finder.ps_modules.keys()

# Generated at 2022-06-10 23:30:07.876049
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("TestModuleExecScript")
    psmdf.scan_exec_script("TestModuleExecScript")
    assert psmdf.exec_scripts["TestModuleExecScript"] == to_bytes("This is a test script")


# Generated at 2022-06-10 23:30:19.223627
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    tmp_test_file = '/tmp/tmp_test_PSModuleDepFinder.txt'
    tmp_test_file_b = to_bytes(tmp_test_file)
    import os
    if os.path.exists(tmp_test_file_b):
        os.remove(tmp_test_file_b)

    # test scan_exec_script() function
    from ansible.plugins.loader import powershell_loader
    depfinder = PSModuleDepFinder()
    powershell_loader.get_powershell_script(depfinder.scan_exec_script, 'ConvertTo-JSON')
    assert depfinder.exec_scripts['ConvertTo-JSON']

    # test scan_exec_script() function with a bad name
    depfinder = PSModuleDepFinder()

# Generated at 2022-06-10 23:30:23.529328
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test execution when object is not instantiated
    with pytest.raises(NameError):
        # Test execution when the object is not instantiated
        # We expect a NameError to be raised as the object is not created
        result = exec_script('name')


# Generated at 2022-06-10 23:30:24.639614
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test not implemented
    pass


# Generated at 2022-06-10 23:30:33.263246
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test_scan_module() with existent module
    module_data = b'#Requires -Module Ansible.ModuleUtils.Test;\n'
    mu_data = b"# Empty data to test if mu_data is used"
    mu_path = "Ansible.ModuleUtils.Test"
    ps_module_utils_loader.ps_module_utils = {mu_path: {"data": mu_data, "path": None}}
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data)
    assert to_text(ps_module_dep_finder.ps_modules[to_text(mu_path)]["data"]) == to_text(mu_data)

    # test_scan_module() with non-existent module
    module_

# Generated at 2022-06-10 23:30:44.329344
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:30:51.241732
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test the scan_module method of the PSModuleDepFinder class.
    test_file_path = '/path/to/non-existent/file.ps1'
    string_data = ''
    test_scan_module_class = PSModuleDepFinder()
    # This method is not available on the PSModuleDepFinder class.
    test_scan_module_class.scan_module(string_data, test_file_path)



# Generated at 2022-06-10 23:31:01.332965
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    import os
    import re

    test_name = "ansible.module_utils.basic"
    test_path = os.path.join(os.path.dirname(__file__), test_name+".psm1")
    test_data = _slurp(test_path)
    pdmf = PSModuleDepFinder()

    # before we scan, there should be no utils
    assert pdmf.ps_modules == {}
    assert pdmf.cs_utils_wrapper == {}
    assert pdmf.cs_utils_module == {}
    assert pdmf.exec_scripts == {}

    pdmf.scan_module(test_data)

    # ensure that the basic module has the required modules

# Generated at 2022-06-10 23:31:26.521999
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup mock AnsibleModule
    class AnsibleModuleMock:
        class AnsibleModuleExit:
            pass
    ansible_module = AnsibleModuleMock
    # setup mock ps_module_dep_finder
    class PSModuleDepFinderMock:
        def scan_module(self, module_data, fqn=None, wrapper=True, powershell=True):
            pass
    ps_module_dep_finder = PSModuleDepFinderMock()
    ps_module_dep_finder.exec_scripts = dict()
    # setup mock pkgutil
    class pkgutilMock:
        class get_dataMock:
            pass
        get_data = get_dataMock
    pkgutil = pkgutilMock()
    # setup mock os

# Generated at 2022-06-10 23:31:31.784450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_md_finder = PSModuleDepFinder()
    file_name = 'winrm.ps1'
    ps_md_finder.scan_exec_script(file_name)
    assert file_name in ps_md_finder.exec_scripts.keys()

# Generated at 2022-06-10 23:31:37.536603
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell import _to_bytes
    dep_finder = PSModuleDepFinder()
    random_number = random.randrange(0, 100)
    dep_finder.scan_exec_script("get_current_powershell_version")
    assert "get_current_powershell_version" in dep_finder.exec_scripts
    assert "\n" == _to_bytes("\n")
    assert len(dep_finder.exec_scripts["get_current_powershell_version"].split(b"\n")) == random_number




# Generated at 2022-06-10 23:31:40.633352
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('my_exec_script')
    assert dep_finder.exec_scripts['my_exec_script'] == b'my_exec_script contents'



# Generated at 2022-06-10 23:31:42.212859
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    scanner = PSModuleDepFinder()
    scanner.scan_exec_script('script')



# Generated at 2022-06-10 23:31:48.632170
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    assert dep_finder.exec_scripts == dict()
    dep_finder.scan_exec_script("powershell_common")
    assert len(dep_finder.exec_scripts) == 1
    dep_finder.scan_exec_script("powershell_common")
    assert len(dep_finder.exec_scripts) == 1
    dep_finder.scan_exec_script("powershell_pscopy")
    assert len(dep_finder.exec_scripts) == 2


# Generated at 2022-06-10 23:31:53.226154
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pf = PSModuleDepFinder()
    name = "bogus"
    result = pf.scan_exec_script(name)
    assert result is None, "Expected None from scan_exec_script()"


# Generated at 2022-06-10 23:31:57.292718
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # instantiate the class
    p = PSModuleDepFinder()
    # call method to test
    p.scan_exec_script(name='powershell_wrapper')
    print(p.ps_modules)


# Generated at 2022-06-10 23:32:05.212430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # This should fail as the Invalid module is not a valid module in
    # 'lib/ansible/executor/powershell
    try:
        finder.scan_exec_script("Invalid")
        assert False, "Expected failure as Invalid is not a valid script"
    except AnsibleError:
        pass

    finder.scan_exec_script("AnsiblePsWrapper")
    assert finder.exec_scripts["AnsiblePsWrapper"] is not None
    assert "Ansible.ModuleUtils.CommonUtils" in finder.ps_modules
    assert "Ansible.ModuleUtils.ProcessCommon" in finder.ps_modules
    assert "Ansible.ModuleUtils.Powershell" in finder.ps_modules



# Generated at 2022-06-10 23:32:18.810751
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test case values
    to_bytes = lambda x: x
    ps_module_utils_loader = lambda x, y: x
    import_module = lambda x: x
    pkgutil = lambda x, y: 'pkgutil'
    pkgutil_module_data = lambda x: 'abc'
    os = lambda x: x
    os.path = lambda x: 'path'
    setattr(PSModuleDepFinder, 'ps_modules', dict(zip(['m1', 'm2'], ['v1', 'v2'])))
    setattr(PSModuleDepFinder, 'exec_scripts', dict(zip(['m1', 'm2'], ['v1', 'v2'])))

# Generated at 2022-06-10 23:32:42.803281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import_module("ansible.module_utils.basic")
    import_module("ansible.module_utils.common.removed")
    import_module("ansible.module_utils.common.dict_transformations")
    import_module("ansible.module_utils.facts.system.smartos.smartos")
    import_module("ansible.module_utils.facts.system.aixtools.aix_tools")
    import_module("ansible.module_utils.facts.system.distribution.netbsd")
    import_module("ansible.module_utils.facts.system.packaging.pip")
    import_module("ansible.module_utils.facts.system.pkg_mgr.pip")
    import_module("ansible.module_utils.facts.system.virtual.kvm")
    import_

# Generated at 2022-06-10 23:32:44.237084
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:32:45.727970
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True==False

# Generated at 2022-06-10 23:32:59.158373
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cls = PSModuleDepFinder()
    assert len(cls.exec_scripts) == 0
    cls.scan_exec_script('basic')
    assert len(cls.exec_scripts) == 1
    assert 'basic' in cls.exec_scripts.keys()
    assert '#Requires' in cls.exec_scripts['basic']
    cls.scan_exec_script('basic')
    assert len(cls.exec_scripts) == 1
    assert 'basic' in cls.exec_scripts.keys()
    assert '#Requires' in cls.exec_scripts['basic']
    cls.scan_exec_script('winrm_kerberos')
    assert len(cls.exec_scripts) == 2
    assert 'basic' in cls.exec_scripts.keys()
    assert '#Requires'