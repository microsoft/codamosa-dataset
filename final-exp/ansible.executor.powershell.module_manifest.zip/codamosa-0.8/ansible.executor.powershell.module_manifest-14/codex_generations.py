

# Generated at 2022-06-10 23:23:37.774249
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("exec_wrapper")

    assert 'exec_wrapper' in finder.exec_scripts
    assert b'#ansiblerequires -powershell Ansible.ModuleUtils.Powershell' in finder.exec_scripts.get('exec_wrapper')
    assert 'ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.not_a_real_module' in finder.ps_modules


# Generated at 2022-06-10 23:23:43.432713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # There are two case of PSModuleDepFinder.scan_exec_script:
    # 1.name is not in finder.exec_scripts.keys()
    # 2.name is in finder.exec_scripts.keys()
    # Execute case 2 first
    name = "test"
    #fake name in finder.exec_scripts
    finder.exec_scripts[name] = "fake_data"
    finder.scan_exec_script(name)
    assert finder.exec_scripts[name] == "fake_data"
    if C.DEFAULT_DEBUG:
        exec_script = "fake_data"
    else:
        exec_script = _strip_comments("fake_data")
    finder.scan_exec_script(name)

# Generated at 2022-06-10 23:23:50.926181
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", to_native("ExecutionWrapper.ps1"))
    obj.scan_exec_script(to_text("ExecutionWrapper"))
    assert obj.exec_scripts["ExecutionWrapper"] == data
    obj.scan_module(data, wrapper=True, powershell=True)
    assert obj.ps_modules["Ansible.ModuleUtils.Common"]


# Generated at 2022-06-10 23:23:52.426679
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:24:05.629624
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

    # Test PS module with no module_utils reference
    finder.scan_module("Get-Foo -Bar 'Baz'")
    assert finder.ps_modules == {}
    assert finder.cs_utils_module == {}
    assert finder.cs_utils_wrapper == {}
    assert finder.ps_version is None
    assert finder.os_version is None
    assert finder.become is False
    finder.ps_modules = {}
    finder.cs_utils_module = {}
    finder.cs_utils_wrapper = {}
    finder.ps_version = None
    finder.os_version = None
    finder.become = False

    # Test PS module with a builtin module_util reference and a wrapped C# script

# Generated at 2022-06-10 23:24:10.675413
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("copy_file")
    assert finder.exec_scripts["copy_file"]
    finder.scan_exec_script("copy_file")
    assert finder.exec_scripts["copy_file"]



# Generated at 2022-06-10 23:24:11.924140
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:24:18.561510
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    resource = import_module('ansible.executor.powershell')
    is_resource = resource.__name__
    util = PSModuleDepFinder()
    assert util.scan_exec_script('script') == None
    is_instance = util.scan_exec_script('script')
    assert isinstance(is_instance,PSModuleDepFinder)
    assert isinstance(is_resource, import_module)


# Generated at 2022-06-10 23:24:32.615023
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    m = PSModuleDepFinder()
    ps = b"#Requires -Module Ansible.ModuleUtils.MyUtil\n"
    cs = b"#AnsibleRequires -CSharpUtil Ansible.MyUtil\n"
    mu = b"#Requires -Module Ansible.ModuleUtils.Util1\n"
    cs_m = b"using Ansible.MyUtil;\n"
    cs_m_m = b"#AnsibleRequires -CSharpUtil Ansible.Util2\n"
    m.scan_module(ps)
    assert to_text(mu) in m.ps_modules
    m.scan_module(cs)
    assert "Ansible.MyUtil" in m.cs_utils_module
    m.scan_module(mu)
    assert to_text

# Generated at 2022-06-10 23:24:41.437267
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:25:03.277939
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = b'''
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.facts import default_collectors
from ansible.module_utils.facts.system.distribution import DistributionFactCollector
from ansible.module_utils._text import to_bytes, to_native
'''
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(module_data)
    assert dep_finder.ps_modules is not None
    assert dep_finder.cs_utils_wrapper is not None
    assert dep_finder.exec_scripts is not None



# Generated at 2022-06-10 23:25:05.504641
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Remove this if this method is not used in the class
    pass


# Generated at 2022-06-10 23:25:06.394594
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False



# Generated at 2022-06-10 23:25:07.493516
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    assert 0 == 1


# Generated at 2022-06-10 23:25:20.396588
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test with a powershell module that has no dependencies
    module_data = b"""
    Import-Module Foo
    """
    finder = PSModuleDepFinder()
    finder.scan_module(module_data)
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.cs_utils_module) == 0
    assert finder.ps_version is None
    assert finder.os_version is None
    assert not finder.become

    # test with a powershell module that imports a builtin powershell module_util ansible.powershell.common
    # it also checks module_utils in collections.

# Generated at 2022-06-10 23:25:21.805874
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()
    mu.scan_exec_script(u'test_exec')

    assert u'test_exec' in mu.exec_scripts.keys()

# Generated at 2022-06-10 23:25:22.505542
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:25:27.412902
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TypeError: Required argument 'ext' (pos 2) not found
    # TypeError: Required argument 'fqn' (pos 3) not found
    try:
        s = PSModuleDepFinder()
    except TypeError as err:
        print(err)
        if err.args[0].startswith('Required argument'):
            raise



# Generated at 2022-06-10 23:25:34.933402
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class ModuleDepFinder_test():
        def __init__(self):
            self.module_utils_included = False
            self.module_utils_included_in_exec_wrapper = False

    module_dep_finder = ModuleDepFinder_test()

    # Test: PS module contains #Requires -Module Ansible.ModuleUtils.{name}
    module_data = "#Requires -Module Ansible.ModuleUtils.Network.F5.Common"
    module_dep_finder.scan_module(module_data)
    assert len(module_dep_finder.ps_modules) == 1

    # Test: PS module contains #AnsibleRequires -Powershell
    # Ansible.ModuleUtils.Network.F5.{name}

# Generated at 2022-06-10 23:25:49.404548
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:26:09.036442
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Creating instance of class PSModuleDepFinder
    ps_md_finder = PSModuleDepFinder()

    # Calling method scan_exec_script with argument "2.7.0"
    ps_md_finder.scan_exec_script("2.7.0")

    # Asserting equality of expected and actual results
    assert "2.7.0.ps1" not in ps_md_finder.exec_scripts

    # Calling method scan_exec_script with argument "2.7.1"
    ps_md_finder.scan_exec_script("2.7.1")

    # Asserting equality of expected and actual results
    assert ps_md_finder.exec_scripts["2.7.1"] != ""


# Generated at 2022-06-10 23:26:21.723768
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('Executing unit test for PSModuleDepFinder_scan_exec_script')
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('test')
    assert len(ps_module_dep_finder.exec_scripts.keys()) == 1
    #test the different options of providing path and validating the data
    ps_module_dep_finder.scan_exec_script('test/test')
    assert len(ps_module_dep_finder.exec_scripts.keys()) == 2
    ps_module_dep_finder.scan_exec_script('test/test1')
    assert len(ps_module_dep_finder.exec_scripts.keys()) == 3

# Generated at 2022-06-10 23:26:29.156681
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:26:34.792946
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    args = dict(
        module_data=b'',
        fqn=None,
        wrapper=False,
        powershell=True
    )
    obj = PSModuleDepFinder()
    obj.scan_module(**args)


# Generated from ansible.plugins.loader.ps_module_utils_loader._strip_comments()

# Generated at 2022-06-10 23:26:48.080925
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Test module scan_module of class PSModuleDepFinder to ensure that
    # all dependencies of a module is found.
    from ansible.module_utils.powershell import powershell
    fqn = 'ansible_collections.ansible.netcommon.plugins.modules.win_service'
    module_data = '{0}\n#AnsibleRequires {}'.format(powershell.PS_VERSION_REQ, fqn)
    md = PSModuleDepFinder()
    md.scan_module(module_data, fqn=fqn)
    assert len(md.ps_modules) == 2
    assert fqn in md.ps_modules
    assert md.ps_version == powershell.PS_VERSION_REQ.group(1)
    assert md.become is False

    # Test module scan_module

# Generated at 2022-06-10 23:26:49.689817
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO
    psmdf = PSModuleDepFinder()


# Generated at 2022-06-10 23:26:54.559003
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    md = PSModuleDepFinder()
    md.scan_exec_script('json')
    assert md.exec_scripts['json'] == 'function_command_to_json $script:file_encoding "json" "$($web_server.CreateObject("System.Text.UTF8Encoding", $false))"'
    assert md.ps_modules['ansible.module_utils.basic']['data'] == b'# this is a utf-8 encoded file'


# Generated at 2022-06-10 23:27:06.067467
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest
    import codecs

    with pytest.raises(AnsibleError) as excinfo:
        finder = PSModuleDepFinder()
        finder.scan_module(b"#AnsibleRequires -Wrapper not_there")
    assert 'Could not find executor powershell script' in to_text(excinfo.value)

    with pytest.raises(AnsibleError):
        finder = PSModuleDepFinder()
        finder.scan_module(b"#Requires -Module Ansible.module_utils.some_utility")

    with pytest.raises(AnsibleError):
        finder = PSModuleDepFinder()
        finder.scan_module(b"#AnsibleRequires -PowerShell Ansible.module_utils.some_utility")


# Generated at 2022-06-10 23:27:07.553666
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_deps = PSModuleDepFinder()
    module_deps.scan_exec_script("foo")


# Generated at 2022-06-10 23:27:17.495739
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(
        """
            #requires -Version 5.0
            if ($PSVersionTable.Version -lt "5.0"){
                Write-Warning "This module requires PowerShell 5.0 or higher for proper execution."
                return
            }

            #Requires -Module Ansible.ModuleUtils.Common

            #Requires -Module Ansible.ModuleUtils.Subversion
        """
    )

    assert finder.ps_version == "5.0"
    assert finder.os_version is None
    assert finder.become is False

    assert len(finder.ps_modules) == 2
    assert 'Ansible.ModuleUtils.Common' in finder.ps_modules
    assert 'Ansible.ModuleUtils.Subversion' in finder.ps_

# Generated at 2022-06-10 23:27:56.190888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dep_finder = PSModuleDepFinder()
	
    # 1) Test scan_exec_script() method
    ps_dep_finder.scan_exec_script('win_psexec')
    assert ps_dep_finder.exec_scripts['win_psexec'] == b'# This script originates from the Ansible PSModuleDepFinder project. For more information: https://github.com/ansible/ansible/tree/devel/lib/ansible/plugins/loader/ps_module_utils_loader.py\n\n$PSVersionTable.PSVersion.Major\n'
    assert ps_dep_finder.ps_modules['Ansible.ModuleUtils.Win32.PsExec']
    assert ps_dep_finder.ps_modules['Ansible.ModuleUtils.CommonArgs']

# Generated at 2022-06-10 23:27:59.150532
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    scan_exec_script_obj = PSModuleDepFinder()
    scan_exec_script_obj.scan_exec_script('my_name')
    

# Generated at 2022-06-10 23:28:04.317648
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    assert len(dep_finder.exec_scripts) == 0
    dep_finder.scan_exec_script('Expand-String')
    assert len(dep_finder.exec_scripts) == 1
    assert b"Expand-String" in dep_finder.exec_scripts['Expand-String']


# Generated at 2022-06-10 23:28:12.410462
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:28:19.602829
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common._collections_compat import Sequence

    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script(name="script")

    with pytest.raises(AnsibleError) as excinfo:
        psmdf.scan_exec_script(name="nonexistentscript")
    assert "'Could not find executor powershell script for 'nonexistentscript''" in to_native(excinfo.value)


# Generated at 2022-06-10 23:28:30.861564
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible_collections.aet.test.plugins.module_utils.test_module_utils
    from ansible.module_utils._text import to_bytes

    def _slurp(path):
        with open(path, 'rb') as f:
            return f.read()

    mu1 = ansible_collections.aet.test.plugins.module_utils.test_module_utils
    mu1_path = _slurp(resource_from_fqcr(mu1.__file__, 'aet.test', 'test_module_utils.psm1'))

    mu2 = ansible_collections.aet.test.plugins.module_utils.test_module_utils2

# Generated at 2022-06-10 23:28:35.503513
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that method scan_exec_script works for case when ansible_collections.namespace.collection.plugins.module_utils.powerhell.ps1
    # exists
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powerhell')
    assert 'powerhell' in dep_finder.exec_scripts.keys()
    assert dep_finder.exec_scripts['powerhell'] == b'Test Data'



# Generated at 2022-06-10 23:28:37.061902
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True == True

# Generated at 2022-06-10 23:28:49.345129
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    exec_scripts = ['pwsh/PwshInvoke.ps1', 'exec/PwshExec.ps1', 'exec/Main.ps1', 'exec/PwshReverseTunnel.ps1', 'exec/PwshFinalShell.ps1', 'pwsh/PwshCommon.ps1', 'pwsh/PwshInternalModule.ps1', 'pwsh/PwshFinalShell.ps1']
    with pytest.raises(AnsibleError) as exc_info:
        PSModuleDepFinder().scan_exec_script('pwsh/')
    assert 'Could not find executor powershell script for'.lower() in str(exc_info.value).lower()

# Generated at 2022-06-10 23:28:51.603348
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    instance = PSModuleDepFinder()
    instance.scan_exec_script('')



# Generated at 2022-06-10 23:29:45.929763
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("powershell.ps1")
    psmdf.scan_exec_script("powershell_base.ps1")
    psmdf.scan_exec_script("powershell_common.ps1")

    assert "powershell_base.ps1" in psmdf.exec_scripts
    assert "powershell_common.ps1" in psmdf.exec_scripts
    assert "powershell.ps1" in psmdf.exec_scripts



# Generated at 2022-06-10 23:29:56.858211
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import json
    import os

    module_path = os.environ.get('TEST_MOD_PATH', '/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/share/ansible/')
    module_name = os.environ.get('TEST_MOD_NAME', 'os_server')

    module_path = os.path.join(module_path, 'modules')
    fd = open(os.path.join(module_path, module_name + '.py'), encoding='utf-8')
    module_data = fd.read()
    fd.close()

    print('Load module data from', os.path.join(module_path, module_name + '.py'))

    fqn = 'ansible.modules.cloud.openstack.%s' % module_name


# Generated at 2022-06-10 23:30:03.658297
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = pkgutil.get_data(
        'ansible_collections.t_collection.t_ns.plugins.module_utils',
        'collection_module_utils.psm1')

    finder = PSModuleDepFinder()
    finder.scan_module(data, fqn='t_ns.t_coll.t_module', powershell=True)

    assert len(finder.ps_modules) == 1
    assert finder.ps_modules['Ansible.ModuleUtils.MyTestUtil']['path'] == \
        to_text(os.path.join(C.DEFAULT_MODULE_UTILS_PATH, 'MyTestUtil.psm1'))
    assert len(finder.cs_utils_module) == 0
    finder.ps_modules.clear()


# Generated at 2022-06-10 23:30:06.782235
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #  set up arguments to test method scan_exec_script of class PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('')

# Generated at 2022-06-10 23:30:18.050723
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import sys
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.facts.powershell.collection_loader import ps_module_dep_finder
    from ansible.module_utils.facts.powershell.collection_loader import ps_module_utils_loader
    from ansible.module_utils.facts.powershell.collection_loader import ps_loader_common
    ps_module_utils_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), u'module_utils'))
    # Execute the method
    psmd = ps_module_dep_finder.PSModuleDepFinder()
    name = "common_psrp"
    psmd.scan_exec_script

# Generated at 2022-06-10 23:30:19.514882
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This function only serves as a placeholder for test cases
    assert True

# Generated at 2022-06-10 23:30:22.594450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Tests issue #55656
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("root_powershell")



# Generated at 2022-06-10 23:30:32.161445
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    file_path = './test_data/scan_module.txt'
    with open(file_path, 'rb') as mm:
        test_data = mm.read()

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(test_data)

    assert to_text(ps_module_dep_finder.ps_modules[to_text('Ansible.ModuleUtils.PowerShell.Data')]['path']).endswith('/ansible/plugins/module_utils/powershell/data/data.psm1')

# Generated at 2022-06-10 23:30:38.977939
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()

    test_data = \
"""#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Bar
#Requires -Module Ansible.ModuleUtils.Foo1
#Requires -Module Ansible.ModuleUtils.Foo2
#Requires -Module Bar1
#Requires -Module Bar2
"""
    psmdf.scan_module(to_bytes(test_data))
    assert len(psmdf.ps_modules) == 5


# Generated at 2022-06-10 23:30:42.850077
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('powershell_default.ps1')
    assert len(dep_finder.exec_scripts) == 1


# Generated at 2022-06-10 23:31:31.170698
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pmdf = PSModuleDepFinder()
    # TODO: Add unit test to validate method scan_module of class PSModuleDepFinder
    # TODO: Add unit test to validate method scan_exec_script of class PSModuleDepFinder
    # TODO: Add unit test to validate method _add_module of class PSModuleDepFinder
    # TODO: Add unit test to validate method _parse_version_match of class PSModuleDepFinder


# Generated at 2022-06-10 23:31:31.557834
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	pass



# Generated at 2022-06-10 23:31:35.814470
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("win_psexec")
    assert ps_module_dep_finder.exec_scripts.get("win_psexec") is not None


# Generated at 2022-06-10 23:31:44.639471
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:31:51.226279
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fqn  = resource_from_fqcr("Ansible.Builtin.win_ping")[0]
    fqn  = fqn.replace("_", ".")
    util = PSModuleDepFinder()
    util.scan_exec_script('windows-ping')
    assert list(util.exec_scripts.keys())[0] == 'windows-ping'
    assert fqn in util.ps_modules


# Generated at 2022-06-10 23:32:02.356611
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:32:11.271419
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = '#Requires -Module Ansible.ModuleUtils.ConfigParser'
    module_data += '#Requires -Module Ansible.ModuleUtils.Common'
    module_data += '#Requires -Module Ansible.ModuleUtils.Powershell'
    module_data += '#Requires -Module Ansible.ModuleUtils.Powershell.Convert'

    depfinder = PSModuleDepFinder()
    depfinder.scan_module(module_data)

    assert len(depfinder.ps_modules) == 4, "Did not load expected 4 modules"


# Generated at 2022-06-10 23:32:12.713194
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:32:24.900890
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  import unittest
  import os
  import sys
  import mock
  from ansible.module_utils.powershell.module_utils.module_docs import PSModuleDepFinder
  from ansible.module_utils.powershell._winapi import get_os_version
  from importlib import import_module
  import platform
  import pkgutil
  from io import open
  from ansible.parsing import vault
  from ansible.module_utils.common.validation import check_type_bytes, check_type_dict
  from ansible import constants
  from ansible.plugins.loader import manager as plugin_loader_manager

  # This unit test can be executed individually by using the following command
  # > python test_PSModuleDepFinder.py
  # or can be executed with other unit tests using the following command
  # > python

# Generated at 2022-06-10 23:32:39.007680
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import tempfile

    from ansible.module_utils import basic
    from ansible.module_utils import powershell
    from ansible.module_utils.powershell.common import (
        MODULE_UTIL_PRESENT,
        MODULE_UTIL_PATH,
        MODULE_UTIL_DATA,
    )
    from ansible.module_utils._text import to_bytes

    # create test data directory
    test_data_dir = tempfile.TemporaryDirectory(prefix='ansible_test_')

    # create powershell module wrapper template
    wrapper_path = os.path.join(test_data_dir.name, 'libansibleexecutorpowershell.powershell_module.ps1')