

# Generated at 2022-06-10 23:23:45.501430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    v = PSModuleDepFinder()
    v.scan_exec_script("test")
    assert v.become == False, '_re_become should not have matched'
    v.scan_exec_script("test")
    assert v.become == False, '_re_become should not have matched'
    v.scan_exec_script("test")
    assert v.become == False, '_re_become should not have matched'

# Generated at 2022-06-10 23:23:53.422780
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    path = os.path.join(os.path.dirname(__file__), 'powershell_exec_script.ps1')
    name = 'ansible_collections.foo.bar.plugins.module_utils.powershell_exec_script'
    data = to_bytes(open(path, "rb").read())
    ps = PSModuleDepFinder()
    assert name not in ps.exec_scripts
    ps.scan_exec_script(name)
    assert name in ps.exec_scripts
    assert ps.exec_scripts[name] == data


# Generated at 2022-06-10 23:24:05.846081
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
   psModuleDepFinder = PSModuleDepFinder()
   ps_module = {"#AnsibleRequires -CSharpUtil ansible_collections.microsoft.windows.plugins.module_utils.wmf.wmf":"ansible_collections.microsoft.windows.plugins.module_utils.wmf.wmf"}
   data="ansible_collections.microsoft.windows.plugins.module_utils.wmf"
   psModuleDepFinder.cs_utils_wrapper=ps_module
   psModuleDepFinder.scan_exec_script(data)
   assert psModuleDepFinder.cs_utils_wrapper == {"ansible_collections.microsoft.windows.plugins.module_utils.wmf":"ansible_collections.microsoft.windows.plugins.module_utils.wmf"}

# Generated at 2022-06-10 23:24:12.373410
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module = AnsibleModule(argument_spec=dict())
    finder = PSModuleDepFinder()
    value = "Ansible.Powershell.InvokeCommand"
    finder.scan_exec_script(value)
    assert("Ansible.Powershell.InvokeCommand" in finder.exec_scripts.keys())

# Helper function to read a file and return its data

# Generated at 2022-06-10 23:24:13.591596
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:24:23.889332
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from textwrap import dedent

    ps_module = PSModuleDepFinder()


# Generated at 2022-06-10 23:24:36.491336
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible.utils.module_docs_fragments
    from ansible.module_utils.basic import AnsibleModule

    data = pkgutil.get_data('ansible.module_utils.basic', 'basic.psm1')
    base_module = to_bytes(data)
    module_utils = set()
    util_output = {
        'changed': False,
        'module_utils': []
    }

    # Test PS Module
    # Test Built-in module_util
    finder = PSModuleDepFinder()
    if finder.ps_version is None:
        util_output['ps_version'] = '4.0'
    util_output['module_utils'] = []
    finder.scan_module(base_module)

# Generated at 2022-06-10 23:24:40.562237
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script(name='Find-Module')
    assert ps.exec_scripts['Find-Module']



# Generated at 2022-06-10 23:24:45.685306
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create the instance of the class and test if method scan_exec_script creates dictionary of name and script.
    finder = PSModuleDepFinder()
    finder.scan_exec_script(name='ExecutionWrapper')
    assert finder.exec_scripts["ExecutionWrapper"] is not None
    



# Generated at 2022-06-10 23:24:55.957762
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("Common")
    assert psmdf.exec_scripts
    assert isinstance(psmdf.exec_scripts["Common"], bytes)
    assert len(psmdf.exec_scripts) == 1
    # Base64 version of "#Requires -Module Ansible.ModuleUtils.ArgumentSpec"
    assert b"IyBSZXF1aXJlcyAtTW9kdWxlIEFuc2libGUuTW9kdWxlVXRpbHMuQXJndW1lbnRTcGVj" in psmdf.exec_scripts["Common"]


# Generated at 2022-06-10 23:25:18.535331
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create an instance of PSModuleDepFinder
    obj = PSModuleDepFinder()
    # Run method scan_exec_script
    # This method simply scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies
    result=obj.scan_exec_script(name="ansible_powershell_common")
    assert result is None
    # This is a place holder to make test cases pass.
    # The test cases may fail as there is no return statement in the method.
    # Make the test case pass by adding a return statement.
    assert True

# Generated at 2022-06-10 23:25:29.367343
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # this is a wrapper that loads the above tests/pw_test/test_module_dep_finder.psm1 module and
    # checks that all the dependencies are found and nothing else is found
    # Note: This test is only for the host side (not the exec wrapper side)
    mod_data = pkgutil.get_data("test.unit.test_powerstate_ansible_module", to_native("test_module_dep_finder.psm1"))
    mod_data = to_bytes(mod_data)

    finder = PSModuleDepFinder()
    finder.scan_module(mod_data)

    assert finder.ps_version == '4.0'
    assert finder.os_version == '6.0'
    assert finder.become
    assert len(finder.ps_modules) == 7


# Generated at 2022-06-10 23:25:41.586948
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_cases = [
        (
            "PSModuleDepFinder_scan_exec_script_1: scan executable script",
            {
                "name": "test",
                "module_data": "# this is a comment\nTestData\n# more data",
                "wrapper": True
            },
            {
                "expected_exec_scripts": {
                    "test": "TestData"
                }
            }
        )
    ]
    for test_case_name, test_case_args, test_case_kwargs in test_cases:
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_exec_script(**test_case_args)
        assert dep_finder.exec_scripts == test_case_kwargs["expected_exec_scripts"]

# Generated at 2022-06-10 23:25:53.008079
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_data = '''#Requires -Module Ansible.ModuleUtils.TestModule
    #Requires -Module TestModule2
    #AnsibleRequires -CSharpUtil TestUtil
    #AnsibleRequires -PowerShell TestUtil2 -Optional
    #AnsibleRequires -PowerShell .testutils.TestUtil3 -Optional
    #AnsibleRequires -PowerShell .testutils.TestUtil4 -Optional
    #AnsibleRequires -CSharpUtil TestUtil5 -Optional'''

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(test_module_data)
    assert len(dep_finder.ps_modules) == 2, "TestModule and TestModule2 should have been added to the ps_modules dict"
    assert len(dep_finder.cs_utils_wrapper)

# Generated at 2022-06-10 23:26:04.808646
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # PS_MODULE_UTIL_DATA is a string containing contents of a PS module.
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(PS_MODULE_UTIL_DATA)
    assert len(ps_module_dep_finder.ps_modules) == 3
    assert len([m for m in ps_module_dep_finder.ps_modules.items() if not m[1]['path']]) == 1
    assert len([m for m in ps_module_dep_finder.ps_modules.items() if not m[1]['data']]) == 1
    assert "Ansible.ModuleUtils.ArgumentSpec" in ps_module_dep_finder.ps_modules.keys()

# Generated at 2022-06-10 23:26:06.108449
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:26:18.972347
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    psmd = PSModuleDepFinder()

    # PS module test
    psmd.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common')
    assert psmd.ps_modules[u'Ansible.ModuleUtils.Common']['data']

    # PS module test with another module util
    psmd.scan_module(b'#Requires -Module Ansible.ModuleUtils.Common\n'
                     b'#Requires -Module Ansible.ModuleUtils.Log')
    assert psmd.ps_modules[u'Ansible.ModuleUtils.Common']['data']
    assert psmd.ps_modules[u'Ansible.ModuleUtils.Log']['data']

    # Collection module test

# Generated at 2022-06-10 23:26:22.957114
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("WinRM")
    assert finder.exec_scripts["WinRM"] is not None
    assert len(finder.ps_modules.items()) > 0


# Generated at 2022-06-10 23:26:27.573760
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Arrange
    name = "my_name"
    ps_module_finder = PSModuleDepFinder()

    # Act
    ps_module_finder.scan_exec_script(name=name)

    # Assert
    assert ps_module_finder.exec_scripts is not None
    assert name in ps_module_finder.exec_scripts.keys()



# Generated at 2022-06-10 23:26:32.767700
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for method scan_exec_script of class PSModuleDepFinder"""
    dep = PSModuleDepFinder()
    dep.scan_exec_script('win_psmodulepath')
    assert "Ansible.ModuleUtils.Common" in dep.ps_modules


# Generated at 2022-06-10 23:26:58.642531
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(b"Invoke-AnsibleProvider")
    assert dep_finder.exec_scripts.keys() == [b"Invoke-AnsibleProvider"]
    assert dep_finder.become
    assert dep_finder.ps_version
    assert dep_finder.os_version

# Generated at 2022-06-10 23:27:12.030149
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # basic test to make sure the module results in all defined
    # deps being added
    finder = PSModuleDepFinder()
    # get a ps1 file and strip the encoding header
    test_ps1 = to_bytes(pkgutil.get_data("ansible_collections.test.test_collection.plugins.modules", "test.ps1"))
    test_ps1 = test_ps1.replace(b'#!powershell_shebang', b'')
    finder.scan_module(test_ps1)


# Generated at 2022-06-10 23:27:20.807518
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This test method assumes that a powershell library called ansible_test_lib_ps1 is present in
    # the lib/ansible/executor/powershell directory and is referenced in the executor script
    # ansible_test_exec_ps1. It also assumes that the powershell library contains a reference to
    # a powershell module_util
    ref_data = b"#Test\nusing Ansible.ModuleUtils.Test;\n#Requires -Modules Ansible.ModuleUtils.Test\n\n"

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_test_exec")

    # Compare the reference data with the data returned by the scan_exec_script method
    assert ref_data == dep_finder.exec_scripts['ansible_test_exec']

# Unit

# Generated at 2022-06-10 23:27:32.558074
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    data = pkgutil.get_data("ansible.executor.powershell", to_native('powershell_wrapper.ps1'))
    b_data = to_bytes(data)

    # remove comments to reduce the payload size in the exec wrappers
    if C.DEFAULT_DEBUG:
        exec_script = b_data
    else:
        exec_script = _strip_comments(b_data)
    p = PSModuleDepFinder()
    p.exec_scripts['powershell_wrapper.ps1'] = to_bytes(exec_script)
    p.scan_module(b_data, wrapper=True, powershell=True)
    assert p.exec_scripts['powershell_wrapper.ps1'] == b_data

# Generated at 2022-06-10 23:27:36.157028
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ctor = type('PSModuleDepFinder', (PSModuleDepFinder,), {})
    module_finder = ctor()
    module_finder.scan_exec_script('Invoke-Ansible')



# Generated at 2022-06-10 23:27:45.334149
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test scan_exec_script method of PSModuleDepFinder to check whether
    it adds the expected information in exec_scripts dictionary.
    :return: None
    """
    # Test data for testing scan_exec_script

# Generated at 2022-06-10 23:27:51.144282
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script('TestExecScript')

    assert dep_finder.exec_scripts.get('TestExecScript', None)
    assert len(dep_finder.exec_scripts.keys()) == 1


# Generated at 2022-06-10 23:28:01.253426
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_case1: when file does not exist
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("test")
    assert psmdf.exec_scripts["test"] == b""

    # test_case2: when file exists
    data_file = os.path.join("tests", "data", "powershell", "ansible_collections.ansible.builtin_0.0.1",
                             "plugins", "modules", "docker_volume.ps1")
    with open(data_file, "rb") as f:
        psmdf = PSModuleDepFinder()
        psmdf.scan_exec_script("docker_volume")
        assert psmdf.exec_scripts["docker_volume"] == to_bytes(f.read())


# Generated at 2022-06-10 23:28:10.741888
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # unit test for method scan_exec_script of class PSModuleDepFinder
    module_dep_finder = PSModuleDepFinder()

    # test_PSModuleDepFinder_scan_exec_script#1
    module_dep_finder.scan_exec_script(name='Common')

    # test_PSModuleDepFinder_scan_exec_script#2
    module_dep_finder.scan_exec_script(name='PosixCommon')

    # test_PSModuleDepFinder_scan_exec_script#3
    module_dep_finder.scan_exec_script(name='Common')

    # test_PSModuleDepFinder_scan_exec_script#4
    module_dep_finder.scan_exec_script(name='PosixCommon')

    # test_PSModuleDepFinder_scan_exec_script#5


# Generated at 2022-06-10 23:28:18.005731
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_instance = PSModuleDepFinder()

    try:
        test_instance.scan_exec_script("name")
        raise AssertionError("AnsibleError exception was not raised")
    except AnsibleError as e:
        assert e.message.startswith("Could not find executor powershell script for 'name'")

    try:
        test_instance.scan_exec_script("abc")
    except:
        raise AssertionError("AnsibleError exception was raised")


# Generated at 2022-06-10 23:28:31.727465
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("exec_wrapper")
    assert isinstance(mdf.exec_scripts, dict)
    assert "exec_wrapper" in mdf.exec_scripts



# Generated at 2022-06-10 23:28:38.058010
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("\n    test_PSModuleDepFinder_scan_module")
    obj = PSModuleDepFinder()
    # Test with a placeholder module data
    try:
        obj.scan_module("placeholder data")
    except Exception as e:
        assert False, "Unxpected Exception in scanning non-existing \
         module data:\n  %s" % repr(e)
    # Test with a real module data

# Generated at 2022-06-10 23:28:50.387134
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is meant to be executed on an Ansible host, as a part of the unit test for
    # the method scan_exec_script of class PSModuleDepFinder.
    # It writes a random string to a random file, and executes the method scan_exec_script
    # of class PSModuleDepFinder passing the name of the random file as the argument name.
    # The method scan_exec_script is expected to raise an exception AnsibleError, because
    # the file it expects to read does not exist.
    random_name = base64.urlsafe_b64encode(os.urandom(10)).decode("utf-8")
    random_file = open("/tmp/%s.ps1" % random_name, "w")

# Generated at 2022-06-10 23:28:57.187222
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.plugins.loader import ps_module_utils_loader
    from ansible.utils.collection_loader import resource_from_fqcr

    finder = PSModuleDepFinder()
    finder.scan_exec_script('Ansible.ModuleUtils.Logging')
    assert 'ansible_collections.jctanner.cloud_azure.plugins.module_utils.ansible_module_utils.logging' in finder.cs_utils_wrapper
    assert 'Ansible.ModuleUtils.Json' in finder.ps_modules



# Generated at 2022-06-10 23:29:05.256574
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder._script_template = b"""# This is a test
echo "Hello World"
"""
    dep_finder.scan_exec_script("TestExecScript")
    assert dep_finder.exec_scripts['TestExecScript'] == dep_finder._script_template
    assert "TestExecScript" not in dep_finder.ps_modules

# Unit tests for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:15.697269
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Testing with a mono module
    finder = PSModuleDepFinder()
    finder.scan_module('data', fqn='fake.mod')
    assert finder.ps_modules == {"Ansible.ModuleUtils.Common": {"data": "data", "path": "fake/mod/util_path"}}
    assert finder.cs_utils_wrapper == {}
    assert finder.cs_utils_module == {}
    assert finder.exec_scripts == {}

    # Testing with a multi-module
    finder = PSModuleDepFinder()
    finder.scan_module('data', fqn='fake.mod', wrapper=True)
    assert finder.ps_modules == {"Ansible.ModuleUtils.Common": {"data": "data", "path": "fake/mod/util_path"}}
   

# Generated at 2022-06-10 23:29:26.880064
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # I had originally done the below but there was a bug in Python 2 which means decode() was
    # called internally before being passed to pkgutil.get_data() causing an encode() to blow
    # up. https://bugs.python.org/issue33963
    #
    #      with open(os.path.join(os.path.dirname(__file__), "support_files", "test_module.psm1"),
    #                'rb') as f:
    #          module_data = f.read()
    #
    # This is a workaround for Python 2.
    import sys

# Generated at 2022-06-10 23:29:36.995275
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test instantiating class PSModuleDepFinder
    psd = PSModuleDepFinder()
    # test method scan_exec_script of class PSModuleDepFinder
    # test short powershell script
    psd.scan_exec_script("test_script_1")
    assert psd.exec_scripts["test_script_1"] == b'$test_variable="test_value"\n'
    # test long powershell script
    psd.scan_exec_script("test_script_2")
    assert psd.exec_scripts["test_script_2"] == b'$test_variable="test_value_2_1"\n$test_variable="test_value_2_2"\n$test_variable="test_value_2_3"\n'


# Generated at 2022-06-10 23:29:44.640891
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(name="ExecutionWrapper")
    assert "ExecutionWrapper" in finder.exec_scripts
    finder.scan_exec_script(name="ExecutionWrapper")
    assert "ExecutionWrapper" in finder.exec_scripts
    assert finder.exec_scripts["ExecutionWrapper"] == finder.exec_scripts["ExecutionWrapper"]

# Generated at 2022-06-10 23:29:55.536733
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:30:13.064041
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def test():
        module_finder = PSModuleDepFinder()
        module_finder.scan_exec_script(b'WinPendrive')
        #assert module_finder.exec_scripts == {b"WinPendrive": module_finder.exec_scripts.get(b"WinPendrive")}
        assert b"WinPendrive" in module_finder.exec_scripts.keys()

    test()



# Generated at 2022-06-10 23:30:16.157872
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('pip_win_prereq')


# Generated at 2022-06-10 23:30:24.096215
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    t = PSModuleDepFinder()
    t.scan_exec_script("/usr/bin/python")
    assert("/usr/bin/python" in t.exec_scripts)
    assert("/usr/bin/python" in t.exec_scripts.keys())
    assert("/usr/bin/python" not in t.ps_modules.keys())
    assert("/usr/bin/python" not in t.cs_utils_wrapper.keys())
    assert("/usr/bin/python" not in t.cs_utils_module.keys())



# Generated at 2022-06-10 23:30:32.995553
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('win_command')
    assert len(ps_module_dep_finder.exec_scripts) == 1
    assert len(ps_module_dep_finder.ps_modules) == 1
    assert len(ps_module_dep_finder.cs_utils_wrapper) == 2
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert ps_module_dep_finder.ps_version is None
    assert ps_module_dep_finder.os_version is None
    assert ps_module_dep_finder.become is False
    assert 'ansible.executor.powershell.win_command.ps1' in ps_module_dep_finder.exec_scripts.keys()
   

# Generated at 2022-06-10 23:30:43.468170
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Determine if class PSModuleDepFinder fails when passed a valid value
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script('')
    except Exception as err:
        assert isinstance(err, AnsibleError)
        assert str(err) == "Could not find executor powershell script for ''"
    else:
        raise AssertionError('Expected AnsibleError not raised.')

    # Determine if class PSModuleDepFinder passes when passed an invalid value
    try:
        finder.scan_exec_script('executor')
    except Exception as err:
        raise AssertionError('Unexpected exception raised: %s' % err)
    else:
        pass

# Generated at 2022-06-10 23:30:51.074051
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Create a new PSModuleDepFinder
    depfinder = PSModuleDepFinder()

    # Create some test data
    name = 'test_exec_script'
    depfinder.exec_scripts[name] = 'test_exec_script_data'

    # Execute the method under test with some basic data
    depfinder.scan_exec_script(name)

    # Verify the results of the scan
    assert name in depfinder.exec_scripts


# Generated at 2022-06-10 23:31:01.161294
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    data = b"""
#Requires -Module Ansible.ModuleUtils.Foo
#Requires -Module Ansible.ModuleUtils.Bar
#Requires -Module Ansible.ModuleUtils.Baz
blah blah
"""

    util_data = b"""
#Requires -Module Ansible.ModuleUtils.Foo
blah blah
"""
    finder.scan_module(module_data=data)
    assert finder.ps_modules["Ansible.ModuleUtils.Foo"]["data"] == util_data
    assert finder.ps_modules["Ansible.ModuleUtils.Bar"]["data"] is None
    assert finder.ps_modules["Ansible.ModuleUtils.Baz"]["data"] is None

# Generated at 2022-06-10 23:31:02.821705
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():  # noqa: D103
    pass

    # Unit test for method _add_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:31:07.892251
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test = PSModuleDepFinder()
    test.scan_exec_script("CopyFile")

    assert to_text(test.exec_scripts["CopyFile"]) == "#check file size but not its content if same size"
    assert to_text(test.exec_scripts["Common"]) == "param($argument_dict, $powershell_script, $env)"

# Generated at 2022-06-10 23:31:17.622645
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:31:42.602949
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    with pytest.raises(AnsibleError):
        f = PSModuleDepFinder()
        f.scan_exec_script("does_not_exist")

# Generated at 2022-06-10 23:31:43.479281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "TBD"


# Generated at 2022-06-10 23:31:55.375814
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test the scan_module method for the PSModuleDepFinder Class
    """

    # _slurp should return the content of the file
    # _slurp should return bytes
    # _slurp should return a string
    # _slurp should return an empty string
    # _slurp should return a string
    # _slurp should raise an error
    # _slurp should raise an error
    # _slurp should return a string
    # _slurp should raise an error
    # _slurp should raise an error

    # _strip_comments should return a string with comment stripped
    # _strip_comments should raise an error
    # _strip_comments should return a string
    # _strip_comments should raise an error


# Generated at 2022-06-10 23:32:04.177825
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psModuleDepFinder = PSModuleDepFinder()
    moduleUtils_1 = '#Requires -Module Ansible.ModuleUtils.Foo'
    moduleUtils_2 = '#Requires -Module Ansible.ModuleUtils.Fizz'
    moduleUtils_3 = '#Requires -Module Ansible.ModuleUtils.Bar'
    moduleUtils_4 = '#Requires -Module Ansible.ModuleUtils.Buzz'
    moduleUtils_5 = '#Requires -Module Ansible.ModuleUtils.CSharp'
    moduleUtils_6 = '#AnsibleRequires -PowerShell ansible_collections.test.test_utils.plugins.module_utils.foobar'

    psModuleDepFinder.scan_module(moduleUtils_1)
    assert psModuleDepFinder.ps_modules != None

# Generated at 2022-06-10 23:32:09.099967
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_object = PSModuleDepFinder()
    test_name = random.randint(0,100000)
    test_object.exec_scripts[test_name] = random.randint(0,100000)
    test_object.scan_exec_script(test_name)

# Generated at 2022-06-10 23:32:22.649120
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test scan_exec_script method of class PSModuleDepFinder"""
    import sys
    import os
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file_name = 'testfile.ps1'
    test_file_data = 'ansible'
    test_file_path = os.path.join(test_dir, test_file_name)
    with open(test_file_path, 'w') as test_file:
        test_file.write(test_file_data)
        test_file.close()

    sys.path.append(test_dir)
    psmdf = PSModuleDepFinder()

    psmdf.ps_modules = {}
    psmdf.scan_exec_script(test_file_name)


# Generated at 2022-06-10 23:32:30.126951
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("bogus")
        assert False, "should have gotten an exception"
    except AnsibleError:
        pass

    finder.scan_exec_script("connect")
    assert len(finder.exec_scripts) == 1
    assert "connect" in finder.exec_scripts
    assert len(finder.ps_modules) > 0


# Generated at 2022-06-10 23:32:36.511120
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create an instance of class PSModuleDepFinder
    PSModuleDepFinder_instance = PSModuleDepFinder()
    # Call method scan_module with module data, fqn, wrapper and powershell
    PSModuleDepFinder_instance.scan_module(b"#AnsibleRequires -CSharpUtil Ansible.Test")


# Generated at 2022-06-10 23:32:41.912376
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    result = PSModuleDepFinder()
    result.scan_exec_script("ANSIBLE_MODULE_EXEC_PATH_SEPARATOR")
    # Assert
    assert result.exec_scripts["ANSIBLE_MODULE_EXEC_PATH_SEPARATOR"] == "write-debug $ansible_full_module_path_separator\n"


# Generated at 2022-06-10 23:32:45.194855
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(b'an_exec_script_name')

