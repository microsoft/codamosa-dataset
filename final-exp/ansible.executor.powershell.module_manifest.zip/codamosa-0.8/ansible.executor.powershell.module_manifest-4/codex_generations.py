

# Generated at 2022-06-10 23:23:43.708329
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    finder = PSModuleDepFinder()
    current_test_file_name = tempfile.NamedTemporaryFile(delete=False)
    current_test_file_name.write(b"#AnsibleRequires -CSharpUtil Ansible.Common\n")
    current_test_file_name.write(b"#AnsibleRequires -Wrapper Utils\n")
    current_test_file_name.write(b"#AnsibleRequires -Wrapper Utils")
    current_test_file_name.close()
    finder.scan_exec_script(current_test_file_name.name)

# Generated at 2022-06-10 23:23:48.892669
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #dummy_exec_scripts = ["psutil_common"]
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script("psutil_common")
    dep_finder.scan_exec_script("psutil_common")
    dep_finder.scan_exec_script("psutil_posix")


# Generated at 2022-06-10 23:23:57.582295
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # set up a random string to use as the test data
    random_string = to_text(base64.b64encode(os.urandom(random.randint(128, 512)))) + "\n"

    # create a file which contains the test data, which is the cs wrapper for win_ping.ps1
    test_file_path = os.path.join(C.DEFAULT_LOCAL_TMP, "PSModuleDepFinder_ScanExecScript.ps1")
    with open(test_file_path, "wb") as test_file:
        test_file.write(random_string)

    # create an instance of PSModuleDepFinder and scan the file
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(test_file_path)

    # make sure the contents of the script

# Generated at 2022-06-10 23:24:10.531034
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print('In test_PSModuleDepFinder_scan_module')
    # test_module_utils_include_CS_module is a ps module that contains a C# util include
    module_data = pkgutil.get_data('ansible_test', 'test_module_utils_include_CS_module.psm1')
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(module_data, fqn='ansible_test.test_module_utils_include_CS_module.psm1')
    assert 'ansible_collections.test.test_module_utils_include_CS_module.plugins.module_utils.win_ping' in ps_module_dep_finder.cs_utils_in_ps_modules



# Generated at 2022-06-10 23:24:13.649872
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script('CommonUtils')
    assert(len(f.exec_scripts) == 1)


# Generated at 2022-06-10 23:24:23.924456
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # For the given module, test_module, the scan module method should return
    # the modules required by the given module.

    # test_module requires Ansible.CommonUtils and ansible_collections.geerlingguy.windows.plugins.module_utils.windows_dsc
    test_module = '''#!/usr/bin/env powershell
# Copyright (c) 2019 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# Requires -Module Ansible.CommonUtils
# AnsibleRequires -CSharpUtil ansible_collections.geerlingguy.windows.plugins.module_utils.windows_dsc
import-module Ansible.CommonUtils
'''

    depfinder = PSModuleDepFinder()
   

# Generated at 2022-06-10 23:24:28.809244
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('test_script')

    # test
    assert ps_module_dep_finder.exec_scripts['test_script'] is not None

# Generated at 2022-06-10 23:24:31.995466
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('PowerShellExecutor')
    assert finder.exec_scripts['PowerShellExecutor'] is not None

# Generated at 2022-06-10 23:24:41.093770
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test the scan_exec_script method of class PSModuleDepFinder.
    # This method is used to get the path of the powershell script required to support the Ansible module.
    # This method also scans the script for any module utils that the script may require.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.powershell import AnsiblePowerShell
    from ansible.module_utils.powershell.runner import WIN_PS_EXE, WIN_POWERSHELL_PATH
    from ansible.module_utils.powershell.winrm import _handle_decode_dict, _create_winrm_client
    from ansible.executor.powershell.module_utils import modules_common_loader
    # assert that these scripts

# Generated at 2022-06-10 23:24:42.160639
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert 1 <= 1


# Generated at 2022-06-10 23:25:06.671686
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.B')
    assert ps_module_dep_finder.ps_modules.get(b'Ansible.ModuleUtils.B') is not None

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.B -Optional')
    assert ps_module_dep_finder.ps_modules.get(b'Ansible.ModuleUtils.B') is None

    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:25:19.693924
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Test PSModuleDepFinder._add_module()
    """
    test_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'PSModuleDepFinder_scan_module')

    with open(os.path.join(test_data_dir, 'input.txt'), 'rb') as input_f:
        input_data = input_f.read()

    # expected output for a single module scan.
    # - ModuleUtil.foo is in a .psm1 module which also has a Requires to ModuleUtil.bar
    # - ModuleUtil.baz is a .cs module
    # - ModuleUtil.quux is another .cs module that's in a different module_utils namespace
    # - ModuleUtil.qux is a .

# Generated at 2022-06-10 23:25:23.135315
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    import ansible.executor.powershell

    # Act
    PSModuleDepFinder().scan_exec_script('win_command')
    PSModuleDepFinder().scan_exec_script('win_environment')


# Generated at 2022-06-10 23:25:24.015174
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO Test scan_exec_script if needed
    assert False

# Generated at 2022-06-10 23:25:32.902537
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    test_PSModuleDepFinder_scan_module
    """
    import sys, os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, current_dir + "/../../../../lib/ansible/plugins/action")
    from win_ping import ActionModule as win_ping


# Generated at 2022-06-10 23:25:41.415418
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    path = "/path/to/exec/script.ps1"
    name = "exec_script"
    with pytest.raises(AnsibleError):
        PSModuleDepFinder().scan_exec_script(name)

    data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
    with patch("pkgutil.get_data", side_effect=data, return_value=data):
        PSModuleDepFinder().scan_exec_script(name)



# Generated at 2022-06-10 23:25:52.953542
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep = PSModuleDepFinder()
    dep.scan_exec_script("powershell_helpers")
    assert dep.ps_modules[".module_utils.powershell.powershell_helpers"]['path'] == "ansible/module_utils/powershell/powershell_helpers.psm1"
    assert dep.exec_scripts["powershell_helpers"].decode("utf-8").startswith("# Dummy header")
    assert dep.cs_utils_wrapper[".module_utils.powershell.ps_module_utils"]['path'] == 'ansible/module_utils/powershell/ps_module_utils.cs'

# Generated at 2022-06-10 23:25:58.468387
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#AnsibleRequires -Module Ansible.ModuleUtils.Tools\n#AnsibleRequires -Module Ansible.ModuleUtils.Tools\n')
    assert len(psmdf.ps_modules.keys()) == 1


# Generated at 2022-06-10 23:26:09.813489
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def test_scan_exec_script(self, module_data, fqn=None, wrapper=False, powershell=True):
        lines = module_data.split(b'\n')
        module_utils = set()
        if wrapper:
            cs_utils = self.cs_utils_wrapper
        else:
            cs_utils = self.cs_utils_module


# Generated at 2022-06-10 23:26:14.153642
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_finder = PSModuleDepFinder()
    mu_finder.scan_exec_script(name='Ansible.posix.System')
    assert mu_finder.exec_scripts['Ansible.posix.System'] == b'\r\n'

# Generated at 2022-06-10 23:26:37.575328
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    td = dict()
    td["name"] = "test"
    td["expected"] = None
    
    # Replace ps_module_utils_loader.find_plugin with a method that returns None
    # This method is part of the module_utils.loader module, so we have to import it
    import module_utils.loader
    import __builtin__
    if not hasattr(__builtin__, "_find_plugin"):
        __builtin__._find_plugin = module_utils.loader.find_plugin
    def find_plugin(name, ext, mod_type=None, ignore_deprecated=False, disable_warnings=False, support_vars=False):
        return None
    module_utils.loader.find_plugin = find_plugin
    

# Generated at 2022-06-10 23:26:50.026236
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mock_name_1 = random.choice(list(string.ascii_letters))
    mock_name_2 = random.choice(list(string.ascii_letters))
    mock_data_1 = "I am data"
    mock_data_2 = "I am more data"
    mock_path_1 = "mock/path/1"
    mock_path_2 = "mock/path/2"

    # make a mock finder class with a mock scan_exec_script
    class MockFinder(PSModuleDepFinder):
        def scan_exec_script(self, name):
            # Test that the right data is passed in to the method
            assert name == mock_name_1, "Name was not the same as expected"

            # Test that the expected data is in exec_scripts
            assert mock_name_

# Generated at 2022-06-10 23:26:57.042432
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import inspect
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import _json_decode
    from ansible.module_utils.common.json_utils import _json_encode
    from ansible.module_utils.common.json_utils import encode_stream
    from ansible.module_utils.common.json_utils import from_json
    from ansible.module_utils.common.json_utils import log_invocation
    from ansible.module_utils.common.json_utils import to_lines
    from ansible.module_utils.common.json_utils import to_text
    from ansible.module_utils.common.process import get

# Generated at 2022-06-10 23:27:11.289148
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mod_dep_finder = PSModuleDepFinder()

    # Test 1
    # Test normal path, no dependencies.
    name = 'TestName'
    mod_dep_finder.scan_exec_script(name)
    assert to_text(name) in mod_dep_finder.exec_scripts.keys()
    assert to_text(name) in mod_dep_finder.ps_modules.keys()
    assert to_text(name) in mod_dep_finder.cs_utils_wrapper.keys()

    # Test 2
    # Test normal path, with dependencies.
    name = 'TestName'
    mod_dep_finder.scan_exec_script(name)
    assert to_text(name) in mod_dep_finder.exec_scripts.keys()
    assert to_text(name) in mod_dep_finder.ps_

# Generated at 2022-06-10 23:27:14.181826
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    try:
        obj.scan_exec_script("win_ansible")
    except AnsibleError:
        assert False


# Generated at 2022-06-10 23:27:20.435479
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Check that scan_exec_script works as expected
    f = PSModuleDepFinder()
    # Test with existing script
    f.scan_exec_script('win_ping')
    # Test with non-existing script
    try:
        f.scan_exec_script('win_does_not_exist')
        assert False, "Scanning for non-existant script should throw AnsibleError."
    except AnsibleError:
        assert True
    except Exception as e:
        assert False, "Scanning for non-existant script should throw AnsibleError. Got: %s" % str(e)



# Generated at 2022-06-10 23:27:32.168519
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell import entry

    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("pswrap")
    assert mdf.exec_scripts["pswrap"] == entry
    assert mdf.cs_utils_wrapper["Ansible.ModuleUtils.Powershell.InvokeCommand"]["path"] == "ansible_collections/ansible/builtin/plugins/module_utils/powershell/invoke_command.psm1"
    assert mdf.cs_utils_wrapper["Ansible.ModuleUtils.Powershell.HashTable"]["path"] == "ansible_collections/ansible/builtin/plugins/module_utils/powershell/hashtable.psm1"

    mdf.scan_exec_script("basic")

# Generated at 2022-06-10 23:27:38.542204
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    assert os.path.exists("test/runner/test/units/modules/test_psmodule_dep_finder.ps1")

    finder = PSModuleDepFinder()
    assert len(finder.exec_scripts) == 0
    finder.scan_exec_script("test/runner/test/units/modules/test_psmodule_dep_finder")
    assert len(finder.exec_scripts) == 1



# Generated at 2022-06-10 23:27:43.945575
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    module_data = 'using Ansible.TestModuleUtil;'
    fqn = 'Ansible.TestModuleUtil'
    wrapper = False
    powershell = True
    obj.scan_module(module_data, fqn = fqn, wrapper = wrapper, powershell = powershell)
    obj.scan_module(module_data, wrapper = wrapper, powershell = powershell)


# Generated at 2022-06-10 23:27:48.480950
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder_obj = PSModuleDepFinder()
    test_PSModuleDepFinder_obj.scan_exec_script("test_PSModuleDepFinder_name")



# Generated at 2022-06-10 23:28:02.786589
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script('Test_PSModuleDepFinder')
    assert 'Test_PSModuleDepFinder' in psmdf.exec_scripts

# Generated at 2022-06-10 23:28:03.495821
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:28:11.959298
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os.path
    from ansible.module_utils.basic import AnsibleModule
    import ansible.executor.powershell
    import pkgutil

    base_script = os.path.join(os.path.abspath(ansible.executor.powershell.__path__[0]), 'base.ps1')
    base_script_data = pkgutil.get_data('ansible.executor.powershell', 'base.ps1')
    # Create PSModuleDepFinder instance
    mdf = PSModuleDepFinder()
    mdf.scan_module(base_script_data, wrapper=True, powershell=True)
    # Test fields ps_modules, exec_scripts, ps_version, os_version and become
    assert mdf.ps_modules != {}
    assert mdf.exec_scripts != {}


# Generated at 2022-06-10 23:28:19.196482
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    fixture = PSModuleDepFinder()

    # With an invalid powershell script
    with pytest.raises(AnsibleError):
        fixture.scan_exec_script('i_do_not_exist')

    # With a real powershell script
    fixture.scan_exec_script('common_exec')

    # After calling the method, the powershell script common_exec is populated in exec_scripts
    assert 'common_exec' in fixture.exec_scripts



# Generated at 2022-06-10 23:28:30.579321
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        importlib.reload(ps_module_utils_loader)
    except NameError:
        import importlib
    try:
        importlib.reload(resource_from_fqcr)
    except NameError:
        import importlib


    mod = PSModuleDepFinder()
    assert mod.ps_modules == {}
    assert mod.exec_scripts == {}
    assert mod.cs_utils_wrapper == {}
    assert mod.cs_utils_module == {}
    assert mod.ps_version is None
    assert mod.os_version is None
    assert mod.become == False

    test_path = os.path.dirname(os.path.realpath(__file__))

    # Test that a module with no module_utils and no exec_script dependencies
    # will add nothing to the attrs
   

# Generated at 2022-06-10 23:28:31.233413
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:28:42.570651
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # test case 1
    data = b"""#Requires -Module Ansible.ModuleUtils.ActiveDirectory
#Requires -Module Ansible.ModuleUtils.CommonUtils
#Requires -Module Ansible.ModuleUtils.Legacy
#Requires -Version 5.0
#Requires -Version 5.1
"""
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(data)
    assert len(ps_module_dep_finder.ps_modules) == 5
    assert ps_module_dep_finder.ps_version == "5.1"

    # test case 2
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module(data.replace(b"#Requires", b"#AnsibleRequires"))
    assert len

# Generated at 2022-06-10 23:28:45.106466
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell.common')

# Generated at 2022-06-10 23:28:56.069399
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:03.280566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test to make sure a custom exec script can be found
    # Assert scan_exec_script raises the correct exception in these cases
    # Test to make sure a custom exec script is added to self.exec_scripts
    # Test to make sure a custom exec script has been stripped of comments
    f = PSModuleDepFinder()
    f.scan_exec_script("exec", True)
    assert f.scan_exec_script("exec.ps1") is not None

# Generated at 2022-06-10 23:29:46.413580
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()

    assert obj is not None

    # test with an existing name
    obj.scan_exec_script("PowerShellGet")
    assert obj.exec_scripts is not None
    assert len(obj.exec_scripts.keys()) == 1
    assert "PowerShellGet" in obj.exec_scripts.keys()
    assert obj.exec_scripts["PowerShellGet"]

    # test with a non-existing name
    obj.scan_exec_script("PowerShellGet1")
    assert obj.exec_scripts is not None
    assert len(obj.exec_scripts.keys()) == 1
    assert "PowerShellGet" in obj.exec_scripts.keys()
    assert obj.exec_scripts["PowerShellGet"]



# Generated at 2022-06-10 23:29:51.622978
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible_module_wrapper")
    assert len(finder.exec_scripts) == 1
    assert finder.exec_scripts["ansible_module_wrapper"] == _slurp(
        "lib/ansible/executor/powershell/ansible_module_wrapper.ps1")



# Generated at 2022-06-10 23:29:54.480495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    assert psModuleDepFinder.scan_exec_script("a") == None


# Generated at 2022-06-10 23:30:03.358838
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmd = PSModuleDepFinder()
    assert len(psmd.ps_modules.keys()) == 0
    assert len(psmd.cs_utils_wrapper.keys()) == 0
    assert len(psmd.cs_utils_module.keys()) == 0
    assert psmd.ps_version is None
    assert psmd.os_version is None
    assert psmd.become is False

    module = resource_from_fqcr("community.windows.windows_firewall")
    psmd.scan_module(module.data())
    assert len(psmd.ps_modules.keys()) == 13
    assert "Ansible.ModuleUtils.ActiveDirectory" in psmd.ps_modules.keys()
    assert "Ansible.ModuleUtils.Common" in psmd.ps_modules.keys

# Generated at 2022-06-10 23:30:14.078570
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a new instance of psmoduledepfinder class and check module is scanned.
    obj = PSModuleDepFinder()
    module_data = b''
    fqn = None
    wrapper = False
    powershell_data = b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}'
    powershell_extension = '.psm1'
    powershell = True

    try:
        obj.scan_module(module_data, fqn, wrapper, powershell)

    except AnsibleError as error:
        raise error

    # Create a new instance of psmoduledepfinder class and check module is scanned.
    obj = PSModuleDepFinder()
    module_data = b''
    fqn = None
    wrapper = True
    powershell_extension = '.psm1'
   

# Generated at 2022-06-10 23:30:26.062309
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The selected_platforms are used by the coverage collection system to determine if
    # the test is applicable to the platform on which the tests are executing.
    selected_platforms = [
        # The following platforms are supported by the PSModuleDepFinder_scan_exec_script test.
        'windows',
    ]

    # Skip this test on platforms other than those in selected_platforms.
    if platform.system() not in selected_platforms:
        pytest.skip('Platform not in selected_platforms.')

    # The text for the test_PSModuleDepFinder_scan_exec_script test.

# Generated at 2022-06-10 23:30:29.333061
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder.scan_exec_script('Basic')
    result = depFinder.ps_modules
    assert 'ansible.module_utils.basic' in result



# Generated at 2022-06-10 23:30:36.819494
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    mod = PSModuleDepFinder()

    mod.scan_exec_script("win_package")

    assert mod.exec_scripts["win_package"] is not None

    # If a file is not present, this function will raise a AnsibleError.
    # We need to check that that is the case
    try:
        mod.scan_exec_script("win_package1")
    except AnsibleError as e:
        assert e.message == "Could not find executor powershell script for 'win_package1'"



# Generated at 2022-06-10 23:30:38.695708
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    val = PSModuleDepFinder()
    val.scan_exec_script("connect_server")


# Generated at 2022-06-10 23:30:47.984425
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pdmdf = PSModuleDepFinder()
    pdmdf.scan_exec_script("testExecScript")

# Generated at 2022-06-10 23:32:38.299046
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psmdf = PSModuleDepFinder()
    psmdf.scan_module(b'#Requires -Module Ansible.ModuleUtils.Legacy.Collection',
                     'ansible_collections.fortinet.fortios.plugins.module_utils.network.fortios.fortios')
    assert psmdf.ps_modules['Ansible.ModuleUtils.Legacy.Collection']['data'].startswith(b'Import-Module')
    assert psmdf.ps_modules['Ansible.ModuleUtils.Legacy.Collection']['data'].endswith(b'Get-FnTmpPath\n')

# Generated at 2022-06-10 23:32:46.173835
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = u'#Requires -Module Ansible.ModuleUtils.Logging\n' \
                  u'#AnsibleRequires -PowerShell Ansible.ModuleUtils.PowerShell\n' \
                  u'#AnsibleRequires -Wrapper ansible_collections.my_namespace.my_collection.plugins.module_utils.command.exe'
    finder.scan_module(to_bytes(module_data))

# Generated at 2022-06-10 23:32:59.354002
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('\n# Unit test for method scan_exec_script of class PSModuleDepFinder')

    # For testing, we are going to create a class instance
    # and add some test data which we can use to check the return
    # value of the method.
    test_obj = PSModuleDepFinder()
    test_data = "abcdefg"
    
    # The test data should not be in the dictionary at this point
    # and so the method should return successfully
    assert test_obj.scan_exec_script(test_data) is None

    # Now we are going to mock pkgutil.get_data with a method
    # which always returns a test string.
    # We then add the test data to the dictionary so that
    # the method should try to recursively scan the test data.
    # This would normally cause an error,