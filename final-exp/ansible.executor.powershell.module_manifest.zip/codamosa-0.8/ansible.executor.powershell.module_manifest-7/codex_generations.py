

# Generated at 2022-06-10 23:23:29.975840
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  # mock of exec_scripts for testing scan_exec_script
  class mock_exec_scripts:
    def __init__(self):
      self.exec_scripts = {}

    def get_exec_scripts(self):
      return self.exec_scripts

    def get_exec_scripts_keys(self):
      return self.exec_scripts.keys()

  # mock of AnsibleError for testing scan_exec_script
  class mock_AnsibleError:
    def __init__(self):
      self.error = None
    def __call__(self, err):
      self.error = err

  # mock of pkgutil for testing scan_exec_script
  class mock_pkgutil:
    def __init__(self):
      self.package = None
      self.name = None


# Generated at 2022-06-10 23:23:42.815608
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import tempfile
    from distutils.version import LooseVersion

    test_case_dir = os.path.dirname(os.path.realpath(__file__))
    test_case_file_path = os.path.join(test_case_dir, "PSModuleDepFinder_scan_module_case.psm1")
    assert os.path.exists(test_case_file_path), \
        ('Failed to get test case files from "{0}". Make sure there is '
         'PSModuleDepFinder_scan_module_case.psm1 file under the same directory.'.format(test_case_dir))
    test_case_data = open(test_case_file_path, 'rb').read()

    mdf = PSModuleDepFinder()

# Generated at 2022-06-10 23:23:53.727709
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    psdep_finder = PSModuleDepFinder()
    psdep_finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.SomeModuleUtil\n")
    assert len(psdep_finder.ps_modules) == 1
    assert list(psdep_finder.ps_modules.keys())[0] == "Ansible.ModuleUtils.SomeModuleUtil"
    assert "data" in psdep_finder.ps_modules.get("Ansible.ModuleUtils.SomeModuleUtil")
    assert "path" in psdep_finder.ps_modules.get("Ansible.ModuleUtils.SomeModuleUtil")

    psdep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:24:06.810979
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    def mock_ps_module_utils_loader_find_plugin(m, ext):
        return "mock_ansible/plugins/module_utils/power_shell/%s" %m

    def mock_get_data(name, file_name):
        return to_native(pkgutil.get_data("ansible.executor.powershell", name).decode('utf-8'))

    finder = PSModuleDepFinder()
    finder._add_module = mock_add_module
    finder.scan_exec_script = mock_scan_exec_script
    finder._parse_version_match = mock_parse_version_match

    ###########################################################################
    # Test scan module
    # PS module contains #Requires -Module Ansible.ModuleUtils.{name}.

# Generated at 2022-06-10 23:24:07.686360
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Test not implemented"



# Generated at 2022-06-10 23:24:08.927535
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True is not False


# Generated at 2022-06-10 23:24:12.262109
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for `PSModuleDepFinder.scan_exec_script` method."""
    import pytest
    assert pytest.main([__file__]) == 0


# Generated at 2022-06-10 23:24:23.023021
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # These tests are currently not run on Travis and only executed when invoked locally.
    import sys
    from ansible.module_utils import basic

    mu_name = 'basic'
    finder = PSModuleDepFinder()

    mu_files = ['ansible_module_utils/%s.ps1' % mu_name]

    # sample output of the module_utils finder above
    mod_utils = [
        ansible_module_utils.basic
    ]

    # Look for dynamic module_utils
    for util in mod_utils:
        try:
            finder.scan_exec_script(util.__name__)
        except SystemExit:
            # We don't want to trigger the exit of the program if a module_util fails to load,
            # so let's log the error and continue the execution
            e = sys.exc_

# Generated at 2022-06-10 23:24:35.546723
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # pylint: disable=redefined-outer-name
    depfinder = PSModuleDepFinder()
    module_util_data1 = b'#Requires -Module Ansible.ModuleUtils.Tools\n'
    module_util_data2 = b'#AnsibleRequires -Powershell Ansible.ModuleUtils.Tools\n'
    module_util_data3 = b'#AnsibleRequires -Powershell ansible_collections.foo.bar.plugins.module_utils.Tools\n'
    module_util_data4 = b'#Requires -Module Ansible.ModuleUtils.Tools\n' \
                        b'#Requires -Module Ansible.ModuleUtils.Tools\n'

# Generated at 2022-06-10 23:24:43.244228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    from ansible.module_utils.powershell import PSModuleDepFinder

    finder = PSModuleDepFinder()
    finder.scan_exec_script("basic")

    assert finder.exec_scripts["basic"] is not None
    assert len(finder.exec_scripts) == 1

    assert finder.ps_modules["Ansible.ModuleUtils.Common"] is not None
    assert len(finder.ps_modules) == 1


# Generated at 2022-06-10 23:25:12.410839
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # Call scan_exec_script
    finder.scan_exec_script('script_name')



# Generated at 2022-06-10 23:25:21.268441
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Declaration
    sut = PSModuleDepFinder()
    name = None

    # Setup
    sut._re_wrapper = re.compile(to_bytes(r'(?i)^#\s*ansiblerequires\s+-wrapper\s+(\w*)'))

    # Exercise

    # Verify
    try:
        sut.scan_exec_script(name)
    except Exception as e:
        if "Could not find executor powershell script for '%s'" % name in e.args[0]:
            pass
        else:
            raise

# Generated at 2022-06-10 23:25:23.590450
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("pwshconverter")


# Generated at 2022-06-10 23:25:27.603800
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    name = "helpers"
    dep_finder.scan_exec_script(name)

    # script should always have one dependency to the Networking module_util
    assert len(dep_finder.ps_modules) == 1


# Generated at 2022-06-10 23:25:31.777644
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    test_PSModuleDepFinder_scan_exec_script
    """

    finder = PSModuleDepFinder()
    finder.scan_exec_script('script_name')



# Generated at 2022-06-10 23:25:36.081687
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # AnsibleModuleDepFinder
    psModuleDepFinder = PSModuleDepFinder()
    script = psModuleDepFinder.scan_exec_script('test_script')
    assert script == 'test_script'


# Generated at 2022-06-10 23:25:50.611757
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """ Unit test case for PSModuleDepFinder_scan_exec_script """
    ps_module_dep_finder = PSModuleDepFinder()

    # check if the name is in exec_scripts dict
    # and if so return
    ps_module_dep_finder.exec_scripts = {
        'Name1': 'Exec_Script1',
        'Name2': 'Exec_Script2',
        'Name3': 'Exec_Script3',
    }
    ps_module_dep_finder.scan_exec_script('Name1')
    ps_module_dep_finder.scan_exec_script('Name2')
    ps_module_dep_finder.scan_exec_script('Name3')

# Generated at 2022-06-10 23:26:02.784053
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def test_ansible_module_data(self, name, data, optional=False):
        self.data = data
        self.path = name
        self.optional = optional

    test_ansible_module_data.__name__ = "test_ansible_module_data"
    test_ansible_module_data.__doc__ = "Testable version of AnsibleModule"

    ps_module_utils_loader.AnsibleModule = test_ansible_module_data
    ps_module_utils_loader.AnsibleModule.__doc__ = "Testable version of AnsibleModule"

    ps_dep_finder = PSModuleDepFinder()

    module_data = to_bytes("""\
#Requires -Module 'FooBar'
""")
    ps_dep_finder.scan_module(module_data)
   

# Generated at 2022-06-10 23:26:06.658351
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    c = PSModuleDepFinder()

    assert c.scan_exec_script("init_ansible") is None

    assert c.exec_scripts['init_ansible'] == b'function [ansible.executor.powershell]::init_ansible {\n[cmdletbinding()]\n'

    assert isinstance(c.exec_scripts['init_ansible'], bytes)


# Generated at 2022-06-10 23:26:19.622607
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    a = PSModuleDepFinder()
    a.scan_module(resource_from_fqcr('ansible.netcommon.plugins.modules.net_ping.psm1'))
    assert len(a.ps_modules) == 2
    assert len(a.cs_utils_module) == 0
    assert len(a.cs_utils_wrapper) == 0
    for module_util, module_util_info in a.ps_modules.items():
        if module_util == "Ansible.ModuleUtils.PowerShellTools":
            assert module_util_info['path'].endswith("/ansible/module_utils/powershell/tools.psm1")
            assert module_util_info['data'] == b"# Test\r\n"

# Generated at 2022-06-10 23:26:37.150855
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-10 23:26:42.577145
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_finder = PSModuleDepFinder()
    mu_finder.scan_exec_script('powershell_script_template')
    # Check if the powershell_script_template is present in exec_scripts
    assert 'powershell_script_template' in mu_finder.exec_scripts.keys()

# Generated at 2022-06-10 23:26:53.350858
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.facts.system.ceph import _find_ceph_conf

    finder = PSModuleDepFinder()

    # try not going to the ps1, using only the cs util
    finder.scan_exec_script('ceph')
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 1
    assert len(finder.exec_scripts) == 1

    # this one should not be in the cs utils because it's in a collection
    finder.cs_utils_wrapper = dict()
    finder.scan_exec_script('openstack_cloud')
    assert len(finder.ps_modules) == 0
    assert len(finder.cs_utils_wrapper) == 0
    assert len(finder.exec_scripts) == 1

    # try with

# Generated at 2022-06-10 23:27:08.594690
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile
    import shutil


# Generated at 2022-06-10 23:27:18.559281
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This can be simplified to get_data when we move to 2.7 where get_data is a native function
    def get_data(package, resource_name):
        return pkgutil.get_data(package, resource_name)

    def get_data_side_effect(package, resource_name):
        def _get_data(package, resource_name):
            if package not in data:
                raise OSError(2, "No such file or directory")

            result = data[package].get(resource_name, None)
            if result is None:
                raise OSError(2, "No such file or directory")

            return result

        return _get_data(package, resource_name)

    pkgutil.get_data = get_data
    data = dict()

    # Add 1st util to internal dict,

# Generated at 2022-06-10 23:27:24.856769
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #Arrange
    ps_module_dep_finder = PSModuleDepFinder()
    name = "test"

    #Act
    ps_module_dep_finder.scan_exec_script(name)
    
    #Assert
    assert ps_module_dep_finder.exec_scripts == {"test": b'$test = "test"\r\n'}, "Scan PS Module test failed"


# Generated at 2022-06-10 23:27:32.738632
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiating object
    obj = PSModuleDepFinder()
    # test with dummmy value
    obj.scan_exec_script(name="name")
    # Validating the type of `name`
    assert isinstance(name, str)
    # Test for the actual output vs expected
    assert obj.exec_scripts == {'name': b'\n'}
    # Test for the actual output vs expected
    assert obj.ps_modules == {'Ansible.ModuleUtils.Common': {'data': b'#', 'path': 'name'}}

# Generated at 2022-06-10 23:27:43.031706
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Unit test for method scan_exec_script of class PSModuleDepFinder
    # Arrange
    organization = "Ansible"
    module_name = "Ansible.ModuleUtils.AzureRM.NetApp"
    mu_path = os.path.join(C.DEFAULT_MODULE_UTILS_PATH, "powershell", "AzureRM.NetApp.psm1")
    ps_module_util = PSModuleDepFinder()
    # Act
    ps_module_util.scan_exec_script(module_name)
    # Assert
    assert module_name in ps_module_util.ps_modules.keys()
    # Assert
    assert mu_path == ps_module_util.ps_modules[module_name]["path"]



# Generated at 2022-06-10 23:27:54.504556
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    depfinder = PSModuleDepFinder()
    depfinder.scan_module(" # ANsibleRequires -powershell template")
    assert depfinder.ps_modules is not None
    assert depfinder.ps_modules.get('Ansible.Template', None) is not None
    assert depfinder.cs_utils_module is None
    assert depfinder.cs_utils_wrapper is None
    data = depfinder.ps_modules.get('Ansible.Template')
    assert data
    content = data.get('data')
    assert content
    assert content.find(b"function template_from_file") > 0


# Generated at 2022-06-10 23:28:04.705290
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import mock
    x = PSModuleDepFinder()
    a = mock.Mock()
    a.group.side_effect = ["Filename"]
    test_fqn="valid_fqn"
    def side_effect(*args, **kwargs):
        if args[1] == ".cs":
            return True
        return False
    with mock.patch("ansible.module_utils.common._load_params", return_value={'a': "2"}):
        with mock.patch.object(PSModuleDepFinder, '_add_module', side_effect=side_effect):
            with mock.patch("ansible.module_utils.common._load_params",  return_value={'a': "2"}):
                with mock.patch("pkgutil.get_data", return_value="data"):
                    x.scan

# Generated at 2022-06-10 23:28:38.721756
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Test function scan_exec_script
    '''
    finder = PSModuleDepFinder()
    scirpt_name = 'test_script'
    finder.scan_exec_script(scirpt_name)
    assert(finder.exec_scripts[scirpt_name])

# Generated at 2022-06-10 23:28:42.363374
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dep_finder = PSModuleDepFinder()
    ps_dep_finder.scan_exec_script('win_template')
    assert 'win_template' in ps_dep_finder.exec_scripts

# Generated at 2022-06-10 23:28:54.261949
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """ Unit test for method scan_exec_script of class PSModuleDepFinder """
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    # pylint: disable=unused-variable
    # pylint: disable=attribute-defined-outside-init

    def test_load_powershell_script(self, name, module_path=None):
        ''' Used as a mock for load_powershell_script. We don't actually care about
            the internal module loading, just that scan_exec_script is called. '''
        self.find_module_deps.scan_exec_script(name)

    # we want to test that this calls scan_exec_script with the module name

# Generated at 2022-06-10 23:29:05.255460
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    # Create the module.
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    def _find_module(name):
        return (name, "not found")

    def _find_plugin(name, ext):
        return None

    # Create the loader.
    loader = DataLoader()

    # Setup the module utility finder.
    module._load_powershell_module = lambda *args, **kwargs: None
    module._load_powershell_module_support = _find_module
    module._find_powershell_module_by_path = lambda *args, **kwargs: None

    # Setup the module plugin finder.


# Generated at 2022-06-10 23:29:15.710908
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from ansible.module_utils.common.text.converters import to_text
    from ansible.plugins.loader._module_utils_loader import get_ps_module_utils_path
    from ansible.utils.collection_loader import _get_collection_fqn
    import os
    import re
    import sys
    import tempfile
    import textwrap
    from tempfile import TemporaryDirectory

    def create_script(path, source):
        with open(path, "w") as f:
            f.write(to_text(source))


# Generated at 2022-06-10 23:29:16.099776
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:29:19.238365
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_module = lambda x,y: x
    finder.scan_exec_script('a')
    assert finder.exec_scripts['a'] == "a"
    

# Generated at 2022-06-10 23:29:30.895164
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # data to be mocked out
    finder = PSModuleDepFinder()
    name = 'name'
    n_resource_name = to_native(name + '.ps1')
    b_data = b'b_data'
    
    # mocking out
    with patch("ansible.module_utils.powershell.dep_finder.pkgutil.get_data") as get_data:
        get_data.return_value = b_data
        with patch("ansible.module_utils.powershell.dep_finder.PSModuleDepFinder.scan_module") as scan_module:
            # execution
            finder.scan_exec_script(name)
            
            # validation
            assert name in finder.exec_scripts.keys()
            assert finder.exec_scripts[name] == b_data

# Generated at 2022-06-10 23:29:33.564101
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.scan_exec_script('ping')


# Generated at 2022-06-10 23:29:37.040930
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("CommonWrapper")
    assert len(finder.exec_scripts.keys()) == 1
    assert len(finder.ps_modules.keys()) == 1



# Generated at 2022-06-10 23:29:57.717179
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test scan_exec_script of class PSModuleDepFinder."""
    # add a script
    data = pkgutil.get_data("ansible.executor.powershell", "test.ps1")
    b_data = to_bytes(data)
    # remove comments to reduce the payload size in the exec wrappers
    exec_script = _strip_comments(b_data)
    assert exec_script == b'{\n    return "test"\n}\n'


# Generated at 2022-06-10 23:30:05.336800
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:30:09.752069
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test PSModuleDepFinder.scan_exec_script"""
    ps_module_dep_finder = PSModuleDepFinder()
    assert ps_module_dep_finder is not None

    ps_module_dep_finder.scan_exec_script('power_shell')
    assert ps_module_dep_finder is not None


# Generated at 2022-06-10 23:30:13.470904
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('Testing scan_exec_script of class PSModuleDepFinder')
    P = PSModuleDepFinder()
    P.scan_exec_script('connect')
    assert 'connect' in  P.exec_scripts


# Generated at 2022-06-10 23:30:23.529128
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create instance of class PSModuleDepFinder
    finder = PSModuleDepFinder()
    # call the method scan_exec_script
    finder.scan_exec_script("ansible_powershell_common")
    finder.scan_exec_script("ansible_powershell_common")
    # check the instance variables were set properly
    assert finder.exec_scripts["ansible_powershell_common"][:10] == "#Requires -"
    assert len(finder.cs_utils_wrapper.keys()) == 1
    assert list(finder.cs_utils_wrapper.keys())[0] == "Ansible.ModuleUtils.Common"
    

# Generated at 2022-06-10 23:30:26.756537
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('Pester')
    assert('Pester' in finder.exec_scripts.keys())


# Generated at 2022-06-10 23:30:31.346550
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test to scan lib/ansible/executor/powershell for scripts used in the module exec side
    """
    module = PSModuleDepFinder()
    name = 'common'
    assert module.scan_exec_script(name) is None
    module._add_module("Ansible.ModuleUtils.Common", ".psm1", "Ansible.ModuleUtils.Common", False, False)

# Generated at 2022-06-10 23:30:43.078228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    # no need to test with debug turned on or else we'll get the comments
    C.DEFAULT_DEBUG = False

    # load the script. It's the powershell script in the same directory as this
    # file that has the same name except with a .ps1 extension
    test_script = os.path.abspath(__file__)
    test_script = os.path.splitext(test_script)[0] + '.ps1'
    with open(test_script, "rb") as f:
        script_data = to_bytes(f.read(), errors='surrogate_or_strict')

    # this script is used directly by the powershell module in order to ensure
    # we have the latest version from this module, we add it here.

# Generated at 2022-06-10 23:30:46.966676
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The `self` parameter of this method is actually the test case
    if getattr(self, "ps_module_dep_finder_instance", None) is None:
        self.ps_module_dep_finder_instance = PSModuleDepFinder()
    return self.ps_module_dep_finder_instance.scan_exec_script("test_exec_script")


# Generated at 2022-06-10 23:30:57.940280
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This method is basically only used in the test
    finder = PSModuleDepFinder()
    finder.scan_exec_script('PowershellExecutor')
    assert finder.exec_scripts['PowershellExecutor'].startswith(b'''# This script is used to call powershell modules from the module''')
    assert 'PowershellExecutor' in finder.exec_scripts
    assert 'PowershellExecutor' in finder.ps_modules
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1
    exec_psm1_path = finder.ps_modules['PowershellExecutor']['path']

# Generated at 2022-06-10 23:31:15.815549
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('Running ' + __file__ + '...')
    f = PSModuleDepFinder()
    f.scan_exec_script('core')
    f.scan_exec_script('corev2')
    print('Success!')


# Generated at 2022-06-10 23:31:23.455052
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script(): #IGNORE:C01111
    data = pkgutil.get_data("ansible.executor.powershell", to_native("basic.ps1"))
    assert data is not None
    assert data.find("Test-Path") > -1
    assert data.find("# comment") == -1

    data = pkgutil.get_data("ansible.executor.powershell", to_native("basic_no_strip.ps1"))
    assert data is not None
    assert data.find("# comment") > -1

# Generated at 2022-06-10 23:31:26.441526
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # a = PSModuleDepFinder()
    # a.scan_exec_script(name)
    assert True



# Generated at 2022-06-10 23:31:28.062744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    a = PSModuleDepFinder()
    a.scan_exec_script("windows")


# Generated at 2022-06-10 23:31:37.582592
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Type stub for mock_module_utils_loader.find_plugin
    def find_plugin(name, ext):
        return ("plugins/%s.psm" % name)

    # Type stub for mock_suppress_warnings
    def suppress_warnings(method):
        def wrapper(*args, **kwargs):
            return method(*args, **kwargs)
        return wrapper

    test_module_name = "pstestmodule"
    test_module_data = "TestModuleData"
    test_module_util = "TestModuleUtil"
    test_module_util_data = "TestModuleUtilData"
    test_exec_script_name = "pstestexectest"
    test_exec_script_data = "TestExecScriptData"

# Generated at 2022-06-10 23:31:38.872217
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_loader = PSModuleDepFinder()
    
    test_loader.scan_exec_script('CloudStack')


# Generated at 2022-06-10 23:31:39.814983
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert True

# Generated at 2022-06-10 23:31:47.297163
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script returns the right error when Powershell script is not found
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("script_not_found")
    except AnsibleError as err:
        assert "Could not find executor powershell script for 'script_not_found'" == str(err)

    # Test that scan_exec_script returns the right error when Powershell script is not found
    dep_finder = PSModuleDepFinder()
    try:
        dep_finder.scan_exec_script("script_not_found")
    except AnsibleError as err:
        assert "Could not find executor powershell script for 'script_not_found'" == str(err)

    # Test that scan_exec_script returns the right error when Powershell script is not found


# Generated at 2022-06-10 23:31:47.972626
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	pass

# Generated at 2022-06-10 23:31:59.755981
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    #template1 = "{% import_role 'test' with context %}"
    #expected1 = '{"_ansible_verbose_override": true, "ANSIBLE_FORCE_COLOR": "false", "ANSIBLE_HOST_KEY_CHECKING": "false", "ANSIBLE_SSH_ARGS": "-o UserKnownHostsFile=/dev/null -o IdentitiesOnly=yes -o ControlMaster=auto -o ControlPersist=60s"}'
    #template2 = "{% import_role 'test' with context %}"
    #expected2 = "ansible-playbook -i 'localhost' --extra-vars='ansible_python_interpreter=/usr/bin/python3' 'playbook.yml'"

    worker = PSModuleDepFinder()

    #with open(os.path.join(os.path.dir

# Generated at 2022-06-10 23:32:25.846231
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # clean the object
    finder = PSModuleDepFinder()
    # import the ps1 script
    finder.scan_exec_script("test")
    # check for the script name
    assert("test" in finder.exec_scripts.keys())
    # check for the script content
    assert("test" in to_text(finder.exec_scripts["test"]))
    # check for the required modules
    assert("ansible_collections.test.test.plugins.module_utils.test" in finder.ps_modules.keys())
    # check for the required module content
    assert("test" in to_text(finder.ps_modules["ansible_collections.test.test.plugins.module_utils.test"]["data"]))


# Generated at 2022-06-10 23:32:39.881827
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    unit test for method scan_exec_script of class PSModuleDepFinder,
    ensure that the module_utils are loaded and are running successfully.
    :return: None
    """
    import os
    abs_path = os.path.dirname(os.path.abspath(__file__))

    module_path = os.path.join(abs_path, '..', '..', '..', '..', '..', '..',
                               'lib', 'ansible', 'modules', 'network', 'ios',
                               'ios_facts.ps1')
    dep_finder = PSModuleDepFinder()
    with open(module_path, 'r') as f:
        module_data = f.read()
        dep_finder.scan_module(to_bytes(module_data))

# Generated at 2022-06-10 23:32:41.318465
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert 0 == 1

# Generated at 2022-06-10 23:32:55.611082
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    script_name = "Get-PathInfo"
    executor_ns_script_name = os.path.join("ansible", "executor", "powershell", script_name + ".ps1")
    executor_ns_script_path = resource_from_fqcr(executor_ns_script_name)
    test_dep_finder = PSModuleDepFinder()
    test_dep_finder.scan_exec_script(script_name)
    assert to_bytes(test_dep_finder.exec_scripts[script_name]) == _slurp(executor_ns_script_path)
    assert len(test_dep_finder.ps_modules) == 1
    assert len(test_dep_finder.cs_utils_module) == 0
    assert len(test_dep_finder.cs_utils_wrapper) == 0


# Generated at 2022-06-10 23:33:04.570957
# Unit test for method scan_exec_script of class PSModuleDepFinder