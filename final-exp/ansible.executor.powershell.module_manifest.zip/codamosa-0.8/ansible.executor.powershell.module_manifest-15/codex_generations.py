

# Generated at 2022-06-10 23:23:42.384723
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    # Setup
    pf = PSModuleDepFinder()

# Generated at 2022-06-10 23:23:43.276117
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:23:54.193033
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.plugins.loader import ps_module_loader
    from ansible.plugins.loader import module_loader

    m = ps_module_loader.find_plugin("stdlib.network.os.win_uri", ".psm1")
    data = _slurp(m)

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(data)

    assert "Ansible.ModuleUtils.Common" in dep_finder.ps_modules.keys()
    assert "Ansible.ModuleUtils.Common" not in dep_finder.cs_utils_wrapper.keys()
    assert "Ansible.ModuleUtils.Common" not in dep_finder.cs_utils_module.keys()
    assert "Ansible.ModuleUtils.URI" in dep_finder.ps_modules.keys()


# Generated at 2022-06-10 23:23:57.534879
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("ansible_module_pwsh_wrapper")


# Generated at 2022-06-10 23:24:10.462098
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    result = PSModuleDepFinder().scan_module(
        b'#Requires -Version 3.0\n#Requires -Module Ansible.ModuleUtils.Common\n#Requires -Module Ansible.ModuleUtils.Nunjucks')
    assert result == {
        'Ansible.ModuleUtils.Common': {
            'data': b'# dummy test data for Ansible.ModuleUtils.Common',
            'path': 'lib/ansible/module_utils/common.psm1',
        },
        'Ansible.ModuleUtils.Nunjucks': {
            'data': b'# dummy test data for Ansible.ModuleUtils.Nunjucks',
            'path': 'lib/ansible/module_utils/nunjucks.psm1',
        }
    }


# Generated at 2022-06-10 23:24:15.823205
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu_finder = PSModuleDepFinder()
    mu_finder.scan_exec_script("ansible_powershell")
    assert "ansible_powershell" in mu_finder.exec_scripts
    assert "ansible.module_utils.common.network.common.wait_for" in mu_finder.ps_modules


# Generated at 2022-06-10 23:24:19.179429
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_dep_finder = PSModuleDepFinder()
    # call the method
    mod_data = module_dep_finder.scan_exec_script("common.ps1")


# Generated at 2022-06-10 23:24:23.495859
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("Common")
    # check that it is a returning None
    assert finder.scan_exec_script("Common") is None
    # check that scan_exec_script("Common") is a returning None
    assert finder.scan_exec_script("Common") is None

# Generated at 2022-06-10 23:24:24.098418
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:24:25.653361
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:24:39.959109
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "TODO: Implement the unit test"  # remove this line and write the code



# Generated at 2022-06-10 23:24:42.676245
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("script")
    assert dep_finder.exec_scripts["script"] == ""



# Generated at 2022-06-10 23:24:47.925444
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #Test to verify with input value

    import ansible.executor.powershell as powershell
    with patch.object(powershell, 'get_data', return_value=Mock(return_value='{}')):
        assert PSModuleDepFinder().scan_exec_script('test_file')



# Generated at 2022-06-10 23:24:56.735669
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.compat import mock
    from ansible.module_utils import powershell
    from ansible.module_utils.powershell.powerstate import PowerState
    from ansible.module_utils.powershell import win_psmodulepath

    def _slurp_mock(name):
        return mock.Mock()

    finder = PSModuleDepFinder()
    finder.scan_exec_script('PowerState')
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 1



# Generated at 2022-06-10 23:24:57.709017
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO remove this
    pass

# Generated at 2022-06-10 23:25:05.334478
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of PSModuleDepFinder
    psmdf = PSModuleDepFinder()
    # create a random file name
    rand_name = "".join(random.sample(string.ascii_letters, 16))
    # call the method scan_exec_script with random name
    # as this name is not present in ansible.executor.powershell directory,
    # it raises AnsibleError exception
    with pytest.raises(AnsibleError) as err:
        psmdf.scan_exec_script(rand_name)
    assert err.value.message.startswith("Could not find executor powershell script for")

# Generated at 2022-06-10 23:25:09.177878
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(name='found')
    print('finder.exec_scripts:', type(finder.exec_scripts), len(finder.exec_scripts))

# Generated at 2022-06-10 23:25:16.489287
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Instantiate a PSModuleDepFinder object
    x = PSModuleDepFinder()
    # Assert x is a PSModuleDepFinder object
    assert isinstance(x, PSModuleDepFinder)
    # Assert x.scan_exec_script('exec_wrapper')
    # asserts that exec_wrapper is a powershell script
    try:
        x.scan_exec_script('exec_wrapper')
    except AnsibleError:
        pass


# Generated at 2022-06-10 23:25:20.108347
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        module_finder.scan_exec_script("doesn't exist")


# Generated at 2022-06-10 23:25:22.338379
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    return f.scan_exec_script('Microsoft.PowerShell.Core')



# Generated at 2022-06-10 23:25:36.021693
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert None  # Not implemented



# Generated at 2022-06-10 23:25:50.548930
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    This unit test will test the scan_exec_script method of PSModuleDepFinder
    class.

    :return:
    """

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('basic')
    assert len(dep_finder.exec_scripts.keys()) == 1
    assert len(dep_finder.ps_modules) == 0
    assert len(dep_finder.cs_utils_module) == 0
    assert len(dep_finder.cs_utils_wrapper) == 0
    assert dep_finder.become is False

    dep_finder.scan_exec_script('basic')
    assert len(dep_finder.exec_scripts.keys()) == 1
    assert len(dep_finder.ps_modules) == 0

# Generated at 2022-06-10 23:26:02.691384
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from tests.unit.base_fixtures import exec_script_stubs

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.cs_utils_wrapper = exec_script_stubs['cs_utils']

    ps_module_dep_finder.scan_exec_script('win_copy')
    ps_module_dep_finder.scan_exec_script('win_copy')

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.cs_utils_wrapper = exec_script_stubs['cs_utils']
    ps_module_dep_finder.scan_exec_script('win_copy')
    ps_module_dep_finder.scan_exec_script('win_copy')

# Generated at 2022-06-10 23:26:09.587325
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = pkgutil.get_data("ansible.plugins.modules", to_native("my_testmodule.ps1"))
    assert finder.scan_module(module_data) is None
    assert finder.ps_modules is not None
    assert len(finder.ps_modules) >= 2
    sorted_ps_modules = sorted(finder.ps_modules.keys())
    assert sorted_ps_modules[0] == 'Ansible.ModuleUtils.Common.Errors'
    assert sorted_ps_modules[1] == 'Ansible.ModuleUtils.Common.Info'
    assert sorted_ps_modules[2] == 'Ansible.ModuleUtils.Common.Net'

# Generated at 2022-06-10 23:26:12.788574
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.powershell.executor import PSModuleDepFinder
    p = PSModuleDepFinder()
    p.scan_exec_script(b'connect-WSMan')


# Generated at 2022-06-10 23:26:21.722534
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:26:30.822131
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_test_inst = PSModuleDepFinder()
    # Find exec scripts by path
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_common")
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_winrm")
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_sysnative")
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_invoke_command")
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_invoke_script")
    PSModuleDepFinder_test_inst.scan_exec_script("ansible_powershell_copy_file")
    PSModuleDepFinder_test_

# Generated at 2022-06-10 23:26:31.988758
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-10 23:26:39.439958
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    data = '''
#Requires -Module Ansible.ModuleUtils.Something
#Requires -Module Ansible.ModuleUtils.SomethingElse
#AnsibleRequires -PowerShell ansible_collections.cisco.ios.plugins.module_utils.something
#AnsibleRequires -Powershell ansible_collections.cisco.ios.plugins.module_utils.something_else
#AnsibleRequires -CSharpUtil ansible_collections.cisco.ios.plugins.module_utils.something
#AnsibleRequires -CSharpUtil ansible_collections.cisco.ios.plugins.module_utils.something_else
'''
    test_fqn = 'ansible_collections.cisco.ios.plugins.modules.test_module'
    dep_finder = PSModuleDepFinder()
    dep_finder.scan

# Generated at 2022-06-10 23:26:51.511678
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup
    fqcr = 'ansible.builtin.ec2_snapshot'
    ps_module_dep_finder = PSModuleDepFinder()

    # Exercise
    ps_module_dep_finder.scan_module(fqcr)

    # Verify
    assert len(ps_module_dep_finder.ps_modules) == 3
    assert len(ps_module_dep_finder.cs_utils_module) == 0
    assert len(ps_module_dep_finder.exec_scripts) == 0

    assert "Ansible.ModuleUtils.Common" in ps_module_dep_finder.ps_modules
    assert "Ansible.ModuleUtils.Ec2" in ps_module_dep_finder.ps_modules
    assert "Ansible.ModuleUtils.Compression" in ps_module_dep_finder

# Generated at 2022-06-10 23:27:14.579456
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: NOTE: This test was made before the introduction of the _re_wrapper regex and the script may need to be updated
    # create a simple test script with a single dependency
    test_script = b"""
# Requires -Modules Ansible.ModuleUtils.Something
# Requires -Modules PowerShellGet
# http://(.*)/something"""

    test_script_path = os.path.join(C.DEFAULT_LOCAL_TMP, b"ansible_test_exec_script.ps1")

    with open(test_script_path, 'wb') as f:
        f.write(test_script)

    # create an instance of the dependency finder to test with
    dep_finder = PSModuleDepFinder()

    # scan the test script and check the result

# Generated at 2022-06-10 23:27:21.801378
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_module_with_ps_utils = """
#Requires -Module Ansible.ModuleUtils.foo

function test {
    #Requires -Module Ansible.ModuleUtils.bar
    return $true
}

function other_test {
    #Requires -Module Ansible.ModuleUtils.baz
}

#Requires -Module Ansible.ModuleUtils.foo

#Requires -Module Ansible.ModuleUtils.bar

#Requires -Module Ansible.ModuleUtils.baz
"""

# Generated at 2022-06-10 23:27:23.391713
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "Not implemented."



# Generated at 2022-06-10 23:27:28.999987
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for AnsibleError exception for not found executor powershell script
    with pytest.raises(AnsibleError) as e_info:
        PSModuleDepFinder().scan_exec_script('not_exist')
    assert to_text(e_info.value).startswith("Could not find executor powershell script for")



# Generated at 2022-06-10 23:27:30.956780
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("test_name")

# Generated at 2022-06-10 23:27:31.678073
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:27:42.495238
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell as executor_powershell
    class PSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            self.exec_scripts = dict()
            # scan lib/ansible/executor/powershell for scripts used in the module
            # exec side. It also scans these scripts for any dependencies
            name = "ps_invoke_powershell"
            data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
            if data is not None:
                b_data = to_bytes(data)
                # remove comments to reduce the payload size in the exec wrappers
                if C.DEFAULT_DEBUG:
                    exec_script = b_data

# Generated at 2022-06-10 23:27:43.305768
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
	pass

# Generated at 2022-06-10 23:27:53.775800
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class PSModuleDepFinder_test_scan_exec_script(object):
        def scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
            return

        def scan_exec_script(self, name):
            return name
    test_obj = PSModuleDepFinder_test_scan_exec_script()
    script_name = 'test_scan_exec_script'
    assert script_name == test_obj.scan_exec_script(script_name)


# Generated at 2022-06-10 23:27:54.460540
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:28:08.730471
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = "name"
    assert False

# Generated at 2022-06-10 23:28:19.152817
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class TestPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self, ps_modules, cs_utils_module, cs_utils_wrapper, ps_version, os_version, become):
            super(TestPSModuleDepFinder, self).__init__()
            self.ps_modules = ps_modules
            self.cs_utils_module = cs_utils_module
            self.cs_utils_wrapper = cs_utils_wrapper
            self.ps_version = ps_version
            self.os_version = os_version
            self.become = become


# Generated at 2022-06-10 23:28:30.145553
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.One\n#Requires -Module Ansible.ModuleUtils.Two')
    assert to_text(dep_finder.ps_modules[u"Ansible.ModuleUtils.One"]['data'])
    assert to_text(dep_finder.ps_modules[u"Ansible.ModuleUtils.Two"]['data'])
    assert isinstance(dep_finder.ps_modules[u"Ansible.ModuleUtils.One"]['path'], str)
    assert isinstance(dep_finder.ps_modules[u"Ansible.ModuleUtils.Two"]['path'], str)

# Generated at 2022-06-10 23:28:33.711425
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder.exec_scripts['ns'] = 'util data'

    depFinder.scan_exec_script('ns')
    assert 'ns' in depFinder.exec_scripts.keys()


# Generated at 2022-06-10 23:28:46.092108
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    module_data_1 = """#This is a comment
#Requires -Version 2.0
#Requires -Module Ansible.ModuleUtils.MyUtil
using ansible_collections.foo.bar.plugins.module_utils.MyUtil;
using Ansible.ModuleUtils.MyUtil;
# using Ansible.ModuleUtils.SomeUtil
"""
    module_data_2 = """#This is a comment
#Requires -Version 2.0
#Requires -Module Ansible.ModuleUtils.AnotherUtil
using ansible_collections.foo.bar.plugins.module_utils.MyUtil;
"""
    #module_data_3 = """
#AnsibleRequires -PowerShell Ansible.ModuleUtils.SomeUtil-Optional
#AnsibleRequires -PowerShell ansible_collections.foo.bar.plugins.

# Generated at 2022-06-10 23:28:56.538563
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create fixture
    psmodf = PSModuleDepFinder()

# Generated at 2022-06-10 23:29:09.004439
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    folder_name = os.path.join(os.path.dirname(__file__), 'test_data', 'module_utils')
    module_utils = []
    ps_modules = []
    sources = os.listdir(folder_name)
    for source in sources:
        if source.endswith('.psm1'):
            ps_modules.append(source)
        if source.endswith('.py'):
            module_utils.append(source)
    for module_util in module_utils:
        module_name = os.path.splitext(module_util)[0]
        ps_module_name = "%s.psm1" % module_name 
        ps_path = os.path.join(folder_name, ps_module_name)

# Generated at 2022-06-10 23:29:15.708689
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Scripts are used to execute the module on the target
    # When a script is imported from a script, then scan that as well
    obj = PSModuleDepFinder()

    # Check if all the modules are in the required paths
    obj.scan_exec_script("TestScript")
    assert "TestScript" in obj.exec_scripts
    assert "TestScriptData" in obj.exec_scripts["TestScript"]
    assert "TestScriptIncludedOne" in obj.exec_scripts
    assert "TestScriptIncludedTwo" in obj.exec_scripts



# Generated at 2022-06-10 23:29:19.989474
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  # Test 1: invalid name
  finder = PSModuleDepFinder()
  assert failing_test(test_name="test_PSModuleDepFinder_scan_exec_script", exception=AnsibleError, 
                      method=finder.scan_exec_script, name="fake.ps1") is True
  # Test 2: valid name
  assert finder.scan_exec_script(name="ansible_psmodule.ps1") is None

# Generated at 2022-06-10 23:29:22.138696
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    scan_exec_script = PSModuleDepFinder().scan_exec_script

    # TODO: write test


# Generated at 2022-06-10 23:29:41.512563
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script of class PSModuleDepFinder
    finder = PSModuleDepFinder()
    finder.scan_exec_script("BinaryFile")
    finder.scan_exec_script("BinaryFile")
    assert len(finder.exec_scripts.keys()) == 1
    assert finder.exec_scripts["BinaryFile"].startswith(b'function Start-BinaryFile')



# Generated at 2022-06-10 23:29:42.533204
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:29:52.427621
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    try:
        importlib.import_module("microsoft.powershell.core")
    except ImportError:
        return


# Generated at 2022-06-10 23:29:59.126406
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('powershell.psm1')
    assert len(finder.exec_scripts) == 1
    assert finder.exec_scripts.keys()[0] == 'powershell'
    finder.scan_exec_script('powershell')
    assert len(finder.exec_scripts) == 1
    assert finder.exec_scripts.keys()[0] == 'powershell'


# Generated at 2022-06-10 23:30:08.641133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import tempfile

    test_script_name = "mytestscript"
    test_script_data = "#AnsibleRequires -CSharpUtil Ansible.Util;\n"
    test_script_path = os.path.join(tempfile.gettempdir(), test_script_name + '.ps1')
    with open(test_script_path, 'w') as test_script_fd:
        test_script_fd.write(test_script_data)
    test_dep_finder = PSModuleDepFinder()
    test_dep_finder.scan_exec_script(test_script_name)
    assert(test_script_name in test_dep_finder.exec_scripts)
    assert(test_dep_finder.cs_utils_wrapper["Ansible.Util"] is not None)



# Generated at 2022-06-10 23:30:13.470372
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("Become")

    assert 'become' in ps_module_dep_finder.exec_scripts
    assert ps_module_dep_finder.exec_scripts['become'] is not None



# Generated at 2022-06-10 23:30:25.274185
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("test_PSModuleDepFinder_scan_module")
    from ansible.module_utils.six import b

# Generated at 2022-06-10 23:30:36.451849
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    finder.scan_module(b'#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo.Bar')
    finder.scan_module(b'#AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.Foo.Bar')
    finder.scan_module(b'#AnsibleRequires -PowerShell ..module_utils.Foo.Bar')
    with pytest.raises(AnsibleError):
        finder.scan_module(b'#AnsibleRequires -PowerShell Something.Missing')
    finder.scan_module(b'#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.Foo.Bar -Optional')
    finder.scan_module

# Generated at 2022-06-10 23:30:38.848447
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PD = PSModuleDepFinder()
    PD.scan_exec_script('test')
    assert PD.exec_scripts


# Generated at 2022-06-10 23:30:48.111693
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:31:01.445228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    #TODO:
    #tests


# Generated at 2022-06-10 23:31:04.064381
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmdf = PSModuleDepFinder()
    psmdf.scan_exec_script("win_copy_module")
    assert "win_copy_module" in psmdf.exec_scripts

# Generated at 2022-06-10 23:31:07.864360
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmodule = PSModuleDepFinder()
    psmodule.scan_exec_script("paramiko_4x_wrapper")

    assert psmodule.exec_scripts["paramiko_4x_wrapper"] is not None
    assert psmodule.cs_utils_wrapper["ansible.module_utils.common.network.module_utils.paramiko_4x.paramiko_4x"] is not None


# Generated at 2022-06-10 23:31:08.470247
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:31:14.360874
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # setup
    finder = PSModuleDepFinder()
    args = [
        "ansible.module_utils.powershell.basic",
        "ansible_collections.ansible.builtin.plugins.module_utils.basic",
    ]

    # test
    for arg in args:
        finder.scan_exec_script(arg)

    # assert
    assert(arg in finder.exec_scripts.keys())
    assert(arg in finder.cs_utils_wrapper.keys())


# Generated at 2022-06-10 23:31:26.058473
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md_finder = PSModuleDepFinder()
    md_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Foo\n')
    assert 'Ansible.ModuleUtils.Foo' in md_finder.ps_modules
    md_finder = PSModuleDepFinder()
    md_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Foo\n#Requires -Module Ansible.ModuleUtils.Bar\n')
    assert 'Ansible.ModuleUtils.Foo' in md_finder.ps_modules
    assert 'Ansible.ModuleUtils.Bar' in md_finder.ps_modules
    md_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:31:26.911638
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

# Generated at 2022-06-10 23:31:30.489591
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    assert len(PSModuleDepFinder().scan_exec_script("TestExec")) == 0


# Generated at 2022-06-10 23:31:36.691931
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # teardown the finder
    sys.modules.pop('ansible.plugins.loader', None)
    sys.modules.pop('ansible.module_utils.basic', None)
    # setup the finder
    imp.reload(ps_module_utils_loader)
    # create the finder
    dep_finder = PSModuleDepFinder()
    # create a module
    module_name = 'basic'

# Generated at 2022-06-10 23:31:45.356062
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder._add_module = MagicMock()
    dep_finder.scan_module = MagicMock()

    dep_finder.scan_exec_script('Helper')
    dep_finder.scan_module.assert_called_once_with(ANY, fqn=None, wrapper=True, powershell=True)
    dep_finder._add_module.assert_called_once_with(ANY, ext='.psm1', fqn=None, optional=False, wrapper=False)

    dep_finder.scan_exec_script('Helper')
    dep_finder.scan_module.assert_called_once_with(ANY, fqn=None, wrapper=True, powershell=True)
    assert dep_finder._add_module.call_count == 1
    assert dep_

# Generated at 2022-06-10 23:32:15.417833
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ansible.module_utils._text")
    assert "ansible.module_utils._text" in finder.exec_scripts


# Generated at 2022-06-10 23:32:26.338570
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class TestException(Exception):
        pass
    # test_module contains these lines:
    # #AnsibleRequires -PowerShell ansible_collections.microsoft.powershell.module_utils.ansible_release_module
    # #AnsibleRequires -CSharpUtil ansible_collections.microsoft.test_module.plugins.module_utils.test_module
    # using Ansible.ModuleUtils.CommonUtils;
    modules_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'units', 'module_utils',
                                'powershell')
    test_module_data = _slurp(os.path.join(modules_path, 'test_module.psm1'))
    test_module_util_data = _sl

# Generated at 2022-06-10 23:32:28.769949
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Implement tests for PSModuleDepFinder.scan_module
    assert False



# Generated at 2022-06-10 23:32:39.613000
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Scan the executor scripts for dependencies

    # If a non-existing script is specified, it raises an error and exits
    try:
        PSModuleDepFinder().scan_exec_script('foo')
    except Exception as e:
        assert str(e) == "Could not find executor powershell script for 'foo'"

    # If a script is not used, it is not added to the list of scripts
    ps_deps = PSModuleDepFinder()
    ps_deps.scan_exec_script('basic_main')
    assert (len(ps_deps.exec_scripts) == 0)



# Generated at 2022-06-10 23:32:47.929860
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    inv_path = os.path.join(os.path.dirname(__file__), "data/PSModuleDepFinder")
    inv = _get_inventory(inv_path)
    # host_file is not used
    host_file = os.path.join(inv_path, "hosts")
    play_context = _get_play_context(inv, host_file)
    options = inv._options
    loader = _get_loader(options)

    try:
        PSModuleDepFinder().scan_exec_script(name='win_package_facts')

        PSModuleDepFinder().scan_exec_script(name='core')
    except AnsibleError as e:
        assert False, e



# Generated at 2022-06-10 23:32:54.352972
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Create a python object to host the results
    results = {'errors': set(), 'warnings': set()}

    # Create a python object to host the deps finder
    f = PSModuleDepFinder()

    # Create python objects to host the bytes data of the module_utils
    native_win_module_util = b'This is a native module_util'
    ps_module_util = b'This is a ps module_util'
    csharp_module_util = b'This is a csharp module_util'
    csharp_module_util_in_ps_module = b'This is a csharp module_util in ps module'
    csharp_module_util_in_csharp_module = b'This is a csharp module_util in csharp module'

    # Populate the bytes data of the module_utils in

# Generated at 2022-06-10 23:33:02.509067
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.exec_scripts == {}
    assert finder.ps_modules == {}
    finder.scan_exec_script('Common')
    assert finder.exec_scripts != {}
    assert finder.ps_modules != {}
    assert 'Common' in finder.ps_modules
    assert 'Common' in finder.exec_scripts
    assert finder.ps_modules['Common']['data'] == finder.exec_scripts['Common']
    assert len(finder.exec_scripts['Common']) >= 1
