

# Generated at 2022-06-10 23:23:44.874414
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pytest
    import yaml
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes

    # Scan the current ps wrapper to find all the non-standard modules we use
    # and also scan those modules to find their own module_util deprecencies.
    ps_wrapper = to_bytes(pkgutil.get_data('ansible.executor.powershell', 'executor.ps1'))
    finder = PSModuleDepFinder()
    # Get the modules the executor requires.
    finder.scan_module(ps_wrapper, wrapper=True)
    # Get the modules the modules require.
    for exec_name in finder.exec_scripts.keys():
        finder.scan_module(ps_wrapper, wrapper=True)
    executor_modules = finder.ps

# Generated at 2022-06-10 23:23:50.404117
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import ansible.plugins.loader as plugin_loader
    import ansible.executor.powershell as ps_exec
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes

    # we want to pick up any plugin changes
    plugin_loader.add_directory(C.DEFAULT_MODULE_UTILS_PATH)
    ps_exec.ps_module_utils_loader.add_directory(C.DEFAULT_MODULE_UTILS_PATH)


# Generated at 2022-06-10 23:23:54.443025
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    power_shell_module_dep_finder = PSModuleDepFinder()
    power_shell_module_dep_finder.scan_exec_script('example')



# Generated at 2022-06-10 23:23:59.030422
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = '#AnsibleRequires -GetWinOsInfo'
    finder = PSModuleDepFinder()
    finder.scan_exec_script(module_data)
    assert len(finder.exec_scripts) > 0


# Generated at 2022-06-10 23:23:59.808358
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    return None



# Generated at 2022-06-10 23:24:05.466124
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("shell")
    assert len(finder.exec_scripts) == 1
    assert isinstance(finder.exec_scripts["shell"], bytes)
    assert len(finder.exec_scripts["shell"]) > 0


# Generated at 2022-06-10 23:24:14.748660
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.process import get_bin_path
    ps_exe = get_bin_path('powershell.exe')
    if not ps_exe:
        raise AnsibleError('Powershell is not installed')
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.ExampleUtils1')
    ps_module_finder.scan_exec_script('wrap_async', b'#Requires -Module Ansible.ModuleUtils.ExampleUtils2')
    

# Generated at 2022-06-10 23:24:16.264177
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True



# Generated at 2022-06-10 23:24:17.579479
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:24:24.170541
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("*****in test*****")
    """ Test case for method scan_module of class PSModuleDepFinder """
    # FIXME: desiderata, create a mock of module_data and other parameters
    # TODO: replace this mock with a real test
    result = PSModuleDepFinder().scan_module(None)
    assert result == None


# Generated at 2022-06-10 23:24:51.237843
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import mock
    import ansible
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-10 23:24:57.477038
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # We use a specific output loader for unit tests since we want the module_utils
    # recursively processed and the normal method used for module_utils is too strict
    # for our unit tests.
    p = PSModuleDepFinder()
    p.scan_exec_script('basic')
    assert 'basic' in p.exec_scripts
    assert 'add_host' in p.cs_utils_wrapper



# Generated at 2022-06-10 23:24:59.888264
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert "UpdateScriptInfo.ps1" in PSModuleDepFinder().scan_exec_script()

# Generated at 2022-06-10 23:25:02.622566
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder is not None

    name = "shell"
    finder.scan_exec_script(name)
    assert name in finder.exec_scripts



# Generated at 2022-06-10 23:25:14.238106
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a module wrapper

    test_module_dep_finder = PSModuleDepFinder()
    test_module_dep_finder.ps_modules = {"Ansible.ModuleUtils.CommonUtils.psm1": {"path": "path_to_module1_module_util",
                                                                                "data": "Foo"}}
    test_module_dep_finder.cs_utils_module = {"Ansible.ModuleUtils.CommonUtils.cs": {"path": "path_to_module2_module_util",
                                                                                     "data": "Foo"}}
    test_module_dep_finder.cs_utils_wrapper = {}
    test_module_dep_finder.exec_scripts = {}

# Generated at 2022-06-10 23:25:23.179770
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize PSModuleDepFinder object with an empty dictionary
    testPSModuleDep = PSModuleDepFinder()
    testPSModuleDep.exec_scripts = dict()
    testPSModuleDep.cs_utils_wrapper = dict()

    # Find a valid powershell script
    testPSModuleDep.scan_exec_script("common_exec")

    # Check the output is as expected, given the common_exec.ps1 script has no dependencies
    assert len(testPSModuleDep.exec_scripts) == 1
    assert len(testPSModuleDep.cs_utils_wrapper) == 1



# Generated at 2022-06-10 23:25:25.337196
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = 'py_noop'
    result = PSModuleDepFinder().scan_exec_script(name)
    assert result is None
    assert result == {}


# Generated at 2022-06-10 23:25:28.494744
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script("basic")
    assert f.exec_scripts["basic"] == to_bytes(b"function cmd_wrapper") 
    

# Generated at 2022-06-10 23:25:41.128610
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Setup
    ps_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:25:52.876100
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    test_object = PSModuleDepFinder()

    test_string = "Test String"
    test_string_bytes = b"Test String"
    test_module_name = "Test Module"
    test_module_name_bytes = b"Test Module"
    test_module_string = "test string"
    test_module_string_bytes = b"test string"
    test_file_name = "Test File"
    test_file_content = "Test File Content"
    test_file_path = "Test File Path"

    # creating mocks
    # pkgutil.get_data
    get_data = mock.Mock(name="get_data")
    get_data.side_effect = [test_file_content, test_module_string]
    pkgutil.get_data = get_data
    

# Generated at 2022-06-10 23:26:13.256154
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # assert scan_module for powershell modules
    ps_md = PSModuleDepFinder()
    ps_md.scan_module(b"#Requires -Module Ansible.ModuleUtils.Foo.Bar")
    assert 'Ansible.ModuleUtils.Foo.Bar' in ps_md.ps_modules.keys()
    assert not ps_md.cs_utils_module
    assert not ps_md.cs_utils_wrapper
    assert not ps_md.exec_scripts

    ps_md = PSModuleDepFinder()
    ps_md.scan_module(b"#AnsibleRequires -PowerShell Ansible.ModuleUtils.Foo.Bar")
    assert 'Ansible.ModuleUtils.Foo.Bar' in ps_md.ps_modules.keys()
    assert not ps_md.cs_utils_

# Generated at 2022-06-10 23:26:14.261791
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:26:24.898796
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True

test_PSModuleDepFinder_scan_exec_script.ps_modules = dict()
test_PSModuleDepFinder_scan_exec_script.exec_scripts = dict()
test_PSModuleDepFinder_scan_exec_script.cs_utils_wrapper = dict()
test_PSModuleDepFinder_scan_exec_script.cs_utils_module = dict()
test_PSModuleDepFinder_scan_exec_script.ps_version = None
test_PSModuleDepFinder_scan_exec_script.os_version = None
test_PSModuleDepFinder_scan_exec_script.become = False


# Generated at 2022-06-10 23:26:36.410059
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:26:49.190019
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pytest
    from ansible.module_utils.powershell._base import find_powershell_path
    if not find_powershell_path():
        pytest.skip(msg="Could not find any powershell executable, skipping this test case.")

    from ansible.module_utils.powershell.powershell import _get_encoded_dict
    from ansible.module_utils.powershell.executor import PSExecutor
    from ansible.module_utils.powershell.common import (
        DATA_PS_SCRIPT,
        DATA_JSON,
    )
    from ansible.plugins.loader import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    cl = AnsibleCollectionLoader()
    m_loader = module_loader.get('windows.windows_ping')
    module_path = cl.path

# Generated at 2022-06-10 23:26:49.991715
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:26:56.588258
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    test_data = """
    # Requires -Module Ansible.ModuleUtils.Something
    # Requires -Module Ansible.ModuleUtils.SomethingElse
    # Requires -ModuleFoo Ansible.ModuleUtils.Bar
    """

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(test_data, wrapper=True)
    assert dep_finder.ps_modules == {
        "Ansible.ModuleUtils.Something": {
            "path": "",
            "data": b'# getpsmodule'
        },
        "Ansible.ModuleUtils.SomethingElse": {
            "path": "",
            "data": b'# getpsmodule'
        }
    }


# Generated at 2022-06-10 23:27:02.644562
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_module('#AnsibleRequires -PowerShell Ansible.ModuleUtils.Common')
    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Common']

# Generated at 2022-06-10 23:27:09.916896
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Arrange
    ps_module_dep_finder = PSModuleDepFinder()

    # Act
    ps_module_dep_finder.scan_exec_script("file_v2")

    # Assert
    assert 'file_v2' in ps_module_dep_finder.exec_scripts.keys()


# Generated at 2022-06-10 23:27:10.496599
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:27:34.243664
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("ansible_runner")
    assert dep_finder.exec_scripts == {'ansible_runner': b'#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Common;\n\n'}
    assert dep_finder.cs_utils_wrapper == {'Ansible.ModuleUtils.Common': {'data': b'#Generated from PowerState.Common\nimport-module $PSScriptRoot\\PowerState.Common\n#EndGenerated\n', 'path': 'ansible.module_utils.common'}}
    assert dep_finder.cs_utils_module == {}
    assert dep_finder.ps_modules == {}


# Generated at 2022-06-10 23:27:35.945470
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass



# Generated at 2022-06-10 23:27:45.210333
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test the method scan_exec_script to ensure that it correctly adds the powershell script 
    # to the exec_scripts dictionary, adds any module_utils files to the ps_modules dictionary,
    # and calls scan_module to find any additional module_utils files required
    module_data = b'#Requires -Module Ansible.ModuleUtils.Common\n#stuff here\n#AnsibleRequires -CSharpUtil Ansible.ModuleUtils.Something'
    # ensure that the exec_scripts dictionary is empty
    assert not ps_module_dep_finder.exec_scripts
    # ensure that the ps_modules dictionary is empty
    assert not ps_module_dep_finder.ps_modules
    # ensure that the cs_utils_wrapper dictionary is empty
    assert not ps_module_dep_finder.cs_utils_wrapper
    # call scan_exec

# Generated at 2022-06-10 23:27:53.299073
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def scan_module_mock(module_data, fqn=None, wrapper=False, powershell=True):
        return module_data

    ps_obj = PSModuleDepFinder()
    ps_obj.scan_module = scan_module_mock
    ps_obj.scan_exec_script("a")
    assert ps_obj.exec_scripts['a'] == 'a\n'


# Generated at 2022-06-10 23:28:03.544310
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:28:11.987743
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    def _init_finder():
        class_ = PSModuleDepFinder()
        class_.ps_modules = dict()
        class_.exec_scripts = dict()
        class_.cs_utils_wrapper = dict()
        class_.cs_utils_module = dict()
        class_.ps_version = None
        class_.os_version = None
        class_.become = False

        return class_

    # test empty exec script name
    finder = _init_finder()
    try:
        finder.scan_exec_script(name='')
        assert False
    except AnsibleError:
        assert True

    # test valid exec script name
    finder = _init_finder()
    finder.scan_exec_script(name='posix_ls_wrapper')
    assert 'posix_ls_wrapper' in finder.exec

# Generated at 2022-06-10 23:28:24.009885
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell.module_utils._text import to_text
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.utils.collection_loader import _get_collection_name_from_fqcr
    from ansible.utils.path import unfrackpath
    import ansible.executor.powershell.module_utils as module_utils
    import ansible.executor.powershell.plugins as plugins

    def _strip_comments(b_data):
        # remove comments to reduce the payload size in the exec wrappers
        return b_data

    def mock_find_plugin(name, *args):
        try:
            return getattr(module_utils, name.split('.')[-1]).__file__
        except AttributeError:
            pass


# Generated at 2022-06-10 23:28:26.934955
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("fake.ps1")
    except AnsibleError:
        pass


# Generated at 2022-06-10 23:28:28.838975
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder_scan_exec_script.__wrapped__()



# Generated at 2022-06-10 23:28:36.733795
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.file import module_finder
    from ansible.module_utils.basic import AnsibleModule

    finder = module_finder.ModuleFinder()

    def _load_powershell_module(name):
        # requires is the fully qualified name, so adjust accordingly
        path = to_bytes(name.replace('.', os.path.sep) + '.psm1')
        return to_bytes(pkgutil.get_data(AnsibleModule.__module__, path))

    ps_module = _load_powershell_module('Ansible.ModuleUtils.Common.Collection')
    dep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:28:56.380051
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(b'', wrapper=True)
    with pytest.raises(AnsibleError, match='^Could not find collection imported module support code for \'Ansible.abc\'$'):
        md.scan_module(b'\n#ansiblerequires -csharputil ansible_collections.abc.collection.plugins.module_utils.something')
    with pytest.raises(AnsibleError, match='^Could not find imported module support code for \'ansible.abc\'$'):
        md.scan_module(b'\n#ansiblerequires -powershell ansible.abc')

# Generated at 2022-06-10 23:29:04.750832
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Test PSModuleDepFinder._add_module
    '''
    dep = PSModuleDepFinder()

    dep.scan_exec_script('wrapper')
    assert dep.exec_scripts['wrapper'][:5] == b'#! /usr/bin/env pwsh'
    assert len(dep.ps_modules) == 1
    assert dep.ps_modules['Ansible.ModuleUtils.CommonUtils']['data'][:5] == b'#! /usr/'


# Generated at 2022-06-10 23:29:15.480577
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Note: currently this test only runs under Python 3 because Python 2
    # has no b"..." literal syntax.

    # Run on an empty PSModuleDepFinder object and confirm that the result is an error
    ps_mod_dep_finder = PSModuleDepFinder()
    try:
        ps_mod_dep_finder.scan_exec_script("test_script")
        assert False, "Expected an AnsibleError, but didn't get one"
    except AnsibleError as exc:
        assert "Could not find executor powershell script for 'test_script'" in str(exc)

    # Add a predictable module to the module_utils dict and verify that
    # we can find it

# Generated at 2022-06-10 23:29:26.879733
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.formatters import bytes_to_human
    psdf = PSModuleDepFinder()
    module_data = u"""
#Requires -Module System.Management.Automation
#Requires -Module System.DirectoryServices.AccountManagement
#Requires -Module System.Security
$objUser = New-Object System.Security.Principal.NTAccount("Administrator")
$objID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
$objPrincipal = [System.DirectoryServices.AccountManagement.Principal]::FindByIdentity($objContext, $objID.Value)
""".encode("utf-8")

    psdf.scan_module(module_data, fqn=u"example.ps.module")
    # In order for module_utils to be added, we also

# Generated at 2022-06-10 23:29:32.157241
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('test_PSModuleDepFinder_scan_exec_script')
    # Test arguements
    finder = PSModuleDepFinder()
    finder.scan_exec_script('basic')
    assert finder.exec_scripts['basic'] == _slurp(resource_from_fqcr('executor/powershell/basic.ps1'))


# Generated at 2022-06-10 23:29:45.660762
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    Method scan_module of class PSModuleDepFinder tests
    """
    # Example of a module with a Requires of a builtin with a Requires of a collection
    module_with_deps_data = to_bytes("""
#Requires -Module Ansible.ModuleUtils.Legacy

function TestModule {
    param(
       [Parameter(Mandatory)]
       [string]$name
    )
    Write-Host "Foo bar $name"
}
""")

    # Example of a module with a Requires of a collection with a Requires of a builtin

# Generated at 2022-06-10 23:29:50.141864
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script('exec_wrapper')
    assert 'exec_wrapper' in psModuleDepFinder.exec_scripts
    assert len(psModuleDepFinder.exec_scripts['exec_wrapper']) == 649

# Generated at 2022-06-10 23:29:59.021878
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert finder.exec_scripts == dict()
    assert finder.ps_modules == dict()
    # test a valid module
    finder.scan_exec_script('ExecutionWrappers')
    assert finder.exec_scripts == dict()
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    # test an invalid module
    with pytest.raises(AnsibleError, match="Could not find executor powershell script for 'missing'"):
        finder.scan_exec_script('missing')


# Generated at 2022-06-10 23:30:08.503496
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # A module can have a dependency to a builtin module_util
    data = b'\n'.join([
        b'#Requires -Module ansible.module_utils.my_util'
    ])
    psm = PSModuleDepFinder()
    psm.scan_module(data, fqn='ansible.builtin.mymodule')
    assert psm.ps_modules[u'Ansible.ModuleUtils.my_util']

    # A module can have a dependency to a collection module_util
    data = b'\n'.join([
        b'#AnsibleRequires -PowerShell ansible.module_utils.my_util'
    ])
    psm = PSModuleDepFinder()
    psm.scan_module(data, fqn='ansible.mymodule')
    assert psm.ps_

# Generated at 2022-06-10 23:30:19.862413
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fetcher = PSModuleDepFinder()

# Generated at 2022-06-10 23:30:41.024974
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('test_scan_exec')
    assert finder.exec_scripts['test_scan_exec'] == b'data'
    assert list(finder.ps_modules.keys()) == ['ps_util']



# Generated at 2022-06-10 23:30:46.537124
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depFinder = PSModuleDepFinder()
    depFinder._add_module = MagicMock()
    depFinder.ps_modules = dict()
    depFinder.exec_scripts = dict()

    depFinder.scan_exec_script("ps_base_wrapper.ps1")
    assert len(depFinder.exec_scripts) == 1
    assert "ps_base_wrapper.ps1" in depFinder.exec_scripts
    assert depFinder._add_module.called


# Generated at 2022-06-10 23:30:52.743381
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Unit test for method scan_exec_script of class PSModuleDepFinder."""
    finder = PSModuleDepFinder()
    finder.scan_exec_script('ping')
    assert finder.exec_scripts['ping'].startswith(b'function Invoke-AnsiblePing {')
    assert finder.cs_utils_wrapper

# Generated at 2022-06-10 23:31:02.592197
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script('common')
    assert len(dep_finder.cs_utils_wrapper) == 1
    assert to_text('ansible_collections.ansible.windows.plugins.module_utils.windows.win_dsc') in dep_finder.cs_utils_wrapper.keys()
    assert len(dep_finder.ps_modules) == 1
    assert to_text('Ansible.ModuleUtils.Powershell') in dep_finder.ps_modules.keys()

    dep_finder.scan_exec_script('file')
    assert len(dep_finder.cs_utils_wrapper) == 2
    assert to_text('ansible_collections.ansible.windows.plugins.module_utils.windows.win_file') in dep_finder.cs_

# Generated at 2022-06-10 23:31:12.564427
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script("an")

    exec_scripts = dep_finder.exec_scripts
    assert len(exec_scripts) == 1

    assert exec_scripts.get("an") is not None
    assert exec_scripts.get("an").startswith(b"<#")
    assert exec_scripts.get("an").endswith(b"#>")

    ps_modules = dep_finder.ps_modules
    assert len(ps_modules) > 0
    assert ps_modules.get("Ansible.ModuleUtils.ArgumentSpec") is not None
    assert ps_modules.get("Ansible.ModuleUtils.ArgumentSpec").get("data").startswith(b"<#")

# Generated at 2022-06-10 23:31:14.683612
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    with pytest.raises(AnsibleError):
        PSModuleDepFinder.scan_exec_script("{no_ps1}")



# Generated at 2022-06-10 23:31:26.397442
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import sys
    if sys.version_info[0] >= 3:
        from unittest.mock import patch
    else:
        from mock import patch

    from ansible_collections.test.test_utils.test_pkgutils.test.plugins.module_utils import test_utils

    with patch('pkgutil.get_data') as get_data_mock:
        get_data_mock.side_effect = lambda p, f: test_utils.read_data_file(f)
        finder = PSModuleDepFinder()
        finder.scan_module("#Noop", fqn="test.test_module")
        assert {} == finder.ps_modules
        assert {} == finder.cs_utils_wrapper


# Generated at 2022-06-10 23:31:37.023695
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('')
    print('#' * 80)
    # test 1:
    #    data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))
    print('# test 1:')
    print('#    data = pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))')
    print('#    if data is None:')
    print('#        raise AnsibleError("Could not find executor powershell script "')
    print('#                           "for \'%s\'" % name)')
    #
    # check data is None
    data_is_none = random.choice([True, False])
    #
    # check data

# Generated at 2022-06-10 23:31:43.768716
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    script_name = "resource_script"
    script_path = ansible.executor.powershell.__path__[0] + '/' + script_name + '.ps1'

    if os.path.exists(script_path):
        with open(script_path, 'r') as f_resource:
            f_resource_data = f_resource.read()
    else:
        raise ansible.errors.AnsibleError("Could not find executor powershell script "
                                          "for '%s'" % script_name)

    data = pkgutil.get_data("ansible.executor.powershell", script_name + ".ps1")

# Generated at 2022-06-10 23:31:55.692418
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_text

    mod_dep_finder = PSModuleDepFinder()

    # test with python module_util in a powershell module

# Generated at 2022-06-10 23:32:38.803972
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.exec_scripts = {}
    finder.ps_modules = {'Ansible.ModuleUtils.Abc': {'data': b'UtilAbc', 'path': 'Ansible.ModuleUtils.Abc'},
                         'ansible_collections.foo.bar.plugins.module_utils.Baz': {'data': b'UtilBaz', 'path':
                         'ansible_collections.foo.bar.plugins.module_utils.Baz'},
                         'ansible_collections.a.b.plugins.module_utils.FooBar': {'data': b'UtilFooBar', 'path':
                         'ansible_collections.a.b.plugins.module_utils.FooBar'}}
    finder.cs_utils_

# Generated at 2022-06-10 23:32:48.590855
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pmdf = PSModuleDepFinder()
    pmdf.scan_exec_script("powershell.py")
    exec_scripts = pmdf.exec_scripts
    # Assert that exec_scripts has a particular key
    assert "powershell.py" in exec_scripts, 'powershell.py not found in exec_scripts'
    # Assert that exec_scripts["powershell.py"] contains the value of the first line of powershell.py
    assert b"Use this script to load the python interpreter into powershell" in exec_scripts["powershell.py"],\
        'exec_scripts["powershell.py"] does not contain the first line of powershell.py'
    # Assert that the exec_scripts dictionary has the expected size
    assert len(exec_scripts) == 1, "exec_scripts is not the expected size"


# Generated at 2022-06-10 23:32:55.020672
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:33:00.761027
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_util = PSModuleDepFinder()
    module_util.scan_exec_script("executor")
    assert(module_util.exec_scripts["executor"]) is not None
    assert(module_util.ps_modules["Ansible.ModuleUtils.Logging"]) is not None
