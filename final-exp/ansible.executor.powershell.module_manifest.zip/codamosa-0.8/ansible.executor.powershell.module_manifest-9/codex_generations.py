

# Generated at 2022-06-10 23:23:44.098827
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    t = PSModuleDepFinder()
    module_data = r'''#requires -version 5.0
#requires -module Ansible.ModuleUtils.Common
#requires -module Ansible.ModuleUtils.Powershell
#requires -module Ansible.ModuleUtils.Legacy
#ansiblerequires -powershell Ansible.ModuleUtils.Legacy -Optional
#ansiblerequires -wrapper New-AnsibleModule
#ansiblerequires -Become
param(
      [int]$debugger_test = 1
  )'''
    t.scan_module(to_bytes(module_data))

    assert t.ps_modules['Ansible.ModuleUtils.Legacy']
    assert t.exec_scripts['New-AnsibleModule']
    assert t.become


# Generated at 2022-06-10 23:23:48.949279
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    module_data = "#Requires -Module Ansible.ModuleUtils.PSCore"
    finder.scan_module(module_data)
    assert finder.ps_modules["Ansible.ModuleUtils.PSCore"] is not None


# Generated at 2022-06-10 23:23:53.421881
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    module_data = "module data"
    fqn = "a.b.c"
    wrapper = "wrapper"
    powershell = "powershell"
    obj.scan_module(module_data, fqn, wrapper, powershell)


# Generated at 2022-06-10 23:24:06.292401
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    script_path = os.path.join(C.DEFAULT_LOCAL_TMP, "script_path")
    content = "#Test\n# Ansi bleRequires -CSharpUtil Foo. Bar"
    md5sum = "95d66c3d3e4dc35421e82b98a9b9f3a3"

    # when the script is present
    with open(script_path, 'w') as script:
        script.write(content)

    md5 = PSModuleDepFinder()._scan_exec_script(script_path)

    assert md5 == md5sum

    os.unlink(script_path)

    # when the scripts is not present
    md5 = PSModuleDepFinder()._scan_exec_script(script_path)

    assert md5 is None


# Generated at 2022-06-10 23:24:07.656187
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # No test required, this is abstract
    pass


# Generated at 2022-06-10 23:24:19.700343
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # pylint: disable=attribute-defined-outside-init
    test_module_data = """#Requires -Module Ansible.ModuleUtils.Test1
#Requires -Module Ansible.ModuleUtils.Test2
#Requires -Module Ansible.ModuleUtils.Test1
#AnsibleRequires -CSharpUtil Ansible.CSharpUtilName
#Requires -Module Ansible.ModuleUtils.Test2
#AnsibleRequires -CSharpUtil Ansible.CSharpUtilName
#AnsibleRequires -CSharpUtil Ansible.CSharpUtilName
#Requires -Module Ansible.ModuleUtils.Test1
#Requires -Module ansible_collections.acme_inc.test.plugins.module_utils.Test1
"""
    # pylint: enable=attribute-defined-outside-init

    ps_module

# Generated at 2022-06-10 23:24:26.959914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pkgutil
    import os
    import tempfile

    tmp = tempfile.TemporaryDirectory()
    tmppath = tmp.name
    # test_file = tmppath + '\\' + 'test_file.ps1'


# Generated at 2022-06-10 23:24:38.266097
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    class MockPSModuleDepFinder(PSModuleDepFinder):
        def __init__(self):
            PSModuleDepFinder.__init__(self)
            self.exec_scripts = dict()
            self.ps_modules = dict()
            self.cs_utils_wrapper = dict()
            self.scanned_module_utils = dict()

        def scan_module(self, module_data, fqn=None, wrapper=False, powershell=False):
            self.scanned_module_utils[fqn] = True

    mock_dep_finder = MockPSModuleDepFinder()

    # Test that a powershell module can be successfully found and scanned
    name = 'foo'
    mock_dep_finder.scan_exec_script(name)
    assert name in mock_dep_finder.exec_scripts
    assert mock

# Generated at 2022-06-10 23:24:50.637449
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # get the path to the powershell module executor wrapper
    p = os.path.dirname(ps_module_utils_loader.find_plugin('Ansible.ModuleUtils.PowerShell', '.psm1'))
    # if os.path.isdir(p) is False:
    #     raise Exception("Unable to find a directory at " + p)

    # load the powershell_module_wrapper
    p = os.path.join(p, 'powershell_module_wrapper.ps1')
    # if os.path.isfile(p) is False:
    #     raise Exception("Unable to find the file at " + p)

    # read the powershell_module_wrapper
    with open(p, 'r') as f:
        data = f.read()

    # set the finder data
    finder

# Generated at 2022-06-10 23:24:52.475779
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: rewrite to use patching
    pass

# Generated at 2022-06-10 23:25:21.317036
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ''' test PSModuleDepFinder.scan_exec_script method '''
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script('advanced_get_connection')
    assert len(depfinder.exec_scripts) == 1
    assert len(depfinder.ps_modules) >= 1
    assert 'Ansible.ModuleUtils.ConnectionHelpers' in depfinder.ps_modules.keys()
    assert len(depfinder.cs_utils_wrapper) == 0
    assert len(depfinder.cs_utils_module) == 0


# Generated at 2022-06-10 23:25:27.032642
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    expected = to_bytes(base64.b64decode('IyBOZXcgZm9ybWF0LiBDYWNoZSB3aXRoIG1ldGhvZCBvcmRlcg=='))
    result = f.scan_exec_script('shell_common')
    assert expected == f.exec_scripts['shell_common']



# Generated at 2022-06-10 23:25:28.890588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script('windows_command')


# Generated at 2022-06-10 23:25:41.471489
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import mock
    ps_module_dep_finder = PSModuleDepFinder()

    #Test case 1: _re_ps_module
    test_module_data = '#Requires -Module Ansible.ModuleUtils.Common'
    test_fqn = 'ansible_collections.namespace.collection.plugins.modules.test_module'
    recurse_module_modules = [
        ('ansible_collections.namespace.collection.plugins.module_utils.test.test1', '.psm1',
         test_fqn, False),
        ('ansible_collections.namespace.collection.plugins.module_utils.test.test2', '.psm1',
         test_fqn, False),
    ]

# Generated at 2022-06-10 23:25:48.792247
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_PSModuleDepFinder = PSModuleDepFinder()
    test_PSModuleDepFinder.scan_exec_script("wrapper")

# Generated at 2022-06-10 23:25:49.569033
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:25:58.752989
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create an instance of PSModuleDepFinder
    # the class PSModuleDepFinder has no __init__ method
    # so we call its base __init__ method here
    # initialize some instance attributes
    psmdf = PSModuleDepFinder()
    psmdf.ps_modules = {u'Ansible.ModuleUtils.Basic': {u'data': b'#!ps1\n\ndo', u'path': u'/path/to/Ansible.ModuleUtils.Basic.psm1'}}
    # run the code to be tested
    psmdf.scan_exec_script('Common.ps1')


# Generated at 2022-06-10 23:26:04.935353
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = 'testname'
    class TestAnsiblePlugins(object):
        def __init__(self):
            self.name = name
    test_object = TestAnsiblePlugins()
    ret = PSModuleDepFinder._add_module(test_object,name)
    assert isinstance(ret,type(test_object))
    assert ret == test_object
    assert ret.name == name

# Generated at 2022-06-10 23:26:06.866119
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script('powershell_wrapper')
    assert to_text(depfinder.exec_scripts['powershell_wrapper'])

# Generated at 2022-06-10 23:26:10.174098
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    name = 'ansible_collections.ns.coll.plugins.modules.name.psm1'
    test_obj.scan_exec_script(name)

# Generated at 2022-06-10 23:26:49.939211
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.file import _slurp
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("compat_boolean")
    # matching data from file ansible/executor/powershell/compat_boolean.ps1
    assert dep_finder.exec_scripts == {'compat_boolean': b"#requires -version 5.0\n\n"
                                                                 b"class compat_boolean {\n"
                                                                 b"    [bool]$value\n"
                                                                 b"}\n"}
    dep_finder.exec_scripts.clear()
    dep_finder.scan_exec_script("compat_datetime")
    # matching data from file ansible/executor/powershell/compat_datetime.ps1

# Generated at 2022-06-10 23:26:56.953389
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import mock
    import pkg_resources

    from ansible.plugins.loader import collections_loader

    finder = PSModuleDepFinder()
    with mock.patch("ansible.module_utils.common.collections.__path__", collections_loader._get_collection_paths("ansible_collections.module_utils_test")):
        # No file specified
        finder.scan_exec_script("test_exec_script")

        # File specified
        finder.scan_exec_script("test_util_exec")

    # Invalid file

# Generated at 2022-06-10 23:27:04.337594
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test scan_exec_script of PSModuleDepFinder with different values.
    # Arrange
    psmdf = PSModuleDepFinder()
    name = 'win_ping'
    # Act
    result = psmdf.scan_exec_script(name)
    # Assert
    assert result == None


# Generated at 2022-06-10 23:27:10.271333
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # This is a test method for the unit test of class PSModuleDepFinder.
    # The method is named with test_ and takes no arguments
    # The method names are arbitrary, but test_ is a good standard practice
    assert False, "Test not implemented for PSModuleDepFinder.scan_exec_script"


# Generated at 2022-06-10 23:27:14.743881
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psm = PSModuleDepFinder()
    psm.scan_exec_script("basic")
    psm.scan_exec_script("native_win32")
    assert psm.exec_scripts["basic"]
    assert psm.exec_scripts["native_win32"]


# Generated at 2022-06-10 23:27:18.483882
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print("-----------------------------")
    print("Test: test_PSModuleDepFinder_scan_exec_script")
    print("-----------------------------")
    finder = PSModuleDepFinder()
    finder.scan_exec_script("ps_base")
    print("-----------------------------")


# Generated at 2022-06-10 23:27:27.379171
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("win_shell")
    assert dep_finder.exec_scripts["win_shell"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.CommonUtils"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.JSON"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.Process"]
    assert dep_finder.ps_modules["Ansible.ModuleUtils.PwshCompatibility"]

# Generated at 2022-06-10 23:27:28.905938
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder().scan_exec_script('posix')

# Generated at 2022-06-10 23:27:30.236028
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_obj = PSModuleDepFinder()
    assert my_obj is not None

# Generated at 2022-06-10 23:27:31.725964
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # FIXME: Implementation skipped
    raise NotImplementedError()


# Generated at 2022-06-10 23:29:05.737856
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "TODO"


# Generated at 2022-06-10 23:29:08.850572
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    test_name = 'test'
    result = test_obj.scan_exec_script(test_name)


# Generated at 2022-06-10 23:29:10.814651
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    obj.scan_exec_script('powershell_base')



# Generated at 2022-06-10 23:29:15.824607
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Check that scanning an existing script works, and that scanning a missing script raises an error.
    helper = PSModuleDepFinder()

    helper.scan_exec_script('base')

    try:
        helper.scan_exec_script('nonexisting')
    except AnsibleError:
        pass
    else:
        raise AssertionError('Expected an AnsibleError when scanning an invalid script.')



# Generated at 2022-06-10 23:29:19.932363
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Get a json data from the file test_data.json. It contains a dict.
    with open("test_data.json", "r") as file:
        data = json.load(file)
    ps_module_utils = data['ps_module_utils']
    ps_module_utils_list = list(ps_module_utils.keys())
    random_util = ps_module_utils_list[random.randint(0, len(ps_module_utils_list) - 1)]
    # Create an instance of PSModuleDepFinder class
    ps_module_dep_finder = PSModuleDepFinder()
    # Call scan_exec_script and parse the arguments
    ps_module_dep_finder.scan_exec_script(random_util)
    # Check if the object is created properly

# Generated at 2022-06-10 23:29:26.834226
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test PSModuleDepFinder.scan_exec_script"""
    # Creating dummy PSModuleDepFinder object
    psmdf = PSModuleDepFinder()
    # Creating dummy script
    dummy_script = '/usr/bin/ansible-collections'
    # Asserting if the dummy script is equal to the scanned script
    assert dummy_script == psmdf.scan_exec_script(dummy_script)


# Generated at 2022-06-10 23:29:30.030030
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import pkgutil
    pkgutil.get_data("ansible.executor.powershell", to_native("test.ps1"))
    
    
# Unit tests for class PSModuleDepFinder

# Generated at 2022-06-10 23:29:31.431953
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:29:37.757115
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module = PSModuleDepFinder()
    # Test with a available powershell script
    module.scan_exec_script("test_module_utils")
    assert module.exec_scripts.has_key("test_module_utils")
    assert module.cs_utils_wrapper.has_key("Ansible.ModuleUtils.Test")


# Generated at 2022-06-10 23:29:43.793495
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_exec_script(name="MyScript")
    if ps_module_dep_finder.exec_scripts["MyScript"] != b"":
        raise AssertionError("exec_scripts should contain an empty string")


# Generated at 2022-06-10 23:31:45.825092
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pmdf = PSModuleDepFinder()
    NAME = "test_name"
    DATA = "#AnsibleRequires -powershell test_name"
    pmdf.scan_module(DATA)
    assert pmdf.ps_modules.keys() == [NAME]

    pmdf = PSModuleDepFinder()
    DATA = "#Requires -Module Ansible.ModuleUtils.test_name"
    pmdf.scan_module(DATA)
    assert pmdf.ps_modules.keys() == [NAME]

    pmdf = PSModuleDepFinder()
    DATA = "#AnsibleRequires -csharputil test_name"
    pmdf.scan_module(DATA)
    assert pmdf.cs_utils_module.keys() == [NAME]


# Generated at 2022-06-10 23:31:56.430404
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.powershell import PSModuleDepFinder
    from ansible.module_utils.common._collections_compat import MutableMapping

    depfinder = PSModuleDepFinder()

    depfinder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Pangea.Common")
    depfinder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Pangea.Common")

    assert isinstance(depfinder.ps_modules, MutableMapping)
    assert to_text(depfinder.ps_modules.keys()) == "dict_keys(['Ansible.ModuleUtils.Pangea.Common'])"



# Generated at 2022-06-10 23:31:57.075113
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:31:59.970339
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test = PSModuleDepFinder()
    # Supply Valid Script name
    test.scan_exec_script('ansible_module_wrapper')
    assert test.exec_scripts.__str__()

# Generated at 2022-06-10 23:32:11.413871
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    obj = PSModuleDepFinder()
    # Check module without dependencies
    module_data = """
    param(
        [string]
        $Foo,
        [string]
        $Bar
    )
    """
    obj._re_cs_in_ps_module = [
        re.compile(to_bytes(r'(?i)^#\s*ansiblerequires\s+-csharputil\s+((Ansible\.[\w\.]+)|'
                            r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+)|'
                            r'(\.[\w\.]+))(?P<optional>\s+-Optional){0,1}')),
    ]

# Generated at 2022-06-10 23:32:24.138891
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils import powershell
    from ansible.module_utils.six import PY3

    ps_module_dep_finder = PSModuleDepFinder()
    try:
        ps_module_dep_finder.scan_exec_script('basic')
    except AnsibleError:
        if PY3:
            # AnsibleError is raised in PY3
            pytest.fail('AnsibleError is raised')
        else:
            # TypeError is raised in PY2
            pytest.fail('TypeError is raised')

    # PSModuleDepFinder() should find
    # module_utils/powershell/\*.psm1 path as the module_utils_path
    # during the execution in Ansible 2.9 or later

# Generated at 2022-06-10 23:32:27.989228
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script(name = "name")

    assert True


# Generated at 2022-06-10 23:32:30.962196
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    host =  PSModuleDepFinder()
    assert(host.scan_exec_script("basic_powershell")==None)

# Generated at 2022-06-10 23:32:42.680856
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    print("Test scan_module")
    dep_finder = PSModuleDepFinder()
    sample_module = "#AnsibleRequires -CSharpUtil Test.Module\n" \
                    "#AnsibleRequires -CSharpUtil Test2.Module"
    dep_finder.scan_module(sample_module.encode("utf-8"), powershell=False, wrapper=False)
    assert dep_finder.cs_utils_module["Test.Module"] \
           == {'data': b'# Module Util\n', 'path': 'Test\Module.cs'}, \
        "Error: Unexpected module_utils found"

# Generated at 2022-06-10 23:32:56.970773
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''Unit test for library/plugins/loader/ps_module_dep_finder.py::PSModuleDepFinder::scan_exec_script'''

    # Load the class definition and test method definition
    from ansible.plugins.loader import ps_module_dep_finder
    from ansible.plugins.loader.ps_module_dep_finder import PSModuleDepFinder
    import os

    finder = PSModuleDepFinder()
    assert finder.scan_exec_script('ExecutionFramework') == None, 'Failed to call scan_exec_script with valid arguments'
    #check that an exception is thrown when an invalid module is used
    import os.path