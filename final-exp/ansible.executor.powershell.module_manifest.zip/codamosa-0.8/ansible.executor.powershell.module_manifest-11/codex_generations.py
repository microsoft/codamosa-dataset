

# Generated at 2022-06-10 23:23:28.198359
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script("PowerShellExecutor")



# Generated at 2022-06-10 23:23:35.816994
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # return: dict(object, dict)
    ps = PSModuleDepFinder()
    name = "Windows.PsUtil"
    ps.scan_exec_script(name)
    assert name in ps.exec_scripts, "Should be True"
    assert name in ps.cs_utils_wrapper, "Should be True"

# Generated at 2022-06-10 23:23:47.141615
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Since the tests are based on randomness, increase the random seed to
    # make sure the results are repeatable.
    random.seed(3)

    finder = PSModuleDepFinder()

    # PSModuleDepFinder.scan_module() should return an empty set without
    # requiring any module utils
    assert finder.scan_module(b"") == set()

    # PSModuleDepFinder.scan_module() should recognize a reference to a
    # builtin module util.
    assert finder.scan_module(b"#Requires -Module Ansible.ModuleUtils.Common") == {"Ansible.ModuleUtils.Common"}

    # PSModuleDepFinder.scan_module() should recognize multiple references to
    # builtin module utils

# Generated at 2022-06-10 23:23:56.693081
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_text

    dep_finder = PSModuleDepFinder()
    dep_finder.scan_module(to_bytes("#Requires -Module Ansible.ModuleUtils.Foo"))
    data = dep_finder.ps_modules['Ansible.ModuleUtils.Foo']
    result = data['data'][0:12]
    assert result == b"#\r\n# Ansib"

    dep_finder.ps_modules = dict()
    dep_finder.scan_module(to_bytes("#Requires -Module Ansible.ModuleUtils.Foo_Bar"))
    data = dep_finder.ps_modules['Ansible.ModuleUtils.Foo_Bar']
    result = data['data'][0:12]

# Generated at 2022-06-10 23:24:03.839818
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_text
    md = PSModuleDepFinder()
    md.scan_module(to_text("#AnsibleRequires -PowerShell Ansible.ModuleUtils.foo\n"))
    assert "Ansible.ModuleUtils.foo" in md.ps_modules.keys()


# Generated at 2022-06-10 23:24:06.813852
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('ExecWrapper')
    assert dep_finder.exec_scripts

# Generated at 2022-06-10 23:24:09.896133
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    result = obj.scan_exec_script("google_drive")
    repr(result)
    assert result is None

# Generated at 2022-06-10 23:24:21.397336
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # '#AnsibleRequires -Wrapper'
    # {wrapper_name}.ps1
    # '#AnsibleRequires -Powershell ...'
    # '#AnsibleRequires -CSharpUtil ...'
    # {wrapper_name}.ps1
    # '#Requires -Module Ansible.*'
    # {wrapper_name}.ps1

    # Get the module data required by the wrappers, ps_modules and cs_utils_wrapper
    # from the scanner
    scanner = PSModuleDepFinder()

    scanner.scan_exec_script('powershell_base')

    assert 'Ansible.ModuleUtils.Legacy' in scanner.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Basic' in scanner.ps_modules.keys()

# Generated at 2022-06-10 23:24:23.477116
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialization for the test_PSModuleDepFinder_scan_exec_script
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script("foo")
    # Assertion to check if wrapped function is giving the correct output
    assert psModuleDepFinder.exec_scripts == {'foo': b'#'}


# Generated at 2022-06-10 23:24:25.725876
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: Implement unit test
    return True



# Generated at 2022-06-10 23:24:56.457720
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    #Global
    output = {}
    input = {}
    print_dir = os.path.dirname(os.path.abspath(__file__))
    print_dir = os.path.join(print_dir, '../../../lib/ansible/modules/windows/')
    input['module_name'] = print_dir + 'win_package'
    os.chdir(print_dir)
    psm = PSModuleDepFinder()
    psm.scan_module(psm.scan_module)
    output_str = ""
    for key, value in psm.ps_modules.iteritems():
        output_str += key
        output_str += ' '
        output_str += value['path']
        output_str += ' '
        output_str += str(len(value['data']))
        output

# Generated at 2022-06-10 23:24:57.434532
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass



# Generated at 2022-06-10 23:25:06.447814
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.common.text.formatters.json import dumps

    PSModuleDepFinder = import_module('ansible.module_utils.powershell.PSModuleDepFinder').PSModuleDepFinder

    # Make an instance
    obj = PSModuleDepFinder()

    # Make a sequence of args
    args = Sequence()

    # Make a mapping of kwargs
    kwargs = Mapping()
    kwargs['module_data'] = to_bytes(dumps({'changed': False, 'msg': 'hello, world'}))
    kwargs['fqn'] = to_bytes('ansible_collections.namespace.collection.plugins.module_utils.module_name')

# Generated at 2022-06-10 23:25:12.411990
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test: Scan g'exec' powershell script for module references
    p = PSModuleDepFinder()
    p.scan_exec_script("g'exec'")
    assert p.exec_scripts['g"exec"'] == pkgutil.get_data('ansible.executor.powershell', 'g"exec".ps1')

# Generated at 2022-06-10 23:25:24.317369
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    test_obj._re_cs_module = [re.compile(to_bytes(r'(?i)^using\s((Ansible\..+)|'
                                   r'(ansible_collections\.\w+\.\w+\.plugins\.module_utils\.[\w\.]+));\s*$'))]

# Generated at 2022-06-10 23:25:26.136948
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # This method is currently untestable do to the side effects of the package utils.
    pass


# Generated at 2022-06-10 23:25:29.495378
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # execute unit test
    
    # FIXME: check if called with right args
    # FIXME: check if break if called with wrong args
    # FIXME: check if breaks if called with no args
    return True

# Generated at 2022-06-10 23:25:39.790170
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    This will test the entire module to ensure all dependencies are scanned
    """
    sut = PSModuleDepFinder()
    sut.scan_exec_script('powershell_boilerplate')
    assert sut.exec_scripts['powershell_boilerplate']

    assert len(sut.ps_modules) == 0
    assert len(sut.cs_utils_wrapper) > 1, "There are missing Cs utils for the wrapper"
    assert len(sut.cs_utils_module) == 0
    assert sut.ps_version is None
    assert sut.os_version is None
    assert not sut.become


# Generated at 2022-06-10 23:25:41.454732
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:25:53.214358
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    name = random.choice(['test_abc', 'xyz_test'])
    ext = random.choice(['.py', '.yaml'])
    fqn = random.choice(['test_fqn', 'xyz_fqn'])
    optional = random.choice([True, False])
    wrapper = random.choice([True, False])
    _ansible_module_generated_by = random.choice(['test_abc', 'xyz_test'])
    module_data = """
Sample module.
    Ansible doc: http://docs.ansible.com/ansible/
"""
    PSModuleDepFinder1 = PSModuleDepFinder()
    PSModuleDepFinder1.scan_module(module_data, fqn=None, wrapper=False, powershell=True)

    # exec_script = p

# Generated at 2022-06-10 23:26:09.357238
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module = PSModuleDepFinder()
    module.scan_exec_script("powerstate")



# Generated at 2022-06-10 23:26:22.597896
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test if scan_exec_script return expected results
    """
    util = PSModuleDepFinder()
    util.exec_scripts = {
        '1': b'\n============================================================\n',
        '4': b'\n============================================================\n',
        '5': b'\n============================================================\n',
        '6': b'\n============================================================\n',
        '7': b'\n============================================================\n',
        '2': b'\n============================================================\n',
        '3': b'\n============================================================\n',
        '8': b'\n============================================================\n',
        '9': b'\n============================================================\n',
        '10': b'\n============================================================\n',
    }

# Generated at 2022-06-10 23:26:31.015619
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("ansible_shell")

# Generated at 2022-06-10 23:26:34.006679
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    entity = PSModuleDepFinder()
    with pytest.raises(AnsibleError):
        entity.scan_exec_script("abc")


# Generated at 2022-06-10 23:26:40.893441
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test that scan_exec_script scans lib/ansible/executor/powershell for scripts used in the module
    # exec side. It also scans these scripts for any dependencies.
    tester = PSModuleDepFinder()
    exec_script = tester.scan_exec_script("Ansible.ModuleUtils.PoshRSJob")
    assert exec_script is not None
    assert exec_script == ""



# Generated at 2022-06-10 23:26:52.382739
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # This is a mock function that always returns the same value.
    # It's not used in this test since we don't care about the value,
    # we just need to replace the original pkgutil.get_data() function
    # with a mock and make sure it's called.
    def pkgutil_get_data(pkg_name, pkg_data):
        # return b"mock-package-data"
        return "mock-package-data"

    # The real function is mocked and replaced by the mock function
    pkgutil.get_data = pkgutil_get_data

    dep = PSModuleDepFinder()
    dep.scan_exec_script("Ansible.ModuleUtils.get_platform_subclass")

    # Make sure that the mock function is called

# Generated at 2022-06-10 23:27:07.456576
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test for method scan_module of class PSModuleDepFinder."""
    random_string = base64.b64encode(os.urandom(64))

# Generated at 2022-06-10 23:27:15.193338
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import sys
    import traceback
    import tempfile
    from ansible.module_utils.compat.importlib import import_module
    from ansible.module_utils._text import to_bytes, to_native

    loader = PSModuleDepFinder()
    mod = import_module(__name__)

    def url(name, ext=".py"):
        return to_native("%s.module_utils.%s.%s" % (mod.__package__, name, ext))
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False, suffix=".psm1")

# Generated at 2022-06-10 23:27:25.448430
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def se_ps1_module_data(module_util_name):
        return b"#Requires -Module " + to_bytes(module_util_name) + b"\n"

    class ModuleData:
        def __init__(self):
            self.cs_utils_module = dict()
            self.ps_modules = dict()

    test_object = PSModuleDepFinder()
    test_object.ps_modules = ModuleData()
    test_object.cs_utils_module = ModuleData()
    test_object.cs_utils_wrapper = ModuleData()
    test_object.exec_scripts = dict()

    assert PSModuleDepFinder is not None

    # Scan a dependency that exists
    test_object.scan_exec_script('amzn1_session')

# Generated at 2022-06-10 23:27:34.037348
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell.module_utils.compat import C
    from ansible.executor.powershell.module_utils.basic import Basic
    
    C.DEFAULT_DEBUG=False
    m = PSModuleDepFinder()
    name = 'Basic'
    m.scan_exec_script(name)
    
    
    assert m.exec_scripts[name].decode()==Basic.to_bytes(Basic._strip_comments(Basic.pkgutil.get_data(Basic.to_native("ansible.executor.powershell"), Basic.to_native(name + ".ps1"))))

# Generated at 2022-06-10 23:28:02.446033
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    f = PSModuleDepFinder()
    f.scan_exec_script(b"Get-Command")
    assert len(f.exec_scripts) == 1



# Generated at 2022-06-10 23:28:10.328120
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dependency_finder = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", "Initialize-Module.ps1")
    ps_dependency_finder.scan_module(data)
    assert len(ps_dependency_finder.exec_scripts) == 1
    assert len(ps_dependency_finder.ps_modules) == 0
    assert len(ps_dependency_finder.cs_utils_wrapper) == 0
    assert len(ps_dependency_finder.cs_utils_module) == 0
    assert ps_dependency_finder.exec_scripts["Initialize-Module"] == data



# Generated at 2022-06-10 23:28:21.482522
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.executor.powershell.generic import PowershellGenericRunner

    utils = {
        "Util1": b"data for util1",
        "Ansible.Util2": b"data for util2",
        "Ansible.ModuleUtils.Util3": b"data for util3",
    }
    ps_data = b"""#Requires -Module @{ModuleName='Ansible.ModuleUtils.Util3';ModuleVersion="1.0.0"}
#ansiblerequires -CSharpUtil "Ansible.ModuleUtils.Util4"
#AnsibleRequires -Wrapper Util1
"""
    cs_data = b"""using Ansible.ModuleUtils.Util4;
using ansible_collections.ns.coll.plugins.module_utils.Util5;
"""

# Generated at 2022-06-10 23:28:25.831615
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    with pytest.raises(AnsibleError, match=r"Could not find executor powershell script for 'foo'"):
        finder.scan_exec_script('foo')



# Generated at 2022-06-10 23:28:28.472439
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script("powershell")
    return True


# Generated at 2022-06-10 23:28:30.763974
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psModuleDepFinder = PSModuleDepFinder()
    psModuleDepFinder.scan_exec_script("common")

# Generated at 2022-06-10 23:28:34.451555
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Method: scan_exec_script() of class PSModuleDepFinder
    """
    # Make an instance of the PSModuleDepFinder class
    _depfinder = PSModuleDepFinder()
    name = 'PowershellCore'
    _depfinder.scan_exec_script(name)

# Generated at 2022-06-10 23:28:47.195267
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    '''
    Unit test for method scan_module of class PSModuleDepFinder
    '''
    dep_finder = PSModuleDepFinder()
    # PS Module with two module utils (one builtin and one collection)
    dep_finder.scan_module(b'#Requires -Module Ansible.ModuleUtils.Pester\n#AnsibleRequires -PowerShell ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network_template', fqn="windows")
    # Exec wrapper with multiple module utils
    dep_finder.scan_exec_script(b'ansible_powershell')
    # PS Module with one optional module_util
    dep_finder.scan_module(b'#AnsibleRequires -PowerShell -Optional Ansible.ModuleUtils.Pester', fqn="windows")

# Generated at 2022-06-10 23:28:57.068402
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    testname = 'test_PSModuleDepFinder_scan_module'
    print('in %s' % testname)

    psmdf = PSModuleDepFinder()

    module_data = '''
    #Requires -Version 6.1.0
    #AnsibleRequires -PowerShell ansible_collections.ntd.test.plugins.module_utils.test
    #AnsibleRequires -PowerShell .test
    #AnsibleRequires -PowerShell .test2
    #AnsibleRequires -Wrapper test_wrapper
    '''

    psmdf.scan_module(module_data)
    assert psmdf.ps_version == '6.1.0'
    assert psmdf.cs_utils_wrapper == {}
    assert psmdf.cs_utils_module == {}
    assert psmdf.become

# Generated at 2022-06-10 23:28:57.676330
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    pass

# Generated at 2022-06-10 23:29:54.867403
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    rf = PSModuleDepFinder()
    assert rf.scan_exec_script('win_service') == None


# Generated at 2022-06-10 23:29:58.545830
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    error_msg = "Invalid module_data, expected type str"
    try:
        ps_finder = PSModuleDepFinder()
        ps_finder.scan_exec_script(None)
    except Exception as e:
        assert str(e) == error_msg


# Generated at 2022-06-10 23:30:04.273540
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(b"exec-wrapper")

    module_name = "exec-wrapper"
    assert module_name in finder.exec_scripts.keys()
    assert finder.exec_scripts[module_name]

    if C.DEFAULT_DEBUG:
        assert b'#' in finder.exec_scripts[module_name]
    else:
        assert b'#' not in finder.exec_scripts[module_name]

    assert module_name in finder.ps_modules.keys()


# Generated at 2022-06-10 23:30:06.481605
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('/tmp/test_test_test.ps1')



# Generated at 2022-06-10 23:30:17.684942
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # The purpose of this test is to test that scan_module() parses
    # the module utils properly, including the 'AnsibleRequires'
    # comments introduced with Ansible 2.10. For example, the following
    # module has a reference to two module utils, which are the only
    # requirements that should be returned.
    #
    # #Requires -Module Ansible.ModuleUtils.Json
    #
    # #AnsibleRequires -PowerShell ansible_collections.ns.coll.plugins.module_utils.validate_powershell_module

    # Test variables
    module_metadata = {
        "name": "ansible_collection.ns.coll.module",
        "version": "1.0.0",
        "namespace": "ns",
        "collection": "coll",
    }
    module_data

# Generated at 2022-06-10 23:30:28.950169
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():

    finder = PSModuleDepFinder()
    finder.scan_module(b'')
    assert finder.ps_modules == dict()
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.exec_scripts == dict()

    finder = PSModuleDepFinder()
    ps_module_data = b'#Requires -Module Ansible.ModuleUtils.Test\n' \
                     b'#Requires -Module Ansible.ModuleUtils.Test2\n'

    finder.scan_module(ps_module_data)
    assert len(finder.ps_modules) == 2
    assert finder.cs_utils_wrapper == dict()
    assert finder.cs_utils_module == dict()
    assert finder.exec_scripts == dict()

# Generated at 2022-06-10 23:30:40.978102
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test no name passed
    dep_finder = PSModuleDepFinder()
    result = dep_finder.scan_exec_script()
    assert result == None

    # test for when there is no name passed in
    dep_finder = PSModuleDepFinder()
    result = dep_finder.scan_exec_script(None)
    assert result == None

    # test for when there is no script found
    dep_finder = PSModuleDepFinder()
    result = dep_finder.scan_exec_script("test")
    assert result == None

    # test for when there is a script found
    dep_finder = PSModuleDepFinder()
    result = dep_finder.scan_exec_script("win_ping")

# Generated at 2022-06-10 23:30:43.117914
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # test_PSModuleDepFinder_scan_exec_script() : Test cases for scan_exec_script
    pass


# Generated at 2022-06-10 23:30:54.920947
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    import shutil
    module_loader = PSModuleDepFinder()
    temp_path = '/tmp/ansible-collections/ansible_collections/ansible/test_collection/plugins/module_utils/test_module_utils'
    os.makedirs(temp_path)
    os.makedirs(temp_path + 'ps')
    ps_file = temp_path + '/test_module_utils.psm1'
    cs_file = temp_path + '/ps/test_module_utils.cs'
    required_cs_file = temp_path + '/ps/test_required_module_utils.cs'
    required_file = temp_path + '/test_required_module_utils.psm1'

# Generated at 2022-06-10 23:31:04.286225
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:33:01.765275
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils.common.process import module_dep_finder_process

    dep_finder = module_dep_finder_process.PSModuleDepFinder()
    dep_finder.scan_exec_script("ExecutionWrapper")
    assert(dep_finder.exec_scripts["ExecutionWrapper"].startswith(b"#ExecutionWrapper (^_^)"))

