

# Generated at 2022-06-10 23:23:29.223268
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert True == True

# Generated at 2022-06-10 23:23:41.463887
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest

    @pytest.mark.parametrize('name, ext, fqn, optional', [
        ('Ansible.ModuleUtils.SomeUtil', '.ps1', None, False),
        ('ansible_collections.some.collection.plugins.module_utils.OtherUtil', '.ps1', None, False),
    ])
    def test_module_util_found(self, monkeypatch, name, ext, fqn, optional):
        def _add_module(self, name, ext, fqn, optional, wrapper=False):
            pass
        monkeypatch.setattr(PSModuleDepFinder, '_add_module', _add_module)
        ps_module_dep_finder = PSModuleDepFinder()

# Generated at 2022-06-10 23:23:42.608783
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False, "Unit test not implemented"

# Generated at 2022-06-10 23:23:53.511128
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    #
    # docstring used by pylint
    #
    """
    :param module_data:
    :param fqn:
    :param wrapper:
    :param powershell:
    :return:
    """
    #
    #
    #

# Generated at 2022-06-10 23:24:05.517471
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    md = PSModuleDepFinder()
    md.scan_module(
        b'using ansible_collections.ns.coll.plugins.module_utils.abc;',
        fqn='abc.file',
        wrapper=False,
        powershell=False
    )
    md.scan_module(
        b'#Requires -Module Ansible.ModuleUtils.abc',
        fqn='abc.file',
        wrapper=False,
        powershell=True
    )

    assert md.ps_modules['Ansible.ModuleUtils.abc']['data']
    assert md.cs_utils_module['ansible_collections.ns.coll.plugins.module_utils.abc']['data']


# Generated at 2022-06-10 23:24:17.599459
# Unit test for method scan_module of class PSModuleDepFinder

# Generated at 2022-06-10 23:24:22.907235
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_module_dep_finder = PSModuleDepFinder()

    ps_module_dep_finder.scan_module("#Requires -Module Ansible.ModuleUtils.Powershell")

    assert ps_module_dep_finder.ps_modules['Ansible.ModuleUtils.Powershell']['path'] == 'ansible/module_utils/powershell/Powershell.psm1'


# Generated at 2022-06-10 23:24:27.100644
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import pytest

    # This is a placeholder for a test. Replace this with real tests.
    #
    # Original message:
    #   This requires pytest-ansible in your test environment.
    pytest.skip("no valid test")



# Generated at 2022-06-10 23:24:38.374348
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # do not execute unit tests if we are in a PR build (no code coverage)
    skip_test = os.environ.get('BUILD_SOURCEBRANCH')
    if skip_test:
        return

    psmdf = PSModuleDepFinder()
    data = b"#Requires -Module Ansible.ModuleUtils.Foo\n#Requires -Module Ansible.ModuleUtils.Bar"
    # ensure that newlines do not confuse the regex
    data += b"\n\n"
    data += b"#AnsibleRequires -Powershell Ansible.ModuleUtils.Foo\n#AnsibleRequires -Powershell Ansible.ModuleUtils.Bar"
    psmdf.scan_module(data)

    assert len(psmdf.ps_modules.keys()) == 4

# Generated at 2022-06-10 23:24:49.566680
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
	module_data = '\n'.join([
		'using ansible_collections.ns.coll.plugins.module_utils.foobar;',
		'#AnsibleRequires -CSharpUtil ansible_collections.ns.coll.plugins.module_utils.foobar;'
		])

	dep_finder = PSModuleDepFinder()
	dep_finder.scan_module(module_data, fqn="foo.bar", wrapper=False, powershell=True)
	assert dep_finder.ps_modules == {}
	assert dep_finder.cs_utils_module['ansible_collections.ns.coll.plugins.module_utils.foobar'] == {}


# Generated at 2022-06-10 23:25:06.664247
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder.scan_exec_script("foo")


# Generated at 2022-06-10 23:25:14.573229
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    req = PSModuleDepFinder()
    req.scan_exec_script('ansible_local')
    assert len(req.exec_scripts) == 1
    assert len(req.ps_modules) > 1
    assert len(req.cs_utils_wrapper) == 0
    assert req.ps_modules['Ansible.ModuleUtils.PowerShell.Bacon']['path'].endswith('Ansible.ModuleUtils.PowerShell.Bacon.psm1')


# Generated at 2022-06-10 23:25:23.088245
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    d = PSModuleDepFinder()
    d.scan_exec_script('basic')
    assert len(d.exec_scripts) == 1
    assert len(d.cs_utils_wrapper) == 0
    assert d.ps_modules == {}
    assert d.become == False
    d.scan_exec_script('winrm')
    assert len(d.exec_scripts) == 2
    assert len(d.cs_utils_wrapper) == 0
    assert len(d.ps_modules) == 3
    assert d.become == True



# Generated at 2022-06-10 23:25:32.471691
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    testcase_scan_exec_script_data = [
        [
            "test_exec_script",
            [
                "#AnsibleRequires -CSharpUtil ansible_collections.test.test1.plugins.module_utils.test_util",
                "#AnsibleRequires -PowerShell ..module_utils.test_util_psm1",
            ],
        ],
    ]

    def _ansible_get_data(*args, **kwargs):
        if args[0] != "ansible.executor.powershell":
            raise AnsibleError("Unexpected error")
        for t in testcase_scan_exec_script_data:
            if args[1] == t[0] + ".ps1":
                return "\n".join(t[1]) + "\n"

        return None

    original_ansible_

# Generated at 2022-06-10 23:25:33.858159
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:25:36.081562
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert(PSModuleDepFinder().scan_exec_script('common') == None)

# Generated at 2022-06-10 23:25:41.873254
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    # This method doesn't actually do anything so this is all that is needed
    finder.scan_exec_script("test_ps_exec")
    assert "test_ps_exec" in finder.exec_scripts



# Generated at 2022-06-10 23:25:46.642161
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psmd = PSModuleDepFinder()
    psmd.scan_exec_script('script')
    assert psmd.exec_scripts['script'] == b'#!/usr/bin/env python\n'



# Generated at 2022-06-10 23:25:51.018757
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    
    # Test that an AnsibleError is raised if the script does not exist
    # TODO
    
    # Test that the module is read, added to the dict and that it is scanned
    # TODO
    
    pass

# Generated at 2022-06-10 23:25:54.984171
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    m = PSModuleDepFinder()
    m.scan_exec_script('powershell_base')
    code = m.exec_scripts['powershell_base']
    assert(code.startswith(b'# Version'))


# Generated at 2022-06-10 23:26:06.357383
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pmdf = PSModuleDepFinder()
    pmdf.scan_exec_script('script')


# Generated at 2022-06-10 23:26:07.310313
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "TODO"


# Generated at 2022-06-10 23:26:11.431007
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    depfinder = PSModuleDepFinder()

    depfinder.scan_exec_script("wrapper")
    assert "wrapper" in depfinder.exec_scripts
    assert "#Requires -Module Ansi" in depfinder.exec_scripts["wrapper"].decode("utf-8")



# Generated at 2022-06-10 23:26:13.155812
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # TODO: implement unit test
    pass


# Generated at 2022-06-10 23:26:18.920009
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_class = PSModuleDepFinder()
    # Checking whether function returns the desired output for strings
    assert PSModuleDepFinder_class.scan_exec_script("script_name") == "script_name"


# Generated at 2022-06-10 23:26:22.912706
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    error_triggered = False

    try:
        p = PSModuleDepFinder()
        p.scan_exec_script("None")
    except AnsibleError:
        error_triggered = True

    assert error_triggered



# Generated at 2022-06-10 23:26:24.982562
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("powershell.exe")


# Generated at 2022-06-10 23:26:32.493321
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cls = PSModuleDepFinder()

    assert cls.exec_scripts == dict()

    name = "tmp" + str(random.randint(0, 10000000))
    cls.scan_exec_script(name)

    assert cls.exec_scripts[str(name) + ".ps1"] == pkgutil.get_data("ansible.executor.powershell", to_native(name + ".ps1"))


# Generated at 2022-06-10 23:26:36.822627
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_finder = PSModuleDepFinder()
    ps_module_finder.scan_exec_script("win_register_dotnet")
    assert ps_module_finder.exec_scripts["win_register_dotnet"]
    assert ps_module_finder.exec_scripts["win_register_dotnet"].startswith(b"function win_register_dotnet")

# Generated at 2022-06-10 23:26:39.501775
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  class_instance = PSModuleDepFinder()
  assert class_instance.scan_exec_script('') == NotImplementedError


# Generated at 2022-06-10 23:26:56.768356
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mu = PSModuleDepFinder()
    module = 'Secondary.psm1'
    mu.scan_exec_script(name=module)
    script = mu.exec_scripts.get(key=module)

# Generated at 2022-06-10 23:26:58.066196
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:27:10.101840
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_dep_finder = PSModuleDepFinder()
    # This is the hash of the test-module.psm1 file that contains the following condition:
    #if ($Script:ThisScriptIsLoadedFromTestModule -ne $true) {
    #    throw 'Module should be loaded from Ansible.ModuleUtils.TestModule'
    #}
    assert test_dep_finder.scan_exec_script('test-module') == to_bytes('4d31b4c4f4b63eb8a6d32d75e1537ccb')

# Unit tests for class PSModuleDepFinder

# Generated at 2022-06-10 23:27:11.688375
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    test_obj.scan_exec_script("foo")


# Generated at 2022-06-10 23:27:18.593856
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # check whether basic exec wrapper dependencies are added
    finder = PSModuleDepFinder()
    finder.scan_exec_script("basic")
    assert (len(finder.exec_scripts.keys()) == 1 and "basic" in finder.exec_scripts.keys())
    assert len(finder.cs_utils_wrapper.keys()) == 1
    assert "ansible_collections.sensu.sensu.plugins.module_utils.sensu_snippets" in finder.cs_utils_wrapper.keys()


# Generated at 2022-06-10 23:27:25.389518
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # obtains all executor powershell scripts and runs scan_module on them
    import os
    import pkgutil
    from ansible.executor.powershell import executor_scripts

    mdf = PSModuleDepFinder()
    for script in executor_scripts():
        data = pkgutil.get_data("ansible.executor.powershell", script)
        mdf.scan_exec_script(script)



# Generated at 2022-06-10 23:27:26.620368
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False



# Generated at 2022-06-10 23:27:37.200023
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    assert 'Ansible.ModuleUtils.Common' in finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.Convert' in finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.ConvertFrom' in finder.ps_modules.keys()
    assert 'Ansible.ModuleUtils.Powershell.ConvertTo' in finder.ps_modules.keys()

    assert 'Ansible.ModuleUtils.Network.Network' in finder.ps_modules.keys()
    assert 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.network' in finder.ps_modules.keys()

# Generated at 2022-06-10 23:27:40.108852
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    mdf = PSModuleDepFinder()
    mdf.scan_module(".Module.psm1", 'ansible_collections.namespace.collection.plugins.name')



# Generated at 2022-06-10 23:27:44.196234
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for powershell executor script
    finder = PSModuleDepFinder()
    finder.scan_exec_script('json')
    assert 'json' in finder.exec_scripts.keys()

# Generated at 2022-06-10 23:27:58.351690
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
        import sys
        import unittest
        psmdf = PSModuleDepFinder()
        psmdf.scan_exec_script('WindowsComputeResource')



# Generated at 2022-06-10 23:28:08.647102
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os
    import tempfile
    from ansible.module_utils.common.removed import removed
    removed(module='PSModuleDepFinder', version='2.5', removed_in='2.5', removal_type='deprecate',
            alternative=None, collection_name=None)
    # test with a valid exec script
    fixture = {
        'ModuleUtils.Common.ps1': '#This is a ps module.',
        'TestCollection.ModuleUtils.Common.ps1': '#This is another ps module.',
    }
    with tempfile.TemporaryDirectory() as temp_dir:
        for name, content in fixture.items():
            with open(os.path.join(temp_dir, name), 'w', encoding='utf-8') as exec_script:
                exec_script.write(content)

# Generated at 2022-06-10 23:28:13.383635
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Helper to test secret and known values for a given yaml file in the ./test_data/inventory directory
    fqn = 'ansible_collections.ns.coll.plugins.module_utils.name'
    finder = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.executor.powershell", "exec_wrapper.ps1")
    finder.scan_module(data, fqn=fqn, wrapper=True, powershell=True)
    assert isinstance(finder.exec_scripts["exec_wrapper"], bytes)



# Generated at 2022-06-10 23:28:17.412064
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("basic")
    assert dep_finder.exec_scripts["basic"] is not None
    assert dep_finder.cs_utils_wrapper != dict()


# Generated at 2022-06-10 23:28:23.616079
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def test_function():
        dep_finder = PSModuleDepFinder()
        dep_finder.scan_exec_script('common')
        assert 'common' in dep_finder.exec_scripts
        assert isinstance(dep_finder.exec_scripts['common'], bytes)
        assert 'version' in dep_finder.cs_utils_wrapper
    test_function()

# Generated at 2022-06-10 23:28:33.872793
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Test that the powershell script is called and scanned correctly. mock_module_utils is a script
    # that defines a single module.
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("mock_module_util")

    module_data = pkgutil.get_data("ansible.executor.powershell", "mock_module_util.ps1")
    assert dep_finder.exec_scripts.get("mock_module_util") == module_data
    assert to_native(dep_finder.exec_scripts.get("mock_module_util")) == to_native(module_data)
    assert len(dep_finder.ps_modules) == 1
    assert list(dep_finder.ps_modules.keys()) == ["Ansible.ModuleUtils.MockModuleUtil"]

# Generated at 2022-06-10 23:28:42.376467
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.powershell.executor.module_utils.providers import win_pwd_provider
    # Initialize the class
    depfinder = PSModuleDepFinder()

    # Test the scan_exec_script method
    this_module_powershell = win_pwd_provider.__file__
    depfinder.scan_exec_script(to_bytes(this_module_powershell))
    assert len(depfinder.exec_scripts.keys()) == 1



# Generated at 2022-06-10 23:28:54.316739
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    finder = PSModuleDepFinder()
    test_data = dict()
    test_data['module_utils'] = dict()
    test_data['module_utils/test_util1.py'] = '#!/usr/bin/python\nfrom ansible.module_utils.test_util2 import hello\n'
    test_data['module_utils/test_util2.py'] = '"""\nThis is the test_util2 module.\n"""\n\nfrom ansible.module_utils.test_util3 import hello\n\n\ndef hello():\n    """ Print hello\n    """\n    print("Hello, World!")\n'

# Generated at 2022-06-10 23:28:57.872165
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    
    # Scan the powershell script name, expected to return None.
    assert ps_module_dep_finder.scan_exec_script(name='powershell') is None

if __name__ == "__main__":
    test_PSModuleDepFinder_scan_exec_script()

# Generated at 2022-06-10 23:29:10.678074
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:29:32.512086
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script(b"dir")
    assert len(finder.exec_scripts) == 1
    assert len(finder.ps_modules) == 7
    assert b"dir" in finder.exec_scripts
    assert b"Get-UnicodeData" in finder.ps_modules
    assert b"Ansible.ModuleUtils.Powershell.Clipboard" in finder.ps_modules
    assert b"Ansible.ModuleUtils.Powershell.Convert" in finder.ps_modules
    assert b"Ansible.ModuleUtils.Powershell.Misc" in finder.ps_modules
    assert b"Ansible.ModuleUtils.Powershell.String" in finder.ps_modules

# Generated at 2022-06-10 23:29:36.048962
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    psf = PSModuleDepFinder()
    psf.scan_exec_script('connect')
    assert 'connect' in psf.exec_scripts.keys()



# Generated at 2022-06-10 23:29:38.965522
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()

    dep_finder.scan_exec_script('win_copy')


# Generated at 2022-06-10 23:29:40.353810
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass


# Generated at 2022-06-10 23:29:44.249387
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("common")
    assert len(finder.exec_scripts) == 1
    assert "common" in finder.exec_scripts

# Generated at 2022-06-10 23:29:46.674834
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('win_ping')
    assert True

# Generated at 2022-06-10 23:29:48.574772
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: add unit test for scan_exec_script
    pass

# Generated at 2022-06-10 23:29:58.940589
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    importlib = import_module("importlib")
    # create a fake module_util inside lib/ansible/executor/powershell
    module = None
    try:
        module = type('Ansible.ModuleUtils.Test.Util', (object,), {'__file__': "test"})
        module.__package__ = "Ansible.ModuleUtils.Test"
        sys_modules_old = importlib.sys.modules.copy()
        sys_modules_new = {
            "ansible.executor.powershell": module,
            "ansible.executor.powershell.Test.Util": module,
            "ansible.executor.powershell.Test": module,
        }
        importlib.sys.modules.update(sys_modules_new)
    except Exception as e:
        raise Ansible

# Generated at 2022-06-10 23:30:00.846763
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    '''
    Unit test for method scan_exec_script of class PSModuleDepFinder
    '''
    pass

# Generated at 2022-06-10 23:30:02.600826
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The test_PSModuleDepFinder_scan_exec_script() method of the PSModuleDepFinder class implementation
    pass

# Generated at 2022-06-10 23:30:14.286877
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # noinspection PyUnusedLocal
    psmdf = PSModuleDepFinder()


# Generated at 2022-06-10 23:30:17.525764
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script("pwsh")
    finder.scan_exec_script("pwsh")



# Generated at 2022-06-10 23:30:19.012070
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass# #TODO: Write test here

# Generated at 2022-06-10 23:30:22.064132
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_data = '''
'''
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script(module_data)


# Generated at 2022-06-10 23:30:28.159032
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    r = finder.scan_exec_script("exec_parse_json")
    assert type(r) == type(None), "test_PSModuleDepFinder_scan_exec_script1 failed"

test = PSModuleDepFinder()
r = test.scan_exec_script("exec_parse_json")
type(r)


# Generated at 2022-06-10 23:30:40.481592
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2

    finder = PSModuleDepFinder()
    finder.scan_exec_script('posh-vendor')

# Generated at 2022-06-10 23:30:45.629841
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()

    finder.scan_exec_script('Ansible.ArgumentSpec')
    assert finder.exec_scripts['Ansible.ArgumentSpec'].decode('utf-8') == pkgutil.get_data('ansible.executor.powershell', 'Ansible.ArgumentSpec.ps1').decode('utf-8')
    assert finder.become


# Generated at 2022-06-10 23:30:52.017059
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ansible_module_utils = {}
    ansible_module_utils['ansible_collections.test.test_module_utils.test_module_utils.test_module_utils'] = {
		'cs_utils_module': {
			'ansible_collections.test.test_module_utils.test_module_utils.test_module_utils.test_module_utils':{
				'path':'ansible_collections/test/test_module_utils/test_module_utils/test_module_utils/test_module_utils.psm1',
				'data':b'# unit test for scan_exec_script\n# '
			}
		}
	}
    test_module_util = {}

# Generated at 2022-06-10 23:31:01.900623
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # Testing with valid data.
    ps_module_depfinder_obj = PSModuleDepFinder()
    ps_module_depfinder_obj.scan_module("#Requires -Module Ansible.ModuleUtils.{name}")
    ps_module_depfinder_obj.scan_module("#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}")
    ps_module_depfinder_obj.scan_module("#Requires -Module Ansible.ModuleUtils.{name}")
    ps_module_depfinder_obj.scan_module("#AnsibleRequires -PowerShell Ansible.ModuleUtils.{name}")
    assert ps_module_depfinder_obj.ps_modules
    assert ps_module_depfinder_obj.ps_version
    assert ps_module_depfinder_obj.os_version
   

# Generated at 2022-06-10 23:31:12.521792
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils import powershell
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.ansible_release import __powershell_required_version__ as ps_version
    from ansible.module_utils.six import PY2

    ps_deps = PSModuleDepFinder()
    ps_deps.scan_exec_script("python_loader")

    # We don't want to assume that the Python binary is always in the same place
    python_path = get_bin_path('python')


# Generated at 2022-06-10 23:31:29.793139
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    finder = PSModuleDepFinder()
    finder.scan_exec_script('../../module_utils/basic.py')
    assert finder.exec_scripts['../../module_utils/basic.py'] is not None
    assert finder.cs_utils_wrapper['ansible_collections.ansible.builtin.plugins.module_utils.basic'] is not None

# Generated at 2022-06-10 23:31:31.108015
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # TODO: Write unit test for method scan_exec_script of class PSModuleDepFinder
    pass


# Generated at 2022-06-10 23:31:37.907837
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    obj = PSModuleDepFinder()
    obj.scan_exec_script("open_powershell_session")
    assert obj.exec_scripts["open_powershell_session"]


if __name__ == '__main__':

    fqn = "ansible.builtin.win_ping"

    # load module data, or scan the module
    mu = PSModuleDepFinder()
    data = to_bytes(_slurp("%s.psm1" % to_text(resource_from_fqcr(fqn))))
    mu.scan_module(data, fqn=fqn, wrapper=False)

    print("PSUtils:")
    for util in mu.ps_modules.keys():
        print("    %s" % util)

    print("CsUtils:")

# Generated at 2022-06-10 23:31:43.853129
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Unit test for function scan_exec_script of class PSModuleDepFinder
    :return:
    """
    ps_modules = dict()

    cs_utils_wrapper = dict()

    dep_finder = PSModuleDepFinder()
    dep_finder.ps_modules = ps_modules
    dep_finder.cs_utils_wrapper = cs_utils_wrapper

    dep_finder.scan_exec_script('{}')

    assert dep_finder.ps_modules
    assert dep_finder.cs_utils_wrapper



# Generated at 2022-06-10 23:31:45.638345
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """
    test_PSModuleDepFinder_scan_module
    """
    # FIXME: needs code
    assert True



# Generated at 2022-06-10 23:31:58.010911
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Initialize the module scan and add the exec wrapper
    p = PSModuleDepFinder()
    p.scan_exec_script('ok')

# Generated at 2022-06-10 23:31:58.697481
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:32:02.378472
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('exec_wrapper')
    assert len(ps_module_dep_finder.ps_modules) == 1
    assert len(ps_module_dep_finder.exec_scripts) == 1


# Generated at 2022-06-10 23:32:08.158149
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Using the constructed parameter, run the method under test
    depfinder = PSModuleDepFinder()
    depfinder.scan_exec_script("script.ps1")

    # Check the exectution result
    expected = {u"script.ps1": u"newdata"}
    assert depfinder.exec_scripts == {u"script.ps1": u"newdata"}



# Generated at 2022-06-10 23:32:19.063154
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('Start test scan_exec_script')
    # test initialization
    c = PSModuleDepFinder()
    # test function
    c.scan_exec_script("posh-netapi")
    c.scan_exec_script("posh-dsc")
    c.scan_exec_script("power_shell_api")
    c.scan_exec_script("win_psmodule_manager")
    c.scan_exec_script("win_package")
    print('scan_exec_script result {}'.format(c.ps_modules))
    print('End test scan_exec_script')


# Generated at 2022-06-10 23:32:41.606344
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test with a nonexistent script name
    # assertRaises(AnsibleError, self.PSModuleDepFinder().scan_exec_script, "nonexistent_exec_script")
    try:
        PSModuleDepFinder().scan_exec_script("nonexistent_exec_script")
    except AnsibleError as e:
        assert "Could not find executor powershell script for 'nonexistent_exec_script'" in to_text(e)
    else:
        assert False, "No exception was thrown"

    # Test with a real script name
    pdm = PSModuleDepFinder()
    pdm.scan_exec_script("json")
    assert to_text(pdm.exec_scripts["json"][0:14]).lower() == b'function get-'


# Generated at 2022-06-10 23:32:49.749219
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    module_finder = PSModuleDepFinder()
    module_finder.scan_exec_script('powershell.ps1')
    assert len(module_finder.ps_modules.keys()) == 1
    assert module_finder.ps_modules['Ansible.ModuleUtils._AnsibleModuleBase']
    assert len(module_finder.cs_utils_wrapper.keys()) == 1
    assert module_finder.cs_utils_wrapper['ansible_collections.ansible.builtin.plugins.module_utils.json_utils.json']
    assert len(module_finder.exec_scripts.keys()) == 1
    assert module_finder.exec_scripts['powershell']

# Generated at 2022-06-10 23:32:52.333525
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
     assert PSModuleDepFinder.scan_exec_script == "some_exec_script.ps1"

# Generated at 2022-06-10 23:32:58.083878
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script("exec-network")
    assert dep_finder.exec_scripts["exec-network"]
    assert not dep_finder.ps_modules
    assert not dep_finder.cs_utils_wrapper


# Generated at 2022-06-10 23:33:01.212347
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    mdf = PSModuleDepFinder()
    mdf.scan_exec_script("Basic")
    assert len(mdf.exec_scripts) == 1
    assert len(mdf.ps_modules) > 0
