

# Generated at 2022-06-10 23:23:33.420654
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():

    # Create a test object
    dep_finder = PSModuleDepFinder()

    # Call scan_exec_script method
    dep_finder.scan_exec_script('test')



# Generated at 2022-06-10 23:23:44.548609
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    imp = PSModuleDepFinder()
    imp.scan_exec_script("exec_lib")
    assert b"This is an execute wrapper" in imp.exec_scripts["exec_lib"]
    assert imp.ps_modules["Ansible.ModuleUtils.Common"]['path'] == u'/home/jenkins/workspace/ansible-pull-python2.7/lib/ansible/module_utils/common.psm1'
    assert imp.cs_utils_wrapper["ansible_collections.ansible.posix.plugins.module_utils.compat"]['path'] == u'/home/jenkins/workspace/ansible-pull-python2.7/lib/ansible/module_utils/posix/linux.py'

# Generated at 2022-06-10 23:23:55.227220
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    cwd = os.getcwd()
    ps_module_name = "test_module"
    ps_module_path = os.path.join(cwd, "test_module")
    os.makedirs(ps_module_path)

    ps_module_utils_path = os.path.join(cwd, "test_module_utils")
    os.makedirs(ps_module_utils_path)

    with open(os.path.join(ps_module_path, ps_module_name + ".psm1"), "w") as f:
        f.write('''#AnsibleRequires -PowerShell ..module_utils.my_module_util.ps1''')


# Generated at 2022-06-10 23:24:02.682682
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
  f = PSModuleDepFinder()
  # dict object
  exec_scripts= {"name": "name"}
  # string object
  name = "name"
  # AnsibleError object
  raise AnsibleError("err")

  try:
    f.scan_exec_script(name)
  except AnsibleError as e:
    assert str(e) == "err"

# Generated at 2022-06-10 23:24:05.597265
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """
    Test method scan_exec_script of class PSModuleDepFinder
    """
    ps_module_dep_finder_obj = PSModuleDepFinder()
    ps_module_dep_finder_obj.scan_exec_script('RunAs')


# Generated at 2022-06-10 23:24:07.637382
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """ Tests method scan_exec_script of class PSModuleDepFinder """
    pass

# Generated at 2022-06-10 23:24:19.700286
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import os.path
    import sys
    # This is the location on disk of the test/units/module_loader/data/ps_wrapper
    data_path = os.path.join(os.path.dirname(__file__), "data", "ps_wrapper")
    sys.path.append(os.path.abspath(data_path))

    from ps_wrapper import ps_wrapper_before_2_3, ps_wrapper_after_2_3

    # create the object
    finder = PSModuleDepFinder()

    # get the data for a script that exists in the above module_utils
    finder.scan_exec_script('compressed_script')
    # verify that the data returned matches what we expect
    assert set(finder.exec_scripts.keys()) == {'compressed_script'}
    assert finder

# Generated at 2022-06-10 23:24:29.773431
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    g = dict()
    def scan_module(self, module_data, fqn=None, wrapper=False, powershell=True):
        g["self"] = self
        g["module_data"] = module_data
        g["fqn"] = fqn
        g["wrapper"] = wrapper
        g["powershell"] = powershell
    def _add_module(self, name, ext, fqn, optional, wrapper=False):
        g["self_add_module"] = self
        g["name_add_module"] = name
        g["ext_add_module"] = ext
        g["fqn_add_module"] = fqn
        g["optional_add_module"] = optional
        g["wrapper_add_module"] = wrapper
    def scan_exec_script(self, name):
        g

# Generated at 2022-06-10 23:24:30.864452
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    assert False, "Test not implemented"


# Generated at 2022-06-10 23:24:31.522104
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    pass

# Generated at 2022-06-10 23:25:08.153424
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("posh-dnscmd")
    ps_module_dep_finder.scan_exec_script("posh-winrm")
    assert len(ps_module_dep_finder.exec_scripts) == 2


# Generated at 2022-06-10 23:25:15.729821
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    for method in [lambda: PSModuleDepFinder.scan_exec_script(PSModuleDepFinder, "name"),
                   lambda: PSModuleDepFinder.scan_exec_script(PSModuleDepFinder(), "name")]:
        try:
            method()
            raise Exception("Failure to raise exception")
        except NotImplementedError:
            pass
        except Exception as ex:
            raise Exception("Wrong exception raised: %s" % ex)

# Generated at 2022-06-10 23:25:27.322326
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    import os
    from ansible.module_utils.common._collections_compat import CollectionLoader

    os.environ["ANSIBLE_COLLECTIONS_PATH"] = "./test/collections/"

    loader = CollectionLoader()
    collection_list = loader.list_collections()
    collection_to_test = "testnamespace.testcollection"
    module_fqn = collection_to_test + ".testmodule"

    if collection_to_test not in collection_list:
        print("Collection %s is not available" % collection_to_test)
        exit(0)

    reader = loader._load_collections(loader._get_collection_name_from_file(collection_to_test),
                                      loader._get_collection_path_from_file(collection_to_test))

    module_path = reader.path_

# Generated at 2022-06-10 23:25:37.765066
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def func(mock_dep_finder):
        mock_dep_finder.scan_exec_script('test')
        mock_dep_finder.scan_exec_script('test')

    mock_dep_finder = PSModuleDepFinder()
    func(mock_dep_finder)
    assert mock_dep_finder.exec_scripts == {'test': b'\n'}

    mock_dep_finder = PSModuleDepFinder()
    try:
        mock_dep_finder.scan_exec_script('test')
        assert False
    except AnsibleError as e:
        assert e.message == "Could not find executor powershell script for 'test'"


# Generated at 2022-06-10 23:25:51.504348
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # The PowerShell module requires the module_utils to be a dict of dicts.
    ps_module = {
        # The module_utils dict contains a list of dicts.
        "module_utils": [],
    }

    module_data = pkgutil.get_data("ansible.executor.powershell", "module.psm1")
    if getattr(module_data, 'read', None):
        module_data = module_data.read()

    # Add the required PowerShell module_utils
    modfinder = PSModuleDepFinder()
    modfinder.scan_module(module_data, "module", wrapper=True)

    # Convert ps_module_utils dict to a list of dicts.
    ps_module_utils = []
    keys = list(modfinder.ps_modules.keys())
    keys.sort()

   

# Generated at 2022-06-10 23:25:58.934524
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # create a TestPSModuleDepFinder class
    TestPSModuleDepFinder = type(
        'TestPSModuleDepFinder',
        (PSModuleDepFinder,),
        {},
    )
    test_exec_script = TestPSModuleDepFinder()

    # check that exec script is processed as expected
    assert test_exec_script.scan_exec_script('test_exec_script') is None
    assert test_exec_script.exec_scripts == {'test_exec_script': None}



# Generated at 2022-06-10 23:26:02.507119
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script("script_name")


# Generated at 2022-06-10 23:26:09.482093
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    print('test_PSModuleDepFinder_scan_exec_script start')
    from ansible.plugins.loader import init_loader
    import os

    module_loader = init_loader()
    module_loader.add_directory(os.path.join(C.ANSIBLE_LIB_PATH, 'ansible', 'modules'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'ansible_collections', 'ansible_namespace', 'collection_name', 'plugins', 'modules'))

    depfinder = PSModuleDepFinder()
    mod_data = resource_from_fqcr(module_loader, 'ansible_namespace.collection_name.test_module')
    depfinder.scan_module(mod_data.data(), wrapper=False, powershell=True)

# Generated at 2022-06-10 23:26:22.735839
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_dep_finder = PSModuleDepFinder()
    old_exec_scripts = ps_dep_finder.exec_scripts
    old_ps_modules = ps_dep_finder.ps_modules
    ps_dep_finder.exec_scripts = {'foo': 'bar',}
    ps_dep_finder.ps_modules = {'foo': 'bar',}


# Generated at 2022-06-10 23:26:31.109929
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible_collections.ansible.tmp_unit_tests.plugins.module_utils.powershell.module_script_parts as msp
    import ansible_collections.ansible.tmp_unit_tests.plugins.module_utils.powershell.module_utils.basic as basic

    finder = PSModuleDepFinder()

    assert msp.__name__ not in finder.ps_modules
    assert msp.__name__ not in finder.cs_utils_module

    finder.scan_exec_script(msp.__name__)

    assert msp.__name__ in finder.ps_modules
    assert msp.__name__ not in finder.cs_utils_module
    assert basic.__name__ in finder.ps_modules
    assert basic.__name__ not in finder.cs_utils

# Generated at 2022-06-10 23:27:11.384573
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    PSModuleDepFinder_mock = mock.MagicMock()
    PSModuleDepFinder_mock.name = "PSModuleDepFinder_mock"
    PSModuleDepFinder_mock.base_module_names = ["base"]
    PSModuleDepFinder_mock.scan_module = mock.MagicMock()
    result = PSModuleDepFinder_mock.scan_exec_script("no_data")
    assert result is None
    result = PSModuleDepFinder_mock.scan_exec_script("could_not_find_file")
    assert result is None
    result = PSModuleDepFinder_mock.scan_exec_script("comment_out")
    assert result is None
    assert PSModuleDepFinder_mock.scan_module.call_count == 3
    PSModuleDepFinder

# Generated at 2022-06-10 23:27:14.877825
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    my_dict = {
        'section1': 'value1',
        'section2': 'value2'
    }
    assert my_dict['section1'] == 'value1'



# Generated at 2022-06-10 23:27:18.867023
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    def test_PSModuleDepFinder_scan_exec_script_01():
        # Test with a non existent script
        # This should invoke AnsibleError
        pass
    def test_PSModuleDepFinder_scan_exec_script_02():
        # Test with a valid script
        # This should not invoke any exception
        pass


# Generated at 2022-06-10 23:27:20.966825
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    t_obj = PSModuleDepFinder()
    t_obj.scan_exec_script('/bin/sh')


# Generated at 2022-06-10 23:27:32.752042
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    import os
    import pkgutil
    import re
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    import os
    import pkgutil
    import re
    from ansible.errors import AnsibleError

# Generated at 2022-06-10 23:27:41.017641
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    try:
        import ansible.executor.powershell
    except ImportError:
        pytest.skip("Unable to import powershell modules")

    md = PSModuleDepFinder()
    md.scan_exec_script("test")
    assert md.exec_scripts["test"] is not None

    md = PSModuleDepFinder()
    md.scan_exec_script("test")
    md.scan_exec_script("test2")
    assert md.exec_scripts["test"] is not None
    assert md.exec_scripts["test2"] is not None

# Generated at 2022-06-10 23:27:55.783232
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    expected = {}
    expected["out_data"] = b'out(\'{"changed":false,"rc":0,"stdout":"","stdout_lines":[],"warnings":[]}\')'
    expected["exec_data"] = b'function out(\'{"changed":false,"rc":0,"stdout":"","stdout_lines":[],"warnings":[]}\') {\n'
    expected["ps_modules"] = {}

    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.ps_modules = {}

    script_data = b'function out(data) {\n'
    expected["out_data"] = script_data
    ps_module_dep_finder.scan_exec_script('test')

    assert ps_module_dep_finder.exec_scripts == expected


# Generated at 2022-06-10 23:28:06.136438
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    if not is_pytest_installed():
        assert True
    else:
        import tempfile
        import shutil
        import os
        import os.path
        import sys
        import json
        print("\n***** In Test_PSModuleDepFinder_scan_exec_script *****")
        print("***** In Test_PSModuleDepFinder_scan_exec_script *****")

        dirpath = tempfile.mkdtemp()
        module_name = 'test_module'
        module_path = os.path.join(dirpath, module_name + '.ps1')

# Generated at 2022-06-10 23:28:07.484015
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False, "TODO: Implement"


# Generated at 2022-06-10 23:28:14.027164
# Unit test for method scan_exec_script of class PSModuleDepFinder

# Generated at 2022-06-10 23:28:52.781205
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Note: we're using the scan_exec_script method which is the only method that can be tested standalone
    # So we just have to be sure that it can be called without any problem
    # It's the responsability of the other tests to ensure that scan_exec_script will actually find the dependencies
    ps_mod_dep_finder = PSModuleDepFinder()
    ps_mod_dep_finder.scan_exec_script(b'require_ansible_collections')



# Generated at 2022-06-10 23:28:59.900384
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    """Unit test of class `PSModuleDepFinder`"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.powershell.common import CMD_RUNNER, CMD_INVOKER

    finder = PSModuleDepFinder()
    finder.scan_module(pkgutil.get_data("ansible.module_utils.powershell", "basic.psm1"),
                       fqn="Ansible.ModuleUtils.Basic", wrapper=False, powershell=True)
    assert getattr(finder, CMD_RUNNER) == [b'Ansible.ModuleUtils.Basic',
                                           b'Ansible.ModuleUtils.ArgumentSpec',
                                           b'Ansible.ModuleUtils.CommonArgs']

# Generated at 2022-06-10 23:29:04.921850
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    #prepare
    name = 'Test'
    #file = open(name)
    #name = file.readlines()
    #file.close()
    #scan_module(name)
    #assert_equals('test', scan_module(name))


# Generated at 2022-06-10 23:29:15.480125
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible_collections
    import unittest

    class TestPSModuleDepFinder(unittest.TestCase):

        def test_PSModuleDepFinder_scan_exec_script(self):
            from ansible.module_utils.powershell import PSModuleDepFinder
            import ansible_collections.example_namespace.example_collection.plugins.module_utils.example_module_util

            # get path of the resource loaded
            n_package_name = to_native(ansible_collections.example_namespace.example_collection.__name__)
            n_resource_name = to_native(ansible_collections.example_namespace.example_collection.__name__)
            resource = resource_from_fqcr(f"{n_package_name}.{n_resource_name}")

# Generated at 2022-06-10 23:29:26.880462
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    fqn = 'ansible_collections.my.my_module'
    module_name = 'my_module'
    module_data = pkgutil.get_data('ansible_collections.my.my_module', module_name)
    # Remove BOM from data
    data = module_data[3:]
    # b64encode the data for testing
    module_data = base64.b64encode(data)

    ps_module_dep_finder_obj = PSModuleDepFinder()
    ps_module_dep_finder_obj.scan_module(data, fqn=fqn)
    assert module_name in ps_module_dep_finder_obj.ps_modules.keys()
    assert len(ps_module_dep_finder_obj.ps_modules.keys()) == 2

# Generated at 2022-06-10 23:29:32.511005
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    util = PSModuleDepFinder()
    name = "script1"
    file_content = "echo 'script content'"
    pkgutil.get_data = mock_get_data(file_content)
    util.scan_exec_script(name)
    assert name in util.exec_scripts
    assert util.exec_scripts[name] == to_bytes(file_content)


# Generated at 2022-06-10 23:29:39.722398
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Test method scan_exec_script of class PSModuleDepFinder"""
    psmd = PSModuleDepFinder()

    try:
        psmd.scan_exec_script("no_such_file")
    except Exception as e:
        if not 'no_such_file.ps1' in e.args[0]:
            raise
        return

    # If we get here, then an exception was not thrown
    raise AssertionError("Executor script 'no_such_file.ps1' does not exist, but no exception thrown.")


# Generated at 2022-06-10 23:29:46.887257
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-10 23:29:56.670955
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # Test for method scan_exec_script(name)
    #TODO: This test method is not complete
    #ansible_collections.asnible.builtin
    #print("AnsibleCollectionDepFinder test called")
    dep_finder = PSModuleDepFinder()
    dep_finder.scan_exec_script('net_ping')
    module_df = dep_finder.ps_modules
    #print("module_df is %s" % module_df)
    #print("Exec script is %s" % dep_finder.exec_scripts)
    assert(len(dep_finder.exec_scripts) == 1)
    assert(len(dep_finder.ps_modules) == 2)


# Generated at 2022-06-10 23:29:57.802880
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    modules = PSModuleDepFinder()
    modules.scan_exec_script(to_bytes('Test'))


# Generated at 2022-06-10 23:31:06.231199
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    class ModuleData(object):
        data = None

    def test_module(module_data, fqn=None, wrapper=False, powershell=True):
        this.scan_module(module_data.data, fqn, wrapper, powershell)

    this = PSModuleDepFinder()
    this.scan_module = test_module

    # test a basic ansible module that uses the slurp util
    module_data = ModuleData()

# Generated at 2022-06-10 23:31:14.768588
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    # pylint: disable=protected-access
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    module = type("AnsibleModule", (AnsibleModule,), {"params": {}})
    dep_finder = PSModuleDepFinder()
    # First test with existing file
    dep_finder.scan_exec_script("powershell.exe")
    # Second test with non existing file
    with pytest.raises(AnsibleError) as excinfo:
        dep_finder.scan_exec_script("powershell")
    assert to_bytes("Could not find executor powershell script for 'powershell'") in excinfo.value.message
    assert dep_finder.exec_scripts["powershell.exe"]

# Generated at 2022-06-10 23:31:17.403019
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps = PSModuleDepFinder()
    ps.scan_exec_script("basic")
    

# Generated at 2022-06-10 23:31:31.651739
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    ps_dep_finder = PSModuleDepFinder()
    with open('test_files/module_with_module_dependencies.psm1') as ps_module_file:
        ps_dep_finder.scan_module(ps_module_file, fqn=None, wrapper=False, powershell=True)

        assert len(ps_dep_finder.ps_modules) >= 3
        assert to_text('Ansible.Windows.Common') in ps_dep_finder.ps_modules
        assert to_text('ansible_collections.systemtools.test.plugins.module_utils.test_plugin_utils') in ps_dep_finder.ps_modules
        assert to_text('ansible_collections.systemtools.test.plugins.module_utils.test_plugin_utils_2') in ps_dep_finder.ps_modules

# Generated at 2022-06-10 23:31:36.944484
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    """Function to test method scan_exec_script of class PSModuleDepFinder"""
    finder = PSModuleDepFinder()
    try:
        finder.scan_exec_script("this_script_does_not_exist")
        assert 0
    except AnsibleError:
        pass

    # Test a real script
    finder.scan_exec_script("standard_wrapper")
    assert finder.exec_scripts["standard_wrapper"]



# Generated at 2022-06-10 23:31:38.251100
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    assert False



# Generated at 2022-06-10 23:31:41.624428
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    ps_module_dep_finder = PSModuleDepFinder()
    ps_module_dep_finder.scan_exec_script('test.ps1')
    assert ps_module_dep_finder.exec_scripts['test.ps1'] == b'\n'

# Generated at 2022-06-10 23:31:43.167795
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    test_obj = PSModuleDepFinder()
    test_obj.scan_exec_script('testname')



# Generated at 2022-06-10 23:31:49.435711
# Unit test for method scan_exec_script of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_exec_script():
    import ansible.executor.powershell
    import types
    import pkg_resources
    dir_path = os.path.join(pkg_resources.get_distribution('ansible').location, 'lib/ansible/executor/powershell')

# Generated at 2022-06-10 23:32:01.469951
# Unit test for method scan_module of class PSModuleDepFinder
def test_PSModuleDepFinder_scan_module():
    # note, this is an integration test which needs psm1 and cs utils to run
    # this is a standalone unit test so we are going to manually load the
    # utils in the test data since we are not running them as part of a
    # collection/module_utils/psm1 file.
    pmdf = PSModuleDepFinder()
    data = pkgutil.get_data("ansible.module_utils.basic", "__init__.psm1")
    pmdf.scan_module(b"#Requires -Module Basic.psm1")
    pmdf.scan_module(data, fqn="basic.__init__")

    assert len(pmdf.ps_modules) == 2
    assert pmdf.ps_modules["Ansible.Basic"] == {'data': data, 'path': None}
    assert pm