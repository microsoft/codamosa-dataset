

# Generated at 2022-06-22 18:38:27.022743
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    """AdHocCLI - init_parser"""
    from argparse import ArgumentParser
    cli = AdHocCLI()
    parser = cli.init_parser()
    # test if parser is an instance of ArgumentParser
    assert isinstance(parser, ArgumentParser)

# Generated at 2022-06-22 18:38:38.252688
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-22 18:38:40.505135
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """This is a test to check if class AdHocCLI is constructed correctly"""
    assert isinstance(AdHocCLI, object)

# Generated at 2022-06-22 18:38:48.251247
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adHocCLI = AdHocCLI()
    adHocCLI.init_parser()
    args = adHocCLI.parser.parse_args(args='-a "a=1 b=2" host')
    _options = adHocCLI.post_process_args(options=args)
    assert _options.module_args == 'a=1 b=2'
    assert _options.module_name == 'command'
    assert _options.args == 'host'
    assert _options.verbosity == 0


# Generated at 2022-06-22 18:38:55.595054
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    def dummy_init_parser():
        parser = CLI.init_parser(AdHocCLI, usage='%prog <host-pattern> [options]',
                                 desc="Define and run a single task 'playbook' against a set of hosts",
                                 epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")
        return parser

    parser = dummy_init_parser()

    # Assert that the description contains the correct text
    assert parser.description.strip() == "Define and run a single task 'playbook' against a set of hosts", \
        "Description of the ansible CLI parser should contain the correct text"



# Generated at 2022-06-22 18:38:58.748766
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    parser = ad_hoc_cli.parser

# Generated at 2022-06-22 18:39:07.710574
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def run_mocked(self):
        self._tqm = '1'
        self._play_prereqs_mocked()
        return '2'

    def _play_prereqs_mocked(self):
        pass

    from ansible.cli.adhoc import AdHocCLI
    import ansible.constants as C
    import tempfile
    import os
    import shutil
    C.DEFAULT_FORKS = 1

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 18:39:18.039922
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=cli.options.inventory)
    cli._inventory = inventory

    playbook = PlaybookExecutor(playbooks=[],
                                inventory=inventory,
                                variable_manager=variable_manager,
                                loader=loader,
                                passwords={})
    cli._playbook = playbook


# Generated at 2022-06-22 18:39:28.286050
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Construct a mock object for the optparse.OptionParser instance and add command line options
    from six import iteritems
    import mock
    parser = mock.Mock(spec=optparse.OptionParser)
    parser.add_option = parser.add_argument

    # Confirm no error is thrown if the verbosity level is not in the list of possible values
    context.CLIARGS = {'verbosity': -1}
    AdHocCLI().post_process_args(context.CLIARGS)

    context.CLIARGS = {'verbosity': 20}
    AdHocCLI().post_process_args(context.CLIARGS)

    # Confirm no error is thrown if the module_args are valid

# Generated at 2022-06-22 18:39:32.171037
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    """
    This unit test is to test init_parser method of class AdHocCLI
    """
    cli = AdHocCLI([])
    cli.init_parser()
    context.CLIARGS = cli.parser.parse_args()
    cli.post_process_args(context.CLIARGS)

# Generated at 2022-06-22 18:39:43.702601
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Initialize and empty array
    opt_args = []
    context.CLIARGS = {}

    # Test with one option passed
    opt_args.append(['-a', "127.0.0.1"])
    context.CLIARGS = opt_help.parse_optiosn(opt_args)
    adhoc_cli = AdHocCLI(['-a', "127.0.0.1"])
    res = adhoc_cli.post_process_args(context.CLIARGS)
    assert(res['module_args'] == "127.0.0.1")
    assert(res['args'].values() == [])

    # Test with one option passed with value
    opt_args.append(['-a', 'ping'])
    context.CLIARGS = opt_

# Generated at 2022-06-22 18:39:53.921188
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.patterns import Pattern

    # create the objects
    loader = DataLoader()
    options = context.CLIARGS
    inventory = InventoryManager(loader=loader, sources=options['inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    #play = Play().load(play_ds, 
    #                variable_manager=variable_manager, loader=loader)
    #playbook = Playbook(loader)
    #playbook

# Generated at 2022-06-22 18:40:05.358140
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-22 18:40:08.798174
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)
    assert isinstance(adhoc, CLI)
    assert isinstance(adhoc, object)


# Generated at 2022-06-22 18:40:19.853373
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # create an options parser for bin/ansible
    parser = CLI.base_parser('ans')
    # create an options parser for bin/ansible-playbook
    opt_help.add_runtask_options(parser)
    opt_help.add_tasknoplay_options(parser)

    options = parser.parse_args(['localhost', '-m', 'setup', '-a', 'ansible_python_interpreter=/usr/bin/python3'])
    adhoc_cli = AdHocCLI(parser)

    assert options.module_name == 'setup'
    assert options.module_args == 'ansible_python_interpreter=/usr/bin/python3'

    # Test that 'gather_facts' is automatically set to 'no' when 'module_name=setup'
    options = adh

# Generated at 2022-06-22 18:40:29.316012
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def ask_passwords():
        return (None, None)

    def get_host_list(inventory, subset, pattern):
        return []

    def _play_ds(pattern, async_val, poll):
        return {}

    class Play:
        def load(self, play_ds, variable_manager, loader):
            return {}

    class Playbook:
        def __init__(self, loader):
            pass

    class TaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks, run_tree, forks):
            pass

        def load_callbacks(self):
            pass

        def run(self, play):
            return {}

    ansible_ad_hoc = AdHocCLI()
    ansible_ad_hoc

# Generated at 2022-06-22 18:40:42.101926
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create AdHocCLI instance and set
    # the 'module_args' and 'module_name' attributes
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.options = CLI.base_parser(constants=C, usage='%prog <host-pattern> [options]',
                                         desc="Define and run a single task 'playbook' against a set of hosts",
                                         epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")
    ad_hoc_cli.options.module_args = 'x=1 y=2'
    ad_hoc_cli.options.module_name = 'setup'

    # Assert the return value of method post_process_args is
    # the same as the 'options' attribute
    assert ad_

# Generated at 2022-06-22 18:40:43.769202
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    pass

# Generated at 2022-06-22 18:40:53.573694
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    test_args = [
        'ansible',
        '-m',
        'ping',
        '-a',
        'data=test',
        'localhost',
    ]
    adhoc_test_obj = AdHocCLI(args=test_args)
    test_options = adhoc_test_obj.parser.parse_args(test_args)
    result = adhoc_test_obj.post_process_args(test_options)
    assert result.module_name == 'ping'
    assert result.module_args == 'data=test'
    assert result.args == 'localhost'

# Generated at 2022-06-22 18:41:02.133293
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_cli = AdHocCLI()
    parser = ad_hoc_cli.init_parser()
    options, args = parser.parse_args(['-m', 'setup', 'localhost'])
    ad_hoc_cli.post_process_args(options)


# Generated at 2022-06-22 18:41:05.121835
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Call the init_parser method
    myAdHocCLI = AdHocCLI()
    myAdHocCLI.init_parser()

# Generated at 2022-06-22 18:41:12.896159
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create the AdHocCLI object
    adhoc = AdHocCLI(['-i', 'localhost', 'all', '-a', 'echo 12345'])

    assert adhoc is not None
    assert adhoc._play_prereqs() is not None
    assert adhoc.get_host_list([], [], 'none') is not None
    assert adhoc.run() is not None
    assert adhoc.cleanup() is not None


# Generated at 2022-06-22 18:41:16.288599
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()


# Generated at 2022-06-22 18:41:22.758826
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Create an instance of class AdHocCLI
    adhoc_cli = AdHocCLI(
        ['ansible', 'all', '-a', '"/bin/date"', '-m', 'shell', '-u', 'centos']
    )
    adhoc_cli.parse() # Call parse()

    # Check whether the instance of class AdHocCLI is created or not
    if adhoc_cli:
        assert True
    else:
        assert False


# Generated at 2022-06-22 18:41:30.212471
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    myargv = [
        "-m", "setup",
        "-a", "filter=ansible_os_family",
        "host.example.com"
    ]
    try:
        cli = AdHocCLI(myargv)
        display.verbosity = 2
        cli.parse()
        cli.post_process_args(cli.options)
        cli.run()
    except SystemExit as e:
        if e.code != 0:
            raise

# Generated at 2022-06-22 18:41:33.232406
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        adhoc_cli = AdHocCLI(args=[])
        adhoc_cli.run()
    except AnsibleOptionsError as e:
        assert False, ("Test failed with exception: %s" % str(e))

# Generated at 2022-06-22 18:41:42.803607
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

    assert cli.parser is not None
    assert cli.parser._prog == 'ansible'
    assert cli.parser.usage == '%prog <host-pattern> [options]'
    assert len(cli.subparsers.choices) == 1

    assert cli.subparser_loader is not None
    assert isinstance(cli.subparser_loader, CLI.CLISubparserLoader)

    parser_adhoc = cli.subparsers.choices['adhoc']

    assert parser_adhoc.prog == 'ansible adhoc'
    assert parser_adhoc.usage == '%prog <host-pattern> [options]'

# Generated at 2022-06-22 18:41:44.936758
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()



# Generated at 2022-06-22 18:41:56.632082
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # testing method init_parser of class AdHocCLI,
    #     to check if the usage and description of the options are correct.
    import argparse

    adhoc = AdHocCLI(None)
    parser = adhoc.parser
    assert parser.usage == '%prog <host-pattern> [options]'

    assert parser.description == ("""
        Define and run a single task 'playbook' against a set of hosts""")

    action_strings = [str(a) for a in parser._actions]
    assert '-h, --help' in action_strings
    assert '-a ACTION_ARGS, --args=ACTION_ARGS' in action_strings
    assert '-m ACTION_NAME, --module-name=ACTION_NAME' in action_strings

# Generated at 2022-06-22 18:42:00.645523
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    action_func = AdHocCLI()
    assert(action_func.name == 'AdHocCLI')

# Generated at 2022-06-22 18:42:09.570884
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    myex = AdHocCLI(['-m', 'setup', 'test'])
    assert myex.options.module_name == 'setup'
    assert myex.options.module_args == ''
    assert myex.options.args == 'test'
    assert myex.options.connection == 'smart'
    assert myex.options.forks == None
    assert myex.options.remote_user == None
    assert myex.options.ask_pass == None
    assert myex.options.private_key_file == None
    assert myex.options.become == None
    assert myex.options.become_user == None
    assert myex.options.become_method == 'sudo'
    assert myex.options.become_ask_pass == None
    assert myex.options.verbosity == None


# Generated at 2022-06-22 18:42:17.351320
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    inventory = opt_help.Inventory(options=['localhost,'])
    inventory._vars_plugins = dict(
        inventory=inventory,
        compiler=None,
        loader=None,
        inventory_manager=None,
        all_group=None,
        groups=None,
    )
    inventory.parse_inventory(inventory._options.host_list)

    options, _ = opt_help.parse_connection_options(dict(host_list=inventory._options.host_list, forks=1, remote_user='root'))

    cli = AdHocCLI(['localhost', '-m', 'ping', '-a', 'free_form_arg=yes'])
    cli.parse()
    cli.options = options
    cli.post_process_args(cli.options)

# Generated at 2022-06-22 18:42:26.648820
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    #assert cli.parser.usage == '%prog <host-pattern> [options]', 'AdHocCLI init_parser() has an incorrect usage option'
    #assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts", 'AdHocCLI init_parser() has an incorrect desc option'
    #assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)", 'AdHocCLI init_parser() has an incorrect epilog option'

# Generated at 2022-06-22 18:42:31.168492
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['--list-hosts', '-m', 'ping', '-a', '"authorize=yes"', 'all', '-u', 'send'])
    assert cli.parser.description is not None

# Generated at 2022-06-22 18:42:33.678215
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Test default constructor
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.args is None

# Generated at 2022-06-22 18:42:44.809779
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    adhoc.parser = adhoc.init_parser()

    context.CLIARGS = { 'module_name': 'ping',
                        'module_args': '',
                        # Passwords are needed for the unit test to pass, but
                        # provide no value.
                        'ask_pass': True,
                        'ask_su_pass': True,
                        'ask_become_pass': True,
                        'ask_su_become_pass': True
                        }
    adhoc.options = adhoc.post_process_args(adhoc.options)
    assert(adhoc.options.ask_pass == True)
    assert(adhoc.options.ask_su_pass == True)
    assert(adhoc.options.ask_become_pass == True)
   

# Generated at 2022-06-22 18:42:56.330423
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Passing all params
    options = opt_help.get_common_options()
    options.connection = "local"
    options.inventory = "test/test_hosts"
    options.module_path = ["test/test_module_path"]
    options.module_name = "test/test_module_name"
    options.module_args = "test/test_module_args"
    options.ask_pass = "test/test_ask_pass"
    options.ask_become_pass = "test/test_ask_become_pass"
    options.become = "test/test_become"
    options.check = "test/test_check"
    options.listhosts = "test/test_listhosts"
    options.one_line = "test/test_one_line"

# Generated at 2022-06-22 18:42:58.964094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Find a better way
    import builtins
    builtins.display = Display()
    x = AdHocCLI()



# Generated at 2022-06-22 18:43:09.714704
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-22 18:43:18.263923
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    class MockCLI(AdHocCLI):

        def __init__(self):
            self.options = None
            self.args = None
            self.passwords = None
            self.inventory = None
            self.variable_manager = None

        def parse(self):
            parser = MockParser()
            self.args = parser.args
            self.options = parser.options

        def post_process_args(self, options):
            return options

        def get_host_list(self, inventory, subset, pattern):
            return ['10.0.0.1', '10.0.0.2']

        def ask_passwords(self):
            return None, None

        def _play_prereqs(self):
            self.inventory = MockInventory()
            self.variable_manager = MockVariableManager()
            loader

# Generated at 2022-06-22 18:43:21.866936
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    This is the test of AdHocCLI module
    '''
    Adhoc = AdHocCLI()
    assert Adhoc._tqm is None

# Generated at 2022-06-22 18:43:32.525854
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # NOTE: This test uses the 'argparse' module directly
    # to test its functionality. For this purpose the
    # 'add_subparser' method is called to add the AdHocCLI
    # to the parser without actually calling the 'run'
    # method of the AdHocCLI.
    #
    # TODO: Implement more complete unit tests for module
    # unit_tests/test_module_utils/test_cli.py

    import argparse

    parent_parser = argparse.ArgumentParser()
    subparsers = parent_parser.add_subparsers()
    cli = AdHocCLI()
    cli.add_subparser(subparsers)
    parser = subparsers.choices['ad-hoc']


# Generated at 2022-06-22 18:43:39.271801
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import sys
    wide_display = Display(verbosity=99)
    adhoc_cli = AdHocCLI(args=sys.argv[1:])
    # test init_parser()
    adhoc_cli.init_parser()
    # test post_process_args()
    adhoc_cli.post_process_args(adhoc_cli.options)
    # test _play_ds()
    adhoc_cli._play_ds('all', 0, 0)
    # test run()
    adhoc_cli.run()
    assert adhoc_cli.parser.description

# Generated at 2022-06-22 18:43:46.473530
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Set up the class to run unit test
    myCLI = AdHocCLI()
    myCLI.opts = {'module_name': "shell", 'module_args': 'date'}
    myCLI.args = ['localhost']
    myCLI.parser = None

    # Run method run of class AdHocCLI
    myCLI.run()

# Generated at 2022-06-22 18:43:58.212325
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class MockAdhoccli(AdHocCLI):
        def run(self):
            return super(AdHocCLI,self).run()

    adhoccli = MockAdhoccli()
    adhoccli.init_parser()
    options,args = adhoccli.parser.parse_known_args()
    options = adhoccli.post_process_args(options)
    assert "pattern" in options
    assert "module_name" in options
    assert "module_args" in options
    assert "timeout" in options
    assert "listhosts" in options
    assert "listtasks" in options
    assert "listtags" in options
    assert "syntax" in options
    assert "connection" in options
    assert not options.listhosts
    assert not options.listtasks

# Generated at 2022-06-22 18:44:00.957025
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['-i', 'localhost,', '-m', 'shell', '-a', 'echo hello']
    cli = AdHocCLI(args)
    cli.parse()
    cli.run()

# Generated at 2022-06-22 18:44:04.232932
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    #
    # Unit test for method init_parser of class AdHocCLI
    #
    pass


# Generated at 2022-06-22 18:44:11.135488
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    adhoc_cli = AdHocCLI()
    # set the args for module_name
    context.CLIARGS = {'module_name': 'raw'}
    # set the args for module_args
    context.CLIARGS['module_args'] = 'hostname'
    # set the args for args
    context.CLIARGS['args'] = 'all'
    try:
        # call the run method of class AdHocCLI
        adhoc_cli.run()
    except ValueError:
        pass

# Generated at 2022-06-22 18:44:12.811246
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli

# Generated at 2022-06-22 18:44:16.524790
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    some tests for the ad-hoc cli we can run with nosetests
    """
    # Stub out the get_host_list function
    def stub_get_host_list(inventory, subset, pattern):
        return ['testhost']

    cli = AdHocCLI()
    cli.get_host_list = stub_get_host_list

    cli.run()

# Generated at 2022-06-22 18:44:27.995304
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test example from CLI docs
    args = ['host_pattern', '-m', 'ping', '-a', '"args=hello world"']
    options = AdHocCLI(args=args).parse()
    assert options.inventory == C.DEFAULT_HOST_LIST
    assert options.module_name == 'ping'
    assert options.module_args == '"args=hello world"'
    assert options.subset is None or options.subset == ''

    # Test example from CLI docs with additional args
    args = ['host_pattern', '-m', 'ping', '-a', '"arg1=hello arg2=world"', 'an_argument']
    with pytest.raises(AnsibleError):
        AdHocCLI(args=args).parse()

    # Test no-args example

# Generated at 2022-06-22 18:44:29.802677
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    AdHocCLI.post_process_args(AdHocCLI())

# Generated at 2022-06-22 18:44:32.966678
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create a new AdHocCLI
    ad_hoc_cli = AdHocCLI()
    # Validate object
    assert ad_hoc_cli


# Generated at 2022-06-22 18:44:39.928419
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    #PY3: Test parameter
    #Testing init_parser with description 'extra-simple tool/framework' and epilog 'make sense in Ad-Hoc'
    CLI = AdHocCLI()
    CLI.init_parser()
    expected = '%prog <host-pattern> [options]\n\n' \
               'extra-simple tool/framework\n\n' \
               'Some actions do not make sense in Ad-Hoc (include, meta, etc)\n\n'
    assert expected in CLI.parser.format_help()


# Generated at 2022-06-22 18:44:44.587459
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    a = AdHocCLI()
    a.parser.parse_args(['-m', 'shell', '-a', 'ls /', 'localhost'])
    result = a.run()
    assert result == 0


# Generated at 2022-06-22 18:44:56.231741
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import sys
    import os
    import ansible.cli
    test_args = ['ansible', '-m', 'shell', '-c', 'local', '-a', 'arg1=1' ,'-i', 'hosts', 'host1']
    args = ansible.cli.CLI.base_parser(test_args, usage='%prog [options]', desc="Ansible Ad-hoc", epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")
    options = args.parse_args()
    cli = AdHocCLI(args)
    options = cli.post_process_args(options)

# Generated at 2022-06-22 18:45:07.518155
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C

    # initialize a lot of empty lists and dicts for the test

# Generated at 2022-06-22 18:45:10.854202
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    options = adhoc.parse()
    options.ask_vault_pass = False
    options.ask_pass = False
    context._init_global_context(options)
    adhoc.post_process_args(options)
    assert adhoc.run() == 0

# Generated at 2022-06-22 18:45:11.566287
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:45:23.368037
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    class Object(object):
        ''' Dummy object for test '''
        def __init__(self, **entries):
            self.__dict__.update(entries)

    # test with C.DEFAULT_FORKS=100
    C.DEFAULT_FORKS = 100
    test_args = []
    context.CLIARGS = Object(connection='local', forks=100, module_name='shell', module_args='ls')
    adhoccli = AdHocCLI()
    assert adhoccli.post_process_args(test_args) == context.CLIARGS

    # test with C.DEFAULT_FORKS=10
    C.DEFAULT_FORKS = 10
    test_args = []

# Generated at 2022-06-22 18:45:26.119806
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-22 18:45:27.666362
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    result = AdHocCLI().run()
    assert result is None

# Generated at 2022-06-22 18:45:29.994454
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    adhoc = AdHocCLI(args = [])
    adhoc.post_process_args()
    adhoc.run()

# Generated at 2022-06-22 18:45:31.305735
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    raise NotImplementedError

# Generated at 2022-06-22 18:45:35.807265
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    adhoc = AdHocCLI()
    adhoc.parser.parse_args(['-i','inventory','--module-name','shell','--module-args','whoami','localhost'])
    adhoc.run()

# Generated at 2022-06-22 18:45:40.548670
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    x = AdHocCLI()

    # Create option object
    options = x.parser.parse_args(['--check', '--fork', '5', 'all'])

    assert x.post_process_args(options) == None, 'Validate error message for "--check" and "--fork" options.'

# Generated at 2022-06-22 18:45:43.295589
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Currently, we don't have unit test for run, so this is never called.
    # We need to fix it later.
    cli = AdHocCLI(args=[])
    cli.run()

# Generated at 2022-06-22 18:45:55.383524
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args_list = [
        ['cliuser', '-m', 'shell', '-a', "arg1='arg1' arg2='arg2'", 'host1'],
        ['cliuser', '-m', 'shell', '-a', "arg1='arg1' arg2='arg2'", 'host1', '-e', "arg3='arg3' arg4='arg4'"],
        ['cliuser', '-m', 'shell', '-a', "arg1='arg1' arg2='arg2'", '--extra-vars', "arg3='arg3' arg4='arg4'", 'host1'],
    ]

# Generated at 2022-06-22 18:46:07.720028
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    options = {}
    o_ai = options.setdefault('ask_inventory', False)
    o_ai = options.setdefault('ask_vault_pass', False)
    o_ai = options.setdefault('ask_pass', False)
    o_ai = options.setdefault('ask_become_pass', False)
    o_ai = options.setdefault('ask_sudo_pass', False)
    o_ai = options.setdefault('ask_su_pass', False)
    o_ai = options.setdefault('new_vault_password_file', None)
    o_ai = options.setdefault('vault_password_file', None)
    o_ai = options.setdefault('listhosts', None)
    o_ai = options.setdefault('become_method', None)

# Generated at 2022-06-22 18:46:18.145774
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class CLIARGS(object):
        def __init__(self):
            self.verbosity = 1
            self.ask_pass = False
            self.ask_su_pass = False
            self.ask_sudo_pass = False
            self.ask_vault_pass = False
            self.vault_password_file = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.become_ask_pass = False
            self.ask_passwords = False
            self.remote_user = 'root'
            self.module_path = None
            self

# Generated at 2022-06-22 18:46:26.026651
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Unit test for run method of class AdHocCLI"""
    # pylint: disable=redefined-outer-name
    import json
    import sys

    from ansible.context import cli_args, context
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes

    from units.mock.procenv import (monkeypatch_pid, ProgNameScope, set_argv0)

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.module_utils._text import to_text

    adhoc_cli = AdHocCLI(sys.argv)
    context.CLIARGS = adhoc_cli.parse()
   

# Generated at 2022-06-22 18:46:27.688088
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    result = AdHocCLI().run()
    assert  result == 0

# Generated at 2022-06-22 18:46:30.326171
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert isinstance(adhoc, CLI)
    assert isinstance(adhoc, AdHocCLI)

# Generated at 2022-06-22 18:46:33.231710
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

    for attr in cli.__dict__:
        assert not attr.startswith("_")

# Generated at 2022-06-22 18:46:42.465166
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Store original values of variables async_seconds, forks and verbosity.
    async_seconds = 5
    forks = 10
    verbosity = 2
    # Create an instance of AdHocCLI.
    args = dict()
    args['module_name'] = 'ping'
    args['module_args'] = 'echo'
    args['pattern'] = 'localhost'
    args['async_seconds'] = async_seconds
    args['forks'] = forks
    args['verbosity'] = verbosity
    adhoc_cli = AdHocCLI(args)

    # Test the post_process_args method with empty args
    options = adhoc_cli.post_process_args({})

    assert options.get('module_name') == 'ping'
    assert options.get('module_args') == 'echo'

# Generated at 2022-06-22 18:46:44.608869
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhocliparser = AdHocCLI().init_parser()
    assert adhocliparser.get_default_values().module_name == u'command'

# Generated at 2022-06-22 18:46:56.098182
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    c = AdHocCLI(['-i', 'test', '-m', 'test'])
    assert c.parser.parse_args(['-i', 'test'])
    assert c.parser.parse_args(['-m', 'test'])
    assert c.parser.parse_args(['-a', 'test'])
    assert c.parser.parse_args(['-i', 'test', '-m', 'test', '-a', 'test'])
    assert c.parser.parse_args(['-i', 'test', '-m', 'test', '-a', 'test', '--extra-vars', 'test'])
    assert c.parser.parse_args(['-e', 'test'])
    assert c.parser.parse_args(['test'])



# Generated at 2022-06-22 18:47:08.548357
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI._play_prereqs = lambda self: (None, None, None)
    AdHocCLI.get_host_list = lambda self, inventory, subset, pattern: []
    AdHocCLI._play_ds = lambda self, pattern, async_val, poll: (pattern, async_val, poll)
    AdHocCLI.ask_passwords = lambda self: (None, None)
    AdHocCLI.validate_conflicts = lambda self, options, runas_opts=False, vault_opts=False, fork_opts=False: True
    AdHocCLI.post_process_args = lambda self, options: options
    AdHocCLI.run_command = lambda self: True
    # AdHocCLI.run_command is called but not used:
    Ad

# Generated at 2022-06-22 18:47:18.825711
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import tempfile
    playbook_file_tmp = tempfile.NamedTemporaryFile(delete=False)
    playbook_file_tmp.write("""---
- hosts: all
  strategy: free
  tasks:
    - shell: echo Hello
      register: result
      check_mode: false
      delegate_to: localhost
""")
    playbook_file_tmp.close()

# Generated at 2022-06-22 18:47:28.849122
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor import playbook_executor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import cliconf_loader, connection_loader, lookup_loader, module_loader, timeout_loader
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.display import Display
    from ansible.vars.management import VariableManager
    import os
    import tempfile

    def cliargs(**kwargs):
        class CLIARGS(object):
            def __init__(self):
                self.connection = kwargs.get('connection', 'ssh')

# Generated at 2022-06-22 18:47:33.586210
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['ansible', 'all', '-m', 'shell', '-a', 'echo foo']
    adhoc = AdHocCLI(args)
    result = adhoc.run()
    assert result == 0

# Generated at 2022-06-22 18:47:37.468668
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # init a class object first
    test_AdHocCLI=AdHocCLI()

    parser_obj=test_AdHocCLI.init_parser()
    assert parser_obj.prog=='ansible-adhoc'



# Generated at 2022-06-22 18:47:46.311195
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.utils.display import Display
    display = Display()

    parser = opt_help.create_parser(None, '$ ansible ad-hoc -m ping')
    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_async_options(parser)
    opt_help.add_output_options(parser)
    opt_help.add_connect_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)
    opt_help.add_basedir_options

# Generated at 2022-06-22 18:47:53.054187
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.parser = CLI.base_parser(constants.SOME_NONE_DEFAULT_VARS)
    options, args = cli.parser.parse_args(['-m', 'ping', '-a', 'foo=bar'])
    options = cli.post_process_args(options)

# Generated at 2022-06-22 18:47:55.941671
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    assert(parser is not None)

# Generated at 2022-06-22 18:48:05.373953
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a fake inventory
    class FakeInventory:
        def get_hosts(self, pattern="all"):
            class FakeHost:
                name = "test_host"
            # Return a host with the pattern "test_host"
            return [FakeHost()]
    class FakeOptions:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    context.CLIARGS = FakeOptions(module_name="shell", module_args="ls", one_line=True, forks=10, verbosity=1, subset="all", listing=True)
    display.verbosity = 1
    display.quiet = False
    display.verbose = True
    # Create a fake loader
    class FakeLoader:
        def __init__(self):
            pass

# Generated at 2022-06-22 18:48:17.124417
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    out_args    = ['ansible', 'local', '--module-name', 'setup', 'localhost']

# Generated at 2022-06-22 18:48:21.445303
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    fake_options = {'verbosity': 5,
                    'inventory': '/etc/ansible/hosts',
                    'subset': '*',
                    'module_name': 'ping',
                    'module_args': '',
                    'args': 'localhost',
                    'listhosts': False,
                    'one_line': True,
                    'tree': None,
                    'seconds': 60,
                    'poll_interval': 15}

    cls = AdHocCLI(args='localhost', runas_opts={}, fork_opts={})
    print(cls.post_process_args(fake_options))

# Generated at 2022-06-22 18:48:26.130294
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    options = adhoc.parse()
    adhoc.post_process_args(options)
    adhoc.run()