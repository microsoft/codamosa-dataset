

# Generated at 2022-06-22 18:38:26.337263
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    instance = AdHocCLI()
    assert isinstance(instance, AdHocCLI)
    assert isinstance(instance, CLI)
    assert hasattr(instance, 'init_parser')
    assert hasattr(instance, 'post_process_args')
    assert hasattr(instance, 'run')

# Generated at 2022-06-22 18:38:28.262233
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None
    assert adhoc._tqm is None
    assert adhoc.parser is not None


# Generated at 2022-06-22 18:38:30.719574
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.parser is not None
    assert cli.usage_json is not None

# Generated at 2022-06-22 18:38:41.415619
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.callback.default import CallbackModule

    # Initialize a class object of AdHocCLI
    #          to test method run of class AdHocCLI
    cli = AdHocCLI()

    #Load context plugins in PlayContext object
    #          to test method run of class AdHocCLI

# Generated at 2022-06-22 18:38:43.419921
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI(args=[])
    assert ad_hoc
    assert ad_hoc.parser

# Generated at 2022-06-22 18:38:47.088978
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    cli.init_parser()
    assert cli.parser.usage == "%prog <host-pattern> [options]"

# Generated at 2022-06-22 18:38:57.142422
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cls = AdHocCLI()
    os.environ['ANSIBLE_STDOUT_CALLBACK'] = 'dummy'
    os.environ['ANSIBLE_FORKS'] = '1'
    os.environ['ANSIBLE_VERBOSITY'] = '2'
    cls.args = ['-m', 'ping', '-a', 'args', 'localhost']
    ret = cls.post_process_args(cls.parser.parse_args(cls.args))
    assert ret.oneshot
    assert ret.module_name == 'ping'
    assert ret.module_args == 'args'
    assert ret.verbosity == 2
    assert ret.inventory_sources == ['localhost,']
    assert ret.forks == 1
    assert ret.ask_pass
    assert ret.become_ask_

# Generated at 2022-06-22 18:39:03.705862
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    dummy_args = ['ansible-adhoc', '-v', '-m', 'ping', '-a', 'k=v', 'h']
    cli = AdHocCLI(args=dummy_args)
    options = cli.parse()
    results = cli.post_process_args(options)
    assert results.module_args == 'k=v'
    assert results.module_name == 'ping'
    assert results.verbosity == 2


# Generated at 2022-06-22 18:39:05.933929
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()
    assert ad_hoc_cli.parser.prog == 'ansible'

# Generated at 2022-06-22 18:39:17.152706
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import sys, os
    from mock import Mock

    class MockPlay(object):
        pass

    class MockAdhocCLI(AdHocCLI):
        def __init__(self, *args, **kwargs):
            self._tqm = Mock()
            self.args = kwargs.get('args')
            self.mock_playbook_on_stats = Mock()
            self.mock_display = Mock()
            self.mock_get_host_list = Mock()
            self._options = Mock()

# Generated at 2022-06-22 18:39:18.634388
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-22 18:39:24.167700
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test1 = AdHocCLI(["-a", "uptime"])
    assert test1.parser.description == "Define and run a single task 'playbook' against a set of hosts"

# Test to ensure that v2_playbook_on_start is called

# Generated at 2022-06-22 18:39:25.088757
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-22 18:39:34.540300
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI

    # Create a AdHocCLI object
    class MockAdHocCLI(AdHocCLI):
        def __init__(self):
            pass

        def finalize_options(self, **kwargs):
            # Mock self.args so that the overriding of default options by
            # the CLI options works
            if not hasattr(self, 'args'):
                self.args = []

        def run(self):
            # This is the function returned by the mock
            return self

    # Mock the argparse.Parser.parse_args to return a mocked
    # (and not valid) argument structure

# Generated at 2022-06-22 18:39:37.249296
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''
    Unit test for method init_parser of class AdHocCLI
    '''

    cli = AdHocCLI()
    cli.init_parser()
    cli.parser.parse_args()



# Generated at 2022-06-22 18:39:47.380509
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ansible = AdHocCLI([])
    ansible.init_parser()
    options = ansible.parser.parse_args(['-m', 'fake_module', '--tree', 'fake_tree', 'fake_host'])
    
    assert options.module_name == 'fake_module'
    assert options.tree == 'fake_tree'
    assert options.args == 'fake_host'
    assert options.module_args == C.DEFAULT_MODULE_ARGS
    
    options = ansible.post_process_args(options)
    assert C.CALLBACKS_ENABLED[0] == 'tree'
    assert C.TREE_DIR == 'fake_tree'
    assert context.CLIARGS['module_name'] == 'fake_module'

# Generated at 2022-06-22 18:39:51.424809
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    args = ['-m', 'test', '-a', 'ansible_test=test', 'localhost']
    opts = adhoc_cli.parse(args)
    adhoc_cli.post_process_args(opts)
    adhoc_cli.run()

# Generated at 2022-06-22 18:40:00.468094
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    c = AdHocCLI(args=[
        '-i', 'my_hosts',
        '-m', 'mymodule',
        '-a', 'arg1=value1',
        '-v',
        'all',
        '-f', '10',
        '-k', '--ask-sudo-pass',
        '--ask-su-pass',
        '-u', 'someuser',
        '-T', '30',
        '-t', 'my_tags',
        '-P',
        'mypattern',
        'otherarg'
    ])

    # Check resulting args

# Generated at 2022-06-22 18:40:01.988895
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ac = AdHocCLI()
    ac.init_parser()

# Generated at 2022-06-22 18:40:05.879953
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhocc = AdHocCLI()
    assert isinstance(adhocc, AdHocCLI)
    adhocc.init_parser()
    assert isinstance(adhocc.parser, CLI.parser)

# Generated at 2022-06-22 18:40:17.304950
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # Use a mock object for sys.argv
    # and use the default settings for other parameters
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class MockArgv:

        def __getitem__(self):
            return ""

        def __len__(self):
            return 0

    context._init_global_context(
        cli_args=MockArgv(),
        options=opt_help.create_default_options(connection='local', module_path=None),
        args=MockArgv(),
    )

    AdHocCLI(
        cli_args=context.CLIARGS,
        inventory=None,
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
    )

# Generated at 2022-06-22 18:40:20.324317
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    parser = cli.init_parser()
    assert parser is not None
    assert isinstance(parser, CLI.OptionParser)


# Generated at 2022-06-22 18:40:29.519709
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    foo = AdHocCLI(["-m", "setup", "foobar"])

# Generated at 2022-06-22 18:40:42.137948
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.callback import CallbackBase

    context.CLIARGS['module_name'] = 'shell'
    context.CLIARGS['module_args'] = 'echo Hello World'

    class FakeInventory(Mapping):
        hosts = ['127.0.0.1']

        def __iter__(self):
            return iter(self.hosts)

        def __len__(self):
            return len(self.hosts)

        def __getitem__(self, key):
            return self.hosts[key]

    class FakeVariableManager:
        def __init__(self):
            self.extra_vars = {}


# Generated at 2022-06-22 18:40:55.049948
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()

    assert parser.usage == '%prog <host-pattern> [options]'

    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"

    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

    assert parser.version == 'ansible %s' % C.__version__

    assert parser.add_argument.called
    assert len(parser.add_argument.call_args_list) == 23

    pos_arg = parser.add_argument.call_args_list[-1]

    assert len(pos_arg[0]) == 2
    assert pos_arg[0][0] == 'args'

# Generated at 2022-06-22 18:41:02.386156
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    from units.mock.cli_arguments import MockCLIArguments as MockOptions
    from units.mock.cli_common import CLIReturnValue
    from units.mock.path import mock_unfrackpath_noop

    args = MockOptions()
    cli = AdHocCLI(args)
    # Make sure that help does not take unneeded options
    args.help = True
    cli._play_prereqs = lambda: (None, None, None)
    cli.post_process_args = lambda x: x
    with mock_unfrackpath_noop():
        res = cli.run()
        assert isinstance(res, CLIReturnValue)

# Generated at 2022-06-22 18:41:10.688332
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['ansible', 'all', '-m', 'ping'])
    assert(cli.args == ['ansible', 'all', '-m', 'ping'])
    assert(cli.parser.prog == 'ansible')
    assert(cli.parser._positionals.title == 'pattern')
    assert(cli.parser.epilog.split('\n')[0] == "Some actions do not make sense in Ad-Hoc (include, meta, etc)")

# Generated at 2022-06-22 18:41:14.075302
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    AdHocCLI().run()
    """

    def test_AdHocCLI_run_real_results(self):
        """
        AdHocCLI().run()
        """
        # (self):

# Generated at 2022-06-22 18:41:20.586611
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit test for AdHocCLI class in CLI '''
    adhoccli = AdHocCLI(args=['-m', 'ping', 'localhost', '--ask-pass'])
    output = adhoccli.parse()
    assert output.module_name == 'ping'

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-22 18:41:31.633983
# Unit test for constructor of class AdHocCLI

# Generated at 2022-06-22 18:41:42.588890
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cls = AdHocCLI()
    cls.init_parser()

# Generated at 2022-06-22 18:41:45.147577
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert(isinstance(adhoc_cli, AdHocCLI))

# Generated at 2022-06-22 18:41:54.232717
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Test if the method post_process_args of class AdHocCLI raise
    AnsibleOptionsError when options with conflicts are passed to
    AdHocCLI.post_process_args method.

    :return:
    """
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    parser_option = adhoc_cli.parser.parse_args(['-e', 'test_option=test_value',
                                                 '-r', 'test_option=test_role',
                                                 '-a', 'test_argument',
                                                 'test_host_pattern'])
    # Expect AnsibleOptionsError

# Generated at 2022-06-22 18:41:57.817218
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhocCLI = AdHocCLI()
    adhocCLI.init_parser()
    adhocCLI.parser.parse_args(['-a', 'date', '-f', '5', 'all'])
    adhocCLI.post_process_args(adhocCLI.parser.parse_args(['-a', 'date', '-f', '5', 'all']))


# Generated at 2022-06-22 18:42:02.737565
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ah = AdHocCLI()
    parser = ah.init_parser()
    assert parser

    assert parser.prog == 'ansible'
    assert parser.usage == 'ansible <host-pattern> [options]'
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-22 18:42:03.798913
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI([])

# Generated at 2022-06-22 18:42:11.611736
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    argument_parser = CLI.base_parser(constants.base_parser_options, usage="%prog <host-pattern> [options]")
    cli = AdHocCLI(argument_parser)
    cli.init_parser()
    arguments = argument_parser.parse_args([])
    options = vars(arguments)
    assert options['module_args'] == C.DEFAULT_MODULE_ARGS
    option_keys = options.keys()
    assert 'module_name' in option_keys
    assert 'args' in option_keys


# Generated at 2022-06-22 18:42:21.129690
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {}
    context.CLIARGS['one_line'] = False
    context.CLIARGS['module_name'] = "test_AdHocCLI_run"
    context.CLIARGS['module_args'] = "arg1=value1 arg2=value2"
    context.CLIARGS['subset'] = "all"
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['tree'] = None
    context.CLIARGS['forks'] = 5
    context.CLIARGS['seconds'] = 10
    context.CLIARGS['poll_interval'] = 15
    context.CLIARGS['ask_pass'] = False
    context.CLIARGS

# Generated at 2022-06-22 18:42:24.093004
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cls = AdHocCLI()
    assert isinstance(adhoc_cls, AdHocCLI)

# Generated at 2022-06-22 18:42:28.487542
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Get a AdHocCLI class object and its method run to test
    adhoc_instance = AdHocCLI()
    adhoc_run = adhoc_instance.run

    # For now, ignore coverage until we sort out how to test this
    adhoc_run()  # pragma: no cover

# Generated at 2022-06-22 18:42:29.894887
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    assert not AdHocCLI().init_parser()


# Generated at 2022-06-22 18:42:32.247547
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Constructor for AdHocCLI class
    """
    cli = AdHocCLI()
    assert cli.__class__.__name__ == 'AdHocCLI'

# Generated at 2022-06-22 18:42:39.901602
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['ansible', '-h'])
    assert cli.parser.usage == '%prog <host-pattern> [options]'
    assert cli.parser.prog == 'ansible'
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-22 18:42:40.529724
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-22 18:42:51.330775
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    inventory_file = './test/units/ansible-inventory'
    module_path = 'test/units/modules'
    module_name = 'ping'
    module_args = 'data=testarg'
    result_options = {}
    result_options['inventory'] = inventory_file
    result_options['subset'] = 'all'
    result_options['module_path'] = module_path
    result_options['module_name'] = module_name
    result_options['module_args'] = module_args
    result_options['listhosts'] = False
    result_options['listtasks'] = False
    result_options['listtags'] = False
    # result_options['syntax'] = None
    result_options['forks'] = 100
    result_options['poll_interval'] = 15
    result_

# Generated at 2022-06-22 18:42:59.625761
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    def set_defaults(args, args_defaults):
        args_copy = args.copy()
        for key, value in args_defaults.items():
            args_copy[key] = value
        return args_copy

    def assert_default_values(args, args_defaults):
        for key, value in args_defaults.items():
            assert args[key] == value


# Generated at 2022-06-22 18:43:01.616338
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Unit test for constructor of class AdHocCLI.
    """
    AdHocCLI()

# Generated at 2022-06-22 18:43:12.496749
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import sys
    import inspect
    import textwrap

    def get_member(obj, name):
        # Find and return a member (function, class, property, etc.)
        # from obj by name
        members = inspect.getmembers(obj)
        for member in members:
            if member[0] == name:
                return member[1]

    # If this is an internal class, create an instance of the
    # external class, using the same constructor arguments
    if '_' in __name__:
        # Get the module this class is defined in
        mod = sys.modules[__name__.split('.')[-2]]
        # Recreate this class in mod, using the same constructor args
        clazz = get_member(mod, __name__.split('.')[-1])

# Generated at 2022-06-22 18:43:15.141642
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    This is a test of module ansible.cli.adhoc
    '''
    adhoccmd = AdHocCLI([])
    assert adhoccmd is not None

# Generated at 2022-06-22 18:43:27.003955
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import argparse
    from ansible.module_utils.common.removed import removed_module

    def mock_parse_args(args, namespace):
        namespace.module_name = 'command'
        namespace.module_args = 'test -r'
        namespace.listhosts = None
        namespace.one_line = None
        namespace.vault_password_file = None
        namespace.forks = None
        namespace.ask_pass = None
        namespace.ask_vault_pass = None
        namespace.become = None
        namespace.become_method = None
        namespace.become_user = None
        namespace.check = None
        namespace.extra_vars = None
        namespace.graph = None
        namespace.inventory = None
        namespace.output_file = ''
        namespace.private_key_file = None
       

# Generated at 2022-06-22 18:43:30.001828
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Test class for constructor of class AdHocCLI
    '''

    ad_hoc = AdHocCLI()
    assert isinstance(ad_hoc, AdHocCLI)

# Generated at 2022-06-22 18:43:34.461139
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    a = AdHocCLI(['-u', 'root', '-i', 'hosts', 'all', '-m', 'ping', '--ask-pass'])
    options = a.options
    a.post_process_args(options)
    assert options.verbosity == 0
    assert options.subset == "all"

# Generated at 2022-06-22 18:43:39.461624
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''Unit test CLI.init_parser method. Does not test the parser.'''
    # create a dummy parser
    parser = object()

    # instantiate the CLI
    cli = AdHocCLI()

    # call the init_parser method
    res_parser = cli.init_parser(parser)

    # the init_parser method simply return the parser, so we juste check that it returns a parser
    assert parser == res_parser

# Generated at 2022-06-22 18:43:43.463271
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def test_run_mock(self):
        self.tasks = []
        return (0, "success")

    run_original = AdHocCLI.run
    AdHocCLI.run = test_run_mock
    result = AdHocCLI().run()
    AdHocCLI.run = run_original
    assert result ==  0


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-22 18:43:44.700254
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:43:45.472452
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI.init_parser("my_parser")

# Generated at 2022-06-22 18:43:46.796228
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli

# Generated at 2022-06-22 18:43:58.528361
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    parser = CLI().init_parser()

    assert parser.prog == 'ansible'
    assert parser.usage == "usage: %prog [options] [...]"
    assert parser.description == (
        "Ansible is a radically simple IT automation "
        "engine that automates cloud provisioning, configuration management, "
        "application deployment, intra-service orchestration, and many other IT needs.\n"
        "See '%prog --help' or the full documentation for a list of available modules.\n\n"
        "Options:\n")


# Generated at 2022-06-22 18:44:06.759149
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    cli = AdHocCLI(args=[])

    # test for 'Timeout Error'
    cli.run_one_task('all', 'shell', args={'echo hello'}, timeout=2)
    with pytest.raises(AnsibleError) as err:
        display.error('hello')
        assert 'Timeout Error' in str(err.value)

    # test for 'Invalid option'
    cli.parse()
    assert cli.post_process_args(cli.options) is None

# Generated at 2022-06-22 18:44:10.431508
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Test normal case
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser.prog == 'ansible'
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"

# Generated at 2022-06-22 18:44:16.783962
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class args(object):
        module_name = None
        module_args = None
        verbosity = None
    arg = args()
    arg.module_name = 'command'
    arg.module_args = 'ls'
    arg.verbosity = 2
    arg.connection = 'smart'
    context.CLIARGS = arg
    rst = AdHocCLI().post_process_args(arg)
    assert rst == arg

# Generated at 2022-06-22 18:44:18.795910
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    return adhoc_cli

# Generated at 2022-06-22 18:44:30.912491
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Tests setup
    argv = [
            '/usr/bin/ansible',
            '-m', 'copy',
            '-a', "src=~/test dest=/tmp/test",
            'all',
            '-v'
           ]

    args = AdHocCLI(argv).parse()
    # Tests run
    args = AdHocCLI(['/usr/bin/ansible', '-m', 'copy', '-a', "src=~/test dest=/tmp/test", 'all', '-v']).parse()

    # Tests assertions
    assert args.module_name == 'copy'
    assert args.module_args == "src=~/test dest=/tmp/test"
    assert args.args == 'all'
    assert args.verbosity == 1

# Generated at 2022-06-22 18:44:39.387760
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli._play_ds("all", 5, 10) == {'name': u'Ansible Ad-Hoc',
                                          'hosts': u'all',
                                          'gather_facts': u'no',
                                          'tasks': [{'action': {'module': u'ping',
                                                                'args': u''},
                                                     'timeout': 0},
                                                    {'action': {'module': u'ping',
                                                                'args': u''},
                                                     'async_val': 5,
                                                     'poll': 10,
                                                     'timeout': 0}]}

# Generated at 2022-06-22 18:44:45.983071
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    a = AdHocCLI(args=[])
    assert C.DEFAULT_FORKS == a.post_process_args(a.parse())['forks']
    assert C.DEFAULT_MODULE_NAME == a.post_process_args(a.parse())['module_name']
    assert C.DEFAULT_MODULE_ARGS == a.post_process_args(a.parse())['module_args']

# Generated at 2022-06-22 18:44:56.745379
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import os
    adhoc_cli = AdHocCLI(args=['localhost', '-m', 'command', '-a', 'whoami'],
                         bin_ansible_callbacks=False)

    assert adhoc_cli.parser._prog == 'adhoc'
    assert adhoc_cli.options._errors is None
    assert adhoc_cli.options._exit_without_starting is False
    assert adhoc_cli.options.action is None
    assert adhoc_cli.options.one_line is False
    assert adhoc_cli.options.verbosity == 0
    assert adhoc_cli.options.check is False
    assert adhoc_cli.options.force_handlers is False
    assert adhoc_cli.options.start_at_task is None
    assert adh

# Generated at 2022-06-22 18:45:05.078556
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ad_hoc test cases"""

    try:
        cmd = AdHocCLI(args=[])
        assert len(cmd.parser._optionals._actions) == 27
        assert len(cmd.parser._positionals._actions) == 1
        assert len(cmd.parser._actions) == 28
    except SystemExit:
        pass

    # Test missing required positional arguments
    try:
        cmd = AdHocCLI(args=[])
        cmd.parse()
    except SystemExit:
        pass

    # Test single positional arguments
    try:
        cmd = AdHocCLI(args=['-vvv', '-m', 'ping', 'host1'])
        cmd.parse()
    except SystemExit:
        pass

    # Test missing required positional arguments

# Generated at 2022-06-22 18:45:06.772193
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert isinstance(cli, CLI)

# Generated at 2022-06-22 18:45:18.709256
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Testing method AdHocCLI.run"""
    from ansible.cli.adhoc import AdHocCLI

    import sys
    import io
    import StringIO
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Mock class
    class MockNone:
        def __init__(self, *args, **kwargs):
            return None

        def __getattr__(self, name):
            return None

        def __setattr__(self, name, value):
            return None

        def __call__(self, *args, **kwargs):
            return MockNone()

        @classmethod
        def __getattr__(cls, name):
            if name in ('__file__', '__path__'):
                return

# Generated at 2022-06-22 18:45:29.532627
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class UnitTestAdHocCLI(AdHocCLI):
        def run(self):
            pass
    # Test1
    # basic test with no value in context.CLIARGS
    context.CLIARGS = dict()
    context.CLIARGS = {
        'become': False,
    }
    ut_ad_hoc = UnitTestAdHocCLI()
    res = ut_ad_hoc.post_process_args(context.CLIARGS)
    assert res['become'] == False

    # Test2
    # basic test with value in context.CLIARGS
    context.CLIARGS = {}
    context.CLIARGS['become'] = True
    ut_ad_hoc = UnitTestAdHocCLI()
    res = ut_ad_hoc

# Generated at 2022-06-22 18:45:41.269838
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Construct an instance of AdHocCLI
    acli = AdHocCLI(args=['-m', 'ping', '-a', 'data=hello world', 'localhost'])

    # Assert that the instance is properly constructed.
    assert acli.vault_password_files == [], 'unexpected value for vault_password_files'
    assert acli.ask_pass == False, 'unexpected value for ask_pass'
    assert acli.ask_vault_pass == False, 'unexpected value for ask_vault_pass'

    assert context.CLIARGS['module_name'] == 'ping', \
        'unexpected value for module_name'
    assert context.CLIARGS['module_args'] == 'data=hello world', \
        'unexpected value for module_args'

# Generated at 2022-06-22 18:45:42.199431
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print("This method is tested as part of this class")

# Generated at 2022-06-22 18:45:45.501740
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Set up parameters
    arg = '-vvvv -m shell -a uptime'
    adhoc_cli = AdHocCLI(args=arg.split())
    # Test run method
    adhoc_cli.run()

# Generated at 2022-06-22 18:45:48.139839
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    assert cli.args == []
    assert cli.parser is None
    cli.init_parser() # test code
    assert cli.parser is not None



# Generated at 2022-06-22 18:45:57.438062
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Args:
        ask_pass = True
        connection = 'ssh'
        connection_user = 'joe'
        ask_become_pass = True
        become = True
        become_user = 'root'
        forks = 5
        remote_user = 'jane'
        become_ask_pass = True
        private_key_file = 'a.key'
        private_key_file_user = 'bob'
        verbosity = 3
        timeout = 10
        tree = 'a.tree'
        module_name = 'shell'
        module_args = 'arg1 arg2'
        inventory_file = 'b.inv'
        inventory_file_user = 'claire'
        subset = 'c.subset'
        listhosts = True
        output_file = 'd.out'
        output

# Generated at 2022-06-22 18:46:00.586429
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    import argparse
    a = AdHocCLI()
    a.init_parser()
    assert isinstance(a.parser, argparse.ArgumentParser)


# Generated at 2022-06-22 18:46:05.158228
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import pytest

    cli = AdHocCLI(None)
    with pytest.raises(AnsibleError):
        cli.run()



# Generated at 2022-06-22 18:46:15.085058
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.module_utils.common._collections_compat import OrderedDict
    import os
    import json

    # set up some variables:
    #    hosts - list of hosts in inventory
    #    module_name - name of module to execute (e.g., ping)
    #    module_args - space separated list of arguments to the module
    #    pattern - host wildcard pattern
    hosts = ['localhost', '127.0.0.1']
    module_name = 'ping'
    module_args = '-c3'

# Generated at 2022-06-22 18:46:24.431504
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Note: ansible-playbook cannot be called with -m flag. Hence, it is an invalid option
    invalid_commands = ['-m=shell']
    # Note: ansible-playbook should be called with -f flag. Hence, it is a valid option
    valid_commands = ['-vvvv']

    # Test for Invalid Commands
    for command in invalid_commands:
        parser = AdHocCLI(command.split())
        options = parser.options
        with pytest.raises(AnsibleOptionsError) as execinfo:
            parser.post_process_args(options)
        assert to_text(execinfo.value) == '-m is not a valid playbook option'

    # Test for Valid Commands
    for command in valid_commands:
        parser = AdHocCLI(command.split())
       

# Generated at 2022-06-22 18:46:26.008480
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()
    a.init_parser()

# Generated at 2022-06-22 18:46:30.004228
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.parser.prog == "ansible"
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-22 18:46:32.908649
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI(args=[])
    assert adHocCLI.parser
# End of unit testing

# Generated at 2022-06-22 18:46:42.250045
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    from ansible.callbacks import oneline

    cli = AdHocCLI()
    cli.options = opt_help.add_options(dict(), shlex.split(u"--module-name ping localhost"))
    cli.options = opt_help.add_connect_options(cli.options, shlex.split(u""))
    cli.options = opt_help.add_runtask_options(cli.options, shlex.split(u""))
    cli.options = opt_help.add_module_options(cli.options, shlex.split(u""))
    cli.options = opt_help.add_fork_options(cli.options, shlex.split(u""))

    cli.parser = opt_help.CLIOptionParser(cli.options)
    cli.validate_

# Generated at 2022-06-22 18:46:51.075246
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    opt = opt_help.define_runas_options()
    opt += opt_help.define_inventory_options()
    opt += opt_help.define_async_options()
    opt += opt_help.define_output_options()
    opt += opt_help.define_connect_options()
    opt += opt_help.define_check_options()
    opt += opt_help.define_runtask_options()
    opt += opt_help.define_vault_options()
    opt += opt_help.define_fork_options()
    opt += opt_help.define_module_options()
    opt += opt_help.define_basedir_options()
    opt += opt_help.define_tasknoplay_options()

    options, args = adhoc.parser

# Generated at 2022-06-22 18:46:52.492549
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()  # expected to fail, return code != 0

# Generated at 2022-06-22 18:46:54.711409
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    context.CLIARGS = {}
    adhoc = AdHocCLI()

    assert adhoc._tqm is None


# Generated at 2022-06-22 18:46:59.880310
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoccl = AdHocCLI(args=['-i', 'hosts', 'host1', 'host2', 'host3'])
    assert adhoccl.options.module_name == 'command'
    assert adhoccl.options.module_args == ''
    assert adhoccl.options.args == '\'host1\' \'host2\' \'host3\''


# Generated at 2022-06-22 18:47:12.371555
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test to verify '-f' and '-k' options conflict
    cli = AdHocCLI(args=[])
    opts = cli.parser.parse_args(['all', '-m', 'command', '-a', 'uname -a'])
    args = cli.post_process_args(opts)
    assert args.forks == 5

    # Test to verify '-f' and '-k' options conflict
    cli = AdHocCLI(args=[])
    opts = cli.parser.parse_args(['all', '-m', 'command', '-a', 'uname -a', '-k'])
    args = cli.post_process_args(opts)
    assert args.ask_pass

    # Test to verify '-f' and '-k'

# Generated at 2022-06-22 18:47:22.616616
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # mock up args
    from ansible.constants import __version__
    from ansible.utils.display import Display
    from datetime import datetime


# Generated at 2022-06-22 18:47:24.972434
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Create an object of class AdHocCLI
    adp = AdHocCLI()



# Generated at 2022-06-22 18:47:27.067179
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.parser.description

# Generated at 2022-06-22 18:47:39.906619
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    # Checking the help menu of AdHocCLI
    adhoc_help = adhoc.parser.format_help()
    assert "Define and run a single task 'playbook' against a set" in to_text(adhoc_help)
    assert "host pattern" in to_text(adhoc_help)
    assert "Some actions do not make sense in Ad-Hoc" in to_text(adhoc_help)
    # Checking the argument list of AdHocCLI
    adhoc_args = set(adhoc.parser._actions[1:])
    assert isinstance(adhoc_args, set)
    # Checking the runas_opts argument list of AdHocCLI
    adhoc_runasopts

# Generated at 2022-06-22 18:47:42.854946
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cliargs = {}
    cli = AdHocCLI(args=[], cliargs=cliargs)
    assert cli.parser._usage == '%prog <host-pattern> [options]'

# Generated at 2022-06-22 18:47:56.206649
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(['-f', '4', '-m', 'ping', '-a', 'data=hello', '-k', '-K', '-u', 'joe', 'localhost'])
    options = cli.parse()
    post_processed_options = cli.post_process_args(options)
    assert post_processed_options['become_method'] == 'sudo'
    assert post_processed_options['forks'] == '4'
    assert post_processed_options['ask_pass'] == True
    assert post_processed_options['ask_become_pass'] == True
    assert post_processed_options['become_user'] == 'joe'
    assert post_processed_options['module_name'] == 'ping'
    assert post_processed_

# Generated at 2022-06-22 18:48:00.142521
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    """
    unit test for init_parser method of AdHocCLI class
    """

    cli = AdHocCLI()

    # assert isinstance(cli.parser, argparse.HelpFormatter)
    assert hasattr(cli, '_play_prereqs')



# Generated at 2022-06-22 18:48:12.710062
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options = adhoc_cli.parse([])
    adhoc_cli.post_process_args(options)

# Generated at 2022-06-22 18:48:21.786595
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple

    context.CLIARGS = namedtuple('CLIARGS',
                                 'connection forks module_name module_path module_args timeout become become_user check diff listhosts listtasks listtags verbosity syntax start_at_task subset one_line vault_password_file')

    cli = AdHocCLI()
    cli.init_parser()

    context.CLIARGS = cli.parse_args(
        'localhost -m ping -a "data=hello"'.split())

    context.CLIARGS = context.CLIARGS._replace(verbosity=4)
    context.CLIAR

# Generated at 2022-06-22 18:48:30.201836
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Create AdHocCLI object which calls init_parser method
    cli = AdHocCLI()
    cli.init_parser()
    # Check usage text
    assert cli.parser._prog_usage == '%prog <host-pattern> [options]'
    # Check description text
    assert cli.parser._prog_description.startswith("""\
Define and run a single task 'playbook' against a set of hosts""")
    # Check epilog text
    assert cli.parser._prog_epilog.startswith("""\
Some actions do not make sense in Ad-Hoc (include, meta, etc)""")