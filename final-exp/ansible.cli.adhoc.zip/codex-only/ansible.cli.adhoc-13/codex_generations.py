

# Generated at 2022-06-22 18:38:36.774291
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Test for AdHocCLI class
    """


# Generated at 2022-06-22 18:38:38.787046
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoccli = AdHocCLI()
    adhoc = adhoccli.run(None, None)

    assert adhoc == 0


# Generated at 2022-06-22 18:38:42.807436
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    cli.init_parser()
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"



# Generated at 2022-06-22 18:38:45.457039
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoccli = AdHocCLI([])
    adhoccli.init_parser()


# Generated at 2022-06-22 18:38:54.535568
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os 
    # When test_adhoc.py file is executing, current working directory is not 
    # test directory, that's why explicit path should be set. 
    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(my_path)

    from ansible.cli.adhoc import AdHocCLI
    from ansible.module_utils.basic import AnsibleModule

    ad = AdHocCLI(args=['./test/hosts', '-i', './test/hosts',
                    '-k', '-K', '-m', 'ping', '-a', 'ping'])
    # mock sys.argv to simulate stdin while testing.

# Generated at 2022-06-22 18:39:03.404196
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['./ansible', '--module-name', 'some_module', '--module-args', 'a=b', 'some_host']
    with AdHocCLI() as cli:
        cli.parse(args)
        cli.post_process_args(cli.args)
        assert context.CLIARGS['module_name'] == 'some_module'
        assert context.CLIARGS['module_args'] == 'a=b'
        assert context.CLIARGS['args'] == 'some_host'




# Generated at 2022-06-22 18:39:07.736253
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Constructor for class AdHocCLI
    adhoc_cli = AdHocCLI()

    # Run the run() method to see if it exits without throwing an error
    try:
        adhoc_cli.run()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-22 18:39:14.738734
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()

    assert isinstance(parser, CLI.parser_class)

    # option: -a, --args
    option_name = '-a'
    option = parser._option_string_actions[option_name]
    assert option.dest == 'module_args'
    assert option.default == C.DEFAULT_MODULE_ARGS

    option_name = '--args'
    option = parser._option_string_actions[option_name]
    assert option.dest == 'module_args'
    assert option.default == C.DEFAULT_MODULE_ARGS

    # option: -m, --module-name
    option_name = '-m'
    option = parser._option_string_actions[option_name]
    assert option.dest

# Generated at 2022-06-22 18:39:17.001359
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()

    parser = adhoc.parser
    assert parser is not None


# Generated at 2022-06-22 18:39:27.388943
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from ansible import constants as C
    from ansible.cli.adhoc import AdHocCLI
    from ansible.errors import AnsibleOptionsError
    from ansible.parsing.splitter import parse_kv
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    # Setup

# Generated at 2022-06-22 18:39:28.746590
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli is not None

# Generated at 2022-06-22 18:39:32.843718
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Used with pytest of the test_adhoc_run.py file, to handle
    the AdHocCLI.run() method
    '''
    adhoc_cli = AdHocCLI()
    #TODO: fix this test, currently fails due to missing CLI options
    #assert adhoc_cli.run() == 0

# Generated at 2022-06-22 18:39:38.971895
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-i', 'hosts', '-a', 'cmd="some command"', '-f', '10', '-u', 'someuser', 'somehost']
    cli = AdHocCLI([])
    options = cli.parser.parse_args(args)
    options = cli.post_process_args(options)
    assert options.host_pattern == 'somehost'
    assert options.inventory == 'hosts'
    assert options.module_name == 'command'
    assert options.module_args == 'cmd="some command"'
    assert options.forks == 10
    assert options.remote_user == 'someuser'

# Generated at 2022-06-22 18:39:41.947063
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    options = adhoc.parse()
    options = adhoc.post_process_args(options)
    assert not options.help


# Generated at 2022-06-22 18:39:52.287002
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    cli.args = ['test']
    cli.options = cli.parser.parse_args(cli.args)
    assert cli.options.verbosity == 0
    assert cli.options.ask_vault_pass is False
    assert cli.options.ask_sudo_pass is False
    assert cli.options.ask_su_pass is False
    assert cli.options.ask_pass is False
    assert cli.options.vault_password_file is None
    assert cli.options.new_vault_password_file is None
    assert cli.options.force_handlers is False
    assert cli.options.flush_cache is False
    assert cli.options.listhosts is False
    assert cli

# Generated at 2022-06-22 18:39:57.221078
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoccli = AdHocCLI()
    (options, args) = adhoccli.parser.parse_args(['-i', 'hosts', '-m', 'ping', 'all'])
    context.CLIARGS = options
    adhoccli.post_process_args(options)
    assert context.CLIARGS['module_name'] == 'ping'
    assert context.CLIARGS['pattern'] == 'all'

# Generated at 2022-06-22 18:39:58.033352
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    assert True

# Generated at 2022-06-22 18:40:07.183745
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import ansible.constants as C
    import ansible.utils.display as display
    class TestAdHocCLI(AdHocCLI):
        def post_process_args(self, options):
            return super(TestAdHocCLI, self).post_process_args(options)

    options = [
        '--module-name', 'ping'
    ]
    tcli = TestAdHocCLI(args=options)
    # test verbosity ad hoc options
    for verbosity in range(0, 5):
        options = [
            '--module-name', 'ping',
            '--verbosity', str(verbosity)
        ]
        tcli.run()
        assert display.verbosity == verbosity
    # test minimal ad hoc options

# Generated at 2022-06-22 18:40:07.977634
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    pass

# Generated at 2022-06-22 18:40:13.047813
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])
    assert cli.parser._usage == '%prog <host-pattern> [options]'
    assert cli.parser._actions[1].choices == ['smart', 'ssh', 'paramiko', 'docker', 'winrm', 'local']

# Generated at 2022-06-22 18:40:19.564546
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create an instance of AdHocCLI
    adhoc_cli_obj = AdHocCLI()
    # Create an instance of parser
    parser_obj = adhoc_cli_obj.parser
    # Run the method post_process_args with following test arguments
    options = parser_obj.parse_args(['-m', 'debug', '-a', 'var=val', 'all'])
    result = adhoc_cli_obj.post_process_args(options)
    display.display(result)

# Generated at 2022-06-22 18:40:28.983005
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    fake_inventory = FakeInventory()
    fake_loader = FakeLoader()
    fake_variable_manager = FakeVariableManager()
    fake_cli = FakeAdHocCLI(fake_loader, fake_inventory, fake_variable_manager)

    fake_ds = {'hosts': ['host1'],
               'tasks': [{'action': {'module': 'shell', 'args': 'echo "Hello World"'},
                          'name': 'Ansible Ad-Hoc'}]}
    # if not fake_ds['hosts']:
    #    raise AnsibleError("Pattern is empty")

    # Create a fake play

# Generated at 2022-06-22 18:40:39.555930
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    sys.path.append("..")
    import test_utils
    test_utils.run_module(module_name="ansible.cli.adhoc", module_args="--listhosts 127.0.0.1",
                          expected_result={"hosts": {'127.0.0.1': {}}},
                          result_type="dict",
                          args="--listhosts 127.0.0.1 --connection=local")

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 18:40:42.591494
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Initialize AdHocCLI and call init_parser; check it returns 0
    cli = AdHocCLI(['-m', 'shell', '-a', 'date', 'all'])
    assert 0 == cli.init_parser()

# Generated at 2022-06-22 18:40:45.980248
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None


# Generated at 2022-06-22 18:40:57.678427
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-22 18:41:05.017170
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from io import StringIO
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.playbook import PlaybookExecutor

    display = Display()
    module_name = "ping"
    module_args = "data=data"

# Generated at 2022-06-22 18:41:11.368005
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # pylint: disable=import-error
    # import AdHocCLI
    # instantiate class
    cli_instance = AdHocCLI()
    # call into method run
    result = cli_instance.run()
    # assert result is an integer
    assert isinstance(result, int)
    # assert result is 0
    assert result == 0

# Generated at 2022-06-22 18:41:13.105989
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-22 18:41:17.990669
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Arrange

    # Act
    cli = AdHocCLI()
    result = cli.init_parser()
    print(result)

    # Assert

    assert True

# Generated at 2022-06-22 18:41:20.950639
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    mycli = AdHocCLI()
    mycli.options = {}
    mycli.options['args'] = 'test_host'
    mycli.options['module_name'] = 'shell'
    mycli.options['module_args'] = 'some_test_arg'
    try:
        mycli.run()
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-22 18:41:31.675259
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create test object of class AdHocCLI without arguments
    test_AdHocCLI = AdHocCLI(args=context.CLIARGS)
    test_AdHocCLI.init_parser()

    # Initialize Ansible Context
    context._init_global_context(args=context.CLIARGS)

    # Create ArgumentParser object for testing purposes
    import argparse
    test_parser = argparse.ArgumentParser(description='Ad-hoc module execution')

    # Set Ansible options to arguments

# Generated at 2022-06-22 18:41:32.832363
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI.init_parser()

# Generated at 2022-06-22 18:41:39.812450
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    class Object(object):
        pass

    adhoc_cli = AdHocCLI(Object())
    adhoc_cli.init_parser()
    assert adhoc_cli.parser.usage == "%prog <host-pattern> [options]"
    assert adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-22 18:41:45.609213
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    cli = AdHocCLI(args=[])
    options = cli.parse()
    options = cli.post_process_args(options)

    assert options.host_pattern

    options.host_pattern = None

    try:
        cli.post_process_args(options)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-22 18:41:56.999998
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    This unit test checks some cases for method post_process_args from AdHocCLI class.
    It covers two cases:
        - when there are no conflicts between options
        - when there are conflicts between options
    """
    # create a new parser
    parser = CLI.base_parser()

    # create a new instance of class AdHocCLI
    cli = AdHocCLI()

    # initialize parser
    cli.init_parser()

    # create a fake parser
    class FakeParser(object):
        """
        This class creates a fake parser which contains options
        """
        def __init__(self):
            # initialize options
            self.options = ['become']
    parser._parsers['runas'] = FakeParser()

    # create another fake parser

# Generated at 2022-06-22 18:42:08.336220
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # Create an empty parser
    adhoc_cli = AdHocCLI()
    adhoc_cli.parser = opt_help.create_parser(adhoc_cli, '{prog}')

    # Call method
    adhoc_cli.init_parser()

    # Initialize expected results
    expected_usage = '%prog <host-pattern> [options]'
    expected_desc = "Define and run a single task 'playbook' against a set of hosts"
    expected_epilog = "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

    # Verify results
    assert adhoc_cli.parser.usage == expected_usage
    assert adhoc_cli.parser.description == expected_desc
    assert adhoc_cli.parser.epilog == expected_epilog

# Generated at 2022-06-22 18:42:12.140717
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_c = AdHocCLI(['localhost'],
                        ['-m', 'ping', '-a', 'ping_strategy=all'])

    adhoc_c.post_process_args(adhoc_c.options)
    assert adhoc_c.run() == 0



# Generated at 2022-06-22 18:42:18.705155
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Test post_process_args method of AdHocCLI class
    '''
    adhoc = AdHocCLI(args=[])
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = 'ping'

    context.CLIARGS['module_args'] = '-m ping'

    adhoc.post_process_args(context.CLIARGS)

    assert context.CLIARGS['module_name'] == 'ping'


# Generated at 2022-06-22 18:42:19.800633
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()
    pass

# Generated at 2022-06-22 18:42:21.099540
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[]).parse()
    assert cli.args == []

# Generated at 2022-06-22 18:42:26.029751
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' Test to check if the class constructor works properly,
        checking if the parser is constructed properly
    '''
    adhoc = AdHocCLI(args=[])
    assert adhoc.parser is not None, "Construtor fails to create a parser"

# Generated at 2022-06-22 18:42:38.903975
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from unittest import TestCase
    from ansible import errors as ansible_errors
    from ansible.playbook.play import Play

    class MockTaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks, run_tree, forks):
            pass

        def load_callbacks(self):
            pass

        def send_callback(self, name, *args):
            pass

        def run(self, play):
            return play

        def cleanup(self):
            pass

    class MockLoader:
        def cleanup_all_tmp_files(self):
            pass


# Generated at 2022-06-22 18:42:48.185388
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    class MyCLI(AdHocCLI):
        def __init__(self, mock_args):
            self.mock_args = mock_args
            self.parser = None

    cli = MyCLI(['foo', '-v', '-m', 'ping'])
    cli.post_process_args()

    # Let's test our post_process_args method
    assert cli.options.verbosity == 2
    assert cli.options.module_name == 'ping'

    # Now we test with multiple args
    cli = MyCLI(['foo', '-v', '-m', 'ping', '-a', '--option'])
    cli.post_process_args()

    assert cli.options.module_args == '--option'

    # Now test for failure

# Generated at 2022-06-22 18:42:49.329884
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Can't be tested
    pass

# Generated at 2022-06-22 18:42:53.286529
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()

    from ansible.cli.arguments import option_helpers as opt_help
    adhoc_cli.init_parser()
    #assert True


# Generated at 2022-06-22 18:43:00.658821
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.options = mock.Mock()
    cli.options.listhosts = False
    cli.options.module_name = 'ping'
    cli.options.module_args = 'data=boom'
    cli.options.forks = 10
    cli.options.tags = ''
    cli.options.skip_tags = ''
    cli.options.check = False
    cli.options.extra_vars = []
    cli.options.ask_vault_pass = False
    cli.options.vault_password_files = []
    cli.options.new_vault_password_file = None
    cli.options.output_file = None
    cli.options.one_line = True

# Generated at 2022-06-22 18:43:01.659384
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=[])

# Generated at 2022-06-22 18:43:12.540841
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Object(object): pass
    options = Object()
    options.subset = None
    options.inventory = None
    options.module_paths = None
    options.listhosts = None
    options.subset = None
    options.extra_vars = None
    options.forks = None
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = None
    options.become_method = None
    options.become_user = None
    options.verbosity = None
    options.check = None
    options.syntax = None
    options.connection = None
    options.timeout = None
    options

# Generated at 2022-06-22 18:43:21.404161
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import pprint
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import constants as C

# Generated at 2022-06-22 18:43:32.000994
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    # TODO: CLI Integration test
    #Test if all options are registered
    options = {o.dest for o in cli.parser._option_string_actions.values()}

# Generated at 2022-06-22 18:43:40.511426
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    ansible_options = C.config.option_list_ad_hoc.keys()

    options_test_args_invalid_verbosity_level = [
        '-v', '1',
        '--ansible-inventory', 'hosts',
        '--module-name', 'ping',
        'all',
    ]

    options_test_args_valid_verbosity_level = [
        '-v', '4',
        '--ansible-inventory', 'hosts',
        '--module-name', 'ping',
        'all',
    ]

    options_test_args_not_command_no_inventory = [
        '--module-name', 'ping',
        'all',
    ]


# Generated at 2022-06-22 18:43:52.422471
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=["172.10.10.10", "-m", "ping"],
                   callback=None,
                   runas_opts=True,
                   async_opts=True,
                   output_opts=True,
                   connect_opts=True,
                   runtask_opts=True,
                   check_opts=True,
                   vault_opts=True)
    assert cli.parser.prog == "ansible"
    assert cli.parser.usage == "%prog <host-pattern> [options]"
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    # test common options

# Generated at 2022-06-22 18:43:56.738161
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Pass a mock object for argument 'self'
    adhoc_cli = CLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser is not None


# Generated at 2022-06-22 18:44:05.690994
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    mock_args = dict()
    mock_args['module_path'] = "/path/to/modules"
    mock_args['forks'] = 20
    mock_args['listhosts'] = False
    mock_args['listtags'] = False
    mock_args['listtasks'] = False
    mock_args['syntax'] = None
    mock_args['module_name'] = "setup"
    mock_args['module_args'] = ""
    mock_args['one_line'] = False
    mock_args['tree'] = None
    mock_args['ask_vault_pass'] = False
    mock_args['vault_password_files'] = ""
    mock_args['vault_ids'] = ""

# Generated at 2022-06-22 18:44:11.556439
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    adhoc.options = {}
    adhoc.options['verbosity'] = 1
    adhoc.options['module_name'] = 'shell'
    adhoc.options['module_args'] = 'ls -al'

    # should return 0 since we are not running the playbook
    # just get list of hosts to execute against
    adhoc.post_process_args(adhoc.options)

# Generated at 2022-06-22 18:44:12.370026
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:44:14.220285
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_obj = AdHocCLI()
    assert isinstance(adhoc_obj, AdHocCLI)

# Generated at 2022-06-22 18:44:25.628239
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test load module
    module = "ping"
    # Test user
    user = "root"
    # Test pass
    password = "pass"
    # Test host
    host = "127.0.0.1"
    # Test port
    port = 22
    # Test module args
    module_args = host

    AdHocCLI = AdHocCLI()
    AdHocCLI.run()

    module = AdHocCLI.post_process_args()
    module = AdHocCLI.run()
    module = AdHocCLI._play_ds()

    display = AdHocCLI.Display()
    display.scan_available_tags()

    context = AdHocCLI.context

# Generated at 2022-06-22 18:44:30.559177
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_object = AdHocCLI()
    ad_hoc_parser = ad_hoc_object.init_parser()
    assert isinstance(ad_hoc_parser, type(ad_hoc_object.parser))


# Generated at 2022-06-22 18:44:34.575026
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI(['-h'])
    adhoc_cli.init_parser()

    parser = adhoc_cli.parser

    assert parser.usage == '%prog <host-pattern> [options]'

# Generated at 2022-06-22 18:44:38.536103
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_cli = AdHocCLI()
    assert(ad_hoc_cli.parser.prog == 'ansible')


# Generated at 2022-06-22 18:44:50.922708
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    adhoc_cli = AdHocCLI()
    assert type(adhoc_cli) == AdHocCLI
    assert adhoc_cli.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc_cli.parser.description == '''Define and run a single task 'playbook' against a set of hosts'''
    assert adhoc_cli.parser.epilog == 'Some actions do not make sense in Ad-Hoc (include, meta, etc)'
    assert type(adhoc_cli.parser.add_argument) == type(adhoc_cli.parser.add_argument)
    assert type(adhoc_cli.parser.add_argument_group) == type(adhoc_cli.parser.add_argument_group)

# Generated at 2022-06-22 18:45:01.966178
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit test for method run of class AdHocCLI '''

    import sys
    import unittest

    # The sys.argv is the original argument list and often referred to as the argument vector.
    sys.argv = ['ansible-runner', '-i', 'inventory', 'hosts', '-m', 'ping', '-a', 'data=hello world']
    sys.argv[0] = ''

    # This class is a subclass of the unittest.TestCase class. It provides a way of testing methods of a class or module.
    class MockTaskQueueManager:
        ''' Mock class for TaskQueueManager '''
        def run(self, play):
            ''' Mock method for TaskQueueManager method run '''
            return 'task_result'


# Generated at 2022-06-22 18:45:02.903133
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-22 18:45:05.859696
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    run these tests by executing:
    python test/units/cli/callback/test_ad_hoc_cli.py
    """
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.run()

# Generated at 2022-06-22 18:45:10.273716
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert(isinstance(adhoc_cli.parser,CLI.parser.__class__))


# Generated at 2022-06-22 18:45:10.877140
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:45:12.279356
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli_obj = AdHocCLI()
    pass

# Generated at 2022-06-22 18:45:24.275382
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    module_name = 'shell'
    module_args = 'foo'
    args = ['ansible', 'localhost', '-m', module_name, '-a', module_args, '--one-line', '--tree', '/tmp/tree']

    # create an instance of AdHocCLI
    cli = AdHocCLI(args)

    # call the method post_process_args, which returns an object of type ParsedCLIArgs
    result = cli.post_process_args(cli.options)

    # verifies if this object has the expected attributes and values
    assert result.verbosity == 0
    assert result.module_name == module_name
    assert result.module_args == module_args
    assert result.one_line
    assert result.tree == '/tmp/tree'

# Execute this module


# Generated at 2022-06-22 18:45:35.358053
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test a successful run
    context.CLIARGS['seconds'] = False
    context.CLIARGS['poll_interval'] = False
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['listtags'] = False
    context.CLIARGS['subset'] = False
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['check'] = False
    context.CLIARGS['module_name'] = None  # so we get the default
    context.CLIARGS['module_args'] = None
    context.CLIARGS['tree'] = None
    context.CLIARGS['extra_vars'] = None

    # just a very simple playbook

# Generated at 2022-06-22 18:45:38.676210
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_object = AdHocCLI()
    test_object.init_parser()
    context.CLIARGS = test_object.parser.parse_args(args=[])
    assert test_object.run() == 0

# Generated at 2022-06-22 18:45:44.824728
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['127.0.0.1', '-m', 'shell', '-a', '"cmd=hostname"'])
    assert cli.parser
    assert cli.options
    assert cli.args
    assert cli.passwords
    assert cli.callback
    assert cli.inventory
    assert cli.variable_manager
    assert cli.loader
    assert cli.tqm


# Generated at 2022-06-22 18:45:47.848901
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI()
    assert(ad_hoc)

# Generated at 2022-06-22 18:45:48.608626
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:46:01.858638
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['-a', 'test_arg', 'host_pattern'])
    assert cli.parser._actions[1].dest == 'args'
    assert cli.parser._actions[1].choices == None
    assert cli.parser._actions[1].type == 'str'
    assert cli.parser._actions[1].metavar == 'pattern'
    assert cli.parser._actions[1].default == None
    assert cli.parser._actions[1].required == True
    assert cli.parser._actions[1].help == 'host pattern'
    assert cli.parser._actions[1].nargs == 1
    assert cli.parser._actions[1].const == None
    assert cli.parser._actions[1].choices == None

# Generated at 2022-06-22 18:46:13.321095
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_cli = AdHocCLI()

# Generated at 2022-06-22 18:46:21.249351
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    parser = cli.init_parser()
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert parser.prog == "ansible-adhoc"
    assert isinstance(parser.get_default('module_name'), str)
    assert isinstance(parser.get_default('module_args'), str)


# Generated at 2022-06-22 18:46:22.560432
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc != None

# Generated at 2022-06-22 18:46:28.935173
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Unit test for method post_process_args of class AdHocCLI"""
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    options = adhoc_cli.parser.parse_args(['--version'])
    options = adhoc_cli.post_process_args(options)

# Generated at 2022-06-22 18:46:40.002905
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Do a unit test of method post_process_args of class AdHocCLI
    '''

    # Mock output of method get_optparser_arglist of class AdHocCLI
    class MockAdHocCLI:
        def __init__(self):
            self.optparser = MockOptParser()

        def get_optparser_arglist(self):
            return []

    # Mock output of method get_defaults of class MockOptParser

# Generated at 2022-06-22 18:46:42.752964
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
	my_adhoc_cli = AdHocCLI()
	my_adhoc_cli.init_parser()
	actual = my_adhoc_cli.parser._actions[1].dest
	expected = "module_args"
	assert actual == expected


# Generated at 2022-06-22 18:46:43.192541
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:46:55.519935
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.parse()

# Generated at 2022-06-22 18:47:07.198643
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Mock(object):
        pass
    mock_options = Mock()
    mock_options.module_name = 'debug'
    mock_options.module_args = 'msg=hello'
    mock_options.listhosts = False
    mock_options.subset = None
    mock_options.extra_vars = None
    mock_options.verbosity = 0
    mock_options.inventory = 'tests/unit/files/hosts'
    mock_options.pattern = None
    mock_options.become = False
    mock_options.become_user = 'root'
    mock_options.ask_vault_pass = True
    mock_options.new_vault_password_file = None
    mock_options.output_file = None
    mock_options.check = False
    mock_options.syntax = False

# Generated at 2022-06-22 18:47:18.170174
# Unit test for method init_parser of class AdHocCLI

# Generated at 2022-06-22 18:47:29.281998
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    module_option = "some_module"
    module_args = "some_args"
    hosts = "some_hosts"

    class MockOptions(object):
        verbosity = 0
        module_name = module_option
        module_args = module_args
        connection = 'local'
        check = False
        listhosts = False
        listtasks = False
        listtags = False
        subset = None
        forks = 5
        diff = False
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        become_exe = None

# Generated at 2022-06-22 18:47:33.005001
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"

# Generated at 2022-06-22 18:47:41.409044
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli._play_prereqs = lambda: (None, None, None)
    cli.ask_passwords = lambda: (None, None)
    cli.get_host_list = lambda invent, subset, pattern: None
    cli.parser = cli.create_parser()
    cli.options, cli.args = cli.parser.parse_args(['localhost'])
    assert cli.post_process_args(cli.options).host_pattern == 'localhost'

# Generated at 2022-06-22 18:47:42.608252
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI([]).init_parser()


# Generated at 2022-06-22 18:47:46.137514
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    assert parser is not None
    assert type(parser) is type(cli.parser)


# Generated at 2022-06-22 18:47:49.777084
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['ansible', '--version'])
    cli.parse()
    assert context.CLIARGS == {'version': True}

# Generated at 2022-06-22 18:48:01.409558
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # mocker_factory is used to patch modules or methods in the unit test
    # example: mocker_factory.patch('ansible.cli.adhoc.AdHocCLI.init_parser')
    # example: mocker_factory.patch.object(AdHocCLI, 'init_parser')
    #
    # python -m pytest tests/unit/cli/adhoc/test_adhoc.py -k check_adhoc_parser -v
    mocker_factory = MockerFixture()
    mocker = mocker_factory.mocker
    mocker.patch('ansible.cli.adhoc.AdHocCLI.init_parser')

    mocker.patch.object(AdHocCLI, 'init_parser')
    ac = AdHocCLI()
    ac.init_parser

# Generated at 2022-06-22 18:48:07.700205
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    AdHocCLI.setup_loader()
    adhoc_cli = AdHocCLI(args=[])
    options = adhoc_cli.parse()
    adhoc_cli.post_process_args(options)
    assert not context.CLIARGS['connection'] == 'local'
    assert not context.CLIARGS['one_line']

# Generated at 2022-06-22 18:48:10.309563
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    parser = cli.init_parser()
    assert parser is not None


# Generated at 2022-06-22 18:48:14.767784
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from setuptools.command.egg_info import alias
    adHocCli = AdHocCLI(alias("test", "ansible-test"), None)
    assert adHocCli.post_process_args(None) == None


# Generated at 2022-06-22 18:48:18.633793
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # test init_parser
    parser = AdHocCLI(['ansible', 'all', '-i', 'abc', '-m', 'test_module'])
    options = parser.parse()

    # test post_process_args
    options = parser.post_process_args(options)



# Generated at 2022-06-22 18:48:19.719803
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()


# Generated at 2022-06-22 18:48:29.883975
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI(args=[])
    adhoc_cli.parser.add_argument('-i', '--inventory', dest='inventory', required=True,
                                  help="Specify inventory host path (default=%s) or comma separated host list." % C.DEFAULT_HOST_LIST)
    adhoc_cli.options, args = adhoc_cli.parser.parse_known_args(['-i','tests/ansible_test_inventory','testhost'])
    adhoc_cli.post_process_args(adhoc_cli.options)
    assert adhoc_cli.options.inventory == 'tests/ansible_test_inventory'