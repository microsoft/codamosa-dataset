

# Generated at 2022-06-22 18:38:36.775038
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    :return: None
    '''
    options = opt_help.define_vault_opts(opt_help.base_parser(constants=C))
    cli = AdHocCLI(args=[])
    cli.parser = options
    opts = cli.post_process_args(options.parse_args([]))
    assert opts.vault_password_file == C.DEFAULT_VAULT_PASSWORD_FILE
    assert opts.new_vault_password_file == C.DEFAULT_NEW_VAULT_PASSWORD_FILE
    assert opts.vault_ids == []

dir(AdHocCLI)
dir(opt_help)
dir(opt_help.base_parser(constants=C))
AdHocCLI(args = [])


# Generated at 2022-06-22 18:38:47.993717
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # testing module initialization
    adhoccli = AdHocCLI(['ansible', '-h'])

    # testing module arguments
    options = adhoccli.options
    assert options.verbosity == 0
    assert options.inventory == C.DEFAULT_HOST_LIST
    assert options.module_path is None
    assert options.pattern is None
    assert options.ask_pass is False
    assert options.private_key_file is None
    assert options.syntax is None
    assert options.ask_sudo_pass is False
    assert options.ask_su_pass is False
    assert options.diff is False
    assert options.listhosts is False
    assert options.listtasks is False
    assert options.listtags is False
    assert options.module_name is None
    assert options.module_args is None


# Generated at 2022-06-22 18:38:58.225721
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-22 18:39:04.181711
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test with no argument
    adhoc = AdHocCLI(args=[])
    assert adhoc.args == []

    # Test with arguments
    adhoc = AdHocCLI(args=['localhost', '-m', 'ping', '-a', 'data=blabla'])
    assert adhoc.args == [['localhost', '-m', 'ping', '-a', 'data=blabla']]

# Generated at 2022-06-22 18:39:07.170505
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # Init object AdHocCLI
    adhoc_cli = AdHocCLI()

    # Call method init_parser
    adhoc_cli.init_parser()

    assert adhoc_cli.parser is not None




# Generated at 2022-06-22 18:39:13.939815
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI(args=[])
    assert(ad_hoc._usage.startswith("usage: ansible-adhoc"))
    assert(ad_hoc._description.startswith("Define and run a single task 'playbook' against a set of hosts"))
    assert(ad_hoc._epilog.startswith("Some actions do not make sense in Ad-Hoc"))


# Generated at 2022-06-22 18:39:16.220891
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=[])
    assert isinstance(adhoc_cli, AdHocCLI)

# Generated at 2022-06-22 18:39:18.128956
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli_adhoc = AdHocCLI()
    assert isinstance(cli_adhoc, AdHocCLI)

# Generated at 2022-06-22 18:39:28.376948
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Use the module to avoid SystemExit
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli.adhoc import AdHocCLI
    display = Display()
    _tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords={},
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
        forks=5,
    )
    ahc = AdHocCLI(_tqm, display)
    assert isinstance(ahc, CLI)
    assert hasattr(ahc, '_display')
    assert hasattr(ahc, '_tqm')

# Generated at 2022-06-22 18:39:30.059118
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_obj = AdHocCLI(command='command')
    adhoc_ob

# Generated at 2022-06-22 18:39:38.254341
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''Runing unit tests for AdHocCLI class post_process_args method
    :return: int value
    '''
    if not PYTHON_VERSION_INFO[0] < 3 or not PYTHON_VERSION_INFO[1] < 5:
        from unittest.mock import patch, mock_open
    else:
        from mock import patch, mock_open

# Generated at 2022-06-22 18:39:40.255274
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI(command='').init_parser()
    assert parser is not None

# Generated at 2022-06-22 18:39:45.517522
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    test_args = ['ansible', 'all', '-a', 'setup', '-u', 'joe', '-k']
    cl = AdHocCLI(args=test_args)
    data = cl.post_process_args(cl.parse())
    assert data['module_name'] == C.DEFAULT_MODULE_NAME
    assert data['module_args'] == C.DEFAULT_MODULE_ARGS

# Generated at 2022-06-22 18:39:56.155688
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create the object
    args = AdHocCLI()

    # Create a dictionary for the options

# Generated at 2022-06-22 18:39:59.385659
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    # Verify some of the arguments
    cli.parser.parse_args(['-f', '5', '-u', 'user1', '-m', 'shell', '-a', 'date', 'all'])

# Generated at 2022-06-22 18:40:01.426846
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-22 18:40:02.864602
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a=AdHocCLI()
    a.run()

# Generated at 2022-06-22 18:40:04.638418
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:40:08.375008
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    #test defaults of all inputs
    AdHocCLI().run()
    #test with inputs
    #AdHocCLI().run(["-m","module_name","-a","module_args","-f","forks"])

# Generated at 2022-06-22 18:40:12.584353
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    options = adhoc.parser.parse_args([])[0]
    options = adhoc.post_process_args(options)
    assert options.verbosity == 0

# Generated at 2022-06-22 18:40:23.343188
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    cli = AdHocCLI()

    # Create a list of a single host
    host_list_of_one_host = ["dell-poweredge-1950"]

    # Create a empty dictionary
    passwords = {}

    # Create a fake object that dosen't have the method wrap_var
    fake_inventory_dont_have_wrap_var = object()

    # Create a fake object that dosen't have the method set_variable
    fake_variable_man_dont_have_set_variable = object()

    # If subsystem_name is set to AnsibleRunner ( unit test ) then wrap_var is called instead of set_variable
    if C.DEFAULT_SUBSET:
        fake_variable_manager = fake_variable_man_dont_have_set_variable
       

# Generated at 2022-06-22 18:40:27.060948
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    opt = ['-i', 'hosts', 'hostname']
    c = AdHocCLI(opt)
    c.post_process_args(c.options)
    assert context.CLIARGS['inventory'] == 'hosts'
    assert context.CLIARGS['args'] == 'hostname'

# Generated at 2022-06-22 18:40:28.587067
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''AdHocCLI(args=None)'''
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-22 18:40:40.041513
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['-m', 'setup', 'all'])
    # Test created object of type AdHocCLI
    assert isinstance(adhoc, AdHocCLI)
    # Test proper execution of option parsing code in AdHocCLI with base class
    assert isinstance(adhoc.parser, optparse.OptionParser)
    assert adhoc.parser.has_option('-m')
    assert adhoc.parser.has_option('--module-name')
    assert adhoc.parser.has_option('-a')
    assert adhoc.parser.has_option('--args')

# Generated at 2022-06-22 18:40:47.564449
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test verbose
    cli = AdHocCLI([])
    cli.post_process_args(namespace(verbosity=4))
    assert display.verbosity == 4

    # Test listhosts
    cli = AdHocCLI([])
    cli.post_process_args(namespace(listhosts=True))
    assert context.CLIARGS['listhosts']

    # Test subset
    cli = AdHocCLI([])
    cli.post_process_args(namespace(subset='all'))
    assert context.CLIARGS['subset'] == 'all'

    # Test tree
    cli = AdHocCLI([])
    cli.post_process_args(namespace(tree='path'))

# Generated at 2022-06-22 18:40:49.572364
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()

# Generated at 2022-06-22 18:40:57.551292
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Call the method
    cli = AdHocCLI()
    cli.init_parser()

    # Check if the method has the correct attributes set to it
    assert cli.parser.usage == '%prog <host-pattern> [options]'
    assert cli.parser.prog == 'ansible'
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-22 18:41:04.939366
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    a = AdHocCLI([])
    assert a.parser is not None

# Generated at 2022-06-22 18:41:15.506308
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Unit test for method run of class AdHocCLI"""
    # Since AdHocCLI is a subclass of CLI, CLI.run will be tested first.
    # AdHocCLI.run is more complicated than the parent class, so it is tested here.
    # It is difficult to write a unit test for AdHocCLI.run, since it involves
    # Ansible internal modules such as inventory, variable_manager, etc.
    # The test is to make sure that the method does not raise an exception.
    adhoc_cli = AdHocCLI()
    display.verbosity = 3

# Generated at 2022-06-22 18:41:26.152323
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Test for validating
    def test_no_deprecation(args, expectation):
        # check the deprecation isn't raised
        cli = AdHocCLI(args)
        result = cli.post_process_args(cli.parser.parse_args(args))
        assert result == expectation
        # check no deprecation warning was raised
        display.verbosity = 2
        display._deprecations = {}
        result = cli.post_process_args(cli.parser.parse_args(args))
        assert display._deprecations == {}

    # Test for validating and warning
    def test_deprecation(args, expectation):
        # check the deprecation is raised
        cli = AdHocCLI(args)

# Generated at 2022-06-22 18:41:36.928861
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class TestAdHocCLI(AdHocCLI):
        def post_process_args(self, options):
            return options

    cli = TestAdHocCLI()
    cli.parse()

    cli.options.verbosity = 3
    cli.options.module_name = 'ping'
    cli.options.module_args = ''
    cli.options.listhosts = True
    cli.options.listtasks = True
    cli.options.listtags = True

    options = cli.post_process_args(cli.options)

    assert options.verbosity == 3
    assert options.module_name == 'ping'
    assert options.module_args == ''
    assert options.listhosts is True
    assert options.listtasks is True

# Generated at 2022-06-22 18:41:49.108539
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    parser = cli.init_parser()
    # get basic objects
    loader, inventory, variable_manager = cli._play_prereqs()
    # get list of hosts to execute against
    pattern = 'test'
    try:
        hosts = cli.get_host_list(inventory, context.CLIARGS['subset'], pattern)
    except AnsibleError:
        if context.CLIARGS['subset']:
            raise
        else:
            hosts = []
            display.warning("No hosts matched, nothing to do")
    # construct playbook objects to wrap task
    play_ds = cli._play_ds(pattern, context.CLIARGS['seconds'], context.CLIARGS['poll_interval'])

# Generated at 2022-06-22 18:41:53.902665
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test execute module with option module_name given
    # TODO: need to fix this test
    # remove this if once above todo is fixed
    # pylint: disable=unreachable
    ad_hoc = AdHocCLI(['-m', 'setup', 'all'])
    ad_hoc.post_process_args()
    ad_hoc.run()

# Generated at 2022-06-22 18:41:59.667352
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    bash_parser = AdHocCLI.init_parser(AdHocCLI, ['-a', 'ping'])
    assert bash_parser.prog == 'ansible'
    assert bash_parser.usage == '%(prog)s <host-pattern> [options]'
    assert bash_parser.description == 'Define and run a single task \'playbook\' against a set of hosts'
    assert bash_parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-22 18:42:09.009868
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: remove these imports and provide a mock object
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-22 18:42:16.993039
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    def test(test_options, expected_options, expected_exception=None):
        # Ensure the object is created with an argv list containing only a single element 'AdHocCLI' so
        # the test is not affected by the current working directory.
        cli = AdHocCLI(['AdHocCLI'])
        cli.options = test_options

        if expected_exception:
            with pytest.raises(expected_exception):
                cli.post_process_args(test_options)
        else:
            result_options = cli.post_process_args(test_options)

        assert result_options == expected_options


# Generated at 2022-06-22 18:42:18.871913
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
  adhoc = AdHocCLI(args=[])
  assert adhoc.__class__.__name__ == 'AdHocCLI'

# Generated at 2022-06-22 18:42:22.971950
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()
    # Set debug to True
    adhoc_cli.debug = True
    # Set verbosity to 4
    adhoc_cli.verbosity = 4
    # Set diff to True
    adhoc_cli.diff = True
    # Try to run the method
    result = adhoc_cli.run()
    # Check if the result is correct
    assert result == -1
    # Unit test passed

# Generated at 2022-06-22 18:42:26.028193
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    assert (isinstance(parser, CLI.parser_cli))


# Generated at 2022-06-22 18:42:29.603508
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.module_name == 'command'
    assert adhoc.module_args == ''

# Generated at 2022-06-22 18:42:33.411279
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    adhoc.post_process_args({})
    result = adhoc.run()
    return result
    #assert result == 0

# Generated at 2022-06-22 18:42:36.336871
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Execute the class for testing
if __name__ == '__main__':
    AdHocCLI()

# Generated at 2022-06-22 18:42:38.761519
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    ad_hoc = AdHocCLI()
    ad_hoc.run()
    """
    pass


# Generated at 2022-06-22 18:42:39.381217
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:42:48.474418
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert len(cli.parser._actions) == 38
    assert cli.parser._actions[1].option_strings[0] == '-a'
    assert cli.parser._actions[2].option_strings[0] == '-m'
    assert cli.parser._actions[3].dest == 'inventory'
    assert cli.parser._actions[4].option_strings[0] == '-b'
    assert cli.parser._actions[4].option_strings[1] == '--become'
    assert cli.parser._actions[4].type == bool
    assert cli.parser._actions[4].default is None
    assert cli.parser._actions[4].choices is None

# Generated at 2022-06-22 18:42:58.211285
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' # Unit test for method run of class AdHocCLI '''

    # fetch all command line arguments
    parser = CLI.base_parser(
        usage="%prog <host-pattern> [options]",
        desc="Runs commands on remote hosts",
        epilog="use -h for more detailed options")

    # initialize parser with basic options
    CLI.add_base_options(parser)

    # adding options to parser
    parser.add_argument('-a', '--args', dest='module_args',
                        help="The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'",
                        default=C.DEFAULT_MODULE_ARGS)

# Generated at 2022-06-22 18:43:00.182127
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()
    assert a is not None


# Generated at 2022-06-22 18:43:00.804969
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:43:02.820109
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert cli
    assert cli.init_parser()

# Generated at 2022-06-22 18:43:13.216194
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create instance of AdHocCLI
    cli = AdHocCLI()

    # create an options parser for bin/ansible cli
    parser = cli.create_parser()

    # create test options for adhoc cli
    options = parser.parse_args([])
    # set some attributes of options for unit test
    options.ask_vault_pass = True
    options.become = True
    options.become_method = 'su'
    options.become_user = 'test'
    options.check = True
    options.listhosts = True
    options.module_name = 'ping'
    options.user = 'test'

    # post process options
    opts = cli.post_process_args(options)

    # validate ask_vault_pass
    assert opts.ask

# Generated at 2022-06-22 18:43:21.788539
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Testing method post_process_args of Ansible AdHocCLI.
    """
    cls = AdHocCLI()
    cls.base_parser = opt_help.create_base_parser(
        runas_opts=True,
        output_opts=True,
        connect_opts=True,
        check_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        basedir_opts=True,
        subset_opts=True
    )
    cls.init_parser()

# Generated at 2022-06-22 18:43:26.752318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # fake 'pwd' on our path
    # then just execute normal bin/ansible (which will return 1 by default)
    import __main__

    __main__.__file__ = 'bin/ansible'
    __main__.__package__ = None

    # noinspection PyTypeChecker
    AdHocCLI().parse()

# Generated at 2022-06-22 18:43:36.961197
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class FakeCLI(AdHocCLI):
        def __init__(self):
            pass

        def get_host_list(self, inventory, subset, pattern):
            if subset:
                return [subset]
            else:
                return []

        def ask_passwords(self):
            return (None, None)

        def _play_prereqs(self):
            # pylint: disable=unused-argument
            return (None, None, None)

    module = 'shell'
    module_args = 'ls'
    hosts = 'localhost'

    options = dict(
        module='shell',
        module_name=module,
        module_args=module_args,
        args=hosts
    )
    adhoc = FakeCLI()
    adhoc.options = options
    adh

# Generated at 2022-06-22 18:43:38.498763
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhocCLI = AdHocCLI()
    adhocCLI.init_parser()



# Generated at 2022-06-22 18:43:44.942594
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test when no additional arg given
    cli = AdHocCLI(args=[])
    assert cli.parser._actions[2].default == 'ping'
    assert cli.parser._actions[3].default == ''
    assert cli.parser._actions[4].default == C.DEFAULT_MODULE_ARGS
    assert cli.parser._actions[5].default == C.DEFAULT_MODULE_NAME
    assert cli.parser._actions[6].default == 'all'
    assert cli.parser._actions[7].const == 'none'
    assert cli.parser._actions[7].default == False
    assert cli.parser._actions[8].default == False
    assert cli.parser._actions[9].default == C.DEFAULT_FORKS
    assert cli.parser._actions[10].const

# Generated at 2022-06-22 18:43:48.165422
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.description == "Ad-hoc module execution"
    assert cli.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-22 18:43:50.867682
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['--hosts', 'localhost', '-m', 'ping'])
    assert isinstance(cli._tqm, TaskQueueManager) is False

# Generated at 2022-06-22 18:44:01.974578
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Prepare args
    options = opt_help.parse(['-a', '"opt1=val1', 'opt2=val2"', '-m', 'shell', '-b', 'localhost'])
    args = AdHocCLI(options)
    options = args.post_process_args(options)

    # Perform test
    assert isinstance(options.module_name, str)
    assert options.module_name == "shell"
    assert isinstance(options.module_args, str)
    assert options.module_args == '"opt1=val1 opt2=val2"'
    assert isinstance(options.become_user, str)
    assert options.become_user == "root"
    assert isinstance(options.args, str)
    assert options.args == "localhost"

# Generated at 2022-06-22 18:44:05.416541
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_obj = AdHocCLI()
    assert adhoc_obj is not None


# Generated at 2022-06-22 18:44:14.193435
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['-a', 'ls /'])
    assert cli.parser._actions[-2].dest == 'module_args'
    assert cli.parser._actions[-2].metavar == 'pattern'
    assert cli.parser._actions[-2].help == '[options]'
    assert cli.parser._actions[-2].nargs == '?'
    assert cli.parser._actions[-1].dest == 'args'
    assert cli.parser._actions[-1].metavar == 'pattern'
    assert cli.parser._actions[-1].help == 'host pattern'
    assert cli.parser._actions[-1].nargs == 1

# Generated at 2022-06-22 18:44:20.785006
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    module_name = 'shell'
    module_args = "echo ok"
    args = ['foo', '-m', module_name, '-a', module_args]
    cli_args = AdHocCLI(args).parse()
    assert cli_args['module_name'] == module_name
    assert cli_args['module_args'] == module_args
    assert cli_args['args'] == 'foo'
    assert cli_args['subset'] == ''



# Generated at 2022-06-22 18:44:24.764972
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser._prog == "ansible-adhoc"
    assert adhoc_cli.parser._usage == '%prog <host-pattern> [options]'
    assert adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc_cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-22 18:44:36.567046
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test that non-action options are ignored.
    options = {
        'verbosity': 1,
        'check': True,
        'module_path': 'test_path'
    }

    adhoc_cli = AdHocCLI()
    adhoc_cli.post_process_args(options)

    assert adhoc_cli.options.verbosity == 1
    assert adhoc_cli.options.check is True
    assert adhoc_cli.options.module_path == 'test_path'

    # Test that action options are not ignored.
    options = {
        'module_path': 'test_path',
        'module_name': 'test_name',
        'module_args': 'test_args',
        'args': 'test_hosts'
    }


# Generated at 2022-06-22 18:44:43.772241
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = opt_help.create_default_options_parser().parse_args([])
    cli = AdHocCLI(args)

    # Check that the method runs without error given valid arguments
    cli.post_process_args(opt_help.create_default_options_parser().parse_args(["pattern", "--verbose", "-T", "30"]))

    # Check that the method returns False when --listhosts is specified
    assert cli.post_process_args(opt_help.create_default_options_parser().parse_args(["pattern", "--listhosts"])) is False

    # Check that the method raises AnsibleOptionsError when --ask-pass is specified without --forks equal to 1

# Generated at 2022-06-22 18:44:53.197642
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-vvvv', '-m', 'shell', 'all', '-a', '"whoami"', '-e', '"ansible_become_method=sudo"', '-b', '-k', '-K']

    (options, args) = CLI.parse(args, runas_opts=True, vault_opts=True)
    options = AdHocCLI.post_process_args(options)

    assert options.verbosity == 4
    assert options.become == True
    assert options.ask_become_pass == True
    assert options.ask_vault_pass == True
    assert options.module_name == 'shell'
    assert options.module_args == '"whoami"'
    assert options.extra_vars == '"ansible_become_method=sudo"'

# Generated at 2022-06-22 18:45:05.508869
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test variables
    pattern = 'all'
    async_val = None
    poll = None
    check_raw = True
    mytask = {'action': {'module': 'ping', 'args': {'data': 'testdata'}}, 'timeout': 10}
    play_ds = {'name': 'Ansible Ad-Hoc', 'hosts': 'all'}

    # mock all objects used in method run
    adhoccli = AdHocCLI()
    adhoccli.ask_passwords = MagicMock()
    adhoccli._play_prereqs = MagicMock()
    adhoccli.get_host_list = MagicMock(return_value='all')
    adhoccli._play_ds = MagicMock(return_value=play_ds)
    adhoccli

# Generated at 2022-06-22 18:45:09.637010
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit test for constructor of class AdHocCLI'''
    ad_hoc_cli = AdHocCLI('bin/ansible')
    assert ad_hoc_cli

# Generated at 2022-06-22 18:45:20.521824
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Verify that exceptions are thrown with proper messages
    cli = AdHocCLI()
    cli.parser = Parser()
    cli.options = Mock()
    cli.options.module_paths = ['']

    # module_name == 'setup'
    cli.options.module_name = 'setup'
    cli.options.inventory = None
    cli.options.module_path = None
    cli.options.forks = 1
    cli.options.listhosts = None
    cli.options.listtasks = None
    cli.options.listtags = None
    cli.options.syntax = None
    cli.options.step = None
    cli.options.start_at_task = None
    cli.options.verbosity = 0
    cli.options

# Generated at 2022-06-22 18:45:28.375441
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Construct test string to provide as input
    test_str = 'ansible --args "a=b c=d" all'
    # Call post_process_args with the test string
    (options, args) = AdHocCLI(['ansible-playbook', '--args', 'a=b c=d'])


if __name__ == '__main__':
    cli = AdHocCLI(['ansible-playbook', '--args', 'a=b c=d'])
    test_AdHocCLI_post_process_args()

# Generated at 2022-06-22 18:45:30.625178
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    assert AdHocCLI.init_parser(AdHocCLI) is not None


# Generated at 2022-06-22 18:45:41.784854
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create instance of AdHocCLI with mocked super class
    class MockSuper(object):
        def __init__(self):
            self.ask_passwords = lambda: (None, None)
    cli = AdHocCLI(MockSuper())

    # Use CLIARGS as global object
    global context
    context = cli.get_opt_parser()
    args = []
    try:
        # Reparse options, initialize necessary objects.
        cli.parse(args)
    except SystemExit:
        pass

    # Set CLIARGS to these values

# Generated at 2022-06-22 18:45:46.098772
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['localhost,', '-m', 'ping'])
    assert adhoc

if __name__ == "__main__":
    adhoc = AdHocCLI(args=['localhost,', '-m', 'ping'])
    adhoc.parse()
    adhoc.run()

# Generated at 2022-06-22 18:45:56.699480
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import sys
    import os
    import StringIO
    import shutil

    from ansible.utils.display import Display

    from ansible.cli.adhoc import AdHocCLI

    display = Display()
    adhoc = AdHocCLI(args=['all', '-i', 'tests/ansible_hosts', '-m', 'ping', '-o'])

    # Configuration is done in the configuration file,
    # not on the command line
    assert adhoc.options.ask_pass == False

    # The default becomes
    assert adhoc.options.become == True

    # The default check mode
    assert adhoc.options.check == False

    # No vault password
    assert adhoc.options.vault_password_file == None

    # The default output file
    assert adhoc

# Generated at 2022-06-22 18:46:00.370457
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert cli.parser.prog == "ansible"
    assert cli.parser.usage == '%prog <host-pattern> [options]'

# Generated at 2022-06-22 18:46:07.581768
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''
    # Creating AdHocCLI() object
    adhoc_cli = AdHocCLI(args=['-m', 'setup', '-a', 'filter=ansible_distribution_version'])
    # Calling method run of class AdHocCLI
    result = adhoc_cli.run()
    assert isinstance(result, int) and result == 0

# Generated at 2022-06-22 18:46:13.810972
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Run a test to ensure that the AdHocCLI post_process_args method catches
    invalid input and throws AnsibleOptionsError.
    '''

    args = ['-k', '-k', '-a', 'ls']
    try:
        AdHocCLI(args).post_process_args(options)
    except AnsibleOptionsError:
        pass
    else:
        assert False, 'AdHocCLI failed to catch invalid input.'



# Generated at 2022-06-22 18:46:23.702070
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # For test we use AdHocCLI, which is subclass of object
    test_object = AdHocCLI(['--diff', '-f', '1'])

    # Test if validate_conflicts function called
    # And list of options as parameter
    def validate_conflicts(options, runas_opts=False, vault_opts=False, fork_opts=False):
        return True

    # Test if get_host_list function called
    # And list of options as parameter
    def get_host_list(inventory, subset, pattern):
        return True

    def run(self):
        return True

    # Mock method assert_called_with with test parameter

# Generated at 2022-06-22 18:46:24.490841
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    pass

# Generated at 2022-06-22 18:46:30.718077
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # input data
    data = dict(
        module_name='ping',
        module_args='',
        # debug=False,
    )
    # create an object of AdHocCLI
    obj = AdHocCLI()
    # run the method under test
    with pytest.raises(AnsibleOptionsError) as err:
        obj.run()
    assert err.value.message == 'No host targets given (want: -i inventory RESULT | -i inventory --list)'

# Generated at 2022-06-22 18:46:41.206174
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli_args = {
        'connection': 'smart',
        'forks': 1,
        'inventory': '/etc/ansible/hosts',
        'module_name': 'shell',
        'module_args': 'echo hello',
        'private_key_file': '/root/.ssh/foo.pem',
        'ssh_common_args': '-C -o ControlMaster=auto -o ControlPersist=60s',
        'ssh_extra_args': '-vv',
        'subset': ':all',
        'timeout': 10,
        'verbosity': 0,
    }

# Generated at 2022-06-22 18:46:42.447123
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()


# Generated at 2022-06-22 18:46:54.583810
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Create test object
    adhoc_obj = AdHocCLI()
    # Create a mock object for optparse.OptionParser
    mock_optparse = create_autospec(optparse.OptionParser)
    # Create a mock object for opt_help.add_vault_options
    mock_opt_help = create_autospec(opt_help)
    mock_opt_help.add_vault_options = Mock()
    # Create a mock object for opt_help.add_fork_options
    mock_opt_help = create_autospec(opt_help)
    mock_opt_help.add_fork_options = Mock()
    # Create a mock object for opt_help.add_module_options
    mock_opt_help = create_autospec(opt_help)
    mock_opt_help.add

# Generated at 2022-06-22 18:46:58.419164
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad = AdHocCLI(['localhost', '-m', 'ping'])
    # set verbose to True to show facts in logging output
    ad.verbose = True
    # set connection as local to avoid SSH error
    ad.connection = 'local'
    ad.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-22 18:46:59.512387
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert cli.parser is not None



# Generated at 2022-06-22 18:47:05.106436
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    args = ['-vvvv','localhost', '-m','ping','--args','data=instart']
    adhoc_cli = AdHocCLI(args)
    adhoc_cli.parse()
    opts = adhoc_cli.post_process_args(adhoc_cli.options)
    adhoc_cli.run()

# Generated at 2022-06-22 18:47:05.818361
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-22 18:47:16.775313
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # instantiate a cli object
    cli = AdHocCLI()

    # instantiate an option parser object
    parser = cli.init_parser()

    # ensure action is an ad-hoc command
    assert parser.prog == 'ansible'
    assert parser.usage == '%prog <host-pattern> [options]'
    assert parser.description.startswith('Define and run a single task \'playbook\' against a set of hosts')
    assert parser.epilog.startswith('Some actions do not make sense in Ad-Hoc (include, meta, etc)')

    # ensure add_runas_options has been called
    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_output_options(parser)


# Generated at 2022-06-22 18:47:18.127324
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # TODO: implementation
    pass


# Generated at 2022-06-22 18:47:28.041739
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.options = dict()
    ad_hoc_cli.options['module_name'] = 'shell'
    ad_hoc_cli.options['module_args'] = 'ls -s'
    ad_hoc_cli.options['forks'] = 20
    print(ad_hoc_cli.run())

    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.options = dict()
    ad_hoc_cli.options['module_name'] = 'shell'
    ad_hoc_cli.options['module_args'] = 'ls -s'
    ad_hoc_cli.options['forks'] = 20
    ad_hoc_cli.options['listhosts'] = True
   

# Generated at 2022-06-22 18:47:40.666290
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """Test constructor of AdHocCLI"""
    adhoc = AdHocCLI()
    assert isinstance(adhoc._display, Display)
    assert adhoc._display.verbosity == 0
    # test parser
    assert isinstance(adhoc._parser, dict)
    assert 'usage' in adhoc._parser
    assert 'desc' in adhoc._parser
    assert 'epilog' in adhoc._parser
    assert 'prog' in adhoc._parser['usage']
    assert 'args' in adhoc._parser['usage']
    assert 'options' in adhoc._parser
    assert 'argument' in adhoc._parser['options'][1]
    assert 'argument' in adhoc._parser['options'][2]

# Generated at 2022-06-22 18:47:44.799666
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    assert isinstance(ad_hoc_cli, AdHocCLI)
    assert isinstance(ad_hoc_cli, CLI)
    assert ad_hoc_cli._tqm is None

# Generated at 2022-06-22 18:47:50.290586
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # set up test environment
    import argparse
    adhoccli = AdHocCLI()

    # set up parser
    parser = adhoccli.init_parser()

    # check if parser is an argparse.ArgumentParser object
    assert isinstance(parser, argparse.ArgumentParser)


# Generated at 2022-06-22 18:47:51.633089
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-22 18:47:53.796177
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc

# Generated at 2022-06-22 18:48:04.026905
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['-i', '127.0.0.1,', 'all', '-m', 'shell', '-a', 'who'])
    assert cli.options.inventory == '127.0.0.1,'
    assert cli.options.module_name == 'shell'
    assert cli.options.module_args == 'who'
    assert cli.options.listhosts == False
    assert cli.options.subset == None
    assert cli.options.forks == 5
    assert cli.options.timeout == 10
    assert cli.options.remote_user == 'root'
    assert cli.options.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert cli.options.ssh_common_args == ''
    assert cl

# Generated at 2022-06-22 18:48:05.454409
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-22 18:48:06.868318
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
  plugin = AdHocCLI([])
  assert plugin.parser is not None


# Generated at 2022-06-22 18:48:10.612686
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import sys
    import doctest
    import ansible.cli.adhoc
    results = doctest.testmod(ansible.cli.adhoc)
    if results.failed:
        sys.exit(1)

# Generated at 2022-06-22 18:48:12.823065
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli != None

# Generated at 2022-06-22 18:48:13.550622
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-22 18:48:16.328876
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Test for the AdHocCLI class constructor.
    '''
    ad_hoc_cli = AdHocCLI()
    assert ad_hoc_cli

# Generated at 2022-06-22 18:48:21.649218
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test run of class AdHocCLI.

    :return:
    """
    # Create object of class AdHocCLI
    ad_hoc_cli_class = AdHocCLI(args=['-m', 'setup', '-a', 'filter=ansible_distribution*'])

    # Set password for test
    ad_hoc_cli_class.password = "PassW0rd"

    # Run method run
    ad_hoc_cli_class.run()



# Generated at 2022-06-22 18:48:30.977684
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=['-m', 'ping'])
