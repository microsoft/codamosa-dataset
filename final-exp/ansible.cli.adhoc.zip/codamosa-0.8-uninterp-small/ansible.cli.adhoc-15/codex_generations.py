

# Generated at 2022-06-24 17:33:42.500287
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = -117.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_1 = AdHocCLI(float_0)


# Generated at 2022-06-24 17:33:46.151228
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = -5.5
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)


# Generated at 2022-06-24 17:33:51.909795
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    global task_queue_manager_0
    # Initialization
    class1 = AdHocCLI
    arg0 = "arg0"
    # Execution
    ret0 = class1.run(arg0)
    # Validation
    assert ret0 == 0


# Generated at 2022-06-24 17:33:54.113157
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -117.0

    # Test with "test_case_0"
    test_case_0()

# Generated at 2022-06-24 17:34:05.990416
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -117.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    infeasible_constraint_0 = context.CLIARGS['module_name'] in C.MODULE_REQUIRE_ARGS
    # setup loader, inventory, etc
    # get list of hosts to execute against
    # just listing hosts?
    if context.CLIARGS['listhosts']:
        return
    # verify we have arguments if we know we need em
    if infeasible_constraint_0 and not context.CLIARGS['module_args']:
        if pattern.endswith(".yml"):
            err = err + ' (did you mean to run ansible-playbook?)'
        raise AnsibleOptionsError(err)
    # Avoid

# Generated at 2022-06-24 17:34:09.817750
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # create an instance of AdHocCLI and test run method
    ad_hoc_c_l_i_0 = AdHocCLI(None, None, None)
    test_case_0()


# Generated at 2022-06-24 17:34:16.476872
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -117.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:21.673374
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -117.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()

    assert ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:24.195298
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Testing case #0")
    test_case_0()

print("Testing python module:\tansible.cli.adhoc")
test_AdHocCLI()
print("Finished python module:\tansible.cli.adhoc")

# Generated at 2022-06-24 17:34:26.903510
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -117.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:36.376918
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = list()
    args.append('ansible')
    opts = { }
    opts['module_name'] = 'default_module'
    context.CLIARGS = opts
    a = AdHocCLI(args)
    return a.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:37.084777
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-24 17:34:38.109150
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:34:49.117161
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass_0 = 'Argument 1'

    args_0 = []
    args_0.append(pass_0)
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('')
    args_0.append('--ask-pass')
    args_0.append('--ask-become-pass')
    args_0.append('--ask-vault-pass')
    args_0.append('')
    args_0.append('')

    context.CLIARGS = {}

# Generated at 2022-06-24 17:34:55.960622
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Initialize the class and check if all the attributes are initialized correctly or not.
    cli = AdHocCLI()
    assert cli.subcommand == 'adhoc', "Expected subcommand to be 'adhoc' but found {0}".format(cli.subcommand)

test_case_0()
test_AdHocCLI()

# Generated at 2022-06-24 17:35:01.052169
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'arg1'
    # Create an instance of AdHocCLI
    ahc = AdHocCLI(args=['arg2', 'arg3', 'arg4'], display=display)
    # Test method run of class AdHocCLI
    assert ahc.run() == 0


# Generated at 2022-06-24 17:35:03.686889
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Init object
    adHocCLI = AdHocCLI()


# Generated at 2022-06-24 17:35:06.029984
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    result = AdHocCLI()
    assert(result is not None), 'Unable to create instance of AdHocCLI'


# Generated at 2022-06-24 17:35:12.438659
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cmd = 'ansible host -m service -a "name=httpd state=restarted" -i inventory'
    arrs = cmd.split(' ')
    argv = ['ansible']
    for item in arrs:
        argv.append(item)
    adhoc = AdHocCLI(argv, cmd)

    print("before calling run")
    adhoc.parse()
    adhoc.run()
    print("after calling run")

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:15.670526
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("[+] Unit test for AdHocCLI")
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:27.242646
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:36.310107
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(ad_hoc_c_l_i_0.options)
    result = ad_hoc_c_l_i_0.run()
    assert result is None, 'Expected None, but got %s' % (result,)

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:40.145829
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)


# Generated at 2022-06-24 17:35:47.948234
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_1 = False
    ad_hoc_c_l_i_0.callback = bool_1
    bool_2 = False
    context.CLIARGS['tree'] = bool_2
    bool_3 = True
    context.CLIARGS['listhosts'] = bool_3
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:57.482057
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    s_0 = "stdout"
    s_1 = "minimal"
    list_0 = ["bin_ansible_callbacks"]
    list_1 = ["tree"]
    dict_0 = dict()
    dict_0["stdout_callback"] = s_1
    dict_0["default_stdout_callback"] = s_0
    dict_0["enable_plugins"] = list_0
    dict_0["tree"] = list_1
    dict_0["pidfile"] = s_0
    dict_0["background"] = 0
    dict_0["connection"] = s_0
    dict_0["check"] = False
    dict_0["help"] = False
    dict_0["inventory"] = s_0
    dict_0["module_path"] = s_0

# Generated at 2022-06-24 17:36:00.603423
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert True


# Generated at 2022-06-24 17:36:05.924290
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0._tqm = TaskQueueManager()
    var_0 = ad_hoc_c_l_i_0._tqm.run(None)
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:07.436108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:36:13.638272
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    # Create an AdHocCLI object
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    
    # Run the method under test
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:19.828740
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_1 = []
    ad_hoc_c_l_i_1 = AdHocCLI(args_1)
    var_1 = ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:38.389509
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args()

    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:43.318897
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        params = ["ansible", "all", "-m", "ping"]
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        ad_hoc_c_l_i_0.parse(params)
        ad_hoc_c_l_i_0.run()
    except:
        raise

# Generated at 2022-06-24 17:36:49.499346
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # the following test is failing due to the fact that it is trying to
    # import ansible.plugins.loader.vault_loader while running the unit
    # test.
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:52.112036
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:55.388932
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_1 = True
    ad_hoc_c_l_i_1 = AdHocCLI(bool_1)
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:58.054889
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_var_0 = True
    ad_hoc_c_l_i_var_0 = AdHocCLI(bool_var_0)
    var_var_0 = ad_hoc_c_l_i_var_0.run()
    assert var_var_0 == False


# Generated at 2022-06-24 17:37:04.695887
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    bool_1 = bool_0
    ad_hoc_c_l_i_0 = AdHocCLI(bool_1)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:06.993054
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)


# Generated at 2022-06-24 17:37:14.400131
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test for method run of class AdHocCLI
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    test_case_0()
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:17.293463
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    
    # Instantiate an arbitrary AdHocCLI
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:37:43.087294
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test case with good parameters
    # Test case with good parameters
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()
    # Test case with bad parameters


# Generated at 2022-06-24 17:37:54.436474
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:38:00.424468
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:05.330600
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()


if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:12.339094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(False)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:20.852738
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    with open('tests/ansible-test-inventory.ini', 'r') as inventory:
        inv_test = inventory.read()
    ad_hoc_c_l_i_1 = AdHocCLI()
    inventory = ad_hoc_c_l_i_1.get_host_list(inv_test, 1, ['all'])
    assert inventory == ['192.168.225.2'], 'Hosts should be in group'


# Generated at 2022-06-24 17:38:25.772811
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    with pytest.raises(AssertionError):
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        var_0 = ad_hoc_c_l_i_0.init_parser()


# Generated at 2022-06-24 17:38:33.393876
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(bool_0)
    ad_hoc_c_l_i_0.ask_passwords()
    C.TREE_DIR = None
    ad_hoc_c_l_i_0.run()
    C.TREE_DIR = None
    ad_hoc_c_l_i_0.run()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:38.022534
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    int_0 = ad_hoc_c_l_i_0.run()
    assert int_0 == 0

# Generated at 2022-06-24 17:38:43.666236
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Basic test
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert ad_hoc_c_l_i_0.run() == None


# Generated at 2022-06-24 17:39:41.900685
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:47.547745
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        var_0 = ad_hoc_c_l_i_0.run()
    except Exception as err_0:
        print("Exception in testcase0")
        print(str(err_0))
        assert False


# Generated at 2022-06-24 17:39:52.247269
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:55.747821
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    int_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:58.576700
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:09.176418
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_1 = ad_hoc_c_l_i_0.init_parser()
    var_2 = ad_hoc_c_l_i_0.run()
    var_3 = None
    assert var_3 != var_1
    assert var_3 != var_2
    assert var_1 != var_2

# Generated at 2022-06-24 17:40:13.951920
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:27.599617
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_1 = AdHocCLI.init_parser(ad_hoc_c_l_i_0)
    var_2 = AdHocCLI.post_process_args(ad_hoc_c_l_i_0)
    return_value = AdHocCLI.run(ad_hoc_c_l_i_0)
    return return_value

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:32.642389
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert isinstance(var_0, int)


# Generated at 2022-06-24 17:40:36.843752
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()
