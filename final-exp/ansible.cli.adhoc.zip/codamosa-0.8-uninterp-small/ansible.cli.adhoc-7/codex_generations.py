

# Generated at 2022-06-24 17:33:57.128141
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(b'-a')
    ad_hoc_c_l_i_0.run()
    assert True

# Generated at 2022-06-24 17:33:58.348768
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:01.736553
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert isinstance(ad_hoc_c_l_i_0.run(), int)

# Generated at 2022-06-24 17:34:03.286620
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Arrange
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)

    # Act
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:07.351140
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert ad_hoc_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:34:09.393422
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:34:13.962625
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:23.454994
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'+'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    exception_0 = AnsibleError()

# Generated at 2022-06-24 17:34:26.019266
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Assert that the AdHocCLI object is created correctly
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)

# Generated at 2022-06-24 17:34:31.598641
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit:
        pass



# Generated at 2022-06-24 17:34:53.349820
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    # action='store_true'
    # dest='listhosts'
    # short='L'
    # type='bool'
    # value=False
    context.CLIARGS['listhosts'] = True

# Generated at 2022-06-24 17:34:59.197644
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:09.305515
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Unit test for module run with tests for _play_prereqs, get_host_list, _play_ds, and finally run
    #
    #
    # Given no arguments
    bytes_0 = b''
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert ad_hoc_c_l_i_0.run() != 0
    # Given -m module
    bytes_1 = b'-m module0'
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)
    assert ad_hoc_c_l_i_1.run() != 0
    # Given host pattern
    bytes_2 = b'_host0'

# Generated at 2022-06-24 17:35:11.645489
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    bytes_1 = b'B'
    result = ad_hoc_c_l_i_0.run(bytes_1)

# Generated at 2022-06-24 17:35:13.488001
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)


# Generated at 2022-06-24 17:35:18.295592
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()
    ad_hoc_c_l_i_0 = AdHocCLI('ad-hoc')
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:21.355046
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initializing object that is used only for the test
    ad_hoc_c_l_i_0 = AdHocCLI(context.CLIARGS)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:22.758762
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI(b'B') != None


# Generated at 2022-06-24 17:35:33.099683
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert ad_hoc_c_l_i_0 != None
    if ad_hoc_c_l_i_0 != None:
        assert ad_hoc_c_l_i_0.p != None
        assert ad_hoc_c_l_i_0.options != None
        assert ad_hoc_c_l_i_0.args != None
        assert ad_hoc_c_l_i_0.parser != None


# Generated at 2022-06-24 17:35:40.984274
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    p_bytes_0 = b'S'
    ad_hoc_c_l_i_0 = AdHocCLI(p_bytes_0)
    ad_hoc_c_l_i_0.run()
    l_b_0 = context.CLIARGS['tree']
    l_b_1 = context.CLIARGS['poll_interval']
    l_b_2 = context.CLIARGS['seconds']
    # AdHocCLI.run()
    # assert that runtime of ad_hoc_c_l_i_0.run() < 0.1 seconds

# Generated at 2022-06-24 17:36:00.724267
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:04.906995
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
  # Make an instance of class AdHocCLI
  ad_hoc_c_l_i = AdHocCLI()

  # Add a test for the constructor
  assert ad_hoc_c_l_i, "Unable to instantiate AdHocCLI class"

  # Run unit tests associated with class AdHocCLI
  test_case_0()

# Generated at 2022-06-24 17:36:14.694401
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.parser.parse_args(namespace=context.CLIARGS)
    ad_hoc_c_l_i_0.post_process_args(context.CLIARGS)
    assert_equals(ad_hoc_c_l_i_0.run(), 0)

# Generated at 2022-06-24 17:36:20.570364
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:28.108355
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_3 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_3)
    ad_hoc_c_l_i_0.run()
    ad_hoc_c_l_i_0.run()
    assert ad_hoc_c_l_i_0 is not None

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:37.529895
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    display.verbosity = 3
    bytes_1 = b'B'
    ad_hoc_c_l_i_0.get_host_list(bytes_1, 'J', 'R')
    bytes_2 = b'B'
    bytes_3 = b'B'
    bytes_4 = b'B'
    bytes_5 = b'B'
    bytes_6 = b'B'
    bytes_7 = b'B'
    ad_hoc_c_l_i_0.ask_passwords(bytes_2, bytes_3, bytes_4, bytes_5, bytes_6, bytes_7)
    bytes_8 = b'B'
   

# Generated at 2022-06-24 17:36:40.944669
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(b'\x00')
    assert ad_hoc_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:36:44.571116
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI(b'B')
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)


# Generated at 2022-06-24 17:36:48.402576
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'B'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:58.361315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ ansible ad-hoc -m ping -a "data='hello world' name=config" localhost -v """
    command = "ping -a data='hello world' name=config"
    test_command(command)


# Generated at 2022-06-24 17:37:17.915132
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print('Test constructor')
    # ensure '-m' option is available
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i

# Generated at 2022-06-24 17:37:21.710712
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()



# Generated at 2022-06-24 17:37:23.946270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:27.050324
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        ad_hoc_c_l_i_0.run()
    except Exception:
        pass


# Generated at 2022-06-24 17:37:34.897152
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    playbook_file = '/home/kstreith/ansible-test-playbooks/lib/ansible/modules/cloud/azure/azure_rm.py'
    host_pattern = 'localhost'

    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.parse(['-m', playbook_file, '-a', 'subscription_id=123', host_pattern])
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:37:43.938582
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.run() is None

if __name__ == '__main__':
    # code for below can use print statements for testing
    # https://docs.python.org/2/library/unittest.html
    # https://docs.python.org/3/library/unittest.html#basic-example
    import platform
    if platform.python_implementation() == 'CPython':
        import cProfile
        cProfile.run('test_case_0()', 'restats')
        # python -m cProfile -s 'cumulative' ansible/cli/adhoc.py
        # pstats.Stats('restats').sort_stats('cumulative').print_stats(25)
       

# Generated at 2022-06-24 17:37:47.064108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i.run() is None

# Generated at 2022-06-24 17:37:48.835218
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()

    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:37:51.058411
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:37:53.671039
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()
    assert True == True


# Generated at 2022-06-24 17:38:34.149158
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:37.213380
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_run_0 = AdHocCLI()
    res = ad_hoc_c_l_i_run_0.run()
    assert res.exception is None

# Generated at 2022-06-24 17:38:39.469972
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.post_process_args()

# Generated at 2022-06-24 17:38:41.772072
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:38:46.458432
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    result = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:47.779178
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_object = AdHocCLI()
    assert test_object.run() is None


# Generated at 2022-06-24 17:38:50.141318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    with pytest.raises(AnsibleOptionsError) as excinfo:
        ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:38:54.676930
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test 0
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit:
        pass
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:38:57.049013
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:38:58.760818
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ansible_ad_hoc_cli = AdHocCLI()
    assert ansible_ad_hoc_cli

# Generated at 2022-06-24 17:40:33.062169
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    result = ad_hoc_c_l_i_0.run()
    assert result['dark'] == {}
    assert result['contacted'] == {}

# Generated at 2022-06-24 17:40:40.082496
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    ad_hoc_c_l_i = AdHocCLI()

    # Call method run of AdHocCLI
    ad_hoc_c_l_i.run()

if __name__ == "__main__":

    # test_case_0()

    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:52.272312
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    f = open('tests/test_adhoc/input_2.txt')
    i_p_a_d_h_o_c_c_l_i_0_0 = f.read()
    f.close()
    context.CLIARGS = parse_kv(i_p_a_d_h_o_c_c_l_i_0_0,check_raw=True)
    ad_hoc_c_l_i_0 = AdHocCLI()
    return_value = ad_hoc_c_l_i_0.run()
    f = open('tests/test_adhoc/output_2.txt')
    o_p_a_d_h_o_c_c_l_i_0_0 = f.read()
    f.close()

# Generated at 2022-06-24 17:40:56.789482
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.run() == 0


# Generated at 2022-06-24 17:41:05.798114
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ test_run_adhoc_cli_0() - create CLI object """
    ad_hoc_c_l_i_0 = AdHocCLI()

    # test class variable
    #print(ad_hoc_c_l_i_0.print_help)
    assert(ad_hoc_c_l_i_0.print_help == CLI.print_help)
    #print(ad_hoc_c_l_i_0.print_version)
    assert(ad_hoc_c_l_i_0.print_version == CLI.print_version)
    #print(ad_hoc_c_l_i_0.parser)
    #print(ad_hoc_c_l_i_0.subparser)
    #print(ad_hoc_c_l_i

# Generated at 2022-06-24 17:41:06.785782
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:41:18.386080
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()

    # We need to fake the arguments from argparse.
    # TODO: this should be changed when AdHocCLI class is
    # refactored to use a Command class like the others.
    # We should pass in fake args when executing the run method
    # via the Command class.

    context.CLIARGS = {}
    context.CLIARGS['pattern'] = 'test_host'
    context.CLIARGS['module_name'] = 'shell'
    context.CLIARGS['module_args'] = 'ping'

    assert ad_hoc_c_l_i_0.run() is not None

# Generated at 2022-06-24 17:41:20.521010
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:41:29.861122
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()
    ad_hoc_c_l_i_1.run()
    ad_hoc_c_l_i_2 = AdHocCLI()
    ad_hoc_c_l_i_2.run()
    ad_hoc_c_l_i_3 = AdHocCLI()
    ad_hoc_c_l_i_3.run()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:41:32.693439
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    print(ad_hoc_c_l_i_1.run())


if __name__ == "__main__":
    test_AdHocCLI_run()