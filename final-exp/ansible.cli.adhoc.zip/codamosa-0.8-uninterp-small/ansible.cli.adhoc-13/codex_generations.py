

# Generated at 2022-06-24 17:33:58.997775
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -4
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()
    int_0 = -4
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()
    int_0 = -4
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()
    int_0 = -4
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:02.329387
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        ad_hoc_c_l_i_0.run()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 17:34:07.588579
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -580
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    int_0 = 22
    ad_hoc_c_l_i_0.run()
    ad_hoc_c_l_i_0.post_process_args(int_0)


# Generated at 2022-06-24 17:34:10.331298
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test case with argument initialization to 576
    int = 576
    ad_hoc_c_l_i = AdHocCLI(int)


# Generated at 2022-06-24 17:34:14.908536
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("TESTING AdHocCLI")
    test_case_0()

# Generated at 2022-06-24 17:34:25.823011
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    opt_help.add_vault_options(AdHocCLI.init_parser)
    opt_help.add_check_options(AdHocCLI.init_parser)
    opt_help.add_async_options(AdHocCLI.init_parser)
    opt_help.add_runas_options(AdHocCLI.init_parser)
    opt_help.add_connect_options(AdHocCLI.init_parser)
    opt_help.add_runtask_options(AdHocCLI.init_parser)
    opt_help.add_output_options(AdHocCLI.init_parser)
    opt_help.add_fork_options(AdHocCLI.init_parser)

# Generated at 2022-06-24 17:34:30.368161
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = 809
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:35.059603
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    int_0 = 880
    ad_hoc_c_l_i_0.run(int_0)

# Generated at 2022-06-24 17:34:36.383068
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:38.112227
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test the class constructor
    test_case_0()


# Generated at 2022-06-24 17:34:49.212917
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    int_0 = -10968
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)


# Generated at 2022-06-24 17:34:51.854918
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
        return 0
    except:
        return 1

# Function for invoking unit test code

# Generated at 2022-06-24 17:34:58.253329
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(1)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:04.362904
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -218
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    # Test with missing arg 1
    with pytest.raises(TypeError):
        ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:07.063063
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(1)
    int_0 = ad_hoc_c_l_i_0.run()
    print(int_0)


# Generated at 2022-06-24 17:35:14.395290
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except NameError as e:
        print("NameError:", e)
    except TypeError as e:
        print("TypeError:", e)
    except SystemExit as e:
        print("SystemExit:", e)

    try:
        # __main__.ad_hoc_c_l_i_0.run()
        ad_hoc_c_l_i_0.run()
    except NameError as e:
        print("NameError:", e)
    except TypeError as e:
        print("TypeError:", e)
    except SystemExit as e:
        print("SystemExit:", e)
    except AnsibleError as e:
        print("AnsibleError:", e)

# Generated at 2022-06-24 17:35:17.887921
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -580
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)

    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:19.881560
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:24.393556
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create object
    ad_hoc_c_l_i_0 = AdHocCLI()
    # Verify that the object was created correctly
    assert ad_hoc_c_l_i_0 != None
    # Invoke tests for methods
    test_case_0()

# Invoke test for class AdHocCLI
test_AdHocCLI()

# Generated at 2022-06-24 17:35:36.315442
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = 0
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    pattern = "pattern"
    try:
        pattern = "pattern"
        context.CLIARGS['args'] = pattern
        context.CLIARGS['listhosts'] = True
        result = ad_hoc_c_l_i_0.run()
        assert result == 0
    except AnsibleError as e:
        print(e.message)

    try:
        pattern = "pattern"
        context.CLIARGS['args'] = pattern
        result = ad_hoc_c_l_i_0.run()
        assert result == 0
    except AnsibleError as e:
        print(e.message)


# Generated at 2022-06-24 17:35:48.961209
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create the instance of class AdHocCLI
    obj = AdHocCLI()

    # Expected value of run
    int_1 = 1

    # Call the function under test
    obj.run()

    # Compare expected and actual value
    assert int_1 == int_0

# Generated at 2022-06-24 17:35:51.736478
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert 1 == 1
    # Test case where self._tqm.run(play) fails, the following statement is an example
    # assert 1 == 0



# Generated at 2022-06-24 17:35:53.102748
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:00.279865
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    import os

    try:
        # Create ansible ad-hoc CLI instance
        ahcli = AdHocCLI(args=['test.example.org', '-m', 'ping'])
        # Call method run
        result = ahcli.run()
        # Check result
        assert result == 0
    except AnsibleError:
        # We don't really care if above fails since it will fail if we don't
        # have a keypair that works on the test server
        pass

    # Find the test inventory file
    invfile = os.path.join(os.path.dirname(__file__), 'inventory.yml')

    # Create ansible ad-hoc CLI instance
    ahcli = AdHocCLI(args=['test.example.org', '-i', invfile, '-m', 'ping'])



# Generated at 2022-06-24 17:36:07.822367
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:36:10.175856
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Instantiation of class AdHocCLI
    test_case_0()


# Generated at 2022-06-24 17:36:11.260819
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:36:18.820961
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = []
    AdHoc = AdHocCLI(args)
    AdHoc.run()

main = AdHocCLI

# Generated at 2022-06-24 17:36:23.981431
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    int_0 = 0

    try:
        int_0 = 0
        run_result = AdHocCLI().run()
    except Exception as exception:
        raise exception
    assert run_result == int_0

# Generated at 2022-06-24 17:36:24.587085
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = 0

# Generated at 2022-06-24 17:36:38.737710
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    for str_1 in 'y|u', 'w|h':
        try:
            test_case_0()
        except TypeError:
            assert False



# Generated at 2022-06-24 17:36:42.798689
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'P8'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'Q9'
    ad_hoc_c_l_i_0.run(str_1)


# Generated at 2022-06-24 17:36:46.539969
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:50.795278
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('5X')
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:55.913690
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = '1u'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Entry point for program
if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:36:57.343444
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-24 17:37:02.661874
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_1 = 'Tn'
    ad_hoc_c_l_i_0 = AdHocCLI(str_1)
    var_1 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:06.793790
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '8W'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:11.884563
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # AdHocCLI(version_info)
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    test_case_0()

# Generated at 2022-06-24 17:37:13.109267
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:37:29.491094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:37:36.357245
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'test'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Test TypeError exception
    try:
        ad_hoc_c_l_i_0.run('test')
    except TypeError:
        pass
    except Exception as ex:
        print(ex)
    # Test ValueError exception
    try:
        ad_hoc_c_l_i_0.run(str_0)
    except ValueError:
        pass
    except Exception as ex:
        print(ex)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:46.268762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '--help'
    str_1 = '-a'
    str_2 = 'ping'
    str_3 = 'all'
    str_4 = '-k'
    str_5 = 'sdfsdfs'
    str_6 = '-m'
    str_7 = 'ping'
    str_8 = '-u'
    str_9 = 'root'
    str_10 = '-v'
    str_11 = '2'
    list_0 = [str_1, str_2, str_0, str_3, str_4, str_5, str_6, str_7, str_8, str_9, str_10, str_11]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
   

# Generated at 2022-06-24 17:37:51.458301
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'w4'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    var_0
    output = 'None\n'
    assert var_0 == output


# Generated at 2022-06-24 17:37:54.266097
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_2 = 'O7'
    ad_hoc_c_l_i_2 = AdHocCLI(str_2)
    var_2 = ad_hoc_c_l_i_2.run()


# Generated at 2022-06-24 17:38:03.030270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# test func name
# test setup
# test teardown
# test function name
# test multiple tests
# test docstring
# test class
# test module

# Generated at 2022-06-24 17:38:06.102069
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:10.986626
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('Test function run of class AdHocCLI')
    print('---------------------------------------------------')
    test_case_0()



# Generated at 2022-06-24 17:38:14.053210
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except Exception as err:
        print(str(err))
        assert False



# Generated at 2022-06-24 17:38:20.733865
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()
    print ('unit_test_results:')
    print ('  test_AdHocCLI_run: SUCCESS')
    print ('\n')

test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:45.714348
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '-'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    return var_0


# Generated at 2022-06-24 17:38:47.396701
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert(str_0 == 'O7')


# Generated at 2022-06-24 17:38:49.251347
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'X7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:51.867796
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except Exception as e:
        print("exception:")
        print(e)

# Generated at 2022-06-24 17:38:54.726621
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except:
        import traceback
        tb = traceback.format_exc()
        print(tb)
        assert False

# Generated at 2022-06-24 17:38:56.783079
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Main function call
if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:38:59.239215
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:04.263436
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of class AdHocCLI
    str_0 = 'nJO'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Call method run of ad_hoc_c_l_i_0
    var_0 = ad_hoc_c_l_i_0.run()
    # Assert the return type of the method run is int
    assert type(var_0) == int
    # Assert the value of the return of method run is 0
    assert var_0 == 0

# Generated at 2022-06-24 17:39:06.347878
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:11.599057
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_b = '0@'
    ad_hoc_c_l_i_a = AdHocCLI(str_b)
    str_b = 't|'
    str_a = '7:'
    ad_hoc_c_l_i_a.post_process_args(str_b, str_a)
    str_b = 'Mx'
    str_a = 'f5'
    var_a = ad_hoc_c_l_i_a.run(str_b, str_a)


# Generated at 2022-06-24 17:39:36.662200
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:39:46.815751
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # First case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCLI(str)
    # Third case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCLI(str)
    # Fourth case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCLI(str)
    # Fifth case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCLI(str)
    # Sixth case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCLI(str)
    # Seventh case
    str = 'O7'
    ad_hoc_c_l_i = AdHocCL

# Generated at 2022-06-24 17:39:52.116062
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    str_0 = 'O7'
    var_0 = ad_hoc_c_l_i_0.run(str_0)


# Generated at 2022-06-24 17:39:54.477668
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:57.633563
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:07.486019
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    str_1 = 'T6'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0, str_1)
    var_0 = ad_hoc_c_l_i_0.run()

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:13.203041
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # 1. Create an instance of class AdHocCLI with argument O7
    # 2. Call method run
    # 3. Check return
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:21.745655
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('Sb')
    try:
        assert isinstance(ad_hoc_c_l_i_0.run(), int)
    except AssertionError:
        raise AssertionError('Expected AssertionError')
    try:
        assert isinstance(ad_hoc_c_l_i_0.run(), int)
    except AssertionError:
        raise AssertionError('Expected AssertionError')
    try:
        assert isinstance(ad_hoc_c_l_i_0.run(), int)
    except AssertionError:
        raise AssertionError('Expected AssertionError')

# Generated at 2022-06-24 17:40:24.963065
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'O8'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    print("\n")
    # print(ad_hoc_c_l_i_0)
    # print("\n")


# Generated at 2022-06-24 17:40:29.632412
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:53.936469
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    if (ad_hoc_c_l_i_0.run() != 0):
        raise RuntimeError


# Generated at 2022-06-24 17:41:04.109198
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 't'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.post_process_args(None)
    try:
        var_1 = ad_hoc_c_l_i_0.run()
    except Exception:
        raise
    else:
        print('I am here!')
        pass

# Generated at 2022-06-24 17:41:05.551408
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:41:18.420517
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('fh')
    var_0 = ad_hoc_c_l_i_0.run()
    if var_0 != 0:
        print('Failed')
        print('Expected:')
        print(0)
        print('Actual:')
        print(var_0)
        print()
    else:
        print('Passed')
    #
    ad_hoc_c_l_i_1 = AdHocCLI('fh')
    var_1 = ad_hoc_c_l_i_1.run()
    if var_1 != 0:
        print('Failed')
        print('Expected:')
        print(0)
        print('Actual:')
        print(var_1)

# Generated at 2022-06-24 17:41:22.198508
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:41:28.108362
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run() # Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:41:30.946404
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'B8'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:41:33.666495
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Test if the class AdHocCLI could be instantiated

# Generated at 2022-06-24 17:41:46.735125
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    str_1 = 'default'
    str_2 = 'O7'
    str_3 = 'default'
    str_4 = 'O7'
    dict_0 = dict(action=dict(module='O7'), timeout='O7')
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0._play_prereqs()
    var_0 = ad_hoc_c_l_i_0.get_host_list(str_1, str_2, str_3)
    var_1 = ad_hoc_c_l_i_0._play_ds(str_4, dict_0, dict_0)
    play_0 = Play()
    play_

# Generated at 2022-06-24 17:41:49.400523
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:42:21.145034
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'jz'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:42:26.482394
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_1 = 'O7'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    assert ad_hoc_c_l_i_1._tqm is None
    assert ad_hoc_c_l_i_1.callback is None


# Generated at 2022-06-24 17:42:31.045748
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'suite'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:42:33.042899
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

main = AdHocCLI

# Generated at 2022-06-24 17:42:38.482784
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


if __name__ == '__main__':
    import hypothesis
    import hypothesis.strategies as st
    import unit_tests.ansible_hypothesis.hypothesis_utils as h_utils
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--hypothesis", action="store_true",
                        help="run tests using hypothesis")
    args = parser.parse_args()

    if args.hypothesis:
        st_AdHocCLI = st.builds(
            AdHocCLI,
            st.text(),
        )

# Generated at 2022-06-24 17:42:48.531368
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'i'
    context.CLIARGS['module_name'] = str_1
    str_2 = 'n'
    context.CLIARGS['module_args'] = str_2
    str_3 = 'W'
    context.CLIARGS['poll_interval'] = str_3
    str_4 = 'O'
    context.CLIARGS['args'] = str_4
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:42:51.130764
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:43:00.786147
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:43:05.518517
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:43:09.542303
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'O7'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()