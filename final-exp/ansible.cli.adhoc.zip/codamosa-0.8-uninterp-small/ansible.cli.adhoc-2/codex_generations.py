

# Generated at 2022-06-24 17:33:43.744235
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('__adhoc_playbook__')
    assert ad_hoc_c_l_i_0.run() == 0

# Generated at 2022-06-24 17:33:56.025604
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test without callback
    str_0 = 'D^^O/~^'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0._run()
    # Test with callback
    str_0 = 'p<S@'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0._run()
    ad_hoc_c_l_i_0.callback = 'D^^O/~^'
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:01.451625
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('Testing method run of class AdHocCLI')
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:34:03.456098
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'L>`~p=e`<'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:08.450659
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'I/>)q8s&F}wK@FD^'
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    try:
        ad_hoc_c_l_i_1.run()
    except AnsibleOptionsError:
        # Test method run exception handling:
        # Test exception handling for 'if context.CLIARGS['module_name'] in C.MODULE_REQUIRE_ARGS and not context.CLIARGS['module_args']:'
        # Test exception handling for 'raise AnsibleOptionsError(err)'
        assert True
    else:
        assert False

# Generated at 2022-06-24 17:34:09.609129
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:14.319209
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i = AdHocCLI(str_0)
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:34:19.118138
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:22.445160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:25.409304
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

# Generated at 2022-06-24 17:34:37.930666
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:39.414502
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:43.864040
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:52.196778
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.init_parser()
    str_1 = 'L(iMf%}QIu{DBt'
    ad_hoc_c_l_i_0.validate_conflicts(str_1)
    ad_hoc_c_l_i_0.post_process_args(str_0)
    ad_hoc_c_l_i_0.parse()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:53.703563
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:34:59.076289
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:35:06.029349
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '9nK!y[}mv+8r;Jx_(M2'
    assert_0 = AdHocCLI(str_0)
    str_1 = 'IucrD(^~;0UY/qFA~d'
    assert_1 = AdHocCLI(str_1)

    try:
        assert_1.run()
    except SystemExit:
        pass

# Generated at 2022-06-24 17:35:08.523254
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    result = ad_hoc_c_l_i_0.run()
    assert result == 0


# Generated at 2022-06-24 17:35:11.545691
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:14.395367
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '8p+W|-d<K#=iH&Q2^[w'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:30.840289
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = '4OE%c$Yq3FKX?BBgC'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    try:
        ad_hoc_c_l_i_1.run()
    except AnsibleError:
        pass
    except AnsibleOptionsError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:36.093391
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    str_1 = '-i'
    str_2 = 'Y/)~;0LU(D=^4qrFdA'
    str_3 = '-m'
    str_4 = 'debug'
    str_5 = '-a'
    str_6 = 'msg=Hello World'
    str_7 = 'all'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

# Generated at 2022-06-24 17:35:45.596279
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.parsing.dataloader import DataLoader
    

# Generated at 2022-06-24 17:35:49.626846
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = ";1)>w2*s#sA+_%86N}"
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    try:
        ad_hoc_c_l_i_1.run()
    except AnsibleError as e:
        print(e)


# Generated at 2022-06-24 17:35:53.012638
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '.vF6p>U*^'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:54.933875
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:00.852012
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:02.515794
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    play_ds = ad_hoc_c_l_i_0._play_ds()


# Generated at 2022-06-24 17:36:09.071183
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Y/)~;0LU(D=^4qrFdA'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:10.129368
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:36:26.360124
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.run()
    print(var_0)

# Generated at 2022-06-24 17:36:29.434247
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:39.059993
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_1.init_parser()
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit:
        pass
    assert(False)

test_case_0()

# Generated at 2022-06-24 17:36:43.697145
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0._play_prereqs()
    ad_hoc_c_l_i_0.init_parser()

# Generated at 2022-06-24 17:36:48.836085
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_1 = b'\xe7\x97'
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)
    var_1 = ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:37:03.731344
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    with mock.patch('ansible.cli.adhoc.AdHocCLI.run', return_value=0) as mock_run:
        with mock.patch('ansible.cli.adhoc.AdHocCLI.run') as mock_run:
            ad_hoc_c_l_i_0.run()
            assert mock_run.called
            assert mock_run.call_count == 1


# Generated at 2022-06-24 17:37:07.943469
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)



# Generated at 2022-06-24 17:37:15.626426
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    test_case_0()
    var_1 = ad_hoc_c_l_i_0.run()
    del ad_hoc_c_l_i_0
    del bytes_0
    del var_1


# Generated at 2022-06-24 17:37:17.701840
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:37:20.525181
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_1 = ad_hoc_c_l_i_0.run()
    assert var_1 == 0

# Generated at 2022-06-24 17:37:38.896011
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b's\xab\x1d'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:47.929442
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:37:51.991904
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of class AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI(b'\x08\x01\x06')
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    import sys
    import traceback
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:55.117041
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI) == True


# Generated at 2022-06-24 17:38:03.390871
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\xaa\x78\x73'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

test_case_0()

# Generated at 2022-06-24 17:38:05.517023
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # cannot import
    # assert_function_run(AdHocCLI , "run")

    return None


# Generated at 2022-06-24 17:38:12.015834
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ret_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:16.954515
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:23.559372
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x85\xd1'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:25.645830
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create a test object
    ad_hoc_c_l_i_0 = AdHocCLI()


# Generated at 2022-06-24 17:39:00.429327
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:06.284408
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:13.225729
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:39:20.433783
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Input arguments
    bytes_0 = b'\x81\xa8\xcb\xe7\xf0\xcc\x8b'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0._tqm = TaskQueueManager()
    ad_hoc_c_l_i_0._tqm._stats = PlaybookExecutorStats()
    ad_hoc_c_l_i_0._tqm.send_callback = MagicMock()
    ad_hoc_c_l_i_0._tqm.run = MagicMock()
    ad_hoc_c_l_i_0._tqm.run.return_value = 0
    ad_hoc_c_l_

# Generated at 2022-06-24 17:39:25.811210
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:28.963998
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\xa7\x9b\xcf'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    int_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:29.842453
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:39:34.484721
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    test_case_0()
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:40.801686
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\xe3\xf3\x15'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:39:45.938691
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_1 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:57.953563
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:41:03.711096
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.init_parser()
    ad_hoc_c_l_i.post_process_args()
    var = ad_hoc_c_l_i.run()
    assert var == 0

# Generated at 2022-06-24 17:41:05.488814
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI() is not None, "Unable to instantiate AdHocCLI"

# Generated at 2022-06-24 17:41:18.386753
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'O\x0f\x16\x81\x0f\x0e\x92\x07\x14\x10\x10\x14\x96\x04\x18\x13\x12\x00\x17\x1c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    # Test the line: var_0 = ad_hoc_c_l_i_0.init_parser()
    print('var_0: ' + str(var_0))
    # Test the line:

# Generated at 2022-06-24 17:41:28.817014
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:41:33.227833
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.init_parser()

    # Set parameters as required
    ad_hoc_c_l_i_0.args = 'somehost'
    ad_hoc_c_l_i_0.module_name = 'setup'

    ret_val = ad_hoc_c_l_i_0.run()
    assert ret_val == 0

# Generated at 2022-06-24 17:41:40.673767
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_1 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    import pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-24 17:41:43.850850
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x89\xaa\xb3'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)


# Generated at 2022-06-24 17:41:45.860409
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    # test_AdHocCLI()
    pass

# Generated at 2022-06-24 17:41:57.513656
# Unit test for method run of class AdHocCLI