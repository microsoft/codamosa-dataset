

# Generated at 2022-06-24 17:33:45.185739
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    try:
        test_case_0()
    except SystemExit:
        bool_0 = False
    except AnsibleOptionsError:
        bool_0 = False
    assert bool_0

# Generated at 2022-06-24 17:33:48.609286
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:33:57.095907
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_0 = False
    # bool_0 = bool_0
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # Verify the exception is raised
    with pytest.raises(AnsibleOptionsError):
        bool_0 = False
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)


# Generated at 2022-06-24 17:34:00.560006
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    display.verbosity = 3
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)


if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-24 17:34:04.984920
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    context.CLIARGS = {'args': 'ansible', 'module_args': 'foo=bar', 'listhosts': True}
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:09.501658
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    try:
        ad_hoc_c_l_i_0.run()
    except:
        pass

# Generated at 2022-06-24 17:34:14.102405
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    result = ad_hoc_c_l_i_0.run()
    assert len(result) == 2

# Generated at 2022-06-24 17:34:16.182175
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)


# Generated at 2022-06-24 17:34:19.118496
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', 'test_adhoc_base.py'])

# Generated at 2022-06-24 17:34:26.919066
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Run unit tests')
    parser.add_argument('--test', dest='test_name', help='Name of the test case')
    args = parser.parse_args()

    if args.test_name == 'test_method_run_of_class_AdHocCLI':
        test_AdHocCLI_run()
    else:
        test_case_0()

# Generated at 2022-06-24 17:34:44.175532
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Arrange
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.ask_passwords = mock.MagicMock(side_effect = ["", ""])
    ad_hoc_c_l_i_0._play_prereqs = mock.MagicMock(return_value = (None, None, None))
    ad_hoc_c_l_i_0.get_host_list = mock.MagicMock(return_value = [])
    ad_hoc_c_l_i_0._play_ds = mock.MagicMock(return_value = dict())

# Generated at 2022-06-24 17:34:48.793726
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Unit tests for class AdHocCLI

# Generated at 2022-06-24 17:34:53.799437
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print_test_case_name('test_AdHocCLI_run')
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.parser.parse_args([])
    var_0 = ad_hoc_c_l_i_0.run()
    print_test_result(var_0)


# Generated at 2022-06-24 17:35:00.515851
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.post_process_args()
    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:07.173060
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    __tracebackhide__ = True
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.run()
    assert var_1 == 0, 'test_AdHocCLI_run failed'


# Generated at 2022-06-24 17:35:10.735232
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert(ad_hoc_c_l_i_0.test) == True
    assert(ad_hoc_c_l_i_0.parser.prog) == 'ansible'

# Generated at 2022-06-24 17:35:15.177669
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:35:19.187557
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Arrange

    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    
    # Act
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:22.022606
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:26.813694
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    int_0 = ad_hoc_c_l_i_0.run()
    assert int_0 == 0

# Generated at 2022-06-24 17:35:49.935685
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_1 = ad_hoc_c_l_i_0.init_parser()
    bool_3 = ad_hoc_c_l_i_0.post_process_args(bool_1)
    bool_4 = ad_hoc_c_l_i_0.run()
    bool_5 = ad_hoc_c_l_i_0.get_host_list()
    assert bool_4 == True
    assert bool_4 == True
    assert bool_4 == True
    assert bool_4 == True
    assert bool_4 == True


# Generated at 2022-06-24 17:35:53.233378
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = None
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:00.518446
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_1 = False
    ad_hoc_c_l_i_1 = AdHocCLI(bool_1)

    var_1 = ad_hoc_c_l_i_1.init_parser()

    # Test for Command line argument handling
    args = None

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import configparser as six_configparser
    from ansible.module_utils.six.moves import StringIO

    import os
    import sys
    import textwrap
    import types


# Generated at 2022-06-24 17:36:05.618592
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)
    assert isinstance(ad_hoc_c_l_i_0.init_parser(), None)
    assert isinstance(ad_hoc_c_l_i_0.run(), int)

test_case_0()

# Generated at 2022-06-24 17:36:10.640388
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:14.966818
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_1 = True
    result = ad_hoc_c_l_i_0.run(bool_1)


# Generated at 2022-06-24 17:36:20.477049
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    
    bool_0 = True
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:26.898172
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # Create the instance of the class
    ad_hoc_c_l_i_0 = AdHocCLI()
    assert(ad_hoc_c_l_i_0.run())

# Generated at 2022-06-24 17:36:34.000223
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Params for constructor of class AdHocCLI

    try:
        bool_1 = True
        ad_hoc_c_l_i_1 = AdHocCLI(bool_1)
        var_1 = ad_hoc_c_l_i_1.init_parser()
    except Exception as e:
        var_1 = None
    assert var_1 == None

    try:
        bool_2 = True
        ad_hoc_c_l_i_2 = AdHocCLI(bool_2)
        var_2 = ad_hoc_c_l_i_2.init_parser()
    except Exception as e:
        var_2 = None
    assert var_2 == None


# Generated at 2022-06-24 17:36:38.115580
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # There is no assert equals


# Generated at 2022-06-24 17:37:18.652469
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

if __name__ == '__main__':
    import sys
    import os
    sys.path.insert(1, os.path.join(sys.path[0], '..'))
    from tests.base import BaseTestCase

    os.environ['ANSIBLE_LIBRARY'] = "{0}/../modules".format(os.path.dirname(__file__))
    os.environ['ANSIBLE_MODULE_UTILS'] = "{0}/../module_utils".format(os.path.dirname(__file__))
    from ansible.module_utils import basic

    from units.mock.procenv import replace_env_pass, reset_env_pass
    replace_env_pass()

    import pytest
    #import unittest
    #unittest.main(module=__name__

# Generated at 2022-06-24 17:37:23.642045
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:28.716183
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_1 = True
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = "git"
    context.CLIARGS['module_args'] = "repo=https://github.com/ansible/ansible.git version=HEAD dest=/tmp/ansible virtualenv=/tmp/ansible-test"
    result = ad_hoc_c_l_i_0.run(bool_1)
    assert result == 0
    assert display.verbosity == 0
    
if __name__ == "__main__":
    #test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:30.266585
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:37:38.710726
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test case for AdHocCLI.run, test case 0
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_1 = ad_hoc_c_l_i_0.init_parser()
    var_2 = ad_hoc_c_l_i_0.post_process_args(var_1)
    var_3 = ad_hoc_c_l_i_0._play_ds()
    var_4 = ad_hoc_c_l_i_0.run()
    assert not var_4


# Generated at 2022-06-24 17:37:42.630655
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    #  Instance of class AdHocCLI with arg 'False'
    ad_hoc_c_l_i_1 = AdHocCLI(False)

    #  Instance of class AdHocCLI with arg 'True'
    ad_hoc_c_l_i_2 = AdHocCLI(True)



# Generated at 2022-06-24 17:37:47.726327
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:52.820282
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.run()

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:03.817247
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    if C.ANSIBLE_FORCE_COLOR:
        print('''[1m[41m[97m[0m''')
    print('Correct')
    bool_3 = True
    ad_hoc_c_l_i_3 = AdHocCLI(bool_3)
    var_0 = ad_hoc_c_l_i_3.run()



# Generated at 2022-06-24 17:38:05.729496
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except Exception as e:
        display.error(to_text(e))
        sys.exit(1)

# Generated at 2022-06-24 17:39:16.737131
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:18.958230
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:24.541629
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:28.569221
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:39:38.769907
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    bool_1 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_1 = AdHocCLI(bool_1)
    var_1 = ad_hoc_c_l_i_1.init_parser()
    ad_hoc_c_l_i_2 = AdHocCLI(bool_0)
    var_2 = ad_hoc_c_l_i_2.init_parser()
    ad_hoc_c_l_i_3 = AdHocCLI(bool_1)
    var_3 = ad_hoc_c_l_i_

# Generated at 2022-06-24 17:39:46.032087
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    display.display(ad_hoc_c_l_i_0)
    ad_hoc_c_l_i_1 = AdHocCLI()
    display.display(ad_hoc_c_l_i_1)

test_AdHocCLI()

# Generated at 2022-06-24 17:39:50.401820
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:00.236801
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unittest
    import sys, os
    import shutil
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    import json

    # For most tests, we need an inventory and a variable manager
    inventory = InventoryManager(loader=DataLoader(), sources=["/tmp/testing_inventory"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Callback to feed tests

# Generated at 2022-06-24 17:40:07.639356
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert ad_hoc_c_l_i_0.test == bool_0


# Generated at 2022-06-24 17:40:09.526961
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)