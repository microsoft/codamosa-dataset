

# Generated at 2022-06-24 17:33:36.768584
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:33:38.007145
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:33:39.125069
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True


# Generated at 2022-06-24 17:33:50.966236
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    expected_calls = [
        ('v2_playbook_on_start', {'playbook': expected_playbook})
    ]

    ad_hoc_c_l_i_0 = AdHocCLI(None)
    ad_hoc_c_l_i_0._tqm = MockedTaskQueueManager(expected_calls)

    ad_hoc_c_l_i_0.run()
    assert ad_hoc_c_l_i_0._tqm.mock_calls == expected_calls



# Generated at 2022-06-24 17:33:53.700866
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:33:56.719775
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Unit Test for method run() at class AdHocCLI

# Generated at 2022-06-24 17:33:59.846220
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -1807
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:03.146087
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -1807
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:10.571066
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_1 = 0
    ad_hoc_c_l_i_1 = AdHocCLI(int_1)
    int_1 = -1807
    ad_hoc_c_l_i_1.init_parser(int_1)
    # This test case was throwing an exception, confirming that it is throwig the same exception
    try:
        ad_hoc_c_l_i_1.run()
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-24 17:34:14.460953
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:34:25.409377
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Setup
    bytes_0 = b'\x15?\x9c\x81\xd2\xcf\xe5\xb0\x95\x1a\x0b'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    # Unit test for method run of class AdHocCLI
    test_case_0()

# Generated at 2022-06-24 17:34:33.405265
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:34:40.798223
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x88\x0c\x1b\xed\x92\x0f)r\xcbk\x1b\x0b\x1d\xd0l\x09\x07\xfc\x850\x96\x9b\x12'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:44.984499
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class AdHocCLI
    test_AdHocCLI()

# Generated at 2022-06-24 17:34:50.555799
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:59.197154
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_1 = b'\x14\xfc\xaa\x8f\x0c%\x1a\xf1\x7f\x1e\x84\xc2\xa7\xda'
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:35:02.965447
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    var_1 = ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:35:04.876107
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 17:35:05.576857
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:35:08.353650
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cmd_line = b'ansible-adhoc -i 127.0.0.1, -m ping localhost'
    ad_hoc_c_l_i_0 = AdHocCLI(cmd_line)
    assert ad_hoc_c_l_i_0 is not None

# Generated at 2022-06-24 17:35:23.449590
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    arguments = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    adhoc = AdHocCLI(arguments)
    adhoc.run()

test_AdHocCLI()

# Generated at 2022-06-24 17:35:35.839671
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create an instance of our class
    ad_hoc_c_l_i_0 = AdHocCLI()

    # Create a mock object to mock the method run as called by our test case
    class mock_run():
        # Mocked version of the method
        def run(self):
            pass

    # Create a mock object to mock the property modules as accessed by our test case
    class mock_modules():
        # Mocked version of the property
        def run(self):
            pass

    # Set the attribute modules to the mock object - it will take the place of the real one
    ad_hoc_c_l_i_0.modules = mock_modules

    # Set the attribute tqm to the mock object - it will take the place of the real one
    ad_hoc_c_l_i_0.tqm

# Generated at 2022-06-24 17:35:41.662910
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('Testing method run')
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    print(var_0)


# Generated at 2022-06-24 17:35:47.467960
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_1 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:48.737722
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:35:50.003572
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:35:51.901442
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('TESTING AdHocCLI.run()')
    test_case_0()

# Generated at 2022-06-24 17:35:55.300806
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    var_0 = AdHocCLI(b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5')
    var_0.run()


# Generated at 2022-06-24 17:36:02.557581
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert ad_hoc_c_l_i_0.run() == 0

test_case_0()

# Generated at 2022-06-24 17:36:10.311874
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:27.804938
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:32.024397
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Define input values
    cmd_line_args = b']\xd2\x81\x19;r\x83w&\x1d\x1e\07\xdb\xfc\x16\xf5'

    # Execute function
    function_output = AdHocCLI(cmd_line_args).run()

    # Validate function output
    assert function_output is 0

# Generated at 2022-06-24 17:36:40.051492
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:36:42.797532
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    var_0 = AdHocCLI
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:36:51.537156
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        bytes_1 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
        ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)
        var_1 = ad_hoc_c_l_i_1.run()
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-24 17:37:03.285259
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    #
    # TEST CASE:
    #
    # bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    # ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    # var_0 = ad_hoc_c_l_i_0.run()
    #
    pass



# Generated at 2022-06-24 17:37:16.255616
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    test_case_0()

# Generated at 2022-06-24 17:37:28.387671
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x07'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    os.environ['ANSIBLE_CONFIG'] = '/home/vagrant/ansible/hacking/test/integration/targets/all/ansible.cfg'
    os.environ['ANSIBLE_CALLBACK_WHITELIST'] = 'profile_tasks'
    os.environ['ANSIBLE_REMOTE_TEMP'] = '/home/vagrant/.ansible/tmp'
    os.environ['ANSIBLE_STRATEGY'] = 'free'
    os.environ['ANSIBLE_LOG_PATH'] = '/home/vagrant/.ansible.log'


# Generated at 2022-06-24 17:37:37.265821
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x99\xdf\x83\x01\x1a\xc3+\xc5\x9c\xea\xf1\x1e\x1b\x93\xed\x81\x86\xf9\x1c\xfe\x15\xee\xfe\x0e\x15'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:42.882793
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:09.846747
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-24 17:38:12.258163
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # TEST CASE: Test method run of class AdHocCLI when invoked with a 0 argument
    test_case_0()

# Generated at 2022-06-24 17:38:19.846686
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:21.312240
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:38:27.587470
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    # test_AdHocCLI_run(AdHocCLI,bytes)
    # test_AdHocCLI_run(AdHocCLI,bytes)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:38:30.164701
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI and call run
    test_case_0()



# Generated at 2022-06-24 17:38:33.263346
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    var_0 = AdHocCLI()
    ad_hoc_c_l_i_0 = AdHocCLI()
    var_0.run()


test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:39.075681
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\xde\x8a\x82\x1bF\xe5\xab\xe4'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:38:46.421236
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(b'\xfb \xce\x9b\x1b\xef\xa6\n\xba\xf6\xfa\xa0\xfc\xda\xfe\x07\xe5\x8f')
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:52.145177
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x14\xed\x92\x99\x89\xfa\xeeW\xc2%\x9e\x05\x1b\xd8\x18'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:54.478087
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pattern='vagrant'
    ad_hoc_c_l_i_0 = AdHocCLI(pattern)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:00.445389
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    print (ad_hoc_c_l_i_0.run)

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:07.275615
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b']\xd2\x81\x19;r\x83w&\x1d\x1e\x07\xdb\xfc\x16\xf5'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

    print(var_0)

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:13.140396
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(b'\x01\x11\x0c\x02\x1f\x1d')
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:23.040311
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\xf0'
    # argument '_pattern' is assigned a value but never used
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    bytes_0 = b'\x9b\xef\x1f'
    # argument '_pattern' is assigned a value but never used
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:40:34.723714
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x87\x17\x1f\x06\x98\xdb\\\xcf\x8e\x9d\xa2'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()
    var_1 = ad_hoc_c_l_i_0.init_parser()
    var_2 = ad_hoc_c_l_i_0.post_process_args(var_0)
    ad_hoc_c_l_i_0._play_prereqs()
    var_3 = ad_hoc_c_l_i_0.get_host_list(var_1, var_0, var_0)


# Generated at 2022-06-24 17:40:47.082928
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_1 = b'\xfc\x82\xee\xcf\x89\x0f\xfa\xd7:D\x9f\xeb\x03\x95\x1b\xbc\xa7\xd0\xf8\xcc\xc9) '
    bytes_2 = b'\x13\xf1\x93\xce\x18\xf0\x9a\xc7\x1b\xeb\x89\xdf\x0d\x12\xe5\xde\x9a\xae\xfb\x1a\xd5;\x83'
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)

# Generated at 2022-06-24 17:40:52.967855
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x0e\xbb\xab\xb2F\xfa\x99\x8c\xa9\xba\xc7\xef\xec\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:53.639154
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:41:01.967886
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'o\xeb\x945\xb3\x81\x80\x1f\x8a\x93\x7f\xba\x00\x9f\x0c'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    # Unit test for function run of class AdHocCLI
    #test_case_0()