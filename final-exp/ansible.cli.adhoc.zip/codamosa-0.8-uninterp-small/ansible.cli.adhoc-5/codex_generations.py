

# Generated at 2022-06-24 17:33:43.948400
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'Cumblus Linux'
    ad_hoc_c_l_i_0.init_parser(str_1)
    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:33:47.430599
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:33:50.489652
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-24 17:33:53.827909
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible.cli.adhoc import AdHocCLI
    ad_hoc_cli = AdHocCLI()
    assert (ad_hoc_cli)


# Generated at 2022-06-24 17:33:58.162166
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Cumblus Linux'
    try:
        ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    except:
        assert False


# Generated at 2022-06-24 17:33:59.581408
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert callable(AdHocCLI)


# Generated at 2022-06-24 17:34:02.877052
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert(ad_hoc_c_l_i_0.run() == 0)

# Generated at 2022-06-24 17:34:06.479234
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except NameError as error0:
        print('Method test_case_0 of class AdHocCLI threw an exception: ', error0)
    finally:
        pass

# Generated at 2022-06-24 17:34:10.166156
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:17.094718
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C

    # Initialize test variables
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_2 = AdHocCLI(str_0)
    str_0 = 'Cumblus Linux'
    ad_hoc_c_l_i_3 = AdHocCLI(str_0)
    str_0 = 'Cumblus Linux'

# Generated at 2022-06-24 17:34:34.206616
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:40.428670
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    playbook_name = ''
    post_process_args = ''
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.playbook = playbook_name
    ad_hoc_c_l_i.post_process_args = post_process_args
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:34:43.942684
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = test_case_0()
    return ad_hoc_c_l_i_0

# Generated at 2022-06-24 17:34:49.731490
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_2 = AdHocCLI()
    file_name = './sample_playbook.yml'
    ad_hoc_c_l_i_2.run(file_name)

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:00.389405
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    class_tuple = tuple([int, None, str, list, list, list, None, None, None, None, list, list])
    arg_tuple = tuple([0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    assert type(ad_hoc_c_l_i.run(class_tuple, arg_tuple)) == int


# Generated at 2022-06-24 17:35:04.683251
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Setup

    # Test
    ad_hoc_c_l_i_0 = AdHocCLI()
    # Verify
    assert ad_hoc_c_l_i_0 != None


# Generated at 2022-06-24 17:35:07.240884
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    result = ad_hoc_c_l_i_0.run()
    assert type(result) == int


# Generated at 2022-06-24 17:35:08.883787
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print('Test case 0:')
    test_case_0()
    print('===============================')
    print()


# Generated at 2022-06-24 17:35:15.605023
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_c_l_i_1 = AdHocCLI()
    # Test 1
    options = None

    # Load options from ansible file
    options = ad_hoc_c_l_i_1.options_parser.parse_args(['--version'])
    try:
        ad_hoc_c_l_i_1.post_process_args(options)
    except AnsibleOptionsError as e:
        # Python 3.5+
        assert 'has been deprecated' in str(e)
    else:
        # Python 2
        assert 'has been deprecated' in e.message

    options = None

    # Load options from ansible file
    options = ad_hoc_c_l_i_1.options_parser.parse_args(['-m ping', 'all'])
    ad

# Generated at 2022-06-24 17:35:19.188254
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI()

    # Run the method under test
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:36.205703
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()



# Generated at 2022-06-24 17:35:39.282771
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i.run() == 0


# Generated at 2022-06-24 17:35:42.673190
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:35:45.287512
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:52.173160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    host_pattern = 'localhost'
    async_val = 10
    poll = 5
    check_raw = 'ping' in C.MODULE_REQUIRE_ARGS

    mytask = {'action': {'module': 'ping', 'args': parse_kv(host_pattern, check_raw=check_raw)},
              'timeout': C.DEFAULT_TASK_TIMEOUT}

    # avoid adding to tasks that don't support it, unless set, then give user an error
    if 'ping' not in C._ACTION_ALL_INCLUDE_ROLE_TASKS and any(frozenset((async_val, poll))):
        mytask['async_val'] = async_val
        mytask['poll'] = poll

    # get basic objects

# Generated at 2022-06-24 17:35:53.486777
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# unit test for init_parser method

# Generated at 2022-06-24 17:35:55.735026
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()
    assert True


# Generated at 2022-06-24 17:36:01.048872
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    ad_hoc_c_l_i_run_0 = AdHocCLI()

    # Test needs more work
    print("in test_AdHocCLI_run")


# Generated at 2022-06-24 17:36:03.988433
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.post_process_args({'module_name': 'shell', 'module_args': 'echo Hello', 'args': 'localhost'})
    adhoc.run()

# Generated at 2022-06-24 17:36:16.843865
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_obj = AdHocCLI()

    inventory_obj = 'inventory_obj'
    variable_manager_obj = 'variable_manager_obj'
    loader_obj = 'loader_obj'
    passwords = {'conn_pass': None, 'become_pass': None}

    # arrange
    ad_hoc_c_l_i_obj.args = '*'
    ad_hoc_c_l_i_obj.module_name = 'win_ping'
    ad_hoc_c_l_i_obj.module_args = ''
    ad_hoc_c_l_i_obj.tags = ''
    ad_hoc_c_l_i_obj.skip_tags = ''
    ad_hoc_c_l_i_obj.one

# Generated at 2022-06-24 17:36:46.413718
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    x = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:50.630512
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    return ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:36:55.356701
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    test_AdHocCLI_obj_0 = AdHocCLI()
    try:
        test_AdHocCLI_run_0 = AdHocCLI.run(test_AdHocCLI_obj_0)
    except Exception as e:
        print("Exception raised:", e)

# Generated at 2022-06-24 17:36:57.110444
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_var = AdHocCLI()
    test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:01.298833
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI
    test_case_0()


if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:37:11.621500
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_2 = AdHocCLI()
    # Test expected exception.
    # Invalid option 'fail_if_missing' in connection string.
    test_case = 'ansible localhost -m ping -a "fail_if_missing=True"'
    try:
        ad_hoc_c_l_i_2.parse(test_case.split())
    except Exception as e:
        assert type(e).__name__ == 'OptionConflictError'
    # Test function called with wrong arguments
    try:
        ad_hoc_c_l_i_2.run(test_case.split())
    except TypeError as e:
        assert e[0] == 'run() takes exactly 1 argument (2 given)'

# Generated at 2022-06-24 17:37:14.287223
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:37:15.097958
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()


# Generated at 2022-06-24 17:37:17.110314
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:37:21.018191
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()


# Generated at 2022-06-24 17:38:24.325299
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    test_case_0()

# Generated at 2022-06-24 17:38:32.639831
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # 1. Create an instance of the AdHocCLI class
    my_adhoc_cli = AdHocCLI()

    # 2. Create a context object and set context.CLIARGS[''] value
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = C.MODULE_REQUIRE_ARGS[0]
    context.CLIARGS['module_args'] = ''

    # 3. Try to run the my_adhoc_cli instance
    try:
        my_adhoc_cli.run()
    except AnsibleOptionsError as e:
        assert "No argument passed to %s module" % C.MODULE_REQUIRE_ARGS[0] == str(e)


# Generated at 2022-06-24 17:38:33.853297
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_c_l_i_1 = AdHocCLI()



# Generated at 2022-06-24 17:38:34.332384
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pass


# Generated at 2022-06-24 17:38:39.883928
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()

# Generated at 2022-06-24 17:38:42.998136
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    #return AdHocCLI.run(ad_hoc_c_l_i_0)

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:46.735718
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:38:50.585914
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from importlib import reload
    global context, display, AdHocCLI
    reload(context)
    reload(display)
    reload(AdHocCLI)
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:53.069776
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
  ad_hoc_c_l_i = AdHocCLI()
  ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:38:56.574806
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    # TODO: implement test
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:40:33.344188
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

    try:
        context.CLIARGS['tree'] = '.'

        result_0 = ad_hoc_c_l_i_0.run()

        assert result_0 == 0
    finally:
        if os.path.exists('./tree'):
            shutil.rmtree('./tree')

# ##########
# END - Unit test for method run of class AdHocCLI
# ##########

# Generated at 2022-06-24 17:40:38.041909
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pattern = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(pattern)
    assert ad_hoc_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:40:43.564145
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['localhost', '-m ping']
    try:
        AdHocCLI(args).run()
    except Exception as e:
        print("Test Failed")
        print("Unexpected Exception:", type(e), ":", e)


# Generated at 2022-06-24 17:40:55.598180
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    context.CLIARGS['_ansible_config_version'] = 2
    context.CLIARGS['module_name'] = 'command'
    context.CLIARGS['module_args'] = 'uptime'
    context.CLIARGS['args'] = '{{host}}'
    context.CLIARGS['hosts'] = '{{host}}'
    context.CLIARGS['forks'] = 5
    context.CLIARGS['new_vault_password_file'] = 'new_password.txt'

# Generated at 2022-06-24 17:40:57.248496
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass # TODO

# Generated at 2022-06-24 17:41:02.959937
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    var_0

# Generated at 2022-06-24 17:41:06.261744
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_1 = 'Cumulus Linux'
    ad_hoc_c_l_i_1 = AdHocCLI(test_1)
    try:
        var_1 = ad_hoc_c_l_i_1.run()
    except Exception as e:
        raise e


# Generated at 2022-06-24 17:41:10.817681
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()


# Generated at 2022-06-24 17:41:11.944420
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pass

# Generated at 2022-06-24 17:41:20.471910
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print("Testing run() of class AdHocCLI")
    str_0 = 'Cumulus Linux'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.run()
    assert(isinstance(var_1, int))