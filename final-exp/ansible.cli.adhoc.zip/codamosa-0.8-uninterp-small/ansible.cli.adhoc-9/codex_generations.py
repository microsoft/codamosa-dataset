

# Generated at 2022-06-24 17:33:56.089355
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ##############################################################################
    # Instantiate AdHocCLI
    ##############################################################################
    ad_hoc_c_l_i_0 = AdHocCLI('ansible_env')

    # Test ad_hoc_c_l_i_0.init_parser()
    test_case_0()

    ##############################################################################
    # AdHocCLI.post_process_args(options)
    ##############################################################################

    # Test AdHocCLI._play_ds(pattern, async_val, poll)
    AdHocCLI._play_ds(pattern, async_val, poll)

    # Test AdHocCLI.run()
    ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test

# Generated at 2022-06-24 17:33:57.572798
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:34:01.736516
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:09.563019
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Arrange
    CLI.setup_args()
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.init_parser()
    opts = ad_hoc_c_l_i_0.parser.parse_args(['-a', 'date'])
    ad_hoc_c_l_i_0.post_process_args(opts)

    # Act
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:17.059146
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    host_pattern_0 = 'test_pattern'
    argv_0 = ['ansible', 'test_pattern']
    argv_1 = ['ansible', '-t', 'test_pattern']
    argv_2 = ['ansible', '--tree', 'test_pattern']
    argv_3 = ['ansible', '--list-hosts', 'test_pattern']
    argv_4 = ['ansible', '--forks', 'test_pattern']
    argv_5 = ['ansible', '-T', 'test_pattern']
    argv_6 = ['ansible', '-v', 'test_pattern']
    argv_7 = ['ansible', '-vv', 'test_pattern']
    argv_8 = ['ansible', '--module-name', 'test_pattern']
    argv_

# Generated at 2022-06-24 17:34:21.542641
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    result = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:22.749499
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI()

# Generated at 2022-06-24 17:34:25.586588
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:29.205292
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:34.480458
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_2 = AdHocCLI()
    str_0 = 'ansible_env'
    result = ad_hoc_c_l_i_2.run(str_0)
    pass

# Generated at 2022-06-24 17:34:53.107155
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_c_l_i = AdHocCLI()

    ad_hoc_c_l_i.post_process_args = types.MethodType(lambda self, options: options, ad_hoc_c_l_i)
    ad_hoc_c_l_i.ask_passwords = types.MethodType(lambda self: ('', ''), ad_hoc_c_l_i)
    ad_hoc_c_l_i._play_prereqs = types.MethodType(lambda self: (object, object, object), ad_hoc_c_l_i)

# Generated at 2022-06-24 17:35:03.711893
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class test_args(object):
        listhosts = None
        subset = None
        module_name = None
        module_args = None
        task_timeout = None
        verbosity = None
        connection = None
        timeout = None
        remote_user = None
        ask_pass = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = None
        become_method = None
        become_user = None
        become_ask_pass = None
        become_exe = None
        check = None
        diff = None
        syntax = None
        start_at_task = None
        inventory = None
        async_val = None
        poll_interval = None


# Generated at 2022-06-24 17:35:13.220942
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    print("Executing test_AdHocCLI_run ... ")
    try:
        ad_hoc_c_l_i_0.run()
    except AnsibleOptionsError as err:
        print("An unexpected exception occurred: %s" % err)
    else:
        print("Success")

# Command line interface
if __name__ == '__main__':

    import sys
    import os
    from ansible.cli import CLI

    current_dir = os.getcwd()
    sys.argv = ['ansible-adhoc', '--list-hosts', 'all']
    context.CLIARGS = CLI.parse()
    print("Running test_AdHocCLI_run()")
    test_AdH

# Generated at 2022-06-24 17:35:17.358495
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    assert ad_hoc_c_l_i_0.run() is None, 'The case test_AdHocCLI_run failed.'


# Generated at 2022-06-24 17:35:19.747405
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i is not None


# Generated at 2022-06-24 17:35:21.702389
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    try:
        ad_hoc_c_l_i.run()
    except SystemExit as e:
        pass

# Generated at 2022-06-24 17:35:23.985419
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    test_case_1()

    test_case_0()


# Generated at 2022-06-24 17:35:26.014080
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert callable(AdHocCLI)


# Generated at 2022-06-24 17:35:29.370265
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:35:31.335116
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:35:53.973123
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()    

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()


# Generated at 2022-06-24 17:36:01.024253
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    subprocess.check_output(['ansible', '--version'])
    subprocess.check_output(['ansible-doc', '--version'])
    my_env = os.environ.copy()
    my_env["ANSIBLE_HOST_KEY_CHECKING"] = "False"
    assert b"""failed=0""" in subprocess.check_output(['ansible', 'localhost', '-m', 'ping'], shell=True, env=my_env)
    subprocess.check_output(['ansible-playbook', "--version"])
    subprocess.check_output(['ansible-pull', "--version"])
    subprocess.check_output(['ansible-galaxy', "--version"])
    subprocess.check_output(['ansible-doc', "--version"])
    subprocess

# Generated at 2022-06-24 17:36:05.989111
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI()
    assert ad_hoc_c_l_i_0

    ad_hoc_c_l_i_0.init_parser()
    assert ad_hoc_c_l_i_0._parser

    ad_hoc_c_l_i_0.post_process_args(C.load_config_file())
    assert ad_hoc_c_l_i_0

# Generated at 2022-06-24 17:36:11.260535
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i.init_parser.__name__ == 'init_parser'
    assert ad_hoc_c_l_i.run.__name__ == 'run'

# Generated at 2022-06-24 17:36:23.969086
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = [
        'bad_host',
        # '-k',
        '-m', 'ping',
        '-i', 'hosts',
        '-c', 'local',
    ]
    ad_hoc_c_l_i = AdHocCLI(args)

    ad_hoc_c_l_i.parse()
    # agrs = ad_hoc_c_l_i.parse()
    # display.verbosity = args.verbosity
    # results = ad_hoc_c_l_i.validate_conflicts(args)
    # print("HUGO: " + str(results))
    ad_hoc_c_l_i.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:32.724268
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pattern = "test_pattern"
    async_val = "async_val"
    poll = "poll"
    ad_hoc_c_l_i_1 = AdHocCLI() # args = []
    with pytest.raises(AnsibleError):
        ad_hoc_c_l_i_1.run() # No hosts matched, nothing to do
    context.CLIARGS['args'] = pattern
    ad_hoc_c_l_i_2 = AdHocCLI() # args = [pattern]
    with pytest.raises(AnsibleError):
        ad_hoc_c_l_i_2.run() # No hosts matched, nothing to do
    context.CLIARGS['subset'] = "subset"
    ad_hoc_c_l_i

# Generated at 2022-06-24 17:36:38.529103
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    args = ['ansible', 'local', '-m', 'shell', '-a', 'ls', 'localhost']

    ad_hoc_c_l_i_2 = AdHocCLI()
    ad_hoc_c_l_i_2.parse(args)

# Generated at 2022-06-24 17:36:45.154327
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import mock
    # Input parameters
    # module_name = None

    # Return value tests
    ad_hoc_c_l_i_run_v_return_value = {}
    ad_hoc_c_l_i_run_v_return_value['0'] = None
    ad_hoc_c_l_i_run_v_return_value['1'] = None
    ad_hoc_c_l_i_run_v_return_value['2'] = None

    # Output value tests
    ad_hoc_c_l_i_run_v_return_value_output_value_0 = {}
    ad_hoc_c_l_i_run_v_return_value_output_value_1 = {}
    ad_hoc_c_l_i_run_v_return

# Generated at 2022-06-24 17:36:52.866262
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        # Create an object of AdHocCLI class
        ad_hoc_c_l_i = AdHocCLI()
        print('ad_hoc_c_l_i:')
        print(ad_hoc_c_l_i)
    except:
        print('ad_hoc_c_l_i is not an instance of the class AdHocCLI')
        print('Traceback:')
        raise


# Generated at 2022-06-24 17:37:00.625557
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    result = ad_hoc_c_l_i.run()
    assert result == 0


# Generated at 2022-06-24 17:37:40.197696
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.run() == None

# Generated at 2022-06-24 17:37:41.357195
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()


# Generated at 2022-06-24 17:37:52.048531
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    example_host_pattern = 'local-hostname'
    example_option_args = '-a \'opt1=val1 opt2=val2\''
    example_module_name = 'shell'
    example_module_args = 'ansible_password="default_password"'
    try:
        ad_hoc_c_l_i_0.run()
    except:
        ad_hoc_c_l_i_0.run(example_host_pattern, example_option_args, example_module_name, example_module_args)


# Generated at 2022-06-24 17:37:55.563215
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.init_parser()
    ad_hoc_c_l_i_1.post_process_args(context.CLIARGS)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:38:00.965980
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0_AdHocCLI_run = AdHocCLI()
    test_case_0_AdHocCLI_run.run()

# Generated at 2022-06-24 17:38:09.037134
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:38:11.369575
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    n = AdHocCLI()
    n.run()

# Generated at 2022-06-24 17:38:14.456234
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:15.997824
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:38:21.212989
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # This basically checks to see if we can create a AdHocCLI object and then
    # call run() on it to make sure it does not raise any exceptions.
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:39:47.064262
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert issubclass(AdHocCLI, CLI), "Class AdHocCLI should be a subclass of class CLI"


# Generated at 2022-06-24 17:39:52.811067
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pattern = "localhost"
    async_val = 0
    poll = 0
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i._play_ds(pattern, async_val, poll)


# Generated at 2022-06-24 17:39:54.719735
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    assert True


# Generated at 2022-06-24 17:39:59.774262
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()

# Generated at 2022-06-24 17:40:09.489275
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_run = ['ansible', 'localhost', '-a', '"test test2"', '-m', 'test', '-i', '"localhost,"', '-v']
    ad_hoc_c_l_i_1 = AdHocCLI(args_run)
    ad_hoc_c_l_i_1.run()

    # Verify if no exception thrown
    assert(True)



# Generated at 2022-06-24 17:40:10.334762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True == True

# Generated at 2022-06-24 17:40:13.368395
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    for c in (1):
        ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:40:16.889184
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    ad_hoc_c_l_i_1 = AdHocCLI()

    # Call method run of ad_hoc_c_l_i_1
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:40:22.158401
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.post_process_args()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:24.897652
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    test_case_1(ad_hoc_c_l_i_1)
    test_case_2(ad_hoc_c_l_i_1)


# Generated at 2022-06-24 17:42:12.456359
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    str_1 = 'ansible_env'
    var_1 = ad_hoc_c_l_i_0.post_process_args(str_0)
    str_2 = 'pattern'
    str_3 = 'async_val'
    str_4 = 'poll'
    var_2 = ad_hoc_c_l_i_0._play_ds(str_2, str_3, str_4)
    var_3 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:42:20.047623
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:42:25.283089
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:42:38.865742
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.post_process_args(var_0)
    var_2 = ad_hoc_c_l_i_0.run()
    var_3 = ad_hoc_c_l_i_0.get_opt(str_0, int_0)
    var_4 = ad_hoc_c_l_i_0.ask_vault_passwords()
    var_5 = ad_hoc_c_l_i_0.ask_passwords()
    var_6 = ad_

# Generated at 2022-06-24 17:42:46.918272
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'ansible_env'
    str_1 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)


# Generated at 2022-06-24 17:42:54.382272
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    # Testing try block
    try:
        var_1 = ad_hoc_c_l_i_1.run()
    except Exception as e_0:
        print(e_0)
    # Testing try block
    try:
        str_1 = 'anad_env'
        ad_hoc_c_l_i_1.init_parser(str_1)
        var_2 = ad_hoc_c_l_i_1.run()
    except Exception as e_1:
        print(e_1)
    except Exception as e_2:
        print(e_2)


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run

# Generated at 2022-06-24 17:43:08.335422
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '-m ping localhost'
    sys_argv = str_0.split()
    sys_argv.insert(0,'ansible')
    sys_argv.insert(1,'ad-hoc')
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    try:
        var_0 = ad_hoc_c_l_i_0.run()
    except AnsibleOptionsError:
        pass
        sys_argv[0] = 'ansible-ad-hoc'
        sys_argv[2] = '-h'
        var_0 = ad_hoc_c_l_i_0.run()
    except AnsibleError:
        pass
        sys_argv[0] = 'ansible-ad-hoc'

# Generated at 2022-06-24 17:43:10.353104
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except Exception as err:
        print("Failed to create AdHocCLI object")
        raise err

# Generated at 2022-06-24 17:43:17.433387
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'ansible_env'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:43:20.801021
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_1 = 'ansible_env'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
