

# Generated at 2022-06-24 17:33:40.617599
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(var_0)


# Generated at 2022-06-24 17:33:46.017642
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_c_l_i = AdHocCLI()

    try:
        ad_hoc_c_l_i.post_process_args({'version': False, 'verbosity': 0})
        raise AssertionError()
    except SystemExit as e:
        pass

    try:
        ad_hoc_c_l_i.post_process_args({'version': False, 'verbosity': 0, 'ask_vault_pass': False, 'ask_pass': False, 'vault_password_file': None, 'become': False, 'become_method': None, 'become_user': None, 'ask_become_pass': False})
        raise AssertionError()
    except SystemExit as e:
        pass


# Generated at 2022-06-24 17:33:57.192275
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {'inventory': None}

    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.options = context.CLIARGS
    ad_hoc_c_l_i_0.ask_passwords = mock.MagicMock()
    ad_hoc_c_l_i_0.ask_passwords.return_value = (None, None)
    ad_hoc_c_l_i_0._play_prereqs = mock.MagicMock()
    ad_hoc_c_l_i_0._play_prereqs.return_value = (None, None, None)
    ad_hoc_c_l_i_0.get

# Generated at 2022-06-24 17:34:03.244371
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
  my_ansible_config_path = "/path/to/my/ansible.cfg"
  C.config.initialize_with_config_file(my_ansible_config_path)
  bool_0 = False
  ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
  inventory_path = "./inventory"
  module_name = "command"
  module_args = "ls"
  pattern = "all"
  for host in [inventory_path, module_name, module_args, pattern]:
    ad_hoc_c_l_i_0.args.append(host)
  res_0 = ad_hoc_c_l_i_0.run()
  C.config.initialize_with_config_file(None)
  test_case_0

# Generated at 2022-06-24 17:34:08.253262
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    result_0 = ad_hoc_c_l_i_0.run()
    assert result_0 is None

test_case_0()
test_AdHocCLI_run()

# Example for a TTY check
#
# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
#
# import os
# import sys
# import termios
# import fcntl
#
# STDIN_FD = sys.stdin.fileno()
#
#
# def test_tty():
#     return os.isatty(STDIN_FD)
#
#
# def test_pty():
#     return not test_tty

# Generated at 2022-06-24 17:34:15.859293
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    str_0 = 'test'
    str_1 = 'test'
    str_2 = 'test'
    str_3 = 'test'
    str_4 = 'test'
    ans_opt_err_0 = AnsibleOptionsError(str_0)
    ans_err_0 = AnsibleError(str_1)
    ad_hoc_c_l_i_0.get_host_list = MagicMock(side_effect=[ans_opt_err_0])
    ad_hoc_c_l_i_0.post_process_args = MagicMock(return_value=str_2)
    ad_hoc_c_l_i_0.run = Magic

# Generated at 2022-06-24 17:34:20.251632
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI) == True


# Generated at 2022-06-24 17:34:25.700588
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Constructor args
    bool_0 = False
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)

    # Attribute args
    context.CLIARGS = dict()
    context.CLIARGS['module_args'] = 'echo hello'
    context.CLIARGS['module_name'] = 'shell'
    context.CLIARGS['args'] = 'localhost'
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['subset'] = False
    context.CLIARGS['seconds'] = True
    context.CLIARGS['poll_interval'] = False
    context.CLIARGS['tree'] = False
    context.CLIARGS['forks'] = 1

# Generated at 2022-06-24 17:34:26.965025
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except Exception as e:
        print('Failed to run test case.')

# Generated at 2022-06-24 17:34:28.172449
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:34:46.365603
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:48.127594
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # unit test for method run of class AdHocCLI
    pass


# Generated at 2022-06-24 17:34:55.918393
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        import os
        import pwd
        import tempfile
        import types
        import shutil
        import socket
        import hashlib
        # test one arg
        test_case_0()

        # test two arg
        test_case_1()

        # test three arg
        test_case_2()


    except (AnsibleOptionsError, AnsibleError, AnsibleParserError) as e:
        pass
        # except (IOError, OSError) as e:
        #    assert False, "Unit test for AdHocCLI.run() throws exception"
        # except (AssertionError) as e:
        #    assert False, "Unit test for AdHocCLI.run() throws exception"
        # except Exception as e:
        #    assert False, "Unit test for AdHocCL

# Generated at 2022-06-24 17:34:58.656224
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI(False)

# Generated at 2022-06-24 17:35:02.047932
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Test whether constructor of class AdHocCLI works correctly")
    test_case_0()

test_AdHocCLI()

# Generated at 2022-06-24 17:35:05.003978
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Should run successfully with arguments being False
    # Verify that no errors are reported
    assert test_case_0() is None


# Generated at 2022-06-24 17:35:08.288000
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Assigning arguments
    inventory = '__ANSIBLE_TEST__'

    # Invoking object
    ad_hoc_c_l_i = AdHocCLI()

    ad_hoc_c_l_i.run(inventory)


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:10.478104
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert ad_hoc_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:35:18.795349
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.post_process_args({'connection': 'local', 'module_name': 'ping', '_ansible_check_mode': False, '_ansible_verbosity': 3, '_ansible_version': '2.5.5'})

    # calling instance of AdHocCLI
    test_case_0()

# Generated at 2022-06-24 17:35:22.988334
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print("test_AdHocCLI_run")
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()
# _post_process_args() method of AdHocCLI class.

# Generated at 2022-06-24 17:35:35.015637
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:36.535624
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 17:35:42.873550
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create an instance of the AdHocCLI class
    ad_hoc_c_l_i_0 = AdHocCLI(False, '0')
    # pass variable number of args using splat operator
    ad_hoc_c_l_i_0.run(1274)


# Generated at 2022-06-24 17:35:48.690201
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_1 = -2182.9
    ad_hoc_c_l_i_2 = AdHocCLI(float_1)
    bool_1 = True
    str_1 = 'Architecture'
    ad_hoc_c_l_i_3 = AdHocCLI(bool_1, str_1)
    str_2 = 'bin'
    ad_hoc_c_l_i_3.run(str_2)

# Generated at 2022-06-24 17:35:53.759494
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:36:01.978360
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:36:03.836951
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:14.101906
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = -92345.8267
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = False
    str_0 = 'mKjN)4y4h4'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    
#  Output of the test case.
#
#  test_case_0()
#  test_AdHocCLI()
#
#  Process finished with exit code 0

# Generated at 2022-06-24 17:36:22.567076
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    var_0 = ad_hoc_c_l_i_1.run()


if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:29.714040
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    int_0 = ad_hoc_c_l_i_1.run(ad_hoc_c_l_i_0)


# Generated at 2022-06-24 17:36:52.366535
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 516.2
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'topology'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    var_0 = ad_hoc_c_l_i_1.run()
   #Assert for expected value and type

# Generated at 2022-06-24 17:37:06.250636
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    for i in range(100):
        float_0 = -399.4
        ad_hoc_c_l_i_0 = AdHocCLI(float_0)
        bool_0 = True
        str_0 = 'chdir'
        ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
        var_0 = ad_hoc_c_l_i_1.post_process_args(ad_hoc_c_l_i_0)
        ad_hoc_c_l_i_1.run()
        ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:12.064962
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    ad_hoc_c_l_i_0.run(ad_hoc_c_l_i_1)


# Generated at 2022-06-24 17:37:18.200384
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    var_0 = ad_hoc_c_l_i_1.post_process_args(ad_hoc_c_l_i_0)


# Generated at 2022-06-24 17:37:19.918101
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except:
        print(F'error')



# Generated at 2022-06-24 17:37:26.430669
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:37:34.839549
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create a test object of class AdHocCLI
    float_0 = -2182.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    bool_0 = True
    str_0 = 'Architecture'
    ad_hoc_c_l_i_1 = AdHocCLI(bool_0, str_0)

    if ad_hoc_c_l_i_0 == ad_hoc_c_l_i_1:
        print("Pass")
    else:
        print("False")


# Generated at 2022-06-24 17:37:40.374476
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -1384.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_1 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run(ad_hoc_c_l_i_1)


# Generated at 2022-06-24 17:37:46.704280
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    var_0 = ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:50.128300
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1.637
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:21.507551
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ':&'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0.run() is None


# Generated at 2022-06-24 17:38:27.052097
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = ':&'
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    # self.assertEqual(2, ad_hoc_c_l_i_1.testAttr1)
    # self.assertEqual(2, ad_hoc_c_l_i_1.testAttr2)

# Generated at 2022-06-24 17:38:29.748380
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:38:30.675738
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:38:34.603108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('*test_AdHocCLI_run')
    test_case_0()
    
if __name__ == '__main__':
    #test_AdHocCLI_run()
    c = AdHocCLI('win_ping')
    c.get_opt_parser()

# Generated at 2022-06-24 17:38:40.865829
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # AdHocCLI instance created with arguments
    str_0 = ':&'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # AssertionError raised
    with pytest.raises(AssertionError):
        var_0 = ad_hoc_c_l_i_0.run()

    return


# Generated at 2022-06-24 17:38:45.249129
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
    except TypeError as err:
        raise AssertionError(err)

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:38:53.899801
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = '-m ping -a "data=Test data"'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    var_1 = ad_hoc_c_l_i_0.init_parser()
    var_2 = ad_hoc_c_l_i_0.post_process_args(var_0)


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:38:55.366195
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    var_1 = AdHocCLI()


# Generated at 2022-06-24 17:38:57.304414
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI_run()
    print("Everything passed")

# Generated at 2022-06-24 17:40:05.703661
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    for i in range(3):
        test_case_0()

# Generated at 2022-06-24 17:40:07.821640
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI(';')


# Generated at 2022-06-24 17:40:08.735434
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:40:13.708315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ':&'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:22.010039
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        ad_hoc_c_l_i_0 = AdHocCLI(str)
    except Exception as var_0:
        assert False
    C.DEFAULT_STDOUT_CALLBACK = 'default'
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = True
    C.DEFAULT_MODULE_NAME = 'setup'
    C.DEFAULT_MODULE_ARGS = 'filter=ansible_mounts'
    C.CALLBACKS_ENABLED.append('tree')
    C.TREE_DIR = "/./outputs/tree"
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:24.605279
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = ':-@'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    var_1 = ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:40:25.378908
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:40:30.900268
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('--module-name', ':&')
    with pytest.raises(AnsibleError):
        var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:33.389704
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except Exception as e:
        print('error: %s' % str(e))


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:38.042965
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ':&'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()
