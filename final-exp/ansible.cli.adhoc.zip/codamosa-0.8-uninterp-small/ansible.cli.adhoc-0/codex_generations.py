

# Generated at 2022-06-24 17:33:40.126836
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


if __name__ == '__main__':
# Unit testing for module ad_hoc_c_l_i
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:33:40.911049
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    assert False


# Generated at 2022-06-24 17:33:46.228610
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    float_0 = -1485.077
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    dict_0 = dict()
    dict_0['module_name'] = 'module_name'
    dict_0['subset'] = 'subset'
    dict_0['module_args'] = 'module_args'
    dict_0['forks'] = -1538
    dict_0['listhosts'] = True
    dict_0['verbosity'] = 5
    dict_0['become'] = True
    dict_0['become_user'] = 'become_user'
    dict_0['conn_pass'] = 'conn_pass'
    dict_0['args'] = 'args'
    expected = dict()

# Generated at 2022-06-24 17:33:57.307376
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_c_l_i_0 = AdHocCLI(10.0)
    ad_hoc_c_l_i_1 = AdHocCLI(float_0)
    numeric_list_0 = []
    numeric_list_1 = [10.0]
    numeric_list_2 = []
    numeric_list_3 = []
    numeric_list_3.append(20.0)
    numeric_list_3.append(10.0)
    numeric_list_3.append(10.0)
    ad_hoc_c_l_i_0.post_process_args(numeric_list_0)
    ad_hoc_c_l_i_0.post_process_args(numeric_list_1)
    ad_hoc_c_l_i

# Generated at 2022-06-24 17:34:02.473965
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=[])
    options = dict()
    options['module_name'] = 'copy'
    options['module_args'] = 'src=/etc/hosts dest=/tmp/hosts'
    options['pattern'] = 'all'
    options['seconds'] = 0
    options['poll_interval'] = 15
   

# Generated at 2022-06-24 17:34:04.540620
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Check if the result is a valid float
    # assert isinstance(float_0, float)
    test_case_0()


# Generated at 2022-06-24 17:34:08.005738
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('')
    host_pattern = 'ansible-2'
    AdHocCLI.run(AdHocCLI(), host_pattern)


# Generated at 2022-06-24 17:34:15.716161
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # try invalid module name
    try:
        adhoc_cli = AdHocCLI(['-m', 'nmod', 'all', '-a', 'a=b'])
        adhoc_cli.run()
    except AnsibleOptionsError:
        pass
    except AnsibleError:
        pass
    except:
        pass
    else:
        assert False

    # try non-existing module
    try:
        adhoc_cli = AdHocCLI(['-m', 'foo_module', 'all', '-a', 'a=b'])
        adhoc_cli.run()
    except AnsibleError:
        pass
    except:
        pass
    else:
        assert False

    # try no module args expected

# Generated at 2022-06-24 17:34:18.383172
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:24.122864
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Setup test
    float_0 = -1590.925
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    
    # Test call
    result = ad_hoc_c_l_i_0.run()

    # Verify test results
    assert isinstance(result, int) == True


# Generated at 2022-06-24 17:34:40.362564
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -1608
    list_0 = [int_0, int_0, int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:46.431142
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -1608
    list_0 = [int_0, int_0, int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:50.629035
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    list_0 = [-5, -5, -5, -5]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(context.CLIARGS)


# Generated at 2022-06-24 17:34:59.866126
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    var_0 = ';'
    ad_hoc_c_l_i_0 = AdHocCLI([var_0])
    var_1 = [var_0]
    ad_hoc_c_l_i_0.post_process_args(var_1)
    ad_hoc_c_l_i_0.run()


if __name__ == "__main__":
    # main()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:06.520668
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    int_0 = -1608
    list_0 = [int_0, int_0, int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    # Adding an assertion here
    assert var_0 == None


# Generated at 2022-06-24 17:35:06.941324
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_0 = []

# Generated at 2022-06-24 17:35:11.338520
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    int_0 = -1608
    list_0 = [int_0, int_0, int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.post_process_args(list_0)


# Generated at 2022-06-24 17:35:17.981379
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -1599
    list_0 = [int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:25.190980
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test case for arg list: ['-a']
    int_0 = -1608
    list_0 = [int_0, int_0, int_0, int_0]
    ad_hoc_c_l_i_0 = AdHocCLI(list_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = var_0.parse_args(['-a'])
    var_2 = ad_hoc_c_l_i_0.post_process_args(var_1)


# Generated at 2022-06-24 17:35:36.608567
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.init_parser()
    arg_0 = ad_hoc_c_l_i_0.ad_hoc_c_l_i_0.add_argument()
    arg_0.dest = 'module_name'
    arg_0.action = 'store'
    arg_0.const = ('', ' ', 'p', '5', '@', 'a', 'Y', 'O', 'w', '{')
    arg_0.default = 'module_name'
    arg_0.required = 0
    arg_0.nargs = '?'
    arg_0.choices = None
    arg_0.help = ''

# Generated at 2022-06-24 17:36:05.265468
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    str_1 = '#'
    str_2 = '5E5'
    str_3 = 'Y.'
    str_4 = 'A<p'
    str_5 = 'c['
    str_6 = 'm'
    str_7 = 'x'
    str_8 = 'Ik'
    str_9 = '+('
    str_10 = ')}'
    str_11 = 'I-'
    str_12 = '5a'
    str_13 = 'A+'
    str_14 = '6'
    str_15 = '-L'
    str_16 = ';p'
    str_17 = 'x'
    str_18 = '<g'
    str_19 = 'L'
    str_20 = 'v,'
   

# Generated at 2022-06-24 17:36:06.796329
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:36:10.943865
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ''
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:16.494462
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '*'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:23.570191
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'a'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)

# Generated at 2022-06-24 17:36:32.578344
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    #
    # Unit test for method run of class AdHocCLI
    #
    """
    ad_hoc_c_l_i_0 = AdHocCLI('/')
    str_0 = to_text('g[2Bhsl5\u007fW\ue8ba+\u00d7\u001cL')
    var_0 = ad_hoc_c_l_i_0.post_process_args(str_0)
    var_1 = ad_hoc_c_l_i_0.init_parser()

# Generated at 2022-06-24 17:36:37.070315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:47.846459
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_0 = '/)'
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    str_0 = '/)'
    ad_hoc_c_l_i_2 = AdHocCLI(str_0)
    str_0 = '/)'
    ad_hoc_c_l_i_3 = AdHocCLI(str_0)
    str_0 = '/)'
    ad_hoc_c_l_i_4 = AdHocCLI(str_0)
    str_0 = '/)'
    ad_hoc_c_l_i_5 = AdHocCLI(str_0)
   

# Generated at 2022-06-24 17:36:52.012490
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:59.172677
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    yaml_0 = 'arg'
    ad_hoc_c_l_i_0 = AdHocCLI(yaml_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:34.774216
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '-'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    test_case_run_1(ad_hoc_c_l_i_0)


# Generated at 2022-06-24 17:37:38.851478
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '('
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    test_case_0()


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:41.497713
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:50.528326
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'O'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    var_1 = ad_hoc_c_l_i_1.run()
    assert var_1 == 0 or var_1 == None, 'Wrong return value: var_1'
    var_2 = ad_hoc_c_l_i_1.run()
    assert var_2 == 0 or var_2 == None, 'Wrong return value: var_2'

# Generated at 2022-06-24 17:37:52.370602
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # # No errors expected
    test_case_0()
    # # Successful completion
    test_case_0()

# Generated at 2022-06-24 17:37:53.541475
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:38:00.543251
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "ad-hoc"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == None

# Generated at 2022-06-24 17:38:01.978164
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:38:03.269896
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True == True


# Generated at 2022-06-24 17:38:09.438901
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '*'
    pattern = str_0
    num_0 = 0
    async_val = num_0
    num_1 = 0
    poll = num_1
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    play_ds = ad_hoc_c_l_i_0._play_ds(pattern, async_val, poll)
    assert play_ds == '''  gather_facts: 'no'
  hosts: '*'
  tasks:
  - action:
      args:
      module: 'debug'
    async_val: 10
    poll: 10
  timeout: 10
name: Ansible Ad-Hoc'''


# Generated at 2022-06-24 17:39:31.510493
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI and set some attributes
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.vault_password_file = ''
    ad_hoc_c_l_i_0.subset = 'subset'
    ad_hoc_c_l_i_0.module_args = 'module_args'
    ad_hoc_c_l_i_0.module_path = 'module_path'
    ad_hoc_c_l_i_0.verbosity = 'verbosity'
    ad_hoc_c_l_i_0.connection = 'connection'
    ad_hoc_c_l_i_0.check

# Generated at 2022-06-24 17:39:32.775363
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:39:35.700234
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_2 = '*'
    ad_hoc_c_l_i_2 = AdHocCLI(str_2)
    var_1 = ad_hoc_c_l_i_2.run()

# Generated at 2022-06-24 17:39:38.710885
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    if var_0 != 0:
        raise Exception('Wrong return value')


# Generated at 2022-06-24 17:39:42.868194
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = '|'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    var_1 = ad_hoc_c_l_i_1.run()
    assert var_1 == 0

# Generated at 2022-06-24 17:39:43.967372
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-24 17:39:46.038316
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 17:39:50.568665
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '\x1e\x7f'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    # test_AdHocCLI_run()
    test_case_0()

# Generated at 2022-06-24 17:40:00.290577
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initialize a variable for the test
    str_0 = '&!0=+xI'
    # Initialize a variable for the test
    str_1 = 'f?t'
    # Initialize a variable for the test
    str_2 = '*`X'
    # Initialize a variable for the test
    str_3 = '\x1b'
    # Initialize a variable for the test
    str_4 = '|'
    # Initialize a variable for the test
    str_5 = '_!O'
    # Initialize a variable for the test
    str_6 = '0-bE'
    # Initialize a variable for the test
    str_7 = 'm>z'
    # Initialize a variable for the test

# Generated at 2022-06-24 17:40:06.550282
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '/)'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
