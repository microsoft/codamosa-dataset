

# Generated at 2022-06-24 17:33:43.419306
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "..'"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:33:46.788954
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:33:51.415773
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:33:55.434022
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "."
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    try:
        ad_hoc_c_l_i_0.run()
    except AnsibleError:
        pass


# Generated at 2022-06-24 17:33:56.682654
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("yen")

# Generated at 2022-06-24 17:33:59.430254
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert (False)

# Generated at 2022-06-24 17:34:04.189187
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    argv = ['ansible', 'localhost', '-m', 'module_name', '-a', 'key=value']
    options = AdHocCLI.parse(argv)
    taskqueue_manager = AdHocCLI.run(options)
    assert taskqueue_manager
    assert taskqueue_manager.inventory
    assert taskqueue_manager.variable_manager

# Generated at 2022-06-24 17:34:06.281946
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    c = AdHocCLI('ansible')
    c.run()

# Generated at 2022-06-24 17:34:10.687409
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Test that the returned result is of type int"""
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert isinstance(ad_hoc_c_l_i_0.run(), int)

# Generated at 2022-06-24 17:34:15.250981
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:34:26.934653
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_0 = ['./ansible-playbook']
    options_0 = ad_hoc_c_l_i_0.parse(args_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:35.465228
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test case 0
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    r = ad_hoc_c_l_i_0.run()
    print(r)

if __name__ == "__main__":
    #test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:39.135833
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI('k')
    is_an_error_0 = ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:34:50.327333
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # method 1 input
    str_1 = "HJ"
    str_2 = 'c'
    boolean_3 = true
    # method 1 test

# Generated at 2022-06-24 17:34:52.805992
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Call method run of class AdHocCLI
    test_case_0()

# Generated at 2022-06-24 17:34:59.795042
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    arg_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(arg_0)

    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:04.164300
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:06.639013
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:35:07.312192
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:35:09.632908
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:21.034353
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:30.428027
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "."
    int_0 = 0
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0.run() == int_0
    str_1 = "./../bin/ansible"
    int_1 = 0
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    assert ad_hoc_c_l_i_1.run() == int_1
    str_2 = "../bin/ansible"
    int_2 = 0
    ad_hoc_c_l_i_2 = AdHocCLI(str_2)
    assert ad_hoc_c_l_i_2.run() == int_2

#

# Generated at 2022-06-24 17:35:32.615190
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(".'8_")
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:35.674046
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI("\"8'.")
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:39.802496
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    arg_1 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(arg_1)

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:43.687504
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:46.201941
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:35:52.068610
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Testcase 0 : ad_hoc_c_l_i_0 = AdHocCLI("8_")
    ad_hoc_c_l_i_0 = AdHocCLI("8_")
    # Testcase 1 : ad_hoc_c_l_i_1 = AdHocCLI("8_")
    ad_hoc_c_l_i_1 = AdHocCLI("8_")
    # Testcase 2 : ad_hoc_c_l_i_2 = AdHocCLI("8_")
    ad_hoc_c_l_i_2 = AdHocCLI("8_")


# Generated at 2022-06-24 17:35:53.824889
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # return for test purposes
    return ad_hoc_c_l_i_0


# Generated at 2022-06-24 17:36:00.413270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    ad_hoc_c_l_i_1.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:36:13.374762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "CJ"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:20.009998
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test case for constructor
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:36:22.252547
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    str_1 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:27.891129
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(1)
    try:
        ad_hoc_c_l_i_0.run()
    except:
        assert()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:29.119462
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
  ad_hoc_c_l_i_0 = AdHocCLI()
  ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:31.633241
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = "A"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0.run() == 0



# Generated at 2022-06-24 17:36:39.638097
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        str_0 = ".'8_"
        ad_hoc_c_l_i_0 = AdHocCLI(str_0)
        ad_hoc_c_l_i_0.run()
    except SystemExit:
        pass

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:42.897579
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = ".'8_"
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:45.165472
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:36:46.283981
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:36:58.355670
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    object_name = ad_hoc_c_l_i.__name__
    assert object_name == 'AdHocCLI'


if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:37:02.487880
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Test: test_AdHocCLI")
    ad_hoc_c_l_i_0 = AdHocCLI()


# Generated at 2022-06-24 17:37:09.446308
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# AdHocCLI.run_hosts

# Generated at 2022-06-24 17:37:14.175620
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    result = ad_hoc_c_l_i_0.run()
    print(result)


# Generated at 2022-06-24 17:37:16.400976
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:20.357251
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:37:23.642396
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Init AdHocCLI from a different Class
    # Force an exception
    ad_hoc_c_l_i_2 = CLI()

test_AdHocCLI()
test_case_0()

# Generated at 2022-06-24 17:37:26.534984
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:37:30.057255
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:37:32.494120
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:37:43.506851
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:54.626065
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initialize a AdHocCLI object
    ad_hoc_c_l_i_1 = AdHocCLI()
    # Initialize a dict variable for options of AdHocCLI
    options_1 = {}

# Generated at 2022-06-24 17:38:01.792133
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Testing constructor of class AdHocCLI")

    try:
        test_case_0()
    except:
         print("Constructor of class AdHocCLI not working")
    else:
         print("Constructor of class AdHocCLI is working")

# Generated at 2022-06-24 17:38:07.219186
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.post_process_args(AdHocCLI().init_parser().parse_args(
        ['--args', 'foo_m=321 foo_n=abc', '-a', 'foo_m=123 foo_n=xyz',
         '-C', '-F', '3', 'localhost']))
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:38:10.578664
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-24 17:38:22.563300
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    args1 = ['-i', 'inventory',
             '-k',
             '-u', 'user',
             '-t', 'target',
             '-e', 'exclude',
             '-c', 'connection',
             '-T', 'timeout',
             '-P', 'poll',
             '--check',
             '--module-name', 'module_name',
             '--module-path', 'module_path',
             '--start-at-task', 'start_at_task',
             '--step',
             '--args', 'module_args',
             ]
    testcase1 = AdHocCLI(args1)
    assert 'inventory' == getattr(testcase1, 'options.inventory')
    assert 'target' == getattr(testcase1, 'options.listhosts')

# Generated at 2022-06-24 17:38:25.426839
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    result = ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:38:28.325989
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Instantiation of object
    ad_hoc_c_l_i_1 = AdHocCLI()
    # Call the method
    ad_hoc_c_l_i_1.run()



# Generated at 2022-06-24 17:38:34.116089
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI(args=None)
    ad_hoc_c_l_i_1 = AdHocCLI(args=['arg_0', 'arg_1', 'arg_2'])


# Generated at 2022-06-24 17:38:38.192422
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    _AdHocCLI = AdHocCLI()
    assert _AdHocCLI
    assert isinstance(_AdHocCLI, AdHocCLI)

# Generated at 2022-06-24 17:39:00.928617
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:39:03.373943
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_1 = AdHocCLI()


# Generated at 2022-06-24 17:39:06.737470
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.__class__.__name__ == 'AdHocCLI'


# Generated at 2022-06-24 17:39:09.127361
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test case 0
    ad_hoc_c_l_i_0 = AdHocCLI()

# Generated at 2022-06-24 17:39:14.208459
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:39:15.852232
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    pass

# Generated at 2022-06-24 17:39:17.617181
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()


# Generated at 2022-06-24 17:39:22.390205
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Arrange
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:39:26.360065
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_cli_run_0 = AdHocCLI()
    #
    # Create and execute the single task playbook.
    #
#    ad_hoc_cli_run_0.run()


# Generated at 2022-06-24 17:39:37.111549
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Setup test
    test_AdHocCLI_run_cliargs = dict()
    test_AdHocCLI_run_cliargs['module_name'] = 'setup'
    test_AdHocCLI_run_cliargs['module_args'] = '#'
    test_AdHocCLI_run_cliargs['args'] = 'test_AdHocCLI_run_hosts'
    context.CLIARGS = test_AdHocCLI_run_cliargs

    test_AdHocCLI_run_hosts = """
[test_AdHocCLI_run_hosts]
test_AdHocCLI_run_host1
test_AdHocCLI_run_host2
"""

# Generated at 2022-06-24 17:40:25.196907
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    if ad_hoc_c_l_i_0.run() == 0:
        pass
    else:
        raise AssertionError('test_AdHocCLI_run() returned not zero')

test_case_0()

# Generated at 2022-06-24 17:40:34.979929
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create a dummy inventory
    inventory = Inventory()
    host_one = Host(name='localhost')
    host_one.set_variable("var_1", "one")
    inventory.add_host(host_one)

    # create a dummy module
    def dummy_module(self, connection):
        pass

    # load it into the module framework
    from ansible import constants as C
    C.DEFAULT_MODULE_NAME = 'test'
    C.DEFAULT_MODULE_PATH = None
    C.DEFAULT_MODULE_LANG = 'py'
    C.DEFAULT_KEEP_REMOTE_FILES = False
    module_loader.add_directory(os.getcwd())
    module_loader._modules["test"] = (dummy_module, None)

    # fake options

# Generated at 2022-06-24 17:40:36.289312
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:40:41.566486
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
   # Define here environment variables required.
   # Load and run Ansible
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:40:48.865490
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    display_1 = Display()
    display_1.verbosity = 2

# Generated at 2022-06-24 17:40:50.886109
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc = AdHocCLI()
    assert ad_hoc is not None

# Generated at 2022-06-24 17:40:53.041915
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:40:56.736554
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()

    context.CLIARGS['module_name'] = 'command'
    context.CLIARGS['module_args'] = 'ls -l'
    context.CLIARGS['module_name'] = 'command'
    context.CLIARGS['module_args'] = 'ls -l'
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:41:02.902949
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:41:06.492875
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    result = test_case_0()
    assert result == None, "Return type is " + str(type(result)) + " which is not None"

from inspect import getfullargspec
# unit test for the init_parser function

# Generated at 2022-06-24 17:42:04.875815
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        assert type(AdHocCLI()) == AdHocCLI
    except AssertionError:
        raise AssertionError('Test case  test_case_0() failed: AssertionError: assert type(AdHocCLI()) == AdHocCLI failed')

# Generated at 2022-06-24 17:42:08.773291
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    try:
        ad_hoc_c_l_i.run()
    except:
        assert False


# Generated at 2022-06-24 17:42:11.548495
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()

# vim: tabstop=2 softtabstop=2

# Generated at 2022-06-24 17:42:14.914199
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # ad_hoc_c_l_i_0 = AdHocCLI()
    assert True


# Generated at 2022-06-24 17:42:19.697673
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()

    # Test run without parameters
    assert ad_hoc_c_l_i.run() != 0

    # Test run with parameters
    assert ad_hoc_c_l_i.run(module_name='ping', module_args='', inventory=['localhost']) == 0


# Generated at 2022-06-24 17:42:25.748439
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    exception_thrown = False
    try:
        ad_hoc_c_l_i_0.run()
    except Exception:
        exception_thrown = True
    assert exception_thrown == False



# Generated at 2022-06-24 17:42:29.393217
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:42:34.015781
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:42:39.029382
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:42:43.105060
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Unit test for function _play_ds() AdHocCLI.run() method
    pattern = 'test_pattern'
    async_val = True
    poll = True
    result = ad_hoc_c_l_i_0._play_ds(pattern, async_val, poll)
    assert result == {'name': 'Ansible Ad-Hoc', 'gather_facts': 'no', 'tasks': [{'timeout': None, 'async_val': True, 'poll': True, 'action': {'module': 'setup', 'args': {}}}], 'hosts': 'test_pattern'}
