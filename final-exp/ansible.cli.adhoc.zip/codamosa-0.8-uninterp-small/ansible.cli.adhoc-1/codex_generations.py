

# Generated at 2022-06-24 17:33:53.140707
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'q3[e'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_0 = 's=fT'
    str_1 = 'n_J('
    ad_hoc_c_l_i_0.run(str_0, str_1)


# Generated at 2022-06-24 17:33:58.927126
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    arg_0 = 'P{WKQ'
    ad_hoc_c_l_i_0 = AdHocCLI(arg_0)
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:02.286088
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'L{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:08.832913
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI('L{cXJ')
    ad_hoc_c_l_i_0.run()

    # callable
    try:
        result = ad_hoc_c_l_i_0.post_process_args(None)
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"


# Generated at 2022-06-24 17:34:12.708416
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'F{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:17.924604
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'L{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:20.421151
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'L{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

# Generated at 2022-06-24 17:34:23.912125
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'L{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:27.379457
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_origin = sys.argv[1:]
    args_copy = args_origin.copy()
    test_case_0()
    assert sys.argv[1:] == args_copy, 'test_ad_hoc-test_AdHocCLI_run#0 failed!'

test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:34.931230
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '$4#4z'
    str_1 = 'L{cXJ'
    ad_hoc_c_l_i_0 = AdHocCLI(str_1)
    int_1 = ad_hoc_c_l_i_0.run(str_0)
    assert int_1 == 0


# Generated at 2022-06-24 17:34:52.677658
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:34:57.838601
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    CLIARGS = {}
    context.CLIARGS = CLIARGS
    ans = AdHocCLI()
    ans.run()
    assert ans.run() == 0

# Generated at 2022-06-24 17:34:58.951276
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = 1



# Generated at 2022-06-24 17:35:00.311631
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-24 17:35:04.101034
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()


if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:07.470952
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print("\n=== Running test case 0 ===")
    print("test_AdHocCLI_run()")
    test_case_0()

# Runs the unit tests when module is called directly
if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:11.086680
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args_0 = [
        'ansible',
    ]

    # Instantiation and call function 'run'
    # Note how cliargs is modified in this function.
    # This can create strange error messages in the tests.
    with pytest.raises(AnsibleOptionsError):
        AdHocCLI(args_0).run()

# Generated at 2022-06-24 17:35:14.027629
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    # Set in this file
    # cli.run()



# Generated at 2022-06-24 17:35:18.340915
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    my_AdHocCLI = AdHocCLI()
    my_AdHocCLI.run()


if __name__ == '__main__':
    my_AdHocCLI = AdHocCLI()
    my_AdHocCLI.run()

# Generated at 2022-06-24 17:35:20.638945
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli.init_parser()
    args = ['--list-hosts']
    cli.parse(args)
    cli.run()

# Generated at 2022-06-24 17:35:31.203847
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:36.296764
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    m_0 = ModuleName()
    ad_hoc_c_l_i_0 = AdHocCLI()
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:35:41.678101
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1726.13695
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:47.202513
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()
    var_1 = 1334.15012
    print(ad_hoc_c_l_i_0._tqm._stats.dark)
    print(ad_hoc_c_l_i_0._tqm._stats.processed)


# Generated at 2022-06-24 17:35:48.564702
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:35:51.770672
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(0.5)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:56.650276
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1037.1225
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(float_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:03.524710
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    Test_code = """ 
    Test_code = '''
    myobj = AdHocCLI.AdHocCLI()
    myobj.run()
    '''
    return Test_code
    """
    Test_code = '''
    myobj = AdHocCLI.AdHocCLI()
    myobj.run()
    '''
    return Test_code

import os
import sys
import unittest


# Generated at 2022-06-24 17:36:12.585747
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # We do not do anything in method run
    # All class AdHocCLI really does is
    #  Directs input to CLI method run
    #  So, just test that one.
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    return_val = ad_hoc_c_l_i_0.run()
    assert return_val == 0

# Generated at 2022-06-24 17:36:16.566094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 0.5546934
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    int_0 = ad_hoc_c_l_i_0.run()
    assert(int_0 == 0)


# Generated at 2022-06-24 17:36:34.873153
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)

    assert ad_hoc_c_l_i_0 != None



# Generated at 2022-06-24 17:36:41.940561
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_1 = 1334.15012
    ad_hoc_c_l_i_1 = AdHocCLI(float_1)
    ad_hoc_c_l_i_1.init_parser()
    ad_hoc_c_l_i_1.post_process_args()
    var_1 = ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:46.834563
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 0.352185
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.post_process_args(float_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:52.485418
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1.93933
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    float_0 = ad_hoc_c_l_i_0.run()
    assert float_0 == None, 'Expected None, but got %s' % float_0


# Generated at 2022-06-24 17:36:54.662744
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI(0.83911) # TODO: Should test for correct parameters for constructor

# Generated at 2022-06-24 17:36:56.739977
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    var_1 = AdHocCLI(1334.15012)
    var_2 = var_1.run()
    
test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:03.391030
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:09.838353
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:13.612605
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:37:18.715144
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
    except Exception as e:
        print(e.args)
        print(repr(e))

    # Test for method run of class AdHocCLI


# Generated at 2022-06-24 17:37:51.829435
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    float_0 = 1334.15012
    ad_hoc_c_l_i_0.init_parser()
    int_0 = ad_hoc_c_l_i_0.run()
    assert int_0 == 0


if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-24 17:37:53.973850
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)


# Generated at 2022-06-24 17:37:59.953979
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:04.396757
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_1 = 1334.15012
    ad_hoc_c_l_i_1 = AdHocCLI(float_1)
    var_1 = ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:38:13.344309
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1211.111
    ad_hoc_c_l_i_2 = AdHocCLI(float_0)
    var_2 = ad_hoc_c_l_i_2.init_parser()
    var_3 = ad_hoc_c_l_i_2.post_process_args(var_2)
    var_4 = ad_hoc_c_l_i_2.run()
    assert var_4 == 0

# Generated at 2022-06-24 17:38:15.425879
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('Test: run of class AdHocCLI')



# Generated at 2022-06-24 17:38:21.720163
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pattern = 'host list'
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.post_process_args(pattern)

# Generated at 2022-06-24 17:38:26.512886
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1337.15532
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:38:32.901108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.post_process_args(var_0)
    var_2 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:39.076224
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()


if __name__ == '__main__':
    test_AdHocCLI()
    test_case_0()

# Generated at 2022-06-24 17:39:35.836315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
  float_0 = 0.2
  try:
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()
  except Exception as exc:
    print(exc)

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:37.110743
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

test_AdHocCLI()

# Generated at 2022-06-24 17:39:40.504897
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1323.656
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert (var_0 == False or var_0 == True)

# Generated at 2022-06-24 17:39:42.284788
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1351.63811
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.run()

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:47.546687
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    char_0 = "AdHocCLI"
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    int_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:54.380198
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(var_0)
    return 0

# Generated at 2022-06-24 17:39:58.470755
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 1334.15012
    ad_hoc_c_l_i_1 = AdHocCLI(float_0)
    test_case_0()
    res_0 = ad_hoc_c_l_i_1.run()
    assert res_0 == 0

# Generated at 2022-06-24 17:40:05.810671
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_0 = 1334.15012
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    assert ad_hoc_c_l_i_0.parser == None

# Generated at 2022-06-24 17:40:10.610078
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 716.14
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)

    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit as e:
        assert(e.code == 0)
    except Exception as e:
        raise e


# Generated at 2022-06-24 17:40:15.797327
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI()
#     assert ad_hoc_c_l_i_0
