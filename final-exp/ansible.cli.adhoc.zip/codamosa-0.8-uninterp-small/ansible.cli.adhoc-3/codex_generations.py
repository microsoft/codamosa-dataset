

# Generated at 2022-06-24 17:33:40.851304
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:33:42.913762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = 0.0
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)

    ad_hoc_c_l_i_0.run()  # No exception should be thrown here


# Generated at 2022-06-24 17:33:52.277168
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    float_var_0 = 1743.0
    int_var_1 = -1
    str_var_2 = 'Ad-Hoc'
    ad_hoc_c_l_i_var_0 = AdHocCLI(float_var_0)
    ad_hoc_c_l_i_var_0.init_parser(int_var_1, str_var_2)
    ad_hoc_c_l_i_var_0.init_parser()


# Generated at 2022-06-24 17:33:53.691490
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -32
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    test_case_0()


# Generated at 2022-06-24 17:34:04.853496
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_c_l_i_0 = AdHocCLI(499.0)
    str_0 = "u"
    str_1 = "r"
    str_2 = "t"
    str_3 = "h"
    str_4 = " "
    str_5 = "p"
    str_6 = "a"
    str_7 = "t"
    str_8 = "t"
    str_9 = "e"
    str_10 = "r"
    str_11 = "n"
    str_12 = ":"
    str_13 = " "
    str_14 = "a"
    str_15 = "l"
    str_16 = "l"
    str_17 = " "
    str_18 = "h"

# Generated at 2022-06-24 17:34:09.765701
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:14.318699
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    float_0 = -2873.9
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    # TODO: Test possible combination of AdHocCLI.post_process_args
    assert False


# Generated at 2022-06-24 17:34:18.306542
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import sys
    _main = sys.modules['__main__']
    _main.__package__ = 'ansible.builtin'
    import __main__ as main
    main.display = Display()
    test_case_0()

# Generated at 2022-06-24 17:34:19.020619
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert True

# Generated at 2022-06-24 17:34:21.924706
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    float_0 = -2557.78
    ad_hoc_c_l_i_0 = AdHocCLI(float_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:37.937266
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:39.645515
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Testing commit 62b74f71e150f2d1668b33f4dd4ea4d9e5992f55 

# Generated at 2022-06-24 17:34:40.352675
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:34:41.265248
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


# Generated at 2022-06-24 17:34:46.761048
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    assert isinstance(ad_hoc_c_l_i_0, AdHocCLI)


# Generated at 2022-06-24 17:34:49.849974
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:58.254146
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    a_d_hoc_c_l_i_0 = AdHocCLI()
    a_d_hoc_c_l_i_0.init_parser()
    a_d_hoc_c_l_i_0.post_process_args()
    a_d_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:08.978049
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    int_0 = -222
    var_1 = context.CLIARGS
    var_2 = context.CLIARGS
    var_2['module_name'] = "debug"
    var_1['module_name'] = "debug"
    var_1 = context.CLIARGS
    var_2 = context.CLIARGS
    var_1['module_args'] = "msg=hello"
    var_2['module_args'] = "msg=hello"
    var_1 = context.CLIARGS
    var_2 = context.CLIARGS
    var_1['args'] = "test_host"

# Generated at 2022-06-24 17:35:11.275091
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Call the constructor of class AdHocCLI
    # The test passes if the constructor has no exceptions
    test_case_0()


if __name__ == '__main__':
    # Unit test for class AdHocCLI
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:15.620895
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
#
# The following tests are for cases where errors are thrown
#


# Generated at 2022-06-24 17:35:31.948077
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:35:36.404686
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    int_1 = 1
    try:
        test_case_0()
    except Exception:
        print('Exception: ', Exception)

    return

# Generated at 2022-06-24 17:35:42.805129
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object to test
    AdHocCLI_obj = AdHocCLI(sys.argv)
    AdHocCLI_obj.post_process_args(sys.argv)
    AdHocCLI_obj.run()


# Generated at 2022-06-24 17:35:45.409669
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print("Entering TestCase for method run")
    test_case_0()
    print("Exiting TestCase for method run")


# Generated at 2022-06-24 17:35:48.355774
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_3 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_3.run()


# Generated at 2022-06-24 17:35:51.782750
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    var_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(var_0)
    var_3 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:55.846802
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    assert ad_hoc_c_l_i_0.__class__ == AdHocCLI

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-24 17:36:06.367860
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:36:12.486048
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Test case for method run of class AdHocCLI

# Generated at 2022-06-24 17:36:15.194093
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:37:09.166876
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:37:15.137222
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    # Verify that the following call fails
    try:
        ad_hoc_c_l_i_0.run()
    except BaseException as var_0:
        print(var_0)


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:23.423748
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # loading the input test data
    import os
    data_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../data/test_input_AdHocCLI_run.json')
    import json
    data_in = json.load(open(data_file_path))
    int_0 = data_in['int_0']
    from ansible.utils import context

# Generated at 2022-06-24 17:37:26.319362
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()
    if var_0 == 0:
        print(0)
    else:
        print(1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:37:31.925877
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test setup
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)

    var_0 = -222
    var_1 = ad_hoc_c_l_i_0.run()
    assert var_0 != var_1


# Generated at 2022-06-24 17:37:35.151050
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:36.122001
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:37:40.544822
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = 0
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()


test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:41.686805
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:37:47.663170
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Data tests: 1
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:39:31.189254
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert(var_0 == 0)



# Generated at 2022-06-24 17:39:35.022023
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:40.156694
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create an instance of class AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI()

    # Run method of class AdHocCLI
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:39:47.678828
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    int_0 = 88
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    int_1 = 44
    ad_hoc_c_l_i_0.init_parser(int_1)
    int_2 = 1
    ad_hoc_c_l_i_0.post_process_args(int_2)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:39:56.855461
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import mock

    # command line arguments as input
    sys.argv = ['-a', 'ping', 'ansible.cfg', ]

    mock.patch('ansible.cli.adhoc.CLI.post_process_args', side_effect=test_case_0).start()

    # Call the method under test
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

    # Restore the patched methods
    mock.patch.stopall()


# Generated at 2022-06-24 17:39:59.285526
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(15)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:40:05.927443
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()

test_case_0()

# Generated at 2022-06-24 17:40:10.422865
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    int_0 = -222
    ad_hoc_c_l_i_0 = AdHocCLI(int_0)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:40:15.612957
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        test_case_0()
    except Exception as exp:
        assert False, 'AdHocCLI.run raised exception ' + str(exp)

# Generated at 2022-06-24 17:40:19.011315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI_run()