

# Generated at 2022-06-24 17:33:51.748720
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    str_0 = '%p/\x0bY\n\x11\x1f\x0e\x0b'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    options_0 = ad_hoc_c_l_i_0.options
    options_0.accelerate = 'accelerate_0'
    options_0.accelerate_ipv6 = 'accelerate_ipv6_0'
    options_0.become = 'become_0'
    options_0.become_ask_pass = 'become_ask_pass_0'
    options_0.become_method = 'become_method_0'
    options_0.become_user = 'become_user_0'
    options_

# Generated at 2022-06-24 17:33:53.594160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:34:03.281028
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pattern_0 = '192.168.1.1-192.168.1.10,192.168.2.1-192.168.2.10,192.168.3.1'
    async_val_0 = context.CLIARGS['seconds']
    poll_0 = context.CLIARGS['poll_interval']
    ad_hoc_c_l_i_1 = AdHocCLI(None)
    ad_hoc_c_l_i_1.run()
    _play_ds_0 = ad_hoc_c_l_i_1._play_ds(pattern_0, async_val_0, poll_0)

# Generated at 2022-06-24 17:34:08.344899
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'x jc{~X|W`_hZ$q3nd'
    str_2 = '&sA]Rd\x1eV)\x1fW\x12Qd*\x05\x0e\x20\x1c)0\x1a!\n\x1a\x1d+\x1f\x1a\x18'
    str_3 = 'xi;2\r_J\x0cGm1~\x1a@'

# Generated at 2022-06-24 17:34:09.618370
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:12.348998
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:34:15.886924
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    str_0 = '[1,2,3]'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    obj_0 = ad_hoc_c_l_i_0.post_process_args(ad_hoc_c_l_i_0)
    str_1 = repr(obj_0)
    str_2 = '[1, 2, 3]'
    assert str_1 == str_2


# Generated at 2022-06-24 17:34:24.467293
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'x'
    str_1 = '\x7f\x89\x19\x99\x11\xb7'
    str_2 = ';'

# Generated at 2022-06-24 17:34:29.014394
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'YBvsykce?'
    ad_hoc_c_l_i_0.init_parser(str_1)

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:36.381696
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(['-m', 'copy', '-a', 'src=/tmp/test_dir dest=/tmp/test_dir_copy', '-k', '-u', 'vagrant', 'myHost'])
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:56.352345
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:00.942071
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:02.451061
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# End of file

# Generated at 2022-06-24 17:35:11.393072
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:35:11.886041
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert 1

# Generated at 2022-06-24 17:35:13.347498
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:35:21.384808
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '\x1f\x0f\x19\x15\x00\x0b\x0f\x1c\x0b\x1f\x0f\x0c\x0f\x00\x1e\x1c'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

    try:
        ad_hoc_c_l_i_0.run()
    except AnsibleError as err:
        assert(err.message == 'No argument passed to expect module (did you mean to run ansible-playbook?)')

# Generated at 2022-06-24 17:35:26.995221
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:37.347383
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    str_0 = 'J.\t\x00\x0b\x06\t\n\t\x02\x0bC!\x0b'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

    ad_hoc_c_l_i_0.options = None
    ad_hoc_c_l_i_0.dir_tree = None
    ad_hoc_c_l_i_0.dir_tree = None
    ad_hoc_c_l_i_0.dir_tree = None
    ad_hoc_c_l_i_0.callback = None
    ad_hoc_c_l_i_0.callback = None
    ad_hoc_c_l_i_0.callback = None
   

# Generated at 2022-06-24 17:35:48.637783
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'mi#\x0b\\Q\rgWG+S+WVg2C:'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Calling run() with clean_reload=False is not supported
    # with ad-hoc CLI
    # Calling run() with module_paths=None is not supported
    # with ad-hoc CLI
    # Calling run() with forks=None is not supported
    # with ad-hoc CLI
    # Calling run() with inventory=None is not supported
    # with ad-hoc CLI
    # Calling run() with subset=None is not supported
    # with ad-hoc CLI
    # Calling run() with tags=None is not supported
    # with ad-hoc CLI
    # Calling run() with skip_

# Generated at 2022-06-24 17:36:05.891407
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cmd = 'ansible -m ping localhost -a "data=hello"'
    parser = AdHocCLI(cmd.split())
    options = parser.parse()
    options.module_name = 'ping'
    options.module_args = 'data=hello'
    options.subset = 'localhost'
    options.one_line = True
    options.check = True
    options.diff = True
    options.listhosts = False
    options.syntax = False
    options.sudo = False
    options.sudo_user = None
    options.ask_sudo_pass = False
    options.ask_su_pass = False
    options.verbosity = 0
    options.connection = 'smart'
    options.timeout = 10
    options.remote_user = 'root'
    options.remote_pass = None
    options

# Generated at 2022-06-24 17:36:08.533137
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()
    pass

test_AdHocCLI()

# Generated at 2022-06-24 17:36:13.949347
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = False
    try:
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    except Exception as e:
        print("Exception caught: " + str(e))
    else:
        print("No exception caught.")

# Generated at 2022-06-24 17:36:22.045464
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.parse()
    ad_hoc_c_l_i_0.options = ad_hoc_c_l_i_0.post_process_args(ad_hoc_c_l_i_0.options)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:28.905370
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Setting up object
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    # Calling method run of the class AdHocCLI on object ad_hoc_c_l_i_0
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:30.649330
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Check that result is the expected type
    assert isinstance(AdHocCLI.run(AdHocCLI), int)

# Generated at 2022-06-24 17:36:38.924160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_1 = True
    var_1 = ad_hoc_c_l_i_0.post_process_args(bool_1)
    bool_2 = True
    var_2 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:42.455753
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_1 = ad_hoc_c_l_i_0.run()
    assert var_1 == 0

# Generated at 2022-06-24 17:36:49.370607
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    for _ in range(100):
        # Variable assignment
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        var_0 = test_case_0
        var_1 = ad_hoc_c_l_i_0.run()
        if var_0:
            var_1 = ad_hoc_c_l_i_0.init_parser()

# Generated at 2022-06-24 17:36:52.171473
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-24 17:37:16.253951
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = False
    AdHocCLI_obj_0 = AdHocCLI(bool_0)
    AdHocCLI_obj_0.init_parser()

    if AdHocCLI_obj_0.run() is None:
        print("Run test returned None")
    else:
        print("Run test returned "+ str(AdHocCLI_obj_0.run()))

if __name__ == '__main__':
    AdHocCLI(False).run()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:25.459962
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    assert var_0 is None

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI()

# Generated at 2022-06-24 17:37:32.479661
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(True)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.options = context.CLIARGS
    print("\n=== ansible ad-hoc ===\n")
    var_1 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:34.739768
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    add_class_instance = AdHocCLI()
    # insert your code here
    assert 0 == 0



# Generated at 2022-06-24 17:37:43.820510
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # ad_hoc_c_l_i_0 is an object of class AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI()
    bool_0 = True
    var_0 = ad_hoc_c_l_i_0.init_parser(bool_0)
    var_1 = ad_hoc_c_l_i_0.run()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "test_case_0":
            test_case_0()
        if sys.argv[1] == "test_AdHocCLI_run":
            test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:47.421146
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert ad_hoc_c_l_i_0



# Generated at 2022-06-24 17:37:51.145067
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()

    assert var_0 == 0

# Generated at 2022-06-24 17:37:56.984428
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of arguments
    # Define the value of a argument
    arguments_0 = C.CLIARGS
    arguments_0['args'] = 'fc7VU'
    # Assign argument values
    context.CLIARGS = arguments_0
    pass

if __name__ == '__main__':
    # Initialise a test run for method run of class AdHocCLI
    test_AdHocCLI_run()
    # Run tests
    test_case_0()

# Generated at 2022-06-24 17:37:59.383245
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # Invoke method
    int_0 = ad_hoc_c_l_i_0.run()

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:04.301374
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert ad_hoc_c_l_i_0 is not None, 'test_case_1:test_AdHocCLI'


# Generated at 2022-06-24 17:38:40.263172
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:42.617248
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:38:49.042107
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.run()
    assert var_0 == None

if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:58.481802
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create an options parser for bin/ansible
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    # handle password prompts
    sshpass_0 = None
    becomepass_0 = None
    var_0 = ad_hoc_c_l_i_0.ask_passwords()
    # get basic objects
    loader_0 = ad_hoc_c_l_i_0._play_prereqs()
    # get list of hosts to execute against
    hosts_0 = ad_hoc_c_l_i_0.get_host_list(inventory=loader_0[1], subset=loader_0[2], pattern=loader_0[0])


# Generated at 2022-06-24 17:39:03.088461
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Constructs an instance of the AdHocCLI class
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    assert_equals(ad_hoc_c_l_i_0.module_name, 'command')
    assert_equals(ad_hoc_c_l_i_0.module_args, '')

# Generated at 2022-06-24 17:39:07.748197
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_c_l_i_0 = AdHocCLI()
    var_0 = ad_hoc_c_l_i_0.run()
    # print(var_0)
    assert var_0 == 0


# Test method run of class AdHocCLI
test_case_0()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:18.922483
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI(False)

    # one requirement for the run() method is
    # that context.CLIARGS['module_name'] not be in C._ACTION_IMPORT_PLAYBOOK
    # so we will just do a quick test
    try:
        context.CLIARGS['module_name'] = 'include_role'
        ad_hoc_c_l_i_0.run()
    except AnsibleOptionsError as error:
        assert( 'is not a valid action for ad-hoc commands' in error.message)
    except SystemExit as error:
        assert( 'is not a valid action for ad-hoc commands' in str(error))

    context.CLIARGS['module_name'] = 'shell'
    ad_hoc_c_

# Generated at 2022-06-24 17:39:28.060750
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        ad_hoc_c_l_i_0.init_parser()
        assert False
    except:
        pass
    try:
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        ad_hoc_c_l_i_0.init_parser()
        assert False
    except:
        pass


# Generated at 2022-06-24 17:39:32.715591
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.post_process_args(None)
    return_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:39:35.131065
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print ("Start to test AdHocCLI_run()")
    obj = AdHocCLI()
    obj.run()

# Generated at 2022-06-24 17:40:57.634019
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    def test_case_1():
        bool_0 = True
        ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
        var_0 = ad_hoc_c_l_i_0.init_parser()


# Generated at 2022-06-24 17:41:02.960223
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # var_0 = ad_hoc_c_l_i_0.init_parser()


# Generated at 2022-06-24 17:41:04.226861
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)

# Generated at 2022-06-24 17:41:08.449922
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    # ad_hoc_c_l_i_0.run()


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:41:22.800233
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.parsing.splitter import parse_kv
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    global display
    display = Display()

    display.verbosity = 3
    ad_hoc_c_l_i_0 = AdHocCLI()


# Generated at 2022-06-24 17:41:29.573709
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Testing constructor of class AdHocCLI")
    ad_hoc_c_l_i_0 = AdHocCLI()
    #ad_hoc_c_l_i_0 = AdHocCLI('/usr/bin/ansible', '/etc/ansible/ansible.cfg')
    #ad_hoc_c_l_i_0 = AdHocCLI('/usr/bin/ansible', '/etc/ansible/ansible.cfg', '/usr/share/ansible')



# Generated at 2022-06-24 17:41:33.490484
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:41:34.727478
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:41:39.530969
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    bool_0 = ad_hoc_c_l_i_0.run()
    assert bool_0 == False


# Generated at 2022-06-24 17:41:46.770403
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bool_0 = True
    ad_hoc_c_l_i_0 = AdHocCLI(bool_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.post_process_args()
    var_0 = ad_hoc_c_l_i_0.run()