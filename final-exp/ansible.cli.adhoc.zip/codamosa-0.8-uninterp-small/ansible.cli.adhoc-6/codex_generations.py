

# Generated at 2022-06-24 17:33:43.540280
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    sample_play_ds = {
        'hosts': 'all',
        'name': 'test',
        'tasks': [
            {
                'action': {
                    'args': {},
                    'module': 'copy',
                    'name': 'copy'
                },
                'async_val': None,
                'poll': None,
                'register': 'copy'
            }
        ]
    }
    inventory = 'hosts'
    playbook = Playbook(loader)
    playbook._entries.append(play)
    playbook._file_name = '__adhoc_playbook__'
    passwords = {'conn_pass': '', 'become_pass': ''}

# Generated at 2022-06-24 17:33:51.289362
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:33:52.356939
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert test_case_0() == None, """Constructor for class `AdHocCLI` should return None"""

# Generated at 2022-06-24 17:33:57.097003
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_1 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)


if __name__ == '__main__':
    test_AdHocCLI()
    test_case_0()

# Generated at 2022-06-24 17:34:00.884771
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit as system_exit_0:
        pass

# Generated at 2022-06-24 17:34:06.890357
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:12.285779
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    assert ad_hoc_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:34:21.538315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    int_0 = ad_hoc_c_l_i_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 17:34:29.213787
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x8d\xad\xb4\x0c|\xce\x1d)3\x96\xef\x9c\x8f\x1f\xa4\xc7\x8f\xcd\x1c\x07'
    options_0 = {}
    options_0['verbosity'] = 2
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:32.222909
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)

    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:34:46.509373
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)



# Generated at 2022-06-24 17:34:51.250902
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    result = ad_hoc_c_l_i_0.run()

    assert result is None


# Generated at 2022-06-24 17:34:55.818199
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Testing constructor of class AdHocCLI")
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:04.491160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)

    try:
        ad_hoc_c_l_i_0.run()
    except AnsibleOptionsError as ansible_options_error_0:
        bytes_1 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
        ad_hoc_c_l_i_1 = AdHocCLI(bytes_1)
        ad_

# Generated at 2022-06-24 17:35:08.920681
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\xad\xda\x97\xd3\xf7\xfb\x1b\x8b\r\x17%\x97\xf9X\x9e\xee\xa2\xfe\xa8'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:13.285250
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    adhoc_cli_0 = AdHocCLI(bytes_0)
    adhoc_cli_1 = AdHocCLI(bytes_0)
    adhoc_cli_1.run()

# Generated at 2022-06-24 17:35:18.516829
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)


# Generated at 2022-06-24 17:35:19.826537
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_1 = AdHocCLI()


# Generated at 2022-06-24 17:35:25.286732
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    bytes_0 = b'\x17t\x8b\xc9\xd9\x15\xf4\xbd\xe3o\x10B2I\x07\xce\x14\x00'
    ad_hoc_c_l_i_0 = AdHocCLI(bytes_0)
    result = ad_hoc_c_l_i_0.run()
    print(result)


# Generated at 2022-06-24 17:35:28.155437
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test case for AdHocCLI with no parametes
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:43.626666
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i is not None


# Generated at 2022-06-24 17:35:46.484344
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # setup test
    ad_hoc_c_l_i_0 = AdHocCLI()

    # test method
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:49.464386
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Constructing the object of AdHocCLI class
    ad_hoc_c_l_i_0 = AdHocCLI()
    # calling method run
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:35:52.503616
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    # No error should be raised
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:35:54.808842
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    pattern = '*'
    ad_hoc_c_l_i.run(pattern)

# Generated at 2022-06-24 17:35:58.440721
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:02.384870
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.init_parser()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:06.056067
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i is not None

# Generated at 2022-06-24 17:36:09.662812
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()

    # TODO: Use assert_raises when Python 2.7 is dropped
    # with assert_raises(AnsibleOptionsError):
    #     ad_hoc_c_l_i_0.run()
    try:
        ad_hoc_c_l_i_0.run()
    except AnsibleOptionsError as e:
        pass


# Generated at 2022-06-24 17:36:13.035494
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    _ = ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:36:47.377290
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:36:51.122749
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test case with no exception
    TestAdHocCLI = AdHocCLI()
    TestAdHocCLI.run()
    TestAdHocCLI.run()


# Generated at 2022-06-24 17:36:56.850249
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i != None


# Generated at 2022-06-24 17:37:02.661241
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Check when value of loader is None
    obj = AdHocCLI()
    obj._play_prereqs = lambda : (None, None, None)
    obj._tqm = None
    obj.run()

test_AdHocCLI_run()

# Generated at 2022-06-24 17:37:12.650879
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Define test host & group vars
    testvars = {
        "ansible_connection": "local",
        "ansible_become_user": "root",
        "ansible_become_method": "",
        "ansible_user": "test",
        "ansible_ssh_pass": "password",
        "ansible_become_pass": "password",
        "ansible_port": 22,
        "ansible_host": "127.0.0.1",
        "ansible_python_interpreter": "/usr/bin/python",
    }

    # Define test hosts
    h = {
        'default': {
            'hosts': [
                'test_host',
            ],
        },
    }

    i = Inventory(loader=DataLoader())
    i.add

# Generated at 2022-06-24 17:37:13.935662
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:37:22.722196
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    options = C.config.Options()
    options.module_name = 'command'
    options.module_args = 'uptime'
    options.module_options_for_help = ['command']
    options.subset = 'all'
    options.listhosts = False
    options.ask_pass = False
    options.ask_sudo_pass = False
    options.ask_su_pass = False
    options.ask_vault_pass = False
    options.ask_private_key_pass = False
    options.verbosity = 0
    options.one_line = False
    options.seconds = 10
    options.poll_interval = 15
    options.check = False
    options.syntax = False
    options.connection = 'smart'
    options.timeout = 10
    options.ssh_common_args = None


# Generated at 2022-06-24 17:37:29.596703
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()
    ad_hoc_c_l_i.run() # Run twice so that unit test passes the second time

# Generated at 2022-06-24 17:37:35.854274
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()

    # Assigning values to the following variables:
    pattern = ""
    async_val = ""
    poll = ""

    # Calling _play_ds method
    # Method to test: _play_ds(self, pattern, async_val, poll)
    # TODO: Check how to replace the parameter values here
    ad_hoc_c_l_i_0._play_ds(pattern, async_val, poll)

    ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:37:37.080021
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:38:12.015946
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()


# Generated at 2022-06-24 17:38:16.003628
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:38:24.591158
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''

    # Make mocked args

# Generated at 2022-06-24 17:38:31.660279
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        test_case_0()
        test_case_1()
    except Exception as ex:
        if ex.__class__.__name__ == 'AttributeError' or ex.__class__.__name__ == 'TypeError' or ex.__class__.__name__ == 'NameError' or ex.__class__.__name__ == 'ValueError':
            print(ex.__class__.__name__)
            print(ex)
        else:
            raise ex

if __name__ == "__main__":
    try:
        test_AdHocCLI()
    except Exception as e:
        raise e

# Generated at 2022-06-24 17:38:33.784937
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:38:34.501584
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoccli = AdHocCLI()

# Generated at 2022-06-24 17:38:37.140398
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.run() == 0


# Generated at 2022-06-24 17:38:39.759744
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    assert ad_hoc_c_l_i_1.run() is None


# Generated at 2022-06-24 17:38:42.086801
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()

    assert ad_hoc_c_l_i


# Generated at 2022-06-24 17:38:49.164669
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:39:34.347231
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    print('add-hoc run test')
    ad_hoc_c_l_i_1.run()


if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:39.031260
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert(ad_hoc_c_l_i != None)    
    

# Generated at 2022-06-24 17:39:43.961175
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:39:49.112604
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create AdHocCLI instance
    ad_hoc_c_l_i_1 = AdHocCLI()

    # Set instance attribute 'parser'
    ad_hoc_c_l_i_1.parser = None

    # Set instance attribute 'args'
    ad_hoc_c_l_i_1.args = None

    # Set instance attribute 'subset'
    ad_hoc_c_l_i_1.subset = None

    # Set instance attribute 'subset_pattern'
    ad_hoc_c_l_i_1.subset_pattern = None

    # TODO: Create test for method run of class AdHocCLI to test invocation of callback
    success, msg = ad_hoc_c_l_i_1.run()
    assert success == 0


# Generated at 2022-06-24 17:39:52.898203
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert isinstance(ad_hoc_c_l_i, AdHocCLI)


# Generated at 2022-06-24 17:39:54.817225
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_1 = AdHocCLI()


# Generated at 2022-06-24 17:40:01.699943
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:40:06.278023
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create and execute the single task playbook
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:40:09.868044
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_1 = AdHocCLI()
    # Test passing a normal string.
    try:
        ad_hoc_c_l_i_1.run()
    except SystemExit:
        pass


# Generated at 2022-06-24 17:40:16.324316
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    ad_hoc_c_l_i = AdHocCLI()

    ad_hoc_c_l_i.parse()
    ad_hoc_c_l_i.post_process_args(ad_hoc_c_l_i.options)

    ad_hoc_c_l_i.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:41:54.477891
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    assert isinstance(ad_hoc_c_l_i_0.run(), int)

# Generated at 2022-06-24 17:42:00.178588
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit as system_exit_0:
        assert system_exit_0.code == 0

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:42:03.355297
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_1 = AdHocCLI()


# Generated at 2022-06-24 17:42:12.640395
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-24 17:42:15.930008
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()


# Generated at 2022-06-24 17:42:17.143990
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()


if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:42:24.767392
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    try:
        response = ad_hoc_c_l_i_0.run()
    except:
        assert(False)


# Generated at 2022-06-24 17:42:30.076443
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    ad_hoc_c_l_i.run()

# Generated at 2022-06-24 17:42:33.043108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i.run() is None

# Generated at 2022-06-24 17:42:35.722886
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i = AdHocCLI()
    assert ad_hoc_c_l_i._tqm is None
