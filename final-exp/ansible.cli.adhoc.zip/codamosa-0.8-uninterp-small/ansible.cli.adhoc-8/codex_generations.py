

# Generated at 2022-06-24 17:33:39.349467
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0.run() == 0

# Generated at 2022-06-24 17:33:48.338988
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with arguments:
    # With arguments: 'os\t04NQs'
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

    ad_hoc_c_l_i_0.run()


# Unit tests for file ansible/plugins/cliconf/__init__.py
# Unit tests for class OutQueue

# Generated at 2022-06-24 17:33:49.738139
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_c_l_i_0 = AdHocCLI('')


# Generated at 2022-06-24 17:33:55.510492
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print("Test start :: test_AdHocCLI")
    str_0 = '04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    print("This is for test :: " + str(ad_hoc_c_l_i_0))
    print("Test end :: test_AdHocCLI")


# Generated at 2022-06-24 17:33:57.388176
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:34:01.003903
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert(str_0 == ad_hoc_c_l_i_0.args)


# Generated at 2022-06-24 17:34:09.276803
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_a = 'async_val\t04NQs'
    str_b = 'poll\t04NQs'

    ad_hoc_c_l_i_a = AdHocCLI(str_a)
    ad_hoc_c_l_i_b = AdHocCLI(str_b)

    ad_hoc_c_l_i_a.pattern = str_b
    ad_hoc_c_l_i_b.pattern = str_a

# Unit test of run() in class AdHocCLI

# Generated at 2022-06-24 17:34:13.679830
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    argv_0 = ['/usr/local/bin/ansible', 'all', '-m', '/usr/bin/']
    ad_hoc_c_l_i_0 = AdHocCLI(argv_0, '/tmp/.ansible.cfg')
    ad_hoc_c_l_i_0.parse()
    assert (ad_hoc_c_l_i_0.options.module_name == '/usr/bin/')

# Generated at 2022-06-24 17:34:19.161353
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()
    return

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:26.544831
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    print('Unit test for method run of class AdHocCLI')
    print('Local variables: ')
    print('hosts: ' + str(ad_hoc_c_l_i_0._hosts))
    print('pattern: ' + str(ad_hoc_c_l_i_0._pattern))
    print('options: ' + str(ad_hoc_c_l_i_0.options))
    print('Pass')


# Generated at 2022-06-24 17:34:37.930591
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

if __name__ == '__main__':
    TEST_CASES = [
        test_AdHocCLI_run,
    ]
    for test_case in TEST_CASES:
        test_case()

# Generated at 2022-06-24 17:34:41.356282
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    # test_AdHocCLI_run()

# Generated at 2022-06-24 17:34:49.077598
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Test for an exception raised in run
    # Create an instance of AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI('q\tfQ7U')
    try:
        ad_hoc_c_l_i_0.run()
    except Exception as e:
        print(e)
        assert True
    else:
        assert False


# Generated at 2022-06-24 17:34:55.228880
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    try:
        ad_hoc_c_l_i_0.run()
    except SystemExit:
        pass
    except Exception:
        raise

# Generated at 2022-06-24 17:34:59.794814
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:08.382245
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'pattern'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.init_parser()
    options, args = ad_hoc_c_l_i_0.parser.parse_args()
    ad_hoc_c_l_i_0.parser.parse_args = Mock(return_value=(options, args))
    ad_hoc_c_l_i_0.post_process_args = Mock(return_value=options)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:35:09.206171
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-24 17:35:13.749910
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        str_0 = 'os\t04NQs'
        ad_hoc_c_l_i_0 = AdHocCLI(str_0)
        ad_hoc_c_l_i_0.run()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:16.921602
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)


# Generated at 2022-06-24 17:35:17.981260
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:35:33.341895
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = "python"
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    str_2 = "linux"
    var_1 = ad_hoc_c_l_i_1.get_host_list(str_2, "test", "args")
    ad_hoc_c_l_i_1.run()

test_case_0()
test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:37.196850
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    pass


# Generated at 2022-06-24 17:35:43.496626
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.post_process_args(None)
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:35:48.744178
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'os\t04NQs'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    ad_hoc_c_l_i_1.run()
    # print(ad_hoc_c_l_i_1)

if __name__ == '__main__':
    test_case_0()
    # test_AdHocCLI_run()

# Generated at 2022-06-24 17:35:51.680181
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create some insance
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Run test cases
    test_case_0()

# Run the testing function
if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-24 17:35:57.935752
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    return var_0


# Generated at 2022-06-24 17:36:02.068303
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'P!X51@U'
    ad_hoc_c_l_i_1 = AdHocCLI(str_0)
    ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:36:05.923973
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    u_t_0 = '04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(u_t_0)
    var_0 = ad_hoc_c_l_i_0.run()

# TEST FUNCTIONS

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:36:14.136239
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Test for class 'AdHocCLI' with test case 0
    print ("AdHocCLI.py: Test case 0")
    test_case_0()

# Executes the testcase
if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-24 17:36:23.266395
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    var_1 = ad_hoc_c_l_i_0.run()
    var_2 = ad_hoc_c_l_i_0.post_process_args()
    var_3 = ad_hoc_c_l_i_0._play_ds()
    var_4 = ad_hoc_c_l_i_0._play_prereqs()


# Generated at 2022-06-24 17:36:41.988143
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Creating a static instance of class AdHocCLI
    ad_hoc_c_l_i_0 = AdHocCLI('str_0')
    assert ad_hoc_c_l_i_0.run() == None

test_AdHocCLI_run()

# Generated at 2022-06-24 17:36:46.167120
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'o_z\t\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:36:49.425140
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_c_l_i_0 = AdHocCLI()
    ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:36:49.868487
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass



# Generated at 2022-06-24 17:36:58.583602
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0._base_parser.usage == '%prog <host-pattern> [options]'
    assert ad_hoc_c_l_i_0._base_parser.description == 'Define and run a single task \'playbook\' against a set of hosts'
    assert ad_hoc_c_l_i_0._base_parser.add_help == True
    assert ad_hoc_c_l_i_0._base_parser.add_version == False
    assert ad_hoc_c_l_i_0._base_parser.prog == 'os\t04NQs'
    assert ad

# Generated at 2022-06-24 17:37:05.086118
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Test method run
    test_case_0()



# Generated at 2022-06-24 17:37:10.671808
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    int_0 = ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:21.749616
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = '\'-a\''
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    context_0 = context
    context_0.CLIARGS = {'module_name': 'yum'}
    context_0.CLIARGS['module_args'] = 'option_name=sync_threads option_value=3 state=present'
    context_0.CLIARGS['tree'] = '/etc/ansible'
    context_0.CLIARGS['verbosity'] = 2
    var_1 = ad_hoc_c_l_i_0.run()


# Generated at 2022-06-24 17:37:27.023176
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    str_1 = 'os\t04NQs'
    ad_hoc_c_l_i_0.init_parser(str_1)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:37:35.245140
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    
    # Test case for expected result with given input
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args(var_0)
    var_1 = ad_hoc_c_l_i_0.run()
    assert var_1 == None


# Generated at 2022-06-24 17:38:10.450024
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'test_string'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:19.307994
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cb = 'oneline'
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = 'ping'
    context.CLIARGS['forks'] = 1
    context.CLIARGS['tree'] = '/Users/nirmita/Documents/HPE/workspace/ansible/projects/ansible/examples/test_p/'
    context.CLIARGS['seconds'] = 10
    context.CLIARGS['poll_interval'] = 20
    context.CLIARGS['subset'] = 'default'
    context.CLIARGS['args'] = 'localhost'
    context.CLIARGS['listhosts'] = True
    ad_hoc_c_l_i_0 = AdHocCLI()
    # Test

# Generated at 2022-06-24 17:38:26.513102
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.init_parser()
    ad_hoc_c_l_i_0.post_process_args()
    var_0 = ad_hoc_c_l_i_0.run()
    assert_equal(var_0, 0)

# Generated at 2022-06-24 17:38:33.257747
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'

    # invovke the method with arguments
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.run()


if __name__ == "__main__":
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:38:35.385733
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    assert ad_hoc_c_l_i_0.run() == 0

# Generated at 2022-06-24 17:38:38.236033
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = '\x00'
    print(AdHocCLI(str_0))


# Generated at 2022-06-24 17:38:45.714350
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'os\t04NQs'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    var_1 = ad_hoc_c_l_i_1.run()


# Generated at 2022-06-24 17:38:49.091986
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)

    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:38:50.118980
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_case_0()

# Generated at 2022-06-24 17:38:57.124679
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'host\trefer\n\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.init_parser()
    C.CALLBACKS_ENABLED.append('display')
    C.CALLBACKS_ENABLED.remove('tree')
    C.CALLBACKS_ENABLED.append('tree')
    ad_hoc_c_l_i_0.run()

# Generated at 2022-06-24 17:40:13.390998
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_c_l_i_0 = AdHocCLI('os\t04NQs')
    global str_0
    str_0 = 'os\t04NQs'
    str_1 = '--private-key'
    str_2 = '--private-key'
    str_3 = '--private-key'
    str_4 = '--private-key'
    str_5 = '--private-key'
    str_6 = ''


# Generated at 2022-06-24 17:40:20.504577
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pb = 'unit test string'
    password = 'unit test password'
    user = 'unit test user'
    module_name = 'unit test module name'
    module_args = 'unit test module args'
    comment = 'unit test comment'
    prefix = 'unit test prefix'
    ad_hoc_c_l_i_0 = AdHocCLI(pb)
    var_0 = ad_hoc_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_AdHocCLI_run()

# Generated at 2022-06-24 17:40:32.557377
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    kwargs = {'module_name': 'ping', 'module_args': '-c 3'}
    test_cli_args = {'host_key_checking': False,
                     'verbosity': 0,
                     'listhosts': True, 'module_name': 'ping',
                     'module_args': '-c 3', 'one_line': False,
                     'tree': '', 'resource_limits': {},
                     'args': '127.0.0.1'}
    cli = CLI(**kwargs)
    cli.parse()
    assert C.CLIARGS == test_cli_args


# Generated at 2022-06-24 17:40:37.483663
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'os\t04NQs'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    ad_hoc_c_l_i_1.run()

# Generated at 2022-06-24 17:40:44.498294
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    ad_hoc_c_l_i_0.init_parser()
    var_0 = ad_hoc_c_l_i_0.run()



# Generated at 2022-06-24 17:40:49.459969
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()

# unit test for post_process_args method of class AdHocCLI

# Generated at 2022-06-24 17:40:57.714202
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    # Check that constructor doesn't raise exception with proper input
    try:
        test_case_0()
    except Exception:
        raise AssertionError('Exception raised')


if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-24 17:41:02.960186
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_1 = 'jY4l4s'
    ad_hoc_c_l_i_1 = AdHocCLI(str_1)
    print(ad_hoc_c_l_i_1.run())


# Generated at 2022-06-24 17:41:05.141671
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    str_0 = 'os\t04NQs'
    ad_hoc_c_l_i_0 = AdHocCLI(str_0)
    var_0 = ad_hoc_c_l_i_0.run()
    print(var_0)


# Generated at 2022-06-24 17:41:07.162935
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an object of the class under test
    ad_hoc_c_l_i_0 = AdHocCLI()
    # Expecting Exception: RuntimeError
    assert_raises(RuntimeError, AdHocCLI().run)