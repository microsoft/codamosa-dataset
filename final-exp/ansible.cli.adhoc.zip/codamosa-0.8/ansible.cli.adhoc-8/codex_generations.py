

# Generated at 2022-06-10 21:58:26.805314
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Mock_AdHocCLI(AdHocCLI):
        def get_host_list(self, inventory, subset, pattern):
            return []
        def _play_prereqs(self):
            return(None, None, None)
        def _play_ds(self, pattern, async_val, poll):
            return dict(
                    name="Ansible Ad-Hoc",
                    hosts=pattern,
                    gather_facts='no',
                    tasks=[{"action": {"module": "yum", "args": {"name": "httpd"}},
                            "timeout": 15}])
    cli = Mock_AdHocCLI()
    cli.post_process_args(context.CLIARGS)
    cli.run()

# Generated at 2022-06-10 21:58:27.886854
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli._tqm is None

# Generated at 2022-06-10 21:58:33.932989
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Test run method of class AdHocCLI'''
    t = AdHocCLI()
    t.post_process_args()
    t.ask_passwords = lambda: ('sshpass', 'becomepass')
    # FIXME: evaluation of t.run() yields
    #  "AttributeError: 'AdHocCLI' object has no attribute '_play_prereqs'"

# Generated at 2022-06-10 21:58:36.151260
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI([])
    assert adhoc.run() == 0

# Generated at 2022-06-10 21:58:39.619988
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Test the contructor of class AdHocCLI
    :return: None
    '''
    a = AdHocCLI(args=[])
    assert a.parser is not None

# Generated at 2022-06-10 21:58:43.813394
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=['-a','foo=bar','localhost,','all'])
    cli.parse()
    assert cli.run() == 0


# Generated at 2022-06-10 21:58:47.370027
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['ansible', 'all', '-m', 'shell', '-a', 'uptime', '-f', '6'])
    assert cli.parser.prog == 'ansible'


# Generated at 2022-06-10 21:58:54.463774
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(['/bin/ansible', 'host', '-m', 'setup'])
    res = cli.run()
    # Depending on whether the localhost is configured in the inventory this
    # will work or not
    # If it works res is 0
    # If it doesn't res is None (None is considered a true value in Python)
    assert res is None or res == 0

# Generated at 2022-06-10 21:58:59.450530
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.init_parser()
    context.CLIARGS = cli.parser.parse_args(['all', '-i', 'localhost,'])
    context.CLIARGS['listhosts'] = True
    cli.post_process_args(context.CLIARGS)
    cli.run()

# Generated at 2022-06-10 21:59:02.952964
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    Ahc = AdHocCLI()
    assert Ahc.init_parser()
    assert Ahc.post_process_args()
    assert Ahc.run()

# Generated at 2022-06-10 21:59:21.273800
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create an instance of AdHocCLI
    AdHocCLI_instance = AdHocCLI()

    # Create an instance of AnsibleOptions
    AnsibleOptions_instance = AnsibleOptions()

    # Assign values to required variables of AnsibleOptions
    AnsibleOptions_instance.module_name='shell'
    AnsibleOptions_instance.module_args='ls'
    AnsibleOptions_instance.subset='all'
    AnsibleOptions_instance.inventory='/etc/ansible/hosts'

    # invoke run method of class AdHocCLI
    AdHocCLI_instance.run(AnsibleOptions_instance)

# Generated at 2022-06-10 21:59:22.705457
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:24.948333
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''
    pass

# Generated at 2022-06-10 21:59:27.202860
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(None)
    assert adhoc.parser is not None

# Generated at 2022-06-10 21:59:38.728503
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 21:59:40.628400
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pass


# Generated at 2022-06-10 21:59:49.458983
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli_parser = cli.init_parser()
    cli_args = ['localhost', '-m', 'shell', '-a', 'ls']

    try:
        cli_options = cli.parse(cli_args, cli_parser)
    except SystemExit:
        print("exit")

    assert cli_options.args == 'localhost'
    assert cli_options.module_name == 'shell'
    assert cli_options.module_args == 'ls'
    assert cli_options.listhosts is False
    assert cli_options.subset is None
    assert cli_options.forks is None
    assert cli_options.ask_pass is False
    assert cli_options.private_key_file is None
    assert cli_

# Generated at 2022-06-10 21:59:52.361189
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ahc = AdHocCLI(['-v', '-m', 'command', '-a', 'whoami', 'localhost'])
    ahc.run()

# Generated at 2022-06-10 21:59:54.423550
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI(None, None, ['-m', 'setup', '-a', 'filter=*ipv4*', 'all'])

# Generated at 2022-06-10 21:59:56.211877
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Constructor
    a_c = AdHocCLI()
    assert a_c is not None

# Generated at 2022-06-10 22:00:08.575674
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    # default values
    assert adhoc.parser is None
    assert adhoc.args is None
    assert adhoc.options is None
    assert adhoc.callback is None
    assert adhoc._tqm is None

# Generated at 2022-06-10 22:00:10.197416
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:00:14.554980
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Given
    ad_hoc = AdHocCLI(args=['-i', 'localhost,', 'all', '-m', 'ping'])

    # When
    result = ad_hoc.run()

    # Then
    assert result == 0

# Generated at 2022-06-10 22:00:15.623005
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:00:16.216087
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # pass
    pass

# Generated at 2022-06-10 22:00:17.562314
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert AdHocCLI.run() is not None

# Generated at 2022-06-10 22:00:21.971587
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=[])
    cli.options = cli.get_opt(['-m', 'ping', 'localhost'])
    display.verbosity = 1
    cli.run()

# Generated at 2022-06-10 22:00:33.421015
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from units.test_utils import mock
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    import json
    import pytest
    # Create class objects
    adhocobj = AdHocCLI()
    display = adhocobj.display
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-10 22:00:43.418648
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test class AdHocCLI run method'''
    display = Display()
    ad_hoc_cli = AdHocCLI(None)
    # Check for a exception if pattern is not provided
    try:
        ad_hoc_cli.run()
        assert False
    except AnsibleError as e:
        assert 'usage' in to_text(e)

    # Check for exception if a wrong file is provided
    context.CLIARGS['args'] = 'xyz.yml'
    try:
        ad_hoc_cli.run()
        assert False
    except AnsibleError as e:
        assert 'xyz.yml' in to_text(e)

    # Check for exception if a wrong file is provided
    context.CLIARGS['args'] = 'xyz'

# Generated at 2022-06-10 22:00:44.025410
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:10.197940
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    b = AdHocCLI()

    assert b._play_prereqs() == (
        DataLoader(),
        InventoryManager(loader=None, sources=C.DEFAULT_HOST_LIST),
        VariableManager())

    assert b._play_ds(pattern='*', async_val=10, poll=100).keys() == (
        ['name', 'hosts', 'gather_facts', 'tasks'])
    assert b._play_ds(pattern='*', async_val=10, poll=100)['tasks'][0]['async_val'] == 10


# Generated at 2022-06-10 22:01:15.752123
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    script = AdHocCLI(['-m', 'ping', 'localhost'])
    script.parse()
    script.post_process_args()
    assert script.options.module_name == 'ping'
    assert context.CLIARGS['module_name'] == 'ping'
    assert script.options.args[0] == 'localhost'
    assert context.CLIARGS['module_args'] is None

# Generated at 2022-06-10 22:01:25.273104
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    adhocCLI = AdHocCLI()
    class DummyOptions:
        module_name = 'win_ping'
        module_args = ''
        listhosts = True
        subset = 'test'
        pattern = 'pattern'
        verbosity = '1'
        connection = 'ssh'
        timeout = '120'
        start_at_task ='start_at_task'
        #options unique to ansible ad-hoc
        module_name = 'win_ping'
        module_args = 'arg'
        #other options
        forks = 10
        ask_pass = False
        ask_become_pass = False
        ask_sudo_pass = False
        private_key_file = 'private_file_path'
        remote_user = 'remote_user'

# Generated at 2022-06-10 22:01:28.141179
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Initialize AdHocCLI class
    adhoc_cli = AdHocCLI()

    # Initialize parser
    adhoc_cli.init_parser()

# Generated at 2022-06-10 22:01:31.259302
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Test for method AdHocCLI.run()
    '''
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-10 22:01:41.101445
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def TaskQueueManagerMock(self, inventory, variable_manager, loader,
                             passwords, stdout_callback,
                             run_additional_callbacks,
                             run_tree,
                             forks=None):
        self.inventory = inventory
        self.variable_manager = variable_manager
        self.loader = loader
        self.passwords = passwords
        self.stdout_callback = stdout_callback
        self.run_additional_callbacks = run_additional_callbacks
        self.run_tree = run_tree
        self._stats = {}

    class PlaybookMock2:
        def __init__(self, loader):
            self.loader = loader
            self._entries = [play]
            self._file_name = '__adhoc_playbook__'


# Generated at 2022-06-10 22:01:47.834188
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class PlayCLI(object):
        def __init__(self):
            self.defaults = dict(
                module_name=dict(default=None),
            )

        def spec(self, name):
            return self.defaults[name]

    class CLI(object):
        def __init__(self):
            self.pattern = 'server1'
            self.module_name = 'setup'
            self.module_args = ''
            self.subset = None

    context.CLIARGS = CLI()
    adhoc_cli = AdHocCLI()
    adhoc_cli.play_cli = PlayCLI()
    assert adhoc_cli.run() == 0

# Generated at 2022-06-10 22:01:54.561705
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test with options which have been set to non-default values
    args = ['-m', 'ping', '-c', 'ssh', '-u', 'admin', 'localhost:5000']
    cli = AdHocCLI(args)
    options = cli.parse()
    for k, v in options:
        assert (v.get(k) != 'default')
    options = cli.post_process_args(options)
    # Test with options which have been set to default values
    args = ['-m', 'ping', 'localhost:5000']
    cli = AdHocCLI(args)
    options = cli.parse()
    for k, v in options:
        assert (v.get(k) == 'default')
    options = cli.post_process_args(options)

# Generated at 2022-06-10 22:02:04.687930
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from unittest import TestCase

    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes

    testcase = TestCase()

    class DummyAdHocCLI(AdHocCLI):

        def _play_ds(self, pattern, async_val, poll):
            assert pattern == 'host'
            assert async_val == 42
            assert poll == 2

            return dict(
                name="Ansible Ad-Hoc",
                hosts='host',
                gather_facts='no',
                tasks=[{'action': {'module': 'test', 'args': 'test'}, 'timeout': 42}])

        def run_playbook(self, pb, callbacks, **kwargs):

            assert pb.name == "Ansible Ad-Hoc"
            assert p

# Generated at 2022-06-10 22:02:05.766908
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI()

# Generated at 2022-06-10 22:02:46.470905
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.config
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test defauls
    class Options:
        connection = 'smart'
        remote_user = 'root'
        ask_pass = None
        private_key_file = None
        become_method = None
        become_user = None
        verbosity = 0
        inventory = None
        subset = None
        module_paths = None
        forks = None
        ask_vault_pass = None
        vault_password_files = None
        new_vault_password_file = None
        output_file = None

# Generated at 2022-06-10 22:02:56.658589
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test with no arguments
    with pytest.raises(AnsibleOptionsError):
        ad_hoc_cli = AdHocCLI()
        ad_hoc_cli.parse()

    # Test with bad options and arguments
    with pytest.raises(AnsibleOptionsError):
        sys.argv.extend(['-m', 'shell', 'myhost.com', '--extra-vars', 'foo=bar'])
        ad_hoc_cli = AdHocCLI()
        ad_hoc_cli.parse()

    # Test with good options
    sys.argv = ['ansible', '-m', 'shell', '-B', '900', '-P', '0', 'myhost.com']
    ad_hoc_cli = AdHocCLI()
    ad_hoc

# Generated at 2022-06-10 22:03:06.856452
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath
    from ansible.utils.display import Display
    from ansible import constants as C

    def dict_hash(data):
        h = hashlib.sha1()
        h.update(json.dumps(data, sort_keys=True).encode("utf-8"))
        return h.hexdigest()


# Generated at 2022-06-10 22:03:09.418769
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, CLI)

# Generated at 2022-06-10 22:03:17.822003
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
        Unit tests to see if the method run of class AdHocCLI works as expected
    """
    # creating objects
    test_cli = AdHocCLI()
    assert test_cli is not None
    test_playbook = Playbook()
    assert test_playbook is not None

    # test where the method run of class AdHocCLI is called with no arguments to check if the the required
    # arguments are passed and throw the expected error
    try:
        test_cli.run()
    except AnsibleOptionsError:
        pass

    # test when the method run is called with an argument
    assert test_cli.run() is not None

# Generated at 2022-06-10 22:03:19.285714
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()


# Generated at 2022-06-10 22:03:32.483086
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initialize the CLI class with CLI arguments
    cli_args = AdHocCLI.init_parser()
    # Validate and post process the arguments.
    options = AdHocCLI.post_process_args(cli_args)
    # Validate if the host pattern matches with any hosts. Then get the list of hosts.
    (sshpass, becomepass) = AdHocCLI.ask_passwords()
    # Get the basic objects
    (loader, inventory, variable_manager) = AdHocCLI._play_prereqs()
    # Get the host list
    hosts = AdHocCLI.get_host_list(inventory, cli_args['subset'], cli_args['args'])
    # Construct the playbook to execute

# Generated at 2022-06-10 22:03:34.458274
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test for method run of class AdHocCLI'''
    pass

# Generated at 2022-06-10 22:03:47.855934
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # constructor of AdHocCLI sets default values of some attributes
    cli = AdHocCLI([])
    assert not cli.options
    assert not cli.args
    assert cli._play_prereqs_ok
    assert not cli._play_context
    assert not cli.help_menu
    assert not cli.passwords
    assert not cli.results_callback
    assert not cli.inventory
    assert not cli.variable_manager
    assert not cli.loader
    assert not cli.callback
    assert not cli.options
    assert not cli._tqm

    # test the run method
    # this test will only test the flow, not the functionality
    # constructor of AdHocCLI sets default values of some attributes
    cli = AdHocCLI([])
    cl

# Generated at 2022-06-10 22:03:49.320231
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    runner = AdHocCLI()
    runner.run()

# Generated at 2022-06-10 22:05:10.808072
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import pytest
    from ansible import constants as C
    from ansible.cli import CLI

    class MyCLI(AdHocCLI):
        class Options(object):
            module_name = None
            module_args = None
            one_line = None
            tree = None

        def __init__(self):
            self.module_name = None
            self.module_args = None
            self.one_line = None
            self.tree = None

        def get_host_list(self, inventory, subset, pattern):
            return pattern

        def load_options(self, args):
            return self.Options()

    class MyTaskQueueManager(object):
        def __init__(self, *args, **kwargs):
            pass

        def load_callbacks(self):
            pass


# Generated at 2022-06-10 22:05:15.183365
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['-m', 'ping', 'localhost', '-a', 'data=test'])
    cli.parse()
    cli.post_process_args()
    assert cli.run() == 0

# Generated at 2022-06-10 22:05:18.066175
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Just instantiating AdHocCLI class and calling its run method
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:05:20.178488
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:05:21.919539
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():    
    adhoc_cli = AdHocCLI()
    assert adhoc_cli


# Generated at 2022-06-10 22:05:30.604326
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import shutil

    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.parsing.splitter import parse_kv
    from ansible.plugins import module_loader
    from ansible.utils.display import Display
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    class MyDisplay(Display):
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

    class MyOptions(object):
        def __init__(self):
            self.ask_vault_pass = False
            self.connection = None
            self.module_path = ''
            self.forks = 10
            self.become = False

# Generated at 2022-06-10 22:05:34.904179
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    parser = adhoc.init_parser()
    options = adhoc.post_process_args(parser.parse_args(args=['-m', 'test', 'localhost']))
    context.CLIARGS = options
    adhoc.run()

# Generated at 2022-06-10 22:05:44.851593
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''

    print(__doc__)
    print('TEST START')

    # create instance of class AdHocCLI
    cli = AdHocCLI(args=[])
    # set values for attributes
    cli.options = cli.parse()
    cli.options.module_name = 'my_module'
    cli.options.module_args = 'my_module_args'
    cli.options.subset = 'my_subset'
    cli.options.listhosts = 'my_listhosts'
    cli.options.seconds = 'my_seconds'
    cli.options.poll_interval = 'my_poll_interval'

# Generated at 2022-06-10 22:05:56.111956
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import sys

    adhock_cli = AdHocCLI(None)
    options, args = adhock_cli.parse()
    context.CLIARGS = options

    adhock_cli.post_process_args(options)

    loader = DataLoader()

    inv_manager = InventoryManager(loader=loader, sources="localhost,")

    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-10 22:06:07.417081
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Options(object):
        verbosity=1
        module_name = 'shell'
        module_args = 'ls'
        listhosts = False
        subset = None
        forks = None
        inventory = None
        pattern = 'all'
        one_line = False
        tree = None

    options = Options()
    cli = AdHocCLI(args=[])
    cli.post_process_args(options)

    options.module_name = 'command'
    cli.post_process_args(options)

    options.module_name = 'script'
    cli.post_process_args(options)