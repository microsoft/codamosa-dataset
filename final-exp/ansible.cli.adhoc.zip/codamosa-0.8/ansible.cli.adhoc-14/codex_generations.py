

# Generated at 2022-06-10 21:58:28.468998
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    This method is used as a unit test for method run of class AdHocCLI.
    """

    # create an options parser for bin/ansible
    parser = opt_help.create_base_parser(
        '/usr/bin/ansible',
        '%(prog)s <host-pattern> [options]',
        'Define and run a single task \'playbook\' against a set of hosts',
        'Some actions do not make sense in Ad-Hoc (include, meta, etc)',
        epilog=None,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    opt_help.add_version_option(parser)
    opt_help.add_log_options(parser)

    opt_help.add_runas_options(parser)
    opt_help.add_

# Generated at 2022-06-10 21:58:37.864587
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    loader, vars, ips = opt_help.setup(['-i', '-m', 'ping', 'all', '-a', '"data=test"'])
    opt_help.create_inventory(ips)
    cli = AdHocCLI(['-i', './test/test_adhoc.py', 'testhosts', '-m', 'ping', '-a', '"data=test"'])
    cli.run()
    assert context.CLIARGS['module_name'] == 'ping'
    assert context.CLIARGS['module_args'] == '"data=test"'
    assert context.CLIARGS['listhosts'] == False
    assert context.CLIARGS['args'] == 'testhosts'
    assert context.CLIARGS['module_name'] == 'ping'

# Generated at 2022-06-10 21:58:46.575708
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test if instantiation of class is successful
    adhoc_cli = AdHocCLI()
    # Test if __init__ instantiation of _base_parser is successful
    assert adhoc_cli._base_parser is not None

    adhoc_cli.init_parser()
    adhoc_cli.post_process_args(adhoc_cli.parser.parse_args())
    adhoc_cli.parser.parse_args()
    adhoc_cli.run()

    # class AdHocCLI(CLI):

# Generated at 2022-06-10 21:58:48.062811
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''Test constructor'''
    AdHocCLI()

# Generated at 2022-06-10 21:58:48.712045
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:51.310946
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    a = AdHocCLI()
    result = a.run()
    assert result == 0

# Generated at 2022-06-10 21:59:02.866147
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a cli object
    cli = AdHocCLI()

    # Create options for cli
    options = CLI.parse()
    options.module_name = "command"
    options.module_args = 'echo test'
    options.verbosity = 0
    context.CLIARGS = options

    # Create an inventory object with a host
    # This host will be connected and a task will be executed on it
    class host:
        name = "test"
    class inventory:
        hosts = [host()]
    context.CLIARGS['inventory'] = inventory()

    # Set the host pattern
    context.CLIARGS['args'] = "test"

    # Create a loader object
    class loader:
        def __init__(self):
            return
    loader = loader()

    # Test the run method

# Generated at 2022-06-10 21:59:11.484606
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    with open("/tmp/ansible_temp.json","w+") as fp1:
        fp1.write('{"test": "password"}')
    with open("/tmp/ansible_temp2.json","w+") as fp2:
        fp2.write('{"test": "password"}')
    adhoc_obj = AdHocCLI(["-a",'ansible_temp.json', "-i",'ansible_temp2.json', "test"])
    assert (adhoc_obj.run()) == 2

# Generated at 2022-06-10 21:59:15.666378
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    AdHocCLI - constructor for class AdHocCLI
    '''
    adhoc = AdHocCLI()
    assert adhoc

# Generated at 2022-06-10 21:59:23.120685
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys

    class FakeOption:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    with open('tests/adhoc_playbook.yml', 'r') as f:
        ansible_playbook = f.read()
    m = 'ansible.cli.adhoc.AdHocCLI.run'
    with patch(m, autospec=True) as m1:
        m2 = 'ansible.cli.adhoc.AdHocCLI.post_process_args'

# Generated at 2022-06-10 21:59:39.217224
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-m','ping','hadoop-master'])
    assert isinstance(adhoc,CLI) # Check the object is instance of class CLI or not
    assert adhoc.init_parser() is None # Check the init_parser is return None or not
    assert adhoc.post_process_args(adhoc.options) is not None # Check the post_process_args is return None or not
    assert adhoc.run() is  not None # Check the run function is return None or not


# Generated at 2022-06-10 21:59:48.976412
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test function for Ansible's CLI class
    '''
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.collections import ImmutableDict
    AdHoc_CLI_object = AdHocCLI()
    #Take output of class and create a parser
    parser = AdHoc_CLI_object.init_parser()
    #Create group, add host to group, add group to inventory
    group = Group('nodrones')
    group.add_host(Host("127.0.0.1"))
    inventory = InventoryManager("")
    inventory.add_group(group)
    #Set context
   

# Generated at 2022-06-10 21:59:54.046387
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['/home/ansible/test/inventory','test-host','test_module','test_args','test_host_pattern','test_module_exc','test_host_pattern_1','test_host_pattern_2']
    adhocl = AdHocCLI(args)
    p_obj = adhocl.run()
    assert(p_obj == 0)

# Generated at 2022-06-10 22:00:02.433096
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Unit test for constructor of class AdHocCLI
    '''
    if not C.CONFIG_FILE:
        C.CONFIG_FILE = os.path.join(os.path.dirname(__file__), "../../../test/ansible.cfg")
    args = [
        "ansible", "localhost",
        "-a", "date",
        "-c", "local",
        "-m", "command",
    ]
    cli = AdHocCLI(args)
    assert cli.options.module_name == 'command', "Expected module_name to be set to 'command'"

# Generated at 2022-06-10 22:00:05.248679
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    argv = []
    adhoc = AdHocCLI(None, argv)
    assert(adhoc)

# Generated at 2022-06-10 22:00:17.763218
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    help_ = """[options] <host-pattern> [options]

Define and run a single task 'playbook' against a set of hosts"""
    parser = AdHocCLI(None, None, None).parser
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.usage == "%prog <host-pattern> [options]"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert parser.option_list[0].help == help_
    assert parser.option_list[1].help == 'The action\'s options in space separated k=v format: -a \'opt1=val1 opt2=val2\''

# Generated at 2022-06-10 22:00:29.989525
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader
    import ansible.constants as C
    import os

    # generate a test user with ssh key
    password="ansible"
    home="/home/ansible"
    os.system("useradd -m -s /bin/bash -d %s -p %s ansible"%(home, password))
    os.system("mkdir %s/.ssh"%home)
    os.system("touch %s/.ssh/authorized_keys"%home)
    os.system("echo -e 'ansible\nansible' |ssh-keygen -q -t rsa -N '' -f %s/.ssh/id_rsa"%home)

# Generated at 2022-06-10 22:00:42.828028
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.vault_secrets import get_test_vault_secrets

    test_host = 'testhost'
    test_hostvars = {'ansible_connection': 'local'}
    test_inventory = MockInventory(loader=DictDataLoader({'_meta': {'hostvars': {test_host: test_hostvars}}}))

    test_module_name = 'debug'
    test_module_args = 'msg="This is a test"'
    test_action = {'module': test_module_name, 'args': parse_kv(test_module_args, check_raw=True)}

    test_playbook = Playbook(loader=DictDataLoader({}))

# Generated at 2022-06-10 22:00:45.114481
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert(adhoc is not None)

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-10 22:00:46.592984
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Case where everything runs as expected
    pass

# Generated at 2022-06-10 22:00:55.427245
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:02.039439
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    c = AdHocCLI([])
    assert c.description
    assert c.description == ('Define and run a single task \'playbook\' against a set of hosts')
    assert c.epilog
    assert c.epilog == ('Some actions do not make sense in Ad-Hoc (include, meta, etc)')
    assert c.usage
    assert c.usage == ('%prog <host-pattern> [options]')

# Generated at 2022-06-10 22:01:02.743141
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:10.294813
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    adhoc_cli.parse()
    assert adhoc_cli.parser is not None
    assert adhoc_cli._usage == "%prog <host-pattern> [options]"
    assert adhoc_cli._description \
           == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc_cli._epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-10 22:01:11.295030
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:01:13.019630
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-10 22:01:18.663766
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ this is a basic test, just to make sure the class is constructed correctly """
    args = ['ansible', 'local', '-m', 'setup', 'localhost']
    adhoc = AdHocCLI(args)
    assert isinstance(adhoc, AdHocCLI)
    assert adhoc.parser is not None

# Generated at 2022-06-10 22:01:26.464444
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit test for method run of class AdHocCLI '''
    from ansible.cli.adhoc import AdHocCLI
    from ansible import constants as C

    adhoc_cli = AdHocCLI()

    # there is not much to test here, since this class is mostly delegating
    # to other classes via objects that are created and destroyed during
    # the run() method.  Thus we will defer testing to those classes.
    # Only testing for try/except block to cover the code

    # Add an entry for 'module_name' argument in context.CLIARGS
    context.CLIARGS['module_name'] = None
    # Add an entry for 'module_args' argument in context.CLIARGS
    context.CLIARGS['module_args'] = None
    # Add an entry for 'sub

# Generated at 2022-06-10 22:01:31.896458
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    import sys
    sys.argv = ['ansible', 'all', '-m', 'shell', '-a', 'ls ~']

    adhoc_obj = AdHocCLI()
    adhoc_obj.init_parser()
    adhoc_obj.post_process_args(adhoc_obj.parser.parse_args())
    adhoc_obj.run()

# Generated at 2022-06-10 22:01:33.829702
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli_adhoc = AdHocCLI()
    cli_adhoc.init_parser()

# Generated at 2022-06-10 22:01:56.376983
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: AnsibleOptionsError: fail: msg: pattern is required
    # Invoke AdHocCLI.run() without any parameter
    ansible_cli = AdHocCLI()
    # TODO: First, it requires options to setup the parser
    res = ansible_cli.run()
    print(res)



# Generated at 2022-06-10 22:02:05.521284
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-10 22:02:09.228585
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser is not None
    options = cli.post_process_args(cli.parser.parse_args([]))
    assert options is not None
    assert cli.run() is None

# Generated at 2022-06-10 22:02:16.647118
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    mocker.patch('ansible.cli.adhoc.AdHocCLI.init_parser')
    mocker.patch('ansible.cli.adhoc.AdHocCLI.post_process_args')
    mocker.patch('ansible.cli.adhoc.AdHocCLI.ask_passwords')
    mocker.patch('ansible.cli.adhoc.AdHocCLI._play_prereqs')
    mocker.patch('ansible.cli.adhoc.AdHocCLI.get_host_list')
    mocker.patch('ansible.cli.adhoc.display')
    mocker.patch('ansible.cli.adhoc.context')
    mocker.patch('ansible.cli.adhoc.AnsibleOptionsError')

# Generated at 2022-06-10 22:02:25.295492
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    playbook_dir = '.'
    playbook_file_path = os.path.join(playbook_dir, 'test_adhoc.yml')
    playbook_file = open(playbook_file_path, 'w')
    playbook_file.write('''
---
        - hosts: all
          tasks:
            - ping:
    ''')
    playbook_file.close()

    ansible_adhoc = AdHocCLI(args=[])
    ansible_adhoc.run()
    os.remove(playbook_file_path)

# Generated at 2022-06-10 22:02:33.088163
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.cli.adhoc as adhoc
    fake_playbook = {'hosts': 'localhost', 'tasks': [{'action': {'module': 'test', 'args': {'key': 'value'}}}]}
    fake_play = Play().load(fake_playbook, None, None)
    fake_playbook = Playbook(None)
    fake_playbook._entries.append(fake_play)

    mock_variable_manager = Mock()
    mock_variable_manager.host_vars = {}
    mock_variable_manager.extra_vars = {}

    mock_inventory = Mock()
    mock_inventory.list_hosts = lambda x: ['localhost']
    mock_inventory.get_host = lambda x: Mock()

    mock_loader = Mock()
    mock_loader.load_from_

# Generated at 2022-06-10 22:02:33.789713
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    return

# Generated at 2022-06-10 22:02:44.610694
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unittest

    class Test(unittest.TestCase):
        def test_invalid_playbook(self):
            ad_hoc_cli = AdHocCLI()


# Generated at 2022-06-10 22:02:46.798959
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)


# Generated at 2022-06-10 22:02:56.766018
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {}
    context.CLIARGS['verbosity'] = 1
    context.CLIARGS['module_name'] = 'shell'
    context.CLIARGS['module_args'] = 'ls'
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['one_line'] = True
    context.CLIARGS['tree'] = '/current/directory/file/path'
    context.CLIARGS['forks'] = 5
    context.CLIARGS['seconds'] = 10
    context.CLIARGS['poll_interval'] = 20
    context.CLIARGS['connection'] = 'ssh'
    context.CLIARGS['timeout'] = 5
    context.CLIARGS['remote_user'] = 'root'
    context

# Generated at 2022-06-10 22:03:52.155099
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create an options parser
    parser = opt_help.AnsibleOptions(version=C.ANSIBLE_VERSION)

    # create the default cli options parser
    (options, args) = AdHocCLI.parse(['-m', 'ping', 'all'], parser)
    options.pattern = 'all'
    options.module_name = 'ping'

    # construct playbook objects to wrap task
    play_ds = AdHocCLI()._play_ds(options.pattern, options.seconds, options.poll_interval)

    # now create a task queue manager to execute the play

# Generated at 2022-06-10 22:03:59.866508
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=[])
    cli.post_process_args()
    assert cli._play_ds("https://10.0.0.1", 10, 5) == {'name': 'Ansible Ad-Hoc', 'hosts': 'https://10.0.0.1', 'gather_facts': 'no', 'tasks': [{'action': {'module': 'ping', 'args': {'data': 'pong'}}, 'timeout': 5}]}

# Generated at 2022-06-10 22:04:11.114117
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Import here to prevent import loop
    global AdHocCLI
    from ansible.cli.adhoc import AdHocCLI
    # Mock CLI options
    context.CLIARGS = {
        'module_name': 'test',
        'module_args': 'test_arguments',
    }

    # Mock the TaskQueueManager class
    class TaskQueueManager:
        called = 0

        def load_callbacks(self):
            TaskQueueManager.called += 1

        def run(self, play):
            TaskQueueManager.called += 1

    # Mock the Playbook class
    class Playbook:
        variable_manager = 1
        loader = 'Fake class'
        entries = [1, 2]

    # Mock the Play class
    class Play():
        variable_manager = 'Mocked variable manager'


# Generated at 2022-06-10 22:04:12.220308
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    c = AdHocCLI()

# Generated at 2022-06-10 22:04:17.485908
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI

    # construct the object
    cli = AdHocCLI('test_AdHocCLI_run')
    cli.init_parser()

    cli.options = cli.parser.parse_args()
    # set required arguments
    cli.options.module_name = 'setup'

    # call the method
    cli.run()

# Generated at 2022-06-10 22:04:19.266516
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = dict(module_name='ping', module_args='', args='localhost')
    AdHocCLI().run()

# Generated at 2022-06-10 22:04:24.752307
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # AdHocCLI_run(AdHocCLI) requires ~40min, it is reasonable to skip full test
    # and perform basic checks for a few cases.

    # Test run with 'ls' module and '-c' argument
    # Tested in TestAdHocCLI.test_run_ls
    pass

# Generated at 2022-06-10 22:04:28.134928
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI([])
    adhoc_cli.post_process_args({})
    adhoc_cli.run()

# Generated at 2022-06-10 22:04:37.215806
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    from ansible.utils.display import Display
    display = Display()

    c = AdHocCLI(
        args=sys.argv[1:],
        command_name='ansible-adhoc',
    )

    # create a hosts file
    hosts = tempfile.NamedTemporaryFile(mode='w+t')
    hosts.write('localhost ansible_connection=local')
    hosts.flush()


# Generated at 2022-06-10 22:04:39.087592
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    a = AdHocCLI(['--limit', 'localhost', '--module-name', 'ping', 'localhost'])
    a.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-10 22:06:09.401393
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser is not None
    assert adhoc.parser.description is not None
    assert isinstance(adhoc, AdHocCLI)


# Generated at 2022-06-10 22:06:22.101350
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ansible_args = {}
    ansible_args['module_name'] = 'command'
    ansible_args['module_args'] = 'uptime'
    ansible_args['forks'] = 10
    ansible_args['subset'] = None
    ansible_args['listhosts'] = False
    ansible_args['pattern'] = 'all'
    ansible_args['seconds'] = 0
    ansible_args['poll_interval'] = 0
    ansible_args['check'] = False
    ansible_args['verbosity'] = 0
    ansible_args['extra_vars'] = []
    ansible_args['tree'] = False
    ansible_args['ask_vault_pass'] = False
    ansible_args['vault_password_files'] = []
    ansible_args

# Generated at 2022-06-10 22:06:25.680342
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    global display
    display = Display()

    adhoc = AdHocCLI(['--list-hosst'])
    assert isinstance(adhoc, AdHocCLI)
    adhoc.run()



# Generated at 2022-06-10 22:06:27.949212
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    adhoc = AdHocCLI()
    #adhoc.post_process_args(arnol)
    adhoc.run()
    '''
    pass

# Generated at 2022-06-10 22:06:31.021984
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # ansible-playbook ad-hoc-simple.yml -i hosts
    args = ['-i', 'hosts', 'ad-hoc-simple.yml']
    adhoc_cli = AdHocCLI(args)
    assert adhoc_cli.run() == 0

# Generated at 2022-06-10 22:06:31.528538
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:06:32.569112
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc

# Generated at 2022-06-10 22:06:43.591318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['localhost']
    module_args = ""

    class MockTaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks, run_tree, forks):
            self._stats = None

        def load_callbacks(self):
            pass

        def send_callback(self, callback_method, *args, **kwargs):
            if callback_method == 'v2_playbook_on_start':
                callbacks.v2_playbook_on_start(kwargs['playbook'])

        def run(self, play):
            return True

        def cleanup(self):
            pass

    inventory = MockInventory()
    variable_manager = MockVariableManager()
    loader = MockLoader()
    passwords = {}


# Generated at 2022-06-10 22:06:47.320423
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.usage == "%prog <host-pattern> [options]"


# Generated at 2022-06-10 22:06:54.058438
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Construct AdHocCLI() instance
    adhoccli = AdHocCLI()
    assert adhoccli.parser

    # Assert that options are parsed
    assert adhoccli.options
    assert adhoccli.args

    # Assert that password is prompted and run method returns None
    assert adhoccli.run() is None