

# Generated at 2022-06-10 21:58:19.991735
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:23.819041
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.constants as C
    import ansible.cli.adhoc as adhoc
    import ansible.parsing.splitter as splitter
    import ansible.playbook as playbook

# Generated at 2022-06-10 21:58:26.330758
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhocObj = AdHocCLI()
    assert isinstance(adhocObj, AdHocCLI)


# Generated at 2022-06-10 21:58:32.815355
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import shutil
    import sys
    
    # Create the host file
    host_file = '/tmp/inventory-adhoc'
    with open(host_file, 'w') as f:
        f.write("[test]\n127.0.0.1\n")
    # Create the host file
    
    # Create custom callback class
    class CallbackModule(CallbackBase):
        """
        Custom callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'test'

        def __init__(self):
            super(CallbackModule, self).__init__()
            self.task_start_times = {}
            self.task_results = {}
            self.task_status = {}

# Generated at 2022-06-10 21:58:45.811202
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.path import unfrackpath


# Generated at 2022-06-10 21:58:51.562332
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test that all error messages are returned in the form of AnsibleError
    adhoc_obj = AdHocCLI(['localhost', '-m', 'ping'])
    adhoc_obj.post_process_args(adhoc_obj.options)
    try:
        adhoc_obj.run()
    except AnsibleError as exc:
        assert isinstance(exc, AnsibleError)

# Generated at 2022-06-10 21:58:52.235501
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:54.395210
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # test the constructor
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-10 21:58:56.069198
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 21:58:58.333331
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    cli = AdHocCLI(args=[])
    '''
    assert True

# Generated at 2022-06-10 21:59:08.370234
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    parser = adhoc.parser
    assert parser is not None
    assert isinstance(adhoc, AdHocCLI)

# Generated at 2022-06-10 21:59:09.812300
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    #unit_test is not implemented here
    pass

# Generated at 2022-06-10 21:59:17.112639
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''run() will start playbook execution.'''
    # Arrange
    context.CLIARGS = {'module_name': 'shell',
                       'module_args': 'ls -l',
                       'args': 'localhost',
                       'forks': 10}
    adhoc = AdHocCLI()
    adhoc.run()
    # Act
    # Assert

# Generated at 2022-06-10 21:59:28.729670
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    ad_hoc_cli = AdHocCLI()

    class Options:
        ask_pass = False
        ask_private_key_pass = False
        ask_tags = False
        ask_vault_pass = False
        become = False
        become_ask_pass = False
        become_method = 'sudo'
        become_user = 'root'
        check = False
        diff = False
        inventory = ''
        listhosts = False
        module_name = 'shell'
        module_path = False
        module_vars = ''
        one_line = False
        output_file = ''
        private_key_file = ''
        run_hosts = ''
        seconds = 0
        subset = None
        timeout = 10
        tree = ''
        vault_password_file = ''
        verbosity = 0


# Generated at 2022-06-10 21:59:32.415445
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI([])
    options = cli.parser.parse_args([])
    cli.post_process_args(options)
    result = cli.run()
    assert type(result) is int

# Generated at 2022-06-10 21:59:37.250417
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(['-vvvvvvvvvvvvv', '-m', 'ping', 'localhost'])
    assert adhoc_cli
    assert adhoc_cli.parser

# Generated at 2022-06-10 21:59:48.839901
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_cli = AdHocCLI()

    # No arguments are passed, we should get an error message
    if ad_hoc_cli.run():
        raise AssertionError()

    ad_hoc_cli.args.extend(['localhost'])
    # If ad-hoc is not called with -m module_name, then it should print
    # the usage of the module (module is not installed)
    if ad_hoc_cli.run():
        raise AssertionError()
    ad_hoc_cli.args.extend(['-m', 'setup'])
    # If ad-hoc is called with a module that exists, it should not print
    # the usage of the module.
    if not ad_hoc_cli.run():
        raise AssertionError()

# Generated at 2022-06-10 21:59:59.779107
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Test 1 : If no hosts are passed
    from ansible.cli.adhoc import AdHocCLI
    cli = AdHocCLI(args=[])
    cli.parse()

# Generated at 2022-06-10 22:00:10.076226
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    class AdHocCLIMock(AdHocCLI):
        def __init__(self):
            self.display = Display()

        def _play_prereqs(self):
            return None, None, None

    class TaskQueueManager(object):

        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks, run_tree, forks, **kwargs):
            self._stats = None

        def load_callbacks(self):
            pass

        def send_callback(self, v2_playbook_on_start, playbook):
            pass

        def run(self, play):
            return 0

        def cleanup(self):
            pass

    class Playbook(object):
        def __init__(self, loader):
            self.loader = loader

        #

# Generated at 2022-06-10 22:00:23.985568
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory.host import Host
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # Test for exception nr. 1
    cli = AdHocCLI({})
    pattern = 'host'
    async_val = '10'
    poll = '5'
    loader = DataLoader()
    context.CLIARGS = {
        'module_name': 'ping',
        'module_args': '',
        'subset': None,
        'listhosts': False,
        'seconds': async_val,
        'poll_interval': poll,
        'verbosity': 0 }
    hosts = ['localhost']
    variable_manager = VariableManager()

# Generated at 2022-06-10 22:00:46.789723
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    options = opt_help.get_legacy_opts()
    options.module_name = 'command'
    options.module_args = 'dir'
    options.pattern = 'localhost,'
    options.listhosts = False
    options.one_line = False
    options.tree = None
    options.module_path = './library'
    options.module_path.append('./module_utils')

    # create an AdHocCLI object and retrieve the result of running the method run()
    cli = AdHocCLI(options)
    result = cli.run()
    # compare the result with zero (0)
    assert result == 0

# Generated at 2022-06-10 22:00:55.816834
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Mock class Play and module constants
    _play = 'ansible.playbook.play.Play'
    _constants = 'ansible.constants'
    _original_play = __import__(_play, fromlist=[''])
    _original_constants = __import__(_constants, fromlist=[''])
    Play = PlayMock
    constants = constantsMock
    import sys
    import ansible.cli.adhoc
    _adhocCli = sys.modules['ansible.cli.adhoc']
    adhocCli = AdHocCLIMock(_adhocCli)

    try:
        ret_value = adhocCli.run()
    except:
        pass

    # Recover original class contents
    sys.modules[_play] = _original_play
    sys.modules[_constants] = _

# Generated at 2022-06-10 22:01:00.675708
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    inventory = """
        [test]
        localhost ansible_connection=local
    """
    with open("/tmp/ansible_test_inventory", "wb") as f:
        f.write(inventory)
    cli = AdHocCLI()
    assert cli.run() == 2

# Generated at 2022-06-10 22:01:12.015471
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    class AdHocCLITester(AdHocCLI):
        @staticmethod
        def get_host_list(inventory, subset, pattern):
            return ['host1', 'host2', 'host3']

        @staticmethod
        def _play_prereqs():
            # get basic objects
            loader = None
            inventory = None
            variable_manager = None
            return loader, inventory, variable_manager

        @staticmethod
        def _play_ds(pattern, async_val, poll):
            return dict(
                name="Ansible Ad-Hoc",
                hosts=pattern,
                gather_facts='no',
                tasks=[{'action': {'module': 'shell', 'args': 'whoami'}, 'timeout': 30}])

        @staticmethod
        def ask_passwords():
            return 'sshpass',

# Generated at 2022-06-10 22:01:22.734456
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' This test is for the method run of class AdHocCLI '''
    # Create object for AdHocCLI class
    try:
        ad_hoc_cli_obj = AdHocCLI()
    except Exception as ex:
        print("Exception while creating object for AdHocCLI class")
        print("Exception message: " + str(ex))
    # Setting values for the instance variables of ad_hoc_cli_obj
    ad_hoc_cli_obj.ask_passwords()
    ad_hoc_cli_obj._play_prereqs()
    ad_hoc_cli_obj.get_host_list()
    ad_hoc_cli_obj._play_ds()
    # Calling run method of AdHocCLI class object

# Generated at 2022-06-10 22:01:24.369379
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    AdHocCLI - run
    """
    pass

# Generated at 2022-06-10 22:01:35.767206
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import unannotated
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    import os

    display = Display()
    display.verbosity = 3

    args = [
            'foo',
            '-m', 'ping',
            '-i', 'inventory',
            '-v',
           ]

    opt = AdHocCLI(args)
    opt.post

# Generated at 2022-06-10 22:01:43.128906
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # unit tests can only be started if a "src/" dir is found, but there is no
    # src dir in galaxy, so this test is skipped there
    import os
    src = os.path.join(os.path.dirname(__file__), "../../../../src")
    if os.path.exists(src):
        from ansible.cli.adhoc import AdHocCLI
        adhoc_cli = AdHocCLI()
        adhoc_cli.options = adhoc_cli.parse()
        adhoc_cli.post_process_args(adhoc_cli.options)
    else:
        adhoc_cli = None

# Generated at 2022-06-10 22:01:54.431180
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class MyCLI(AdHocCLI):
        def __init__(self, args):
            self.allargs = args
            super(MyCLI, self).__init__()

        def init_parser(self):
            super(MyCLI, self).init_parser()
            self.parser.add_argument("-a", "--arg3", dest="arg3", action="store", default="a3")

        def post_process_args(self, options):
            self.allargs.update(vars(options))
            return super(MyCLI, self).post_process_args(options)

        def run(self):
            super(MyCLI, self).run()
            return 0


# Generated at 2022-06-10 22:01:58.117449
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-10 22:02:46.288891
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:02:50.965497
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.init_parser()
    cli.post_process_args(cli.parser.parse_args([]))
    res = cli.run()
    assert res == 0

# Generated at 2022-06-10 22:02:51.670776
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:02:58.683052
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.errors as errors
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from io import StringIO
    from ansible.parsing.splitter import parse_kv
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    test_passwords = None
    test_stdin = StringIO()
    test_stdout = StringIO()
    test_forks = None
    test_ask_sudo_pass = None
    test_ask_su_pass = None
    test_ask_pass = None
    test_verbosity = None
    test_check = None
    test_syntax = None
    test_listhosts = None
    test_listtasks = None
   

# Generated at 2022-06-10 22:03:00.886610
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()



# Generated at 2022-06-10 22:03:01.901016
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

# Generated at 2022-06-10 22:03:08.696452
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import sys
    import unittest

    from ansible.module_utils.six.moves import StringIO

    TEST_DIR = os.path.abspath(os.path.dirname(__file__))
    module_path = os.path.join(TEST_DIR, "..")
    ansible_path = os.path.join(module_path, "..", "..")
    sys.path.insert(0, module_path)
    sys.path.insert(1, ansible_path)

    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.utils.sentinel import Sentinel


# Generated at 2022-06-10 22:03:10.478295
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoccli = AdHocCLI()
    assert isinstance(adhoccli, CLI)

# Generated at 2022-06-10 22:03:11.806449
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()

# Generated at 2022-06-10 22:03:20.222429
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    AdHocCLI run method unit test
    '''
    # Set up needed variables
    class_module = 'AdHocCLI'
    class_name = 'AdHocCLI'

    test_cli = AdHocCLI()
    test_cli._tqm = None
    test_cli.callback = 'callback'

    test_loader = object()
    test_inventory = object()
    test_variable_manager = object()

    test_context = object()

# Generated at 2022-06-10 22:04:56.741799
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(
        args=['-m', 'ping', '-u', 'user', '-k', '-c', 'ssh', '-e', 'key=value', 'host1'],
        async_poll=2,
        connection='ssh',
        forks=3,
        inventory=None,
        listhosts=None,
        module_path=None,
        pattern='host1',
        subset=None,
        syntax=None,
        verbosity=1
    )
    return adhoc

if __name__ == '__main__':
    adhoc = test_AdHocCLI()
    adhoc.parse()
    adhoc.run()

# Generated at 2022-06-10 22:05:01.100482
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context._init_global_context(['ansible-playbook', 'test.yml.tmp'])
    context.CLIARGS['module_name'] = 'command'
    context.CLIARGS['module_args'] = 'echo hello'
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-10 22:05:03.178055
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    res = adhoc.run()
    assert res == 0


# Generated at 2022-06-10 22:05:11.383356
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.module_utils.common.collections import ImmutableDict
    import mock

    # Define mock task callback
    class MockTaskCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(MockTaskCallback, self).__init__

# Generated at 2022-06-10 22:05:21.245103
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:05:23.391279
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.post_process_args()
    adhoc.run()

# Generated at 2022-06-10 22:05:24.627570
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:05:34.850817
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play_context import PlayContext

    config_manager = ConfigManager('')

# Generated at 2022-06-10 22:05:44.821287
# Unit test for constructor of class AdHocCLI

# Generated at 2022-06-10 22:05:52.002480
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import pytest
    with pytest.raises(AnsibleOptionsError) as excinfo:
        CLI.run(['./bin/ansible', '-vv', '-m', 'command', '-a', 'ls', 'localhost', '-u', 'root'])
        print(excinfo)
        assert excinfo == "Provided hosts list is empty (if you are using -i, is it pointing to an existing file?)"