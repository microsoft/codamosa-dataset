

# Generated at 2022-06-10 21:58:30.921046
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, AdHocCLI)

# Generated at 2022-06-10 21:58:38.797505
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import ansible.constants
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # create a loader for the cli
    loader = DataLoader()
    # create the inventory
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    # create the variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create the object under test
    adhoc_cli = AdHocCLI(args=[])
    adhoc_cli._play_prereqs()

# Generated at 2022-06-10 21:58:50.478093
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    parser = CLI.base_parser(
        usage='%prog [options] <host-pattern>',
        epilog="some epilog"
    )
    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_async_options(parser)
    opt_help.add_output_options(parser)
    opt_help.add_connect_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)
    opt_help.add_basedir_options(parser)

# Generated at 2022-06-10 21:59:02.129623
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.module_utils.common._collections_compat import MutableMapping
    import ansible.constants as C
    import sys
    import os
    from io import BytesIO
    from ansible import context
    import ansible.cli.adhoc as CLI_adhoc
    from ansible.cli.adhoc import AdHocCLI
    import six
    import tempfile
    from ansible.utils.display import Display


# Generated at 2022-06-10 21:59:06.836162
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from unittest.mock import patch
    from ansible.errors import AnsibleOptionsError
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.splitter import parse_kv
    from ansible.utils.display import Display



# Generated at 2022-06-10 21:59:20.459349
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit test for method run of class AdHocCLI.

        Since it is not possible to test for the inventory source here,
        tests have been moved to AdHocCLI_test.py in test/integration/targets
    '''
    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # Initialize and run the AdHocCLI
    cli = AdHocCLI()
    cli.parser = cli.create_parser()
    cli.options, cli.args = cli.parser.parse_args([])
    cli.post_process_args(cli.options)

    # Args to be passed

# Generated at 2022-06-10 21:59:22.953029
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

# Generated at 2022-06-10 21:59:25.202936
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli_instance = AdHocCLI()
    result = adhoc_cli_instance
    assert result

# Generated at 2022-06-10 21:59:25.941945
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:29.171318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ Verify if AdHocCLI class returns correct result """
    # TODO: unit test for ad-hoc CLI needs to be written once the CLI option parsing module is ready.
    assert False

# Generated at 2022-06-10 21:59:43.666187
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create an object and call the method
    obj = AdHocCLI(args=['book', 'test'])
    obj.run()

    # assert a callback warning
    assert obj.__dict__['callback'] == 'minimal'

# Generated at 2022-06-10 21:59:55.803600
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    unit test for method run of class AdHocCLI
    """
    from ..units import patch_ansible_module, opts, mock_inventory, mock_options
    from ..units import make_mocked_task_queue_manager, make_mocked_task_queue_manager
    from ansible.cli.adhoc import AdHocCLI
    adhoc = AdHocCLI()
    adhoc.post_process_args(opts)
    adhoc.init_parser()
    patch_ansible_module()
    with mock_inventory([], opts=opts):
        with mock_options(opts):
            with make_mocked_task_queue_manager() as mocked_tqm:
                mocked_tqm.run = lambda x: 0
                assert adhoc.run()

# Generated at 2022-06-10 22:00:07.847590
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test for method run of class AdHocCLI'''
    # Test for when args is not empty

# Generated at 2022-06-10 22:00:11.856747
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible.cli.adhoc import AdHocCLI
    # invoke test coverage for PlayCLI constructor
    # initializes options and parses args
    inv = AdHocCLI(args=["localhost"])

# Generated at 2022-06-10 22:00:13.662156
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=[])
    assert adhoc.parser

# Generated at 2022-06-10 22:00:14.437146
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:00:27.619712
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:00:28.335394
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:00:29.505802
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test = AdHocCLI()


# Generated at 2022-06-10 22:00:41.644696
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C

    def test_method(tmpdir):
        context.CLIARGS['module_name'] = 'ping'
        context.CLIARGS['module_args'] = 'data=hello'
        context.CLIARGS['forks'] = 1
        context.CLIARGS['forks'] = 5
        context.CLIARGS['seconds'] = 10
        context.CLIARGS['poll_interval'] = 60
        context.CLIARGS['listhosts'] = False
        context.CLIARGS['subset'] = None
        context.CLIARGS['verbosity'] = 3

        loader, inventory, variable_manager = self._play_prereqs()
        pattern = 'test'

# Generated at 2022-06-10 22:01:02.681625
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli is not None


if __name__ == '__main__':
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:01:04.930884
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI([])
    assert adhoc is not None
    return adhoc

# Generated at 2022-06-10 22:01:05.564054
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:06.229444
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:08.006937
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    myAdHocCLI = AdHocCLI()
    assert myAdHocCLI is not None

# Generated at 2022-06-10 22:01:08.880774
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:09.549249
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:17.898387
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI.
    '''
    display = Display()

    def display_test(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
        '''
        Test implementation for method display for class Display.
        '''
        print(msg)

    display.display = display_test

    adhoc_cli = AdHocCLI(['-m', 'setup', '172.17.0.2'])
    adhoc_cli.run()

# Generated at 2022-06-10 22:01:20.128025
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run
    '''
    adhoc_test = AdHocCLI()
    adhoc_test.run()

# Generated at 2022-06-10 22:01:24.318159
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Test the run method of AdHocCLI class.
    '''
    # Create an instance of class AdHocCLI
    adhoccli = AdHocCLI(['-m', 'ping', '--listhosts', 'localhost'])
    adhoccli.parse()
    # Run the run method
    adhoccli.run()

# Generated at 2022-06-10 22:02:07.349444
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # basic tests

    # min args
    cli = AdHocCLI([])
    assert cli.run() == 255

    # basic function
    options = cli.parse(['127.0.0.1'])
    assert cli.run() == 0

    # other options (not tested)
    # options = cli.parse(['-f', '127.0.0.1'])
    # options = cli.parse(['-f', '5', '127.0.0.1'])
    # options = cli.parse(['-m', 'ping', '127.0.0.1'])
    # options = cli.parse(['-a', 'ping', '127.0.0.1'])
    # options = cli.parse(['-m', 'ping', '-a

# Generated at 2022-06-10 22:02:11.430181
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    parser = AdHocCLI().parser
    for cur_arg in ('-i', '-a', '-m', 'args'):
        assert cur_arg in parser._actions[-1].option_strings, \
            "AdHocCLI constructor failed to add %s argument" % cur_arg

# Generated at 2022-06-10 22:02:22.940876
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from mock import patch
    from mock import Mock

    from ansible.plugins.loader import module_loader
    # to create a object of class AdHocCLI and call run method on it
    # we need the following three
    # 1 module_loader
    # 2 TaskQueueManager
    # 3 Playbook

    with patch.object(module_loader, 'get_all_plugin_loaders') as mock_get_all_plugin_loaders:
        mock_get_all_plugin_loaders.return_value = []
        loader = Mock()
        loader.path_dwim = Mock()
        loader.path_dwim.return_value = '/tmp'

        with patch.object(TaskQueueManager, '__init__') as mock_TaskQueueManager:
            mock_TaskQueueManager.return_value = None

# Generated at 2022-06-10 22:02:32.238474
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # test command line arguments parsing
    test_args = [
        "127.0.0.1",
        "-m ping",
        "-i", "foo",
        "--list-hosts",
        "-f", "5",
        "-v",
    ]

    # skip test for Python 2.6, where argument parsing fails
    import sys
    if sys.version_info[:2] == (2, 6):
        sys.stderr.write("Skip argument parsing test (Python 2.6)\n")

# Generated at 2022-06-10 22:02:41.227364
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli._play_prereqs = lambda: (None, None, None)
    cli.get_host_list = lambda *args, **kwargs: [object()]
    cli._play_ds = lambda *args, **kwargs: dict(
        name="Ansible Ad-Hoc", hosts=args[0], gather_facts='no', tasks=[dict(action=dict(module='ping', args=None), timeout=None)])
    cli.run()

# Generated at 2022-06-10 22:02:44.395734
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    obj = AdHocCLI(args=['localhost', '--module-name', 'command', '--module-args', '"echo \'foo\'"'])
    assert obj.run() == 0


# Generated at 2022-06-10 22:02:55.220320
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Fake class for testing
    class MyCLI(AdHocCLI):

        def __init__(self):
            super(MyCLI, self).__init__()
            self.host_list = None
            self.subset = None
            self.pattern = None
            self.listhosts = None
            self.module_name = None
            self.module_args = None
            self.seconds = None
            self.poll_interval = None
            self.tree = None
            self.verbosity = None
            self.one_line = None

        # Return the value of the attributes

# Generated at 2022-06-10 22:03:06.172703
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli import CLI
    import os
    import pytest

    # load methods
    cli = CLI()
    cli._tqm = 'test_value'
    cli.ask_passwords = lambda x: (None, None)

    # test with fake return values
    cli.post_process_args = lambda x: {}
    cli.get_host_list = lambda x, y, z: ['test_host']
    cli._play_prereqs = lambda: ('loader', 'inventory', 'variable_manager')

# Generated at 2022-06-10 22:03:07.512322
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    obj = AdHocCLI(args=[])

# Generated at 2022-06-10 22:03:09.722965
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-10 22:04:22.333462
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)

# Generated at 2022-06-10 22:04:24.247395
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Need to properly mock this class to fully test it.
    assert 1 == 1

# Generated at 2022-06-10 22:04:35.651506
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    import textwrap

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from lib import graphite

    (fd, fdname) = tempfile.mkstemp()

    ad_hoc_playbook = textwrap.dedent("""\
    - hosts: localhost
      connection: local
      tasks:
        - graphite:
            host: localhost
            port: 2003
            metric: my.ansible.test
            state: present
            value: "{{ lookup('env','USER') }}"
            """)

    os.write(fd, to_text(ad_hoc_playbook).encode('utf-8'))
    os.close(fd)

    ad_hoc_playbook

# Generated at 2022-06-10 22:04:39.198057
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create instance of class AdHocCLI with valid arguments
    cli = AdHocCLI(args='-i ./tests/unit/inventory localhost -m ping')
    assert cli.run() == 0

# Generated at 2022-06-10 22:04:47.423970
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ adhoc_cli = AdHocCLI(args) """

    args = ['-m', 'ping', 'localhost']
    adhoc_cli = AdHocCLI(args)
    assert adhoc_cli.parser._prog_name == 'ansible'
    assert adhoc_cli.parser._usage == "%prog <host-pattern> [options]"
    assert adhoc_cli.parser._description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-10 22:04:50.474767
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # for now tests just invoke the CLI and assert that it does not have exceptions.
    # This does basic parsing of arguments and creation of objects for the AdHocCLI run() method.
    cli = AdHocCLI(['localhost'])
    cli.run()

# Generated at 2022-06-10 22:04:51.189140
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()

# Generated at 2022-06-10 22:05:00.796094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    with pytest.raises(AnsibleError):
        cli_adhoc_obj = AdHocCLI()
        cli_adhoc_obj.run()

    with pytest.raises(AnsibleOptionsError):
        cli_adhoc_obj = AdHocCLI()

# Generated at 2022-06-10 22:05:09.894895
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.cli.adhoc as adhoc

    adhoc.display = mocker.MagicMock(name="display")
    adhoc.CLI.ask_passwords = mocker.MagicMock(name="ask_passwords")
    adhoc.CLI._play_prereqs = mocker.MagicMock(name="_play_prereqs")
    adhoc.CLI.get_host_list = mocker.MagicMock(name="get_host_list")
    adhoc.AdHocCLI._play_ds = mocker.MagicMock(name="_play_ds")
    adhoc.Play = mocker.MagicMock(name="Play")
    adhoc.Playbook = mocker.MagicMock(name="Playbook")


# Generated at 2022-06-10 22:05:20.508239
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # ansible-test units --python -v --pylint adhoc
    # ansible-test units --python -v --pylint adhoc test_AdHocCLI_run
    # ansible-test units --python -v --pylint adhoc AdHocCLI
    #
    # ansible-test units --python -v --coverage --coverage-check --pylint adhoc
    # ansible-test units --python -v --coverage --coverage-check --pylint adhoc test_AdHocCLI_run

    results = AdHocCLI(['pattern']).run()
    assert results == 0