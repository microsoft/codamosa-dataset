

# Generated at 2022-06-10 21:58:25.485621
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = opt_help.parse()[0]
    context.CLIARGS['subset'] = None
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = None

    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.run()

# Generated at 2022-06-10 21:58:32.366076
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 4

    loader = DataLoader()

    # Fake inventory
    inventory = Inventory(loader=loader, variable_manager=VariableManager(),  host_list='tests/unit/inventory_malformed')

    # Fake play

# Generated at 2022-06-10 21:58:33.583141
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:37.363379
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    adhoc = AdHocCLI()

    assert hasattr(adhoc, 'init_parser')
    assert hasattr(adhoc, 'post_process_args')
    assert hasattr(adhoc, 'run')

# Generated at 2022-06-10 21:58:48.935324
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
     from mock import Mock
     from ansible.module_utils.facts.system.distribution import Distribution
     from ansible.module_utils.facts.system.distribution import LinuxDistribution
     from ansible.module_utils.facts.system.network import Network

     distribution = Mock(spec=Distribution)
     distribution.name = 'Debian'
     distribution.version = '9.8'
     distribution.codename = 'stretch'

     linux_distribution = Mock(spec=LinuxDistribution)
     linux_distribution.distribution = distribution
     linux_distribution.major_version = '9'

     network = Mock(spec=Network)
     network.interfaces = 'dummy'

     AdHocCLI = adhoc.AdHocCLI()
     AdHocCLI.post_process_args = Mock()


# Generated at 2022-06-10 21:58:51.134390
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    obj = AdHocCLI({}, runas=None)
    assert obj

# Generated at 2022-06-10 21:58:53.297332
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_run = AdHocCLI()
    adhoc_run.run()

# Generated at 2022-06-10 21:58:55.003172
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:02.122686
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # construct adhoc object
    adhoc = AdHocCLI()

    # setup some args
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = ''
    context.CLIARGS['pattern'] = 'localhost'
    context.CLIARGS['listhosts'] = None
    context.CLIARGS['listtasks'] = None
    context.CLIARGS['listtags'] = None
    context.CLIARGS['one_line'] = None
    context.CLIARGS['tree'] = None
    context.CLIARGS['forks'] = 1
    context.CLIARGS['poll_interval'] = 15
    context.CLIARGS['seconds'] = None

   

# Generated at 2022-06-10 21:59:04.009659
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI(None)
    adhoc.run()

# Generated at 2022-06-10 21:59:11.951713
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adHocCLI = AdHocCLI(["test"])
    adHocCLI.run()

# Generated at 2022-06-10 21:59:14.241264
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 21:59:16.630730
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 21:59:17.856840
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

# Generated at 2022-06-10 21:59:25.557191
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    import unittest
    from ansible.cli.adhoc import AdHocCLI
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.playbook_test import strip_internal_keys, strip_keys

    class CLIArgs(object):
        def __init__(self, entries=dict()):
            self.__dict__.update(entries)

    def generate_args(entries=dict()):
        return CLIArgs(entries)

    class DisplayMock(object):
        def __init__(self):
            self._message = ''
            self._level = 0

        @property
        def message(self):
            return self._message

        @property
        def level(self):
            return self._level


# Generated at 2022-06-10 21:59:31.253262
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible.cli.adhoc import AdHocCLI

    # for now, just a test of the construction
    adhoc = AdHocCLI(['-h'])
    assert adhoc is not None


if __name__ == '__main__':
    AdHocCLI(['-h']).run()

# Generated at 2022-06-10 21:59:33.362313
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc != None

# Generated at 2022-06-10 21:59:34.506524
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:37.960055
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.args = '-m ping localhost'
    cli.options = ''
    cli.post_process_args()
    cli.run()

# Generated at 2022-06-10 21:59:45.309393
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Run the test in an isolated environment
    with test_utils.isolated_environ():
        adhoc_cli = AdHocCLI()
        adhoc_cli.parser = create_parser()
        adhoc_cli.options, adhoc_cli.args = adhoc_cli.parser.parse_args()
        assert adhoc_cli.run() == 0


# Generated at 2022-06-10 22:00:03.909322
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import iteritems
    # test init_parser
    cli = AdHocCLI()
    cli.init_parser()
    # test post_process_args
    options = cli.post_process_args(dict())
    assert(isinstance(options, Mapping))
    assert(all(v == 0 for v in options.values()))
    # test run
    print("Skip test_AdHocCLI_run")
    pass

# Generated at 2022-06-10 22:00:05.312258
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:00:17.819499
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create and execute the single task playbook
    import sys
    import unittest
    from ansible.plugins.loader import module_loader, fragment_loader
    module_loader.add_directory('./lib/ansible/modules/')
    fragment_loader.add_directory('./lib/ansible/module_utils')
    sys.modules['ansible.module_utils.six'] = __import__('ansible.module_utils.six')
    # TODO: handle user different values in default_vars of hosts
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    C.FORKS=1
    C.ANSIBLE_STDOUT_CALLBACK = 'debug'
    # TODO: use localhost instead of a random server
    # TODO: handle user different values in default_vars

# Generated at 2022-06-10 22:00:19.746522
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoccli = AdHocCLI()


# Generated at 2022-06-10 22:00:31.435207
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    unit test for constructor of class AdHocCLI
    """

    # get the object
    obj = AdHocCLI()

    # class instance verification
    assert isinstance(obj, AdHocCLI)
    assert isinstance(obj.parser, optparse.OptionParser)
    assert isinstance(obj.parser._actions[1], optparse._VersionAction)
    assert isinstance(obj.parser._actions[2], optparse._SubParsersAction)

    # check the parser options
    assert '-C, --check, --syntax-check' in str(obj.parser._actions[6])
    assert '--inventory-file' in str(obj.parser._actions[6])
    assert '--extra-vars' in str(obj.parser._actions[6])

    # check properties
    assert obj.sub

# Generated at 2022-06-10 22:00:44.105733
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from units.compat import unittest
    from units.compat.mock import patch, MagicMock

    from ansible.cli import CLI

    # Functions used to define the steps of the mock
    def cleanup():
        pass
    def cleanup_all_tmp_files():
        pass
    def get_host_list(inventory, subset, pattern):
        return MagicMock(name='hosts')
    def load(play_ds, variable_manager, loader):
        return MagicMock(name='play')
    def send_callback(self, cmd, playbook):
        pass
    def run(self, play):
        pass
    def load_callbacks(self):
        pass

    # Mock used to run the command

# Generated at 2022-06-10 22:00:51.803801
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def ask_passwords():
        rt = ['', '']
        return rt

    adhoc = AdHocCLI()
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'subset': False, 'listhosts': False, 'seconds': '', 'poll_interval': '', 'args': 'test'}
    adhoc.ask_passwords = ask_passwords
    adhoc.run()

# Generated at 2022-06-10 22:00:57.827449
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Runable:
        def __init__(self):
            self.display = display
    class Test(AdHocCLI):
        def __init__(self):
            self.test = Runable()
            self.callback = None
    test = Test()
    test.test.verbosity = 0
    test.post_process_args({})
    assert test.run() == 0

# Generated at 2022-06-10 22:00:59.072696
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:00.581245
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-10 22:01:47.093259
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        import __main__
        __main__.display = Display()
    except ImportError:
        pass

    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a new AdHocCLI
    cli = AdHocCLI()

    # Create a mock object for the options
    class Options(object):
        pass

    # Create a mock object for the context
    class Context(object):
        def __init__(self):
            self.CLIARGS={}
            self.CLIARGS['module_name'] = 'copy'
            self.CLIARGS['module_args'] = 'src= /etc/hosts dest=/tmp'

# Generated at 2022-06-10 22:01:58.652099
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # it is required to avoid  https://github.com/ansible/ansible/issues/56175
    constants.DEFAULT_PRIVATE_ROLE_VARS = False


# Generated at 2022-06-10 22:02:07.303542
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from collections import namedtuple

# Generated at 2022-06-10 22:02:14.089308
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """test_AdHocCLI_run"""
    exit_code = None
    try:
        cli_instance = AdHocCLI()
        cli_instance.options = opt_help.parse([])
        cli_instance.parser = opt_help.parser
        cli_instance.parser = opt_help.parser
        cli_instance.options = opt_help.parse(['--listhosts', 'all'])
        cli_instance.run()
    except SystemExit as e:
        exit_code = e.code
    #assert exit_code == 0

# Generated at 2022-06-10 22:02:27.112246
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create and populate an object of class AdHocCLI
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.options = opt_help.parse_connection_options({})
    ad_hoc_cli.options.subset = None
    ad_hoc_cli.options.listhosts = None
    ad_hoc_cli.options.module_name = 'shell'
    ad_hoc_cli.options.module_args = 'echo hello'
    ad_hoc_cli.options.forks = 10
    ad_hoc_cli.options.httpapi = None
    ad_hoc_cli.options.new_vault_password_file = None
    ad_hoc_cli.options.timeout = 10
    ad_hoc_cli.options.tree = None


# Generated at 2022-06-10 22:02:28.067764
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli is not None

# Generated at 2022-06-10 22:02:31.794414
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    adhoc_cli.post_process_args(parser)
    assert AdHocCLI

# Generated at 2022-06-10 22:02:33.485237
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-10 22:02:36.589082
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    sys.argv = ['ansible', '-m', 'setup', 'host1,host2']
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:02:37.788741
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:04:10.297520
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class AnsibleHosts:
        def __init__(self, hostname):
            self.name = hostname
            self.vars = {}
    class AnsibleOptions:
        def __init__(self):
            self.connection = 'ssh'
            self.forks = 10
            self.ask_pass = False
            self.ask_become_pass = False
            self.verbosity = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.listhosts = None
            self.module_name = 'ping'
            self.module_path = None
            self.module_args = None
            self.one_line = None
            self.output_file = None
            self.tree = None

# Generated at 2022-06-10 22:04:19.646487
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # mock options
    m_options = {'listhosts': False,
                 'module_name': 'shell',
                 'module_args': None,
                 'one_line': False,
                 'verbosity': 0,
                 'ask_pass': False,
                 'ask_vault_pass': False,
                 'ask_become_pass': False,
                 'become': False,
                 'become_ask_pass': False}

    # mock class method
    class Mock_get_host_list(object):
        def __init__(self, inventory, subset, pattern):
            self.pattern = pattern
            self.subset = subset
            self.inventory = inventory
        def __call__(self):
            return ['192.168.1.1']

    # mock class method

# Generated at 2022-06-10 22:04:28.860399
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = 'localhost -m ping'
    adhoc = AdHocCLI([b'ansible', b'-m', b'ping', b'localhost'])
    assert(adhoc.run() == 0)
    adhoc = AdHocCLI([b'ansible', '-m', b'ping', b'localhost'])
    assert(adhoc.run() == 0)
    adhoc = AdHocCLI(['ansible', '-m', 'ping', 'localhost'])
    assert(adhoc.run() == 0)

# Generated at 2022-06-10 22:04:30.160998
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # FIXME: add a unit test
    assert False

# Generated at 2022-06-10 22:04:38.065122
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import datetime
    import pytest
    from collections import namedtuple
    from ansible.errors import AnsibleOptionsError
    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

# Generated at 2022-06-10 22:04:40.744633
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI()
    assert isinstance(adHocCLI, CLI)


# Generated at 2022-06-10 22:04:43.719286
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    adhoc_cli.run()

# Generated at 2022-06-10 22:04:52.572648
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    module_name = 'setup'
    module_args = 'ansible_test_test_key=test_value'
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-10 22:05:02.278451
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    display = Display()
    display._verbosity = 10
    display._output_handler = None


# Generated at 2022-06-10 22:05:03.518762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()