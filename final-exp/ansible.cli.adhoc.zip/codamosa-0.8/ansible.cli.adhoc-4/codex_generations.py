

# Generated at 2022-06-10 21:58:23.312038
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 21:58:30.030078
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Instantiate CLI object
    cli = AdHocCLI()
    # Call method
    cli.run()
    # Check object has instance attribute _tqm
    assert hasattr(cli, '_tqm') is True
    # Check _tqm is an instance of TaskQueueManager
    assert isinstance(cli._tqm, TaskQueueManager) is True
    # Check _tqm has required attributes
    assert hasattr(cli._tqm, 'cleanup') is True
    assert hasattr(cli._tqm, 'send_callback') is True
    assert hasattr(cli._tqm, 'run') is True

# Generated at 2022-06-10 21:58:30.666963
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:31.986703
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_obj = AdHocCLI()
    assert adhoc_obj

# Generated at 2022-06-10 21:58:34.342263
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO
    # this method is called in __main__ of file adhoc.py,
    # which has not been run in unit test, so this method cannot be tested
    # by unit test.
    pass

# Generated at 2022-06-10 21:58:34.926108
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:35.426414
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:36.016917
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:47.963017
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = parse_kv('ansible --ask-pass')
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = '-a "data=blah"'
    context.CLIARGS['pattern'] = 'all'
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['ask_pass'] = True
    context.CLIARGS['ask_become_pass'] = False
    context.CLIARGS['seconds'] = False
    context.CLIARGS['poll_interval'] = 0
    context.CLIARGS['one_line'] = False
    context.CLIARGS['tree'] = ''
    context.CLIARGS['forks'] = 5
    context.CL

# Generated at 2022-06-10 21:58:55.214926
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no interaction
    display.verbosity = 3
    options = context.CLIARGS
    options['module_name'] = 'shell'
    options['module_args'] = 'echo hello'
    options['listhosts'] = False
    options['tree'] = '/tmp/ansible/adhoc'
    options['forks'] = 10
    base_obj = AdHocCLI(options)
    base_obj.run()

# Generated at 2022-06-10 21:59:17.232022
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli._play_ds = mock.MagicMock()
    ad_hoc_cli.ask_passwords = mock.MagicMock()
    ad_hoc_cli._play_prereqs = mock.MagicMock()
    ad_hoc_cli.get_host_list = mock.MagicMock()
    ad_hoc_cli.callback = mock.MagicMock()
    result = ad_hoc_cli.run()
    assert result is not None


if __name__ == "__main__":
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from io import StringIO
    import pytest
    import sys


# Generated at 2022-06-10 21:59:24.944633
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.shlex import shlex_split
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.plugins.loader import module_loader

    def _init_parser(self):
        # This is what AdHocCLI.init_parser actually does
        self.parser = opt_help.base_parser(constants=self.constants,
                                           configure_env=True, version=self.version)
        opt_help.add_runas_options(self.parser)
        opt_help.add_inventory_options(self.parser)
        opt_help.add_async_options(self.parser)
        opt_help.add_output_options(self.parser)
        opt_help.add_connect_options(self.parser)

# Generated at 2022-06-10 21:59:26.936218
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()
    # TODO: assert more

# Generated at 2022-06-10 21:59:33.987015
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create subprocess as a context manager to ensure the test process is killed.
    with subprocess.Popen(['ansible', 'localhost', '-m', 'test', '-a', '"a=1"', '-o'],
            stdout=subprocess.PIPE, bufsize=0) as p:
        # wait for the process to terminate
        while p.poll() is None:
            # read line without blocking
            line = p.stdout.readline()
            # line is not empty
            assert line

    return

# Generated at 2022-06-10 21:59:35.864227
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad = AdHocCLI()
    assert ad

# Generated at 2022-06-10 21:59:48.220464
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI
    import io

    # Set up CLI object to test run of class AdHocCLI
    cli = CLI(args=[u'--tree', u'/home/arista/ansible-playbooks/out/test_play', u'--forks', u'10',
                    u'--module-name', u'ping', u'--module-args', u'', u'-vvvv',
                    u'-i', u'localhost,', u'localhost'])

    # Set up adhoc_cli object using the CLI object
    adhoc_cli = AdHocCLI(cli.args)

    # Create the fake output capture object
    fake_stdout = io.StringIO()

# Generated at 2022-06-10 21:59:59.127141
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = Inventory(loader, {
            "all": {
                "hosts": ["host1", "host2"],
                "children": ["ungrouped"]
            },
            "ungrouped": {
                "hosts": ["host3", "host4"]
            }
        })
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # construct playbook objects to wrap task

    play

# Generated at 2022-06-10 22:00:09.702801
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:00:15.601922
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoccli = AdHocCLI()
    assert isinstance(adhoccli, AdHocCLI)
    assert adhoccli.init_parser() is None
    assert adhoccli.post_process_args(adhoccli.options)
    assert isinstance(adhoccli.run(), int)


# Generated at 2022-06-10 22:00:17.016315
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run(None, None)

# Generated at 2022-06-10 22:00:34.114652
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-10 22:00:45.966244
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.playbook.play import Play
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugin_loader import PluginLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    #from ansible.inventory.host import Host, HostPattern
    o = AdHocCLI()
    o.init_parser()

# Generated at 2022-06-10 22:00:47.285174
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad = AdHocCLI()
    ad.run()

# Generated at 2022-06-10 22:00:56.152228
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ Unit test for AdHocCLI.run() """

    display = Display()
    display.verbosity = 1

    class MockOptions():
        """ Mock object for the options needed by AdHocCLI """

        def __init__(self):
            self.module_name = 'command'
            self.args = 'ls'
            self.module_args = None
            self.forks = 10
            self.connection = 'paramiko'
            self.become = False
            self.become_user = None
            self.become_method = None
            self.become_ask_pass = False
            self.remote_user = None
            self.ask_pass = False
            self.private_key_file = None
            self.verbosity = 0
            self.check = False
            self.diff = False
           

# Generated at 2022-06-10 22:01:00.639083
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI

    cli = AdHocCLI(args=['localhost', '-m', 'test', '-a', 'arg="foo"', '-b'])

    result = cli.run()

    assert(result == 0)

# Generated at 2022-06-10 22:01:11.970740
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''
    p = AdHocCLI()
    p._play_ds = lambda pattern, async_val, poll: dict(
        name="Ansible Ad-Hoc",
        hosts=pattern,
        gather_facts='no',
        tasks=[
            dict(
                action=dict(
                    module='ping',
                    args=dict(
                    )
                ),
                timeout=10
            )
        ]
    )
    p._play_prereqs = lambda: (None, None, None)
    p.callback = 'minimal'
    p.get_host_list = lambda inventory, subset, pattern: ['test1.com']
    p.ask_passwords = lambda: (None, None)

# Generated at 2022-06-10 22:01:15.212329
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    args = []
    loader_ = None
    command_ = 'test_command'
    context_ = None
    cli = AdHocCLI(args, loader_, command_, context_)
    return True

# Generated at 2022-06-10 22:01:19.045189
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    testargs = 'ansible -m ping -a "data=testarg" localhost'.split()
    cli = AdHocCLI(args=testargs)
    assert isinstance(cli, CLI)

# Generated at 2022-06-10 22:01:19.654089
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:29.056404
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ##################################################################################
    #
    # Method test preparation
    #
    ##################################################################################
    #
    # Argument parsing using command
    #
    #     ansible --version
    #
    # This will parse the command line arguments and return the namespace object
    # containing the selected options.
    #
    import argparse
    parser = argparse.ArgumentParser()

    # Set up arguments for the command line
    #
    # For example:
    #
    #  parser.add_argument(
    #    '-m',
    #    '--module_name',
    #    dest='module_name',
    #    help="Module name (default=%s)" % C.DEFAULT_MODULE_NAME,
    #    default=C.DEFAULT_MODULE_NAME
    #  )

    #

# Generated at 2022-06-10 22:02:00.277292
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:02:02.364342
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-10 22:02:03.905758
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli

# Generated at 2022-06-10 22:02:05.037348
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement test
    print('\nNot implemented yet')

# Generated at 2022-06-10 22:02:14.494747
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import context
    from ansible.plugins.loader import callback_loader

    conn_pass = 'secret'
    become_pass = 'secret'

# Generated at 2022-06-10 22:02:17.569158
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    c = AdHocCLI()
    c.post_process_args(dict())
    c.run()

# Generated at 2022-06-10 22:02:28.436777
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test for method run of class AdHocCLI'''

    class Options:
        listhosts = None
        subset = None
        module_path = None
        extra_vars = []
        forks = C.DEFAULT_FORKS
        ask_vault_pass = False
        vault_password_files = []
        new_vault_password_file = None
        output_file = None
        one_line = False
        tree = None
        ask_pass = False
        private_key_file = None
        remote_user = None
        connection = None
        timeout = C.DEFAULT_TIMEOUT
        ssh_common_args = None
        sftp_extra_args = None
        scp_extra_args = None
        ssh_extra_args = None
        verbosity = 3
        syntax = False

# Generated at 2022-06-10 22:02:30.916924
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # pylint: disable=unused-variable
    ad_cli = AdHocCLI([])

# Generated at 2022-06-10 22:02:43.379933
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse
    import sys
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    adhoc_cli = AdHocCLI()

    p = argparse.ArgumentParser()
    adhoc_cli.init_parser()
    options = p.parse_args([
        '-i', 'hosts', '--list-hosts', 'host1',
        '-m', 'ping'
    ])
    adhoc_cli.post_process_args(options)
    adhoc_cli.parse()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['hosts'])

    # get list of

# Generated at 2022-06-10 22:02:44.232421
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:03:48.288110
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:03:48.968503
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:03:53.418220
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    args = '-m ping -a "data=hello world" localhost'.split()
    adhoc = AdHocCLI(args)

    assert adhoc.parser._get_args(['-m ping -a "data=hello world" localhost']).args == ['localhost']
    assert adhoc.parser._get_args(['-m ping -a "data=hello world" localhost']).module_name == 'ping'
    assert adhoc.parser._get_args(['-m ping -a "data=hello world" localhost']).module_args == 'data=hello world'

# Generated at 2022-06-10 22:04:02.061625
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an AdHocCLI object and set one_line context
    adhoc = AdHocCLI()
    context.CLIARGS = {'one_line': True}

    # Create an AnsibleError object
    an = AnsibleError()

    # Test cases if exception is raised
    try:
        adhoc.run()
    except:
        an.parsing = True
    assert an.parsing is True

    try:
        adhoc.run()
        adhoc._play_ds(pattern, async_val, poll)
    except:
        an.parsing = True
    assert an.parsing is True

# Generated at 2022-06-10 22:04:13.344576
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:04:14.644932
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad = AdHocCLI()
    assert ad

# Generated at 2022-06-10 22:04:21.937980
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:04:34.519601
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {'one_line': False}
    context.CLIARGS = {'tree': 'outdir'}
    context.CLIARGS = {'module_name': 'ping'}
    context.CLIARGS = {'module_args': 'arg1'}
    context.CLIARGS = {'forks': 10}
    context.CLIARGS = {'args': 'host_pattern'}
    context.CLIARGS = {'seconds': 10}
    context.CLIARGS = {'poll_interval': 10}
    context.CLIARGS = {'subset': False}
    context.CLIARGS = {'listhosts': True}
    cli_adhoc = AdHocCLI()
    #Will throw TypeError when call this function

# Generated at 2022-06-10 22:04:46.332985
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.parsing.dataloader import DataLoader

    # create an arg parser with subparsers for modules
    adhoccli = AdHocCLI([])
    adhoccli.optparser.add_argument('-i', '--inventory', default='/etc/ansible/hosts,/etc/ansible/hosts2')

    adhoccli.options = adhoccli.post_process_args(adhoccli.optparser.parse_args([
        '-i', '/etc/ansible/hosts',
        '-a', 'ls /tmp',
        'host1',
        'host2',
        'host3',
    ]))

    loader = DataLoader()

    # setup context

# Generated at 2022-06-10 22:04:48.627210
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])
    assert cli.parser
    assert cli._tqm is None



# Generated at 2022-06-10 22:07:58.439228
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()
    assert isinstance(a, AdHocCLI)

# Generated at 2022-06-10 22:08:04.549240
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test method run of class AdHocCLI
    """

    from ansible.cli.adhoc import AdHocCLI
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from units.mock.plugins.module_loader import AnsibleModule
    from units.mock.plugins.callback import CallbackBase

    add_all_plugin_dirs()

    class TestCallback(CallbackBase):
        """
        A test callback
        """

        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.verbose = False


# Generated at 2022-06-10 22:08:05.094294
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:08:08.191226
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    obj = AdHocCLI(['-h'])
    assert obj._usage == '%prog <host-pattern> [options]'
    assert obj.parser._actions[4].dest == 'inventory'
