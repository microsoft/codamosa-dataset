

# Generated at 2022-06-10 21:58:20.941948
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:27.254894
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_obj = AdHocCLI(['-m', 'test', '-a', '1=2', 'test_host'])
    adhoc_obj.parser.parse_args()
    assert context.CLIARGS['module_name'] == 'test'
    assert context.CLIARGS['module_args'] == '1=2'
    assert context.CLIARGS['args'] == 'test_host'

# Generated at 2022-06-10 21:58:30.528605
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-10 21:58:33.189167
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """Test constructor"""
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-10 21:58:35.517798
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-10 21:58:43.869624
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cls = AdHocCLI
    # Initialize a AdHocCLI object
    obj = cls()
    # Set value of private members to be tested here
    # It is not needed if there is no private members
    # Set values of public members
    # It is not needed if there is no public members
    obj.callback = None
    # Call method run of the class to be tested
    res = obj.run()
    # Check that result is as expected
    assert(res == 0)


# Generated at 2022-06-10 21:58:44.542926
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-10 21:58:52.972899
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C


# Generated at 2022-06-10 21:58:55.099831
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI(args=[])
    adhoc_cli.run()

# Generated at 2022-06-10 21:59:00.939725
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli._tqm is None
    assert adhoc_cli._display is None
    assert adhoc_cli.options is None
    assert adhoc_cli.args is None
    assert adhoc_cli.parser is None
    assert adhoc_cli.subparser is None


# Generated at 2022-06-10 21:59:18.392114
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import sys
    import pytest
    sys.argv = [sys.argv[0]]
    cli = AdHocCLI(sys.argv[1:])
    assert cli.run() == 0
    sys.argv = [sys.argv[0], '--foo']
    with pytest.raises(AnsibleOptionsError):
        cli = AdHocCLI(sys.argv[1:])


# Generated at 2022-06-10 21:59:19.763429
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()


# Generated at 2022-06-10 21:59:23.059575
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    assert ad_hoc_cli

# Generated at 2022-06-10 21:59:35.573126
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test method run of class AdHocCLI
    """
    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI

    # Test with empty CLIARGS

# Generated at 2022-06-10 21:59:36.946585
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc._play_ds

# Generated at 2022-06-10 21:59:44.374510
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_obj = AdHocCLI(['-a', 'df -h', '-m', 'shell', 'localhost'])
    assert isinstance(adhoc_obj, AdHocCLI)
    assert 'AdHocCLI' == adhoc_obj.__class__.__name__


# Generated at 2022-06-10 21:59:45.021878
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:47.489269
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()

# Generated at 2022-06-10 21:59:52.959861
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    loader = None
    inventory = None
    variable_manager = None
    passwords = {}
    callback = None
    one_line = False
    display.verbosity = 2

    # Create an AnsibleOptions object
    options = context.CLIARGS
    options['module_name'] = 'setup'
    options['module_args'] = "filter=ansible_distribution*"
    options['subset'] = None
    options['verbosity'] = 2
    options['listhosts'] = False
    options['seconds'] = None
    options['poll_interval'] = None

    # Create a AdHocCLI object
    cli = AdHocCLI()

    # Create a Play object
    play_ds = cli._play_ds('localhost', None, None)

# Generated at 2022-06-10 22:00:03.761229
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class _TestCLI(object):
        def __init__(self):
            self.args = None
            self.options = None
            self.subset = None

    class _TestOptions(object):
        def __init__(self):
            self.ask_pass = False
            self.ask_become_pass = True
            self.check = False
            self.listhosts = False
            self.module_name = 'file'
            self.module_path = None
            self.module_paths = None
            self.one_line = False
            self.tree = None
            self.verbosity = None

    test_args = "localhost"

    # Test case 1: Ask becoming password
    test_options = _TestOptions()
    context.CLIARGS = context.CLIARGS_EMPTY
    context

# Generated at 2022-06-10 22:00:22.530526
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:00:34.018170
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    playbook = Playbook()
    playbook._entries = []
    playbook._file_name = '__adhoc_playbook__'
    pattern = 'local'

    adhoc.callback = 'oneline'
    context.CLIARGS['module_name'] = 'test'
    context.CLIARGS['module_args'] = 'abc'
    context.CLIARGS['seconds'] = 0
    context.CLIARGS['poll_interval'] = 0

    play_ds = adhoc._play_ds(pattern, 0, 0)
    play = Play().load(play_ds, variable_manager=None, loader=None)

    playbook._entries.append(play)
    context.CLIARGS['listhosts'] = True


# Generated at 2022-06-10 22:00:37.305667
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ansible ad-hoc cli unit test
    '''
    adhoc_cli = AdHocCLI()
    assert adhoc_cli

# Generated at 2022-06-10 22:00:48.161601
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    display = Display()
    display.verbosity = 1
    args = ['-m', 'testmodule', 'testpattern']
    options = {'module_name': 'testmodule', 'module_args': {'testmodule': {}},
               'args': ['testpattern'], 'become': None,
               'become_method': None, 'become_user': None,
               'verbosity': 1, 'check': False}
    cli = AdHocCLI(args)
    cli.post_process_args(options)
    with patch('ansible.cli.AdHocCLI._play_prereqs') as mockplay:
        loader = DictDataLoader()
        inventory = MagicMock()
        variable_manager = MagicMock()
        mockplay.return_value = (loader, inventory, variable_manager)

# Generated at 2022-06-10 22:00:56.476636
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    cwd = os.getcwd()
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    module_path = os.path.join(os.getcwd(), 'args.py')
    with open(module_path, 'w') as fp:
        fp.write("#!/bin/env python\nfrom __future__ import (absolute_import, division, print_function)\nfrom ansible.module_utils.basic import AnsibleModule\nfrom ansible.module_utils._text import to_bytes\nfrom ansible.utils.display import Display\ndisplay = Display()\ndef main():\n    module = AnsibleModule(\n        argument_spec=dict(\n        ))\n")

# Generated at 2022-06-10 22:01:05.298875
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Instantiate AdHocCLI class
    obj = AdHocCLI()
    # Instantiate AdHocCLI.args class
    obj.args = AdHocCLI.args()
    # Configure AdHocCLI.args
    obj.args.module_name = 'command'
    obj.args.module_args = 'hostname'
    obj.args.args = 'localhost'
    # Invoke AdHocCLI.run()
    obj.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-10 22:01:06.323064
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:01:07.737393
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initialize the test
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-10 22:01:09.122525
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:01:10.255716
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI(None).run()

# Generated at 2022-06-10 22:01:47.543246
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:01:52.938962
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=[])
    cli.parser = cli.create_parser()
    cli.options, cli.args = cli.parser.parse_args([])
    cli.post_process_args(cli.options)
    with pytest.raises(AnsibleOptionsError):
        cli.run()

# Generated at 2022-06-10 22:01:58.475479
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # setup
    import mock
    import sys

    # setup mocks
    monkeypatch = mock.patch.dict("sys.modules", {'ansible': mock.MagicMock()})
    monkeypatch.start()

    # mock out class AdHocCLI
    def mock_get_host_list(inventory, subset, pattern):
        return True
    def mock_ask_passwords():
        return True, True
    def mock_play_prereqs():
        return True, True, True

    fake_self = mock.MagicMock()
    fake_self._tqm = None
    fake_self.validate_conflicts = mock.MagicMock(return_value=True)
    fake_self.get_host_list = mock.MagicMock(side_effect=mock_get_host_list)
    fake

# Generated at 2022-06-10 22:02:02.661844
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # FIXME: This method is untestable, as it interacts with ansible-playbook,
    # which itself calls sys.exit() on errors.  This test method needs to be
    # converted to a proper unit test, which will require further refactoring
    # of the CLI code base.
    pass

# Generated at 2022-06-10 22:02:04.114508
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser

# Generated at 2022-06-10 22:02:05.312258
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    adhoc = AdHocCLI()
    '''
    pass

# Generated at 2022-06-10 22:02:07.576942
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=['localhost', '-m', 'ping'])
    result = cli.run()
    assert result == 0

# Generated at 2022-06-10 22:02:15.885737
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # AdHocCLI gives one more "ansible" in bin/ansible CLI
    # So, _init_parser is just added here for testing
    def _init_parser():
        return 1

    ad_hoc = AdHocCLI()
    ad_hoc._init_parser = _init_parser
    assert ad_hoc._init_parser() == 1

    # post_process_args is also highly related to sys.argv/CLI arguments
    # So, it is just added for testing

# Generated at 2022-06-10 22:02:17.189657
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

# Generated at 2022-06-10 22:02:28.310927
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from units.helper import mock_plugins, AnsibleExitJson, AnsibleFailJson
    from ansible.module_utils import basic

    AdHocCLI_run_mock_inventory = """
    localhost ansible_connection=local

    [all:children]
    localhost

    [all:vars]
    ansible_connection=local
    """

    AdHocCLI_run_mock_ansible_config = """
    [defaults]
    stdout_callback = yaml
    callback_plugins = %(callback_plugins)s
    """

    module_name = 'ping'
    module_path = '%(module_path)s'
    action = {'module': module_name, 'args': ''}


# Generated at 2022-06-10 22:03:51.502347
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Read file adhoc.yml
    with open('adhoc.yml') as data_file:
        data = yaml.load(data_file)

    # Test case 1
    # Test that output of AdHocCLI is expected
    myAdHocCLI = AdHocCLI()
    myAdHocCLI.run()
    assert adHocCLI.run() == data['test_AdHocCLI_run_1']

    # Test case 2
    # Test that output of AdHocCLI is expected
    myAdHocCLI = AdHocCLI()
    myAdHocCLI.run()
    assert adHocCLI.run() == data['test_AdHocCLI_run_2']


# Generated at 2022-06-10 22:03:58.779852
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    clf_dict = dict(connection='smart', module_name='command', module_args='ls')
    cli = AdHocCLI(args=['all'], runas_opts=True, fork_opts=True, **clf_dict)
    setattr(cli, '_tqm', None)
    cli.run()
    assert cli._tqm is not None

# Generated at 2022-06-10 22:04:10.386330
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse
    from io import BytesIO
    from ansible.errors import AnsibleOptionsError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-10 22:04:17.285506
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class AnsibleCLI(AdHocCLI):
        def ask_passwords(self):
            return('sshpass', 'becomepass')

        def _play_prereqs(self):
            return (None, None, None)

    cli = AnsibleCLI()
    cli.options = context.CLIARGS
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = 'shell'
    pattern = 'testhost'
    res = cli.run(pattern)
    assert res == 0

# Generated at 2022-06-10 22:04:23.211547
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from units.mock.loader import DictDataLoader

    options = opt_help.get_common_options()
    for option in options:
        if option in context.CLIARGS:
            del context.CLIARGS[option]

    context.CLIARGS = {
        'module_name': 'command',
        'module_args': '',
        'listhosts': False,
        'subset': None,
        'seconds': 30,
        'forks': 5,
        'verbosity': 0,
        'check': False,
        'extra_vars': [],
        'args': 'all',
    }

    cli = AdHocCLI(args=['all'])
    cli.post_process_args(context.CLIARGS)

    # Create mock objects
    loader

# Generated at 2022-06-10 22:04:35.697270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import tempfile
    import time
    import shutil
    from ansible.module_utils import basic

    sys.argv = ["", "all", "-m", "shell", "-a", "/bin/true"]
    context._init_global_context(CLIArgs.parse_args(args=sys.argv[1:]))

# Generated at 2022-06-10 22:04:36.471242
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO
    pass

# Generated at 2022-06-10 22:04:38.519110
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    p = AdHocCLI()
    assert p is not None

# Generated at 2022-06-10 22:04:47.759840
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import mock
    from io import StringIO

    fake_args = ['ansible', '-m', 'ping', '-a', 'data=test', 'localhost']
    with mock.patch.object(sys, 'argv', fake_args):
        display = Display()
        adhoc = AdHocCLI(None, None, None, display)
        result = adhoc.run()

    assert display.verbosity == 3
    assert display.display.call_count == 0
    assert display.warning.call_count == 1
    assert display.error.call_count == 0


# Generated at 2022-06-10 22:04:55.012993
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create a stub for class AdHocCLI
    class AdHocCLI_stub(object):
        class Play(object):
            class Load(object):
                class ReturnValue(object):
                    def __init__(self, loader, variable_manager, play):
                        self.loader = loader
                        self.variable_manager = variable_manager
                        self.play = Play()
                        self.play.get_variable_manager()
                        self.play.get_loader()
                        self.play.get_plays()
                def return_value(self, loader, variable_manager, play):
                    return self.ReturnValue(loader, variable_manager, play)
            class ReturnValue(object):
                def __init__(self, loader, variable_manager, play_ds):
                    self.loader = loader
                    self.variable_manager = variable