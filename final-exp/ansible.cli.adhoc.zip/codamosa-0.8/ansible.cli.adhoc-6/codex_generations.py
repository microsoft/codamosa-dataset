

# Generated at 2022-06-10 21:58:27.653657
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['all', '-m', 'setup'])
    adhoc.parse()
    assert context.CLIARGS['module_name'] == 'setup'



# Generated at 2022-06-10 21:58:34.517293
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoccli = AdHocCLI()
    adhoccli.options = {'module_name': C.DEFAULT_MODULE_NAME, 'module_args': "", 'subset': "", 'listhosts': ""}
    adhoccli.args = ["127.0.0.1"]
    adhoccli.run()


if __name__ == '__main__':
    ad = AdHocCLI()
    ad.parse()
    ad.run()

# Generated at 2022-06-10 21:58:46.889883
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import callback_loader

    class FakeDict(dict):
        def __getitem__(self, key):
            return to_text(dict.__getitem__(self, key), encoding='utf-8')

        def __contains__(self, key):
            return dict.__contains__(self, key)

    class FakeOptions(FakeDict):
        pass

    # Monkey patching method load_options of class AdHocCLI

# Generated at 2022-06-10 21:58:48.598719
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-10 21:59:01.048638
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # First, test that ansible.cfg is loaded
    context.CLIARGS = {'module_path': 'foo'}
    context.CLIARGS = CLI.parse()
    assert context.CLIARGS['module_path'] == 'foo'

    # Second, test that the argument 'module_path' takes precedence over
    # ansible.cfg
    context.CLIARGS = {'module_path': 'foo'}
    context.CLIARGS = CLI.parse(args=['--module-path=bar'])
    assert context.CLIARGS['module_path'] == 'bar'

    # Third, test that when ansible.cfg is not loaded,
    # CLI.parse() uses the correct defaults
    context.CLIARGS = {}
    context.CLIARGS = CLI.parse()
   

# Generated at 2022-06-10 21:59:06.020723
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unittest
    class TestAdHocCLI_run(unittest.TestCase):
        def test_empty(self):
            # this throws an exception if run() raises, or fails to return an integer
            AdHocCLI().run()
    unittest.main()

# Generated at 2022-06-10 21:59:19.854057
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test for method run of class AdHocCLI
    """

    global context
    global display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.parsing.loader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible import constants as C
    from ansible.options import Options
    from __main__ import CLI
    import sys

    display = Display()
    context = CLI.context

# Generated at 2022-06-10 21:59:32.558373
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    from ansible.plugins.loader import module_loader
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)
    run = AdHocCLI()
    run.post_process_args(context.CLIARGS)
    defaults = C.runner_defaults
    context._init_global_context(defaults)
    context.CLIARGS = dict(module_name='ping')
    context.CLIARGS = dict(module_args='data=hello world')
    run.run()
    

# Generated at 2022-06-10 21:59:34.455550
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 21:59:44.231626
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = '-a "import_playbook=foo.yml" -m command foo.yml'
    cli = AdHocCLI(args.split())
    cli.parse()
    try:
        cli.run()
    except AnsibleOptionsError as e:
        assert e.message == "'command' is not a valid action for ad-hoc commands"

    args = '-a "import_tasks=foo.yml" -m command foo.yml'
    cli = AdHocCLI(args.split())
    cli.parse()
    try:
        cli.run()
    except AnsibleOptionsError as e:
        assert e.message == "'command' is not a valid action for ad-hoc commands"

    args = '-m command foo -m shell'

# Generated at 2022-06-10 21:59:56.525733
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    ac = AdHocCLI()
    ac.run()

# Generated at 2022-06-10 22:00:02.304390
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' adhoc_cli.py:constructor test '''

    from ansible.cli.adhoc import AdHocCLI
    cli = AdHocCLI([])
    cli.parse()
    cli.post_process()
    cli.run()


if __name__ == '__main__':
    # CLI()
    test_AdHocCLI()

# Generated at 2022-06-10 22:00:11.267590
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    #Test Default constructor
    try:
        obj = AdHocCLI()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

    #Test overloaded constructor
    try:
        obj = AdHocCLI(args=['host','host'], prog_name='ansible')
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

    #Test overloaded constructor with host
    try:
        obj = AdHocCLI(args=['host', 'host'], prog_name='ansible', subset='all', module_name='shell', module_args='ls')
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-10 22:00:20.991776
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    AdHocCLI.run() returns a tuple of (task_result, host_result)
    '''
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    Result = namedtuple('Result', 'task_result host_result')

    # Disable loading of plugins
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = False
    # Disable fact collection
    DistributionFactCollector.DISTRIB_CACHE_FILE = '/dev/null'
    C.DEFAULT_HOST_LIST = '/dev/null'

    inventory = 'localhost,'
    module_name = 'ping'
    module_args = ''

# Generated at 2022-06-10 22:00:21.840991
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:00:26.218438
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=['ansible', '--help'])
    assert(adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts")

# Generated at 2022-06-10 22:00:29.926094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()
    cli.run()


if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-10 22:00:33.602166
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    try:
        result = adhoc_cli.run()
    except SystemExit as e:
        result = e
    assert result.code == 1

# Generated at 2022-06-10 22:00:35.092290
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit test for method run of class AdHocCLI '''
    pass

# Generated at 2022-06-10 22:00:36.316835
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()


# Generated at 2022-06-10 22:00:56.691323
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:01:08.671270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create an argparse.Namespace object.
    # This object is a class with no method, a subclass of
    # dictionary whose elements are accessible through
    # attributes.
    args = argparse.Namespace()

    # Define the string attributes.
    setattr(args,'args',['local'])
    setattr(args,'module_arg',['test_fail_test=test'])
    setattr(args,'module_name',['test_fail_test'])
    setattr(args,'one_line',False)
    setattr(args,'tree',False)
    setattr(args,'connection','ssh')
    setattr(args,'forks','1')
    setattr(args,'listhosts',False)
    setattr(args,'host_key_checking',True)

# Generated at 2022-06-10 22:01:12.150042
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    AdHocCLI - run
    """
    _ = AdHocCLI(args=['-m', 'ping', 'somehost'])
    _.post_process_args()
    #result = _.run()
    assert True

# Generated at 2022-06-10 22:01:13.104409
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()

# Generated at 2022-06-10 22:01:14.215941
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI(Mock()) is not None

# Generated at 2022-06-10 22:01:19.735139
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initialization
    cli_args = ['localhost', '--module-name', 'ping', '--module-args', 'arg1=val1']
    adhoc_cli = AdHocCLI(cli_args)

    # Invoke method run
    # Here we test the method doesn't raise exception
    adhoc_cli.run()

# Generated at 2022-06-10 22:01:27.018591
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Options:
        inventory = 'hosts'
        module_name = 'shell'
        module_args = 'ls'
        ask_pass = False
        ask_become_pass = False
        private_key_file = None
        verbosity = 1
        check = False
        listhosts = False
        subset = None
        diff = False
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        timeout = None
        connection = 'ssh'
        remote_user = None
        remote_port = None
        forks = None
        module_path = None
        pattern = None
        start_at

# Generated at 2022-06-10 22:01:37.812394
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    options = CLI.base_parser(
        usage='ansible-cli ad-hoc <host-pattern> [options]',
        desc="Ad-hoc command execution",
        epilog="Uses /etc/ansible/hosts by default, or another inventory file (specified with -i) or "
               "explicit hosts (specified with -l)"
    ).parse_args(args=[])

    sshpass = None
    becomepass = None

    loader = DataLoader()


# Generated at 2022-06-10 22:01:45.783751
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create a simple command line for testing
    cmd = 'ansible localhost -m ping'

    # Construct an AdHocCLI object to parse the command
    cli = AdHocCLI(cmd.split())
    assert cli is not None

    # Check the constructed AdHocCLI object
    assert cli.parser.prog == 'ansible'
    assert cli.parser._actions[0].dest == 'args'
    assert cli.parser._actions[0].metavar == 'pattern'

    assert cli.parser._actions[1].dest == 'module_args'
    assert cli.parser._actions[1].default == '""'

    assert cli.parser._actions[2].dest == 'verbosity'
    assert cli.parser._actions[2].type == int
    assert cli.parser

# Generated at 2022-06-10 22:01:57.556912
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # generate fake arguments to pass in
    args = ['ansible', 'all', '-m', 'shell', '-a', 'uptime']
    # generate fake display class with custom write
    display = type('Display', (object,), {'warning': lambda *args: None})()
    # generate fake host list
    hosts = ['test1.example.com', 'test2.example.com']
    # generate fake host list iterator
    host_list = type('HostList', (object,), {'list': lambda *args: hosts})()
    # generate fake inventory class
    inventory = type('Inventory', (object,), {'host_list': host_list})()
    # generate fake option parser class
    option_parser = type('OptionParser', (object,), {'error': lambda *args: None})()
    # generate fake option

# Generated at 2022-06-10 22:02:33.027804
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()

# Generated at 2022-06-10 22:02:34.697069
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI()
    assert ad_hoc

# Generated at 2022-06-10 22:02:38.326214
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Test: constructor
    cli = AdHocCLI(args=[])
    # Verify: initialized correctly
    assert cli
    # cleanup
    cli = None

# Generated at 2022-06-10 22:02:46.292076
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import tempfile
    import os
    import shutil
    import ansible.constants as C
    import ansible.context
    import ansible.cli.adhoc
    import ansible.inventory
    import ansible.parsing.dataloader
    import ansible.playbook
    import ansible.playbook.play
    import ansible.plugins.loader
    import ansible.vars.manager
    import ansible.vars.hostvars_overrides

    ########################################################################################
    # Define a minimal inventory with one host
    ########################################################################################
    hosts = ansible.inventory.Hosts([])
    groups = ansible.inventory.Groups([])
    groups.add_host("test")
    hosts.add_group(groups)

# Generated at 2022-06-10 22:02:48.173132
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ahc = AdHocCLI()
    ahc.init_parser()

# Generated at 2022-06-10 22:02:57.289913
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from ansible.module_utils._text import to_bytes
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    ContextCLIARGS = namedtuple('ContextCLIARGS',
                                'module_name module_args connection forks runner_type stdout_callback one_line task_timeout listhosts poll_interval subset seconds tree')
    ContextCLIARGS.module_name = C.DEFAULT_MODULE_NAME
    ContextCLIARGS.module_args = ''
    ContextCLIARGS.connection = C.DEFAULT_TRANSPORT
    ContextCLIARGS.forks = C.DEFAULT_FORKS
    ContextCLIARGS.runner_type = C.DEFAULT_RUNNER_TYPE

# Generated at 2022-06-10 22:03:00.426084
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(["-h"])
    adhoc.run()

# Generated at 2022-06-10 22:03:02.022702
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(['-m', 'ping', 'host'])
    cli.run()

# Generated at 2022-06-10 22:03:08.749841
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Function to test method run of class AdHocCLI"""
    vars = {}

# Generated at 2022-06-10 22:03:11.615827
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    test_cli = AdHocCLI()
    test_cli.post_process_args(context.CLIARGS)
    assert test_cli.run() == 0

# Generated at 2022-06-10 22:04:19.758955
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ Returns AdHocCLI class object 
        args: none
        return: AdHocCLI class object
    """
    p = AdHocCLI(args=[])
    return p


# Generated at 2022-06-10 22:04:32.925126
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    display = Display()
    display.verbosity = 0

# Generated at 2022-06-10 22:04:34.622524
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """This is a test function for 'ansible-doc' command."""
    AdHocCLI.run()

# Generated at 2022-06-10 22:04:39.772180
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoccli = AdHocCLI()
    options = adhoccli.parse(['-a', 'date', '-m', 'shell', 'localhost'])
    assert adhoccli.post_process_args(options)
    adhoccli.run()
    # TODO: add test to check that no exceptions are thrown and return value is 0

# Generated at 2022-06-10 22:04:44.717063
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    class Dummy():
        def __init__(self, options=None):
            self.options = options

    adhoccli = AdHocCLI(Dummy(options={'verbosity': 0}))
    adhoccli.execute()



# Generated at 2022-06-10 22:04:46.847548
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()

if __name__ == '__main__':
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:04:48.709711
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI()
    assert adHocCLI is not None

# Generated at 2022-06-10 22:04:54.302740
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-i', 'localhost,', 'localhost', '-m', 'command', '-a', 'ls', '-t', '/tmp'])
    adhoc.parse()
    assert context.CLIARGS['inventory'] == 'localhost,'
    assert context.CLIARGS['subset'] is None
    assert context.CLIARGS['module_name'] == 'command'
    assert context.CLIARGS['module_args'] == 'ls'
    assert context.CLIARGS['args'] == 'localhost'
    assert context.CLIARGS['tree'] == '/tmp'

# Generated at 2022-06-10 22:04:55.618456
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # AdHocCLI.run is indirectly tested by test_adhoc.py
    pass

# Generated at 2022-06-10 22:04:56.204538
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True