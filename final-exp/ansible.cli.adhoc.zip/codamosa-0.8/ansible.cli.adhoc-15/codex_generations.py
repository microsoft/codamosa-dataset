

# Generated at 2022-06-10 21:58:39.749884
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:58:51.009385
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import __version__

    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import ansible.constants as C
    import ansible.utils.display as display

    display.verbosity = 3


# Generated at 2022-06-10 21:59:00.645973
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.constants as C
    import ansible.cli
    from ansible.utils.display import Display
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    C.HOST_KEY_CHECKING = False

    display = Display()

    inventory = Inventory(loader=DataLoader(), hosts=['localhost', 'otherhost'])
    variable_manager = VariableManager()
    playbook = ansible.cli.adhoc.AdHocCLI()

    res = playbook.run(inventory, variable_manager, ['ping'])

    assert res == 0

# Generated at 2022-06-10 21:59:02.174173
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()

# Generated at 2022-06-10 21:59:04.347119
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # 1. Test successful execution with expected output
    # 2. Test with exception
    # 3. Test with listhosts
    pass

# Generated at 2022-06-10 21:59:08.483336
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI([])
    cli.post_process_args(cli.parse())
    cli.run()

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-10 21:59:09.366965
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:10.078075
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:12.359629
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # There is no way to test a CLI class.
    # You can use a code coverage tool to ensure that all code paths are executed
    pass


# Generated at 2022-06-10 21:59:23.524551
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    class Options(object):
        verbosity = 0
        inventory = None
        subset = None
        module_paths = '/usr/lib/python2.7/site-packages/ansible/modules'
        forks = 5
        ask_vault_pass = False
        vault_password_files = None
        new_vault_password_file = None
        output_file = None
        tags = None
        skip_tags = None
        one_line = None
        tree = None
        ask_pass = False
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        ssh_conn = None
        connection = 'smart'
        timeout = 10
        become = False
        become_method

# Generated at 2022-06-10 21:59:41.536149
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import unittest
    from StringIO import StringIO
    from units.mock.path import mock_path_exists

    sys.stdout = StringIO()
    sys.stderr = StringIO()

    class fake_options:
        module_name = 'command'
        module_args = 'ls'
        listhosts = True
        subset = None
        verbosity = 0
        one_line = False
        tree = '/some/path'
        forks = 5
        inventory = None
        check = False
        diff = False
        timeout = None

    class fake_args():
        args = 'fakehostname'


# Generated at 2022-06-10 21:59:54.047675
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ##########################################################################################
    class MockCLI(AdHocCLI):
        ##########################################################################################

        def __init__(self, *args, **kwargs):
            super(MockCLI, self).__init__(*args, **kwargs)

            class MockParser(object):
                ##########################################################################################

                def __init__(self, *args, **kwargs):
                    pass

                ##########################################################################################

                def parse_args(self, *args, **kwargs):
                    return self

                ##########################################################################################

                def parse_known_args(self, args):
                    return self

                #################################################################

# Generated at 2022-06-10 21:59:56.882318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''This method will run AdHocCLI.run() and checks for exception'''
    ad_hoc = AdHocCLI(['-m setup','localhost'])
    assert ad_hoc.run() == 0

# Generated at 2022-06-10 22:00:08.836606
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import inspect
    import os
    import sys
    import tempfile

    ad = AdHocCLI(args=[]) # Creating an instance of AdHocCLI
    data_dir = os.path.dirname(inspect.getfile(AdHocCLI)) + os.path.sep + "data"
    sys.path.insert(0, data_dir)
    # Creating a temporary yml file to store the datas of playbook_ds
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write("""
- hosts: localhost
  remote_user: root
  gather_facts: no
  tasks:
    - name: test1
      shell: echo test1
      async: 1
      poll: 0""")
    tmp_file.seek(0)
    # Storing the datas of the

# Generated at 2022-06-10 22:00:12.698491
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI([])
    assert isinstance(adhoc_cli, AdHocCLI)
    assert isinstance(adhoc_cli._tqm, TaskQueueManager)

# Generated at 2022-06-10 22:00:17.299826
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adh = AdHocCLI(['test_AdHocCLI_run.py', 'localhost', '-m', 'test_module'])
    adh.run()
    assert adh._tqm is not None
    assert adh._tqm._stats._hosts['localhost']['failures'] == 0

# Generated at 2022-06-10 22:00:24.650487
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=['1.1.1.1'])
    assert adhoc_cli.parser.prog == 'ansible'
    assert adhoc_cli.run() == 0
    adhoc_cli = AdHocCLI(args=['1.1.1.1', '-m', 'ping'])
    assert adhoc_cli.run() == 0

# Generated at 2022-06-10 22:00:37.634019
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    def _tqm_run_mock(play):
        return 0

    class _TaskQueueManager_mock:

        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks,
                     run_tree, forks):
            self._stats = 0

        def load_callbacks(self):
            return

        def send_callback(self, name, stats):
            return

        def run(self, play):
            return _tqm_run_mock(play)

        def cleanup(self):
            return

    class _Playbook_mock:
        def __init__(self):
            self._file_name = '__adhoc_playbook__'
            self._entries = []


# Generated at 2022-06-10 22:00:47.976869
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # The class object is instantiated and the instance is passed to run method
    # for testing its functionality. The instance shares the same attributes of
    # the class. If a new attribute is added to the class, the test case needs
    # to be updated with that new attribute.
    # The function test_AdHocCLI_run() is called from test/units/utils/module_runner.py

    instance = AdHocCLI()
    # The argument is a list of key-value pairs and not a string

# Generated at 2022-06-10 22:00:56.404017
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' test class AdHocCLI run() method '''
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    args = "-m setup -a foo=bar all".split()
    adhoc_obj = AdHocCLI(args)
    adhoc_options = adhoc_obj.parse()
    adhoc_inventory = InventoryManager(loader=DataLoader(), sources=adhoc_options.inventory)
    adhoc_variable_manager = VariableManager(loader=DataLoader(), inventory=adhoc_inventory)

    adhoc_loader = DataLoader()
    play_ds = adhoc_obj._play_ds(pattern="all", async_val=0, poll=0)
    play

# Generated at 2022-06-10 22:01:12.963313
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['localhost'])
    assert isinstance(cli, AdHocCLI)


# Generated at 2022-06-10 22:01:23.540909
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:01:25.103427
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_cli = AdHocCLI()
    ad_cli.run()

# Generated at 2022-06-10 22:01:26.045388
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()

# Generated at 2022-06-10 22:01:28.181599
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI(['/foo/bar', '-m', 'ping'])

# Generated at 2022-06-10 22:01:38.936530
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test of method AdHocCLI.run
    '''

    from ansible_collections.notstdlib.moveitallout.tests.unit.test_files.test_ansible_adhoc import get_test_data
    from ansible_collections.notstdlib.moveitallout.plugins.callback.tree import CallbackModule as Tree

    module_results = get_test_data()

    results = []
    tqm = None

    def send_callback(callback_name, *args, **kwargs):
        results.append((callback_name, args, kwargs))

    def run(play):
        assert results == [("v2_playbook_on_start", (play,), {})]
        yield module_results

    class FakeDisplay(object):
        verbosity = 0


# Generated at 2022-06-10 22:01:41.879786
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI()
    assert isinstance(adHocCLI, AdHocCLI)
    assert adHocCLI.init_parser() == None


# Generated at 2022-06-10 22:01:47.093057
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit testing for AdHocCLI.run method '''
    from AnsiballZ_ansible import create_fake_module
    create_fake_module(':memory:', 'testmodule')
    cli = AdHocCLI(args=['all', '-m', 'testmodule'])
    cli.run()

# Generated at 2022-06-10 22:01:47.792806
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass # not implemented yet

# Generated at 2022-06-10 22:01:54.533839
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C
    from ansible.utils.display import Display
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.utils.sentinel import Sentinel

    display = Display()
    adhoc = AdHocCLI(sentinel=Sentinel())

    opt_help.add_module_options(adhoc.parser)
    opt_help.add_runtask_options(adhoc.parser)
    opt_help.add_runtask_options(adhoc.parser)
    opt_help.add_vault_options(adhoc.parser)
    opt_help.add_tasknoplay_options(adhoc.parser)


# Generated at 2022-06-10 22:02:25.427962
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert isinstance(cli, CLI)

# Generated at 2022-06-10 22:02:30.125038
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli._options is None
    assert cli._args is None
    assert cli._play_prereqs is None
    assert cli._play is None
    assert cli._playbook is None
    assert cli._tqm is None
    assert cli._variables is None
    assert cli._rv is None

# Generated at 2022-06-10 22:02:30.847160
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-10 22:02:43.349529
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    host = 'test_host'
    module_name = 'test_module_name'
    args = dict(key1='value1', key2='value2')
    poll = 10
    seconds = 3600
    verbosity = 3
    forks = 5
    listhosts = True
    subset = None
    tree = '/tmp/test_tree'
    vault_password_file = '/tmp/vault_password'
    module_path = '/tmp/module_path'
    one_line = False
    exclude_hosts = None
    inventory = '/tmp/inventory'
    subset = None
    ask_pass = True
    become = True
    become_user = 'test_become_user'
    become_ask_pass = True
    timeout = 10

    ctx = context.CLIARGS

# Generated at 2022-06-10 22:02:46.429427
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # unit test:
    #  AdHocCLI(args=args).run()
    #
    # also useful:
    #  AdHocCLI(args=args).post_process_args()
    pass

# Generated at 2022-06-10 22:02:47.819180
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])

# Generated at 2022-06-10 22:02:52.224798
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    AdHocCLI constructor method
    '''
    adhoc = AdHocCLI()

    # one_tier_opts set
    assert len(adhoc.one_tier_opts) == 2

# Generated at 2022-06-10 22:03:04.531983
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-10 22:03:05.131240
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:03:06.124652
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass


# Generated at 2022-06-10 22:04:34.932769
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.constants as C
    import ansible.parsing.splitter as S

    C.HOST_KEY_CHECKING = False
    C.DEFAULT_MODULE_NAME = 'ping'
    for args in (
        '-a "a=1 b=2" localhost',
        '-a "a=1 b=2 c=3" -m ping localhost',
        '-a "a=1 b=2 c=3" -m ping -v localhost',
        '-a "a=1 b=2 c=3" -m ping localhost',
        '-a "a=1 b=2 c=3" -m setup localhost'):
        args = S.parse_kv(args)
        print(args)
        cli = AdHocCLI(args)
        cl

# Generated at 2022-06-10 22:04:35.671251
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:04:37.564220
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    assert type(adhoc.run()) is int

# Generated at 2022-06-10 22:04:49.064386
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import json
    import pytest

    from __main__ import parse_args

    sys.argv = ['ansible', '-m', 'setup', '-i', 'localhost,', 'all']

    args = parse_args()
    args.subset = False

    a = AdHocCLI(args)
    a.parse()
    a.post_process_args(a.args)
    result = a.run()

    # This is not very meaningful, as it will be running on the machine where the tests are being ran.
    # A proper solution would be mocking the result somehow.
    assert result == 0

    assert a.callback == 'json'
    assert a.verbosity == 0
    assert a.args.listhosts

    assert a.args.any_errors_fatal
    assert not a._always

# Generated at 2022-06-10 22:04:51.052905
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO(bparham) test ad-hoc with `ansible -m debug -a 'msg=foo' <hosts>`
    pass

# Generated at 2022-06-10 22:04:52.888848
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    adhoc_cli = AdHocCLI(args=['-m', 'ping'])

    adhoc_cli.run()
    """
    pass

# Generated at 2022-06-10 22:05:02.494047
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' adhoc_cli.py:TestAdHocCLI '''


# Generated at 2022-06-10 22:05:03.397482
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-10 22:05:11.516707
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.connection_loader_class is None
    assert cli.connection_loader_class_kwargs is None
    assert cli.connection_lock_class is None
    assert cli.connection_lock_class_kwargs is None
    assert cli.callback is None
    assert cli.callback_class is None
    assert cli.display is Display()
    assert cli.display.verbosity == 0
    assert cli.galler is None
    assert cli.gen is None
    assert cli.inventory_loader_class is None
    assert cli.inventory_loader_class_kwargs is None
    assert cli.parser is None
    assert cli.password is None
    assert cli.repo_dir is None
    assert cli.sshpass is None


# Generated at 2022-06-10 22:05:12.031701
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass