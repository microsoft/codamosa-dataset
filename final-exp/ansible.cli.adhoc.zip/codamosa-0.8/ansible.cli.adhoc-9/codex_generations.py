

# Generated at 2022-06-10 21:58:26.501573
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adCli = AdHocCLI()
    assert isinstance(adCli, CLI)

# Generated at 2022-06-10 21:58:27.653826
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()
    assert a is not None

# Generated at 2022-06-10 21:58:30.124498
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    o = AdHocCLI()



# Generated at 2022-06-10 21:58:38.397884
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ ansible ad-hoc -m ping -a 'data=foo' localhost """
    context.CLIARGS = parse_kv(u"module_name=ping module_args='data=foo'")
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = u"data=foo"
    context.CLIARGS['ask_pass'] = False
    context.CLIARGS['ask_become_pass'] = False
    context.CLIARGS['ask_sudo_pass'] = False
    context.CLIARGS['connection'] = 'local'
    context.CLIARGS['forks'] = 5
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['check'] = False
    context.CL

# Generated at 2022-06-10 21:58:47.709167
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli._play_ds = 'test_AdHocCLI_play_ds'
    adhoc_cli.ask_passwords = lambda : ['sshpass', 'becomepass']
    adhoc_cli._play_prereqs = lambda : [['loader'], ['inventory'], ['variable_manager']]
    adhoc_cli.get_host_list = lambda inventory, subset, pattern: ['hosts']
    adhoc_cli.callback = 'minimal'
    adhoc_cli.run()



# Generated at 2022-06-10 21:59:00.263400
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''test the run method of AdHocCLI'''
    context.CLIARGS = dict(module_name='copy', module_args='src=a dest=b', forks=1,
                           listhosts=False, subset=False, verbosity=1, one_line=False)
    # Creating a variable manager
    variable_manager = VariableManager()

    # Creating a inventory
    device_list = ['localhost', 'localhost']
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=device_list)

    # Creating a loader
    loader = DataLoader()

    # Creating a callback
    callback = default.CallbackModule()

    # Creating a pushbback queue
    queue = Queue()

    instance = AdHocCLI(args=None, callback=callback, queue=queue)

   

# Generated at 2022-06-10 21:59:03.187907
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI()
    assert isinstance(adHocCLI, AdHocCLI)


# Generated at 2022-06-10 21:59:06.444136
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

if __name__ == "__main__":
    test_AdHocCLI_run()

# Generated at 2022-06-10 21:59:20.158803
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def mock_play_prereqs():
        loader = {
            '_basedir': '/Users/mawillia/GitHub/code/ansible/lib/ansible'
        }
        inventory = {
            'host_list': [
                'all',
                ':children',
                ':vars',
                'vault_encrypted',
                'group1',
                ':vars',
                'vault_encrypted'],
            'parser': object(),
            'groups': {
                'group1': {
                    'hosts': ['localhost']
                }
            }
        }

# Generated at 2022-06-10 21:59:25.569175
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['all', '-m', 'ping', '-a', 'data=blah'])
    assert cli.module_name == 'ping'
    assert cli.module_args == 'data=blah'

# Generated at 2022-06-10 21:59:34.265448
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 21:59:37.070257
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI(['-i', 'localhost,', 'all', '-m', 'ping'])
    adhoc.run()

# Generated at 2022-06-10 21:59:41.836392
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-10 21:59:54.343240
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """This is a unit test for method run of class AdHocCLI
    """
    # Test with existing host pattern on existing module
    options = context.CLIARGS
    options['verbosity'] = 1
    options['module_name'] = 'shell'
    options['module_args'] = "echo 1"
    options['subset'] = 'all'
    options['check'] = False
    options['connection'] = 'ssh'
    options['forks'] = 5
    options['tree'] = None
    options['listhosts'] = None
    options['ask_vault_pass'] = False
    options['ask_pass'] = False
    options['ask_sudo_pass'] = False
    options['extra_vars'] = None
    options['tqm_class'] = None
    options['listtags'] = None


# Generated at 2022-06-10 21:59:57.272653
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Constructor test
    '''
    adhoc_cli = AdHocCLI(['/usr/bin/ansible', 'servers', '-m', 'ping'])


# Unit test

# Generated at 2022-06-10 22:00:08.450318
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Unit test for method execute of class AdHocCLI"""

    test_adhoccli = AdHocCLI()
    test_adhoccli._connection = None
    test_adhoccli._play_context = None
    test_adhoccli._loader = None
    test_adhoccli._tqm = None
    test_adhoccli._variable_manager = None
    test_adhoccli.basedir = None
    test_adhoccli.callback = None
    test_adhoccli.callbacks = None
    test_adhoccli.display = None
    test_adhoccli.inventory = None
    test_adhoccli.parser = None
    test_adhoccli.stdout_callback = None

# Generated at 2022-06-10 22:00:16.256817
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Initializing class object 
    AdHocCLI()

    # testing with empty value
    pattern = ''
    async_val = ''
    poll = ''
    play_ds = AdHocCLI._play_ds(pattern, async_val, poll)
    # test with assert equl
    assert play_ds == dict(name="Ansible Ad-Hoc", hosts=pattern, gather_facts='no', tasks=[{'action': {'module': 'shell', 'args': {}}, 'timeout': 10}])

# Generated at 2022-06-10 22:00:29.032759
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # initialize a AdHocCLI object
    adhoc_cli = AdHocCLI()
    adhoc_cli.run = lambda: None

    # test case #1: init_parser function success
    setattr(adhoc_cli, 'init_parser', lambda: None)
    adhoc_cli.run()

    # test case #2: init_parser function raises AnsibleOptionsError
    setattr(adhoc_cli, 'init_parser', lambda: AnsibleOptionsError('test'))
    try:
        adhoc_cli.run()
    except AnsibleOptionsError:
        pass
    else:
        assert False, 'test case #2 failed'

    # test case #3: init_parser function raises other exceptions
    setattr(adhoc_cli, 'init_parser', lambda: Exception('test'))

# Generated at 2022-06-10 22:00:32.169466
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    args = ["ec2"]
    cli = AdHocCLI(args)
    assert cli is not None
    assert cli.args == ['ec2']

# Generated at 2022-06-10 22:00:38.910322
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = 'localhost -i inventory -m ping -a "data=test"'
    cli = AdHocCLI(args.split())
    options = cli.parse()
    options = cli.post_process_args(options)
    result = cli.run()
    print(result)

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-10 22:01:06.323140
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.cli.adhoc
    from ansible.cli.adhoc import AdHocCLI
    from ansible.errors import AnsibleOptionsError, AnsibleError
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import sys

    ad = AdHocCLI(
        ['--module-name', 'ping', '-i', 'hosts', 'hosts'],
        'ping',
        'ping',
    )
    # # _play_prereqs
    ad.options = ad.post_process_args(ad.options)
    ad.validate_conflicts(ad.options)

    l = DataLoader()


# Generated at 2022-06-10 22:01:08.410371
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    connection = AdHocCLI.run()
    assert isinstance(connection, TaskQueueManager)

# Generated at 2022-06-10 22:01:10.753415
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI(args=[])
    adhoc.post_process_args(adhoc.parser.parse_args(''))

# Generated at 2022-06-10 22:01:12.492724
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli is not None


# Generated at 2022-06-10 22:01:19.646232
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Configure argument parsing
    parser = CLIBase.base_parser(
        desc='Execute Ad-Hoc commands.',
        usage='%prog [options]',
        epilog='Use %(prog)s module <module_name> to display parameters of a module.'
    )

    adhoc = AdHocCLI(parser)
    # Create a playbook_executor object
    p = adhoc.parse()
    assert isinstance(p, dict)

# Generated at 2022-06-10 22:01:21.324674
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI(args=['localhost', '--module-name=ping']).run()

# Generated at 2022-06-10 22:01:24.708592
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    #assert isinstance(cli, CLI)
    assert cli.run is not None
    assert cli.run != {}
    try:
        cli.init_parser()
    except:
        #exception occurs due to missing argv[1]
        pass

# Generated at 2022-06-10 22:01:36.054924
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test without specifying all the options
    params = {}
    cli = AdHocCLI(args=params)
    cli.run()

    # Test with specifying all the options

# Generated at 2022-06-10 22:01:38.603526
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """unit test for constructor of class AdHocCLI"""

    obj = AdHocCLI(['-m','test','test.test'],['test','test'])
    obj.run()

# Generated at 2022-06-10 22:01:39.203024
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:02:15.554870
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Test AdHocCLI class by making sure it can be constructed, and that any
    required methods are callable.
    '''
    # Construct the AdHocCLI class
    ad_hoc_cli = AdHocCLI()

    # Make sure the parser is callable
    _ = ad_hoc_cli.parser

    # Make sure the run function is callable
    _ = ad_hoc_cli.run()

# Generated at 2022-06-10 22:02:27.624714
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import StringIO

    class fakeopt():
        def __init__(self, pattern, **kwargs):
            self.__dict__.update(kwargs)
            self.args = pattern


# Generated at 2022-06-10 22:02:35.405182
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {
        'module_name': 'setup',
        'module_args': '',
        'subset': '',
        'seconds': '',
        'poll_interval': '',
        'verbosity': 0,
        'listhosts': False,
        'one_line': False,
        'tree': '',
        'args': 'master'
    }
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-10 22:02:45.240458
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.errors import AnsibleOptionsError, AnsibleError
    from ansible.parsing.splitter import parse_kv
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueManagerError

    class test_AdHocCLI(AdHocCLI):
        def __init__(self):
            self.password = None
            self.module_name = 'shell'
            self.verbosity = 0
            self.module_args = ''
            self.listhosts = None
            self.subset = False
            self.seconds = None
            self.poll_interval = None
            self.connection = 'smart'
            self.force_handlers = None
            self.check = False
            self.syntax = False
            self.diff = False
            self.sudo = False


# Generated at 2022-06-10 22:02:55.813440
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import constants as C
    from ansible.cli.adhoc import AdHocCLI

    cli = AdHocCLI(args=['-m', 'ping', 'localhost'])
    cli.parse()

    context.CLIARGS = cli.args
    context.CLIARGS['ask_pass'] = False
    context.CLIARGS['ask_sudo_pass'] = False
    context.CLIARGS['ask_su_pass'] = False
    context.CLIARGS['become_ask_pass'] = False
    context.CLIARGS['become_ask_sudo_pass'] = False
    context.CLIARGS['become_ask_su_pass'] = False
    context.CLIARGS['connection'] = 'ssh'

# Generated at 2022-06-10 22:03:06.519638
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class FakeOptions(FakeCLIOptions):
        def __init__(self):
            self.verbosity = 0
            self.extra_vars = ['{"one": "two", "three": [1, 2, 3]}']
            self.module_path = None
            self.listhosts = False
            self.subset = None
            self.tags = ['tag_one', 'tag_two']
            self.skip_tags = None
            self.check = False
            self.diff = None
            self.syntax = False
            self.connection = None
            self.timeout = 10
            self.ssh_common_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.ssh_extra_args = None
            self.become = None
            self

# Generated at 2022-06-10 22:03:17.802143
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a helper object to call method
    ad = AdHocCLI()

    # Create a result object with return value 0
    r = type('', (), {})()
    r.return_value = 0

    # Create a context object to call method
    c = type('', (), {})()
    c.CLIARGS = {'module_name':'shell','module_args':'ls','subset':None, 'tree':None, 'listhosts':False,'verbosity':None,'ask_pass':False,'private_key_file':None,'one_line':False,
                    'ask_sudo_pass':False,'ask_su_pass':False,'seconds':None,'connection':None,'timeout':None, 'forks':None,'poll_interval':None,'diff':False,'check':False,
                    'syntax':None}


# Generated at 2022-06-10 22:03:31.854986
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI.

    :rtype: bool
    :return: test result
    '''
    test_result = True

    # Mock class for testing class AdHocCLI
    class MockAdHocCLI(AdHocCLI):
        def __init__(self):
            pass

        def init_parser(self):
            pass

        def post_process_args(self, options):
            pass

        def _play_ds(self, pattern, async_val, poll):
            pass

        def run(self):
            pass

    test_AdHocCLI = MockAdHocCLI()

    test_AdHocCLI.init_parser()
    test_AdHocCLI.post_process_args(None)
    test_AdHoc

# Generated at 2022-06-10 22:03:45.018572
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Construct command line tool object
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, CLI)
    assert isinstance(adhoc_cli, AdHocCLI)


# # Unit test for method init_parser of class AdHocCLI
# def test_init_parser():
#     pass
#
# # Unit test for method post_process_args of class AdHocCLI
# def test_post_process_args():
#     pass
#
# # Unit test for method _play_ds of class AdHocCLI
# def test__play_ds():
#     pass
#
# # Unit test for method run of class AdHocCLI
# def test_run():
#     pass
#
# # Unit test for method _play_ds of class AdHocCLI

# Generated at 2022-06-10 22:03:45.748994
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:04:57.546827
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ AnsibleAdHocCLI run function unit test """
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-10 22:04:58.247298
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:04:59.471993
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    cli = AdHocCLI()
    assert cli.display is not None

# Generated at 2022-06-10 22:05:01.349616
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' ansible-doc ad-hoc unit test '''
    AdHocCLI()

# Generated at 2022-06-10 22:05:04.839913
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    myadhoc = AdHocCLI(['-m', 'ping', 'bogus_host_name'])
    myadhoc.parse()
    myadhoc.post_process_args()
    myadhoc.run()

# Generated at 2022-06-10 22:05:12.088386
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Imports
    from unittest.mock import MagicMock, patch
    import ansible.constants as C
    # Constants
    None

    # Mocks
    def get_host_list(inventory, subset, pattern):
        return ['localhost']

    # Functions

    # Variables
    adhoc_cli = AdHocCLI()
    context.CLIARGS = {}
    context.CLIARGS['module_name'] = 'command'
    context.CLIARGS['module_args'] = 'ls'
    context.CLIARGS['tree'] = None
    context.CLIARGS['forks'] = 0
    context.CLIARGS['seconds'] = None
    context.CLIARGS['poll_interval'] = None

    # Functions
    adhoc_cli._play

# Generated at 2022-06-10 22:05:12.585593
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-10 22:05:14.925343
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ansibullbot.utils.ansible.cli.AdHocCLI class
    '''

    obj = AdHocCLI()
    assert obj

# Generated at 2022-06-10 22:05:22.982157
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    module_name = 'shell'
    module_args = 'id'
    argv = 'hserver -m %s -a "%s" -f 10' % (module_name, module_args)
    cli = AdHocCLI(['ansible-playbook', '-c', 'local', 'test', '--list-hosts', '--step'])
    cli.parse()
    cli.args = ' '.join(argv)
    cli.post_process_args()
    cli.run()

# Generated at 2022-06-10 22:05:28.300722
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['-m', 'shell', '-a', 'echo "hello"', 'localhost'])
    assert cli.options.module_name == 'shell', "Module name not parsed."
    assert cli.options.module_args == 'echo "hello"', "Module args not parsed."
    assert cli.args == ['localhost'], "Host name not parsed."