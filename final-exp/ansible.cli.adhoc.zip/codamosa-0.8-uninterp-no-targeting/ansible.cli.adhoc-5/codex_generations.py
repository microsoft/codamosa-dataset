

# Generated at 2022-06-20 12:51:52.910160
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()

if __name__ == '__main__':
    test_AdHocCLI()

# Generated at 2022-06-20 12:51:54.879053
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()

# Generated at 2022-06-20 12:52:05.961992
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from unittest.mock import mock_open, patch, Mock, MagicMock
    from ansible import context
    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.clean import clean_facts
    from ansible.template import Templar

    # Fixture
    result = 0
    cli = AdHocCLI(args=['localhost', '-m', 'ping'])
    cli.options = cli.parser.parse_args(['localhost', '-m', 'ping'])

# Generated at 2022-06-20 12:52:07.139209
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    pass

# Generated at 2022-06-20 12:52:07.979578
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI() is not None

# Generated at 2022-06-20 12:52:09.378125
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
  adhoccli = AdHocCLI()
  result = adhoccli.run()
  assert result == 0

# Generated at 2022-06-20 12:52:11.461147
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-m', 'ping', 'localhost'])

# Generated at 2022-06-20 12:52:22.150004
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import io
    import sys

    # Create an instance of the class AdHocCLI
    adhoc_instance = AdHocCLI(
        args=['-c paramiko', 'localhost', '-a', 'uptime'],
        stdin=io.StringIO('test'),
    )
    adhoc_instance.parser.parse_args(args=adhoc_instance.args, namespace=adhoc_instance.options)

    # Call method post_process_args on adhoc_instance
    adhoc_instance.post_process_args(adhoc_instance.options)

    # The expected result is the following
    # {'ask_pass': False,
    #  'ask_su_pass': False,
    #  'ask_vault_pass': False,
    #  'become': False,


# Generated at 2022-06-20 12:52:34.701831
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Object(object): pass
    options = Object()
    options.verbosity = 0
    options.private_key_file = None
    options.ask_pass = False
    options.ask_vault_pass = False
    options.module_path = None
    options.listhosts = None
    options.subset = None
    options.extra_vars = []
    options.forks = 5
    options.module_name = 'shell'
    options.module_args = 'echo hello'
    options.one_line = False
    options.tree = None
    options.output_file = None
    options.output_dir = None
    options.tags = []
    options.skip_tags = []
    options.force_handlers = False
    options.flush_cache = False
    options.listtasks = None


# Generated at 2022-06-20 12:52:38.398985
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser.description.startswith("Ansible Ad-Hoc")


# Generated at 2022-06-20 12:52:47.797051
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    assert ad_hoc_cli

# Generated at 2022-06-20 12:52:49.918099
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    assert cli is not None
    parser = cli.init_parser()
    assert parser is not None

# Generated at 2022-06-20 12:52:54.179602
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''
    Return the AdHocCLI object with the arguments parsed and
    ready for the run method to be executed.
    '''
    args = AdHocCLI(['-m', 'module_name', 'host_pattern'])
    return args.init_parser()


# Generated at 2022-06-20 12:52:59.409352
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ''' Unit test for method post_process_args of class AdHocCLI '''
    a = AdHocCLI()
    assert a.post_process_args({'module_name': 'shell'}) == {'module_name': 'shell'}



# Generated at 2022-06-20 12:53:10.558188
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cliargs = {}

    cliargs['module_name'] = "hello"
    cliargs['module_args'] = "one=1"
    cliargs['args'] = "localhost"

    cliargs['verbosity'] = 0
    cliargs['listhosts'] = False
    cliargs['subset'] = None
    cliargs['forks'] = None
    cliargs['ask_vault_pass'] = False
    cliargs['vault_password_file'] = None
    cliargs['ask_become_pass'] = False
    cliargs['become_ask_pass'] = False
    cliargs['become_method'] = None
    cliargs['become_password'] = None
    cliargs['become_user'] = None

# Generated at 2022-06-20 12:53:11.936406
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert(adhoc != None)

# Generated at 2022-06-20 12:53:16.651461
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # create an options parser for bin/ansible
    # create an options parser for bin/ansible
    parser = AdHocCLI(None).init_parser()
    assert parser

if __name__ == "__main__":
    import pytest
    pytest.main("-q test_AdHocCLI.py")

# Generated at 2022-06-20 12:53:17.595769
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI().init_parser()

# Generated at 2022-06-20 12:53:19.820896
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    test_AdHocCLI_init_parser.parser = AdHocCLI(args=[]).init_parser()


# Generated at 2022-06-20 12:53:22.989783
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # Create an instance of the AdHocCLI object
    adHocCLI = AdHocCLI(args=[])

    # Verify the init_parser method returns a valid parser object
    assert isinstance(adHocCLI.init_parser(), object)


# Generated at 2022-06-20 12:53:36.479800
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()

    # Test CLI.ask_vault_pass
    adhoc.ask_vault_pass = True

    # Test CLI.ask_pass
    adhoc.ask_pass = True

    # Test CLI.ask_become_pass
    adhoc.ask_become_pass = True

# Generated at 2022-06-20 12:53:38.467064
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('In AdHocCLI_run')
    from ansible.cli.adhoc import AdHocCLI
    cli_adhoc = AdHocCLI()


# Generated at 2022-06-20 12:53:50.117839
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import mock


# Generated at 2022-06-20 12:54:00.769172
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    cli = AdHocCLI()
    # pylint: disable=no-member
    parser = cli.init_parser()

    # Check if required options are present
    assert parser._actions[1].dest == "host_pattern"
    assert parser._actions[1].required
    assert parser._actions[1].metavar == "pattern"

    # Check the rest of the options
    assert len(parser._actions) == 24
    assert parser._actions[2].dest == "module_name"
    assert parser._actions[3].dest == "module_args"
    assert parser._actions[4].dest == "forks"
    assert parser._actions[5].dest == "become"
    assert parser._actions[6].dest == "become_method"

# Generated at 2022-06-20 12:54:01.929549
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    AdHocCLI()

# Generated at 2022-06-20 12:54:12.386276
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI([])
    options = cli.post_process_args({'module_name': 'ping', 'module_args': '', 'args': 'localhost'})
    assert(options['module_name'] == 'ping')
    assert(options['module_args'] == '')
    assert(options['args'] == 'localhost')
    assert(options['verbosity'] == 0)
    options = cli.post_process_args({'module_name': 'ping', 'module_args': '', 'args': 'localhost', 'verbosity': 2})
    assert(options['module_name'] == 'ping')
    assert(options['module_args'] == '')
    assert(options['args'] == 'localhost')
    assert(options['verbosity'] == 2)
    options = cli.post_process_

# Generated at 2022-06-20 12:54:22.850985
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    import ansible.plugins.loader
    args = []
    # AdHocCLI.init_parser(args)
    # Test for type error when input_args are not of type list
    # args = "test"
    # Test for value error when no arguments are passed to args
    # args = []
    # AdHocCLI.init_parser(args)
    # Test for system exit if no args are passed
    # AdHocCLI.init_parser(args)

    # Test for command line arguments to be displayed when no args are passed
    # ad_hoc_cmd = AdHocCLI(args)
    # ad_hoc_cmd.parser.parse_args(args)
    # ad_hoc_cmd.init_parser()

    # Test for command line arguments to be displayed when -h is passed as an argument

# Generated at 2022-06-20 12:54:29.677111
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    parser = adhoc_cli.parser
    assert "usage: %prog <host-pattern> [options]" == parser.usage
    assert "Define and run a single task 'playbook' against a set of hosts" == parser.description
    assert "Some actions do not make sense in Ad-Hoc (include, meta, etc)" == parser.epilog

# Generated at 2022-06-20 12:54:33.506624
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.module_utils.common.removed import removed
    removed(__file__, 'AdHocCLI.run()', version='2.11')

# Generated at 2022-06-20 12:54:40.130971
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cmd = AdHocCLI(['-U', 'root', '-f', '10', 'all', '-a', 'shell date'])
    assert cmd, 'Failed to instantiate AdHocCLI'


# Generated at 2022-06-20 12:54:52.649616
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    # Assert that parser object is not None
    assert cli.parser is not None


# Generated at 2022-06-20 12:54:55.530152
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' constructor returns AdHocCLI object with proper args '''
    adhoc = AdHocCLI([])
    assert isinstance(adhoc, AdHocCLI)

# Generated at 2022-06-20 12:55:02.225218
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.post_process_args(["-i", "inventory", "-k", "-b", "-K", "-M", "m_path"])

    return cli.get_opt("host_key_checking") == True and \
           cli.get_opt("become") == True and \
           cli.get_opt("ask_become_pass") == True and \
           cli.get_opt("module_path") == "m_path"



# Generated at 2022-06-20 12:55:09.132346
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unit_tests.utils as utils

    # prerequisites
    args = utils.prepare_mocks()
    module_name = 'ping'
    args.pop('module_name')
    args['module_name']= module_name
    print('args', args)
    adhoccli = AdHocCLI(args)
    adhoccli.options = args
    adhoccli.post_process_args(adhoccli.options)
    adhoccli.run()
    print("adhoccli.options", adhoccli.options)

# Generated at 2022-06-20 12:55:11.451497
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI(args=['-m', 'shell', '127.0.0.1'])
    assert ad_hoc_cli is not None

# Generated at 2022-06-20 12:55:22.543336
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    from ansible.cli.arguments import option_helpers

    args = [
        '-m', 'ping',
        '-a', 'test=test',
        '--limit', 'localhost',
        '-u', 'user',
        '-k',
        '-c', 'ssh',
        '-v',
        '-e', 'test=test',
        'args',
    ]
    adhoc = AdHocCLI(args=args)
    adhoc.init_parser()
    assert adhoc.parser
    assert adhoc.parser._option_string_actions['-c'] == 'store'
    add_inventory_options = option_helpers.add_inventory_options
    add_inventory_options_calls = []

# Generated at 2022-06-20 12:55:25.360119
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_class = AdHocCLI()
    adhoc_class._play_prereqs()
    adhoc_class.get_host_list()
    adhoc_class.run()

# Generated at 2022-06-20 12:55:37.831086
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:55:40.664643
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    assert adhoc.parser.description.startswith('Define and run a single task')

# Generated at 2022-06-20 12:55:51.489736
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    AdHocCLI_instance = AdHocCLI()
    options = AdHocCLI_instance.post_process_args()

    # Test value of context.CLIARGS global dictionary
    assert 'connection'           in context.CLIARGS.keys()
    assert 'private_key_file'     in context.CLIARGS.keys()
    assert 'user'                 in context.CLIARGS.keys()
    assert 'module_name'          in context.CLIARGS.keys()
    assert 'module_args'          in context.CLIARGS.keys()
    assert 'become'               in context.CLIARGS.keys()
    assert 'become_method'        in context.CLIARGS.keys()
    assert 'become_user'          in context.CLIARGS.keys()


# Generated at 2022-06-20 12:56:11.974238
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class_AdHocCLI = AdHocCLI()
    class_AdHocCLI.options = opt_help.create_test_options_mock({'module_name': 'mock'})
    assert class_AdHocCLI.post_process_args(class_AdHocCLI.options) == class_AdHocCLI.options

# Generated at 2022-06-20 12:56:22.355547
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    display = Display()
    cli = AdHocCLI(args=['-K', 'test', '-u', 'user', '-k', 'test'], display=display)
    assert cli.options.ask_become_pass == True
    assert cli.options.ask_pass == True
    assert cli.options.become_pass == None
    assert cli.options.become_user == None
    assert cli.options.become == False
    assert cli.options.become_ask_pass == False
    assert cli.options.connection == 'smart'
    assert cli.options.diff == None
    assert cli.options.extra_vars == None
    assert cli.options.flush_cache == None
    assert cli.options.inventory == C.DEFAULT_HOST_LIST

# Generated at 2022-06-20 12:56:29.609379
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    adhoc_cli = AdHocCLI([])
    options = adhoc_cli.parser.parse_args(['-m', 'ping', '-a', 'foo=bar', 'all'])
    new_options = adhoc_cli.post_process_args(options)
    assert new_options.module_name == 'ping'
    assert new_options.module_args == 'foo=bar'
    assert new_options.args == 'all'
    '''
    pass

# Generated at 2022-06-20 12:56:32.603477
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_cli = AdHocCLI([])
    test_options = test_cli.parse()
    result = test_cli.run()
    assert result == 0

# Generated at 2022-06-20 12:56:40.197114
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    args = cli.parser.parse_args(['-m', 'raw', '-a', 'test', 'all'])
    args = cli.post_process_args(args)
    assert args.module_name == 'raw'
    assert args.module_args == 'test'
    assert args.args == 'all'
    assert args.one_line is False
    assert args.verbosity == 0



# Generated at 2022-06-20 12:56:40.823788
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:56:49.737547
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    class A(AdHocCLI):
        def run(self):
            assert self.args

    class B(AdHocCLI):
        def post_process_args(self, options):
            assert options

    class C(AdHocCLI):
        def run(self):
            assert self.inventory

    class D(AdHocCLI):
        def run(self):
            assert self.variable_manager

    class E(AdHocCLI):
        def run(self):
            assert self.loader

    class F(AdHocCLI):
        def run(self):
            assert self._tqm

    class G(AdHocCLI):
        def run(self):
            assert self.playbook


# Generated at 2022-06-20 12:56:58.236584
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])
    assert cli.parser.description == 'Define and run a single task \'playbook\' against a set of hosts'

    # Check that all subclass options have been added
    assert cli.parser._option_string_actions['-a'].dest == 'module_args'
    assert cli.parser._option_string_actions['-m'].dest == 'module_name'

    # Check that add_tasknoplay_options has been added
    assert cli.parser._option_string_actions['--task-timeout'].dest == 'task_timeout'



# Generated at 2022-06-20 12:57:08.396904
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # noinspection PyProtectedMember
    from ansible.plugins.loader import module_loader
    module_loader._find_plugins('./test/sanity/code/lib/ansible/modules')
    ad_hoc_cli = AdHocCLI(['test0', 'test1', 'test2'])
    ad_hoc_cli.init_parser()
    cmd_opts = ad_hoc_cli.get_optparser()
    ad_hoc_cli.parse(cmd_opts)
    assert len(cmd_opts.args) == 3
    ad_hoc_cli.post_process_args(cmd_opts)
    assert cmd_opts.args == ['test0', 'test1', 'test2']

# Generated at 2022-06-20 12:57:09.673194
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()

# Generated at 2022-06-20 12:57:45.882696
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()

    assert adhoc is not None

# Generated at 2022-06-20 12:57:50.558868
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Using params from AdHocCLI.__init__()
    ad_hoc_cli_init_parser = AdHocCLI()
    # Using params from AdHocCLI.init_parser() test coverage
    ad_hoc_cli_init_parser_help = AdHocCLI(args=["--help"])


# Generated at 2022-06-20 12:57:51.850427
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli


# Generated at 2022-06-20 12:57:59.515087
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.plugins.loader import module_loader

    # Create AdHocCLI object
    a = AdHocCLI()

    # Create parser for AdHocCLI object
    a.init_parser()

    # Create OptionParser object for AdHocCLI object
    parser = a.parser

    # Create fake arguments for OptionParser object
    args = parser.parse_args()

    # Post process and validate options
    a.post_process_args(args)

    # Load connection plugins relative to an arbitrary path
    a.load_plugins(module_loader.ALL_CATEGORIES)

    # Execute method run
    a.run()

# Generated at 2022-06-20 12:58:01.305455
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=[])
    assert isinstance(adhoc, AdHocCLI)
    # Verify that class attributes are properly set
    assert adhoc._tqm is None

# Generated at 2022-06-20 12:58:03.232177
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    parser = cli.init_parser()
    # one of the following parsers must be initialized:
    assert parser is not None


# Generated at 2022-06-20 12:58:13.190197
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    class Mock(object):
        pass

    args = Mock()
    args.module_args = 'module_args'
    args.module_name = 'module_name'
    args.args = 'args'
    adhoc_cli = AdHocCLI(args)

    assert adhoc_cli.parser is None
    assert adhoc_cli.options == args
    assert adhoc_cli.args == []
    assert adhoc_cli.display is None
    assert adhoc_cli.context is None
    assert adhoc_cli._tqm is None
    assert adhoc_cli.callback is None


# Generated at 2022-06-20 12:58:15.389031
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert not adhoc.sub
    assert adhoc.subparser is None
    assert adhoc.options is None
    assert adhoc.args is None
    assert adhoc.parser is None
    assert adhoc.callback is None



# Generated at 2022-06-20 12:58:22.161098
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    
    assert parser._actions[1].dest == 'subset'
    print(parser._actions[2].dest)
    assert parser._actions[2].dest == 'verbosity'
    assert parser._actions[3].dest == 'listhosts'
    assert parser._actions[4].dest == 'listtasks'
    assert parser._actions[5].dest == 'listtags'
    assert parser._actions[6].dest == 'syntax'


# Generated at 2022-06-20 12:58:23.890377
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()

# Generated at 2022-06-20 12:59:45.318278
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad = AdHocCLI()
    assert ad.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert ad.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-20 12:59:53.377285
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class FakeOption:
        def __init__(self, conflict_opts):
            self.conflict_opts = conflict_opts
    class FakeOptions:
        def __init__(self, verbosity, subset, listhosts, one_line, tree, module_name, module_args, forks,
                     runas_user, become_user, become_pass, become_method, become_ask_pass, connection,
                     check, inventory, stdout_callback, runtask_opts, seconds, poll_interval, basedir):
            self.verbosity = verbosity
            self.subset = subset
            self.listhosts = listhosts
            self.one_line = one_line
            self.tree = tree
            self.module_name = module_name
            self.module_args = module_args

# Generated at 2022-06-20 12:59:56.769534
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    AdHocCLI class constructor test case
    '''
    adhoc = AdHocCLI(['ping'])
    assert adhoc.options is not None
    assert adhoc.args is not None

# Generated at 2022-06-20 13:00:02.324899
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    args = cli.parser.parse_args([
        "-m", "ping",
        "-a", "'data=foo bar'",
        "host1 host2"
    ])
    assert args.host_pattern == "host1 host2"
    assert args.module_name == "ping"
    assert args.module_args == "data=foo bar"


# Generated at 2022-06-20 13:00:09.136279
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Read input parameters from command line
    parser = opt_help.create_base_parser(constants.base_parser_args, '{{ ansible_managed }}')
    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_async_options(parser)
    opt_help.add_output_options(parser)
    opt_help.add_connect_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)
    opt_help.add_basedir_options(parser)

# Generated at 2022-06-20 13:00:11.961553
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    CLI.set_defaults()
    mycli = AdHocCLI()
    assert isinstance(mycli.parser, optparse.OptionParser)

# Generated at 2022-06-20 13:00:16.868306
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = '-m ping -a "data=test" myhost'.split()
    cli = AdHocCLI()
    opts = cli.parse(args)[0]

    cli.post_process_args(opts)

    assert context.CLIARGS['module_name'] == 'ping'
    assert context.CLIARGS['module_args'] == 'data=test'
    assert context.CLIARGS['args'] == 'myhost'

# Generated at 2022-06-20 13:00:26.056201
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test with verbose set to False
    args = ['test-host']
    cli = AdHocCLI(args)
    cli.options.verbose = False
    cli.run()
    assert context.CLIARGS['verbosity'] == cli.options.verbose
    assert context.CLIARGS['host_pattern'] == 'test-host'
    # Test with verbose set to True
    args = ['test-host']
    cli = AdHocCLI(args)
    cli.options.verbose = True
    cli.run()
    assert context.CLIARGS['verbosity'] == cli.options.verbose
    assert context.CLIARGS['host_pattern'] == 'test-host'


# Generated at 2022-06-20 13:00:36.209673
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import sys
    import argparse
    from ansible import constants as C

    ####
    # Here we fake out argparse to add the required options. It's not a complete
    # fake since we use the actual OptionParser class. But it's sufficient to
    # make the class think it has all the required options.
    ####
    class FakeArg:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            parser = argparse.ArgumentParser()
            for arg, argval in self.kwargs.items():
                if arg == 'choices':
                    argval = list(argval)
                parser.add_argument(*self.args, **self.kwargs)
            # Calling

# Generated at 2022-06-20 13:00:36.745393
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass