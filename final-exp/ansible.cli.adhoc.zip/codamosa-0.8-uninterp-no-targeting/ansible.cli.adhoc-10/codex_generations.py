

# Generated at 2022-06-20 12:51:52.835763
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['foo'])
    cli.init_parser()
    cli.parser.parse_args(['host-pattern'])
    assert True

# Generated at 2022-06-20 12:51:55.259764
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    obj = AdHocCLI()
    assert obj == AdHocCLI()

# Generated at 2022-06-20 12:51:56.699576
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    t = AdHocCLI()
    t.init_parser()

# Generated at 2022-06-20 12:52:06.155547
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Prepare test
    import sys
    sys.argv = ['./bin/ansible']
    adhoc = AdHocCLI()

    # Execute test
    adhoc.init_parser()

    # Assertion
    assert adhoc.parser.prog == "./bin/ansible"
    assert adhoc.parser.usage == "%prog <host-pattern> [options]"
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-20 12:52:10.474003
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test when fork option specified
    options = opt_help.create_parser().parse_args(['some_hosts', '-f'])
    adhoc_cli = AdHocCLI()
    ppa = adhoc_cli.post_process_args
    try:
        ppa(options)
        assert False, "AnsibleOptionsError not raised when fork option specified"
    except AnsibleOptionsError:
        assert True



# Generated at 2022-06-20 12:52:18.974936
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.module_utils import basic
    a = AdHocCLI(args=['localhost'], runas_opts=True, fork_opts=True)
    a.set_option('module_name', 'ping')
    assert a.post_process_args(a.options)
    methods = {'run': a.run}
    ansible_mock = basic.AnsibleModule
    ansible_mock.run_command = methods['run']
    assert ansible_mock.run_command(a)

# Generated at 2022-06-20 12:52:26.627942
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''Test the post_process_args method of the AdHocCLI class'''

    # We need an instance of the AdHocCLI class
    adhoc = AdHocCLI()

    # Initialize the instance of the AdHocCLI class
    adhoc.parse()

    # AdHocCLI.post_process_args uses AnsibleCLI.post_process_args, which uses AnsibleCLI._load_options, which
    # uses AnsibleCLI.parse.
    # It means we need to "fake" the return value of AnsibleCLI.parse.
    # To set the return value of AnsibleCLI.parse, we "fake" the return value of AnsibleCLI._match_args.
    # So, we can test the return value of AnsibleCLI._match_args.
    matches

# Generated at 2022-06-20 12:52:31.478378
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Test with a existing parser
    ad_hoc = AdHocCLI(parser=CLI.base_parser(constants.constants))
    ad_hoc.parse()

    # Test with no existing parser
    ad_hoc = AdHocCLI()
    ad_hoc.parse()

# Generated at 2022-06-20 12:52:44.596925
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Unit test for method post_process_args of class AdHocCLI.

    :return:
    """
    import sys, os
    adhoc_cli = AdHocCLI(args=[])

    # [1] set up option
    from ansible.utils.vars import combine_vars

    # root_loader.set_vault_secrets(None)
    # root_loader.set_vault_password('None')

    context.CLIARGS = combine_vars(adhoc_cli.parse(), vault_secrets=None, vault_password=None)
    # print('CLIARGS: ', context.CLIARGS)

    # [2] call post_process_args
    adhoc_cli.post_process_args(context.CLIARGS)

# Generated at 2022-06-20 12:52:54.509292
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    with open("test_adhoccli.txt", "a") as f:
        test_cli = AdHocCLI()
        #Test init_parser
        test_cli.init_parser()
        f.write('\n test_adhoccli.txt \n')
        #Test post_process_args
        options = ['-a', 'opt1=val1 opt2=val2','-m', 'ping', '-k', '127.0.0.1']
        test_cli.post_process_args(options)
        #Test run function
        test_cli.run()
        #Test _play_ds function
        test_cli._play_ds('test',1.0,0.01)
        #Test validate_conflicts function
        test_cli.validate_conflicts('test',True,False)
       

# Generated at 2022-06-20 12:53:08.938996
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc = AdHocCLI(['-f', '25', '-t', '25', '-k'])
    ad_hoc._options = ad_hoc.parser.parse_args(['-f', '25', '-t', '25', '-k'])
    ad_hoc.post_process_args(ad_hoc._options)
    assert ad_hoc._options.timeout == '25'
    assert ad_hoc._options.forks == '25'
    assert ad_hoc._options.ask_pass == 'True'



# Generated at 2022-06-20 12:53:09.609474
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:53:11.781634
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    assert isinstance(parser, object)

# Generated at 2022-06-20 12:53:21.570922
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    arghandler = AdHocCLI()
    assert isinstance(arghandler, CLI)
    assert arghandler.ops == None
    assert not arghandler.args 
    assert arghandler.help == True 
    assert arghandler.listhosts == False
    assert arghandler.listtasks == False
    assert arghandler.listtags == False
    assert arghandler.syntax == False
    assert arghandler.connection == 'smart'
    assert arghandler.timeout == 10
    assert arghandler.forks == 5
    assert arghandler.ssh_common_args == None
    assert arghandler.ssh_extra_args == None
    assert arghandler.sftp_extra_args == None
    assert arghandler

# Generated at 2022-06-20 12:53:23.074723
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    obj = AdHocCLI(args=[])
    obj.init_parser()



# Generated at 2022-06-20 12:53:26.311242
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Ensures that the default method does not raise an exception.
    """
    class MockAdHocCLI(AdHocCLI):
        def init_parser(self):
            return

    mock_parser = MockAdHocCLI()
    mock_parser.post_process_args(MockAdHocCLI().parse())

# Generated at 2022-06-20 12:53:38.880094
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    display = Display()
    # Create a AdHocCLI instance
    my_adhoc = AdHocCLI()
    # Mocked method set_options

# Generated at 2022-06-20 12:53:50.709636
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Modify CLIArgs to satisfy test cases
    context.CLIARGS = {'module_name': 'ping'}

    # Create an instance of AdHocCLI in 'test' mode
    cli = AdHocCLI(['ping'], run_in_test=True)

    # Create an instance of Display
    display.verbosity = 3

    # Create an instance of Playbook
    playbook = Playbook()

    # Create instances of Play and TaskQueueManager
    play = Play()
    queue_manager = TaskQueueManager()

    # Importing Play
    play_ds = cli._play_ds(to_text('ping'), context.CLIARGS['seconds'], context.CLIARGS['poll_interval'])
    play = Play().load(play_ds, variable_manager=None, loader=None)



# Generated at 2022-06-20 12:53:54.098004
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-m', 'ping']
    cli = AdHocCLI(args)
    options = cli.parse()
    cli.post_process_args(options)
    assert options.module_name == 'ping'


# Generated at 2022-06-20 12:53:56.534428
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Test class constructor
    '''
    cli = AdHocCLI()
    assert isinstance(cli, AdHocCLI)

# Generated at 2022-06-20 12:54:07.067441
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    adhoc.init_parser()


# Generated at 2022-06-20 12:54:17.615356
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.utils.display import Display
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    cli = AdHocCLI(args=[], display=display)
    try:
        cli.parse()
    except AnsibleOptionsError as e:
        assert "ERROR! Missing required arguments: pattern" in to_text(e)
    else:
        assert False, "AnsibleOptionsError was not raised"

    # test the case where no options are provided
    cli = AdHocCLI(args=['all'], display=display)
    options = cli.parse()
    assert options is not None, "options should not be none"
    options = cli.post_process_args(options)
   

# Generated at 2022-06-20 12:54:18.944557
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(["localhost"])


# Generated at 2022-06-20 12:54:23.177900
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.initialize()
    assert parser != None

# Make sure we get a useful error message if trying to use options specific to action plugins

# Generated at 2022-06-20 12:54:25.493688
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    options = opt_help.parse_cli_args()
    adhoc = AdHocCLI(args=options)

# Generated at 2022-06-20 12:54:34.716946
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test case 1
    # AdHocCLI.post_process_args() raises AnsibleOptionsError when the parameter
    # - check_raw=True (for '-a' option in this case)
    # - is not passed via CLI (no module args given)
    # - option 'module_name' value is in C.MODULE_REQUIRE_ARGS

    import mock
    import sys
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.utils.display import Display

    display = Display()

    adhoc_cli = CLI(['adhoc', '-a', 'ping', 'all'])
    adh

# Generated at 2022-06-20 12:54:36.847928
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    run = AdHocCLI().run()
    assert run

# Generated at 2022-06-20 12:54:46.073169
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert cli.parser.format_help() == AdHocCLI.run.__doc__
    assert cli.parser._actions[1].choices == ['smart', 'ssh', 'paramiko']
    assert cli.parser._actions[3].help == 'output action in adhoc mode (default is to use the configured callback plugin)'
    assert cli.parser._actions[5].help == 'seconds to delay to wait for async tasks to finish. Use 0 for no delay.'
    assert cli.parser._actions[7].default == False
    assert cli.parser._actions[8].default == None
    assert cli.parser._actions[9].default == C.DEFAULT_ASK_SUDO_PASS


# Generated at 2022-06-20 12:54:50.916366
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(None)
    if not isinstance(adhoc_cli, AdHocCLI):
        raise AssertionError("adhoc_cli is not an instance of class AdHocCLI")


# Generated at 2022-06-20 12:54:51.494749
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    pass

# Generated at 2022-06-20 12:55:18.460539
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # Create a mock object for display class
    display = type("Display", (object,), {
        'verbosity': 0,
        'warning': lambda self, msg: None,
    })
    display.verbosity = 0

    # Create a mock object for context class
    context.CLIARGS = {}
    context.CLIARGS['verbosity'] = 0

    # Create a mock object for CLI class
    adhoc = type("CLI", (object,), {
    })
    adhoc.parser = type("parser", (object,), {
    })
    adhoc.init_parser()
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-20 12:55:27.164000
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class DummyAdHocCLI(AdHocCLI):
        def __init__(self):
            self.parser = CLI.base_parser(
                usage='%prog <host-pattern> [options]',
                desc="Ad-hoc command line tools to execute simple tasks "
                     "when you just want to kick something off."
            )
            self.inventory = None
            self.loader = None
            self.variable_manager = None

        def init_parser(self):
            super(DummyAdHocCLI, self).init_parser()

        def run(self):
            return 0

    # create an instance of the dummy class
    dacli = DummyAdHocCLI()

    # create a parser
    dacli.init_parser()

    # add arguments to the parser

# Generated at 2022-06-20 12:55:39.884694
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-20 12:55:42.357305
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    try:
        a = AdHocCLI()
        a.run()
    except Exception as e:
        assert(0)



# Generated at 2022-06-20 12:55:52.953745
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    host_pattern = '192.168.100.100'
    module_name = 'ping'
    module_args = 'ping'

# Generated at 2022-06-20 12:56:01.721935
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    argv = ['-a', 'argument1=value1', '-f', '8', 'localhost', '-m', 'module1', '-C', '-k', '-K']
    args = AdHocCLI(args=argv).parse()
    assert args['module_name'] == 'module1'
    assert args['module_args'] == 'argument1=value1'
    assert args['forks'] == 8
    assert args['host_pattern'] == 'localhost'
    assert args['ask_pass']
    assert args['ask_become_pass']
    assert args['listhosts']
    assert args['check']

# Generated at 2022-06-20 12:56:11.218621
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    with open('./test/unit/cli/adhoc/AdHocCLI_init_parser.yml', 'r') as f:
        test_cases = yaml.load(f)['test_cases']
        for test_case in test_cases:
            # Initialize AdHocCLI with test case parameters
            cli = AdHocCLI()
            cli.options = test_case['options']
            cli.args = test_case['args']
            exp_args = test_case['expected_args']

            # Call the method under test
            cli.init_parser()

            # Verify options and args
            assert cli.options == exp_args['options']
            assert cli.args == exp_args['args']

# Generated at 2022-06-20 12:56:16.714051
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(command='/usr/bin/ansible-adhoc')
    adhoc_cli.parse()
    assert adhoc_cli.options.listhosts is False
    assert adhoc_cli.options.listtasks is False
    assert adhoc_cli.options.listtags is False

# Generated at 2022-06-20 12:56:21.280450
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Run the post_process_args method of AdHocCLI to print the arguments
    '''

    cli = AdHocCLI(['-a', 'var_name=val', 'hostpattern'])
    cli.parse()
    cli.post_process_args(cli.options)
    assert cli.options


# Generated at 2022-06-20 12:56:33.188803
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.options = opt_help.parse_option_strings('')
    cli.post_process_args(cli.options)
    assert context.CLIARGS['module_name'] == 'command'
    assert context.CLIARGS['module_args'] == 'echo hi'
    assert context.CLIARGS['args'] == 'test_host'

    # test default args
    cli.options = opt_help.parse_option_strings('')
    context.CLIARGS = None
    cli.post_process_args(cli.options)
    assert context.CLIARGS['module_name'] == 'command'
    assert context.CLIARGS['module_args'] == ''

    # test empty args
    cli.options = opt_help

# Generated at 2022-06-20 12:57:14.060741
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Options(object):
        pass

    options = Options()
    # Disable pylint message: Access to a protected member _display of a client class
    # pylint: disable=protected-access

    # Test call with verbosity 3
    options.verbosity = 3
    cli = AdHocCLI()
    options = cli.post_process_args(options)
    assert options.verbosity == 3
    assert cli._display.verbosity == 3

    # Test call with verbosity 2
    options.verbosity = 2
    cli = AdHocCLI()
    options = cli.post_process_args(options)
    assert options.verbosity == 2
    assert cli._display.verbosity == 2

    # Test call with verbosity 1
    options.verbosity = 1
    cli = AdH

# Generated at 2022-06-20 12:57:15.768164
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    assert cli.parser._prog == 'ansible'

# Generated at 2022-06-20 12:57:26.001850
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Unit tests for method post_process_args of class AdHocCLI"""
    # Check that it uses the args parameter when present
    temp_parse_args = CLI.parse_args
    CLI.parse_args = lambda *args, **kwargs: {'args': '0123456789'}
    assert AdHocCLI().post_process_args({})['args'] == '0123456789'
    CLI.parse_args = temp_parse_args
    # Check that it raises an error when pattern is missing
    temp_parse_args = CLI.parse_args
    CLI.parse_args = lambda *args, **kwargs: {}
    try:
        AdHocCLI().post_process_args({})
    except Exception as error:
        assert type(error) == SystemExit

# Generated at 2022-06-20 12:57:34.041013
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    class AdHocCLI_test(AdHocCLI):

        def post_process_args(self, options):
            return super(AdHocCLI_test, self).post_process_args(options)

    # create an options object for testing
    parser = AdHocCLI_test()
    parser.parse()

    # test verbosity
    assert parser.post_process_args(options=None).verbosity == 0

    # test check mode
    assert parser.post_process_args(options=None).check == False

    # test start at task
    assert parser.post_process_args(options=None).start_at_task == None

# Generated at 2022-06-20 12:57:45.449783
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:57:46.376429
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:57:48.289777
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    try:
        adhoc_cli = AdHocCLI()
    except:
        assert False
    assert True

# Generated at 2022-06-20 12:57:51.978519
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    import sys
    adhoc_cli = AdHocCLI(args=sys.argv[1:])
    assert adhoc_cli.parser
    assert adhoc_cli.parser._usage_actions
    assert adhoc_cli.parser._actions

# Generated at 2022-06-20 12:57:53.792179
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()


# Generated at 2022-06-20 12:57:57.242045
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # No longer relevant. To be removed after https://github.com/ansible/ansible/issues/62186 is fixed.
    #
    # test_instance = AdHocCLI()
    # assert test_instance.run() == 0
    pass

# Generated at 2022-06-20 12:59:04.504661
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Test for AdHocCLI class method init_parser
    # (inherited from the super class CLI) with an instance
    # of AdHocCLI class with a method called init_parser
    testobj = AdHocCLI()
    assert hasattr(testobj, 'init_parser')

# Generated at 2022-06-20 12:59:09.359414
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    obj = AdHocCLI()
    obj.post_process_args(['ansible', '1.1.1.1', '-m', 'test', '-a', 'opt1=val1'])

    # Test failure - no pattern
    try:
        obj.post_process_args(['ansible', '-m', 'test', '-a', 'opt1=val1'])
    except SystemExit:
        pass
    else:
        assert False, "Exception was not raised"

# Generated at 2022-06-20 12:59:11.159060
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI()
    assert isinstance(ad_hoc, AdHocCLI)

# Generated at 2022-06-20 12:59:23.270927
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    test_adhoc_cli = AdHocCLI()
    test_adhoc_cli.init_parser()
    test_args = ['-vvv', '-m', 'test_module', '-a', 'test_arg', 'test_inventory_path', 'test_pattern']
    # test --ask-pass and --ask-become-pass without resolution
    new_args = test_adhoc_cli.parser.parse_args(test_args)
    assert new_args.ask_pass is False
    assert new_args.ask_become_pass is False
    return_args = test_adhoc_cli.post_process_args(new_args)
    assert return_args.ask_pass is False
    assert return_args.ask_become_pass is False

    # test --ask-pass and --ask-bec

# Generated at 2022-06-20 12:59:29.656329
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.module_utils.six.moves import StringIO

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    task_list = dict(
        action=dict(
            module='ping',
            args=dict()
        )
    )
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[task_list]
    )

# Generated at 2022-06-20 12:59:39.006196
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse
    """
        Invoke run() method of class AdHocCLI and verify
        if it executes well or not.
    """
    from collections import namedtuple

    args_list = list(
        namedtuple("My_args", "module_name module_args forks")
        (
            "setup",
            "filter=*ipv4*",
            100
        )
    )

    for args in args_list:
        # Create an instance of class AdHocCLI
        adhoc_cli = AdHocCLI()

        # Create an instance of class ArgumentParser
        parser_obj = adhoc_cli.create_parser()

        # Add required arguments to an instance of class AdHocCLI

# Generated at 2022-06-20 12:59:49.508031
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Unit test for method post_process_args of class AdHocCLI
    """
    test_obj = AdHocCLI(args=['pattern'])
    test_options = opt_help.add_runtask_options(test_obj.parser)
    test_options.__dict__[C.FORKS_OPTIONS_MIN_FORKS] = '3'
    test_options.__dict__[C.FORKS_OPTIONS_MAX_FORKS] = '5'
    test_return_options = test_obj.post_process_args(test_options)
    assert test_return_options.__dict__[C.FORKS_OPTIONS_MIN_FORKS] == 3
    assert test_return_options.__dict__[C.FORKS_OPTIONS_MAX_FORKS]

# Generated at 2022-06-20 12:59:59.863077
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()

# Generated at 2022-06-20 13:00:06.322622
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=[])
    options = cli.parser.parse_args(['-e', 'key=value', '-e', 'key=value'])
    options = cli.post_process_args(options)
    assert options.extra_vars == dict(key='value')

    # Make sure we throw an error if there is a problem with parsing
    cli = AdHocCLI(args=[])
    options = cli.parser.parse_args(['-e', 'key=value', '-e', 'key="value'])
    with pytest.raises(AnsibleOptionsError):
        cli.post_process_args(options)

# Generated at 2022-06-20 13:00:08.047825
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoccli = AdHocCLI()
    assert isinstance(adhoccli, AdHocCLI)