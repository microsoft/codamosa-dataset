

# Generated at 2022-06-20 12:51:55.852939
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()

    assert (adhoc_cli.parser.usage == '%prog <host-pattern> [options]')
    assert (adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts")
    assert (adhoc_cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)")
    assert (adhoc_cli.parser.formatter_class == argparse.RawDescriptionHelpFormatter)
    assert (adhoc_cli.parser.add_argument.call_count == 17)

    # Add runas options
    runas_opts = adhoc_cli.parser.add_argument.call_args_list[1][0]

# Generated at 2022-06-20 12:52:01.204733
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser.description is not None, "Description is empty!"
    assert adhoc_cli.parser.epilog is not None, "Epilog is empty!"

# Generated at 2022-06-20 12:52:06.586579
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert(cli.parser.prog == 'ansible')
    assert(cli.parser.description == ("Define and run a single task 'playbook' against a set of hosts"))
    assert(cli.parser.usage == "%prog <host-pattern> [options]")
    assert(cli.parser.epilog == ("Some actions do not make sense in Ad-Hoc (include, meta, etc)"))

# Generated at 2022-06-20 12:52:07.710066
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    assert cli.parser



# Generated at 2022-06-20 12:52:13.319597
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    #TODO: implement better unit tests for AdHocCLI.run
    import sys

    #test code should create a temp inventory and CLIARGS
    #test code should use setUp and tearDown to create and clean up files
    #test code should use mox

    #mock up an adhoc cli instance
    cli = AdHocCLI(sys.argv)
    #set CLIARGS
    context.CLIARGS = dict(listhosts=False, subset=False, module_name=C.DEFAULT_MODULE_NAME, module_args='echo hi', forks=1, verbosity=0, one_line=False, tree=None, seconds=0, poll_interval=0)

# Generated at 2022-06-20 12:52:16.887413
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import sys
    sys.argv = ['./ansible-playbook', 'test', '--version']
    x = AdHocCLI(args=sys.argv[1:])
    x.parse()

# Generated at 2022-06-20 12:52:27.418201
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    #Test check_raw
    opts=dict(
        module_name = 'echo',
        module_args='a=b c=d',
        verbosity=2)

    objTest = AdHocCLI()
    objTest.post_process_args(opts)

    assert opts['module_name'] == 'echo'
    assert opts['module_args'] == dict(a='b', c='d')
    assert opts['verbosity'] == 2
    assert context.CLIARGS['module_name'] == 'echo'
    assert context.CLIARGS['module_args'] == dict(a='b', c='d')
    assert context.CLIARGS['verbosity'] == 2

    #Test check_raw

# Generated at 2022-06-20 12:52:29.545863
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    acli = AdHocCLI([])
    acli.init_parser()


# Generated at 2022-06-20 12:52:34.783580
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:52:36.455670
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli

# Generated at 2022-06-20 12:52:54.575105
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ''' Test AdHocCLI post_process_args '''
    cli = AdHocCLI(args=[])
    cli.parse()
    options = cli.options
    # Test with required options, and no sshpass
    options.module_name = 'setup'
    options.remote_user = 'root'
    options.connection = 'ssh'
    cli.post_process_args(options)
    # Test with required options, sshpass, and no becomepass
    options.ssh_pass = 'ansible'
    cli.post_process_args(options)
    # Test with required options, sshpass and becomepass
    options.become_pass = 'ansible'
    cli.post_process_args(options)

# Generated at 2022-06-20 12:53:06.297054
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # test case 1
    args = ['ansible', 'all', '-m', 'ping']
    adhoc_cli = AdHocCLI(args)
    assert adhoc_cli.options.module_name == 'ping'
    assert adhoc_cli.options.subset == 'all'
    assert adhoc_cli.options.module_args is None
    # test case 2
    args = ['ansible', 'all', '-a', 'arg1=val1', '-a', 'arg2=val2']
    adhoc_cli = AdHocCLI(args)
    assert adhoc_cli.options.subset == 'all'
    assert adhoc_cli.options.module_name == C.DEFAULT_MODULE_NAME
    assert adhoc_cli.options.module_

# Generated at 2022-06-20 12:53:11.015953
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['-m', 'ping', 'localhost'])
    assert adhoc.args == ['ping']
    assert adhoc.options.module_name == 'ping'
    assert adhoc.options.module_args == C.DEFAULT_MODULE_ARGS

# Generated at 2022-06-20 12:53:13.596143
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    args = ['ansible', '-m', 'setup', '-a', 'ping']
    runner = AdHocCLI(args)
    runner.parse()

    assert context.CLIARGS['module_name'] == 'setup'
    assert context.CLIARGS['module_args'] == 'ping'



# Generated at 2022-06-20 12:53:14.900752
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])
    assert cli

# Generated at 2022-06-20 12:53:17.493253
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI(args=['-e','connection=local','foo', 'bar'])
    a._parse_cli_opts()
    assert a.parser
    a.post_process_args(a.opts)
    assert a.opts

# Generated at 2022-06-20 12:53:21.685073
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    args = [
        'ansible',
        'host-pattern'
    ]
    my_adhoc_cli = AdHocCLI(args)
    assert my_adhoc_cli.parser.prog == 'ansible'
    assert my_adhoc_cli.parser._positionals.title == 'options'


# Generated at 2022-06-20 12:53:22.873399
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()
    assert True

# Generated at 2022-06-20 12:53:29.212259
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # pylint: disable=protected-access
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.parser = CLI.base_parser(constants=C)
    C.config = CLI._configure_logging(None, 0)

    with ad_hoc_cli.parser.subcommand() as x:
        x.add_argument('-a', '--args', dest='module_args', help="The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'", default=C.DEFAULT_MODULE_ARGS)

# Generated at 2022-06-20 12:53:31.565967
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()

# Generated at 2022-06-20 12:53:51.325420
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Creating an instance of AdHocCLI class
    adhoc_cli = AdHocCLI()
    # Calling the method run
    adhoc_cli.run()

# Generated at 2022-06-20 12:54:01.485956
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    basedir = os.path.dirname(__file__)
    data_loader = DataLoader()
    inventory = Inventory(loader=data_loader,
                          variable_manager=VariableManager(loader=data_loader),
                          host_list=os.path.join(basedir, '../../files/hosts'))

# Generated at 2022-06-20 12:54:04.143808
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=[])
    assert isinstance(adhoc_cli, AdHocCLI)


# Generated at 2022-06-20 12:54:05.084553
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    raise NotImplementedError

# Generated at 2022-06-20 12:54:10.499828
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    display.verbosity = 3
    cli = AdHocCLI()
    cli.parser = cli.create_parser()
    cur_args = cli.parse()
    with pytest.raises(AnsibleOptionsError) as excinfo:
        cli.post_process_args(cur_args)
    assert '-a option is required in Adhoc' in excinfo.exconly()

# Generated at 2022-06-20 12:54:14.677087
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.usage == "%prog <host-pattern> [options]"



# Generated at 2022-06-20 12:54:19.173359
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # instantiate class
    cli = AdHocCLI(args=[])

    # test constructor args
    assert cli._play_prereqs == AdHocCLI.play_prereqs
    assert cli._ask_passwords == AdHocCLI.ask_passwords
    assert cli._tqm == None

# Generated at 2022-06-20 12:54:21.999339
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' test init of AdHocCLI.init_parser() '''

    ahc = AdHocCLI()
    parser = ahc.init_parser()
    assert parser



# Generated at 2022-06-20 12:54:27.389914
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"

# Generated at 2022-06-20 12:54:28.544907
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    assert 1 == 1



# Generated at 2022-06-20 12:54:48.439930
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-a', '']

    test_obj = AdHocCLI(args)
    result = test_obj.post_process_args(test_obj.parser.parse_args(args))
    assert result.module_args == C.DEFAULT_MODULE_ARGS
    assert result.module_name == C.DEFAULT_MODULE_NAME

# Generated at 2022-06-20 12:55:00.703141
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test case 1:
    #   If '-M' is used,
    #   then 'basedir' is a mandatory option.
    try:
        opt = {'module_path': '/path/to/my/module_path', 'module_name': 'shell', 'module_args': 'whoami'}
        cli = AdHocCLI(args=[])
        cli.post_process_options(opt)
        raise Exception("AdHoc CLI did not raise an exception despite that 'basedir' wasn't defined")
    except SystemExit as e:
        if not e.code == -1:
            raise Exception("AdHoc CLI did not return the correct exit code")

    # Test case 2:
    #   If '-M' is used,
    #   then 'basedir' isn't a mandatory option.
    opt

# Generated at 2022-06-20 12:55:02.461657
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pass

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-20 12:55:11.105062
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an AdHocCLI object
    adhoc_cli_obj = AdHocCLI()

    # Create an argument parser
    parser = adhoc_cli_obj.parser
    # Add arguments to the parser
    adhoc_cli_obj.init_parser()
    # Parse the user input arguments
    args = parser.parse_args('-m setup localhost'.split())
    # Set the object attributes from the parsed args
    adhoc_cli_obj.args = args
    # Run the Ad-Hoc command given the user input arguments
    adhoc_cli_obj.run()

    # Create another AdHocCLI object
    adhoc_cli_obj = AdHocCLI()

    # Create an argument parser
    parser = adhoc_cli_obj.parser
    # Add arguments to

# Generated at 2022-06-20 12:55:19.603342
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(['--become', '-K', '-i', 'localhost,', '-m', 'ping', '--timeout', '5'])
    args = cli.parse()
    args = cli.post_process_args(args)
    assert args.become
    assert args.become_method == 'sudo'
    assert args.become_user == 'root'
    assert args.connection == 'smart'
    assert args.timeout == 5
    assert args.verbosity == 0
    assert not args.check


# Generated at 2022-06-20 12:55:24.074325
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI(['-a', 'ls -al'])
    assert adhoc.parser.prog == 'ansible-adhoc'
    assert adhoc.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc._usage == '%prog <host-pattern> [options]'


# Generated at 2022-06-20 12:55:25.863514
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Unit test for the AdHocCLI class in the cli directory.
    """
    # FIXME
    pass

# Generated at 2022-06-20 12:55:28.107599
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # setup
    cmd = AdHocCLI(args=[])
    cmd.parse()
    # test
    assert cmd.parser is not None
    # cleanup
    cmd.parser = None


# Generated at 2022-06-20 12:55:30.065127
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI(['-h'])
    assert parser is not None


# Generated at 2022-06-20 12:55:42.129927
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.removed import removed_module

    AdHocCLI._play_prereqs = lambda x: (module_loader, Inventory([], [], [], []), VariableManager(play_context=PlayContext()))
    AdHocCLI.ask_passwords = lambda x: ('', '')

    adhoc = AdHocCLI()
    adhoc.run = lambda: 0
    adhoc.callback = None

# Generated at 2022-06-20 12:56:24.022207
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    #These lines create the AdHocCLI class with the args of this method
    adhoc = AdHocCLI(args=['-l','localhost', '-m', 'test', '-a', 'test'])
    adhoc.init_parser()
    #Calling the parser with the defined args will create a new parser that we compare
    #with the one created in the method
    parser = CLI.base_parser(constants.DEFAULT_MODULE_NAME, constants.DEFAULT_MODULE_PATH,
                             constants.DEFAULT_MODULE_ARGS, '%prog <host-pattern> [options]',
                             'Define and run a single task \'playbook\' against a set of hosts',
                             epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")

# Generated at 2022-06-20 12:56:35.131147
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    adhoc.parser = adhoc.init_parser()

# Generated at 2022-06-20 12:56:46.248819
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    options = cli.options
    options.connection = 'ssh'

    cli.post_process_args(options)
    assert context.CLIARGS['connection'] == 'ssh'

    # make sure we catch errors
    options.connection = 'blah'
    try:
        cli.post_process_args(options)
        assert False
    except AnsibleOptionsError as e:
        assert str(e) == "connection should be one of ssh|paramiko|winrm|local"

    cli2 = AdHocCLI()
    cli2.options.module_name = 'shell'

# Generated at 2022-06-20 12:56:53.048295
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create and execute the single task playbook
    # first initialize the display
    display = Display()
    display.verbosity = 0
    # initialize the options
    cli = AdHocCLI(args=['ansible', 'all', '-i', 'localhost,'])
    options = cli.parse()
    options = cli.post_process_args(options)
    display.verbosity = options.verbosity
    # get basic objects
    loader, inventory, variable_manager = cli._play_prereqs(None)
    # get list of hosts to execute against
    hosts = cli.get_host_list(inventory, context.CLIARGS['subset'], 'all')
    # construct playbook objects to wrap task
    play_ds = cli._play_ds('all', '0', '0')

# Generated at 2022-06-20 12:57:00.813936
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    assert ad_instance.post_process_args(options) == options

ad_instance = AdHocCLI(['/etc/ansible/hosts'])
options = ad_instance.init_parser()
options = ad_instance.post_process_args(options)
options.verbosity = 2
options.module_name = 'shell'
options.module_args = 'date'
options.forks = 5
options.listhosts = False
options.subset = None
options.seconds = 0
options.poll_interval = 0
options.tree = None

# Generated at 2022-06-20 12:57:11.042264
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible import context

    class FakeOptions():
        pass

    class FakeCLIArgs():
        inventory = 'inventory/test'
        forks = 10
        module_name = 'fake'
        verbosity = 3
        subset = 'all'
        module_args = 'arg=value'
        async_val = 1
        poll_interval = 1
        seconds = 1
        extra_vars = []
        run_hosts = []

    context.CLIARGS = FakeCLIArgs()

    # build fake inventory
    inventory_path = context.CLIARGS.inventory
    loader = False
    sources = 'test'
   

# Generated at 2022-06-20 12:57:16.809050
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert cli.parser.prog == u'ansible'
    assert cli.parser._actions[2].help == 'Pattern of hosts to run the ad-hoc command on (default=all)'
    assert cli.parser._actions[2].metavar == 'pattern'
    assert cli.parser._actions[5].help == 'name of the action module to execute (default=command)'
    assert cli.parser._actions[6].help == "The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'"


# Generated at 2022-06-20 12:57:27.119082
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # create an options parser for bin/ansible
    cli = AdHocCLI()
    cli.init_parser()

    # Case: args: tasknoplay=True, verbosity=1
    cli.parser.set_defaults(tasknoplay=True)
    cli.parser.set_defaults(verbosity=1)
    args = cli.parser.parse_args([])
    options = cli.post_process_args(args)
    assert options.tasknoplay
    assert options.verbosity == 1
    assert not hasattr(options, 'listhosts')

    # Case: args: listhosts=True, verbosity=3
    cli.parser.set_defaults(listhosts=True)
    cli.parser.set_defaults(verbosity=3)


# Generated at 2022-06-20 12:57:30.868169
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI(['localhost', '-m', 'module', 'arg1', 'arg2'])
    adhoc_cli.init_parser()
    adhoc_cli.run()


# Generated at 2022-06-20 12:57:32.288391
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """Test the AdHocCLI method run"""
    # TODO

# Generated at 2022-06-20 12:59:03.626481
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:59:05.595454
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI = AdHocCLI()
    args = AdHocCLI.init_parser()


# Generated at 2022-06-20 12:59:15.807028
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    options = optparse.Values()
    options.module_name = 'ping'
    options.inventory = ['/etc/ansible/hosts']
    options.become = True
    options.become_method = 'sudo'
    options.become_user = 'ansible'
    options.ask_pass = False
    options.private_key_file = ['/home/good.pem']
    options.verbosity = 3
    options.timeout = 30
    options.connection = 'local'
    options.check = False

    cli = AdHocCLI(None)
    cli.post_process_args(options)

    assert cli.options.inventory == '/etc/ansible/hosts'
    assert cli.options.connection == 'local'

# Generated at 2022-06-20 12:59:17.183835
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import ansible.cli.adhoc
    AdHocCLI()

# Generated at 2022-06-20 12:59:19.424243
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()



# Generated at 2022-06-20 12:59:21.033496
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    return 0


# Generated at 2022-06-20 12:59:28.871198
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    class Mock_CLI(AdHocCLI):
        def __init__(self, args):
            pass

    mock_args = []
    mock_args.append('ansible')
    mock_args.append('all')
    mock_args.append('-i')
    mock_args.append('localhost,')

    try:
        mock_args.remove('-m')
    except ValueError:
        pass

    mock_args.append('-m')
    mock_args.append('setup')
    mock_args.append('-c')
    mock_args.append('local')
    mock_args.append('-v')

    instance = Mock_CLI(mock_args)

    assert instance.base_parser.description == '''Define and run a single task 'playbook' against a set of hosts'''

# Generated at 2022-06-20 12:59:33.144825
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.options = cli.parse()

    assert cli.options.module_name == C.DEFAULT_MODULE_NAME
    assert cli.options.module_args == C.DEFAULT_MODULE_ARGS
    assert cli.options.args == 'pattern'

# Generated at 2022-06-20 12:59:37.021303
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ test_AdHocCLI: test constructor only.  Other tests are in main.py """
    cli = AdHocCLI()
    assert cli.parser
    assert cli.args
    assert cli.options

# Generated at 2022-06-20 12:59:43.083205
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['--list-hosts'])
    cli.init_parser()
    opt = cli.parser.parse_args(['--list-hosts'])
    assert opt.module_name == C.DEFAULT_MODULE_NAME
    assert opt.module_args == C.DEFAULT_MODULE_ARGS
    assert opt.listhosts is True