

# Generated at 2022-06-20 12:52:09.933851
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Initialize class, set options and call post_process_args
    cli = AdHocCLI()

# Generated at 2022-06-20 12:52:15.850188
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    mycli = AdHocCLI(['ansible', 'test.org', '-a', 'foo=123'])
    assert mycli.options.module_name == 'command'
    assert mycli.options.module_args == 'foo=123'
    assert mycli.options.args == 'test.org'

    mycli = AdHocCLI(['ansible', 'test.org', '-m', 'service', '-a', 'name=httpd state=restarted'])
    assert mycli.options.module_name == 'service'
    assert mycli.options.module_args == 'name=httpd state=restarted'
    assert mycli.options.args == 'test.org'


# Generated at 2022-06-20 12:52:19.236503
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    cli = AdHocCLI()
    cli.init_parser()

    assert isinstance(cli.parser, argparse.ArgumentParser)



# Generated at 2022-06-20 12:52:26.788244
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class FakeCLI(AdHocCLI):
        pass

    cli = FakeCLI()

    class FakeOptions(object):
        connection = 'local'
        forks = 5
        inventory = '/some/path'
        become = True
        become_method = 'su'
        become_user = 'someuser'
        check = False
        diff = False
        extra_vars = [('foo', 'bar'), ('bar', 'baz')]
        flush_cache = True
        force_handlers = True
        listhosts = True
        module_path = ['x1', 'x2']
        one_line = True
        output_file = '/some/path'
        poll_interval = 15
        private_key_file = '/some/path'
        su = True
        su_user = 'someuser'

# Generated at 2022-06-20 12:52:28.350504
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI()
    assert type(ad_hoc) == AdHocCLI

# Generated at 2022-06-20 12:52:35.110663
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    fake_prog_name = 'ansible'
    cli = AdHocCLI(prog=fake_prog_name)
    parser = cli.init_parser()

    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

    assert parser.prog == fake_prog_name


# Generated at 2022-06-20 12:52:37.445239
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, AdHocCLI)


# Generated at 2022-06-20 12:52:43.228714
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context._init_global_context(load_plugins=False)
    cli = AdHocCLI(args=['ansible', 'all', '-m', 'debug', '-a', 'msg=Hello'])
    result = cli.run()
    assert result == 0

# Generated at 2022-06-20 12:52:53.971289
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    test_AdHocCLI = AdHocCLI()
    test_AdHocCLI.init_parser()

    #positional arguments
    result = test_AdHocCLI.parse(['example.org', '-a', 'file=/etc/ntp.conf state=present'])
    assert result.args == 'example.org'
    assert result.module_args == 'file=/etc/ntp.conf state=present'
    assert result.module_name == 'command'

    #invalid positional argument
    try:
        result = test_AdHocCLI.parse([])
        assert False
    except SystemExit:
        assert True

    #invalid option

# Generated at 2022-06-20 12:52:55.027259
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:53:16.350298
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse
    mock_args = argparse.Namespace(
        module_name='test_module',
        module_args='test_argument',
        args='test_pattern',
        tree='test_tree',
        forks=1,
        poll_interval=2,
        seconds=3,
        listhosts=False,
        subset=False,
        one_line=False,
        verbosity=0,
        check=False)

    #mock all calls to other classes,  AnsibleOptionsError is raised in method post_process_args of class AdHocCLI
    #when module_name=test_module and module_args=''
    mock_args.module_name='test_module'
    mock_args.module_args=''

# Generated at 2022-06-20 12:53:18.347955
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # test constructor of AdHocCLI
    a = AdHocCLI()
    assert type(a) == AdHocCLI

# Generated at 2022-06-20 12:53:26.436758
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    AdHocCLI - post_process_args
    '''

    class Args:
        is_playbook = False
        inventory = None
        subset = None
        limit = None
        verbosity = False
        ask_vault_pass = False
        ask_pass = False
        connection = None
        module_path = None
        forks = None
        become = False
        become_method = None
        become_user = None
        check = False
        diff = False
        syntax = False
        start_at_task = None
        step = False
        listhosts = None
        listtasks = None
        listtags = None
        extra_vars = []
        extra_vars_file = None
        vault_id = None
        vault_password_file = None
        tags = None
        skip

# Generated at 2022-06-20 12:53:31.235579
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert cli.args == []
    assert cli.parser == None
    assert cli.options == None
    assert cli.passwords == {}


# Generated at 2022-06-20 12:53:41.322259
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # setup mock
    class MockCLI(object):
        def __init__(self):
            self.verbosity = 1
            self.display = Display()

    args = ['-c', 'local', '-m', 'setup', 'localhost', '-a', 'filter=ansible_distribution_version']
    cli_args = {}

    # test with a valid command
    adhoc_cli = AdHocCLI(MockCLI())
    adhoc_cli.post_process_args(args, cli_args)

    assert 'module_name' in cli_args
    assert cli_args['module_name'] == 'setup'
    assert 'module_args' in cli_args
    assert cli_args['module_args'] == 'filter=ansible_distribution_version'

# Generated at 2022-06-20 12:53:47.449640
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_args = [
        '--list-hosts',
        '--list-tasks',
        '--list-tags',
        '--syntax-check',
        '--connection', 'local',
        '--module-name', 'ping',
        '--module-path', '/path/to/mymodules',
        '--forks', '10',
        '--sudo',
        '--sudo-user', 'bob',
        '--ask-sudo-pass',
        '--ask-pass',
        '--verbose',
        'all'
    ]
    with AdHocCLI(args=test_args) as cli_adhoc:
        pass

# Generated at 2022-06-20 12:53:50.844418
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-i', 'localhost,', 'localhost', '-c', 'local', '-m', 'setup'])
    adhoc.init_parser()

# Generated at 2022-06-20 12:53:52.668814
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc = AdHocCLI()
    ad_hoc.init_parser()

# Generated at 2022-06-20 12:53:54.821548
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 12:53:56.764638
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # This is a fake test for method run of class AdHocCLI
    # TODO: real unit test
    assert True

# Generated at 2022-06-20 12:54:17.013361
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import shutil
    import pytest
    import tempfile


# Generated at 2022-06-20 12:54:24.534313
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Setup
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli._parser.usage == '%prog <host-pattern> [options]'
    assert adhoc_cli._parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc_cli._parser.epilog == 'Some actions do not make sense in Ad-Hoc (include, meta, etc)'
    adhoc_cli._parser.print_help()



# Generated at 2022-06-20 12:54:25.338658
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:54:34.628635
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    def test_check_passwords():
        return ('pass', 'pass')

    def test_get_host_list(source, subset_as_list, pattern):
        return ['host1', 'host2', 'host3']

    def test_play_ds(pattern, async_val, poll):
        return dict(
            name="Ansible Ad-Hoc",
            hosts=pattern,
            gather_facts='no',
            tasks=[dict(
                action=dict(module='ping'),
                timeout=None)])

    def test_post_process_args(options):
        return options

    def test_validate_conflicts(options, runas_opts, fork_opts):
        return None

    def test_run_playbook(playbook, inventory, variable_manager, loader, options, passwords):
        return None

# Generated at 2022-06-20 12:54:37.119274
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Check if an instance of class AdHocCLI is created without error
    AdHocCLI()

# Generated at 2022-06-20 12:54:38.023452
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()

# Generated at 2022-06-20 12:54:45.550510
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()

    assert(adhoc_cli._parser.prog == 'ansible')
    assert(adhoc_cli._parser.usage == '%prog <host-pattern> [options]')
    assert(adhoc_cli._parser.description == "Define and run a single task 'playbook' against a set of hosts")
    epilog = '''Some actions do not make sense in Ad-Hoc (include, meta, etc)'''
    assert(adhoc_cli._parser.epilog == epilog)

# Generated at 2022-06-20 12:54:46.989999
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.init_parser() is not None


# Generated at 2022-06-20 12:54:55.059793
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''AdHocCLI class used as an example to support unit test'''
    adhoc_cli = AdHocCLI(args=[])
    adhoc_cli.init_parser()
    AdHocCLI_args = ['--interpreter', 'echo', '--help']
    adhoc_cli.parse()
    #AdHocCLI.parse(adhoc_cli, args=AdHocCLI_args)


# Generated at 2022-06-20 12:55:05.578674
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ''' Ensure expected behavior of post_process_args method of class AdHocCLI '''

    # Test 1. Ensure module_name is defaulted to command
    args = ['-m', 'ping', 'localhost']
    with pytest.raises(AnsibleError):
        adhoc = AdHocCLI(args)
    options = adhoc.parse()
    assert options.module_name == 'ping'
    assert options.module_args == C.DEFAULT_MODULE_ARGS

    # Test 2. Ensure module_name is NOT defaulted to command
    args = ['ping', 'localhost']
    adhoc = AdHocCLI(args)
    options = adhoc.parse()
    assert options.module_name == C.DEFAULT_MODULE_NAME

# Generated at 2022-06-20 12:55:31.149148
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options, args = adhoc_cli.parser.parse_args(['-a', "module_args", 'test1', 'test2'])
    adhoc_cli.post_process_args(options)
    assert context.CLIARGS['module_args'] == "module_args"

# Generated at 2022-06-20 12:55:39.730775
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI(['-a', 'opt1=val1', '-m', 'command', '-k', '-s', '-B', '3600', '-P', '30', '-u', 'usr', '-kK', '-c', 'local', '-v', '2', '-vvvvvvvvvvvvv', '*'])
    ad_hoc.parse()
    ad_hoc.post_process_args(ad_hoc.options)
    ad_hoc.run()

# Generated at 2022-06-20 12:55:50.656035
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    print('hello world')


if __name__ == "__main__":
    import sys
    import os
    import inspect

    print('Testing ' + inspect.getfile(inspect.currentframe()))

    import argparse

    base = os.path.dirname(os.path.dirname(inspect.getfile(inspect.currentframe())))
    sys.path.append(base + '/lib/')

    from ansible.errors import AnsibleError, AnsibleOptionsError

    from ansible.module_utils._text import to_bytes

    parser = argparse.ArgumentParser()
    parser.add_argument('host_pattern', nargs='?', default='all', type=str,
                        help='host pattern, see ansible-playbooks host pattern for details',
                        )

# Generated at 2022-06-20 12:55:54.115461
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' ad_hoc_cli = AdHocCLI(args)  '''
    ad_hoc_cli = AdHocCLI(['localhost', '-m', 'ping'])
    assert ad_hoc_cli  # TODO: write tests

# Generated at 2022-06-20 12:55:55.929071
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI(['ansible-'])

# Generated at 2022-06-20 12:56:06.699976
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    def set_options(**kwargs):
        for key, value in kwargs.items():
            if value is not None:
                setattr(ad_cli.options, key, value)
        return ad_cli.post_process_args(ad_cli.options)

    def assert_exception(args, message):
        with pytest.raises(AnsibleOptionsError) as ex:
            ad_cli.parse(args)
            options = ad_cli.post_process_args(ad_cli.options)
        assert message in str(ex.value)

    ad_cli = AdHocCLI([])
    ad_cli.parse()
    ad_cli.post_process_args(ad_cli.options)

    # Check conficts: -K and --ask-sudo-pass

# Generated at 2022-06-20 12:56:17.823156
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import sys

    def mock_args(**kwargs):
        class Mock(object):
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)
        return Mock(**kwargs)


# Generated at 2022-06-20 12:56:25.398572
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Does not raise an exception
    AdHocCLI().post_process_args(CLI.base_parser.parse_args(['-m', 'ping', 'all'], namespace=context.CLIARGS))

    # Raises an exception
    try:
        AdHocCLI().post_process_args(CLI.base_parser.parse_args(['-m', 'ping',
                                                                 '-u', 'user',
                                                                 '-k',
                                                                 'all'], namespace=context.CLIARGS))
    except AnsibleOptionsError:
        pass
    else:
        assert False

    # Raises an exception

# Generated at 2022-06-20 12:56:35.045526
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    class MockAdHocCLI(object):
        pass

    from ansible.cli import CLI

    cli = MockAdHocCLI()
    cli.parser = CLI.base_parser(
        usage='%prog <host-pattern> [options]',
        epilog="some more text for the epilog"
    )

    cli.options, cli.args = cli.parser.parse_known_args()

    cli.validate_conflicts = CLI.validate_conflicts
    cli.get_host_list = CLI.get_host_list
    cli.ask_passwords = CLI.ask_passwords

    cli.post_process_args(cli.options)

# Generated at 2022-06-20 12:56:39.782313
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ test_AdHocCLI_run """
    # pylint: disable=no-self-use
    ''' AdHocCLI._run()'''
    ad_cli = AdHocCLI()
    ad_cli.run()

# Generated at 2022-06-20 12:57:30.057856
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    host_list = {
        'all': {
            'hosts': ['test_host1'],
            'vars': {'ansible_user': 'test_user', 'ansible_ssh_pass': 'test_password'}
        }
    }
    # Create a instance of class AdHocCLI with given host list
    ad_hoc_cli = AdHocCLI(host_list)
    pattern = 'test_host1'
    async_val = 0
    poll = 0
    play_ds = ad_hoc_cli._play_ds(pattern, async_val, poll)

# Generated at 2022-06-20 12:57:33.356508
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    test_object = AdHocCLI()
    assert test_object.parser.description.startswith('Ad-hoc')
    assert test_object.parser.epilog.startswith('Some actions')


# Generated at 2022-06-20 12:57:35.657613
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test for method run of class AdHocCLI
    """
    # FIXME: need to fix mocking for class AdHocCLI for this test
    # assert True == True

# Generated at 2022-06-20 12:57:47.010078
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    print('\nTest constructor class AdHocCLI')
    # Create an object class AdHocCLI
    ad_hoc_object = AdHocCLI()

    # Print class and module of the object
    print('\tType:', type(ad_hoc_object))
    print('\tModule:', AdHocCLI.__module__)
    print('\tId:', id(ad_hoc_object))

    # Unit test for method init_parser()
    ad_hoc_object.init_parser()

    # Unit test for method post_process_args()
    post_process_args_object = ad_hoc_object.post_process_args(None)
    print('\tId:', id(post_process_args_object))

    # Unit test for method run()
    run

# Generated at 2022-06-20 12:57:53.180002
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''Unit test for method init_parser of class AdHocCLI'''

    # Note: if this test fails, try to run it under the
    #       valgrind with the following command:
    #       valgrind python -m pytest tests/unit/cli/adhoc_test.py::test_AdHocCLI_init_parser

    # access to protected class attribute
    # pylint: disable=W0212

    # use a private temporary directory
    with tempfile.TemporaryDirectory(prefix='ansible_test_unit_adhoc_init_parser_') as td:

        # create a configuration file
        config_file = os.path.join(td, 'ansible.cfg')

# Generated at 2022-06-20 12:58:01.883678
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI(args=[])
    parser = adhoc.init_parser()
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    expected_usage = "Usage: %prog <host-pattern> [options]"
    assert parser.usage == expected_usage
    found = False
    for opt in parser.option_list:
        if opt.get_opt_string() == "--module-name":
            if opt.help == "Name of the action to execute (default=ping)":
                found = True
    assert found
    found = False

# Generated at 2022-06-20 12:58:13.901615
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Skip this test if the ansible-playbook command is not available:
    try:
        cli = AdHocCLI(args=['--version'])
    except AnsibleOptionsError as e:
        if 'invalid choice' in to_text(e):
            msg = "Skipping test because the ansible-playbook command is not available"
            pytest.skip(msg)
        raise

    # Create an options dict with a single element. The parsed ansible-playbook
    # command line arguments are post-processed in a specific way. This test
    # just verifies that the expected output is generated.
    #
    # For this test the `ansible-playbook` command is used because it is a
    # publically available and well-tested command. The `ansible-playbook`
    # command calls the private `

# Generated at 2022-06-20 12:58:23.801069
# Unit test for constructor of class AdHocCLI

# Generated at 2022-06-20 12:58:28.361293
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli.options, dict)
    assert isinstance(adhoc_cli.args, list)
    assert adhoc_cli.parser

# Generated at 2022-06-20 12:58:34.599789
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-m', 'debug', '--one-line', '-b', 'become_user=root', '-a', 'msg=Hello World', 'localhost']
    cli = AdHocCLI(args)

    cli.parse()
    options = cli.post_process_args(context.CLIARGS)

    assert options['module_name'] == 'debug'
    assert options['module_args'] == 'msg=Hello World'
    assert options['one_line']
    assert options['become']
    assert options['become_user'] == 'root'

# Generated at 2022-06-20 13:00:04.063454
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    AdHocCLI()


if __name__ == '__main__':
    cli = AdHocCLI()
    cli.parse()
    cli.run()

# Generated at 2022-06-20 13:00:07.417405
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()

    # Create the command line arguments
    context.CLIARGS = {'module_name': 'echo',
                       'module_args': ''}

    # The 'run' method must not raise an exception
    try:
        adhoc_cli.run()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-20 13:00:12.883089
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import tempfile
    import yaml

    def mock_playbook_option(self, k, v):
        self._playbook_options[k] = v


# Generated at 2022-06-20 13:00:14.437906
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=[])
    assert adhoc_cli is not None

# Generated at 2022-06-20 13:00:26.092811
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Ansible AdHocCLI class run unit test
    """
    import sys
    cli_args = [
        'ANSIBLE_MODULE_ARGS={}'.format(sys.argv[1]),
        'ANSIBLE_MODULE_NAME={}'.format(sys.argv[2]),
        'ANSIBLE_HOST_PATTERN={}'.format(sys.argv[3])
    ]
    cli_args.extend(sys.argv[4:])
    mycli = AdHocCLI(args=cli_args)
    mycli.parse()
    mycli.post_process_args(vars(mycli.options))
    return mycli.run()


if __name__ == '__main__':

    def main():
        from ansible.utils.display import Display

# Generated at 2022-06-20 13:00:32.463619
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test 1: check conflicts
    args_dict = dict(
        vault_password_file='/path/to/vault_password_file',
        ask_vault_pass=True
    )

    try:
        cli = AdHocCLI(args=args_dict)
    except AnsibleOptionsError as e:
        assert "The vault-password-file / path-to-vault-password-file option is mutually exclusive with the ask-vault-pass / ask-vault-password option" == str(e)

# Generated at 2022-06-20 13:00:41.799692
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible_mikrotik import MikroTikCLI
    from ansible_collections.ansible.netcommon.plugins.action.ping import ActionModule
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_to_set
    import ansible.constants as C
    
    # not sure if there is a better way to test
    # because argparse.parse_args doesn't support default values
    # so I can't do this in __init__
    options = MikroTikCLI.init_parser(MikroTikCLI())
    # options.reset_source_vars = False
    options.module_name = 'ping'
    options.module_args = 'dest="192.168.33.254"'
    options.ask_pass = False

# Generated at 2022-06-20 13:00:46.029413
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    import sys
    import os

    class MockCLI():
        pass
    mock_cli = MockCLI()
    mock_cli.args = ['Pattern']
    AdHocCLI._run(mock_cli)


# Generated at 2022-06-20 13:00:48.626226
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHoc = AdHocCLI()
    assert adHoc

# Run 'python -m unittest test_adhoc' to execute the tests
if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-20 13:00:55.548982
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI

    args_adhoc_basic = ['-vvvv', '-m', 'shell', '-a', 'ls', '-i', '/tmp/hosts', 'local']
    adhoc_cli = AdHocCLI(args=args_adhoc_basic)
    adhoc_cli.parse()

    for option, value in adhoc_cli.post_process_args(adhoc_cli.options).items():
        assert option in adhoc_cli.parser._actions[0].option_strings
        assert value == getattr(adhoc_cli.parser._actions[0], option)

