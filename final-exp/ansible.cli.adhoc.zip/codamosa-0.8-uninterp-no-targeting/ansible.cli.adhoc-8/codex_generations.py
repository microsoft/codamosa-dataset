

# Generated at 2022-06-20 12:52:10.287206
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.utils.color import ANSIBLE_COLOR, stringc
    from ansible.utils.display import Display
    from ansible.cli.arguments.options.connection import ConnectionCLI
    from ansible.utils.connection import Connection

    if not ANSIBLE_COLOR:
        # remove color method from display if we don't have color support
        setattr(Display, 'colorize', stringc)
        setattr(Display, 'colorize', stringc)
        setattr(Display, 'banner', lambda self, msg, color=None: msg)
        setattr(Display, 'warning', lambda self, msg, color=None: msg)
        setattr(Display, 'vvvv', lambda self, msg, host=None: msg)

    # initialize parser with some command line argument

# Generated at 2022-06-20 12:52:11.838564
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

# Generated at 2022-06-20 12:52:20.118158
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''Unit test to test constructor of class AdHocCLI'''
    # Construct instance of AdHocCLI
    ad_hoc = AdHocCLI()

    # Check values of few class instance attributes
    assert('usage: %prog <host-pattern> [options]' == ad_hoc.usage)
    assert('Define and run a single task \'playbook\' against a set of hosts' == ad_hoc.desc)
    assert('Some actions do not make sense in Ad-Hoc (include, meta, etc)' == ad_hoc.epilog)

# Generated at 2022-06-20 12:52:28.907899
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class mock_args:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    args = mock_args(vault_password=True, verbosity=3, check=False, force_handlers=False)
    a = AdHocCLI()
    a.post_process_args(args)
    assert args.vault_password_file == C.DEFAULT_VAULT_PASSWORD_FILE

# Generated at 2022-06-20 12:52:40.259202
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.executor import task_queue_manager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    pb = Playbook()
    play = Play()
    play_ds = dict(
        name="Ansible Ad-Hoc",
        hosts=['localhost'],
        gather_facts='no',
        tasks=[{'action': {'module': 'command', 'args': 'echo hello'},
                'timeout': 3}])
    play.load(play_ds, variable_manager=VariableManager(), loader=pb._loader)
    pb._entries.append(play)
    pb._file_name = '__adhoc_playbook__'

    inventory = task_queue_manager.get_default_inventory()
    variable_manager = VariableManager()


# Generated at 2022-06-20 12:52:44.920909
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    argv = 'pattern [options]'.split()
    cli = AdHocCLI(argv, strict=False)
    cli.init_parser()



# Generated at 2022-06-20 12:52:45.968606
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    a = AdHocCLI()
    assert a

# Generated at 2022-06-20 12:52:46.997199
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    obj = AdHocCLI()


# Generated at 2022-06-20 12:52:55.071265
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # basic test
    my_cli = AdHocCLI(['-a', 'host=host01', '-a', 'host=host02', 'host_pattern'])
    my_cli.init_parser()
    context.CLIARGS = my_cli.parse()

    assert context.CLIARGS['module_args'] == 'host=host01 host=host02'
    assert context.CLIARGS['args'] == 'host_pattern'

    # test with '=value'
    my_cli = AdHocCLI(['-a', 'host=host01', 'integration_test'])
    my_cli.init_parser()
    context.CLIARGS = my_cli.parse()

    assert context.CLIARGS['module_args'] == 'host=host01'

# Generated at 2022-06-20 12:52:57.506190
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    assert cli.post_process_args({}) is None

# Generated at 2022-06-20 12:53:16.523483
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    class TestAdHocCLI(AdHocCLI):
        def post_process_args(self, options):
            return options

        def run(self):
            return 0

    test_AdHocCLI = TestAdHocCLI(['-vvv', '-m', 'shell', '-a', 'echo hello world'])
    assert test_AdHocCLI._play_ds('localhost', None, None)['tasks'][0]['action']['module'] == 'shell', 'test_AdHocCLI returns wrong module name'  # noqa
    assert test_AdHocCLI._play_ds('localhost', None, None)['tasks'][0]['action']['args'] == {'echo': 'hello world'}, 'test_AdHocCLI returns wrong module args'  # no

# Generated at 2022-06-20 12:53:22.086663
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    parser = cli.parser
    assert parser.format_usage() == '%prog <host-pattern> [options]'
    assert parser.description.startswith("Define and run a single task 'playbook' against a set of hosts")
    assert parser.epilog.startswith("Some actions do not make sense in Ad-Hoc (include, meta, etc)")


# Generated at 2022-06-20 12:53:26.787459
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    test_parser = AdHocCLI(['ansible-playbook', '-i', 'hosts', '-u', 'root', '--ask-sudo-pass', '-forks', '5'])
    assert test_parser.parser.prog == 'ansible-playbook'
    assert test_parser.parser.description is not None

# Generated at 2022-06-20 12:53:30.565401
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    argv = []
    adhoc = AdHocCLI(argv)
    parser = adhoc.init_parser()

    assert parser == adhoc.parser

# Generated at 2022-06-20 12:53:30.951306
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:53:32.790698
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()


# Generated at 2022-06-20 12:53:42.464782
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test with no arguments
    cli_args = []
    cli = AdHocCLI(args=cli_args)
    cli.parse()
    options = cli.post_process_args(cli.options)
    assert options.inventory == C.DEFAULT_HOST_LIST

    # Test with subset
    args = ['-i', '/etc/ansible/hosts', '-l', 'host_subset']
    cli = AdHocCLI(args=args)
    cli.parse()
    options = cli.post_process_args(cli.options)
    assert options.subset == 'host_subset'
    assert options.inventory == '/etc/ansible/hosts'

    # Test with subset and explicit inventory

# Generated at 2022-06-20 12:53:55.231007
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Unit test for AdHocCLI constructor
    """
    test_obj = AdHocCLI()
    argv = ["-v", "-m", "test_module", "host_pattern", "-a", "opt1=val1 opt2=val2"]
    # when
    with open("/dev/null", "w") as null_fh:
        with context.capture_stdout_stderr(null_fh):
            test_obj.parse(argv)
    # then
    assert context.CLIARGS['verbosity'] == 2
    assert context.CLIARGS['module_name'] == "test_module"
    assert context.CLIARGS['module_args'] == "opt1=val1 opt2=val2"
    assert context.CLIARGS['one_line']

# Generated at 2022-06-20 12:54:03.873077
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_cli = AdHocCLI([])
    test_args = ['-m', 'copy', '-a', 'src=file.in dest=file.out', 'localhost', '-k', '-K', '-f', '10', '-v']
    ad_hoc_cli.parse(args=test_args)
    assert context.CLIARGS['module_name'] == 'copy'
    assert context.CLIARGS['module_args'] == 'src=file.in dest=file.out'
    assert context.CLIARGS['args'] == 'localhost'
    assert context.CLIARGS['ask_pass']
    assert context.CLIARGS['ask_become_pass']
    assert context.CLIARGS['forks'] == 10
    assert context.CLIARGS

# Generated at 2022-06-20 12:54:07.550421
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_cli = AdHocCLI([])
    parser = ad_hoc_cli.init_parser()
    options, args = parser.parse_args([])
    assert parser.usage == '%prog <host-pattern> [options]'


# Generated at 2022-06-20 12:54:15.407760
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()


# Generated at 2022-06-20 12:54:26.046421
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ad_hoc_cli = AdHocCLI()

# Generated at 2022-06-20 12:54:26.602458
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI().run()

# Generated at 2022-06-20 12:54:28.641699
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_obj = AdHocCLI(None)
    assert adhoc_obj.run is not None

# Generated at 2022-06-20 12:54:32.299713
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible.cli.adhoc import AdHocCLI
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli._parser
    assert parser.prog == 'ansible-adhoc'
    parser.print_help()

# Generated at 2022-06-20 12:54:36.803380
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser.prog == 'ansible'


# Generated at 2022-06-20 12:54:41.346944
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options = adhoc_cli.parser.parse_args(['server1', '-m', 'shell', '-a', 'echo "This is a test."'])

    # options post_process method is able to modify the args
    assert options.verbosity == 3

    if C.DEFAULT_MODULE_NAME == 'shell':
        assert options.module_name == 'shell'
    else:
        assert options.module_name == C.DEFAULT_MODULE_NAME

    assert options.module_args == 'echo "This is a test."'

    assert options.subset == ':all'

# Generated at 2022-06-20 12:54:43.448044
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit tests are not normally used, but are useful to ensure coverage '''
    cli = AdHocCLI()
    assert cli.parser is not None
    options, args = cli.parser.parse_args([])
    assert options.listhosts == False

# Generated at 2022-06-20 12:54:45.384176
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()
    assert isinstance(ad_hoc_cli, CLI)

# Generated at 2022-06-20 12:54:51.687742
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    cli.init_parser()

    assert cli.parser.prog == 'ansible'
    assert cli.parser.usage == '%prog <host-pattern> [options]'
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"

    # test that all the options are present

# Generated at 2022-06-20 12:55:07.765225
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    a = AdHocCLI(None)
    a.init_parser()


# Generated at 2022-06-20 12:55:18.842114
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import os
    import tempfile
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.display import Display
    from ansible.cli.arguments import option_helpers as opt_help

    # callbacks make these tests noisy, so turn them down
    display = Display(verbosity=5)

    # test that a valid host pattern works
    cli = AdHocCLI(['localhost'])
    assert cli.run() == 0

    # test that an invalid host pattern fails
    cli = AdHocCLI([''])
    try:
        cli.run()
    except AnsibleOptionsError:
        pass

    # test that an unset module_name works

# Generated at 2022-06-20 12:55:20.529575
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc._tqm is None

# Generated at 2022-06-20 12:55:26.791802
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Unit test for method run of class AdHocCLI '''

    # Create an instance of AdHocCLI
    adhoc = AdHocCLI()

    # Create an instance of parser
    adhoc.parser = adhoc.create_parser()

    # Parse the arguments
    adhoc.parse()

    # Process the arguments
    adhoc.args = adhoc.post_process_args()

    # Initialize the options
    adhoc.init_options()

    # Run the AdHocCLI
    adhoc.run()

# Generated at 2022-06-20 12:55:33.299174
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI

    argv = ['-i', 'localhost,']

    context.CLIARGS = AdHocCLI(args=argv).parse()
    context.CLIARGS['verbosity'] = 0

    result = AdHocCLI(args=argv).run()

    assert result != 0

# Generated at 2022-06-20 12:55:35.304611
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Constructor of class AdHocCLI is tested by its inherited class CLI
    pass

# Generated at 2022-06-20 12:55:37.553543
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    command = AdHocCLI(args=[])
    assert isinstance(command, AdHocCLI)


# Generated at 2022-06-20 12:55:44.590541
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {'module_name': 'testmodule',
                       'module_args': 'opt1=val1 opt2=val2',
                       'args': 'all'}
    adhoccli = AdHocCLI()
    # make sure user is set for forked process
    adhoccli._play_prereqs()
    adhoccli.run()
    assert not adhoccli._tqm.result_q.empty()



# Generated at 2022-06-20 12:55:45.699015
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI()

# Generated at 2022-06-20 12:55:46.697097
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

# Generated at 2022-06-20 12:56:21.882743
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class UnitTestAdHocCLI(AdHocCLI):
        def run(self):
            pass

    cli = UnitTestAdHocCLI()
    cli.parse(['-i', '/some/inventory', 'all', '-m', 'ping'])

    options = cli.post_process_args(cli.options)

    assert options.inventory == '/some/inventory'
    assert options.module_name == 'ping'
    assert options.pattern == 'all'

# Generated at 2022-06-20 12:56:33.365596
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    from collections import namedtuple
    from optparse import OptionParser

    # Fake object

# Generated at 2022-06-20 12:56:34.871703
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()

# Generated at 2022-06-20 12:56:45.338160
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    from ansible.cli.adhoc import AdHocCLI
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)
    assert adhoc._usage.startswith("%prog <host-pattern>")
    assert adhoc._description.startswith("Define and run a single task")
    assert adhoc._epilog.startswith("Some actions")
    assert len(adhoc._parser._actions) == 9
    assert adhoc._options.listhosts == False
    assert adhoc._options.listtasks == False
    assert adhoc._options.listtags == False
    assert adhoc._options.syntax == False


# Generated at 2022-06-20 12:56:53.995830
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.errors import AnsibleOptionsError
    import sys

    test_args = dict(
        verbose=True,
        inventory=['foo'],
        subset='all',
        fork=2,
        timeout=30,
        remote_user='user',
        connection='local',
        module_name='setup',
        module_args='',
        check=False,
        diff=False,
        extra_vars=['extra_var'],
        private_key_file=['/tmp/id_rsa'],
        args='foo'
    )

    test_cmd = CLI(args=sys.argv[0:1])

    orig_method = opt_help.process_connection_options

# Generated at 2022-06-20 12:56:55.310926
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-20 12:56:57.929171
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ basic test of constructor for this class """
    parser = opt_help.create_parser()
    cli = AdHocCLI(parser)
    assert cli is not None

# Generated at 2022-06-20 12:57:08.970425
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    my_AdHocCLI = AdHocCLI()
    my_AdHocCLI.options = opt_help.parse_options(args=[])
    my_AdHocCLI.options.module_name = 'ping'
    my_AdHocCLI.options.module_args = ''
    my_AdHocCLI.options.pattern = 'all'
    my_AdHocCLI.options.diff = False
    my_AdHocCLI.options.listtags = False
    my_AdHocCLI.options.listtasks = False
    my_AdHocCLI.options.syntax = False
    my_AdHocCLI.options.verbosity = 0
    my_AdHocCLI.options.ask_pass = False
    my_AdHocCLI.options

# Generated at 2022-06-20 12:57:16.484541
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    parametrized test for method post_process_args of class AdHocCLI
    """

# Generated at 2022-06-20 12:57:18.704334
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI(None, None)
    adhoc_cli.init_parser()
    assert adhoc_cli.parser is not None

# Generated at 2022-06-20 12:58:22.656615
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.usage == "%prog <host-pattern> [options]"

# Generated at 2022-06-20 12:58:24.370441
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()


# Generated at 2022-06-20 12:58:34.807590
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    class TestAdHocCLI(AdHocCLI):
        def __init__(self):
            self.options = self.get_optparser()

        def get_optparser(self):
            super(TestAdHocCLI, self).get_optparser()
            # Avoid the set of basic code,
            # because it will exit with a non-zero code
            self.parser.description = ""
            # Mock list tasks options
            self.parser.add_argument('-l', '--list-tasks',
                                     dest='listtasks',
                                     action='store_true',
                                     default=False)
            # Mock list hosts options


# Generated at 2022-06-20 12:58:38.242827
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' unit test for init_parser method - AdHocCLI class '''

    cliclass = AdHocCLI([])
    cliclass.init_parser()
    assert cliclass.parser

# Generated at 2022-06-20 12:58:45.135252
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''Test for post_process_args method'''

    # Mock Display
    Display().verbosity = 2

    # Create AdHocCLI instance and call post_process_args
    test_adhoc_cli = AdHocCLI()
    result = test_adhoc_cli.post_process_args(dict())

    # Check value of inventory
    assert(context.CLIARGS['inventory'] == 'hosts')

    # Check value of verbosity
    assert(display.verbosity == 2)

# Generated at 2022-06-20 12:58:55.514253
# Unit test for method init_parser of class AdHocCLI

# Generated at 2022-06-20 12:58:58.253269
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test-1
    # Object creation
    adhoc_obj = AdHocCLI()
    adhoc_obj.run()

# Generated at 2022-06-20 12:59:08.333889
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create an instance of AdHocCLI
    myadhoc = AdHocCLI()
    # Create a dict that represents the options argument of post_process_args
    myoption = {}

    # Supply defaults for the missing keys of options
    myoption['verbosity'] = 1
    myoption['inventory'] = '/etc/ansible/hosts'

    # The option 'module_name' is required for running
    # the method post_process_args
    myoption['module_name'] = 'setup'

    # test if the method returns options after
    # post-processing
    result = myadhoc.post_process_args(myoption)
    print(result)
    assert result == myoption

if __name__ == '__main__':
    test_AdHocCLI_post_process_args()

# Generated at 2022-06-20 12:59:16.300571
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    parser = cli.init_parser()
    options = parser.parse_args()

    # create a dictionary with all the default options
    new_options = {}
    for key, val in vars(options).copy().items():
        if isinstance(val, list):
            new_options[key] = val.pop()
        else:
            new_options[key] = val

    # update the default options with any options set by the user

# Generated at 2022-06-20 12:59:23.660900
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    loader = None
    inventory = None
    variable_manager = None
    passwords = {'conn_pass': None,
                 'become_pass': None}
    pattern = ""
    adhoc = AdHocCLI(loader=loader,
                     inventory=inventory,
                     variable_manager=variable_manager,
                     passwords=passwords,
                     context=None,
                     stdout_callback='default')
    adhoc.run()