

# Generated at 2022-06-20 12:51:46.033306
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Unit test for the class AdHocCLI
    """
    ad_hoc_instance = AdHocCLI()
    options = ad_hoc_instance.init_parser()
    ad_hoc_instance.run()

# Generated at 2022-06-20 12:51:54.080184
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:52:05.019913
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    id_1 = {'verbosity': 1, 'module_name': 'ping', 'module_args': '', 'args': 'all'}
    id_2 = {'verbosity': 0, 'module_name': 'ping', 'module_args': '', 'args': 'all'}

    args = AdHocCLI(args=['all'])
    assert args.post_process_args(id_1) == {'verbosity': 1, 'module_name': 'ping', 'module_args': '', 'args': 'all'}
    assert args.post_process_args(id_2) == {'verbosity': 0, 'module_name': 'ping', 'module_args': '', 'args': 'all'}

# Generated at 2022-06-20 12:52:12.532151
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    inventory = cli.cli_common_args['inventory']
    pattern = 'all'
    async_val = 5
    poll = 10
    loader = cli._play_prereqs()[0]
    play_ds = cli._play_ds(pattern, async_val, poll)
    play = Play().load(play_ds, variable_manager=None, loader=loader)
    playbook = Playbook(loader)
    playbook._entries.append(play)
    playbook._file_name = '__adhoc_playbook__'
    assert cli._tqm == None
    cli.run()
    assert cli._tqm != None
    cli._tqm.cleanup()
    loader.cleanup_all_tmp_files()
    assert cli

# Generated at 2022-06-20 12:52:13.101317
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-20 12:52:18.140461
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    test_obj = AdHocCLI(None)
    test_obj.init_parser()
    try:
        assert isinstance(test_obj.parser, argparse.ArgumentParser)
        print("ad hoc init_parser success")
    except:
        print("ad hoc init_parser failed")


# Generated at 2022-06-20 12:52:21.043484
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert 'usage' in adhoc_cli.parser._actions[0].option_strings

# Generated at 2022-06-20 12:52:30.805664
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    import mock

    mock_args = 'foo'
    mock_class_init = mock.MagicMock(return_value=None)
    mock_parser = mock.MagicMock(return_value=None)
    with mock.patch.object(AdHocCLI, '__init__', mock_class_init):
        with mock.patch('ansible.cli.CLI.init_parser', mock_parser):
            cli = AdHocCLI(mock_args)
            assert not cli.parser
            cli.init_parser()
            assert cli.parser



# Generated at 2022-06-20 12:52:38.288760
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc = AdHocCLI()
    parser = ad_hoc.init_parser()
    # test parser
    assert parser.prog == 'ansible'
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    # test args
    assert parser.usage == '%(prog)s <host-pattern> [options]'


# Generated at 2022-06-20 12:52:40.501323
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=['--version'])
    cli.parse()

# Generated at 2022-06-20 12:52:59.139763
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.init_parser()


# Generated at 2022-06-20 12:53:08.882466
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    cli = AdHocCLI([])


# Generated at 2022-06-20 12:53:15.312923
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
  module_name = 'ping'
  module_args = 'data=hello world'
  pattern = 'all'

  # Call the constructor of AnsibleCLI
  adhoc = AdHocCLI([pattern])

  # Execute the method post_process_args()
  adhoc.post_process_args({
    'module_name': module_name,
    'module_args': module_args,
    'one_line': True,
  })

# Generated at 2022-06-20 12:53:24.368550
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:53:25.721222
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli is not None

# Generated at 2022-06-20 12:53:28.878341
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    cli = AdHocCLI()
    parser = cli.init_parser()

    assert parser is not None


# Generated at 2022-06-20 12:53:37.198099
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['-m', 'setup', '-a'],)  # cli.args = ['setup']
    cli.parse()

    assert (cli.options.module_name == 'setup')
    assert (cli.options.module_args == '')
    assert (cli.options.fork == 1)
    assert (cli.options.seconds == 5)
    assert (cli.options.poll_interval == 15)
    assert (cli.options.listhosts == None)



# Generated at 2022-06-20 12:53:45.410390
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=[])
    options, args = cli.parser.parse_known_args()
    options = cli.post_process_args(options)
    assert options.verbosity == 0
    assert options.inventory is None
    assert options.ask_pass is False
    assert options.ask_become_pass is False
    assert options.ask_vault_pass is False
    assert options.private_key_file is None
    assert options.host_key_checking is True
    assert options.remote_user is None
    assert options.connection is None
    assert options.timeout is None
    assert options.ssh_common_args == ''
    assert options.sftp_extra_args == ''
    assert options.scp_extra_args == ''
    assert options.ssh_extra_args == ''

# Generated at 2022-06-20 12:53:58.013604
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    import os
    import sys
    import unittest

    PATTERN = 'testhost'
    ARGS = 'arg1=value1 arg2=value2'
    MODULE_NAME = 'file'
    CWD = os.getcwd()
    PLAYBOOK_TMP_DIR = '/tmp/ansible-test-adhoc-cli-1234567890'
    MODULE_UTILS_DIR = '%s/lib/ansible/module_utils' % CWD
    MODULES_DIR = '%s/lib/ansible/modules' % CWD
    EXECUTABLE = sys.executable


# Generated at 2022-06-20 12:53:59.648237
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    class_instance = AdHocCLI()
    parser = class_instance.init_parser()
    assert parser is not None

# Generated at 2022-06-20 12:54:21.907669
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    parser = cli.parser
    assert parser.usage == '%prog <host-pattern> [options]'
    assert parser.description.startswith('Define and run a single task \'playbook\'')
    assert parser.epilog.startswith('Some actions do not make sense in Ad-Hoc')
    assert parser._positionals.title == 'positional arguments'
    assert parser._optionals.title == 'optional arguments'


# Generated at 2022-06-20 12:54:32.766400
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Test AdHocCLI._post_process_args method"""
    from ansible import context
    from ansible.cli.arguments import option_helpers as opt_help

    # Create an AdHocCLI object
    adhoc = AdHocCLI()

    # Populate opt_help.ad_hoc_parser (see bin/ansible)
    opt_help.ad_hoc_parser()

    # Call AdHocCLI._post_process_args
    options = adhoc.post_process_args(context.CLIARGS)

    # Assert that async_val is not in options
    assert options is not None
    assert 'async_val' not in options

    # Assert that poll is not in options
    assert 'poll' not in options

    # Assert that poll is not in options

# Generated at 2022-06-20 12:54:38.564965
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Unit test needs to mock the following method
    #  _play_prereqs(), ask_passwords()
    # and get_host_list() provided by super class
    class AdHocCLIStub(AdHocCLI):
        def __init__(self):
            pass
        def _play_prereqs(self):
            return 'loader', 'inventory', 'variable_manager'
        def ask_passwords(self):
            return None, None
        def get_host_list(self, inventory, subset, pattern):
            return ['host1']

    # Run the method
    ad_hoc_cli_stub = AdHocCLIStub()

# Generated at 2022-06-20 12:54:39.825520
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run(None)

# Generated at 2022-06-20 12:54:42.697939
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    args = cli.parser.parse_args(['-a', 'ls /home/test', 'host1'])


# Generated at 2022-06-20 12:54:45.427216
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(None)
    parser = cli.init_parser()
    assert parser.description == cli.description
    assert parser.epilog == cli.epilog

# Generated at 2022-06-20 12:54:51.711733
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create method object to call
    test_AdHocCLI = AdHocCLI()
    # Create a dictionary with options to create a Options object

# Generated at 2022-06-20 12:54:52.268463
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement test case
    pass

# Generated at 2022-06-20 12:55:02.960625
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc_cli = AdHocCLI()
    test_host_list = ['localhost']
    test_pattern = 'all'
    test_seconds = 1
    test_poll_interval = 1
    test_module_name = 'shell'
    test_module_args = 'echo \'hello world\''
    context.CLIARGS = {'subset': False, 'listhosts': False, 'one_line': False, 'tree': False, 'seconds': test_seconds,
                       'poll_interval': test_poll_interval, 'module_name': test_module_name, 'module_args': test_module_args,
                       'args': test_pattern, 'verbosity': 3}
    ad_hoc_cli.run()

# Generated at 2022-06-20 12:55:07.646963
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()

    assert cli.parser.usage == '%prog <host-pattern> [options]'
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert 'Some actions do not make sense in Ad-Hoc (' in cli.parser.epilog

# Generated at 2022-06-20 12:55:41.614972
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI.init_parser()
    assert parser.__dict__

# Generated at 2022-06-20 12:55:51.029826
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI(['-m', 'ping', 'localhost']).init_parser()
    assert parser
    args = parser.parse_args(['-m', 'ping', 'localhost', '-v'])
    assert args.module_name == 'ping'
    args = parser.parse_args(['-m', 'ping', 'localhost'])
    assert not args.verbosity
    args = parser.parse_args(['-m', 'ping', 'localhost', '-a', 'ping'])
    assert args.module_args == 'ping'
    args = parser.parse_args(['-m', 'ping', 'localhost', '-a', "'ping'" ])
    assert args.module_args == "'ping'"

# Generated at 2022-06-20 12:55:55.229543
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' adhoc_cli = AdHocCLI()
    '''
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.module_name == C.DEFAULT_MODULE_NAME
    assert adhoc_cli.module_args == C.DEFAULT_MODULE_ARGS


# Generated at 2022-06-20 12:55:57.241315
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI().init_parser()


# Generated at 2022-06-20 12:56:07.939014
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import ansible.constants as C


# Generated at 2022-06-20 12:56:09.535295
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    adhoc = AdHocCLI(args=None)
    assert isinstance(adhoc, AdHocCLI)
    assert isinstance(adhoc, CLI)
    '''
    pass

# Generated at 2022-06-20 12:56:20.375216
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    Test AdHocCLI.post_process_args()
    """
    p = AdHocCLI()
    host = 'localhost'
    # no option
    context.CLIARGS = {}
    options = p.post_process_args(host)
    assert options is not None
    assert options == host

    # verbosity
    context.CLIARGS = {}
    options = p.post_process_args('-v %s' % host)
    assert options == '-v %s' % host
    assert context.CLIARGS['verbosity'] == 1

    context.CLIARGS = {}
    options = p.post_process_args('-vv %s' % host)
    assert options == '-vv %s' % host

# Generated at 2022-06-20 12:56:24.479826
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """This is a test for method run in class AdHocCLI. """
    AdHoc_cli = AdHocCLI()
    # Should return 0 and terminate successfully.
    assert AdHoc_cli.run() == 0

# Generated at 2022-06-20 12:56:36.449415
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Patch display.display so that we can inspect its output for testing purposes.
    display.display = lambda msg: print(msg)
    # Patch ad_hoc_cli._play_ds so that we can test that it is correctly called.
    from ansible.cli.adhoc import ad_hoc_cli
    real_ad_hoc_cli__play_ds = ad_hoc_cli._play_ds

    def fake_ad_hoc_cli__play_ds(pattern, async_val, poll):
        print("_play_ds")
        fake_play_ds = real_ad_hoc_cli__play_ds(pattern, async_val, poll)
        print("_play_ds")
        return fake_play_ds

    ad_hoc_cli._play_ds = fake_ad_hoc_cli__play

# Generated at 2022-06-20 12:56:46.630637
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Arrange
    adhoc = AdHocCLI(args=[])
    options = adhoc.parse()
    options.verbosity = 4

    # Setup valid options for adhoc
    options.inventory = "/path/to/inventory"
    options.ask_vault_pass = True
    options.ask_become_pass = True
    options.connection = "ssh"
    options.module_name = "setup"

    # Act
    try:
        options = adhoc.post_process_args(options)
    except AnsibleOptionsError as e:
        raise AssertionError("AnsibleOptionsError should not be raised, post_process_args accepts valid options.")
        #TODO: add in assertion for values that should be set

    # Assert
    assert options.verbosity == 4

    # Setup

# Generated at 2022-06-20 12:58:11.321859
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['-k', '-s', '-m', 'ping', 'all'])

# Generated at 2022-06-20 12:58:22.047938
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad = AdHocCLI()
    ad._init_parser()

    parser = ad.parser

    assert parser._actions[1].dest == 'inventory'
    assert parser._actions[2].dest == 'module_path'
    assert parser._actions[3].dest == 'forks'
    assert parser._actions[4].dest == 'remote_user'
    assert parser._actions[5].dest == 'private_key_file'
    assert parser._actions[6].dest == 'ssh_common_args'
    assert parser._actions[7].dest == 'ssh_extra_args'
    assert parser._actions[8].dest == 'sftp_extra_args'
    assert parser._actions[9].dest == 'scp_extra_args'
    assert parser._actions[10].dest == 'become'
    assert parser._actions

# Generated at 2022-06-20 12:58:24.357331
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Unit test for constructor of class AdHocCLI
    """
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)


# Generated at 2022-06-20 12:58:34.807623
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.parser
    assert parser is not None
    assert parser.prog == 'ansible'
    assert parser.usage == "%prog <host-pattern> [options]"
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert len(parser._positionals._group_actions) == 1
    assert len(parser._optionals._group_actions) == 20
    assert parser._positionals._group_actions[0].dest == 'args'
    assert parser._positionals._group_actions[0].metavar == 'pattern'

# Generated at 2022-06-20 12:58:37.544325
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc = AdHocCLI()
    ad_hoc.init_parser()
    ad_hoc.run()

# Generated at 2022-06-20 12:58:47.851593
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os.path
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(current_dir, "lib"))
    from ansible.cli import CLI

    AdHocCLI.add_cli_options = lambda self: None
    AdHocCLI.post_process_args = lambda self, options: options
    AdHocCLI.run_subset = lambda self, hosts, module, task_vars: None
    AdHocCLI.get_host_list = lambda self, inventory, subset, pattern: [u'127.0.0.1']
    AdHocCLI.ask_passwords = lambda self: ('', '')

# Generated at 2022-06-20 12:58:54.264468
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test: 'test_AdHocCLI_run'
    # Description: This is a testcase to test the method run of class AdHocCLI.
    # Input Parameter: None
    # Return: None
    # Output: None
    print('Starting testcase: test_AdHocCLI_run...')
    test = AdHocCLI()
    # test.parse()
    test.post_process_args(None)
    test.run()



# Generated at 2022-06-20 12:58:56.254950
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()
    assert ad_hoc_cli.parser._prog == 'ansible'

# Generated at 2022-06-20 12:59:00.639286
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    create AdHocCLI class to check if all the setup and initialization
    for the class are done properly
    '''

    ad = AdHocCLI()
    assert ad



# Generated at 2022-06-20 12:59:01.581083
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass