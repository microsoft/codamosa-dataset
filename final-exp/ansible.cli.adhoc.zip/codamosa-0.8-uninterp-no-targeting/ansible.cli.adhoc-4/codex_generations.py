

# Generated at 2022-06-20 12:51:52.292982
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    adhoc_cli = AdHocCLI()

    # Verify AdHocCLI parses correct usage
    assert adhoc_cli._usage == "%prog <host-pattern> [options]"

    # Verify AdHocCLI parses correct description
    assert adhoc_cli._desc == "Define and run a single task 'playbook' against a set of hosts"

    # Verify AdHocCLI parses correct epilog
    assert adhoc_cli._epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

    # Verify AdHocCLI parses correct module_args
    assert adhoc_cli.parser._option_string_actions['-a'].default == C.DEFAULT_MODULE_ARGS

    # Verify AdHocCLI parses correct module name

# Generated at 2022-06-20 12:51:58.024389
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    module = __import__('ansible.cli.adhoc')
    module.display = Display()
    # load class
    adhoc = getattr(module, 'AdHocCLI')
    # create object
    adhoc_object = adhoc()
    # call method
    adhoc_object.init_parser()

# Generated at 2022-06-20 12:52:00.026447
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    return AdHocCLI()

# Generated at 2022-06-20 12:52:09.162175
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import shutil
    import tempfile
    from ansible.cli.adhoc import AdHocCLI

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary inventory file
    src = """
    localhost ansible_connection=local
    """
    infile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    infile.write(src)
    infile.close()
    inventory = infile.name

    # Create a temporary playbook file
    src = """
    - hosts: localhost
      tasks:
        - debug: msg="Hello, world!"
    """
    pbfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    pbfile.write(src)
    pbfile.close()
   

# Generated at 2022-06-20 12:52:13.924630
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    """
    This method unit tests the init_parser() method of class AdHocCLI.
    It tests the method's ability to create an options parser for bin/ansible
    """

    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()


# Generated at 2022-06-20 12:52:17.745038
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' Unit test for method init_parser of class AdHocCLI '''

    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.init_parser()

# Generated at 2022-06-20 12:52:26.051063
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.constants import C

    a = AdHocCLI(None)
    options = a.parse(['-m', 'setup', 'local'])
    a.post_process_args(options)

    # test constants runas_opts=True
    assert context.CLIARGS['ask_become_pass'] == C.DEFAULT_BECOME_ASK_PASS
    assert context.CLIARGS['become'] == C.DEFAULT_BECOME
    assert context.CLIARGS['become_method'] == C.DEFAULT_BECOME_METHOD
    assert context.CLIARGS['become_ask_pass'] == C.DEFAULT_BECOME_ASK_PASS
    assert context.CLIARGS['become_user'] == C.DEFAULT_BECOME_

# Generated at 2022-06-20 12:52:32.883063
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert isinstance(cli, AdHocCLI)
    assert isinstance(cli.parser, opt_help.Parser)
    assert cli.options is None
    assert cli.args is None
    assert cli.module_args is None
    assert cli.module_name is None
    assert cli.action_name is None
    assert cli.action is None
    assert cli.display is None


# Generated at 2022-06-20 12:52:34.907417
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, AdHocCLI)

# Generated at 2022-06-20 12:52:47.609608
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # create a test object
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.parse()

    # mock out subprocess
    ad_hoc_cli.get_host_list = mock.Mock()
    ad_hoc_cli.get_host_list.return_value = ['1.example.com']

    ad_hoc_cli._play_prereqs = mock.Mock()
    ad_hoc_cli._play_prereqs.return_value = ['loader', 'inventory', 'variable_manager']

    class Play(object):
        def __init__(self):
            self.name = 'Ansible Ad-Hoc'
            self.hosts = '1.example.com'
            self.tasks = ['task1', 'task2', 'task3']

# Generated at 2022-06-20 12:53:00.795418
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    parser._check_value('-m', 'shell')

# Generated at 2022-06-20 12:53:09.126894
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    test_ad_hoc = AdHocCLI()
    class args:
        def __init__(self, listhosts, subset, one_line, tree, module_name, module_args):
            self.listhosts = listhosts
            self.subset = subset
            self.one_line = one_line
            self.tree = tree
            self.module_name = module_name
            self.module_args = module_args
    test_context = context.CLIARGS
    setattr(test_context, 'listhosts', True)
    setattr(test_context, 'subset', None)
    setattr(test_context, 'one_line', False)
    setattr(test_context, 'tree', False)
    setattr(test_context, 'module_name', None)
    set

# Generated at 2022-06-20 12:53:10.207724
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:53:20.156882
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-20 12:53:21.408064
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=['localhost', '-m', 'setup'])
    cli.run()

# Generated at 2022-06-20 12:53:23.865302
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Arrange
    cliz = AdHocCLI()

    # Act
    cliz.init_parser()

    # Assert
    assert cliz.parser is not None



# Generated at 2022-06-20 12:53:36.882324
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-20 12:53:40.921522
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['--module-name', 'ping', 'localhost']

    cli = AdHocCLI(args)
    options = cli.parser.parse_args(args)
    options = cli.post_process_args(options)

    assert options.module_name == 'ping'
    assert options.module_args == C.DEFAULT_MODULE_ARGS


# Generated at 2022-06-20 12:53:48.084051
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    from ansible.cli.arguments import validate_conflicts

    parser = AdHocCLI([])

    # assert that a parser is returned by AdHocCLI.init_parser()
    assert parser

    # assert AdHocCLI.init_parser() return a parser that has a method 'add_option'
    assert hasattr(parser, "add_argument")

    # assert that the parser returned by AdHocCLI.init_parser() has options
    # that are specified in AdHocCLI.__doc__
    assert hasattr(parser, "args")

    # assert that the parser returned by AdHocCLI.init_parser() has options
    # that are specified in AdHocCLI.init_parser()
    assert hasattr(parser, "module_args")

    # assert that the parser returned by AdHoc

# Generated at 2022-06-20 12:53:59.318510
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-20 12:54:06.466966
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:54:17.108359
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from collections import namedtuple
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    values = namedtuple("Values", "verbose")
    options = CLI.base_parser(Values(False)).parse_args(['-m', 'debug', 'localhost'])
    display = Display()
    display.columns = 80
    display.verbosity = options.verbosity
    display.colorize = stringc
    display.error = lambda _msg, wrap_text=None: _msg
    display.warning = lambda _msg, wrap_text=None: _msg
    display.deprecated = lambda _msg, version=None, removed=False: _msg

# Generated at 2022-06-20 12:54:18.071884
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:54:29.245958
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    This function tests the method post_process_args of class AdHocCLI
    when the arguments are incorrect and when the arguments are correct.
    '''
    # arguments when the arguments are incorrect
    options = {}
    adhoc_class = AdHocCLI(args=[])
    try:
        # post_process_args of AdHocCLI class should raise AnsibleOptionsError exception
        # because the arguments provided here are incorrect
        assert adhoc_class.post_process_args(options) is None
    except AnsibleOptionsError:
        pass
    except Exception:
        raise

    # arguments when the arguments are correct
    options = {'inventory': 'my-ansible-inventory'}
    adhoc_class = AdHocCLI(args=[])

# Generated at 2022-06-20 12:54:36.682893
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    parser = CLI.base_parser('adhoc')

    args = parser.parse_args(['-m', 'ping', '-a', 'ping_args', 'all'])
    options = AdHocCLI().post_process_args(args)
    assert options.module_name == 'ping'
    assert options.module_args == 'ping_args'

    # positional arguments
    args = parser.parse_args(['ping_hosts'])
    options = AdHocCLI().post_process_args(args)
    assert options.args == 'ping_hosts'

    args = parser.parse_args(['-m', 'ping', '-a', 'ping_args', 'all' ,'-l', 'example.com'])
    options = AdHocCLI().post_process_args(args)

# Generated at 2022-06-20 12:54:37.937633
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ac = AdHocCLI()
    ac.init_parser()


# Generated at 2022-06-20 12:54:45.143462
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Unit test for method run of class AdHocCLI with
    # when: all branch coverage
    # expected output:
    #     ansible-playbook: error: argument -t/--tags: expected one argument
    #     No hosts matched, nothing to do
    #     ansible-playbook: error: argument <pattern>: expected one argument

    # create an instance of class AdHocCLI
    ahc = AdHocCLI(['ansible', '-t', '-i', 'my-hosts', 'my-hosts'])
    # run method
    ahc.run()

# Generated at 2022-06-20 12:54:51.544320
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # We need to mock different parts of CLI class in order to test it's method run
    # To do this we need to:
    # 1) make the method run non-static
    AdHocCLI.run = AdHocCLI.run.__func__
    # 2) mock other methods used in run
    CLI.post_process_args = lambda self, options: options
    CLI.ask_passwords = lambda self: (None, None)
    CLI.validate_conflicts = lambda self, options, runas_opts=False, vault_opts=False, fork_opts=False: True
    # 3) mock classes used in run

# Generated at 2022-06-20 12:55:01.774959
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Unit test for method post_process_args of class AdHocCLI"""
    args = [
        "example.com",
        "-m", "setup",
        "-a", "filter=ansible_all_ipv4_addresses",
        "--ask-pass",
        "--list-hosts"
    ]

    adhoc = AdHocCLI(args)
    assert adhoc.options.host_pattern == "example.com"
    assert adhoc.options.module_name == "setup"
    assert adhoc.options.module_args == "filter=ansible_all_ipv4_addresses"
    assert adhoc.options.ask_pass == True
    assert adhoc.options.listhosts == True

# Generated at 2022-06-20 12:55:04.200624
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoccli = AdHocCLI()
    adhoccli.init_parser()
    assert True


# Generated at 2022-06-20 12:55:19.241942
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-20 12:55:19.830734
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    pass

# Generated at 2022-06-20 12:55:28.210817
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Exercise and verify post_process_args()"""
    class args:
        def __init__(self, verbosity=0, subset=None, forking=None, check=False, inventory=None, module_name='', module_args='', listhosts=False, one_line=False, connection=None, timeout=None, poll_interval=None, seconds=None):
            self.verbosity = verbosity
            self.subset = subset
            self.forking = forking
            self.check = check
            self.inventory = inventory
            self.module_name = module_name
            self.module_args = module_args
            self.listhosts = listhosts
            self.one_line = one_line
            self.connection = connection
            self.timeout = timeout
            self.poll_interval = poll_

# Generated at 2022-06-20 12:55:31.914400
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ["-m ", "ping", "localhost"]
    adhoc = AdHocCLI(args)
    adhoc.post_process_args(adhoc.options)
    assert adhoc.run() == 0

# Generated at 2022-06-20 12:55:34.488540
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc = AdHocCLI()
    ad_hoc.init_parser()
    


# Generated at 2022-06-20 12:55:36.522539
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI().init_parser()
    assert parser is not None


# Generated at 2022-06-20 12:55:47.588181
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    app = AdHocCLI()

    # in this test we use a sub-parser to test its attributes
    sub_parser = app.parser.bots_group
    assert sub_parser.prog == 'ansible-bot'
    assert sub_parser.usage == "%(prog)s [options]"

    # test that the bot options are registered
    sub_parser.get_default('bot') is None
    sub_parser.get_default('bot_data_file') is None
    sub_parser.get_default('bot_workspace') is None
    sub_parser.get_default('bot_test_mode') is None
    sub_parser.get_default('bot_test_command') is None
    assert 'bot' in sub_parser._option_string_actions
    assert 'bot-data-file' in sub_parser._option

# Generated at 2022-06-20 12:55:52.135693
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    parser = AdHocCLI()
    arguments = {'module_name': C.DEFAULT_MODULE_NAME, 'module_args': '', 'args': 'arg1,arg2', 'verbosity': '0'}
    args = parser.post_process_args(arguments)

    assert args.pop('module_name') == 'ping'
    assert args.pop('module_args') == ''
    assert args.pop('args') == 'arg1,arg2'
    assert args.pop('verbosity') == 0

    assert len(args) == 0

# Generated at 2022-06-20 12:56:01.800812
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI
    '''

    # Setup the module object and create the AdHocCLI object
    context.CLIARGS = {
        'module_name': 'ping',
        'module_args': '',
        'task_timeout': 1,
        'seconds': '2',
        'poll_interval': '1',
        'one_line': False,
        'tree': '',
        'forks': 1,
        'subset': '',
        'listhosts': False,
        'args': 'A'
    }

    adhoc_obj = AdHocCLI()

    # Call run method
    adhoc_obj.run()

# Generated at 2022-06-20 12:56:04.267944
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser is not None

# Generated at 2022-06-20 12:56:36.305576
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])

    parser = cli.init_parser()
    assert parser



# Generated at 2022-06-20 12:56:38.605381
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    parser = cli.init_parser()
    assert parser is not None

# Generated at 2022-06-20 12:56:40.431593
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()

    assert parser.args is None

# Generated at 2022-06-20 12:56:49.447624
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:56:58.543109
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # is an extra-simple tool/framework/API for doing 'remote things'.
    # this command allows you to define and run a single task 'playbook' against a set of hosts

    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()

    assert adhoc_cli.parser._prog_name == 'ansible'
    assert adhoc_cli.parser._usage == '%prog <host-pattern> [options]'
    assert adhoc_cli.parser._epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"


# Generated at 2022-06-20 12:57:07.611813
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.run()
    options = cli.post_process_args(cli.parser.parse_args(['-m', 'ping', 'localhost']))

    assert options.module_name == 'ping'
    assert options.module_args == '', "Default should be empty string."

    options = cli.post_process_args(cli.parser.parse_args(['-m', 'ping', '-a', 'myvar=myvalue', 'localhost']))

    assert options.module_name == 'ping'
    assert options.module_args == 'myvar=myvalue', "Values should match."

# Generated at 2022-06-20 12:57:15.351931
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import ansible.utils.unsafe_proxy
    # overriding the ansible.utils.unsafe_proxy.wrap_var() function
    # to return the same value that was passed to it
    old_wrap_var = ansible.utils.unsafe_proxy.wrap_var
    ansible.utils.unsafe_proxy.wrap_var = lambda x: x

    adhoc_instance = AdHocCLI() # initialized instance of class AdHocCLI

    # testing the return value of AdHocCLI.post_process_args()
    # when options is an empty dict
    assert adhoc_instance.post_process_args({}) == {}

    # testing the return value of AdHocCLI.post_process_args()
    # when options is None

# Generated at 2022-06-20 12:57:25.490832
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Test the CLI by using a known test case
    cli = AdHocCLI()
    cli.init_parser()

    # Verify parser arguments
    assert cli.parser._actions[2].dest == 'module_args'
    assert cli.parser._actions[2].help == "The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'"
    assert cli.parser._actions[2].default == 'echo hello'
    assert cli.parser._actions[3].dest == 'module_name'
    assert cli.parser._actions[3].help == "Name of the action to execute (default=command)"
    assert cli.parser._actions[3].default == 'command'
    assert cli.parser._actions[4].dest == 'args'
    assert cli

# Generated at 2022-06-20 12:57:27.163598
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test instantiation of AdHocCLI
    assert isinstance(AdHocCLI(), CLI)

# Generated at 2022-06-20 12:57:31.217497
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Test with default values
    # FIXME: will change output of test
    context.CLIARGS = opt_help.global_opts.parse_args([])
    cli = AdHocCLI()
    cli.init_parser()


# Generated at 2022-06-20 12:58:51.023534
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    from ansible import constants as C

    options = context.CLIARGS
    options['module-name'] = 'shell'
    options['module-args'] = 'ls /stuff'
    options['inventory'] = None
    options['args'] = 'host_pattern'
    options['ask-pass'] = False
    options['ask-su-pass'] = False
    options['ask-sudo-pass'] = False
    options['ask-vault-pass'] = False
    options['vault-password-file'] = C.DEFAULT_VAULT_PASSWORD_FILE
    options['new-vault-password-file'] = C.DEFAULT_VAULT_PASSWORD_FILE
    options['forks'] = C.DEFAULT_FORKS
    options['module_path'] = C.DEFAULT_MODULE_PATH
    options

# Generated at 2022-06-20 12:58:58.651712
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' Test method run of class AdHocCLI.
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.executor.task_result import TaskResult


# Generated at 2022-06-20 12:59:07.567892
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.init_parser()
    options = cli.parser.parse_args(['webserver', '-a', '-m', 'ping'])
    assert hasattr(options, 'module_args')
    assert hasattr(options, 'module_name')
    assert options.module_args == '-m ping'
    assert options.module_name == 'command'
    options = cli.parser.parse_args(['webserver', '-a', '-m', 'ping', 'key1=val1'])
    assert options.module_args == 'key1=val1'
    assert options.module_name == 'ping'

# Generated at 2022-06-20 12:59:19.502725
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # if verbosity is 0 set it to 1
    cli = AdHocCLI(args=[])
    cli.post_process_args(cli.options)
    assert cli.options.verbosity == 1
    # if verbosity is -v or vv set it to 1
    cli = AdHocCLI(args=['-v'])
    cli.post_process_args(cli.options)
    assert cli.options.verbosity == 1
    cli = AdHocCLI(args=['-vv'])
    cli.post_process_args(cli.options)
    assert cli.options.verbosity == 1
    # if verbosity is -vvv set it to 3
    cli = AdHocCLI(args=['-vvv'])
    cli.post_process

# Generated at 2022-06-20 12:59:20.390615
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    pass

# Generated at 2022-06-20 12:59:22.162141
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_cli = AdHocCLI()
    return ad_cli

# Generated at 2022-06-20 12:59:27.524355
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ahc = AdHocCLI(args=['testhost', '-a', 'echo foo'])
    assert ahc._play_ds('testhost', None, None) == dict(
        name="Ansible Ad-Hoc",
        hosts='testhost',
        gather_facts='no',
        tasks=[
            dict(action={'module': 'echo', 'args': {'foo': None}},
                 timeout=C.DEFAULT_TASK_TIMEOUT)
        ]
    )

# Generated at 2022-06-20 12:59:30.367048
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test for method run of class AdHocCLI'''
    ad_hoc_cli = AdHocCLI()


# Generated at 2022-06-20 12:59:36.623534
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create instance of AdHocCLI run
    AdHoc_run = AdHocCLI()

    # call the run method of the CLI
    AdHoc_run.run()

if __name__ == '__main__':
    # create instance of AdHocCLI run
    AdHoc_run = AdHocCLI()

    # call the run method of the CLI
    AdHoc_run.run()

# Generated at 2022-06-20 12:59:41.126887
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # args[0] is the yaml file in which the testcase is written
    args = ['test/unittests/test_AdHocCLI/testcase.yml']
    cli = AdHocCLI(args, display)
    assert cli.run() == 0