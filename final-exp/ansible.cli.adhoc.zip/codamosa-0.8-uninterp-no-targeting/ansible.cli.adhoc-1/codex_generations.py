

# Generated at 2022-06-20 12:52:00.655411
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    class TestAdHocCLI(AdHocCLI):
        def __init__(self, args, callback=None):
            super(TestAdHocCLI, self).__init__(args, callback)

        def run(self):
            pass

    # Testing with default args
    adhoc = TestAdHocCLI([])
    assert isinstance(adhoc.parser, object)

    #TODO check all opts are registered to parser

# Generated at 2022-06-20 12:52:07.608394
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Arrange
    cli = AdHocCLI(None, 'AdHocCLI')
    cli.CLI.parser = cli.CLI._init_parser()

    # Act
    cli.init_parser()

    # Assert
    assert 'usage' in cli.CLI.parser._actions[0].option_strings, "The usage is wrong."
    assert '%prog <host-pattern> [options]' == cli.CLI.parser._actions[0].help, "The usage is wrong."
    assert 'Define and run a single task \'playbook\' against a set of hosts' == cli.CLI.parser.description, "The description is wrong."
    assert 'Some actions do not make sense in Ad-Hoc (include, meta, etc)' == cli.CLI.parser.epilog

# Generated at 2022-06-20 12:52:08.739155
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-20 12:52:13.137949
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])
    assert cli is not None

if __name__ == '__main__':
    test_AdHocCLI()
    cli = AdHocCLI(['Ad Hoc', '-h'])
    cli.parse()

# Generated at 2022-06-20 12:52:18.834303
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    assert parser.prog == 'ansible'
    args = ['host-pattern']
    opt = cli.parse(args)
    assert opt.args == 'host-pattern'
    assert opt.host_pattern == 'host-pattern'

# Generated at 2022-06-20 12:52:32.177029
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Set up arguments as command line would have passed
    argv = ['-m', 'ping']
    argv.extend(['-i', 'localhost,'])
    argv.extend(['-e', 'host_key_checking=False'])
    argv.extend(['localhost'])

    adhoc = AdHocCLI(args=argv)
    (options, args) = adhoc.parser.parse_args(adhoc.args)
    # This will trigger the parser to exit unless we catch the error
    try:
        options = adhoc.post_process_args(options)
    except SystemExit:
        assert False, "Should not exit"
    assert options.verbosity == 0
    assert options.module_name == 'ping'
    assert options.module_args == ''
    assert options

# Generated at 2022-06-20 12:52:37.956828
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI([])
    options = adhoc_cli.parser.parse_args(['localhost',
                                           '--module-name', 'ping'])
    options = adhoc_cli.post_process_args(options)
    assert options.module_name == 'ping'
    assert options.verbosity == 3
    assert options.connection == 'smart'

# Generated at 2022-06-20 12:52:40.162064
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhocObj = AdHocCLI()
    assert isinstance(adhocObj, AdHocCLI)

# Generated at 2022-06-20 12:52:45.198764
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(args=[])

    #To get code coverage for constructor
    assert adhoc_cli is not None
    assert isinstance(adhoc_cli._display, Display)

# Generated at 2022-06-20 12:52:53.497408
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI('ansible', '0.1.0')
    assert ad_hoc_cli._base_parser is not None
    assert ad_hoc_cli._play_prereqs != CLI._play_prereqs
    assert ad_hoc_cli._play_prereqs.__doc__ == CLI._play_prereqs.__doc__
    assert ad_hoc_cli.version == '0.1.0'
    assert isinstance(ad_hoc_cli.parser, argparse.ArgumentParser)
    assert ad_hoc_cli.module_args is None


# Generated at 2022-06-20 12:53:04.614797
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    a = AdHocCLI()
    a.init_parser()
    assert a.parser


# Generated at 2022-06-20 12:53:16.172358
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """ Return a unittest for AdHocCLI method run"""
    from ansible.utils import context_objects as co

    context.CLIARGS = {'module_args': '{"test": "test"}',
                       'module_name': 'setup',
                       'subset': None,
                       'listhosts': False,
                       'seconds': None,
                       'poll_interval': 15,
                       'verbosity': False,
                       'one_line': False,
                       'tree': None,
                       'forks': 5,
                       'args': 'ansible-playbook'}

    inventory = co.GlobalCLIArgs._get_global_context().inventory

    loader = co.GlobalCLIArgs._get_global_context().loader

    variable_manager = co.GlobalCLIArgs._get_global_context().variable_manager

# Generated at 2022-06-20 12:53:17.427319
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ ad hoc cli test """
    AdHocCLI()

# Generated at 2022-06-20 12:53:23.913745
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    options = opt_help.get_default_options()
    options.module_name = 'shell'
    options.module_args = 'echo $HOME'
    options.listhosts = True
    options.verbosity = 1

    adhoc_manager = AdHocCLI()
    adhoc_manager.post_process_args(options)
    assert(options.verbosity == 1)
    assert(options.listhosts == True)
    assert(options.module_name == 'shell')
    assert(options.module_args == 'echo $HOME')


# Generated at 2022-06-20 12:53:29.219302
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    # The method is called at the end of the method init_parser
    cli.post_process_args = Mock()
    cli.parse()
    assert cli.post_process_args.called



# Generated at 2022-06-20 12:53:38.879334
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ac = AdHocCLI(args=[])
    ac.init_parser()
    # initialize the parser object
    parser = ac.parser
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.usage == "%prog <host-pattern> [options]"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    # check the options
    parser.parse_args(['-m', 'ping', 'all'])
    parser.parse_args(['-a', 'opt1=val1', 'all'])

# Generated at 2022-06-20 12:53:41.434549
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(['--list-hosts', 'pattern'])
    assert cli.options.listhosts == True
    assert cli.options.args == 'pattern'

# Generated at 2022-06-20 12:53:48.418717
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Make sure all the expected options are included in the parser.
    ad_hoc_cli_obj = AdHocCLI()
    ad_hoc_cli_obj.init_parser()
    ad_hoc_cli_parser = ad_hoc_cli_obj.parser

    assert ad_hoc_cli_parser.get_option("-a")
    assert ad_hoc_cli_parser.get_option("--args")
    assert ad_hoc_cli_parser.get_option("-k")
    assert ad_hoc_cli_parser.get_option("--ask-pass")
    assert ad_hoc_cli_parser.get_option("-b")
    assert ad_hoc_cli_parser.get_option("--become")
    assert ad_hoc_cli_parser.get_option

# Generated at 2022-06-20 12:53:59.565411
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # We need the inventory to contain the hostname 'success'
    success_inventory = """
{
    "_meta": {
        "hostvars": {
            "success": {
                "ansible_host": "127.0.0.1",
                "ansible_port": 5985,
                "ansible_user": "vagrant",
                "ansible_password": "vagrant",
                "ansible_connection": "winrm",
                "ansible_winrm_transport": "ntlm",
                "ansible_winrm_server_cert_validation": "ignore"
            }
        }
    },
    "success": {
        "hosts": [
            "success"
        ]
    }
}
"""
    # We need a config file for Kerberos authentication

# Generated at 2022-06-20 12:54:10.067526
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    class TestAdHocCLI(AdHocCLI):
        def __init__(self, args):
            self.options = args
            super(TestAdHocCLI, self).__init__()

        def get_host_list(self, inventory, subset, pattern):
            return pattern

    # Test case: ad-hoc run without privilege escalation
    # Expected result: success
    pattern = 'localhost,'

# Generated at 2022-06-20 12:54:21.953637
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['-m', 'ping', 'all'])
    assert cli.args == ['-m', 'ping', 'all']
    assert cli.parser is not None
    assert cli.options is not None
    assert cli.display is not None


# Generated at 2022-06-20 12:54:32.490514
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    Test AdHocCLI.run() method
    """
    from click.testing import CliRunner
    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI

    runner = CliRunner()
    test_args = {
        'pattern': 'localhost',
        'module_name': 'command',
        'module_args': 'ls'
    }

    cli = CLI.load()
    adhoc = AdHocCLI(cli)
    result = runner.invoke(adhoc.run, [test_args['pattern'], '-m', test_args['module_name'], '-a', test_args['module_args']])

    assert result.exit_code == 0
    assert 'localhost' in result.output

# Generated at 2022-06-20 12:54:35.196701
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    c = AdHocCLI()
    c.init_parser()

# Generated at 2022-06-20 12:54:36.380556
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    pass

# Generated at 2022-06-20 12:54:37.681211
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad = AdHocCLI()
    assert ad._tqm is None

# Generated at 2022-06-20 12:54:40.843456
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI = AdHocCLI("test.py")

if __name__ == '__main__':
    AdHocCLI = AdHocCLI("test.py")

# Generated at 2022-06-20 12:54:42.977905
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    test_obj = AdHocCLI()
    test_obj.init_parser()
    assert test_obj.parser is not None


# Generated at 2022-06-20 12:54:50.279328
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' Checking all arguments initialized by init_parser method of class AdHocCLI '''

# Generated at 2022-06-20 12:54:51.226587
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: create a minimal test
    pass

# Generated at 2022-06-20 12:55:01.959374
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:55:21.456335
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import __main__

    class TestAdHocCLI(AdHocCLI):
        "Wrapper class to inject mocks"
        def get_host_list(self, inventory, subset, pattern):
            return 'inventory'

        def ask_passwords(self):
            return 'sshpass', 'becomepass'

        def _play_prereqs(self):
            return 'loader', 'inventory', 'variable_manager'

    class TestDisplay:
        "Wrapper class to implement missing method display of class Display"
        def display(self, value):
            pass

    class TestCLI(CLI):
        "Wrapper class to inject mocks"

# Generated at 2022-06-20 12:55:32.522697
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    from ansible.errors import AnsibleOptionsError

    adhoccli = AdHocCLI([])
    context.CLIARGS = {}

    # Should raise AnsibleOptionsError because -m and -a are required
    with pytest.raises(AnsibleOptionsError):
        adhoccli.post_process_args({})

    # module_name and module_args are not empty
    context.CLIARGS = {'module_name': 'foo', 'module_args': 'bar'}
    adhoccli.post_process_args({})

    # module_name is empty but module_args is not empty
    context.CLIARGS = {'module_name': '', 'module_args': 'bar'}
    adhoccli.post_process_args({})

    # module_name is not empty

# Generated at 2022-06-20 12:55:35.472235
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = AdHocCLI(['--version']).parser
    args = parser.parse_args(['--version'])
    assert args.version is True

# Generated at 2022-06-20 12:55:36.920371
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli.init_parser()

# Generated at 2022-06-20 12:55:39.344231
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI(args=['all', '-m', 'ping'])
    assert cli.run() == 0

# Generated at 2022-06-20 12:55:47.956846
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Method init_parser of AdHocCLI should set all_parser options
    cli_adhoc = AdHocCLI()
    all_parser = cli_adhoc.parser
    cli_adhoc.init_parser()
    assert all_parser.version == cli_adhoc.parser.version
    assert all_parser.usage == cli_adhoc.parser.usage
    assert all_parser.epilog == cli_adhoc.parser.epilog
    assert all_parser.conflict_handler == cli_adhoc.parser.conflict_handler


# Generated at 2022-06-20 12:55:48.912786
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI(args=[])

# Generated at 2022-06-20 12:55:50.351173
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    assert cli._play_context

# Generated at 2022-06-20 12:56:01.116626
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.module_utils._text import to_bytes
    import ansible.context
    import ansible.cli.adhoc
    cli_adhoc = ansible.cli.adhoc.AdHocCLI()
    cli_adhoc.options = cli_adhoc.parser.parse_args([])
    cli_adhoc.options.module_name = 'setup'
    cli_adhoc.options.module_args = b'hostname=localhost'
    cli_adhoc.options.forks = 10
    cli_adhoc.options.listhosts = False
    cli_adhoc.options.one_line = False
    cli_adhoc.options.poll_interval = 15
    cli_adhoc.options.seconds = 120

# Generated at 2022-06-20 12:56:11.584660
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():  # noqa
    # Arrange
    cli = AdHocCLI()

    options = cli.parse()[0]

    # Act
    options = cli.post_process_args(options)

    # Assert
    assert options.verbosity == 4
    assert options.connection == 'smart'
    assert options.timeout == 10
    assert options.forks == 5
    assert options.check is False
    assert options.diff is False
    assert options.listhosts is False
    assert options.listtasks is False
    assert options.listtags is False
    assert options.syntax is False
    assert options.sudo is False
    assert options.sudo_user is None
    assert options.remote_user is None
    assert options.ask_sudo_pass is False
    assert options.ask_pass is False
    assert options

# Generated at 2022-06-20 12:56:40.289551
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    ansible_adhoc_cli = AdHocCLI(args=['-m', 'ping', '-a', 'opt1=data1', 'dummy'])
    ansible_adhoc_cli.run()


if __name__ == '__main__':
    import os
    import unittest
    from units.mock.patch import Patch, MagicMock

    class TestAdHocCLI(unittest.TestCase):
        def test_run(self):
            testargs = 'ansible-adhoc -m ping -a "opt1=data1" dummy'.split()

# Generated at 2022-06-20 12:56:49.384332
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Case 1: module_name is C.DEFAULT_MODULE_NAME and verbosity is positive
    # set verbosity as positive value and in dict args
    # set module_name as C.DEFAULT_MODULE_NAME
    args = dict(verbosity=2,
                module_name=C.DEFAULT_MODULE_NAME)
    # create instance of AdHocCLI
    ad_hoc_cli = AdHocCLI()
    # execute method post_process_args of class AdHocCLI
    # and assign result to variable ad_hoc_cli_args
    ad_hoc_cli_args = ad_hoc_cli.post_process_args(args)
    # verify that context.CLIARGS['verbosity'] is equal to args['verbosity']

# Generated at 2022-06-20 12:57:00.813704
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # create mock_parser
    class MockParser:
        def __init__(self):
            self.args = ''
        def error(self, msg):
            raise AnsibleOptionsError(msg)

    mock_parser = MockParser()

    # create mock_options
    class MockOptions:
        def __init__(self):
            self.ask_vault_pass = False
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.connect_timeout = None
            self.executable = None
            self.extra_vars = []
            self.flush_cache = False
            self.forks = 5
            self.host_key_checking = False
            self.inventory = None

# Generated at 2022-06-20 12:57:11.041873
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()

    # 'module_name' is required
    options = cli.parse()
    try:
        cli.post_process_args(options)
        assert False, "ad-hoc: missing required option 'module_name' failed to raise AnsibleOptionsError exception"
    except AnsibleOptionsError: pass
    except Exception as e:
        assert False, "unexpected exception raised: %s" % e.__class__.__name__

    # 'module_name' requires arguments
    options = cli.parse('-m ping')
    try:
        cli.post_process_args(options)
        assert False, "ad-hoc: missing required option 'module_name' failed to raise AnsibleOptionsError exception"
    except AnsibleOptionsError: pass

# Generated at 2022-06-20 12:57:11.769195
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:57:14.557327
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.init_parser()
    assert isinstance(parser, CLI.ArgumentParser)
    assert parser._prog_prefix == '%prog '
    assert parser._prog == 'ansible adhoc'


# Generated at 2022-06-20 12:57:16.039081
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()     # constructor without arguments
    ad_hoc_cli.run()

# Generated at 2022-06-20 12:57:24.867018
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''Unit test for method post_process_args of class AdHocCLI'''
    # pylint: disable=protected-access
    adhoc_cli = AdHocCLI(args=['pattern-or-hostname', '-a'])
    options = adhoc_cli._process_args(['pattern-or-hostname', '-a', 'module_args'])
    options = adhoc_cli.post_process_args(options)

    assert options.module_name == C.DEFAULT_MODULE_NAME
    assert options.module_args == 'module_args'
    assert options.args == 'pattern-or-hostname'

# Generated at 2022-06-20 12:57:28.409025
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    import ansible.utils.plugin_docs as plug_docs

    adhoc = AdHocCLI()
    assert adhoc._usage.startswith('usage: ')
    plug_docs.init(adhoc, 'AdHocCLI')

# Generated at 2022-06-20 12:57:32.152922
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc = AdHocCLI()
    option, args = ad_hoc.parser.parse_args(['-m', 'ping', 'all'])
    assert option.module_name == 'ping'
    assert args == 'all'

# Generated at 2022-06-20 12:58:08.463828
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert isinstance(cli.parser, CLI.parser)

# Generated at 2022-06-20 12:58:20.038342
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    sut = AdHocCLI()

    # Mock methods
    def mock_init_parser(*args, **kwargs):
        pass


# Generated at 2022-06-20 12:58:21.641788
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, AdHocCLI)
    assert adhoc_cli.__class__.__name__ == 'AdHocCLI'


# Generated at 2022-06-20 12:58:22.605504
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # test init_parser
    api = AdHocCLI()
    parser = api.init_parser()
    assert parser is not None

# Generated at 2022-06-20 12:58:32.250357
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    def _run_parser(cli, args):
        """Runs the parser, mocking out the args list."""
        with context.CLIARGS.patch(args):
            cli.init_parser()

    adhoc_cli = AdHocCLI()

    _run_parser(adhoc_cli, [])
    assert adhoc_cli.parser.description

    _run_parser(adhoc_cli, ['--check', '--module-name=ping', '--module-args=ping_args', 'pattern'])

    assert adhoc_cli.parser.description



# Generated at 2022-06-20 12:58:39.635826
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    ''' unit test to make sure adhoc CLI parsed correctly'''
    cli = AdHocCLI(['example.com', '-m', 'mymodule', '-a', '"param1=value1 param2=value2"'])
    opt = cli.parse()
    cli.post_process_args(opt)
    module_name = context.CLIARGS['module_name']
    assert module_name == 'mymodule'
    module_args = context.CLIARGS['module_args']
    assert module_args == 'param1=value1 param2=value2'

# Generated at 2022-06-20 12:58:42.082549
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad_hoc = AdHocCLI()
    assert ad_hoc.parser



# Generated at 2022-06-20 12:58:45.432684
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    display.verbosity = 3
    context.CLIARGS = {
        'listhosts': 'True',
        'module_name': 'command',
        'module_args': {'echo': 'Hello world'}
    }
    AdHocCLI().run()

# Generated at 2022-06-20 12:58:54.742007
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Instantiating an object of class AdHocCLI
    object = AdHocCLI()

    # Instantiating an object of class Namespace containing the command line arguments
    cmd_args = type('',(),{
        'one_line': False,
        'tree': False,
        'verbosity': 0,
        'inventory': '/etc/ansible/hosts',
        'module_path': None,
        'module_name': 'ping',
        'module_args': '',
    })()

    # Testing post_process_args method of class AdHocCLI
    try:
        assert object.post_process_args(cmd_args) == cmd_args
    except:
        assert False

# Generated at 2022-06-20 12:59:05.933815
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # The mock module module mocks an instance of class AdHocCLI
    mock_cli = AdHocCLI(args=[])

    # mock_options mocks the options namespace created by parser.parse_args()
    # The mock object is passed to the post_process_args method
    mock_options = opt_help.parse_options(mock_cli.parser, [
        '-a', 'echo hello world', '-m', 'command', 'localhost'
    ])

    mock_cli.post_process_args(mock_options)

    # get the CLI arguments from context, created by the post_process_args method's call to super()
    args = context.CLIARGS

    assert args['subset'] is None
    assert args['module_name'] == 'command'

# Generated at 2022-06-20 13:00:19.666483
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI()

# Generated at 2022-06-20 13:00:24.120141
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Test 1 : check argument is not parsed correctly

    cli = AdHocCLI(args=[])
    cli.init_parser()
    options, args = cli.parser.parse_args(['-m', 'ping', 'all'])
    options = cli.post_process_args(options)

    assert options.module_name == 'ping'


# Generated at 2022-06-20 13:00:27.732974
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Test with invalid options
    invalid_args = ['ansible', 'abc', 'xyz', '-vvvvv']
    with pytest.raises(SystemExit):
        AdHocCLI(args=invalid_args)



# Generated at 2022-06-20 13:00:37.805620
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import unittest.mock
    from ansible.utils.display import Display
    from ansible.parsing.splitter import parse_kv

    with unittest.mock.patch.object(Display, "vvv") as dv:
        with unittest.mock.patch.object(Display, "warning") as dw:
            with unittest.mock.patch.object(Display, "display") as dp:
                with unittest.mock.patch.object(ParallelCLI, "run") as pr:
                    adhoc = AdHocCLI()
                    adhoc.init_parser()
                    adhoc.post_process_args(adhoc.parser.parse_args("-m ping localhost".split()))
                    adhoc.run()
                    # check that the right play was

# Generated at 2022-06-20 13:00:46.871968
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Display:
        def __init__(self):
            self.verbosity = 0
        def display(self, msg):
            print(msg)


# Generated at 2022-06-20 13:00:50.487540
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # Test AdHocCLI class constructor with arguments
    adhoc_cli = AdHocCLI(['test_file'])

    # Test AdHocCLI class constructor without arguments
    #adhoc_cli = AdHocCLI()
    print(adhoc_cli.run())

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-20 13:00:55.132056
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args_list = (
        ['ansible', '-m', 'shell', '-a', 'foo', 'localhost'],
        ['ansible', '-m', 'shell', '-a', "'foo'", 'localhost']
    )
    for args in args_list:
        cli = AdHocCLI(args)
        cli.parse()
        cli.post_process_args(cli.options)

# Generated at 2022-06-20 13:01:00.413220
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    c = AdHocCLI()
    c.parser = c.create_parser()
    args = c.parser.parse_args(['-i', 'inventory.cfg', '-m', 'ping', 'all'])
    args = c.post_process_args(args)
    display.verbosity = 3
    assert args['verbosity'] == 3


# Generated at 2022-06-20 13:01:11.217467
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create a class to test the post_process_args method of class AdHocCLI
    # with the options received in the command line
    class Test_AdHocCLI(AdHocCLI):

        def __init__(self):
            pass

        def init_parser(self):
            super(AdHocCLI, self).init_parser(usage='%prog <host-pattern> [options]',
                                              desc="Define and run a single task 'playbook' against a set of hosts",
                                              epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")

            opt_help.add_runas_options(self.parser)
            opt_help.add_inventory_options(self.parser)

# Generated at 2022-06-20 13:01:15.686797
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''Unit test for method post_process_args of class AdHocCLI'''
    options = opt_help.create_base_parser(constants=C).parse_args([])
    options = AdHocCLI(base_parser=opt_help.create_base_parser(constants=C)).post_process_args(options)
    assert options.verbosity == 0