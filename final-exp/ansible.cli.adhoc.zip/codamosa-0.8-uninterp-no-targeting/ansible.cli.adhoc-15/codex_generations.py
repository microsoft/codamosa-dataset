

# Generated at 2022-06-20 12:51:56.589521
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    assert parser.usage == '%prog <host-pattern> [options]'
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert parser.add_argument_group.called
    assert parser._optionals.title == 'options'
    assert parser._positionals.title == 'arguments'
    assert parser.add_argument.called

# Generated at 2022-06-20 12:52:00.868868
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    my_AdHocCLI = AdHocCLI()

    assert my_AdHocCLI.parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-20 12:52:09.672453
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """
    AdHocCLI - run
    """
    from units.mock.loader import DictDataLoader
    adhoc = AdHocCLI(args=[])
    adhoc.parser = adhoc.create_parser()
    adhoc.options, adhoc.args = adhoc.parser.parse_args(args=[])

    # test when the host pattern is invalid, it will raise AnsibleError
    with pytest.raises(AnsibleError):
        adhoc.run()

    # test when the action is invalid and no host is specified, it will raise AnsibleError
    adhoc.options, adhoc.args = adhoc.parser.parse_args(args=['./host.pattern'])

# Generated at 2022-06-20 12:52:12.939475
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ad_hoc_cli = AdHocCLI(args=['-h'])
    assert ad_hoc_cli is not None
    '''
    pass

# Generated at 2022-06-20 12:52:22.807624
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    options = opt_help.add_options(['-k', '-K'])
    options.ask_pass = True
    options.ask_sudo_pass = True
    options.ask_su_pass = True

    cli = AdHocCLI()
    options_changed = cli.post_process_args(options)

    assert options_changed.ask_pass is True
    assert options_changed.ask_su_pass is True
    assert options_changed.ask_sudo_pass is True
    assert options_changed.ask_vault_pass is False
    assert options_changed.become is False
    assert options_changed.become_method is None
    assert options_changed.become_user is None

# Generated at 2022-06-20 12:52:31.711435
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    context.CLIARGS = {'module_args': 'opt1=val1 opt2=val2', 'module_name': 'ping', 'args': 'localhost', 'pattern': 'localhost'}
    options = context.CLIARGS
    adhoc = AdHocCLI()
    adhoc.run()
    """
    25-02-19  11:41
    Test is running. Please wait...

    Test results:
        status: failed
        failed: 1
        passed: 0
        errors: 1
    """

# Generated at 2022-06-20 12:52:40.372447
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''
    ansible-playbook CLI.init_parser() unit test
    :return:
    '''
    cli = AdHocCLI(['--version'])

    # Verify parser usage
    assert cli.parser.usage == "%prog <host-pattern> [options]"

    # Verify parser epilog
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

    # Verify parser description
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-20 12:52:53.168921
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ad_hoc = AdHocCLI(None)
    class FakeOptions():
        verbosity = 1
        subset = None
        listhosts = None
        module_name = 'ping'
        module_args = None
        forks = 1
        one_line = False
        tree = None
        seconds = None
        poll_interval = None
        ask_pass = False
        ask_su_pass = False
        ask_sudo_pass = False
        ask_vault_pass = False
        vault_password_file = None
        become = False
        become_method = 'sudo'
        become_user = None
        become_ask_pass = False
        tags = None
        skip_tags = None
        check = False
    context.CLIARGS = FakeOptions()
    class FakeHost():
        port = 22


# Generated at 2022-06-20 12:52:56.422150
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    This is a basic unit test to make sure ad-hoc cli is initialized properly
    """
    try:
        AdHocCLI()
    except (AttributeError, TypeError):
        assert False
    else:
        assert True

# Generated at 2022-06-20 12:53:03.515571
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    adhoc = AdHocCLI([])
    options = adhoc.parse()

    adhoc._options = options
    options = adhoc.post_process_args(options)

    assert options.runas == 'root'
    assert options.forks == 1
    assert options.timeout == 600
    assert options.verbosity == 0
    assert options.connection == 'smart'
    assert options.check == False

# Generated at 2022-06-20 12:53:13.640091
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(None)
    adhoc.parse()

# Generated at 2022-06-20 12:53:22.957888
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()

    # Following is the dict that would be returned from OptionParser.parse_args()

# Generated at 2022-06-20 12:53:29.256148
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import copy
    from ansible.cli.adhoc import AdHocCLI
    from ansible.errors import AnsibleOptionsError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager

    # set up some objects we need in order to test the AdHocCLI run() method
    current_path = os.path.dirname(os.path.realpath(__file__))
    hosts_path = os.path.join(current_path, '../../inventory/test_inventory.ini')
    private_

# Generated at 2022-06-20 12:53:32.851317
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"

# Generated at 2022-06-20 12:53:42.505649
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Initialize ansible options
    context.CLIARGS = {}

    # Create an AdHocCLI instance and add options described in docstring
    cli = AdHocCLI()
    cli.init_parser()

    # Case 1: Default options
    # Parse arguments
    args = cli.parser.parse_args([])
    options = cli.post_process_args(args)

    # Check if playbook name is empty
    assert options.playbook is None

    # Check if inventory is default
    assert options.inventory == C.DEFAULT_HOST_LIST

    # Check if module name is default
    assert options.module_name == C.DEFAULT_MODULE_NAME

    # Case 2: Non-default options
    # Parse arguments

# Generated at 2022-06-20 12:53:43.628640
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI()

# Generated at 2022-06-20 12:53:56.204838
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Create a class object
    obj = AdHocCLI(
        ['--ask-pass', '--ask-become-pass', '--list-hosts', '--module-name', 'ping',
         '--one-line', '--output=foo.txt', '--tree=./output', '--verbose',
         '--connection=local', '--cache-connection', '--timeout=10',
         '--limit=testhost1', '--ssh-common-args=test', '--sftp-extra-args=test',
         '--scp-extra-args=test', '--ssh-extra-args=test', '--ask-vault-pass',
         '127.0.0.1', '--vault-password-file=./vault_pass.txt', '-v', '-vvvv'])

# Generated at 2022-06-20 12:53:59.349427
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # AdHocCLI.run is currently not unit tested but it is
    # important to have full coverage of this file,
    # therefore this function exists to increase the coverage.
    pass

# Generated at 2022-06-20 12:54:09.865509
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    option_parser = adhoc.get_optparser()
    # The option_parser object should have the add_connection_options method
    assert hasattr(option_parser, 'add_connection_options')
    # The option_parser object should have the add_runtask_options method
    assert hasattr(option_parser, 'add_runtask_options')
    # The option_parser object should have the add_module_options method
    assert hasattr(option_parser, 'add_module_options')
    # The option_parser object should have the add_tasknoplay_options method
    assert hasattr(option_parser, 'add_tasknoplay_options')
    # The option_parser object should have the add_async_options method

# Generated at 2022-06-20 12:54:12.382121
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: write unit tests for AdHocCLI.run()
    # Consider whether to test all code paths, or just code paths
    # with significant logic.
    assert False

# Generated at 2022-06-20 12:54:31.829263
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    # Test the default option is False
    assert not adhoc.parser._optionals._long_opt.get('listhosts')
    # Test the default option is False
    assert not adhoc.parser._optionals._long_opt.get('subset')
    # Test the default option is '-'
    assert adhoc.parser._optionals._long_opt.get('inventory')[0].default is '-'
    # Test the default option is False
    assert not adhoc.parser._optionals._long_opt.get('syntax')
    # Test the default option is False
    assert not adhoc.parser._optionals._long_opt.get('connection')[0].default
    # Test the default option is False
    assert not adhoc.parser._optionals._long

# Generated at 2022-06-20 12:54:43.846664
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Instantiate class
    adhoc = AdHocCLI('test_AdHocCLI_run')

    # Mock the exec_rc file 
    adhoc.exec_rc = '/tmp/test_AdHocCLI_run.rc'

    # Create a mocked object to replace 'adhoc.run' method
    # This object will be called instead of the original method

# Generated at 2022-06-20 12:54:45.088680
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    assert AdHocCLI().args == []


# Generated at 2022-06-20 12:54:46.293762
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

if __name__ == '__main__':
    test_AdHocCLI_run()

# Generated at 2022-06-20 12:54:46.802818
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    pass

# Generated at 2022-06-20 12:54:59.176824
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """verify the return value for AdHocCLI.post_process_args()

    :return:
    """
    parser = AdHocCLI(['-m', 'shell', 'all', 'uname'])
    options = parser.parse()
    options = parser.post_process_args(options)
    assert options.verbosity == 0
    assert options.ask_pass == True
    assert options.module_name == 'shell'
    assert options.module_args == 'uname'
    assert options.async_val == None
    assert options.poll_interval == 10
    assert options.one_line == False
    assert options.tree == None
    assert options.check == False
    assert options.forks == 5
    assert options.subset == None
    assert options.listhosts == False
    assert options

# Generated at 2022-06-20 12:55:00.610938
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI([])


# Generated at 2022-06-20 12:55:09.909580
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options = adhoc_cli.options

# Generated at 2022-06-20 12:55:12.348695
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI() # adhoc class of cli.py
    adhoc.run()
    #assert data == 'some return value'

# Generated at 2022-06-20 12:55:14.521750
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

##  Management of argument parsing for command line


# Generated at 2022-06-20 12:55:37.554583
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Check that CLI help message contains the summary of bin/ansible
    cli = AdHocCLI([])
    cli.init_parser()
    help_message = cli.parser.format_help()
    assert 'The official Ansible command line tool' in help_message
    assert 'Define and run a single task \'playbook\' against a set of hosts' in help_message


# Generated at 2022-06-20 12:55:40.470743
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # AdHocCLI object
    adhoccli = AdHocCLI()
    # AdHocCLI object has method run
    assert callable(adhoccli.run)

# Generated at 2022-06-20 12:55:42.586142
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    obj = AdHocCLI(['arg1', 'arg2'])
    assert obj.parser

# Generated at 2022-06-20 12:55:48.537730
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options = adhoc_cli.parser.parse_args(["host1", "-m", "shell", "-a", "id"])
    adhoc_cli.post_process_args(options)
    assert options.module_name == "shell"
    assert options.module_args == "id"
    assert options.args == "host1"


# Generated at 2022-06-20 12:55:50.349491
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # AdHocCLI().init_parser()
    pass  # TODO


# Generated at 2022-06-20 12:55:52.468587
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Calls constructor of class AdHocCLI
    a = AdHocCLI([])
    return a

# Generated at 2022-06-20 12:55:52.983736
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:56:03.952256
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()

    # assert initial values are properly set
    # None values are tested as an empty string
    assert(cli.parser is None)
    assert(cli.options is None)
    assert(cli.args == '')
    assert(cli.action == 'run')
    assert(cli.passwords == {})

    cli.init_parser()
    assert(cli.parser is not None)

    args = cli.parser.parse_args([])
    assert(args.subset == '')
    assert(args.listhosts == False)
    assert(args.listtasks == False)
    assert(args.listtags == False)
    assert(args.syntax == False)
    assert(args.sudo_user == '')
    assert(args.remote_user == '')
   

# Generated at 2022-06-20 12:56:14.530399
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    mocker = Mocker()
    args = ['host_pattern']
    options = MagicMock()
    options.module_name = None
    options.module_args = None
    options.listhosts = False
    options.subset = None
    options.verbosity = 0
    options.one_line = False
    options.tree = None
    options.ask_vault_pass = False
    options.vault_password_files = []
    options.new_vault_password_file = None
    options.output_file = None
    options.become = False
    options.become_method = None
    options.become_user = None
    options.ask_become_pass = False
    options.become_ask_pass = False
    options.ask_pass = False
    options.private_key_

# Generated at 2022-06-20 12:56:16.477452
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli

# Generated at 2022-06-20 12:56:50.444292
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    pass

# Generated at 2022-06-20 12:57:01.160170
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    # nargs=1
    cli.parser.add_argument('-t', '--timeout', nargs=1)
    # nargs='+'
    cli.parser.add_argument('-P', '--priority', nargs='+')
    # argparse.REMAINDER
    cli.parser.add_argument('--extra-vars', nargs=argparse.REMAINDER)
    # no nargs specified
    cli.parser.add_argument('-T', '--tags', dest='tags', default='all')

    options = cli.post_process_args(('-t', '3600', '-P', 'high', '-P', 'medium', '-T', 'foo', '-T', 'bar'))


# Generated at 2022-06-20 12:57:11.041762
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI()
    args = ['-m', 'ping', '-a', '"myarg=myval"', '-u', 'myuser', '-k', '-K', '-c', 'myconn', '-a', '"arg2=val2"', 'all']
    options = adhoc.parser.parse_args(args)
    options = adhoc.post_process_args(options)
    assert options.connection == 'myconn'
    assert options.module_name == 'ping'
    assert options.module_args == '"myarg=myval" "arg2=val2"'
    assert options.ask_pass
    assert options.ask_su_pass
    assert options.remote_user == 'myuser'

# Generated at 2022-06-20 12:57:13.833577
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    assert AdHocCLI(args=['ansible', 'all', '-m', 'ping'])
    # test for when missing required argument
    try:
        AdHocCLI(args=['ansible', 'all', '-m'])
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-20 12:57:23.271838
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse

    adhoc_cli = AdHocCLI(['k='])
    adhoc_cli.options = argparse.Namespace()

    adhoc_cli.options.ask_pass = False
    adhoc_cli.options.ask_become_pass = False
    adhoc_cli.options.ask_su_pass = False
    adhoc_cli.options.ask_su_pass = False
    adhoc_cli.options.verbosity = 0
    adhoc_cli.options.subset = False

    adhoc_cli.options.listhosts = False
    adhoc_cli.options.tags = []
    adhoc_cli.options.one_line = False
    adhoc_cli.options.tree = None

# Generated at 2022-06-20 12:57:24.498041
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:57:34.302679
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Call load to setup the tests
    loader = CLI.load()

    # Create an instance of the CLI adhoc class
    cli_adhoc = AdHocCLI(args=[])
    cli_adhoc._play_prereqs = lambda: (loader.load_from_file('/path/to/playbook/tasks.py'), None, None)

    # Test run with empty arguments
    try:
        cli_adhoc.run()
    except AnsibleOptionsError:
        pass

    # Set the module name
    cli_adhoc.post_process_args({'module_name': 'test'})

    # Test run with no argument passed to the module_name
    try:
        cli_adhoc.run()
    except AnsibleOptionsError:
        pass

    cli_adhoc.post

# Generated at 2022-06-20 12:57:45.791449
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Tests for method post_process_args of class AdHocCli
    options = AdHocCLI().options_array[:]
    options.extend(['-m', 'copy', '-a', 'test=test', 'host'])
    # Test without args module_args

# Generated at 2022-06-20 12:57:49.579545
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Make sure we are calling actual methods and not stubs
    assert AdHocCLI.run.__module__ == 'ansible.cli.adhoc'

    # Make sure we get back an integer
    assert isinstance(AdHocCLI.run(None), int)


# Generated at 2022-06-20 12:57:50.187922
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:59:00.726837
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # There is no actual test here at this moment.
    # Just trying to instantiate the class for code coverage.
    cli = AdHocCLI()

# Generated at 2022-06-20 12:59:09.061047
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    """
    Test the ansible-adhoc cli init_parser method

    """
    # create an instance of AdHocCLI class
    # to access the init_parser method
    adhoc_cli = AdHocCLI()

    # create an instance of the ArgumentParser class
    # to access the prog attribute which is set to
    # the name of the program (ansible-adhoc)
    parser = adhoc_cli.parser

    # assert the name of the program is ansible-adhoc
    assert parser.prog == 'ansible-adhoc'

    # assert parser description
    description = "Define and run a single task 'playbook' against a set of hosts"
    assert parser.description == description

    # assert epilog

# Generated at 2022-06-20 12:59:16.524666
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    context.CLIARGS = {}
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['inventory'] = None
    context.CLIARGS['subset'] = ''
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = ''
    context.CLIARGS['task_timeout'] = 60
    context.CLIARGS['args'] = ['127.0.0.1']
    context.CLIARGS['seconds'] = None
    context.CLIARGS['poll_interval'] = value = 5
    context.CLIARGS['one_line'] = False
    context.CLIARGS['tree'] = None
    context.CLIAR

# Generated at 2022-06-20 12:59:23.932969
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['-i','test_inventory','test_host','test_module_name','test_module_args','test_subset','test_forks','test_module_path','test_listhosts','-v']

    cli = AdHocCLI()
    cli.init_parser()
    options, args = cli.parser.parse_args(args)
    options = cli.post_process_args(options)

    assert options.inventory == 'test_inventory'
    assert options.subset == 'test_subset'
    assert options.module_path == 'test_module_path'
    assert options.forks == 'test_forks'
    assert options.listhosts == True
    assert options.module_name == 'test_module_name'

# Generated at 2022-06-20 12:59:25.258116
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    result = adhoc.init_parser()
    assert result is None

# Generated at 2022-06-20 12:59:27.493974
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert isinstance(adhoc_cli, AdHocCLI)

# Generated at 2022-06-20 12:59:30.324561
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Establish that AdHocCLI instantiates correctly
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-20 12:59:37.213426
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-a', 'uptime'])
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc.parser.description == '''Define and run a single task 'playbook' against a set of hosts'''
    assert adhoc.parser.epilog == '''Some actions do not make sense in Ad-Hoc (include, meta, etc)'''

# Generated at 2022-06-20 12:59:47.881312
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()

    # Construct a dummy parser and dummy args values
    class DummyParser(object):
        def __init__(self):
            self.module_name = 'command'
            self.module_args = 'touch /tmp/test'
            self.listhosts = False
            self.subset = None
            self.verbosity = 1
            self.ask_pass = False
            self.ask_sudo_pass = False
            self.ask_su_pass = False
            self.ask_vault_pass = False
            self.timeout = None
            self.inventory = ''
            self.extra_vars = []
            self.forks = 5
            self.args = 'localhost'

    class DummyArgs(object):
        def __init__(self):
            self.module_

# Generated at 2022-06-20 12:59:54.404564
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    options = parser.parse_args(['-h'])
    assert options.verbosity == 0
    options = parser.parse_args(['-vvvv'])
    assert options.verbosity == 4
    options = parser.parse_args(['-vv'])
    assert options.verbosity == 2
    options = parser.parse_args(['-vv', '-vv'])
    assert options.verbosity == 4
    options = parser.parse_args(['--vault-password-file', '~/foo'])
    assert options.vault_password_file == '~/foo'
    options = parser.parse_args(['--ask-vault-pass'])
    assert options.ask_vault_pass is True