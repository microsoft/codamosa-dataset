

# Generated at 2022-06-20 12:51:57.552810
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Pass
    ad_hoc_cli = AdHocCLI()
    ad_hoc_cli.run()
    # Fail
    ad_hoc_cli = AdHocCLI()
    context.CLIARGS['module_name'] = "debug"
    ad_hoc_cli.run()

# Generated at 2022-06-20 12:52:00.783209
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli


# Generated at 2022-06-20 12:52:09.606109
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI

    # Create instance of AdHocCLI
    adhoc_cli = AdHocCLI()

    # Create a list of arguments
    argv = [
        'ansible',
        '/home/david/GitLab/ansible-2.8.2/test/integration/targets',
        '-i',
        '/home/david/GitLab/ansible-2.8.2/test/integration/inventory',
        '-m',
        'ping',
        '-vvvv'
    ]

    # Call method
    result = adhoc_cli.run(args=argv)

    # Assertions

    # Value should be
    assert result == 0, 'Value should be 0'

# Generated at 2022-06-20 12:52:15.012359
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    cli.init_parser()
    #  AssertionError: <test_ansiballz.ActionModule object at 0x7f5b0f5244a8> != <ansible.cli.adhoc.AdHocCLI object at 0x7f5b0f5243c8>

# Generated at 2022-06-20 12:52:24.796151
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    def _res(host_list):
        class _res(object):
            def __init__(self, host_list):
                self.host_list = host_list
            def get_host_list(self, *args):
                return self.host_list
        return _res(host_list)

    res = _res(['tgt'])
    cli_adhoc = AdHocCLI(args=[], callback=None, res=res)

# Generated at 2022-06-20 12:52:26.069124
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI()


# Generated at 2022-06-20 12:52:31.335342
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli._init_parser()
    assert cli.parser.usage == '%prog <host-pattern> [options]'

    cli.parser.exit = lambda _: None
    with pytest.raises(SystemExit):
        cli.parser.parse_args(['-h'])

# Generated at 2022-06-20 12:52:44.469289
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.options = \
        {
            'module_name': 'command',
            'module_args': 'ls',
            'forks': 2,
            'check': True,
            'inventory': '/path/to/inventory/file',
            'pattern': '.',
            'verbosity': 1,
            'listhosts': True
        }

    cli.post_process_args(cli.options)
    assert cli.options['verbosity'] == 1
    assert not cli.options['check']
    assert not cli.options['listhosts']

    # Force some verbosity levels so we know what's happening in the tests.
    cli.options['verbosity'] = 0
    cli.options['check'] = True

# Generated at 2022-06-20 12:52:48.064372
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ad = AdHocCLI(args=['-f', '10', '-m', 'ping', 'localhost'])
    ad.parse()
    ad.post_process_args(ad.options)
    '''
    pass

# Generated at 2022-06-20 12:52:54.584571
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """This is a unit test for AdHocCLI class"""
    adhoc = AdHocCLI()
    assert bool(adhoc) is True, "Unable to create adhoc object"
    assert bool(adhoc.get_optparser() ) is True, "Unable to create get_optparser function"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 12:53:06.473664
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    Constructor test for class AdHocCLI
    '''
    adhoc_cli = AdHocCLI()


# Generated at 2022-06-20 12:53:14.058147
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    import cutlass
    cmd = AdHocCLI(
        ['-a', 'test_args', '-m', 'test_module_name', 'test_args']
    )

    # Make sure the option doesn't already exist
    assert not hasattr(cmd.parser, 'module_name')
    assert not hasattr(cmd.parser, 'module_args')

    cmd.init_parser()

    assert hasattr(cmd.parser, 'module_name')
    assert hasattr(cmd.parser, 'module_args')



# Generated at 2022-06-20 12:53:15.221849
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # FIXME: not implemented
    pass

# Generated at 2022-06-20 12:53:16.866870
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert isinstance(adhoc.parser, CLI.parser)

# Generated at 2022-06-20 12:53:20.197222
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    version = "version"
    ansible_version = "ansible_version"
    ansible_cmd = "ansible_command"
    ansible_base_dir_tmp = "base_dir"
    src_ansible_base_dir = "src_base_dir"

    AdHocCLI(version, ansible_version, ansible_cmd, ansible_base_dir_tmp, src_ansible_base_dir)



# Generated at 2022-06-20 12:53:21.725006
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    runner = AdHocCLI()
    parser = runner.init_parser()
    assert parser

# Generated at 2022-06-20 12:53:26.791517
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc = AdHocCLI([])
    # pylint: disable=protected-access
    adhoc._options = adhoc.parser.parse_args([])
    adhoc.post_process_args(adhoc._options)
    assert adhoc._options.subset is None
    adhoc._options.subset = 'test'
    adhoc.post_process_args(adhoc._options)
    assert adhoc._options.subset == 'test'
    # pylint: enable=protected-access

# Generated at 2022-06-20 12:53:33.730322
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ad = AdHocCLI([])
    mock_parser = ad.init_parser()

    assert mock_parser.prog == 'ansible'
    assert mock_parser.usage == '%prog <host-pattern> [options]'
    assert mock_parser.description.startswith('Define and run a single task')
    assert mock_parser.epilog.startswith('Some actions')

# Generated at 2022-06-20 12:53:43.143234
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    # If we raise an error in this test, we should not hit the code
    # that prints the exception to stderr.
    def mock_exit(rc):
        raise rc


# Generated at 2022-06-20 12:53:45.430880
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''Unit test for method run of class AdHocCLI'''
    pass

# Generated at 2022-06-20 12:53:54.665155
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI([])
    adhoc_cli.run()

# Generated at 2022-06-20 12:53:57.789224
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser is not None


# Generated at 2022-06-20 12:54:03.526154
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import pytest
    from ansible.errors import AnsibleError

    input_args = ['host-pattern']
    opts = CLI._parse_cli_args(input_args)[0]

    adhoc = AdHocCLI(args=input_args)
    adhoc.options = opts
    with pytest.raises(AnsibleOptionsError):
        adhoc.run()

# Generated at 2022-06-20 12:54:13.779900
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    def _test_AdHocCLI_post_process_args_test_name(arguments, expected_output):
        options = CLI(args=arguments.split()).parse()[0]
        adhoc = AdHocCLI()
        options = adhoc.post_process_args(options)
        assert options.module_name == expected_output

    tests = dict(
        test_single_module_name=['-m testmodule', 'testmodule'],
        test_single_module_name_with_spaces=['-a "foo=bar" -m testmodule', 'testmodule'],
        test_no_module_name_defaults_to_command=['-a "foo=bar"', 'command'],
    )


# Generated at 2022-06-20 12:54:24.173420
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class MockOptions:
        connection = "smart"
        module_name = "ping"
        module_args = "data=blah"
        inventory = None
        verbosity = 1
        subset = None
        timeout = 1
        background = 10
        poll_interval = 1
        forks = 1
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        vault_password_file = None

    cli = AdHocCLI()
    cli.options = MockOptions()
    cli.args = ['all']

    # Throw Assertion error as connection argument is not supported in AdHoc CLI

# Generated at 2022-06-20 12:54:26.738457
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    a = AdHocCLI(args=['localhost', '-m', 'ping'])
    x = a.run()
    assert (x == 0)

# Generated at 2022-06-20 12:54:35.313382
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create object AdHocCLI
    adhoc_cli = AdHocCLI()

    # Create object OptionParser
    optparser = opt_help.create_optparser(adhoc_cli.parser, adhoc_cli.version)

    # Create options
    options = optparser.parse_args(['-b', '-K', '-M', '-B', '-P', '-A', '-v',
                                    'test_all/test_modules/test_setup.yml', 'test_playbook_paths/.'])[0]

    # Call method post_process_args
    result = adhoc_cli.post_process_args(options)

    # Assert results
    assert result is not None
    assert result.become == True
    assert result.become_ask_pass == True

# Generated at 2022-06-20 12:54:36.801885
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:54:46.351494
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Test the AdHocCLI post_process_args method.

    :param self: self
    :return: None
    '''
    import ansible.constants as C

    # test empty options
    class MyAdHocCLI(AdHocCLI):
        def __init__(self, args):
            super(AdHocCLI, self).__init__(args)

# Generated at 2022-06-20 12:54:58.664718
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class DummyAdHocCLI(AdHocCLI):
        def get_host_list(self, inventory, subset, pattern):
            return ['www']

        def ask_passwords(self):
            return (None, None)

        def init_parser(self):
            super(DummyAdHocCLI, self).init_parser()
            self.parser.add_argument('-f', '--forks', dest='forks', type=int, default=C.DEFAULT_FORKS,
                                     help='Specify number of parallel processes to use (default=%(default)s)')

    context.CLIARGS = opt_help.parse_args(args=['-m', 'ping', '-a', 'data=hello world', 'www'])


# Generated at 2022-06-20 12:55:17.939131
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    test the constructor of class AdHocCLI
    :return:
    '''
    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)

# Generated at 2022-06-20 12:55:23.956203
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' unit test for AdHocCLI.init_parser() '''

    # test that init_parser() will set the description and epilog
    test_cli = AdHocCLI()
    test_cli.init_parser()
    assert test_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert test_cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"



# Generated at 2022-06-20 12:55:30.807500
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class options(object):
        listhosts = False
        subset = None
        module_paths = None
        pattern = 'host_name'
        forks = 5
        module_name = 'ping'
        remote_user = 'root'
        private_key_file = '/dev/null'
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = 'root'
        verbosity = 3
        connection = 'smart'
        timeout = 50
        ask_pass = False
        ask_become_pass = False
        ask_sudo_pass = False
        ask_vault_pass = False
        vault_password_files = None
        new_v

# Generated at 2022-06-20 12:55:38.314478
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert cli.parser._prog == 'ansible'
    assert cli.parser.description == 'Define and run a single task \'playbook\' against a set of hosts'
    assert cli.parser.epilog == 'Some actions do not make sense in Ad-Hoc (include, meta, etc)'
    assert isinstance(cli.parser, CLI.OptionParser)


# Generated at 2022-06-20 12:55:39.171635
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    assert True

# Generated at 2022-06-20 12:55:40.664643
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    cli.run()

# Generated at 2022-06-20 12:55:45.910288
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # pylint: disable=protected-access
    assert AdHocCLI()._post_process_args(
        {'module_name': 'shell', 'module_args': 'uptime', 'one_line': True}
    ) == {'module_name': 'shell', 'module_args': 'uptime', 'one_line': True}

# Generated at 2022-06-20 12:55:46.933484
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    AdHocCLI(None)

# Generated at 2022-06-20 12:55:55.681222
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()

    adhoc.init_parser()
    options = adhoc.parser.parse_args(['-i', 'hosts.yml', 'host', '-m', 'command', '-a', 'howdy=hello',
                                       '-c', 'paramiko', '-f', '10', '--private-key', 'key.pem',
                                       '--extra-vars', '@passwd.yml', '--tags', 'tag1,tag2', '--skip-tags', 'tag3,tag4',
                                       '--become', '--become-user=root', '--become-method=sudo',
                                       '--ask-become-pass', '--start-at-task', 'mytask'])

# Generated at 2022-06-20 12:55:59.580547
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''
    return the namespace object based on the given
    command line arguments `args`
    '''
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()


# Generated at 2022-06-20 12:56:37.742935
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    args = ''
    cli = AdHocCLI(args)

    assert cli.parser._prog_name == 'ansible'
    assert cli.parser._usage == '%prog <host-pattern> [options]'

# Generated at 2022-06-20 12:56:38.490143
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:56:48.011557
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # we test if this function throws any exceptions
    try:
        cli = AdHocCLI()
        parser = cli.init_parser()
    except Exception as e:
        assert False, e

    assert parser._prog == 'ansible'
    assert parser.usage == '%prog <host-pattern> [options]'
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert len(parser._positionals._group_actions) == 1
    assert len(parser._optionals._group_actions) == 23
    assert parser._positionals._group_actions[0].dest == 'args'
    assert parser._positionals._group_actions[0].help

# Generated at 2022-06-20 12:56:54.266468
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # We need to create ad-hoc cli object to call init_parser method
    adhoc_cli = AdHocCLI()
    # Create argparse object
    parser = adhoc_cli.init_parser()
    # This method returns parser object, we need to check if we are getting an instance of ArgumentParser
    assert isinstance(parser, opt_help.ArgumentParser)


# Generated at 2022-06-20 12:56:56.611759
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI(['-h'])
    # Assert that the parser exists
    assert(adhoc.parser)


# Generated at 2022-06-20 12:57:03.702027
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Dummy instance of class AdHocCLI
    obj = AdHocCLI()
    # Dummy options object
    options = opt_help.create_base_parser('').parse_args([])
    # Empty dict
    context.CLIARGS = {}
    options = obj.post_process_args(options)
    assert options.verbosity == 0
    assert context.CLIARGS['subset'] is None
    options = obj.post_process_args(options)
    assert options.verbosity == 0

# Generated at 2022-06-20 12:57:13.255349
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Options(object):
        module_name = 'shell'
        module_args = 'echo "hello world"'
        pattern = 'testpattern'
        listhosts = False
        forks = 5
        verbosity = 0
        inventory = None
        subset = None
        connection = 'local'
        timeout = 10
        remote_user = None
        remote_pass = None
        become = False
        become_method = 'sudo'
        become_user = None
        become_pass = None
        check = False
        diff = False
        symbols = None
        private_key = None
        args = 'test pattern'
        seconds = None
        poll_interval = 0
        ask_pass = False
        ask_sudo_pass = False
        ask_su_pass = False
        vault_pass = None

# Generated at 2022-06-20 12:57:22.827269
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import add_host_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import MergeVars

    # instantiate
    adhoc_cli = AdHocCLI()

    # create mock inventory
    inventory = FakeInventory()

    # mock plugins
    plugin_loader = FakePluginLoader()

    # create mock variable manager
    variable_manager = FakeVariableManager()

# Generated at 2022-06-20 12:57:27.357084
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI(['-a', 'module_args', '-m', 'module_name'])
    parser = adhoc.init_parser()
    assert parser

    #argv = ['-m', 'ping', 'all']
    #args = parser.parse_args(argv)


# Generated at 2022-06-20 12:57:30.672164
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ad_hoc_cli = AdHocCLI()

    assert isinstance(ad_hoc_cli, AdHocCLI)
    assert ad_hoc_cli.parser is not None


# Generated at 2022-06-20 12:58:49.514043
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys, six

    sys.modules['ansible'].Options = lambda: None
    sys.modules['ansible'].Options.connection = 'paramiko'
    sys.modules['ansible'].Options.forks = 1
    sys.modules['ansible'].Options.become = True
    sys.modules['ansible'].Options.become_method = 'sudo'
    sys.modules['ansible'].Options.become_ask_pass = False
    sys.modules['ansible'].Options.become_user = 'root'
    sys.modules['ansible'].Options.verbosity = 3
    sys.modules['ansible'].Options.remote_user  = 'test'
    sys.modules['ansible'].Options.private_key_file  = 'test'
    sys.modules['ansible'].Options

# Generated at 2022-06-20 12:58:53.761363
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=["test_host"])
    assert adhoc

if __name__ == '__main__':
    adhoc = AdHocCLI(args=["test_host"])
    adhoc.parse()
    adhoc.run()

# Generated at 2022-06-20 12:58:56.094397
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # TODO: add tests for AdHocCLI's init_parser method
    # SEE: https://github.com/ansible/ansible/pull/37153#issuecomment-287410890
    assert 0 == 0

# Generated at 2022-06-20 12:59:07.042092
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    class mock_parser(object):
        '''Mock parser class'''
        def __init__(self):
            self.added_args = []

        def add_argument(self, *args, **kwargs):
            self.added_args.append((args, kwargs))

    class mock_parser2(object):
        def __init__(self):
            self.added_args = []

        def add_argument(self, *args, **kwargs):
            self.added_args.append((args, kwargs))

    mock_parser_ins = mock_parser()
    AdHocCLI(parser=mock_parser_ins).init_parser()

    # Test for the method init_parser

# Generated at 2022-06-20 12:59:12.204192
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(["test_AdHocCLI","-a","-m"])
    assert type(adhoc) == AdHocCLI
    assert adhoc.run() == 0


# Generated at 2022-06-20 12:59:24.164426
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # create an options parser for bin/ansible
    parser = CLI.base_parser(usage='%prog <host-pattern> [options]',
                             desc="Define and run a single task 'playbook' against a set of hosts",
                             epilog="Some actions do not make sense in Ad-Hoc (include, meta, etc)")

    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_async_options(parser)
    opt_help.add_output_options(parser)
    opt_help.add_connect_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_runtask_options(parser)

# Generated at 2022-06-20 12:59:35.480993
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:59:38.297221
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    args = ['127.0.0.1']
    cli = AdHocCLI(args)
    assert cli.parser.prog == 'ansible'

# Generated at 2022-06-20 12:59:38.835291
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:59:48.195329
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''
    Test method init_parser of class AdHocCLI
    '''
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Call method init_parser
    adhoc_cli.init_parser()

if __name__ == '__main__':
    # unit test this module
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    display = Display()
    display.verbosity = 3
    test_AdHocCLI_init_parser()