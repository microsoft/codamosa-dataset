

# Generated at 2022-06-20 12:52:05.602188
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Options(object):
        ask_pass = False
        check = False
        connection = 'ssh'
        diff = False
        fork = 5
        inventory_file = './tests/inventory'
        module_path = ''
        remote_user = C.DEFAULT_REMOTE_USER
        subset = None
        vault_password_file = './tests/vault_password_file'
        verbosity = 0

    options = Options()

    ad_hoc_cli = AdHocCLI(args = ['h1,h2'])
    ad_hoc_cli.post_process_args(options)

    assert context.CLIARGS['ask_pass'] == options.ask_pass
    assert context.CLIARGS['check'] == options.check
    assert context.CLIARGS['connection'] == options.connection

# Generated at 2022-06-20 12:52:12.836062
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import mock
    import tempfile
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help

    required_args = {}
    kallable = CLI()
    kallable.init_parser()
    # set version
    kallable.parser.version = 'ansible-playbook 2.8.1'
    opt_help.add_runas_options(kallable.parser)
    opt_help.add_inventory_options(kallable.parser)
    opt_help.add_async_options(kallable.parser)
    opt_help.add_output_options(kallable.parser)
    opt_help.add_connect_options(kallable.parser)
    opt_help.add_check_options(kallable.parser)


# Generated at 2022-06-20 12:52:21.710108
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    '''
    Function to test method post_process_args of class AdHocCLI.
    '''
    args = ['-m', 'ping', '-a', '1 2 3', 'host1', 'host2']
    options = CLI.base_parser(args[0], args[1:])
    obj = AdHocCLI(args)
    ret = obj.post_process_args(options)
    assert ret.module_name == 'ping'
    assert ret.module_args == '1 2 3'
    assert ret.args[0] == 'host1'
    assert ret.args[1] == 'host2'

# Generated at 2022-06-20 12:52:34.015072
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create an instance of AdHocCLI
    adHocCLI = AdHocCLI()

    # call the method init_parser.
    adHocCLI.init_parser()

    # Get parser of this instance
    parser = adHocCLI.parser

    # Get all of options of parser
    options = parser._option_string_actions
    
    # Verify there are correct number of options

# Generated at 2022-06-20 12:52:47.072815
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    def set_values(args):
        args.connection            = 'local'
        args.module_path           = None
        args.forks                 = None
        args.become                = False
        args.become_method         = 'sudo'
        args.become_user           = None
        args.check                 = False
        args.diff                  = False
        args.listhosts             = None
        args.listtasks             = None
        args.listtags              = None
        args.syntax                = None
        args.vault_password_file   = None
        args.verbosity             = 0
        args.ask_vault_pass        = False
        args.ask_pass              = False
        args.private_key_file      = None
        args.remote_user           = None

# Generated at 2022-06-20 12:52:55.157185
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Options:
        check = None
        listhosts = None
        module_path = None
        one_line = None
        subset = None
        vault_password_file = None
        verbosity = None

    options = Options()
    # Test with empty vault password
    context.CLIARGS = dict(vault_password_files=None)
    ad_hoc_cli = AdHocCLI()
    options = ad_hoc_cli.post_process_args(options)
    assert options.check == False
    assert options.listhosts == False
    assert options.one_line == False
    assert options.subset == None
    assert options.vault_password_file == None
    assert options.verbosity == 0

    # Test with two vault passwords

# Generated at 2022-06-20 12:53:06.747897
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class ParseResult:
        inventory = ''
        module_name = ''
        module_args = ''
        forks = ''
        private_key_file = ''
        ask_vault_pass = ''
        verbosity = ''
        ask_pass = ''
        subset = ''
        check = ''
        diff = ''
        extra_vars = ''
        vault_password_files = ''
        output_file = ''
        run_once = ''
        connection = ''
        timeout = ''
        remote_user = ''
        connection_user = ''
        sudo = ''
        sudo_user = ''
        vault_ids = ''
        ask_sudo_pass = ''
        ask_su_pass = ''
        listhosts = ''
        subset = ''
        module_path = ''
        become = ''

# Generated at 2022-06-20 12:53:15.992471
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """
    (Unit Test) test_AdHocCLI_post_process_args: post_process_args removes the 'args' arg from the context.
    """
    adhoc = AdHocCLI(['arg1', 'arg2', 'arg3'])
    adhoc.parse()

    assert 'args' in context.CLIARGS

    adhoc.post_process_args(adhoc.parser.parse_args(['arg1', 'arg2', 'arg3']))

    assert 'args' not in context.CLIARGS
    assert context.CLIARGS['args'] == ['arg1', 'arg2', 'arg3']

# Generated at 2022-06-20 12:53:20.991922
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    parser = adhoc.parser
    assert parser._option_string_actions['-a'] == '--args'
    assert parser._option_string_actions['-m'] == '--module-name'
    assert parser._positionals.title == 'pattern'
    assert parser._positionals.metavar == 'pattern'

# Generated at 2022-06-20 12:53:22.189737
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=['localhost'])
    cli.parse()
    assert cli.args == ['localhost']

# Generated at 2022-06-20 12:53:38.243304
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Get object from class.
    object = AdHocCLI()

    # Get args
    args = ["k8s-master", "k8s-worker1", "k8s-worker1"]

    # Get object parser.
    parser = object.init_parser(args)

    # Test Result
    assert parser is not None

# Generated at 2022-06-20 12:53:40.661388
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # arrange
    cli = AdHocCLI()

    # act
    parser = cli.init_parser()

    # assert
    assert parser is not None


# Generated at 2022-06-20 12:53:47.910006
# Unit test for constructor of class AdHocCLI

# Generated at 2022-06-20 12:53:54.050372
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test to run method run of class AdHocCLI
    # Return a oneline result with a success status
    import argparse
    opt = argparse.Namespace()
    ansible_adhoc = AdHocCLI([])
    opt.module_name = "debug"
    opt.module_args = "var=test_module"
    opt.one_line = True
    result = ansible_adhoc.run()
    assert result == 0

# Generated at 2022-06-20 12:54:03.315115
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:54:13.524068
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.ask_passwords = lambda: (None, None)
    adhoc_cli._play_prereqs = lambda: (None, None, None)
    adhoc_cli.get_host_list = lambda inventory, subset, pattern: ["localhost"]
    context.CLIARGS = dict(
        module_name="ping",
        module_args="option_value=value",
        host_pattern="localhost",
        timeout=5,
        subset="all",
        one_line=True,
        tree=".",
        forks=4,
        poll_interval=1,
        seconds=1,
        check=False,
        verbosity=2,
        listhosts=False,
    )


# Generated at 2022-06-20 12:54:23.624885
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    inventory_manager = "ansible.cli.adhoc.AdHocCLI"

# Generated at 2022-06-20 12:54:26.106196
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    result = AdHocCLI.run(AdHocCLI())
    assert result == 0

# Generated at 2022-06-20 12:54:32.649851
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # test manually adding hosts adhoc cli
    # using ansible.cfg in tests/ to avoid check_hosts()
    args = [
        '--connection=local',
        '--inventory=tests/test_inventory.ini',
        '--module-name=ping',
        'server1',
    ]
    cmd = AdHocCLI(args)
    args = cmd.parse()
    adhoc = AdHocCLI(args)
    assert adhoc.run() == 0

# Generated at 2022-06-20 12:54:44.277771
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
    Unit test for method run of class AdHocCLI.
    '''
    # Create AdHocCLI object
    cli = AdHocCLI([])

    # Import module ansible_test_utils to provide mock objects
    import ansible_test_utils.mock as m

    # Need to parse options to store CLI args
    cli.parse()

    # Create mock objects
    variabla_manager = m.MockAnsibleVariableManager()
    loader = m.MockAnsibleLoader()

    # Create mock for for method _get_host_list to return host list
    inventory = m.MockAnsibleInventory()
    inventory.get_hosts.return_value = ["10.10.10.1", "10.10.10.2"]
    inventory.list_hosts

# Generated at 2022-06-20 12:55:15.356327
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-20 12:55:16.572358
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    AdHocCLI()

# Generated at 2022-06-20 12:55:21.898310
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    from ansible.cli.adhoc import AdHocCLI
    from ansible.utils.display import Display
    from ansible.utils.color import ANSIBLE_COLOR, stringc

    def colorize(lead, num, color):
        """ Prints 'lead' = 'num' in 'color' """
        if num != 0 and ANSIBLE_COLOR and color is not None:
            return "%s=%s" % (lead, stringc(num, color))
        else:
            return "%s=%s" % (lead, num)

    adhoc_cli = AdHocCLI()
    display = Display()

    # -v
    adhoc_cli.options.verbosity = 1
    assert display.verbosity == 1
    adhoc_cli.options.verbosity = 2
    assert display.verbosity

# Generated at 2022-06-20 12:55:29.526358
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    display = Display()
    display.verbosity = 0

    cli = AdHocCLI(
        args=['all'],
        display=display,
        version=C.ANSIBLE_VERSION,
    )

    # Verify the correct usage is set
    if not cli.parser._usage.startswith('%prog <host-pattern>'):
        print("Unexpected usage: %s" % cli.parser._usage)
        return False

    # Verify the correct description is set
    if not cli.parser._description.startswith(
            "Define and run a single task 'playbook' against a set of hosts"):
        print("Unexpected description: %s" % cli.parser._description)
        return False

    # Verify the correct epilog is set

# Generated at 2022-06-20 12:55:41.568146
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory import Inventory
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class MockOptions(MutableMapping):
        def __init__(self):
            self.__store = dict()
        def __getitem__(self, key):
            return self.__store[key]
        def __setitem__(self, key, value):
            self.__store[key] = value
        def __delitem__(self, key):
            del self.__store[key]

# Generated at 2022-06-20 12:55:52.078858
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import argparse
    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI

    class MockTaskQueueManager(object):

        def __init__(self, *args, **kwargs):
            pass

        def run(self, play):
            return "Run success"

    class MockPlay(Play):

        def __init__(self, *args, **kwargs):
            pass

        def get_iterator(self, *args):
            return "Iterator"

        def load(self, *args):
            return "Load success"

    class MockCLI(CLI):

        def __init__(self, *args, **kwargs):
            pass

        def _get_options(self):
            return

# Generated at 2022-06-20 12:56:02.454846
# Unit test for constructor of class AdHocCLI

# Generated at 2022-06-20 12:56:05.179420
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit test for AdHocCLI instantiation'''
    adhoc_cli = AdHocCLI()
    assert type(adhoc_cli) == AdHocCLI

# Generated at 2022-06-20 12:56:09.073773
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI([])
    parser = cli.init_parser()
    cliargs = ["all", "-m", "ping"]
    options, args = parser.parse_args(cliargs)
    newargs = cli.post_process_args(options)

# Generated at 2022-06-20 12:56:19.960016
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Options:
        module_name = 'shell'
        module_args = 'ls -l'
        runas_user = None
        runas_user_base64 = None
        runas_user_exe = None
        runas_user_password = None
        runas_user_password_base64 = None
        runas_user_prompt = None
        runas_user_prompt_msg = None
        become = False
        become_ask_pass = False
        become_user = None
        become_method = None
        become_exe = None
        become_password = None
        become_password_base64 = None
        ask_vault_pass = False
        vault_password_file = None
        new_vault_password_file = None
        listhosts = False
        subset = None

# Generated at 2022-06-20 12:57:02.724403
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-b', '-m', 'shell', 'all', 'echo "Hello World"'], '')
    assert adhoc

# Generated at 2022-06-20 12:57:08.660463
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    options, args = cli.parser.parse_args(['--list-hosts', 'all', '-m', 'shell', '-a', 'ansible'])
    options = cli.post_process_args(options)
    assert options.listhosts
    assert options.module_name == 'shell'
    assert options.module_args == 'ansible'

# Generated at 2022-06-20 12:57:09.883961
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cmd = AdHocCLI()
    assert cmd is not None

# Generated at 2022-06-20 12:57:16.848100
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    from ansible.constants import DEFAULT_PRIVATE_KEY_FILE
    from ansible.constants import DEFAULT_REMOTE_TMP
    from ansible.constants import DEFAULT_REMOTE_USER
    from ansible.constants import DEFAULT_SUDO_PASS

    class MockOptions(object):

        def __init__(self):
            # Define defaults
            self.verbosity = 0
            self.ask_pass = False
            self.ask_vault_pass = False
            self.ask_sudo_pass = False
            self.ask_su_pass = False
            self.module_path = None
            self.listhosts = None
            self.subset = None
            self.check = False
            self.syntax = False
            self.extra_vars = None
            self.host_

# Generated at 2022-06-20 12:57:27.164886
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class FakeOptions:
        pass

    # Create a fake options object
    fake_options = FakeOptions()

    # Populate it with fake data
    fake_options.__dict__ = dict(ask_pass=False, ask_su_pass=False, ask_vault_pass=False, verbosity=3, check=False,
                       listhosts=False, module_path=None, one_line=False, subset=None, timeout=None, tree=None,
                       vault_password_files=None, verbosity=0)

    # Test the post_process_args function
    AdHocCLI().post_process_args(fake_options)

    # Check the results

# Generated at 2022-06-20 12:57:32.472247
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    adhoc = AdHocCLI()
    opts = adhoc.options
    assert opts.module_name == C.DEFAULT_MODULE_NAME
    assert opts.module_args == C.DEFAULT_MODULE_ARGS
    assert opts.args == 'pattern'

if __name__ == "__main__":
    test_AdHocCLI()

# Generated at 2022-06-20 12:57:42.333587
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.adhoc import AdHocCLI
    from units.mock.loader import DictDataLoader

    hosts = set()
    loader = DictDataLoader({
        "all": {
            "hosts": {
                "test": None
            }
        }
    })
    inventory = InventoryManager(loader=loader, sources=["all"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    context.CLIARGS = dict()
    context.CLIARGS['verbosity'] = 0
    context

# Generated at 2022-06-20 12:57:51.637426
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(['ansible-playbook', 'test_pattern', '-f', '200'])
    assert adhoc_cli.args == ['test_pattern']
    assert adhoc_cli.options.forks == 200
    assert AdHocCLI.run.__doc__ == ''' create and execute the single task playbook '''
    assert AdHocCLI._play_ds.__doc__ == ''' create a playbook for the adhoc task '''
    assert AdHocCLI.post_process_args.__doc__ == '''Post process and validate options for bin/ansible '''

# Generated at 2022-06-20 12:58:00.776980
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Unit test 1: module_name = shell and module_args = cat
    test_module_name = 'shell'
    test_module_args = 'cat'
    test_subset = None
    test_listhosts = False
    test_verbosity = 0
    test_one_line = False
    test_tree = False
    test_connection = 'ssh'
    test_module_path = None
    test_forks = 8
    test_private_key_file = None
    test_ssh_common_args = None
    test_ssh_extra_args = None
    test_sftp_extra_args = None
    test_scp_extra_args = None
    test_become = False
    test_become_method = None
    test_become_user = None
    test_ask_pass

# Generated at 2022-06-20 12:58:04.028443
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    options = opt_help.create_base_parser(None).parse_args([])[0]

    options.verbosity = 1
    options.module_name = 'command'
    options.module_args = 'ls -al'
    options.args = 'all'

    a = AdHocCLI(None)

    assert a.post_process_args(options) == options


# Generated at 2022-06-20 12:59:34.549007
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    import ansible.context
    import os
    import tempfile
    import sys

    display = Display()
    # Increase display verbosity for unit test
    display.verbosity = 3
    # Allow all message types
    display.verbosity = 10

    options = C.config.parse_args(args=[])

    # Test 1:
    # Test with valid parameters
    # Expect: Successful return of post-processed argument
    sys.argv = ['ansible', 'localhost', '-m', 'ping']

# Generated at 2022-06-20 12:59:42.121189
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    test_arg1 = 'arg1'
    test_arg2 = 'arg2'

    options = opt_help.create_option_parser(vals=dict(module_name=test_arg1, module_args=test_arg2))[0]
    options = AdHocCLI(None).post_process_args(options)

    assert context.CLIARGS['module_name'] == test_arg1
    assert context.CLIARGS['module_args'] == test_arg2

# Generated at 2022-06-20 12:59:50.975142
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    def test_init():
        # test adhoc cli object
        adhoc_cli_obj = AdHocCLI()

        assert adhoc_cli_obj
        assert adhoc_cli_obj.parser

        # test basic options
        for option in [adhoc_cli_obj.parser._option_string_actions['-v'],
                       adhoc_cli_obj.parser._option_string_actions['-q'],
                       adhoc_cli_obj.parser._option_string_actions['--version'],
                       adhoc_cli_obj.parser._option_string_actions['-h']]:
            assert option
            assert option.dest == 'verbosity'
            assert option.default == 0
            assert option.const == 1
            assert option.nargs == 0

# Generated at 2022-06-20 12:59:52.928541
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit tests for class AdHocCLI '''

    adhoc = AdHocCLI()

    assert adhoc
    assert adhoc._play_ds

# Generated at 2022-06-20 13:00:01.014167
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create an instance of AdHocCLI()
    ad_hoc_cli = AdHocCLI()
    # Create an instance of optparse.Values()
    options = optparse.Values()
    # Set values for options
    options.verbosity = 2
    # Assign options to class variable context.CLIARGS
    context.CLIARGS = options
    # Execute method post_process_args() of ad_hoc_cli
    ad_hoc_cli.post_process_args(options)
    # Verify that context.CLIARGS is updated with right values
    assert context.CLIARGS['verbosity'] == 2

# Generated at 2022-06-20 13:00:04.801821
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI(['-m', 'test_module', '-a', 'arg1=test_value1'])
    assert adhoc_cli.get_opt('module_name') == 'test_module'
    assert adhoc_cli.get_opt('module_args') == 'arg1=test_value1'



# Generated at 2022-06-20 13:00:15.396688
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    """AdHocCLI: Test .run() using various command line options
    """
    import sys
    import tempfile
    import ansible.constants as C
    from units.mock.options import MockCLIOptions

    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader

    # Create test file to use as inventory
    test_host_list = ['hostA', 'hostB']
    _, hosts_file = tempfile.mkstemp()
    with open(hosts_file, 'w') as f:
        f.write('\n'.join(test_host_list))

    # Setup test command arguments

# Generated at 2022-06-20 13:00:21.786904
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    parser = adhoc_cli.parser

    # Empty arguments
    options, args = parser.parse_args([])
    post_options = adhoc_cli.post_process_args(options)
    assert post_options.verbosity == 0

# Generated at 2022-06-20 13:00:23.329404
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert isinstance(cli, AdHocCLI)

# Generated at 2022-06-20 13:00:33.803112
# Unit test for method post_process_args of class AdHocCLI