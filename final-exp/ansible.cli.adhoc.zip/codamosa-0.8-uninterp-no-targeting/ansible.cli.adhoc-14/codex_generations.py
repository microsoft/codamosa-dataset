

# Generated at 2022-06-20 12:52:04.428030
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    adhoc_cli = AdHocCLI()
    options, _args = adhoc_cli.parser.parse_args()
    adhoc_cli.post_process_args(options)

    assert context.CLIARGS['connection'] == 'ssh'
    assert context.CLIARGS['forks'] == C.DEFAULT_FORKS
    assert context.CLIARGS['ask_pass'] is False
    assert context.CLIARGS['ask_su_pass'] is False
    assert context.CLIARGS['ask_sudo_pass'] is False
    assert context.CLIARGS['ask_vault_pass'] is False
    assert context.CLIARGS['become'] is False
    assert context.CLIARGS['become_method'] == 'sudo'
    assert context.CLIARGS

# Generated at 2022-06-20 12:52:06.453110
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    adhoc = AdHocCLI()
    assert isinstance(adhoc, AdHocCLI)


# Generated at 2022-06-20 12:52:08.211204
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI(args=[])
    assert cli._tqm is None
    assert cli.options is None


# Generated at 2022-06-20 12:52:20.410634
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    my_AdHocCLI = AdHocCLI()
    my_AdHocCLI.init_parser()
    #
    # Verify that the parser has the correct options and arguments
    #
    # Options
    assert my_AdHocCLI.parser._actions[4].dest == 'connection'
    assert my_AdHocCLI.parser._actions[7].dest == 'subset'
    assert my_AdHocCLI.parser._actions[9].dest == 'module_path'
    assert my_AdHocCLI.parser._actions[11].dest == 'forks'
    assert my_AdHocCLI.parser._actions[14].dest == 'become'
    assert my_AdHocCLI.parser._actions[15].dest == 'become_method'
    assert my_AdH

# Generated at 2022-06-20 12:52:26.477481
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['localhost', '-m', 'test', '-a', 'opt1=foo'])
    adhoc.parse()
    assert adhoc.options.module_name == 'test'
    assert adhoc.options.module_args == 'opt1=foo'

# Generated at 2022-06-20 12:52:27.255748
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:52:29.391925
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ansible.cli.adhoc.AdHocCLI.run(AdHocCLI, context.CLIARGS)

# Generated at 2022-06-20 12:52:40.541958
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # test setup
    parser = CLI.base_parser(
        usage='%prog <host-pattern> [options]',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        async_opts=True,
        output_opts=True,
        basedir_opts=True,
        tasknoplay_opts=True
    )

    # create an options parser for bin/ansible
    options_parser = AdHocCLI(parser)

    # Call method post_process_args

# Generated at 2022-06-20 12:52:53.168329
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    loader_mock = MagicMock()
    inventory_mock = MagicMock()
    variable_manger_mock = MagicMock()
    playbook_mock = MagicMock()
    play_mock = MagicMock()

    adhoc_cli = AdHocCLI()
    adhoc_cli._play_prereqs = MagicMock(return_value = (loader_mock,
                                                        inventory_mock,
                                                        variable_manger_mock))
    adhoc_cli.get_host_list = MagicMock(return_value = ['dummy_host_list'])
    adhoc_cli._play_ds = MagicMock(return_value = {'dummy_play_ds'})

# Generated at 2022-06-20 12:52:56.097892
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    args = ['-i','test_inventory','test_host','test_module','-a','arg=val','--list-hosts']
    ad = AdHocCLI(args)
    ad.run()

# Generated at 2022-06-20 12:53:05.377741
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhocCLI = AdHocCLI()
    assert adhocCLI is not None


# Generated at 2022-06-20 12:53:16.737871
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # Create test object
    cli = AdHocCLI()

    # Set values for method run
    pattern = '127.0.0.1'
    async_val = '10'
    poll = '10'
    check_raw = 'false'
    timeout= ''
    async_val = '10'
    poll = '10'
    sshpass = None
    becomepass = None
    module_name= ''
    module_args = 'test'
    module_name= ''
    seconds = '10'
    poll_interval = '10'
    inventory = '127.0.0.1'
    variable_manager = 'test'
    loader = ' test'
    passwords = {'conn_pass': sshpass, 'become_pass': becomepass}
    cb = 'oneline'

# Generated at 2022-06-20 12:53:17.639067
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhocCLI = AdHocCLI()

# Generated at 2022-06-20 12:53:19.409030
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-20 12:53:20.991032
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(None)
    cli.init_parser()

    assert cli.parser

# Generated at 2022-06-20 12:53:24.939891
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    adhoc = AdHocCLI()

    # If a valid command is supplied, it should return a result of 0
    result = adhoc.run()
    assert result == 0

    # If an invalid command is supplied, it should return a result of 2
    result = adhoc.run(['--module-name', 'invalid'])
    assert result == 2

# Generated at 2022-06-20 12:53:27.950347
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Create the object
    adhoc = AdHocCLI()

    # test init_parser()
    adhoc.init_parser()

# Generated at 2022-06-20 12:53:32.236442
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():

    # invoke constructor without argument
    print(AdHocCLI())

    # invoke constructor with argumet, __repr__ calls object.__repr__(self) so we need to use object.
    object.__repr__(AdHocCLI())

# Generated at 2022-06-20 12:53:38.765660
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=[])
    loader, inventory, variable_manager = cli._play_prereqs()
    options = cli.init_parser().parse_args([])
    options = cli.post_process_args(options)
    assert options.verbosity == 4
    try:
        options = cli.post_process_args(options)
        assert False, "Exception should be raised if setting incompatible flags"
    except AnsibleOptionsError:
        assert True

# Generated at 2022-06-20 12:53:39.819561
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:54:05.509209
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    mycli = AdHocCLI()
    mycli.init_parser()
    optionstuple = mycli.parser.parse_args(['-m', 'ping', '-a', 'foo=bar', 'localhost'])
    post_processed_opt = AdHocCLI.post_process_args(mycli, optionstuple)
    assert optionstuple.module_args == post_processed_opt.module_args

# Generated at 2022-06-20 12:54:06.207110
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:54:07.641266
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli.parse()

# Generated at 2022-06-20 12:54:18.168029
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # ad-hoc command line argument processing

    import os
    import tempfile

    args = [
        '-i', 'localhost,'
    ]

    kwargs = dict(
        module_name='command',
        module_args='/bin/echo success',
    )

    cli = AdHocCLI(args)
    cli.options = cli.parser.parse_args(args)
    cli.post_process_args(cli.options)
    options = cli.options

    for k, v in kwargs.items():
        assert getattr(options, k) == v

    assert options.connection == 'smart'
    assert not options.listhosts
    assert not options.subset
    assert not options.tree
    assert not options.extra_vars
    assert not options.syntax



# Generated at 2022-06-20 12:54:26.528250
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    import os
    import shutil
    import tempfile

    try:
        old_cwd = os.getcwd()
        tmpdir = tempfile.mkdtemp()
        os.chdir(tmpdir)

        cli = AdHocCLI(['-m', 'ping', '-i', 'hosts', 'localhost'])
        cli.run()

        assert os.path.exists(os.path.join(tmpdir, 'hosts')) is True
    finally:
        os.chdir(old_cwd)
        shutil.rmtree(tmpdir)



# Generated at 2022-06-20 12:54:35.214242
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # AdHocCLI is an abstract class, so these tests are on a derived class

    class AdHocCLI_Tester(AdHocCLI):
            def run(self):
                return
    tester = AdHocCLI_Tester()
    tester.setup()

    # Make sure nothing is printed to the screen and that the options returned
    # are the same options passed in.
    options = tester.parser.parse_args(['localhost'])
    options = tester.post_process_args(options)
    assert options.listhosts is False
    assert options.listtasks is False
    assert options.listtags is False
    assert options.syntax is False
    assert options.connection is 'smart'
    assert options.module_path is None
    assert options.forks is 5

# Generated at 2022-06-20 12:54:39.268208
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class Object(AdHocCLI):
        """Class object to test method post_process_args of class AdHocCLI"""

    obj = Object()
    obj.init_parser()
    args = obj.parser.parse_args(['test', '--module-name', 'module_name', '--module-args', 'module_args'])
    args = obj.post_process_args(args)
    assert isinstance(args, dict), "Expected an instance of dict"


# Generated at 2022-06-20 12:54:40.373017
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ''' test AdHocCLI.run() '''

    # The function is not implemented
    assert(False)

# Generated at 2022-06-20 12:54:46.355598
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    def _set_args(**kwargs):
        AdHocCLI.parser.set_defaults(**kwargs)

    def _run_method_and_assert_error(kwargs, error):
        _set_args(**kwargs)
        AdHocCLI.parser.parse_args(['hosts'])
        try:
            AdHocCLI.post_process_args(AdHocCLI.parser)
            assert False
        except AnsibleError as e:
            assert error in to_text(e)

    # Verifies that mutually exclusive options cannot be used together

# Generated at 2022-06-20 12:54:58.653065
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    import sys
    from io import StringIO
    from unittest.mock import patch


# Generated at 2022-06-20 12:55:44.717631
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-20 12:55:47.576232
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.args = ''
    adhoc.basename = ''
    adhoc.options = ''
    adhoc.parser = ''
    adhoc.version = ''

    # Test Exception - AnsibleOptionsError
    try:
        adhoc.run()
        # This line should be reached if no exception occured.
        assert(0)
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-20 12:55:48.724936
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

# Generated at 2022-06-20 12:55:54.735777
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """Tests to see if basic AdHocCLI functions."""

    # Test Parser
    cli = AdHocCLI(['all', '-m', 'ping'])
    assert cli.parser.__class__.__name__ == 'CLI'

    # Test Post_Process_Args
    cli.post_process_args()
    assert context.CLIARGS['module_name'] == 'ping'

    # Test run
    cli.run()
    assert context.CLIARGS['module_name'] == 'ping'

# Generated at 2022-06-20 12:56:06.015638
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    parser = CLI().get_base_parser()
    AdHocCLI().init_parser(parser)
    (options, args) = parser.parse_args([])
    assert not options.listhosts
    assert not options.subset
    assert options.module_name == 'command'
    assert not options.tree
    assert not options.inventory
    assert options.connection == 'smart'
    assert options.verbosity == 0
    assert not options.check
    assert not options.diff
    assert not options.extra_vars
    assert not options.forks
    assert not options.listtasks
    assert not options.listtags
    assert not options.syntax
    assert not options.start_at_task
    assert not options.step
    assert not options.args
    assert not options.module_path

# Generated at 2022-06-20 12:56:09.714197
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI(['-m','shell','--list-hosts','localhost'])
    adhoc.init_parser()
    adhoc.parse()
    adhoc.post_process_args(adhoc.args)


# Generated at 2022-06-20 12:56:20.541335
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Scenario 1: module_args is not provided
    #  Expected: all problems should be reported
    #  Actual: all problems are reported
    context.CLIARGS = {'module_name': 'ping'}
    mycli = AdHocCLI()
    mycli.post_process_args(context.CLIARGS)

    # Scenario 2: module_args is provided
    #  Expected: all problems should be reported
    #  Actual: all problems are reported
    context.CLIARGS = {'module_name': 'ping', 'module_args': 'data="spam"'}
    mycli = AdHocCLI()
    mycli.post_process_args(context.CLIARGS)

    # Scenario 3: module_name and module_args are provided
    #  Expected: all

# Generated at 2022-06-20 12:56:32.261084
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Test with all parameters
    options = opt_help.add_common_options(mock.Mock())
    options.connection = 'ssh'
    options.module_path = '/foo'
    options.forks = 10
    options.remote_user = 'remote_user'
    options.private_key_file = '/foo/id_rsa'
    options.ssh_common_args = '-o "ProxyCommand=\'ssh -W %h:%p -q bastion\'"'
    options.sftp_extra_args = '-f 5'
    options.scp_extra_args = '-l 100'
    options.become = True
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.verbosity = 5
    options.check = True


# Generated at 2022-06-20 12:56:39.832472
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ad_hoc_cli = AdHocCLI(args=['-m', 'ping', '-a', 'pinging'])
    assert_equals(ad_hoc_cli.post_process_args(ad_hoc_cli.parse()).module_args, 'pinging')
    assert_equals(ad_hoc_cli.post_process_args(ad_hoc_cli.parse()).module_name, 'ping')
    '''
    pass

# Generated at 2022-06-20 12:56:46.753894
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    Make sure that AdHocCLI() constructs correctly
    """
    adhoc = AdHocCLI(['localhost'])
    assert adhoc.name == 'ansible-adhoc'
    assert adhoc.version == C.ANSIBLE_VERSION
    assert adhoc.parser is not None
    assert adhoc.args is None
    assert adhoc.options is None
    assert adhoc.callback is None
    assert adhoc.tasks is None
    assert adhoc.inject is None
    assert adhoc.jobs is None

# Generated at 2022-06-20 12:58:22.987724
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    CLI.setup()
    cli = AdHocCLI()
    cli.get_opt_parser()
    parser = cli.parser
    cli.init_parser()
    cli.preprocess_args('-m ping', '172.16.1.1,172.16.2.2')
    cli.post_process_args(context.CLIARGS)
    for key, val in context.CLIARGS.items():
        if key in parser._actions:
            assert getattr(context.CLIARGS, key) == val


# Generated at 2022-06-20 12:58:33.168470
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    
    import sys
    import unittest

    class TestAdHocCLI(unittest.TestCase):
        def test_AdHocCLI_run_ok(self):
            return True

        # TODO: Write unittest
        def test_AdHocCLI_run_fail(self):
            pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestAdHocCLI)
    unittest.TextTestRunner(verbosity=0).run(suite)

if __name__ == '__main__':
    cli = AdHocCLI()
    r_code = cli.run()
    sys.exit(r_code)

# Generated at 2022-06-20 12:58:35.636846
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=[])
    options = cli.parser.parse_args([])
    assert cli.post_process_args(options) == None

# Generated at 2022-06-20 12:58:37.715758
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc = AdHocCLI()
    assert adhoc.parser is not None


# Generated at 2022-06-20 12:58:40.341528
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(['-m', 'ping', 'all'])
    assert cli.parser.parse_args(['all'])



# Generated at 2022-06-20 12:58:49.568624
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Init object
    cli = AdHocCLI(['-v', '-vvvv', '-vvvvv', '-vvvvvv', '-vvvvvvv', '-vvvvvvvv', '-M', 'mydir', '-T', '60', 'test', '-a', 'arg1=val1', '-m', 'module1'])
    # Set default values
    options = opt_help.create_base_parser(constants=C).parse_args([])
    options.verbosity = 0
    options.connection = 'smart'
    options.module_path = None
    options.forks = 5
    options.module_name = 'command'
    options.module_args = ''
    options.timeout = 10
    options.listhosts = False
    options.subset = None
    #

# Generated at 2022-06-20 12:58:52.429302
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # check if the constructor creates an instance of class AdHocCLI
    cli = AdHocCLI()
    assert isinstance(cli, AdHocCLI)

# Generated at 2022-06-20 12:59:03.545073
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    # Test with module name ansible-doc and args '-l'
    context.CLIARGS = dict(module_name='ansible-doc', module_args='-l')
    cli = AdHocCLI()
    options = cli.post_process_args(context.CLIARGS)
    assert options.module_name == 'ansible-doc'
    assert options.module_args == '-l'

    # Test with module name include and args '--list'
    context.CLIARGS = dict(module_name='include', module_args='--list')
    cli = AdHocCLI()
    options = cli.post_process_args(context.CLIARGS)
    assert options.module_name == 'include'
    assert options.module_args == '--list'

    #

# Generated at 2022-06-20 12:59:05.512512
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cmd = AdHocCLI()
    cmd.options = {'module_name': 'ping'}
    cmd.run()

# Generated at 2022-06-20 12:59:10.505692
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """
    This is to test the constructor of class AdHocCLI.
    """
    adhoc_cli = AdHocCLI()
    print(adhoc_cli)
    assert adhoc_cli