

# Generated at 2022-06-20 12:51:56.612578
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    adhoc.init_parser()
    assert adhoc


# Generated at 2022-06-20 12:52:02.873766
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI(args=[])
    opt = cli.parser.parse_args([])
    new_opt = cli.post_process_args(opt)
    assert not hasattr(new_opt, 'verbose')
    assert hasattr(new_opt, 'verbosity')
    assert new_opt.verbosity == 0


# Generated at 2022-06-20 12:52:10.931101
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    class TestClass(AdHocCLI):
        def __init__(self):
            self.display = Display()
            self.parser = None
    
    # test invalid verbosity
    adhoc_cli = TestClass()
    parser = adhoc_cli.create_parser()
    #invalid verbosity
    options = parser.parse_args(['-v', 'invalid', '-m', 'ping', 'all'])
    result = adhoc_cli.post_process_args(options)
    expected = AdHocCLI.post_process_args(adhoc_cli, options)
    assert result == expected
    #valid verbosity
    options = parser.parse_args(['-v', '0', '-m', 'ping', 'all'])
    result = adhoc_cli.post_process

# Generated at 2022-06-20 12:52:15.161403
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    options = context.CLIARGS
    options['verbosity'] = 0
    options['inventory'] = 'localhost,'
    options['module_name'] = 'ping'
    options['module_args'] = ''
    options['args'] = 'localhost'
    options['ask_pass'] = False
    options['ask_sudo_pass'] = False
    options['ask_su_pass'] = False

    adhoc = AdHocCLI(args=['localhost'])
    adhoc.post_process_args(options)
    adhoc.run()

# Generated at 2022-06-20 12:52:22.807807
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    cli.init_parser()

    # ad hoc command only accepts 2 or 3 as verbosity levels
    for verbosity_level in range(4):
        options = cli.parser.parse_args(['all', '-v', str(verbosity_level)])
        if verbosity_level > 1:
            assert options.verbosity == verbosity_level - 1
        else:
            assert options.verbosity == verbosity_level



# Generated at 2022-06-20 12:52:32.473965
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    args = ['test_host']

    for ansible_options in ['-vvvv', '-k', '-K', '-u user', '-U user', '--become',
                            '--become-user=user', '--become-method=sudo', '-c ssh',
                            '-c paramiko']:
        args.append(ansible_options)
        cli = AdHocCLI(args)
        options = cli.parse()
        with pytest.raises(AnsibleOptionsError):
            cli.post_process_args(options)



# Generated at 2022-06-20 12:52:36.357639
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI(args=[])
    parser = cli.init_parser()

    # test for required arguments
    assert parser.get_option('module_name')
    assert parser.get_option('module_args')

# Generated at 2022-06-20 12:52:48.751492
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.executor import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook
    from ansible.plugins.loader import callback_loader

    # https://docs.pytest.org/en/latest/monkeypatch.html
    mocker_patch_methods = {
        'callback_loader.get': lambda x, y: callback_loader._load_callback_plugins(x, y)
    }

    # https://docs.pytest.org/en/latest/monkeypatch.html

# Generated at 2022-06-20 12:52:50.622575
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    ''' unit test for constructor of class AdHocCLI '''
    AdHocCLI()

# Generated at 2022-06-20 12:52:55.869496
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    cli = AdHocCLI()
    inventory = """
[webservers]
localhost
"""
    cli.parse(args=['hostname', '-m', 'setup', '-i', 'hosts'])
    context.CLIARGS = {'playbook': 'hosts', 'inventory': inventory, 'forks': 1, 'connection': 'local'}
    # FIXME (test fails with 'Permission denied')
    #cli.run()

# Generated at 2022-06-20 12:53:07.799954
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    """ this is a more basic test than the others, which actually
    execute stuff, but just makes sure we get back a base class
    we expect """

    ad_hoc_cli = AdHocCLI()
    assert isinstance(ad_hoc_cli, CLI)

# Generated at 2022-06-20 12:53:10.450900
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=[])
    assert adhoc.parser is not None, "Failed to construct AdHocCLI"

# Generated at 2022-06-20 12:53:20.420601
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Create object of class AdHocCLI
    ad_hoc_cli = AdHocCLI()

    # Call init_parser method
    ad_hoc_cli.init_parser()

    # Assert arguments required by method
    assert ad_hoc_cli.parser.description is not None
    assert ad_hoc_cli.parser.usage is not None
    assert ad_hoc_cli.parser.prog == "ansible"
    assert ad_hoc_cli.parser._positionals._group_action.choices[0] == 'pattern'
    assert ad_hoc_cli.parser._positionals._group_action.dest == 'args'

    # Assert long options added by method

# Generated at 2022-06-20 12:53:27.648323
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    display = Display()
    argv = ['--version']
    parser = AdHocCLI.init_parser(AdHocCLI(), argv, display)
    opt = parser.parse_args(argv)
    assert opt.version is True
    assert opt.verbosity == 0
    assert opt.inventory is None
    assert opt.listhosts is None
    assert opt.subset is None
    assert opt.module_path is None
    assert opt.forks is None
    assert opt.private_key_file is None
    assert opt.become is False
    assert opt.become_ask_pass is None
    assert opt.become_method is None
    assert opt.become_user is None
    assert opt.remote_user is None
    assert opt.ask_pass is None
    assert opt.ask_sudo

# Generated at 2022-06-20 12:53:35.667020
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    parser = cli.init_parser()
    args = parser.parse_args([ '-m', 'module_name', '-u', 'remote_user', '--private-key', 'private_key.pem', 'localhost' ])
    assert args.module_name == 'module_name'
    assert args.remote_user == 'remote_user'
    assert args.private_key == 'private_key.pem'
    assert args.args == 'localhost'

# Generated at 2022-06-20 12:53:40.579172
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    '''
    ansible ad-hoc cli constructor test
    '''
    obj = AdHocCLI(['anisble-adhoc', '-m', 'ping', 'localhost'])
    assert obj.parser._prog == 'ansible-adhoc'
    assert obj.parser._module_name == 'ping'
    assert obj.parser._hosts == ['localhost']


# Generated at 2022-06-20 12:53:42.423434
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
  AdHocCLI_instance = AdHocCLI()
  AdHocCLI_instance.init_parser()


# Generated at 2022-06-20 12:53:45.795793
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.basic_help
    assert adhoc_cli.display_error
    assert adhoc_cli.display_help
    assert adhoc_cli.inventory_opts
    assert adhoc_cli.parser
    assert adhoc_cli.run

# Generated at 2022-06-20 12:53:58.102678
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    class AdHocCLI_post_process_args(AdHocCLI):

        def post_process_args(self, options):
            # test
            assert options == options

    class TestOptions(object):

        def __init__(self):
            self.become = True
            self.become_method = None
            self.become_user = None
            self.connect_timeout = 30
            self.diff = False
            self.extra_vars = None
            self.flush_cache = None
            self.forks = 50
            self.inventory = None
            self.listhosts = False
            self.listtags = False
            self.listtasks = False
            self.module_path = None
            self.module_name = None
            self.one_line = False

# Generated at 2022-06-20 12:54:05.025615
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    from ansible.inventory.manager import InventoryManager

    inventory_content = """
    [test_hosts]
    127.0.0.1
    """
    test_host_file = "/tmp/hosts.tmp"
    with open(test_host_file, "w") as f:
        f.write(inventory_content)

    inventory = InventoryManager(loader=None, sources=[test_host_file])
    pattern = 'test_hosts'

    # used in start callback
    playbook = Playbook(loader=[])
    play = Play()

# Generated at 2022-06-20 12:54:23.177977
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    from ansible import context
    context.CLIARGS = {}

    # Test class constructor
    cli_adhoc = AdHocCLI()
    cli_adhoc.init_parser()

    # Test parser errors
    # If no arguments are passed
    context.CLIARGS = {}
    with pytest.raises(SystemExit):
        cli_adhoc.post_process_args(cli_adhoc.parser.parse_args(args = []))

    # If both become and sudo options are passed
    context.CLIARGS = {}
    with pytest.raises(AnsibleOptionsError):
        cli_adhoc.parser.parse_args(args = ['localhost', '-u', 'root', '-b', '-s'])

# Generated at 2022-06-20 12:54:33.622320
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    # Construct a dummy inventory
    test_inventory = """
        [test_hosts]
        localhost ansible_connection=local
    """
    test_inventory_fh = open('./test_inventory', 'w')
    test_inventory_fh.write(test_inventory)
    test_inventory_fh.close()

    # Construct a dummy play

# Generated at 2022-06-20 12:54:35.196627
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    cli

# Generated at 2022-06-20 12:54:39.514482
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI()
    cli.init_parser()
    assert isinstance(cli.parser, CLI.base_parser.__class__)
    assert not cli.base_parser is None
    assert not cli.parser is None


# Generated at 2022-06-20 12:54:45.631439
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    cli = AdHocCLI()
    cli.parser.add_argument("--hello", default="this",help="A test argument.")
    cli.parser.add_argument("--bye", default=None, help="A test argument.")
    opts = cli.parser.parse_args([])
    options = cli.post_process_args(opts)
    assert options.hello == "this"
    assert options.bye == None
    assert options.verbosity == 0

# Generated at 2022-06-20 12:54:57.408888
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a mock playbook and task queue manager.
    playbook = Playbook(loader=None)
    task_queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, passwords=None, stdout_callback=None, run_additional_callbacks=None, run_tree=None, forks=None)

    # Create a mock display object.
    display = Display()

    # Create a mock task queue manager.
    class MockTaskQueueManager:
        def __init__(self):
            self._stats = 'task_queue_manager._stats'

        def run(self, play):
            return 'task_queue_manager.run'

        def cleanup(self):
            pass

        def send_callback(self, msg, stats):
            pass

    adhoc = AdHocCLI()
    adh

# Generated at 2022-06-20 12:55:00.615508
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # AdHocCLI is a subclass of CLI.
    # This test cases tests init_parser method of AdHocCLI.
    # 1. Instantiate object of class AdHocCLI
    # 2. Assert that usage is set to a particular value and description starts with expected value
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc_cli.parser.description.startswith("Define and run a single task 'playbook' against a set of hosts")


# Generated at 2022-06-20 12:55:03.015933
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.post_process_args(adhoc_cli.parse())

# Generated at 2022-06-20 12:55:05.484629
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    # Create and instance of class AdHocCLI
    a = AdHocCLI()

    assert a is not None, 'Failed to create an instance of AdHocCLI'

# Generated at 2022-06-20 12:55:12.728005
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    path_to_inventory_json = './ansible/inventory/sample_inventory_1.json'
    path_to_adhoc_yml = './ansible/playbooks/sample_adhoc_1.yml'

    # case-1: '-a "echo test"'
    context.CLIARGS = {'args': path_to_inventory_json,
                       'module_name': 'shell',
                       'module_args': 'echo test'}
    print('Test case: ' + str(context.CLIARGS))

    ahc = AdHocCLI(['-m', 'shell', '-a', 'echo test', 'localhost'])
    ahc.post_process_args(context.CLIARGS)

    # case-2: '--args "echo test"'
    context.CLIARGS

# Generated at 2022-06-20 12:55:26.258217
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:55:35.474385
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # Given
    bin_ansible = 'bin/ansible'
    cli = AdHocCLI(
        command=bin_ansible,
        args=''
    )

    # When
    parser = cli.init_parser()

    # Then
    assert parser == cli.parser
    assert parser.prog == bin_ansible
    assert parser.usage == '%prog <host-pattern> [options]'
    assert parser.description == "Define and run a single task 'playbook' against a set of hosts"


# Generated at 2022-06-20 12:55:36.919662
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.run() == 0

# Generated at 2022-06-20 12:55:42.083634
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    # create an options parser for bin/ansible
    adHocCLI = AdHocCLI(args=[])
    parser = adHocCLI.init_parser()
    args = parser.parse_args('')
    assert args.module_name == 'command'
    assert args.module_args == ''


# Generated at 2022-06-20 12:55:44.155137
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # AdHocCLI.run(self):

    # assert False  # TODO: implement your test here
    pass

# Generated at 2022-06-20 12:55:45.296934
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    ansible = AdHocCLI(['localhost', '--module-name', 'file', '--module-args', 'path=/path/to/file'])


# Generated at 2022-06-20 12:55:46.792974
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adh = AdHocCLI()
    adh.parse()

# Generated at 2022-06-20 12:55:55.590977
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    class Options(object):
        def __init__(self):
            self.module = 'command'
            self.module_args = 'uptime'
            self.forks = 10
            self.connection = 'ssh'
            self.pattern = 'test_host_pattern'

    class ModuleUtilsCLI():
        def __init__(self):
            self.args = Options()
            self.options = Options()

        def get_host_list(self, inventory, subset, pattern):
            return ['host1']

    class CallbackModule():
        def __init__(self):
            self.name = 'json'

    class CLIARGS(dict):
        def __init__(self):
            super(CLIARGS, self).__init__()
            self['connection'] = 'ssh'

# Generated at 2022-06-20 12:55:59.940555
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    display = Display()
    opt = AdHocCLI(
        args=['-m', 'setup', '-a', '"filter=ansible_distribution*"', 'testserver'],
        display=display
    )
    opt.parse()
    return opt

# Generated at 2022-06-20 12:56:10.283780
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    # Create an instance of class AdHocCLI and call the target method
    obj = AdHocCLI(args=[])
    obj.post_process_args(obj.parser.parse_args(args=['-m', 'shell', '-a', 'free=true', 'localhost']))
    assert context.CLIARGS['module_args'] == 'free=true'
    assert context.CLIARGS['module_name'] == 'shell'
    obj.post_process_args(obj.parser.parse_args(args=['-m', 'shell', 'localhost']))
    assert context.CLIARGS['module_args'] == ''
    assert context.CLIARGS['module_name'] == 'shell'


if __name__ == '__main__':
    cli = AdHocCLI(args=[])

# Generated at 2022-06-20 12:56:46.291737
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    parser = CLI.base_parser(
        usage="%prog [options]",
        desc="Ad-Hoc",
    )
    opt_help.add_runas_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_async_options(parser)
    opt_help.add_output_options(parser)
    opt_help.add_connect_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)
    opt_help.add_basedir_options(parser)

    # options unique to ans

# Generated at 2022-06-20 12:56:46.852824
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:56:56.443438
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():
    """Tests function AdHocCLI().post_process_args()

    Test data:
        args is a list of tuples with 3 members: a description, a list of args and result.
        First member of a tuple is the description of the test.
        Second member is the list of strings with args.
        Third member is the result.
        Result is a dictionary with
            for the first 2 tests the key 'module_args', the value is a string of kv pairs
            for test 3 and 4 the key 'module_args' is missing
            for test 5 the key 'module_args' is a list of kv pairs
            for test 5 the key 'module_name' is 'debug'

    """

# Generated at 2022-06-20 12:57:07.790322
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    stdout_buf = []
    def fake_print(msg, file=sys.stdout):
        stdout_buf.append(msg)

    # monkey patch for avoiding calling print()
    sys.stdout.write = sys.stderr.write = fake_print

    import io
    class FakeStream:
        def __init__(self, name):
            self.name = name
            self.buf = io.StringIO()
            self.closed = False
        def write(self, s):
            self.buf.write(s)
        def close(self):
            self.closed = True

    # monkey patch for control of stdout and stderr
    saved_sys_stdout = sys.stdout
    saved_sys_stderr = sys.stderr
    sys.stdout = FakeStream('stdout')


# Generated at 2022-06-20 12:57:09.715775
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    args = []
    adhoc = AdHocCLI(args)
    adhoc.init_parser()



# Generated at 2022-06-20 12:57:16.726025
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    '''
      This unit test for method run of class AdHocCLI checks
      all the possible paths through the method run.
    :return:
    '''

    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI
    from ansible.errors import AnsibleOptionsError
    from ansible.parsing.splitter import parse_kv
    from ansible.utils.display import Display

    with pytest.raises(TypeError) as type_err:
        AdHocCLI.run(None)

    assert str(type_err.value) == 'run() takes 1 positional argument but 2 were given'

    with pytest.raises(CLIError) as cli_error:
        AdHocCLI().run()


# Generated at 2022-06-20 12:57:18.291035
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli_object = AdHocCLI(['-m', 'ping', 'localhost'])

# Generated at 2022-06-20 12:57:20.361285
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():

    t = AdHocCLI()
    t.init_parser()

    assert t.parser != None

# Generated at 2022-06-20 12:57:24.637575
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    ''' Unit test for method init_parser of class AdHocCLI '''
    adhoc_cls = AdHocCLI(None)
    adhoc_cls.init_parser()
    assert isinstance(adhoc_cls.parser, object)

# Generated at 2022-06-20 12:57:29.900752
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    options, args = adhoc_cli.parser.parse_known_args()
    adhoc_cli.post_process_args(options)
    context._init_global_context(adhoc_cli)
    context.CLIARGS = adhoc_cli.args

    adhoc_cli.run()

# Generated at 2022-06-20 12:58:30.553501
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()

# Generated at 2022-06-20 12:58:31.146659
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-20 12:58:37.011957
# Unit test for method post_process_args of class AdHocCLI

# Generated at 2022-06-20 12:58:47.548602
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():

    # TEST CASE 1
    # Test for pattern, with list-hosts option
    # Test for AnsibleOptionsError, when module_requre_args and no module args passed
    # Test for AnsibleOptionsError, when module-name is not a valid action for ad-hoc
    # Test for ad-hoc, when no host is matched and subset options is present
    cli = AdHocCLI([])
    cli.options = cli.parser.parse_args(['-m debug', '-a', 'var=arg', 'all'])
    cli.post_process_args(cli.options)
    assert cli.options.listhosts

    # TEST CASE 2
    # Test for one-line option
    # Test for run-tree option
    cli = AdHocCLI([])

# Generated at 2022-06-20 12:58:50.422224
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    adhoc_cli = AdHocCLI()
    adhoc_cli.init_parser()
    assert adhoc_cli.parser is not None


# Generated at 2022-06-20 12:58:56.549415
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    import sys
    sys.argv = ["ansible-playbook", "-i", "test_inventory", "--list-hosts", "test_pattern"]
    context.CLI = AdHocCLI(args=context.CLI.args[2:])
    context.CLI.run()

    assert context.CLIARGS['listhosts'] is True
    assert context.CLIARGS['subset'] == "test_pattern"
    assert context.CLIARGS['inventory_file'] == ["test_inventory"]

# Generated at 2022-06-20 12:59:07.531372
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    '''Return a argument parser for bin/ansible
    '''

    # Simple test for method init_parser of class AdHocCLI
    # The test case does not cover all the options the method can take.
    # Feel free to add more test cases for greater coverage

# Generated at 2022-06-20 12:59:14.064136
# Unit test for method init_parser of class AdHocCLI
def test_AdHocCLI_init_parser():
    cli = AdHocCLI([])
    assert isinstance(cli.parser, CLI.base_parser.__class__)
    # test add_argument
    cli.init_parser()
    assert isinstance(cli.parser, CLI.base_parser.__class__)
    assert 'module_args' in cli.parser._option_string_actions
    assert 'module_name' in cli.parser._option_string_actions
    assert 'args' in cli.parser._pos_actions

# Generated at 2022-06-20 12:59:19.582245
# Unit test for method post_process_args of class AdHocCLI
def test_AdHocCLI_post_process_args():

    import random

    # For a random int as verbosity value, test verbosity sets
    for i in range(3):
        rand_int = random.randint(0,5)
        opts = opt_help.create_base_opts({'verbosity':rand_int})
        assert context.CLIARGS['verbosity'] == rand_int
        assert display.verbosity == rand_int

# Generated at 2022-06-20 12:59:21.983456
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adHocCLI = AdHocCLI()
    assert adHocCLI.setup() == 0