

# Generated at 2022-06-16 19:41:09.494723
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:41:15.652451
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser
    parser = adhoc_cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['-m', 'ping', 'all'])

    # Set context.CLIARGS
    context.CLIARGS = vars(args)

    # Call method run of class AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:41:17.368920
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 19:41:26.035545
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser._positionals.title == 'positional arguments'
    assert adhoc.parser._optionals.title == 'optional arguments'
    assert adhoc.parser._option_string_actions['-a'].dest == 'module_args'

# Generated at 2022-06-16 19:41:33.714096
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser
    parser = adhoc_cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['-m', 'ping', 'all'])

    # Set context.CLIARGS
    context.CLIARGS = vars(args)

    # Call method run of AdHocCLI object
    adhoc_cli.run()

# Generated at 2022-06-16 19:41:44.107466
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a context object
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'subset': '', 'listhosts': False, 'seconds': None, 'poll_interval': 15, 'tree': None, 'forks': 5}

    # Create a loader object
    loader = None

    # Create a inventory object
    inventory = None

    # Create a variable_manager object
    variable_manager = None

    # Create a passwords object
    passwords = None

    # Create a play_ds object
    play_ds = adhoc_cli._play_ds('all', None, 15)

    # Create a play object

# Generated at 2022-06-16 19:41:53.646484
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.errors import AnsibleError
   

# Generated at 2022-06-16 19:42:01.677382
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a dict object to store the command line options
    context.CLIARGS = dict()

    # Set the command line options
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = 'data=hello world'
    context.CLIARGS['args'] = 'localhost'
    context.CLIARGS['subset'] = None
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['seconds'] = None
    context.CLIARGS['poll_interval'] = None
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['one_line'] = False

# Generated at 2022-06-16 19:42:02.253252
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:42:03.632397
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli

# Generated at 2022-06-16 19:42:19.374390
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-16 19:42:32.260850
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()
    # Create a parser object
    parser = adhoc_cli.create_parser()
    # Create a dict object

# Generated at 2022-06-16 19:42:33.082506
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:42:34.425654
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-16 19:42:45.571231
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-16 19:42:46.898893
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-16 19:42:47.995998
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-16 19:42:48.586302
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:42:50.003199
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 19:42:51.510142
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 19:43:15.740433
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': '', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

    # Test with hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': 'localhost', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc_cli = AdHocCLI()

# Generated at 2022-06-16 19:43:17.202427
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-16 19:43:18.635847
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser is not None

# Generated at 2022-06-16 19:43:20.228865
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-16 19:43:23.621444
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser is not None

# Generated at 2022-06-16 19:43:24.491118
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:43:35.211287
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.cli import CLI
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-16 19:43:36.857824
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:43:46.860180
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import yaml
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-16 19:43:48.178049
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Write unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:44:17.485284
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()
    # Create a dict object to store the options
    options = {}
    # Set the options
    options['module_name'] = 'ping'
    options['module_args'] = ''
    options['subset'] = ''
    options['listhosts'] = False
    options['seconds'] = 0
    options['poll_interval'] = 15
    options['tree'] = ''
    options['forks'] = 5
    # Set the options to context
    context.CLIARGS = options
    # Call the run method
    adhoc_cli.run()

# Generated at 2022-06-16 19:44:18.665541
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 19:44:30.729241
# Unit test for method run of class AdHocCLI

# Generated at 2022-06-16 19:44:42.761902
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.cli.adhoc import AdHocCLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-16 19:44:52.587762
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(args=['-m', 'ping', 'localhost'])
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser._positionals.title == 'positional arguments'
    assert adhoc.parser._optionals.title == 'optional arguments'
    assert adhoc.parser.usage == '%(prog)s <host-pattern> [options]'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser._option_string_actions['-a'].dest == 'module_args'
    assert adhoc.parser._

# Generated at 2022-06-16 19:44:59.272368
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:45:00.180580
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    AdHocCLI()

# Generated at 2022-06-16 19:45:04.112754
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser object
    parser = adhoc_cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['-m', 'ping', 'localhost'])

    # Call method run of class AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:45:04.516097
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:45:05.776572
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:46:09.403419
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 19:46:19.149945
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a test object
    test_obj = AdHocCLI()

    # Create a test playbook
    test_playbook = Playbook()

    # Create a test task queue manager
    test_tqm = TaskQueueManager()

    # Create a test loader
    test_loader = Playbook()

    # Create a test inventory
    test_inventory = Playbook()

    # Create a test variable manager
    test_variable_manager = Playbook()

    # Create a test password
    test_passwords = {'conn_pass': 'test_sshpass', 'become_pass': 'test_becomepass'}

    # Create a test callback
    test_cb = 'oneline'

    # Create a test run tree
    test_run_tree = False

    # Create a test stats
    test_stats = Playbook()

   

# Generated at 2022-06-16 19:46:20.044148
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 19:46:31.056388
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser is not None
    assert adhoc.parser._prog == 'ansible'
    assert adhoc.parser._usage == '%prog <host-pattern> [options]'
    assert adhoc.parser._description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser._epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser._version == '%(prog)s ' + C.VERSION
    assert adhoc.parser._optionals._title == 'Options'
    assert adhoc.parser._positionals._title == 'Positional arguments'
    assert adhoc.parser._actions[0].dest == 'args'

# Generated at 2022-06-16 19:46:35.717871
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:46:37.856585
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:46:48.509715
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': '', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': ''}
    adhoc = AdHocCLI()
    adhoc.run()

    # Test with hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': 'localhost', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': ''}
    adhoc = AdHocCLI()

# Generated at 2022-06-16 19:46:56.017629
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a dict object to store the arguments
    context.CLIARGS = dict()

    # Set the arguments
    context.CLIARGS['module_name'] = 'ping'
    context.CLIARGS['module_args'] = ''
    context.CLIARGS['args'] = 'localhost'
    context.CLIARGS['subset'] = ''
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['seconds'] = None
    context.CLIARGS['poll_interval'] = None
    context.CLIARGS['tree'] = None
    context.CLIARGS['forks'] = 5
    context.CLIARGS['verbosity'] = 0


# Generated at 2022-06-16 19:46:57.993557
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc is not None

# Generated at 2022-06-16 19:47:09.497358
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    cli = AdHocCLI()
    assert cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert cli.parser.usage == "%prog <host-pattern> [options]"
    assert cli.parser._actions[1].dest == "module_args"
    assert cli.parser._actions[1].help == "The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'"
    assert cli.parser._actions[1].default == "echo hi"
    assert cli.parser._actions[2].dest == "module_name"

# Generated at 2022-06-16 19:50:02.607841
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-16 19:50:03.345088
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc

# Generated at 2022-06-16 19:50:05.017033
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:50:05.762473
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:50:07.952375
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a mock object for class AdHocCLI
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-16 19:50:08.849715
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: write test
    pass

# Generated at 2022-06-16 19:50:14.882741
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.usage == '%prog <host-pattern> [options]'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:50:15.703737
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 19:50:22.345216
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': '', 'subset': None, 'listhosts': False, 'seconds': None, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc = AdHocCLI()
    adhoc.run()

    # Test with hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': 'localhost', 'subset': None, 'listhosts': False, 'seconds': None, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc = AdHocCLI()

# Generated at 2022-06-16 19:50:23.239463
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement unit test for method run of class AdHocCLI
    pass