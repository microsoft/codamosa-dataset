

# Generated at 2022-06-16 19:41:10.487478
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:41:11.486782
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 19:41:13.112869
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:41:15.586005
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    sys.argv = ['ansible', 'all', '-m', 'ping', '-a', 'data=test']
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-16 19:41:19.274849
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:41:20.183329
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 19:41:20.736610
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:41:27.852492
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import os
    import sys
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.callback.default import CallbackModule
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    display.verbosity = 3

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary inventory file
    inv_file = os.path.join(tmpdir, 'hosts')

# Generated at 2022-06-16 19:41:32.919964
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:41:43.830793
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser object
    parser = adhoc_cli.create_parser()

    # Create a dictionary of options

# Generated at 2022-06-16 19:42:01.445621
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI(['-m', 'ping', 'localhost'])
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser._positionals.title == 'positional arguments'
    assert adhoc.parser._optionals.title == 'optional arguments'
    assert adhoc.parser.usage == '%(prog)s <host-pattern> [options]'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser._option_string_actions['-a'].dest == 'module_args'
    assert adhoc.parser._option_

# Generated at 2022-06-16 19:42:07.214519
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a mock object for the class TaskQueueManager
    class MockTaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, passwords, stdout_callback, run_additional_callbacks, run_tree, forks):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.passwords = passwords
            self.stdout_callback = stdout_callback
            self.run_additional_callbacks = run_additional_callbacks
            self.run_tree = run_tree
            self.forks = forks

        def load_callbacks(self):
            pass

        def send_callback(self, callback_name, *args):
            pass

# Generated at 2022-06-16 19:42:16.927945
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.loader import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-16 19:42:22.878948
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()
    # Create a dict object
    context.CLIARGS = {'module_name': 'shell', 'module_args': 'ls', 'args': 'localhost'}
    # Call method run of class AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:42:24.438965
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:42:25.998149
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:42:28.163153
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc

# Generated at 2022-06-16 19:42:30.350005
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:42:39.397030
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.parser.prog == 'ansible'
    assert adhoc_cli.parser._usage_actions[0].help == '%prog <host-pattern> [options]'
    assert adhoc_cli.parser._actions[0].help == 'host pattern'
    assert adhoc_cli.parser._actions[0].metavar == 'pattern'
    assert adhoc_cli.parser._actions[0].dest == 'args'
    assert adhoc_cli.parser._actions[1].dest == 'module_args'
    assert adhoc_cli.parser._actions[1].help == "The action's options in space separated k=v format: -a 'opt1=val1 opt2=val2'"
    assert adhoc_cli

# Generated at 2022-06-16 19:42:52.610270
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-16 19:43:14.228276
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc_cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:43:15.902669
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-16 19:43:16.604204
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:43:23.159218
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser object
    parser = adhoc_cli.create_parser()

    # Create a namespace object
    args = parser.parse_args(['-m', 'ping', 'localhost'])

    # Set the args attribute of the AdHocCLI object
    adhoc_cli.args = args

    # Call the run method of the AdHocCLI object
    adhoc_cli.run()

# Generated at 2022-06-16 19:43:31.461737
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser for AdHocCLI
    adhoc_cli.init_parser()

    # Create a option for AdHocCLI
    options = adhoc_cli.parser.parse_args(['-m', 'ping', 'localhost'])

    # Post process and validate options for bin/ansible
    adhoc_cli.post_process_args(options)

    # Run AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:43:33.012880
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:43:35.922180
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc_cli.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"

# Generated at 2022-06-16 19:43:37.573688
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-16 19:43:38.601562
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 19:43:45.844637
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    adhoc_cli = AdHocCLI()

    # Create an instance of parser
    parser = adhoc_cli.create_parser()

    # Create an instance of options
    options = parser.parse_args(['-m', 'ping', 'localhost'])

    # Set the options to context
    context.CLIARGS = options

    # Execute the run method
    adhoc_cli.run()

# Generated at 2022-06-16 19:44:28.357233
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create an instance of AdHocCLI
    adhoc_cli = AdHocCLI()
    # Create an instance of ArgumentParser
    parser = adhoc_cli.create_parser()
    # Create an instance of Namespace
    args = parser.parse_args()
    # Set the attributes of the Namespace instance
    args.module_name = 'ping'
    args.module_args = 'data=hello world'
    args.args = 'localhost'
    # Call method run of class AdHocCLI
    adhoc_cli.run()

if __name__ == '__main__':
    # Unit test for method run of class AdHocCLI
    test_AdHocCLI_run()

# Generated at 2022-06-16 19:44:39.897940
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser.usage == "%prog <host-pattern> [options]"
    assert adhoc.parser._actions[0].dest == "args"
    assert adhoc.parser._actions[0].metavar == "pattern"
    assert adhoc.parser._actions[0].help == "host pattern"
    assert adhoc.parser._actions[1].dest == "module_args"

# Generated at 2022-06-16 19:44:47.605385
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-16 19:44:48.191662
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:44:53.748175
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()
    # Create a parser object
    parser = adhoc_cli.create_parser()
    # Create a list of arguments
    args = ['-m', 'ping', '-a', 'data=hello', 'localhost']
    # Parse the arguments
    options = parser.parse_args(args)
    # Set the options to the context
    context.CLIARGS = options
    # Call the run method
    adhoc_cli.run()

# Generated at 2022-06-16 19:44:56.022367
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:44:57.321268
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-16 19:45:06.998247
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a context object
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'subset': '', 'listhosts': False, 'seconds': None, 'poll_interval': 15, 'tree': None, 'forks': 5}

    # Create a loader object
    loader = None

    # Create a inventory object
    inventory = None

    # Create a variable_manager object
    variable_manager = None

    # Create a passwords object
    passwords = {'conn_pass': None, 'become_pass': None}

    # Create a play_ds object

# Generated at 2022-06-16 19:45:08.488645
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:45:18.154139
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a context object

# Generated at 2022-06-16 19:46:31.114679
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc_cli = AdHocCLI()
    adhoc_cli.run()

# Generated at 2022-06-16 19:46:36.741371
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser object
    parser = adhoc_cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['-m', 'ping', '-a', 'data=hello world', 'localhost'])

    # Call method run of class AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:46:37.483508
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:46:44.057676
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser
    parser = adhoc_cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['-m', 'ping', 'localhost'])

    # Call method run of class AdHocCLI
    adhoc_cli.run()

# Generated at 2022-06-16 19:46:45.895069
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc_cli = AdHocCLI()
    assert adhoc_cli is not None

# Generated at 2022-06-16 19:46:50.775038
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Create a AdHocCLI object
    adhoc_cli = AdHocCLI()

    # Create a parser object
    parser = adhoc_cli.create_parser()

    # Parse the command line arguments
    options = parser.parse_args(['-m', 'ping', '-a', 'data=hello', 'localhost'])

    # Set the options
    adhoc_cli.options = options

    # Run the method
    adhoc_cli.run()

# Generated at 2022-06-16 19:46:57.232133
# Unit test for constructor of class AdHocCLI
def test_AdHocCLI():
    adhoc = AdHocCLI()
    assert adhoc.parser.prog == 'ansible'
    assert adhoc.parser.description == "Define and run a single task 'playbook' against a set of hosts"
    assert adhoc.parser.epilog == "Some actions do not make sense in Ad-Hoc (include, meta, etc)"
    assert adhoc.parser._positionals.title == 'positional arguments'
    assert adhoc.parser._optionals.title == 'optional arguments'
    assert adhoc.parser._option_string_actions['--args'].dest == 'module_args'
    assert adhoc.parser._option_string_actions['--module-name'].dest == 'module_name'
    assert adhoc.parser._positionals.metavar == 'pattern'


# Generated at 2022-06-16 19:47:08.776042
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': '', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': False, 'forks': 5}
    adhoc_cli = AdHocCLI()
    assert adhoc_cli.run() == 0

    # Test with hosts

# Generated at 2022-06-16 19:47:10.349348
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # TODO: Implement unit test for method run of class AdHocCLI
    pass

# Generated at 2022-06-16 19:47:11.332906
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    AdHocCLI.run()

# Generated at 2022-06-16 19:50:36.704036
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    pass

# Generated at 2022-06-16 19:50:38.185533
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    adhoc = AdHocCLI()
    adhoc.run()

# Generated at 2022-06-16 19:50:48.744503
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-16 19:50:58.503204
# Unit test for method run of class AdHocCLI
def test_AdHocCLI_run():
    # Test with no hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': '', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc = AdHocCLI()
    adhoc.run()

    # Test with hosts
    context.CLIARGS = {'module_name': 'ping', 'module_args': '', 'args': 'localhost', 'subset': '', 'listhosts': False, 'seconds': 0, 'poll_interval': 15, 'verbosity': 0, 'one_line': False, 'tree': None}
    adhoc = AdHocCLI()