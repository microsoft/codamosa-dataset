

# Generated at 2022-06-25 21:45:56.342042
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(None, None, None) is None
    assert get_input_output_paths('/home/foo/bar/',
                                  '/home/foo/bar/',
                                  '/home/foo/bar/') is not None

# Generated at 2022-06-25 21:46:00.542950
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_path = 'test_io_0.py'
    root = 'test_io.py'
    output_path = 'test_io_1.py'
    for i in get_input_output_paths(input_path, output_path, root):
        assert i.input_path.name == input_path
        assert i.output_path.name == output_path



# Generated at 2022-06-25 21:46:04.849803
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root_path = 'test_fixtures'
    input_path = 'test_fixtures/urllib/response.py'
    output_path = 'test_fixtures/'
    for path in get_input_output_paths(input_path, output_path, root_path):
        pass

# Generated at 2022-06-25 21:46:08.766171
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib.response'
    str_1 = 'urllib.response'
    str_2 = 'urllib.response'
    iterable_0 = get_input_output_paths(str_1, str_0, str_2)

# Generated at 2022-06-25 21:46:17.661015
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('urllib/response.py', 'urllib/', 'urllib')) == [
        InputOutput(Path('urllib/response.py'), Path('urllib/response.py'))
    ]

    assert list(get_input_output_paths('urllib/response.py', 'urllib/response.py', 'urllib')) == [
        InputOutput(Path('urllib/response.py'), Path('urllib/response.py'))
    ]

    assert list(get_input_output_paths('urllib/', 'urllib/', 'urllib')) == []

    assert list(get_input_output_paths('urllib/', 'urllib/response.py', 'urllib'))

# Generated at 2022-06-25 21:46:19.693928
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:22.971395
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib.response'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    # test.equal()
    # -> None
    # test.raises()
    # -> exception thrown

# Generated at 2022-06-25 21:46:33.828733
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input_, output_paths, root = Module_name
    output_paths = get_input_output_paths("urllib.response", "urllib.response", "urllib.response")
    print("Output Path is : ", end = '')
    print(output_paths)

    # Test input_, output_paths, root = Path_to_some_file
    output_paths = get_input_output_paths("test.py", "test.py", "test.py")
    print("Output Path is : ", end = '')
    print(output_paths)

# Update function to make Mock_input available
# def get_input_output_paths(input_: str, output: str,
#                            root: Optional[str]) -> Iterable[InputOutput]:
#    

# Generated at 2022-06-25 21:46:37.601990
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from . analyze import get_input_output_paths
    str_0 = 'urllib.response'
    list_0 = get_input_output_paths(str_0, str_0, str_0)
    for path in list_0:
        print(path)
    pass
# test case

# Generated at 2022-06-25 21:46:41.466973
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from hypothesis import given
    from .hypothesis_test_util import assert_equal

    @given(str, str, str)
    def test(input_, output, root):
        expect = [InputOutput(Path(input_), Path(output))]
        actual = list(get_input_output_paths(input_, output, root))
        assert_equal(expect, actual)
    test()

# Generated at 2022-06-25 21:46:45.478234
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:46:46.390432
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:46:52.099320
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('urllib/response.py', 'urllib/response.py', 'urllib/response.py')
    get_input_output_paths('urllib/abstractsgrp.py', 'urllib/response.py', 'urllib/response.py')

# Generated at 2022-06-25 21:46:56.691021
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib.response'
    str_1 = 'urllib.response'
    str_2 = 'urllib.response'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    assert isinstance(iterable_0, (Iterable, types.GeneratorType))


# Generated at 2022-06-25 21:47:06.321502
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("/python/stdlib/test_urllib", "", "") == [InputOutput(WindowsPath('/python/stdlib/test_urllib'), WindowsPath('/python/stdlib/test_urllib'))]
    assert get_input_output_paths("/python/stdlib/test_urllib", "/python/stdlib_std", "") == [InputOutput(WindowsPath('/python/stdlib/test_urllib'), WindowsPath('/python/stdlib_std/test_urllib'))]
    assert get_input_output_paths("/python/stdlib/test_urllib", ".py", "") == [InputOutput(WindowsPath('/python/stdlib/test_urllib'), WindowsPath('test_urllib.py'))]

# Generated at 2022-06-25 21:47:20.028849
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib.response'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    assert (InputOutput(Path('urllib/response.py'), Path('urllib/response.py')),) == iterable_0

    str_1 = 'urllib.response'
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)
    assert (InputOutput(Path('urllib/response.py'), Path('urllib/response.py')),) == iterable_1

    str_2 = 'urllib.response'
    iterable_2 = get_input_output_paths(str_2, str_2, str_2)

# Generated at 2022-06-25 21:47:21.076472
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:47:29.949896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test case 1
    str_0 = 'a.py'
    str_1 = 'b.py'
    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    res = next(iterable_0)
    assert res.input == Path(str_0)
    assert res.output == Path(str_1)

    # test case 2
    str_0 = 'a.py'
    str_1 = '/b'
    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    res = next(iterable_0)
    assert res.input == Path(str_0)
    assert res.output == (Path(str_1) / str_0)

    # test case 3
    str_

# Generated at 2022-06-25 21:47:35.466824
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib.response'
    str_1 = 'urllib.response'
    str_2 = 'urllib.response'
    obj_0 = get_input_output_paths(str_0, str_1, str_2)
    str_3 = 'urllib.request'
    str_4 = 'urllib.request'
    str_5 = 'urllib.response'
    obj_1 = get_input_output_paths(str_3, str_4, str_5)

# Generated at 2022-06-25 21:47:44.256030
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('urllib.request', 'urllib', 'urllib')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('urllib.request', 'urllib.responce', 'urllib')

    iterable_0 = get_input_output_paths('urllib.request', 'urllib.responce', 'urllib')
    iterable_1 = get_input_output_paths('urllib.request', 'urllib.response', 'urllib')
    iterable_2 = get_input_output_paths('urllib', 'urllib', 'urllib')

# Generated at 2022-06-25 21:47:56.394987
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from io import StringIO

    from contextlib import redirect_stdout

    from importlib import import_module

    import libfoolang

    root = libfoolang.get_data_path(__file__).joinpath('get_input_output_paths')

    sample_input = root.joinpath('sample.foo')
    sample_output = root.joinpath('sample.py')

    # input is a file
    input_ = 'sample.foo'
    output = '.'

    # get_input_output_paths(input_, output, root)
    assert list(get_input_output_paths(input_, output, root)) == [InputOutput(sample_input, sample_output)]

    # input is a file and output is a file
    input_ = 'sample.foo'

# Generated at 2022-06-25 21:47:58.063506
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths("test.py", "output.py", None)


# Generated at 2022-06-25 21:48:00.372433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a.txt', 'b.txt', 'c.txt') is None

# Generated at 2022-06-25 21:48:08.635332
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'false_path'
    output_0 = 'false_path'
    assert_raises(InputDoesntExists, get_input_output_paths, input_0, output_0, None)

    input_1 = '../input/builtins/builtins.py'
    output_1 = '../output/builtins/builtins.py'
    iterable_1 = get_input_output_paths(input_1, output_1, None)
    assert_equal(iterable_1.__next__().input_path, Path('../input/builtins/builtins.py'))
    assert_equal(iterable_1.__next__().output_path, Path('../output/builtins/builtins.py'))

    input_2 = '../input/builtins'
    output_2

# Generated at 2022-06-25 21:48:18.282085
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt')

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a', 'b.py')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py')

    pairs_0 = [
        InputOutput(Path('a.py'), Path('a.py')),
    ]
    assert list(get_input_output_paths('a.py', 'a.py')) == pairs_0


# Generated at 2022-06-25 21:48:26.729463
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:48:30.487738
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    p = Path(str(__file__))
    p = p.parent.parent.joinpath('examples')
    gen = get_input_output_paths(str(p), str(p), str(p))
    paths = list(gen)
    assert len(paths) == 3
    for item in paths:
        assert isinstance(item, InputOutput)


# Generated at 2022-06-25 21:48:34.852205
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('urllib.response','asd.py','urllib.response')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('urllib.response','urllib.response','urllib.response')

# Generated at 2022-06-25 21:48:36.626015
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    iterable_0 = get_input_output_paths('urllib.response', 'urllib.response', 'urllib.response')

# Generated at 2022-06-25 21:48:43.138992
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('.', '.', '.') == InvalidInputOutput
    assert get_input_output_paths('.', '', '.') == InputDoesntExists
    assert get_input_output_paths('.', '.', '') == InvalidInputOutput
    assert get_input_output_paths('', '', '') == InputDoesntExists
    assert get_input_output_paths('.', '.', '.') == InvalidInputOutput

# Generated at 2022-06-25 21:48:49.508791
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # input_ = './examples'
    # output = './examples_output'
    # list_path = get_input_output_paths(input_, output)
    pass

# Generated at 2022-06-25 21:48:59.715879
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'examples'
    output_0 = 'static'
    root_0 = None

# Generated at 2022-06-25 21:49:01.609746
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert  isinstance(get_input_output_paths(str_0, str_0, str_0), Iterable)


# Generated at 2022-06-25 21:49:10.022681
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = 'examples'
    input_ = 'examples/example_0.py'
    output = 'out/example_0.py'
    input_output = get_input_output_paths(input_, output, root)
    input_output_iter = iter(input_output)
    assert next(input_output_iter) == InputOutput('examples/example_0.py', 'out/example_0.py')
    try:
        next(input_output_iter)
    except StopIteration:
        pass
    else:
        raise AssertionError('StopIteration not raised')

    root = None
    input_ = 'examples'
    output = 'out'
    input_output = get_input_output_paths(input_, output, root)

# Generated at 2022-06-25 21:49:11.369032
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = get_input_output_paths('examples', 'examples', None)
    assert path


# Generated at 2022-06-25 21:49:21.001699
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    get_input_output_paths('examples/in_put', 'examples/out_put', 'examples')
    try:
        get_input_output_paths('examples/in_put', 'examples/out_put.py', 'examples')
        assert False
    except InvalidInputOutput:
        pass
    try:
        get_input_output_paths('examples/in_put.py', 'examples/out_put', 'examples')
        assert False
    except InvalidInputOutput:
        pass
    try:
        get_input_output_paths('examples/in_put.py', 'examples/out_put', 'examples')
        assert False
    except InvalidInputOutput:
        pass



# Generated at 2022-06-25 21:49:29.336297
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'examples'
    str_1 = '.'
    input_output = get_input_output_paths(str_0, str_1, None)
    assert hasattr(input_output, '__next__') is True
    #
    str_0 = 'examples/example0.py'
    str_1 = '.'
    input_output = get_input_output_paths(str_0, str_1, None)
    assert hasattr(input_output, '__next__') is True
    #
    str_0 = 'examples/example0.py'
    str_1 = 'examples'
    input_output = get_input_output_paths(str_0, str_1, None)
    assert hasattr(input_output, '__next__') is True
   

# Generated at 2022-06-25 21:49:36.145094
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:49:43.966026
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a = get_input_output_paths('examples', 'output', None)
    str_0 = 'examples'
    str_1 = 'output'
    str_2 = ''

# Generated at 2022-06-25 21:49:46.759395
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('examples','examples','examples') == \
    [InputOutput(posixpath('examples/fibonacci.py'), posixpath('examples/fibonacci.py'))]


# Generated at 2022-06-25 21:49:54.647414
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
      assert input.endswith('.py') and not output.endswith('.py'), "Error: Invalid input/output path"
    except :
      pass

# Generated at 2022-06-25 21:50:02.585447
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the get_input_output_paths function."""
    # Test case 1
    input_ = 'urllib'
    output = 'test'
    root = 'urllib'
    iterable_0 = get_input_output_paths(input_, output, root)
    list_0 = list(iterable_0)
    list_1 = [InputOutput(Path('urllib/response.py'), Path('urllib/response.py'))]
    assert list_0 == list_1

    # Test case 2
    input_ = 'urllib'
    output = 'test'
    root = ''
    iterable_0 = get_input_output_paths(input_, output, root)
    list_0 = list(iterable_0)

# Generated at 2022-06-25 21:50:09.020984
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'test_cases.py'
    str_1 = 'output.py'
    str_2 = 'test_cases.py'
    str_3 = 'output.py'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert var_0[0].input_path == Path(Path(str_0))
    assert var_0[0].output_path == Path(Path(str_3))

# Generated at 2022-06-25 21:50:10.409357
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 21:50:17.380369
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    get_input_output_paths(str_0, str_1, str_2)
    str_0 = ''
    str_1 = ''
    get_input_output_paths(str_0, str_1, None)
    try:
        str_0 = 'fixtures/raise.py'
        str_1 = 'fixtures/raise.py'
        get_input_output_paths(str_0, str_1, None)
    except InvalidInputOutput:
        pass
    else:
        assert False


# Generated at 2022-06-25 21:50:22.881440
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input_path.absolute() == 'urllib/response.py'
    assert var_0[0].output_path.absolute() == 'urllib/response.py'

# Generated at 2022-06-25 21:50:30.801375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0][1] == Path('urllib/response.py')
    assert var_0[0][0] == Path('urllib/response.py')
    str_1 = 'urllib/response.py'
    str_2 = 'urllib/response.py'
    str_3 = 'urllib/response.py'
    iterable_1 = get_input_output_paths(str_1, str_2, str_3)
    var_1 = list(iterable_1)

# Generated at 2022-06-25 21:50:38.948989
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input_path == Path(str_0)
    assert var_0[0].output_path == Path(str_0)

    str_0 = 'urllib/response.py'
    iterable_0 = get_input_output_paths(str_0, '.', str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input_path == Path(str_0)
    assert var_0[0].output_path == Path('./response.py')

# Generated at 2022-06-25 21:50:41.149709
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # var_0: List[InputOutput]
    test_case_0()
    


if __name__ == '__main__':
    import sys
    import nose2
    nose2.main()

# Generated at 2022-06-25 21:50:49.636117
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths("urllib/response.py",
                                           "urllib/response.py",
                                           "urllib/response.py"))) == 1
    assert len(list(get_input_output_paths("urllib",
                                           "urllib/response.py",
                                           None))) > 0
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("urllib/response.py", "urllib/response", None))
        list(get_input_output_paths("urllib/response", "urllib/response.py", None))

# Generated at 2022-06-25 21:51:13.755776
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    assert list(get_input_output_paths(str_0, str_0, str_0)) == [InputOutput(Path('urllib/response.py'), Path('urllib/response.py'))]
    str_0 = 'urllib/request.py'
    str_1 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path('urllib/request.py'), Path('urllib/request.py'))]
    str_0 = 'test_fixtures/input_nolint'

# Generated at 2022-06-25 21:51:17.383213
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'urllib/response.py'
    output = 'out'
    root = '/'
    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)
    assert var_0[0].input_path == Path('urllib/response.py')
    assert var_0[0].output_path == Path('out/response.py')

# Generated at 2022-06-25 21:51:25.033879
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('urllib/response.py',
                                           'urllib/response.py',
                                           'urllib/response.py'))) == 1
    assert len(list(get_input_output_paths('urllib/response.py',
                                           'urllib/response.py',
                                           'urllib'))) == 1
    assert len(list(get_input_output_paths('urllib/response2.py',
                                           'urllib/response.py',
                                           'urllib'))) == 1
    assert len(list(get_input_output_paths('./test/test_input',
                                           './test/test_output',
                                           './test'))) == 2



# Generated at 2022-06-25 21:51:32.421838
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        str_0 = 'urllib/response.py'
        str_1 = 'urllib/response_new.py'
        iterable_0 = get_input_output_paths(str_0, 'urllib/response_new.txt', str_1)
        var_0 = list(iterable_0)

    with pytest.raises(InputDoesntExists):
        str_0 = 'urllib/response.py'
        iterable_0 = get_input_output_paths('urllib/response_new.txt', str_0, str_0)
        var_0 = list(iterable_0)

    str_1 = 'urllib/response.py'
    iterable_0 = get_input_output_paths

# Generated at 2022-06-25 21:51:34.576026
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except Exception as e:
        print('An exception was thrown: ' + type(e).__name__ + '!')

# Generated at 2022-06-25 21:51:43.496845
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    str_3 = 'urllib/request.py'
    str_4 = 'urllib/response.py'
    iterable_1 = get_input_output_paths(str_3, str_4, str_4)
    var_1 = list(iterable_1)
    str_5 = 'urllib/response.py'
    str_6 = 'urllib/request.py'
    iterable_2 = get_input_output_paths(str_5, str_6, str_6)

# Generated at 2022-06-25 21:51:50.413371
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    with raises(InvalidInputOutput):
        get_input_output_paths('urllib/response', 'json', 'urllib')
    with raises(InputDoesntExists):
        get_input_output_paths('urllib/response1', 'urllib/response1',
                               'urllib/response1')
    assert isinstance(get_input_output_paths('urllib/response',
                                             'urllib/response',
                                             'urllib'),
                      Iterable)

# Generated at 2022-06-25 21:51:57.409483
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:52:01.268399
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    str_1 = 'urllib/test_response.py'

    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input_path == Path(str_0)
    assert var_0[0].output_path == Path(str_1)

# Generated at 2022-06-25 21:52:03.563267
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert str(test_case_0()[0].input) == 'urllib/response.py'
    assert str(test_case_0()[0].output) == 'urllib/response.py'

# Generated at 2022-06-25 21:52:44.188126
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ('../test/input/urllib.py')
    str_1 = ('../test/output/urllib.py')
    var_0 = get_input_output_paths(str_0, str_1, '../test/input')
    var_1 = list(var_0)
    var_2 = isinstance(var_1, list)
    assert(var_2 == True)

# Generated at 2022-06-25 21:52:49.871154
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('urllib/response.py', 'urllib/response.txt', 'urllib/response.py')
        
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('urllib/response.txt', 'urllib/response.py', 'urllib/response.py')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('!@#$%^&*()', 'urllib/response.py', 'urllib/response.py')


# Generated at 2022-06-25 21:52:56.147384
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    output_0 = Path(str_0)
    input_0 = Path(str_0)
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input_path == input_0
    assert var_0[0].output_path == output_0

# Generated at 2022-06-25 21:53:03.980490
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'urllib/response.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    int_0 = len(var_0)
    assert_equals(int_0, 1)
    str_1 = 'urllib/cookies.py'
    iterable_1 = get_input_output_paths(str_0, str_0, str_1)
    var_1 = list(iterable_1)
    assert_equals(var_1, var_0)
    int_1 = len(var_1)
    assert_equals(int_1, 1)

# Generated at 2022-06-25 21:53:13.787334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with assert_raises(InvalidInputOutput) as e:
        iterable_0 = get_input_output_paths('urllib/response.py', 'test_result/urllib.py', 'urllib')
    with assert_raises(InputDoesntExists) as e:
        iterable_0 = get_input_output_paths("I don't exist", 'test_result/urllib.py', 'urllib')
    with assert_raises(InputDoesntExists) as e:
        iterable_0 = get_input_output_paths("urllib/response.py/not", 'test_result/urllib.py', 'urllib')
    str_0 = 'urllib/response.py'

# Generated at 2022-06-25 21:53:19.652647
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'tests/fixtures/urllib'
    str_1 = 'tests/fixtures/urllib'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    var_0 = list(iterable_0)
    assert var_0[0].input_file == Path('tests/fixtures/urllib/request.py')
    assert var_0[0].output_file == Path('tests/fixtures/urllib/request.py')
    assert var_0[1].input_file == Path('tests/fixtures/urllib/response.py')
    assert var_0[1].output_file == Path('tests/fixtures/urllib/response.py')

# Generated at 2022-06-25 21:53:30.204161
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Prepare test data
    str_0 = "./tests/data/input/urllib/response.py"
    str_1 = "./tests/data/output/urllib/response.py"
    iterable_0 = get_input_output_paths(str_0, str_1, "./tests/data/input/urllib")
    var_0 = list(iterable_0)
    assert var_0 is not None, "Expected is not None"
    assert len(var_0) == 1, "Expected is 1"
    var_1 = var_0[0]
    assert var_1.input_path.as_posix() == str_0, "Expected is {}".format(str_0)

# Generated at 2022-06-25 21:53:32.712241
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(1, 2, 3) == iter((),)

if __name__ == "__main__":
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:53:33.867594
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

test_get_input_output_paths()

print('unit_test completed')

# Generated at 2022-06-25 21:53:36.744580
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    s = 'urllib/response.py'
    iterable = get_input_output_paths(s, s, s)
    var = list(iterable)

    assert isinstance(var, list)
    assert len(var) == 1
    assert isinstance(var[0].input_path, Path)
    assert isinstance(var[0].output_path, Path)