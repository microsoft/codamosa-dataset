

# Generated at 2022-06-25 21:46:00.786330
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_1 = ''
    str_0 = 'Ozk-=s1FgW8s[ny'
    path_0 = Path(str_0)
    str_2 = '1VItCK_fka'
    str_3 = 'PwEOKkDrD@8ju9'
    str_4 = 'fjyW2[8.py'
    # Test.assert_equals(
    #     next(
    #         get_input_output_paths(str_3, str_3, str_3)
    #     ), InputOutput(path_0, path_0)
    # )
    # Test.assert_equals(
    #     next(
    #         get_input_output_paths(str_4, str_1, None)
    #     ), InputOutput

# Generated at 2022-06-25 21:46:11.343332
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'd+tVi*ZMO/fGs=R`G'
    output = 'd+tVi*ZMO/fGs=R`G'
    root = 'd+tVi*ZMO/fGs=R`G'  # type: ignore
    iterable_0 = get_input_output_paths(input_, output, root)
    assert len(iterable_0) == 1
    assert list(iterable_0)[0].input == Path(input_)
    assert list(iterable_0)[0].output == Path(output)

    input_ = 'd+tVi*ZMO/fGs=R`G'
    output = 'd+tVi*ZMO/fGs=R`G'
    root = 'd+tVi*ZMO/fGs=R`H' 

# Generated at 2022-06-25 21:46:12.737797
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('some input', 'some output', None)

# Generated at 2022-06-25 21:46:20.136547
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        # Case 1
        str_0 = './bp/test/test_input.py'
        str_1 = './bp/test/test_output.py'
        iterable_0 = get_input_output_paths(str_0, str_1, None)
        if (str(iterable_0[0][0]) == str_0 and str(iterable_0[0][1]) == str_1):
            print("test 1 passed")
        else:
            print("test 1 failed")
    except InputDoesntExists as e:
        print("test 1 failed")
    except InvalidInputOutput as e:
        print("test 1 failed")
    except Exception as e:
        print("test 1 failed")


# Generated at 2022-06-25 21:46:21.861334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

# Generated at 2022-06-25 21:46:29.669557
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'foo.py'
    input_1 = 'bar.py'
    output_0 = 'bar.py'
    output_1 = 'foo.py'
    root = 'root'
    input_outputs = list(get_input_output_paths(input_0, output_0, root))
    input_outputs.extend(list(get_input_output_paths(input_1, output_1, root)))
    input_output = input_outputs[0]
    assert input_output
    input_output.input
    input_output.output

# Generated at 2022-06-25 21:46:31.574753
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:46:40.191798
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('d+tVi*ZMO/fGs=R`G', 'd+tVi*ZMO/fGs=R`G', 'd+tVi*ZMO/fGs=R`G') == 19.0
    assert get_input_output_paths('Y-gf.j', 'Y-gf.j', 'Y-gf.j') == 2.0

# Generated at 2022-06-25 21:46:44.352408
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert not hasattr(get_input_output_paths, '__call__'), 'Function should not have the __call__ method'  # noqa
    __tracebackhide__ = True
    assert not hasattr(get_input_output_paths, '__name__'), 'Function should not have the __name__ attribute'  # noqa



# Generated at 2022-06-25 21:46:55.655976
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'lz\ue9d3)qXD$m6_mum'
    assert not get_input_output_paths(str_0, str_0, str_0).__next__()
    str_0 = 'jKb:=T7Z,Q+/C/7-`X'
    assert True is get_input_output_paths(str_0, str_0, str_0).__next__().__contains__(str_0)
    str_0 = 'd+tVi*ZMO/fGs=R`G'
    assert True is get_input_output_paths(str_0, str_0, str_0).__next__().__contains__(str_0)

# Generated at 2022-06-25 21:47:00.639375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test function
    print("Testing get_input_output_paths")
    try:
        test_case_0()
    except IOError as e:
        print("I/O error: {0}".format(e))
    except ValueError:
        print("Could not convert data to an integer")
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise
    else:
        print("No exception was raised")

# Generated at 2022-06-25 21:47:07.731743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert repr(get_input_output_paths(None, None, None)) == '<generator object get_input_output_paths at 0x109dffaf8>'
    str_0 = 'd+tVi*ZMO/fGs=R`G'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    str_1 = 'g?\\'
    str_2 = str_1
    try:
        get_input_output_paths(str_1, str_2, str_2)
    except InputDoesntExists:
        assert True
    else:
        assert False
    try:
        get_input_output_paths(str_2, str_1, str_2)
    except InvalidInputOutput:
        assert True

# Generated at 2022-06-25 21:47:14.967368
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path(__file__).parent.parent
    input_outputs = get_input_output_paths(str(root), '.', None)
    for input_output in input_outputs:
        assert input_output.input.suffix == '.py'



# Generated at 2022-06-25 21:47:21.338795
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '/'
    str_1 = '*'
    str_2 = '/tmp'

    import types

    assert isinstance(get_input_output_paths(str_0, str_0, str_0), types.GeneratorType)

    iterable_0 = get_input_output_paths(str_1, str_0, str_2)
    int_0 = 0
    for item_0 in iterable_0:
        int_0 += 1

    assert int_0 == 0




# Generated at 2022-06-25 21:47:30.152412
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Input/output: d+tVi*ZMO/fGs=R`G, d+tVi*ZMO/fGs=R`G
    assert expected_paths == get_input_output_paths(input_, output, root)

    # Input/output: d+tVi*ZMO/fGs=R`G, d+tVi*ZMO/fGs=R`G
    assert expected_paths == get_input_output_paths(input_, output, root)


if __name__ == '__main__':
    """
    First, print out the generated test cases, 
    and run this file as python script.
    """
    try:
        from testcase import *
    except ImportError:
        pass
    test_get_input_output_paths()

# Generated at 2022-06-25 21:47:37.162182
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'X'
    str_1 = 'Bw'
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(str_0, str_1, str_1)
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(str_1, str_0, str_1)
    str_1 = 'B(~'
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(str_0, str_1, str_0)
    str_2 = 'd+tVi*ZMO/fGs=R`G'
    iterable_0 = get_input_output_paths(str_2, str_2, str_2)
    str_1 = 'B('
    str

# Generated at 2022-06-25 21:47:45.697665
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '1.py'
    str_1 = '2.py'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    assert list(iterable_0)[0].input == Path(str_0)
    assert list(iterable_0)[0].output == Path(str_1)
    str_2 = 'input.py'
    str_3 = 'output/'
    iterable_1 = get_input_output_paths(str_2, str_3, None)
    assert list(iterable_1)[0].input == Path(str_2)
    assert list(iterable_1)[0].output == Path(str_3).joinpath(Path(str_2).name)
    str_4 = '.'

# Generated at 2022-06-25 21:47:51.573722
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Define variables for function get_input_output_paths
    arg0 = None
    arg1 = None
    arg2 = None
    ret = None

    # Setup and call function get_input_output_paths
    str_0 = 'jMx@x,o'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)

    # Test function get_input_output_paths
    assert not ret
    assert len(next(iterable_0)) == 2
    assert len(next(iterable_0)) == 2



# Generated at 2022-06-25 21:48:00.284503
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from random import randrange
    from random import randint

    for i in range(50):
        input_ = ''
        for j in range(randrange(1, 50 + 1)):
            input_ += chr(randint(32, 126))
        output = ''
        for j in range(randrange(1, 50 + 1)):
            output += chr(randint(32, 126))
        root = ''
        for j in range(randrange(1, 50 + 1)):
            root += chr(randint(32, 126))
        iterable_0 = get_input_output_paths(input_, output, root)


if __name__ == '__main__':
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:48:01.110873
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:08.361226
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('./test_data/test1', 'output.py', None) == \
        InputOutput(Path('test1.py'), Path('output.py'))
    assert get_input_output_paths('./test_data/test2', 'output.py', None) == \
        InputOutput(Path('test2.py'), Path('output.py'))
    assert get_input_output_paths('./test_data/test3', 'output.py', None) == \
        InputOutput(Path('test3.py'), Path('output.py'))
    # with pytest.raises(InvalidInputOutput):
    #     get_input_output_paths('./test_data/test4', 'output.py', None)
    # with pytest.raises(

# Generated at 2022-06-25 21:48:18.033880
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1: filea.py -> filea.py
    str_0 = Path('filea.py')
    expected_0 = [InputOutput(Path('filea.py'), Path('filea.py'))]
    actual_0 = [io for io in get_input_output_paths(str_0, str_0, None)]
    assert expected_0 == actual_0, 'Test 1 failed'

    # Test 2: filea.py -> fileb.py
    str_0 = Path('filea.py')
    str_1 = Path('fileb.py')
    expected_0 = [InputOutput(Path('filea.py'), Path('fileb.py'))]
    actual_0 = [io for io in get_input_output_paths(str_0, str_1, None)]

# Generated at 2022-06-25 21:48:18.814824
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:22.557604
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'd+tVi*ZMO/fGs=R`G'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:48:23.920903
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True  # TODO: implement your test here

# Unit tests for function InputDoesntExists

# Generated at 2022-06-25 21:48:26.729645
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Running tests for function get_input_output_paths')
    try:
        test_case_0()
    except Exception as e:
        print(f'Handled exception in test case {e}')


# Generated at 2022-06-25 21:48:35.364253
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_0 = Path('input.py')
    path_1 = Path('output.py')
    iterable_0 = get_input_output_paths(str(path_0), str(path_1), str(path_0.parent))
    iterator_0 = iter(iterable_0)
    assert next(iterator_0) == InputOutput(path_0, path_1)
    path_2 = Path('input/input.py')
    path_3 = Path('output/input.py')
    iterable_1 = get_input_output_paths(str(path_2), str(path_3), str(path_2.parent))
    iterator_1 = iter(iterable_1)
    assert next(iterator_1) == InputOutput(path_2, path_3)

# Generated at 2022-06-25 21:48:44.710771
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('py/tbot/dummy/dummy.py', 'py/tbot/dummy/dummy.py', None)
    assert get_input_output_paths('py/tbot/dummy/dummy.py', 'py/tbot/dummy', None)
    assert get_input_output_paths('py/tbot/dummy', 'py/tbot/dummy/dummy.py', 'py/tbot/dummy')
    assert get_input_output_paths('py/tbot/dummy', 'py/tbot/dummy', 'py/tbot/dummy')

# Generated at 2022-06-25 21:48:49.867247
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from hypothesis import given
    from hypothesis import strategies as st
    from os import path
    from pathlib import Path
    from .exceptions import InputDoesntExists

    @given(s = st.text())
    def test(s):
        try:
            for element in get_input_output_paths(s, s, s):
                assert isinstance(element, InputOutput)
        except InputDoesntExists as e:
            pass

    test()

# Generated at 2022-06-25 21:49:00.081391
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(get_input_output_paths('sztYRX(VZxu', 'sztYRX(VZxu', 'sztYRX(VZxu')) == 0
    assert len(get_input_output_paths('Mn_<o=a]', 'Mn_<o=a]', 'Mn_<o=a]')) == 0
    assert len(get_input_output_paths('wuP>A*zJ$', 'wuP>A*zJ$', 'wuP>A*zJ$')) == 0
    assert len(get_input_output_paths('_CeYg<]yh]', '_CeYg<]yh]', '_CeYg<]yh]')) == 0

# Generated at 2022-06-25 21:49:17.124990
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    input_output = get_input_output_paths("./test_file/test_file_0.py", "./test_file/test_file_0_cops.py", ".")
    for i in input_output:
        if i.input_path.name == "test_file_0.py" and i.output_path.name == "test_file_0_cops.py":
            assert True
        else:
            assert False

    input_output = get_input_output_paths("./test_file/test_file_0.py", "./test_file_0_cops", ".")

# Generated at 2022-06-25 21:49:21.001795
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test all branches
    # Test the return value is correct.
    assert str(get_input_output_paths('a', 'b', 'c')) == "[InputOutput(src='a', dst='b')]"
    test_case_0()


# Test that get_input_output_paths raises InvalidInputOutput when given a wrong input

# Generated at 2022-06-25 21:49:29.335696
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = os.getcwd()
    str_0 = os.path.join(path,"test_input/")
    str_1 = os.path.join(path,"test_output/")
    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path(str_0+"a.py"),Path(str_1+"a.py"))]
    assert len(var_0) == 1
    assert isinstance(var_0[0],InputOutput)
    try:
        get_input_output_paths(str_0+"a.py", str_1+"a.py", str_0)
    except InvalidInputOutput:
        pass

# Generated at 2022-06-25 21:49:35.731289
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a','a','a') != None

# Generated at 2022-06-25 21:49:39.224278
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(str, str, str) == get_input_output_paths(str, str, str)

# Generated at 2022-06-25 21:49:42.415788
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert test_case_0() == 'Expected'
    except:
        assert test_case_0() == 'Excepted'

# Generated at 2022-06-25 21:49:43.466997
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("", "a.py", None) is not None

# Generated at 2022-06-25 21:49:50.418416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('tests/fixtures/foo.py', 'tests/fixtures/bar.py', None))\
        == InputOutput(Path('tests/fixtures/foo.py'), Path('tests/fixtures/bar.py')), "Line 15"
    assert next(get_input_output_paths('tests/fixtures/foo.py', 'tests/fixtures/bar', None))\
        == InputOutput(Path('tests/fixtures/foo.py'), Path('tests/fixtures/bar/foo.py')), "Line 16"

# Generated at 2022-06-25 21:49:57.606497
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_0 = Path('/path/to/input')
    path_1 = Path('/path/to/output')

    assert next(get_input_output_paths(path_0, path_1, None)) == \
        InputOutput(path_0, path_1)

    with raises(InvalidInputOutput):
        get_input_output_paths('input', 'output', None)

    with raises(InputDoesntExists):
        get_input_output_paths(path_0 / 'unknown', path_1, None)

# Generated at 2022-06-25 21:49:59.931381
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('files/file.py', 'files/out.py', 'root') == [InputOutput(Path('files/file.py'), Path('files/out.py'))]


# Generated at 2022-06-25 21:50:14.831193
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Test #1')
    assert list(get_input_output_paths('../input/', '../output/', '../input/')) == \
        [InputOutput(Path('../input/__init__.py'), Path('../output/__init__.py')),
         InputOutput(Path('../input/foo_bar.py'), Path('../output/foo_bar.py')),
         InputOutput(Path('../input/test_foo_bar.py'), Path('../output/test_foo_bar.py'))]
    print('Test #2')

# Generated at 2022-06-25 21:50:23.117903
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    dir_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-25 21:50:25.825887
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
#     assert var_0 == [(Path('.'), Path('.'))]

# Generated at 2022-06-25 21:50:27.061503
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:50:28.615813
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Test with a mock of pathlib.Path

# Generated at 2022-06-25 21:50:29.976257
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test default case
    assert get_input_output_paths('', '', '') is None



# Generated at 2022-06-25 21:50:33.103693
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = ''
    output = ''
    root = ''
    assert list(get_input_output_paths(input_, output, root)) == []


if __name__ == '__main__':
    # test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:34.894630
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # AssertionError: Path('0').joinpath(Path('0')) != Path('0')
    with pytest.raises(AssertionError):
        test_case_0()

# Generated at 2022-06-25 21:50:39.975694
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('', '', ''))) == 0
    assert get_input_output_paths('.', '.', None)
    assert get_input_output_paths('.', '', None)
    assert get_input_output_paths('', '.', None)
    assert get_input_output_paths('.', '.', '.')

# Generated at 2022-06-25 21:50:47.422466
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for _ in range(1, 10):
        if 'arg' in globals():
            del arg
        _str = 'str'
        _int = 1
        _float = 1e-4
        _list = [_str, _int, _float]
        _dict = globals()
        _ = _str * _int
        _ = _int / _int
        _ = _int + _int
        _ = _int - _int
        _ = _int % _int
        _ = _int | _int
        _ = _int ^ _int
        _ = _int & _int
        _ = _int >> _int
        _ = _int << _int
        _ = -_int
        _ = ~_int
        _ = _int ** _int
        _ = _int // _int

# Generated at 2022-06-25 21:50:53.038182
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1

# Generated at 2022-06-25 21:51:01.802903
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''

    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)

    str_1 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_1 = list(iterable_0)

    str_0 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_2 = list(iterable_0)

    str_1 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)

# Generated at 2022-06-25 21:51:03.083487
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a', 'b', 'c') == [('a', 'b')]

# Generated at 2022-06-25 21:51:11.927923
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths("", "", "", ))) == 0
    assert len(list(get_input_output_paths("", "", "", ))) == 0
    assert len(list(get_input_output_paths("", "", "", ))) == 0
    assert len(list(get_input_output_paths("", "", "", ))) == 0
    assert len(list(get_input_output_paths("", "", "", ))) == 0


# Development tool to run the unit tests
# Run by executing 'python3 -m unittest -v tests'
if __name__ == '__main__':
    import unittest
    unittest.main(exit=False)

# Generated at 2022-06-25 21:51:15.975033
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("", "", "")

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("", "", "")

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("", "", "")

# Generated at 2022-06-25 21:51:18.758941
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

if __name__ == "__main__":
    import sys, traceback
    # run any unit tests
    try:
        test_get_input_output_paths()
    except AssertionError as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback)
        raise
    else:
        print('Passed all unit tests!')

# Generated at 2022-06-25 21:51:27.055523
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_1, str_0, str_2)
    var_0 = list(iterable_0)
    str_3 = "path to python file"
    str_4 = "different path to python file"
    iterable_1 = get_input_output_paths(str_3, str_4, str_0)
    var_1 = list(iterable_1)
    str_5 = "dir"
    str_6 = "dir/to"
    str_7 = "dir/to"
    str_8 = "dir/to"
    str_9 = "dir/to"

# Generated at 2022-06-25 21:51:28.804092
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(
        'input_0', 'output_0', 'root_0'), 'incorrect result for get_input_output_paths'

# Generated at 2022-06-25 21:51:37.223766
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Setup
    str_0 = ''
    str_1 = ''
    dict_0 = {}
    int_0 = 0
    # AssertionError
    try:
        var_0 = get_input_output_paths(str_0, str_1, dict_0)
    except AssertionError as exc:
        print(exc)
    # AssertionError
    try:
        var_0 = get_input_output_paths(str_0, int_0, str_0)
    except AssertionError as exc:
        print(exc)
    # AssertionError
    try:
        var_0 = get_input_output_paths(str_0, str_0, int_0)
    except AssertionError as exc:
        print(exc)
    # Assertion

# Generated at 2022-06-25 21:51:44.884325
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths), "[FAILED] - function get_input_output_paths is not defined"
    assert isinstance(get_input_output_paths('str_0', 'str_0', 'str_0'), Iterable), "[FAILED] - function get_input_output_paths does not return an Iterable"
    assert list(get_input_output_paths('str_0', 'str_0', 'str_0')) == [InputOutput(Path(), Path())]
    assert list(get_input_output_paths('tests/test_case.py', 'out', 'tests')) == [InputOutput(Path('tests/test_case.py'), Path('out/test_case.py'))]

# Generated at 2022-06-25 21:52:06.183476
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = 't'
    str_2 = 'a'
    list_0 = []
    for _ in range(10):
        list_0.append(str_2)
    str_3 = ''.join(list_0)
    str_4 = 't'
    str_5 = 'a'
    str_6 = ''.join([str_4, str_5])
    str_7 = 't'
    str_8 = 'a'
    str_9 = ''.join([str_7, str_8])
    s = str_9
    str_10 = 't'
    str_11 = 'a'
    str_12 = ''.join([str_10, str_11])
    str_13 = 't'
    str_14 = 'a'

# Generated at 2022-06-25 21:52:14.852166
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    f = 'tests/data/fixtures/tests_a/*.py'
    o = 'tests/data/fixtures/output/tests_a'
    root = 'tests/data/fixtures/tests_a'

    input_output = get_input_output_paths(f, o, root)

# Generated at 2022-06-25 21:52:17.153646
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:52:18.153762
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1  # TODO: implement your test here



# Generated at 2022-06-25 21:52:26.467017
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    for i in range(100):
        with pytest.raises(InvalidInputOutput):
            get_input_output_paths('./tests/data/input.py', './tests/data/output.txt', None)

    for i in range(100):
        with pytest.raises(InputDoesntExists):
            get_input_output_paths('./tests/data/input.py.in', './tests/data/output.txt', None)

    str_0 = './tests/data'
    iterable_0 = get_input_output_paths('./tests/data/main.py', './tests/data/output.py', str_0)
    var_0 = list(iterable_0)
    str_1 = 'main'
    assert var_0[0].input.name

# Generated at 2022-06-25 21:52:33.417869
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    i = './example'
    o = './example_out'

    paths = sorted(get_input_output_paths(i, o, None), key=lambda x: x.input)
    assert paths == [
        InputOutput(Path('./example/module_a.py'), Path('./example_out/module_a.py')),
        InputOutput(Path('./example/module_b.py'), Path('./example_out/module_b.py')),
        InputOutput(Path('./example/module_c.py'), Path('./example_out/module_c.py')),
        InputOutput(Path('./example/module_d.py'), Path('./example_out/module_d.py')),
    ]


# Generated at 2022-06-25 21:52:40.739908
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'test.py'
    output_0 = 'test.py'
    root_0 = "test_files"
    input_0 = 'test_files/test.py'
    iterable_0 = get_input_output_paths(str_0, output_0, root_0)
    var_0 = list(iterable_0)
    test_0 =  (var_0[0].input.name == input_0 and var_0[0].output.name == output_0)
    assert test_0


# Generated at 2022-06-25 21:52:44.534325
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'zits Ywvks'
    output_0 = 'Y/oJly'
    root_0 = '.,Fz'
    iterable_0 = get_input_output_paths(input_0, output_0, root_0)
    var_0 = list(iterable_0)



# Generated at 2022-06-25 21:52:48.872157
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    if not test_case_0():
        print('Failed test case 0')
        return
    if not test_case_1():
        print('Failed test case 1')
        return
    if not test_case_2():
        print('Failed test case 2')
        return
    if not test_case_3():
        print('Failed test case 3')
        return
    if not test_case_4():
        print('Failed test case 4')
        return
    if not test_case_5():
        print('Failed test case 5')
        return



# Generated at 2022-06-25 21:52:51.994118
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with 0 params
    iterable_0 = get_input_output_paths(str(), str(), str())
    assert len(list(iterable_0)) == 0
    # Test with 1 params


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 21:53:12.878540
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:53:16.703912
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    input_output = var_0[0]
    assert input_output.input_path == Path(str_0).resolve()
    assert input_output.output_path == Path(str_1).resolve()



# Generated at 2022-06-25 21:53:23.668777
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

    str_1 = ''
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)
    var_1 = list(iterable_1)

    str_2 = ''
    iterable_2 = get_input_output_paths(str_2, str_2, str_2)
    var_2 = list(iterable_2)

    str_3 = ''
    iterable_3 = get_input_output_paths(str_3, str_3, str_3)
    var_3 = list(iterable_3)

    str_4 = ''


# Generated at 2022-06-25 21:53:31.280011
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from os import mkdir
    from os.path import join, expanduser, dirname
    from shutil import rmtree
    from tempfile import mkdtemp

    def create_py_file(path: str):
        with open(path, 'w'):
            pass

    def create_folder(path: str) -> str:
        Path(path).mkdir(parents=True, exist_ok=True)
        return path

    def create_py_folder(path: str) -> str:
        create_folder(path)
        py_path = join(path, 'test.py')
        create_py_file(py_path)
        return py_path


# Generated at 2022-06-25 21:53:37.033784
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # input_: str
    input__0 = "str_0"
    # output: str
    output_0 = "str_1"
    # root: Optional[str]
    root_0 = "str_2"
    # value: Iterable[InputOutput]
    value_0 = get_input_output_paths(input__0, output_0, root_0)
    # value: Iterable[InputOutput]
    value_1 = get_input_output_paths(input__0, output_0, None)
    # value: Iterable[InputOutput]
    value_2 = get_input_output_paths(input__0, output_0, None)
    # value: Iterable[InputOutput]

# Generated at 2022-06-25 21:53:41.193212
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'test_files/'
    input_1 = 'test_files1/'
    output_0 = get_input_output_paths(input_0, input_1, None)
    output_1 = get_input_output_paths(input_0, input_0, None)
    output_2 = get_input_output_paths(input_0, input_1, 'test_files')
    
    assert output_0 == list()
    assert output_1 == list()
    assert output_2 == list()

# Generated at 2022-06-25 21:53:43.123614
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InputDoesntExists) as ex:
        list(get_input_output_paths('inp', 'out', 'root'))
    assert ex.value.message == 'Input doesnt exists.'



# Generated at 2022-06-25 21:53:43.724706
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()



# Generated at 2022-06-25 21:53:48.896823
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case with arguments that the function is expected to receive.
    assert list(get_input_output_paths('a', 'b', 'c')) == [InputOutput(Path('a'), Path('b/a'))], \
        'incorrect handling of parameter \'input_\''

    # Test case with arguments that the function is not expected to receive.
    try:
        get_input_output_paths(1.0, 'a', 'b')
    except InvalidInputOutput:
        assert True
    else:
        assert False, 'function get_input_output_paths does not handle unexpected parameter \'input_\''

    # Test case with arguments that the function is not expected to receive.

# Generated at 2022-06-25 21:53:49.915106
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert None is not get_input_output_paths

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4 autoindent

# Generated at 2022-06-25 21:54:39.480683
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

    output_path = 'test.py'
    input_path = 'test_folder'

    input_output_paths = list(get_input_output_paths(input_path, output_path, None))
    assert len(input_output_paths) == 11
    assert str(input_output_paths[0].input_path) == 'test_folder/__init__.py'
    assert str(input_output_paths[0].output_path) == 'test.py/__init__.py'



# Generated at 2022-06-25 21:54:40.155140
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:54:40.581433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:54:41.636761
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_cases = [
        # TODO: add tests
    ]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 21:54:43.485463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = get_input_output_paths('input-3', 'output-3', None)
    assert next(result) == InputOutput(Path('input/input-3.py'), Path('output-3/input-3.py'))

# Generated at 2022-06-25 21:54:46.448995
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # These values will be used as arguments to call the function.
    # You can modify this to test different inputs.
    arg0 = ''
    arg1 = ''
    arg2 = ''

    # Call the function with the above arguments.
    # You can replace this with the values the function should return.
    ret = ''

    # You can modify this to test different outputs.
    assert ret == ''


# Generated at 2022-06-25 21:54:46.824431
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert False

# Generated at 2022-06-25 21:54:48.871985
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Main entry point of the script
if __name__ == "__main__":
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:54:53.872092
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Check that files are processed correctly
    # (output is not a file, input is a file)
    assert list(get_input_output_paths('input.py', 'output', 'input.py')) == \
        [InputOutput(Path('input.py'), Path('output/input.py'))]
    # (output is a file, input is a file)
    assert list(get_input_output_paths('input.py', 'output.py', 'input.py')) == \
        [InputOutput(Path('input.py'), Path('output.py'))]
    # Check that folder is processed correctly

# Generated at 2022-06-25 21:54:59.498325
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test 1
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('.txt', '.py', '')

    # test 2
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths('fake.py', 'test.py', '')

    # test 3
    assert get_input_output_paths('test.py', 'test.py', '') == (Path('test.py'), Path('test.py'))

    # test 4
    assert get_input_output_paths('test.py', '', '') == (Path('test.py'), Path('test.py'))

    # test 5