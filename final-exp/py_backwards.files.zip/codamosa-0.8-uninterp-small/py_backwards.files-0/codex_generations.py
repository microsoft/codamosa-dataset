

# Generated at 2022-06-25 21:45:53.955291
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput as e:
        pass
    except InputDoesntExists as e:
        pass
    else:
        assert False

# Test file for cases
test.support.run_unittest(__name__)

# Generated at 2022-06-25 21:45:56.235784
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        assert True
    except:
        assert False

# Generated at 2022-06-25 21:45:57.051462
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1

# Generated at 2022-06-25 21:45:58.513656
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(test_case_0) == 0
# Test with coverage
test_get_input_output_paths()

# Generated at 2022-06-25 21:46:03.039362
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test 0
    try:
        test_case_0()
        assert False
    except InvalidInputOutput:
        assert True

    # test 1
    try:
        test_case_0()
        assert False
    except InputDoesntExists:
        assert True
 

if __name__ == '__main__':
    for test in [func for name, func in list(globals().items()) if name.startswith('test_')]:
        try:
            test()
        except:
            print('%s failed' % test)
            raise

# Generated at 2022-06-25 21:46:04.298414
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Generated at 2022-06-25 21:46:05.819600
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("%':", "%':", "%':")

# Generated at 2022-06-25 21:46:09.135553
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for i in range(10):
        str_0 = "%':"
        iterable_0 = get_input_output_paths(str_0, str_0, str_0)


# Unit tests for program implementation

# Generated at 2022-06-25 21:46:10.602776
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    print("Success!")

# Main function

# Generated at 2022-06-25 21:46:14.174643
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        assert True
    except InputDoesntExists:
        assert True
    else:
        assert False


if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-25 21:46:32.025961
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists
    input_output_list = list(get_input_output_paths('input/foo.py', 'output/foo.py', None))
    assert input_output_list == [InputOutput(Path('input/foo.py'), Path('output/foo.py'))]

    input_output_list = list(get_input_output_paths('input', 'output', None))
    assert input_output_list == [InputOutput(Path('input/foo.py'), Path('output/foo.py'))]

    input_output_list = list(get_input_output_paths('input', 'output', 'input'))

# Generated at 2022-06-25 21:46:40.476850
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with None root, not a folder output and a file ending in .py
    input_ = "test/examples/input_output_examples/file1.py"
    output = "test/examples/input_output_examples/file2.py"
    paths = None
    result = [input_, output]
    assert tuple(get_input_output_paths(inputs=input_, output=output, root=paths)) == tuple(result), "Should be equal"

    # Test with None root, a folder output and a file ending in .py
    input_ = "test/examples/input_output_examples/file1.py"
    output = "test/examples/input_output_examples"
    paths = None

# Generated at 2022-06-25 21:46:50.911314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # InputOutput(input_, output)
    assert set(get_input_output_paths('data/input.py', 'data/output.py', None)) == set([InputOutput(Path('data/input.py'), Path('data/output.py'))])

    # InputOutput(input_, 'data/output/input.py')
    assert set(get_input_output_paths('data/input.py', 'data/output', None)) == set([InputOutput(Path('data/input.py'), Path('data/output/input.py'))])

    # InputOutput(input_, 'data/output/child.py')

# Generated at 2022-06-25 21:46:56.875413
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_outputs = get_input_output_paths('.', 'out', None)
    assert input_outputs is not None
    input_outputs = get_input_output_paths('.', 'out', '')
    assert input_outputs is not None
    input_outputs = get_input_output_paths('.', 'out', '.')
    assert input_outputs is not None



# Generated at 2022-06-25 21:47:06.487499
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths(
        '/home/root/pyproject.toml', '/home/user/output/pyproject.toml', None))
    assert paths == [InputOutput(Path('/home/root/pyproject.toml'), Path('/home/user/output/pyproject.toml'))]

    paths = list(get_input_output_paths(
        '/home/root/pyproject.toml', '/home/user/output', None))
    assert paths == [InputOutput(Path('/home/root/pyproject.toml'), Path('/home/user/output/pyproject.toml'))]


# Generated at 2022-06-25 21:47:20.091862
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import re
    import shutil
    import os
    import pathlib
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        (pathlib.Path(tmpdir) / 'foo.py').write_text('pass')
        (pathlib.Path(tmpdir) / 'bar.py').write_text('pass')
        (pathlib.Path(tmpdir) / 'baz.py').write_text('pass')
        (pathlib.Path(tmpdir) / 'qux.py').write_text('pass')

        (pathlib.Path(tmpdir) / 'foo').mkdir(parents=True)
        (pathlib.Path(tmpdir) / 'foo' / 'baz.py').write_text('pass')

# Generated at 2022-06-25 21:47:29.270189
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .exceptions import InputDoesntExists, InvalidInputOutput
    import pytest

# Generated at 2022-06-25 21:47:36.906696
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory

    from pathlib import Path

    with TemporaryDirectory() as directory:
        root = Path(directory)

        (root / 'test').mkdir()
        (root / 'test' / 'a.py').touch()
        (root / 'test' / 'b.py').touch()

        # 1. Test with .py files
        # input_ = test, output = a.py
        output = (root / 'test' / 'a.py').absolute()
        output.unlink()
        input_ = (root / 'test').absolute()
        result = list(get_input_output_paths(str(input_), str(output), str(root)))

# Generated at 2022-06-25 21:47:45.491714
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os

    test_dir, _ = os.path.split(__file__)

    # test when input is a directory
    test_input = os.path.join(test_dir, 'input', 'test_strict_equal')
    test_output = os.path.join(test_dir, 'output')
    inputs_outputs = get_input_output_paths(test_input, test_output, test_input)
    assert len(list(inputs_outputs)) == 1
    test_input1, test_output1 = next(inputs_outputs)
    assert test_input1.name == 'test_strict_equal.py'
    assert test_output1.name == 'test_strict_equal.py'

    # test when input is a file
    test_input = os.path.join

# Generated at 2022-06-25 21:47:48.703218
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from click.testing import CliRunner

    from flakehell.cli import cli

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['clean', 'tests/testdata/example'],
    )
    assert result.exit_code == 0

# Generated at 2022-06-25 21:47:52.497284
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:48:01.428482
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Two input, both python files
    inputs = ['inpUts/main1.py', 'inputs/main2.py']
    outputs = ['outputs/main1.py', 'outputs/main2.py']
    for input_, output in zip(inputs, outputs):
        iterable_0 = get_input_output_paths(input_, output, None)
        unit_test_0(iterable_0)
        unit_test_1(iterable_0)
    # One input is a non-py file
    input_0 = 'inputs/main'
    output_0 = ['outputs/main1.py', 'outputs/main2.py']
    iterable_0 = get_input_output_paths(input_0, output_0[0], None)
    unit_test_

# Generated at 2022-06-25 21:48:07.116030
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    inp = 'test/test_data'
    outp = 'test/test_output'
    root = 'test'
    path_list = list(get_input_output_paths(inp, outp, root))
    assert path_list[0].input_path == Path(inp + '/file_0.py')
    assert path_list[1].input_path == Path(inp + '/file_1.py')
    assert path_list[2].input_path == Path(inp + '/file_2.py')
    assert path_list[0].output_path == Path(outp + '/file_0.py')
    assert path_list[1].output_path == Path(outp + '/file_1.py')

# Generated at 2022-06-25 21:48:16.867695
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_1 = 'inpUt'
    str_2 = 'inpUt'
    str_3 = 'inpUt'
    iterable_1 = get_input_output_paths(str_1, str_2, str_3)
    var_1 = list(iterable_1)

    try:
        str_4 = 'inpUt'
        str_5 = 'outPut'
        str_6 = 'inpUt'
        iterable_2 = get_input_output_paths(str_4, str_5, str_6)
        var_2 = list(iterable_2)
        raise Exception('AssertionError not raised')
    except AssertionError:
        pass


# Generated at 2022-06-25 21:48:19.921380
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    str_0 = 'inpUt'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

    assert str_0 in str(var_0)
    assert str_0 in str(iterable_0)

# Generated at 2022-06-25 21:48:24.453016
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print("Testing function get_input_output_paths")
    assert get_input_output_paths("test_input.py", "test_output.py", None) is None
    assert get_input_output_paths("test_input.py", "test_output.py", None)  == get_input_output_paths("test_input.py", "test_output.py", None)

# Generated at 2022-06-25 21:48:32.251539
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert Path(get_input_output_paths((Path('/foo/bar/baz.py')), Path('/foo/bar/baz.py'), None)) == Path('/foo/bar/baz.py')
    assert Path(get_input_output_paths((Path('/foo/bar/baz.py')), Path('/foo/bar/baz.py'), Path('/foo/bar'))) == Path('/foo/bar/baz.py')
    assert Path(get_input_output_paths((Path('/foo/bar/baz.py')), Path('/foo/bar/baz.py'), Path('/foo'))) == Path('/foo/bar/baz.py')

# Generated at 2022-06-25 21:48:42.883000
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # This testcase was created with help of zserge/webview

    str_0 = 'inpUt'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

    str_1 = 'inpUt'
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)
    var_1 = list(iterable_1)

    str_2 = 'inpUt'
    iterable_2 = get_input_output_paths(str_2, str_2, str_2)
    var_2 = list(iterable_2)

    str_3 = 'inpUt'

# Generated at 2022-06-25 21:48:51.054930
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'input'
    str_1 = 'output'
    str_2 = 'root'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    var_1 = len(var_0)
    var_2 = var_0[0].source_path
    var_3 = var_0[1].input_path
    var_4 = var_0[2].output_path
    var_5 = var_0[3].source_path
    var_6 = var_0[4].input_path
    var_7 = var_0[5].output_path
    var_8 = var_0[6].source_path
    var_9 = var_0[7].input_path

# Generated at 2022-06-25 21:49:00.817563
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    p = Path(__file__).parent.parent
    input_ = p.joinpath('input').resolve().as_posix()
    output = p.joinpath('output').resolve().as_posix()
    root = p.resolve().as_posix()

    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)

    assert var_0 == [InputOutput(Path(input_, 'example.py'),
                                 Path(output, 'example.py')),
                     InputOutput(Path(input_, 'subdir', 'example.py'),
                                 Path(output, 'subdir', 'example.py'))]



# Generated at 2022-06-25 21:49:15.490166
# Unit test for function get_input_output_paths
def test_get_input_output_paths(): 
    try:
        get_input_output_paths('samples/bad-*.py', 'out', 'samples')
        print('SUCCESS: ValueError was raised')
    except ValueError:
        print('FAILED: ValueError was not raised')
    try:
        get_input_output_paths('samples/bad-*.py', 'out/', 'samples')
        print('SUCCESS: ValueError was raised')
    except ValueError:
        print('FAILED: ValueError was not raised')
    try:
        list(get_input_output_paths('samples/bad-*.py', 'out', 'samples'))
        print('SUCCESS: ValueError was raised')
    except ValueError:
        print('FAILED: ValueError was not raised')

# Generated at 2022-06-25 21:49:20.074005
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        str_0 = 'input'
        str_1 = 'output'
        str_2 = None
        iterable_0 = get_input_output_paths(str_0, str_1, str_2)
        var_0 = list(iterable_0)
    except InputDoesntExists as e:
        print('Not exist')

# Generated at 2022-06-25 21:49:22.751155
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/path/to/input/file.py', 'output/path/file.py', None) == InputOutput(Path('/path/to/input/file.py'),Path('output/path/file.py'))

# Generated at 2022-06-25 21:49:25.768045
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # str_0 = 'inpUt'
    # iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    # var_0 = list(iterable_0)
    assert type(var_0) is list

# Generated at 2022-06-25 21:49:27.177474
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Generated at 2022-06-25 21:49:28.502647
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'inpUt'
    assert False



# Generated at 2022-06-25 21:49:33.626483
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    out_0 = get_input_output_paths('abc', 'abc', 'abc')
    assert isinstance(out_0, Iterable)
    out_1 = get_input_output_paths('abc', 'abc', 'abc')
    assert isinstance(out_1, Iterable)
    out_2 = get_input_output_paths('abc', 'abc', 'abc')
    assert isinstance(out_2, Iterable)
    out_3 = get_input_output_paths('abc', 'abc', 'abc')
    assert isinstance(out_3, Iterable)
    out_4 = get_input_output_paths('abc', 'abc', 'abc')
    assert isinstance(out_4, Iterable)

# Generated at 2022-06-25 21:49:34.985625
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("inpUt", "outpUt", "root") == True

# Generated at 2022-06-25 21:49:41.679007
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    items = get_input_output_paths('input', 'output', None)
    items_list = list(items)
    assert len(items_list) == 1
    assert Path('input/test.py') == items_list[0].input_path
    assert Path('output/test.py') == items_list[0].output_path

# Generated at 2022-06-25 21:49:42.600786
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:50:13.020161
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    arg_0 = str
    arg_1 = str
    arg_2 = str
    for arg_3 in range(100):
        with raises(InputDoesntExists):
            get_input_output_paths(arg_0, arg_1, arg_2)



# Generated at 2022-06-25 21:50:16.223217
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input('Press Enter to continue...')
    print('Testing function get_input_output_paths, v0.0.1')
    print('')
    input('Press Enter to continue...')

# Called only if this is run as a script
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:50:21.239936
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'inpUt'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input == Path(str_0)
    assert var_0[0].output == Path(str_0)

# Generated at 2022-06-25 21:50:27.164751
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Setup
    str_0 = 'input'
    str_1 = 'output'
    str_2 = 'root'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    list_0 = list(iterable_0)
    str_3 = str(list_0[0][0])
    str_4 = str(list_0[0][1])
    bool_0 = bool(str_3 == 'input')
    bool_1 = bool(str_4 == 'output')
    assert (bool_0 and bool_1) == True

# Generated at 2022-06-25 21:50:27.821530
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1

# Generated at 2022-06-25 21:50:34.337900
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    in_0 = 'tests/input_output_test.py'
    out_0 = 'tests/out_0'
    root_0 = 'tests'
    iterable_0 = get_input_output_paths(in_0, out_0, root_0)
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path('tests/input_output_test.py'), Path('tests/out_0/input_output_test.py'))], 'tests/input_output_test.py->tests/out_0/input_output_test.py'

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:42.766688
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'inpUt'
    str_1 = 'inpUt'
    str_2 = 'inpUt'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    # AssertionError
    assert var_0 != ['inpUt']

    str_3 = 'TestCase0.py'
    str_4 = 'TestCase0.py'
    str_5 = 'TestCase0.py'
    iterable_1 = get_input_output_paths(str_3, str_4, str_5)
    var_1 = list(iterable_1)
    # TypeError
    assert type(var_1) != list



# Generated at 2022-06-25 21:50:45.013973
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(Path(sys.argv[1]).glob("**/*.py")) == len(list(get_input_output_paths(sys.argv[1], sys.argv[2], sys.argv[3])))

# Generated at 2022-06-25 21:50:45.822572
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() == None

# Generated at 2022-06-25 21:50:55.259253
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Function calls
    str_0 = 'input'
    str_1 = 'output'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input == Path('input/input.py')
    assert var_0[0].output == Path('output/input.py')

    str_2 = 'input.py'
    str_3 = 'output'
    iterable_1 = get_input_output_paths(str_2, str_3, None)
    var_1 = list(iterable_1)
    assert len(var_1) == 1
    assert var_1[0].input == Path('input.py')
   

# Generated at 2022-06-25 21:52:19.343630
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Testing get_input_output_paths')

    # Case 0 - Asserts that the function returns a iterable of InputOutput when
    # input and output are files in the same folder
    test_case_0()

    print('All tests passed')

test_get_input_output_paths()

# Generated at 2022-06-25 21:52:21.491171
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    with pytest.raises(InvalidInputOutput):
        test_case_0()


# Generated at 2022-06-25 21:52:22.246376
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:52:23.731739
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

# Generated at 2022-06-25 21:52:31.965252
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'inpUt'
    str_1 = 'iNPut'
    str_2 = 'iNPut'
    str_3 = 'input'
    str_4 = 'output'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    iterable_1 = get_input_output_paths(str_3, str_0, str_2)
    var_1 = list(iterable_1)
    iterable_2 = get_input_output_paths(str_3, str_3, str_3)
    var_2 = list(iterable_2)

# Generated at 2022-06-25 21:52:41.457787
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Testing get_input_output_paths')
    # Unit test for function get_input_output_paths
    def test_get_input_output_path_0():
        str_1 = 'input.py'
        str_2 = 'output.py'
        iterable_1 = get_input_output_paths(str_1, str_2, str_2)
        var_1 = list(iterable_1)
        assert len(var_1) == 1

    # Unit test for function get_input_output_paths
    def test_get_input_output_path_1():
        str_3 = 'input.py'
        str_4 = 'input.py'
        iterable_2 = get_input_output_paths(str_3, str_4, str_4)
       

# Generated at 2022-06-25 21:52:43.114086
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(None, './input/../input', './input/../input') == None

# Generated at 2022-06-25 21:52:45.611615
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    try:
        assert False
    except AssertionError:
        print('Test case 0 failed')



if __name__ == '__main__':
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:52:53.471821
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    in_t = ['inpUt', 'inpUt', 'inpUt']
    out_t = ['input', 'output', 'root']
    root_t = ['root', 'root', None]
    iterable_0 = get_input_output_paths(in_t[0], out_t[0], root_t[0])
    iterable_1 = get_input_output_paths(in_t[1], out_t[1], root_t[1])
    iterable_2 = get_input_output_paths(in_t[2], out_t[2], root_t[2])

    # input with .py, output with .py
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:52:54.963054
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/tmp', '/tmp', '/tmp') is not None

