

# Generated at 2022-06-25 21:46:00.484905
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Path input_: str, output: str, root: Optional[str]
    # -> Iterable[InputOutput]
    str_0 = 'P\x14\x1ee\x1dG\x0eQ\x1cS\x0b\x1b\x1b\x0e'
    # str, str, str -> Iterable[InputOutput]
    assert get_input_output_paths(str_0, str_0, str_0) is not None
    # str, str, str -> Iterable[InputOutput]



# Generated at 2022-06-25 21:46:04.929274
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [InputOutput(Path('.0z\x0b@~ Y\rF>qbW!x'), Path('.0z\x0b@~ Y\rF>qbW!x'))] == get_input_output_paths(".0z\x0b@~ Y\rF>qbW!x", ".0z\x0b@~ Y\rF>qbW!x", ".0z\x0b@~ Y\rF>qbW!x")
    assert [] == get_input_output_paths('2M0m0', '2M0m0', '2M0m0')

# Generated at 2022-06-25 21:46:14.877329
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.0z\x0b@~ Y\rF>qbW!x'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)

# CPAChecker
# Results for test case 0
# Condition:
#   get_input_output_paths('.0z\x0b@~ Y\rF>qbW!x', '.0z\x0b@~ Y\rF>qbW!x', '.0z\x0b@~ Y\rF>qbW!x')
# Is always false:
#   get_input_output_paths('.0z\x0b@~ Y\rF>qbW!x', '.0z\x0b@~ Y\rF>qbW!

# Generated at 2022-06-25 21:46:15.784929
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        return
    else:
        assert False

# Generated at 2022-06-25 21:46:24.476415
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os

    # the test case above
    test_case_0()

    # case 1: input is a directory and output is a file
    dirname = os.path.abspath('./test_data/input/')
    filename = os.path.abspath('./test_data/output/1.py')
    iterable_1 = get_input_output_paths(dirname, filename, os.curdir)
    assert len(list(iterable_1)) == 0

    # case 2: input is a directory and output is a directory
    dirname = os.path.abspath('./test_data/input/')
    filename = os.path.abspath('./test_data/output/')

# Generated at 2022-06-25 21:46:29.398904
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('MyScript.py', 'MyScript.py', '.') ==\
        ("MyScript.py", "MyScript.py")
    # assert get_input_output_paths('MyScript.py', 'SomeFolder', '.') ==\
    #    ("MyScript.py", "SomeFolder\\MyScript.py")

# Generated at 2022-06-25 21:46:39.230565
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:47.847830
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('_.py','_.py','_.py')
    with pytest.raises(InputDoesntExists):
        next(get_input_output_paths('_.py','_.py',None))
    with pytest.raises(InputDoesntExists):
        next(get_input_output_paths('_.py','/',None))
    with pytest.raises(InputDoesntExists):
        next(get_input_output_paths('/','/',None))
    assert next(get_input_output_paths('_.py','_.py','_.py')) == InputOutput(Path("_.py"), Path("_.py"))
    assert next(get_input_output_paths('/','/./','/')) == Input

# Generated at 2022-06-25 21:46:49.640572
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True # TODO: implement your test here

# Generated at 2022-06-25 21:47:00.677629
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    testcase = {
        'in': {'input': './data/input_test.txt',
               'output': './data/output_test',
               'root': None},
        'out': [{'input': '/Users/noah/wissen/python-coverage-diff/data/input_test.txt',
                 'output': '/Users/noah/wissen/python-coverage-diff/data/output_test/input_test.txt'}],
    }
    res = list(get_input_output_paths(**testcase['in']))
    assert len(res) == len(testcase['out'])
    assert all(map(lambda x: x in res, testcase['out']))



# Generated at 2022-06-25 21:47:37.021772
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '../'
    str_1 = '../..'
    iterable_0 = get_input_output_paths('../', '../../', '../../')
    assert iterable_0 is not None

    str_2 = '../../'
    iterable_1 = get_input_output_paths('../', '../../', '../../')
    assert iterable_1 is not None

    str_3 = '../../'
    iterable_2 = get_input_output_paths('../', '../../', '../../')
    assert iterable_2 is not None

    iterable_3 = get_input_output_paths('../', '../../', '../../')
    assert iterable_3 is not None



# Generated at 2022-06-25 21:47:39.252899
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 21:47:45.245140
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from hypothesis import given
    from hypothesis import strategies as st
    from .verify import verify_multi

    @given(st.text(min_size=1), st.text(min_size=1), st.text(min_size=1))
    def test_get_input_output_paths_invariant(input_: str, output: str, root: str):
        verify_multi(get_input_output_paths, input_, output, root)
    test_get_input_output_paths_invariant()

# Generated at 2022-06-25 21:47:47.342183
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Setup
    str_0 = '/'
    # Run the test - we should not get any exceptions
    get_input_output_paths(str_0, str_0, str_0)

# Generated at 2022-06-25 21:47:48.084388
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()



# Generated at 2022-06-25 21:47:55.238618
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .main import get_input_output_paths
    import pytest
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('', '', '')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')


# Generated at 2022-06-25 21:47:56.020774
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Nothing to test
    pass

# Generated at 2022-06-25 21:47:59.376664
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = './'
    assert get_input_output_paths(input_0, input_0, input_0) == get_input_output_paths(input_0, input_0, input_0)

# Generated at 2022-06-25 21:48:07.754948
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:48:17.418410
# Unit test for function get_input_output_paths
def test_get_input_output_paths():


    # unit test example: test get_input_output_paths takes 1 input argument and returns 1 output argument
    # which is of type list
    assert_equal(func(input_), expectedOutput)


    # unit test example: test get_input_output_paths takes 1 input argument and returns 1 output argument
    # which is of type list
    assert_equal(func(input_), expectedOutput)


    # unit test example: test get_input_output_paths takes 1 input argument and returns 1 output argument
    # which is of type list
    assert_equal(func(input_), expectedOutput)


    # unit test example: test get_input_output_paths takes 1 input argument and returns 1 output argument
    # which is of type list
    assert_equal(func(input_), expectedOutput)


    # unit test example:

# Generated at 2022-06-25 21:49:08.445108
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '/'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)

# Generated at 2022-06-25 21:49:18.780890
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Raise InvalidInputOutput
    with pytest.raises(InvalidInputOutput):
        str_0 = '..\\examples\\a.py'
        str_1 = '.\\b.py'
        str_2 = '.'
        iterable_0 = get_input_output_paths(str_0, str_1, str_2)
        next(iterable_0)
    # Raise InputDoesntExists
    with pytest.raises(InputDoesntExists):
        str_0 = '.\\examples\\a.py'
        str_1 = '.\\b.py'
        str_2 = '.'
        iterable_0 = get_input_output_paths(str_0, str_1, str_2)
        next(iterable_0)
    # Output string

# Generated at 2022-06-25 21:49:19.726572
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:49:28.074359
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (next(get_input_output_paths(
        '/home/peter/source/python/auto-repair/test_global/test_package/test_module.py',
        '/home/peter/source/python/auto-repair/test_global/test_package/test_module.py',
        '/home/peter/source/python/auto-repair/test_global/test_package/test_module.py',
    )) ==
        InputOutput(
            Path('/home/peter/source/python/auto-repair/test_global/test_package/test_module.py'),
            Path('/home/peter/source/python/auto-repair/test_global/test_package/test_module.py')
        )
    )


# Generated at 2022-06-25 21:49:29.401701
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(get_input_output_paths('/', '/', '/'))


# Generated at 2022-06-25 21:49:31.404124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)



# Generated at 2022-06-25 21:49:40.552219
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        str_0 = 'a/b/c'
        str_1 = 'a/b/c'
        str_2 = 'a/b/c'
        get_input_output_paths(str_0, str_1, str_2)
    except InvalidInputOutput:
        assert True
    else:
        assert False

# Generated at 2022-06-25 21:49:46.456915
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "/home/test/test1.py"
    output = "/home/test/test2.py"
    root = "/home/test"
    iterable = get_input_output_paths(input_, output, root)
    var = next(iterable)
    assert var.input_path == Path("/home/test/test1.py")
    assert var.output_path == Path("/home/test/test2.py")

# Generated at 2022-06-25 21:49:48.682367
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() is None

# Generated at 2022-06-25 21:49:49.611202
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True



# Generated at 2022-06-25 21:52:05.943289
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'input'
    output = 'output'
    root = None  # type: Optional[str]
    iterable = get_input_output_paths(input_, output, root)
    result = next(iterable)
    assert result.input_path == Path('input/input.py')
    assert result.output_path == Path('output/input.py')



# Generated at 2022-06-25 21:52:14.629801
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = 'dummy_input'
    output = 'dummy_output'
    strings = [
        'dummy_input/dummy_input/dummy.py',
        'dummy_input/dummy_input/dummy2.py',
    ]
    input_outputs = []
    for string in strings:
        input_outputs.extend(get_input_output_paths(string, output, root))

    assert input_outputs[0].input_path.name == 'dummy.py'
    assert input_outputs[0].output_path.name == 'dummy.py'
    assert input_outputs[1].input_path.name == 'dummy2.py'
    assert input_outputs[1].output_path.name == 'dummy2.py'

# Generated at 2022-06-25 21:52:17.854786
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/'
    output = '/'
    root = '/'
    assert next(get_input_output_paths(input_, output, root)) == InputOutput(Path('/'), Path('/'))



# Generated at 2022-06-25 21:52:24.294802
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = Path('../tests/tests_data/data')
    output = Path('../tests/tests_data/results/data')
    root = None
    iterable_0 = get_input_output_paths(input_, output, root)
    iter_0 = iter(iterable_0)
    for i in iter_0:
        assert i == InputOutput(Path('../tests/tests_data/data/test.py'), Path('../tests/tests_data/results/data/test.txt'))
        assert i == InputOutput(Path('../tests/tests_data/data/test_2.py'), Path('../tests/tests_data/results/data/test_2.txt'))

# Generated at 2022-06-25 21:52:24.927375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True

# Generated at 2022-06-25 21:52:26.896972
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Generated at 2022-06-25 21:52:29.244561
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/'.encode('utf-8')
    output = '/'.encode('utf-8')
    root = '/'.encode('utf-8')
    # get_input_output_paths(input_, output, root)

# Generated at 2022-06-25 21:52:29.694449
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:52:37.853540
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    var_0 = get_input_output_paths('/foo/bar', '', 'bar')
    assert var_0.next().input_file == Path('/foo/bar')
    assert var_0.next().output_file == Path('/foo/bar')
    assert var_0.next().input_file == Path('/foo/bar')
    assert var_0.next().output_file == Path('/foo/bar')
    assert var_0.next().input_file == Path('/foo/bar')
    assert var_0.next().output_file == Path('/foo/bar')

    var_0 = get_input_output_paths('/foo/bar', '', 'foo')
    assert var_0.next().input_file == Path('/foo/bar')
    assert var_0.next().output

# Generated at 2022-06-25 21:52:46.602399
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    in_1 = './test_data/input/test_case_0/test_input'
    out_1 = './test_data/output/test_case_0/test_output'
    root_1 = './test_data'
    expected_1 = [('./test_data/input/test_case_0/test_input/merge_sort.py',
                   './test_data/output/test_case_0/test_output/merge_sort.py')]
    actual_1 = list(get_input_output_paths(in_1, out_1, root_1))
    assert expected_1 == actual_1

    in_2 = './test_data/input/test_case_0/test_input/merge_sort.py'