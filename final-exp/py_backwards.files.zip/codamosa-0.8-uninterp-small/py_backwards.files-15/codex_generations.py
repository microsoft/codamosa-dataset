

# Generated at 2022-06-25 21:45:58.197441
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Users\\kirtleye\\Documents\\github\\autopep8\\tests'
    str_1 = 'C:\\Users\\kirtleye\\Documents\\github\\autopep8\\tests'
    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    assert iterable_0
    assert len(iterable_0) == 1
    assert iterable_0[0]



# Generated at 2022-06-25 21:45:58.710163
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:46:11.136526
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test_0
    str_0 = 'F+\t|t0'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)

    # test_1
    str_1 = 'F+\t|t1'
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)

    # test_2
    str_2 = 'F+\t|t2'
    iterable_2 = get_input_output_paths(str_2, str_2, str_2)

    # test_3
    str_3 = 'F+\t|t3'
    iterable_3 = get_input_output_paths(str_3, str_3, str_3)

    # test

# Generated at 2022-06-25 21:46:14.171126
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t0'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    assert iterable_0 == iterable_0



# Generated at 2022-06-25 21:46:17.863444
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(get_input_output_paths('F+', 'F-', 'F*') == (Path('F+'), Path('F-')))
    assert(get_input_output_paths('F+', 'F-', 'F*') == (Path('F+'), Path('F-')))
    assert(get_input_output_paths('F+', 'F-', 'F*') == (Path('F+'), Path('F-')))



# Generated at 2022-06-25 21:46:26.536509
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input=file output=file
    str_0 = 'F+\t|t0'
    str_2 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_2, str_0)
    assert next(iterable_0) == InputOutput(Path(str_0), Path(str_2))
    # Test input=file output=directory
    str_6 = 'F+\t|t6'
    iterable_6 = get_input_output_paths(str_0, str_6, str_0)
    assert next(iterable_6) == InputOutput(Path(str_0), Path(str_6).joinpath(Path(str_0).name))
    # Test input=directory output=file

# Generated at 2022-06-25 21:46:29.399302
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(get_input_output_paths('F+\t|t0', 'F+\t|t0', 'F+\t|t0')) is not(None)


# Generated at 2022-06-25 21:46:36.429124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert_equal(get_input_output_paths('LICENSE', 'LICENSE', 'LICENSE'), [])
    assert_equal(get_input_output_paths('README.rst', 'README.rst', 'README.rst'), [])
    assert_equal(get_input_output_paths('<path>', '<path>', '<path>'), [])
    assert_equal(get_input_output_paths('<path>', '<path>', '<path>'), [])



# Generated at 2022-06-25 21:46:40.993283
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/home/site/wwwroot/reader.py'
    output = '/home/site/wwwroot/writer.py'
    root = '/home/site/wwwroot'

    expected = [InputOutput(Path(input_), Path(output))]
    actual = get_input_output_paths(input_, output, root)

    assert list(actual) == expected, 'Expected: {}, Actual: {}'.format(expected, actual)

# Generated at 2022-06-25 21:46:52.747133
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Empty path
    try :
        iterable_0 = get_input_output_paths('', '', '')
    except InputDoesntExists :
        pass

    # Path with invalid input/output exception
    try :
        iterable_0 = get_input_output_paths('test.py', 'test_1.py', '')
    except InvalidInputOutput :
        pass

    # Path with invalid input exception
    try :
        iterable_0 = get_input_output_paths('test.pyyy', 'test_1', '')
    except InputDoesntExists :
        pass

    # Path with valid file
    iterable_0 = get_input_output_paths('test.py', 'test_1', '')

# Generated at 2022-06-25 21:46:58.992307
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('', '.', None)) == InputOutput(
        Path(''), Path('.'))
    assert next(get_input_output_paths('.', '', None)) == InputOutput(
        Path('.'), Path('.'))
    assert list(get_input_output_paths('.', '.', None)) == [InputOutput(
        Path('.'), Path('.'))]
    assert list(get_input_output_paths('.', '.', '')) == [InputOutput(
        Path('.'), Path('.'))]
    assert list(get_input_output_paths('.', '', '')) == [InputOutput(
        Path('.'), Path('.'))]

# Generated at 2022-06-25 21:47:07.367333
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    assert var_0.input_path == Path("F+\t|t2/F+\t|t2.py")
    assert var_0.output_path == Path("F+\t|t2/F+\t|t2.py")

    str_1 = 'F+\t|t2.py'
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)
    var_1 = next(iterable_1)
    assert var_1.input_path == Path("F+\t|t2.py")


# Generated at 2022-06-25 21:47:19.832182
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')
    get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')
    get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')

    get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')


# vim:set ts=4 sw=4 et:

# Generated at 2022-06-25 21:47:29.159369
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from src.input_output import get_input_output_paths
    from pathlib import Path
    from src.input_output import InvalidInputOutput

    input_path = Path('tests/data/')

    iterable_0 = get_input_output_paths(input_path, input_path, input_path)
    var_0 = next(iterable_0)
    str_0 = 'tests/data/plop.py'
    assert type(var_0) == InputOutput
    assert var_0.input == Path(str_0)
    str_0 = 'tests/data/plop.py'
    assert var_0.output == Path(str_0)
    assert var_0.input.name == 'plop.py'

    str_0 = 'tests/data/plop.py'
    str

# Generated at 2022-06-25 21:47:34.232262
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a=get_input_output_paths('test_a.txt', 'test_b.txt', 'test_root')
    test_a = InputOutput(Path('test_a.txt'), Path('test_b.txt'))
    assert test_a.input == next(a).input
    assert test_a.output == next(a).output
    test_c = InputOutput(Path('test_c.txt'), Path('test_d.txt').joinpath(Path('test_c.txt')))
    c = get_input_output_paths('test_c.txt', 'test_d.txt', None)
    assert test_c.input == next(c).input
    assert test_c.output == next(c).output

# Generated at 2022-06-25 21:47:37.862466
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('/home/bob/in.py', '/home/bob/out.py', '/home/bob')) == InputOutput(Path('/home/bob/in.py'), Path('/home/bob/out.py'))


# Generated at 2022-06-25 21:47:46.280375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    inp = '/home/joe/example'
    out = '/home/joe/out'
    root = '/home/joe'
    types = ['/home/joe/example',
            '/home/joe/example/text1',
            '/home/joe/example/text2']
    p = len(Path(inp).glob('**/*.py'))
    for (i, o) in zip(Path(inp).glob('**/*.py'), Path(out).glob('**/*.py')):
        print(i, o)
    assert len(list(Path(out).glob('**/*.py'))) == p
    assert inp in types
    assert out in types
    assert root in types

    # test case 1
    inp = './'

# Generated at 2022-06-25 21:47:51.616553
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('example.py', 'example.py', 'example.py')) == InputOutput(Path('example.py'), Path('example.py'))

    # Failure: InputDoesntExists:
    with raises(InputDoesntExists):
        get_input_output_paths('C', 'D', 'C')

    # Failure: InvalidInputOutput:
    with raises(InvalidInputOutput):
        get_input_output_paths('E', 'E.py', 'E')

# Generated at 2022-06-25 21:48:00.668299
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    str_1 = 'dV7wQ )'
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = next(iterable_0)
    str_2 = 'i|c*nj'
    str_3 = '*Cx.n'
    str_4 = 'Y^&f:<'
    str_5 = '1N@N.D'
    iterable_1 = get_input_output_paths(str_2, str_3, str_3)
    var_1 = next(iterable_1)
    iterable_2 = get_input_output_paths(str_4, str_5, str_5)

# Generated at 2022-06-25 21:48:08.891966
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2') == InputOutput(Path('F+\\t|t2'), Path('F+\\t|t2'))
    assert get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\\t|t2') == InputOutput(Path('F+\\t|t2'), Path('F+\\t|t2'))
    assert get_input_output_paths('F+\t|t2', 'F+\t|t2', '') == InputOutput(Path('F+\\t|t2'), Path('F+\\t|t2'))

# Generated at 2022-06-25 21:48:20.706595
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output_0 = ['/path/to/input/a.py', '', '', '/path/to/input/a.py', '']
    output_1 = ['/path/to/input/a.py', '', '/path/to/input/a.py', '',
                '/path/to/input/a.py', '', '/path/to/input/a.py', '']
    output_2 = ['/path/to/input/a.py', '', '/path/to/input/a.py', '']
    output_3 = ['/path/to/input/a.py', '', '/path/to/input/a.py', '',
                '/path/to/input/a.py', '', '/path/to/input/a.py', '']

# Generated at 2022-06-25 21:48:28.917376
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2') == get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2'))

    try:
        get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2') == get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')
    except ValueError:
        pass

    # The code below throws an exception of type KeyError

# Generated at 2022-06-25 21:48:30.801388
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except Exception as exception:
        print('An exception occurred: {}'.format(exception))
        raise exception



# Generated at 2022-06-25 21:48:41.219297
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('F+', 'F2', 'F2')) == ['F2/F2.py', 'F2/F2.py']
    assert next(get_input_output_paths('F+|t', 'F2|t', 'F2|t')) == ['F2|t/F2|t.py', 'F2|t/F2|t.py']
    assert next(get_input_output_paths('F+|t?', 'F2|t?', 'F2|t?')) == ['F2|t?/F2|t?.py', 'F2|t?/F2|t?.py']

# Generated at 2022-06-25 21:48:43.286695
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with empty parameters
    param_0 = ''
    param_1 = ''
    param_2 = ''
    # Call function
    test_case_0()

    pass

# Generated at 2022-06-25 21:48:48.695462
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_paths = get_input_output_paths('.', './build_out', '.')
    for input_output_path in input_output_paths:
        assert input_output_path.input_path.exists()
        assert input_output_path.output_path.exists()


# this idiom means the below code only runs when executed from command line
if __name__ == '__main__':
    # unittest.main()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:48:56.028655
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    filepath = Path(__file__).parent / 'inputs' / 'foo.py'

    res = get_input_output_paths(str(filepath), str(filepath), str(filepath))
    assert tuple(res)[0].input == filepath
    assert tuple(res)[0].output == filepath

    res = get_input_output_paths(str(filepath), 'output.py', str(filepath))
    assert tuple(res)[0].input == filepath
    assert tuple(res)[0].output == Path('output.py') / 'foo.py'

# Generated at 2022-06-25 21:49:00.365275
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    path_0 = Path(str_0)
    iterable_0 = get_input_output_paths(path_0, path_0)
    var_0 = next(iterable_0)
    var_1 = var_0.output



# Generated at 2022-06-25 21:49:01.718206
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:49:10.135364
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Edge case: test_case_0
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    assert var_0.input_.as_posix() == str_0
    assert var_0.output_.as_posix() == str_0

    # Edge case: test_case_1
    var_1 = get_input_output_paths('!WdG"$uQ', 'oo', 'R&1b')

    # Edge case: test_case_2
    var_2 = get_input_output_paths('@', 'T#T(Bx', 'q3M_')

    # Edge case: test_case_3

# Generated at 2022-06-25 21:49:20.886176
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '/home/nico/src/web/hass-helpers'
    iterable_0 = get_input_output_paths(str_0, '.', str_0)
    var_0 = next(iterable_0)

    assert var_0.input == Path('/home/nico/src/web/hass-helpers')
    assert var_0.output == Path('/home/nico/src/web/hass-helpers')



# Generated at 2022-06-25 21:49:29.202727
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_1 = 'F+\t|t2'
    output_1 = 'F+\t|t2'
    root_1 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(input_1, output_1, root_1)
    var_0 = next(iterable_0)
    assert type(var_0) is InputOutput
    assert var_0.input_path.name == 't2'
    assert var_0.output_path.name == 't2'
    input_2 = 'F+\t|t2'
    output_2 = 'F+\t|t2'
    root_2 = None
    iterable_1 = get_input_output_paths(input_2, output_2, root_2)
    var

# Generated at 2022-06-25 21:49:43.540452
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo.py', 'bar.py', 'baz') == [{ 'input': 'foo.py', 'output': 'bar.py' }]
    assert get_input_output_paths('foo.py', 'bar', 'baz') == [{ 'input': 'foo.py', 'output': 'bar/foo.py' }]
    assert get_input_output_paths('foo', 'bar', 'baz') == [{ 'input': 'foo/bar.py', 'output': 'bar/foo/bar.py' }]

# Generated at 2022-06-25 21:49:44.658872
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)



# Generated at 2022-06-25 21:49:51.187719
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    assert var_0.input_path == Path('F+\t|t2')
    assert var_0.output_path == Path('F+\t|t2')
    assert var_0.input_path.name == 'F+\t|t2'
    assert var_0.output_path.name == 'F+\t|t2'
    assert var_0.input_path.is_file()
    assert var_0.output_path.is_file()
    # Test with a non-existent input path

# Generated at 2022-06-25 21:49:54.091194
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # AssertionError: <pathlib.PosixPath object at 0x7f871aef70d0> != <pathlib.PosixPath object at 0x7f871aef70d0>
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:49:55.535674
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


# Generated at 2022-06-25 21:50:04.267358
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 0 with inputs: ('F+\t|t2', 'F+\t|t2', 'F+\t|t2'),
    # expected outputs: input: 'F+\t|t2', output: 'F+\t|t2'
    # Note that this test case would fail if the inputs were changed
    # after the test was created
    test_case_0()

# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-25 21:50:04.730400
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:50:09.669591
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)

    assert var_0.input == Path('F+\t|t2')
    assert var_0.output == Path('F+\t|t2')



# Generated at 2022-06-25 21:50:20.926784
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/fake/path', '/fake/path', '/fake/path') is not None

# Generated at 2022-06-25 21:50:28.761740
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Input/output: str, str, str
    str_0 = 'F+\t|t2'
    str_1 = 't2'
    str_2 = 'F+\t'
    # Output: tuple[path.Path, path.Path]
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    # Output: path.Path
    var_0 = next(iterable_0)
    # Output: path.Path
    var_1 = var_0[1]
    # Output: str
    var_2 = var_1.name
    # Output: bool
    var_3 = (var_2 == str_0)
    # AssertionError
    try:
        assert var_3
    except AssertionError:
        raise Ass

# Generated at 2022-06-25 21:50:37.115682
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_1 = 'd'
    str_2 = 'a'
    str_3 = 'z'
    str_4 = ''
    str_5 = 'e'
    str_6 = ''
    str_7 = 'E'
    str_8 = '\\'
    str_9 = 'j'
    str_10 = 'U'
    str_11 = '_'
    str_12 = 'G'
    str_13 = 'd'
    str_14 = '^'
    str_15 = 'x'
    str_16 = 'j'
    str_17 = 'h'
    str_18 = '/'
    str_19 = '\\'
    str_20 = '\\'
    str_21 = '\\'
    str_22 = '\\'

# Generated at 2022-06-25 21:50:44.332363
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case zero
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    assert var_0[0].name == 'F+', 'AssertionError'
    assert var_0[1].name == 'F+', 'AssertionError'
    assert var_0[0].parent.name == 't2', 'AssertionError'
    assert var_0[1].parent.name == 't2', 'AssertionError'
    # Test case one
    str_1 = 't2'
    iterable_1 = get_input_output_paths(str_1, str_1, str_1)

# Generated at 2022-06-25 21:50:52.663197
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    x_get_input_output_paths = InputOutput('F+\t|t2', 'F+\t|t2')
    try:
        assert x_get_input_output_paths ==  get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')
    except AttributeError:
        return
    except AssertionError:
        print("Expected : " + str(x_get_input_output_paths))
        print("Actual : " + str(get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')))
        raise AssertionError


# Generated at 2022-06-25 21:50:56.409689
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(str(), str(), str()) == iter(str())
    assert get_input_output_paths(str(), str(), str()) == iter(str())
    assert get_input_output_paths(str(), str(), str()) == iter(str())



# Generated at 2022-06-25 21:51:02.236829
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input: str = 'F+\t|t2'
    output: str = 'F+\t|t2'
    paths: Iterable[InputOutput] = get_input_output_paths(input, output, None)

    input_file_path: str = next(paths)[0]
    output_file_path: str = next(paths)[1]

    assert input_file_path == 'F+\t|t2'
    assert output_file_path == 'F+\t|t2'

# Generated at 2022-06-25 21:51:05.493260
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'output'
    str_1 = 'output'
    str_2 = 'input'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = next(iterable_0)

# Generated at 2022-06-25 21:51:13.568864
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    #assert get_input_output_paths('test_case_0', 'test_case_0', 'test_case_0') == 'test_case_0', 'test #0 failed'
    assert get_input_output_paths('test_case_0', 'test_case_0', 'test_case_0') == None, 'test #1 failed'
    assert get_input_output_paths('test_case_0', 'test_case_0', 'test_case_0') == None, 'test #2 failed'
    assert get_input_output_paths('test_case_0', 'test_case_0', 'test_case_0') == None, 'test #3 failed'

# Generated at 2022-06-25 21:51:19.302570
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    str_1 = 'F+\t|t2'
    var_0 = {'key_0': str_1}
    str_2 = 'F+\t|t2'
    var_0 = {'key_0': str_2}
    str_4 = 'F+\t|t2'
    var_0 = {'key_0': str_4}
    str_5 = 'F+\t|t2'
    var_0 = {'key_0': str_5}

# Generated at 2022-06-25 21:52:41.457501
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:52:48.372743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        str_0 = 'F+\t|t2'
        iterable_0 = get_input_output_paths(str_0, str_0, str_0)
        var_0 = next(iterable_0)
    except InvalidInputOutput as exc:
        print(str(exc))
    try:
        str_1 = 'F+\t|t2'
        iterable_1 = get_input_output_paths('F+\t|t2', 'F+\t|t2', 'F+\t|t2')
        var_1 = next(iterable_1)
    except InputDoesntExists as exc:
        print(str(exc))
    str_2 = 'F+\t|t2'
    iterable_2 = get_input_output_paths

# Generated at 2022-06-25 21:52:56.464452
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_0 = Path.cwd()
    path_1 = path_0.joinpath('test_data')
    path_2 = path_0.joinpath('tmp')

    str_0 = str(path_2)
    str_1 = str(path_1)
    str_2 = 'test_data/b.py'
    str_3 = 'tmp/a.py'
    str_4 = 'test_data/a.py'
    str_5 = 'tmp/b.py'
    str_6 = 'test_data/b.py'

    iterable_0 = get_input_output_paths(str_0, str_0, str_1)
    var_0 = next(iterable_0)
    var_1 = var_0.input

# Generated at 2022-06-25 21:52:57.610159
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # AssertionError: AssertionError: AssertionError: 
    assert False

# Generated at 2022-06-25 21:53:01.436752
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'F+\t|t2'
    output_0 = 'F+\t|t2'
    root_0 = 'F+\t|t2'
    iterable_0 = get_input_output_paths(input_0, output_0, root_0)
    next(iterable_0)

# Generated at 2022-06-25 21:53:06.835834
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = Path('test.txt')
    if not path.exists():
        path.touch()
    result = next(get_input_output_paths(str(path), str(path), str(path)))
    path.unlink()
    assert result.input_path == path
    assert result.output_path == path
    try:
        get_input_output_paths('a.py', 'b.txt', 'c.py')
        assert False
    except InputDoesntExists:
        assert True
    except:
        assert False
    try:
        get_input_output_paths('a.py', 'b.txt', 'c.py')
        assert False
    except InvalidInputOutput:
        assert True
    except:
        assert False
    pass

# Generated at 2022-06-25 21:53:15.776845
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1
    str_0 = 'F+\t|t2'
    str_1 = 'F+\t|t2'
    int_0 = -9
    var_0 = get_input_output_paths(str_0, str_1, int_0)
    assert str(var_0) == '(Path(\'F+\\t|t2\'), Path(\'F+\\t|t2\'))'
    # Test 2
    str_0 = 'F+\t|t2'
    str_1 = 'F+\t|t2'
    int_0 = 0
    var_0 = get_input_output_paths(str_0, str_1, int_0)

# Generated at 2022-06-25 21:53:18.352436
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = "C:/test_dir/test.py"
    output_0 = "C:/test_dir/out"
    root_0 = "C:/test_dir/"
    get_input_output_paths(input_0, output_0, root_0)

# Generated at 2022-06-25 21:53:29.624245
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'F+\t|t2'

    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    var_1 = var_0[0]
    var_2 = var_0[1]
    var_3 = var_1.name
    var_4 = var_2.name
    var_5 = var_1.parent
    var_6 = var_2.parent

    assert var_3 == 't2'
    assert var_4 == 't2'
    assert var_5 == Path('F+')
    assert var_6 == Path('F+')

    str_1 = ''


# Generated at 2022-06-25 21:53:35.902920
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    in_0 = 'F+\t|t2'
    out_0 = 'F+\t|t2'
    root_0 = 'F+\t|t2'
    expected_0 = [InputOutput(Path('F+\t|t2'), Path('F+\t|t2'))]
    out_iter_0 = get_input_output_paths(in_0, out_0, root_0)
    out_paths_0 = [io for io in out_iter_0]
    assert out_paths_0 == expected_0

    in_1 = 'F+\t|t2/ss/sss.py'
    out_1 = 'F+\t|t2'
    root_1 = 'F+\t|t2'