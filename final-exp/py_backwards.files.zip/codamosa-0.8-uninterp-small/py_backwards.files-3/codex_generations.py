

# Generated at 2022-06-25 21:45:52.990535
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True


# Generated at 2022-06-25 21:45:53.508948
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:45:54.365150
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pass


# Generated at 2022-06-25 21:46:02.377314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Test case 0
    try:
        test_case_0()
    except InvalidInputOutput:
        pass
    else:
        assert False

    # Test case 1
    try:
        get_input_output_paths('y', '', '')
    except InvalidInputOutput:
        assert True
    else:
        assert False

    # Test case 2
    try:
        get_input_output_paths('E#1', '', '')
    except InvalidInputOutput:
        assert True
    else:
        assert False

    # Test case 3
    try:
        get_input_output_paths('X ', '', '')
    except InvalidInputOutput:
        assert True
    else:
        assert False

    # Test case 4

# Generated at 2022-06-25 21:46:12.695778
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'fixtures'
    str_1 = '.py'
    str_2 = 'fixtures/passing_linear'
    str_3 = 'fixtures/passing_linear.py'
    str_4 = 'fixtures/passing_tree'
    str_5 = 'fixtures/passing_tree/one.py'
    str_6 = 'fixtures/passing_tree/two.py'
    str_7 = 'fixtures/passing_tree/three.py'
    str_8 = 'fixtures/passing_tree/four.py'
    str_9 = 'fixtures/passing_tree/five.py'
    str_10 = 'fixtures/passing_tree/six.py'
    str_11 = 'fixtures/passing_tree/seven.py'


# Generated at 2022-06-25 21:46:19.104156
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_outputs = get_input_output_paths(os.getcwd(), os.getcwd(), os.getcwd())

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(os.getcwd(), os.getcwd(), os.getcwd() + '.py')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths(os.getcwd() + '123', os.getcwd(), os.getcwd())

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', os.getcwd(), os.getcwd())

# Generated at 2022-06-25 21:46:20.027999
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)



# Generated at 2022-06-25 21:46:23.946363
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    function_tests = []        # type: list

    # Add code for each test
    # ...

    # Run all functions
    return run_functions(get_input_output_paths, function_tests)

# Run all functions with the same name as test_<name>

# Generated at 2022-06-25 21:46:34.435294
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/abc/abc.py', '/abc', '/abc') == InputOutput(Path('/abc/abc.py'), Path('/abc/abc.py'))
    assert get_input_output_paths('/abc/abc.py', '/abc', '/def') == InputOutput(Path('/abc/abc.py'), Path('/abc/abc.py'))
    assert get_input_output_paths('/abc/abc.py', '/abc', '/abc/123') == InputOutput(Path('/abc/abc.py'), Path('/abc/abc.py'))
    assert get_input_output_paths('/abc/abc.py', '/abc/123', '/abc') == InputOutput(Path('/abc/abc.py'), Path('/abc/123/abc.py'))
   

# Generated at 2022-06-25 21:46:39.599153
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    try:
        get_input_output_paths('path/to/input.py', 'path/to/output.py', 'path/to')
    except InputDoesntExists:
        print('InputDoesntExists')

    try:
        get_input_output_paths('path/to/input.py', 'path/to/output.txt', 'path/to')
    except InvalidInputOutput:
        print('InvalidInputOutput')

# Generated at 2022-06-25 21:46:57.754657
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest
    from os.path import sep
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input/a.txt', 'output/a.txt', None)
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input/a.txt', 'output', None)
    assert list(get_input_output_paths('input/a.py', 'output/a.txt', None))[0][1].as_posix() == 'output/a.txt'
    assert list(get_input_output_paths('input/a.py', 'output', None))[0][1].as_posix() == 'output/a.py'

# Generated at 2022-06-25 21:47:07.141091
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""

    # Input is not a file
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/home/input_is_not_a_file', '/home/output', None)

    # Input is a file, but it doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/home/input_doesnt_exist.py', '/home/output', None)

    # Input/Output are files and they exist
    result = get_input_output_paths('/home/input.py', '/home/output.py', None)
    assert result == [(Path('/home/input.py'), Path('/home/output.py'))]

    # Input is a file,

# Generated at 2022-06-25 21:47:20.646255
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./to_mypy/input', './to_mypy/output', './to_mypy/input')) == [
        InputOutput(Path('./to_mypy/input/foo.py'), Path('./to_mypy/output/foo.py')),
        InputOutput(Path('./to_mypy/input/another_folder/bar.py'), Path('./to_mypy/output/another_folder/bar.py')),
    ]

# Generated at 2022-06-25 21:47:29.630882
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_pairs = get_input_output_paths(
        Path("./tests/fixtures/input_output/input"),
        Path("./tests/fixtures/input_output/output"),
        Path("./tests/fixtures/input_output/input")
    )
    pairs = {pair.input.relative_to(Path("./tests/fixtures/input_output/input")): 
             pair.output.relative_to(Path("./tests/fixtures/input_output/input"))
             for pair in input_output_pairs}

# Generated at 2022-06-25 21:47:37.021733
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def test_func(input_: str, output: str, root: Optional[str]) -> List[InputOutput]:
        return list(get_input_output_paths(input_, output, root))

    assert test_func("foo/bar.py", "baz/bar.py", None) == [InputOutput(Path("foo/bar.py"), Path("baz/bar.py"))]
    assert test_func("foo/bar.py", "baz.py", None) == [InputOutput(Path("foo/bar.py"), Path("baz.py"))]

    assert test_func("foo/bar.py", "foo/baz/bar.py", None) == [InputOutput(Path("foo/bar.py"), Path("foo/baz/bar.py"))]


# Generated at 2022-06-25 21:47:45.591987
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test, when the input is a python file
    input_ = './test_inputs/input.py'
    output = './test_outputs'
    root = './test_inputs'
    file_pairs = get_input_output_paths(input_, output, root)
    assert isinstance(file_pairs, Iterable)
    for pair in file_pairs:
        assert isinstance(pair, InputOutput)
        assert pair.input.name == 'input.py'
        assert pair.output.name == 'input.py'

    # Test, when the input is the root directory of the project
    input_ = './test_inputs'
    output = './test_outputs'
    root = './test_inputs'
    file_pairs = get_input_output_paths

# Generated at 2022-06-25 21:47:53.386896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test input: no root, input is directory and output is directory as well
    res = [
        i for i in get_input_output_paths(
            'test/data/testdir', 'test/data/testdir2', root=None)
    ]
    assert len(res) == 2
    assert all([x.input_file.exists() for x in res])
    assert all([x.output_file.exists() for x in res])
    assert all([not x.output_file.is_dir() for x in res])
    for p in res:
        assert p.output_file.relative_to(
            Path('test/data/testdir2')).as_posix() == p.input_file.name
    # test input: root, input is directory and output is directory as well

# Generated at 2022-06-25 21:48:02.229715
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root_path = Path(__file__).parent.parent
    fun = get_input_output_paths
    assert len(list(fun(root_path, 'output'))) > 1
    assert len(list(fun(root_path, 'output', root_path))) > 1
    assert len(list(fun('test_input.py', 'output'))) == 1
    assert list(fun('test_input.py', 'output'))[0].input_path.name == \
        'test_input.py'
    assert list(fun('test_input.py', 'output', root_path))[0].input_path.name == \
        'test_input.py'

# Generated at 2022-06-25 21:48:06.601362
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given:
    input_ = 'foo/bar.py'
    output = 'baz'

    # When:
    result = list(get_input_output_paths(input_, output, root='foo'))

    # Then
    assert len(result) == 1
    assert result[0].input.name == input_
    assert result[0].output.name == output

# Generated at 2022-06-25 21:48:16.359134
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1: Test the return value of function get_input_output_paths
    def test_get_input_output_paths_value(input_:str, output:str, root:str, expected:InputOutput):
        '''Test the return value of function get_input_output_paths'''
        print('Test 1.1: Check the return value of function get_input_output_paths')
        for inputoutput in get_input_output_paths(input_, output, root):
            assert inputoutput == expected


# Generated at 2022-06-25 21:48:26.705527
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    iterable_0 = get_input_output_paths('fixtures/import_from/bar', 'foo', 'fixtures/import_from')
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path('fixtures/import_from/bar/baz.py'), Path('foo/baz.py'))]

# Generated at 2022-06-25 21:48:29.338514
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_2, str_1, str_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:48:38.819308
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a = get_input_output_paths("/a/b", "/a/c", "/a")
    b = get_input_output_paths("/a/b/c.py", "/a/c", "/a")
    c = get_input_output_paths("/a/b", "/a/c/d.py", "/a")
    d = get_input_output_paths("d/e.py", "d/f", "d")
    e = get_input_output_paths("/a", "/d", "/a")
    f = get_input_output_paths("/a", "/d/e.py", "/a")
    

# Generated at 2022-06-25 21:48:46.336334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # AssertionError: <_io.TextIOWrapper name='.../test.py'
    # mode='r' encoding=...> != <_io.TextIOWrapper name='.../test.py'
    # mode='w' encoding=...>
    with pytest.raises(AssertionError):
        str_0 = './read-write/test.py'
        iterable_0 = get_input_output_paths(str_0, str_0, str_0)
        var_0 = list(iterable_0)

    # AssertionError: <_io.TextIOWrapper name='.../read-write/test.py'
    # mode='r' encoding=...> != <_io.TextIOWrapper name='.../read-write/test.py'
   

# Generated at 2022-06-25 21:48:56.284578
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = 'test_cases/test_case_0.py'
    str_2 = 'test_cases/test_case_1.py'
    str_3 = 'test_cases/test_case_with_comments.py'
    str_4 = 'test_cases/test_case_with_comments.txt'
    str_5 = 'test_cases/test_case_with_comments_2.txt'
    str_6 = 'test_cases/test_case_with_comments_3.txt'
    str_7 = 'test_cases/test_case_with_comments_4.txt'
    str_8 = 'test_cases/test_case_with_comments_5.txt'

# Generated at 2022-06-25 21:49:04.750938
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_0 = Path()
    path_1 = Path()
    path_2 = Path()
    obj_0 = InputOutput(path_1, path_2)
    str_0 = ''
    name_0 = Path()
    obj_1 = InputOutput(name_0, path_1)
    assert get_input_output_paths(str_0, str_0, str_0) == iter([obj_0])
    assert get_input_output_paths(str_0, str_0, str_0) == iter((obj_0,))
    assert get_input_output_paths(str_0, str_0, str_0) == [obj_0]
    assert get_input_output_paths(str_0, str_0, str_0) == (obj_0,)
    assert get

# Generated at 2022-06-25 21:49:07.019692
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Pass the fixture data (input and output)
    test_case_0()

# Tested the function with multiple test cases to handle the exceptions and error cases(if any).

# Generated at 2022-06-25 21:49:07.811245
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True


# Generated at 2022-06-25 21:49:18.130953
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        input_ = ''
        output = ''
        root = ''
        iterable = get_input_output_paths(input_, output, root)
        list(iterable)
    except InvalidInputOutput:
        pass
    else:
        raise Exception(
            'Expected call to get_input_output_paths(%s, %s, %s) to raise '
            'InvalidInputOutput' % (input_, output, root))

    try:
        input_ = ''
        output = ''
        root = ''
        iterable = get_input_output_paths(input_, output, root)
        list(iterable)
    except InvalidInputOutput:
        pass

# Generated at 2022-06-25 21:49:21.113141
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:49:26.922551
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1

# Generated at 2022-06-25 21:49:32.972057
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', 'path/to/a')) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('path/to/a.py', 'b', 'path/to')) == [InputOutput(Path('path/to/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('path/to', 'b', 'path/to')) == [InputOutput(Path('path/to/a.py'), Path('b/a.py'))]

# Generated at 2022-06-25 21:49:38.610443
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except IOError as err:
        print('IO error: {0}'.format(err))
    except ValueError:
        print('ValueError error: {0}'.format(ValueError))
    except ImportError:
        print('ImportError error: {0}'.format(ImportError))
    except RuntimeError:
        print('RuntimeError error: {0}'.format(RuntimeError))
    except NameError:
        print('NameError error: {0}'.format(NameError))

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:48.282373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    mock_input_output_0 = InputOutput(Path('tests/data/input/example_1.py'), Path('tests/data/output/example_1.py'))
    mock_input_output_1 = InputOutput(Path('tests/data/input/example_2.py'), Path('tests/data/output/example_2.py'))
    mock_input_output_2 = InputOutput(Path('tests/data/input/example_1.py'), Path('tests/data/output/example_1.py'))
    mock_input_output_3 = InputOutput(Path('tests/data/input/example_2.py'), Path('tests/data/output/example_2.py'))

# Generated at 2022-06-25 21:49:54.337873
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'examples/simple'
    output_0 = 'tmp'
    root_0 = None
    try:
        iterable_0 = get_input_output_paths(input_0, output_0, root_0)
        var_0 = list(iterable_0)
    except InvalidInputOutput as e0:
        assert False
    except InputDoesntExists as e1:
        assert False
    assert len(var_0) == 2


if __name__ == '__main__':
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:58.048316
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


if __name__ == '__main__':
    # Test the units
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:02.861948
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def test_assertions(args, expected_ret):
        assert get_input_output_paths(*args) == expected_ret

    test_case_0()


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 21:50:07.470896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case: Input is empty
    assert list(get_input_output_paths('', '', '')) == []
    # Test case: Input is a file
    assert list(get_input_output_paths('b.py', 'out', 'root')) == []



# Generated at 2022-06-25 21:50:09.588918
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:16.582486
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert var_0 == [(Path(''), Path(''))]
    str_3 = ''
    str_4 = ''
    str_5 = ''
    # generate function call
    iterable_1 = get_input_output_paths(str_3, str_4, str_5)
    # save the result
    var_1 = list(iterable_1)
    str_6 = ''
    str_7 = ''
    str_8 = 'abc/a.py'
    # generate function call
    iterable_2 = get_input_output_path

# Generated at 2022-06-25 21:50:30.831014
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

##
#   Unit tests.
##

if __name__ == '__main__':
    print('Running unit tests for get_input_output_paths')
    test_get_input_output_paths()
    print('Done!')

# Generated at 2022-06-25 21:50:39.291487
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    import shutil
    import sys
    import tempfile
    from contextlib import ExitStack

    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Set up test directories
    tmpdir = tempfile.mkdtemp()
    tmpdir_1 = os.path.join(tmpdir, 'dir_1')
    tmpdir_2 = os.path.join(tmpdir, 'dir_2')
    os.mkdir(tmpdir_1)
    os.mkdir(tmpdir_2)

    with ExitStack() as stack:
        path_0 = os.path.join(tmpdir_1, 'file_0.py')
        path_1 = os.path.join(tmpdir_1, 'file_1.py')

# Generated at 2022-06-25 21:50:42.345897
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'abc'
    output_0 = 'xyz'
    root_0 = 'xxx'
    test_case_0()
    iterable_0 = get_input_output_paths(input_0, output_0, root_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:50:45.460078
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input0 = "a"
    output0 = "b"
    root0 = "c"
    func = get_input_output_paths(input0, output0, root0)
    # compare answer to expected output
    print(func)
    if 1:
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-25 21:50:54.847237
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

    # Test failure case
    with pytest.raises(InvalidInputOutput):
        # Test failure case
        str_0 = ''
        str_1 = 'a/'
        str_2 = ''
        get_input_output_paths(str_0, str_1, str_2)

    # Test failure case
    with pytest.raises(InputDoesntExists):
        # Test failure case
        str_0 = ''
        str_1 = ''
        str_2 = ''
        get_input_output_paths(str_0, str_1, str_2)

    # Test failure case
    with pytest.raises(InvalidInputOutput):
        # Test failure case
        str_0 = ''
        str_1 = 'a/'

# Generated at 2022-06-25 21:51:02.796071
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iter_0 = get_input_output_paths(str_0, str_1, str_2)
    str_3 = ''
    str_4 = ''
    str_5 = ''
    iter_1 = get_input_output_paths(str_3, str_4, str_5)
    str_6 = ''
    str_7 = ''
    str_8 = ''
    iter_2 = get_input_output_paths(str_6, str_7, str_8)
    str_9 = ''
    str_10 = ''
    str_11 = ''
    iter_3 = get_input_output_paths(str_9, str_10, str_11)



# Generated at 2022-06-25 21:51:06.354235
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True # TODO: implement your test here

# ----------------------------------------------------------------------
# If this module is running at the top level (as opposed to being
# imported by another module), then call the 'main' function.
# ----------------------------------------------------------------------
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 21:51:14.041478
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    tmp_path = Path(__file__).parent.joinpath('data/tmp')
    tmp_path.mkdir(exist_ok=True)

    # Test case 0
    try:
        test_case_0()
        assert False
    except InvalidInputOutput:
        assert True

    # Test case 1
    try:
        get_input_output_paths(
            Path(__file__).parent.joinpath('data/not_exists.py').as_posix(),
            Path(__file__).parent.joinpath('data/not_exists.py').as_posix(),
        )
        assert False
    except InputDoesntExists:
        assert True

    # Test case 2

# Generated at 2022-06-25 21:51:15.746401
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('', '', '')
        assert True
    except:
        assert False



# Generated at 2022-06-25 21:51:17.187700
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo.py', 'bar', 'baz') == [
        ('foo.py', 'bar/foo.py')
    ]

# Generated at 2022-06-25 21:51:43.362521
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:51:43.833574
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pass

# Generated at 2022-06-25 21:51:44.718193
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True

# Generated at 2022-06-25 21:51:51.419064
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Example 0
    input_ = ''
    output = ''
    root = ''
    expected_output_0 = []
    # Actual Output
    iterable_0 = get_input_output_paths(input_, output, root)
    actual_output_0 = list(iterable_0)
    # Check if same
    assert actual_output_0 == expected_output_0

    # Example 1
    input_ = ''
    output = ''
    root = ''
    expected_output_1 = []
    # Actual Output
    iterable_1 = get_input_output_paths(input_, output, root)
    actual_output_1 = list(iterable_1)
    # Check if same
    assert actual_output_1 == expected_output_1

    # Example 2
    input_ = ''
    output

# Generated at 2022-06-25 21:51:58.439958
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = (Path('path', 'to', 'my.py'), Path('out_file.py'))
    output_0 = get_input_output_paths(str(input_0[0]), str(input_0[1]), None)
    expected_0 = [input_0]
    assert list(output_0) == expected_0


    input_1 = (Path('path', 'to', 'my.py'), Path('path', 'to', 'out_file.py'))
    output_1 = get_input_output_paths(str(input_1[0]), str(input_1[1]), None)
    expected_1 = [input_1]
    assert list(output_1) == expected_1



# Generated at 2022-06-25 21:52:06.379834
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(
        get_input_output_paths('input_dir', 'output_dir', 'root_dir')
    ) == [
        InputOutput(Path('input_dir/foo.py'), Path('output_dir/foo.py')),
        InputOutput(Path('input_dir/bar.py'), Path('output_dir/bar.py')),
    ]
    assert list(
        get_input_output_paths('input_dir', 'output_dir/foo.py', 'root_dir')
    ) == [
        InputOutput(Path('input_dir/foo.py'), Path('output_dir/foo.py')),
        InputOutput(Path('input_dir/bar.py'), Path('output_dir/foo.py/bar.py')),
    ]

# Generated at 2022-06-25 21:52:15.759704
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert {'__name__': '__main__', '__doc__': None}

    try:
        str_0 = ''
        get_input_output_paths(str_0, str_0, str_0)
    except InputDoesntExists:
        pass
    else:
        assert False

    try:
        str_0 = ''
        get_input_output_paths(str_0, str_0, str_0)
    except InvalidInputOutput:
        pass
    else:
        assert False

    str_0 = ''
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    var_1 = var_0.input
    var_2 = var_0.output

# Generated at 2022-06-25 21:52:17.688451
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('', '', '')
    except NameError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 21:52:25.180858
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = [
        ("a", "b", None),
        ("a.py", "b.py", None),
        ("a.py", "b", None),
        ("a.py", "b", "a.py"),
        ("a", "b", "a.py"),
        ("a/b.py", "c/d.py", "a"),
        ("a/b.py", "c/d", "a"),
        ("a/b.py", "c/d", "a/b.py"),
    ]

# Generated at 2022-06-25 21:52:32.983610
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'input_1.py'
    str_1 = 'output_0'
    str_2 = 'input_1.py'
    str_3 = 'output_0.py'
    str_4 = 'input_1.py'
    str_5 = 'output_0/'
    str_6 = 'input_1.py'
    str_7 = 'output_0.py'
    str_8 = 'input_1.py'
    str_9 = 'output_0/'
    str_10 = 'input_1.py'
    str_11 = 'output_0/'
    str_12 = 'input_1.py'
    str_13 = 'output_0.py'
    str_14 = 'input_1.py'