

# Generated at 2022-06-25 21:46:00.989743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = [
        (os.path.join('pathlib', '__init__.py'),
         os.path.join('.', 'pathlib_converted', '__init__.py')),
        (os.path.join('pathlib', 'PurePosixPath.py'),
         os.path.join('.', 'pathlib_converted', 'PurePosixPath.py')),
        (os.path.join('pathlib', 'PureWindowsPath.py'),
         os.path.join('.', 'pathlib_converted', 'PureWindowsPath.py')),
    ]
    for input_output in get_input_output_paths(
            'pathlib', './pathlib_converted', 'pathlib'):
        assert input_output in paths

# Generated at 2022-06-25 21:46:11.345347
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Make the program believe that the file exists
    Path.exists = lambda x: True
    temp = get_input_output_paths('a.py', 'b', 'c')
    next_ = next(temp)
    next_2 = next(temp)
    # test1
    if not (next_ == InputOutput(Path('a.py'), Path('b/a.py'))) :
        raise ValueError('get_input_output_paths test1 failed')
    # test2
    if not next_2 == InputOutput(Path('a.py'), Path('b/a.py')) :
        raise ValueError('get_input_output_paths test2 failed')
    # test3

# Generated at 2022-06-25 21:46:12.407985
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(test_case_0())

# Generated at 2022-06-25 21:46:19.899337
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('data/ast', 'data/ast_output', 'data'))) == 1, "Test case 0 failed"
    assert len(list(get_input_output_paths('data/ast/__init__.py', 'data/ast_output', 'data'))) == 1, "Test case 1 failed"
    assert len(list(get_input_output_paths('tests/data/generation', 'data/ast_output', 'tests/data'))) == 2, "Test case 2 failed"
    assert len(list(get_input_output_paths('tests/data/generation', 'data/ast_output', 'tests'))) == 2, "Test case 3 failed"

# Generated at 2022-06-25 21:46:20.767539
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() == str_0



# Generated at 2022-06-25 21:46:24.550173
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '/Users/ashish/Desktop/Programming/Python/Projects/dummy'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    pass

# Generated at 2022-06-25 21:46:35.065601
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # single file
    files = get_input_output_paths('a', 'b', 'b')
    for f in files:
        assert f.input.name == 'a.py'
        assert f.output.name == 'a.py'
    # single folder
    files = get_input_output_paths('a', 'b', 'a')
    for f in files:
        assert f.input.name == 'a.py'
        assert f.output.name == 'a.py'
    # single folder, no root
    files = get_input_output_paths('a', 'b', None)
    for f in files:
        assert f.input.name == 'a.py'
        assert f.output.name == 'a.py'
    # recursive folder
    files = get_input_output_

# Generated at 2022-06-25 21:46:42.475364
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from hypothesis import given, settings
    from hypothesis.strategies import text
    from .strategies import inputs_and_outputs, project_paths

    @given(project_paths())
    @settings(deadline=None)
    def run_test(project_path):
        input_, output_ = project_path
        result = list(get_input_output_paths(input_, output_, None))
        root = Path(input_)
        expected = []
        if input_.endswith('.py'):
            if output_.endswith('.py'):
                expected.append([root, Path(output_)])
            else:
                output_root = Path(output_)
                output_root.mkdir(parents=True, exist_ok=True)
                expected

# Generated at 2022-06-25 21:46:43.553990
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:46:55.157065
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = Path('/usr/bin/python')
    str_1 = Path('/usr/bin/python')
    Path_2 = Path('/home/linux/Documents/python')
    Path_3 = Path('/home/linux/Documents/python')
    Path_4 = Path('/home/linux/Documents/python')
    InputOutput_5 = InputOutput(str_0, str_1)
    Path_6 = Path('/home/linux/Documents/python')
    Path_7 = Path('/home/linux/Documents/python')
    InputOutput_8 = InputOutput(Path_6, Path_7)
    InputOutput_9 = InputOutput(Path_3, Path_4)
    InputOutput_10 = InputOutput(Path_2, Path_3)

# Generated at 2022-06-25 21:47:06.757114
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_equal(var_0.input_path, Path('a.py'))
    test_equal(var_0.output_path, Path('c'))
    test_equal(var_1.input_path, Path('a.py'))
    test_equal(var_1.output_path, Path('c'))
    test_true(bool_0)
    test_equal(var_2.args[0], 'a.py')
    test_class(var_2, ValueError)


if __name__ == '__main__':
    import pytest  # type: ignore
    pytest.main(['-qq', '--capture=sys', '--cov=pre_commit_hooks'])

# Generated at 2022-06-25 21:47:07.527181
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:47:11.721515
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:47:12.987370
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:47:21.764243
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    bool_0 = True
    str_0 = 'a.py'
    str_1 = 'c'
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = next(iterable_0)
    var_1 = next(iterable_0)
    var_2 = ValueError(str_0)
    str_2 = 'get_input_output_paths test2 failed'
    try:
        for _ in range(2):
            var_0 = next(iterable_0)
    except ValueError:
        bool_0 = False
    assert bool_0
    assert False


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:47:24.194896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except ValueError:
        check_0 = True
    else:
        check_0 = False
    assert check_0

# Generated at 2022-06-25 21:47:32.047174
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert type(get_input_output_paths('a.py', 'c', 'c')) is Iterable, 'get_input_output_paths test1 failed'
    try:
        get_input_output_paths('c', 'b.py', 'c')
    except InvalidInputOutput:
        pass
    else:
        assert False, 'get_input_output_paths test2 failed'
    try:
        get_input_output_paths('a.py', 'b.py', 'a.py')
    except InvalidInputOutput:
        assert False, 'get_input_output_paths test3 failed'

# Generated at 2022-06-25 21:47:37.169611
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except AssertionError:
        str_0 = 'get_input_output_paths test1 failed'
        pytest.fail(str_0)
    except ValueError:
        str_0 = 'get_input_output_paths test3 failed'
        pytest.fail(str_0)
# ############################################################################


# Generated at 2022-06-25 21:47:45.699952
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    dict_0 = dict()
    dict_0['testcase_0'] = {
        'bool_0': True, # bool
        'str_0': 'a.py', # str
        'str_1': 'c', # str
        'iterable_0': [InputOutput(Path('a.py'), Path('c/a.py'))], # iterable
        'var_0': InputOutput(Path('a.py'), Path('c/a.py')), # InputOutput
        'var_1': None, # type
        'var_2': InvalidInputOutput,
        'str_2': 'get_input_output_paths test2 failed'  # str
    }

# Generated at 2022-06-25 21:47:47.272104
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
        bool_0 = True
    except Exception as exception:
        bool_0 = False
    assert bool_0

# Generated at 2022-06-25 21:48:01.183120
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        var_1 = "output/folder"
        var_2 = "test/folder"
        f = next(get_input_output_paths(var_1, var_1, var_1))
        assert f.input_ == Path('output/folder')
        assert f.output == Path('output/folder')
        print("get_input_output_paths test1: PASS")
    except StopIteration:
        print("get_input_output_paths test1: FAIL")

# Generated at 2022-06-25 21:48:08.854756
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    bool_0 = True
    str_0 = 'a.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    var_1 = ValueError(str_0)
    str_1 = 'get_input_output_paths test2 failed'
    try:
        get_input_output_paths(str_0, str_0, str_0)
    except ValueError as exception_0:
        assert exception_0 == var_1
    else:
        raise ValueError(str_1)
    bool_1 = type(var_0) == InputOutput
    assert bool_1
    return var_0


# Generated at 2022-06-25 21:48:18.497075
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    bool_0 = True
    str_0 = str(bool_0)
    try:
        get_input_output_paths(str_0, str_0, str_0)
    except InvalidInputOutput as var_0:
        var_1 = ValueError(str_0)
        str_1 = 'get_input_output_paths test1 failed'
    try:
        get_input_output_paths(str_1, str_0, str_1)
    except InvalidInputOutput as var_0:
        print('get_input_output_paths test3 failed')
    except InputDoesntExists as var_0:
        print('get_input_output_paths test2 failed')
    iterable_0 = get_input_output_paths(str_1, str_0, str_0)

# Generated at 2022-06-25 21:48:19.566262
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pytest.raises(TypeError, test_case_0)

# Generated at 2022-06-25 21:48:21.716758
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 0
    try:
        test_case_0()
    except ValueError:
        pass


# Generated at 2022-06-25 21:48:29.621710
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with invalid input
    # Comparing exceptions
    try:
        get_input_output_paths('a', 'b', 'c')
    except InvalidInputOutput:
        pass
    else:
        raise AssertionError('get_input_output_paths test1 failed')
    # Test with valid input
    # Comparing classes
    assert isinstance(next(get_input_output_paths('a.py', 'b.py', 'c')), InputOutput) == True
    # Comparing variables
    try:
        assert next(get_input_output_paths('a', 'a.py', 'b')) == ValueError()
    except ValueError:
        pass
    else:
        raise AssertionError('get_input_output_paths test2 failed')

# Generated at 2022-06-25 21:48:36.126873
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert True
    except ValueError as var_1:
        print('The exception is: ', var_1)
        print('get_input_output_paths test1 failed')
    # Case 0 for if-statement

    try:
        get_input_output_paths(str_0, str_0, str_0)
        print('The exception is: ', var_1)
        print('get_input_output_paths test2 failed')
    except ValueError as var_1:
        print('The exception is: ', var_1)


# Generated at 2022-06-25 21:48:42.340536
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except Exception:
        var_0 = Exception.args
        var_1 = bool(var_0)
        try:
            assert(var_1)
        except AssertionError:
            print('AssertionError: ' + 'test_case_0')
    else:
        pass

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:48:44.766695
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except ValueError:
        print('get_input_output_paths test1 failed')
        raise
    except StopIteration:
        print('get_input_output_paths test2 failed')
        raise

# Generated at 2022-06-25 21:48:48.622828
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True, 'get_input_output_paths test1 failed'
    assert True, 'get_input_output_paths test2 failed'
    assert True, 'get_input_output_paths test3 failed'
    assert True, 'get_input_output_paths test4 failed'

# Generated at 2022-06-25 21:48:55.311416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Initialize test case 0
    test_case_0()

if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:02.912704
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'get_input_output_paths test6 failed'
    try:
        get_input_output_paths('a.py', 'a.txt', 'a.txt')
        GetInputOutputPathsTest6Failed = False
    except TypeError:
        GetInputOutputPathsTest6Failed = True
    except AssertionError:
        GetInputOutputPathsTest6Failed = False
    str_1 = 'get_input_output_paths test6 failed'
#   assert(GetInputOutputPathsTest6Failed)

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 21:49:11.298696
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    var_2 = get_input_output_paths('a.py', 'a.py', 'a.py')
    var_3 = next(var_2)
    
    # Assertions
    assert var_3.output.name == 'a.py', 'get_input_output_paths test1 failed'
    assert var_3.input.name == 'a.py', 'get_input_output_paths test2 failed'
    try:
        get_input_output_paths('a.py', 'a.py', '')
        assert False, 'get_input_output_paths test3 failed'
    except InputDoesntExists:
        pass
    except Exception:
        assert False, 'get_input_output_paths test4 failed'

# Generated at 2022-06-25 21:49:21.231014
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input0
    # test case 1
    # function get_input_output_paths
    str_0 = 'a.py'
    # function get_input_output_paths
    str_1 = str_0
    # function get_input_output_paths
    str_2 = str_0
    # list comprehension
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = next(iterable_0)
    var_1 = ValueError(str_0)
    str_3 = 'get_input_output_paths test2 failed'
    # 'assertEqual' call

# Generated at 2022-06-25 21:49:29.526236
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_pairs = get_input_output_paths(
        input_='./tests/data/inputoutput_data/input',
        output='./tests/data/inputoutput_data/output',
        root='./tests/data/inputoutput_data/root')
    assert str(next(input_output_pairs).input) == './tests/data/inputoutput_data/input/a.py'
    assert str(next(input_output_pairs).input) == './tests/data/inputoutput_data/input/foo/b.py'
    assert str(next(input_output_pairs).input) == './tests/data/inputoutput_data/input/foo/bar/c.py'

# Generated at 2022-06-25 21:49:38.362567
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass
    try:
        assert False
        print('AssertionError expected')
    except AssertionError:
        pass

# Generated at 2022-06-25 21:49:48.170999
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    global bool_0
    global str_0
    global iterable_0
    global var_0
    global var_1
    global str_1
    # if input and output have '.py', get one pair
    bool_0 = True
    str_0 = 'a.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    assert var_0.input_path == Path(str_0)
    assert var_0.output_path == Path(str_0)
    # if output doesn't have '.py', raise exception
    var_1 = ValueError(str_0)

# Generated at 2022-06-25 21:49:58.049204
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Function used to unit test get_input_output_paths"""

# Generated at 2022-06-25 21:50:00.056801
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except ValueError as error:
        print(error)
    else:
        print('Function get_input_output_paths passed all tests.')

# Generated at 2022-06-25 21:50:07.481633
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert get_input_output_paths(str_0, str_0, str_0) == var_0
        bool_0 = False
    except AssertionError:
        str_1 = 'get_input_output_paths test1 failed'
    try:
        get_input_output_paths(str_0, str_0, str_0) == var_1
        bool_0 = False
    except Exception:
        bool_0 = True

    assert bool_0
    test_case_0()

# Generated at 2022-06-25 21:50:25.596296
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    bool_0 = True
    str_0 = 'get_input_output_paths test2 failed'
    str_1 = 'get_input_output_paths test22 failed'
    iterable_0 = get_input_output_paths('.test', '.test', None)
    str_2 = '.test'
    inputoutput_0 = InputOutput(Path(str_2), Path(str_2))
    iterable_1 = get_input_output_paths('.test', '.test', '.test')
    inputoutput_1 = InputOutput(Path(str_2), Path(Path(str_2).name))
    iterable_2 = get_input_output_paths('.test/a.py', '.test/b.py', None)

# Generated at 2022-06-25 21:50:30.732122
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for output = ''
    try:
        get_input_output_paths('', '', '')
    except ValueError:
        bool_0 = True
    else:
        bool_0 = False
    assert bool_0
    # Test for output != ''
    bool_0 = False
    try:
        get_input_output_paths('', 'a.py', '')
    except ValueError:
        bool_0 = True
    assert bool_0

# Generated at 2022-06-25 21:50:32.774433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a.py', 'b.py', 'root') == InputOutput(Path('a.py'), Path('b.py'))


# Generated at 2022-06-25 21:50:41.116415
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:50:44.738334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except NameError:
        print('Missing variable')
    except AssertionError:
        print('Assertion failed')
    except StopIteration:
        print('Empty iterable')
    except TypeError:
        print('Illegal operand types')
    except ZeroDivisionError:
        print('Illegal division')
    except ValueError:
        print(str_1)

# Generated at 2022-06-25 21:50:50.102479
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'get_input_output_paths test failed'
    str_1 = '/users/you/temp/templates.zip'
    iterable_0 = get_input_output_paths(str_1, str_1, str_1)
    var_0 = next(iterable_0)
    bool_0 = True
    # Assert that file is the input and output
    assert bool_0

# Generated at 2022-06-25 21:50:57.891139
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Generating input data
    bool_0 = True
    str_0 = 'a.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    var_1 = ValueError(str_0)
    str_1 = 'get_input_output_paths test2 failed'

    # Executing function
    try:
        result = get_input_output_paths(str_0, str_0, str_0)
    except ValueError as err:
        result = err
    except Exception:
        result = None

    if result is not None:
        if not isinstance(result, ValueError):
            return str_1
    else:
        return str_1



# Generated at 2022-06-25 21:51:02.329057
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except AssertionError:
        var_2 = AssertionError(str_1)
        raise var_2
    except Exception:
        var_3 = Exception(str_1)
        raise var_3


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:51:09.459015
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    v = get_input_output_paths('a.py', 'a.py', 'a.py')
    v = next(v)
    assert (v.input == 'a.py' and v.output == 'a.py')
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('./examples/a.py', 'a.py', 'a.py')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')

# Generated at 2022-06-25 21:51:10.901857
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('a.py', 'a.py', 'a.py')

# Generated at 2022-06-25 21:51:39.049911
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('a.py', 'a.py', 'a.py')
    except ValueError as e:
        print('get_input_output_paths test1 failed')

    try:
        bool_0 = True
        str_0 = 'a.py'
        iterable_0 = get_input_output_paths(str_0, str_0, str_0)
        var_0 = next(iterable_0)
        var_1 = ValueError(str_0)
        str_1 = 'get_input_output_paths test2 failed'
    except ValueError as e:
        print('get_input_output_paths test2 failed')


# Generated at 2022-06-25 21:51:41.531520
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Success
    try:
        test_case_0()
        assert True
    # Fail
    except ValueError:
        assert True
    except AssertionError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 21:51:46.667565
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = Path(__file__).parent.absolute() / 'test_io'
    iterable_0 = get_input_output_paths('test_io', 'test_io', str_0)
    var_0 = next(iterable_0)
    var_1 = str_0 / 'test_io.py'
    assert var_0.input == var_1
    assert var_0.output == var_1
    try:
        next(iterable_0)
    except StopIteration:
        pass
    else:
        assert False


# Generated at 2022-06-25 21:51:47.325386
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:51:54.587897
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths("a.txt", "a.py", "a.txt")
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths("a.txt", "a.txt", "a.txt")
    assert list(get_input_output_paths("a.py", "a.txt", None)) == \
        [InputOutput(Path("a.py"), Path("a.txt/a.py"))]
    assert list(get_input_output_paths("/path/a.py", "a.txt", None)) == \
        [InputOutput(Path("/path/a.py"), Path("a.txt/a.py"))]

# Generated at 2022-06-25 21:52:00.314665
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert False == bool_0
    with pytest.raises(var_1):
        get_input_output_paths(str_0, str_0, str_0)
    try:
        get_input_output_paths(str_0, str_0, str_0)
    except Exception as var_2:
        str_2 = str(var_2)
        assert str_2 == str_0
        assert var_2 == var_1
    assert var_0.input_path == var_0.input_path
    assert var_0.output_path == var_0.output_path


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:52:04.438135
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    bool_0 = True
    str_0 = 'help.py'
    str_1 = 'help.py'
    str_2 = 'help.py'
    str_3 = 'help.py'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = next(iterable_0)


# Generated at 2022-06-25 21:52:06.656173
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .test_cases.test_get_input_output_paths_cases import test_case_0
    test_case_0()

# Generated at 2022-06-25 21:52:16.011744
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    DIR = Path(os.path.abspath(os.sep))
    TMP = Path(tempfile.gettempdir())
    assert list(get_input_output_paths(
        str(TMP), str(DIR), str(TMP))) == \
        [InputOutput(TMP, DIR / TMP)]
    assert list(get_input_output_paths(
        str(DIR), str(TMP), str(TMP))) == \
        [InputOutput(TMP.joinpath('a.py'), TMP.joinpath('a.py'))]
    assert list(get_input_output_paths(str(TMP), str(TMP), str(TMP))) == \
        [InputOutput(TMP, TMP)]

# Generated at 2022-06-25 21:52:23.251099
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    bool_0 = True
    str_0 = 'a.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = next(iterable_0)
    var_1 = ValueError(str_0)
    str_1 = 'get_input_output_paths test 1 failed'
    try:
        input_output = get_input_output_paths('a.py', 'a.py', '.')
        assert input_output.input == input_output.output
    except ValueError as e:
        assert type(e) is ValueError
        assert e.args[0] == 'a.py'