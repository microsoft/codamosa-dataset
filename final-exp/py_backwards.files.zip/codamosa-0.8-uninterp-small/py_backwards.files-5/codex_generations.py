

# Generated at 2022-06-25 21:45:52.347908
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    #assert None

test_get_input_output_paths()

# Generated at 2022-06-25 21:45:53.913135
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 21:45:55.532320
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:46:02.638255
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'A'
    str_1 = 'B'
    str_2 = 'C'
    str_3 = 'D'
    str_4 = 'E'
    str_5 = 'F'
    str_6 = '20.py'
    output_path = Path(str_6)
    root_path = Path(str_0)
    input_path = Path(str_6)
    child_input = Path(str_6)
    child_output = Path(str_5).joinpath(child_input.relative_to(root_path))
    input_output = InputOutput(input_path, output_path)
    input_output1 = InputOutput(child_input, child_output)

# Generated at 2022-06-25 21:46:12.820412
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for i in range(0, 10):
        str_0 = '$u#/`4Ot'
        str_1 = '{1)zTI{'
        str_2 = '=+g6I.OGm'
        iterable_0 = get_input_output_paths(str_0, str_1, str_2)
        assert isinstance(iterable_0, Iterable)
        sieve_0 = Sieve()
        for input_output_0 in iterable_0:
            assert isinstance(input_output_0, InputOutput)
            str_3 = 'U6Y'
            str_4 = '@$0I'
            str_5 = '?-Z!0'
            assert isinstance(input_output_0.input, Path)

# Generated at 2022-06-25 21:46:20.194531
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'G'
    str_1 = '--output'
    str_2 = 'G'
    str_3 = 'P'
    str_4 = 'n'
    str_5 = 'G'
    str_6 = 'n'
    str_7 = 'P'
    int_0 = len(str_0)
    int_1 = len(str_1)
    int_2 = len(str_2)
    int_3 = len(str_3)
    int_4 = len(str_4)
    int_5 = len(str_5)
    int_6 = len(str_6)
    int_7 = len(str_7)
    int_8 = len(str_0)
    int_9 = len(str_2)
    int_10 = len

# Generated at 2022-06-25 21:46:20.941696
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1, test_case_0()

# Generated at 2022-06-25 21:46:32.390617
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '$u#/`4Ot'
    with pytest.raises(Exception):
        get_input_output_paths(str_0, str_0, str_0)
    str_1 = ".z'$gq3D4"
    with pytest.raises(Exception):
        get_input_output_paths(str_1, str_1, str_1)
    str_2 = '}p@!xW8b+'
    Path.exists = lambda *args, **kwargs: True
    with pytest.raises(Exception):
        get_input_output_paths(str_2, str_2, str_2)
    str_3 = "r3qg+h~zJ"
    Path.exists = lambda *args, **kwargs: False

# Generated at 2022-06-25 21:46:33.518687
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-25 21:46:36.042245
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


if __name__ == '__main__':
    import pytest
    pytest.main(args=['-q', __file__])

# Generated at 2022-06-25 21:46:54.331443
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('testpackage', 'testpackage.py', '')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('nosuchfile', 'testpackage.py', '')
    result = get_input_output_paths('testpackage', 'testpackage_out', '')
    assert len(list(result)) == 3
    result = list(get_input_output_paths('testpackage', 'testpackage_out', 'testpackage'))
    assert len(result) == 3
    assert result[0].input_path.name == '__init__.py'
    assert result[0].output_path.name == '__init__.py'
    assert result[0].input_path.parent == result

# Generated at 2022-06-25 21:47:04.261155
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # INPUT: ROOT and input/output are directories
    input_path = Path('tests/input')
    output_path = Path('tests/output')
    root = 'tests/input'
    # expected results
    expected_input_path = Path('tests/input/example1.py')
    expected_output_path = Path('tests/output/example1.py')
    for input_output in get_input_output_paths(input_path, output_path, root):
        actual_input = input_output.input
        actual_output = input_output.output
        assert expected_input_path == actual_input
        assert expected_output_path == actual_output
    
    # INPUT: input is a directory, output is a file
    input_path = Path('tests/input')

# Generated at 2022-06-25 21:47:04.613655
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pass

# Generated at 2022-06-25 21:47:13.687415
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [InputOutput(Path('input.py'), Path('out.py'))] == list(get_input_output_paths('input.py', 'out.py', None))
    assert [InputOutput(Path('input.py'), Path('out.py'))] == list(get_input_output_paths('input.py', 'out.py', ''))
    assert [InputOutput(Path('input.py'), Path('output.py'))] == list(get_input_output_paths('input.py', 'output/', ''))

# Generated at 2022-06-25 21:47:22.285284
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for get_input_output_paths(input_, output,  root)
    # input_ is a path of a file
    # output is a path of a file
    # root is None
    input_ = 'tests/data/example/hello.py'
    output = 'output/example/hello.py'
    root = None
    expected = InputOutput(Path('tests/data/example/hello.py'), Path('output/example/hello.py'))
    assert list(get_input_output_paths(input_, output, root)) == [expected]

    # Test for get_input_output_paths(input_, output,  root)
    # input_ is a path of a file
    # output is a path of a directory
    # root is None

# Generated at 2022-06-25 21:47:30.912737
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input/', 'output.py', None)
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input/', 'output/', None)

    input_output_paths_relative_to_root = get_input_output_paths(
        'input/module1.py', 'output/module1.py', None)
    input_output_paths_root = get_input_output_paths(
        'input/module1.py', 'output/', None)
    input_output_paths_not_root = get_input_output_paths(
        'input/module1.py', 'output/', 'input/')

    assert input_output_paths_relative

# Generated at 2022-06-25 21:47:35.603611
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/Users/guptaa/Desktop/files/inputfolder'
    output = '/Users/guptaa/Desktop/files/outputfolder'
    root = None
    answer = InputOutput(pathlib.Path('/Users/guptaa/Desktop/files/inputfolder/inputfile.py'), pathlib.Path('/Users/guptaa/Desktop/files/outputfolder/inputfile.py'))
    assert get_input_output_paths(input_, output, root) == [answer]

# Generated at 2022-06-25 21:47:44.359734
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as root_dir:
        root = Path(root_dir)
        input_dir = root.joinpath('input')
        input_dir.mkdir()

        input_dir_level1 = input_dir.joinpath('level1')
        input_dir_level1.mkdir()
        input_dir_level2 = input_dir.joinpath('level2')
        input_dir_level2.mkdir()
        input_level1 = input_dir_level1.joinpath('level1.py')
        input_level1.touch()
        input_level2 = input_dir_level2.joinpath('level2.py')
        input_level2.touch()


# Generated at 2022-06-25 21:47:51.957064
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input = "./a"
    output = "./b"
    root = None
    result = list(get_input_output_paths(input, output, root))
    assert result == [InputOutput(Path("./a/a.py"), Path("./b/a.py"))]

    input = "./a"
    output = "./b"
    root = "./a"
    result = list(get_input_output_paths(input, output, root))
    assert result == [InputOutput(Path("./a/a.py"), Path("./b/a.py"))]

    input = "./a/a.py"
    output = "./b"
    root = None
    result = list(get_input_output_paths(input, output, root))

# Generated at 2022-06-25 21:48:00.966299
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('examples', 'out', None)) == [
        InputOutput(Path('examples/foo.py'), Path('out/foo.py')),
        InputOutput(Path('examples/bar.py'), Path('out/bar.py')),
    ]

    assert list(get_input_output_paths('examples/foo.py', 'out', None)) == [
        InputOutput(Path('examples/foo.py'), Path('out/foo.py')),
    ]

    assert list(get_input_output_paths('examples/foo.py', 'out/foo.py', None)) == [
        InputOutput(Path('examples/foo.py'), Path('out/foo.py')),
    ]


# Generated at 2022-06-25 21:48:04.996196
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 21:48:13.837088
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Try out a positive test case
    try:
        test_case_0()
    except Exception:
        assert False
    # Try out a negative test case
    try:
        str_0 = ''
        iterable_0 = get_input_output_paths(str_0, str_0, str_0)
        var_0 = list(iterable_0)
        str_1 = 'output.py'
        assert False
    except Exception:
        assert True
    # Try out a positive test case

# Generated at 2022-06-25 21:48:15.809034
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True
    print('Success: test_get_input_output_paths')



# Generated at 2022-06-25 21:48:16.836632
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:21.482709
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input: str = "input.py"
    output: str = "output.py"
    root: Optional[str] = None

    # Input: 
    assert get_input_output_paths(input, output, root) == [(Path('input.py'), Path('output.py'))]
    print("Test for get_input_output_paths: " + "PASSED")

test_get_input_output_paths()

# Generated at 2022-06-25 21:48:29.694324
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # User Case 0:
    assert list(get_input_output_paths('input.py', 'output.py', 'project')) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]
    # User Case 1:
    assert list(get_input_output_paths('input.py', 'project/output.py',
                                       'project')) == [
                                           InputOutput(Path('input.py'),
                                                       Path('project/output.py'))
                                       ]
    # User Case 2:
    assert list(get_input_output_paths('project/input.py', 'output.py',
                                       'project')) == [
                                           InputOutput(Path('project/input.py'),
                                                       Path('output.py'))
                                       ]


# Generated at 2022-06-25 21:48:39.638971
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.py', 'root')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', 'root')

    assert get_input_output_paths('input.py', 'output', 'root') == [
        InputOutput(Path('input.py'), Path('output').joinpath(Path('input.py')))
    ]

    assert get_input_output_paths('input.py', 'output', '') == [
        InputOutput(Path('input.py'), Path('output').joinpath(Path('input.py')))
    ]

    assert get_input_output_paths('', 'output', '') == []


# Generated at 2022-06-25 21:48:46.646375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'input/bar.py'
    str_1 = 'input/foo.py'
    str_2 = 'output/'
    str_3 = 'input/foo.py'
    str_4 = 'input/'
    str_5 = 'output/'
    str_6 = 'input/foo.py'
    str_7 = 'output'
    str_8 = 'input'
    str_9 = 'output'
    str_10 = 'input.py'
    str_11 = 'output.py'
    str_12 = 'input/foo.py'
    str_13 = 'input/bar.py'
    str_14 = 'input.py'
    str_15 = 'output.py'
    str_16 = 'input/foo.py'

# Generated at 2022-06-25 21:48:47.586944
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:48:48.731007
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(test_case_0()) == None

# Generated at 2022-06-25 21:48:57.007513
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:49:05.433905
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    while True:
        str_0 = rand_string()
        str_1 = rand_string()
        str_2 = rand_string()

# Generated at 2022-06-25 21:49:11.160343
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    iterable_1 = get_input_output_paths(str_0, str_1, str_2)
    list_0 = list(iterable_0)
    list_1 = list(iterable_1)
    assert list_0 == list_1

# Generated at 2022-06-25 21:49:11.647598
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    case_0()

# Generated at 2022-06-25 21:49:14.129456
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Setup
    input_ = str
    output = str
    root = None

    # Exercise
    paths = get_input_output_paths(input_, output, root)

    # Verify
    assert paths == []

# Generated at 2022-06-25 21:49:17.834889
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Place your code here
    # It's OK to delete this function
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:49:18.932412
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Generated at 2022-06-25 21:49:27.817038
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # noinspection PyUnresolvedReferences
    input_path = Path('pathlib_is_cool/tests/fixtures/input/dummy.py')
    # noinspection PyUnresolvedReferences
    output_path = Path('pathlib_is_cool/tests/fixtures/output/dummy.py')
    result = get_input_output_paths(str(input_path),
                                    str(output_path),
                                    str(Path('pathlib_is_cool/tests/fixtures/input')))
    assert isinstance(result, Iterable)
    assert list(result) == [InputOutput(input_path, output_path)]

    # noinspection PyUnresolvedReferences
    input_path = Path('pathlib_is_cool/tests/fixtures/input')
    # noinspection PyUnresolved

# Generated at 2022-06-25 21:49:33.289359
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    expected = [('', ()), ('', ('bar',)), ('foo/bar.py', 'baz/bar.py'), ('foo/bar.py', 'baz.py'), ('foo/bar.py', 'baz'), ('foo', 'baz')]
    actual = []
    actual.append(get_input_output_paths('', '', ''))
    actual.append(get_input_output_paths('', 'bar', ''))
    actual.append(get_input_output_paths('foo/bar.py', 'baz/bar.py', ''))
    actual.append(get_input_output_paths('foo/bar.py', 'baz.py', ''))
    actual.append(get_input_output_paths('foo/bar.py', 'baz', ''))
    actual.append

# Generated at 2022-06-25 21:49:41.374204
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # SOURCE LINE 5
    input_0 = 'tests/data/input/index.py'
    output_0 = 'tests/data/output'
    root_0 = 'tests/data/input'
    iterable_0 = get_input_output_paths(input_0, output_0, root_0)
    var_0 = list(iterable_0)
    print(var_0)

# Generated at 2022-06-25 21:49:58.764503
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    temp_0 = get_input_output_paths("/home/user/test/test_simple.py",
                                    "/home/user/test/test_simple_out.py",
                                    "/home/user/test")
    assert list(temp_0) == [("/home/user/test/test_simple.py",
                             "/home/user/test/test_simple_out.py")]

    temp_0 = get_input_output_paths("/home/user/test/test_simple.py",
                                    "/home/user/test/test_simple.py",
                                    "/home/user/test")
    assert list(temp_0) == [("/home/user/test/test_simple.py",
                             "/home/user/test/test_simple.py")]

    temp_

# Generated at 2022-06-25 21:50:03.597331
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1 - both input and output are directories
    str_0 = '.'
    str_1 = '.'
    str_2 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input == Path('test_input_output.py')
    assert var_0[0].output == Path('test_input_output.py')

    # Test case 2 - input is directory, output is file
    iterable_1 = get_input_output_paths(str_0, 'output.txt', str_2)
    var_1 = list(iterable_1)
    assert len(var_1) == 1
   

# Generated at 2022-06-25 21:50:04.434357
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:50:11.402117
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    
    with pytest.raises(InvalidInputOutput):
        result = get_input_output_paths('', '', '')
    
    with pytest.raises(InvalidInputOutput):
        result = get_input_output_paths('.py', '/example/output', '')
    
    with pytest.raises(InputDoesntExists):
        result = get_input_output_paths('', '/example/output', '')
    
    # Test with an absolute path
    result = get_input_output_paths('/example/input', '/example/output', '')
    assert result
    result = list(result)
    assert result[0][0].name == 'input.py'
    assert result[0][1].name == 'output.py'
    result = get_input_output_paths

# Generated at 2022-06-25 21:50:12.374027
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)



# Generated at 2022-06-25 21:50:15.320336
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('', '.py', '')
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths('', '.py', '')

# Generated at 2022-06-25 21:50:17.464945
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Should fail for the first case
    try:
        test_case_0()
    except Exception as e:
        return
    assert False

if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:19.332956
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Testing function get_input_output_paths...')
    assert 1 == 1


# Generated at 2022-06-25 21:50:27.904874
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Edges
    try:
        list(get_input_output_paths('test.py', 'test2.py', '.'))
    except AssertionError:
        pass

    try:
        list(get_input_output_paths('test.py', 'test2.py', 'test'))
    except AssertionError:
        pass

    try:
        list(get_input_output_paths('test.py', 'test2.py', 'test.py'))
    except AssertionError:
        pass

    try:
        list(get_input_output_paths('test.py', 'test2', 'test.py'))
    except InvalidInputOutput:
        pass


# Generated at 2022-06-25 21:50:29.593545
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_case_1()
    test_case_2()

# Unit test case

# Generated at 2022-06-25 21:51:28.567896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    # TODO: implement your test here


test_case_0()

# Generated at 2022-06-25 21:51:28.984373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 1 == 1

# Generated at 2022-06-25 21:51:32.100514
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)


# Generated at 2022-06-25 21:51:33.957003
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-25 21:51:42.090754
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    template = (
        '/home/dmitri/proj/tator-transcoder/3rdparty/typing/tests/'
        'data/input_outputs_testcase_0/{}.py'
    )
    input_outputs = list(get_input_output_paths(
        template.format(''), template.format('out'), '/home/dmitri/proj/tator-transcoder/3rdparty/typing/tests/data/input_outputs_testcase_0'
    ))
    variable = input_outputs[0]
    assert variable == InputOutput(Path(template.format('input_file_0')), Path(template.format('output_file_0')))

# Generated at 2022-06-25 21:51:44.578838
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass
    else:
        raise AssertionError('AssertionError: Case 0')


# Generated at 2022-06-25 21:51:51.299314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output_path_0 = ''
    input_path_0 = ''
    root_path_0 = ''
    str_0 = ''
    iterable_0 = get_input_output_paths(input_path_0, output_path_0, root_path_0)
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path('.'), Path('.'))]

    input_path_1 = 'data'
    output_path_1 = 'test/test_output'
    root_path_1 = ''
    iterable_1 = get_input_output_paths(input_path_1, output_path_1, root_path_1)
    var_1 = list(iterable_1)

# Generated at 2022-06-25 21:51:57.077048
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a = 'a'
    b = 'b'
    c = 'c'
    a_path = Path(a)
    b_path = Path(b)
    c_path = Path(c)
    output_paths = get_input_output_paths(a, b, c)
    for i in output_paths:
        assert i.input.relative_to(Path(c)) == i.output.relative_to(Path(b))
    # input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('idnexist', 'exist', 'exist')

# Generated at 2022-06-25 21:52:04.291400
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import lists
    from hypothesis.strategies import composite
    from hypothesis.strategies import sampled_from

    import pathlib
    import sys

    @composite
    def file_path(draw, path=pathlib.Path()):
        in_out = draw(text())
        return path.joinpath(in_out)

    @composite
    def output_path(draw, path=pathlib.Path()):
        in_out = draw(text(alphabet='.py/', min_size=1))
        return path.joinpath(in_out)

    @composite
    def input_output(draw, path=pathlib.Path()):
        """."""
        input_out = draw(text())
       

# Generated at 2022-06-25 21:52:06.184512
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except ImportError:
        pass

# Test of except statements

# Generated at 2022-06-25 21:55:41.904202
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)

    assert len(var_0) == 1
    assert var_0[0].input_path == Path()
    assert var_0[0].output_path == Path()



# Generated at 2022-06-25 21:55:43.173430
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

if __name__ == '__main__':
    test_get_input_output_paths()