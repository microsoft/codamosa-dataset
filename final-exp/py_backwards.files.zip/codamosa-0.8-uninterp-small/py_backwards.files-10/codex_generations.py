

# Generated at 2022-06-25 21:45:51.779119
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:46:00.818761
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        input_0 = '{+_c"`"oz3>Qm0R'
        output_0 = '{+_c"`"oz3>Qm0R'
        root_0 = '{+_c"`"oz3>Qm0R'
        get_input_output_paths(input_0, output_0, root_0)

    with pytest.raises(InputDoesntExists):
        input_0 = '{+_c"`"oz3>Qm0R'
        output_0 = '{+_c"`"oz3>Qm0R'
        root_0 = '{+_c"`"oz3>Qm0R'

# Generated at 2022-06-25 21:46:02.075972
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:46:12.408899
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:19.898628
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .utils import frozen_dir
    from .types import InputOutput

    with frozen_dir({
        'a.py': '',
        'b.py': '',
        'dummy.txt': ''
    }):
        assert list(get_input_output_paths('a.py', 'b.py', None)) == [
            InputOutput(Path('a.py'), Path('b.py'))
        ]
        assert list(get_input_output_paths('.', 'b.py', None)) == [
            InputOutput(Path('a.py'), Path('b.py')),
            InputOutput(Path('dummy.txt'), Path('b.py/dummy.txt')),
            InputOutput(Path('b.py'), Path('b.py/b.py'))
        ]

# Generated at 2022-06-25 21:46:24.088523
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:29.306097
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "path/to/in"
    output = "path/to/out"
    root = "path/to"
    iterable = get_input_output_paths(input_, output, root)
    for file in iterable:
        assert file.input_path == Path("path/to/in")
        assert file.output_path == Path("path/to/out/in")

# Generated at 2022-06-25 21:46:39.156442
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '[/y4$iMLXHY'
    str_1 = 'k58S&|QP"o<I'
    str_2 = '4}X9?t@1+:(A'
    int_0 = len(get_input_output_paths(str_1, str_1, str_2))
    int_1 = len(get_input_output_paths(str_2, str_2, str_0))
    int_2 = len(get_input_output_paths(str_0, str_0, str_1))
    int_3 = len(get_input_output_paths(str_1, str_2, str_0))
    int_4 = len(get_input_output_paths(str_1, str_1, str_0))


# Generated at 2022-06-25 21:46:40.388136
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '{+_c"`"oz3>Qm0R'
    test_case_0()



# Generated at 2022-06-25 21:46:50.755389
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("", "", "") == ()
    assert get_input_output_paths("", "", "") == get_input_output_paths("", "", "")
    assert get_input_output_paths("", "/", "") == get_input_output_paths("", "/", "")
    assert get_input_output_paths("", "", "/") == get_input_output_paths("", "", "/")
    assert get_input_output_paths("", "/", "/") == get_input_output_paths("", "/", "/")
    assert get_input_output_paths("/", "", "") == get_input_output_paths("/", "", "")

# Generated at 2022-06-25 21:46:59.153952
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'a.py'
    input_1 = '.'
    excepted_0 = InputOutput(Path('a.py'), Path('a.py'))
    expect_0 = get_input_output_paths(input_0, input_1, None)
    for item_0, item_1 in zip(excepted_0, expect_0):
        assert item_0 == item_1
    return


# Generated at 2022-06-25 21:47:07.416118
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'a.py'
    output = '.'
    root = None
    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)
    var_1 = get_input_output_paths(input_, output, root)
    var_2 = list(var_1)
    var_3 = get_input_output_paths('b.py', '.', None)
    var_4 = list(var_3)
    var_5 = get_input_output_paths(input_, output, root)
    var_6 = list(var_5)
    var_7 = get_input_output_paths('b.py', '.', None)
    var_8 = list(var_7)

# Generated at 2022-06-25 21:47:20.849555
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'a.py'
    str_1 = 'b.py'
    str_2 = ''
    try:
        get_input_output_paths(str_0, str_1, str_2)
    except InvalidInputOutput:
        pass
    str_0 = 'a.py'
    try:
        get_input_output_paths(str_0, str_1, str_1)
    except InputDoesntExists:
        pass
    str_0 = 'dir'
    str_1 = 'dir'
    str_2 = 'dir'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    str_0 = 'dir'

# Generated at 2022-06-25 21:47:29.774065
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('a.txt', 'b.txt', None)
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths('a.py', 'a.txt', None)
    assert list(get_input_output_paths('a.py', 'b.txt', None)) == [
        InputOutput(Path('a.py'), Path('b.txt'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))
    ]

# Generated at 2022-06-25 21:47:33.258674
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'a.py'
    str_1 = 'b.py'
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:47:42.006719
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '/usr/local/lib/python3.5/site-packages/pip/_vendor/requests'
    str_1 = '/Users/damien/workspace/code-quality/test/test_output.py'
    str_2 = '/usr/local/lib/python3.5/site-packages/pip/_vendor/requests/certs.py'

    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert  var_0[0].input_path == Path('/usr/local/lib/python3.5/site-packages/pip/_vendor/requests/certs.py')

# Generated at 2022-06-25 21:47:47.168964
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # These lines are used to test the error cases...
    # test_case_0()

    str_0 = 'foo/'
    str_1 = 'bar/'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    for var_0 in iterable_0:
        var_0.input.name
        var_0.output.name


if __name__ == '__main__':
    pytest.main(args=[ __file__])

# Generated at 2022-06-25 21:47:50.994591
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Set up test values

    str_0 = 'mod.py'
    str_1 = '.'
    # Call the function under test
    tup_0 = get_input_output_paths(str_0, str_1)
    # Check the result
    assert tup_0 == (mod, mod), 'Failed test_get_input_output_paths'

# Generated at 2022-06-25 21:47:51.956111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:01.012413
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # str.endswith(str) -> bool
    str_0 = 'a.py'
    str_1 = '.'
    # a.py and .
    iterable_0 = get_input_output_paths(str_1, str_1, str_0)
    var_0 = list(iterable_0)

    # str.endswith(str) -> bool
    str_2 = 'a.py'
    str_3 = '.'
    # a.py and .
    iterable_1 = get_input_output_paths(str_2, str_2, str_3)
    var_1 = list(iterable_1)

    # str.endswith(str) -> bool
    str_4 = 'a.py'
    str_5 = '.'
    # a.py

# Generated at 2022-06-25 21:48:06.738445
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:16.437647
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:48:20.522298
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:48:28.740771
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('.', '.', '.'))) == 0
    assert list(get_input_output_paths('tests/tests.py', 'tmp/tests.py', '.')) == [InputOutput(Path("tests/tests.py"), Path("tmp/tests.py"))]
    assert list(get_input_output_paths('tests/tests.py', 'tmp', '.')) == [InputOutput(Path("tests/tests.py"), Path("tmp/tests.py"))]
    assert list(get_input_output_paths('tests', 'tmp', 'tests')) == [InputOutput(Path("tests/tests.py"), Path("tmp/tests.py"))]

# Generated at 2022-06-25 21:48:31.177744
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import numpy as np
    expected = [(Path('.'), Path('.'))]
    actual = list(get_input_output_paths('.', '.', '.'))
    assert all(np.isclose(expected, actual))


# Generated at 2022-06-25 21:48:41.645529
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Input/Output pair, input is a file and output is a file
    input_ = 'example/input/buy_low_sell_high.py'
    output = 'example/output/buy_low_sell_high.py'
    root = None
    expected = [InputOutput(Path(input_), Path(output))]
    iterable = get_input_output_paths(input_, output, root)
    assert list(iterable) == expected
    # Change input to be a directory
    input_ = 'example/input'
    expected = [InputOutput(Path(input_, 'buy_low_sell_high.py'),
                            Path(output, 'buy_low_sell_high.py'))]
    iterable = get_input_output_paths(input_, output, root)

# Generated at 2022-06-25 21:48:47.371139
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # No arguments
    assert list(get_input_output_paths('tests/input/py', 'tests/output/py',
                                       None)) == [
        InputOutput(Path('tests/input/py/foo.py'),
                    Path('tests/output/py/foo.py')),
        InputOutput(Path('tests/input/py/foo/foo.py'),
                    Path('tests/output/py/foo/foo.py')),
        InputOutput(Path('tests/input/py/foo/__init__.py'),
                    Path('tests/output/py/foo/__init__.py')),
        InputOutput(Path('tests/input/py/__init__.py'),
                    Path('tests/output/py/__init__.py'))
    ]

    # One argument

# Generated at 2022-06-25 21:48:50.405072
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    str_1 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_0)
    var_0 = list(iterable_0)
    # AssertionError


# Generated at 2022-06-25 21:49:00.817288
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Assign
    input_0 = 'example/subdir'
    input_1 = 'example/subdir/subsubdir/subsubsubdir/subsubsubsubdir/subsubsubsubsubdir/subsubsubsubsubsubdir'
    input_2 = 'example/subdir/subsubdir/subsubsubdir/subsubsubsubdir/subsubsubsubsubdir'
    input_3 = 'example/subdir/subsubdir/subsubsubdir/subsubsubsubdir'
    input_4 = 'example/subdir/subsubdir/subsubsubdir'
    input_5 = 'example/subdir/subsubdir'
    input_6 = 'example/subdir'
    input_7 = 'example'

    output_0 = input_0
    output_1 = input_1
    output_

# Generated at 2022-06-25 21:49:02.609755
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pass


if __name__ == '__main__':
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:16.029136
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 21:49:17.496819
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(".", ".", None) is not None

# Generated at 2022-06-25 21:49:21.373516
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '.'
    output = '.'
    root = '.'
    actual = get_input_output_paths(input_, output, root)
    expected = [(Path('./test_io.py'), Path('./test_io.py'))]
    assert expected == list(actual)


# Generated at 2022-06-25 21:49:29.658149
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = ""

    if os.path.exists("input.py"):
        os.remove("input.py")
    if os.path.exists("input"):
        os.remove("input")
    if os.path.exists("output"):
        os.remove("output")
    if os.path.exists("output/input.py"):
        os.remove("output/input.py")
    if os.path.exists("output/input"):
        os.remove("output/input")

    # Test case #0

# Generated at 2022-06-25 21:49:38.363608
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    str_1 = '.'
    str_2 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    str_3 = str(var_0[0].input)
    str_4 = str(var_0[0].output)
    assert str_3 == '.'
    assert str_4 == '.'
    print('>>> ', str_3, str_4)

    str_0 = '.'
    str_1 = 'output'
    str_2 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    str_3

# Generated at 2022-06-25 21:49:48.170390
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Assert if the function can handle a directory as input
    input_output_tuples = list(get_input_output_paths('test_data', 'outputs', 'test_data'))
    assert len(input_output_tuples) == 8
    for input_output_tuple in input_output_tuples:
        assert input_output_tuple.input.exists()
        assert input_output_tuple.input.suffix == '.py'
        assert str(input_output_tuple.input).startswith('test_data')
        assert str(input_output_tuple.output).startswith('outputs')
        assert input_output_tuple.output.suffix == '.py'

    # Assert if the function raises an exception if the output is a dir but the input is a file

# Generated at 2022-06-25 21:49:49.575613
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() is None, "test_case_0"

# Generated at 2022-06-25 21:49:53.347686
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0: List[InputOutput] = list(iterable_0)
    var_1: str = var_0[0].input.name
    var_2: str = var_0[0].output.name

# Generated at 2022-06-25 21:50:01.797416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        x = get_input_output_paths('/home/vladimir/PycharmProjects/CodeSkulptor/tests', '/home/vladimir/PycharmProjects/CodeSkulptor/tests', '/home/vladimir/PycharmProjects/CodeSkulptor/tests')
        # assert (x ==)
    except InputDoesntExists:
        assert (1 == 1)
    except InvalidInputOutput:
        assert (1 == 1)
    finally:
        assert (1 == 1)


# Generated at 2022-06-25 21:50:02.290593
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True

# Generated at 2022-06-25 21:51:42.358922
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input_path == var_0[0].output_path


# Generated at 2022-06-25 21:51:46.699490
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert(get_input_output_paths('.', '.', '.') == list('<generator object _paths_from_glob at 0x0288EE30>')) # Checks function returns exactly what it's supposed to
    assert(get_input_output_paths('.', '.', '.') != list('<generator object _paths_from_glob at 0x028AEE30>')) # Checks function returns exactly what it's supposed to

# Generated at 2022-06-25 21:51:47.356837
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:51:54.647543
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(".", ".", None) == InputOutput(Path("."), Path(".")), "The function get_input_output_paths is not working properly"
    assert get_input_output_paths(".", "..", None) == InputOutput(Path("."), Path("..")), "The function get_input_output_paths is not working properly"
    assert get_input_output_paths("..", ".", None) == InputOutput(Path(".."), Path(".")), "The function get_input_output_paths is not working properly"
    assert get_input_output_paths("..", "..", None) == InputOutput(Path(".."), Path("..")), "The function get_input_output_paths is not working properly"

# Generated at 2022-06-25 21:51:59.079582
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    # TODO: Add your own tests!


if __name__ == "__main__":
    # Do not change any code below this line!
    # Those tests are mainly for developers.
    # Unit test output should appear like this
    #
    #   ------------------------------
    #   Function: get_input_output_paths
    #   ------------------------------
    #   test_case_0: PASS
    #   ------------------------------
    #   ------------------------------
    #
    test_get_input_output_paths()

# Generated at 2022-06-25 21:52:00.639883
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True


# Tests if function get_input_output_paths raises invalid input/output error if input is empty

# Generated at 2022-06-25 21:52:01.614281
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

test_case_0()

# Generated at 2022-06-25 21:52:10.989235
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.\\test_get_input_output_paths\\a\\b\\c\\c.py'
    str_1 = '.\\test_get_input_output_paths\\a\\b\\c'
    str_2 = '.\\test_get_input_output_paths\\a\\b\\c'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    assert len(var_0) == 1
    assert var_0[0].input_path.name == 'c.py'
    assert var_0[0].input_path.parent.name == 'c'
    assert var_0[0].output_path.name == 'c.py'

# Generated at 2022-06-25 21:52:11.440087
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True

# Generated at 2022-06-25 21:52:19.594744
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path(__file__).absolute().parent
    input_ = root / 'path_a' / 'file.py'
    output = root / 'path_b'
    assert len(list(get_input_output_paths(str(input_), str(output), str(root)))) == 1

    input_ = root / 'path_a'
    output = root / 'path_b'
    assert len(list(get_input_output_paths(str(input_), str(output), str(root)))) == 1

    input_ = str(root / 'path_a')
    output = str(root / 'path_b')
    assert len(list(get_input_output_paths(input_, output, str(root)))) == 1

    input_ = str(root / 'path_a')
    output = str