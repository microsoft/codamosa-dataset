

# Generated at 2022-06-25 21:46:00.484970
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for (input_, output, root) in [('test_input', 'test_output', None),
                                   ('tests/test_input', 'test_output', None),
                                   ('test_input', 'tests/test_output', None),
                                   ('tests/test_input', 'tests/test_output', None)]:
        for (child_input, child_output) in get_input_output_paths(input_, output, root):
            print('input:', child_input)
            print('output:', child_output)
            assert child_input.read_text('utf-8') == child_output.read_text('utf-8')

# Generated at 2022-06-25 21:46:01.207787
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True
 


# Generated at 2022-06-25 21:46:04.711843
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except AssertionError:
        print("Assertion error in get_input_output_paths at test_case_0")
    except Exception:
        print("Test case 0 failed.")

test_get_input_output_paths()

# Generated at 2022-06-25 21:46:14.687303
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = './examples'
    str_1 = './examples'
    str_2 = './examples'
    input_0 = str_0
    input_1 = str_1
    input_2 = str_2
    output_0 = str_0
    output_1 = str_1
    output_2 = str_2
    iterable_0 = get_input_output_paths(input_0, output_0, input_2)
    iterable_1 = get_input_output_paths(input_1, output_1, input_2)
    for input_output_0 in iterable_0:
        assert (input_output_0.input.name == input_output_0.output.name)

# Generated at 2022-06-25 21:46:21.647752
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    try:
        get_input_output_paths(str_0, str_0, str_0)
        assert False
    except InputDoesntExists:
        pass
    except AssertionError:
        raise AssertionError()
    except:
        pass
    str_1 = 'exc.py'
    iterable_0 = get_input_output_paths(str_1, str_1, str_1)
    str_2 = 'tree'
    str_3 = 'output'
    iterable_1 = get_input_output_paths(str_2, str_3, str_3)
    str_4 = 'tree.py'
    iterable_2 = get_input_output_paths(str_4, str_3, str_3)


# Generated at 2022-06-25 21:46:27.347076
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    str_1 = 'pyc'
    str_2 = 'src'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    isinstance(iterable_0, Iterable)
    assert not iterable_0 is None


if __name__ == '__main__':
    __main__.main()

# Generated at 2022-06-25 21:46:37.683365
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    str_1 = 'src'
    str_2 = 'tests'
    str_3 = '.py'
    str_4 = 'exc.py'
    str_5 = 'src.py'
    str_6 = 'tests.py'
    str_7 = 'example'
    str_8 = 'example.py'
    str_9 = 'example.py'
    str_10 = 'example.py'
    str_11 = 'example.py'
    str_12 = ''
    path_0 = Path(str_4)
    path_1 = Path(str_7)
    path_2 = Path(str_8)
    path_3 = Path(str_9)
    path_4 = Path(str_10)

# Generated at 2022-06-25 21:46:41.909732
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'test'
    str_1 = '/home/dir'
    str_2 = '/home/dir/test/test'
    str_3 = 'test/test'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    iterable_1 = get_input_output_paths(str_3, str_1, str_2)
    assert len(iterable_0) == len(iterable_1)
    assert iterable_0 != iterable_1

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:46:46.468821
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    str_0 = 'exc'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    print(iterable_0)
    list_0 = list(iterable_0)
    assert isinstance(list_0, list)

# Generated at 2022-06-25 21:46:55.770386
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    str_1 = 'exc'
    str_2 = 'exc'
    iterable_1 = get_input_output_paths(str_1, str_2, str_2)
    str_3 = 'exc'
    str_4 = 'exc'
    iterable_2 = get_input_output_paths(str_3, str_4, str_4)

test_case_0()
test_get_input_output_paths()

# Generated at 2022-06-25 21:47:01.835991
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('exc', 'exc', 'exc') == get_input_output_paths('exc', 'exc', 'exc')

# Generated at 2022-06-25 21:47:02.333256
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True

# Generated at 2022-06-25 21:47:05.478251
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    var_0 = Path('exc').joinpath('input')
    var_1 = get_input_output_paths('exc', 'exc', 'exc')
    var_2 = list(var_1)
    var_3 = str(var_2[0].input)
    var_4 = Path('exc').joinpath('output').joinpath('input.py')
    var_5 = str(var_2[0].output)
    assert (var_0 == var_3 and  var_4 == var_5)

# Generated at 2022-06-25 21:47:19.005703
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Call function get_input_output_paths with arguments: str_0, str_0, str_0
    assert callable(get_input_output_paths)

    # Call function get_input_output_paths with arguments: str_1, str_1, str_1
    assert callable(get_input_output_paths)

    # Call function get_input_output_paths with arguments: str_0, str_1, str_1
    assert callable(get_input_output_paths)

    # Call function get_input_output_paths with arguments: str_1, str_0, str_1
    assert callable(get_input_output_paths)

    # Call function get_input_output_paths with arguments: str_1, str_1, str_0
    assert callable

# Generated at 2022-06-25 21:47:27.850846
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    str_1 = None
    # Type case coverage
    try:
        iterable_0 = get_input_output_paths(str_0, str_0, str_1)
        var_0 = list(iterable_0)
    except InputDoesntExists:
        pass
    # Type case coverage
    try:
        iterable_1 = get_input_output_paths(str_0, str_0, str_0)
        var_1 = list(iterable_1)
    except InvalidInputOutput:
        pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 21:47:33.700772
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = ''
    output = ''
    root = ''
    expected_output = []
    actual_output = list(get_input_output_paths(input_, output, root))
    assert actual_output == expected_output
    input_ = 'exc'
    output = 'exc'
    root = 'exc'
    expected_output = [InputOutput(Path('exc'), Path('exc'))]
    actual_output = list(get_input_output_paths(input_, output, root))
    assert actual_output == expected_output
    input_ = 'exc.py'
    output = 'exc.py'
    root = 'exc'
    expected_output = [InputOutput(
        Path('exc.py'), Path('exc.py'))]

# Generated at 2022-06-25 21:47:35.063314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('', '', '') == 'assertion error'

# Generated at 2022-06-25 21:47:36.907317
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:47:45.491374
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    Path('foo').touch()
    Path('bar/baz.py').touch()
    Path('bar/qux').mkdir()
    Path('bar/qux/quux.py').touch()
    Path('bar/qux/quuux').mkdir()
    Path('bar/qux/quuux/corge.py').touch()
    Path('bar/qux/quuux/corge.py').touch()
    Path('bar/qux/quuux/grault').mkdir()
    Path('bar/qux/quuux/grault/garply.py').touch()
    Path('bar/qux/quuux/grault/garply.py').touch()

    assert list(get_input_output_paths('foo', 'bar', 'bar'))

# Generated at 2022-06-25 21:47:48.982982
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input_.endswith('.py')
    assert var_0[0].output_.endswith('.py')



# Generated at 2022-06-25 21:48:01.188375
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1: input/output ends with '.py' and root not None
    expected_1 = list(get_input_output_paths('./example/file.py', './dest', './example'))
    actual_1 = [InputOutput(Path('./example/file.py'), Path('./dest/file.py'))]
    assert expected_1 == actual_1

    # Case 2: input is a folder, root not None
    expected_2 = list(get_input_output_paths('./example', './dest', './example'))

# Generated at 2022-06-25 21:48:06.390348
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'path/to/input'
    output = 'path/to/output/'
    root = 'path/to/'
    iterable = get_input_output_paths(input_, output, root)
    var = list(iterable)
    assert len(var) == 1
    assert var[0].input == Path('path/to/input')
    assert var[0].output == Path('path/to/output/input')
    return

# Generated at 2022-06-25 21:48:08.198761
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('exc', 'exc', 'exc'))) == 1



# Generated at 2022-06-25 21:48:10.593720
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test cases
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 21:48:19.926757
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        func_0 = get_input_output_paths('', '', '')
        next(func_0, None)
    except StopIteration:
        pass
    except Exception as e:
        print(e)
    else:
        raise Exception('<AssertionError>')

    try:
        func_0 = get_input_output_paths('foo', 'bar', 'baz')
        next(func_0, None)
    except StopIteration:
        pass
    except Exception as e:
        print(e)
    else:
        raise Exception('<AssertionError>')

    try:
        func_0 = get_input_output_paths(__file__, 'exc', '')
        next(func_0, None)
    except StopIteration:
        pass
   

# Generated at 2022-06-25 21:48:21.885411
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    var_0 = test_case_0()
    assert len(var_0) == 0
    # TODO: More test cases

# Generated at 2022-06-25 21:48:29.480748
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a = get_input_output_paths('exceptions', 'exceptions', 'exceptions')
    assert next(a) == InputOutput(Path('exceptions.py'), Path('exceptions.py'))
    # Test raise InvalidInputOutput
    try:
        get_input_output_paths('exceptions.py', 'exceptions', 'exceptions')
    except InvalidInputOutput:
        pass
    else:
        assert False, "InvalidInputOutput exception not raised"
    # Test raise InputDoesntExists
    try:
        get_input_output_paths('abc', 'abc', 'abc')
    except InputDoesntExists:
        pass
    else:
        assert False, "InputDoesntExists exception not raised"

# Generated at 2022-06-25 21:48:34.370946
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # input_type: String
    input_0 = 'exc'
    
    # output_type: String
    output_0 = 'exc'
    
    # root_type: String
    root_0 = 'exc'
    
    iterable_0 = get_input_output_paths(input_0, output_0, root_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:48:43.925291
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(
            'examples/example_0.txt',
            'output_example_0.py',
            'examples/example_0.txt'
        )
    
    with pytest.raises(InputDoesntExists):
        get_input_output_paths(
            'examples/example_0.py',
            'output_example_0.py',
            'examples/'
        )
    
    with pytest.raises(FileNotFoundError):
        get_input_output_paths(
            'examples/example_0.py',
            'output_example_0.py',
            'examples/example_0.py'
        )
    

# Generated at 2022-06-25 21:48:48.252732
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('', '', '')

    test_case_0()


if __name__ == '__main__':
    import pytest  # type: ignore

    pytest.main(['-s', '--tb=native', '--pyargs', 'libcst.testing.get_input_output_paths_test'])

# Generated at 2022-06-25 21:48:58.681756
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # get_input_output_paths
    assert get_input_output_paths(str, str, None)
    assert get_input_output_paths('a', 'b', None)
    assert get_input_output_paths('a', 'b', 'c')    
    assert get_input_output_paths('a', 'b', 'c')

# Generated at 2022-06-25 21:49:03.571101
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc', 'exc', 'exc'
    str_1 = 'exc', 'exc/exc.py'
    get_input_output_paths(*str_0)
    try:
        get_input_output_paths(*str_1)
    except InvalidInputOutput:
        pass
    try:
        get_input_output_paths('exc.py', 'exc', 'exc')
    except InputDoesntExists:
        pass

# Generated at 2022-06-25 21:49:04.028776
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True == True

# Generated at 2022-06-25 21:49:12.505986
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    assert list(get_input_output_paths('exc', 'exc', 'exc')) == [InputOutput(Path('exc'), Path('exc'))]

    assert list(get_input_output_paths('exc', 'exc/exc', 'exc')) == [InputOutput(Path('exc'), Path('exc/exc'))]

    assert list(get_input_output_paths('exc/exc', 'exc', 'exc')) == [InputOutput(Path('exc/exc'), Path('exc'))]

    assert list(get_input_output_paths('exc/exc', 'exc/exc', 'exc')) == [InputOutput(Path('exc/exc'), Path('exc/exc'))]


# Generated at 2022-06-25 21:49:20.696330
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Testing get_input_output_paths...', end='')
    # This is just a dummy for coverage, so don't mind the inputs
    str_0 = 'exc'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0 == []
    assert callable(get_input_output_paths)
    test_case_0()
    print('Passed.')


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:29.067255
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_1 = 'exc'
    str_2 = 'content'
    iterable_1 = get_input_output_paths(str_1, str_2, str_2)
    var_1 = list(iterable_1)
    var_2 = list()
    var_2.append(InputOutput('content/exc/builtins.py', 'content/builtins.py'))
    var_2.append(InputOutput('content/exc/__exception_catalog.py', 'content/__exception_catalog.py'))
    var_2.append(InputOutput('content/exc/__init__.py', 'content/__init__.py'))

# Generated at 2022-06-25 21:49:45.570970
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'src'
    str_1 = 'lib'
    iterable_0 = get_input_output_paths(str_0, str_1, 'project')
    var_0 = list(iterable_0)
    var_1 = var_0[0]
    var_2 = var_1.inp_path
    assert var_2 == 'src'
    var_3 = var_1.out_path
    assert var_3 == 'lib'
    str_2 = 'src'
    str_3 = 'lib/exception.py'
    iterable_1 = get_input_output_paths(str_2, str_3, 'project')
    var_4 = list(iterable_1)
    var_5 = var_4[0]
    var_6 = var_

# Generated at 2022-06-25 21:49:49.047197
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('py', 'py', 'py'))) != 0
    assert len(list(get_input_output_paths('py', 'py', 'py'))) != 5
    assert len(list(get_input_output_paths('py', 'py', 'py'))) != 1

# Generated at 2022-06-25 21:49:50.751550
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:50:00.057230
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1
    str_0 = 'exc/exc.py'
    str_1 = 'test_dir/test_dir/test_dir'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    obj_0 = var_0[0]
    assert obj_0.input == Path('exc/exc.py') and obj_0.output == Path('exc/exc.py')

    # Case 2
    str_0 = 'exc/exc.py'
    str_1 = 'test_dir/test_dir/test_dir'
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:50:52.344592
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert len(var_0) == 2
    except AssertionError:
        raise AssertionError(var_0)

# Generated at 2022-06-25 21:50:54.230965
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert test_case_0()
    except:
        raise AssertionError('No exception was raised')

# Generated at 2022-06-25 21:50:58.171558
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    arg_0 = 'exc'
    arg_1 = 'exc'
    arg_2 = 'exc'
    expected_0 = None
    try:
        result_0 = get_input_output_paths(arg_0, arg_1, arg_2)
    except AssertionError:
        raise AssertionError("Function raises assertion_error")
    assert result_0 == expected_0


# Generated at 2022-06-25 21:51:03.405725
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'fixtures/examples'
    str_1 = 'tests/fixtures/examples'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    var_0 = list(iterable_0)
    assert len(var_0) == 4
    # len(var_0) == 4


# print(test_case_0())
# test_get_input_output_paths()

# Generated at 2022-06-25 21:51:04.835020
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:51:13.148859
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        test_case_0()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

    try:
        test_case_1()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

    try:
        test_case_2()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

    try:
        test_case_3()
    except InvalidInputOutput:
        pass
    except InputDoesntExists:
        pass

    try:
        test_case_4()
    except InvalidInputOutput:
        pass
    except:
        pass

    try:
        test_case_5()
    except InvalidInputOutput:
        assert False
    except:
        assert False


# Generated at 2022-06-25 21:51:16.311154
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0] == InputOutput(Path('exc'), Path('exc'))

# Generated at 2022-06-25 21:51:22.685356
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # mock the pathlib.Path.exists() method
    str_0 = 'exc'
    str_1 = 'exc'
    str_2 = 'exc'
    def test_exists(self):
        return False
    def test_endswith(self, suffix):
        return False
    def test_name(self):
        return 'exc'
    path_0 = Path(str_0)
    path_1 = Path(str_1)
    path_2 = Path(str_2)
    path_0.exists = types.MethodType(test_exists, path_0)
    path_1.exists = types.MethodType(test_exists, path_1)
    path_2.exists = types.MethodType(test_exists, path_2)
    path_0.endsw

# Generated at 2022-06-25 21:51:29.433261
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a/b', 'a.py')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('doesnt_exist.py', 'doesnt_exist.py')

    get_input_output_paths('a.py', 'a.py')
    get_input_output_paths('a.py', 'b.py')
    get_input_output_paths('a.py', 'b')
    get_input_output_paths('a', 'b')
    get_input_output_paths('a', 'b', 'a')

# Generated at 2022-06-25 21:51:38.763526
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # get_input_output_paths(input_: str, output: str,
    #                        root: Optional[str]) -> Iterable[InputOutput]
    assert list(get_input_output_paths('foo', 'bar', 'baz')) == [
        InputOutput(Path('foo'), Path('bar/foo'))
    ]
    assert get_input_output_paths('foo', 'foo', 'bar') == [
        InputOutput(Path('foo'), Path('foo'))
    ]
    assert get_input_output_paths('foo.py', 'bar', 'baz') == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))
    ]

# Generated at 2022-06-25 21:52:32.983983
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'exc'
    output_path_0 = Path('exc')
    input_path_0 = Path('exc')
    input_output_0 = InputOutput(input_path_0, output_path_0)
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    assert input_output_0 in iterable_0
    assert len(iterable_0) == 1
    str_1 = 'exc'
    str_2 = 'exc'
    output_path_1 = Path('exc')
    input_path_1 = Path('exc')
    input_output_1 = InputOutput(input_path_1, output_path_1)

# Generated at 2022-06-25 21:52:42.582343
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Testing for custom case #0
    str_0 = 'exc'
    assert get_input_output_paths(str_0, str_0, str_0) == ('exc', 'exc')

    # Testing for custom case #1
    str_1 = 'test'
    str_2 = 'test_1'
    assert get_input_output_paths(str_1, str_2, str_1) == ('test', 'test_1')

    # Testing for custom case #2
    str_3 = '__pycache__'
    str_4 = '__pycache__'
    assert get_input_output_paths(str_3, str_4, str_3) == ('__pycache__', '__pycache__')


# Generated at 2022-06-25 21:52:45.878667
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Function takes an input and output path as an argument. The function is
    supposed to return the input and output path.
    """
    str_0 = 'exc'
    # output_0 = ['exc']
    # assert list(get_input_output_paths(str_0, str_0, str_0)) == output_0

# Generated at 2022-06-25 21:52:48.760661
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('a', 'b', 'c')
    except InputDoesntExists:
        pass
    try:
        get_input_output_paths('a', 'a.py', 'c')
    except InvalidInputOutput:
        pass
    else:
        assert False

# Generated at 2022-06-25 21:52:49.372760
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True # TODO: implement your test here

# Generated at 2022-06-25 21:52:54.369627
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths("input", "output", "root") == [("input", "output")]
    assert get_input_output_paths("input.py", "output.py", "root") == [("input.py", "output.py")]
    assert get_input_output_paths("input.py", "output", "root") == [("input.py", "output")]

# Generated at 2022-06-25 21:53:02.268872
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Make sure that input is of type str
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(2, 2, 2)
    # Assert that the type of the output is an iterable type
    assert isinstance(get_input_output_paths(".", ".", "."),Iterable)
    # Assert that the type of the second parameter is of type str
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(str, 2, ".")
    # Assert that the input file ends with a py extension
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("./flickrapi.py", "./flickrapi.py", "./flickrapi.py")
    # Assert that

# Generated at 2022-06-25 21:53:06.478947
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "examples/path/to"
    output = "examples/path/to/output"
    root = "examples"
    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)
    assert var_0 == [InputOutput(Path('examples/path/to/a.py'), Path('examples/path/to/output/a.py')), InputOutput(Path('examples/path/to/b.py'), Path('examples/path/to/output/b.py'))]

# Generated at 2022-06-25 21:53:15.542804
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    def assert_input_output(input_, output, expected):
        input_path = Path(input_)
        output_path = Path(output)
        str_0 = input_path.parent
        iterable_0 = get_input_output_paths(input_, output, str_0)
        var_0 = list(iterable_0)
        assert var_0 == expected

    assert_input_output(
        'test/test_input.py',
        'test/test_output.py',
        [
            InputOutput(Path('test/test_input.py'), Path('test/test_output.py'))
        ],
    )


# Generated at 2022-06-25 21:53:18.551273
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output_path = Path.cwd().joinpath('output')
    for input_output in get_input_output_paths('exc', output_path, None):
        paths = (input_output.input, input_output.output)
        assert paths == (Path('exc/basic.py'), Path('output/basic.py'))