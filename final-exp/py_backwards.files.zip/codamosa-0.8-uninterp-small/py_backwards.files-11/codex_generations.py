

# Generated at 2022-06-25 21:46:00.857817
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Assert: AssertionError
    try:
        str_0 = 'v,Kr#'
        get_input_output_paths(str_0, str_0, str_0)
    except AssertionError:
        print('AssertionError raised as expected')
    else:
        assert False, 'AssertionError not raised as expected'
    # Assert: Exception
    try:
        str_0 = 'P,oYM'
        get_input_output_paths(str_0, str_0, str_0)
    except Exception:
        print('Exception raised as expected')
    else:
        assert False, 'Exception not raised as expected'
    # Assert: TypeError

# Generated at 2022-06-25 21:46:03.560136
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'kIp$])'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)



# Generated at 2022-06-25 21:46:13.719457
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'kIp$])'
    str_1 = 'X9y`'
    try:
        get_input_output_paths(str_0, str_1, str_1)
        assert False
    except InvalidInputOutput:
        assert True

    str_2 = 'O*eA'
    try:
        get_input_output_paths(str_2, str_1, str_0)
        assert False
    except InputDoesntExists:
        assert True

    # Call the function again to make sure it's reentrant
    str_3 = 'fR,o'
    try:
        get_input_output_paths(str_2, str_1, str_0)
        assert False
    except InputDoesntExists:
        assert True


# Generated at 2022-06-25 21:46:14.151347
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()



# Generated at 2022-06-25 21:46:21.060801
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:32.534654
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path1 = Path(r"C:\Program Files\TortoiseHg\libs\sphinx-2.0.1-py3.8.egg\sphinx\__init__.py")
    path2 = Path(r"C:\Program Files\TortoiseHg\libs\sphinx-2.0.1-py3.8.egg\sphinx\__init__.py")
    it_0 = get_input_output_paths(str(path1), str(path2), str(path1))
    for input_output in it_0:
        assert input_output.input_ == path1
        assert input_output.output == path2
    it_0 = get_input_output_paths(str(path1), str(path1), str(path1))

# Generated at 2022-06-25 21:46:37.561527
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = '/tmp/0/'
    input_path = '/tmp/0/1.py'
    output_path = '/tmp/1'
    result  = get_input_output_paths(input_path, output_path, root)
    assert result[0].input_path == Path('/tmp/0/1.py')
    assert result[0].output_path == Path('/tmp/1/1.py')

# Generated at 2022-06-25 21:46:43.653924
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    try:
        from tempfile import TemporaryDirectory
    except ImportError:
        from backports.tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmpdirname:
        p = Path(tmpdirname)
        input_path = p.joinpath('input.py')
        input_path.write_text('')
        output_path = p.joinpath('output.py')
        output_path.write_text('')
        res = list(get_input_output_paths(str(input_path), str(output_path), None))
        assert res == [InputOutput(input_path, output_path)]


# Generated at 2022-06-25 21:46:47.099483
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    input_ = "tests/test_data/test_0/"
    output = "tests/test_data/test_0/"
    root_ = "tests/test_data/"
    result = get_input_output_paths(input_, output, root_)

    assert result is not None

# Generated at 2022-06-25 21:46:58.969313
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'rO[}&xF3qo=H0'
    str_1 = '(jK!V&WY>M9Pd'
    str_2 = 'fWG?$E7}ZNW'
    str_3 = 'jK!V&WY>M9Pd'
    str_4 = 'wZ>mI{`p3qM'
    str_5 = 'K~&R)Q2aN'
    input_output_paths_0 = get_input_output_paths(str_2, str_0, str_1)
    input_output_paths_1 = get_input_output_paths(str_1, str_1, str_2)

# Generated at 2022-06-25 21:47:11.177643
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:47:20.552935
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths(Path(__file__).parent / 'test_dir' / 'pyproject.toml', Path(__file__).parent / 'out_dir', None)
    except FileNotFoundError as e:
        print(e)
    output_path = Path(__file__).parent / 'out_dir'
    input_path = Path(__file__).parent / 'test_dir' / 'pyproject.toml'
    for child_input in input_path.glob('**/*.py'):
        child_output = output_path.joinpath(child_input.relative_to(input_path))
        yield InputOutput(child_input, child_output)

# Generated at 2022-06-25 21:47:24.378585
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "input/"
    output = "output/"
    root = None
    result = get_input_output_paths(input_, output, root)

    assert(input_.endswith('.py') == result.input_.endswith('.py'))
    
    

# Generated at 2022-06-25 21:47:32.122012
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1
    str_1 = 'C:\\Users\\draco\\Documents\\CS\\Spring 2020\\CS4141\\Git Repos\\pyclean\\tests\\test_input.py'
    str_2 = 'C:\\Users\\draco\\Documents\\CS\\Spring 2020\\CS4141\\Git Repos\\pyclean\\tests\\output'
    lst_1 = [InputOutput(Path(str_1),
        Path(str_2).joinpath(Path(str_1).name))]
    assert(list(get_input_output_paths(str_1, str_2, None)) == lst_1)
    # Test case 2
    str_3 = 'C:\\Users\\draco\\Documents\\CS\\Spring 2020\\CS4141\\Git Repos\\pyclean\\tests\\output'
   

# Generated at 2022-06-25 21:47:41.017249
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py', 
                                   'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py.out', 
                                   None))[0].input == ('C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py')

# Generated at 2022-06-25 21:47:49.018745
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:47:57.405955
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1
    input_1 = "C:\\Git\\TortoiseHg\\tests\\test-pychecker.py"
    output_1 = "C:\\Git\\TortoiseHg\\test-pychecker.py"
    result_1 = get_input_output_paths(input_1, output_1, None)
    input_1_path = []
    output_1_path = []
    for item in result_1:
        input_1_path.append(item.input_path)
        output_1_path.append(item.output_path)
    assert input_1_path == [Path("C:\\Git\\TortoiseHg\\tests\\test-pychecker.py")]

# Generated at 2022-06-25 21:48:05.424937
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_input = "C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx"
    str_output = "C:\\Users\\qiyen\\Desktop\\sphinx_output"
    input_output_paths = get_input_output_paths(str_input, str_output, None)
    for input_output in input_output_paths:
        print(input_output)

#    for input_output in input_output_paths:
#        print(input_output.input_path)
#        print(input_output.output_path)



# Generated at 2022-06-25 21:48:14.342593
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    expected = [InputOutput(Path('C:/Program Files/TortoiseHg/libs/sphinx-2.0.1-py3.8.egg/sphinx/__init__.py'),
                            Path('C:/Program Files/TortoiseHg/libs/sphinx-2.0.1-py3.8.egg/sphinx/__init__.py'))]
    result = list(get_input_output_paths('C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py', 'C:/Program Files/TortoiseHg/libs/sphinx-2.0.1-py3.8.egg/sphinx/__init__.py', None))

# Generated at 2022-06-25 21:48:23.240762
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 0
    input_0 = "sphinx"
    output_0 = "obfuscated"
    root_0 = None
    expected_0 = [InputOutput(Path("sphinx/__init__.py"), Path("obfuscated/__init__.py"))]
    assert list(get_input_output_paths(input_0, output_0, root_0)) == expected_0

    # Test case 1
    input_1 = "sphinx/__init__.py"
    output_1 = "obfuscated/__init__.py"
    root_1 = None
    expected_1 = [InputOutput(Path("sphinx/__init__.py"), Path("obfuscated/__init__.py"))]

# Generated at 2022-06-25 21:48:34.756571
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_1 = 'C:\\Users\\Ishan\\Desktop\\py-dataclass-tortoisehg-2\\sphinx\\__init__.py'
    
    result = get_input_output_paths(str_0,str_1,None)

# Generated at 2022-06-25 21:48:37.267880
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for case in test_cases:
        try:
            get_input_output_paths(case[0], case[1], case[2])
            assert True
        except:
            assert False


# Generated at 2022-06-25 21:48:45.964129
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pyfakefs.fake_filesystem_unittest import TestCase
    from pyfakefs.fake_pathlib import FakePath
    from types import SimpleNamespace

    tests = SimpleNamespace(**{
        'input_output': {
            'input': 'myinput',
            'output': 'myoutput',
            'root': 'myroot'
        },
        'one_input': {
            'input': 'myinput/input.py',
            'output': 'myoutput/output.py'
        },
        'many_input': {
            'input': 'myinput',
            'output': 'myoutput'
        }
    })

    class TestGetInputOutput(TestCase):
        def setUp(self):
            self.setUpPyfakefs()


# Generated at 2022-06-25 21:48:55.990506
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_1 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init___debug.py'
    t = get_input_output_paths(str_0, str_1, None)
    assert str(t.__next__().input_path) == str_0
    assert str(t.__next__().output_path) == str_1
    try:
        t.__next__()
    except StopIteration:
        assert True
    else:
        assert False

# Generated at 2022-06-25 21:49:04.554268
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('.\\tests\\test_input', '.\\tests\\test_input', None)
    except InputDoesntExists:
        pass
    get_input_output_paths('.\\tests\\test_input\\__init__.py', '.\\tests\\test_output\\__init__.py', None)
    get_input_output_paths('.\\tests\\test_input\\__init__.py', '.\\tests\\test_input', None)
    get_input_output_paths('.\\tests\\test_input', '.\\tests\\test_output\\__init__.py', None)
    get_input_output_paths('.\\tests\\test_input', '.\\tests\\test_output', None)

# Generated at 2022-06-25 21:49:06.280905
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    print("pass")

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:49:16.634768
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_1 = 'C:\\Program Files\\TortoiseHg\\install\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'

    # Test for case 0

# Generated at 2022-06-25 21:49:19.259702
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('sphinx', 'sphinx/__init__.py',None)) == [InputOutput(Path('sphinx'),Path('sphinx/__init__.py'))]


# Generated at 2022-06-25 21:49:27.997648
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('test.py', 'out', None) == (
        InputOutput(Path('test.py'), Path('out/test.py')),)
    assert get_input_output_paths('test.py', 'out.py', None) == (
        InputOutput(Path('test.py'), Path('out.py')),)
    assert get_input_output_paths('test', 'out', None) == (
        InputOutput(Path('test/test.py'), Path('out/test.py')),
        InputOutput(Path('test/test2.py'), Path('out/test2.py')))
    assert get_input_output_paths('test', 'out.py', None) == ()


# Generated at 2022-06-25 21:49:33.398728
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Path.joinpath()
    input_0 = 'C:\\Users\\thang\\Desktop\\Python_3\\Input'
    input_1 = 'C:\\Users\\thang\\Desktop\\Python_3\\Input\\abst_class.py'
    input_2 = 'C:\\Users\\thang\\Desktop\\Python_3\\Input\\abst_class_test.py'
    output_0 = 'C:\\Users\\thang\\Desktop\\Python_3\\Output'

    data_0 = get_input_output_paths(input_0, output_0, None)
    assert data_0[0].input.name == 'abst_class.py'
    assert data_0[1].input.name == 'abst_class_test.py'

# Generated at 2022-06-25 21:50:08.663507
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('test function get_input_output_paths')
    input_ = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    output = 'C:\\Program Files\\PyScripter\\pyscripter-test\\test-env\\Lib\\site-packages\\sphinx'
    it = get_input_output_paths(input_, output, None)
    input_output = next(it)
    assert(input_output.input == Path(input_))
    assert(input_output.output == Path(output).joinpath(Path(input_).name))


# Generated at 2022-06-25 21:50:11.708693
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = "C:\\Users\\lizhiyuan\\work\\py2to3\\example.py"
    str_1 = "C:\\Users\\lizhiyuan\\work\\py2to3"
    assert get_input_output_paths(str_0,str_1,None) == str_0


# Generated at 2022-06-25 21:50:18.943766
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('.\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py', '.\\build\\pyi.test\\thg\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py', root='.\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py')
    #assert get_input_output_paths('.\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py', '.\\build\\pyi.test\\thg\\TortoiseHg\\libs\\sphinx-2.0.

# Generated at 2022-06-25 21:50:25.496797
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print("test function get_input_output_paths")
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_1 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'
    ret_0 = get_input_output_paths(str_0, str_1, None)
    print(ret_0)

# Unit test entry function

# Generated at 2022-06-25 21:50:33.527023
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .utils import get_input_output_paths
    from .checkers import check
    from pathlib import Path
    # https://github.com/nomad-software/flake8-bugbear
    # str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_0 = 'C:/Program Files/TortoiseHg/libs/sphinx-2.0.1-py3.8.egg/sphinx/__init__.py'

# Generated at 2022-06-25 21:50:41.938024
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Start test test_get_input_output_paths')

    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_1 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    str_2 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'

# Generated at 2022-06-25 21:50:45.266608
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    ret_val = get_input_output_paths(str_0, str_0, None)
    assert ret_val is not None

    # Unit test for function get_input_output_paths with assertion failure

# Generated at 2022-06-25 21:50:50.453309
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'
    str_1 = 'C:\\Temp\\test_output'
    root = None
    assert get_input_output_paths(str_0, str_1, root) != None



# Generated at 2022-06-25 21:50:58.171869
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:51:01.066071
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (("test_case_0",), {"input_": "test_case_0", "output": "test_case_0"})
    test_case_0()

# Generated at 2022-06-25 21:51:40.362796
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'
    output = 'C:\\Program Files\\TortoiseHg\\libs\\teste.py'
    root = 'C:\\Program Files\\TortoiseHg\\libs\\'
    for input, output in get_input_output_paths(input_, output, root):
        print("input")
        print(input)
        print("output")
        print(output)

# Generated at 2022-06-25 21:51:47.961495
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_, output, root = 'tests/data/fixtures/test_input', 'tests/data/fixtures/test_output', None
    result_list = list(get_input_output_paths(input_, output, root))
    # Check number of pairs
    assert len(result_list) == 6
    # Check pairs
    assert result_list[0] == InputOutput(Path('tests/data/fixtures/test_input/__init__.py'), Path('tests/data/fixtures/test_output/__init__.py'))
    assert result_list[1] == InputOutput(Path('tests/data/fixtures/test_input/settings.py'), Path('tests/data/fixtures/test_output/settings.py'))

# Generated at 2022-06-25 21:51:55.058904
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\'
    output = 'D:\\sphinx\\sphinx-2.0.1-py3.8.egg\\sphinx\\'
    root = None
    path_list = list()

    for path_pair in get_input_output_paths(input_, output, root):
        path_list.append(path_pair)

    assert path_list[-1].input_path == 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\search\\__init__.py'

# Generated at 2022-06-25 21:52:01.579597
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print('Testing: get_input_output_paths()')
    # Test cases

# Generated at 2022-06-25 21:52:10.958893
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Test 1: check get_input_output_paths("C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py", "C:\\Users\\Zhe\\Desktop\\sphinx\\__init__.py", "C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx")
    assert True

# Generated at 2022-06-25 21:52:18.583194
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    temp_file = 'test_files\\temp_files\\test_get_input_output_paths.py'
    input_0 = 'test_files\\test_cases\\test_case_0'
    output_0 = 'test_files\\test_cases\\test_case_0'
    root_0 = 'test_files\\test_cases'
    file_0 = open(temp_file, "w")
    assert get_input_output_paths(input_0, output_0, root_0) == [(path(input_0), path(output_0))]
    file_0.close()
    os.remove(temp_file)
    print('test_get_input_output_paths done!')


# Generated at 2022-06-25 21:52:26.993871
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    output_0 = '__init__.py'
    root_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'
    inputs_0 = get_input_output_paths(input_0, output_0, root_0)
    input_1 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx'
    output_1 = 'src'
    root_1 = None
    inputs_1 = get_input

# Generated at 2022-06-25 21:52:34.162353
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result0 = get_input_output_paths('C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg', 'E:\\tortoisehg\\Documentation\\Source', None)
    result1 = get_input_output_paths('E:\\tortoisehg\\Documentation\\Source', 'E:\\tortoisehg\\Documentation\\Source', None)
    result2 = get_input_output_paths('E:\\tortoisehg\\Documentation\\Source', 'E:\\tortoisehg\\Documentation\\Source\\__init__.py', '')

# Generated at 2022-06-25 21:52:40.701699
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Call function
    test_case_0()
    # Preliminary checks
    assert os.path.exists(str_0)
    # Call function
    get_input_output_paths(
        input_=str_0,
        output='C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\new_path_out',
        root=None
    )

# Generated at 2022-06-25 21:52:43.581846
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for str_0 in test_case_0():
        print(str_0)
        print(get_input_output_paths(str_0))

if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:53:19.723920
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()


# Generated at 2022-06-25 21:53:30.261247
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    arg_0 = "C:\\Users\\pengl\\OneDrive\\Desktop\\pycddl-1.0.1\\doc\\sphinx\\sphinx\\__init__.py"
    arg_1 = "C:\\Users\\pengl\\OneDrive\\Desktop\\pycddl-1.0.1\\doc\\sphinx\\sphinx\\__init__.py"
    arg_2 = "C:\\Users\\pengl\\OneDrive\\Desktop\\pycddl-1.0.1\\doc\\sphinx\\sphinx"
    obj_0 = get_input_output_paths(arg_0, arg_1, arg_2)

# Generated at 2022-06-25 21:53:36.434091
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_input = '.'
    path_output = '.'
    root = '.'

# Generated at 2022-06-25 21:53:42.293246
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths('__init__.py', '__init___editor.py', None)) == InputOutput(Path('__init__.py'), Path('__init___editor.py'))

# Generated at 2022-06-25 21:53:43.329896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert False
    except:
        pass
    else:
        assert True



# Generated at 2022-06-25 21:53:43.928346
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() is None

# Generated at 2022-06-25 21:53:47.231463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = 'C:\\Users\\User\\PycharmProjects\\pyautograd\\.travis.yml'
    str_1 = 'C:\\Users\\User\\PycharmProjects\\pyautograd\\tests\\test_grad\\.travis.yml'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    var_0 = list(iterable_0)

    # Check if iterable_0 is a list
    assert isinstance(iterable_0, list), "Argument is not a list: %r" % iterable_0

    # Check if iterable_0 size is 1
    assert len(iterable_0) == 1, "The list size is not 1: %r" % iterable_0


# Generated at 2022-06-25 21:53:47.943138
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:53:49.732667
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case #0
    try:
        test_case_0()
    except Exception:
        print('Exception raised by test #0')
        raise

# Prevent unittests from executing if this module is imported directly
if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:53:55.715345
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 0
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0] == InputOutput(Path(str_0), Path(str_0))
    
    # Test case 1
    str_0 = 'C:\\Program Files\\TortoiseHg\\libs\\sphinx-2.0.1-py3.8.egg\\sphinx\\__init__.py'