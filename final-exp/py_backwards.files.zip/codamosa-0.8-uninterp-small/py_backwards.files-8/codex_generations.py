

# Generated at 2022-06-25 21:46:01.054561
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = "`zf\x7f@G]xHr':Ek\n|y"
    str_1 = "I_9bq\x7f\x0cjm^\x7f|\n0yV"
    str_2 = "9X\\\x7fHGP\x7fN\x0b|\x7f\x0b"
    str_3 = "p\x7f|\x7f\x0bh\n`\x7f@\x7f\x7f"
    str_4 = "I\x7f\x7f|\x7f\x0b\x7fk\x7f\x7f"

# Generated at 2022-06-25 21:46:07.425572
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = "mo5@`<'l6\x0c\\kFESP:r"
    str_1 = "mo5@`<'l6\x0c\\kFESP:r"
    str_2 = "mo5@`<'l6\x0c\\kFESP:r"
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)



# Generated at 2022-06-25 21:46:16.493868
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Unit test for function get_input_output_paths
    # Assert that the output is Iterable of InputOutput
    # Assert type of each element of Iterable is InputOutput
    assert type(get_input_output_paths(str, str,str)) == 'generator', "'get_input_output_paths' function should return Iterable of InputOutput"
    assert type(next(get_input_output_paths(str, str, str))) == 'InputOutput', "'get_input_output_paths' function should return Iterable of InputOutput"
    # Calling the function with wrong parameters should raise InvalidInputOutput
    # Calling the function with wrong parameters should raise InputDoesntExists
    try:
        assert get_input_output_paths(str,str,str) 
    except InvalidInputOutput:
        assert 1 


# Generated at 2022-06-25 21:46:24.514017
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('.', '..', None))) > 0
    assert list(get_input_output_paths('.', '..', '.')) == list(
        get_input_output_paths('.', '..', None))
    assert list(get_input_output_paths('.', '..', '..')) == list(
        get_input_output_paths('.', '..', None))
    assert len(list(get_input_output_paths('.', 'result', None))) > 0
    assert len(list(get_input_output_paths('.', 'result2', '.'))) > 0
    assert len(list(get_input_output_paths('.', 'result2', None))) > 0

# Generated at 2022-06-25 21:46:35.025367
# Unit test for function get_input_output_paths

# Generated at 2022-06-25 21:46:35.847141
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert True


# Generated at 2022-06-25 21:46:36.960868
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)

# Generated at 2022-06-25 21:46:41.729939
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a/b/c.py', 'd/', 'a/b/c.py') == [(Path('a/b/c.py'), Path('d/c.py'))]
    assert get_input_output_paths('a/b/c.py', 'd/e.py', 'a/b/c.py') == [(Path('a/b/c.py'), Path('d/e.py'))]
    assert get_input_output_paths('a/b/c.py', 'd/', 'a/b/') == [(Path('a/b/c.py'), Path('d/c.py'))]

# Generated at 2022-06-25 21:46:54.054830
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert deep_iter_eq(
        list(get_input_output_paths('foo.py', 'bar.py', None)),
        [InputOutput(Path('foo.py'), Path('bar.py'))]
    )
    assert deep_iter_eq(
        list(get_input_output_paths('.', 'bar.py', None)),
        [InputOutput(Path('./foo.py'), Path('bar.py/foo.py'))]
    )
    assert deep_iter_eq(
        list(get_input_output_paths('.', 'bar', None)),
        [InputOutput(Path('./foo.py'), Path('bar/foo.py'))]
    )

# Generated at 2022-06-25 21:46:57.020431
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    str_0 = "mo5@`<'l6\x0c\\kFESP:r"
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)

# Generated at 2022-06-25 21:47:14.689979
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert test_case_0() == None

if __name__ == '__main__':
    test_case_0()
    test_get_input_output_paths()

# Generated at 2022-06-25 21:47:22.681492
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    Path_0 = Path
    Path_1 = Path
    Path_2 = Path
    Path_3 = Path
    Path_4 = Path
    Path_5 = Path
    Path_6 = Path
    Path_7 = Path
    Path_8 = Path
    Path_9 = Path
    Path_10 = Path
    Path_11 = Path
    Path_12 = Path
    Path_13 = Path
    Path_14 = Path
    Path_15 = Path
    Path_16 = Path
    Path_17 = Path
    Path_18 = Path
    Path_19 = Path
    Path_20 = Path
    Path_

# Generated at 2022-06-25 21:47:31.173257
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input0 = "/home/user/in"
    output0 = "/home/user/out"
    root0 = "/home/user"
    expected_output0 = [InputOutput(Path('/home/user/in/foo.py'), Path('/home/user/out/foo.py'))]
    actual_output0 = get_input_output_paths(input0, output0, root0)
    assert expected_output0 == actual_output0

    input1 = "/home/user/in"
    output1 = "/home/user/out/foo.py"
    root1 = "/home/user"
    expected_output1 = [InputOutput(Path('/home/user/in/foo.py'), Path('/home/user/out/foo.py'))]
    actual_output1 = get_input_output_

# Generated at 2022-06-25 21:47:33.669784
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:47:34.680547
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:47:43.468880
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from hypothesis import given
    from hypothesis.strategies import text
    import os.path

    @given(text(), text(), text())
    def test_cases(input, output, root):
        # if both input and output are directory then we check if this program
        # is able to convert all files in the directory recursively.
        if os.path.isdir(input) and os.path.isdir(output):
            # to avoid interference with data of other tests, we create
            # subdirectories inside the given directories.
            # Note that: the conversion is happening inside the temporary
            # directories, so we remove it after the conversion.
            tmp = '/tmp/py2py_hypothesis_test'

# Generated at 2022-06-25 21:47:44.291070
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()



# Generated at 2022-06-25 21:47:51.916671
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

    # AssertionError
    str_1 = '.'
    str_2 = '.'
    str_3 = '.'
    iterable_1 = get_input_output_paths(str_1, str_2, str_3)
    var_1 = tuple(iterable_1)

    # AssertionError
    str_4 = '.'
    str_5 = '.'
    str_6 = '.'
    iterable_2 = get_input_output_paths(str_4, str_5, str_6)
    var_2 = tuple(iterable_2)

    # AssertionError

# Generated at 2022-06-25 21:47:57.597230
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'tests/data/case_0/'
    output = 'tests/data/case_0_output/'
    root = 'tests/data/case_0/'
    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)

    assert len(var_0) == 1
    assert var_0[0] == InputOutput(Path(input_ + 'test_0.py'), Path(output + 'test_0.py'))

# Generated at 2022-06-25 21:47:59.816424
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    x = get_input_output_paths('str1', 'str2', 'str2')
    assert x is not None

# Generated at 2022-06-25 21:48:13.184263
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert hasattr(get_input_output_paths, '__call__')
    assert get_input_output_paths.__annotations__ == {
        'input_': str,
        'output': str,
        'root': Optional[str],
        'return': Iterable[InputOutput]
    }

# Generated at 2022-06-25 21:48:22.339137
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = os.path.dirname(__file__)
    str_0 = os.path.join(path, 'test_data/test_0')
    str_1 = os.path.join(path, 'test_data/test_1/')
    str_2 = os.path.join(path, 'test_data/test_2/')
    iterable_0 = get_input_output_paths(str_0, str_1, str_1)
    var_0 = list(iterable_0)
    str_3 = os.path.join(path, 'test_data/test_2/test_2.py')
    str_4 = os.path.join(path, 'test_data/test_3/')

# Generated at 2022-06-25 21:48:24.569174
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    str_1 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, None)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:48:32.387731
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)

    with pytest.raises(InvalidInputOutput):
        str_0 = 'templates/main.html'
        str_1 = 'templates/main.py'
        get_input_output_paths(str_0, str_1, str_0)

    with pytest.raises(InputDoesntExists):
        str_0 = 'stub'
        str_1 = '.'
        get_input_output_paths(str_0, str_1, str_0)

    str_0 = 'templates'
    str_1 = '.'

# Generated at 2022-06-25 21:48:34.169458
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:48:43.749495
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

# Generated at 2022-06-25 21:48:45.230930
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = ""
    output = ""
    root = ""
    get_input_output_paths(input_, output, root)


# Generated at 2022-06-25 21:48:55.310153
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(TypeError) as excinfo:
        get_input_output_paths(None, None)
    assert 'expected one argument' in str(excinfo.value)

    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0)
    var_0 = list(iterable_0)
    var_1 = var_0[0]
    var_2 = str(var_1.input)
    var_2 = var_2.endswith('.py')
    var_3 = str(var_1.output)
    var_3 = var_3.endswith('.py')
    var_4 = var_2
    var_4 = var_4 and var_3

# Generated at 2022-06-25 21:48:59.051749
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest   # type: ignore
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('input.py', 'output.txt')
    with pytest.raises(InputDoesntExists):
        assert get_input_o

# Generated at 2022-06-25 21:49:01.254177
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert str(list(get_input_output_paths(None, None, None))[0][0]) == './test_input/demo.py'


# Generated at 2022-06-25 21:49:23.563373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:49:28.215268
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    case_0_0 = 'dummy_value_0'
    case_0_1 = 'dummy_value_1'
    case_0_2 = 'dummy_value_2'
    var_0 = get_input_output_paths(case_0_0, case_0_1, case_0_2)
    assert isinstance(var_0, Iterable)


# Generated at 2022-06-25 21:49:33.486641
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from _pytest.monkeypatch import MonkeyPatch
    from typing import Iterable, List, Tuple
    from pathlib import Path
    from pathlib2 import Path  # type: ignore

    def _fake_path(path_str: str) -> Path:
        return Path(path_str)

    mp = MonkeyPatch()
    mp.setattr(Path, 'exists', lambda path: not path.name.startswith('_bad'))
    mp.setattr(Path, 'glob', lambda path, pattern: path.rglob(pattern))
    mp.setattr(Path, 'joinpath', _fake_path)
    mp.setattr(Path, 'relative_to', lambda path, path2: path.name)


# Generated at 2022-06-25 21:49:39.844809
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    str_1 = '.'
    iterable_1 = get_input_output_paths(str_0, str_1, str_1)
    var_1 = list(iterable_1)
    str_2 = '.'
    iterable_2 = get_input_output_paths(str_0, str_2, None)
    var_2 = list(iterable_2)
    str_3 = 'demo.txt'
    iterable_3 = get_input_output_paths(str_0, str_3, None)
    var_3 = list(iterable_3)
    str_

# Generated at 2022-06-25 21:49:44.140306
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Path(('.',), exists=True), Path(('.',), exists=True)
    assert list(get_input_output_paths('.', '.', '.')) == [InputOutput(Path('.'), Path('.'))]


# Generated at 2022-06-25 21:49:50.879771
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test_case_0
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert var_0[0].input == Path('__init__.py')
    assert var_0[0].output == Path('__init__.py')
    assert str(var_0[0].input) == '__init__.py'
    assert str(var_0[0].output) == '__init__.py'
    assert var_0[1].input == Path('mymodule.py')
    assert var_0[1].output == Path('mymodule.py')
    assert str(var_0[1].input) == 'mymodule.py'

# Generated at 2022-06-25 21:49:52.053505
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths([], '/tmp', None) == []

# Generated at 2022-06-25 21:49:54.231441
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('.', '.', '.'))) > 0
    assert len(list(get_input_output_paths('..', '.', '.'))) > 0

# Generated at 2022-06-25 21:50:02.345308
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b.py', None)) == []
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-25 21:50:10.276815
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    #assert list(get_input_output_paths('foo', 'bar')) == \
    #    [InputOutput(Path('foo'), Path('bar'))]
    assert list(get_input_output_paths('foo', 'bar')) == \
        [InputOutput(Path('foo'), Path('bar'))]

    assert list(get_input_output_paths('foo.py', 'bar')) == \
        [InputOutput(Path('foo.py'), Path('bar/foo.py'))]
    assert list(get_input_output_paths('foo.py', 'bar.py')) == \
        [InputOutput(Path('foo.py'), Path('bar.py'))]


# Generated at 2022-06-25 21:50:58.106517
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test Case #0
    test_case_0()

    try:
        raise InvalidInputOutput
    except InvalidInputOutput:
        pass

# Generated at 2022-06-25 21:51:06.983355
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(".", "tmppypy.py", ".")

    with pytest.raises(InputDoesntExists):
        get_input_output_paths("tmppypy.py", ".", ".")

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("tmppypy", ".", ".")

    with pytest.raises(TypeError):
        get_input_output_paths(".", ".", 'tmppypy.py')

    assert len(list(get_input_output_paths(".", "tmppypy", "."))) == 1
    assert len(list(get_input_output_paths(".", "tmppypy", "tmppypy"))) == 1

# Generated at 2022-06-25 21:51:13.938431
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    str_1 = '.'
    str_2 = '.'
    iterable_0 = get_input_output_paths(str_0, str_1, str_2)
    var_0 = list(iterable_0)
    output_path = Path(Path.cwd().joinpath('bin', 'test', 'test.py'))
    input_path = Path(Path.cwd().joinpath('bin', 'test', 'test.py'))
    class_0 = InputOutput(input_path, output_path)
    assert var_0[0] == class_0


if __name__ == '__main__':
    test_get_input_output_paths()

# Generated at 2022-06-25 21:51:19.516415
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # These callables mock the built-in function __import__.
    def import_mock_0(name, *args, **kwargs):
        raise ImportError

    def import_mock_1(name, *args, **kwargs):
        if name == 'pathlib':
            class pathlib(object):
                class Path(object):
                    def __init__(self, path):
                        self.path = path

                    def exists(self):
                        if self.path == '.':
                            return True
                        if self.path == '/Users/jimmy/Desktop/file.py':
                            return True
                        if self.path == 'file.py':
                            return False
                    def joinpath(self, arg):
                        return self.path + arg
                    def relative_to(self, arg):
                        return self.path

# Generated at 2022-06-25 21:51:22.607781
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '.py'
    output = 'test/test'
    root = '.'
    iterable_0 = get_input_output_paths(input_, output, root)
    var_0 = list(iterable_0)
    assert len(var_0) > 0

# Generated at 2022-06-25 21:51:24.053961
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for i in range (100):
        test_case_0()

# Generated at 2022-06-25 21:51:31.780516
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Not provide input for input

    with pytest.raises(TypeError):
        get_input_output_paths()

    # Not provide input for output

    with pytest.raises(TypeError):
        get_input_output_paths(0.0)

    # Not provide input for root

    with pytest.raises(TypeError):
        get_input_output_paths(0.0, 0.0)

    # First argument is not valid type

    with pytest.raises(AssertionError):
        get_input_output_paths(0, 0.0, 0)

    with pytest.raises(AssertionError):
        get_input_output_paths(0.0, 0.0, 0.0)


# Generated at 2022-06-25 21:51:32.483432
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()

# Generated at 2022-06-25 21:51:36.956900
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Arrange
    # Act
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)

    # Assert
    assert var_0 == [InputOutput(Path('.'), Path('.'))]



# Generated at 2022-06-25 21:51:45.356075
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert [input_.name for input_ in get_input_output_paths(
            'in0.py', 'out0.py', 'root0.py')] == ['in0.py']
    except AssertionError as e:
        print('AssertionError: %s' % e)
    try:
        assert [input_.name for input_ in get_input_output_paths(
            'in1.py', 'out1.py', 'root1.py')] == ['in1.py']
    except AssertionError as e:
        print('AssertionError: %s' % e)

# Generated at 2022-06-25 21:53:45.394347
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    str_1 = '*.py'
    str_2 = '__pycache__'
    iterable_1 = get_input_output_paths(str_1, str_2, str_0)
    var_1 = list(iterable_1)
    assert var_0 == [(Path('./__init__.py'), Path('./__init__.py')), (Path('./test.py'), Path('./test.py')), (Path('./test_test.py'), Path('./test_test.py'))]

# Generated at 2022-06-25 21:53:46.806773
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    return None


# Generated at 2022-06-25 21:53:48.188339
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert len(var_0) == 253


# Test case for function get_input_output_paths

# Generated at 2022-06-25 21:53:49.887875
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test case 0
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)
    assert (var_0 == [])

# Generated at 2022-06-25 21:53:52.040523
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    str_0 = '.'
    iterable_0 = get_input_output_paths(str_0, str_0, str_0)
    var_0 = list(iterable_0)


# test_get_input_output_paths()

# Generated at 2022-06-25 21:53:56.037582
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()

# Test case for function get_input_output_paths in module input_output

# Generated at 2022-06-25 21:54:01.892396
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # No input directory
    try:
        list(get_input_output_paths('', '.', ''))
        assert False, "No exception was raised"
    except InputDoesntExists:
        pass
    # Normal operation
    pairs = list(get_input_output_paths('.', '.', ''))
    assert len(pairs) == 1
    assert str(pairs[0].input) == '.'
    assert str(pairs[0].output) == '.'
    # Input is a directory
    pairs = list(get_input_output_paths('.', 'test.js', ''))
    assert len(pairs) == 1
    assert str(pairs[0].input) == '.'
    assert str(pairs[0].output) == 'test.js/.'
    # Normal operation


# Generated at 2022-06-25 21:54:02.962341
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert 'test' in globals()
    assert 'test_case_0' in globals()

test_get_input_output_paths()

# Generated at 2022-06-25 21:54:07.381789
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)
    assert isinstance(get_input_output_paths(1, 1, 1), Iterable)
    assert isinstance(get_input_output_paths('.', '.', None), Iterable)
    assert get_input_output_paths('.', '.', None) == get_input_output_paths('.', '.', '.')
    assert get_input_output_paths('./examples/simple.py', '.', None) == get_input_output_paths('.', '.', '.')
    assert get_input_output_paths('./examples/simple.py', '.', None) != get_input_output_paths('.', './examples/simple.py', '.')
    assert get_

# Generated at 2022-06-25 21:54:09.191061
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert callable(get_input_output_paths)


# Example for function get_input_output_paths