

# Generated at 2022-06-12 03:18:28.501189
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory

    class TestCase(object):
        def __init__(self, input_path, output_path, root=None):
            self.input_path = input_path
            self.output_path = output_path
            self.root = root
            print(self.input_path)
            print(self.output_path)
            print(self.root)
            self.input_output_pairs = get_input_output_paths(self.input_path,
                                                             self.output_path,
                                                             self.root)

        def test(self):
            for input_, output in self.input_output_pairs:
                assert input_.exists()
                assert not output.exists()


# Generated at 2022-06-12 03:18:34.980919
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_='./tests/data/file_to_convert.py',
        output='./tests/data/result/', root='./tests/data')) == [
            InputOutput(
                input_=Path('./tests/data/file_to_convert.py'),
                output=Path('./tests/data/result/file_to_convert.py')
            )]


# Generated at 2022-06-12 03:18:45.268918
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # This root is used for test.
    root = 'tests/test_data/'

    # test input/output mismatch exception
    input_1 = 'wrong_input/'
    output_1 = 'path/to/dash/output.py'
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(input_1, output_1, root)

    # test no input exception
    input_2 = 'no_input.py'
    output_2 = 'path/to/dash/output.py'
    with pytest.raises(InputDoesntExists):
        get_input_output_paths(input_2, output_2, root)

    # test matching input/output
    input_3 = 'matching_input_output/matching.py'

# Generated at 2022-06-12 03:18:54.223918
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_path = "/home/username/src/project/module/main.py"
    output_path = "/home/username/src/project/module/output.py"
    result = get_input_output_paths(input_path, output_path, None)
    assert list(result) == [InputOutput(Path("/home/username/src/project/module/main.py"), Path("/home/username/src/project/module/output.py"))]
    

    input_path = "/home/username/src/project/module/main.py"
    output_path = "/home/username/src/project/module/"
    result = get_input_output_paths(input_path, output_path, None)

# Generated at 2022-06-12 03:19:01.476064
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:19:09.977582
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from shutil import rmtree
    from tempfile import mkdtemp 
    temp_dir = mkdtemp()

# Generated at 2022-06-12 03:19:17.867906
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        assert get_input_output_paths('tests/data/dummy', '', None)
        assert False
    except InputDoesntExists:
        assert True
    assert list(get_input_output_paths('tests/data/dummy.py', '', None)) == [
        InputOutput(Path('tests/data/dummy.py'), Path('tests/data/dummy.py'))
    ]
    assert list(get_input_output_paths('tests/data/dummy.py', 'tests/data', None)) == [
        InputOutput(Path('tests/data/dummy.py'), Path('tests/data/dummy.py'))
    ]

# Generated at 2022-06-12 03:19:27.823225
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test/in/test.py', 'test/out', root='test/in')) ==\
        [InputOutput(Path('test/in/test.py'), Path('test/out/test.py'))]
    assert list(get_input_output_paths('test/in', 'test/out', root='test/in')) ==\
        [InputOutput(Path('test/in/test.py'), Path('test/out/test.py'))]
    assert list(get_input_output_paths('test/in', 'test/out/out.py', root='test/in')) ==\
        [InputOutput(Path('test/in/test.py'), Path('test/out/out.py'))]

# Generated at 2022-06-12 03:19:29.586593
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [InputOutput(Path('foo.py'), Path('bar.py'))]

# Generated at 2022-06-12 03:19:38.665292
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Path support
    # noinspection PyTypeChecker
    input_output = list(get_input_output_paths(
        Path('some_script.py'),
        Path('/some/output/path'),
        Path('.')
    ))
    assert input_output == [InputOutput((Path('some_script.py')),
                                        (Path('/some/output/path/some_script.py')))]

    # Output file is not .py file
    with pytest.raises(InvalidInputOutput):
        next(get_input_output_paths('some_script.py', 'wrong_output', None))

    # Input file does not exists

# Generated at 2022-06-12 03:19:54.710213
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    current_path = str(Path.cwd())
    input_ = str(Path.cwd().joinpath('tests', 'test_data', 'example'))
    output = str(Path.cwd().joinpath('tests', 'test_data', 'output'))
    test = list(get_input_output_paths(input_, output, root=current_path))

    assert len(test) == 4
    assert str(test[0][0]) == str(Path.cwd().joinpath('tests', 'test_data', 'example',
                                                     'example', '__init__.py'))
    assert str(test[0][1]) == str(Path.cwd().joinpath('tests', 'test_data', 'output',
                                                     'example', '__init__.py'))

# Generated at 2022-06-12 03:20:03.608977
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # root is None
    ios = get_input_output_paths('/a/b/c.py', '/d', None)
    assert next(ios) == InputOutput(Path('/a/b/c.py'), Path('/d/c.py'))
    ios = get_input_output_paths('/a/b', '/d', None)
    assert next(ios) == InputOutput(Path('/a/b/d.py'), Path('/d/b/d.py'))
    with pytest.raises(InvalidInputOutput):
        ios = get_input_output_paths('/a/b.py', '/d', None)

# Generated at 2022-06-12 03:20:09.685706
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    def _assert_ex(input_, output, root=None, exception=InvalidInputOutput):
        with pytest.raises(exception):
            list(get_input_output_paths(input_, output, root))

    input_output = list(get_input_output_paths('inputs/test.py', 'outputs/test.py'))
    assert input_output == [InputOutput(Path('inputs/test.py'), Path('outputs/test.py'))]

    input_output = list(get_input_output_paths('inputs/test.py', 'outputs', 'inputs'))

# Generated at 2022-06-12 03:20:19.454596
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    from unittest import TestCase
    from unittest.mock import mock_open, patch
    import sys

    class TestGetInputOutputPaths(TestCase):
        """Test function get_input_output_paths."""

        def test_get_input_output_paths(self):
            """Test function get_input_output_paths."""
            with open('test_file1.txt', 'w'):
                pass
            with open('test_file2.py', 'w'):
                pass
            with open('test_file3.py', 'w'):
                pass

# Generated at 2022-06-12 03:20:30.181130
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths"""
    path0 = get_input_output_paths('/tmp/foo/bar.py', '/tmp/bar.py', None)
    path1 = get_input_output_paths('bar.py', 'bar.py', None)
    path2 = get_input_output_paths('/tmp/foo.py', '/tmp/bar', None)
    path3 = get_input_output_paths('/tmp/foo.py', '/tmp/bar.py', '/tmp')
    path4 = get_input_output_paths('/tmp/foo', '/tmp/bar', None)
    assert str(path0.__next__().output) == '/tmp/bar.py'
    assert str(path1.__next__().output) == 'bar.py'

# Generated at 2022-06-12 03:20:34.205289
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root_dir = Path(__file__).parents[1]

    inputs_outputs = list(get_input_output_paths(root_dir / 'path_1', root_dir / 'path_2', root_dir))

    assert len(inputs_outputs) == 2

# Generated at 2022-06-12 03:20:38.962677
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b', None)) == \
           [
               InputOutput(Path('a.py'), Path('b/a.py')),
           ]
    assert list(get_input_output_paths('a/b.py', 'b', None)) == \
           [
               InputOutput(Path('a/b.py'), Path('b/b.py')),
           ]
    assert list(get_input_output_paths('a', 'b', None)) == \
           [
               InputOutput(Path('a/a.py'), Path('b/a.py')),
           ]

# Generated at 2022-06-12 03:20:48.495695
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/tmp/test/a.py', '/tmp/test/b.py', None)) == \
        [InputOutput(Path('/tmp/test/a.py'), Path('/tmp/test/b.py'))]

    assert list(get_input_output_paths('/tmp/test/a', '/tmp/test/b.py', None)) == \
        [InputOutput(Path('/tmp/test/a/a.py'), Path('/tmp/test/b.py/a.py'))]


# Generated at 2022-06-12 03:20:54.977769
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    inputs = [
        ('input.py', 'output.py', None),
        ('input.txt', 'output', None),
        ('input.txt', 'output', 'input'),
        ('input.txt', 'output', 'D:/project/input'),
        ('input.txt', 'output', '../input'),
    ]
    for input_output in inputs:
        list(get_input_output_paths(*input_output))

# Generated at 2022-06-12 03:21:04.027353
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    inp = "foo/bar/baz.py"
    out = "foo/bar/baz-out.py"
    list(get_input_output_paths(inp, out, None))
    out = "foo/bar/baz-out"
    list(get_input_output_paths(inp, out, None))
    out = "foo/bar/baz.py"
    list(get_input_output_paths(inp, out, None))
    inp = "foo/bar/baz.py"
    out = "foo/bar/baz.py"
    list(get_input_output_paths(inp, out, None))
    inp = "foo/bar"
    out = "foo/bar/baz.py"

# Generated at 2022-06-12 03:21:28.786883
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print("test_get_input_output_paths start !")
    # test case: input and output suffix are both ".py"
    input_ = "./test_cases/test_input_output_paths/input.py"
    output = "./test_cases/test_input_output_paths/output.py"
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    iter_input_output_paths = iter(input_output_paths)
    input_output_paths1 = next(iter_input_output_paths)
    input_output_paths2 = next(iter_input_output_paths)
    assert input_output_paths1.input_path == Path(input_)
    assert input_output_path

# Generated at 2022-06-12 03:21:39.154929
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a', 'a.txt'))
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.txt', 'a.txt'))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.txt', 'a'))

    assert list(get_input_output_paths('a.py', 'a.py')) == [InputOutput(Path('a.py'), Path('a.py'))]
    assert list(get_input_output_paths('a.py', 'b')) == [InputOutput(Path('a.py'), Path('b/a.py'))]

# Generated at 2022-06-12 03:21:45.003402
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Without root argument
    in_out_paths = list(
        get_input_output_paths("test/resources/hello.py",
                               "test/resources", None))

    assert len(in_out_paths) == 1
    in_out_path = in_out_paths[0]
    assert in_out_path.input == Path("test/resources/hello.py")
    assert in_out_path.output == Path("test/resources/hello.py")

    in_out_paths = list(
        get_input_output_paths("test/resources",
                               "test/resources-out", None))

    assert len(in_out_paths) == 2
    in_out_paths = sorted(in_out_paths, key=lambda x: x.input.name)

# Generated at 2022-06-12 03:21:52.691689
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'abc.py'
    output = 'abc.py'
    pairs = get_input_output_paths(input_, output, None)
    assert len(list(pairs)) == 1
    input_, output = pairs.__next__()
    assert input_ == output

    input_ = 'abc.py'
    output = 'd.py'
    pairs = get_input_output_paths(input_, output, None)
    assert len(list(pairs)) == 1
    input_, output = pairs.__next__()
    assert input_.name == output.name

    input_ = 'abc.py'
    output = 'd'
    pairs = get_input_output_paths(input_, output, None)
    assert len(list(pairs)) == 1
    input_, output

# Generated at 2022-06-12 03:21:55.163358
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(input_="./input1/a.py",
                                  output="./output1", root=None) == [InputOutput("./input1/a.py", "./output1/input1/a.py")]



# Generated at 2022-06-12 03:22:02.080262
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """ Unit test for function get_input_output_paths"""

    import os

    # Check for invalid input output
    input_path = "infile.txt"
    output_path = "outfile.py"
    try:
        list(get_input_output_paths(input_path, output_path, None))
    except InvalidInputOutput as _:
        pass
    else:
        assert False

    # Check for input doesn't exist
    input_path = "infile.py"
    output_path = "outfile.py"
    try:
        list(get_input_output_paths(input_path, output_path, None))
    except InputDoesntExists as _:
        pass
    else:
        assert False


# Generated at 2022-06-12 03:22:09.497041
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """ Unit test for function get_input_output_paths. """
    from .test.test_utils import TEST_ROOT

# Generated at 2022-06-12 03:22:15.381009
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""

    import os


# Generated at 2022-06-12 03:22:21.474387
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'input'
    output = 'output'
    root = 'root'

    # Exception when input and output extensions don't match
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(input_ + '.c', output + '.py', root)

    # Exception when input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths(input_ + '_not_exist', output, root)

    input_paths = [
        input_ + '.py',            # one file
        input_,                    # dir
        os.path.join(input_, input_ + '.py'),  # subdir+file
    ]

# Generated at 2022-06-12 03:22:28.166543
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test without an input
    with pytest.raises(InputDoesntExists):
        input_ = ""
        output_ = ""
        root_ = ""
        list(get_input_output_paths(input_, output_, root_))
    # test with an input
    input_ = "./tests/resources/classes.py"
    output_ = "./output/classes.py"
    root_ = "./tests"
    result = list(get_input_output_paths(input_, output_, root_))
    expected_result = [InputOutput(Path("tests/resources/classes.py"), Path("output/classes.py"))]
    for i in range(len(result)):
        assert result[i].input.samefile(expected_result[i].input)

# Generated at 2022-06-12 03:23:06.805560
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from . import get_input_output_paths

    # Only one input/output pair
    inputs = ['test/test_01.py',
              'test',
              'test/']

    outputs = ['test/test_01_pre.py',
               'out',
               'out/out']

    for input_, output in zip(inputs, outputs):
        gen = get_input_output_paths(input_, output, 'test')
        assert next(gen) == InputOutput(Path('test/test_01.py'), Path('test/test_01_pre.py'))
        with pytest.raises(StopIteration):
            next(gen)

    # Input directory
    gen = get_input_output_paths('test', 'out', 'test')

# Generated at 2022-06-12 03:23:14.578303
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input, output = '/usr/bin', '/tmp/foo'
    input_output = get_input_output_paths(input, output, None)
    assert(bool(input_output) == False)

    input, output = '/tmp/foo', '/tmp/foo'
    input_output = list(get_input_output_paths(input, output, '/tmp/foo'))
    assert(len(input_output) == 1)
    assert(input_output[0].input == Path('/tmp/foo'))
    assert(input_output[0].output == Path('/tmp/foo'))

    input, output = '/tmp/foo', '/tmp/foo/bar'
    input_output = list(get_input_output_paths(input, output, '/tmp/foo'))

# Generated at 2022-06-12 03:23:19.214829
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    files = [file.path for file in get_input_output_paths(
        'test/pyfixtures/simple.py', 'foo', 'test/pyfixtures')]
    assert files == ['foo/simple.py']
    files = [file.path for file in get_input_output_paths(
        'test/pyfixtures', 'foo', 'test/pyfixtures')]
    assert sorted(files) == sorted(['foo/simple.py', 'foo/multiple.py'])

# Generated at 2022-06-12 03:23:29.672421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from io import StringIO
    from itertools import islice
    from unittest import TestCase, main

    class TestGetInputOutputPaths(TestCase):
        """Test function get_input_output_paths."""

        def test_get_input_output_paths(self):
            """Test get_input_output_paths."""
            with TemporaryDirectory() as tempdir:
                tempdirpath = Path(tempdir)

                # 1. python file provided as input should return single item
                input_path = tempdirpath.joinpath('a.py')
                input_path.write_text('# test comments')
                output_path = tempdirpath.joinpath('b.txt')

# Generated at 2022-06-12 03:23:36.438598
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Define some function to test
    get_pairs = get_input_output_paths
    # Create a temporary directory
    with TemporaryDirectory() as root_dir:
        root_dir = Path(root_dir)
        test_dir = Path('testdir')
        root = root_dir.joinpath(test_dir)
        root.mkdir()
        # Create files in the temporary directory
        input_file = Path('input.py')
        output_file = Path('output.py')
        # Create another file that is not a .py file
        input_not_py = Path('not_py.txt')
        # Create files in testdir
        file_a = test_dir.joinpath('a.py')
        file_aa = test_dir.joinpath('aa.py')
        file_ab = test_dir

# Generated at 2022-06-12 03:23:45.028968
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:23:50.889097
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = get_input_output_paths('src', 'dst', 'src')
    input_output = list(input_output)
    assert len(input_output) == 11

# Generated at 2022-06-12 03:23:58.103745
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test function get_input_output_paths.
    """

# Generated at 2022-06-12 03:24:04.133428
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths"""
    # Parsing file
    input_outputs = list(get_input_output_paths('test.py', 'out.py', None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input_path == Path('test.py')
    assert input_outputs[0].output_path == Path('out.py')
    # Parsing dir
    input_outputs = list(get_input_output_paths('test', 'out', None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input_path == Path('test/a.py')
    assert input_outputs[0].output_path == Path('out/a.py')
    # Parsing dir with relative root
    input

# Generated at 2022-06-12 03:24:12.912676
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(
        input_='in1.py', output='out1.py', root=None) is not None
    assert get_input_output_paths(
        input_='in1.py', output='out1', root=None) is not None
    assert get_input_output_paths(
        input_='in1', output='out1', root=None) is not None
    assert get_input_output_paths(
        input_='in1', output='out1', root='in1') is not None
    assert get_input_output_paths(
        input_='in1', output='out1', root='in1/in1.1') is not None

# Generated at 2022-06-12 03:25:21.832675
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo.py', '.', None) == [
        InputOutput(Path('foo.py'), Path('foo.py'))
    ]
    assert get_input_output_paths('foo.py', 'bar.py', None) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]
    assert get_input_output_paths('/', 'bar', None) == [
        InputOutput(Path('/', '1.py'), Path('bar', '1.py'))
    ]
    assert get_input_output_paths('/', 'bar', '/') == [
        InputOutput(Path('/', '1.py'), Path('bar', '1.py'))
    ]

# Generated at 2022-06-12 03:25:28.896850
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = './a.py'
    output = './b.py'
    root = None
    # Inner function to call the function being tested
    def innerGetInputOutputPaths():
        return get_input_output_paths(input_, output, root)

    assert(innerGetInputOutputPaths() == [InputOutput(Path(input_), Path(output))])
    input_ = './a.txt'
    output = './b.txt'
    root = './'
    assert(innerGetInputOutputPaths() == [InputOutput(Path('./a.txt/a.py'), Path('./b.txt/a.py')),
                                          InputOutput(Path('./a.txt/b.py'), Path('./b.txt/b.py'))])

# Generated at 2022-06-12 03:25:34.242276
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for valid input_output_paths
    input_output_paths = get_input_output_paths('tests/data', 'output', 'tests/data')
    input_output_paths_list = list(input_output_paths)
    assert len(input_output_paths_list) == 1
    assert input_output_paths_list[0].input_path == Path('tests/data/main.py')
    assert input_output_paths_list[0].output_path == Path('output/main.py')

    input_output_paths = get_input_output_paths('tests/data/', 'output', 'tests/data')
    input_output_paths_list = list(input_output_paths)


# Generated at 2022-06-12 03:25:41.728455
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test with a single .py file
    assert [(i, o) for i, o in get_input_output_paths('in/dummy.py', 'out/dummy.py')] == \
        [('in/dummy.py', 'out/dummy.py')]
    # Test with a directory
    assert [(i, o) for i, o in get_input_output_paths('in', 'out')] == \
        [('in/dummy.py', 'out/dummy.py')]
    assert [(i, o) for i, o in get_input_output_paths('in', 'out', root='in')] == \
        [('in/dummy.py', 'out/dummy.py')]

# Generated at 2022-06-12 03:25:49.582121
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    additional_tests = [
        ("a.py", "b.py", None),
        ("a.py", "b.py", ""),
        ("a.py", "c", ""),
        ("a.py", "c/d.py", ""),
        ("a.py", "c/d.py", None),
        ("c", "d", ""),
        ("c", "d", None),
        ("c", "d/f", ""),
        ("c", "d/f", None),
        ("c/a.py", "d/f", ""),
        ("c/a.py", "d/f", None),
    ]
    for test in additional_tests:
        paths = list(get_input_output_paths(*test))
        assert len(paths) == 1

# Generated at 2022-06-12 03:25:52.189184
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'test.py'
    output = 'example'
    root = None
    input_output = InputOutput(Path(input_), Path(output).joinpath(Path(input_).name))
    assert get_input_output_paths(input_, output, root).next() == input_output

# Generated at 2022-06-12 03:25:58.690452
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # if we have no .py files in input, exception must be raised
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input', 'output', None))
    # if input is not a file, first argument is directory and second argument is
    # file, exception must be raised
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input_dir', 'output_dir/output_file', None))
    # if input and output are files, input-output is equal

# Generated at 2022-06-12 03:26:06.242576
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Negative test for input_ does not exist
    with pytest.raises(InputDoesntExists):
        next(get_input_output_paths('foo', 'foo', None))

    # Negative test for input_ and output ending with .py
    with pytest.raises(InvalidInputOutput):
        next(get_input_output_paths('setup.py', 'setup.py', None))

    # Positive test for input_ and output not ending with .py
    assert next(get_input_output_paths('setup.py', 'test', None)) \
        == InputOutput(Path('setup.py'), Path('test/setup.py'))

    # Positive test for input_ and output ending with .py

# Generated at 2022-06-12 03:26:15.141861
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    get_input_output_paths('/test/test.py', '/test/output.py', '')
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/test/test.pyc', '/test/output.py', '')
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/test/test1.py', '/test/output.py', '')
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/test/test1.py', '/test/output.pyc', '')
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/test/test1.txt', '/test/output.txt', '')



# Generated at 2022-06-12 03:26:21.977025
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

    inputs_outputs = get_input_output_paths('./tests/fixtures/path/input_1.py'.replace('/', os.sep),
                                            './tests/fixtures/path/input_1_output.py'.replace('/', os.sep),
                                            None)

    assert {InputOutput(Path('./tests/fixtures/path/input_1.py'.replace('/', os.sep)), Path('./tests/fixtures/path/input_1_output.py'.replace('/', os.sep)))} == inputs_outputs