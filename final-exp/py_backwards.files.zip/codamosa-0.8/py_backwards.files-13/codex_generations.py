

# Generated at 2022-06-12 03:18:22.251283
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # input.py, output.py
    assert get_input_output_paths(
        'input.py', 'output.py', None) == [InputOutput(Path('input.py'), Path('output.py'))]
    assert get_input_output_paths(
        'input.py', 'output.txt', None) == [InputOutput(Path('input.py'), Path('output.txt')/'input.py')]
    assert get_input_output_paths(
        'input.py', 'output.txt', 'base') == [InputOutput(Path('input.py'), Path('output.txt')/'base/input.py')]
    # input, output.py
    assert get_input_output_paths(
        'input', 'output.py', None) == []
    # input, output.txt

# Generated at 2022-06-12 03:18:30.617677
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a/b.py', 'c/d.py', None)) == [
        InputOutput(Path('a/b.py'), Path('c/d.py'))
    ]
    assert list(get_input_output_paths('a/b.py', 'c/d.py', 'a')) == [
        InputOutput(Path('a/b.py'), Path('c/d.py'))
    ]

# Generated at 2022-06-12 03:18:39.959199
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./input/a.py', './output/', None)) \
        == [InputOutput(Path('./input/a.py'), Path('./output/a.py'))]
    assert list(get_input_output_paths('./input/a.py', './output/a.py', None)) \
        == [InputOutput(Path('./input/a.py'), Path('./output/a.py'))]

    assert list(get_input_output_paths('./input', './output/', None)) \
        == [InputOutput(Path('./input/b.py'), Path('./output/b.py'))]

# Generated at 2022-06-12 03:18:49.627518
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()
    """
    # Multi file in single folder
    input_ = "tests/data/single_folder"
    output = "tests/output/single_folder"
    input_output = list(get_input_output_paths(input_, output, None))
    assert len(input_output) == 3
    assert input_output[0].input_.parts == ("tests", "data", "single_folder", "abc.py")
    assert input_output[0].output_.parts == ("tests", "output", "single_folder", "abc.py")
    assert input_output[1].input_.parts == ("tests", "data", "single_folder", "def.py")

# Generated at 2022-06-12 03:18:57.621829
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test exception "InvalidInputOutput"
    with pytest.raises(InvalidInputOutput):
        tuple(get_input_output_paths('path/to/input/', 'path/to/output', None))

    # Test exception "InputDoesntExists"
    with pytest.raises(InputDoesntExists):
        tuple(get_input_output_paths('path/to/input.py', 'path/to/output.py', None))

    # Test with path to single file
    assert tuple(get_input_output_paths('path/to/input.py', 'path/to/output.py', None)) == ((Path('path/to/input.py'), Path('path/to/output.py')),)

    # Test with path to single file and root directory

# Generated at 2022-06-12 03:19:03.723156
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('in', 'out', 'root') == [
        InputOutput(Path('in'), Path('out'))
    ]

    with pytest.raises(InputDoesntExists) as excinfo:
        list(get_input_output_paths('in', 'out', 'root'))

    assert excinfo.value.input_path == 'in'

    assert get_input_output_paths('in.py', 'out.py', 'root') == [
        InputOutput(Path('in.py'), Path('out.py'))
    ]

    assert get_input_output_paths('in.py', 'out', 'root') == [
        InputOutput(Path('in.py'), Path('out').joinpath('in.py'))
    ]

    assert get_input_output

# Generated at 2022-06-12 03:19:10.189561
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    import pytest
    import os

    with pytest.raises(InputDoesntExists):
        get_input_output_paths("invalid.py", "out", "")

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(__file__, ".py", "")

    assert list(get_input_output_paths(__file__, "output", ".")) == [InputOutput(
        Path(__file__), Path("output", os.path.basename(__file__)))]

# Generated at 2022-06-12 03:19:18.044168
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def f(input, output, root=None):
        return [
            tuple(map(str, pair))
            for pair in get_input_output_paths(input, output, root)
        ]
    assert f('a', 'b') == [('a', 'b')]
    assert f('a.py', 'b.py') == [('a.py', 'b.py')]
    assert f('a.py', 'b') == [('a.py', 'b/a.py')]
    assert f('a', 'b', 'a') == [('a/a.py', 'b/a.py')]
    assert f('a', 'b', 'c') == [('a/a.py', 'b/c/a.py')]
    assert f('a', 'b', 'a/a')

# Generated at 2022-06-12 03:19:28.236307
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (list(get_input_output_paths("test/test_data/test_mod.py", "test/test_data/output", None))
            == [InputOutput(Path('test/test_data/test_mod.py'), Path('test/test_data/output/test_mod.py'))])
    assert (list(get_input_output_paths("test/test_data/test_mod.py", "test/test_data/output/test_mod.py", None))
            == [InputOutput(Path('test/test_data/test_mod.py'), Path('test/test_data/output/test_mod.py'))])

# Generated at 2022-06-12 03:19:33.161603
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths."""
    def get_input_output_paths_test(input_: str, output: str,
                                    root: Optional[str]) -> Iterable[InputOutput]:
        """Get input/output paths pairs."""
        if output.endswith('.py') and not input_.endswith('.py'):
            raise InvalidInputOutput

        if not Path(input_).exists():
            raise InputDoesntExists

        if input_.endswith('.py'):
            if output.endswith('.py'):
                yield InputOutput(Path(input_), Path(output))
            else:
                input_path = Path(input_)
                if root is None:
                    output_path = Path(output).joinpath(input_path.name)

# Generated at 2022-06-12 03:19:49.096727
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path('root')
    output = Path('root', 'output')
    input_ = Path('root', 'input', 'foo.py')
    input_path = InputOutput(input_, output.joinpath(input_.relative_to(root)))

    assert list(get_input_output_paths('root/input', 'root/output', 'root')) == [input_path]
    assert list(get_input_output_paths('root/input', 'root/output', 'root')) == [input_path]
    assert list(get_input_output_paths('root/input', 'root/input2/output', 'root')) == [input_path]

# Generated at 2022-06-12 03:19:56.192124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing function get_input_output_paths with expected input and output"""
    assert get_input_output_paths('test/test.py', 'test/out/', 'test') == \
    [InputOutput(Path('test/test.py'), Path('test/out/test.py'))]
    assert get_input_output_paths('test/', 'test/out/', 'test') == \
    [InputOutput(Path('test/test.py'), Path('test/out/test.py'))]
    assert get_input_output_paths('test.py', 'out/', 'test') == \
    [InputOutput(Path('test.py'), Path('out/test.py'))]

# Generated at 2022-06-12 03:20:01.690113
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_path = Path('/a/b/c')
    input_path.mkdir(parents=True, exist_ok=True)
    output_path = Path('/x/y/z')
    output_path.mkdir(parents=True, exist_ok=True)
    input_output = get_input_output_paths(input_path, output_path, None)
    assert tuple(next(input_output)) == (Path('/a/b/c'), Path('/x/y/z'))

# Generated at 2022-06-12 03:20:09.152794
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    if get_input_output_paths('/home/user/1.py', '/home/user/directory/2.py', '/home/user/')[0].input_path == '/home/user/1.py':
        print('get_input_output_paths is correct')
    else:
        print('get_input_output_paths has an error')
    if get_input_output_paths('/home/user/1.py', '/home/user/directory/3.py', '/home/user/')[0].output_path == '/home/user/directory/3.py/1.py':
        print('get_input_output_paths is correct')
    else:
        print('get_input_output_paths has an error')

# Generated at 2022-06-12 03:20:18.940327
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (get_input_output_paths('file.py', '', None) == \
            [InputOutput(Path('file.py'), Path('file.py'))])
    assert (get_input_output_paths('file.py', 'file.py', None) == \
            [InputOutput(Path('file.py'), Path('file.py'))])
    assert (get_input_output_paths('file.py', '.tmp', None) == \
            [InputOutput(Path('file.py'), Path('.tmp/file.py'))])

# Generated at 2022-06-12 03:20:29.955240
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b', 'a.py'))]
    assert list(get_input_output_paths('a.py', 'b', 'c')) == [InputOutput(Path('a.py'), Path('b', 'c', 'a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == []
    assert list(get_input_output_paths('a', 'b', None))

# Generated at 2022-06-12 03:20:40.276542
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    temp_folder = Path("temp-src")
    temp_folder_output = Path("temp-dest")
    temp_folder.mkdir(exist_ok=True)
    temp_folder_output.mkdir(exist_ok=True)
    temp_py_file = temp_folder.joinpath("test.py")
    temp_py_file.write_text("') #haha")

    assert set(get_input_output_paths("temp-src/test.py","temp-dest/test.py", None)) == {
        InputOutput(Path("temp-src/test.py"), Path("temp-dest/test.py"))}

# Generated at 2022-06-12 03:20:49.068983
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths()."""
    assert list(get_input_output_paths('file.py', 'file.py', None)) \
               == [InputOutput(Path('file.py'), Path('file.py'))]
    assert list(get_input_output_paths('file2.py', 'file2.py', None)) \
               == [InputOutput(Path('file2.py'), Path('file2.py'))]
    assert list(get_input_output_paths(Path('file3.py'), 'file3.py', None)) \
               == [InputOutput(Path('file3.py'), Path('file3.py'))]

# Generated at 2022-06-12 03:20:55.840694
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='./lib',
            output='./output/lib.py'
        ))

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='./lib.py',
            output='./output/lib'
        ))

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='./lib',
            output='./output/lib'
        ))


# Generated at 2022-06-12 03:21:04.512435
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def validate(input, output, root = None):
        result = get_input_output_paths(input, output, root)
        for p in result:
            assert(p.input_path.is_file())
            assert(not p.output_path.is_file())
            assert(p.input_path.relative_to(root) == p.output_path.relative_to(output))

    validate("test/testdata/a.py", "test/testdata/a.py")
    validate("test/testdata/a.py", "test/testdata/")
    validate("test/testdata/a.py", "test/testdata/dir/")
    validate("test/testdata/dir/", "test/testdata/dir/")

# Generated at 2022-06-12 03:21:27.403254
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Empty paths
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("", "", ""))

    # Input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("nope", "", ""))

    # Same input/output
    paths = list(get_input_output_paths("test_input.py", "test_input.py", ""))
    assert len(paths) == 1
    assert str(paths[0].input_path) == "test_input.py"
    assert str(paths[0].output_path) == "test_input.py"

    # Different input/output

# Generated at 2022-06-12 03:21:36.818231
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .__main__ import get_input_output_paths
    from pathlib import Path
    import tempfile
    import shutil
    import os

    def assert_expected_outputs(input_path: str, output_path: str, expected_outputs: Iterable[str]):
        output_paths = [output.relative_to(Path(output_path)) for input, output in get_input_output_paths(input_path, output_path, None)]
        assert expected_outputs == output_paths


# Generated at 2022-06-12 03:21:38.432641
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:21:41.969416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print("Unit test")
    input_ = "a.py"
    output = "b.py"
    root = None
    paths = get_input_output_paths(input_, output, root)
    #for p in paths:
        #print("input: " + str(p.input_path))
        #print("output: " + str(p.output_path))

# Generated at 2022-06-12 03:21:50.068809
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    #########
    # Invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(input_="foo.py", output="bar",
                                    root=None))
    #########
    # Invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(input_="invalid_input", output="bar",
                                    root=None))
    #########
    # input.py/output/
    in_out = list(get_input_output_paths(input_="foo.py", output="bar",
                                         root=None))
    assert len(in_out) == 1
    assert in_out[0].input == Path("foo.py")

# Generated at 2022-06-12 03:21:55.976200
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/home/user/src/foo.py'
    output = '/home/user/output/foo.py'
    assert get_input_output_paths(input_, output, None).next().output == Path('/home/user/output/foo.py')
    input_ = '/home/user/src/foo.py'
    output = '/home/user/output'
    assert get_input_output_paths(input_, output, None).next().output == Path('/home/user/output/foo.py')
    input_ = '/home/user/src/foo.py'
    output = '/home/user/output'
    assert get_input_output_paths(input_, output, '/home').next().output == Path('/home/user/output/src/foo.py')
    input_

# Generated at 2022-06-12 03:21:59.464728
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    input_ = '/home/user/project/foo.py'
    output = '/home/user/project/bar.py'
    root = '/home/user/project'

    # When
    paths = get_input_output_paths(input_, output, root)
    paths = list(paths)

    # Then
    assert paths == [InputOutput(Path(input_), Path(output))]



# Generated at 2022-06-12 03:22:07.696029
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    input_paths = []
    output_paths = []
    root_paths = []
    input_ = '/base/last/GIT'
    output = '/output'
    root = '/base'

    def get_input_output_paths_non_root(input_, output):
        for input_output in get_input_output_paths(input_, output, None):
            input_paths.append(input_output.input)
            output_paths.append(input_output.output)

    def get_input_output_paths_root(input_, output, root):
        for input_output in get_input_output_paths(input_, output, root):
            input_paths.append(input_output.input)

# Generated at 2022-06-12 03:22:14.044552
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test funciton get_input_output_paths"""

    # test case 1: dir to dir
    input_ = "/home/test"
    output = "/home/test1"
    root = "/home"
    inputoutput = get_input_output_paths(input_, output, root)
    for io in inputoutput:
        assert io.input_ == "/home/test/test.py"
        assert io.output == "/home/test1/test.py"
        break

    # test case 2: dir to dir(different)
    input_ = "/home/test"
    output = "/home/test1"
    root = None
    inputoutput = get_input_output_paths(input_, output, root)

# Generated at 2022-06-12 03:22:20.664947
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:22:40.231138
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # when input is a directory
    input = '/Users/kmayank/Private/workspace/mccabe/test/data'
    output = '/Users/kmayank/Private/workspace/mccabe/test/data/output/'
    inputs_outputs = get_input_output_paths(input, output, None)
    inputs_outputs_valid = [(
        '/Users/kmayank/Private/workspace/mccabe/test/data/do_nothing.py',
        '/Users/kmayank/Private/workspace/mccabe/test/data/output/do_nothing.py',
    )]

    for in_out, in_out_valid in zip(inputs_outputs, inputs_outputs_valid):
        in_, out = in_out

# Generated at 2022-06-12 03:22:43.828597
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/app/app_1.py'
    output = '/app/app_1_cov.py'
    root = None
    result = [InputOutput(Path('/app/app_1.py'), Path('/app/app_1_cov.py'))]
    assert list(get_input_output_paths(input_, output, root)) == result
    # *Unit test for function get_input_output_paths



# Generated at 2022-06-12 03:22:51.091669
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """ Test case for method get_input_output_paths. """
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import shutil

    results = []

    def write_file(path, text=None):
        """Writes file at given path."""
        with open(str(path), 'w') as out_file:
            if text:
                out_file.write(text)

    def assert_equals(expected):
        """Checks that the results are equal to expected."""
        input_outputs = [
            (path.relative_to(tmpdir), output.relative_to(tmpdir))
            for path, output in results
        ]
        assert input_outputs == expected


# Generated at 2022-06-12 03:22:58.015594
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Get input/output paths pairs test
    """
    assert get_input_output_paths('input/test/test.py', 'output/test/test.py', 'input') == [InputOutput(Path('input/test/test.py'), Path('output/test/test.py'))]
    assert get_input_output_paths('input/test/main.py', 'output', 'input') == [InputOutput(Path('input/test/main.py'), Path('output/test/main.py'))]

# Generated at 2022-06-12 03:23:05.875686
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1:
    # Input:
    #     input_: "input.py"
    #     output: "output.py"
    #     root: None
    # Expected output:
    #     [InputOutput(input="input.py", output="output.py")]

    input_ = "input.py"
    output = "output.py"
    expected_output = [InputOutput(Path(input_), Path(output))]

    actual_output = list(get_input_output_paths(input_, output, None))

    for i in range(len(expected_output)):
        assert actual_output[i].input == expected_output[i].input
        assert actual_output[i].output == expected_output[i].output

    # Test case 2:
    # Input:
    #     input

# Generated at 2022-06-12 03:23:14.262457
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    import os

    def create_temp_directory_structure(root_dir, structure):
        for dir_name, sub_path in structure.items():
            real_path = os.path.join(root_dir, dir_name)
            if sub_path is None:
                os.mkdir(real_path)
            else:
                os.mkdir(real_path)
                create_temp_directory_structure(real_path, sub_path)

    def create_temp_file_structure(root_dir, structure):
        create_temp_directory_structure(root_dir, structure)
        for dir_name in structure:
            real_path = os.path.join(root_dir, dir_name)

# Generated at 2022-06-12 03:23:20.004754
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = list(get_input_output_paths('foo/a.py', 'bar', 'foo'))
    assert (Path('foo/a.py'), Path('bar/a.py')) == result[0]

    result = list(get_input_output_paths('foo/a.py', 'bar/b.py', 'foo'))
    assert (Path('foo/a.py'), Path('bar/b.py')) == result[0]

    result = list(get_input_output_paths('foo', 'bar', 'foo'))
    assert (Path('foo/a.py'), Path('bar/a.py')) == result[0]

# Generated at 2022-06-12 03:23:30.577715
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        list(get_input_output_paths('foo', 'bar', None))
    except InputDoesntExists:
        pass
    else:
        assert False
    try:
        list(get_input_output_paths('foo.py', 'bar.py', None))
    except InvalidInputOutput:
        pass
    else:
        assert False

    ios = list(get_input_output_paths('foo.py', 'bar', None))
    assert len(ios) == 1
    assert ios[0].input_path.name == 'foo.py'
    assert ios[0].output_path.name == 'foo.py'
    assert ios[0].output_path.parent == Path('bar')

# Generated at 2022-06-12 03:23:34.768729
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1
    lista = get_input_output_paths(input_ = 'input/', output = 'output/', root = None)
    for inout in lista:
        print(inout)
    # Case 2
    lista = get_input_output_paths(input_ = 'input/test.py', output = 'output/', root = None)
    for inout in lista:
        print(inout)

# Generated at 2022-06-12 03:23:43.327468
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a', 'b', 'c')) == \
        [InputOutput(Path('a'), Path('b'))]
    assert list(get_input_output_paths('a.py', 'c', 'b')) == \
        [InputOutput(Path('a.py'), Path('c').joinpath('a.py'))]
    assert list(get_input_output_paths('a', 'b.py', 'c')) == \
        [InputOutput(Path('a').joinpath('d.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b.py', 'c')) == \
        [InputOutput(Path('a.py'), Path('b.py'))]

# Generated at 2022-06-12 03:24:17.924648
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test simple case
    paths = get_input_output_paths('examples', 'examples', None)
    assert [(p.input, p.output) for p in paths] == [('examples/example1.py', 'examples/example1.py'),
                                                    ('examples/example2.py', 'examples/example2.py')]

    paths = get_input_output_paths('examples/example1.py', 'examples/example1.py', None)
    assert [(p.input, p.output) for p in paths] == [('examples/example1.py', 'examples/example1.py')]

    paths = get_input_output_paths('examples/example1.py', 'examples/example2.py', None)

# Generated at 2022-06-12 03:24:25.904462
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test case 1
    assert list(get_input_output_paths('/path/to/foo.py', '/output/path/to/foo.py', None)) == \
        [InputOutput(Path('/path/to/foo.py'), Path('/output/path/to/foo.py'))]

    # test case 2
    assert list(get_input_output_paths('/path/to/foo.py', '/output/path/to/bar.py', None)) == \
        [InputOutput(Path('/path/to/foo.py'), Path('/output/path/to/bar.py'))]

    # test case 3

# Generated at 2022-06-12 03:24:33.709747
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # invalid input-output pair
    with raises(InvalidInputOutput):
        get_input_output_paths(input_="a.py", output="b.pyc")

    # invalid input non-existant
    with raises(InputDoesntExists):
        get_input_output_paths(input_="./tests/fixtures/fake.py", output=".")

    # single file
    (input_, output) = get_input_output_paths(input_="./tests/fixtures/app.py", output=".")
    assert tuple(input_) == Path('tests/fixtures/app.py')
    assert tuple(output) == Path('app.py')

    # single file with output file name

# Generated at 2022-06-12 03:24:41.950314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths
    """
    # incorrect input/output path in which input is a py script and output is a directory.
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('./tests/script.py',
                               './tests/',
                               None)

    # incorrect input/output path in which input is a directory and output is a py script.
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('./tests/',
                               './tests/script_output.py',
                               None)

    # input path does not exist.

# Generated at 2022-06-12 03:24:50.911472
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = get_input_output_paths('test.py', 'output.py', '.')
    assert next(result).input_path == Path('./test.py')
    assert next(result).output_path == Path('./output.py')

    result = get_input_output_paths('test.py', 'output', '.')
    assert next(result).input_path == Path('./test.py')
    assert next(result).output_path == Path('./output/test.py')

    result = get_input_output_paths('test', 'output', '.')
    assert next(result).input_path == Path('./test/test.py')
    assert next(result).output_path == Path('./output/test.py')

    result = get_input_output_path

# Generated at 2022-06-12 03:24:58.791729
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_path = sys.modules[__name__]
    # Test invalid case
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(test_path, test_path, None))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('.gitignore', test_path, None))
    # Test valid case
    input_output_pairs = list(get_input_output_paths(test_path, 'test_output', None))
    assert len(input_output_pairs) == 3
    assert input_output_pairs[0] == InputOutput(Path(test_path).joinpath('__init__.py'), Path('test_output').joinpath('__init__.py'))
    assert input_output_p

# Generated at 2022-06-12 03:25:07.286004
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import unittest
    from contextlib import redirect_stderr
    from io import StringIO

    class TestGetInputOutputPaths(unittest.TestCase):
        def test_file_pair(self):
            """We should get the same pairs for files."""
            paths = get_input_output_paths('./a.py', './b.py', './')
            a_b = next(paths)
            self.assertEqual(a_b.input, Path('./a.py'))
            self.assertEqual(a_b.output, Path('./b.py'))

        def test_directory_pair(self):
            """We should get the same input and the corresponding output."""

# Generated at 2022-06-12 03:25:10.158923
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path('~').expanduser()
    paths = get_input_output_paths(str(root), str(root), str(root))
    assert next(paths) == InputOutput(root.joinpath('setup.py'), root.joinpath('setup.py'))

# Generated at 2022-06-12 03:25:18.710280
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .test_utils import temp_file, temp_folder
    with temp_folder() as tmp:
        # Get input/output paths for single file
        input_path = tmp.joinpath('foo.py')
        output_path = tmp.joinpath('bar.py')
        input_.strpath = 'foo.py'
        output.strpath = 'bar.py'
        path = get_input_output_paths(input_.strpath, output_.strpath)
        assert path == (InputOutput(input_path, output_path),)
        with temp_file(input_path, 'a=1') as inp:
            assert inp.read() == 'a=1'
            assert not output_path.exists()
            with temp_file(output_path, 'b=2') as outp:
                assert inp

# Generated at 2022-06-12 03:25:26.417385
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        'example_input.py', 'example_output.py', root='.')) == [
            InputOutput(Path('example_input.py'), Path('example_output.py'))]

    assert list(get_input_output_paths(
        'input_dir', 'output_dir', root='.')) == [
            InputOutput(Path('input_dir/example_input.py'),
                        Path('output_dir/example_input.py'))]

    assert list(get_input_output_paths(
        'input_dir', 'output_dir', root='input_dir')) == [
            InputOutput(Path('example_input.py'),
                        Path('example_input.py'))]


# Generated at 2022-06-12 03:26:25.256131
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

    assert get_input_output_paths("in", "out", None) == [
        InputOutput(Path("in"), Path("out"))
    ]

    with pytest.raises(InputDoesntExists):
        get_input_output_paths("in", "out", None)

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("in.py", "out", None)
        get_input_output_paths("in", "out.py", None)

    assert get_input_output_paths("in.py", "out.py", None) == [
        InputOutput(Path("in.py"), Path("out.py"))
    ]


# Generated at 2022-06-12 03:26:33.241160
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the get_input_output_paths function."""
    # Test files
    os.mkdir('dir')
    open(os.path.join('dir', 'file1.py'), 'w').close()
    open(os.path.join('dir', 'file2.py'), 'w').close()
    open(os.path.join('dir', 'file3.py'), 'w').close()
    open('file1.py', 'w').close()
    open('file2.py', 'w').close()
    open('file3.py', 'w').close()

    # test for a dir path and output is end up with '.py'
    with pytest.raises(InvalidInputOutput) as e_info:
        get_input_output_paths('dir', 'file.py', 'dir')

# Generated at 2022-06-12 03:26:41.046129
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for input_ in ['input/file.py', 'input/']:
        for output in ['output/file.py', 'output/']:
            try:
                assert list(get_input_output_paths(input_, output, '')) == [
                    InputOutput(Path(input_), Path(output))
                ]
            except InvalidInputOutput:
                if output.endswith('.py') and not input_.endswith('.py'):
                    pass
                else:
                    raise
    assert list(get_input_output_paths('input/', 'output/', '')) == [
        InputOutput(Path('input/file1.py'), Path('output/file1.py')),
        InputOutput(Path('input/file2.py'), Path('output/file2.py'))
    ]
    assert list

# Generated at 2022-06-12 03:26:48.209622
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    from pathlib import Path
    testRoot = Path("C:/Users/Test/Desktop/Project")
    assert [InputOutput(Path("C:/Users/Test/Desktop/Project/test.py"), Path("C:/Users/Test/Desktop/test.py"))] == list(get_input_output_paths("C:/Users/Test/Desktop/Project/test.py", "C:/Users/Test/Desktop", testRoot))
    assert [InputOutput(Path("C:/Users/Test/Desktop/Project"), Path("C:/Users/Test/Desktop/Project"))] == list(get_input_output_paths("C:/Users/Test/Desktop/Project", "C:/Users/Test/Desktop", testRoot))

# Generated at 2022-06-12 03:26:55.245744
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:27:02.828963
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/home/test/test.py', '/home/test/output.py', None) == \
        [InputOutput(Path('/home/test/test.py'), Path('/home/test/output.py'))]
    assert get_input_output_paths('/home/test/test.py', '/home/test/output', None) == \
        [InputOutput(Path('/home/test/test.py'), Path('/home/test/output/test.py'))]
    assert get_input_output_paths('/home/test', '/home/test/output', None) == \
        [InputOutput(Path('/home/test/test.py'), Path('/home/test/output/test.py'))]

# Generated at 2022-06-12 03:27:09.856656
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    assert isinstance(list(get_input_output_paths('test/test_files/foo.py',\
        'test/test_files/output', 'test/test_files')), list)
    assert isinstance(list(get_input_output_paths('test/test_files/foo',\
        'test/test_files/output', 'test/test_files')), list)
    assert len(list(get_input_output_paths('test/test_files/foo.py',\
        'test/test_files/output', 'test/test_files'))) == 1

# Generated at 2022-06-12 03:27:17.116148
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def _assert(input_, output, root, expected):
        assert list(get_input_output_paths(input_, output, root)) == expected
    # Test 1
    _assert('foo.py', 'output', None, [
        InputOutput(Path('foo.py'), Path('output/foo.py'))])
    # Test 2
    _assert('foo.py', 'output/foo.py', None, [
        InputOutput(Path('foo.py'), Path('output/foo.py'))])
    # Test 3
    _assert('/path/to/foo.py', 'output', None, [
        InputOutput(Path('/path/to/foo.py'), Path('output/foo.py'))])
    # Test 4

# Generated at 2022-06-12 03:27:24.213556
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:27:29.547007
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths"""
    import tempfile
    # test case both file ends with py
    input_ = tempfile.mktemp(prefix='input', suffix='.py')
    output = tempfile.mktemp(prefix='output', suffix='.py')
    _root = tempfile.mktemp(prefix='root')
    input_path = Path(input_)
    output_path = Path(output)
    root_path = Path(_root)
    input_path.touch()
    output_path.touch()
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(input_=input_path,
                               output=output_path,
                               root=root_path)
    # test case input file doesn't exists