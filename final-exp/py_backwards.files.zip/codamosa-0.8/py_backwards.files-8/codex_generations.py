

# Generated at 2022-06-12 03:18:12.827111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Should raise InvalidInputOutput if input is not .py and output is .py
    try:
        for _ in get_input_output_paths('', '', ''):
            assert False
    except InvalidInputOutput:
        assert True

    # Should raise InvalidInputOutput if input is .py and output is not .py
    try:
        for _ in get_input_output_paths('', '.py', ''):
            assert False
    except InvalidInputOutput:
        assert True

    # Should raise InputDoesntExists if input doesnt exist
    try:
        for _ in get_input_output_paths('', '', ''):
            assert False
    except InputDoesntExists:
        assert True

# Test that get_input_output_paths generates expected InputOutput pair
    # Test if output is directory
    input_path

# Generated at 2022-06-12 03:18:20.523360
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # InvalidInputOutput
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('/usr/bin','/usr/bin/out.py',None)
    # InputDoesntExists
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths('/usr/bin/idea/input.py','/usr/bin/idea','/usr/bin/idea')
    # input is a python file
    output = get_input_output_paths('/usr/bin','out.py',None)
    assert list(output) == [InputOutput(Path('/usr/bin'), Path('out.py'))]
    # input is a directory

# Generated at 2022-06-12 03:18:29.237794
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    current_path = Path(__file__).parent
    expected = InputOutput(current_path.joinpath('test_get_input_output_path1/abc.py'),
                           current_path.joinpath('test_get_input_output_path1/abc_output.py'))
    test_input = 'test_get_input_output_path1/abc.py'
    test_output = 'test_get_input_output_path1/abc_output.py'
    assert expected == next(get_input_output_paths(test_input, test_output, None))

    expected2 = InputOutput(current_path.joinpath('test_get_input_output_path2/abc.py'),
                            current_path.joinpath('test_get_input_output_path2/abc.py'))
   

# Generated at 2022-06-12 03:18:35.457698
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = list(get_input_output_paths(
        '/home/eib/PycharmProjects/autopep8',
        '/home/eib/PycharmProjects/autopep8_mod',
        None
    ))

# Generated at 2022-06-12 03:18:45.651592
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing the get_input_output_paths function."""
    def test_case(input_: str, output: str):
        return get_input_output_paths(input_, output, None)

    assert next(test_case('/a', '/b')) == InputOutput(Path('/a/__init__.py'), Path('/b/__init__.py'))
    assert next(test_case('/a/__init__.py', '/b')) == InputOutput(Path('/a/__init__.py'), Path('/b/__init__.py'))
    assert next(test_case('/a/__init__.py', '/b/__init__.py')) == InputOutput(Path('/a/__init__.py'), Path('/b/__init__.py'))
   

# Generated at 2022-06-12 03:18:54.652956
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """ Test get_input_output_paths function """
    import tempfile
    with tempfile.TemporaryDirectory() as  source_path:
        with tempfile.TemporaryDirectory() as  test_path:
            os.system(f"touch {os.path.join(source_path,'test1.py')}")
            os.system(f"touch {os.path.join(source_path,'test2.py')}")
            # Test for directory without root
            res = list(get_input_output_paths(source_path, test_path, None))
            assert len(res) == 2
            assert res[0].input_path.name == 'test1.py'
            assert res[0].output_path.name == 'test1.py'

# Generated at 2022-06-12 03:19:00.567576
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    cwd = Path(__file__).parent.resolve()
    tmp = cwd.joinpath('_tmp')
    code = tmp.joinpath('code.py')
    other = tmp.joinpath('code_other.py')
    assert list(get_input_output_paths(str(code), str(other), str(tmp))) == [
        InputOutput(
            Path(str(code)),
            Path(str(other)))]
    assert list(get_input_output_paths(str(code), str(other), None)) == [
        InputOutput(
            Path(str(code)),
            Path(str(other)))]

# Generated at 2022-06-12 03:19:08.806288
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # yields input output pairs
    input_paths = [
        Path('test_data', 'child1.py'),
        Path('test_data', 'child2.py'),
    ]
    output_paths = [
        Path('test_output', 'child1.py'),
        Path('test_output', 'child2.py'),
    ]
    inputs_outputs = list(get_input_output_paths(
        'test_data', 'test_output', None))
    inputs, outputs = zip(*inputs_outputs)
    assert inputs == input_paths
    assert outputs == output_paths

    # raises InvalidInputOutput when input is dir, output is not

# Generated at 2022-06-12 03:19:17.098831
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test_data/test_file_1.py',
                                       'test_data/test_output_directory')) == [
        InputOutput(Path('test_data/test_file_1.py'),
                    Path('test_data/test_output_directory')/'test_file_1.py'),
    ]


# Generated at 2022-06-12 03:19:22.158392
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the function get_input_output_paths."""
    input_ = "./input.py"
    output = "./output"
    root = "./"
    result = [InputOutput(Path('./input.py'), Path('./output/input.py'))]
    assert list(get_input_output_paths(input_, output, root)) == result

# Generated at 2022-06-12 03:19:42.032313
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/home/user/bar.py', '/home/user/bar.py', '/home/user')) == [InputOutput(Path('/home/user/bar.py'), Path('/home/user/bar.py'))]

    assert list(get_input_output_paths('/home/user/bar.py', '/home/user/out', '/home/user')) == [InputOutput(Path('/home/user/bar.py'), Path('/home/user/out/bar.py'))]


# Generated at 2022-06-12 03:19:50.871427
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('setup.py', './', None)) == [
        InputOutput(Path('setup.py'), Path('setup.py'))]
    assert list(get_input_output_paths('dummy.py', './', None)) == [
        InputOutput(Path('dummy.py'), Path('dummy.py'))]
    assert list(get_input_output_paths('./tests/data.py', './', None)) == [
        InputOutput(Path('./tests/data.py'), Path('./tests/data.py'))]

    assert list(get_input_output_paths('setup.py', './', '')) == [
        InputOutput(Path('setup.py'), Path('setup.py'))]

# Generated at 2022-06-12 03:19:57.494226
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    def assert_raises(*args, **kwargs):
        with pytest.raises(*args, **kwargs):
            get_input_output_paths(*args, **kwargs)
    assert_raises(InvalidInputOutput, 'test_file', 'test_file.py')
    assert_raises(InputDoesntExists, 'doesnt_exist', 'test_file')

    # Normal usage
    gen = get_input_output_paths('test/input', 'test/output', None)
    result = list(gen)
    assert len(result) == 1
    assert result[0].input.name == result[0].output.name == 'test_file.py'
    assert result[0].input.parent.name == 'input'
    assert result

# Generated at 2022-06-12 03:20:06.823764
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:20:16.325543
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    here = Path(__file__).parent
    root = here.joinpath('data/' + 'test_root')
    input_ = root.joinpath('test_input.py')
    output = root.parent
    result = get_input_output_paths(input_, output, root)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0].input.name == 'test_input.py'
    assert result[0].output.name == 'test_input.py'
    assert result[0].output.parent.name == '__pycache__'
    assert result[0].output.parent.parent.name == 'data'
    assert result[0].output.parent.parent.parent.name == 'tests'
    assert result[0].output.parent.parent.parent.parent

# Generated at 2022-06-12 03:20:22.387396
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_path = Path('tests')
    assert list(get_input_output_paths(
        test_path,
        test_path,
        'tests')) == [
            InputOutput(Path('tests/test1.py'), Path('tests/test1.py')),
            InputOutput(Path('tests/test2.py'), Path('tests/test2.py')),
            InputOutput(Path('tests/test_with_ast.py'), Path('tests/test_with_ast.py')),
            InputOutput(Path('tests/test_with_exec.py'), Path('tests/test_with_exec.py'))]

# Generated at 2022-06-12 03:20:31.645278
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:20:37.182343
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmp_input = tmpdir.joinpath('input')
        tmp_output = tmpdir.joinpath('output')
        tmp_input.mkdir()
        tmp_output.mkdir()
        tmp_input_pyfile = tmp_input.joinpath('file.py')
        tmp_input_pyfile.touch()
        tmp_output_pyfile = tmp_output.joinpath('file.py')
        tmp_output_pyfile.touch()



# Generated at 2022-06-12 03:20:47.252872
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths"""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    import os
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        # Prepare test data
        input_test = os.path.join(td, 'a.py')
        open(input_test, 'a').close()
        output_test = os.path.join(td, 'b.py')
        open(output_test, 'a').close()
        output_test2 = os.path.join(td, 'c.py')
        open(output_test2, 'a').close()

        # test "get_input_output_paths" without root.

# Generated at 2022-06-12 03:20:54.634282
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "./tests/input"
    output = "./tests/output"
    root = None
    paths = get_input_output_paths(input_, output, root)
    #make sure path is created
    assert(Path("./tests/output/inputpy/input.py").exists())
    #make sure path is created
    assert(Path("./tests/output/inputpy/init.py").exists())
    #make sure class is created
    assert(Path("./tests/output/inputpy/classes/class.py").exists())

    input_ = "./tests/input/inputpy"
    output = "./tests/output2"
    root = None
    paths = get_input_output_paths(input_, output, root)
    #make sure file is created

# Generated at 2022-06-12 03:21:27.596142
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert sorted(get_input_output_paths('migrations', 'migrations2', None)) == sorted(
        [
            InputOutput(
                Path('migrations/__init__.py'),
                Path('migrations2/__init__.py')
            ),
            InputOutput(
                Path('migrations/test.py'),
                Path('migrations2/test.py')
            ),
        ])

    assert sorted(get_input_output_paths('migrations/__init__.py', 'migrations2/__init__.py', None)) == sorted(
        [
            InputOutput(
                Path('migrations/__init__.py'),
                Path('migrations2/__init__.py')
            ),
        ])


# Generated at 2022-06-12 03:21:37.092378
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InvalidInputOutput):
        get_input_output_paths('input', 'output.py', 'root')

    with raises(InputDoesntExists):
        get_input_output_paths('./fake_input', './output.py', './root')

    assert list(get_input_output_paths('./input', './output.py', './root')) == \
        [InputOutput(Path('./input'), Path('./output.py'))]

    assert list(get_input_output_paths('./input', './output', './root')) == \
        [InputOutput(Path('./input'), Path('./output/input.py'))]


# Generated at 2022-06-12 03:21:44.273778
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = get_input_output_paths("unit_test_folder/test_file.py",
                                          "unit_test_folder/output_file.py",
                                          "unit_test_folder")
    input_path = None
    output_path = None
    for input_output_tuple in input_output:
        input_path, output_path = input_output_tuple

    assert input_path == Path("unit_test_folder/test_file.py")
    assert output_path == Path("unit_test_folder/output_file.py")

    input_output = get_input_output_paths("unit_test_folder/test_file.py",
                                          "unit_test_folder/output_directory/",
                                          "unit_test_folder")
    input_path

# Generated at 2022-06-12 03:21:52.096305
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    paths = list(get_input_output_paths('test_data/test_data_file_py.py',
                                        'output/test_data/'))
    assert len(paths) == 1
    assert paths[0].input == Path("test_data/test_data_file_py.py")
    assert paths[0].output == Path("output/test_data/test_data_file_py.py")

    paths = list(get_input_output_paths('test_data/',
                                        'output/test_data/'))
    assert len(paths) == 1
    assert paths[0].input == Path("test_data/test_data_file_py.py")

# Generated at 2022-06-12 03:21:58.464941
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) ==\
        [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.pyc', 'b.py', None)) ==\
        [InputOutput(Path('a.pyc'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b.pyc', None)) ==\
        [InputOutput(Path('a.py'), Path('b.pyc'))]
    assert list(get_input_output_paths('a.py', 'b', None)) ==\
        [InputOutput(Path('a.py'), Path('b/a.py'))]

# Generated at 2022-06-12 03:22:06.815158
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    for test_case in json.load(open(os.path.join(os.path.dirname(__file__),
                                                 'test_data/test_get_input_output_paths.json')))['cases']:
        if test_case['expected']['error'] and 'exception' not in test_case['expected']:
            with pytest.raises(InvalidInputOutput):
                for path_pair in get_input_output_paths(test_case['in']['input'],
                                                        test_case['in']['output'],
                                                        test_case['in'].get('root')):
                    pass

# Generated at 2022-06-12 03:22:13.150291
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('p1.py', 'p1.py', '.')) == \
        [InputOutput(Path('p1.py'), Path('p1.py'))]
    assert list(get_input_output_paths('/home/p1.py', '/home/p1.py', '.')) == \
        [InputOutput(Path('/home/p1.py'), Path('/home/p1.py'))]
    assert list(get_input_output_paths('/home/', '/home/', '.')) == \
        [InputOutput(Path('/home/p1.py'), Path('/home/p1.py'))]

# Generated at 2022-06-12 03:22:20.120583
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    
    print("Performing default unit test...")
    #Unit test for function get_input_output_paths
    #creating a temporary directory for testing
    temp_dir = tempfile.TemporaryDirectory()
    # Points to the directory created
    cur_dir = temp_dir.name
    # Creating a sample py file
    sample_input_path = os.path.join(cur_dir, 'sample.py')
    # Creating an output file
    sample_output_path = os.path.join(cur_dir, 'output')
    # Creating the output 
    sample_expected_path = os.path.join(cur_dir, 'output/sample.py')
    
    # Creating the sample.py file
    sample_file = open(sample_input_path, 'w')

# Generated at 2022-06-12 03:22:26.776916
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a.py', 'b.py', None) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert get_input_output_paths('a.py', 'b', None) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert get_input_output_paths('a', 'b', None) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert get_input_output_paths('a', 'b', 'a') == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-12 03:22:35.377663
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(prefix='fixture') as fixture_path:
        fixture_path = Path(fixture_path)
        foo_file = fixture_path / 'foo' / 'bar.py'
        foo_file.parent.mkdir()
        foo_file.touch()

        output_path = fixture_path / 'output.py'
        script_path = fixture_path / 'script.py'

        input_paths = get_input_output_paths(str(fixture_path), str(output_path), None)
        script_paths = get_input_output_paths(str(fixture_path), str(script_path), None)
        foo_paths = get_input_output_paths(str(foo_file), str(output_path), None)
        foo

# Generated at 2022-06-12 03:23:07.778676
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    input_path = Path(__file__).parent
    output_path = Path(__file__).parent.parent.joinpath('output')
    input_outputs = list(get_input_output_paths(input_path, output_path, None))
    assert any(
        (input_output.input_path.absolute() == Path(__file__)).all() for input_output in input_outputs)
    assert any(
        (input_output.output_path.absolute() == Path(__file__).parent.parent.joinpath('output/test/test_paths.py')).all() for input_output in input_outputs)

# Generated at 2022-06-12 03:23:15.567697
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test for function get_input_output_paths for an input and an output file
    inputOutput_1 = [InputOutput(Path('src/example.py'), Path('out/example.py'))]
    inputOutput_1_test = get_input_output_paths('src/example.py', 'out/example.py', 'src')
    assert list(inputOutput_1_test) == inputOutput_1

    # test for function get_input_output_paths for a directory and an output directory

# Generated at 2022-06-12 03:23:21.571520
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as dir:
        root = Path(dir)

        input_paths = [Path("foo1/foo2/input.py"),
                       Path("input.py"),
                       Path("input"),
                       Path("input/input.py"),
                       Path("input/input.py/output.py")]

# Generated at 2022-06-12 03:23:31.281767
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""

    # Case no input paths
    from alchemist.exceptions import InvalidInputOutput, InputDoesntExists
    from alchemist.types import InputOutput
    try:
        get_input_output_paths('', '', None)
        assert False
    except InputDoesntExists:
        pass

    # Case invalid input paths
    try:
        get_input_output_paths('doesnt-exist', 'output', None)
        assert False
    except InputDoesntExists:
        pass

    # Case invalid input/output paths
    try:
        get_input_output_paths('input.py', 'doesnt-exist', None)
        assert False
    except InputDoesntExists:
        pass

    # Case single input/output paths
    assert next

# Generated at 2022-06-12 03:23:35.363739
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/home/data/src'
    output = '/home/data'
    root = '/home/data'
    result = get_input_output_paths(input_, output, root)
    assert result[0] == InputOutput(Path('/home/data/src'), Path('/home/data'))

# Generated at 2022-06-12 03:23:42.412658
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("foo/bar.py", "bar/baz.py", None)) == [InputOutput(Path("foo/bar.py"), Path("bar/baz.py"))]
    assert list(get_input_output_paths("foo.py", "bar/baz.py", None)) == [InputOutput(Path("foo.py"), Path("bar/baz.py/foo.py"))]
    assert list(get_input_output_paths("foo/bar.py", "bar.py", None)) == [InputOutput(Path("foo/bar.py"), Path("bar.py"))]

# Generated at 2022-06-12 03:23:49.078395
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    # Test: input/output
    io1 = list(get_input_output_paths(
               input_="./foo.py", output="./bar.py", root=None))
    assert io1[0].input_.name == "foo.py"
    assert io1[0].output_.name == "bar.py"
    
    # Test: input/directory
    io2 = list(get_input_output_paths(
               input_="./foo.py", output="./bar/", root=None))
    assert io2[0].input_.name == "foo.py"
    assert io2[0].output_.name == "foo.py"
    assert io2[0].output_.parent.name == "bar"

    # Test: input

# Generated at 2022-06-12 03:23:52.501334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # setup:
    input_ = '/Users/a/path'
    output = '/Users/a/output'
    root = '/Users/a'

    # Exercise:
    actual = list(get_input_output_paths(input_, output, root))

    # Verify:
    expected = [
        InputOutput(Path(input_), Path(output)),
    ]
    assert expected == actual



# Generated at 2022-06-12 03:24:00.167898
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    cwd = os.getcwd()

    # Test single file
    #   from single file to single file
    assert list(get_input_output_paths(cwd + '/test_get_input_output_paths.py',
                                  cwd + '/test_get_input_output_paths.py', None)) == \
           [InputOutput(Path(cwd + '/test_get_input_output_paths.py'), Path(cwd + '/test_get_input_output_paths.py'))]

    #   from single file to directory

# Generated at 2022-06-12 03:24:05.840933
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Testing case when input is a directory
    assert list(
        get_input_output_paths(
            input_='./input',
            output='./output',
            root=None,
        )
    ) == [
        InputOutput(Path('./input/a.py'), Path('./output/a.py')),
        InputOutput(Path('./input/b/b.py'), Path('./output/b/b.py')),
    ]

    # Testing case when input is a python file

# Generated at 2022-06-12 03:24:56.980145
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .exceptions import InvalidInputOutput
    with pytest.raises(InvalidInputOutput) as ex:
        get_input_output_paths('a', 'a', None)


# Generated at 2022-06-12 03:25:03.586594
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    input_ = 'source/app/app2/a.py'
    output = 'build/app/app2/'
    root = 'source/app'

    # When
    input_output_paths = list(get_input_output_paths(input_, output, root))

    # Then
    assert len(input_output_paths) == 1
    assert input_output_paths[0].input == 'source/app/app2/a.py'
    assert input_output_paths[0].output == 'build/app/app2/a.py'


# Generated at 2022-06-12 03:25:10.352083
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    this unit test checks if the function get_input_output_paths()
    works as expected
    """
    # get_input_output_paths is tested with valid input
    input_ = './ahmad/ahmad.py'
    output = './output/'
    root = None
    assert list(get_input_output_paths(input_, output, root)) == [InputOutput(Path('./ahmad/ahmad.py'), Path('./output/ahmad.py'))]

    # get_input_output_paths is tested with invalid input
    input_ = './ahmad/ahmad.py'
    output = './output/ahmad.pyy'
    root = None

# Generated at 2022-06-12 03:25:18.997082
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path

    assert list(get_input_output_paths('a.py', 'b.py', None))\
        == [InputOutput(Path('a.py'), Path('b.py'))]

    assert list(get_input_output_paths('a', 'b', None))\
        == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

    assert list(get_input_output_paths('a', 'b', 'a'))\
        == [InputOutput(Path('a/a.py'), Path('b/a.py'))]


# Generated at 2022-06-12 03:25:26.638095
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit tests for get_input_output_paths."""
    test_path = Path(__file__)
    test_root = test_path.parent.parent.parent
    # ------ test inputs ------
    # test default paths
    input_outputs = get_input_output_paths(str(test_path), str(test_path), test_root)
    assert list(input_outputs)[0] == InputOutput(test_path, test_path)
    # test default paths with relative root
    input_outputs = get_input_output_paths(str(test_path), str(test_path), '.')
    assert list(input_outputs)[0] == InputOutput(test_path, test_path)
    # test custom paths
    input_ = test_path.parent / 'a_file.py'

# Generated at 2022-06-12 03:25:32.884440
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Tests two possible/expected cases"""
    # Case 1
    input_ = "C:\\Users\\me\\Desktop\\Python\\dirty-type-checker\\at-runtime\\"
    output = "C:\\Users\\me\\Desktop\\Python\\dirty-type-checker\\at-runtime\\output\\"
    root = None
    i, o = next(get_input_output_paths(input_, output, root))
    assert "C:\\Users\\me\\Desktop\\Python\\dirty-type-checker\\at-runtime\\main.py" \
           == str(i)
    assert "C:\\Users\\me\\Desktop\\Python\\dirty-type-checker\\at-runtime" \
           "\\output\\main.py" == str(o)

# Generated at 2022-06-12 03:25:40.416833
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    file1 = 'dir1/dir2/file.py'
    file2 = 'dir3/dir4/file.py'
    file3 = 'dir5/dir6/file.py'
    file_list = [file1, file2, file3]

    root = '/Users/user/Documents/project1/'
    p1 = Path('/Users/user/Documents/project1/p.py')
    p2 = Path('/Users/user/Documents/project1/p2.py')
    p3 = Path('/Users/user/Documents/project1/p3.py')
    p1_list = [p1, p2, p3]
    output1 = '/Users/user/Documents/project2/'
    output2 = '/Users/user/Documents/project2/'

# Generated at 2022-06-12 03:25:48.305488
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('app.py', 'app.exe', None))
    assert list(get_input_output_paths('app.py', 'app', None)) == [
        InputOutput(Path('app.py'), Path('app.py'))
    ]
    assert list(get_input_output_paths('src/app.py', 'dist', 'src')) == [
        InputOutput(Path('src/app.py'), Path('dist/app.py'))
    ]
    assert list(get_input_output_paths('src/app.py', 'dist/app.py', None)) == [
        InputOutput(Path('src/app.py'), Path('dist/app.py'))
    ]

# Generated at 2022-06-12 03:25:55.277111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory

    def paths_equal(first: str, second: str) -> bool:
        try:
            from pathlib import Path
        except ImportError:
            from pathlib2 import Path  # type: ignore
        return Path(first) == Path(second)

    with TemporaryDirectory() as temp_dir:
        project_dir = Path(temp_dir)
        conf_module = project_dir.joinpath('conf.py')
        conf_module.touch()
        submodule = project_dir.joinpath('submodule.py')
        submodule.touch()
        subdir = project_dir.joinpath('subdir')
        subpkg = subdir.joinpath('__init__.py')
        subpkg.touch()
        subpkg_module = subdir.joinpath('subpkg_module.py')


# Generated at 2022-06-12 03:26:01.195215
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = get_input_output_paths(
        '../test',
        '/home/output',
        '../test'
    )
    paths = list(paths)
    assert isinstance(paths[0].input, Path)
    assert isinstance(paths[0].output, Path)
    assert paths[0].input.name == 'main.py'
    assert paths[0].output.name == 'main.py'

# Generated at 2022-06-12 03:27:46.437411
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_data = {
        "input": "tests/data/input",
        "output": "tests/data/output",
        "root": None,
        "expected": [
            InputOutput(Path("tests/data/input/module.py"), Path("tests/data/output/module.py")),
            InputOutput(Path("tests/data/input/submodule.py"), Path("tests/data/output/submodule.py")),
            InputOutput(Path("tests/data/input/subpackage/subsubmodule.py"), Path("tests/data/output/subpackage/subsubmodule.py"))
        ]
    }
    for result in get_input_output_paths(test_data["input"], test_data["output"], test_data["root"]):
        assert result in test_data["expected"]

# Unit test

# Generated at 2022-06-12 03:27:52.522407
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', 'test'))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test2.py', 'test.txt', 'test'))

    input_output = get_input_output_paths('test3.py', 'test.txt', 'test')
    assert input_output == [InputOutput(Path('test3.py'), Path('test.txt'))]

    input_output = get_input_output_paths('test', 'test2', '')

# Generated at 2022-06-12 03:27:54.615250
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    import pytest

    class MyException(Exception):
        """
        Create Exception class.
        """

    with pytest.raises(MyException):
        raise MyException("My Exception")

# Generated at 2022-06-12 03:28:01.805237
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths(
        input_='./tests/data/files/', output='./tests/data/files_output/'))
    assert len(paths) == 2

    assert paths[0][0] == Path('./tests/data/files/test_file.py')
    assert paths[0][1] == Path('./tests/data/files_output/test_file.py')

    assert paths[1][0] == Path('./tests/data/files/test_package/__init__.py')
    assert paths[1][1] == Path('./tests/data/files_output/test_package/__init__.py')