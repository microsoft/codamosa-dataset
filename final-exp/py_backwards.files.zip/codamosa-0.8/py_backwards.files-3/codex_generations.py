

# Generated at 2022-06-12 03:18:23.943412
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "/home/jkennedy/Documents/Projects/cis4930/cis4930_assignment3/q3_2/q3_2.py"
    output = "/home/jkennedy/Documents/Projects/cis4930/cis4930_assignment3/q3_2/q3_2.py"
    root = None

    paths = get_input_output_paths(input_, output, root)
    temp = next(paths)
    assert(temp[0].name == "q3_2.py")

# Generated at 2022-06-12 03:18:32.079994
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("foo.py", "bar.py", None)) == [
        InputOutput(Path("foo.py"), Path("bar.py"))]
    assert list(get_input_output_paths("foo/bar/baz.py", "qoo.py", None)) == [
        InputOutput(Path("foo/bar/baz.py"), Path("qoo.py"))]
    assert list(get_input_output_paths("foo/bar.py", "qoo/bar.py", None)) == [
        InputOutput(Path("foo/bar.py"), Path("qoo/bar.py"))]

# Generated at 2022-06-12 03:18:41.297054
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_function = get_input_output_paths

    # Test if an error is raised when extensions are not equal
    with pytest.raises(InvalidInputOutput):
        test_function('./foo.txt', './bar.py', './')

    # Test if an error is raised when an input file does not exist
    #with pytest.raises(InputDoesntExists):
    #    test_function('./foo.txt', './bar.txt', './')

    # Test single file import/export
    input_output_list = test_function('./foo.py', './bar.py', './')
    assert len(list(input_output_list)) == 1
    input_output = input_output_list[0]

# Generated at 2022-06-12 03:18:49.061765
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_list = ['a.py', 'a/a.py', 'a/b/a.py', 'b.py', 'b/a.py', 'b/b.py']
    output_list = ['b', 'b/', 'b/',
                   'b.py', 'b.py/a.py', 'b.py/b.py']
    for i in range(len(input_list)):
        input_ = input_list[i]
        output = output_list[i]
        assert get_input_output_paths(input_, output, None)



# Generated at 2022-06-12 03:18:53.828134
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_get_input_output_paths_input_and_output_both_py_files()
    test_get_input_output_paths_input_is_py_file_output_is_dir()
    test_get_input_output_paths_input_is_dir_output_is_dir()
    test_get_input_output_paths_input_is_dir_output_is_dir_with_root()


# Generated at 2022-06-12 03:19:01.161509
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths."""
    # testing normal cases (with only files, with directory and file)
    input_ = "inputs/testcases.py"
    output = "outputs/testcases.py"
    root = "inputs"
    assert tuple(get_input_output_paths(input_, output, root)) == \
           (InputOutput(Path(input_), Path(output)),)

    # testing invalid cases (directory for directory and file for file)
    input_ = "inputs"
    output = "outputs"
    root = "inputs"
    try:
        tuple(get_input_output_paths(input_, output, root))
    except InvalidInputOutput:
        assert True
    else:
        assert False

    # testing invalid cases (file-input does not

# Generated at 2022-06-12 03:19:09.821780
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # The root doesn't exist
    assert get_input_output_paths('test.py', 'out', 'bad root') == []

    # Input is a file and output is a directory
    assert get_input_output_paths('test.py', '/tmp', '/tmp2/') == [InputOutput('/tmp/test.py', '/tmp/test.py')]

    # Input is a file and output is a file
    assert get_input_output_paths('test.py', '/tmp/test2.py', None) == [InputOutput('test.py', '/tmp/test2.py')]

    # Input is a directory and output is a file
    assert get_input_output_paths('test', '/tmp/test.py', None) == []

    # Input is a directory and output is a directory
    assert get_input

# Generated at 2022-06-12 03:19:12.419379
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(input_ = 'test_input',
                                  output = 'test_output',
                                  root = None) == InputOutput(Path('test_input'), Path('test_output'))

# Generated at 2022-06-12 03:19:21.078514
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test a single file
    input_ = '/Users/userA/test/test.py'
    output = '/Users/userA/testOut'
    expected = [InputOutput(Path('/Users/userA/test/test.py'),
                            Path('/Users/userA/testOut/test.py'))]
    assert get_input_output_paths(input_, output, None) == expected

    input_ = '/Users/userA/test/test.py'
    output = '/Users/userA/testOut/test.py'
    expected = [InputOutput(Path('/Users/userA/test/test.py'),
                            Path('/Users/userA/testOut/test.py'))]
    assert get_input_output_paths(input_, output, None) == expected

    #

# Generated at 2022-06-12 03:19:29.978889
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(input_='test_input', output='test_output', root=None)) == \
        [InputOutput(input_path=Path('test_input'), output_path=Path('test_output'))]

    assert list(get_input_output_paths(input_='test_input', output='test_output/test_input.py', root=None)) == \
        [InputOutput(input_path=Path('test_input'), output_path=Path('test_output/test_input.py'))]


# Generated at 2022-06-12 03:19:44.414134
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # create output directory
    output_dir = Path('output')
    output_dir.mkdir()
    # create input directory
    input_dir = Path('input')
    input_dir.mkdir()
    # create a file in the input directory
    input_file = input_dir.joinpath('test.py')
    open(input_file, 'x')

    # test case 1
    result1 = get_input_output_paths(input_=input_dir, output=output_dir, root=input_dir)
    assert next(result1) == InputOutput(input_file, output_dir.joinpath('test.py'))

    # test case 2
    result2 = get_input_output_paths(input_=input_file, output=output_dir, root=input_dir)

# Generated at 2022-06-12 03:19:49.357211
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_root = Path('/test/root')
    test_input = Path('/test/root/module.py')
    test_output = Path('/test/root/output/')

    result = get_input_output_paths(test_input, test_output, test_root)
    output_path = next(result)

    assert output_path.input == test_inp

# Generated at 2022-06-12 03:19:56.376723
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test when there is only one input file and one output file
    (input_path, output_path) = get_input_output_paths('../tests/example.py', 'out.py', None).__next__()
    assert (input_path.name == 'example.py')
    assert (input_path.parent.name == 'tests')
    assert (output_path.name == 'out.py')
    assert (output_path.parent.name == '.')

    # test when there is only one input file and one output directory
    (input_path, output_path) = get_input_output_paths('../tests/example.py', 'out', None).__next__()
    assert (input_path.name == 'example.py')
    assert (input_path.parent.name == 'tests')

# Generated at 2022-06-12 03:20:05.725151
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('input', 'output', None)) == [
        InputOutput(Path('input'), Path('output'))
    ]

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(
            'foo', 'output', None))

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            'input.py', 'output', None))

    assert list(get_input_output_paths(
        'input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    with open('input.py', 'w') as input_:
        input_.write('# coding: utf-8\nfoo')

# Generated at 2022-06-12 03:20:15.033611
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""

    if Path('tests_files/get_input_output_paths/in').exists():
        shutil.rmtree('tests_files/get_input_output_paths/in')
    shutil.copytree(
        'tests_files/get_input_output_paths/in_origin',
        'tests_files/get_input_output_paths/in')
    if Path('tests_files/get_input_output_paths/out').exists():
        shutil.rmtree('tests_files/get_input_output_paths/out')

# Generated at 2022-06-12 03:20:22.563596
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    inputs = [
        ('a', 'b'),
        ('a.py', 'b'),
        ('a.py', 'b.py'),
        ('a', 'b', ''),
        ('a.py', 'b', ''),
        ('a.py', 'b.py', ''),
        ('a', 'b', None),
        ('a.py', 'b', None),
        ('a.py', 'b.py', None),
        ('a', 'b', 'root'),
        ('a.py', 'b', 'root'),
        ('a.py', 'b.py', 'root'),
        ('root/a', 'b', 'root'),
        ('root/a.py', 'b', 'root'),
        ('root/a.py', 'b.py', 'root'),
    ]

# Generated at 2022-06-12 03:20:31.644371
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    results = get_input_output_paths('dummy/input', 'dummy/output', 'dummy')
    for result in results:
        assert result.input_path.match('**/*.py')
        assert result.output_path.match('**/*.py')

    results = get_input_output_paths('dummy/input/test.py', 'dummy/output', 'dummy/input')
    for result in results:
        assert result.input_path.match('**/*.py')
        assert result.output_path.match('**/*.py')

    results = get_input_output_paths('dummy/input/test.py', 'dummy/output/test.py', 'dummy/input')

# Generated at 2022-06-12 03:20:36.821225
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test
    """
    input_ = os.path.join('tests', 'resources', 'file.py')
    output = os.path.join('tests', 'resources', 'test_file.py')
    root = os.path.join('tests', 'resources')
    input_outputs = [io for io in get_input_output_paths(input_, output, root)]
    assert input_outputs[0].input.name == 'file.py'
    assert input_outputs[0].output.name == 'test_file.py'

# Generated at 2022-06-12 03:20:47.249871
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test when there's no error
    input_output_paths = list(get_input_output_paths('test', "output", None))
    assert len(input_output_paths) == 3
    assert input_output_paths[0] == InputOutput(Path('test/file1.py'),
                                                Path('output/file1.py'))
    assert input_output_paths[1] == InputOutput(Path('test/file2.py'),
                                                Path('output/file2.py'))
    assert input_output_paths[2] == InputOutput(Path('test/file3.py'),
                                                Path('output/file3.py'))
    input_output_paths = list(get_input_output_paths('test/', "output/", None))
    assert len

# Generated at 2022-06-12 03:20:54.634060
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        'test/input', 'test/output', 'test/input')) == [
            InputOutput(Path('test/input/test.py'),
                        Path('test/output/test.py')),
            InputOutput(Path('test/input/child/child.py'),
                        Path('test/output/child/child.py'))]

    assert list(get_input_output_paths(
        'test/input/test.py', 'test/output', 'test/input')) == [
            InputOutput(Path('test/input/test.py'),
                        Path('test/output/test.py'))]


# Generated at 2022-06-12 03:21:14.810022
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print(get_input_output_paths('/var/lib/codeintel', '/var/lib/codeintel/out'))
    print(get_input_output_paths('/var/lib/codeintel', '/var/lib/out'))
    print(get_input_output_paths('/var/lib/codeintel', '/var/lib/out', '/var/lib'))
    print(get_input_output_paths('/var/lib/codeintel', '/var/lib/codeintel/out', '/var/lib'))
    print(get_input_output_paths('/var/lib/codeintel/test1.py', '/var/lib/out', '/var/lib'))

# Generated at 2022-06-12 03:21:24.597316
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing the get_input_output_paths function"""

    assert (list(get_input_output_paths(input_ = "input", output = "output", root = ".")) ==
            [InputOutput(Path("input.py"), Path("output.py"))])

    assert (list(get_input_output_paths(input_ = "input.py", output = "output.py", root = ".")) ==
            [InputOutput(Path("input.py"), Path("output.py"))])

    assert (list(get_input_output_paths(input_ = "input.py", output = "output", root = None)) ==
            [InputOutput(Path("input.py"), Path("output/input.py"))])


# Generated at 2022-06-12 03:21:30.599497
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    input_ = './tests/data/input'
    output = './tests/data/output'

    matches = [
        InputOutput(Path('tests/data/input/a.py'), Path('tests/data/output/a.py')),
        InputOutput(Path('tests/data/input/b.py'), Path('tests/data/output/b.py')),
        InputOutput(Path('tests/data/input/c/d/e.py'), Path('tests/data/output/c/d/e.py')),
    ]
    assert list(get_input_output_paths(input_, output, None)) == matches

# Generated at 2022-06-12 03:21:34.100101
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(Path("./pytrap/tests/test_pytrap.py").resolve(), Path("./pytrap/tests/mytest/test_pytrap.py").resolve(), './pytrap') is not None

# Generated at 2022-06-12 03:21:36.591323
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/test'
    output = '/test'
    root = ''
    assert get_input_output_paths(input_, output, root) is not None

# Generated at 2022-06-12 03:21:41.687677
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    my_input = "Data/MyData/"
    my_output = "Output/"
    assert get_input_output_paths(my_input, my_output, None)
    assert not get_input_output_paths(None, my_output, None)
    assert not get_input_output_paths(my_input, None, None)
    assert not get_input_output_paths(my_input, my_output, "")

# Generated at 2022-06-12 03:21:49.817879
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    import shutil

    def make_dir_structure(dir, files):
        with tempfile.TemporaryDirectory() as root:
            paths = []
            for f in files:
                path = Path(root).joinpath(dir, f)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch()
                paths.append(path)

            return paths

    def test_pair(input_, output, expected_pairs, root=None):
        if (len(expected_pairs) == 0):
            try:
                get_input_output_paths(input_, output, root)
                raise AssertionError("Expect input/output not valid")
            except InvalidInputOutput:
                pass

# Generated at 2022-06-12 03:21:56.352372
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:22:01.783943
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    from io import StringIO
    from contextlib import redirect_stdout
    from .utils import get_input_output_paths

    class Redirector(object):
        """Redirect stdout."""

        def __init__(self):
            """Init."""
            self.buf = StringIO()

        def __enter__(self):
            """Return buffer."""
            return redirect_stdout(self.buf)

        def __exit__(self, _type, value, traceback):
            """Do nothing."""
            pass

        def get_buffer(self):
            """Get buffer."""
            return self.buf


# Generated at 2022-06-12 03:22:09.396794
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'aa', None)) == [InputOutput(Path('a.py'), Path('aa'))]
    assert list(get_input_output_paths('dir', 'dir_out', None)) == [
        InputOutput(Path('dir/a.py'), Path('dir_out/a.py')),
        InputOutput(Path('dir/b.py'), Path('dir_out/b.py')),
        InputOutput(Path('dir/c.py'), Path('dir_out/c.py')),
    ]

# Generated at 2022-06-12 03:22:28.584367
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:22:36.538186
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('dir/dir/dir', 'dir/dir/dir', None)) == [
        InputOutput(Path('dir/dir/dir/dir'), Path('dir/dir/dir/dir/dir'))
    ]
    assert list(get_input_output_paths('dir/dir/dir', 'dir/dir/dir', 'dir/dir/dir')) == [
        InputOutput(Path('dir/dir/dir/dir'), Path('dir/dir/dir/dir'))
    ]
    assert list(get_input_output_paths('dir/dir/dir/dir', 'dir/dir/dir/dir', None)) == [
        InputOutput(Path('dir/dir/dir/dir'), Path('dir/dir/dir/dir'))
    ]

# Generated at 2022-06-12 03:22:40.203425
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a/a/a.py', 'x')) == [InputOutput(Path('a/a/a.py'), Path('x/a.py'))]
    assert list(get_input_output_paths('a.py', 'x')) == [InputOutput(Path('a.py'), Path('x/a.py'))]

# Generated at 2022-06-12 03:22:45.666761
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .types import InputOutput

    def assertEqualInputOutput(input_: str, output: str,
                               root: Optional[str] = None) -> None:
        paths = list(get_input_output_paths(input_, output, root))
        assert paths == [InputOutput(Path(input_), Path(output))]

    assertEqualInputOutput('a', 'b')
    assertEqualInputOutput('a.py', 'b.py')
    assertEqualInputOutput('a', 'b', 'c')
    assertEqualInputOutput('c/a', 'b', 'c')

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b')


# Generated at 2022-06-12 03:22:53.066469
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test root directory
    # - correct case
    files = [f for f in get_input_output_paths('tests/fixtures/directory_1', 'output', 'tests/fixtures')]
    assert files[0] == InputOutput(Path('tests/fixtures/directory_1/file_1.py'), Path('output/file_1.py'))
    assert files[1] == InputOutput(Path('tests/fixtures/directory_1/file_2.py'), Path('output/file_2.py'))
    assert files[2] == InputOutput(Path('tests/fixtures/directory_1/sub_directory_1/sub_file_1.py'), Path('output/sub_directory_1/sub_file_1.py'))

# Generated at 2022-06-12 03:22:59.803539
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .path import utils
    import pytest

    if utils.PY2:
        return

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('my/input.py', 'my/output.json', 'root')

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('my/unknown.py', 'my/output.py', 'root')

    assert list(get_input_output_paths('my/input.py', 'my/output.py', 'root')) == [
        InputOutput(Path('my/input.py'), Path('my/output.py'))
    ]


# Generated at 2022-06-12 03:23:08.204853
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    #Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.txt', 'test.py', None)
    #Test for non-existing-file input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)
    #Test for file-to-file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == \
        [InputOutput(Path('test.py'), Path('test.py'))]
    #Test for directory-to-file

# Generated at 2022-06-12 03:23:15.971002
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # First test: no root
    input_ = 'test/test_data/test_input/test_file1.py'
    output = 'test/test_data/test_output/test_file1.py'
    expected = [InputOutput(Path('test/test_data/test_input/test_file1.py'),
                            Path('test/test_data/test_output/test_file1.py'))]
    assert get_input_output_paths(input_, output, None) == expected
    # Test two
    input_ = 'test/test_data/test_input/'
    output = 'test/test_data/test_output/'

# Generated at 2022-06-12 03:23:21.798216
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from io import StringIO
    import sys
    import pytest

    old_stdout = sys.stdout
    sys.stdout = StringIO()

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/this/path/doesnt/exist',
                               'and/neither/does/this',
                               None)
        sys.stdout.getvalue()

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/this/path/exists/but/isnt/a.py',
                               '/and/neither/is/this',
                               None)
        sys.stdout.getvalue()


# Generated at 2022-06-12 03:23:31.381885
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'out', 'root')) == [InputOutput(
        Path('a.py'), Path('out/a.py'))]
    # test for handling of non-.py output files
    assert list(get_input_output_paths('a.py', 'out.txt', 'root')) == [InputOutput(
        Path('a.py'), Path('out.txt'))]
    assert list(get_input_output_paths('dir/a.py', 'out', 'root')) == [InputOutput(
        Path('dir/a.py'), Path('out/dir/a.py'))]

# Generated at 2022-06-12 03:24:02.936566
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))
    assert list(get_input_output_paths('a.py', 'b.py', 'c')) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('/x/a.py', 'b', 'c')) == [
        InputOutput(Path('/x/a.py'), Path('b/x/a.py'))
    ]


# Generated at 2022-06-12 03:24:11.386261
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths("./A/in.py", "./A/out.py", "./")
    except InvalidInputOutput as e:
        assert str(e) == "Invalid input/output files."
    except InputDoesntExists as e:
        assert str(e) == "Input file doesn't exist."

    get_input_output_paths("./A/in.py", "./A/", "./")
    get_input_output_paths("./A/", "./A/", "./")
    get_input_output_paths("./", "./A/", "./")

# Generated at 2022-06-12 03:24:19.506541
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    import tempfile
    import shutil
    import uuid

    # test with a normal file
    tempdir = tempfile.mkdtemp()
    a_name = uuid.uuid4().hex
    a = Path(tempdir).joinpath(a_name)
    a.touch()

    b = Path(tempdir).joinpath(uuid.uuid4().hex)
    io_pair = next(get_input_output_paths(str(a), str(b), None))
    assert io_pair.input == a
    assert io_pair.output == b
    shutil.rmtree(tempdir)

    # test with a directory
    tempdir = tempfile.mkdtemp()
    a_name = uuid.uuid4().hex


# Generated at 2022-06-12 03:24:28.241117
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    res_1 = list(get_input_output_paths(
        "tests/functional",
        "tests/tempoutput",
        None
    ))
    assert len(res_1) == 2, "There should be two input/output pairs"
    assert str(res_1[0].input_path) == "tests/functional/test_header_comment.py", "Input path 1 incorrect"
    assert str(res_1[0].output_path) == "tests/tempoutput/test_header_comment.py", "Output path 1 incorrect"
    assert str(res_1[1].input_path) == "tests/functional/__init__.py", "Input path 2 incorrect"
    assert str(res_1[1].output_path) == "tests/tempoutput/__init__.py", "Output path 2 incorrect"

   

# Generated at 2022-06-12 03:24:34.742585
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:24:42.459334
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    # Case: When input is a file and output is a file
    result = list(get_input_output_paths('examples/main.py', 'result.py', None))
    assert result == [InputOutput(Path('examples/main.py'), Path('result.py'))]
    # Case: When input is a file and output is a folder
    result = list(get_input_output_paths('examples/main.py', 'result', None))
    assert result == [InputOutput(Path('examples/main.py'), Path('result/main.py'))]
    # Case: When input is a folder
    result = list(get_input_output_paths('examples', 'result', None))

# Generated at 2022-06-12 03:24:51.294015
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    input_, output = 'input', 'output'
    root = '/home/mahdi/Projects/py2exe/tests'

    paths = list(get_input_output_paths(input_, output, root))


# Generated at 2022-06-12 03:24:56.650628
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Get input/output paths pairs with multiple inputs and single output
    paths = list(get_input_output_paths(
        input_='test/fixtures/input1',
        output='test/fixtures/output',
        root=None))
    assert paths == [
        InputOutput(
            Path('test/fixtures/input1/test1.py'),
            Path('test/fixtures/output/test1.py'))
    ]

    # Get input/output paths pairs with single input and single output
    paths = list(get_input_output_paths(
        input_='test/fixtures/input1/test1.py',
        output='test/fixtures/output',
        root=None))

# Generated at 2022-06-12 03:25:00.329962
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = get_input_output_paths(
        'input/example.py', 'output', None)
    assert str(list(result)[0].input) == 'input/example.py'
    assert str(list(result)[0].output) == 'output/example.py'



# Generated at 2022-06-12 03:25:08.332711
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    test_cases = [
        # input_, output, root, expected_results, expected_exception
        ('input.py', 'output/', None, [InputOutput('input.py', 'output/input.py')], None),
        ('input.py', 'output.py', None, [InputOutput('input.py', 'output.py')], None),
        ('input', 'output/', None, [InputOutput('input.py', 'output/input.py')], None),
        ('input', 'output', None, [InputOutput('input.py', 'output.py')], None),
    ]

    for test_case in test_cases:
        input_, output, root, expected_results, expected_exception = test_case

# Generated at 2022-06-12 03:26:05.585351
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:26:10.626102
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get input/output files pairs."""
    assert [InputOutput(Path('a.py'), Path('b.py'))] == list(
        get_input_output_paths('a.py', 'b.py', None))
    assert [InputOutput(Path('a.py'), Path('b/a.py'))] == list(
        get_input_output_paths('a.py', 'b', None))
    assert [InputOutput(Path('a.py'), Path('b/c.py'))] == list(
        get_input_output_paths('a.py', 'b/c.py', None))

# Generated at 2022-06-12 03:26:16.906111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Get input output paths pairs.
    """
    inputs = ['test/test_test_case.py', 'test']
    outputs = ['test/test_output', 'test2/test2_output']
    roots = ['', None]

    for input_ in inputs:
        for output in outputs:
            for root in roots:
                pairs = list(get_input_output_paths(input_, output, root))
                assert len(pairs) > 0
                for pair in pairs:
                    assert pair.input.exists()
                    assert not pair.output.exists()

# Generated at 2022-06-12 03:26:25.345223
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = get_input_output_paths('foo.py', 'output', None)
    assert isinstance(paths, list)

    input_output = paths[0]
    assert input_output.input.name == 'foo.py'
    assert input_output.input.parent.absolute() == os.getcwd()

    assert input_output.output.name == 'foo.py'
    assert input_output.output.parent.absolute() == os.getcwd()

    paths = get_input_output_paths('foo.py', 'output/', None)
    input_output = paths[0]
    assert input_output.output.parent.absolute() == os.path.abspath('output')

    paths = get_input_output_paths('foo', 'output', None)

# Generated at 2022-06-12 03:26:33.398524
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:26:41.195016
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./test/in/simple.py', './test/out/simple.py', root=None)) == [InputOutput(Path('./test/in/simple.py'), Path('./test/out/simple.py'))]
    assert list(get_input_output_paths('./test/in', './test/out', root=None)) == [InputOutput(Path('./test/in/simple.py'), Path('./test/out/simple.py'))]
    assert list(get_input_output_paths('./test/in', './test/out', root='./test')) == [InputOutput(Path('./test/in/simple.py'), Path('./test/out/in/simple.py'))]
    assert list

# Generated at 2022-06-12 03:26:48.874829
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/a/b/c.py', '/d/e/f.txt', None)
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/a/b/c.py', '/d/e/f.py', None)

    paths = list(get_input_output_paths('/a/b/c.py', '/d/e/f.py', None))
    assert paths == [InputOutput(Path('/a/b/c.py'), Path('/d/e/f.py'))]

    paths = list(get_input_output_paths('/a/b', '/d/e', None))

# Generated at 2022-06-12 03:26:55.974552
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    assert list(get_input_output_paths('input/a.py', 'output/a.py', None)) == [
        InputOutput(Path('input/a.py'), Path('output/a.py'))
    ]

    assert list(get_input_output_paths('input/a.py', 'output/b.py', None)) == [
        InputOutput(Path('input/a.py'), Path('output/b.py'))
    ]

    assert list(get_input_output_paths('input/a.py', 'output', None)) == [
        InputOutput(Path('input/a.py'), Path('output/a.py'))
    ]


# Generated at 2022-06-12 03:27:03.423948
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/foo/bar.py', '..', None) == \
        [InputOutput(Path('/foo/bar.py'), Path('../bar.py'))]
    assert get_input_output_paths('/foo/bar.py', '../out', None) == \
        [InputOutput(Path('/foo/bar.py'), Path('../out/bar.py'))]
    assert get_input_output_paths('/foo/bar.py', '../out.py', None) == \
        [InputOutput(Path('/foo/bar.py'), Path('../out.py'))]

# Generated at 2022-06-12 03:27:10.333823
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths('examples', '.', 'examples'))