

# Generated at 2022-06-12 03:17:54.692744
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('file.py', 'file.py', None) == [InputOutput(Path('file.py'), Path('file.py'))]
    assert get_input_output_paths('file.py', 'dir', None) == [InputOutput(Path('file.py'), Path('dir/file.py'))]
    assert get_input_output_paths('dir', 'dir', None) == [InputOutput(Path('dir/file1.py'), Path('dir/file1.py')), InputOutput(Path('dir/file2.py'), Path('dir/file2.py'))]

# Generated at 2022-06-12 03:18:01.154331
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input/output file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == \
           [InputOutput(Path('input.py'), Path('output.py'))]
    # Test input/output folder
    assert list(get_input_output_paths('input.py', 'output', None)) == \
           [InputOutput(Path('input.py'), Path('output/input.py'))]
    # Test input/output folder with root folder
    assert list(get_input_output_paths('input/input.py', 'output', 'input')) == \
           [InputOutput(Path('input/input.py'), Path('output/input.py'))]
    # Test input folder/output file
    with pytest.raises(InvalidInputOutput):
        get_

# Generated at 2022-06-12 03:18:05.355919
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('tests/data/a.py', 'output',
                                  'tests/data') == [InputOutput(Path('tests/data/a.py'), Path('output/a.py'))]
    input_paths = get_input_output_paths('tests/data', 'output', 'tests/data')
    expected_input_paths = [InputOutput(Path('tests/data/a.py'), Path('output/a.py')),
                            InputOutput(Path('tests/data/b.py'), Path('output/b.py'))]
    assert input_paths == expected_input_paths



# Generated at 2022-06-12 03:18:13.382769
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing get_input_output_paths"""
    test_output="output_file.py"
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("not_a_file", test_output, "")
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("file.py", test_output, "")
    paths = get_input_output_paths("file.py", test_output, "")
    assert next(paths).output_path == Path(test_output)
    assert next(paths).input_path == Path("file.py")
    assert next(paths).output_path == Path(test_output)
    assert next(paths) == None

# Generated at 2022-06-12 03:18:20.916831
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_path functions."""
    # Check if function raises InvalidInputOutput
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('/tmp', '/tmp', ''))

    # Check if functions raise InputDoesntExists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('/tmp.py', '/tmp', ''))

    # Input file given
    input_output_paths = list(get_input_output_paths('/tmp.py', '/tmp', ''))
    assert len(input_output_paths) == 1
    assert input_output_paths[0].input == Path('/tmp.py')
    assert input_output_paths[0].output == Path('/tmp')

   

# Generated at 2022-06-12 03:18:29.661592
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    io_list = [InputOutput(Path('a.py'), Path('b/a.py')),
               InputOutput(Path('aa.py'), Path('b/aa.py')),
               InputOutput(Path('aaa.py'), Path('b/aaa.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [io_list[0]]
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [io_list[0]]
    assert list(get_input_output_paths('a', 'b', None)) == io_list
    assert list(get_input_output_paths('a', 'b', 'a')) == io_list

# Generated at 2022-06-12 03:18:35.636901
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Check the behaviour of get_input_output_paths function."""
    this_file = Path(__file__)
    root = this_file.parent.parent

    assert list(get_input_output_paths(
        str(this_file), str(this_file.parent.parent), root=None)) == [
            InputOutput(this_file, this_file.parent.parent)]
    assert list(get_input_output_paths(
        str(this_file.parent), str(this_file.parent), root=None)) == [
            InputOutput(this_file, this_file)]

    assert list(get_input_output_paths(
        str(this_file), str(this_file.parent), root=str(root))) == [
            InputOutput(this_file, this_file.parent)]

# Generated at 2022-06-12 03:18:45.821776
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from textwrap import dedent
    import pytest

    # Case 1: Input and Output are the same python file
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('./a.py', './a.py', './a')

    # Case 2: Output extension is not .py
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('./a.py', './output', './')

    # Case 3: Input file doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('./notExists.py', './output', './')

    # Case 4: Input is

# Generated at 2022-06-12 03:18:54.766147
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # invalid input/output file paths
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('my_file.py', 'sub_dir/output.txt', '')

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('sub_dir/input.txt', 'sub_dir/output.py', '')


    # input file doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('sub_dir/input.txt', 'sub_dir/output.txt', '')


    # input file is a .py file
    # simple use case

# Generated at 2022-06-12 03:19:01.856255
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = './tests/data/in'
    output = './tests/data/out'
    root = None
    paths = list(get_input_output_paths(input_, output, root))
    assert paths[0].input == Path('./tests/data/in/foo.py')
    assert paths[1].input == Path('./tests/data/in/bar.py')
    assert paths[2].input == Path('./tests/data/in/nested/foo.py')

    assert paths[0].output == Path('./tests/data/out/foo.py')
    assert paths[1].output == Path('./tests/data/out/bar.py')
    assert paths[2].output == Path('./tests/data/out/nested/foo.py')


# Generated at 2022-06-12 03:19:16.173745
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""

# Generated at 2022-06-12 03:19:26.345189
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths"""

    assert list(get_input_output_paths(input_=__file__, output='/tmp', root=None)) == \
        [InputOutput(Path('/home/ubuntu/python3/python3-scripts/tools/pyt/tests/test_io.py'),
                     Path('/tmp/test_io.py'))]

    assert list(get_input_output_paths(input_=__file__, output='/tmp', root='/home/ubuntu/python3/python3-scripts')) == \
        [InputOutput(Path('/home/ubuntu/python3/python3-scripts/tools/pyt/tests/test_io.py'),
                     Path('/tmp/tools/pyt/tests/test_io.py'))]


# Generated at 2022-06-12 03:19:29.365592
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    list = [x for x in get_input_output_paths('demo', 'demo_out', None)]
    assert len(list)==1
    assert list[0].in_path == Path('demo')
    assert list[0].out_path == Path('demo_out')

# Generated at 2022-06-12 03:19:38.029090
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from types import GeneratorType 
    
    assert isinstance(get_input_output_paths("a/b.py", "c/d/b.py", "a"), GeneratorType)
    assert isinstance(get_input_output_paths("a/b.py", "c/d/b.py", None), GeneratorType)
    assert isinstance(get_input_output_paths("a/b.py", "c/d", "a"), GeneratorType)
    assert isinstance(get_input_output_paths("a/b.py", "c/d", None), GeneratorType)
    
    
    

# Create doctests
__test__ = {
    name: value for name, value in locals().items() if name.startswith("test_")
}

# Generated at 2022-06-12 03:19:39.177516
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Remove the mark of this function, then run `pytest tests` to test
    assert True

# Generated at 2022-06-12 03:19:48.297453
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('in', 'out', None)) == \
           [InputOutput(Path('in'), Path('out'))]
    assert list(get_input_output_paths('in/a.py', 'out', None)) == \
           [InputOutput(Path('in/a.py'), Path('out/a.py'))]
    assert list(get_input_output_paths('in/a.py', 'out/b.py', None)) == \
           [InputOutput(Path('in/a.py'), Path('out/b.py'))]
    assert list(get_input_output_paths('in', 'out', 'in')) == \
           [InputOutput(Path('in/a.py'), Path('out/a.py'))]

# Generated at 2022-06-12 03:19:55.594164
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:20:04.781867
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert sorted(get_input_output_paths('tests/a.py', 'tests/b', None)) == [InputOutput(Path('tests/a.py'), Path('tests/b/a.py'))]
    assert sorted(get_input_output_paths('tests/a.py', 'tests/b.py', None)) == [InputOutput(Path('tests/a.py'), Path('tests/b.py'))]
    assert sorted(get_input_output_paths('tests/e', 'tests/f', 'tests')) == [InputOutput(Path('tests/e/a.py'), Path('tests/f/a.py'))]

# Generated at 2022-06-12 03:20:10.183739
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    dir_path = str(Path(__file__).absolute()).split("/")
    dir_path = "/".join(dir_path[:(len(dir_path)-1)])

    input_output_pairs = list(get_input_output_paths("{}/examples/example_project/src".format(dir_path),
                                                     "{}/examples/example_project/dest".format(dir_path),
                                                     "{}/examples/example_project".format(dir_path)))


# Generated at 2022-06-12 03:20:19.887617
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = os.path.dirname(__file__)
    def _test(input_, output, root=None):
        actual = tuple(get_input_output_paths(input_, output, root))
        expected = (InputOutput(Path(input_), Path(output)),)
        assert actual == expected
    _test('a/b.py', 'c/d.py')
    _test('a/b.py', 'c/d')
    _test('a/b.py', 'c')
    _test('a/b.py', 'c', 'a')
    _test('a/b.py', 'c', 'f/g')
    _test('a', 'c', 'a')
    _test('a', 'c', 'f/g')
    _test('a', 'c')

# Generated at 2022-06-12 03:20:33.212894
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths to check if it raises exceptions 
    when needed and returns the correct output."""
    import pytest
    # Test if an invalid input/output pair raises an InvalidInputOutput exception
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("example.txt","example.py", root = None)
    # Test if a non-existing input raises an InputDoesntExists exception
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("example.py","example.txt", root = None)
    # Test if a string pair is returned when the input and output are both files
    get_input_output_paths("example.py","example.txt", root = None)
    # Test if a string pair is returned when the input is

# Generated at 2022-06-12 03:20:38.360027
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:20:47.683973
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))]
    assert list(get_input_output_paths('foo', 'bar', None)) == [
        InputOutput(Path('foo/a.py'), Path(
            'bar/a.py')), InputOutput(Path('foo/b.py'), Path('bar/b.py'))]
    assert list(get_input_output_paths('foo', 'bar', 'foo'))

# Generated at 2022-06-12 03:20:54.977671
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('./foo/', './bar/', None)) == [
        InputOutput(Path('./foo/'), Path('./bar/foo'))
    ]
    assert list(get_input_output_paths('./foo/', './bar/', '/tmp/')) == [
        InputOutput(Path('./foo/'), Path('./bar/foo'))
    ]
    assert list(get_input_output_paths('./foo/', './bar/', 'foo')) == [
        InputOutput(Path('./foo/'), Path('./bar/'))
    ]

# Generated at 2022-06-12 03:21:04.027501
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as root_path:
        in_dir = Path(root_path).joinpath('in')
        out_dir = Path(root_path).joinpath('out')
        in_dir.mkdir()
        out_dir.mkdir()

        # 1. test with input and output is directories
        in_dir.joinpath('in_file_1.py').write_text('1')
        pair = next(get_input_output_paths(str(in_dir), str(out_dir), str(root_path)))
        assert pair.input == in_dir.joinpath('in_file_1.py')
        assert pair.output == out_dir.joinpath('in_file_1.py')

        # 2. test with input is directory, output is file

# Generated at 2022-06-12 03:21:09.488147
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = os.path.dirname(__file__)
    test_dir = os.path.join(root, 'test_dir')
    test_dir2 = os.path.join(test_dir, 'test_dir2')
    print(root)
    print(test_dir)
    print(test_dir2)
    x = list(get_input_output_paths('test_dir2', 'test_dir2', root=root))
    print(x)
    pass

# Generated at 2022-06-12 03:21:17.657011
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    for case in [
        ('a.py', 'b.py', None),
        ('a.py', 'b', None),
        ('a', 'b.py', None),
    ]:
        try:
            list(get_input_output_paths(*case))
        except InvalidInputOutput:
            pass
        else:
            assert False, 'InvalidInputOutput not raised'
    assert (
        list(get_input_output_paths('a.py', 'a.py', None)) ==
        [InputOutput(Path.cwd().joinpath('a.py'),
                     Path.cwd().joinpath('a.py'))]
    )

# Generated at 2022-06-12 03:21:27.361050
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_list = get_input_output_paths(
        './test/test_data', './test/test_data/out', './test/test_data')

    # Checking number of input output pairs
    assert(len(input_output_list) == 9)

    # Checking output folder is correct
    for input_output_pair in input_output_list:
        assert(input_output_pair.output.parent.name == 'out')

    # Checking that we get the right pairs
    input_output_list = get_input_output_paths(
        './test/test_data/test_file2.py', './test/test_data/out/test_file2.py',
        './test/test_data')

    input_output_pair = next(input_output_list)
   

# Generated at 2022-06-12 03:21:36.743012
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def assert_paths(expected: Iterable[InputOutput],
                     input_: str,
                     output: str,
                     root: Optional[str] = None):
        print(input_, output, root)
        actual = list(get_input_output_paths(input_, output, root))
        assert expected == actual
    input_path = 'tests/input'
    output_path = 'tests/output'
    # Single file
    assert_paths([InputOutput(Path(input_path, 'a.py'),
                              Path(output_path, 'a.py'))],
                 input_='tests/input/a.py',
                 output='tests/output/a.py')

    # Single file to directory

# Generated at 2022-06-12 03:21:44.059301
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = get_input_output_paths('input/file.py', 'output/file.py', None)
    assert len(paths) == 1
    input_output = paths[0]
    assert input_output.input_path.name == 'file.py'
    assert input_output.input_path.parent.name == 'input'
    assert input_output.output_path.name == 'file.py'
    assert input_output.output_path.parent.name == 'output'

    paths = get_input_output_paths('input', 'output', None)
    assert len(paths) == 1
    input_output = paths[0]
    assert input_output.input_path.name == 'file.py'
    assert input_output.input_path.parent.name == 'input'
    assert input

# Generated at 2022-06-12 03:22:00.088332
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output_path = Path('/output')
    input_path = Path('/input/sub_folder')
    input_file = Path('/input/sub_folder/a.py')
    output_file = Path('/output/sub_folder/a.py')
    assert (list(get_input_output_paths(str(input_path), str(output_path),
                                        str(input_path.parent))) ==
            [InputOutput(input_file, output_file)])

# Generated at 2022-06-12 03:22:08.256059
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('x', 'z', None)) == [InputOutput(Path('x'), Path('z'))]
    assert list(get_input_output_paths('x/a.py', 'z', None)) == [InputOutput(Path('x/a.py'), Path('z/a.py'))]
    assert list(get_input_output_paths('x/a.py', 'z/a.py', None)) == [InputOutput(Path('x/a.py'), Path('z/a.py'))]
    assert list(get_input_output_paths('x', 'z/a.py', None)) == []

# Generated at 2022-06-12 03:22:14.427737
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    #Test for single input file
    input_output_paths = get_input_output_paths('TestDir/TestDir2', 'OutputDir', 'TestDir')
    input_output_paths_list = list(input_output_paths)
    assert len(input_output_paths_list) == 2
    assert input_output_paths_list[0] == InputOutput(Path('TestDir/TestDir2/File1.py'), Path('OutputDir/TestDir2/File1.py'))
    assert input_output_paths_list[1] == InputOutput(Path('TestDir/TestDir2/File2.py'), Path('OutputDir/TestDir2/File2.py'))

    #Test for a directory

# Generated at 2022-06-12 03:22:20.935421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "./test_input"
    assert list(get_input_output_paths(input_, "./test_output", "./")) == \
        [InputOutput(Path('./test_input/test_input/__init__.py'),
                      Path('./test_output/test_input/__init__.py')),
         InputOutput(Path('./test_input/test_input/test.py'),
                      Path('./test_output/test_input/test.py'))]


# Generated at 2022-06-12 03:22:27.667815
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('file1.txt', 'file2.py', 'dir'))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('file1.txt', 'file2.py', 'dir'))

    expected_single = [InputOutput(Path('file1.py'), Path('file2.py'))]
    assert list(get_input_output_paths('file1.py', 'file2.py', 'dir')) == expected_single

    expected_dir = [InputOutput(Path('dir/file1.py'), Path('dir2/file1.py'))]

# Generated at 2022-06-12 03:22:31.506325
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'dir1'
    output = '/dir1'
    actual = list(get_input_output_paths(input_, output, None))
    expected = [
        InputOutput(Path(input_, 'dir1.py'), Path('/dir1', 'dir1', 'dir1.py'))
    ]
    assert actual == expected



# Generated at 2022-06-12 03:22:38.797165
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('file.py', 'file_output.py', '') == [InputOutput(Path('file.py'), Path('file_output.py'))]
    assert get_input_output_paths('file.py', 'dir_output', '') == [InputOutput(Path('file.py'), Path('dir_output\\file.py'))]
    assert get_input_output_paths('dir_input', 'dir_output', '') == [InputOutput(Path('dir_input\\file.py'), Path('dir_output\\file.py'))]
    assert get_input_output_paths('dir_input', 'dir_output', 'dir_input') == [InputOutput(Path('dir_input\\file.py'), Path('dir_output\\file.py'))]

# Generated at 2022-06-12 03:22:44.847088
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [
        InputOutput(Path('a/b.py'), Path('d/b.py'))
    ] == list(get_input_output_paths('a/b.py', 'd', None))

    assert [
        InputOutput(Path('a/b.py'), Path('d/b.py'))
    ] == list(get_input_output_paths('a/b.py', 'd/', None))

    assert [
        InputOutput(Path('a/b.py'), Path('a/b.pyc'))
    ] == list(get_input_output_paths('a/b.py', 'a/b.pyc', None))


# Generated at 2022-06-12 03:22:52.102966
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./dummy/x.py', './out/', root=None)) == \
           [InputOutput(Path('./dummy/x.py'), Path('./out/x.py'))]
    assert list(get_input_output_paths('./dummy/x.py', './out', root=None)) == \
           [InputOutput(Path('./dummy/x.py'), Path('./out/x.py'))]
    assert list(get_input_output_paths('./dummy/a.py', './out/', root=None)) == \
           [InputOutput(Path('./dummy/a.py'), Path('./out/a.py'))]

# Generated at 2022-06-12 03:22:58.981337
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # TEST 1
    # Input:
    #   input_: "/a/b/c.py"
    #   output: "/d"
    #   root: None
    # Output:
    #   input_path: Path("/a/b/c.py")
    #   output_path: Path("/d/c.py")
    #   root: "/d"
    input_ = "/a/b/c.py"
    output = "/d"
    root = None
    output_paths = get_input_output_paths(input_, output, root)

    for input_path, output_path in output_paths:
        assert str(input_path) == "/a/b/c.py"
        assert str(output_path) == "/d/c.py"
        assert str(root)

# Generated at 2022-06-12 03:23:32.000590
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InvalidInputOutput):
        get_input_output_paths(
            input_='a.py', output='b.py', root='/home')

    with raises(InputDoesntExists):
        get_input_output_paths(
            input_='/home/a.py', output='b.py', root='/home')

    assert list(get_input_output_paths(
        input_='/home/a.py', output='/home/b', root='/home')) == [
            InputOutput(
                Path(input_='/home/a.py'),
                Path(output='/home/b/a.py'))]


# Generated at 2022-06-12 03:23:37.659372
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Input single file.
    input_output = list(get_input_output_paths(
        'test.py',
        'test_output.py',
        '/path/to/project',
    ))
    assert len(input_output) == 1
    assert input_output[0].input.as_posix() == '/path/to/project/test.py'
    assert input_output[0].output.as_posix() == '/path/to/project/test_output.py'

    # Input directory.
    input_output = list(get_input_output_paths(
        '/path/to/project',
        '/path/to/tests',
        '/path/to/project',
    ))
    assert len(input_output) == 1
    assert input_output[0].input.as_posix

# Generated at 2022-06-12 03:23:46.060303
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('input_files/input1', 'input_files/output1', None)) == [InputOutput(Path('input_files/input1/a.py'), Path('input_files/output1/a.py')), InputOutput(Path('input_files/input1/b.py'), Path('input_files/output1/b.py'))]
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input_files/input1', 'input_files/output1.txt', None))

# Generated at 2022-06-12 03:23:50.675621
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:23:57.961106
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
  from .types import InputOutput
  from .exceptions import InvalidInputOutput, InputDoesntExists

  # Case 1:
  #   - input: test_get_input_output_paths.py
  #   - output: test_get_input_output_paths.py
  #
  # Expected result:
  #   - InputOutput(Path('test_get_input_output_paths.py'), Path('test_get_input_output_paths.py'))
  io_paths = get_input_output_paths(
    'test_get_input_output_paths.py',
    'test_get_input_output_paths.py',
    None
  )

# Generated at 2022-06-12 03:24:04.049836
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1: When we pass as input and output both files
    input_ = 'input.py'
    output = 'output.py'

    paths = list(get_input_output_paths(input_, output, None))

    assert len(paths) == 1
    assert paths[0].input_path == Path(input_)
    assert paths[0].output_path == Path(output)

    # Test 2: When we pass as input a directory that contains files and as
    # output a directory
    input_ = 'directory_input'
    output = 'output_directory'

    paths = list(get_input_output_paths(input_, output, None))
    assert len(paths) == 2

    assert paths[0].input_path == Path(input_).joinpath('file_input.py')

# Generated at 2022-06-12 03:24:12.915060
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    from .exceptions import InputDoesntExists

    assert list(get_input_output_paths('module.py', 'output', None)) == [
        InputOutput(Path('module.py'), Path('output'))]

    assert list(get_input_output_paths('module.py', 'output/', None)) == [
        InputOutput(Path('module.py'), Path('output/module.py'))]

    assert list(get_input_output_paths('module.py', 'output.py', None)) == [
        InputOutput(Path('module.py'), Path('output.py'))]


# Generated at 2022-06-12 03:24:20.977262
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # output is a parent of input
    assert list(get_input_output_paths('foo/bar', 'foo', 'foo/bar')) == \
        [InputOutput(Path('foo/bar'), Path('foo/bar'))]

    # output is a file, input is a folder
    assert list(get_input_output_paths('foo/bar', 'foo/bar.py', 'foo')) == \
        [InputOutput(Path('foo/bar'), Path('foo/bar.py'))]

    # output is a file, input is a folder
    assert list(get_input_output_paths('foo/bar', 'foo/bar.py')) == \
        [InputOutput(Path('foo/bar'), Path('foo/bar.py'))]

    # input is a file, output is a folder

# Generated at 2022-06-12 03:24:29.879995
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing function get_input_output_paths."""
    # Case1: input and output are in the same directory
    result = get_input_output_paths('./test_input/test_input.py',
                                    './test_output/test_output.py', None)
    assert len([x for x in result]) == 1
    assert str(result[0][0]) == 'test_input/test_input.py'
    assert str(result[0][1]) == 'test_output/test_output.py'
    # Case2: input and output are different directories
    result = get_input_output_paths('./test_input/subdirectory',
                                    './test_output', None)
    assert len([x for x in result]) == 1

# Generated at 2022-06-12 03:24:36.743184
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('../tests/input',
                                           '../tests/output',
                                           '../tests/'))) == 1
    assert len(list(get_input_output_paths('../tests/input/test_hello.py',
                                           '../tests/output/test_hello.py',
                                           '../tests/'))) == 1
    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('../tests/abc.py',
                                    '../tests/output/abc.py',
                                    '../tests/'))
    # Test for input is a directory and output is a file

# Generated at 2022-06-12 03:25:31.613256
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytype_extensions import test
    from .server import Path

    ts = test.enter_context(test.TempTestSuite())

    input_ = '{}/in'.format(ts.root)
    output = '{}/out'.format(ts.root)

    ts.make_tree({
        input_: {
            '__init__.py': '',
            'file1.py': '',
            'file2.py': '',
            'foo': {
                '__init__.py': '',
                'file3.py': '',
            }
        }
    })

    def assert_paths(actual, expected):
        actual = [(o, i) for i, o in actual]
        assert actual == expected


# Generated at 2022-06-12 03:25:38.957925
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:25:46.727575
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1:
    # Given:
    #     - input = 'input_file.py'
    #     - output = 'output_file.py'
    #     - root = None
    # Expected:
    #     - InputOutput('input_file.py', 'output_file.py')
    input_output_paths = list(get_input_output_paths('input_file.py', 'output_file.py', None))

    assert len(input_output_paths) == 1
    (input_, output) = input_output_paths[0]
    assert str(input_) == 'input_file.py'
    assert str(output) == 'output_file.py'


    # Test 2:
    # Given:
    #     - input = 'dir_input'
    #    

# Generated at 2022-06-12 03:25:53.971021
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput

    cases = (
        (
            'tests/resources/onefile.yml',
            'test.py',
            'tests/resources/',
        ),
        (
            'tests/resources/onefile.yml',
            'test.py',
            None,
        ),
        (
            'tests/resources/onefile.yml',
            'test',
            None,
        ),
    )

    outputs = [
        InputOutput(Path('tests/resources/onefile.yml'), Path('test.py')),
    ] * 3
    for case, output in zip(cases, outputs):
        assert next(get_input_output_paths(*case)) == output


# Generated at 2022-06-12 03:25:59.829158
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    import pytest
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('ok.py', 'notok.txt', 'root')
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('ok.txt', 'notok.py', 'root')
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths(
            '/this/path/does/not/exists', '/is/also/not/exists', 'root')


# Generated at 2022-06-12 03:26:06.615241
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test class for function get_input_output_path."""
    import pytest # type: ignore

    def check_paths(input_: str, output: str, root: str,
                    expected: Iterable[InputOutput]) -> None:
        input_expected = tuple(sorted(
            '{} {}'.format(p.input, p.output) for p in expected))
        output_actual = tuple(sorted(
            '{} {}'.format(p.input, p.output) for p in get_input_output_paths(
                input_, output, root)))
        assert input_expected == output_actual


# Generated at 2022-06-12 03:26:15.601428
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    # Test for input and output are file path
    assert list(get_input_output_paths("/test/test1.py", "/test/test2.py", "test")) == \
        [InputOutput(Path("/test/test1.py"), Path("/test/test2.py"))]
    # Test for input is file path and output is directory path
    assert list(get_input_output_paths("/test/test1.py", "/test/test2", "test")) == \
        [InputOutput(Path("/test/test1.py"), Path("/test/test2/test1.py"))]

# Generated at 2022-06-12 03:26:24.310073
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""
    parent_dir_path = Path(__file__).parent
    # test1: when input is file and output is directory
    input_output = get_input_output_paths(str(parent_dir_path) + "\test_inputs", str(parent_dir_path), None)
    test1_output = [input_output.input for input_output in input_output]
    assert test1_output == [parent_dir_path / 'test_inputs' / 'foo.py', parent_dir_path / 'test_inputs' / 'bar.py']
    
    # test2: when input is directory and loop over directory to get file

# Generated at 2022-06-12 03:26:32.136489
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:26:40.049147
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
  assert list(get_input_output_paths("./input/", "./output/", "./")) == [
    InputOutput(Path("./input/input1.py"), Path("./output/input1.py")),
    InputOutput(Path("./input/input2.py"), Path("./output/input2.py")),
    InputOutput(Path("./input/input3.py"), Path("./output/input3.py")),
    InputOutput(Path("./input/testpy/input4.py"), Path("./output/testpy/input4.py")),
    InputOutput(Path("./input/testpy/input5.py"), Path("./output/testpy/input5.py"))
  ]