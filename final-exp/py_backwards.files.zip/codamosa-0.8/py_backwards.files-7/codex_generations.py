

# Generated at 2022-06-12 03:18:07.792976
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for get_input_output_paths."""

# Generated at 2022-06-12 03:18:15.649421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    import shutil

    # Case 1:
    # input_ = '/tmp/abc.py'
    # output = '/tmp/out//abc.py'
    # assert [(input_, output)] == list(get_input_output_paths(input_, output, None))

    # Case 2:
    # input_ = '/tmp/a/b/c.py'
    # output = '/tmp/out'
    # assert [(input_, '/tmp/out/c.py')] == list(get_input_output_paths(input_, output, None))

    # Case 3:
    # input_ = '/tmp/a/b/c.py'
    # output = '/tmp/out'
    # assert [(input_, '/tmp/out/a/b/c.py')] == list(get

# Generated at 2022-06-12 03:18:23.651555
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1: valid input/output pair, input is a single file.
    #             This case should return a single pair.
    valid_input_output_pair_single_file = get_input_output_paths("../tests/a.py","../tests/",None)
    assert len(list(valid_input_output_pair_single_file)) == 1
    # Test case 2: valid input/output pair, input is a single directory.
    #             This case should return all child files.
    valid_input_output_pair_single_dir = get_input_output_paths("../tests/","../tests/",None)
    assert len(list(valid_input_output_pair_single_dir)) == 4
    # Test case 3: invalid input/output pair, output is a single file.
    #             This case should raise

# Generated at 2022-06-12 03:18:27.017266
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = get_input_output_paths(
        input_='test.py', output='out', root='out')
    paths_list = list(paths)
    assert paths_list == [InputOutput(Path('test.py'), Path('out/test.py'))]

# Generated at 2022-06-12 03:18:34.076124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_pairs = get_input_output_paths('a.py', 'b', None)
    pairs = list(input_output_pairs)
    assert len(pairs) == 1
    assert pairs[0].input == Path('a.py')
    assert pairs[0].output == Path('b/a.py')

    input_output_pairs = get_input_output_paths('a', 'b', None)
    pairs = list(input_output_pairs)
    assert len(pairs) == 0

    input_output_pairs = get_input_output_paths('a', 'b.py', None)
    pairs = list(input_output_pairs)
    assert len(pairs) == 1
    assert pairs[0].input == Path('a.py')

# Generated at 2022-06-12 03:18:44.517370
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', '.')) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a/b.py', 'b/b.py', 'a')) == [InputOutput(Path('a/b.py'), Path('b/b.py'))]
    assert list(get_input_output_paths('a/b.py', 'b', 'a')) == [InputOutput(Path('a/b.py'), Path('b/b.py'))]
    assert list(get_input_output_paths('a', 'b', '.')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-12 03:18:53.332253
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Unit test for function get_input_output_paths
    """

    assert get_input_output_paths("./templater/templater.py", "./", None) == [InputOutput(PosixPath('templater/templater.py'), PosixPath('templater.py'))]


# Generated at 2022-06-12 03:19:00.822842
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""
    input_output_paths = get_input_output_paths('a.py', 'b/c.py', 'root/dir')
    assert next(input_output_paths) == InputOutput(Path('a.py'), Path('b/c.py'))

    input_output_paths = get_input_output_paths('a.py', 'b.py', 'root/dir')
    assert next(input_output_paths) == InputOutput(Path('a.py'), Path('b.py'))

    input_output_paths = get_input_output_paths(
        'root/dir/a.py', 'b.py', 'root/dir')

# Generated at 2022-06-12 03:19:09.664521
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # case 1
    input = "vendor/test.py"
    output = "outputs"
    root = None
    answer = [InputOutput(Path('vendor/test.py'), Path('outputs/test.py'))]
    assert [i for i in get_input_output_paths(input, output, root)] == answer

    # case 2
    input = "vendor"
    output = "outputs"
    root = None
    answer = [InputOutput(Path('vendor/script.py'), Path('outputs/script.py'))]
    assert [i for i in get_input_output_paths(input, output, root)] == answer

    # case 3
    input = "vendor/script.py"
    output = "outputs/vendor.py"
    root = None
    answer

# Generated at 2022-06-12 03:19:17.591965
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_path = Path('/home/jazmin/proyectos/micropyde/micropyde-cli/input')
    output_path = Path('/home/jazmin/proyectos/micropyde/micropyde-cli/output')
    root = Path('/home/jazmin/proyectos/micropyde/micropyde-cli')
    assert list(get_input_output_paths('input', 'output', str(root))) == \
        [InputOutput(input_path.joinpath('input.py'), output_path.joinpath('input.py')),
        InputOutput(input_path.joinpath('subdir/subdir/subdir.py'),
        output_path.joinpath('subdir/subdir/subdir.py'))]


# Generated at 2022-06-12 03:19:31.771013
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'vega-datasets'
    output = 'jupyter-widget-d3-slider/tests'
    root = 'vega-datasets'
    input_output_paths = get_input_output_paths(input_, output, root)
    input_path, output_path = next(input_output_paths)
    assert str(input_path) == 'vega-datasets/data/barley.py'
    assert str(output_path) == 'jupyter-widget-d3-slider/tests/barley.py'
    input_path, output_path = next(input_output_paths)
    assert str(input_path) == 'vega-datasets/data/sp500.py'

# Generated at 2022-06-12 03:19:39.459328
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('tests/data/source.py', 'tests/data/output.py', None)) == [
            InputOutput(Path('tests/data/source.py'), Path('tests/data/output.py'))]
    assert list(get_input_output_paths('tests/data/source.py', 'tests/data/output.py', 'tests')) == [
            InputOutput(Path('tests/data/source.py'), Path('tests/data/output.py'))]
    assert list(get_input_output_paths('tests/data', 'tests/data/output', 'tests')) == [
            InputOutput(Path('tests/data/source.py'), Path('tests/data/output/source.py'))]

# Generated at 2022-06-12 03:19:48.384578
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('test.py', 'out', 'test') == [
        InputOutput(Path('test.py'), Path('out/test.py')),
    ]

    assert get_input_output_paths('test.py', 'out.py', 'test') == [
        InputOutput(Path('test.py'), Path('out.py')),
    ]

    assert get_input_output_paths('test', 'out', 'test') == [
        InputOutput(Path('test/a.py'), Path('out/a.py')),
    ]

    assert get_input_output_paths('test', 'out', None) == [
        InputOutput(Path('test/a.py'), Path('out/a.py')),
    ]

# Generated at 2022-06-12 03:19:55.626319
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # "/" is a placeholder of "abcd"
    assert list(get_input_output_paths("abcd", "abcd", None)) == [InputOutput(Path("abcd"), Path("abcd"))]
    assert list(get_input_output_paths("abcd/main.py", "abcd", None)) == [InputOutput(Path("abcd/main.py"), Path("abcd"))]
    assert list(get_input_output_paths("abcd", "abcd/output", None)) == [InputOutput(Path("abcd"), Path("abcd/output"))]
    assert list(get_input_output_paths("abcd/main.py", "abcd/output", None)) == [InputOutput(Path("abcd/main.py"), Path("abcd/output/main.py"))]

# Generated at 2022-06-12 03:20:04.816839
# Unit test for function get_input_output_paths

# Generated at 2022-06-12 03:20:10.200162
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Use the function in test_get_input_output_paths can delete files
    def test_delete_files(path: str):
        try:
            Path(path).unlink()
        except FileNotFoundError:
            pass
    def test_write_files(path: str, text: str):
        with open(path, 'w') as f:
            f.write(text)


# Generated at 2022-06-12 03:20:19.883780
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Single file
    assert list(get_input_output_paths('input/S1/x.py', 'output/y.py', None)) == [
        InputOutput(Path('input/S1/x.py'), Path('output/y.py'))
    ]
    # Directory
    assert list(get_input_output_paths('input/S1', 'output', None)) == [
        InputOutput(Path('input/S1/x.py'), Path('output/S1/x.py')),
        InputOutput(Path('input/S1/z/y.py'), Path('output/S1/z/y.py'))
    ]
    # Directory with root

# Generated at 2022-06-12 03:20:30.211506
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'psi4/__main__.py'
    output = 'psi4/tests/test.py'

    paths = get_input_output_paths(input_, output, None)
    assert len(list(paths)) == 1
    (input_path, output_path) = next(paths)
    assert Path(input_).name == input_path.name
    assert output_path.name == Path(output).name

    input_ = 'psi4/__main__.py'
    output = 'psi4/tests'

    paths = get_input_output_paths(input_, output, None)
    assert len(list(paths)) == 1
    (input_path, output_path) = next(paths)
    assert Path(input_).name == input_path.name

# Generated at 2022-06-12 03:20:38.664500
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    tester = get_input_output_paths('/Users/david/Documents/PythonProjects/PythonProjects/dummy_package','/Users/david/Documents/PythonProjects/PythonProjects/dummy_package/13','/Users/david/Documents/PythonProjects/PythonProjects/dummy_package')
    test = list(tester)
    assert test[0] == InputOutput(Path('/Users/david/Documents/PythonProjects/PythonProjects/dummy_package/13/dummy.py'),Path('/Users/david/Documents/PythonProjects/PythonProjects/dummy_package/13/dummy.py'))

# Generated at 2022-06-12 03:20:48.192410
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    assert str(get_input_output_paths(
        'test.py',
        '.',
        None)[0].input) == 'test.py'
    assert str(get_input_output_paths(
        'test.py',
        '.',
        None)[0].output) == './test.py'
    assert str(get_input_output_paths(
        'test.py',
        'test2.py',
        None)[0].input) == 'test.py'
    assert str(get_input_output_paths(
        'test.py',
        'test2.py',
        None)[0].output) == 'test2.py'

# Generated at 2022-06-12 03:21:06.661978
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output mode
    result = get_input_output_paths('a.py', 'b.py', '.')
    assert next(result) == InputOutput(Path('a.py'), Path('b.py'))
    with pytest.raises(InputDoesntExists):
        result = get_input_output_paths('c.py', 'b.py', '.')
    with pytest.raises(InvalidInputOutput):
        result = get_input_output_paths('a.py', 'b', '.')

    # Test for input directory/output directory mode
    result = get_input_output_paths('./test', './test/output', '.')

# Generated at 2022-06-12 03:21:14.777307
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test: normal usage of get_input_output_paths
    print("Testing: normal usage of get_input_output_paths")
    result = get_input_output_paths("test_dir/test_dir2/test_file2.py", "output", "test_dir/test_dir2")
    for i in result:
        assert(i.input_path.name == "test_file2.py")
        assert(i.output_path.name == "test_file2.py")

    # Test: normal usage of get_input_output_paths
    print("Testing: normal usage of get_input_output_paths")
    result = get_input_output_paths("test_dir/test_dir2/test_file.py", "output", "test_dir")

# Generated at 2022-06-12 03:21:24.558834
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_paths = get_input_output_paths(
        "test_get_input_output_paths/input",
        "test_get_input_output_paths/output",
        "test_get_input_output_paths"
    )
    assert [
        InputOutput(Path("test_get_input_output_paths/input/1.py"),
                    Path("test_get_input_output_paths/output/1.py")),
        InputOutput(Path("test_get_input_output_paths/input/sub/2.py"),
                    Path("test_get_input_output_paths/output/sub/2.py"))
    ] == list(test_paths)

# Generated at 2022-06-12 03:21:31.111563
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from .types import InputOutput


# Generated at 2022-06-12 03:21:40.773518
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    input_ = 'test/test_files'
    output = 'test/output_files'
    root = None

    # When
    output_files = list(get_input_output_paths(input_, output, root))

    # Then
    assert len(output_files) == 5
    assert output_files[0].input == Path('test/test_files/helloworld.py')
    assert output_files[0].output == Path('test/output_files/helloworld.py')
    assert output_files[1].input == Path('test/test_files/test/test_files.py')
    assert output_files[1].output == Path('test/output_files/test/test_files.py')

# Generated at 2022-06-12 03:21:48.709694
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths"""
    def get_input_output_file_names(input_: str, output: str,
                                    root: Optional[str]) -> Iterable[str]:
        return tuple(
            (str(x.input_path), str(x.output_path))
            for x in get_input_output_paths(input_, output, root)
        )

    assert get_input_output_file_names('a', 'b', '') == ()

    with pytest.raises(InvalidInputOutput):
        get_input_output_file_names('a', 'b.py', '')

    with pytest.raises(InputDoesntExists):
        get_input_output_file_names('a', 'b', '')

    assert get_input_output_file_

# Generated at 2022-06-12 03:21:55.653908
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test case 1
    # input: 
    # - input path: /a/b/c.py
    # - output path: /d/e/f.py
    # output:
    # - input path: /a/b/c.py  
    # - output path: /d/e/f.py
    test_file_paths = get_input_output_paths('/a/b/c.py', '/d/e/f.py', None)
    for test_file_path in test_file_paths:
        assert test_file_path.input_path == Path('/a/b/c.py')
        assert test_file_path.output_path == Path('/d/e/f.py')

    # test case 2
    # input: 
    # - input path: /

# Generated at 2022-06-12 03:22:01.289770
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo.py', 'bar.py', None) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]
    assert get_input_output_paths('foo.py', 'bar/', None) == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))
    ]
    assert get_input_output_paths('foo.py', 'bar/', 'myroot') == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))
    ]
    assert get_input_output_paths('foo.py', 'bar/', 'myroot') == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))
    ]
    assert get_input_output_

# Generated at 2022-06-12 03:22:09.267623
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """ Test function get_input_output_paths """
    # Test 1 : Test on a directory
    test_list = []
    root = os.getcwd()
    input_ = root + '/pytype_test/pyi'
    output = root + '/pytype_test/pyi/out'
    test_list = list(get_input_output_paths(input_, output, root))
    assert test_list[0].input_path == input_ + '/a.pyi'
    assert test_list[0].output_path == output + '/a.py'
    assert test_list[1].input_path == input_ + '/b.pyi'
    assert test_list[1].output_path == output + '/b.py'

# Generated at 2022-06-12 03:22:15.227856
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a', 'output', None) == InputOutput('a', 'output')
    assert get_input_output_paths('a.py', 'output', None) == InputOutput('a.py', 'output/a.py')
    assert get_input_output_paths('a', 'output.py', None) == InputOutput('a', 'output.py')
    assert get_input_output_paths('detect', 'output', None).next() == InputOutput('detect/detect.py', 'output/detect/detect.py')

    with pytest.raises(Exception):
        get_input_output_paths('a.py', 'output.py', None)

# Generated at 2022-06-12 03:22:49.194433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input', 'output.py', None)

    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    io_paths = list(get_input_output_paths('input.py', 'output.py', None))
    assert len(io_paths) == 1
    assert io_paths[0].input_path == 'input.py'
    assert io_paths[0].output_path == 'output.py'

    io_paths = list(get_input_output_paths('input.py', 'output', None))
    assert len(io_paths) == 1
    assert io_paths[0].input_

# Generated at 2022-06-12 03:22:56.362939
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    input_ = '/p/a.py'
    output = '/p/b.py'
    assert list(get_input_output_paths(input_, output, root=None)) == \
        [InputOutput(Path(input_), Path(output))]

    input_ = '/p/a.py'
    output = '/p/'
    assert list(get_input_output_paths(input_, output, root=None)) == \
        [InputOutput(Path(input_), Path(output).joinpath(Path(input_).name))]

    input_ = '/p/a.py'
    output = '/p/'
    root = '/p'

# Generated at 2022-06-12 03:23:04.052130
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [
        InputOutput(Path('a/b/c1.py'), Path('o/b/c1.py')),
        InputOutput(Path('a/b/c2.py'), Path('o/b/c2.py')),
        InputOutput(Path('a/b/c3.py'), Path('o/b/c3.py')),
        InputOutput(Path('a/d/e.py'), Path('o/d/e.py')),
    ] == list(
        get_input_output_paths('a', 'o', None)
    )

# Generated at 2022-06-12 03:23:12.097726
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/tmp/x/a.py'
    output = '/tmp/y'
    root = '/tmp/x'

    ios = get_input_output_paths(input_, output, root)
    ios_expected = [
        InputOutput(
            Path('/tmp/x/a.py'),
            Path('/tmp/y/a.py'))]
    assert list(ios) == ios_expected

    ios = get_input_output_paths(input_, output, None)
    ios_expected = [
        InputOutput(
            Path('/tmp/x/a.py'),
            Path('/tmp/y/a.py'))]
    assert list(ios) == ios_expected

    input_ = '/tmp/x'

# Generated at 2022-06-12 03:23:19.476986
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = get_input_output_paths('a.py', 'test_dir')
    assert next(input_output) == ('a.py', 'test_dir/a.py')

    input_output = get_input_output_paths('test_dir', 'test_dir2')
    assert next(input_output) == ('test_dir/a.py', 'test_dir2/a.py')
    assert next(input_output) == ('test_dir/subdir/b.py', 'test_dir2/subdir/b.py')

    input_output = get_input_output_paths('test_dir', 'test_dir2', 'test_dir')

# Generated at 2022-06-12 03:23:29.949475
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a/b', 'a/c', 'a')) == \
        [InputOutput(Path('a/b/d.py'), Path('a/c/d.py'))]
    assert list(get_input_output_paths('a/b/d.py', 'a/c', 'a')) == \
        [InputOutput(Path('a/b/d.py'), Path('a/c/d.py'))]
    assert list(get_input_output_paths('a/b/d.py', 'a/c/d.py', 'a')) == \
        [InputOutput(Path('a/b/d.py'), Path('a/c/d.py'))]

# Generated at 2022-06-12 03:23:36.116000
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Tests for the function get_input_output_paths."""
    root = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-12 03:23:42.848204
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path

    input_ = Path('/', 'foo', 'bar')
    output = Path('/', 'baz')
    root = Path('/', 'foo')
    path1 = InputOutput(input_ / 'hello.py', output / 'hello.py')
    path2 = InputOutput(input_ / 'world.py', output / 'world.py')

    for path in get_input_output_paths('/foo/bar', '/baz', '/foo'):
        if path == path1:
            assert path1 == path
        else:
            assert path2 == path

# Generated at 2022-06-12 03:23:46.714306
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test 1
    input_ = 'input'
    output = 'output'
    root = '/Users/wraman/git/research/code-summarization/summarizer/summarizer'
    pairs = get_input_output_paths(input_, output, root=None)
    for pair in pairs:
        print(pair.input_path)
        print(pair.output_path)

# Generated at 2022-06-12 03:23:52.131407
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    import pytest
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # test with invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output', 'test_data'))

    # test with non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('not-existing', 'output', 'test_data'))

    # test input is directory, output is file
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test_data', 'output.py', 'test_data'))

    # test input is directory, output is directory
    paths

# Generated at 2022-06-12 03:24:50.007834
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test funct get_input_output_paths
    """
    from .types import InputOutput
    from .exceptions import InvalidInputOutput
    from pathlib import Path
    from pytest import raises

    # Test for assert output as file
    with raises(InvalidInputOutput):
        get_input_output_paths(
            input_=Path("tests/fixtures/test_root_module.py"),
            output=Path("tests/fixtures/tests_output"),
            root=None
        )

    # Test for assert that input file exists

# Generated at 2022-06-12 03:24:55.237401
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_list = list(get_input_output_paths('testdata/a.py',
                                                    'testdata/output/a.py',
                                                    None))
    assert input_output_list[0].input_path == Path('testdata/a.py')
    assert input_output_list[0].output_path == Path('testdata/output/a.py')

    input_output_list = list(get_input_output_paths('testdata',
                                                    'testdata/output',
                                                    None))
    assert input_output_list[0].input_path == Path('testdata/a.py')
    assert input_output_list[0].output_path == Path('testdata/output/a.py')


# Generated at 2022-06-12 03:25:03.703634
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('src', 'dest', 'src')) == \
        [InputOutput(Path('src/__init__.py'), Path('dest/__init__.py'))]
    
    assert list(get_input_output_paths('src/__init__.py', 'dest', 'src')) == \
        [InputOutput(Path('src/__init__.py'), Path('dest/__init__.py'))]
    
    assert list(get_input_output_paths('src/__init__.py', 'dest/__init__.py',
                                       'src')) == \
        [InputOutput(Path('src/__init__.py'), Path('dest/__init__.py'))]


# Generated at 2022-06-12 03:25:10.417418
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # output as directory
    input_ = 'filename.py'
    output = 'output'
    paths = get_input_output_paths(input_, output, None)
    assert list(paths) == [InputOutput(Path('filename.py'), Path('output/filename.py'))]

    # output as filename
    input_ = 'filename.py'
    output = 'output.py'
    paths = get_input_output_paths(input_, output, None)
    assert list(paths) == [InputOutput(Path('filename.py'), Path('output.py'))]

    # input as file
    input_ = 'filename.py'
    output = 'output'

# Generated at 2022-06-12 03:25:19.091753
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test that it returns single entry
    inputs = [
        ('foo/bar.py', 'foo/bar.py'),
        ('foo/bar.py', 'foo/baz/'),
        ('foo/bar.py', 'foo/baz/bar.py'),
        ('foo/bar/', 'foo/'),
        ('foo/bar/', 'foo/bar/'),
        ('foo/bar/', 'foo/baz/'),
        ('foo/bar/baz.py', 'foo/baz/baz.py'),
    ]
    for i, o in inputs:
        assert next(get_input_output_paths(i, o, None)) == InputOutput(Path(i), Path(o))

    # test that empty Path for root works

# Generated at 2022-06-12 03:25:26.699944
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = Path(__file__).parent.parent
    test_cases = (
        (path / 'tests/fixtures/a.py', path / 'tests/fixtures', 'tests/fixtures/__init__.py'),
        (path / 'tests/fixtures/a.py', path / 'tests/fixtures', 'tests/fixtures/__init__.py'),
        (path / 'tests/fixtures/a.py', path / 'tests/fixtures', 'tests/fixtures/__init__.py'),
    )

    for case in test_cases:
        input_raw, output_raw, root = case
        case = get_input_output_paths(str(input_raw), str(output_raw), str(root))
        assert len(list(case)) == 1
        case = next(iter(case))

# Generated at 2022-06-12 03:25:32.926846
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo/bar.py', 'dst', 'foo')) == [
        InputOutput(Path('foo/bar.py'), Path('dst/bar.py'))
    ]

    assert list(get_input_output_paths('foo/bar.py', 'dst', None)) == [
        InputOutput(Path('foo/bar.py'), Path('dst/bar.py'))
    ]

    assert list(get_input_output_paths('foo', 'dst', None)) == [
        InputOutput(Path('foo/bar.py'), Path('dst/bar.py'))
    ]


# Generated at 2022-06-12 03:25:40.482263
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""

    # case 1: input = 'test.py', output = 'output.py'
    expected_value = [InputOutput(Path('test.py'), Path('output.py'))]
    assert list(get_input_output_paths('test.py', 'output.py', None)) == expected_value

    # case 2: input = 'data.py', output = 'output'
    expected_value = [InputOutput(Path('data.py'), Path('output/data.py'))]
    assert list(get_input_output_paths('data.py', 'output', None)) == expected_value

    # case 3: input = 'test.py', output = 'output'

# Generated at 2022-06-12 03:25:48.341252
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('sources/foo.py', 'sources/bar.py',
                                       'sources')) == \
        [InputOutput(Path('sources/foo.py'), Path('sources/bar.py'))]
    assert list(get_input_output_paths('sources/foo.py', 'bar/', 'sources')) == \
        [InputOutput(Path('sources/foo.py'), Path('bar/foo.py'))]
    assert list(get_input_output_paths('sources/foo.py', 'bar/foo.py',
                                       'sources')) == \
        [InputOutput(Path('sources/foo.py'), Path('bar/foo.py'))]

# Generated at 2022-06-12 03:25:54.557114
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path('/test')
    output_path = Path('/test/output')
    assert list(get_input_output_paths(
        str(root.joinpath('foo.py')),
        str(output_path))) == [InputOutput(
            Path('/test/foo.py'),
            Path('/test/output/foo.py'))]

    assert list(get_input_output_paths(
        str(root.joinpath('foo.py')),
        str(output_path.joinpath('foo.py')))) == [InputOutput(
            Path('/test/foo.py'),
            Path('/test/output/foo.py'))]


# Generated at 2022-06-12 03:27:44.974237
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    test_root = Path(__file__).parent
    test_input = Path(test_root, "__init__.py")
    test_output_dir = Path(test_root, "__init__.out")
    test_output_file = Path(test_root, "__init__.out.py")
    
    test_root_str = str(test_root)
    test_input_str = str(test_input)
    test_output_dir_str = str(test_output_dir)
    test_output_file_str = str(test_output_file)
    pairs = list(get_input_output_paths(test_input_str, test_output_dir_str, test_root_str))
    
    assert len(pairs) == 1
    assert pairs

# Generated at 2022-06-12 03:27:51.579266
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    from .exceptions import InputDoesntExists
    test_input = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test_input')
    test_output = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test_output')


# Generated at 2022-06-12 03:27:58.887520
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    _test_get_input_output_paths(False, '/bar/baz/foo.py', '/bar/baz/a.py', '.py', '/bar/baz/a.py')
    _test_get_input_output_paths(False, '/bar/baz/foo.py', '/baz', '.py', '/baz/foo.py')
    _test_get_input_output_paths(False, '/bar/baz/foo.py', '/baz/', '.py', '/baz/foo.py')
    _test_get_input_output_paths(False, '/bar/baz/foo.py', 'baz/', '.py', 'baz/foo.py')
    _test_get_input_output_