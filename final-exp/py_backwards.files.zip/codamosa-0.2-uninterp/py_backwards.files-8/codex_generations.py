

# Generated at 2022-06-17 23:46:23.863455
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for input/output pair
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for input directory and output directory

# Generated at 2022-06-17 23:46:31.546578
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for single file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for single file with root

# Generated at 2022-06-17 23:46:42.846414
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:46:50.545380
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:46:57.562991
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    assert get_input_output_paths('a.py', 'b.py', None) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert get_input_output_paths('a.py', 'b', None) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert get_input_output_paths('a', 'b', None) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:09.043294
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'test.py', None))

    # Test for input/output as files
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input as file and output as directory

# Generated at 2022-06-17 23:47:20.017877
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:31.334309
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:47:40.274482
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'test.py', None))

    # Test for single file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for single file with root

# Generated at 2022-06-17 23:47:50.369620
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:02.913052
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.txt', 'output.py', None))

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for single file
    paths = list(get_input_output_paths('input.py', 'output.py', None))
    assert len(paths) == 1
    assert paths[0].input == Path('input.py')
    assert paths[0].output == Path('output.py')

    # Test for single file with root

# Generated at 2022-06-17 23:48:11.275680
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test with a single file
    input_ = 'test/test_input.py'
    output = 'test/test_output.py'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    assert len(list(input_output_paths)) == 1
    input_output_path = next(input_output_paths)
    assert input_output_path.input_path.name == 'test_input.py'
    assert input_output_path.output_path.name == 'test_output.py'

    # Test with a directory
    input_ = 'test/test_input'
    output = 'test/test_output'
    root = None
    input_output_paths

# Generated at 2022-06-17 23:48:22.197730
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test case 1: input is a folder, output is a folder
    input_ = 'test/test_input'
    output = 'test/test_output'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:48:33.304120
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for single file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for single file with root

# Generated at 2022-06-17 23:48:43.623750
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('/a/b/c.py', '/d/e/f.py', None)) == [
        InputOutput(Path('/a/b/c.py'), Path('/d/e/f.py'))]
    assert list(get_input_output_paths('/a/b/c.py', '/d/e/f', None)) == [
        InputOutput(Path('/a/b/c.py'), Path('/d/e/f/c.py'))]

# Generated at 2022-06-17 23:48:49.655214
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', 'a')) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:48:59.001893
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:49:06.036777
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for input/output files
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b.py', None)) == [
        InputOutput(Path('a/a.py'), Path('b.py'))
    ]

# Generated at 2022-06-17 23:49:15.353569
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:25.967958
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        input_path = temp_dir.joinpath('input')
        input_path.mkdir()
        input_path.joinpath('a.py').touch()
        input_path.joinpath('b.py').touch()
        input_path.joinpath('c.py').touch()
        input_path.joinpath('d.py').touch()

        output_path = temp_dir.joinpath('output')
        output_path.mkdir()


# Generated at 2022-06-17 23:50:15.672886
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert result == [InputOutput(Path(input_), Path(output))]

    # Test 2
    input_ = 'input.py'
    output = 'output'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert result == [InputOutput(Path(input_), Path(output).joinpath(Path(input_).name))]

    # Test 3
    input_ = 'input'
    output = 'output'
    root = None
    result = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:50:26.320847
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:35.997444
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:45.374573
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for single file
    assert list(get_input_output_paths('test/test_input.py', 'test/test_output.py', None)) == [InputOutput(Path('test/test_input.py'), Path('test/test_output.py'))]
    # Test for single file with different output name
    assert list(get_input_output_paths('test/test_input.py', 'test/test_output', None)) == [InputOutput(Path('test/test_input.py'), Path('test/test_output/test_input.py'))]
    # Test for directory

# Generated at 2022-06-17 23:50:54.217908
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:04.258090
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for input_output_paths
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:14.245225
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output paths pairs
    assert list(get_input_output_paths(
        input_='/home/user/project/src/main.py',
        output='/home/user/project/src/main_out.py',
        root=None)) == [InputOutput(Path('/home/user/project/src/main.py'),
                                   Path('/home/user/project/src/main_out.py'))]

# Generated at 2022-06-17 23:51:23.861514
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:32.917998
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for existing input
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for existing input and output

# Generated at 2022-06-17 23:51:42.263085
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_dir.joinpath('a.py').touch()
        temp_dir.joinpath('b.py').touch()
        temp_dir.joinpath('c.py').touch()
        temp_dir.joinpath('d.py').touch()
        temp_dir.joinpath('subdir').mkdir()
        temp_dir.joinpath('subdir', 'e.py').touch()
        temp_dir.joinpath('subdir', 'f.py').touch()
        temp_dir.joinpath('subdir', 'g.py').touch()

# Generated at 2022-06-17 23:52:40.311744
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/data/a.py', 'tests/data/b.py', None)) == [
        InputOutput(Path('tests/data/a.py'), Path('tests/data/b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:52:50.414511
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for single file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for single file with output directory

# Generated at 2022-06-17 23:53:01.132440
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    # Test 1
    input_ = 'input.py'
    output = 'output.py'
    root = None
    expected = [InputOutput(Path('input.py'), Path('output.py'))]
    actual = list(get_input_output_paths(input_, output, root))
    assert actual == expected

    # Test 2
    input_ = 'input.py'
    output = 'output'
    root = None
    expected = [InputOutput(Path('input.py'), Path('output/input.py'))]
    actual = list(get_input_output_paths(input_, output, root))
    assert actual == expected

    # Test 3
    input_ = 'input'
    output = 'output'
    root = None

# Generated at 2022-06-17 23:53:11.825811
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for input/output as files
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]
    # Test for input as file and output as directory
    assert list(get_input_output_paths('input.py', 'output', None)) == [
        InputOutput(Path('input.py'), Path('output/input.py'))
    ]
    # Test for input as directory and output as directory

# Generated at 2022-06-17 23:53:21.504726
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for a single file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', 'c')) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))
    ]

# Generated at 2022-06-17 23:53:30.563745
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert get_input_output_paths('test.py', 'test.py', None) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory
    assert get_input_

# Generated at 2022-06-17 23:53:38.231049
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test/input.py', 'test/output.py', None)) == [
        InputOutput(Path('test/input.py'), Path('test/output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:53:48.792097
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""

# Generated at 2022-06-17 23:53:59.672463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for single file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for single file with root

# Generated at 2022-06-17 23:54:10.903012
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:55:57.296574
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [
        InputOutput(Path('foo.py'), Path('bar').joinpath('foo.py'))
    ]
    assert list(get_input_output_paths('foo', 'bar', None)) == [
        InputOutput(Path('foo').joinpath('foo.py'), Path('bar').joinpath('foo.py'))
    ]

# Generated at 2022-06-17 23:56:07.341905
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for single file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for single file with root