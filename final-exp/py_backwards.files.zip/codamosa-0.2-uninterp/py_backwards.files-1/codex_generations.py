

# Generated at 2022-06-17 23:46:33.095805
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [
        InputOutput(Path('foo.py'), Path('bar').joinpath('foo.py'))
    ]
    assert list(get_input_output_paths('foo', 'bar', None)) == [
        InputOutput(Path('foo').joinpath('foo.py'), Path('bar').joinpath('foo.py'))
    ]

# Generated at 2022-06-17 23:46:45.287190
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .utils import get_input_output_paths

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b', None)

    # Test for single file
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]

    # Test for single

# Generated at 2022-06-17 23:46:55.758192
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a').joinpath('a.py'), Path('b').joinpath('a.py'))]

# Generated at 2022-06-17 23:47:02.386856
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b.py', None)) == [
        InputOutput(Path('a/a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:47:11.285028
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:20.681505
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.txt', 'test.txt', None)

    # Test for single file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for directory
    assert list(get_input_output_paths('test', 'test', None)) == [
        InputOutput(Path('test/test.py'), Path('test/test.py'))
    ]

    #

# Generated at 2022-06-17 23:47:31.998968
# Unit test for function get_input_output_paths

# Generated at 2022-06-17 23:47:40.318566
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'test.py', None))

    # Test for single input/output
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for single input/output with root

# Generated at 2022-06-17 23:47:50.434698
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test for input/output pair
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    # test for input/output pair with root
    assert list(get_input_output_paths('a.py', 'b.py', 'c.py')) == [InputOutput(Path('a.py'), Path('b.py'))]
    # test for input/output pair with root
    assert list(get_input_output_paths('a.py', 'b', 'c.py')) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    # test for input/output pair with root

# Generated at 2022-06-17 23:48:00.749392
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test with input and output as python files
    input_ = 'input.py'
    output = 'output.py'
    root = '.'
    input_output = get_input_output_paths(input_, output, root)
    assert input_output == [InputOutput(Path(input_), Path(output))]

    # Test with input as a directory and output as a python file
    input_ = 'input'
    output = 'output.py'
    root = '.'
    input_output = get_input_output_paths(input_, output, root)
    assert input_output == [InputOutput(Path(input_).joinpath('input.py'),
                                        Path(output).joinpath('input.py'))]

    # Test with input as

# Generated at 2022-06-17 23:48:13.633921
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for a single file
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input == Path(input_)
    assert result[0].output == Path(output)

    # Test for a single file in a directory
    input_ = 'input/test.py'
    output = 'output.py'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input == Path(input_)

# Generated at 2022-06-17 23:48:22.885416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:33.493935
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:43.832060
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a').joinpath('a.py'), Path('b').joinpath('a.py'))
    ]

# Generated at 2022-06-17 23:48:55.141867
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:49:03.787274
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for input is a file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:13.602395
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:49:25.383692
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:49:31.000893
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input and output are both files
    input_ = 'test/test_input/test_file.py'
    output = 'test/test_output/test_file.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert result == [InputOutput(Path('test/test_input/test_file.py'), Path('test/test_output/test_file.py'))]

    # Test for input is a file and output is a directory
    input_ = 'test/test_input/test_file.py'
    output = 'test/test_output'
    root = None
    result = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:49:41.162738
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for single file
    paths = get_input_output_paths('test/test.py', 'test/test.py', None)
    assert next(paths) == InputOutput(Path('test/test.py'), Path('test/test.py'))
    with pytest.raises(StopIteration):
        next(paths)

    # Test for single file with output directory

# Generated at 2022-06-17 23:49:58.195923
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:08.550941
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test case 1: input is a file, output is a file
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input_path.name == 'input.py'
    assert result[0].output_path.name == 'output.py'

    # Test case 2: input is a file, output is a directory
    input_ = 'input.py'
    output = 'output'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input_

# Generated at 2022-06-17 23:50:15.675215
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a.py', 'b', 'c')) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:26.317799
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input and output are both files
    input_ = 'test/test_input/test_input_file.py'
    output = 'test/test_output/test_output_file.py'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    input_path, output_path = next(input_output_paths)
    assert input_path == Path('test/test_input/test_input_file.py')
    assert output_path == Path('test/test_output/test_output_file.py')

    # Test for input is a file and output is a directory
    input_ = 'test/test_input/test_input_file.py'
    output = 'test/test_output'
    root = None
    input_output

# Generated at 2022-06-17 23:50:35.959259
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:45.309516
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', 'a')) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:50:54.196363
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'test.py', None))

    # Test for input is a file and output is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a file and output is a directory

# Generated at 2022-06-17 23:51:04.257545
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    input_output_paths = get_input_output_paths(
        'input.py', 'output.py', None)
    assert list(input_output_paths) == [InputOutput(Path('input.py'), Path('output.py'))]

    # Test for input/output pair
    input_output_paths = get_input_output_paths(
        'input.py', 'output', None)
    assert list(input_output_paths) == [InputOutput(Path('input.py'), Path('output/input.py'))]

    # Test for input/output pair
    input_output_paths = get_input_output_paths(
        'input.py', 'output', 'root')

# Generated at 2022-06-17 23:51:14.237617
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    try:
        list(get_input_output_paths('a.py', 'b.py', None))
        assert False
    except InvalidInputOutput:
        assert True

    # Test for input doesn't exists
    try:
        list(get_input_output_paths('a.py', 'b', None))
        assert False
    except InputDoesntExists:
        assert True

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for input is a

# Generated at 2022-06-17 23:51:23.861477
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .utils import get_input_output_paths

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b', None))

    # Test for input is a file

# Generated at 2022-06-17 23:52:53.370603
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for input/output files
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == [
        InputOutput(Path('a/a.py'), Path('b.py'))]

# Generated at 2022-06-17 23:53:02.389730
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:53:12.851897
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input/output as files
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for input as directory, output as file

# Generated at 2022-06-17 23:53:22.281695
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test/input.py', 'test/output.py', None)) == [
        InputOutput(Path('test/input.py'), Path('test/output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:53:31.565341
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:53:39.126583
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import copytree

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        copytree('tests/data/input', temp_dir.joinpath('input'))
        copytree('tests/data/output', temp_dir.joinpath('output'))

        inputs = get_input_output_paths(
            temp_dir.joinpath('input'),
            temp_dir.joinpath('output'),
            temp_dir.joinpath('input')
        )

        assert len(list(inputs)) == 3


# Generated at 2022-06-17 23:53:49.662047
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths(
        'tests/data/input.py', 'tests/data/output.py', None)) == [
            InputOutput(Path('tests/data/input.py'),
                        Path('tests/data/output.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:53:59.806710
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == []
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:54:10.902473
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test/data/input.py', 'output.py', None)) == [
        InputOutput(Path('test/data/input.py'), Path('output.py'))]

    # Test for input is a file

# Generated at 2022-06-17 23:54:16.810869
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test with a single file
    input_ = 'test/test_files/test_file.py'
    output = 'test/test_files/test_file_output.py'
    assert list(get_input_output_paths(input_, output, None)) == [
        InputOutput(Path('test/test_files/test_file.py'),
                    Path('test/test_files/test_file_output.py'))]

    # Test with a single file and an output directory
    input_ = 'test/test_files/test_file.py'
    output = 'test/test_files/test_file_output'