

# Generated at 2022-06-17 23:46:32.966500
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output pair
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input/output pair
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for input/output pair

# Generated at 2022-06-17 23:46:45.216012
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:46:55.758134
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)
    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)
    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    # Test for input is a directory

# Generated at 2022-06-17 23:47:02.386165
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [InputOutput(Path('foo.py'), Path('bar/foo.py'))]
    assert list(get_input_output_paths('foo', 'bar', None)) == [InputOutput(Path('foo/a.py'), Path('bar/a.py')), InputOutput(Path('foo/b.py'), Path('bar/b.py'))]

# Generated at 2022-06-17 23:47:11.284942
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input and output are both files
    input_ = 'test_input/test_file.py'
    output = 'test_output/test_file.py'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    assert input_output_paths == [InputOutput(Path('test_input/test_file.py'), Path('test_output/test_file.py'))]

    # Test for input is a file and output is a directory
    input_ = 'test_input/test_file.py'
    output = 'test_output'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:47:20.658632
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b', None)

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]

    # Test for input is a directory
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

   

# Generated at 2022-06-17 23:47:31.996929
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for a single file
    input_ = 'test/data/test_file.py'
    output = 'test/data/output'
    root = None
    expected = [InputOutput(Path('test/data/test_file.py'),
                            Path('test/data/output/test_file.py'))]
    assert list(get_input_output_paths(input_, output, root)) == expected

    # Test for a directory
    input_ = 'test/data'
    output = 'test/data/output'
    root = None
    expected = [InputOutput(Path('test/data/test_file.py'),
                            Path('test/data/output/test_file.py'))]

# Generated at 2022-06-17 23:47:40.423609
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == []
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:50.448332
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:00.782602
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:48:15.505920
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/data/input.py',
                                       'tests/data/output.py', None)) == [
                                           InputOutput(Path('tests/data/input.py'),
                                                       Path('tests/data/output.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:48:23.837873
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test case 1: input is a file and output is a file
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert result == [InputOutput(Path('input.py'), Path('output.py'))]

    # Test case 2: input is a file and output is a directory
    input_ = 'input.py'
    output = 'output'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert result == [InputOutput(Path('input.py'), Path('output/input.py'))]

    # Test case 3: input is a directory and output is a file
    input

# Generated at 2022-06-17 23:48:33.548597
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))
    ]
    assert list(get_input_output_paths('foo', 'bar', None)) == [
        InputOutput(Path('foo/foo.py'), Path('bar/foo.py'))
    ]
    assert list(get_input_output_paths('foo', 'bar', 'foo')) == [
        InputOutput(Path('foo/foo.py'), Path('bar/foo.py'))
    ]

# Generated at 2022-06-17 23:48:43.937028
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:55.217997
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test with a single file
    input_outputs = list(get_input_output_paths('a.py', 'b.py', None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path('a.py')
    assert input_outputs[0].output == Path('b.py')

    # Test with a directory
    input_outputs = list(get_input_output_paths('a', 'b', None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path('a/a.py')
    assert input_outputs[0].output == Path('b/a.py')

    # Test with a directory and a root
    input_outputs

# Generated at 2022-06-17 23:49:03.854768
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test input is a directory

# Generated at 2022-06-17 23:49:13.657032
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:25.386528
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('./test/test_input/test_input.py',
                                    './test/test_output/test_output.txt',
                                    './test/test_input'))
    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('./test/test_input/test_input.txt',
                                    './test/test_output/test_output.py',
                                    './test/test_input'))
    # Test for input is a file

# Generated at 2022-06-17 23:49:33.415816
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:49:42.777650
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:50:00.364514
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:10.500310
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file and output is a file
    assert list(get_input_output_paths(
        'tests/data/input.py', 'tests/data/output.py', None)) == [
            InputOutput(Path('tests/data/input.py'),
                        Path('tests/data/output.py'))]

    # Test for input is a file and output is a directory

# Generated at 2022-06-17 23:50:21.885130
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:50:31.398110
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:41.937476
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file and output is a file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for input is a

# Generated at 2022-06-17 23:50:48.167629
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for single file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))]

    # Test for single file with root

# Generated at 2022-06-17 23:50:56.200467
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:06.054794
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .types import InputOutput

    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:51:15.026913
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = './test/test_input'
    output = './test/test_output'
    root = './test'
    input_output_paths = get_input_output_paths(input_, output, root)
    for input_output_path in input_output_paths:
        assert input_output_path.input.exists()
        assert input_output_path.input.is_file()
        assert input_output_path.output.parent.exists()
        assert input_output_path.output.parent.is_dir()
        assert input_output_path.output.name == input_output_path.input.name
        assert input_output_path.output.suffix == '.py'

# Generated at 2022-06-17 23:51:20.435223
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'test/test_input'
    output = 'test/test_output'
    root = 'test'
    input_output_paths = get_input_output_paths(input_, output, root)
    for input_output_path in input_output_paths:
        assert input_output_path.input.exists()
        assert input_output_path.output.parent.exists()

# Generated at 2022-06-17 23:51:54.449483
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('foo.py', 'bar.py', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('foo.py', 'bar', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/data/foo.py', 'bar.py', None)) == [
        InputOutput(Path('tests/data/foo.py'), Path('bar.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:52:03.557710
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:52:12.950910
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('input', 'output', None)) == [
        InputOutput(Path('input'), Path('output'))
    ]
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]
    assert list(get_input_output_paths('input.py', 'output', None)) == [
        InputOutput(Path('input.py'), Path('output/input.py'))
    ]
    assert list(get_input_output_paths('input', 'output', 'root')) == [
        InputOutput(Path('input'), Path('output/input'))
    ]

# Generated at 2022-06-17 23:52:23.679583
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .utils import get_input_output_paths
    from pathlib import Path

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for single file input

# Generated at 2022-06-17 23:52:28.890782
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:52:38.198743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_paths = get_input_output_paths('/home/user/project/src/', '/home/user/project/build/', '/home/user/project/')
    assert input_output_paths == [InputOutput(Path('/home/user/project/src/'), Path('/home/user/project/build/'))]
    input_output_paths = get_input_output_paths('/home/user/project/src/', '/home/user/project/build/', None)
    assert input_output_paths == [InputOutput(Path('/home/user/project/src/'), Path('/home/user/project/build/src/'))]

# Generated at 2022-06-17 23:52:48.680813
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for single file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for single file with root
    assert list(get_input_output_paths('a.py', 'b.py', 'a.py'))

# Generated at 2022-06-17 23:52:54.414515
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:53:02.880396
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))
    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'test.py', None))
    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]
    # Test for input is a directory

# Generated at 2022-06-17 23:53:13.496025
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input/output with .py extension
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input/output without .py extension