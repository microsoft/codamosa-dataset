

# Generated at 2022-06-17 23:46:32.822073
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:46:45.102886
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    import os
    import tempfile
    import shutil
    from pathlib import Path

    def create_temp_dir(prefix: str) -> Path:
        """Create a temporary directory."""
        temp_dir = tempfile.mkdtemp(prefix=prefix)
        return Path(temp_dir)

    def create_temp_file(prefix: str, dir_: Path) -> Path:
        """Create a temporary file."""
        temp_file = tempfile.NamedTemporaryFile(prefix=prefix, dir=str(dir_))
        return Path(temp_file.name)

    def create_temp_dir_with_files(prefix: str, dir_: Path,
                                   files: Iterable[str]) -> Path:
        """Create a temporary directory with files."""


# Generated at 2022-06-17 23:46:55.690635
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:02.339968
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    try:
        get_input_output_paths('a.py', 'b.txt', None)
    except InvalidInputOutput:
        pass
    else:
        assert False

    # Test for invalid input
    try:
        get_input_output_paths('a.txt', 'b.txt', None)
    except InputDoesntExists:
        pass
    else:
        assert False

    # Test for single file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test for single file with output directory

# Generated at 2022-06-17 23:47:11.232272
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with a single file
    input_ = 'tests/data/simple_file.py'
    output = 'tests/data/output'
    root = None
    input_output = get_input_output_paths(input_, output, root)
    assert input_output == [InputOutput(Path('tests/data/simple_file.py'),
                                        Path('tests/data/output/simple_file.py'))]

    # Test with a directory
    input_ = 'tests/data/simple_dir'
    output = 'tests/data/output'
    root = None
    input_output = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:47:20.632349
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:47:31.998279
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    input_ = 'input.py'
    output = 'output.py'
    root = None
    input_output = get_input_output_paths(input_, output, root)
    assert input_output == [InputOutput(Path('input.py'), Path('output.py'))]

    # Test for input/output pair with root
    input_ = 'input.py'
    output = 'output.py'
    root = 'root'
    input_output = get_input_output_paths(input_, output, root)
    assert input_output == [InputOutput(Path('input.py'), Path('output.py'))]

    # Test for input/output pair with root
    input_ = 'root/input.py'
    output = 'output.py'

# Generated at 2022-06-17 23:47:40.350609
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test with input and output as files
    input_ = 'test/data/input/test.py'
    output = 'test/data/output/test.py'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    input_path, output_path = next(input_output_paths)
    assert input_path == Path('test/data/input/test.py')
    assert output_path == Path('test/data/output/test.py')

    # Test with input as directory and output as file
    input_ = 'test/data/input'
    output = 'test/data/output/test.py'
    root = None
    input_output_paths = get_input_

# Generated at 2022-06-17 23:47:50.424421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    input_outputs = get_input_output_paths('a.py', 'b.py', None)
    assert next(input_outputs) == InputOutput(Path('a.py'), Path('b.py'))

    # Test for input/output directory
    input_outputs = get_input_output_paths('a.py', 'b', None)
    assert next(input_outputs) == InputOutput(Path('a.py'), Path('b/a.py'))

    # Test for input directory/output directory
    input_outputs = get_input_output_paths('a', 'b', None)
    assert next(input_outputs) == InputOutput(Path('a/a.py'), Path('b/a.py'))

    # Test for input directory/output directory

# Generated at 2022-06-17 23:48:00.754951
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test/test_data/test_file.txt', 'test/test_data/test_file.py', None)
    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test/test_data/test_file.py', 'test/test_data/test_file.py', None)
    # Test for input/output pair

# Generated at 2022-06-17 23:48:14.063433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:23.143157
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:33.521662
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for input and output files
    input_output = get_input_output_paths('test/input.py', 'test/output.py', None)
    assert next(input_output).input_path == Path('test/input.py')
    assert next(input_output).output_path == Path('test/output.py')

    # Test for input file and output directory
    input_output = get_input_output_paths('test/input.py', 'test/output', None)
    assert next(input_output).input_path == Path('test/input.py')
    assert next(input_output).output_path == Path('test/output/input.py')

    # Test for input directory and output directory
    input_output = get_input_output_

# Generated at 2022-06-17 23:48:43.867092
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:48:55.143909
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]

    # Test input is a directory

# Generated at 2022-06-17 23:49:03.787402
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:13.605207
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    input_ = 'test/input/test_input.py'
    output = 'test/output/test_output.py'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)
    assert input_output_paths[0].input_path == Path('test/input/test_input.py')
    assert input_output_paths[0].output_path == Path('test/output/test_output.py')

    # Test for input/output folder
    input_ = 'test/input/test_input.py'
    output = 'test/output'
    root = None
    input_output_paths = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:49:25.383853
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:30.999373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:37.100297
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input/output is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:56.351553
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a.py', 'b', 'c')) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == []

# Generated at 2022-06-17 23:50:02.500751
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:12.256885
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output files
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [InputOutput(Path('input.py'), Path('output.py'))]
    assert list(get_input_output_paths('input.py', 'output', None)) == [InputOutput(Path('input.py'), Path('output/input.py'))]
    assert list(get_input_output_paths('input', 'output.py', None)) == [InputOutput(Path('input/input.py'), Path('output.py'))]
    assert list(get_input_output_paths('input', 'output', None)) == [InputOutput(Path('input/input.py'), Path('output/input.py'))]

# Generated at 2022-06-17 23:50:22.682091
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input/output as files
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))]

    # Test for input as directory and output as file

# Generated at 2022-06-17 23:50:32.315779
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test 1
    input_ = 'test_data/input/test_1.py'
    output = 'test_data/output/test_1.py'
    root = None
    expected = [InputOutput(Path('test_data/input/test_1.py'),
                            Path('test_data/output/test_1.py'))]
    actual = list(get_input_output_paths(input_, output, root))
    assert actual == expected

    # Test 2
    input_ = 'test_data/input'
    output = 'test_data/output'
    root = None

# Generated at 2022-06-17 23:50:42.822926
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b', None)

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b', None)) == \
        [InputOutput(Path('a.py'), Path('b/a.py'))]

    # Test for input is a directory
    assert list(get_input_output_paths('a', 'b', None)) == \
        [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:53.902241
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    # Test for input/output pair with root
    assert list(get_input_output_paths('a.py', 'b.py', 'c.py')) == [InputOutput(Path('a.py'), Path('b.py'))]
    # Test for input/output pair with root
    assert list(get_input_output_paths('a.py', 'b', 'c.py')) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    # Test for input/output pair with root

# Generated at 2022-06-17 23:51:04.021590
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:13.998946
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    # Test 1
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input_path.name == 'input.py'
    assert result[0].output_path.name == 'output.py'

    # Test 2
    input_ = 'input.py'
    output = 'output'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input_path.name == 'input.py'

# Generated at 2022-06-17 23:51:23.641621
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test case 1: input is a file and output is a file
    input_ = 'test_input/test_input_1.py'
    output = 'test_output/test_output_1.py'
    root = None
    result = list(get_input_output_paths(input_, output, root))
    expected = [InputOutput(Path('test_input/test_input_1.py'),
                            Path('test_output/test_output_1.py'))]
    assert result == expected

    # Test case 2: input is a file and output is a directory
    input_ = 'test_input/test_input_1.py'
    output = 'test_output'
    root = None

# Generated at 2022-06-17 23:51:50.450738
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:56.723150
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:52:06.461857
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from pathlib import Path
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for single file input
    assert list(get_input_output_paths('input.py', 'output.py', None)) == \
        [InputOutput(Path('input.py'), Path('output.py'))]

    # Test for

# Generated at 2022-06-17 23:52:16.596421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test for input/output pair
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))]
    # Test for input/output pair with root
    assert list(get_input_output_paths('input.py', 'output', 'root')) == [
        InputOutput(Path('input.py'), Path('output').joinpath('input.py'))]
    # Test for input/output pair with root and output is a file
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.py', 'root'))
    # Test for input/output pair with root and input

# Generated at 2022-06-17 23:52:25.992615
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:52:35.743214
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1: input is a file and output is a file
    input_ = 'test/input/test_input_1.py'
    output = 'test/output/test_output_1.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert next(result) == InputOutput(Path(input_), Path(output))

    # Test case 2: input is a file and output is a directory
    input_ = 'test/input/test_input_1.py'
    output = 'test/output'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert next(result) == InputOutput(Path(input_), Path(output).joinpath(Path(input_).name))

    # Test case 3

# Generated at 2022-06-17 23:52:40.800525
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test input is a file

# Generated at 2022-06-17 23:52:50.768945
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:53:01.596229
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:53:12.226462
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/fixtures/input.py',
                                       'output.py', None)) == [
        InputOutput(Path('tests/fixtures/input.py'), Path('output.py'))
    ]

    # Test for input is a directory