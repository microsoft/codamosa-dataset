

# Generated at 2022-06-17 23:46:33.019366
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    import tempfile
    import shutil

    def create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def create_dir(path):
        os.mkdir(path)

    def create_files(path, files):
        for file in files:
            create_file(os.path.join(path, file), '')

    def create_dirs(path, dirs):
        for dir in dirs:
            create_dir(os.path.join(path, dir))

    def create_tree(path, tree):
        for name, value in tree.items():
            if isinstance(value, dict):
                create_dir(os.path.join(path, name))

# Generated at 2022-06-17 23:46:45.215279
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:46:55.758898
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b.txt', None))

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a.py', 'b.py', None))

    # Test for input is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == \
        [InputOutput(Path('a.py'), Path('b.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:47:02.386433
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test for input is a file and output is a file
    input_ = './test/test_input/test_file.py'
    output = './test/test_output/test_file.py'
    assert list(get_input_output_paths(input_, output, None)) == [
        InputOutput(Path('./test/test_input/test_file.py'),
                    Path('./test/test_output/test_file.py'))
    ]

    # Test for input is a file and output is a directory
    input_ = './test/test_input/test_file.py'
    output = './test/test_output'

# Generated at 2022-06-17 23:47:11.260521
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1
    input_ = 'test/test_input/test_input_1.py'
    output = 'test/test_output/test_output_1.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert list(result) == [InputOutput(Path('test/test_input/test_input_1.py'), Path('test/test_output/test_output_1.py'))]

    # Test 2
    input_ = 'test/test_input/test_input_1.py'
    output = 'test/test_output'
    root = None
    result = get_input_output_paths(input_, output, root)

# Generated at 2022-06-17 23:47:20.660188
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:32.003541
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:47:40.351463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for case 1
    # input_: str, output: str, root: Optional[str]
    # input_: 'a.py', output: 'b.py', root: None
    # expected: [('a.py', 'b.py')]
    input_ = 'a.py'
    output = 'b.py'
    root = None
    expected = [('a.py', 'b.py')]
    actual = get_input_output_paths(input_, output, root)
    assert expected == actual

    # Test for case 2
    # input_: str, output: str, root: Optional[str]
    # input_: 'a.py', output: 'b', root: None
    # expected: [('a.py', 'b/a.py')]

# Generated at 2022-06-17 23:47:50.423859
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('foo.py', 'bar.py', '.'))

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('foo.py', 'bar', '.'))

    # Test for input is a file
    assert list(get_input_output_paths('foo.py', 'bar', '.')) == [
        InputOutput(Path('foo.py'), Path('bar/foo.py'))]

    # Test for input is a directory

# Generated at 2022-06-17 23:48:00.747814
# Unit test for function get_input_output_paths

# Generated at 2022-06-17 23:48:15.337962
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .utils import get_input_output_paths

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('foo.py', 'bar.py', None)

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('foo', 'bar', None)

    # Test for input/output as file
    assert get_input_output_paths('foo.py', 'bar.py', None) == [
        InputOutput(Path('foo.py'), Path('bar.py'))
    ]

    # Test for

# Generated at 2022-06-17 23:48:23.764671
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:48:33.548557
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:48:43.902082
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for input/output pair
    input_ = './test/test_input/test_input.py'
    output = './test/test_output/test_output.py'
    root = './test/test_input'
    input_output_paths = get_input_output_paths(input_, output, root)
    assert input_output_paths[0].input_path == Path(input_)
    assert input_output_paths[0].output_path == Path(output)

    # Test for input/output pair
    input_ = './test/test_input/test_input.py'
    output = './test/test_output'
    root = './test/test_input'

# Generated at 2022-06-17 23:48:55.141890
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/data/a.py', 'tests/data/b.py', None)) == [
        InputOutput(Path('tests/data/a.py'), Path('tests/data/b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:03.787315
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('tests/test_input/a.py',
                                       'tests/test_output/b.py',
                                       None)) == [
        InputOutput(Path('tests/test_input/a.py'),
                    Path('tests/test_output/b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:49:13.603232
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:19.961914
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = './tests/data/input'
    output = './tests/data/output'
    root = './tests/data/input'
    input_output_paths = get_input_output_paths(input_, output, root)
    assert len(list(input_output_paths)) == 2

# Generated at 2022-06-17 23:49:28.517652
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:35.801854
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:49:56.651148
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test/test_input.py', 'test/test_output.py', None)) == [
        InputOutput(Path('test/test_input.py'), Path('test/test_output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:50:02.665935
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:50:12.350753
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test/a.py', 'test/b.py', None)) == [
        InputOutput(Path('test/a.py'), Path('test/b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:50:22.686416
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('/tmp/a.py', '/tmp/b.txt', None)

    # Test for input doesn't exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/tmp/a.py', '/tmp/b.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('/tmp/a.py', '/tmp/b.py', None)) == [
        InputOutput(Path('/tmp/a.py'), Path('/tmp/b.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:50:32.314726
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('invalid.py', 'output.py', None))

    # Test for input is a file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:50:42.824011
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('test/test_data/test_input/test_input.py',
                                       'test/test_data/test_output/test_output.py',
                                       'test/test_data/test_input')) == \
           [InputOutput(Path('test/test_data/test_input/test_input.py'),
                         Path('test/test_data/test_output/test_output.py'))]


# Generated at 2022-06-17 23:50:53.898360
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]

# Generated at 2022-06-17 23:51:03.990005
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test for input/output pair
    input_ = 'input.py'
    output = 'output.py'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert next(result) == InputOutput(Path(input_), Path(output))

    # test for input/output directory
    input_ = 'input.py'
    output = 'output'
    root = None
    result = get_input_output_paths(input_, output, root)
    assert next(result) == InputOutput(Path(input_), Path(output).joinpath(Path(input_).name))

    # test for input/output directory with root
    input_ = 'input.py'
    output = 'output'
    root = 'root'
    result = get_input_output_path

# Generated at 2022-06-17 23:51:14.000276
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:51:23.643111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test.py', 'test.txt', None))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.txt', 'test.py', None))

    # Test for single file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for single file with output directory

# Generated at 2022-06-17 23:52:40.708997
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    # Test invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'b', None))

    # Test input doesn't exist
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('a', 'b', None))

    # Test input is a file and output is a file
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))]

    # Test input is a file and output is a directory

# Generated at 2022-06-17 23:52:50.735711
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .types import InputOutput

    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.py', 'output.txt', None))

    # Test for non-existing input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('input.py', 'output.py', None))

    # Test for input/output pair
    assert list(get_input_output_paths('input.py', 'output.py', None)) == [
        InputOutput(Path('input.py'), Path('output.py'))
    ]

    #

# Generated at 2022-06-17 23:53:01.540225
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for input doesn't exists
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for input is a file
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [
        InputOutput(Path('test.py'), Path('test.py'))
    ]

    # Test for input is a directory

# Generated at 2022-06-17 23:53:12.187107
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:53:21.722437
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)
    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)
    # Test for valid input/output
    assert list(get_input_output_paths('test.py', 'test.py', None)) == [InputOutput(Path('test.py'), Path('test.py'))]
    # Test for valid input/output with root
    assert list(get_input_output_paths('test.py', 'test', 'test')) == [InputOutput(Path('test.py'), Path('test/test.py'))]
   

# Generated at 2022-06-17 23:53:30.829820
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', 'a')) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-17 23:53:38.485410
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.py', 'test.txt', None)

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test.py', 'test.py', None)

    # Test for single file
    input_output_paths = get_input_output_paths('test.py', 'test.py', None)
    assert next(input_output_paths) == InputOutput(Path('test.py'), Path('test.py'))

    # Test for single file with root
    input_output_paths = get_input_output_paths('test.py', 'test.py', 'root')

# Generated at 2022-06-17 23:53:49.031745
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b').joinpath('a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a').joinpath('a.py'), Path('b').joinpath('a.py'))
    ]

# Generated at 2022-06-17 23:53:54.619517
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Test case 1: input is a file, output is a file
    input_ = 'test/input/test_file.py'
    output = 'test/output/test_file.py'
    root = 'test/input'
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input_path == Path('test/input/test_file.py')
    assert result[0].output_path == Path('test/output/test_file.py')

    # Test case 2: input is a file, output is a directory
    input_ = 'test/input/test_file.py'
    output = 'test/output'
    root = 'test/input'
   

# Generated at 2022-06-17 23:54:02.337534
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [
        InputOutput(Path('a.py'), Path('b.py'))
    ]
    assert list(get_input_output_paths('a.py', 'b', None)) == [
        InputOutput(Path('a.py'), Path('b/a.py'))
    ]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))
    ]