

# Generated at 2022-06-21 17:13:00.874800
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = list(get_input_output_paths('tests/data',
                                               'tests/output',
                                               'tests/data'))
    assert len(input_output) == 3
    input_output = list(get_input_output_paths('tests/data/autopep8.py',
                                               'tests/output/autopep8.py',
                                               'tests/data'))
    assert len(input_output) == 1

# Generated at 2022-06-21 17:13:08.270431
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    input_ = 'in'
    output = 'out'
    root = 'in'
    input_output_paths = get_input_output_paths(input_, output, root)
    for input_output_path in input_output_paths:
        pass


# Generated at 2022-06-21 17:13:17.467397
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory
    from shutil import copytree

    with TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)
        root_source = temp_dir_path.joinpath('root_source')
        root_source.mkdir()
        source_file1 = root_source.joinpath('source1.py')
        source_file2 = root_source.joinpath('source2.py')
        source_file1.touch()
        source_file2.touch()
        target = temp_dir_path.joinpath('target')
        target.mkdir()
        target_file1 = target.joinpath('source1.py')
        target_file2 = target.joinpath('source2.py')
        target_dir = target.joinpath('dir')

# Generated at 2022-06-21 17:13:26.146989
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        paths = get_input_output_paths("invalid", "invalid", "invalid")
    except InputDoesntExists:
        pass
    else:
        assert False, "Invalid input file should raise InputDoesntExists exception"

    try:
        paths = get_input_output_paths("tests/input/valid_input.py", "tests/input/invalid_input_output.py", "invalid")
    except InvalidInputOutput:
        pass
    else:
        assert False, "Invalid input/output files should raise InvalidInputOutput exception"

    paths = get_input_output_paths("tests/input/valid_input.py", "tests/input/valid_input.py", "invalid")

# Generated at 2022-06-21 17:13:37.843501
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/home/foo.py', '/tmp/bar.py', None)) == \
        [InputOutput(Path('/home/foo.py'), Path('/tmp/bar.py'))]
    assert list(get_input_output_paths('/home', '/tmp/bar.py', None)) == \
        [InputOutput(Path('/home/foo.py'), Path('/tmp/bar.py/foo.py'))]
    assert list(get_input_output_paths('/home', '/tmp/bar.py', '/home')) == \
        [InputOutput(Path('/home/foo.py'), Path('/tmp/bar.py/foo.py'))]

# Generated at 2022-06-21 17:13:49.332274
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for collection of directory and file
    assert list(get_input_output_paths(
        "input/", "output/", None)) == [
        InputOutput(input_file=Path('./input/directory/file1.py'),
                    output_file=Path('./output/directory/file1.py')),
        InputOutput(input_file=Path('./input/directory/file2.py'),
                    output_file=Path('./output/directory/file2.py'))
    ]

    # Test for single file

# Generated at 2022-06-21 17:14:00.152661
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    test_case = [
        ('test/test.py', 'test/tmp/', 'test/'),
        ('test/test.py', 'test/tmp/test.js', ''),
        ('test/', 'test/tmp/', ''),
        ('test/', 'test/tmp/', None),
        ('test/', 'test/tmp/', 'test'),
        ('test/', 'test/tmp/', 'test/')
    ]

# Generated at 2022-06-21 17:14:10.495666
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (set(get_input_output_paths('hello.py',
                                       'output.py',
                                       root='.')) ==
            {InputOutput(Path('hello.py'),
                         Path('output.py'))})

    assert (set(get_input_output_paths('hello.py', 'output',
                                       root='.')) ==
            {InputOutput(Path('hello.py'),
                         Path('output').joinpath('hello.py'))})

    assert (set(get_input_output_paths('.', 'output',
                                       root='.')) ==
            {InputOutput(Path('hello.py'),
                         Path('output').joinpath('hello.py'))})


# Generated at 2022-06-21 17:14:18.930615
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(
        '../_doc/sources', '../_doc/sources', '../_doc') == [InputOutput(
            Path('../_doc/sources/darglint.py'),
            Path('../_doc/sources/darglint.py'))]
    assert get_input_output_paths(
        '../_doc/sources', '../_doc/sources', None) == [InputOutput(
            Path('../_doc/sources/darglint.py'),
            Path('../_doc/sources/darglint.py'))]

# Generated at 2022-06-21 17:14:28.846482
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input1 = 'path/to/foo'
    output1 = 'path/to/bar'
    root1 = 'path/to'
    result1 = get_input_output_paths(input1, output1, root1)
    expected1 = [
        InputOutput(Path('path/to/foo'), Path('path/to/bar/foo'))
    ]
    assert result1 == expected1

    input2 = 'path/to/foo'
    output2 = 'path/to/bar.py'
    root2 = 'path/to'
    result2 = get_input_output_paths(input2, output2, root2)
    expected2 = [
        InputOutput(Path('path/to/foo'), Path('path/to/bar.py'))
    ]
    assert result2 == expected2

# Generated at 2022-06-21 17:14:40.478799
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

# Generated at 2022-06-21 17:14:50.276612
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    input_output = get_input_output_paths('/home/user/project/src/dir/dir1/dir2/main.py',
                                          '/home/user/project/dst/dir/dir1/dir2/main.py',
                                          None)
    assert [x for x in input_output] == [(Path('/home/user/project/src/dir/dir1/dir2/main.py'),
                                          Path('/home/user/project/dst/dir/dir1/dir2/main.py'))]


# Generated at 2022-06-21 17:14:57.221588
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path1 = get_input_output_paths('input.py', 'output.py', '.')[0]
    assert path1.input == Path('input.py')
    assert path1.output == Path('output.py')

    path1 = get_input_output_paths('input.py', 'output.py', '.')[0]
    assert path1.input == Path('input.py')
    assert path1.output == Path('output.py')

    path2 = get_input_output_paths('input', 'output', '.')[0]
    assert path2.input == Path('input')
    assert path2.output == Path('output')

    path3 = get_input_output_paths('input', 'output', '.')[0]
    assert path3.input == Path('input')
    assert path

# Generated at 2022-06-21 17:15:09.272347
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import shutil
    from os.path import abspath, join, dirname
    from os import mkdir
    from tempfile import mkdtemp
    from base64 import urlsafe_b64encode
    from .pipfile import Pipfile
    from .utils import normalize_path

    # Create temp directory
    tmp = mkdtemp()
    config = abspath(join(dirname(__file__), 'configs'))
    # Create temp pipfile config
    pipfile = join(tmp, 'Pipfile.lock')
    shutil.copyfile(join(config, 'Pipfile.lock'), pipfile)

    # Create temp python file
    input_code = urlsafe_b64encode(
            'import requests\nprint(requests)').decode('utf-8')

# Generated at 2022-06-21 17:15:20.173610
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(input_ = 'input', output = 'output', root = None) == None
    assert get_input_output_paths(input_ = 'input.py', output = 'output.py', root = None) == None
    # assert get_input_output_paths(input_ = '', output = 'output.py', root = None) == InputDoesntExists
    # assert get_input_output_paths(input_ = 'input.py', output = 'output', root = None) == InvalidInputOutput
    assert get_input_output_paths(input_ = 'input', output = 'output', root = 'input/child') == None
    assert get_input_output_paths(input_ = 'input', output = 'output', root = 'input/child') == None
    assert get_

# Generated at 2022-06-21 17:15:30.649839
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('tests/repo2/a.py', 'b.py', 'tests/repo2'))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('tests/bad_input', 'tests/output', 'tests/repo2'))
    #Single file
    assert list(get_input_output_paths('tests/repo2/a.py', 'tests/output', 'tests/repo2')) == [InputOutput(Path(__file__).parent.joinpath('repo2/a.py'), Path(__file__).parent.joinpath('output/a.py'))]

# Generated at 2022-06-21 17:15:36.584747
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Test input is a directory
    assert get_input_output_paths('.', '.', None) == []
    assert get_input_output_paths('.', 'out', '.') == []
    assert get_input_output_paths('.', 'out2', '.') == []

    # Test output is a directory
    assert get_input_output_paths('file.py', 'fileout.py', '') == \
        [InputOutput(Path('file.py'), Path('fileout.py'))]
    assert get_input_output_paths('file.py', 'fileout.py', '.') == \
        [InputOutput(Path('file.py'), Path('fileout.py'))]

# Generated at 2022-06-21 17:15:48.787786
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/path/to/root/a1.py'
    root = '/path/to/root'
    output = '/path/to/out/a2.py'
    # Case 1: if input_ is a file and output is a file
    res = list(get_input_output_paths(input_, output, root))
    assert res == [InputOutput(Path(input_), Path(output))]

    # Case 2: if input_ is a file and output is a directory
    output = '/path/to/out'
    input_ = '/path/to/root/a1.py'
    res = list(get_input_output_paths(input_, output, root))
    assert res == [InputOutput(Path(input_), Path(output).joinpath('a1.py'))]

    #

# Generated at 2022-06-21 17:16:01.352402
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:16:12.904786
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = None
    input_ = 'example.py'
    output = 'output'
    result = list(get_input_output_paths(input_, output, root))
    assert len(result) == 1
    assert result[0].input.name == 'example.py'
    assert result[0].output.parent == Path('output')
    assert result[0].input.stem == result[0].output.stem

    input_ = 'example.txt'
    with pytest.raises(InvalidInputOutput) as info:
        list(get_input_output_paths(input_, output, root))
    assert info.value.args[0] == 'Input and output should be of the same type'

    input_ = 'example.py'
    output = 'output.txt'

# Generated at 2022-06-21 17:16:24.281539
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '../tests/test_data/sample_in'
    output = '../tests/test_data/sample_out'
    root = input_
    pairs = list(get_input_output_paths(input_, output, root))
    assert pairs[0] == InputOutput(Path('../tests/test_data/sample_in/test_in.py'),
                                   Path('../tests/test_data/sample_out/test_in.py'))
    assert pairs[1] == InputOutput(Path('../tests/test_data/sample_in/test_in2.py'),
                                   Path('../tests/test_data/sample_out/test_in2.py'))
    input_ = '../tests/test_data'
    output = '../tests/test_data/sample_out'
   

# Generated at 2022-06-21 17:16:33.692036
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test/input_py', 'test/output', None)) == [InputOutput(Path('test/input_py'), Path('test/output'))]
    assert list(get_input_output_paths('test/input_dir', 'test/output', None)) == [InputOutput(Path('test/input_dir/input_py'), Path('test/output/input_py'))]
    assert list(get_input_output_paths('test/input_dir', 'test/output', 'test')) == [InputOutput(Path('test/input_dir/input_py'), Path('test/output/input_dir/input_py'))]

# Generated at 2022-06-21 17:16:43.113946
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:16:53.201164
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a.py', 'b.py', None) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert get_input_output_paths('a', 'b', None) == \
        [InputOutput(Path('a/foo.py'), Path('b/foo.py'))]
    assert get_input_output_paths('a', 'b', 'a') == \
        [InputOutput(Path('a/foo.py'), Path('b/foo.py'))]
    assert get_input_output_paths('a', 'b', 'c') == \
        [InputOutput(Path('a/foo.py'), Path('b/a/foo.py'))]


# Generated at 2022-06-21 17:17:03.859637
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths"""
    from nose2.tools import params
    from nose2.events import Plugin

    class TestPlugin(Plugin):

        def __init__(self):
            self.input_outputs = []

        def startTestRun(self, event):
            try:
                self.input_outputs = get_input_output_paths(
                    event.test.test.test_input, event.test.test.test_output,
                    event.test.test.test_root)
            except Exception as e:
                self.last_exception = e
            else:
                self.last_exception = None

        def getTestedInputs(self, event):
            for input_output in self.input_outputs:
                event.handled = True

# Generated at 2022-06-21 17:17:13.371369
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/home/test/test_input'
    output = '/home/test/test_output'
    root = '/home/test'

# Generated at 2022-06-21 17:17:20.741599
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = []
    paths = []
    paths.append(('A/aa.py', 'B/aa.py'))
    paths.append(('A/B/bb.py', 'C/bb.py'))
    paths.append(('D/dd.py', 'E'))
    paths.append(('F/', 'G'))
    paths.append(('H/ii.py', 'I/ii.py'))
    paths.append(('J/', 'K/'))
    paths.append(('L/', 'M/'))
    for p in paths:
        input_output.append(get_input_output_paths(p[0], p[1], 'A'))

# Generated at 2022-06-21 17:17:31.168531
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:17:41.407926
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = list(get_input_output_paths(input_='./test_dir',
                                         output='./output/dir2',
                                         root=None))
    expected = [
        InputOutput(Path('./test_dir/a.py'), Path('./output/dir2/a.py')),
        InputOutput(Path('./test_dir/b.py'), Path('./output/dir2/b.py')),
        InputOutput(Path('./test_dir/b/c.py'), Path('./output/dir2/b/c.py'))
    ]
    assert result == expected

# Generated at 2022-06-21 17:17:54.103369
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('toto.py', '', None))

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('toto.py', '.', None))

    res = list(get_input_output_paths('toto.py', 'titi.py', None))
    assert res == [InputOutput(Path('toto.py'),  Path('titi.py'))]

    res = list(get_input_output_paths('toto.py', 'titi', None))
    assert res == [InputOutput(Path('toto.py'),  Path('titi/toto.py'))]


# Generated at 2022-06-21 17:18:04.752379
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Check if a single file is correctly processed
    input_output_paths = get_input_output_paths(
        input_='test_folder/test_file.py',
        output='test_output',
        root=None)
    assert input_output_paths == [InputOutput(Path('test_folder/test_file.py'),
                                              Path('test_output/test_file.py'))]

    # Check if an entire folder is correctly processed
    input_output_paths = get_input_output_paths(
        input_='test_folder',
        output='test_output',
        root=None)
    input_output_paths = [path for path in input_output_paths]
    assert len(input_output_paths) == 2

# Generated at 2022-06-21 17:18:15.592498
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # check when input and output are directories
    assert list(get_input_output_paths('test_input', 'test_output', None)) == [InputOutput(Path('test_input/m.py'), Path('test_output/m.py'))]
    assert list(get_input_output_paths('test_input', 'test_output', 'test_input')) == [InputOutput(Path('test_input/m.py'), Path('test_output/m.py'))]
    assert list(get_input_output_paths('test_input', 'test_output/dir1', None)) == [InputOutput(Path('test_input/m.py'), Path('test_output/dir1/m.py'))]

# Generated at 2022-06-21 17:18:23.650236
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("a.py","b.py")) == [InputOutput(Path("a.py"),Path("b.py"))]
    assert list(get_input_output_paths("a","b.py")) ==[InputOutput(Path("a"),Path("b.py"))]
    assert list(get_input_output_paths("a/b.py","b.py")) == [InputOutput(Path("a/b.py"),Path("b.py/b.py"))]

# Generated at 2022-06-21 17:18:32.832459
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths function."""
    os.mkdir("temp_get_input_output_paths")
    os.chdir("temp_get_input_output_paths")
    Path("file").touch()
    Path("folder").mkdir()
    Path("folder/file").touch()

    func = get_input_output_paths(".", ".", "")
    assert func is not None

    io_list = list(func)
    assert len(io_list) == 0

    func = get_input_output_paths("file", "folder", "")
    assert func is not None
    io_list = list(func)
    assert len(io_list) == 1

    func = get_input_output_paths("folder", "folder", "")
    assert func is not None

# Generated at 2022-06-21 17:18:44.765773
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .utils import temporary_directory

    with temporary_directory() as temp_dir:

        # Create input/output files
        with open(temp_dir.path('input.py'), 'w') as input_file:
            input_file.write('\n')
        with open(temp_dir.path('input/__init__.py'), 'w') as input_file:
            input_file.write('\n')
        with open(temp_dir.path('input/submodule.py'), 'w') as input_file:
            input_file.write('\n')
        temp_dir.path('input/submodule/__init__.py').touch()
        temp_dir.path('input/submodule/subsubmodule.py').touch()

# Generated at 2022-06-21 17:18:55.002167
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("file1.py", "file2", "test"))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("file1.py", "file2.py", "test"))

    assert list(get_input_output_paths("file1.py", "output", None)) == \
           [InputOutput(Path("file1.py"), Path("output/file1.py"))]

    assert list(get_input_output_paths("dir", "output", None)) == \
           [InputOutput(Path("dir/file.py"), Path("output/file.py"))]


# Generated at 2022-06-21 17:19:02.514792
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test 1
    input_ = 'a.py'
    output = 'b.py'

    ret_val = next(get_input_output_paths(input_, output, None))
    assert ret_val == InputOutput(Path('a.py'), Path('b.py'))

    # test 2
    input_ = 'a.py'
    output = 'b'

    ret_val = next(get_input_output_paths(input_, output, None))
    assert ret_val == InputOutput(Path('a.py'), Path('b/a.py'))

    # test 3
    input_ = 'a'
    output = 'b'

    ret_val = next(get_input_output_paths(input_, output, None))

# Generated at 2022-06-21 17:19:13.290917
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test if input ends with and output does not
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('abc.py', 'def', None)

    # Test if output path does not exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('abc.py', 'def.py', 'ghi')

    # Test if input ends with and output ends with
    assert list(get_input_output_paths('abc.py', 'def.py', 'ghi')) == [
        InputOutput(Path('abc.py'), Path('def.py'))
    ]

    # Test if input ends with and output does not end with

# Generated at 2022-06-21 17:19:20.387093
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test 1
    input_ = '/home/location'
    output = '/home/location'
    root = None
    
    input_output_paths = get_input_output_paths(input_, output, root)
    for pair in input_output_paths:
        input_path = pair.input_path
        output_path = pair.output_path

        assert str(input_path) != str(output_path)


# Generated at 2022-06-21 17:19:21.120600
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pass

# Generated at 2022-06-21 17:19:41.486550
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    expected = [
        InputOutput(Path('a'), Path('b')),
        InputOutput(Path('a/b.py'), Path('b/b.py')),
        InputOutput(Path('a/c.py') ,Path('b/c.py')),
        InputOutput(Path('a/d.py'), Path('b/d.py')),
    ]
    assert list(get_input_output_paths('a', 'b', None)) == expected
    expected = [
        InputOutput(Path('a/b.py'), Path('b/b.py')),
        InputOutput(Path('a/c.py') ,Path('b/c.py')),
        InputOutput(Path('a/d.py'), Path('b/d.py')),
    ]

# Generated at 2022-06-21 17:19:50.191276
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for a single py
    input_output = get_input_output_paths(
        '/root/1.py',
        '/root/output/1.py',
        '/root',
    )
    assert list(input_output) == [InputOutput(
        Path('/root/1.py'),
        Path('/root/output/1.py'),
    )]

    # Test for a folder
    input_output = get_input_output_paths(
        '/root/1/1.py',
        '/root/output/1/1.py',
        '/root',
    )
    assert list(input_output) == [InputOutput(
        Path('/root/1/1.py'),
        Path('/root/output/1/1.py'),
    )]

    # Test for a single root folder

# Generated at 2022-06-21 17:19:59.378047
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test_data/test1.py',
                                       'test_data/test2',
                                       None)) == [
        InputOutput(Path('test_data/test1.py'),
                    Path('test_data/test2/test1.py'))]
    assert list(get_input_output_paths('test_data/test1',
                                       'test_data/test2',
                                       None)) == [
        InputOutput(Path('test_data/test1/test1.py'),
                    Path('test_data/test2/test1.py'))]

# Generated at 2022-06-21 17:20:05.331045
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:20:13.455346
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./src/LICENSE', './output/')) == [
        InputOutput(Path('./src/LICENSE'), Path('./output/LICENSE'))
    ]
    assert list(get_input_output_paths('./src/LICENSE.py', './output/')) == [
        InputOutput(Path('./src/LICENSE.py'), Path('./output/LICENSE.py'))
    ]

# Generated at 2022-06-21 17:20:21.900050
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    tmp_input_path = Path('.tmp_input')
    tmp_input_path.mkdir()
    tmp_output_path = Path('.tmp_output')
    tmp_output_path.mkdir()
    counter = 0

    def _gen_file(root, file):
        full = (root / file)
        full.parent.mkdir(exist_ok=True, parents=True)
        full.touch()

        return full

    def _gen_test():
        nonlocal counter
        counter += 1
        return (
            f'tmp_input_{counter}',
            f'tmp_output_{counter}',
            None if counter in [1, 2, 7] else 'tmp_input_{counter - 1}'
        )


# Generated at 2022-06-21 17:20:32.952301
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # If input and output are files
    input_, output = 'input.py', 'output.py'
    paths = get_input_output_paths(input_, output, None)
    assert paths
    assert isinstance(paths, Iterable)
    assert tuple(paths) == (InputOutput(Path('input.py'), Path('output.py')),)

    # If output is an existing python script
    input_, output = 'input', 'output.py'
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(input_, output, None)

    # If input is a directory and output is a file
    input_, output = 'input', 'output'

# Generated at 2022-06-21 17:20:43.944664
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""
    input = "input"
    output = "output"
    input2 = "input2"
    input3 = "input3"
    output2 = "output2"
    root = "root"

    # Pathlib.Path does not have __eq__ implemented.
    if sys.version_info.major == 3 and sys.version_info.minor == 5:
        assert str(get_input_output_paths(input, output, None)[0].input) == "input"
        assert str(get_input_output_paths(input, output, None)[0].output) == "output"
        assert str(get_input_output_paths(input2, output, None)[0].input) == "input2"

# Generated at 2022-06-21 17:20:50.058366
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    assert get_input_output_paths('file.py', 'file.py', None) == InputOutput('file.py', 'file.py')



# Generated at 2022-06-21 17:21:02.646448
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        '/home/mark/app.py', '/home/mark/output.py', None
    )) == [
        InputOutput(Path('/home/mark/app.py'), Path('/home/mark/output.py'))
    ]
    assert list(get_input_output_paths(
        '/home/mark/app.py', '/home/mark/output/', None
    )) == [
        InputOutput(Path('/home/mark/app.py'), Path('/home/mark/output/app.py'))
    ]

# Generated at 2022-06-21 17:22:15.961969
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('src/file.py', 'dst/file.py',
             None)) == [InputOutput(Path('src/file.py'),
             Path('dst/file.py'))]


# Generated at 2022-06-21 17:22:24.546105
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""
    pairs = get_input_output_paths("a.py", "b.py", None)
    pairs = list(pairs)
    assert len(pairs) == 1
    assert pairs[0].input == Path("a.py")
    assert pairs[0].output == Path("b.py")

    pairs = get_input_output_paths("a.py", "b", None)
    pairs = list(pairs)
    assert len(pairs) == 1
    assert pairs[0].input == Path("a.py")
    assert pairs[0].output == Path("b/a.py")

    pairs = get_input_output_paths("a.py", "b", "foo")
    pairs = list(pairs)

# Generated at 2022-06-21 17:22:33.337634
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from pylama.lint import InvalidInputOutput

    # Parse normal input
    input_ = Path('/tmp/input/test.py')
    output = Path('/tmp/output/')
    root = Path('/tmp/input/')
    expected = InputOutput(input_, Path('/tmp/output/test.py'))
    assert next(get_input_output_paths(str(input_), str(output), str(root))) == expected

    # Parse glob input
    input_ = Path('/tmp/input/')
    output = Path('/tmp/output/')
    root = Path('/tmp/input/')
    expected = InputOutput(Path('/tmp/input/test.py'), Path('/tmp/output/test.py'))

# Generated at 2022-06-21 17:22:45.002925
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths path generation."""
    from pytest import raises
    from pathlib import Path

    input_ = 'test/data/folder'
    output = 'test/output/folder'
    for paths in get_input_output_paths(input_, output, input_):
        print(paths)
        assert paths.input.exists()
        assert not paths.output.exists()
    for paths in get_input_output_paths(Path(input_), output, input_):
        print(paths)
        assert paths.input.exists()
        assert not paths.output.exists()
    for paths in get_input_output_paths(input_, Path(output), input_):
        print(paths)
        assert paths.input.exists()

# Generated at 2022-06-21 17:22:54.448463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('example.py', 'example.py', None)) == [InputOutput('example.py', 'example.py')]
    assert list(get_input_output_paths('example.py', 'example.py', '.')) == [InputOutput('example.py', 'example.py')]
    assert list(get_input_output_paths('example.py', '', None)) == [InputOutput('example.py', 'example.py')]
    assert list(get_input_output_paths('example.py', '', '.')) == [InputOutput('example.py', 'example.py')]
    assert list(get_input_output_paths('example.py', 'foo', '.')) == [InputOutput('example.py', 'foo/example.py')]