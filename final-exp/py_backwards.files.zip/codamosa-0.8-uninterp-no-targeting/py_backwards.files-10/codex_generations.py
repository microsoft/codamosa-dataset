

# Generated at 2022-06-21 17:13:02.867110
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test/in.py', 'test/out.py', '')) == \
        [InputOutput(Path('test/in.py'), Path('test/out.py'))]
    assert list(get_input_output_paths('in.py', 'test/out', '')) == \
        [InputOutput(Path('in.py'), Path('test/out/in.py'))]
    assert list(get_input_output_paths('test', 'test/out', '')) == \
        [InputOutput(Path('test/in.py'), Path('test/out/in.py')),
         InputOutput(Path('test/other.py'), Path('test/out/other.py'))]

# Generated at 2022-06-21 17:13:14.126079
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Testing get_input_output_paths function
    """
    # Testing exceptions
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test.txt', 'test.py', None)
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test', 'test', None)

    # Testing input and output
    for input_, output in get_input_output_paths('test.py', 'test.py', None):
        assert input_ == Path('test.py')
        assert output == Path('test.py')

    # Testing input and output

# Generated at 2022-06-21 17:13:24.838298
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # If input is a file and output is a file
    # the function should return a one InputOutput path
    input = 'dummy/input/file1.py'
    output = 'dummy/output/file1.py'
    input_output_paths = get_input_output_paths(input, output,
                                                None)
    assert(len(list(input_output_paths)) == 1)
    input_output_paths = list(input_output_paths)
    assert(input_output_paths[0].input == Path("dummy/input/file1.py"))
    assert(input_output_paths[0].output == Path("dummy/output/file1.py"))

    # If input is a file and output is a directory
    # the function should return a one InputOutput path
   

# Generated at 2022-06-21 17:13:38.189387
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    input_output_directory = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.dirname(input_output_directory)
    input_dir = os.path.join(input_output_directory, 'input')
    output_dir = os.path.join(input_output_directory, 'output')
    test_file = os.path.join(input_dir, 'file.py')
    test_file2 = os.path.join(input_dir, 'file2.py')
    test_file_output = os.path.join(input_output_directory, 'output.py')
    test_file_output2 = os.path.join(output_dir, 'file2.py')

# Generated at 2022-06-21 17:13:49.513258
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test.py', 'output')) == [
        InputOutput(Path('test.py'), Path('output/test.py'))
    ]
    assert list(get_input_output_paths('dir/test.py', 'output')) == [
        InputOutput(Path('dir/test.py'), Path('output/test.py'))
    ]
    assert list(get_input_output_paths('dir/test.py', 'output', 'dir')) == [
        InputOutput(Path('dir/test.py'), Path('output/test.py'))
    ]

# Generated at 2022-06-21 17:13:58.969316
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('input', 'output', None)) == [
        InputOutput(Path('input'), Path('output'))
    ]

    assert list(get_input_output_paths('input/a.py', 'output', None)) == [
        InputOutput(Path('input/a.py'), Path('output/a.py'))
    ]

    assert list(get_input_output_paths('input', 'output', 'input')) == [
        InputOutput(Path('input/a.py'), Path('output/a.py'))
    ]


# Generated at 2022-06-21 17:14:03.993711
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('file.py', 'dir', None)) == [InputOutput(Path('file.py'), Path('dir/file.py'))]

    assert list(get_input_output_paths('dir', 'output', 'dir')) == [InputOutput(Path('dir/foo/bar.py'), Path('output/foo/bar.py'))]

# Generated at 2022-06-21 17:14:12.406674
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 0: input is a file, output is a file
    input0 = './test/0/input.py'
    output0 = './test/0/output.py'
    expected0 = [InputOutput(Path(input0), Path(output0))]

    assert get_input_output_paths(input0, output0, None) == expected0

    # Test case 1: input is a file, output is a directory
    input1 = './test/1/input.py'
    output1 = './test/1/output'
    root1 = 'test/1'
    expected1 = [InputOutput(Path(input1), Path(output1).joinpath('input.py'))]

    assert get_input_output_paths(input1, output1, root1) == expected1

    # Test case

# Generated at 2022-06-21 17:14:19.162546
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_="tests/files/",
        output="tests/files_output/"
    )) == [
        InputOutput(Path("tests/files/complex.py"), Path("tests/files_output/complex.py")),
        InputOutput(Path("tests/files/foo.py"), Path("tests/files_output/foo.py")),
        InputOutput(Path("tests/files/foor.py"), Path("tests/files_output/foor.py")),
        InputOutput(Path("tests/files/foos.py"), Path("tests/files_output/foos.py")),
        InputOutput(Path("tests/files/simple.py"), Path("tests/files_output/simple.py")),
    ]

# Generated at 2022-06-21 17:14:28.876613
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    from pytest import raises
    with raises(InvalidInputOutput):
        get_input_output_paths("a.py", "b", "")
    with raises(InvalidInputOutput):
        get_input_output_paths("a", "b.py", "")
    with raises(InputDoesntExists):
        get_input_output_paths("a.py", "b.py", "")
    ios = get_input_output_paths("tests/input/a.py", "tests/output/b.py", "")
    assert next(ios) == InputOutput(Path("tests/input/a.py"), Path("tests/output/b.py"))

# Generated at 2022-06-21 17:14:36.246947
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    input_ = "/home/user/foo/aaa.py"
    output = "/home/user/bar"
    root = "/home/user/foo"

    # When
    input_output_paths = get_input_output_paths(input_, output, root)
    result = next(input_output_paths)

    # Then
    assert input_ == str(result.input_path)
    assert "/home/user/bar/aaa.py" == str(result.output_path)


# Generated at 2022-06-21 17:14:42.556284
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InputDoesntExists, InvalidInputOutput
    from .utils import get_input_output_paths
    import pytest
    from pathlib import Path

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_="src/test.py", output="test.py", root=None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(
            input_="src/test.pyy", output="test.py", root=None))


# Generated at 2022-06-21 17:14:51.098756
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    
    assert get_input_output_paths("tests/input-output","tests/output","tests/input-output")==[InputOutput(PurePosixPath('tests/input-output/a.py'), PurePosixPath('tests/output/a.py')), InputOutput(PurePosixPath('tests/input-output/b.py'), PurePosixPath('tests/output/b.py'))]
    assert get_input_output_paths("tests/input-output/a.py","tests/output/a.py","tests/input-output")==[InputOutput(PurePosixPath('tests/input-output/a.py'), PurePosixPath('tests/output/a.py'))]

# Generated at 2022-06-21 17:15:01.121537
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:15:03.290374
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_pairs = get_input_output_paths('./my/test/input', './my/test/output', './my')
    assert not input_output_pairs

# Generated at 2022-06-21 17:15:10.924428
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # when input is a single .py file and output is a .py file
    input_ = 'input'
    output = 'output'
    assert get_input_output_paths(input_, output, None) == [
        InputOutput(Path(input_), Path(output))
    ]

    # when input and output are directories
    input_ = 'input'
    output = 'output'
    root = 'root'
    input_path = Path(input_).joinpath(
        Path('root').joinpath(
            Path('a.py')))
    output_path = Path(output).joinpath(
        Path('root').joinpath(
            Path('a.py')))
    assert get_input_output_paths(
        input_, output, root) == [InputOutput(input_path, output_path)]



# Generated at 2022-06-21 17:15:19.424683
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [str(path) for path in get_input_output_paths('test_input.py', 'test_output.py', None)] == \
        [str(p) for p in [
            Path('test_input.py'),
            Path('test_output.py')
        ]]
    assert [str(path) for path in get_input_output_paths('test_input.py', 'test_output', None)] == \
        [str(p) for p in [
            Path('test_input.py'),
            Path('test_output/test_input.py')
        ]]

# Generated at 2022-06-21 17:15:30.418169
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_outputs = list(get_input_output_paths('input.py', 'outout.py', root=None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path('input.py')
    assert input_outputs[0].output == Path('outout.py')

    input_outputs = list(get_input_output_paths('input.py', 'outout', root=None))
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path('input.py')
    assert input_outputs[0].output == Path('outout/input.py')

    input_outputs = list(get_input_output_paths('tests', 'outout', root='tests'))

# Generated at 2022-06-21 17:15:40.912148
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    assert set(get_input_output_paths('foo.py', 'bar.py', None)) ==\
        {InputOutput(Path('foo.py'), Path('bar.py'))}
    assert set(get_input_output_paths('foo.py', 'bar.py', 'roo')) ==\
        {InputOutput(Path('foo.py'), Path('bar.py'))}
    assert set(get_input_output_paths('foo.py', 'bar', None)) ==\
        {InputOutput(Path('foo.py'), Path('bar').joinpath('foo.py'))}

# Generated at 2022-06-21 17:15:47.654168
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_='./test_input/in.py',
        output='./test_output',
        root='./test_input')) == [InputOutput(
            input_=Path('./test_input/in.py'),
            output=Path('./test_output/in.py'))]


# Generated at 2022-06-21 17:15:58.183413
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    data = [
        ('path/to/input.py', 'output.py', None, True),
        ('path/to/input.py', 'output/', None, True),
        ('path/to/input_dir', 'output.py', None, False),
        ('path/to/input_dir', 'output/', None, False),
        ('path/to/input_dir', 'output/', 'path/to/', True),
        ('path/to/input_dir', 'output.py', 'path/to/', False)
    ]
    for case in data:
        if case[3]:
            try:
                get_input_output_paths(case[0], case[1], case[2])
            except Exception as e:
                pytest.fail(e)

# Generated at 2022-06-21 17:16:03.417743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    directory_to_test = Path(__file__).parent.joinpath('../tests/test_paths')

# Generated at 2022-06-21 17:16:13.555368
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # when input is a file and output is a directory
    input_output_list = list(get_input_output_paths(
        'a.py', 'b', None))
    assert len(input_output_list) == 1
    assert input_output_list[0].input_path.as_posix() == Path('a.py').as_posix()
    assert input_output_list[0].output_path.as_posix() == Path(
        'b/a.py').as_posix()

    # when input is a file and output is a file
    input_output_list = list(get_input_output_paths(
        'a.py', 'b.py', None))
    assert len(input_output_list) == 1

# Generated at 2022-06-21 17:16:23.549878
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test InputOutput object as input/output
    assert(get_input_output_paths('input.py', 'output.py', None) ==
           [(InputOutput(Path('input.py'), Path('output.py')))])
    # Test relative path as input/output
    assert(get_input_output_paths('./input.py', '../output.py', None) ==
           [(InputOutput(Path('input.py'), Path('../output.py')))])
    # Test invalid InputOutput
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input.txt', 'output.py', None)

    # Test input path doesn't exist

# Generated at 2022-06-21 17:16:34.436869
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_pairs = list(get_input_output_paths(
        'example_input', 'example_output', None))
    assert len(input_output_pairs) == 4
    assert Path('example_input/a.py') in [io.input for io in input_output_pairs]
    assert Path('example_input/b.py') in [io.input for io in input_output_pairs]
    assert Path('example_input/c.py') in [io.input for io in input_output_pairs]
    assert Path('example_input/d.py') in [io.input for io in input_output_pairs]
    assert Path('example_output/a.py') in [io.output for io in input_output_pairs]

# Generated at 2022-06-21 17:16:41.418180
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    root = '/root/'
    input_ = '/root/foo.py'
    output = '/output/'

    # When
    input_outputs = get_input_output_paths(input_, output, root)

    # Then
    input_output = next(input_outputs)
    assert input_output.input == Path('/root/foo.py')
    assert input_output.output == Path('/output/foo.py')

# Generated at 2022-06-21 17:16:53.075108
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    # Test a file with a file
    input_ouput_paths = get_input_output_paths('/tmp/foo.py', '/tmp/bar.py', None)
    assert list(input_ouput_paths) == \
        [InputOutput(Path('/tmp/foo.py'), Path('/tmp/bar.py'))]

    # Test a file with a directory (root not set)
    input_ouput_paths = get_input_output_paths('/tmp/foo.py', '/tmp/bar/', None)
    assert list(input_ouput_paths) == \
        [InputOutput(Path('/tmp/foo.py'), Path('/tmp/bar/foo.py'))]

    # Test a file with a

# Generated at 2022-06-21 17:17:00.094513
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:17:08.130242
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test one file input file
    assert list(get_input_output_paths(input_="a.py", output="b.py", root=None)) == \
        [InputOutput(Path('a.py'), Path('b.py'))]

    # Test one file into directory
    assert list(get_input_output_paths(input_="a.py", output="b", root=None)) == \
        [InputOutput(Path('a.py'), Path('b/a.py'))]

    # Test one file into directory
    assert list(get_input_output_paths(input_="a.py", output="b", root="c")) == \
        [InputOutput(Path('a.py'), Path('b/a.py'))]

    # Test directory into directory

# Generated at 2022-06-21 17:17:16.971789
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unittest for functions get_input_output_paths."""
    input_ = '/'
    output = '/'
    root = '/'
    input_output_paths = get_input_output_paths(input_, output, root)
    input_output_paths_list = list(input_output_paths)
    assert len(input_output_paths_list) > 0

    output = '/tmp/'
    root = '/'
    input_output_paths = get_input_output_paths(input_, output, root)
    input_output_paths_list = list(input_output_paths)
    assert len(input_output_paths_list) > 0

    output = '/tmp'
    root = '/'
    input_output_paths = get_input_output

# Generated at 2022-06-21 17:18:42.251553
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:18:54.040142
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from cStringIO import StringIO

    saved_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    print(list(get_input_output_paths("foo", "bar", "root")))

    sys.stdout = saved_stdout
    assert mystdout.getvalue() == '[]\n'

    try:
        get_input_output_paths("foo.py", "bar", "root")
    except InvalidInputOutput:
        pass
    else:
        assert False

    try:
        get_input_output_paths("foo", "bar.py", "root")
    except InvalidInputOutput:
        pass
    else:
        assert False


# Generated at 2022-06-21 17:19:01.773490
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Given
    input_ = "input/file.py"
    output = "output"
    root = "root"

    # When
    dict = get_input_output_paths(input_, output, root)

    # Then
    assert dict == InputOutput(Path(input_), Path(output).joinpath(Path(input_).relative_to(root)))

# Generated at 2022-06-21 17:19:13.002092
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with a file as input and a file as output
    result = list(get_input_output_paths("input.py", "output.py", None))
    assert len(result) == 1
    assert result[0].input == Path("input.py")
    assert result[0].output == Path("output.py")
    # Test with a file as input and a directory as output
    result = list(get_input_output_paths("input.py", "output", "."))
    assert len(result) == 1
    assert result[0].input == Path("input.py")
    assert result[0].output == Path("output/input.py")
    # Test with a file as input and a directory as output
    result = list(get_input_output_paths("input.py", "./output", ".."))


# Generated at 2022-06-21 17:19:22.432732
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = get_input_output_paths('test_input.py', 'test_output.py',
                            'root')
    next(path)
    try:
        next(path)
    except StopIteration:
        pass
    else:
        assert False
    path = get_input_output_paths('test_input.py', 'test_output',
                            'root')
    input_output = next(path)
    assert input_output.input_path.name == 'test_input.py'
    assert input_output.output_path.name == 'test_input.py'
    try:
        next(path)
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-21 17:19:31.037312
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('this_file_does_not_exist.py', 'test_output.py', None)
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test_input.py', 'test_output.c', None)

    assert get_input_output_paths('test_input.py', 'test_output.py', None) == \
        [InputOutput(Path('test_input.py'), Path('test_output.py'))]

# Generated at 2022-06-21 17:19:42.328197
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from ..utils import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        for not_pyfile in ('file', 'folder'):
            with pytest.raises(InvalidInputOutput):
                list(get_input_output_paths(not_pyfile, 'output', ''))

        file = temp_dir.joinpath('file.py')
        file.touch()
        file_output_name = str(temp_dir.joinpath('file_output.py'))
        file_output_name_no_ext = str(temp_dir.joinpath('file_output'))

        file_output = list(get_input_output_paths(file_output_name, '', ''))
        assert file_output[0].input == file
        assert file_output[0].output == file_output_name

        file_

# Generated at 2022-06-21 17:19:51.512825
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_1 = 'test_files/test_file.py'
    output_1 = 'test_files/test_file_output.py'
    result_1 = [(Path(input_1), Path(output_1))]

    input_2 = 'test_files/test_file.py'
    output_2 = 'test_files/test_folder/'
    root_2 = 'test_files/test_folder'
    result_2 = [(Path(input_2), Path(output_2))]

    input_3 = 'test_files/test_folder/'
    output_3 = 'test_files/outputs'

# Generated at 2022-06-21 17:20:01.129679
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Checks if it returns a tuple of paths.

    The first element of the tuple is the path to a python file, the second
    element of the tuple is the path where the output of the compiler will be
    saved.
    """
    from pyfrost.as_pyfrost import __file__ as pyfrost_path

    result = list(
        get_input_output_paths(
            pyfrost_path,
            'path/to/output',
            'as_pyfrost'
        )
    )

    assert result == [
        InputOutput(
            Path(pyfrost_path),
            Path('path/to/output/as_pyfrost.py')
        )
    ]


# Generated at 2022-06-21 17:20:11.429634
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    tmpdir = tempfile.TemporaryDirectory()