

# Generated at 2022-06-21 17:13:04.568835
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # This will catch you if the starting directory ever changes.
    get_io_paths = get_input_output_paths('.', '.', None)
    from pprint import pprint
    pprint(list(get_io_paths))

# Generated at 2022-06-21 17:13:15.162450
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test case 1
    assert list(get_input_output_paths('example.py', 'example.py.new', None)) == [InputOutput(Path('example.py'), Path('example.py.new'))]

    # test case 2
    assert list(get_input_output_paths('/home/example.py', '/home/example.py.new', None)) == [InputOutput(Path('/home/example.py'), Path('/home/example.py.new'))]

    # test case 3
    assert list(get_input_output_paths('/home/example.py', '/home/example.py', None)) == [InputOutput(Path('/home/example.py'), Path('/home/example.py'))]

    # test case 4

# Generated at 2022-06-21 17:13:24.907383
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('./test/test.py', './test/test.py',
                                    root=None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('./test/test2.py', './test/test.py',
                                    root=None))

    testresult = list(get_input_output_paths('./test/test',
                                             './test/test2',
                                             root=None))
    assert testresult[0][1] == Path('./test/test2/test/test.py')

# Generated at 2022-06-21 17:13:38.189703
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Set up various scenarios
    scenario1 = get_input_output_paths('fileA.py', 'fileX.py', None)
    scenario2 = get_input_output_paths('folderA/', 'folderX/', None)
    scenario3 = get_input_output_paths('fileB.py', 'folderY/', None)
    scenario4 = get_input_output_paths('folderB/', 'folderY/', None)
    scenario5 = get_input_output_paths('folderC/', 'folderY/', 'folderC/')
    scenario6 = get_input_output_paths('folderC/', 'folderY/', 'folderC/folderD/')

# Generated at 2022-06-21 17:13:49.463349
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test with different inputs that the function returns correct values
    # test raises exception if input path is not a directory
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('a', 'b', 'c')

    # test python file with python file
    assert len(list(get_input_output_paths('test_input/a.py', 'test_output/a.py', 'test_input'))) == 1
    # test not python file with not python file
    assert len(list(get_input_output_paths('test_input', 'test_output', 'test_input'))) == 1
    # test python file with not python file

# Generated at 2022-06-21 17:14:00.152519
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Unit test for function get_input_output_paths
    """
    from os import chdir, getcwd, listdir
    from pathlib import Path
    from shutil import rmtree
    from time import time
    
    # directory to store the test files
    temp_dir = "temp" + str(time())
    
    # test files
    temp_input_file = "example.py"
    temp_output_file = "example_test.py"
    temp_input_dir = "example_dir"
    temp_output_dir = "example_test_dir"
    
    # create test files
    # create test input file
    Path(temp_dir + "/" + temp_input_file).touch()
    # create test input directory

# Generated at 2022-06-21 17:14:09.168717
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    assert list(get_input_output_paths("test1.py", "testout", "test")) == [
        InputOutput(Path("test1.py"), Path("testout"))]
    assert list(get_input_output_paths("test", "testout", "test")) == [
        InputOutput(Path("test/test1.py"), Path("testout/test1.py"))]
    assert list(get_input_output_paths("test", "testout", "test1")) == [
        InputOutput(Path("test/test1.py"), Path("testout/test1.py"))]

# Generated at 2022-06-21 17:14:18.533768
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test fuction get_input_output_paths
    """
    assert get_input_output_paths('./tests', './output', None) == [InputOutput('./tests/test.py', './output/test.py'), InputOutput('./tests/test1.py', './output/test1.py'), InputOutput('./tests/test2.py', './output/test2.py')]
    assert get_input_output_paths('./tests', './output/test1.py', None) == [InvalidInputOutput]
    assert get_input_output_paths('./tests/test.py', './output/test.py', None) == [InputOutput('./tests/test.py', './output/test.py')]

# Generated at 2022-06-21 17:14:24.076638
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pyppl import __file__ as pppl_file
    import os
    res = list(get_input_output_paths(pppl_file, 'tests/data'))
    assert len(res) == 1
    assert res[0].input == pppl_file
    assert res[0].output == os.path.join('tests', 'data', 'pyppl.py')
    res = list(get_input_output_paths('tests/data/data.py', 'tests/data'))
    assert len(res) == 1
    assert res[0].input == os.path.join('tests', 'data', 'data.py')
    assert res[0].output == os.path.join('tests', 'data', 'data.py')

# Generated at 2022-06-21 17:14:31.526221
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test when input is a directory
    foo = Path('./testdir')
    foo_output = Path('./foo_output')
    for input_output in get_input_output_paths(str(foo), str(foo_output), None):
        assert input_output.input_path == foo.joinpath('foo.py')
        assert input_output.output_path == foo_output.joinpath('foo.py')

    # Test when input is a file
    foo = Path('./testdir')
    for input_output in get_input_output_paths(str(foo.joinpath('foo.py')), str(foo), None):
        assert input_output.input_path == foo.joinpath('foo.py')
        assert input_output.output_path == foo.joinpath('foo.py')



# Generated at 2022-06-21 17:14:37.768027
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths("./myfile/myfile.py", "./myfile/myfile.txt", None)
    with pytest.raises(InputDoesntExists):
        assert get_input_output_paths("./myfile/myfile.py", "./myfile/myfile.py", None)
    assert get_input_output_paths("./myfile/myfile.py", "./myfile/myfile.py", None)

# Generated at 2022-06-21 17:14:49.290339
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from shutil import rmtree
    from tempfile import mkdtemp
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .types import InputOutput


# Generated at 2022-06-21 17:15:00.424032
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    cwd = os.getcwd()
    assert list(get_input_output_paths('', '', '')) == [(Path.cwd(), Path.cwd()),]
    assert list(get_input_output_paths('', '.', '')) == [(Path.cwd(), Path.cwd()),]
    assert list(get_input_output_paths(cwd, '', '')) == \
        [(Path(cwd, name), Path(cwd, name)) for name in os.listdir(cwd) if name.endswith('.py')]

# Generated at 2022-06-21 17:15:09.410174
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test case 1: input is a file and output is a file
    input_ = 'input/in.py'
    output = 'output/out.py'
    paths = list(get_input_output_paths(input_, output, None))
    assert len(paths) == 1
    assert paths[0].input == Path(input_)
    assert paths[0].output == Path(output)

    # Test case 2: input is a file and output is a directory
    input_ = 'input/in.py'
    output = 'output'
    paths = list(get_input_output_paths(input_, output, None))
    assert len(paths) == 1
    assert paths[0].input == Path(input_)

# Generated at 2022-06-21 17:15:20.173671
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input output
    assert get_input_output_paths('/input/test.py', '/output/test.py', '/') == [
        InputOutput(Path('/input/test.py'), Path('/output/test.py'))
    ]
    # Test input folder
    assert get_input_output_paths('/input/', '/output/', '/') == [
        InputOutput(Path('/input/test1.py'), Path('/output/test1.py')),
        InputOutput(Path('/input/test2.py'), Path('/output/test2.py')),
        InputOutput(Path('/input/test3.py'), Path('/output/test3.py')),
    ]
    # Test input folder with root

# Generated at 2022-06-21 17:15:27.053018
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = Path('/Users/user/Desktop/python_files/')
    input_path = str(path.joinpath('input').absolute())
    output_path = str(path.joinpath('output').absolute())

    # check that the error is thrown when input_path is invalid
    invalid_input_path = str(path.joinpath('not_existing').absolute())
    try:
        list(get_input_output_paths(invalid_input_path, output_path, None))
        assert False
    except InputDoesntExists:
        pass

    # check that the error is thrown when input is a file but output is a dir
    try:
        list(get_input_output_paths('test.py', output_path, None))
        assert False
    except InvalidInputOutput:
        pass

    # check that the

# Generated at 2022-06-21 17:15:39.856963
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths()."""
    dir_test = Path('dir_test')
    dir_test_output = Path('dir_test_output')

    if not dir_test.exists():
        dir_test.mkdir()

    dir_test_2 = Path('dir_test/dir_test_2')
    dir_test_3 = Path('dir_test/dir_test_3')

    if not dir_test_2.exists():
        dir_test_2.mkdir()

    if not dir_test_3.exists():
        dir_test_3.mkdir()

    with open('dir_test/file1.py', 'w'):
        pass

    with open('dir_test/file2.py', 'w'):
        pass


# Generated at 2022-06-21 17:15:49.947731
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path("/home/user/dev/project")
    assert list(get_input_output_paths("/home/user/dev/project/src", "/home/user/dev/project/build/src", "/home/user/dev/project")) == [InputOutput(Path("/home/user/dev/project/src/a.py"), Path("/home/user/dev/project/build/src/a.py")), InputOutput(Path("/home/user/dev/project/src/b.py"), Path("/home/user/dev/project/build/src/b.py"))]

# Generated at 2022-06-21 17:16:01.580590
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Check that input is file and output is file
    for pair in get_input_output_paths('/abc/def/file.py', '/ghi/def/file.py', None):
        assert pair.input == Path('/abc/def/file.py')
        assert pair.output == Path('/ghi/def/file.py')

    # Check that input is file and output is dir
    for pair in get_input_output_paths('/abc/def/file.py', '/ghi/def', None):
        assert pair.input == Path('/abc/def/file.py')
        assert pair.output == Path('/ghi/def/file.py')

    # Check that input is dir and output is dir

# Generated at 2022-06-21 17:16:12.986667
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Sanity test
    assert get_input_output_paths("./tests/data/HelloWorld.py", "./tests", "./tests/data").__next__() == InputOutput(Path("./tests/data/HelloWorld.py"),Path("./tests/HelloWorld.py"))

    # Invalid Input Output test
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("HelloWorld.java", "./", "")

    # Missing Input Test
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("HelloWorld.py", "./", "")
    
    # Test for a directory when input is a directory

# Generated at 2022-06-21 17:16:23.902489
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

    test_cases = (
        # input, output, root
        ('a.py', 'b.py', None),
        ('a.py', 'b.py', 'r'),
        ('a.py', 'b/', None),
        ('a.py', 'b/', 'r'),
        ('a', 'b', None),
        ('a', 'b', 'r'),
        ('a/', 'b', None),
        ('a/', 'b', 'r'),
        ('a', 'b/', None),
        ('a', 'b/', 'r'),
        ('a/', 'b/', None),
        ('a/', 'b/', 'r')
    )

# Generated at 2022-06-21 17:16:34.492372
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = os.path.join(os.path.dirname(__file__), "test_data")

    # valid globs
    paths = [
        ("glob_test/test_*.py", "glob_test/"),
        ("glob_test/test_*.py", "glob_test/test_out/"),
        ("glob_test/test_*.py", "glob_test/test_out/fixtures/"),
        ("glob_test/test_*.py", "glob_test/test_out/fixtures/assets/"),
        ("glob_test/test_*.py", "glob_test/test_out/fixtures/assets/glob_test/"),
    ]


# Generated at 2022-06-21 17:16:41.774580
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    samples = (
        ('foo.py', 'out', ('foo.py', 'out/foo.py')),
        ('bar', 'out', ('bar/foo.py', 'out/foo.py')),
        ('bar', 'out/baz', ('bar/foo.py', 'out/baz/foo.py')),
    )

    for input_, output, (child_input, child_output) in samples:
        input_ = Path(input_)
        output = Path(output)
        root = Path(__file__).parent.absolute()

        input_, output = next(get_input_output_paths(input_, output, root))
        assert input_ == Path(child_input)
        assert output == Path(child_output)

# Generated at 2022-06-21 17:16:53.102422
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get input/output path pairs."""
    # Single file to file
    paths = list(get_input_output_paths('foo.py', 'bar.py', None))
    assert len(paths) == 1
    assert paths[0].input == Path('foo.py')
    assert paths[0].output == Path('bar.py')

    # Single file to directory
    paths = list(get_input_output_paths('foo.py', 'bar', None))
    assert len(paths) == 1
    assert paths[0].input == Path('foo.py')
    assert paths[0].output == Path('bar/foo.py')

    # Single file to directory with root directory
    paths = list(get_input_output_paths('foo.py', 'bar', 'bar'))

# Generated at 2022-06-21 17:17:03.858183
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.pyc', None)

    with raises(InvalidInputOutput):
        get_input_output_paths('input.py', 'output.py', None)

    with raises(InputDoesntExists):
        get_input_output_paths('input.py', 'output.py', None)

    assert list(get_input_output_paths('input', 'output.py', 'root')) == [
        InputOutput(Path('input'), Path('output.py'))]
    assert list(get_input_output_paths('input', 'output', 'root')) == [
        InputOutput(Path('input'), Path('output').joinpath('input'))]

# Generated at 2022-06-21 17:17:13.373223
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test if this is a python file
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test/test_ast2code.py', 'test/output1', 'test'))
    assert list(get_input_output_paths('test/test_ast2code.py', 'test/output', 'test')) == [InputOutput(Path('test/test_ast2code.py'), Path('test/output/test_ast2code.py'))]

    # Test if this is a directory

# Generated at 2022-06-21 17:17:23.624027
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test cases for function get_input_output_paths."""

# Generated at 2022-06-21 17:17:35.531913
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
            '/foo/bar/baz.py',
            '/output/foo/bar/baz.py',
            None)) == [
                InputOutput(
                    Path('/foo/bar/baz.py'),
                    Path('/output/foo/bar/baz.py'))
            ]
    assert list(get_input_output_paths(
            '/foo/bar/baz/',
            '/output/foo/bar/baz.py',
            None)) == [
                InputOutput(
                    Path('/foo/bar/baz/baz.py'),
                    Path('/output/foo/bar/baz.py'))
            ]

# Generated at 2022-06-21 17:17:42.074717
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert next(get_input_output_paths("input.py", "output.py", None)) == InputOutput(Path("input.py"), Path("output.py"))
    assert next(get_input_output_paths("input.py", "output/output.py", None)) == InputOutput(Path("input.py"), Path("output/output.py"))
    assert next(get_input_output_paths("dir_input", "dir_output", None)) == InputOutput(Path("dir_input/input.py"), Path("dir_output/input.py"))
    assert next(get_input_output_paths("dir_input", "dir_output", "dir_input")) == InputOutput(Path("dir_input/input.py"), Path("dir_output/input.py"))

# Generated at 2022-06-21 17:17:54.320838
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths
    """

    # Input is folder
    input_ = 'examples/conditional'
    output = 'output'
    assert list(get_input_output_paths(
        input_, output, root=None)) == [
            InputOutput(Path('examples/conditional/__init__.py'),
                        Path('output/__init__.py')),
            InputOutput(Path('examples/conditional/conditional.py'),
                        Path('output/conditional.py')),
            InputOutput(Path('examples/conditional/conditional2.py'),
                        Path('output/conditional2.py')),
        ]

    # Invalid input/output combination
    input_ = 'examples/conditional'
    output = 'output.py'

# Generated at 2022-06-21 17:18:04.826160
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input & output is actual file
    assert(tuple(get_input_output_paths('a.py', 'b.py', None))
           == (InputOutput(Path('a.py'), Path('b.py')),))
    # Test input & output is actual directory
    assert(tuple(get_input_output_paths('a', 'b', None))
           == (InputOutput(Path('a/a.py'), Path('b/a.py')),))
    # Test input is actual directory and output is actual file
    assert(tuple(get_input_output_paths('a', 'b.py', None))
           == (InputOutput(Path('a/a.py'), Path('b.py')),))
    # Test input is actual directory, output is actual file and
    # root is actual directory
   

# Generated at 2022-06-21 17:18:15.592532
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        assert get_input_output_paths('input', 'output.py', None)

    # Input is a file
    file_inputs = get_input_output_paths('input.py', 'output.py', None)
    assert list(file_inputs) == [InputOutput(Path('input.py'), Path('output.py'))]
    file_inputs = get_input_output_paths('input.py', 'output', None)
    assert list(file_inputs) == [InputOutput(Path('input.py'), Path('output').joinpath(Path('input.py')))]

    # Input is a directory
    file_inputs = get_input_output_paths('input', 'output.py', None)
    assert list(file_inputs)

# Generated at 2022-06-21 17:18:25.829036
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_, output = r'E:\pdr\pdr\test', r'E:\pdr\pdr\output'
    # test1: input: directory or file; output: directory
    assert sum(1 for _ in get_input_output_paths(
        input_, output, None)) == 3
    # test2: input: directory or file; output: file
    assert sum(1 for _ in get_input_output_paths(
        input_, output+'\test1.py', None)) == 0
    # test3: input: file; output: directory or file
    assert sum(1 for _ in get_input_output_paths(
        input_+'\test1.py', output, None)) == 1

# Generated at 2022-06-21 17:18:33.985094
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert tuple(get_input_output_paths('/a', '/b', '/a')) == (InputOutput(
        Path('/a/a.py'), Path('/b/a.py')))
    assert tuple(get_input_output_paths('/a/a.py', '/b', '/a')) == (InputOutput(
        Path('/a/a.py'), Path('/b/a.py')), )
    assert tuple(get_input_output_paths('/a/a.py', '/b/b.py', '/a')) == (InputOutput(
        Path('/a/a.py'), Path('/b/b.py')), )

# Generated at 2022-06-21 17:18:45.186963
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input and output with the same extension
    IO_PATHS = get_input_output_paths(
        "input", "output", None)
    assert IO_PATHS[0].input.name == "input"
    assert IO_PATHS[0].input.is_file() == True
    assert IO_PATHS[0].output.name == "output"

    # Test input with .py extension, and output with .txt
    IO_PATHS = get_input_output_paths(
        "input.py", "output.txt", None)
    assert IO_PATHS[0].input.name == "input.py"
    assert IO_PATHS[0].input.is_file() == True
    assert IO_PATHS[0].output.name == "input.txt"

   

# Generated at 2022-06-21 17:18:55.137081
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_='.',
        output='hello.py',
        root=None
    )) == [InputOutput(Path('.'), Path('hello.py'))]

    assert list(get_input_output_paths(
        input_='.',
        output='.',
        root=None
    )) == list(get_input_output_paths(
        input_='.',
        output='.',
        root='.'
    ))

    assert list(get_input_output_paths(
        input_='hello.py',
        output='.',
        root=None
    )) == list(get_input_output_paths(
        input_='hello.py',
        output='.',
        root='.'
    ))

# Generated at 2022-06-21 17:19:02.559377
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    import pytest
    assert get_input_output_paths('one.py', 'two.py', 'root') == [InputOutput(Path('one.py'),Path('two.py'))]
    assert get_input_output_paths('one.py', 'two', 'root') == [InputOutput(Path('one.py'),Path('two/one.py'))]
    assert get_input_output_paths('one', 'two.py', 'root') == [InputOutput(Path('one/two.py'),Path('two.py'))]

# Generated at 2022-06-21 17:19:13.324074
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from io import StringIO
    import sys
    import os
    import tempfile
    from contextlib import contextmanager
    from unittest.mock import patch
    import pytest

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-21 17:19:23.275214
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 1: input/output is file
    input_output_paths = list(get_input_output_paths('/a/b.py', '/c/d.py', None))
    assert len(input_output_paths) == 1
    (input_path, output_path) = input_output_paths[0]
    assert input_path == Path('/a/b.py')
    assert output_path == Path('/c/d.py')

    # Test 2: input is file, output is directory
    input_output_paths = list(get_input_output_paths('/a/b.py', '/c/d', None))
    assert len(input_output_paths) == 1
    (input_path, output_path) = input_output_paths[0]
    assert input

# Generated at 2022-06-21 17:19:31.195943
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a/b.c', 'd/e.c', None)) == []
    assert list(get_input_output_paths('a/b.py', 'd/e.c', None)) == [
        InputOutput(Path('a/b.py'), Path('d/e.c/b.py'))
    ]
    assert list(get_input_output_paths('a/b', 'd/e.c', None)) == [
        InputOutput(Path('a/b/b.py'), Path('d/e.c/b.py'))
    ]

# Generated at 2022-06-21 17:19:49.362702
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = 'tests'
    input_ = 'tests/tests_fixtures/test_dir_1/test_dir_3'
    output = 'tests/tests_fixtures/test_dir_1/test_dir_4'

    result = [
        InputOutput('tests/tests_fixtures/test_dir_1/test_dir_3/test_file_1.py',
          'tests/tests_fixtures/test_dir_1/test_dir_4/test_file_1.py'),
        InputOutput('tests/tests_fixtures/test_dir_1/test_dir_3/test_dir_2/test_file_2.py',
          'tests/tests_fixtures/test_dir_1/test_dir_4/test_dir_2/test_file_2.py'),
    ]

# Generated at 2022-06-21 17:20:00.580773
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = 'tests'
    input_path = os.path.join(root, 'folder1')
    output_path = 'folder2'
    paths = list(get_input_output_paths(input_path, output_path, root))
    assert paths == [
        InputOutput(Path('tests/folder1/folder3/file3.py'),
                    Path('folder2/folder3/file3.py')),
        InputOutput(Path('tests/folder1/folder2/file2.py'),
                    Path('folder2/folder2/file2.py')),
        InputOutput(Path('tests/folder1/file1.py'),
                    Path('folder2/file1.py'))
    ]

    input_path = os.path.join(root, 'folder1/file1.py')

# Generated at 2022-06-21 17:20:10.263593
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a', 'b', None) == [InputOutput(Path('a'), Path('b'))]
    assert get_input_output_paths('a.py', 'b', None) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert get_input_output_paths('a', 'b.py', None) == [InputOutput(Path('a'), Path('b.py'))]
    assert get_input_output_paths('a.py', 'b.py', None) == [InputOutput(Path('a.py'), Path('b.py'))]

# Generated at 2022-06-21 17:20:20.981520
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    input_path = os.getcwd()
    output_path = os.getcwd()
    input_list = [os.path.join(input_path,i) for i in os.listdir(input_path)]
    output_list = [os.path.join(output_path,i) for i in os.listdir(output_path)]
    for i in range(len(input_list)):
        if os.path.isdir(input_list[i]):
            input_list[i] = os.path.join(input_list[i],'*.py')
    
    for i in range(len(output_list)):
        if not os.path.isdir(output_list[i]):
            output_list.pop(i)
    
    input_tuple = ()

# Generated at 2022-06-21 17:20:29.543848
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Given
    input_ = 'tests/fixtures/duplicates/duplicate_mod.py'
    output = 'tests/fixtures/duplicates/output'

    # When
    result = list(get_input_output_paths(input_, output, None))

    # Then
    expected_output = ['tests/fixtures/duplicates/output/duplicate_mod.py']
    assert result[0].input.as_posix() == input_
    assert result[0].output.as_posix() in expected_output



# Generated at 2022-06-21 17:20:40.603376
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', '.', None)) == [InputOutput(Path('foo.py'), Path('foo.py'))]
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [InputOutput(Path('foo.py'), Path('bar/foo.py'))]
    assert list(get_input_output_paths('foo', 'bar', None)) == [InputOutput(Path('foo/a.py'), Path('bar/a.py')), InputOutput(Path('foo/b.py'), Path('bar/b.py'))]

# Generated at 2022-06-21 17:20:53.755104
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(
            get_input_output_paths(
                input_='input2.py', output='output', root=None
            )
        )

    with pytest.raises(InvalidInputOutput):
        list(
            get_input_output_paths(
                input_='input', output='output/output.py', root=None
            )
        )

    with pytest.raises(InputDoesntExists):
        list(
            get_input_output_paths(
                input_='input', output='output', root=None
            )
        )

    ret = list(
        get_input_output_paths(
            input_='util/input.py', output='util/output', root=None
        )
    )
    assert ret

# Generated at 2022-06-21 17:21:04.144174
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:21:15.351128
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    input_dir = Path(tempfile.mkdtemp())
    output_dir = Path(tempfile.mkdtemp())
    input_dir_1 = input_dir / 'x1'
    input_dir_2 = input_dir / 'x2'
    input_dir_1.mkdir()
    input_dir_2.mkdir()
    (input_dir_1 / 'a.py').touch()
    (input_dir_2 / 'b.py').touch()
    (input_dir_2 / 'c.py').touch()

    result = list(
        get_input_output_paths(input_dir, output_dir, None))
    assert len(result) == 3
    assert all(input.parent == input_dir for input, _ in result)

# Generated at 2022-06-21 17:21:26.110267
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()"""
    # A simple input/output path test
    assert get_input_output_paths('input', 'output', None) == [
        InputOutput(Path('input'), Path('output'))
    ]

    # A simple input/folder output test
    assert get_input_output_paths('input', 'output', None) == [
        InputOutput(Path('input'), Path('output'))
    ]

    # A folder input/output test with nested folders

# Generated at 2022-06-21 17:22:44.839779
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Need to be some file/directory
    input_path = 'tests/fixtures'
    output_path = 'tests/tests'
    root_path = 'tests'

    output = list(get_input_output_paths(input_path, output_path, root_path))
    # Get all fixtures files
    fixtures_dir = Path(input_path)
    input_paths = list(fixtures_dir.glob('**/*'))
    input_paths = [path for path in input_paths if path.is_file()]
    # Get paths to output
    output_path = Path(output_path)
    output_paths = []
    for path in input_paths:
        output_paths.append(output_path.joinpath(path.relative_to(fixtures_dir)))
    #

# Generated at 2022-06-21 17:22:54.417573
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/src/a/b/c.py', '/output/', '/src/')) == [InputOutput(Path('/src/a/b/c.py'), Path('/output/b/c.py'))]
    assert list(get_input_output_paths('/src/a/b/c.py', '/output/', None)) == [InputOutput(Path('/src/a/b/c.py'), Path('/output/c.py'))]
    assert list(get_input_output_paths('/src/a/b/c.py', '/src/a/b/', '/src/')) == [InputOutput(Path('/src/a/b/c.py'), Path('/src/a/b/c.py'))]
    assert list