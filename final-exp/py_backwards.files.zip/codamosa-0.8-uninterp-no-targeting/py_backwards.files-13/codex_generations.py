

# Generated at 2022-06-21 17:13:02.865429
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pairs = {}
    for input_, output in get_input_output_paths('../tests', '../tests/output', None):
        assert isinstance(input_, Path)
        assert isinstance(output, Path)
        assert input_.name.endswith('.py')
        pairs[input_] = output
    assert len(pairs) == 4
    assert pairs[Path('../tests/test_basic.py')] == Path('../tests/output/test_basic.py')
    assert pairs[Path('../tests/test_compare_ast.py')] == Path('../tests/output/test_compare_ast.py')
    assert pairs[Path('../tests/test_docstrings.py')] == Path('../tests/output/test_docstrings.py')

# Generated at 2022-06-21 17:13:14.125438
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output_paths = get_input_output_paths("/Users/test/testme.py", "/Users/test/out", "/Users/test/out")
    assert list(input_output_paths) == [InputOutput(Path("/Users/test/testme.py"), Path("/Users/test/out/testme.py"))]
    input_output_paths = get_input_output_paths("/Users/test/test.py", "/Users/test/out", "/Users/test/")
    assert list(input_output_paths) == [InputOutput(Path("/Users/test/test.py"), Path("/Users/test/out/test.py"))]

# Generated at 2022-06-21 17:13:24.837727
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths('input', 'output', 'root'))
    assert paths == [InputOutput(Path('input'), Path('output/input'))]
    paths = list(get_input_output_paths('input.py', 'output.py', 'root'))
    assert paths == [InputOutput(Path('input.py'), Path('output.py'))]
    paths = list(get_input_output_paths('input.py', 'output', 'root'))
    assert paths == [InputOutput(Path('input.py'), Path('output/input.py'))]
    paths = list(get_input_output_paths('input.py', 'output', None))
    assert paths == [InputOutput(Path('input.py'), Path('output/input.py'))]

# Generated at 2022-06-21 17:13:37.325426
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths(
        input_='tests/res/input/tests/', output='tests/res/output/'))
    expected = [
        InputOutput(Path('tests/res/input/tests/dummy.py'),
                    Path('tests/res/output/dummy.py')),
        InputOutput(Path('tests/res/input/tests/dummy2.py'),
                    Path('tests/res/output/dummy2.py')),
        InputOutput(Path('tests/res/input/tests/tests/dummy3.py'),
                    Path('tests/res/output/tests/dummy3.py')),
    ]
    assert paths == expected

# Generated at 2022-06-21 17:13:49.223755
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("input", "output", None)) ==\
        [InputOutput(Path("input").relative_to("input"),
                     Path("output").joinpath("input"))]

    assert list(get_input_output_paths("input/file.py", "output/file.py", None)) ==\
        [InputOutput(Path("input/file.py"), Path("output/file.py"))]

    assert list(get_input_output_paths("input/file.py", "output", None)) ==\
        [InputOutput(Path("input/file.py"), Path("output/file.py"))]

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("input", "output.py", None))


# Generated at 2022-06-21 17:14:00.152789
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def check(input_, output, expected_input, expected_output):
        result = list(get_input_output_paths(input_, output, None))
        assert result[0].input == Path(expected_input)
        assert result[0].output == Path(expected_output)

    check('input.py', 'output.py', 'input.py', 'output.py')
    check('input/inner/input.py', 'output/inner/input.py',
          'input/inner/input.py', 'output/inner/input.py')
    check('input.py', 'output', 'input.py', 'output/input.py')
    check('input/inner/input.py', 'output',
          'input/inner/input.py', 'output/inner/input.py')

# Generated at 2022-06-21 17:14:07.753543
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [InputOutput(Path('test1.py'), Path('test2.py'))] == list(get_input_output_paths('test1.py', 'test2.py', None))
    assert [InputOutput(Path('test1.py'), Path('test2.py')/'test1.py')] == list(get_input_output_paths('test1.py', 'test2.py', None))
    assert [InputOutput(Path('test1.py'), Path('test2.py')/'test1.py'), InputOutput(Path('test1.py')/'test3.py', Path('test2.py')/'test3.py')] == list(get_input_output_paths('test1.py', 'test2.py', 'test1.py'))

# Generated at 2022-06-21 17:14:18.138525
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    from itertools import chain

    def check(input_: str, output: str, root: Optional[str],
              expected_values: Iterable[InputOutput]):
        paths = get_input_output_paths(input_, output, root)
        assert tuple(paths) == tuple(expected_values)

    check(
        '/foo/bar/baz.py',
        '/qux',
        None,
        (
            (Path('/foo/bar/baz.py'), Path('/qux/baz.py'))
        )
    )


# Generated at 2022-06-21 17:14:28.756677
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(
        get_input_output_paths(
            input_='/path/to/a.py',
            output='/path/to/output.py',
            root='/path/to/'
        )
    ) == [InputOutput(Path('/path/to/a.py'), Path('/path/to/output.py'))]
    assert list(
        get_input_output_paths(
            input_='/path/to/a.py',
            output='/path/to',
            root='/path/to/'
        )
    ) == [InputOutput(Path('/path/to/a.py'), Path('/path/to/a.py'))]

# Generated at 2022-06-21 17:14:34.364980
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Tests a single file with the same extension
    path_pairs = list(get_input_output_paths('tests/test_directory/test_file.txt',
                                            'tests/test_directory/result', None))
    path_pairs[0].input.should.be.a(Path)
    str(path_pairs[0].input).should.equal('tests/test_directory/test_file.txt')
    str(path_pairs[0].output).should.equal('tests/test_directory/result/test_file.txt')
    # Tests multiple files with the same extension
    path_pairs = list(get_input_output_paths('tests/test_directory/test_directory',
                                             'tests/test_directory/result', None))

# Generated at 2022-06-21 17:14:48.628914
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output = '/tmp/output'
    # Given the input is a directory
    input_ = '/tmp/input'
    for path in get_input_output_paths(input_, output, None):
        print(path.input, path.output)

    input_ = '/tmp/input/file.py'
    for path in get_input_output_paths(input_, output, None):
        print(path.input, path.output)

    # Given root is not None
    root = '/tmp/root'
    for path in get_input_output_paths(input_, output, root):
        print(path.input, path.output)
    print("test_get_input_output_paths passed.")

test_get_input_output_paths()

# Generated at 2022-06-21 17:15:00.190440
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:15:08.024335
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    a = get_input_output_paths("test", "test", None)
    assert([(i.input, i.output) for i in a] == [(Path("test/file.py"), Path("test/file.py")), (Path("test/dir/dir2/file2.py"), Path("test/dir/dir2/file2.py"))])
if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-21 17:15:19.670465
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('', '', '')) == []
    assert list(get_input_output_paths('a.py', 'b.py', '')) == [
        InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', '')) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b', '')) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]

# Generated at 2022-06-21 17:15:30.474911
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [(input_.as_posix(), output.as_posix())
            for input_, output in get_input_output_paths('a', 'b', 'x')] ==\
           [('a', 'b')]

    assert [(input_.as_posix(), output.as_posix())
            for input_, output in get_input_output_paths('a.py', 'b', 'x')] ==\
           [('a.py', 'b')]

    assert [(input_.as_posix(), output.as_posix())
            for input_, output in get_input_output_paths('a.py', 'b.py', 'x')] ==\
           [('a.py', 'b.py')]


# Generated at 2022-06-21 17:15:40.905771
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = list(get_input_output_paths('input.py', 'output.py', None))
    assert len(paths) == 1
    path, = paths
    assert path.input_path == Path('input.py')
    assert path.output_path == Path('output.py')

    paths = list(get_input_output_paths('a', 'b', None))
    assert len(paths) == 1
    path, = paths
    assert path.input_path == Path('a/input.py')
    assert path.output_path == Path('b/input.py')

    paths = list(get_input_output_paths('a', 'b', 'a'))
    assert len(paths) == 1
    path, = paths

# Generated at 2022-06-21 17:15:47.033075
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "/path/to/root/src"
    output = '/path/to/root/dest'
    root = '/path/to/root'
    paths = [p.input.as_posix() for p in get_input_output_paths(input_, output, root)]
    assert paths == ['src/a.py', 'src/b.py', 'src/c.py']

input_ = "/path/to/root/src"
output = '/path/to/root/dest'
root = '/path/to/root'

for p in get_input_output_paths(input_, output, root):
    pass
    #print(p.input, p.output)

# Generated at 2022-06-21 17:15:52.337826
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        input_ = tmpdir.joinpath('foobar.py')
        output = tmpdir.joinpath('output')
        input_.write_text('print("hello")')

        input_output = list(get_input_output_paths(str(input_),str(output),str(tmpdir)))
        assert len(input_output) == 1
        assert input_output[0].input.name == 'foobar.py'
        assert input_output[0].output.name == 'foobar.py'
        assert input_output[0].output.parents[0] == output

# Generated at 2022-06-21 17:16:02.037284
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from nose.tools import assert_true, assert_equal

    expected = [InputOutput(Path('test/test.py'), Path('test/test.py')),
                InputOutput(Path('test/test.py'), Path('test/test.py')),
                InputOutput(Path('test/test.py'), Path('test/test_copy.py')),
                InputOutput(Path('test/test.py'), Path('test_copy/test.py')),
                InputOutput(Path('test/test.py'), Path('test_copy/test.py'))]

    output = get_input_output_paths('test/test.py', 'test/test.py', None)
    assert_true(isinstance(output, Iterable))

# Generated at 2022-06-21 17:16:13.148701
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/src/file1.py', '/dest', None)) == [InputOutput(Path('/src/file1.py'), Path('/dest/file1.py'))]
    assert list(get_input_output_paths('/src/file1.py', '/dest/file2.py', None)) == [InputOutput(Path('/src/file1.py'), Path('/dest/file2.py'))]
    assert list(get_input_output_paths('/src/file1.py', '/', None)) == [InputOutput(Path('/src/file1.py'), Path('/file1.py'))]

# Generated at 2022-06-21 17:16:24.148470
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from shutil import rmtree
    from tempfile import mkdtemp
    from .utils import write_file

    class InvalidInputOutputAssert(Exception):
        pass

    class InputDoesntExistsAssert(Exception):
        pass

    def assertRaises(exception, function):
        try:
            function()
        except exception:
            pass
        else:
            raise exception

    root = Path(mkdtemp())

    subdir1 = root.joinpath('dir1')
    subdir1.mkdir()
    file1 = subdir1.joinpath('file1.py')
    file1.touch()

    subdir2 = root.joinpath('dir2')
    subdir2.mkdir()
    file2 = subdir2.joinpath('file2.py')
    file2.touch()

    output

# Generated at 2022-06-21 17:16:34.558648
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # Single file (input), single file (output)
    for path in get_input_output_paths('setup.py', 'out/setup.py', None):
        assert path.input == Path('setup.py')
        assert path.output == Path('out/setup.py')

    # Single file <output> with directory structure
    for path in get_input_output_paths('setup.py', 'out', None):
        assert path.input == Path('setup.py')
        assert path.output == Path('out/setup.py')

    # Single file <output> with directory structure and <root>
    for path in get_input_output_paths('setup.py', 'out', '.'):
        assert path.input == Path('setup.py')

# Generated at 2022-06-21 17:16:43.378544
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # pyrefactor convert input.py
    # convert input.py
    def _test_eq(input_outputs):
        assert input_outputs == get_input_output_paths(
            'input.py', 'output.py', None)

    _test_eq(
        [InputOutput(Path('input.py'), Path('output.py'))])

    # pyrefactor convert input.py output/
    # convert input.py output/
    _test_eq(
        [InputOutput(Path('input.py'), Path('output/input.py'))])

    # pyrefactor convert input_dir/ output/
    # convert input_dir/ output/

# Generated at 2022-06-21 17:16:53.443553
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the get_input_output_paths method"""
    # Test for an input folder and an output folder
    res_1 = [path for path in get_input_output_paths('Input_folder/',
                                                     'Output_folder/',
                                                     None)]
    # Test for an input file and an output folder
    res_2 = [path for path in get_input_output_paths('Input_folder/file.py',
                                                     'Output_folder/',
                                                     None)]
    # Test for an input file and an output file
    res_3 = [path for path in get_input_output_paths('Input_folder/file.py',
                                                     'Output_folder/file.py',
                                                     None)]

    # Test for an input folder and an output folder with a root
   

# Generated at 2022-06-21 17:17:03.910305
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Valid
    input_: str = '/foo/bar/baz.py'
    output: str = '/foo/bar/qux'
    root: Optional[str] = None
    result: Iterable[InputOutput] = get_input_output_paths(input_, output, root)
    expected: Iterable[InputOutput] = [InputOutput(Path('/foo/bar/baz.py'), Path('/foo/bar/qux/baz.py'))]
    assert list(result) == expected

    # Invalid
    input_: str = '/foo/bar/baz.py'
    output: str = '/foo/bar/qux.py'
    root: Optional[str] = None
    result: Iterable[InputOutput] = get_input_output_paths(input_, output, root)


# Generated at 2022-06-21 17:17:13.393270
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""
    input_output = [InputOutput(Path('input\\index.py'), Path('output\\index.py'))]
    assert list(get_input_output_paths('input\\index.py', 'output', 'input')) == input_output
    assert list(get_input_output_paths('input\\index.py', 'output\\', 'input')) == input_output
    assert list(get_input_output_paths('input\\index.py', 'output\\', 'input\\')) == input_output
    assert list(get_input_output_paths('input\\index.py', 'output\\index.py', 'input\\')) == input_output

# Generated at 2022-06-21 17:17:22.607490
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = Path('tests').joinpath('test_files')
    output = Path('tests').joinpath('test_files_out')
    for input_output in get_input_output_paths(str(input_), str(output), 'tests/test_files'):
        assert input_output.input_path.is_file()
        assert input_output.output_path.is_file() == False

    assert get_input_output_paths('tests/test_files/test1/test_file_1.py', 'tests/test_files_out', 'tests/test_files').__next__().input_path == input_.joinpath('test1/test_file_1.py')

# Generated at 2022-06-21 17:17:27.640931
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        list(get_input_output_paths('foo.py', 'bar.py', None))
    except InvalidInputOutput:
        pass
    else:
        raise AssertionError()

    try:
        list(get_input_output_paths('foo.py', 'test', None))
    except InvalidInputOutput:
        pass
    else:
        raise AssertionError()

    try:
        list(get_input_output_paths('foo.py', 'test', None))
    except InvalidInputOutput:
        pass
    else:
        raise AssertionError()

    try:
        list(get_input_output_paths('not_exists', 'bar.py', None))
    except InputDoesntExists:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-21 17:17:36.321956
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    get_input_output_paths('test/test_get_input_output_paths.py', 'test/test_get_input_output_paths.py', None)
    get_input_output_paths('test/test_get_input_output_paths.py', 'test/test_get_input_output_paths_output.py', None)
    get_input_output_paths('test/test_get_input_output_paths.py', 'test/test_get_input_output_paths_output', None)

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test/test_get_input_output_paths.py', 'test/test_get_input_output_paths.c', None)


# Generated at 2022-06-21 17:17:42.353647
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Can get input/output paths pairs."""
    import pytest
    from .types import InputOutput

    # output needs to be a .py file when input is not a directory
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('tests/test_data/test.c2py',
                               'tests/test_data/test.c')

    # input needs to exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('tests/test_data/notexists.py',
                               'tests/test_data/notexists.py')

    # basic test
    paths = get_input_output_paths(
        'tests/test_data',
        'tests/output/test_data',
    )

# Generated at 2022-06-21 17:17:56.750324
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """test get_input_output_paths"""
    from .exceptions import InputDoesntExists, InvalidInputOutput
    from .types import InputOutput

    def get_input_output_paths_test(input_: str, output: str,
                                    root: Optional[str]) -> Iterable[InputOutput]:
        """Get input/output paths pairs."""
        if output.endswith('.py') and not input_.endswith('.py'):
            raise InvalidInputOutput

        if not Path(input_).exists():
            raise InputDoesntExists

        if input_.endswith('.py'):
            if output.endswith('.py'):
                yield InputOutput(Path(input_), Path(output))
            else:
                input_path = Path(input_)

# Generated at 2022-06-21 17:18:05.707718
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (
        list(get_input_output_paths('a.py', 'b', None))) == [
        InputOutput(Path('a.py'), Path('b/a.py'))]
    assert (
        list(get_input_output_paths(
            'a', 'b', None))) == [
        InputOutput(Path('a/a.py'), Path('b/a.py'))]
    assert (
        list(get_input_output_paths(
            'a.py', 'b.py', None))) == [
        InputOutput(Path('a.py'), Path('b.py'))]

# Generated at 2022-06-21 17:18:14.532299
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [InputOutput(Path('a.py'), Path('b.py'))] == list(get_input_output_paths('a.py', 'b.py', None))
    assert [] == list(get_input_output_paths('a', 'b.py', None))
    assert [InputOutput(Path('a/b.py'), Path('c/d.py'))] == list(get_input_output_paths('a', 'c', 'a'))

# Generated at 2022-06-21 17:18:25.612005
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    fixtures = ['tests/fixtures']

# Generated at 2022-06-21 17:18:31.815206
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    test function get_input_output_paths
    """
    input_ = './black_input/black.py'
    output = './black_output/'
    root = './black_input/'
    input_outputs = get_input_output_paths(input_, output, root)
    for input_output in input_outputs:
        assert str(input_output.input()) == input_
        assert str(input_output.output()) == './black_output/black.py'

# Generated at 2022-06-21 17:18:44.530616
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from unittest.mock import MagicMock, patch
    from pyfakefs.fake_filesystem import FakeFilesystem
    from pyfakefs.fake_filesystem_unittest import Patcher
    from pyfakefs.fake_pathlib import FakePath

    with Patcher() as patcher:
        fake_fs = patcher.fs
        fake_path = patcher.path

        input_ = '/test/input'
        output = '/test/output'
        root = '/test'


        # Test with a file.py as input and file.py as output, thus no iteration
        fake_input = MagicMock(spec_set=FakePath)
        fake_input.iterdir.return_value = []
        fake_input.is_file.return_value = True
        fake_input.exists.return_value = True

# Generated at 2022-06-21 17:18:54.984301
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # get_input_output_paths(input_: str, output: str, root: Optional[str])
    # inputs:
    #   output_file       ->     output_file
    #   output_folder     ->     output_folder/input_file
    #   output_folder     ->     output_folder/path_to_file
    # outputs: 
    #   InvalidInputOutput
    #   InputDoesntExists
    input_folder = Path('test_input')
    output_folder = Path('test_output')
    output_file = Path('test_output/test1.py')
    input_file = Path('test_input/test1.py')
    root = Path('test_input/test')

# Generated at 2022-06-21 17:19:02.491936
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pprint import pprint
    from pathlib import Path
    from .exceptions import InvalidInputOutput, InputDoesntExists

    data_dir = Path(__file__).parent.joinpath('data')

    # check for files
    pprint(list(get_input_output_paths(
        str(data_dir.joinpath('in.py')),
        str(data_dir.joinpath('out.py')),
        str(data_dir))))
    pprint(list(get_input_output_paths(
        str(data_dir.joinpath('in.py')),
        str(data_dir.joinpath('out')),
        str(data_dir))))

# Generated at 2022-06-21 17:19:10.490176
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from documentation_generator.generator.path_utils import get_input_output_paths

    result = [
        InputOutput(input, output)
        for input, output
        in get_input_output_paths("/a/b/c/d", "/e/f/g", root="/a")
    ]

    assert result == [InputOutput("/a/b/c/d", "/e/f/g/b/c/d")]

# Generated at 2022-06-21 17:19:22.369603
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:19:35.911953
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('input1.py', 'output', None)) == \
    [InputOutput(Path('input1.py'), Path('output'))]
    assert list(get_input_output_paths('input2.py', 'output/', None)) == \
    [InputOutput(Path('input2.py'), Path('output/'))]
    assert list(get_input_output_paths('input3.py', 'output.py', None)) == \
    [InputOutput(Path('input3.py'), Path('output.py'))]
    assert list(get_input_output_paths('input4.py', 'output.txt', None)) == \
    [InputOutput(Path('input4.py'), Path('output.txt'))]

# Generated at 2022-06-21 17:19:46.206564
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test get_input_output_paths
    """
    assert list(get_input_output_paths("tests/resources/test_input.py", "test_output.py", "/")) == \
           [InputOutput(Path("tests/resources/test_input.py"), Path("test_output.py"))]

    assert list(get_input_output_paths("tests/resources/test_input.py", "tests/resources/test_output.py", "/")) == \
           [InputOutput(Path("tests/resources/test_input.py"), Path("tests/resources/test_output.py"))]


# Generated at 2022-06-21 17:19:56.301467
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # if input is a file and output is a file
    input_ = 'input/hi.py'
    output = 'output/hi.py'
    result = get_input_output_paths(input_, output, 'input')
    expect = InputOutput(Path('input/hi.py'), Path('output/hi.py'))
    assert list(result) == [expect]

    # if input is a file and output is a folder
    input_ = 'input/hi.py'
    output = 'output'
    result = get_input_output_paths(input_, output, 'input')
    expect = InputOutput(Path('input/hi.py'), Path('output/hi.py'))
    assert list(result) == [expect]

    # if input is a folder and output is a folder

# Generated at 2022-06-21 17:20:04.528263
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Test 1: Call with file and directory.
    assert len(list(get_input_output_paths('test.py', 'output', None))) == 1
    assert (list(get_input_output_paths('test.py', 'output', None))[0].input_.name) == 'test.py'
    assert (list(get_input_output_paths('test.py', 'output', None))[0].output_.name) == 'test.py'

    # Test 2: Call with file and file.
    assert len(list(get_input_output_paths('test.py', 'output.py', None))) == 1
    assert (list(get_input_output_paths('test.py', 'output.py', None))[0].input_.name) == 'test.py'

# Generated at 2022-06-21 17:20:14.956277
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:20:25.514709
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Get input/output paths pairs."""
    # True case
    case1_input = 'test/test_get_input_output_paths/input'
    case1_output = 'test/test_get_input_output_paths/output'
    case1_output_paths = \
    [
        InputOutput(Path('test/test_get_input_output_paths/input'),
                    Path('test/test_get_input_output_paths/output')),
        InputOutput(Path('test/test_get_input_output_paths/input/test.py'),
                    Path('test/test_get_input_output_paths/output/test.py'))
    ]

# Generated at 2022-06-21 17:20:34.053259
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pprint import pprint
    list(get_input_output_paths('test/test_folder',
                                'output_test_folder',
                                'test'))
    pprint(list(get_input_output_paths('test/test_folder',
                                       'output_test_folder',
                                       'test')))
    assert list(get_input_output_paths('test/test_folder',
                                       'output_test_folder',
                                       'test')) \
        == [InputOutput(Path('test/test_folder/test1.py'),
                        Path('output_test_folder/test1.py')),
            InputOutput(Path('test/test_folder/test2.py'),
                        Path('output_test_folder/test2.py'))]

# Generated at 2022-06-21 17:20:44.222158
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .tests import RESOURCES

# Generated at 2022-06-21 17:20:53.804305
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path(__file__).parent.parent
    input_path = root / 'pylint/functional/utils.py'
    output_path = Path('output') / 'pylint/functional/utils.py'
    result = list(get_input_output_paths(str(input_path), str(output_path), str(root)))
    assert len(result) == 1
    assert result[0] == InputOutput(input_path, output_path)

# Generated at 2022-06-21 17:20:58.546197
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    io_dir = os.path.join(cur_dir, 'input_output')
    input_dir = os.path.join(io_dir, 'a')
    output_dir = os.path.join(io_dir, 'b')

# Generated at 2022-06-21 17:21:07.950991
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Delete to test if the file exists
    Path('test_input').unlink()
    Path('test_output').unlink()
    test_input = Path('test_input')
    test_output = Path('test_output')
    test_input_file = test_input.joinpath('test_file.py')
    test_output_file = test_output.joinpath('test_file.py')
    test_input.mkdir(exist_ok=True)
    test_output.mkdir(exist_ok=True)
    test_input_file.touch()

    # Test if the input/output paths pairs are correct

# Generated at 2022-06-21 17:21:16.522915
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Invalid input/output paths
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('abc.txt', 'abc.txt', None)

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('abc.py', 'abc.txt', None)

    # Invalid input path
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('abc.py', 'xyz', None)

    # Single file
    assert list(get_input_output_paths('abc.py', 'xyz', None)) == [
        InputOutput(Path('abc.py'), Path('xyz'))]


# Generated at 2022-06-21 17:21:26.539469
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path

    # Test one-to-one
    tmpdir = mkdtemp()
    input_file = path.join(tmpdir, 'file1.py')
    output_file = path.join(tmpdir, 'file1.rst')
    with open(input_file, 'w') as f:
        f.write('pass')
    io = list(get_input_output_paths(input_file, output_file,
                                     root=None))
    assert len(io) == 1
    assert io[0].input == Path(input_file)
    assert io[0].output == Path(output_file)
    rmtree(tmpdir)

    # Test wrong input
    tmpdir = mkdtemp()
    input

# Generated at 2022-06-21 17:21:30.411111
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""
    get_input_output_paths('.', '.', '.')

# Generated at 2022-06-21 17:21:38.616108
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test for single file
    input_ = Path('foo.py')
    input_.write_text('pass')
    assert list(get_input_output_paths(str(input_), 'bar.py', None)) == [InputOutput(input_, Path('bar.py'))]
    assert list(get_input_output_paths(str(input_), 'bar', None)) == [InputOutput(input_, Path('bar').joinpath(input_.name))]
    assert list(get_input_output_paths(str(input_), 'bar', 'foo_py')) == [InputOutput(input_, Path('bar').joinpath(input_.relative_to(Path('foo_py'))))]

    # test for directory
    input_ = Path('foo')
    input_.mkdir()

# Generated at 2022-06-21 17:21:48.952142
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function."""
    assert list(get_input_output_paths('.', '.', root='.')) == [
        InputOutput(Path('.'), Path('.'))]
    assert list(get_input_output_paths('test', '.', root='.')) == [
        InputOutput(Path('test'), Path('test'))]
    assert list(get_input_output_paths('test.py', '.', root='.')) == [
        InputOutput(Path('test.py'), Path('test.py'))]
    assert list(get_input_output_paths('test.py', 'test_output.py', root='.')) == [
        InputOutput(Path('test.py'), Path('test_output.py'))]

# Generated at 2022-06-21 17:21:51.383753
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test no errors when everything is ok
    get_input_output_paths(input_='foo.py', output='bar.py', root='')

# Generated at 2022-06-21 17:22:02.850421
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for a normal case
    input_output_1 = get_input_output_paths('examples/test_file.test',
                                            'output', 'examples')
    true_output_1 = [InputOutput(Path('examples/test_file.test'),
                                 Path('output/test_file.test'))]

    # Test for a case when input is a directory
    input_output_2 = get_input_output_paths('examples/', 'output', 'examples')
    true_output_2 = [InputOutput(Path('examples/test_file.test'),
                                 Path('output/test_file.test'))]

    # Test for a case when input is file and ouptut is directory

# Generated at 2022-06-21 17:22:10.167515
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    if __name__ == '__main__':
        path1 = get_input_output_paths('a.py', 'b.py', root = '.')
        path2 = get_input_output_paths('./a.py', './b/c.py', root = '.')
        path3 = get_input_output_paths('./a', './b/c.py', root = '.')
        path4 = get_input_output_paths('./a', './b/c.py', root = None)

# Generated at 2022-06-21 17:22:13.889455
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    _ = get_input_output_paths
    _(input_="not_exist.path", output="a/b", root="not_used")


# Generated at 2022-06-21 17:22:46.151671
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert len(list(get_input_output_paths('tests/test_folder', 'tests/test_folder_output', 'tests/test_folder'))) == 0
    assert len(list(get_input_output_paths('tests/test_folder', 'tests/test_folder_output', None))) == 0
    assert len(list(get_input_output_paths('tests/test_folder', 'tests/test_folder_output'))) == 0
    assert len(list(get_input_output_paths('tests/test_folder', 'tests/test_folder_output/', 'tests/test_folder'))) == 0
    assert len(list(get_input_output_paths('tests/test_folder', 'tests/test_folder_output/', None))) == 0