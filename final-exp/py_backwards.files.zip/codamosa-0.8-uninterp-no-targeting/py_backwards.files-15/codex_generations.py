

# Generated at 2022-06-21 17:13:11.636109
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    TEST_FOLDERS = [
        [r'c:\TestInput1\test_1.py', r'c:\TestOutput\test_1.py',  r'c:\TestInput1'],
        [r'c:\TestInput1\test_1.py', r'c:\TestOutput', r'c:\TestInput1'],
        [r'c:\TestInput1', r'c:\TestOutput', r'c:\TestInput1'],
        [r'c:\TestInput1', r'c:\TestOutput', None],
    ]

    for testInput, testOutput, testRoot in TEST_FOLDERS:
        for path in get_input_output_paths(testInput, testOutput, testRoot):
            assert path.input_ == Path(testInput)
            assert path.output == Path(testOutput)

# Generated at 2022-06-21 17:13:20.369719
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(
        'test_input/test_py.py', 'test_output', 'test_input') == [
            InputOutput(Path('test_input/test_py.py'),
                        Path('test_output/test_py.py'))]
    assert get_input_output_paths(
        'test_input/test_py.py', 'test_output/test_out_py.py', 'test_input') == [
            InputOutput(Path('test_input/test_py.py'),
                        Path('test_output/test_out_py.py'))]

# Generated at 2022-06-21 17:13:26.624646
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', 'baz.py', None)) == \
        [InputOutput(Path('foo.py'), Path('baz.py'))]
    assert list(get_input_output_paths('foo.txt', 'baz.py', 'bar')) == \
        [InputOutput(Path('bar').joinpath('foo.txt'), Path('baz.py').joinpath('foo.txt'))]
    assert list(get_input_output_paths('foo', 'baz.py', None)) == \
        [InputOutput(Path('foo').joinpath('file.py'), Path('baz.py').joinpath('file.py'))]

# Generated at 2022-06-21 17:13:31.671970
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = Path(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_files'))
    output_ = Path(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_files_output'))
    expected_result = []
    expected_result.append(InputOutput(Path(os.path.join(input_, 'folder1', 'file1.py')), Path(os.path.join(output_, 'folder1', 'file1.py'))))
    expected_result.append(InputOutput(Path(os.path.join(input_, 'folder1', 'file2.py')), Path(os.path.join(output_, 'folder1', 'file2.py'))))
    expected_result

# Generated at 2022-06-21 17:13:39.490407
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .convert import normalize_path
    import pytest
    from .exceptions import InputDoesntExists, InvalidInputOutput
    from .types import InputOutput

    def assert_paths(input_, output, root=None, verbose=False):
        paths = list(get_input_output_paths(input_, output, root))
        if verbose:
            print("\ninput: {!r}, output: {!r}, root: {!r}\n".format(
                input_, output, root))
            for path in paths:
                print("\t{!r} -> {!r}".format(path.input, path.output))
        assert all(path.input.exists() for path in paths)


# Generated at 2022-06-21 17:13:50.526498
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pairs = get_input_output_paths('a/b/c.py', 'd/e/f.py', None)
    assert list(pairs) == [InputOutput(Path('a/b/c.py'), Path('d/e/f.py'),)]
    pairs = get_input_output_paths('a/b/c', 'd/e/f', 'a')
    assert list(pairs) == [InputOutput(Path('a/b/c'), Path('d/e/f/b/c'),)]
    pairs = get_input_output_paths('a/b/c', 'd/e/f.py', 'a')
    assert list(pairs) == [InputOutput(Path('a/b/c'), Path('d/e/f.py/b/c'),)]

# Generated at 2022-06-21 17:13:58.381627
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test input/output files
    input_output = get_input_output_paths('test/test_fixtures/input1.py', 'test/test_fixtures/output1.py', None)
    input_output = list(input_output)
    assert len(input_output) == 1
    
    assert input_output[0].input.name == 'input1.py'
    assert input_output[0].output.name == 'output1.py'
    # Test input/output folders
    input_output = get_input_output_paths('test/test_fixtures/input_dir', 'test/test_fixtures/output_dir', None)
    input_output = list(input_output)
    assert len(input_output) == 2
    

# Generated at 2022-06-21 17:14:07.267038
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='foo.py',
            output='bar.py.html',
        ))
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='foo.py',
            output='bar.py',
        ))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(
            input_='foo.py',
            output='bar.html',
        ))
    # ---

# Generated at 2022-06-21 17:14:16.280969
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
  # Call the function to be tested with mock paths.
  io_pairs = get_input_output_paths(
      input_='/usr/src/app/foo/bar.py',
      output='/usr/src/app/lorem/ipsum',
      root=None
  )
  # Check for results.
  assert next(io_pairs).input_path.match('/usr/src/app/foo/bar.py')
  assert next(io_pairs).output_path.match('/usr/src/app/lorem/ipsum/bar.py')

# Generated at 2022-06-21 17:14:28.021124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test for get_input_output_paths
    """
    input_ = './src/exceptions.py'
    output = './target'
    root = './src'
    assert next(get_input_output_paths(input_, output, root)) == InputOutput(Path(input_),
                                                                             Path(output).joinpath(Path(input_).name))
    with pytest.raises(InvalidInputOutput):
        next(get_input_output_paths(input_, 'exceptions.py', root))
    with pytest.raises(InputDoesntExists):
        next(get_input_output_paths('./src/not_exist.py', output, root))

    input_ = './src'
    output = './target'

# Generated at 2022-06-21 17:14:40.410738
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    def test_valid(input_: str, output: str,
                   root: Optional[str] = None) -> Iterable[InputOutput]:
        """Get valid input/output paths pairs."""
        return list(get_input_output_paths(input_, output, root))

    assert test_valid('foo', 'bar') == [InputOutput(Path('foo.py'), Path('bar.py'))]
    assert test_valid('foo/bar.py', 'baz') == [InputOutput(Path('foo/bar.py'), Path('baz/bar.py'))]
    assert test_valid('foo', 'bar', 'foo') == [InputOutput(Path('foo.py'), Path('bar.py'))]


# Generated at 2022-06-21 17:14:50.274975
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest

    # invalid input/output pair
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('abc', 'abc.py', root=None)

    # invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('invalid', 'output', root=None)

    # single .py file
    assert list(get_input_output_paths('foo.py', 'output', root=None)) == [
        InputOutput(Path('foo.py'), Path('output/foo.py'))]
    assert list(get_input_output_paths('foo.py', 'output/a.py', root=None)) == [
        InputOutput(Path('foo.py'), Path('output/a.py'))]

    # directory

# Generated at 2022-06-21 17:14:57.221459
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('/tmp/a.py', '/tmp/b.py', None)) == [InputOutput(Path('/tmp/a.py'), Path('/tmp/b.py'))]
    assert list(get_input_output_paths('/tmp/a.py', '/tmp', None)) == [InputOutput(Path('/tmp/a.py'), Path('/tmp/a.py'))]
    assert list(get_input_output_paths('/tmp', '/tmp', None)) == []
    assert list(get_input_output_paths('/tmp', '/tmp', '/tmp')) == []

# Generated at 2022-06-21 17:15:09.272710
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('asd', 'out', None)) == [
        InputOutput(Path('asd'), Path('out/asd'))]
    assert list(get_input_output_paths('asd/', 'out', None)) == [
        InputOutput(Path('asd/.py'), Path('out/asd/.py')),
        InputOutput(Path('asd/1.py'), Path('out/asd/1.py'))]
    assert list(get_input_output_paths('asd/a.py', 'out', None)) == [
        InputOutput(Path('asd/a.py'), Path('out/a.py'))]

# Generated at 2022-06-21 17:15:20.173674
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('../App_Server/app.py', '../App_Server/app.py', '../App_Server'))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('../App_Server/app.py', '../App_Server/app', '../App_Server'))
    f = list(get_input_output_paths('../App_Server/app.py', '../App_Server/app/app.py', '../App_Server'))
    assert f[0].input_path == '../App_Server/app.py' and f[0].output_path == '../App_Server/app/app.py'

# Generated at 2022-06-21 17:15:27.052802
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    assert list(get_input_output_paths('/Users/simon/a.py', '/Users/simon/b.py', None)) == [InputOutput(Path('/Users/simon/a.py'), Path('/Users/simon/b.py'))]

    assert list(get_input_output_paths('/Users/simon/a.py', '/Users/simon/b', None)) == [InputOutput(Path('/Users/simon/a.py'), Path('/Users/simon/b/a.py'))]


# Generated at 2022-06-21 17:15:39.856583
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path

    file = Path('test','test.py')
    dir = Path('test','test')
    file_to_file = get_input_output_paths(file, file, dir)
    assert next(file_to_file) == InputOutput(Path('test','test.py'), Path('test','test.py'))
    file_to_dir = get_input_output_paths(file, dir, dir)
    assert next(file_to_dir) == InputOutput(Path('test','test.py'), Path('test','test','test.py'))
    dir_to_dir = get_input_output_paths(dir, dir, dir)
    assert next(dir_to_dir) == InputOutput(Path('test','test'), Path('test','test'))

# Generated at 2022-06-21 17:15:46.611951
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the function get_input_output_paths."""
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('app', 'app.py', 'app'))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('not_exists', 'app.py', None))
    assert list(get_input_output_paths('app', 'app.py', None)) == [
        InputOutput(Path('app.py'), Path('app.py'))
    ]
    assert list(get_input_output_paths('app.py', 'app', None)) == [
        InputOutput(Path('app.py'), Path('app').joinpath('app.py'))
    ]

# Generated at 2022-06-21 17:15:53.223087
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test invalid input output paths
    test_cases = [('test.py', 'test.md'), ('test.md', 'test.py'),
                  ('test.md', 'test'), ('test.md', '/test.py')]

    for input_, output in test_cases:
        try:
            for input_output in get_input_output_paths(input_, output,
                                                       None):
                pass
        except InvalidInputOutput:
            pass
        else:
            raise Exception('Unit test failed at {}, {}'.format(input_,
                                                                output))

    # Test cases

# Generated at 2022-06-21 17:15:58.424597
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    pairs = list(get_input_output_paths(input_='./src/hello.py',
                                        output='./output/hello.py',
                                        root=None))
    assert len(pairs) == 1
    assert pairs[0].input == Path('./src/hello.py')
    assert pairs[0].output == Path('./output/hello.py')
    pairs = list(get_input_output_paths(input_='./src/hello.py',
                                        output='./output',
                                        root=None))
    assert len(pairs) == 1
    assert pairs[0].input == Path('./src/hello.py')
    assert pairs[0].output == Path('./output/hello.py')

# Generated at 2022-06-21 17:16:14.701677
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo.py', 'bar/baz.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar').joinpath('baz.py'))]
    assert list(get_input_output_paths('foo.py', 'bar', None)) == [
        InputOutput(Path('foo.py'), Path('bar').joinpath('foo.py'))]

# Generated at 2022-06-21 17:16:23.792559
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    io_paths = get_input_output_paths(
        Path('test/foo.py'), Path('test/output'), None)
    io_path = next(io_paths)
    assert io_path.input.as_posix() == 'test/foo.py'
    assert io_path.output.as_posix() == 'test/output/foo.py'

    io_paths = get_input_output_paths(
        Path('test'), Path('test/output'), Path('test'))
    io_path = next(io_paths)
    assert io_path.input.as_posix() == 'test/foo.py'
    assert io_path.output.as_posix() == 'test/output/foo.py'

    io_paths = get_input_output_paths

# Generated at 2022-06-21 17:16:29.551821
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = get_input_output_paths('x/y/z.py', 'output')
    assert list(result) == [InputOutput(Path('x/y/z.py'), Path('output/z.py'))]

# Generated at 2022-06-21 17:16:36.079882
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Get input output from a file (input) and a directory (output)
    assert list(
        get_input_output_paths(input_='/home/user/x.py', output='/home/user/y',
                               root=None)) == [
             InputOutput(Path('/home/user/x.py'),
                         Path('/home/user/y/x.py'))]

    # Get input output from a directory (input) and a directory (output)

# Generated at 2022-06-21 17:16:43.752247
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""

    from pathlib import Path

    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .types import InputOutput


# Generated at 2022-06-21 17:16:53.564046
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import os
    import tempfile

    tempdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-21 17:17:03.938614
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    ''' Path(Path(input_path).relative_to(root)) '''
    def input_output_paths(root: Optional[str],
                           input_: str,
                           output: str) -> Iterable[InputOutput]:
        return get_input_output_paths(input_, output, root)

    # test when input is file
    assert list(input_output_paths('root', 'input', 'output')) ==\
        [InputOutput(Path('input'), Path('output'))]

    assert list(input_output_paths('root', 'input/a.py', 'output')) ==\
        [InputOutput(Path('input/a.py'), Path('output/a.py'))]

    assert list(input_output_paths(None, 'input/a.py', 'output'))

# Generated at 2022-06-21 17:17:13.413463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    cases = [
        ("a.py", "out", None),
        ("a.py", "out.py", None),
        ("a.py", "out/", None),
        ("a.py", "out.py/", None),
        ("a.py", "out/a.b", None),
    ]

    for inp, outp, root in cases:
        paths = [x for x in get_input_output_paths(inp, outp, root)]
        assert len(paths) == 1
        assert paths[0].input_path == Path(inp)
        assert paths[0].output_path == Path(Path(outp).joinpath(Path(inp).name))


# Generated at 2022-06-21 17:17:23.649270
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_1 = get_input_output_paths('input', 'output', 'root')
    assert next(test_1) == InputOutput(Path('input'), Path('output'))

    test_2 = get_input_output_paths('input.py', 'output', 'root')
    assert next(test_2) == InputOutput(Path('input.py'), Path('output/input.py'))

    test_3 = get_input_output_paths('input', 'output.py', 'root')
    assert next(test_3) == InputOutput(Path('input'), Path('output.py'))

    test_4 = get_input_output_paths('input.py', 'output.py', 'root')
    assert next(test_4) == InputOutput(Path('input.py'), Path('output.py'))

# Generated at 2022-06-21 17:17:35.551764
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # one output, one input
    # file input, file output
    input_ = './foo/bar.py'
    output = '/tmp/bar.py'
    input_output_pairs = get_input_output_paths(input_, output, None)
    expected_input_output_pairs = [(
        Path('foo/bar.py'),
        Path('/tmp/bar.py')
    )]
    assert list(input_output_pairs) == expected_input_output_pairs
    # directory input, file output
    input_ = './foo'
    output = '/tmp/bar.py'
    input_output_pairs = get_input_output_paths(input_, output, None)

# Generated at 2022-06-21 17:17:56.736937
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('b.py', 'a.py', None) == [InputOutput(Path('b.py'), Path('a.py'))]
    assert get_input_output_paths('t', 't', None) == [InputOutput(Path('t/main.py'), Path('t/main.py'))]
    assert get_input_output_paths('t', 'a.py', None) == [InputOutput(Path('t/main.py'), Path('a.py'))]
    assert get_input_output_paths('t/main.py', 'a.py', None) == [InputOutput(Path('t/main.py'), Path('a.py'))]

# Generated at 2022-06-21 17:18:05.705222
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths"""
    from .exceptions import InputDoesntExists
    from .types import InputOutput
    from pathlib import Path

    # Test for single file path
    actual_paths = get_input_output_paths("test_io/test_input.py",
                                          "test_io/test_output.py",
                                          None)
    expected_paths = [InputOutput(Path("test_io/test_input.py"),
                                  Path("test_io/test_output.py"))]

    assert list(actual_paths) == expected_paths

    # Test with invalid input file

# Generated at 2022-06-21 17:18:15.909171
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert tuple(get_input_output_paths('input.py', 'output.py', None)) == (
        InputOutput(Path('input.py'), Path('output.py')),
    )
    assert tuple(get_input_output_paths('input.py', 'output', None)) == (
        InputOutput(Path('input.py'), Path('output').joinpath('input.py')),
    )
    assert tuple(get_input_output_paths('input', 'output', None)) == (
        InputOutput(Path('input/__init__.py'), Path('output').joinpath('__init__.py')),
    )
    with pytest.raises(InvalidInputOutput):
        tuple(get_input_output_paths('input.py', 'output.txt', None))

# Generated at 2022-06-21 17:18:25.856157
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'tests/test_input/test.py'
    root = 'tests/test_input'
    output = 'test_output'
    expected_output = Path('test_output/test.py')
    assert list(get_input_output_paths(input_, output, root)) == [InputOutput(Path(input_), expected_output)]

    input_ = 'tests/test_input/test.py'
    root = None
    output = 'test_output'
    expected_output = Path('test_output/test.py')
    assert list(get_input_output_paths(input_, output, root)) == [InputOutput(Path(input_), expected_output)]

    input_ = 'tests/test_input'
    root = None
    output = 'test_output'

# Generated at 2022-06-21 17:18:29.897557
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths."""
    assert [InputOutput(Path('a.py'), Path('b.py')),
            InputOutput(Path('c.py'), Path('b/c.py')),
            InputOutput(Path('d/e.py'), Path('b/d/e.py'))] == list(
        get_input_output_paths('a.py', 'b.py', None))
    assert [InputOutput(Path('a.py'), Path('b.py'))] == list(
        get_input_output_paths('a.py', 'b.py', './'))

# Generated at 2022-06-21 17:18:40.500838
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with single py file in input and output
    input_outputs = get_input_output_paths("input.py", "output.py", None)
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path("input.py")
    assert input_outputs[0].output == Path("output.py")

    # Test with single py file in input, not in output
    input_outputs = get_input_output_paths("input.py", "output", None)
    assert len(input_outputs) == 1
    assert input_outputs[0].input == Path("input.py")
    assert input_outputs[0].output == Path("output").joinpath("input.py")

    # Test with single py file in input, not in output

# Generated at 2022-06-21 17:18:51.206825
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    # Directory to directory
    result = get_input_output_paths('test/input',
                                    'test/output', None)
    assert isinstance(result, Iterable)
    assert isinstance(next(result), InputOutput)
    assert next(result).input_path.name == 'test_input_output.py'
    assert next(result).output_path.name == 'test_input_output.py'

    # File to directory
    result = get_input_output_paths('test/input/test_input_output.py',
                                    'test/output', None)
    assert next(result).input_path.name == 'test_input_output.py'

# Generated at 2022-06-21 17:18:56.753500
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InvalidInputOutput):
        next(get_input_output_paths('file.txt', 'file.py', None))

    with raises(InputDoesntExists):
        next(get_input_output_paths('doesnt_exist', 'whatever.py', None))

    assert next(get_input_output_paths('file.py', 'file.py', None)) == InputOutput(
        input=Path('file.py'), output=Path('file.py'))

    assert next(get_input_output_paths('file.py', '.', None)) == InputOutput(
        input=Path('file.py'), output=Path('file.py'))


# Generated at 2022-06-21 17:19:03.032958
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input = '/test/test.py'
    output = '/test/'
    root = None
    test = InputOutput('/test/test.py', '/test/test.pyi')
    assert next(get_input_output_paths(input, output, root)) == test

    input = '/test/test.pyi'
    output = '/test/'
    root = None
    test = InputOutput('/test/test.pyi', '/test/test.pyi')
    assert next(get_input_output_paths(input, output, root)) == test

    input = '/test/'
    output = '/test/'
    root = None
    test = InputOutput('/test/test.py', '/test/test.py')
    assert next(get_input_output_paths(input, output, root))

# Generated at 2022-06-21 17:19:13.506816
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths"""

    input_ = "good_input_no_output"
    output = ""
    root = "root"
    res = get_input_output_paths(input_, output, root)

    assert next(res) == InputOutput(Path("good_input_no_output/file1.py"),
                                    Path("file1.py"))
    assert next(res) == InputOutput(Path("good_input_no_output/file2.py"),
                                    Path("file2.py"))
    assert next(res) == InputOutput(Path("good_input_no_output/file3.py"),
                                    Path("file3.py"))
    with pytest.raises(StopIteration):
        next(res)


# Generated at 2022-06-21 17:19:41.333784
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'tests/data'
    output = 'tests/output'
    path = get_input_output_paths(input_, output, None)
    assert next(path) == InputOutput(Path(input_ + '/args.py'), Path(output + '/args.py'))

# Generated at 2022-06-21 17:19:50.129348
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("input/a.py", "output", None)) == \
           [InputOutput(Path("input/a.py"), Path("output/a.py"))]
    assert list(get_input_output_paths("input/a.py", "output/", None)) == \
           [InputOutput(Path("input/a.py"), Path("output/a.py"))]
    assert list(get_input_output_paths("input/a.py", "output/b.py", None)) == \
           [InputOutput(Path("input/a.py"), Path("output/b.py"))]

# Generated at 2022-06-21 17:19:59.581188
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Set up unit test
    input_ = 'C:\\Users\\user\\Desktop\\gacha\\bot\\gacha_bot.py'
    output = 'C:\\Projects'
    root = 'C:\\Users\\user\\Desktop\\gacha\\'
    io = InputOutput(Path(input_), Path(output))
    io_expected = io

    # Run function
    io_actual = get_input_output_paths(input_, output, root)

    # Test
    assert io_actual == io_expected
    assert isinstance(io_actual, Iterable)
    assert isinstance(io_expected, InputOutput)

# Generated at 2022-06-21 17:20:05.889636
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = list(get_input_output_paths('foo', 'bar', None))
    assert len(input_output) == 1
    assert input_output[0].input == Path('foo')
    assert input_output[0].output == Path('bar')

# Generated at 2022-06-21 17:20:13.975964
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path(os.path.dirname(__file__))
    test_path = Path(os.path.join(root, "tests_get_input_output_paths"))
    """Test if input output pair of paths is correct"""
    with pytest.raises(InvalidInputOutput):
        input_ = 'a.txt'
        output = 'b.py'
        list(get_input_output_paths(input_, output, root))
    with pytest.raises(InputDoesntExists):
        input_ = 'f'
        output = 'f'
        list(get_input_output_paths(input_, output, root))

    input_ = os.path.join(test_path, 'a.py')
    output = os.path.join(test_path, 'b.py')


# Generated at 2022-06-21 17:20:21.098191
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # given
    input = 'tests/test_data/sample_source'
    output = 'tests/test_data/sample_output'
    # when
    result = get_input_output_paths(input, output, None)
    # unit test
    assert len(list(result)) == 3

# Generated at 2022-06-21 17:20:31.004741
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Different extension for input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('input.txt', 'output.py', None))
    # Input doesn't exists
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('wrong_input', 'output.py', None))
    # Input and output are single files
    assert list(get_input_output_paths(
        'input.py', 'output.py', None)) == [
            InputOutput(Path('input.py'), Path('output.py'))
        ]
    # Input and output are files with different names

# Generated at 2022-06-21 17:20:41.310295
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for get_input_output_paths."""
    assert list(get_input_output_paths('a.py', 'b.py', None)) == \
        [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == \
        [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a', 'b.py', None)) == \
        [InputOutput(Path('a'), Path('b.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == \
        [InputOutput(Path('a'), Path('b/a'))]

# Generated at 2022-06-21 17:20:54.398510
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Check for invalid input/output path
    with nose.tools.assert_raises(InvalidInputOutput):
        get_input_output_paths('./input/indir/test', './output/test.py', './input')

    # Check for invalid input path
    with nose.tools.assert_raises(InputDoesntExists):
        get_input_output_paths('./input/invalid_dir/test.py', './output/test.py', './input')

    # Check for invalid directory input
    with nose.tools.assert_raises(InputDoesntExists):
        get_input_output_paths('./input/invalid_dir/', './output/test.py', './input')

    # Check standard output

# Generated at 2022-06-21 17:21:04.449661
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(
        get_input_output_paths(input_='examples/noqaspec', output='noqaspec')) == [
            InputOutput(Path('examples/noqaspec/__init__.py'), Path('noqaspec/__init__.py')),
            InputOutput(Path('examples/noqaspec/dummy.py'), Path('noqaspec/dummy.py')),
            InputOutput(Path('examples/noqaspec/dummy2.py'), Path('noqaspec/dummy2.py')),
        ]