

# Generated at 2022-06-21 17:13:03.105724
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Testing the get_input_output_paths function"""
    import pytest
    from .exceptions import InvalidInputOutput, InputDoesntExists

    test_dir = str(Path(__file__).parent)

    # Test invalid argument
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('test_func.py', 'test_func.txt')

    # Test invalid input
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('test_func.txt', 'test_func.py')

    # Test input is a single file and output is a regular file
    # And the input and output have the same name

# Generated at 2022-06-21 17:13:14.287692
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test if get_input_output_paths works correctly

    Basic tests that check if the function will detect invalid input/output pairs
    """
    from pathlib import Path

    TF = InputOutput
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('./python_files/a.py', './python_files/c.txt', './python_files/'))
        list(get_input_output_paths('./python_files/a.txt', './python_files/a.py', './python_files/'))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('./python_files/d.py', './python_files/a.py', './python_files/'))

   

# Generated at 2022-06-21 17:13:22.607956
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path('/root')
    out = Path('/out')

    assert list(get_input_output_paths('/root/a.py', '/out/a.py', None)) == [
        InputOutput(Path('/root/a.py'), Path('/out/a.py'))]

    assert list(get_input_output_paths(str(root), str(out), None)) == [
        InputOutput(child, out.joinpath(child.relative_to(root)))
        for child in root.glob('**/*.py')]

# Generated at 2022-06-21 17:13:32.194154
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path = Path('/tmp/input')
    path2 = Path('/tmp/input/test/test.py')
    path3 = Path('/tmp/input/test/test/test.py')

    assert list(get_input_output_paths(str(path), '/tmp/output', None)) \
        == [InputOutput(path2, Path('/tmp/output/test.py')),
            InputOutput(path3, Path('/tmp/output/test/test.py'))]
    assert list(get_input_output_paths(str(path), '/tmp/output', str(path))) \
        == [InputOutput(path2, Path('/tmp/output/test.py')),
            InputOutput(path3, Path('/tmp/output/test/test.py'))]

# Generated at 2022-06-21 17:13:39.639992
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test 2 dir
    from pathlib import Path
    a = get_input_output_paths('/a', '/b', None)
    a_ = [x for x in a]
    assert a_ == [InputOutput(Path('/a'), Path('/b'))]
    # Test 2 file
    a = get_input_output_paths('/a/a.py', '/b/b.py', None)
    a_ = [x for x in a]
    assert a_ == [InputOutput(Path('/a/a.py'), Path('/b/b.py'))]
    # Test dir to dir
    a = get_input_output_paths('/a', '/b', None)
    a_ = [x for x in a]

# Generated at 2022-06-21 17:13:50.526907
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_='/home/user/scripts',
        output='/home/user/scripts',
        root=None
    )) == [InputOutput(Path('/home/user/scripts'), Path('/home/user/scripts'))]

    assert list(get_input_output_paths(
        input_='tests/data/',
        output='test_output',
        root=None
    )) == [
        InputOutput(Path('tests/data/main.py'), Path('test_output/main.py')),
        InputOutput(Path('tests/data/subpackage/script.py'),
                    Path('test_output/subpackage/script.py'))]


# Generated at 2022-06-21 17:13:58.379873
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from pathlib import Path

    assert list(get_input_output_paths('inp.py', 'out.py', None)) == [
        InputOutput(Path('inp.py'), Path('out.py'))
    ]
    assert list(get_input_output_paths('inp.py', 'out', None)) == [
        InputOutput(Path('inp.py'), Path('out/inp.py'))
    ]
    assert list(get_input_output_paths('inp', 'out', None)) == [
        InputOutput(Path('inp/child.py'), Path('out/child.py'))
    ]

# Generated at 2022-06-21 17:14:07.266229
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""
    # Test --file/-f
    _input = 'filename.py'
    _output = 'filename.py.bak'
    assert list(get_input_output_paths(_input, _output, None)) == [InputOutput(Path('filename.py'), Path('filename.py.bak'))]

    _input = 'filename.py'
    _output = './'
    assert list(get_input_output_paths(_input, _output, None)) == [InputOutput(Path('filename.py'), Path('filename.py'))]

    _input = 'filename.py'
    _output = '/tmp/'

# Generated at 2022-06-21 17:14:17.963055
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_cases = [
        ('test/test_file.py', 'output/destination.py', None),
        ('test', 'output', 'test'),
        ('test', 'output', '/home/fake/test'),
        ('/home/fake/test', '/home/fake/output', None)
    ]
    expected = {
        'test/test_file.py': 'output/destination.py',
        'test/__init__.py': 'output/__init__.py',
        'test/dir/__init__.py': 'output/dir/__init__.py',
        'test/dir/file.py': 'output/dir/file.py'
    }
    for root in test_cases:
        result = dict(get_input_output_paths(*root))
        assert result == expected



# Generated at 2022-06-21 17:14:28.711046
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = "test_input_output"
    out = "test_input_output"
    full = "test_input_output/test_input_output"
    inp = "test_input_output/test_input_output.py"
    full_inp = "test_input_output/test_input_output/test_input_output.py"
    out_full_inp = "test_input_output/test_input_output/test_input_output.py"
    out_inp = "test_input_output/test_input_output.py"
    # for when the output directory does not have a .py extension
    assert get_input_output_paths(input_, out, None) == [(input_, out_inp), (full, out_full_inp)]
    # for when the

# Generated at 2022-06-21 17:14:39.106015
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit-test for function get_input_output_paths."""
    from pathlib import Path

    input_ = 'example/example.py'
    output = 'output'
    root = None
    paths = get_input_output_paths(input_, output, root)
    assert paths == [InputOutput((Path(input_)), (Path(output) / Path(input_).name))]

    input_ = 'input.txt'
    output = 'output.txt'
    root = None
    paths = get_input_output_paths(input_, output, root)
    assert paths == [InputOutput((Path(input_)), (Path(output) / Path(input_).name))]

    input_ = 'input.txt'
    output = 'output.txt'
    root = 'root.txt'
    paths

# Generated at 2022-06-21 17:14:49.835556
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1
    # root = ''
    # input = '../../data/test_input.py'
    # output = '../../data/output.py'
    root = ''
    input = 'data/test_input.py'
    output = 'output'
    result = list(get_input_output_paths(input, output, root))
    expected = [InputOutput(Path('data/test_input.py'), Path('output/test_input.py'))]
    assert result == expected

    # Case 2
    # root = ''
    # input = '../../data/'
    # output = '../../data/output'
    root = ''
    input = 'data/'
    output = 'output'
    result = list(get_input_output_paths(input, output, root))
   

# Generated at 2022-06-21 17:15:00.635481
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:15:10.304504
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths."""
    input_ = '/project/foo/bar.py'
    output = '/project/foo/baz.py'
    root = '/project'
    input_output = list(get_input_output_paths(input_, output, root))
    assert input_output == [InputOutput(Path('/project/foo/bar.py'), Path('/project/foo/baz.py'))]

    input_ = '/project/foo/bar.py'
    output = '/project/foo/'
    root = '/project'
    input_output = list(get_input_output_paths(input_, output, root))
    assert input_output == [InputOutput(Path('/project/foo/bar.py'), Path('/project/foo/bar.py'))]

# Generated at 2022-06-21 17:15:20.213172
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Tests for function get_input_output_paths."""

# Generated at 2022-06-21 17:15:27.083868
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root_path = Path(__file__).parent.parent
    pairs = get_input_output_paths('abc', 'abc.pyc', root='./')
    assert len(list(pairs)) == 0
    pairs = get_input_output_paths('abc.py', 'abc.pyc', root='./')
    assert len(list(pairs)) == 0
    pairs = get_input_output_paths('abc.py', 'xyz', root='./')
    for input_output in pairs:
        assert input_output.input == Path('abc.py')
        assert input_output.output == Path('xyz/abc.pyc')
    pairs = get_input_output_paths('./abc.py', 'xyz', root='./')

# Generated at 2022-06-21 17:15:39.860634
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        "./lib", "./lib", "./lib")) == [(Path('./lib/__init__.py'), Path('./lib/__init__.py'))]
    assert list(get_input_output_paths(
        "./lib/__init__.py", "./lib", "./lib")) == [(Path('./lib/__init__.py'), Path('./lib/__init__.py'))]
    assert list(get_input_output_paths(
        "./lib", "./build", "./lib")) == [(Path('./lib/sample.py'), Path('./build/sample.py'))]

# Generated at 2022-06-21 17:15:46.612706
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("test.py", "out.txt", None))
    
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("test.py", "out.py", None))
    
    paths = get_input_output_paths("test.py", "out.py", None)
    assert len(list(paths)) == 1
    assert list(paths)[0].input_path == Path("test.py")
    assert list(paths)[0].output_path == Path("out.py")

    paths = get_input_output_paths("test.py", "out", None)
    assert len(list(paths)) == 1

# Generated at 2022-06-21 17:15:50.892727
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo', 'bar', None) == [InputOutput(Path('foo'), Path('bar'))]
    assert get_input_output_paths('foo', 'bar', '.') == [InputOutput(Path('foo'), Path('bar'))]
    assert get_input_output_paths('foo/a.py', 'bar/b.py', None) == [InputOutput(Path('foo/a.py'), Path('bar/b.py'))]

# Generated at 2022-06-21 17:16:01.855924
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [
        InputOutput(Path('a.py'), Path('a.py')),
        InputOutput(Path('b.py'), Path('b.py'))
    ] == list(get_input_output_paths(
        input_='a.py b.py',
        output='a.py b.py',
        root=None
    ))
    assert [
        InputOutput(Path('a.py'), Path('b.py/a.py'))
    ] == list(get_input_output_paths(
        input_='a.py',
        output='b.py',
        root=None
    ))

# Generated at 2022-06-21 17:16:14.553327
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a.py', 'b/', None)) == [InputOutput(Path('a.py'), Path('b/a.py'))]
    assert list(get_input_output_paths('a.py', 'a.py', None)) == [InputOutput(Path('a.py'), Path('a.py'))]
    assert list(get_input_output_paths('a', 'a.py', None)) == []
    assert list(get_input_output_paths('a', 'b', None)) == []

# Generated at 2022-06-21 17:16:23.747054
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    with TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        # error test
        with pytest.raises(InputDoesntExists):
            for x in get_input_output_paths('t', 't', None):
                assert False
        # error test: input is a folder, output is a file  
        with pytest.raises(InvalidInputOutput):
            for x in get_input_output_paths(temp_path, 't.py', None):
                assert False
        # error test: input is a file, output is a folder
        with pytest.raises(InvalidInputOutput):
            (temp_path / 'a.py').touch()

# Generated at 2022-06-21 17:16:34.491249
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import tempfile
    from pathlib import Path
    from shutil import rmtree, copytree
    from .exceptions import InvalidInputOutput, InputDoesntExists, OutputAlreadyExists


# Generated at 2022-06-21 17:16:41.776188
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

    # Invalid input/output
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b', None)

    # Input does not exist
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('/tmp/a.py', '/tmp/b.py', None)

    def test_input_and_output(input_: str, output: str, root: Optional[str],
                              expected: InputOutput):
        paths = get_input_output_paths(input_, output, root)
        assert next(paths) == expected
        with pytest.raises(StopIteration):
            next(paths)

    # Input and output at the same directory level
    test_input_and_

# Generated at 2022-06-21 17:16:53.102134
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    io_paths = get_input_output_paths(
        input_='../test/test_data/test1.py',
        output='../test/test_data/test1out.py',
        root=None
    )
    assert next(io_paths) == InputOutput(Path("../test/test_data/test1.py"), Path("../test/test_data/test1out.py"))
    with pytest.raises(StopIteration):
        next(io_paths)

    io_paths = get_input_output_paths(
        input_='../test/test_data/',
        output='../test/test_data/output',
        root=None
    )

# Generated at 2022-06-21 17:17:03.856771
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = 'C:\\Users\\Agustin Kambourian\\Documents\\PyRevit\\pyrevit\\pyrevitlib'
    input_ = 'C:\\Users\\Agustin Kambourian\\Documents\\PyRevit\\pyrevit\\pyrevitlib\\wm'
    output_ = 'C:\\Users\\Agustin Kambourian\\Documents\\PyRevit\\pyrevit\\pyrevitlib\\wm'
    #Expected result: ['.pyrevit/data/pyrevitlibs/PyRevitModdingTools.py',
    #                 '.pyrevit/data/pyrevitlibs/wm/windowmanager.py',
    #                 '.pyrevit/data/pyrevitlibs/wm/windowmanagers.py']

# Generated at 2022-06-21 17:17:13.371886
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from . import get_input_output_paths
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    import pytest

    def test_get_input_output_paths_pair(input_: str, output: str,
                            root: Optional[str], expected_paths: Iterable[InputOutput]):
        assert expected_paths == list(get_input_output_paths(input_, output, root))

    def test_get_input_output_paths_error(input_: str, output: str, root: Optional[str],
                                          expected_exc):
        pytest.raises(expected_exc, get_input_output_paths, input_, output, root)


# Generated at 2022-06-21 17:17:23.632812
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.txt', 'b.py', None))
    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('c.py', 'b', None))

    # Test for valid inputs

# Generated at 2022-06-21 17:17:35.530965
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Input and output are both files
    result = list(get_input_output_paths("file1.py", "file2.py", None))
    assert result == [InputOutput("file1.py", "file2.py")]

    # Input and output are both folders
    result = list(get_input_output_paths("folder1", "folder2", None))
    assert result == [InputOutput("folder1\file1.py", "folder2\file1.py")]

    # Input is file and output is folder
    result = list(get_input_output_paths("file1.py", "folder2", None))
    assert result == [InputOutput("file1.py", "folder2\file1.py")]

    # Input is file and output is folder

# Generated at 2022-06-21 17:17:43.203560
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('./tests/foo.py', './tests/bar.txt', None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('unknownfile.py', './tests/bar.txt', None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('unknownfile.txt', './tests/bar.txt', None))

    x = list(get_input_output_paths('./tests/foo.py', './tests/bar.txt', None))
    assert len(x) == 1
    assert x[0].input_path.name == 'foo.py'
    assert x[0].output_path

# Generated at 2022-06-21 17:17:57.265463
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('folder', 'file.py', None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('folder', 'folder', '/path'))

    inputs = list(get_input_output_paths('/file.py', '/folder', '/path'))
    assert len(inputs) == 1
    assert inputs[0].input_path == Path('/file.py')
    assert inputs[0].output_path == Path('/folder/file.py')

    inputs = list(get_input_output_paths('/path/file.py', '/folder', '/path'))
    assert len(inputs) == 1

# Generated at 2022-06-21 17:18:05.858658
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths(
        '/home/user/foo', '/home/user/bar', None) == [
            InputOutput(Path('/home/user/foo'), Path('/home/user/bar'))
        ]

    assert get_input_output_paths(
        '/home/user/foo/foo.py', '/home/user/bar', None) == [
            InputOutput(Path('/home/user/foo/foo.py'), Path('/home/user/bar/foo.py'))
        ]

    assert get_input_output_paths(
        '/home/user/foo', '/home/user/bar/baz.py', None) == [
            InputOutput(Path('/home/user/foo'), Path('/home/user/bar/baz.py'))
        ]



# Generated at 2022-06-21 17:18:15.962555
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths"""
    paths = get_input_output_paths(
        input_='/root/input', output='/root/output', root='/root')
    assert paths == [InputOutput(Path('/root/input'), Path('/root/output'))]

    paths = get_input_output_paths(input_='/root/input/a.py',
                                   output='/root/output', root='/root')
    assert paths == [InputOutput(Path('/root/input/a.py'),
                                 Path('/root/output/a.py'))]

    paths = get_input_output_paths(input_='/root/input/a.py',
                                   output='/root/output/b.py', root='/root')

# Generated at 2022-06-21 17:18:25.851472
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Get input/output paths pairs."""
    assert len(list(get_input_output_paths('', '', ''))) ==0
    assert len(list(get_input_output_paths('abc', 'abc', ''))) ==0
    assert len(list(get_input_output_paths('abc', 'abc/def', ''))) ==1
    assert len(list(get_input_output_paths('abc', 'def', ''))) ==1
    assert len(list(get_input_output_paths('abc/def', 'ghi', ''))) ==1
    assert len(list(get_input_output_paths('abc', 'def/ghi', 'abc'))) ==0
    assert len(list(get_input_output_paths('abc/def', 'ghi/jkl', 'abc')))

# Generated at 2022-06-21 17:18:33.985197
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    expected = [InputOutput(Path('a.py'), Path('b.py')),
                InputOutput(Path('c.py'), Path('d.py')),
                InputOutput(Path('e.py'), Path('f.py')),
                InputOutput(Path('folder/g.py'), Path('folder/g.py')),
                InputOutput(Path('folder/h.py'), Path('folder/h.py')),
                InputOutput(Path('folder/i.py'), Path('folder/i.py')),
                InputOutput(Path('folder/sub_folder/j.py'), Path('folder/sub_folder/j.py'))]
    assert list(get_input_output_paths('folder', 'folder', 'folder')) == expected


# Generated at 2022-06-21 17:18:45.196372
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:18:55.148814
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as root:
        input_path = Path(root) / 'input'
        input_path.mkdir()
        (input_path / 'foo.py').touch()
        (input_path / 'bar.py').touch()

        output_path = Path(root) / 'output'
        output_path.mkdir()

        # Basic case
        paths = list(get_input_output_paths(str(input_path), str(output_path),
                                            str(input_path)))

# Generated at 2022-06-21 17:19:00.846447
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py','b.py', None)) == [('a.py', 'b.py')]
    assert list(get_input_output_paths('a', 'b', None)) == [('a/a.py', 'b/a.py')]
    assert list(get_input_output_paths('a', 'b', 'a')) == [('a/a.py', 'b/a.py')]


# Generated at 2022-06-21 17:19:12.613640
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for function get_input_output_paths."""
    import tempfile

    assert list(get_input_output_paths('a', 'b', None)) == []

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    child_file = Path(input_).joinpath('child.py')
    child_file.touch()

    assert list(get_input_output_paths('a', 'b', None)) == []
    assert list(get_input_output_paths(input_, output, None)) == \
        [InputOutput(Path(input_).joinpath('child.py'),
                     Path(output).joinpath('child.py'))]

# Generated at 2022-06-21 17:19:22.962151
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from nose.tools import assert_equal

    test_cases = (
        (
            InputOutput('a.py', 'b.py'),
            'a.py', 'b.py', ''
        ),
        (
            InputOutput('a.py', 'b/c.py'),
            'a.py', 'b/', '',
        ),
        (
            InputOutput('a/a.py', 'b/a.py'),
            'a/', 'b/', '',
        ),
        (
            InputOutput('a/a.py', 'b/a.py'),
            'a/', 'b/', 'a/',
        ),
    )


# Generated at 2022-06-21 17:19:43.351967
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test that get_input_output_paths functions correctly."""
    assert [i for i in get_input_output_paths('a.py', 'b.py', '.')] == [InputOutput(Path('a.py'), Path('b.py'))]
    assert [i for i in get_input_output_paths('a.py', 'nb', '.')] == [InputOutput(Path('a.py'), Path('nb/a.py'))]
    assert [i for i in get_input_output_paths('a.ipynb', 'nb', '.')] == \
        [InputOutput(Path('a.ipynb'), Path('nb/a.ipynb'))]


# Generated at 2022-06-21 17:19:51.617373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Tests the function get_input_output_paths."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists
    assert isinstance(get_input_output_paths("./test/test.py", "./test/test2.py", "./"), Iterable)
    assert isinstance(get_input_output_paths("./test/test.py", "./test/test2.py", ".")[0], InputOutput)
    assert isinstance(get_input_output_paths("./test/test.py", "./test/test2", "./"), Iterable)
    assert isinstance(get_input_output_paths("./test/test.py", "./test/test2", ".")[0], InputOutput)

# Generated at 2022-06-21 17:20:01.164480
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:20:11.427815
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:20:17.294260
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Test case 1 - absolute input and output paths with directory output.
    # --------------
    input_ = '/tmp/input/'
    output = '/tmp/output/'

    # Create directory and files.
    Path(input_ + 'a.py').touch()
    Path(input_ + 'b.py').touch()
    Path(input_ + 'c').mkdir(parents=True)
    Path(input_ + 'c/c.py').touch()
    Path(input_ + 'c/d.py').touch()
    Path(input_ + 'e.py').touch()

    # Check get_input_output_paths function.
    result = list(get_input_output_paths(input_, output, None))
    result = sorted(result, key=lambda x: x.input.name)

# Generated at 2022-06-21 17:20:22.565486
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = 'path/to/input'
    output = 'path/to/output'
    root = None
    assert list(get_input_output_paths(input_, output, root)) == \
        [InputOutput(Path(input_), Path(output))]

    input_ = 'path/to/input'
    output = 'path/to/output'
    root = 'path/to/'
    assert list(get_input_output_paths(input_, output, root)) == \
        [InputOutput(Path(input_), Path(output))]

    input_ = 'path/to/input'
    output = 'path/to/'
    root = None

# Generated at 2022-06-21 17:20:33.201548
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:20:44.017592
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths function"""
    from .types import InputOutput

    input_ = Path('input.py')
    output = Path('output.py')
    root = None
    actual = InputOutput(input_, output)
    expected = next(get_input_output_paths(str(input_), str(output), root))
    assert expected == actual
    input_ = Path('.')
    output = Path('.')
    root = None
    actual = InputOutput(input_, output)
    expected = next(get_input_output_paths(str(input_), str(output), root))
    # On Windows we will get pathlib.WindowsPath object,
    # so we need to convert it to str
    assert str(expected) == str(actual)

test_get_input_output_

# Generated at 2022-06-21 17:20:56.157175
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = {}
    input_output['input_file'] = (
        'test_get_input_output_paths_input.py', 'test_get_input_output_paths_output.py')
    input_output['input_dir_to_output_file'] = (
        'test_get_input_output_paths_input', 'test_get_input_output_paths_output.py')
    input_output['input_dir_to_output_dir'] = (
        'test_get_input_output_paths_input', 'test_get_input_output_paths_output')

# Generated at 2022-06-21 17:21:05.346013
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths('other_simple_test.py', 'output.txt', '.')
        assert False
    except InputDoesntExists:
        get_input_output_paths('test.py', 'output.txt', '.')
    assert get_input_output_paths('test.py', 'output.txt', '.') == \
           [InputOutput(path='test.py', out_path='output.txt')]
    try:
        get_input_output_paths('test.py', 'test2.py', '.')
        assert False
    except InvalidInputOutput:
        pass

# Generated at 2022-06-21 17:21:37.405029
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .tests import (
        INPUT_DIR, OUTPUT_DIR, INVALID_INPUT_FILE, INVALID_OUTPUT_FILE,
        VALID_INPUT_FILES, VALID_OUTPUT_FILES)

    assert list(get_input_output_paths(INVALID_INPUT_FILE,
                                       OUTPUT_DIR,
                                       INPUT_DIR)) == VALID_INPUT_FILES

    assert list(get_input_output_paths(INVALID_INPUT_FILE,
                                       INVALID_OUTPUT_FILE,
                                       INPUT_DIR)) == VALID_INPUT_FILES

    assert list(get_input_output_paths(INVALID_INPUT_FILE,
                                       OUTPUT_DIR,
                                       None)) == VALID_

# Generated at 2022-06-21 17:21:48.354034
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:21:58.311169
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InvalidInputOutput):
        get_input_output_paths('a', 'b.py', None)
    with raises(InputDoesntExists):
        get_input_output_paths('a.py', 'b.py', None)

    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a.py', 'b', None)) == [InputOutput(Path('a.py'), Path('b').joinpath('a.py'))]

# Generated at 2022-06-21 17:22:09.296749
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    with raises(InputDoesntExists):
        next(get_input_output_paths('./some/input.py',
                                    './some/output.py',
                                    './wow'))

    with raises(InvalidInputOutput):
        next(get_input_output_paths('this_is_input.py', 'this_is_output',
                                    None))

    a, b = next(get_input_output_paths('this_is_input.py',
                                       'this_is_output.py',
                                       None))
    assert a == Path('this_is_input.py') and b == Path('this_is_output.py')


# Generated at 2022-06-21 17:22:19.660314
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        pairs = get_input_output_paths('input', 'output', 'root')
        assert False, "Output must include a .py extension"
    except InvalidInputOutput:
        pass

    try:
        pairs = get_input_output_paths('./tests/input/test.py', 'output',
                                       'root')
        assert False, "Input doesn't exist"
    except InputDoesntExists:
        pass

    pairs = list(get_input_output_paths('./tests/input/test.py',
                                        './tests/output/test.py',
                                        'root'))
    assert len(pairs) == 1, "Number of pairs must be 1"
    assert len(pairs[0]) == 2, "Number of elements in a pair must be 2"
    assert len

# Generated at 2022-06-21 17:22:31.240429
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_path = Path(__file__)
    top_dir = input_path.parent.parent
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(str(input_path), '.py', str(top_dir)))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(str(input_path) + '_no_exist', '.py', str(top_dir)))
    input_output_pairs = list(get_input_output_paths(str(input_path), '.py', str(top_dir)))
    assert len(input_output_pairs) == 1

# Generated at 2022-06-21 17:22:40.390379
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    import os
    
    test_dir = mkdtemp()
    test_dir2 = os.path.join(test_dir, "test_dir")
    test_file1 = os.path.join(test_dir, "test_file1.py")
    test_file2 = os.path.join(test_dir2, "test_file2.py")
    test_file3 = os.path.join(test_dir, "test_file3.txt")
    test_file4 = os.path.join(test_dir2, "test_file4.txt")
    os.mkdir(test_dir2)
    open(test_file1, "a").close()
    open(test_file2, "a").close()
   

# Generated at 2022-06-21 17:22:50.455366
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""
    # Valid state