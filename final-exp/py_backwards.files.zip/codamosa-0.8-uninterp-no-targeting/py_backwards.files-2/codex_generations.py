

# Generated at 2022-06-21 17:13:02.127743
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a.py', 'b.py', None)) == \
           [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('dir1', 'dir2', None)) == \
           [InputOutput(Path('dir1/a.py'), Path('dir2/a.py'))]
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a.py', 'py', None))
    assert list(get_input_output_paths('a.py', None, None)) == \
           [InputOutput(Path('a.py'), Path('a.py'))]

# Generated at 2022-06-21 17:13:13.682775
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    here = os.path.dirname(os.path.abspath(__file__))

    # Test pair: input_file, output_file, root
    # input_file should be a .py file
    # if root is None, root is set to the folder containing input_file
    # output_file could be a .py file or a folder
    inputs_outputs = [
        ['examples/example.py', 'example/output.py', None],
        ['examples/example.py', 'example/output', None],
        ['examples/example.py', 'example/output.py', 'examples'],
        ['examples/example.py', 'example/output', 'examples'],
    ]


# Generated at 2022-06-21 17:13:22.021427
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from fnmatch import fnmatchcase
    inputs = [
        ('this/is/input.py', 'this/is/output.py'),
        ('input.py', 'this/is/output.py'),
        ('input.py', 'output.py'),
        ('input_dir', 'this/is/output_dir'),
        ('input_dir', 'this/is/output_dir'),
        ('input_dir', 'output_dir'),
    ]

# Generated at 2022-06-21 17:13:30.913420
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1: Input and Output both .py
    #         Input: file_a.py
    #         Output: file_b.py
    assert [InputOutput(Path("file_a.py"), Path("file_b.py"))] == list(get_input_output_paths("file_a.py", "file_b.py", None))

    # Case 2: Input and Output not in the same directory
    #         Input: file_a.py, folder2/file_b.py
    #         Output: folder3

# Generated at 2022-06-21 17:13:39.161655
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """"
    Function to test get_input_output_paths
    """
    output = 'test_files/test_output/nickname'
    input_ = 'test_files/input/'
    root = 'test_files/input/'


# Generated at 2022-06-21 17:13:50.291275
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Case 1: input is file and output is file
    input_ = 'a.py'
    output = 'b.py'
    ret = list(get_input_output_paths(input_, output, None))
    assert ret == [InputOutput(Path('a.py'), Path('b.py'))]

    # Case 2: input is file and output is directory, use relative path
    input_ = 'a.py'
    output = 'd'
    ret = list(get_input_output_paths(input_, output, None))
    assert ret == [InputOutput(Path('a.py'), Path('d/a.py'))]

    # Case 3: input is directory and output is directory, use relative path
    input_ = 'd1'
    output = 'd2'

# Generated at 2022-06-21 17:14:00.342419
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    paths = get_input_output_paths("sample_input.py", "sample_output.py", 
                                   None)
    assert("sample_input.py" in str(paths)) and ("sample_output.py" in str(paths))
    paths = get_input_output_paths("sample_input.py", "sample_output", 
                                   None)
    assert("sample_input.py" in str(paths)) and ("sample_output/sample_input.py" in str(paths))
    paths = get_input_output_paths("sample_input", "sample_output", 
                                   None)
    assert("sample_input/sample_input.py" in str(paths)) and ("sample_output/sample_input.py" in str(paths))


# Generated at 2022-06-21 17:14:07.852307
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    # get_input_output_paths(input_, output, root=None)
    assert [InputOutput(Path('a/b.py'), Path('a/b.py'))] == \
        list(get_input_output_paths('a/b.py', 'a/b.py', None))
    assert [InputOutput(Path('a/b.py'), Path('x.py'))] == \
        list(get_input_output_paths('a/b.py', 'x.py', None))
    assert [InputOutput(Path('a/b.py'), Path('a/x.py'))] == \
        list(get_input_output_paths('a/b.py', 'a/x.py', None))
   

# Generated at 2022-06-21 17:14:18.162411
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a/b/c', 'd/e/c', 'a')) == [InputOutput(Path('a/b/c'), Path('d/e/c'))]
    assert list(get_input_output_paths('a/b/c/d.py', 'e/f/g', 'a/b')) == [InputOutput(Path('a/b/c/d.py'), Path('e/f/g/d.py'))]

# Generated at 2022-06-21 17:14:27.650049
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('scripts/example1.py', 'out', None) == [
        InputOutput(
            Path('scripts/example1.py'), Path('out/example1.py'))]
    assert get_input_output_paths('scripts', 'out', None) == [
        InputOutput(
            Path('scripts/example1.py'), Path('out/example1.py'))]
    assert get_input_output_paths('scripts', 'out', 'scripts') == [
        InputOutput(
            Path('scripts/example1.py'), Path('out/example1.py'))]


# Generated at 2022-06-21 17:14:36.440907
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:14:48.123570
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    f_input = "test_input.py"
    f_output = "test_output.py"
    assert get_input_output_paths(f_input, f_output, None) == \
        [InputOutput(Path(f_input), Path(f_output))]
    assert get_input_output_paths("test_input/", "test_output/", None) == \
        [InputOutput(Path("test_input/a.py"), Path("test_output/a.py"))]
    assert get_input_output_paths("test_input/", "test_output.py", None) == \
        [InputOutput(Path("test_input/a.py"), Path("test_output.py/a.py"))]

# Generated at 2022-06-21 17:14:59.975393
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:15:10.074484
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    expected_values = [InputOutput(Path('one.py'), Path('two/one.py')), 
                      InputOutput(Path('one/two/three.py'), Path('two/one/two/three.py')), 
                      InputOutput(Path('one/two/three.py'), Path('two/one/two/three.py')), 
                      InputOutput(Path('one/two/three.py'), Path('two/three.py'))]
                                                                                                                                            
    assert list(get_input_output_paths('one.py', 'two', None)) == [expected_values[0]]
    
    assert list(get_input_output_paths('one/', 'two', None)) == [expected_values[1], expected_values[2]]

# Generated at 2022-06-21 17:15:20.195124
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    io = get_input_output_paths('/', '.', None)
    io = [x for x in io]
    assert io[0][0] == Path('/')
    assert io[0][1] == Path('.')
    io = get_input_output_paths('a.py', '.', None)
    io = [x for x in io]
    assert io[0][0] == Path('a.py')
    assert io[0][1] == Path('a.py')
    io = get_input_output_paths('test_data', '.', None)
    io = [x for x in io]
    assert io[0][0] == Path('test_data/a.py')
    assert io[0][1] == Path('a.py')

# Generated at 2022-06-21 17:15:30.672195
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    class TestCase(object):
        description: str
        input_: str
        output: str
        root: Optional[str]
        expected_output: Iterable[InputOutput]
        expected_error: Optional[BaseException]

    current_path = Path(__file__).parent

# Generated at 2022-06-21 17:15:36.580701
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test InvalidInputOutput exception
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("tests/example.txt", "tests/example.txt", "tests")
    
    # Test InputDoesntExists exception
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("tests/example.py", "tests/example.py", "tests")

    # Test valid I/O pairs
    assert get_input_output_paths("tests/example.py", "tests/example.py", "tests") == [InputOutput("tests/example.py", "tests/example.py")]

# Generated at 2022-06-21 17:15:42.990145
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('foo.py', 'bar.py', None)) == [InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo', 'bar', None)) == [InputOutput(Path('foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('foo', 'bar', 'src')) == [InputOutput(Path('src/foo.py'), Path('bar.py'))]
    assert list(get_input_output_paths('src', 'build', 'src')) == [InputOutput(Path('src/foo.py'), Path('build/foo.py'))]

# Generated at 2022-06-21 17:15:50.938074
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function get_input_output_paths."""
    # test with input file and output file
    print("test with input file and output file")
    input_ = "input_sample.py"
    output = "outp_sample.py"
    root = None
    paths = get_input_output_paths(input_, output, root)
    assert next(paths) == InputOutput(Path("input_sample.py"), Path("outp_sample.py"))

    # test with input directory and output directory
    print("test with input directory and output directory")
    input_ = "input_dir"
    output = "outp_dir"
    root = None
    paths = get_input_output_paths(input_, output, root)

# Generated at 2022-06-21 17:15:56.792934
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('/test/test.py',
                                  '/test/test_output.py',
                                  None) == [InputOutput('/test/test.py', '/test/test_output.py')]

# Generated at 2022-06-21 17:16:56.691631
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = '/root'
    root_py = root + '/foo/bar/x.py'
    source = '/source'
    output = '/output'
    source_py = source + '/foo/bar/x.py'
    dest_py = output + '/foo/bar/x.py'
    dest_directory = output + '/foo/bar'

    result = get_input_output_paths(source_py, output, root)
    assert next(result) == InputOutput(Path(source_py), Path(dest_py))
    assert next(result, None) is None

    result = get_input_output_paths(source, output, root)
    assert next(result) == InputOutput(Path(source_py), Path(dest_py))
    assert next(result, None) is None

    result = get_input

# Generated at 2022-06-21 17:17:07.438034
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test with only input
    assert list(get_input_output_paths(os.path.join('examples', 'input'), '', '')) == [InputOutput(Path('examples/input/example.py'), Path('example.py'))]
    # Test with root path
    assert list(get_input_output_paths(os.path.join('examples', 'input'), '', os.path.join('examples', 'input'))) == [InputOutput(Path('examples/input/example.py'), Path('example.py'))]
    # Test with an output folder

# Generated at 2022-06-21 17:17:16.941042
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    assert list(get_input_output_paths('foo.py', 'bar/baz.py', None)) == [
        InputOutput(Path('foo.py'), Path('bar/baz.py'))]
    assert list(get_input_output_paths('foo.py', 'bar/baz', None)) == [
        InputOutput(Path('foo.py'), Path('bar/baz/foo.py'))]
    assert list(get_input_output_paths('bar/baz', 'foo.py', None)) == [
        InputOutput(Path('bar/baz/foo.py'), Path('foo.py'))]

# Generated at 2022-06-21 17:17:24.912951
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [
        InputOutput(Path('./foo.py'), Path('./output/foo.py')),
    ] == list(get_input_output_paths('foo.py', 'output', None))
    assert [
        InputOutput(Path('./foo.py'), Path('./bar.py')),
    ] == list(get_input_output_paths('foo.py', 'bar.py', None))
    assert [
        InputOutput(Path('./bar.py'), Path('./foo.py')),
    ] == list(get_input_output_paths('bar.py', 'foo.py', None))

# Generated at 2022-06-21 17:17:35.885886
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Get input/output pairs for single file
    input_output_pairs = list(get_input_output_paths('a.py', 'c.py',
                                                     root=None))
    assert len(input_output_pairs) == 1
    input_ = input_output_pairs[0][0]
    output = input_output_pairs[0][1]
    assert input_.name == 'a.py' and output.name == 'c.py'

    # Get input/output pairs for directory
    input_output_pairs = list(get_input_output_paths('a', 'c', root=None))
    assert len(input_output_pairs) == 1
    input_ = input_output_pairs[0][0]
    output = input_output_pairs[0][1]


# Generated at 2022-06-21 17:17:42.203714
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:17:53.049582
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = "C:\\Users\\akano\\Desktop\\test_input_output"
    input_ = "C:\\Users\\akano\\Desktop\\test_input_output\\test_input.py"
    output = "C:\\Users\\akano\\Desktop\\test_input_output\\test_output.py"
    assert get_input_output_paths(input_, output, root) == (InputOutput(Path("C:\\Users\\akano\\Desktop\\test_input_output\\test_input.py"), Path("C:\\Users\\akano\\Desktop\\test_input_output\\test_output.py")),)

# Generated at 2022-06-21 17:18:03.360446
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .types import InputOutput

    if not os.path.isdir('tests'):
        os.mkdir('tests')
    assert get_input_output_paths(
        'tests', 'tests', None) == \
           [InputOutput(Path('tests'), Path('tests'))]

    os.chdir('tests')
    if not os.path.isdir('tests_in'):
        os.mkdir('tests_in')
    if not os.path.isdir('tests_out'):
        os.mkdir('tests_out')
    with open('tests_in/test.py', 'w') as f:
        f.write('#')


# Generated at 2022-06-21 17:18:09.103923
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    a = get_input_output_paths("input", "output", "root")
    assert a == (Path("input").exists())
    assert a == (Path("output").exists())
    assert a == (Path("root").exists())

# Generated at 2022-06-21 17:18:16.971940
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('a', 'b', None)) == [InputOutput(Path('a'), Path('b'))]
    assert list(get_input_output_paths('a.py', 'b.py', None)) == [InputOutput(Path('a.py'), Path('b.py'))]
    assert list(get_input_output_paths('a', 'b', 'c')) == [InputOutput(Path('a'), Path('b'))]
    assert list(get_input_output_paths('a.py', 'b', 'c')) == [InputOutput(Path('a.py'), Path('b/a.py'))]

# Generated at 2022-06-21 17:19:16.127936
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('.', '.', '.')) == [
        InputOutput(Path('./a.py'), Path('./a.py')),
        InputOutput(Path('./b.py'), Path('./b.py')),
        InputOutput(Path('./d/c.py'), Path('./d/c.py')),
    ]
    assert list(get_input_output_paths('.', '.', './d')) == [
        InputOutput(Path('./d/c.py'), Path('./c.py')),
    ]

# Generated at 2022-06-21 17:19:27.181054
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit tests for get_input_output_paths."""
    assert list(get_input_output_paths('a/b.py', 'c', None)) == [
        InputOutput(Path('a/b.py'), Path('c/b.py'))]
    assert list(get_input_output_paths('a/b.py', 'c.py', None)) == [
        InputOutput(Path('a/b.py'), Path('c.py'))]
    assert list(get_input_output_paths('a', 'b', None)) == [
        InputOutput(Path('a/b.py'), Path('b/b.py'))]

# Generated at 2022-06-21 17:19:37.005146
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    try:
        get_input_output_paths("123", "123", "123")
        assert False
    except InputDoesntExists:
        assert True

    try:
        get_input_output_paths("123.py", "123", "123")
        assert False
    except InvalidInputOutput:
        assert True

    try:
        get_input_output_paths("123.py", "123.py", "123")
        assert False
    except InvalidInputOutput:
        assert True

    assert str(next(get_input_output_paths("123.py", "123/321.py", "123"))[0]).find("123/123.py") != -1
    assert str(next(get_input_output_paths("123.py", "123/321.py", "123"))[1]).find

# Generated at 2022-06-21 17:19:42.647896
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    args = ['-i', './examples/example.py', '-o', './output/']
    inputs = ['./examples/example.py']
    outputs = ['./output/example.py']
    root = './examples/'
    counter = 0
    for path in get_input_output_paths(args[1], args[3], root):
        assert str(path.input_path) == inputs[counter]
        assert str(path.output_path) == outputs[counter]
        counter += 1

# Generated at 2022-06-21 17:19:51.532738
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test input output file
    paths = get_input_output_paths('test.py', 'output/test.py', 'test/test.py')
    assert isinstance(paths, Iterable)
    for path in paths:
        assert path.input_path == Path('test.py')
        assert path.output_path == Path('output/test.py')

    # test input output directory
    paths = get_input_output_paths('test', 'output', 'test')
    assert isinstance(paths, Iterable)
    for path in paths:
        assert path.input_path.is_file()
        assert path.input_path.parent == Path('test')
        assert path.output_path.is_file()
        assert path.output_path.parent == Path('output')

    # test input file output directory

# Generated at 2022-06-21 17:20:01.157524
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Get input/output paths pairs."""
    root = Path(__file__).parent

    if root.joinpath('input.py').exists():
        # Test with a single file
        assert list(get_input_output_paths(
            'input.py', 'output.py', str(root))) == [
                InputOutput(root.joinpath('input.py'), root.joinpath('output.py'))]
        assert list(get_input_output_paths(
            'input.py', 'output', str(root))) == [
                InputOutput(root.joinpath('input.py'), root.joinpath('output/input.py'))]

# Generated at 2022-06-21 17:20:08.946270
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    root = Path(__file__).parent
    input_ = root.joinpath('test_input')
    output = root.joinpath('test_output')
    input_output = get_input_output_paths(str(input_), str(output), str(root))
    result = [(input_, output), (input_.joinpath('child'), output.joinpath('child'))]

    assert list(input_output) == result

# Generated at 2022-06-21 17:20:20.753297
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test the function
    test_input_file_paths = os.path.join(os.path.dirname(__file__), 'fixtures', 'input1')
    test_input_dir_paths = os.path.join(os.path.dirname(__file__), 'fixtures', 'input2')
    test_output_dir_paths = os.path.join(os.path.dirname(__file__), 'fixtures', 'input1.v1')
    test_output_file_paths = os.path.join(os.path.dirname(__file__), 'fixtures', 'input1', 'test.py')
    
    # assert the results

# Generated at 2022-06-21 17:20:30.511697
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths"""
    source_file='spam.py'
    target_file='eggs.py'
    source_dir='spam'
    target_dir='eggs'
    root='/ham'
    assert get_input_output_paths(source_file, target_file, root) == [
        InputOutput(Path(source_file), Path(target_file))]
    assert get_input_output_paths(source_dir, target_dir, root) == [
        InputOutput(input, output) for input, output in zip(
            Path(source_dir).glob('**/*.py'), Path(target_dir).glob('**/*.py'))]

# Generated at 2022-06-21 17:20:41.100844
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # 1) input is a directory, output is a directory
    # simple case
    inputs = get_input_output_paths(
        input_='/tmp/foo', output='/tmp/bar', root=None)
    inputs = list(inputs)
    assert inputs == [
        InputOutput(Path('/tmp/foo/baz.py'),
                    Path('/tmp/bar/baz.py'))
    ]

    # complex case
    inputs = get_input_output_paths(
        input_='/tmp/foo', output='/tmp/bar', root='/tmp/foo')
    inputs = list(inputs)
    assert inputs == [
        InputOutput(Path('/tmp/foo/baz.py'),
                    Path('/tmp/bar/baz.py'))
    ]

    # 2)

# Generated at 2022-06-21 17:22:40.489876
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unittest for function get_input_output_paths
    """
    from .exceptions import InputDoesntExists, InvalidInputOutput

    # Case 1 : input
    #           - not .py
    #           - exists
    #           - not end with .py
    #         output
    #           - is dir
    #           - exists
    #           - not relative
    #           - not end with .py
    #         root
    #           - None
    #         -> failed
    input_ = "test/data/test_get_input_output_paths_case1_input/input"
    output = "test/data/test_get_input_output_paths_case1_input/output"
    root = None


# Generated at 2022-06-21 17:22:50.456656
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test to check get_input_output_paths function."""
    from .types import InputOutput
    from .exceptions import InvalidInputOutput

    input_ = 'foo.py'
    output = 'bar.py'
    assert list(get_input_output_paths(input_, output, None)) == [
        InputOutput(Path('foo.py'), Path('bar.py'))]

    input_ = 'foo'
    output = 'bar'