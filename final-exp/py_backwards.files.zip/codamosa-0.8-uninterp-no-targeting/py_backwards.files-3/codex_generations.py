

# Generated at 2022-06-21 17:13:11.194646
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('test', 'output', None)) == \
        [InputOutput(
            Path('test').joinpath('test1.py'),
            Path('output').joinpath('test').joinpath('test1.py')
        ), InputOutput(
            Path('test').joinpath('test2.py'),
            Path('output').joinpath('test').joinpath('test2.py')
        )]
    assert list(get_input_output_paths('test/test1.py', 'output', None)) == \
        [InputOutput(
            Path('test').joinpath('test1.py'),
            Path('output').joinpath('test').joinpath('test1.py')
        )]

# Generated at 2022-06-21 17:13:18.380874
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""
    root = '/home/user'

    # First case
    in_ = ['a1.py', 'b1.py', 'b2.py']
    out = 'a2.py'
    input_ = root + '/' + in_[0]
    output = root + '/' + out

    for io in get_input_output_paths(input_, output, root):
        print("Input: " + io.input.__str__())
        print("Output: " + io.output.__str__())
        assert io.input.name, in_[0]
        assert io.output.name, out

    # Second case
    in_ = ['a1.py', 'a2.py']
    out = root + '/a3.py'
   

# Generated at 2022-06-21 17:13:25.955108
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()"""
    import unittest.mock as mock
    from pathlib import Path

    # Test py to py
    with mock.patch('pathlib.Path.exists') as exists:
        exists.return_value = True
        path_list = list(get_input_output_paths('input1.py', 'output1.py', None))

    assert len(path_list) == 1
    assert path_list[0] == InputOutput(Path('input1.py'), Path('output1.py'))

    # Test py to other with root
    with mock.patch('pathlib.Path.exists') as exists:
        exists.return_value = True

# Generated at 2022-06-21 17:13:38.316802
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    here = Path(__file__).parent

    # -------------------------------------------------------------------------
    # Test 1: no input
    # -------------------------------------------------------------------------
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')

    # -------------------------------------------------------------------------
    # Test 2: missing input
    # -------------------------------------------------------------------------
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('', '', '')

    # -------------------------------------------------------------------------
    # Test 3: invalid input/output
    # -------------------------------------------------------------------------
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths(str(here / '../fixtures/dummy1.py'),
                               str(here / '../fixtures'),
                               str(here / '../fixtures'))

    # -------------------------------------------------------------------------
   

# Generated at 2022-06-21 17:13:49.636102
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_output = list(get_input_output_paths("haha.py", "output", None))
    assert len(input_output) == 1, "get_input_output_paths fails"

    input_output = list(get_input_output_paths("haha", "output", None))
    assert len(input_output) == 1, "get_input_output_paths fails"
    
    input_output = list(get_input_output_paths("test/test.py", "output/", "test"))
    assert len(input_output) == 1, "get_input_output_paths fails"
    
    input_output = list(get_input_output_paths("tester", "output/", "tester"))

# Generated at 2022-06-21 17:14:00.174826
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('app/app.py',
                                    'app/__pycache__/app.cpython-36.pyc',
                                    None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('app/app.py', 'app/app.py', None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('app', 'app', None))

    output_paths = [output for input_, output in
                    get_input_output_paths('app', 'out', None)]
    assert 'out/app.py' in output_paths
    assert 'out/core/core.py' in output_path

# Generated at 2022-06-21 17:14:07.785739
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    # Try invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('dir', 'dir.py', None))

    # Try invalid input/output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('dir', 'another/dir.py', None))

    # Try invalid input/output
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('doesntexist', 'another/dir.py', None))

    # Try invalid input/output
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('doesntexist', 'another/doesntexist.py', None))

    # Test when input is a directory
    result

# Generated at 2022-06-21 17:14:18.138642
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    pairs = list(get_input_output_paths('a/1.py', 'b/1.py', 'a'))
    assert len(pairs) == 1
    assert pairs[0].input_path == Path('a/1.py')
    assert pairs[0].output_path == Path('b/1.py')
    pairs = list(get_input_output_paths('a/1.py', 'b', 'a'))
    assert len(pairs) == 1
    assert pairs[0].input_path == Path('a/1.py')
    assert pairs[0].output_path == Path('b/1.py')
    pairs = list(get_input_output_paths('a', 'b', 'a'))
    assert len(pairs) == 3
    assert pairs[0].input_path

# Generated at 2022-06-21 17:14:28.774112
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    def assert_correct_pairs(test_input: str,
                             test_output: str,
                             root: str,
                             pairs: list) -> None:
        expected_pairs = [
            (Path(Path(test_input), Path(pair[0])),
             Path(Path(test_output), Path(pair[1])))
            for pair in pairs
        ]
        path_pairs = tuple(get_input_output_paths(
            test_input, test_output, root))
        assert path_pairs == expected_pairs

    # test_inputs
    # Single *.py file
    assert_correct_pairs(
        '.', './', '',
        [('./a.py', './a.py')]
    )

# Generated at 2022-06-21 17:14:34.335542
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises

    assert list(get_input_output_paths(
        input_='tests', output='tests-out', root=None)) == [
            InputOutput(Path('tests/test_unit.py'), Path('tests-out/test_unit.py')),
            InputOutput(Path('tests/test_unit2.py'), Path('tests-out/test_unit2.py')),
        ]

    assert list(get_input_output_paths(
        input_='tests/test_unit.py', output='tests-out', root=None)) == [
            InputOutput(Path('tests/test_unit.py'), Path('tests-out/test_unit.py')),
        ]

# Generated at 2022-06-21 17:14:49.482373
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('a.py', 'b.py', None) == [(Path('a.py'), Path('b.py'))]
    assert get_input_output_paths('a/b.py', 'c.py', None) == [(Path('a/b.py'), Path('c.py'))]
    assert get_input_output_paths('a/b.py', 'c', None) == [(Path('a/b.py'), Path('c/b.py'))]
    assert get_input_output_paths('a', 'c.py', 'z') == []
    assert get_input_output_paths('a', 'c.py', 'a/x') == []

# Generated at 2022-06-21 17:15:00.506070
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for invalid input output
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("input.txt", "output.py", "root"))

    # Test for invalid input
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("input.py", "output.txt", "root"))

    # Test for valid inputs and outputs and root
    input_output_paths_list = list(get_input_output_paths("input.py", "output.py", "root"))
    assert len(input_output_paths_list) == 1 and input_output_paths_list[0].input == Path("input.py") and input_output_paths_list[0].output == Path("output.py")

    # Test for valid

# Generated at 2022-06-21 17:15:10.280023
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    from .types import InputOutput
    from .exceptions import InvalidInputOutput, InputDoesntExists

    # Input file not provided
    with pytest.raises(InputDoesntExists):
        get_input_output_paths("", "", None)

    # Input file is not a python file
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("test.py", "test.xml", None)

    # Input file is a python file but output file is not a python file
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths("test.py", "test.xml", None)

    # Input file is a python file and output file is also a python file
    io = get_input_output_paths("test.py", "test.py", None)

# Generated at 2022-06-21 17:15:20.195662
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    import pytest
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths("a.txt", "b.py", "c"))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths("a.txt", "b.txt", "c"))
    assert list(get_input_output_paths("a.py", "b.py", "c")) == [InputOutput(Path("a.py"), Path("b.py"))]
    assert list(get_input_output_paths("a.txt", "b/c.py")) == [InputOutput(Path("a.txt/c.py"), Path("b/c.py"))]

# Generated at 2022-06-21 17:15:30.263707
# Unit test for function get_input_output_paths
def test_get_input_output_paths():

    input_path = './tests/input'
    output_path = './tests/output'
    yield_output = list(get_input_output_paths(input_path, output_path, None))
    assert len(yield_output) == 4
    assert str(yield_output[0].input) == './tests/input/file2.py'
    assert str(yield_output[0].output) == './tests/output/file2.py'
    assert str(yield_output[2].input) == './tests/input/subdir/file3.py'
    assert str(yield_output[2].output) == './tests/output/subdir/file3.py'

    root_path = './tests/input/subdir'

# Generated at 2022-06-21 17:15:40.884664
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .paths import get_input_output_paths
    from pathlib import Path
    import pytest
    def normalize_path(path):
        return str(Path(path).resolve().relative_to(Path.cwd()))
    def test_path_pair(input_, output, expected_inputs, expected_outputs):
        expected_inputs = [normalize_path(input_) for input_ in expected_inputs]
        expected_outputs = [normalize_path(output) for output in expected_outputs]
        actual_inputs = []
        actual_outputs = []
        for input_, output in get_input_output_paths(input_, output, None):
            actual_inputs.append(normalize_path(input_))

# Generated at 2022-06-21 17:15:47.605928
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib import Path
    from .exceptions import InputDoesntExists, InvalidInputOutput
    
    import pytest

    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('a.py', 'b.js', None)
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('x.py', '.', None)
    assert get_input_output_paths('input', 'output', None)[0] == (Path('input'), Path('output'))
    assert get_input_output_paths('input', 'output', 'input')[0] == (Path('input'), Path('output'))

# Generated at 2022-06-21 17:16:01.092445
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test when neither input nor output is file
    input_ = '/input'
    output = '/output'
    root = None
    paths = list(get_input_output_paths(input_, output, root))
    assert len(paths) == 2
    assert paths[0].input_.as_posix() == '/input/script.py'
    assert paths[0].output.as_posix() == '/output/script.py'
    assert paths[1].input_.as_posix() == '/input/test/test.py'
    assert paths[1].output.as_posix() == '/output/test/test.py'

    # Test when output is file
    input_ = '/input'
    output = '/output/output.py'
    root = None

# Generated at 2022-06-21 17:16:12.810466
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
        # try a relative input and output
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test/test_input.py', 'test/test_output/', 'test'))
    # input is a file, output is a file
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('./test/test_input.py', './test/test_output.py', 'test'))
    # input is a file, output is a dir
    actual = list(get_input_output_paths('./test/test_input.py', './test/test_output/', 'test'))

# Generated at 2022-06-21 17:16:23.522437
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pytest import raises
    from .types import InputOutput

    # input not exists
    with raises(InputDoesntExists):
        next(get_input_output_paths(
            'tests/test_input', 'tests/test_output', 'tests'))

    # input is dir

# Generated at 2022-06-21 17:16:34.976827
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths()."""

    def get_input_output_paths_testcase(
            input: str, output: str, root: Optional[str] = None):
        list(get_input_output_paths(input, output, root))

    assert_raises(InvalidInputOutput, get_input_output_paths_testcase,
                  'foo/bar.py', 'foo/bar.py')

    assert_raises(InputDoesntExists, get_input_output_paths_testcase,
                  'foo/bar.py', '/baz/foo/bar.py')

    test_input = 'foo/bar.py'
    test_output = '/baz/foo/bar.py'


# Generated at 2022-06-21 17:16:43.501551
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('python', 'python', None)) == []

    assert list(get_input_output_paths(
        'python/x.py', 'python', None)) == [
            InputOutput('python/x.py', 'python/x.py')
    ]

    assert list(get_input_output_paths(
        'python/x.py', 'java', None)) == [
            InputOutput('python/x.py', 'java/x.py')
    ]

    assert list(get_input_output_paths(
        'python', 'java', None)) == [
            InputOutput('python/x.py', 'java/x.py')
    ]


# Generated at 2022-06-21 17:16:53.486487
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    #test case for if input is a .py file
    input_path = "test/resources/test_in.py"
    output_path = "build"
    input_output_paths = list(get_input_output_paths(input_path, output_path, None))
    assert (len(input_output_paths) == 1)
    assert (input_output_paths[0].input == Path(input_path))
    assert (input_output_paths[0].output == Path(output_path + "/" + "test_in.py"))

    # test case for if input is a folder
    input_path = "test/resources/"
    output_path = "build/"
    input_output_paths = list(get_input_output_paths(input_path, output_path, None))
   

# Generated at 2022-06-21 17:17:02.082172
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    output = get_input_output_paths('tests/fixtures/input',
                                    'tests/fixtures/output',
                                    'tests/fixtures/input')
    for (input_, output_) in output:
        assert str(input_).startswith('tests/fixtures/input')
        assert str(output_).startswith('tests/fixtures/output')
        relative = input_.relative_to('tests/fixtures/input')
        assert str(output_) == str(Path('tests/fixtures/output')).joinpath(relative)

# Generated at 2022-06-21 17:17:05.908664
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Get input/output paths pairs."""
    result = get_input_output_paths(input_='.', output='.', root=None)
    #print(result)

if __name__ == "__main__":
    test_get_input_output_paths()

# Generated at 2022-06-21 17:17:13.906088
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test that get_input_output_paths works as expected."""
    assert list(get_input_output_paths(Path(__file__),
                                       Path(__file__).parent.joinpath(
                                           "output.txt"))) == [
                                               InputOutput(Path(__file__),
                                                           Path(__file__).parent.joinpath(
                                                           "output.txt"))]
    assert list(get_input_output_paths(Path(__file__).parent.as_posix(),
                                       Path(__file__).parent.as_posix())) == []


# Generated at 2022-06-21 17:17:20.948755
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # test valid input
    input_ = get_input_output_paths('input/', 'output/', 'input/')
    assert input_.__next__().input_path == Path('input/foo.py')
    assert input_.__next__().output_path == Path('output/foo.py')
    assert input_.__next__().input_path == Path('input/bar/baz.py')
    assert input_.__next__().output_path == Path('output/bar/baz.py')
    # test invalid input
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input/', 'output', 'input/')
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('input/', 'output.py', 'input/')

# Generated at 2022-06-21 17:17:31.207235
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test function `get_input_output_paths`."""
    # input is a file and output is a directory
    # root is None
    assert list(get_input_output_paths(
        'input/foo.py', 'output/', None)) == [
            InputOutput(Path('input/foo.py'), Path('output/foo.py'))]
    # root is not None
    assert list(get_input_output_paths(
        'input/foo.py', 'output/', 'root/')) == [
            InputOutput(Path('input/foo.py'), Path('output/foo.py'))]
    # input is a directory and output is a directory

# Generated at 2022-06-21 17:17:42.351007
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Unit test for function get_input_output_paths."""

    # Input/output paths pairs with input as files, output as folder
    assert list(get_input_output_paths('input.py', 'output', None)) == \
        [InputOutput(Path('input.py'), Path('output').joinpath('input.py'))]

    # Input/output paths pairs with input as file, output as file
    assert list(get_input_output_paths('input.py', 'output.py', None)) == \
        [InputOutput(Path('input.py'), Path('output.py'))]

    # Input/output paths pairs with input as folder, output as folder

# Generated at 2022-06-21 17:17:54.474955
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test for a file
    io_paths = list(get_input_output_paths(input_='my_example.py', output='my_example_output.py', root=None))
    assert len(io_paths) == 1
    assert io_paths[0].input_path == Path('my_example.py')
    assert io_paths[0].output_path == Path('my_example_output.py')
    # Test for an entire folder
    io_paths = list(get_input_output_paths(input_='folder', output='folder_output', root=None))
    assert len(io_paths) == 1
    assert io_paths[0].input_path == Path('folder')
    assert io_paths[0].output_path == Path('folder_output')
    #

# Generated at 2022-06-21 17:18:01.966833
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    result = list(get_input_output_paths('foo.py', 'bar.py', 'root'))
    assert [InputOutput(Path('foo.py'), Path('bar.py'))] == result



# Generated at 2022-06-21 17:18:06.175269
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('input', 'output', 'root')
    assert get_input_output_paths('input.py', 'output.py', 'root')

# Generated at 2022-06-21 17:18:16.066672
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert [
        InputOutput(Path('1.py'), Path('2.py'))
    ] == list(get_input_output_paths('1.py', '2.py', None))
    assert [
        InputOutput(Path('1.py'), Path('2.py')),
        InputOutput(Path('1.py'), Path('3.py')),
        InputOutput(Path('1.py'), Path('4.py')),
        InputOutput(Path('1.py'), Path('5.py')),
    ] == list(get_input_output_paths('1.py', '2.py:3.py:4.py:5.py', None))

# Generated at 2022-06-21 17:18:25.869745
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test get_input_output_paths."""
    # input: single file, output: single file
    input_ = 'test_inputs/foo.py'
    output = 'test_outputs/foo.py'
    assert list(get_input_output_paths(input_, output, None)) == [
        InputOutput(Path(input_), Path(output))
    ]

    # input: single file, output: folder
    input_ = 'test_inputs/foo.py'
    output = 'test_outputs'
    assert list(get_input_output_paths(input_, output, None)) == [
        InputOutput(Path(input_), Path(output).joinpath('foo.py'))
    ]

    # input: single file, output: folder (with --root)

# Generated at 2022-06-21 17:18:29.878127
# Unit test for function get_input_output_paths

# Generated at 2022-06-21 17:18:40.484819
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test for get_input_output_paths"""
    from .exceptions import InvalidInputOutput, InputDoesntExists
    from .types import InputOutput

    # Test with a valid input and output
    input_ = "test"
    output = "output"
    root = "test"
    test_result = get_input_output_paths(input_, output, root)
    expected_result = [InputOutput(Path("test"), Path("output"))]
    assert test_result == expected_result

    # Test with a valid input and non-valid output
    input_ = "test"
    output = "output.py"
    root = "test"
    try:
        get_input_output_paths(input_, output, root)
    except InvalidInputOutput:
        pass
    else:
        assert False

   

# Generated at 2022-06-21 17:18:51.185253
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths('./foo.py', './', None)) == [InputOutput(Path('./foo.py'), Path('./foo.py'))]
    assert list(get_input_output_paths('./foo.py', './', '.')) == [InputOutput(Path('./foo.py'), Path('./foo.py'))]
    assert list(get_input_output_paths('./bar/foo.py', './', './bar')) == [InputOutput(Path('./bar/foo.py'), Path('./foo.py'))]

# Generated at 2022-06-21 17:19:01.224019
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    Test get_input_output_paths function.
    """
    # Test if file is correct.
    input_ = './tests/fixtures/foo.py'
    output = './tests/fixtures/foo.py'

    result = get_input_output_paths(input_, output, None)

    assert list(result) == [InputOutput(Path('./tests/fixtures/foo.py'),
                                        Path('./tests/fixtures/foo.py'))]

    # Test if file is not correct.
    input_ = './tests/fixtures/foo.py'
    output = './tests/fixtures/foo.txt'

    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(input_, output, None))

    # Test

# Generated at 2022-06-21 17:19:11.077807
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    io_paths = list(get_input_output_paths('in/dir', 'out/dir/', None))
    assert len(io_paths) == 2
    assert io_paths[0].input_path == Path('in/dir/__init__.py')
    assert io_paths[0].output_path == Path('out/dir/__init__.py')
    assert io_paths[1].input_path == Path('in/dir/module.py')
    assert io_paths[1].output_path == Path('out/dir/module.py')



# Generated at 2022-06-21 17:19:22.399845
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(input_='a/b.py',
                                       output='c',
                                       root=None)) == [InputOutput(Path('a/b.py'), Path('c/b.py'))]
    assert list(get_input_output_paths(input_='a/b/c.py',
                                       output='d',
                                       root='a')) == [InputOutput(Path('a/b/c.py'), Path('d/b/c.py'))]
    assert list(get_input_output_paths(input_='a',
                                       output='b',
                                       root=None)) == [InputOutput(Path('a/x.py'), Path('b/x.py'))]

# Generated at 2022-06-21 17:19:37.005229
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Invalid input
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths(
            input_='in/file.py', output='out/file.py', root=None))
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths(
            input_='in/file.py', output='out', root=None))
    
    # Valid input and output
    assert list(get_input_output_paths(
        input_='in/file.py', output='out', root=None)) == [InputOutput(Path('in/file.py'), Path('out/file.py'))]
    assert list(get_input_output_paths(
        input_='in/file.py', output='out', root='in'))

# Generated at 2022-06-21 17:19:48.342812
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert (list(get_input_output_paths('test/conftest.py', 'test/conftest.py', None))) == \
        [(Path('test/conftest.py'), Path('test/conftest.py'))]
    assert (list(get_input_output_paths('test/conftest.py', 'test', None))) == \
        [(Path('test/conftest.py'), Path('test/conftest.py'))]
    assert (list(get_input_output_paths('test', 'test', None))) == \
        [(Path('test/conftest.py'), Path('test/conftest.py'))]

# Generated at 2022-06-21 17:19:56.839390
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test valid input case
    expected = [InputOutput(Path('foo.py'), Path('output.txt'))]
    assert (list(get_input_output_paths('foo.py', 'output.txt', None)) == expected)

    # Test invalid input case
    with pytest.raises(InvalidInputOutput):
        get_input_output_paths('foo.py', 'output', None)

    # Test invalid input case
    with pytest.raises(InputDoesntExists):
        get_input_output_paths('notfound.py', 'output.txt', None)

    # Test valid input case
    expected = [
        InputOutput(Path('foo.py'), Path('output.txt').joinpath('foo.py'))
    ]

# Generated at 2022-06-21 17:20:00.483704
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    input_ = '/tmp/foo/bar'
    output = '/tmp/baz'
    root = '/tmp/foo/'
    actual = list(get_input_output_paths(input_, output, root))
    expected = [InputOutput(Path('/tmp/foo/bar'), Path('/tmp/baz/bar'))]
    assert actual == expected

# Generated at 2022-06-21 17:20:11.327982
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Test the function get_input_output_paths"""
    assert list(get_input_output_paths('a/a.py', 'b/b.py', 'a')) == \
           [InputOutput(Path('a/a.py'), Path('b/b.py'))], \
           'File to file failed'
    assert list(get_input_output_paths('a/a.py', 'b', 'a')) == \
           [InputOutput(Path('a/a.py'), Path('b/a.py'))], \
           'File to directory, root=a failed'

# Generated at 2022-06-21 17:20:18.909969
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from .dirs import get_dirs
    from .python import is_py_file
    from .exceptions import InputDoesntExists, InvalidInputOutput
    from .types import InputOutput

    def _test_get_input_output_paths(input_: str, output: str, root: Optional[str]) -> Iterable[InputOutput]:
        return list(get_input_output_paths(input_, output, root))


# Generated at 2022-06-21 17:20:30.291813
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # 2 files in a root directory
    input_ = 'path/to/input'
    output = 'path/to/output'
    pair = [InputOutput(Path(input_).joinpath('file1.py'),
                        Path(output).joinpath('file1.py')),
            InputOutput(Path(input_).joinpath('file2.py'),
                        Path(output).joinpath('file2.py'))]

    assert list(get_input_output_paths(input_, output, 'path/to/input')) == pair 

    # 2 files in a sub directory
    input_ = 'path/to/input'
    output = 'path/to/output'

# Generated at 2022-06-21 17:20:41.019005
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test all the cases where an error is raised,
    # and test the paths created correctly
    input_ = './tests/input/'
    output = './tests/output/'

    try:
        for i in get_input_output_paths(input_, output, None):
            print(i)
    except InputDoesntExists:
        assert False
    except InvalidInputOutput:
        assert False

    input_ = './tests/input/fake.txt'
    output = './tests/output/'

    try:
        for i in get_input_output_paths(input_, output, None):
            print(i)
    except InputDoesntExists:
        assert False
    except InvalidInputOutput:
        assert False

    input_ = './tests/input/fake.txt'

# Generated at 2022-06-21 17:20:54.094652
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths("Rummy", "Rummy.py", "Rummy")) == [
        InputOutput(Path("Rummy.py"), Path("Rummy.py"))
    ]

    assert list(get_input_output_paths("Rummy", "Rummy", "Rummy")) == [
        InputOutput(Path("Rummy.py"), Path("Rummy/Rummy.py"))
    ]

    assert list(get_input_output_paths("Rummy", "Rummy", "Rummy")) == [
        InputOutput(Path("Rummy.py"), Path("Rummy/Rummy.py"))
    ]


# Generated at 2022-06-21 17:20:58.826093
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Construction of test data
    from_string = "bla/blabla/file.py"
    to_string = "ddd/file.py"
    root = "bla/"
    expected_result = [InputOutput(Path("bla/blabla/file.py"), Path("ddd/file.py"))]
    # Start test
    result = list(get_input_output_paths(from_string, to_string, root))
    assert result == result



# Generated at 2022-06-21 17:21:14.482138
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """
    
    """
    # Scenario 1: input is a file and output is a file
    ios = get_input_output_paths('a.py', 'b.py', None)
    assert list(ios) == [InputOutput(Path('a.py'), Path('b.py'))]

    # Scenario 2: input is a file and output is a directory
    ios = get_input_output_paths('a/a.py', 'b/', None)
    assert list(ios) == [InputOutput(Path('a/a.py'), Path('b/a.py'))]

    # Scenario 3: input is a directory and output is a file
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('a/', 'b.py', None))



# Generated at 2022-06-21 17:21:23.577234
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    print(get_input_output_paths('tests/fixtures/input', 'tests/fixtures/output'))
    print(get_input_output_paths('tests/fixtures/input', 'tests/fixtures/output/a.py'))
    print(get_input_output_paths('tests/fixtures/input/b.py', 'tests/fixtures/output/a.py'))
    print(get_input_output_paths('tests/fixtures/input/b.py', 'tests/fixtures/output'))

# Generated at 2022-06-21 17:21:31.493030
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert list(get_input_output_paths(
        input_='input/',
        output='output/',
        root=None,
    )) == [
        InputOutput(Path('input/a.py'), Path('output/a.py')),
        InputOutput(Path('input/b.py'), Path('output/b.py')),
    ]

    assert list(get_input_output_paths(
        input_='input/a.py',
        output='output/',
        root=None,
    )) == [
        InputOutput(Path('input/a.py'), Path('output/a.py')),
    ]


# Generated at 2022-06-21 17:21:38.442811
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    assert get_input_output_paths('foo/bar/baz.py', 'a', '/foo')[0] == \
        InputOutput(Path('foo/bar/baz.py'), Path('a/bar/baz.py'))
    assert get_input_output_paths('foo/bar/baz.py', 'a/baz.py', None)[0] == \
        InputOutput(Path('foo/bar/baz.py'), Path('a/baz.py'))
    assert get_input_output_paths('foo/bar', 'a', '/foo')[0] == \
        InputOutput(Path('foo/bar/baz.py'), Path('a/bar/baz.py'))

# Generated at 2022-06-21 17:21:48.859233
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('test.py', 'output', '.'))
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('test', 'output.py', '.'))

    # get_input_output_paths(input_: str, output: str, root: Optional[str])
    # Input: file, file, None
    assert list(get_input_output_paths('tests/foo.py', 'output.py', None)) == [InputOutput(Path('tests/foo.py'), Path('output.py'))]
    # Input: file, folder, None

# Generated at 2022-06-21 17:21:55.312733
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    path_input = Path(input_)
    path_output = Path(output)

    # test path_output that's not a file
    path_output.mkdir()
    path_output.joinpath("__init__.py").write_text("")
    path_output.joinpath("colours.py").write_text("")
    path_output.joinpath("test.py").mkdir()
    path_output.joinpath("test.py").joinpath("__init__.py").write_text("")
    path_output.joinpath("test.py").joinpath("test.py").write_text("")

    path_input.joinpath("__init__.py").write_text("")
    path_input.joinpath("colours.py").write_text("")

# Generated at 2022-06-21 17:22:04.646868
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    test_case = [
        ('', '', None),
        ('.', '.', None),
        ('a.py', 'test/test1/b.py', '/test/test1'),
        ('a.py', 'test/test1', '/test/test1'),
        ('a.py', 'b.py', None),
        ('a.py', 'test/test1/b.py', '/test/test1'),
        ('test/test1', 'test/test1', '/test'),
        ('/test/test1', '.', None),
        ('/test/test1', 'test/test1', '/test'),
        ('/test/test1/../test1/./', 'test', None),
    ]

# Generated at 2022-06-21 17:22:15.219087
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    from pathlib2 import Path

# Generated at 2022-06-21 17:22:24.368822
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    with pytest.raises(InvalidInputOutput):
        list(get_input_output_paths('/tmp/input.py', '/tmp/output', None))

    with pytest.raises(InputDoesntExists):
        list(get_input_output_paths('/tmp/btn_input.py', '/tmp/output.py', None))

    assert list(get_input_output_paths('/tmp/input.py', '/tmp/output.py', None)) == \
           [InputOutput(Path('/tmp/input.py'), Path('/tmp/output.py'))]


# Generated at 2022-06-21 17:22:33.242721
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    """Check path finding is working properly."""
    assert list(get_input_output_paths(
        'tests/paths/check_input_output_paths',
        'check_input_output_paths/',
        'tests/paths')) == [InputOutput(
            Path('tests/paths/check_input_output_paths/a.py'),
            Path('check_input_output_paths/a.py'))]


# Generated at 2022-06-21 17:22:50.845811
# Unit test for function get_input_output_paths
def test_get_input_output_paths():
    # Test the case that one input is matched to one output
    input_output = [item for item in get_input_output_paths(
        input_='/a/b/test_input.py',
        output='/a/b/test_output.py',
        root=None)]
    assert input_output == [InputOutput(Path('/a/b/test_input.py'),
                                        Path('/a/b/test_output.py'))]

    # Test the case that a same input is matched to different outputs
    # by using different root paths.