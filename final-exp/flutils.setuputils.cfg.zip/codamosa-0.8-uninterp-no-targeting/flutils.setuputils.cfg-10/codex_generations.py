

# Generated at 2022-06-21 13:06:09.428586
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    out = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=('test',)
    )
    assert out.name == 'test'
    assert out.camel == 'Test'
    assert out.description == 'test'
    assert out.commands == ('test',)

# Generated at 2022-06-21 13:06:13.185990
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))
    assert s.name == 'name'
    assert s.camel == 'Camel'
    assert s.description == 'description'
    assert s.commands == ('a', 'b')



# Generated at 2022-06-21 13:06:23.612097
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from pprint import pformat
    from sys import version_info

    from flutils.objects import copy_func_args

    from .flutils_setup_commands_main import (
        flutils_setup_commands_main
    )

    flutils_setup_commands_main.__globals__['__package__'] = 'flutils'
    flutils_setup_commands_main.__globals__['__name__'] = '__main__'

    with open(join(dirname(__file__), 'setup_commands.cfg'), 'r') as fh:
        expected = fh.read()


# Generated at 2022-06-21 13:06:28.565424
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commands',)
    )
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.description == 'description'
    assert sccc.commands == ('commands',)


# Generated at 2022-06-21 13:06:38.594119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect  # noqa: F401

    def validate(
            expected: List[SetupCfgCommandConfig],
            actual: Generator[SetupCfgCommandConfig, None, None]
    ) -> None:
        out = list(actual)
        assert len(expected) == len(out)
        for exp, act in zip(expected, out):
            print(exp, act)
            assert exp.name == act.name
            assert exp.camel == act.camel
            assert exp.description == act.description
            assert len(exp.commands) == len(act.commands)
            for comm_exp, comm_act in zip(exp.commands, act.commands):
                assert comm_exp == comm_act


# Generated at 2022-06-21 13:06:47.103600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import argparse
    from pathlib import Path

    from flutils.systemutils import comment_lines

    setup_dir = str(Path(__file__).parents[0])
    cmd_parser = argparse.ArgumentParser(
        prog='setup.py',
        description='',
    )
    cmd_parser.add_argument(
        '-f', '--format',
        dest='_format',
        choices=('text', 'markdown'),
        default='text',
        help='Output the README file in the given FORMAT.'
    )
    cmd_parser.add_argument(
        'command',
        nargs=argparse.REMAINDER,
        metavar='COMMAND',
        default='setup.py',
        help='The command and arguments to run.'
    )

# Generated at 2022-06-21 13:06:52.298715
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    x = SetupCfgCommandConfig('name', 'camel', 'description', ('one',))
    assert x.name == 'name'
    assert x.camel == 'camel'
    assert x.description == 'description'
    assert x.commands == ('one',)
    print(x)


# Generated at 2022-06-21 13:06:58.069938
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'resources')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        assert isinstance(config.commands, tuple)
        assert config.commands
        for command in config.commands:
            print(command)
        print()



# Generated at 2022-06-21 13:07:04.536952
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, 'fixtures')
    path = os.path.join(path, 'basic-config')
    path = os.path.join(path, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    count = 0
    format_kwargs = {
        'name': 'simple-test-package',
        'setup_dir': path,
    }
    for _ in _each_setup_cfg_command(parser, format_kwargs):
        count += 1
    assert count == 1



# Generated at 2022-06-21 13:07:16.813611
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    tf = tempfile.TemporaryDirectory()
    tf_path = str(tf.name)
    tf_setup = os.path.join(tf_path, 'setup.py')
    tf_setup_cfg = os.path.join(tf_path, 'setup.cfg')
    tf_setup_commands_cfg = os.path.join(tf_path, 'setup_commands.cfg')
    name = 'my-package'
    with open(tf_setup, 'w') as f:
        f.write("""\
from setuptools import setup
setup()
""")
    with open(tf_setup_cfg, 'w') as f:
        f.write('''[metadata]
name=%s
''' % name)

# Generated at 2022-06-21 13:07:32.356778
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class_object = SetupCfgCommandConfig('a', 'b', 'c', 'd')
    assert class_object.name == 'a'
    assert class_object.camel == 'b'
    assert class_object.description == 'c'
    assert class_object.commands == 'd'


# Generated at 2022-06-21 13:07:41.690013
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('a', 'b', 'c', ('d1', 'd2'))
    assert config.name == 'a'
    assert config.camel == 'b'
    assert config.description == 'c'
    assert config.commands == ('d1', 'd2')
    with pytest.raises(TypeError):
        SetupCfgCommandConfig()  # type: ignore
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('a', 'b', 'c')  # type: ignore


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-21 13:07:47.627099
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        'name', 'CamelName', 'description', ('a', 'b', 'c')
    )
    assert sccc.name == 'name'
    assert sccc.camel == 'CamelName'
    assert sccc.description == 'description'
    assert sccc.commands == ('a', 'b', 'c')

# Generated at 2022-06-21 13:07:54.465063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(setup_dir, 'data', 'setup_dir')

    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) == 2
    sc1, sc2 = configs
    assert sc1.commands == (
        'echo SC1',
        'echo SC2',
    )
    assert sc2.commands == (
        'echo SC1',
        'echo SC2',
        'echo SC3',
    )

    assert len(sc1.name) > 0
    assert len(sc2.name) > 0

    assert len(sc1.camel) > 0
    assert len(sc2.camel) > 0


# Generated at 2022-06-21 13:08:03.676745
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        basename = os.path.basename(fs.filename)
        if basename != 'setup.py':
            # the test isn't run from setup.py
            root_dir = os.path.dirname(fs.filename)
            root_dir = os.path.realpath(root_dir)
            for sub_command in each_sub_command_config(root_dir):
                name = sub_command.name
                print(f'name: "{name}"')
            break


if __name__ == "__main__":
    # test_each_sub_command_config()
    print(list(each_sub_command_config()))

# Generated at 2022-06-21 13:08:06.971829
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        print(cmd.name)
        print(cmd.commands)


# Generated at 2022-06-21 13:08:13.274640
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert setup_cfg_command.name == 'name'
    assert setup_cfg_command.camel == 'Camel'
    assert setup_cfg_command.description == 'description'
    assert setup_cfg_command.commands == ('commands',)

# Generated at 2022-06-21 13:08:23.631998
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            import os
            import os.path
            import tempfile
            import textwrap

            class Config:
                def __init__(self, commands):
                    self.commands = commands

                def __eq__(self, other):
                    return self.commands == other.commands

                def __repr__(self):
                    return repr(self.commands)

            def _write_configs(fp, name, dash_name, commands):
                fp.write(textwrap.dedent(
                    '''
                    [metadata]
                    name = %s

                    [setup.command.%s]
                    command =
                    %s
                    ''' % (name, name, '\n'.join(commands))
                ))



# Generated at 2022-06-21 13:08:28.001185
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',)
    )
    SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',)
    )
    assert result == SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',)
    )


# Generated at 2022-06-21 13:08:29.752910
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(name='', camel='', description='', commands=())



# Generated at 2022-06-21 13:09:05.951531
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config1 = SetupCfgCommandConfig('name1', 'camel1', 'desc1', ('command1a', 'command1b'))
    config2 = SetupCfgCommandConfig(
        'name2', 'camel2', 'desc2', ('command2a', 'command2b'))
    assert config1.name == 'name1'
    assert config1.camel == 'camel1'
    assert config1.description == 'desc1'
    assert config1.commands == ('command1a', 'command1b')
    assert config2.name != 'name1'
    assert config2.camel != 'camel1'
    assert config2.description != 'desc1'
    assert config2.commands != ('command1a', 'command1b')
    assert config2.name == 'name2'

# Generated at 2022-06-21 13:09:14.558596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.systemutils import rm
    from flutils.pathutils import parent_dir
    from flutils.strutils import dedent2

    base_dir = os.path.join(
        parent_dir(os.path.dirname(__file__)), 'test', 'fixtures'
    )
    setup_cfg = os.path.join(base_dir, 'setup.cfg')
    print('\nSETUP_CFG: %s\n' % setup_cfg)

# Generated at 2022-06-21 13:09:17.258586
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'description', ('commands'))


# Generated at 2022-06-21 13:09:21.105600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import join
    from sys import stderr

    for config in each_sub_command_config('setup.cfg'):
        print(config, file=stderr)



# Generated at 2022-06-21 13:09:24.966665
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name1',
        'camel1',
        'description1',
        ('cmd1', 'cmd2')
    )
    assert config.name == 'name1'
    assert config.camel == 'camel1'
    assert config.description == 'description1'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:09:34.387589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    unit_test_setup_dir = os.path.realpath(os.path.join('.', 'tests', 'unit'))
    unit_test_setup_cfg_path = os.path.join(unit_test_setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(unit_test_setup_cfg_path)
    name = _get_name(parser, unit_test_setup_cfg_path)
    format_kwargs = dict(name=name,
                         setup_dir=unit_test_setup_dir,
                         home=os.path.expanduser('~'))
    unit_test_setup_cfg_command_path = os.path.join(
        unit_test_setup_dir, 'setup_commands.cfg'
    )
    parser = ConfigParser()
    parser

# Generated at 2022-06-21 13:09:35.942483
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd1', 'cmd2'))



# Generated at 2022-06-21 13:09:48.293542
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Valid, empty
    sc = SetupCfgCommandConfig('', '', '', ())

    # Valid, full
    sc = SetupCfgCommandConfig('name', 'Name', 'description', ('command',))

    # Invalid, empty `name`
    try:
        sc = SetupCfgCommandConfig('', 'Name', 'description', ('command',))
        assert False, "Should have raised a `ValueError` exception."
    except ValueError:
        pass

    # Invalid, empty `camel`
    try:
        sc = SetupCfgCommandConfig('name', '', 'description', ('command',))
        assert False, "Should have raised a `ValueError` exception."
    except ValueError:
        pass

    # Invalid, empty `description`

# Generated at 2022-06-21 13:09:53.172797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function :func:`each_sub_command_config`."""
    from flutils.pathutils import each_line
    from flutils.reutils import each_re_match
    from flutils.textutils import indent
    setup_dir = os.path.expanduser('~/dev/flutils')
    items = tuple(each_sub_command_config(setup_dir))
    print('items:')
    print(indent(((x.name, x.commands) for x in items), 2))

    def _strip_comments(lines: str) -> str:
        return '\n'.join(
            line
            for line in lines.splitlines()
            if line
            and not line.strip().startswith('#')
        )


# Generated at 2022-06-21 13:10:04.492419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import create_temp_directory
    with create_temp_directory() as temp_dir:
        setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name =flutils\n'
            )
        with open(os.path.join(temp_dir, 'setup.py'), 'w') as f:
            f.write('')
        assert tuple(each_sub_command_config(temp_dir)) == ()
        with open(setup_cfg_path, 'a') as f:
            f.write('')

# Generated at 2022-06-21 13:11:09.243034
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    # constructor
    config = SetupCfgCommandConfig(
        "name",
        "camel",
        "description",
        (
            "command1",
            "command2"
        )
    )
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ("command1", "command2")

    # string
    msg = "SetupCfgCommandConfig(name='name', camel='camel', " \
          "description='description', commands=('command1', " \
          "'command2'))"
    assert str(config) == msg

    # repr

# Generated at 2022-06-21 13:11:11.096279
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('cmd1', 'cmd2')
    )

# Generated at 2022-06-21 13:11:19.531572
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        "my_commands.my_command",
        "MyCommand",
        "Command description",
        ("python setup.py my_command",)
    )
    assert setup_cfg_command_config.name == "my_commands.my_command"
    assert setup_cfg_command_config.camel == "MyCommand"
    assert setup_cfg_command_config.description == "Command description"
    assert setup_cfg_command_config.commands == ("python setup.py my_command",)



# Generated at 2022-06-21 13:11:29.609781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import itertools

    def _run(func):
        for _ in each_sub_command_config():
            break
        else:
            return func()


# Generated at 2022-06-21 13:11:32.510465
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('cmd_name', 'CmdName', 'cmd description', ('a', 'b', 'c'))



# Generated at 2022-06-21 13:11:40.641547
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=protected-access
    scfgcc = SetupCfgCommandConfig('name', 'camel', 'description', ('commands', ))
    assert scfgcc._fields == ('name', 'camel', 'description', 'commands')
    assert scfgcc.name == 'name'
    assert scfgcc.camel == 'camel'
    assert scfgcc.description == 'description'
    assert scfgcc.commands == ('commands', )
    assert len(scfgcc) == 4


# Generated at 2022-06-21 13:11:47.821920
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.pathutils import atomic_write

    with TemporaryDirectory() as setup_dir:
        setup_dir = Path(setup_dir)
        setup_dir.joinpath('setup.py').touch()
        setup_dir.joinpath('setup.cfg').touch()
        setup_dir.joinpath('setup_commands.cfg').touch()
        format_kwargs = {
            'setup_dir': setup_dir,
            'name': 'project'
        }
        parser = ConfigParser()
        parser.read(setup_dir.joinpath('setup_commands.cfg'))
        gen = _each_setup_cfg_command(parser, format_kwargs)
        config: SetupCfgCommandConfig = next(gen)
        assert config.name == ''
       

# Generated at 2022-06-21 13:11:54.909329
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        name='a',
        camel='B',
        description='ccc',
        commands=('1', '2', '3',),
    )
    assert result.name == 'a'
    assert result.camel == 'B'
    assert result.description == 'ccc'
    assert result.commands == ('1', '2', '3',)

# Generated at 2022-06-21 13:12:02.428924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pytest
    cfg = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'setup_commands.example.cfg'
    )
    os.environ['FLUTILS_SETUP_COMMANDS_CFG_FILE'] = cfg
    for config in each_sub_command_config(os.path.dirname(os.path.dirname(__file__))):
        print(config)
        pytest.assume(isinstance(config, SetupCfgCommandConfig))
        pytest.assume(config.name)

# Generated at 2022-06-21 13:12:08.645589
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    config = SetupCfgCommandConfig(
        name = 'name1',
        camel = 'camel1',
        description = 'description1',
        commands = '1,2,3',
    )

    assert config.name == 'name1'
    assert config.camel == 'camel1'
    assert config.description == 'description1'
    assert config.commands == ('1', '2', '3')



# Generated at 2022-06-21 13:13:28.503204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each_sub_command_config_tester(
        setup_dir: Union[os.PathLike, str],
        expected: List[Tuple[str, str, str, Tuple[str, ...]]]
    ) -> None:
        out = list(each_sub_command_config(setup_dir))
        assert len(out) == len(expected)
        for actual, (name, camel, description, commands) in zip(
            out, expected
        ):
            assert isinstance(actual, SetupCfgCommandConfig)
            assert actual.name == name
            assert actual.camel == camel
            assert actual.description == description
            assert actual.commands == commands

    # noqa: W291 lines too long

# Generated at 2022-06-21 13:13:37.059502
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _get_setup_cfg_command_configs(setup_dir):
        return list(each_sub_command_config(setup_dir))

    def _test_setup_cfg_command_configs(
            setup_dir: str,
            name: str,
            expected_configs: List[SetupCfgCommandConfig],
    ) -> None:
        configs = _get_setup_cfg_command_configs(setup_dir)
        assert configs == expected_configs
        assert name == _get_name(Parser(), os.path.join(setup_dir, 'setup.cfg'))

    _test_setup_cfg_command_configs(
        './tests/data/setup_cfg_files/no_setup_cmds',
        'flutils-contrib-1',
        []
    )

    _

# Generated at 2022-06-21 13:13:43.443177
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('a', 'b')
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('a', 'b')

# Generated at 2022-06-21 13:13:46.109202
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo', 'Foo', 'description', tuple('asdf')
    ) is not None

# Generated at 2022-06-21 13:13:56.304162
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join, realpath
    from tests import _get_project_root_path
    root = _get_project_root_path()
    root = join(root, 'tutorials', 'setup_py_setup_cfg')
    setup_cfg = join(root, 'setup.cfg')
    assert os.path.isfile(setup_cfg)
    setup_cfg_cmds = join(root, 'setup_commands.cfg')
    assert os.path.isfile(setup_cfg_cmds)
    setup_py = join(root, 'setup.py')
    assert os.path.isfile(setup_py)
    name = None
    for section in ConfigParser().read(setup_cfg):
        if section == 'metadata':
            name = ConfigParser().get(section, 'name')


# Generated at 2022-06-21 13:14:00.543422
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = os.path.abspath(os.path.dirname(__file__))
    for s in each_sub_command_config(setup_dir):
        print(str(s))


if __name__ == '__main__':
    setup_dir = os.path.abspath(os.path.dirname(__file__))
    for s in each_sub_command_config(setup_dir):
        print(str(s))

# Generated at 2022-06-21 13:14:06.183598
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import from_this_file
    from pprint import pprint

    fp = from_this_file(__file__, os.path.pardir, 'setup.cfg')
    commands = tuple(each_sub_command_config(fp))
    print('')
    for command in commands:
        pprint(command)


test_each_sub_command_config()

# Generated at 2022-06-21 13:14:10.163468
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))
    assert c.name == 'name'
    assert c.camel == 'Camel'
    assert c.description == 'description'
    assert c.commands == ('command',)


# Generated at 2022-06-21 13:14:12.272264
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'Test'
    commands = (1, 2, 3)
    assert SetupCfgCommandConfig(name, camel, description, commands)



# Generated at 2022-06-21 13:14:18.409271
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig(name='foo',
                              camel='Foo',
                              description='foo bar',
                              commands=('echo foo', 'echo bar'))
    assert c.name == 'foo'
    assert c.camel == 'Foo'
    assert c.description == 'foo bar'
    assert c.commands == ('echo foo', 'echo bar')