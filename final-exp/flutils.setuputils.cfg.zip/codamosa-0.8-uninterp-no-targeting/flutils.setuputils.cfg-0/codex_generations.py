

# Generated at 2022-06-21 13:06:08.009475
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    create_cfg = SetupCfgCommandConfig
    # test command name
    cmd_name = 'cmd'
    camel = underscor

# Generated at 2022-06-21 13:06:15.085370
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '..', 'example')
    path = os.path.join(path, 'example_package_name')
    configs = list(each_sub_command_config(path))

    assert len(configs) == 2
    assert configs[0].name == 'example_package_name.sub.subsub.subsubsub'
    assert configs[0].camel == (
        'ExamplePackageNameSubSubsubSubsubsub'
    )
    assert configs[0].description == (
        'The first example sub-command with a longer description.'
    )
    assert configs[0].commands == (
        "echo 'example sub-command'",
        "echo 'example sub-command 2'",
    )


# Generated at 2022-06-21 13:06:26.335232
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data'
    )
    out = list(each_sub_command_config(setup_dir))
    assert len(out) == 3
    for entry in out:
        assert isinstance(entry, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:06:36.185997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_package')
    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) == 3
    assert configs[0].name == 'test'
    assert configs[0].camel == 'Test'
    assert configs[0].description == (
        "This is a test command from the setup.cfg file."
    )
    assert configs[0].commands == (
        "echo 'TEST'",
        "touch '{%s}/test.txt'" % configs[0].camel,
        "rm -f '{%s}/test.txt'" % configs[0].camel,
    )
    assert configs[1].name == 'test.foo'

# Generated at 2022-06-21 13:06:43.669568
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    parser = ConfigParser()

    with TemporaryDirectory(dir='.') as temp_dir:
        project_dir = os.path.join(temp_dir, 'project')
        os.mkdir(project_dir)
        setup_cfg_path = os.path.join(project_dir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(project_dir, 'setup_commands.cfg')

        expected_name = 'project'
        parser['metadata'] = {'name': expected_name}
        with open(setup_cfg_path, mode='wt') as fp:
            parser.write(fp)

        parser.clear()

        with open(setup_commands_cfg_path, mode='wt') as fp:
            parser.write(fp)

        path = os.path.join

# Generated at 2022-06-21 13:06:54.566995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from pathlib import Path
    from pprint import pprint
    from .strutils import get_caller_dir

    # Setup
    this_dir = get_caller_dir(1)
    caller_dir = get_caller_dir(2)
    test_dir = os.path.join(caller_dir, 'setup_cfg_sub_commands')
    if os.path.isdir(test_dir) is False:
        raise NotADirectoryError(
            "The test directory, %r, does NOT exist." % test_dir
        )
    old_dir = os.getcwd()
    os.chdir(test_dir)

    # Gather the commands
    commands = {}

# Generated at 2022-06-21 13:06:58.861464
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert x.name == 'name'
    assert x.camel == 'camel'
    assert x.description == 'description'
    assert x.commands == ('commands',)



# Generated at 2022-06-21 13:07:00.458864
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-21 13:07:12.388858
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            'name', 'camel', 'description', ('command', 'commands')
        )
    except Exception:  # pragma: no cover
        raise
    try:
        SetupCfgCommandConfig(
            'name', 'camel', 'description', ('command', 'commands', 'commands')
        )
    except Exception:  # pragma: no cover
        raise
    try:
        SetupCfgCommandConfig(
            'name', 'camel', 'description', ('command', 'commands', 'commands'),
            'description'
        )
    except Exception:  # pragma: no cover
        raise

# Generated at 2022-06-21 13:07:22.705929
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import itertools

    # Create a temporary file and directory
    tmp_file = tempfile.mkstemp()[1]
    tmp_dir = tempfile.mkdtemp()

    # Setup some default test data
    fh = open(tmp_file, 'w', encoding='utf-8')
    fh.write('[metadata]\n')
    fh.write('name = my_proj\n')
    fh.write('\n')
    fh.write('[setup.command.my_command]\n')
    fh.write('name = A nice command\n')
    fh.write('description = This is my first command\n')
    fh.write('command = echo -e "Hello World!\\nIt is a nice day today!"\n')

# Generated at 2022-06-21 13:07:38.104243
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    >>> SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))
    SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=('a', 'b'))
    """

# Generated at 2022-06-21 13:07:42.087857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-21 13:07:45.242529
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass
    # commandConfig = SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=('commands'))


# Generated at 2022-06-21 13:07:51.319691
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_command_config = SetupCfgCommandConfig(
        "test_name",
        "TestName",
        "A test command",
        ("ls", )
    )

    assert type(test_command_config) == SetupCfgCommandConfig
    assert test_command_config.name == "test_name"
    assert test_command_config.camel == "TestName"
    assert test_command_config.description == "A test command"
    assert test_command_config.commands == ("ls", )

# Generated at 2022-06-21 13:07:57.883876
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command1', 'command2')
    )
    assert scfgcc.name == 'name'
    assert scfgcc.camel == 'camel'
    assert scfgcc.description == 'description'
    assert scfgcc.commands == ('command1', 'command2')

# Generated at 2022-06-21 13:08:05.393596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def tst(
            setup_cfg: str,
            expected: str
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_dir = os.path.realpath(tmp_dir)
            setup_cfg_path = os.path.join(tmp_dir, 'setup.cfg')
            setup_cfg_path = os.path.realpath(setup_cfg_path)
            with open(setup_cfg_path, 'w') as fp:
                fp.write(setup_cfg)
            path = os.path.join(tmp_dir, 'setup_commands.cfg')
            with open(path, 'w') as fp:
                fp.write(expected)
            actual = []

# Generated at 2022-06-21 13:08:09.293987
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print()

    setup_dir = os.path.abspath('test_config')
    for config in each_sub_command_config(setup_dir):
        print(config)



# Generated at 2022-06-21 13:08:16.586014
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='one',
        camel='Two',
        description='Three',
        commands=('Four',)
    )
    assert setup_cfg_command_config.name == 'one'
    assert setup_cfg_command_config.camel == 'Two'
    assert setup_cfg_command_config.description == 'Three'
    assert setup_cfg_command_config.commands == ('Four',)



# Generated at 2022-06-21 13:08:18.272674
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('some', 'command'))


# Generated at 2022-06-21 13:08:26.826067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyPackageRequirements
    import flutils.setuputils

    # Get the dir containing this file.
    setup_dir = os.path.dirname(flutils.setuputils.__file__)

    # From this dir, get the parent dir, for the tests dir.
    setup_dir = os.path.dirname(setup_dir)

    # From this dir, get the parent dir, for the flutils dir.
    setup_dir = os.path.dirname(setup_dir)

    # From this dir, create a path to the dir, tests/data/setup.cfg
    setup_dir = os.path.join(
        setup_dir,
        'tests',
        'data',
        'setup.cfg',
    )

    for command in each_sub_command_config(setup_dir):
        assert isinstance

# Generated at 2022-06-21 13:08:48.503396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config())
    assert configs
    assert isinstance(configs, tuple)
    assert isinstance(configs[0].name, str)
    assert isinstance(configs[0].camel, str)
    assert isinstance(configs[0].description, str)
    assert isinstance(configs[0].commands, tuple)
    assert isinstance(configs[0].commands[0], str)

# Generated at 2022-06-21 13:09:00.526104
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from io import StringIO
    from contextlib import redirect_stdout

    def _each_sub_command_config_test_impl(
            path: Union[os.PathLike, str]
    ) -> Generator[Tuple[Union[os.PathLike, str], str], None, None]:
        for config in each_sub_command_config(path):
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            if not config.name:
                raise ValueError(
                    "The 'name' attribute of the SetupCfgCommandConfig "
                    "class is an empty string."
                )
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)

# Generated at 2022-06-21 13:09:04.793463
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import package_directory
    for config in each_sub_command_config(package_directory()):
        assert isinstance(config, SetupCfgCommandConfig)



# Generated at 2022-06-21 13:09:13.684041
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase

    class EachSubCommandConfigTestCase(TestCase):

        def setUp(self):
            self.super()

            class TestSetupDir(str):
                @property
                def setup_cfg(self):
                    return os.path.join(self, 'setup.cfg')

                @property
                def setup_py(self):
                    return os.path.join(self, 'setup.py')

            self._setup_dir = TestSetupDir(
                '/tmp/__test-each-sub-command-config__'
            )
            os.makedirs(self._setup_dir, exist_ok=True)

            with open(self._setup_dir.setup_py, 'w') as f:
                f.write('from setuptools import setup\n')

# Generated at 2022-06-21 13:09:22.452227
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_command = "test_command"
    test_camel = "TestCommand"
    test_desc = "test_desc"
    test_tuple = ("test_a", "test_b")
    test_obj = SetupCfgCommandConfig(test_command, test_camel, test_desc, test_tuple)
    assert test_obj.name == test_command
    assert test_obj.camel == test_camel
    assert test_obj.description == test_desc
    assert isinstance(test_obj.commands, tuple)
    assert test_obj.commands == test_tuple

# Generated at 2022-06-21 13:09:25.113779
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig('', '', '', ())
    assert isinstance(actual, SetupCfgCommandConfig)
    assert actual.name == ''
    assert actual.camel == ''
    assert actual.description == ''
    assert actual.commands == ()

# Generated at 2022-06-21 13:09:34.499943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import os
    import shutil
    import tempfile
    from functools import partial
    from flutils.sysutils import get_temp_dir

    class TempEnv(NamedTuple):
        """Contains a temporary path and the current working directory.

        Attributes:
            temp_dir (str): The temporary directory path.
            cwd (str): The current working directory.
        """
        temp_dir: str
        cwd: str

    class EachSubCommandConfigTestCase(unittest.TestCase):

        @classmethod
        def setUpClass(cls) -> None:
            cls.temp_dir = get_temp_dir()


# Generated at 2022-06-21 13:09:35.034973
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:09:39.381812
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test initialization
    SetupCfgCommandConfig('name', 'Camel', 'description', ('arg1', 'arg2'))

    # Test __repr__
    SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('arg1', 'arg2')
    ).__repr__()

# Generated at 2022-06-21 13:09:48.243986
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import Mock
    debug = Mock(return_value=None)
    with mock.patch('flutils.utils.setup_utils.debug', new=debug):
        config = SetupCfgCommandConfig('name', 'camel', 'description',
                                       ('command', ))
        assert config.name == 'name'
        assert config.camel == 'camel'
        assert config.description == 'description'
        assert config.commands == ('command', )



# Generated at 2022-06-21 13:10:01.746004
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('cmd_name', 'CmdName', 'description', ())
    assert isinstance(cfg, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:10:04.955578
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo.bar'
    camel = 'FooBar'
    description = 'Unit test for constructor.'
    commands = ('foo', 'bar')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Unit tests for each_sub_command_config

# Generated at 2022-06-21 13:10:08.795774
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    # pylint: disable=unused-variable
    from pathlib import Path

    rslt = list(each_sub_command_config(Path(__file__).parent))
    assert len(rslt) == 0

# Generated at 2022-06-21 13:10:13.696238
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_config = SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b',))
    assert test_config.name == 'name'
    assert test_config.camel == 'Camel'
    assert test_config.description == 'description'
    assert test_config.commands == ('a', 'b')

# Generated at 2022-06-21 13:10:15.398704
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('n', 'C', 'd', ('',))



# Generated at 2022-06-21 13:10:16.828820
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    my_setup_dir = os.path.dirname(__file__)
    cmds = tuple(each_sub_command_config(my_setup_dir))
    assert len(cmds) == 2

# Generated at 2022-06-21 13:10:21.127716
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('dev_test', 'DevTest', 'Used for testing', ())
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)
    assert len(config.commands) == 0


# Generated at 2022-06-21 13:10:27.028584
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig('name', 'camel', 'desc', ('command',))
    assert s.name == 'name'
    assert s.camel == 'Camel'
    assert s.description == 'desc'
    assert s.commands == ('command',)



# Generated at 2022-06-21 13:10:33.506237
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'command.name',
        'CommandName',
        'The Command Description',
        ('hello', 'world')
    )
    assert config.camel == 'CommandName'
    assert config.commands == ('hello', 'world')
    assert config.description == (
        'The Command Description'
    )
    assert config.name == 'command.name'

# Generated at 2022-06-21 13:10:41.396617
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os.path
    import pathlib
    import random
    import stat
    import string
    import sys
    import tempfile
    import unittest

    from flutils.pathutils import tempdir

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_raises_filenotfounderror_if_setup_dir_does_not_exist(self):
            import flutils.cmdutils
            import os

            tempdir_path = os.path.realpath(tempfile.mkdtemp())

            def fn():
                setup_dir = os.path.join(tempdir_path, 'nope')
                flutils.cmdutils.each_sub_command_config(setup_dir)

            self.assertRaises(FileNotFoundError, fn)


# Generated at 2022-06-21 13:10:59.100166
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        '',
        '',
        '',
        tuple()
    )
    assert isinstance(obj, SetupCfgCommandConfig)


if __name__ == '__main__':
    # Unit test:
    test_SetupCfgCommandConfig()
    print('Testing Complete')

# Generated at 2022-06-21 13:11:04.347201
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='abc',
        camel='Abc',
        description='This is a test',
        commands=('command 1', 'command 2')
    )
    assert config.name == 'abc'
    assert config.camel == 'Abc'
    assert config.description == 'This is a test'
    assert config.commands == ('command 1', 'command 2')


# Generated at 2022-06-21 13:11:10.559000
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s3 = SetupCfgCommandConfig('name', 'camelName', 'description', ('c1', 'c2'))

    assert s3.name == 'name'
    assert s3.camel == 'camelName'
    assert s3.description == 'description'
    assert s3.commands == ('c1', 'c2')

# Unit tests for each_sub_command_config

# Generated at 2022-06-21 13:11:14.506984
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'build', 'name', 'description', ()
    ) == SetupCfgCommandConfig(
        name='build', camel='Name', description='description', commands=()
    )

# Generated at 2022-06-21 13:11:21.107219
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test constructor of class SetupCfgCommandConfig
    config = SetupCfgCommandConfig(
        name='foo',
        camel='Bar',
        description='hello world',
        commands=('abc', 'def')
    )
    assert config.name == 'foo'
    assert config.camel == 'Bar'
    assert config.description == 'hello world'
    assert config.commands == ('abc', 'def')


# Generated at 2022-06-21 13:11:23.420545
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test name',
        'test camel',
        'test description',
        ('test command 1', )
    )

# Generated at 2022-06-21 13:11:31.142704
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Setup
    name: str = 'Name'
    camel: str = 'Camel'
    description: str = 'Description'
    commands: Tuple[str, ...] = ('Command', 'Command')

    # Exercise
    setup_cfg_command_config: SetupCfgCommandConfig = SetupCfgCommandConfig(
        name,
        camel,
        description,
        commands
    )

    # Verify
    assert setup_cfg_command_config.name == name
    assert setup_cfg_command_config.camel == camel
    assert setup_cfg_command_config.description == description
    assert setup_cfg_command_config.commands == commands
    # Cleanup - none necessary



# Generated at 2022-06-21 13:11:37.081763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    cwd = os.getcwd()
    path = os.path.dirname(os.path.abspath(__file__))
    os.chdir(path)
    for sub_command in each_sub_command_config():
        print(sub_command)
    os.chdir(cwd)

# Generated at 2022-06-21 13:11:42.006178
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test for constructor happy path
    args = [
        'name',
        'camel',
        'description',
        ('command1', 'command2'),
    ]
    SetupCfgCommandConfig(*args)
    # Test for wrong number of arguments
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(*args[:-1])

# Generated at 2022-06-21 13:11:49.270080
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-21 13:12:20.236305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Pass"""
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-21 13:12:24.799029
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo',
        'Foo',
        'This is foo.',
        ('foo 1', 'foo 2')
    ) == SetupCfgCommandConfig(
        'foo',
        'Foo',
        'This is foo.',
        ('foo 1', 'foo 2')
    )

# Generated at 2022-06-21 13:12:31.592953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config(setup_dir=__file__):
        command_name = command.name.replace('.', '_')
        command_name = command_name.replace('-', '_')
        command_name = underscore_to_camel(command_name, lower_first=False)
        assert command.camel == command_name
        assert command.description


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:12:32.241472
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:12:38.517905
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test 1
    name = "myname"
    camel = "Myname"
    description = "My Description"
    commands = ("command1", "command2")
    scc = SetupCfgCommandConfig(name, camel, description, commands)
    assert(scc.name == name)
    assert(scc.camel == camel)
    assert(scc.description == description)
    assert(scc.commands == commands)


# Generated at 2022-06-21 13:12:41.756256
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'Description', ['a', 'b'])
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'Description'
    assert config.commands == ('a', 'b')

# Generated at 2022-06-21 13:12:46.377684
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'Camel', 'description', ('a', 'b')
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('a', 'b')

# Generated at 2022-06-21 13:12:53.073395
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'foo foo foo foo'
    commands = ('foo', 'bar', 'baz')
    x = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(x, SetupCfgCommandConfig)
    assert x.name == name
    assert x.camel == camel
    assert x.description == description
    assert x.commands == commands

# Generated at 2022-06-21 13:13:02.322224
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == [
        SetupCfgCommandConfig(
            'setup_dir',
            'SetupDir',
            'Path/to/the/setup/dir',
            ('echo $setup_dir',)
        ),
        SetupCfgCommandConfig(
            'home',
            'Home',
            'Path/to/the/home/dir',
            ('echo $home',)
        ),
        SetupCfgCommandConfig(
            'name',
            'Name',
            'Package/library/project/name',
            ('echo $name',)
        ),
    ]

# Generated at 2022-06-21 13:13:10.624994
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(this_dir, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {
        'name': 'flutils'
    }
    for config in _each_setup_cfg_command(parser, format_kwargs):
        print(config)


# Generated at 2022-06-21 13:14:14.995261
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from inspect import (
        getfile,
        currentframe
    )
    from os.path import (
        dirname,
        abspath
    )
    from flutils.system import (
        create_symlink
    )
    from shutil import (
        copyfile
    )
    from tempfile import (
        TemporaryDirectory
    )
    from unittest.mock import (
        patch
    )

    with TemporaryDirectory() as temp_dir:
        temp_dir = str(temp_dir)
        home_dir = os.path.join(temp_dir, 'home')
        os.mkdir(home_dir)
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        home_setup_dir = os.path.join

# Generated at 2022-06-21 13:14:26.819012
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # SetupCfgCommandConfig(name: str, camel: str, description: str, commands: Tuple[str, ...])
    test_vals = [
        ('setup_dir', 'frobenius', 'setup_dir1', ('setup_dir2', 'setup_dir3')),
        ('setup_dir', 'frobenius', 'setup_dir1', ('setup_dir2', 'setup_dir3')),
    ]
    for i in range(0, len(test_vals)-1):
        (a, b, c, d) = test_vals[i]
        if a != "setup_dir":
            raise ValueError
        if b != "frobenius":
            raise ValueError
        if c != "setup_dir1":
            raise ValueError

# Generated at 2022-06-21 13:14:33.610814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import unittest
    import os

    testfile = os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        'tests',
        'files',
    )
    testfile = os.path.abspath(testfile)
    assert os.path.isdir(testfile)

    class TestSetupCfgCommandConfig(unittest.TestCase):
        """Unit test for class SetupCfgCommandConfig."""

        def test_setup_cfg_command_iter(self):
            """Unit test for class Config."""
            for subcmd in each_sub_command_config(testfile):
                self.assertIsInstance(subcmd, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:14:40.504184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert type(config) == SetupCfgCommandConfig
        assert '_' not in config.name
        assert type(config.name) == str
        assert config.camel.isidentifier() == True
        assert type(config.description) == str
        assert type(config.commands) == tuple
        for command in config.commands:
            assert type(command) == str
    return

# Generated at 2022-06-21 13:14:50.431276
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import inspect
    import subprocess
    from tempfile import TemporaryDirectory

    setup_dir = TemporaryDirectory()
    module_path = os.path.dirname(inspect.getfile(sys.modules[__name__]))
    path = os.path.join(module_path, 'setup.cfg')
    # noinspection PyProtectedMember
    args = [sys.executable, 'setup.py', 'build_ext', '--inplace']
    # noinspection PyProtectedMember
    subprocess.check_call(args, cwd=setup_dir.name)
    subprocess.check_call(['cp', path, setup_dir.name])
    # noinspection PyProtectedMember
    subprocess.check_call(args, cwd=setup_dir.name)


# Generated at 2022-06-21 13:14:55.505174
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(
        "Running "
        "'flutils.setuputils.test_each_sub_command_config'...",
        file=sys.stderr,
    )
    print()

    from flutils.setuputils import (
        SetupCfgCommandConfig,
        each_sub_command_config,
    )

    for c in each_sub_command_config():
        print(c, file=sys.stderr)
        assert isinstance(c, SetupCfgCommandConfig)

    print("...done.", file=sys.stderr)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:15:00.599623
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('n1', 'c1', 'd1', ('c1', 'c2'))
    assert c.name == 'n1'
    assert c.camel == 'c1'
    assert c.description == 'd1'
    assert c.commands == ('c1', 'c2')



# Generated at 2022-06-21 13:15:02.743820
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'a', 'B', 'c', ('d', 'e', 'f')
    )

# Generated at 2022-06-21 13:15:10.516187
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import io
    import os
    import re
    import shutil
    import tempfile
    import unittest

    from flutils.files import (
        change_dir,
        save_yaml,
    )

    from flutils.packageutils import (
        each_sub_command_config,
    )
    
    class TestSetupUtils(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.stdout = io.StringIO()
            with change_dir(self.tempdir):
                from flutils.packageutils import (
                    each_sub_command_config,
                )
                configs = list(each_sub_command_config())
                self.assertEqual(len(configs), 1)

# Generated at 2022-06-21 13:15:21.756373
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import argparse
    import pkg_resources

    from flutils.pkgutils import find_dist

    class TestParser(argparse.ArgumentParser):
        """A custom argument parser for flutils.pkgutils.each_sub_command_config
        tests.
        """

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.add_argument('--setup-dir')
