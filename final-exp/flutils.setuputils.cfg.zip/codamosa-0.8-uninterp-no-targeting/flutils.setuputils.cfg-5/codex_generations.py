

# Generated at 2022-06-21 13:06:08.847497
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected = SetupCfgCommandConfig(
        'name', 'Camel', 'description', ('command',)
    )
    actual = SetupCfgCommandConfig(
        'name', 'Camel', 'description', ('command',)
    )
    assert expected == actual

# Generated at 2022-06-21 13:06:15.590913
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Arrange
    class MyConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    # Act
    config = MyConfig('name', 'camel', 'desc', ('a', 'b'))

    # Assert
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'desc'
    assert config.commands == ('a', 'b')

    # Act
    config2 = config._replace(name='new')

    # Assert
    assert config2.name == 'new'
    assert config2.camel == 'camel'
    assert config2.description == 'desc'
    assert config2.commands == ('a', 'b')

    # Act
    config._

# Generated at 2022-06-21 13:06:26.856787
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    test_dir = os.path.join(here, 'testdata')
    for config in each_sub_command_config(test_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)
    test_dir = os.path.join(here, 'testdata2')
    for config in each_sub_command_config(test_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)

# Generated at 2022-06-21 13:06:36.911847
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_dir_upwards
    from os import getcwd

    def _exists(name):
        return any(
            os.path.exists(os.path.join(path, name))
            for path in each_dir_upwards(getcwd())
        )

    if _exists('setup.py') is False \
            or _exists('setup.cfg') is False:
        return

    for config in each_sub_command_config():
        assert str(config.name) == config.name
        assert str(config.camel) == config.camel
        assert str(config.description) == config.description
        assert str(config.commands) == str(config.commands)
    assert str(config) == str(config)

# Generated at 2022-06-21 13:06:43.944025
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from doctest import Example
    from sys import version_info
    from .envutils import get_script
    from .cmdutils import procdir

    cwd = procdir()
    if version_info.major == 2:
        cwd = cwd.decode('utf-8')

    # Test on a project that has a setup_commands.cfg file
    m_setup_dir = patch(
        'flutils.setuputils.unit_test._prep_setup_dir',
        return_value=cwd
    )
    with m_setup_dir as m:
        sc_path = os.path.join(cwd, 'setup_commands.cfg')

# Generated at 2022-06-21 13:06:54.820280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile
    import unittest

    class EachSubCommandConfigTester(unittest.TestCase):

        def test_each_sub_command_config(self):
            fd, fp = tempfile.mkstemp()

# Generated at 2022-06-21 13:06:57.488778
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """This test is designed to be run from the root directory of
    the project.
    """
    from pprint import pprint
    pprint(list(each_sub_command_config()))

# Generated at 2022-06-21 13:07:03.564733
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    out = SetupCfgCommandConfig(
        'name',
        'camel',
        'desc',
        ('cmd1', 'cmd2')
    )
    assert isinstance(out, SetupCfgCommandConfig)
    assert out.name == 'name'
    assert isinstance(out.camel, str)
    assert isinstance(out.description, str)
    assert isinstance(out.commands, tuple)
    assert isinstance(out.commands[0], str)
    assert out.commands[0] == 'cmd1'



# Generated at 2022-06-21 13:07:16.296691
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    counts = {
        'no': 0,
        'yes': 0,
    }
    for config in each_sub_command_config(setup_dir):
        if config.name == 'test.yes.command':
            counts['yes'] = 1
            assert config.commands == ('git foo', 'git bar')
            assert config.camel == 'TestYesCommand'
        elif config.name == 'test.no.command':
            counts['no'] = 1
            assert config.commands == ()
            assert config.camel == 'TestNoCommand'
        else:
            raise RuntimeError(
                "Unexpected config name of '%r'."
                % config.name
            )

# Generated at 2022-06-21 13:07:25.369677
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('', '', '', tuple())
    assert cfg.name == ''
    assert cfg.camel == ''
    assert cfg.description == ''
    assert cfg.commands == tuple()



# Generated at 2022-06-21 13:07:49.768766
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import listdir_in_dir
    from flutils.testutils import UnitCase

    from . import each_sub_command_config

    class TestModule(UnitCase):
        def test_each_sub_command_config(self):
            for path in listdir_in_dir('.', '.cfg'):
                if path.endswith('setup.cfg'):
                    continue
                parser = ConfigParser()
                parser.read(path)
                setup_cfg_path = os.path.join('.', 'setup.cfg')
                name = _get_name(parser, setup_cfg_path)
                format_kwargs = {
                    'setup_dir': '.',
                    'home': os.path.expanduser('~'),
                    'name': name
                }

# Generated at 2022-06-21 13:08:01.654649
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import unittest

    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    data_dir = os.path.realpath(data_dir)


# Generated at 2022-06-21 13:08:06.558743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n\n>>> Testing function each_sub_command_config')
    for config in each_sub_command_config(setup_dir=os.path.realpath('.')):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:17.926211
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=protected-access
    assert SetupCfgCommandConfig._fields == ('name', 'camel', 'description', 'commands')
    command_config = SetupCfgCommandConfig(
        'all.go',
        'AllGo',
        'Does a bunch of things.',
        ('/foo/bar',),
    )
    assert isinstance(command_config.name, str)
    assert isinstance(command_config.camel, str)
    assert isinstance(command_config.description, str)
    assert isinstance(command_config.commands, tuple)
    assert len(command_config.commands) == 1
    assert isinstance(command_config.commands[0], str)
    # pylint: enable=protected-access

# Generated at 2022-06-21 13:08:26.112457
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'myname',
        'myname',
        'My Description',
        ('systemctl stop myname', 'rm /etc/systemd/system/myname.service')
    ) == SetupCfgCommandConfig(
        'myname',
        'myname',
        'My Description',
        ('systemctl stop myname', 'rm /etc/systemd/system/myname.service')
    )

# Generated at 2022-06-21 13:08:29.940746
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="test_command",
        camel="TestCommand",
        description="Test Command",
        commands=("python -m this_package.tests.test_func1", ),
    )


# Unit test of each_sub_command_config

# Generated at 2022-06-21 13:08:40.900306
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import reset
    import tempfile

    tmp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-21 13:08:44.036955
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    expected = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    assert result == expected

# Generated at 2022-06-21 13:08:49.243888
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='Foo bar.',
        commands=('ls', 'pwd'))
    assert cmd.name == 'foo'
    assert cmd.camel == 'Foo'
    assert cmd.description == 'Foo bar.'
    assert cmd.commands == ('ls', 'pwd')


# Generated at 2022-06-21 13:08:53.625735
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    inp = SetupCfgCommandConfig('a', 'b', 'c', ('d1', 'd2'))
    assert inp.name == 'a'
    assert inp.camel == 'b'
    assert inp.description == 'c'
    assert inp.commands == ('d1', 'd2')

# Generated at 2022-06-21 13:09:07.576733
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'command.name',
        'CommandName',
        'A description of the command.',
        ('A command.', 'Another command.')
    )
    assert config.name == 'command.name'
    assert config.camel == 'CommandName'
    assert config.description == 'A description of the command.'
    assert config.commands == ('A command.', 'Another command.')

# Generated at 2022-06-21 13:09:12.090149
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    val = SetupCfgCommandConfig('name', 'camel', 'description', ('aa', 'bb', 'cc'))
    assert val.name == 'name'
    assert val.camel == 'camel'
    assert val.description == 'description'
    assert val.commands == ('aa', 'bb', 'cc')
    assert val is not None
# EOF

# Generated at 2022-06-21 13:09:16.170663
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data',
        'setup_commands.cfg'
    ))
    format_kwargs = {
        'setup_dir': os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test_data'
        ),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, format_kwargs['setup_dir'])

# Generated at 2022-06-21 13:09:19.097797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert isinstance(out, list)
    assert len(out) > 0
    assert isinstance(out[0], SetupCfgCommandConfig)

# Generated at 2022-06-21 13:09:26.048518
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    print('\n*** Test each_sub_command_config')
    setup_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..'
    )
    setup_dir = os.path.abspath(setup_dir)
    for i, config in enumerate(each_sub_command_config(setup_dir)):
        print('%d\t%r' % (i, config))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:09:27.741328
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("test", "Testing", "test", [])


# Generated at 2022-06-21 13:09:36.333226
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.iterutils import filter_not_iter
    from flutils.pathutils import list_files

    from .pathutils_test import (
        TEST_DATA_DIR,
        TEST_DATA_DIR_PATH,
    )

    setup_dirs = list_files(
        TEST_DATA_DIR_PATH,
        include_dirs=True,
        full_path=True,
        filter_func=lambda x: os.path.basename(x) == 'setup.py'
    )
    setup_dirs = filter_not_iter(setup_dirs, lambda x: x == TEST_DATA_DIR_PATH)
    setup_dirs = tuple(setup_dirs)

    assert setup_dirs

    for setup_dir in setup_dirs:
        assert os.path.isdir(setup_dir)

# Generated at 2022-06-21 13:09:37.948364
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    pprint.pprint(list(each_sub_command_config()))

# Generated at 2022-06-21 13:09:45.360246
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'name',
        'Camel',
        'Description',
        ('command1', 'command2')
    )
    assert cfg.name == 'name'
    assert cfg.camel == 'Camel'
    assert cfg.description == 'Description'
    assert cfg.commands == ('command1', 'command2')



# Generated at 2022-06-21 13:09:50.946680
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(name='test_name', camel='test_camel', 
        description='test_description', commands=('tuple', 'tuple1'))
    assert result.name == 'test_name'
    assert result.camel == 'test_camel'
    assert result.description == 'test_description'
    assert result.commands == ('tuple', 'tuple1')

# Generated at 2022-06-21 13:10:13.188794
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase, main
    from os.path import join, dirname
    from tempfile import mkdtemp

    # Create temp directory
    path = mkdtemp()

    # Create setup.py in temp directory
    name = 'testsetup'
    path = join(path, 'setup.py')
    with open(path, 'w') as f:
        f.write(textwrap.dedent(
            """
            """
        ))

    # Create setup.cfg in temp directory
    filepath = join(path, 'setup.cfg')

# Generated at 2022-06-21 13:10:14.896789
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('cmds', ))


# Generated at 2022-06-21 13:10:23.280586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import getcwd

    from flutils.testutils import TempDirTestCase

    from .git_utils import get_repo_root

    def _each(
            top_level_path: str,
            cmd_configs: List[SetupCfgCommandConfig]
    ) -> Generator[None, None, None]:
        os.chdir(top_level_path)
        setup_dir = get_repo_root()
        format_kwargs: Dict[str, str] = {
            'setup_dir': setup_dir,
            'home': os.path.expanduser('~')
        }
        setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
        parser = ConfigParser()
        parser.read(setup_cfg_path)

# Generated at 2022-06-21 13:10:35.609825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Create the test project directory
    tmp_dir = tempfile.mkdtemp()

    # The test config file
    cfg = (
        "[metadata]\n"
        "name = {{name}}\n"
        "\n"
        "[setup.command.my_cmd]\n"
        "name = my_cmd\n"
        "description = Does something cool\n"
        "commands =\n"
        "    echo '{name}'"
    )
    # Write the config file
    cfg_path = os.path.join(tmp_dir, 'setup.cfg')
    with open(cfg_path, 'w') as fh:
        fh.write(cfg)

    # Write the setup file
    setup_py_path = os.path.join(tmp_dir, 'setup.py')

# Generated at 2022-06-21 13:10:47.916692
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import unittest.mock
    from flutils.testutils import UnitTest

    class EachSubCommandConfigTestCase(UnitTest):
        """Test case for the ``each_sub_command_config`` function."""

        @unittest.mock.patch.object(
            __name__, '_prep_setup_dir',
            return_value='/path/to/setup/dir'
        )
        def test_invalid_setup_cfg(
                self, mock_prep_setup_dir: unittest.mock.Mock
        ) -> None:
            """Test the function when the setup.cfg is invalid."""
            mock_parser = unittest.mock.Mock()
            mock_parser.sections.return_value = ['metadata']
            mock_parser.options.side_effect

# Generated at 2022-06-21 13:10:57.521799
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from textwrap import dedent
    parser = ConfigParser()
    parser.read_string(dedent("""
    [metadata]
    name = my_package
    [setup.command.bump_version]
    description = bump the version
    commands = python setup.py bumpversion --allow-dirty -f
    """))
    gen = list(_each_setup_cfg_command(parser, {'name': 'my_package'}))
    assert gen == [SetupCfgCommandConfig(
        'bump_version',
        'BumpVersion',
        'bump the version',
        ('python setup.py bumpversion --allow-dirty -f',)
    )]



# Generated at 2022-06-21 13:11:06.835548
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            dirpath = os.path.dirname(__file__)
            dirpath = os.path.abspath(dirpath)
            dirpath = os.path.normpath(dirpath)
            dirpath = os.path.normcase(dirpath)
            # print(dirpath)

            def _assert(
                    dirpath: str,
                    expected_sub_commands: List[SetupCfgCommandConfig]
            ) -> None:
                # noinspection PyTypeChecker
                sub_commands: List[SetupCfgCommandConfig] = list(
                    each_sub_command_config(dirpath)
                )

# Generated at 2022-06-21 13:11:13.242029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    tmpdir = os.path.realpath(tempfile.mkdtemp())
    try:
        open(os.path.join(tmpdir, 'setup.py'), 'w').close()
        open(os.path.join(tmpdir, 'setup.cfg'), 'w').close()
        open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w').close()

        for each in each_sub_command_config(setup_dir=tmpdir):
            print(each)

    finally:
        from shutil import rmtree
        rmtree(tmpdir)



# Generated at 2022-06-21 13:11:16.739071
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='This is the foo command.',
        commands=('echo foo',)
    )



# Generated at 2022-06-21 13:11:27.300923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    here = os.path.join(here, 'testdata')
    for cfg in each_sub_command_config(here):
        assert cfg.camel == 'Hello'
        assert cfg.description == ''
        commands = (
            'echo "Hello, World!"',
        )
        assert cfg.commands == commands


if __name__ == '__main__':
    import sys
    import doctest

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    import flutils  # pylint: disable=import-error, wrong-import-position

    found_error = False
    for module in (flutils, ):
        result = doctest

# Generated at 2022-06-21 13:11:43.424252
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('command', ))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command', )


# Generated at 2022-06-21 13:11:46.602762
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # pragma: no cover
    import pathlib

    result = list(each_sub_command_config(str(pathlib.Path.cwd())))
    print('\n\n'.join(map(str, result)))


if __name__ == '__main__':  # pragma: no cover
    test_each_sub_command_config()

# Generated at 2022-06-21 13:11:51.235405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config("./"):
        print(config)

# Only run if the script is the main script.
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:11:59.477774
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        raise RuntimeError('test_SetupCfgCommandConfig')
    except RuntimeError:
        _, _, tb = sys.exc_info()
        tb_info = traceback.extract_tb(tb)
        filename, line, func, text = tb_info[-1]
        setup_dir = os.path.dirname(os.path.abspath(filename))

    for scc in each_sub_command_config(setup_dir):
        assert scc.name != ''
        assert scc.camel != ''
        assert scc.description != ''
        assert scc.commands != tuple()

# Generated at 2022-06-21 13:12:02.947400
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    base_dir = os.path.dirname(__file__)
    pprint(
        list(each_sub_command_config(
            setup_dir=os.path.join(base_dir, '..', '..', '..', 'tests')
        ))
    )

# Generated at 2022-06-21 13:12:08.005375
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(
        "name",
        "Camel",
        "description",
        ("command",),
    )
    assert scfgcc.name == "name"
    assert scfgcc.camel == "Camel"
    assert scfgcc.description == "description"
    assert scfgcc.commands == ("command",)
    return

# Generated at 2022-06-21 13:12:17.306354
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.strutils import underscore_to_camel
    from os.path import join, dirname, realpath
    from os import expanduser

    # setup.command.<command>.[option]
    parser = ConfigParser()
    parser.read(join(dirname(__file__), 'setup_commands.cfg'))

    format_kwargs = {
        'setup_dir': realpath(dirname(__file__)),
        'home': expanduser('~')
    }

    name = _get_name(parser, join(dirname(__file__), 'setup.cfg'))
    format_kwargs['name'] = name

    for section in parser.sections():
        section = cast(str, section)
        section = section.strip()
        if section.startswith('setup.command.'):
            command_name

# Generated at 2022-06-21 13:12:27.711735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import logging
    import shutil
    import tempfile
    from collections import namedtuple
    from inspect import signature
    from unittest import TestCase
    from unittest.mock import patch

    handle = logging.getLogger('flutils')
    handle.setLevel(logging.DEBUG)

    def _patch_signature(sig: str, **func_kwargs) -> Generator[None, None, None]:
        _kwargs = dict(signature(each_sub_command_config).parameters)
        for key, value in func_kwargs.items():
            _kwargs[key] = value
        func_name = '{}.{}'.format(each_sub_command_config.__module__,
                                   each_sub_command_config.__name__)

# Generated at 2022-06-21 13:12:30.871122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    for x in each_sub_command_config(path):
        pass

# Generated at 2022-06-21 13:12:38.858633
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    os.chdir(os.path.expanduser('~'))
    setup_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )
    print(setup_dir)
    print('\n')
    c = each_sub_command_config(setup_dir)
    print(c)
    print(next(c))
    print('\n')
    print(next(c))
    print(next(c))


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-21 13:13:21.595897
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd: str = os.getcwd()
    os.chdir(os.path.dirname(__file__))
    try:
        assert len(list(each_sub_command_config())) == 4
        assert len(list(each_sub_command_config(None))) == 4
        assert len(list(each_sub_command_config(''))) == 4
        assert len(list(each_sub_command_config('.'))) == 4
        assert len(
            list(each_sub_command_config(
                os.path.realpath('../../../../setup_cfg_test')
            ))
        ) == 1
    finally:
        os.chdir(cwd)

# Generated at 2022-06-21 13:13:27.471799
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test', 'test_project'
    )
    for config in each_sub_command_config(test_path):
        print("  +%s" % str(config))

# Generated at 2022-06-21 13:13:32.232240
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:13:33.785660
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        config = SetupCfgCommandConfig('test', 'test', 'test', ('test',))
    except Exception:
        raise



# Generated at 2022-06-21 13:13:38.793637
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test(setup_dir: Optional[Union[os.PathLike, str]]):
        for cmd in each_sub_command_config(setup_dir):
            print(cmd)

    test('/Users/fschwiet/workspace/projects/flutils/flutils')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:13:49.882160
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('', '', '', ())
    assert cmd.name == ''
    assert cmd.camel == ''
    assert cmd.description == ''
    assert cmd.commands == ()
    cmd = SetupCfgCommandConfig('install', 'Install', '', ('true',))
    assert cmd.name == 'install'
    assert cmd.camel == 'Install'
    assert cmd.description == ''
    assert cmd.commands == ('true',)
    cmd = SetupCfgCommandConfig('', '', 'Install', ('true',))
    assert cmd.name == ''
    assert cmd.camel == ''
    assert cmd.description == 'Install'
    assert cmd.commands == ('true',)


# Generated at 2022-06-21 13:13:50.474609
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:13:59.435857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import relative_to_file
    from flutils.sysutils import get_python_path
    from os.path import join
    from typing import Any, List, Union
    from unittest import TestCase, skipIf

    from flutils.testutils import (
        DataKey,
        TestData,
        TemplatedTestData,
    )
    from flutils.testutils.assertutils import (
        assert_is_instance,
        assert_in,
        assert_not_in,
        assert_substring,
    )

    skip_val = True
    if get_python_path() is not None:
        skip_val = False


# Generated at 2022-06-21 13:14:06.449477
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.realpath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            '..',
            '..',
            '..',
            '..',
            '..',
            'flutils',
            'tests',
            'bootstrap',
            'flutils'
        )
    )
    print(path)
    for command_config in each_sub_command_config(setup_dir=path):
        print(command_config)

# Generated at 2022-06-21 13:14:11.582921
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_SetupCfgCommandConfig = SetupCfgCommandConfig('name', 'camel', 'description', ('command'))
    assert test_SetupCfgCommandConfig.name == 'name'
    assert test_SetupCfgCommandConfig.camel == 'camel'
    assert test_SetupCfgCommandConfig.description == 'description'
    assert test_SetupCfgCommandConfig.commands == ('command',)


# Generated at 2022-06-21 13:15:18.378750
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'my-command'
    camel = 'MyCommand'
    description = 'A command'
    cmds = ('one', 'two')
    cfg = SetupCfgCommandConfig(name, camel, description, cmds)
    assert cfg.name == name
    assert cfg.camel == camel
    assert cfg.description == description
    assert cfg.commands == cmds



# Generated at 2022-06-21 13:15:23.320056
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        name='asdf',
        camel='asdf',
        description='asdf',
        commands=()
    )
    assert result.name == 'asdf'
    assert result.camel == 'asdf'
    assert result.description == 'asdf'
    assert result.commands == ()



# Generated at 2022-06-21 13:15:31.428848
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected = tuple(
        SetupCfgCommandConfig(
            name, camel, description, commands
        ) for name, camel, description, commands in (
            ('greet', 'Greet', 'Greeting from setup.cfg.', ('echo Greetings', )),
            ('say_your_name', 'SayYourName',
             'Say Your Name from setup.cfg.', ('echo YourName', )),
        )
    )

    def _create_setup_cfg(setup_dir: str) -> str:
        path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-21 13:15:37.154973
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    sccc = SetupCfgCommandConfig(
        "command name", "CommandName", "command description",
        ("pylint",)
    )
    assert str(sccc.name) == "command name"
    assert str(sccc.camel) == "CommandName"
    assert str(sccc.description) == "command description"
    assert sccc.commands == ("pylint", )



# Generated at 2022-06-21 13:15:41.762634
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('a',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('a',)


# Unit tests for each_sub_command_config

# Generated at 2022-06-21 13:15:46.316356
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig("name", "camel", "test_cmd", ("cmd0", "cmd1"))
    assert s.name == "name"
    assert s.camel == "camel"
    assert s.description == "test_cmd"
    assert s.commands == ("cmd0", "cmd1")