

# Generated at 2022-06-21 13:06:14.757673
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        CallAssertion,
        setup_cfg_command_test,
        test_cli_sub_commands,
    )

    with setup_cfg_command_test() as ca:
        assert test_cli_sub_commands(
            ca, each_sub_command_config(),
            'dir'
        )


if __name__ == '__main__':  # pragma: no cover
    from flutils.testutils import (
        CallAssertion,
        setup_cfg_command_test,
        test_cli_sub_commands,
    )

    with setup_cfg_command_test() as ca:
        test_cli_sub_commands(
            ca, each_sub_command_config(),
            'dir'
        )

# Generated at 2022-06-21 13:06:19.988736
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    sccc = SetupCfgCommandConfig('name', 'camel', 'desc', ('commands',))
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.description == 'desc'
    assert sccc.commands == tuple(['commands'])

# Generated at 2022-06-21 13:06:30.982227
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    # Create setup.cfg with a name, setup.command.foo, and setup.command.bar
    setup_cfg_foo_section = (
        '[setup.command.foo]\n'
        'description = The foo command does something.\n'
        'commands = python -m foo\n\n'
    )
    setup_cfg_bar_section = (
        '[setup.command.bar]\n'
        'description = The bar command does something.\n'
        'commands = python -m bar\n\n'
    )

# Generated at 2022-06-21 13:06:40.936759
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import textwrap
    from io import StringIO
    from logging import (
        DEBUG,
        INFO,
        root,
        StreamHandler,
        getLogger,
    )
    from argparse import ArgumentParser
    # noinspection PyPackageRequirements
    from flutils.testutils import (
        chdir_fixture,
        BaseTestCase,
        mk_file_fixture,
    )

    from _setup_modules.generate_entry_points import (
        each_sub_command_config,
    )

    with chdir_fixture(os.path.dirname(os.path.abspath(__file__))):
        root.addHandler(StreamHandler(stream=sys.stdout))
        root.setLevel(DEBUG)
        logger = getLogger(__name__)
        logger

# Generated at 2022-06-21 13:06:49.130040
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'setup.command.foo'
    name = 'foo'
    camel = 'Foo'
    description = 'foo command'
    commands = ('foo', 'foo1', 'foo2')
    setup_cfg_command_config = SetupCfgCommandConfig(
        name,
        camel,
        description,
        commands
    )
    assert setup_cfg_command_config.name == name
    assert setup_cfg_command_config.camel == camel
    assert setup_cfg_command_config.description == description
    assert setup_cfg_command_config.commands == commands



# Generated at 2022-06-21 13:06:54.121928
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pkgutils import get_setup_file

    setup_file = get_setup_file()
    setup_dir = os.path.dirname(setup_file)
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:07:03.200148
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pathlib
    from contextlib import suppress
    from flutils.debugutils import get_logger
    from flutils.pyutils import get_func_name

    logger = get_logger(get_func_name())
    setup_dir = pathlib.Path(__file__).resolve().parent
    logger.info("The setup_dir is: %r", setup_dir)

    log_level = logger.getEffectiveLevel()
    logger.info("The effective log level is: %r", log_level)

    sys.stderr.write("LOG LEVEL: %r\n" % logger.getEffectiveLevel())
    for config in each_sub_command_config(setup_dir):
        logger.info("%r", config)
        sys.stderr.write("%s\n" % repr(config))

# Generated at 2022-06-21 13:07:04.628689
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig()

# Generated at 2022-06-21 13:07:16.860793
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with mock.patch.object(os.path, 'join') as mock_join:
        mock_join.side_effect = [
            '/home/me/repo/setup.py',
            '/home/me/repo/setup.cfg',
            '/home/me/repo/setup_commands.cfg'
        ]
        with mock.patch.object(os.path, 'expanduser') as mock_expanduser:
            mock_expanduser.return_value = '/home/me'
            with mock.patch.object(os.path, 'realpath') as mock_realpath:
                mock_realpath.return_value = '/home/me/repo'

# Generated at 2022-06-21 13:07:19.150856
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('', '', '', ()).name == ''
    assert SetupCfgCommandConfig('', '', '', ()).camel == ''
    assert SetupCfgCommandConfig('', '', '', ()).description == ''
    assert SetupCfgCommandConfig('', '', '', ()).commands == ()
    assert SetupCfgCommandConfig('', '', '', ('', )).commands == ('', )



# Generated at 2022-06-21 13:07:46.874428
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', "Camel", "description", ('cmd1', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:07:50.431372
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('cmd', )
    )
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('cmd', )

# Generated at 2022-06-21 13:07:57.224741
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # noqa: D100,D102
    from pprint import pprint
    from flutils.dotdict import dotdict

    for each in each_sub_command_config():
        pprint(dotdict(each._asdict()))
        print()


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-21 13:08:05.038194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, abspath
    from textwrap import dedent
    from unittest import TestCase

    from flutils.configutils import _empty_config_dict

    _up = dirname(dirname(abspath(__file__)))
    if 'tests' in _up:
        _up = dirname(_up)

    _dir = os.path.join(_up, 'tests', 'data', 'setup_cfg')

    _cfg = _empty_config_dict()


# Generated at 2022-06-21 13:08:15.444642
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = (
        'setup.command.foo',
        'foo',
        'This is the foo command.',
        ('/bin/echo "This is the foo command."',
         'python ./setup.py foo',)
    )

    cmd_cfg = SetupCfgCommandConfig(*command)
    assert cmd_cfg.name == 'foo'
    assert cmd_cfg.camel == 'Foo'
    assert cmd_cfg.description == 'This is the foo command.'
    assert cmd_cfg.commands == ('/bin/echo "This is the foo command."',
                                'python ./setup.py foo')



# Generated at 2022-06-21 13:08:20.116650
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',)
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)

# Generated at 2022-06-21 13:08:25.260859
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test the default values the constructor takes
    assert SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="description",
        commands=(),
    )

    # Test a random use case with all possible values
    assert SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="description",
        commands=("command1", "command2"),
    )


# Generated at 2022-06-21 13:08:33.525095
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config(
        os.path.join(os.path.dirname(__file__), 'setup_cfg')
    ))
    assert out == [
        SetupCfgCommandConfig(
            'create',
            'Create',
            'Creates the database.',
            ('echo "create"', 'echo "create again"')
        ),
        SetupCfgCommandConfig(
            'drop',
            'Drop',
            'Drops the database.',
            ('echo "drop"',)
        )
    ]

# Generated at 2022-06-21 13:08:34.764404
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'CamelName', 'description', ('cmd1',))

# Generated at 2022-06-21 13:08:39.966303
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'clean',
        'Clean',
        'Clean current environment.',
        ('rm -rfv dist', 'rm -rfv *.egg-info')
    ) == SetupCfgCommandConfig(
        'clean',
        'Clean',
        'Clean current environment.',
        ('rm -rfv dist', 'rm -rfv *.egg-info')
    )



# Generated at 2022-06-21 13:09:07.249132
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('foo', 'Foo', '', ('bar', 'baz'))
    assert cfg.name == 'foo'
    assert cfg.camel == 'Foo'
    assert cfg.description == ''
    assert cfg.commands == ('bar', 'baz')

# Generated at 2022-06-21 13:09:15.474507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(">>> test_each_sub_command_config")
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = os.path.realpath(tmp_dir)
        setup_cfg = os.path.join(tmp_dir, 'setup.cfg')
        with open(setup_cfg, 'w') as f:
            f.write(
                ("""
[metadata]
description-file = README.md
name = test-package-name
version = 0.0.0

[options]
packages = find:

[setup.command.test]
commands =
    echo 'test command'
    echo 'test command2'
                """))

        setup_dir = os.path.dirname(setup_cfg)


# Generated at 2022-06-21 13:09:25.484411
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands', ),
    ).name == 'name'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands', ),
    ).camel == 'camel'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands', ),
    ).description == 'description'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands', ),
    ).commands == ('commands', )

# Generated at 2022-06-21 13:09:30.020678
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = ('command',)
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-21 13:09:33.278331
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='description of test command',
        commands=('echo test', 'echo test')
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'description of test command'
    assert config.commands == ('echo test', 'echo test')

# Generated at 2022-06-21 13:09:38.842422
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig("name", "camel", "description", ("command_0", "command_1"))
    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == ("command_0", "command_1")


# Generated at 2022-06-21 13:09:51.206549
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check_each_sub_command_config(
        setup_dir: Optional[Union[os.PathLike, str]]
    ) -> None:
        def _check(cmd_cfg: SetupCfgCommandConfig) -> None:
            assert cmd_cfg.name
            assert cmd_cfg.camel
            assert cmd_cfg.description
            assert cmd_cfg.commands
            if len(cmd_cfg.commands) == 1:
                assert ' && ' not in cmd_cfg.commands[0]
            elif len(cmd_cfg.commands) > 1:
                for command in cmd_cfg.commands:
                    assert ' && ' not in command

        for cmd_cfg in each_sub_command_config(setup_dir):
            _check(cmd_cfg)

    check_each_sub_command_config(None)

# Generated at 2022-06-21 13:09:57.667398
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.setup_commands import each_sub_command_config
    setup_cfg_path = os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs: Dict[str, str] = {
        'name': _get_name(parser, setup_cfg_path),
        'setup_dir': os.path.dirname(__file__),
        'home': os.path.expanduser('~')
    }
    scc_list: List[SetupCfgCommandConfig] = list(
        _each_setup_cfg_command(parser, format_kwargs)
    )

# Generated at 2022-06-21 13:10:01.180630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(list(each_sub_command_config()))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:10:11.709033
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def list_to_str(l):
        return '\n'.join(map(str, l))

    out = list_to_str(each_sub_command_config())

# Generated at 2022-06-21 13:10:36.344100
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Contrived class for unit testing
    class SetupCfgCommandConfig():
        """Contrived class for unit testing"""

        def __init__(self):
            self.name = 'name'
            self.camel = 'camel'
            self.description = 'description'
            self.commands = 'commands'
    # Instantiate the contrived class
    setup_cfg_command_config = SetupCfgCommandConfig()
    # Compare the test output to the known value
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == 'commands'

# Generated at 2022-06-21 13:10:42.054613
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'name', 'Camel', 'Description', ('commands', )
    )
    assert cfg.name == 'name'
    assert cfg.camel == 'Camel'
    assert cfg.description == 'Description'
    assert cfg.commands == ('commands', )

# Generated at 2022-06-21 13:10:48.428790
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    obj = SetupCfgCommandConfig(
        'test_name',
        'TestCamel',
        'test_description',
        ('test_command',)
    )
    assert obj.name == 'test_name'
    assert obj.camel == 'TestCamel'
    assert obj.description == 'test_description'
    assert obj.commands == ("test_command",)



# Generated at 2022-06-21 13:10:59.838569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    import subprocess
    from tempfile import mkdtemp

    old_cwd = os.getcwd()

    subproc = subprocess.Popen(
        [
            'python',
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'utils',
                'create_test_project.py'
            ),
            '--name=flutils-tester'
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    stdout, stderr = subproc.communicate()

    stdout = stdout.decode()
    stderr = stderr.decode()

    if stdout:
        print(stdout)

# Generated at 2022-06-21 13:11:03.846631
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    fsc = SetupCfgCommandConfig('', '', '', tuple())
    assert isinstance(fsc.name, str)
    assert isinstance(fsc.camel, str)
    assert isinstance(fsc.description, str)
    assert isinstance(fsc.commands, tuple)

# Generated at 2022-06-21 13:11:12.061003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection Mypy
    from flutils.tools.setup_utils import each_sub_command_config
    commands = []
    for sub_command in each_sub_command_config():
        commands.append(sub_command)
    assert len(commands) == 1
    sub_command = commands[0]
    assert sub_command.name == 'build.dist'
    assert sub_command.camel == 'BuildDist'
    assert sub_command.description
    assert 'setup.cfg' in sub_command.commands[0]
    assert 'dist' in sub_command.commands[0]

# Generated at 2022-06-21 13:11:21.392543
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import logging
    import json

    log = logging.getLogger(__name__)
    log.addHandler(logging.NullHandler())

    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)

    log.debug("Setup directory: %r", setup_dir)
    for cfg in each_sub_command_config(setup_dir):
        log.debug("%s", json.dumps(cfg._asdict(), indent=4, sort_keys=True))

# Generated at 2022-06-21 13:11:27.866789
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    )
    assert result.name == 'name', "result.name != 'name' failed."
    assert result.camel == 'camel', "result.camel != 'camel' failed."
    assert result.description == 'description', \
        "result.description != 'description' failed."
    assert result.commands == ('command',), \
        "result.commands != ('command',) failed."



# Generated at 2022-06-21 13:11:33.680099
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('../'))
    assert len(configs) == 4
    assert configs[0].name == 'test'
    assert configs[1].name == 'version'
    assert configs[2].name == 'opts.foo'
    assert configs[3].name == 'opts.foo-bar'

# Generated at 2022-06-21 13:11:39.387769
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    Unit test for constructor of class SetupCfgCommandConfig
    """
    assert(setup_cfg_command_config, SetupCfgCommandConfig)
    assert(setup_cfg_command_config.name, "test")
    assert(setup_cfg_command_config.description, "a test command")
    assert(setup_cfg_command_config.commands, ("echo test", "echo test"))


# Generated at 2022-06-21 13:12:01.341171
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the ``each_sub_command_config`` function."""
    from flutils.parsers import each_sub_command_config
    from flutils.packaging import Project

    project: Project = None
    for config in each_sub_command_config():
        if project is None:
            project = Project(name=config.name)
        # print(config.name, config.camel, config.description, config.commands)
        cmd = project.add_command(
            name=config.name,
            camel=config.camel,
            description=config.description,
            commands=config.commands
        )
        yield cmd
    # project.save()
    project.write()


if __name__ == '__main__':
    from flutils.parsers import each_sub_command_config
   

# Generated at 2022-06-21 13:12:08.892548
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check_section(
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...],
            setup_dir: str
    ) -> None:
        """
        """
        has_commands = bool(commands)
        has_description = bool(description)
        has_name = bool(name)
        has_camel = bool(camel)
        if has_commands is False \
                and has_description is False \
                and has_name is False \
                and has_camel is False:
            return

        if has_commands is False:
            raise ValueError(
                "The option, command (or commands), is required in "
                "the setup.cfg file."
            )

# Generated at 2022-06-21 13:12:14.278754
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "command-name"
    camel = "CommandName"
    description = "Some command to run."
    commands = ("ls -l", "git status")
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-21 13:12:22.032145
# Unit test for function each_sub_command_config
def test_each_sub_command_config(): # flake8: noqa
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test_support.conftest import (
        example_setup_dir,
        test_root,
    )
    from test_support.flutils.packaging.setup_cfg_utils import (
        example_setup_commands_cfg,
    )
    cmds = list(each_sub_command_config(example_setup_dir))
    assert len(cmds) == 1
    cmd = cmds[0]
    assert cmd.name == 'some.name'
    assert cmd.camel == 'SomeName'
    assert cmd.description.strip() == 'Some description.'

# Generated at 2022-06-21 13:12:26.367373
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_path = os.path.abspath(os.path.join(__file__, '..', '..'))
    path = os.path.join(base_path, 'setup.cfg')
    parser = ConfigParser()
    parser.read(path)
    _get_name(parser, path)



# Generated at 2022-06-21 13:12:34.051464
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_SetupCfgCommandConfig_name'
    camel = 'TestSetupCfgCommandConfigName'
    description = 'test_SetupCfgCommandConfig_description'
    commands = ('a', 'b', 'c')

    config = SetupCfgCommandConfig(
        name=name,
        camel=camel,
        description=description,
        commands=commands
    )
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-21 13:12:39.008596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import mock
    from pathlib import Path
    from flutils.pathutils import temp_file_path
    from flutils.osutils import at_exit
    from typing import List, Callable

    _cleanup: List[Callable] = []

    def _atexit():
        for func in reversed(_cleanup):
            func()

    at_exit(_atexit)

    def _write_file(
            path: Union[str, os.PathLike],
            contents: Optional[str] = None
    ) -> None:
        path = str(path)
        contents = contents or ''
        with open(path, 'w', encoding='utf8') as f:
            f.write(contents)
        _cleanup.append(lambda: Path(path).unlink())


# Generated at 2022-06-21 13:12:40.535324
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))



# Generated at 2022-06-21 13:12:48.379580
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='test_name',
        camel='TestName',
        description='Test Description',
        commands=('test command',)
    )
    assert setup_cfg_command_config.name == 'test_name'
    assert setup_cfg_command_config.camel == 'TestName'
    assert setup_cfg_command_config.description == 'Test Description'
    assert setup_cfg_command_config.commands == ('test command',)


# Generated at 2022-06-21 13:12:51.982020
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(1, 2, 3, 4);
    assert config.name == 1
    assert config.camel == 2
    assert config.description == 3
    assert config.commands == 4

# Generated at 2022-06-21 13:13:20.570089
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    from io import StringIO

    from flutils.envutils import format_env_var

    def get_str(
            name: str,
            description: str = '',
            commands: Tuple[str, ...] = ()
    ) -> str:
        out = StringIO()
        for command in commands:
            out.write(command + '\n')
        return '[setup.command.%s]\n' % name + \
            'name=%s\n' % name + \
            'description=%s\n' % description + \
            (('commands=%s\n' % out.getvalue()) if out.getvalue() else '')

    parser = ConfigParser()

# Generated at 2022-06-21 13:13:21.893121
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) == 0



# Generated at 2022-06-21 13:13:34.027082
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-21 13:13:40.567143
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for x in each_sub_command_config():
        print(x.name)
        print(x.camel)
        print(x.description)
        print(x.commands)

if __name__ == '__main__':
    for x in each_sub_command_config():
        print(x.name)
        print(x.camel)
        print(x.description)
        print(x.commands)

# Generated at 2022-06-21 13:13:44.565741
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for subcmd in each_sub_command_config('/Users/cory/work/birdeye'):
        print(subcmd)


if __name__ == "__main__":
    exit(test_each_sub_command_config())

# Generated at 2022-06-21 13:13:47.564791
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    setup_dir = os.path.join('tests', 'fake_project')
    assert each_sub_command_config(setup_dir) is not None

# Generated at 2022-06-21 13:13:51.990771
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', ['description'], ['commands'])
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ['commands']


# Generated at 2022-06-21 13:14:00.269187
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _load():
        import flutils.configutils as _this_module
        return _this_module

    _cwd = os.getcwd()
    _dir = os.path.dirname(__file__)
    os.chdir(_dir)

    try:
        module = _load()
        for config in module.each_sub_command_config(setup_dir='../..'):
            if config.name == 'release':
                assert 'bumpversion --current-version' in config.commands
            elif config.name == 'test':
                assert 'pytest -k "not integration"' in config.commands
            elif config.name == 'test:integration':
                assert 'pytest' in config.commands
    finally:
        os.chdir(_cwd)

# Generated at 2022-06-21 13:14:10.730054
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import setup_commands

    setup_dir = setup_commands.__path__[0]

    path = os.path.join(setup_dir, 'setup_commands.cfg')
    cfgs = []
    names = []
    camels = []
    descriptions = []
    commands = []
    for cmd_cfg in each_sub_command_config(setup_dir):
        cfgs.append(cmd_cfg)
        names.append(cmd_cfg.name)
        camels.append(cmd_cfg.camel)
        descriptions.append(cmd_cfg.description)
        commands.append(cmd_cfg.commands)

    assert setup_dir == cfgs[0].commands[0].split(' ')[-1]
    assert 'setup_commands' in cfgs[0].commands[1]
   

# Generated at 2022-06-21 13:14:22.340596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    def _write_file(path, data):
        with open(path, 'w') as f:
            f.write(data)
    dirpath = tempfile.TemporaryDirectory()
    setup_dir = dirpath.name
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
    _write_file(setup_cfg_path, '[metadata]\nname=test_project')
    _write_file(setup_commands_cfg_path, """\
[setup.command.test_command]
command=
	echo "Hello 1!"
	echo "Hello 2!"
description={name}!
""")

# Generated at 2022-06-21 13:14:54.427619
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    ans = {
        'name': 'flutils',
        'description': 'A collection of random utility functions.',
        'commands': (
            'echo "Hello World!"',
        )
    }
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    for config in each_sub_command_config(setup_dir):
        assert config.name == ans['name']
        assert config.description == ans['description']
        assert config.commands == ans['commands']

# Generated at 2022-06-21 13:14:58.580232
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg)


if __name__ == '__main__':
    import sys
    test_each_sub_command_config()
    sys.exit(0)

# Generated at 2022-06-21 13:15:02.480317
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig.__annotations__ == {
        'name': str,
        'camel': str,
        'description': str,
        'commands': Tuple[str, ...],
    }
    assert issubclass(SetupCfgCommandConfig, NamedTuple)



# Generated at 2022-06-21 13:15:05.336106
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'Description',
        ('echo -n "hello"', 'echo -n "goodbye"')
    )



# Generated at 2022-06-21 13:15:12.120744
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib

    def _test_each_sub_command_config(
        section_name: str,
        setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        import pprint

        def _repr(o):
            return repr(o).replace(str(pathlib.Path.home()), '~')

        class Repr(pprint.PrettyPrinter):
            def format(self, obj, context, maxlevels, level):  # noqa
                if isinstance(obj, pathlib.Path):
                    return obj.as_posix(), True, False
                if isinstance(obj, (set, frozenset)):
                    if len(obj) == 1:
                        o = next(iter(obj))
                        return _repr(o), True, False


# Generated at 2022-06-21 13:15:23.208700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""

    # Arrange and Act
    import pathlib
    from configparser import ConfigParser
    from tempfile import TemporaryDirectory
    from unittest.mock import Mock

    # Arrange and Act
    package_dir = pathlib.Path(__file__).resolve().parent
    package_dir = str(package_dir)
    with TemporaryDirectory() as tmpdir:
        tmpdir = pathlib.Path(tmpdir)
        setup_dir = tmpdir / 'setup_dir'
        setup_dir.mkdir()
        setup_py = setup_dir / 'setup.py'

# Generated at 2022-06-21 13:15:27.664568
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test name', 'TestName', 'test description', ('test command1', 'test command2'))
    assert(config.name == 'test name')
    assert(config.camel == 'TestName')
    assert(config.description == 'test description')
    assert(config.commands == ('test command1', 'test command2'))


# Generated at 2022-06-21 13:15:29.147695
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print('Each setup command:')
    for conf in each_sub_command_config():
        print(str(conf))

# Generated at 2022-06-21 13:15:33.173094
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    tmp = SetupCfgCommandConfig('name1','camel1','description1',['cmd1',
    'cmd2','cmd3'])
    assert tmp.name == 'name1'
    assert tmp.camel == 'camel1'
    assert tmp.description == 'description1'
    assert tmp.commands == ('cmd1', 'cmd2', 'cmd3')


# Generated at 2022-06-21 13:15:43.271605
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import pathlib
    from flutils.testutils import TestConfig

    #
    # Test 1
    #
    path = pathlib.Path(__file__).parent.joinpath('data/test_commands_1')
    os.chdir(path)
    for cfg in each_sub_command_config():
        assert cfg.name == 'documentation'
        assert cfg.camel == 'Documentation'
        assert cfg.description == 'Generate documentation.'
        assert cfg.commands == ('sphinx-build -b html docs docs/_build/html',)

    #
    # Test 2
    #
    os.chdir(TestConfig.temproot)


if __name__ == '__main__':
    test_each_sub_command_config()