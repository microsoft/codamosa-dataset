

# Generated at 2022-06-21 13:06:09.810914
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)

# Generated at 2022-06-21 13:06:15.029944
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'make',
        'Make',
        'Build the package',
        ('python setup.py bdist_wheel',)
    )
    assert config.name == 'make'
    assert config.camel == 'Make'
    assert config.description == 'Build the package'
    assert config.commands == ('python setup.py bdist_wheel',)
    assert str(config) == "<SetupCfgCommandConfig name: 'make', camel: 'Make', description: 'Build the package', commands: ('python setup.py bdist_wheel',)>"


# Generated at 2022-06-21 13:06:18.891692
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        setup_cfg = SetupCfgCommandConfig(
            name = "name",
            camel = "camel",
            description = "description",
            commands = ("command",),
        )
    except:
        assert False, "Failed"
    assert True, "Passed"


# Generated at 2022-06-21 13:06:26.467827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test_setup_cfg_command_config(
            scfg: SetupCfgCommandConfig
    ) -> None:
        assert scfg.name != ''
        assert scfg.camel != ''
        assert scfg.description != ''
        assert len(scfg.commands) >= 1

    for scfg in each_sub_command_config():
        test_setup_cfg_command_config(scfg)


# vim: set ts=4 sw=4 tw=79 ft=python et :

# Generated at 2022-06-21 13:06:32.590630
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='test',
        camel='test',
        description='test',
        commands=('test',)
    )
    assert setup_cfg_command_config.name == 'test'
    assert setup_cfg_command_config.camel == 'test'
    assert setup_cfg_command_config.description == 'test'
    assert setup_cfg_command_config.commands == ('test',)

# Generated at 2022-06-21 13:06:35.140204
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo', 'Foo', 'Foo bar', ()) == SetupCfgCommandConfig('foo', 'Foo', 'Foo bar', ())

# Generated at 2022-06-21 13:06:43.065330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from tempfile import TemporaryDirectory

    from flutils.fileutils import (
        write_file,
        write_file_if_missing,
    )
    from flutils.miscutils import (
        get_attr_str,
        to_str,
    )
    from flutils.strutils import (
        clean_whitespace,
        get_normalized_indentation,
        remove_whitespace,
        remove_whitespace_and_newlines,
    )

# Generated at 2022-06-21 13:06:47.616219
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.environ['FLUTILS_TEST_SETUP_DIR'] = os.path.dirname(__file__)
    for config in each_sub_command_config(None):
        assert config.name
        assert config.description
        assert config.commands

# Generated at 2022-06-21 13:06:57.698422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""

    from pathlib import Path

    from flutils.pathutils import (
        makedirs_safe,
        rm_rf,
    )
    from nose.tools import (
        assert_equal,
        assert_not_in,
        assert_raises,
        assert_true,
    )
    from tempfile import mkdtemp

    temp_dir = mkdtemp()

# Generated at 2022-06-21 13:07:01.699416
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'a',
        'b',
        'c',
        ('d', 'e', 'f')
    ) == (
        'a',
        'b',
        'c',
        ('d', 'e', 'f')
    )

# Generated at 2022-06-21 13:07:22.824710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    this_dir = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.dirname(this_dir)
    proj_dir = os.path.join(parent_dir, 'tests', 'projects', 'project_a')

    setup_cfg_cmds = list(each_sub_command_config(proj_dir))
    assert len(setup_cfg_cmds) == 8

    assert setup_cfg_cmds[0].name == 'setup.command.config.1'
    assert setup_cfg_cmds[0].camel == 'SetupCommandConfig1'
    assert setup_cfg_cmds[0].description == 'Setup Command Config 1...'
    assert setup_cfg_cmds[0].comm

# Generated at 2022-06-21 13:07:30.861951
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory

    from flutils.strutils import generate_random_string

    from flutils.setuputils import (
        generate_setup_command_code,
        generate_setup_file
    )
    from flutils.testutils.fileutils import create_file

    for n in range(1, 5):
        with TemporaryDirectory() as tmp_dir:
            command_names = tuple(
                generate_random_string(10)
                for _ in range(1, n + 1)
            )
            command_descriptions = tuple(
                generate_random_string(10)
                for _ in range(1, n + 1)
            )

# Generated at 2022-06-21 13:07:42.536872
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-21 13:07:47.761693
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    obj = SetupCfgCommandConfig('foo', 'Foo', 'Foo description', ('bar',))
    assert obj.name == 'foo'
    assert obj.camel == 'Foo'
    assert obj.description == 'Foo description'
    assert obj.commands == ('bar',)

# Generated at 2022-06-21 13:07:54.096284
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = str(os.path.dirname(os.path.dirname(__file__)))
    count = 0
    for each in each_sub_command_config(path):
        if each.name in ('create', 'create_venv', 'create_venv_docker',
                         'delete', 'delete_venv', 'delete_venv_docker'):
            count += 1
    assert count == 6

# Generated at 2022-06-21 13:07:59.276937
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase, main

    class EachSubCommandConfigTest(TestCase):
        def test_each_sub_command_config(self):
            configs: Generator[SetupCfgCommandConfig, None, None] = \
                each_sub_command_config()
            self.assertGreaterEqual(len(list(configs)), 1)

    main()

# Generated at 2022-06-21 13:08:09.240939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.realpath(os.path.join(path, '../fixtures/flutils'))
    gen = each_sub_command_config(path)
    out = list(gen)
    assert len(out) == 4
    assert out[0] == SetupCfgCommandConfig(
        name='build_docs',
        camel='BuildDocs',
        description='Build documentation for the project.',
        commands=('$HOME/anaconda3/bin/sphinx-build '
                  '-b html --color docs docs/_build/html',)
    )

# Generated at 2022-06-21 13:08:20.490655
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.dirname(__file__)
    cwd = os.path.abspath(cwd)
    cwd = os.path.join(cwd, '..')
    got = tuple(each_sub_command_config(cwd))

# Generated at 2022-06-21 13:08:22.986842
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', tuple())
    except Exception:
        assert False
    assert True

# Generated at 2022-06-21 13:08:25.812439
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config():
        assert type(sub_cmd) is SetupCfgCommandConfig
        assert sub_cmd.name
        assert sub_cmd.camel
        assert sub_cmd.description
        assert sub_cmd.commands

# Generated at 2022-06-21 13:08:40.942404
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:08:49.877382
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from unittest.mock import patch

    class TestSetupCfgCommandConfig(TestCase):
        @patch(
            'flsetup.setupcfg._each_setup_cfg_command_section',
            return_value=()
        )
        def test_each_sub_command_config(
                self,
                _each_setup_cfg_command_section_mock:
                MagicMock
        ) -> None:
            each_sub_command_config('flutils')
            _each_setup_cfg_command_section_mock.assert_called_once_with(
                parser=ANY
            )

    from flutils.testutils import run_tests
    run_tests('flutils.tests', verbosity=3)

# Generated at 2022-06-21 13:08:51.157339
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('', '', '', tuple())



# Generated at 2022-06-21 13:08:54.198921
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'foo command'
    commands = ('echo', 'foo')
    SetupCfgCommandConfig(name, camel, description, commands)

# Generated at 2022-06-21 13:09:05.080998
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    setup_dir = tempfile.mkdtemp()
    cmd_file_name = os.path.join(setup_dir, 'setup.cfg')
    cmd_file = '\n'.join((
        '[metadata]',
        'name = foo',
        '',
        '[setup.command.foo_bar]',
        'name = FOO BAR',
        'command = flutils luigi',
        'command = flutils luigi|> echo FOO BAR',
        '',
        '[setup.command.foo_baz]',
        'name = FOO BAZ',
        'commands =',
        '  flutils luigi',
        '  flutils luigi|> echo FOO BAR',
    ))

# Generated at 2022-06-21 13:09:10.821432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = next(each_sub_command_config("/Users/caleb/Projects/fishtest"))
    print("=" * 80)
    print("config.name: %s" % (config.name))
    print("config.camel: %s" % (config.camel))
    print("config.description: %s" % (config.description))
    for c in config.commands:
        print("config.commands[]: %s" % (c))



# Generated at 2022-06-21 13:09:17.475465
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = list(each_sub_command_config(
        setup_dir=r'C:\Users\dpom\flutils\tests\data\sample-project'
    ))
    assert len(result) == 3
    assert result[0].name == 'post-version'
    assert result[0].camel == 'PostVersion'
    assert result[0].description == 'Executes the post version commands'
    assert result[1].name == 'setup.command.config'
    assert result[1].camel == 'Config'
    assert result[1].description == \
        'The config section is a custom commands section that is used to ' \
        'generate the ``setup_commands.cfg`` file that is used to create ' \
        'the commands in ``sample_project.commands.commands``.'

# Generated at 2022-06-21 13:09:22.694273
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=('test',)
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('test',)

# Generated at 2022-06-21 13:09:26.763253
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config())
    assert configs
    for config in configs:
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# Generated at 2022-06-21 13:09:30.157918
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='testing',
        commands=('echo "hello"',),
    )
    assert command_config.name == 'test'
    assert command_config.camel == 'Test'
    assert command_config.description == 'testing'
    assert command_config.commands == ('echo "hello"',)

# Generated at 2022-06-21 13:09:49.665571
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='',
        commands=('cmd1', 'cmd2')).name == 'name'
    assert SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='',
        commands=('cmd1', 'cmd2')).camel == 'Camel'
    assert SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='',
        commands=('cmd1', 'cmd2')).description == ''
    assert SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='',
        commands=('cmd1', 'cmd2')).commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:09:54.757299
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="description",
        commands=("command",)
    )
    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "Camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == ("command",)


# Generated at 2022-06-21 13:09:56.345726
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))

# Generated at 2022-06-21 13:10:01.232690
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # load config from setup.cfg and setup_commands.cfg
    for section, name in _each_setup_cfg_command_section(parser):
        assert isinstance(section, str)
        assert isinstance(name, str)


# Generated at 2022-06-21 13:10:02.901236
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('a', 'b', 'c', ('d', ))
    assert config.name == 'a'
    assert config.camel == 'b'
    assert config.description == 'c'
    assert config.commands == ('d',)



# Generated at 2022-06-21 13:10:13.375507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _validate_each_sub_command_config(
            config: SetupCfgCommandConfig,
            expected: SetupCfgCommandConfig
    ) -> None:
        for attr in ('name', 'camel', 'description', 'commands'):
            if getattr(config, attr) != getattr(expected, attr):
                raise ValueError(
                    'Missing or unexpected %s: expected=%r; actual=%r;.'
                    % (attr, getattr(expected, attr), getattr(config, attr))
                )

    import tempfile
    import pathlib

    def _create_setup_cfg(
            setup_cfg_path: str,
            commands: Tuple[str, ...],
            description: str,
            name: str
    ) -> None:
        config = ConfigParser()
        config

# Generated at 2022-06-21 13:10:17.655824
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup = SetupCfgCommandConfig("name.test", "NameTest", "a description",("command1", "command2"))
    assert setup.name == "name.test"
    assert setup.camel == "NameTest"
    assert setup.description == "a description"
    assert setup.commands == ("command1", "command2")

# Generated at 2022-06-21 13:10:24.271052
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='s3.list_buckets',
        camel='S3ListBuckets',
        description='List the names of the buckets in your S3 account.',
        commands=('aws --profile=dev_sandbox_admin --region=us-west-2 s3 ls',)
    )
    assert config.name == 's3.list_buckets'
    assert config.camel == 'S3ListBuckets'
    assert config.description == 'List the names of the buckets in your S3 account.'
    assert config.commands == ('aws --profile=dev_sandbox_admin --region=us-west-2 s3 ls',)



# Generated at 2022-06-21 13:10:26.101260
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()

# Generated at 2022-06-21 13:10:32.042094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n-----------------------------')
    print('Testing function each_sub_command_config...')
    for config in each_sub_command_config():
        print('-----------------------------')
        for k, v in config._asdict().items():
            print('%s: %r' % (k, v))
    print('-----------------------------')

# Generated at 2022-06-21 13:10:48.980573
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('h', 'H',
                                   'some description',
                                   ('x', 'y', 'z'))
    assert config.name == 'h'
    assert config.camel == 'H'
    assert config.description == 'some description'
    assert config.commands == ('x', 'y', 'z')


# Generated at 2022-06-21 13:10:57.753105
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    commands = ['test', 'test1']
    description = 'This is a test'

    test_obj = SetupCfgCommandConfig(
        name=name,
        description=description,
        commands=commands,
        camel=camel
    )

    assert test_obj.name == name
    assert test_obj.camel == camel
    assert test_obj.commands == commands
    assert test_obj.description == description


if __name__ == '__main__':
    for sc in each_sub_command_config():
        print(sc)

# Generated at 2022-06-21 13:11:07.016055
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.randomutils import random_string
    from flutils.tempdirutils import (
        make_temp_dir,
        with_temp_dir,
    )
    from flutils.osutils import touch


# Generated at 2022-06-21 13:11:14.497774
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import cwd_deduped
    from flutils.miscutils import clean_exit
    from flutils.collections import each_in_enumerate

    def _each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for i, config in each_in_enumerate(
                each_sub_command_config(setup_dir)
        ):
            yield '%3d) %r' % (i, config)

    def _test_each_sub_command_config(
            test_name: str,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        print('-------- %s --------' % test_name)

# Generated at 2022-06-21 13:11:18.608220
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import unittest.mock

    # Unit test for function _get_name
    class Test_get_name(unittest.TestCase):
        def setUp(self):
            self.parser = unittest.mock.Mock(spec=ConfigParser)

        def test_name_option_not_set(self):
            self.parser.options.return_value = []
            setup_cfg_path = ''
            with self.assertRaises(LookupError):
                _get_name(self.parser, setup_cfg_path)

        def test_name_option_empty(self):
            self.parser.options.return_value = ['name']
            self.parser.get.return_value = ''
            setup_cfg_path = ''

# Generated at 2022-06-21 13:11:28.902583
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import inspect
    import tempfile
    import configparser
    import filecmp
    import shutil
    import unittest
    import pathlib
    from ..testutils import assert_exit_1, assert_exit_0
    from ..testutils import silence_stderr

    class Test(unittest.TestCase):
        def setUp(self):
            super().setUp()
            script_name = os.path.basename(sys.argv[0])
            self.tempdir_obj = tempfile.TemporaryDirectory(prefix=script_name)
            self.tempdir = self.tempdir_obj.name
            self.tempdir_path = pathlib.Path(self.tempdir)

# Generated at 2022-06-21 13:11:40.840259
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(setup_dir: Optional[str]) -> None:
        for sc in each_sub_command_config(setup_dir):
            if sc.name == 'install':
                for command in sc.commands:
                    assert command == 'pip install -e .'
            elif sc.name == 'build_sphinx':
                for command in sc.commands:
                    assert command == 'sphinx-build -b html docs docs/_build'
            elif sc.name == 'pep8':
                for command in sc.commands:
                    assert command == 'flake8 {name} tests setup.py'
            elif sc.name == 'test':
                for command in sc.commands:
                    assert command == 'pytest tests/'

# Generated at 2022-06-21 13:11:44.734424
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    f = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))
    assert f.name == 'name'
    assert f.camel == 'camel'
    assert f.description == 'description'
    assert f.commands == ('cmd1', 'cmd2')


# Generated at 2022-06-21 13:11:53.956925
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(name='', camel='',
                                 description='', commands=(),
                                 ).name == ''
    assert SetupCfgCommandConfig(name='', camel='',
                                 description='', commands=(),
                                 ).camel == ''
    assert SetupCfgCommandConfig(name='', camel='',
                                 description='', commands=(),
                                 ).description == ''
    assert SetupCfgCommandConfig(name='', camel='',
                                 description='', commands=(),
                                 ).commands == ()



# Generated at 2022-06-21 13:11:58.672287
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    This function is used to test the constructor of class SetupCfgCommandConfig
    """
    obj = SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('command1', 'command2')

# Generated at 2022-06-21 13:12:27.393968
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    conf = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
    assert conf.name == 'name'
    assert conf.camel == 'camel'
    assert conf.description == 'description'
    assert conf.commands == ('command',)


# Generated at 2022-06-21 13:12:31.808288
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', [])
    assert(config.name == 'name')
    assert(config.camel == 'Camel')
    assert(config.description == 'description')
    assert(config.commands == ())

# Generated at 2022-06-21 13:12:34.051538
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('test_name', 'TestName', 'test_description', ('test_command_one', 'test_command_two'))

# Generated at 2022-06-21 13:12:38.646394
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for ``SetupCfgCommandConfig``."""
    x = SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b'))
    assert x.name == 'name'
    assert x.camel == 'Camel'
    assert x.description == 'description'
    assert x.commands == ('a', 'b')

# Generated at 2022-06-21 13:12:43.956440
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'test',
            'data',
            'test_package'
        )
    )
    for item in each_sub_command_config(test_path):
        assert isinstance(item.name, str)
        assert isinstance(item.camel, str)
        assert isinstance(item.description, str)
        assert isinstance(item.commands, tuple)
        for cmd in item.commands:
            assert isinstance(cmd, str)

# Generated at 2022-06-21 13:12:48.479054
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('=== Testing function each_sub_command_config ===')
    for config in each_sub_command_config(__file__):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:12:55.242361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import Generator
    from pprint import pprint  # noqa: F401

    def _test_each_sub_command_config(
            setup_dir: Union[os.PathLike, str, None]
    ) -> Generator[None, None, None]:
        for data in each_sub_command_config(setup_dir):
            pprint(data)
            yield

    next(
        _test_each_sub_command_config(None),
        None
    )



# Generated at 2022-06-21 13:13:03.784602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.join(os.path.dirname(__file__), 'data')
    for cfg in each_sub_command_config(test_dir):
        assert cfg.name == 'build'
        assert cfg.camel == 'Build'
        assert cfg.description == 'Builds the project\'s source code'
        assert len(cfg.commands) == 2
        assert cfg.commands[0].startswith('python setup.py bdist_wheel')
        assert cfg.commands[1].startswith('python setup.py bdist_egg')


if __name__ == '__main__':
    import sys
    if sys.argv[-1] == 'debug':
        sys.argv.pop()
        test_each_sub_command_config()

# Generated at 2022-06-21 13:13:05.222442
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig


# Generated at 2022-06-21 13:13:11.394236
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the each_sub_command_config function."""
    setup_dir = os.path.abspath(os.path.dirname(__file__))
    setup_dir = os.path.join(setup_dir, 'example')
    for scconfig in each_sub_command_config(setup_dir):
        print(scconfig)



# Generated at 2022-06-21 13:14:11.718970
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..'
    )
    gen = each_sub_command_config(setup_dir)
    result = tuple(gen)
    assert len(result) == 3
    result = sorted(result, key=lambda x: x.name)
    assert result[0].name == 'package.doc'
    assert result[0].camel == 'PackageDoc'
    assert len(result[0].commands) == 1
    assert result[0].commands[0] == \
        '$(MAKE) -C docs html && chromium docs/_build/html/index.html &'
    assert result[1].name == 'package.install'
    assert result[1].camel == 'PackageInstall'
   

# Generated at 2022-06-21 13:14:16.609390
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('a',))

    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('a',)

# Generated at 2022-06-21 13:14:28.173346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config()')
    print(each_sub_command_config.__doc__)
    print('Testing with no parameters')
    for config in each_sub_command_config():
        print(config)
    print('Testing with the current directory')
    for config in each_sub_command_config('.'):
        print(config)
    print('Testing with the setup.py directory')
    for config in each_sub_command_config(__file__):
        print(config)
    print('Testing with the setup.py directory')
    for config in each_sub_command_config(__file__):
        print(config)

# Generated at 2022-06-21 13:14:40.133134
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    setup_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(setup_dir, 'tests'))
    open(os.path.join(setup_dir, 'setup.py'), 'w').close()
    open(os.path.join(setup_dir, 'setup.cfg'), 'w').close()
    open(os.path.join(setup_dir, 'setup_commands.cfg'), 'w').close()
    open(os.path.join(setup_dir, 'tests', 'test_main.py'), 'w').close()
    try:
        out = list(each_sub_command_config(setup_dir))
        del out  # stubbed
    finally:
        shutil.rmtree(setup_dir)



# Generated at 2022-06-21 13:14:44.573788
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig("name", "camel", "desc", ["cmd1", "cmd2"])
    assert obj.name == "name"
    assert obj.camel == "camel"
    assert obj.description == "desc"
    assert obj.commands == ("cmd1", "cmd2")


# Generated at 2022-06-21 13:14:52.538478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    i = 0
    for config in each_sub_command_config(setup_dir):
        i += 1
        if i == 1:
            assert config.name == 'hello'
            assert config.camel == 'Hello'
            assert config.description == 'Hello world'
            assert config.commands == ('echo world', )
        elif i == 2:
            assert config.name == 'custom'
            assert config.camel == 'Custom'
            assert config.description == 'Custom hello world'
            assert config.commands == ('echo custom world', )
        else:
            assert False  # should NOT get here

# Generated at 2022-06-21 13:14:54.388761
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('', '', '', ())



# Generated at 2022-06-21 13:14:59.640946
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'hello',
        'Hello',
        'Use this to say hello.',
        ('',),
    )
    assert config.name == 'hello'
    assert config.camel == 'Hello'
    assert config.description == 'Use this to say hello.'
    assert config.commands == ('',)

# Generated at 2022-06-21 13:15:08.288474
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import get_caller_dir

    caller_dir = get_caller_dir(__file__)
    caller_dir = os.path.join(caller_dir, 'testpkg')
    expected = [
        SetupCfgCommandConfig(
            'testcmd', 'Testcmd', 'Test command.',
            ('echo "test command executed..."',),
        ),
        SetupCfgCommandConfig(
            'testcmd2', 'Testcmd2', 'Test command 2.',
            ('echo "test command2 executed..."',),
        ),
        SetupCfgCommandConfig(
            'testcmd3', 'Testcmd3', 'Test command 3.',
            ('echo "test command3 executed..."',),
        ),
    ]

# Generated at 2022-06-21 13:15:19.023286
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import json
    from io import StringIO

    from flutils.pyutil import get_caller_frame
    from flutils.pyutil import get_caller_module
    from flutils.pyutil import get_caller_filename

    def validate_each_sub_command_config():
        out = []
        for cmd in each_sub_command_config():
            out.append({
                'name': cmd.name,
                'camel': cmd.camel,
                'description': cmd.description,
                'commands': list(cmd.commands)
            })
        return str(json.dumps(out, sort_keys=True, indent=4))

    def get_module_frame_path():
        cf = get_caller_frame(2)