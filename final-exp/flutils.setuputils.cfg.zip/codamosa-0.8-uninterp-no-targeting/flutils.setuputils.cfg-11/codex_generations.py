

# Generated at 2022-06-21 13:06:09.428266
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'my.name', 'MyName', 'My description.', ('mycommand')
    )
    assert cfg.name == 'my.name'
    assert cfg.camel == 'MyName'
    assert cfg.description == 'My description.'
    assert cfg.commands == ('mycommand',)


# Generated at 2022-06-21 13:06:10.850136
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))

# Generated at 2022-06-21 13:06:14.907707
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    commands = []
    commands.append(SetupCfgCommandConfig('a', 'b', 'c', ('d',)))
    assert commands[0].name == 'a'
    assert commands[0].camel == 'b'
    assert commands[0].description == 'c'
    assert commands[0].commands == ('d',)



# Generated at 2022-06-21 13:06:22.207290
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_command_config: SetupCfgCommandConfig
    for setup_command_config in each_sub_command_config():
        assert isinstance(setup_command_config, SetupCfgCommandConfig)
        assert isinstance(setup_command_config.name, str)
        assert isinstance(setup_command_config.camel, str)
        assert isinstance(setup_command_config.description, str)
        assert isinstance(setup_command_config.commands, tuple)


__all__ = ('each_sub_command_config',)

# Generated at 2022-06-21 13:06:24.174764
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        print(cmd)



# Generated at 2022-06-21 13:06:29.040566
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',),
    )
    
    assert a.name == 'name'
    assert a.camel == 'camel'
    assert a.description == 'description'
    assert a.commands == ('commands',)

# Generated at 2022-06-21 13:06:32.751267
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    for sc in each_sub_command_config():
        pass
    return


if __name__ == '__main__':
    for config in each_sub_command_config():
        print()
        print(config)

# Generated at 2022-06-21 13:06:39.948969
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo_bar_baz'
    description = 'Foo bar baz.'
    commands = ['Command 1.', 'Command 2.']

    config = SetupCfgCommandConfig(
        name=name,
        camel=underscore_to_camel(name, lower_first=False),
        description=description,
        commands=tuple(commands),
    )
    assert config.name == name
    assert config.camel == underscore_to_camel(name, lower_first=False)
    assert config.description == description
    assert config.commands == tuple(commands)

# Generated at 2022-06-21 13:06:43.272843
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    func = SetupCfgCommandConfig('name', 'camel', 'description', tuple())
    assert(func.name == 'name')
    assert(func.camel == 'camel')
    assert(func.description == 'description')
    assert(func.commands == tuple())


# Generated at 2022-06-21 13:06:46.130207
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(name='name', camel='Name',
                                 description='description', commands=())


# Unit tests for function _each_setup_cfg_command_section

# Generated at 2022-06-21 13:07:06.927172
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from shutil import rmtree

    class SetupCfgCommandConfigTests(TestCase):
        _test_dir = os.path.join(os.path.dirname(__file__), 'test_cmds')

        def test_each_sub_command_config(self):
            """Each sub command config test."""
            out = tuple(each_sub_command_config(self._test_dir))
            self.assertEqual(len(out), 4)

            # First one is the default which has no description
            self.assertEqual(out[0].name, 'default')
            self.assertEqual(out[0].camel, 'Default')
            self.assertEqual(out[0].description, '')

# Generated at 2022-06-21 13:07:18.758126
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _show_cmd(cmd: SetupCfgCommandConfig) -> str:
        return '%r, %r, %r, %r' % (cmd.camel, cmd.name, cmd.description, cmd.commands)

    def do_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]],
            expected: Tuple[SetupCfgCommandConfig, ...],
            err: str
    ) -> None:
        print('\nTesting with setup_dir=%r ...' % setup_dir)

# Generated at 2022-06-21 13:07:21.466072
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a',)) \
        == SetupCfgCommandConfig(name='name', camel='Camel', description='description', commands=('a',))

# Generated at 2022-06-21 13:07:25.788478
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'bar'
    command = 'baz'
    commands = (command,)
    obj = SetupCfgCommandConfig(name, camel, description, commands)
    assert obj.name == name
    assert obj.camel == camel
    assert obj.description == description
    assert obj.commands == commands



# Generated at 2022-06-21 13:07:29.924417
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'fred'
    camel = 'Fred'
    description = 'fear'
    commands  = ('ring', 'king')
    config = SetupCfgCommandConfig(
        name, camel, description, commands
    )
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-21 13:07:35.333520
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd_names = ('add_config', 'del_config')
    cmd_camel = ('AddConfig', 'DelConfig')
    cmd_desc = ('Add your config', 'Delete your config')
    cmd_cmds = (('echo %s', 'echo %s'), ('echo %s', 'echo %s'))

    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'setup.py')
        with open(setup_dir, 'w') as fp:
            fp.write("plot_bot = 'plot_bot'")
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-21 13:07:36.688273
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config('tests/data'):
        pass

# Generated at 2022-06-21 13:07:39.563626
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Make sure each_sub_command_config does NOT raise exceptions
    for subcmd in each_sub_command_config():
        pass
        # print(subcmd)

# Generated at 2022-06-21 13:07:40.585747
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _ = SetupCfgCommandConfig


# Generated at 2022-06-21 13:07:51.119140
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    t_setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'flutils'
    )
    test_setup_cfg_path = os.path.join(t_setup_dir, 'setup.cfg')
    test_parser = ConfigParser()
    test_parser.read(test_setup_cfg_path)
    t_name = _get_name(test_parser, test_setup_cfg_path)
    for config in each_sub_command_config(t_setup_dir):
        assert config.name == 'upload_docs'
        assert config.camel == 'UploadDocs'
        assert config.description == ''
        assert config.commands == (
            'python -m twine upload docs/build/html',
        )
    assert t_name

# Generated at 2022-06-21 13:08:13.573005
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command1', 'command2')



# Generated at 2022-06-21 13:08:17.611308
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cwd, 'fixtures', 'setupcfgutils')
    yield from each_sub_command_config(setup_dir=path)

# Generated at 2022-06-21 13:08:25.881797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # get setup_dir
    setup_dir = os.path.realpath(
        os.path.join(
            os.path.dirname(__file__),
            os.path.pardir
        )
    )
    # get each_sub_command_config
    each_config = list(each_sub_command_config(setup_dir=setup_dir))
    # format
    each_config = [
        "{name}:{camel}:{description}".format(
            name=x.name,
            camel=x.camel,
            description=x.description,
        ) for x in each_config
    ]
    # test

# Generated at 2022-06-21 13:08:32.370147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(
            os.path.abspath(
                os.path.join(os.path.dirname(__file__), '..', '..', '..')
            )
    ):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:38.233002
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _path = os.path.dirname(os.path.abspath(__file__))
    _path = os.path.dirname(_path)
    _path = os.path.dirname(_path)
    _path = os.path.dirname(_path)
    for r in each_sub_command_config(
            os.path.join(_path, 'example', 'example1')
    ):
        print(repr(r))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:41.304624
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'my_name',
        'MyName',
        'my description',
        ('my command',),
    )


# Generated at 2022-06-21 13:08:43.193177
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('hello', 'world', 'foo', ('bar',))



# Generated at 2022-06-21 13:08:47.052336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    for config in each_sub_command_config('..'):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# Generated at 2022-06-21 13:08:53.416416
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat
    from flutils.testing import get_testing_config_path
    from flutils.configutils import load_config

    config = load_config(get_testing_config_path())
    setup_dir = config['project']['setup_dir']
    data = []
    for command in each_sub_command_config(setup_dir):
        data.append(command)
    print(pformat(data))
    assert len(data) == 5, len(data)

# Generated at 2022-06-21 13:09:01.239279
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test_command',
        'TestCommand',
        'This is a test command',
        tuple(['echo "hello"', 'echo "world"']),
    )
    assert config.name == 'test_command'
    assert config.camel == 'TestCommand'
    assert config.description == 'This is a test command'
    assert config.commands == tuple(['echo "hello"', 'echo "world"'])

# Generated at 2022-06-21 13:09:28.338480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from flutils.pathutils import TempDir

    def _dir_exists(path: os.PathLike) -> bool:
        path = str(path)

# Generated at 2022-06-21 13:09:32.523098
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="test.name",
        camel="TestName",
        description="Test description",
        commands=()
    )
    assert config.name == "test.name"
    assert config.camel == "TestName"
    assert config.description == "Test description"
    assert config.commands == ()

# Generated at 2022-06-21 13:09:39.341549
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import mock
    import os
    from flutils.testutils import (
        AssertCallable,
        AssertRaises,
    )
    from flutils.pathutils import mkdtemp

    with AssertRaises(FileNotFoundError) as e:
        each_sub_command_config(setup_dir=mkdtemp())
    assert str(e) == (
        "The given 'setup_dir' of %r does NOT contain a setup.py file."
        % str(e.expected.value.filename)
    )

    with AssertRaises(FileNotFoundError) as e:
        with mock.patch('sys.argv', ['setup.py']):
            each_sub_command_config()

# Generated at 2022-06-21 13:09:51.613030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, 'setup_commands.cfg')
        with open(path, 'w') as f:
            f.write('''[setup.command.bdist_wheel]
commands =
  python setup.py sdist bdist_wheel
  twine upload dist/*
''')
        path = os.path.join(tmp, 'setup.py')
        with open(path, 'w') as f:
            f.write('''print(__file__)''')
        path = os.path.join(tmp, 'setup.cfg')
        with open(path, 'w') as f:
            f.write('''[metadata]
name = foo
summary = foo''')

# Generated at 2022-06-21 13:09:55.108634
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function :func:`each_sub_command_config`."""
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    setup_dir = os.path.join(setup_dir, 'test_module')
    list(each_sub_command_config(setup_dir))

# Generated at 2022-06-21 13:10:06.992616
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(__file__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.join(path, 'tests', 'fixtures', 'setup.cfg')
    path = os.path.abspath(path)
    assert os.path.isfile(path) is True
    comms = list(each_sub_command_config(os.path.dirname(path)))
    assert len(comms) == 5
    assert comms[0] == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Initializes the testing configuration.',
        commands=('python setup.py test',)
    )

# Generated at 2022-06-21 13:10:17.117246
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # noqa: D103
    x = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert isinstance(x.name, str)
    assert isinstance(x.camel, str)
    assert isinstance(x.description, str)
    assert isinstance(x.commands, tuple)
    assert len(x) == 4
    assert x == (
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert isinstance(x[0], str)
    assert isinstance(x[1], str)
    assert isinstance(x[2], str)
    assert isinstance(x[3], tuple)
    assert x[0] == 'name'
    assert x[1]

# Generated at 2022-06-21 13:10:28.137990
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import sys

    class Test(unittest.TestCase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(__file__)

# Generated at 2022-06-21 13:10:34.941186
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_input = SetupCfgCommandConfig(
        name="example_command",
        camel="ExampleCommand",
        description="Example command",
        commands=('ls',)
    )
    test_output = SetupCfgCommandConfig(
        name='example_command',
        camel='ExampleCommand',
        description='Example command',
        commands=('ls',)
    )
    assert test_input == test_output


# Generated at 2022-06-21 13:10:47.827248
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    import io

    class DummyFile:

        def __init__(self, name):
            self._name = name
            self._io = io.StringIO('')

        def write(self, s):
            self._io.write(s)
            if s.endswith('\n'):
                self._io.write('\n')

        def __str__(self):
            return self._name

    DummyFile.__enter__ = lambda x: x._io
    DummyFile.__exit__ = lambda x, _1, _2, _3: x._io.close()

    setup_dir = os.path.dirname(__file__)
    i = []


# Generated at 2022-06-21 13:11:32.678703
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig('foo', 'bar', 'baz', ('hello', 'world'))
    assert x.name == 'foo'
    assert x.camel == 'bar'
    assert x.description == 'baz'
    assert x.commands == ('hello', 'world')


# Generated at 2022-06-21 13:11:43.694100
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    def make_setup_cfg(d: tempfile.TemporaryDirectory) -> None:
        path = os.path.join(d.name, 'setup.cfg')
        with open(path, mode='w', encoding='utf-8') as f:
            f.write(
                """[metadata]
name = my_pkg
version = 0.1.0
""")

    def make_setup_commands_cfg(d: tempfile.TemporaryDirectory) -> None:
        path = os.path.join(d.name, 'setup_commands.cfg')

# Generated at 2022-06-21 13:11:52.418482
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pytest import raises

    setup_dir = os.path.dirname(__file__)
    with raises(FileNotFoundError):
        list(each_sub_command_config(setup_dir))

    setup_dir = os.path.join(os.path.dirname(setup_dir), 'flutils')
    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) > 0
    assert sorted(configs) == sorted(each_sub_command_config(setup_dir))

# Generated at 2022-06-21 13:12:01.340669
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import (
        patch,
        Mock,
    )
    from pkg_resources import resource_filename
    m_open = 'builtins.open'
    m_extract_stack = 'traceback.extract_stack'
    mocks = {}
    setup_dir = resource_filename(__name__, 'data/setup_cfg_command')

# Generated at 2022-06-21 13:12:03.142654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        list(each_sub_command_config())
    except FileNotFoundError:  # pragma: no cover
        pass

# Generated at 2022-06-21 13:12:06.557579
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=unused-variable
    section = SetupCfgCommandConfig(
        name='test.name',
        camel='TestName',
        description='',
        commands=['command1', 'command2']
    )

# Generated at 2022-06-21 13:12:16.369129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit tests for function each_sub_command_config"""
    setup_dir = os.path.dirname(__file__)
    results = list(each_sub_command_config(setup_dir))
    assert isinstance(results, list)
    assert len(results) == 2
    offset = len('test_generate_cli')
    results_names = list(
        map(lambda x: x.name, results)
    )
    assert results_names == ['test_generate_cli', 'test_package']
    results_camel = list(
        map(lambda x: x.camel, results)
    )
    assert results_camel == ['TestGenerateCli', 'TestPackage']
    results_descriptions = list(
        map(lambda x: x.description, results)
    )

# Generated at 2022-06-21 13:12:27.030454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest.mock import MagicMock

    def setup_dir_factory() -> Generator[str, None, None]:
        with TemporaryDirectory() as tmp_dir:
            tmp_dir = Path(tmp_dir)
            for name in ('setup.py', 'setup.cfg', 'setup_commands.cfg'):
                path = tmp_dir / name
                path.touch()
                yield tmp_dir.as_posix()

    config = {
        'metadata': {
            'name': 'flutils'
        }
    }

    def config_factory(tmp_dir: str) -> Generator[ConfigParser, None, None]:
        parser = ConfigParser()
        parser.read_dict(config)

# Generated at 2022-06-21 13:12:32.602257
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)  # type: ignore
    sections = []
    commands = []
    for config in each_sub_command_config(path):
        sections.append(config.camel)
        commands.append(config.commands[0])
    assert sections == ['Commands']
    assert commands == ['py.test']



# Generated at 2022-06-21 13:12:35.473904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=('', '',)
    )


# Generated at 2022-06-21 13:13:25.854487
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'my_pkg.my_sub_cmd',
        'MyPkgMySubCommand',
        'The description of MyPkgMySubCommand',
        ('cmd1', 'cmd2')
    )
    assert cfg.name == 'my_pkg.my_sub_cmd'
    assert cfg.camel == 'MyPkgMySubCommand'
    assert cfg.description == 'The description of MyPkgMySubCommand'
    assert cfg.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:13:32.664619
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig(
        "foo",
        "Bar",
        "The foo command.",
        ("echo 1", "echo 2",),
    )
    assert isinstance(instance, SetupCfgCommandConfig)
    assert str(instance) == "SetupCfgCommandConfig(name='foo', camel='Bar', " \
           "description='The foo command.', commands=('echo 1', 'echo 2'))"



# Generated at 2022-06-21 13:13:43.601882
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import version_info
    from unittest.mock import (
        Mock,
        patch,
    )

    test_dir = os.path.dirname(__file__)
    flutils_dir = os.path.dirname(test_dir)
    src_dir = os.path.dirname(flutils_dir)
    py2_dir: str = os.path.join(src_dir, 'tests', 'py2')
    py3_dir: str = os.path.join(src_dir, 'tests', 'py3')
    test_dirs: Dict[str, str] = {
        'py2': py2_dir,
        'py3': py3_dir,
    }
    if version_info.major >= 3:
        iter_configs = each_sub_command_

# Generated at 2022-06-21 13:13:48.509072
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import site
    import flutils
    import flutils.scripts
    import flutils.scripts.tests
    import flutils.scripts.tests.test_setup_cfg_command
    import flutils.scripts.tests.test_setup_cfg_command_data
    import flutils.scripts.tests.test_setup_cfg_command_data.test_create
    from flutils.config import (
        each_sub_command_config,
    )
    from flutils.scripts.tests.test_setup_cfg_command.data import (
        TEST_SETUP_CFG_COMMAND_DATA_DIR,
    )

    # Test on the test package itself
    #
    # Note: It is OK if this test fails.
    #
    # Note: If a failure does occur, make sure that the test

# Generated at 2022-06-21 13:13:52.584771
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", "commands")
    assert config.name, "name"
    assert config.camel, "camel"
    assert config.description, "description"
    assert config.commands, "commands"


# Generated at 2022-06-21 13:13:56.907438
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'name description',
        ('command one', 'command two')
    ) == SetupCfgCommandConfig(
        'name',
        'Camel',
        'name description',
        ('command one', 'command two')
    )



# Generated at 2022-06-21 13:14:06.582138
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('foo', 'bar')) == (
        SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('foo', 'bar'))
    )
    assert SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('foo', 'bar')) != (
        SetupCfgCommandConfig('foo', 'Baz', 'Foo', ('foo', 'bar'))
    )
    assert SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('foo', 'bar')) != (
        SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('foo', 'bar', 'baz'))
    )

# Generated at 2022-06-21 13:14:17.540565
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig
    assert SetupCfgCommandConfig.__name__ == 'SetupCfgCommandConfig'
    assert SetupCfgCommandConfig.__module__ == __name__
    assert SetupCfgCommandConfig.__qualname__ == '{}.SetupCfgCommandConfig'.format(__name__)

    assert SetupCfgCommandConfig.__annotations__ == {
        'name': str,
        'camel': str,
        'description': str,
        'commands': Tuple[str, ...],
    }

    assert SetupCfgCommandConfig._fields == ('name', 'camel', 'description', 'commands')


# Generated at 2022-06-21 13:14:29.000480
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name="foo", camel="Foo", description="foo", commands=("foo",))
    expected = (config.name == "foo" and config.camel == "Foo" and config.description == "foo" and config.commands == ("foo",))

    # Test successful creation
    assert(expected)

    # Test None class arguments
    config = SetupCfgCommandConfig(name=None, camel=None, description=None, commands=None)
    expected = (config.name == None and config.camel == None and config.description == None and config.commands == None)
    assert(expected)

    # Test Empty class arguments
    config = SetupCfgCommandConfig(name="", camel="", description="", commands=())

# Generated at 2022-06-21 13:14:40.625576
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap
    dir = os.path.dirname(__file__)
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_py_path = os.path.join(tmpdir, 'setup.py')
        with open(setup_py_path, 'wt') as f:
            pass
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'wt') as f:
            f.write(textwrap.dedent('''\
                [metadata]
                name = test
                '''))
        cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')