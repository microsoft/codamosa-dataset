

# Generated at 2022-06-21 13:06:09.116480
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "desc", ("a", "b"))

    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "desc"
    assert config.commands == ("a", "b")


# Generated at 2022-06-21 13:06:15.755343
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, realpath
    from flutils.pathutils import find_parent_dir

    def _validate(
            sub_cmd: SetupCfgCommandConfig,
            setup_cfg_section: str,
            name: str,
            description: str
    ) -> None:
        assert sub_cmd.name == name
        assert sub_cmd.camel == setup_cfg_section
        assert sub_cmd.description == description
        cmds = sub_cmd.commands
        assert cmds
        assert cmds[0].endswith('python setup.py ' + name)

    base_dir = realpath(dirname(__file__))


# Generated at 2022-06-21 13:06:18.027983
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))


# Generated at 2022-06-21 13:06:28.961828
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test directory
    test_root = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        '..',
        'test_data',
        'unittests',
        'test_flutils_spawn'
    )
    # Test with testsub
    for sub in each_sub_command_config(setup_dir=test_root):
        assert sub.name == 'testsub'
        assert sub.camel == 'Testsub'
        assert sub.description == 'Run the testsub command.'
        assert sub.commands == ('testsub',)

# Generated at 2022-06-21 13:06:37.951916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config(setup_dir='.'))
    assert len(out) == 5
    assert out[0].camel == 'SubCommandOne'
    assert out[0].name == 'command-one'
    assert out[0].description == 'A dummy command just for testing.'
    assert out[0].commands == (
        'echo',
        'echo hello world'
    )
    assert out[1].camel == 'SubCommandTwo'
    assert out[1].name == 'command-two'
    assert out[1].description == 'Another dummy command just for testing.'
    assert out[1].commands == (
        'echo',
        'echo hello world'
    )

# Generated at 2022-06-21 13:06:41.324712
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('./tests/data/pkg'):
        assert config == SetupCfgCommandConfig(
            'test.fixture',
            'TestFixture',
            'Does this test pass?',
            tuple([
                'echo "Test fixture command."',
            ])
        )

# Generated at 2022-06-21 13:06:42.929465
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pprint import pprint
    for i in each_sub_command_config():
        pprint(i)

# Generated at 2022-06-21 13:06:53.793196
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    os.environ['TESTING_EACH_SUB_COMMAND_CONFIG'] = '1'

    setup_dir = os.path.join(_prep_setup_dir(), 'tests')
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs: Dict[str, str] = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~'),
        'name': _get_name(parser, setup_cfg_path),
    }
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
   

# Generated at 2022-06-21 13:06:59.112345
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=no-value-for-parameter

    def _get_setup_dir() -> str:
        return os.path.dirname(os.path.realpath(__file__))

    for config in each_sub_command_config(_get_setup_dir()):
        assert config.name
        assert config.camel
        assert config.description
        assert len(config.commands)



# Generated at 2022-06-21 13:07:02.600025
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))
    assert c.name == 'name'
    assert c.camel == 'Camel'
    assert c.description == 'description'
    assert c.commands == ('command',)


# Generated at 2022-06-21 13:07:11.226347
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))

# Generated at 2022-06-21 13:07:14.503996
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name', 'Camel', 'Description', ('command1', 'command2')
    )

# Generated at 2022-06-21 13:07:23.852415
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    print('*** each_sub_command_config()')
    expected_str = """\
desc='Test description.',
commands=('pip install {home}/test_user_dir/test_lib',)"""

    # Execute
    for cfg_obj in each_sub_command_config('/tmp/test_each_sub_command_config'):
        if cfg_obj.name == 'sub.subsub.subsubsub':
            print(',\n'.join(
                [
                    'desc=%r,' % cfg_obj.description,
                    'commands=(%r,' % cfg_obj.commands[0],
                ]
            ))

    # Assert

# Generated at 2022-06-21 13:07:26.488014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """pytest unit test for function each_sub_command_config"""
    setup_dir = os.path.dirname(__file__)
    for _ in each_sub_command_config(setup_dir):
        assert True

# Generated at 2022-06-21 13:07:27.696786
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config('./flutils'))) > 2

# Generated at 2022-06-21 13:07:29.185444
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(setup_dir=__file__):
        pass

# Generated at 2022-06-21 13:07:30.762651
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args: Tuple[str, ...] = ('name', 'camel', 'description', 'commands')
    assert SetupCfgCommandConfig._fields == args

# Generated at 2022-06-21 13:07:42.142613
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        ConfigDumper,
        ConfigParser,
        setup_dir,
    )
    with TemporaryDirectory() as tmpdirname:
        # Create a setup.py file and setup.cfg file
        tmpdirname = str(tmpdirname)
        setup_dir(tmpdirname)
        setup_cfg_path = os.path.join(tmpdirname, 'setup.cfg')
        parser = ConfigParser()
        parser.read(setup_cfg_path)

        parser.set(
            'metadata',
            'name',
            'flutils'
        )
        parser.set('metadata', 'description', 'A Python3 utility library.')
        parser.set('metadata', 'long_description', 'Too damn long.')

# Generated at 2022-06-21 13:07:47.341863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _setup_dir = os.path.dirname(__file__)
    _setup_dir = os.path.abspath(
        os.path.join(_setup_dir, '..', '..', '..')
    )
    _setup_dir = os.path.realpath(_setup_dir)
    _setup_dir = os.path.dirname(os.path.dirname(_setup_dir))

    count = 0
    for config in each_sub_command_config(_setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)

# Generated at 2022-06-21 13:07:54.309014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    from os.path import realpath, dirname, join
    from inspect import currentframe
    from sys import path as sys_path
    from sys import modules
    this_file = realpath(currentframe().f_code.co_filename)
    sys_path.append(dirname(this_file))
    from flutils_tests import __path__ as flutils_tests_path
    from flutils_tests.base import test

    this_module = modules[__name__]
    flutils_tests_path = join(flutils_tests_path[0], 'config')

    path = join(flutils_tests_path, 'setup_commands.cfg')


# Generated at 2022-06-21 13:08:04.070596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'data', 'setup.cfg')
    for config in each_sub_command_config(os.path.dirname(path)):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:08.506406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_cfg in each_sub_command_config('/home/david/Projects/github/flutils/tests/data/flutils'):
        print(cmd_cfg)


# Generated at 2022-06-21 13:08:11.061145
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test the the commands is a tuple
    assert SetupCfgCommandConfig('foo', 'bar', 'baz', ('one',)).commands == ('one',)

# Generated at 2022-06-21 13:08:21.728198
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=redefined-outer-name,missing-docstring,invalid-name
    import os

    class MockFrameSummary(NamedTuple):
        filename: str

    class MockExtractStack:
        @staticmethod
        def __iter__() -> Generator[MockFrameSummary, None, None]:
            # noinspection PyTypeChecker
            yield MockFrameSummary(os.path.join('foo', 'bar', 'setup.py'))
            # noinspection PyTypeChecker
            yield MockFrameSummary(os.path.join('foo', 'setup.py'))
            # noinspection PyTypeChecker
            yield MockFrameSummary(os.path.join('a', 'setup.py'))
            # noinspection PyTypeChecker

# Generated at 2022-06-21 13:08:29.116172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testingutils import (
        mkdir_p,
        mkfile,
    )
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch

    class Test_each_sub_command_config(TestCase):
        @patch('os.path.expanduser', return_value='~')
        def test_0000(self, mock_os_path_expanduser):
            tmpdir = mkdir_p(TemporaryDirectory().name, 'tmpdir')
            setup_cfg_path = mkfile(
                tmpdir,
                'setup.cfg',
                (
                    '[metadata]\n'
                    '  name = the-project\n'
                )
            )

# Generated at 2022-06-21 13:08:40.013817
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from io import StringIO

    config = StringIO()

# Generated at 2022-06-21 13:08:43.984728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
    )

    path = get_test_data_path()
    if path is None:
        return

    for config in each_sub_command_config(path):
        assert config


if __name__ == "__main__":
    import pytest
    pytest.main(args=["--color=auto", "--capture=sys", "-W", 'error::DeprecationWarning', __file__])

# Generated at 2022-06-21 13:08:49.935814
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    exp = SetupCfgCommandConfig(
        'command.name',
        'CommandName',
        'desc here',
        ('1', '2')
    )
    assert exp == SetupCfgCommandConfig(
        name='command.name',
        camel='CommandName',
        description='desc here',
        commands=('1', '2')
    )
    assert exp == SetupCfgCommandConfig(
        *exp
    )
    assert exp.__dict__ == SetupCfgCommandConfig(*exp).__dict__

# Generated at 2022-06-21 13:09:01.403764
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('/Users/jlong/git/flutils/'))
    assert len(configs) == 15
    config = sorted(
        filter(lambda x: x.name == 'help', configs),
        key=lambda x: x.description
    )[0]
    assert config.description == 'Show help.'
    assert len(config.commands) == 2
    config = sorted(
        filter(lambda x: x.name == 'build', configs),
        key=lambda x: x.description
    )[0]
    assert config.description == 'Build a package.'
    assert len(config.commands) == 4

# Generated at 2022-06-21 13:09:11.740907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    mock_path: os.PathLike = '/mock/path'
    mock_fs: NamedTuple = NamedTuple(
        'mock_fs',
        (
            ('filename', os.path.join(mock_path, 'setup.py')),
            ('line', 100)
        )
    )
    orig_extract_stack = extract_stack
    extract_stack = lambda: [mock_fs]
    try:
        config = list(each_sub_command_config(setup_dir=mock_path))
    finally:
        extract_stack = orig_extract_stack
    assert len(config) == 4
    assert config[0].name == 'tests.test_setup'
    assert config[0].camel == 'TestSetup'

# Generated at 2022-06-21 13:09:26.794188
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "name"
    camel = "Camel"
    description = "description"
    commands = ("ls", "echo")
    SetupCfgCommandConfig(
        name,
        camel,
        description,
        commands
    )

# Generated at 2022-06-21 13:09:33.089618
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from typing import (
        Dict,
        List,
        NamedTuple,
        Optional,
        Tuple,
        Union,
    )

    from flutils.strutils import (
        dot_to_underscore,
    )

    class SetupCfgCommandTestConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    def _prep_setup_cfg_commands_test_file(
            setup_conf_commands: List[SetupCfgCommandTestConfig]
    ) -> str:
        out: List[str] = [
            "[metadata]",
            "name=my_lib",
        ]

# Generated at 2022-06-21 13:09:39.478534
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "futools"
    camel = "Futools"
    description = "A collection of utility functions"
    commands = ("git tag -a -m 'Tag Built'",
                "git push --tags")

    setupCfgCommandConfig = SetupCfgCommandConfig(name, camel, description, commands)
    assert setupCfgCommandConfig.name == name
    assert setupCfgCommandConfig.camel == camel
    assert setupCfgCommandConfig.description == description
    assert setupCfgCommandConfig.commands == commands


# Generated at 2022-06-21 13:09:51.306020
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def get_setup_cfg_command_name() -> str:
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            if os.path.basename(fs.filename).startswith('test_'):
                name = cast(str, os.path.basename(fs.filename).split('.')[0])
                if name.startswith('test_'):
                    name = name.replace('test_', '')
                name = name.replace('_', '-')
                return name
        return ''

    name = get_setup_cfg_command_name()

    count = 0
    for config in each_sub_command_config():
        if name and config.name != name:
            continue
        count += 1

    assert count > 0

# Generated at 2022-06-21 13:10:01.695001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with TemporaryDirectory(prefix='test_setup_commands_') as dpath:
        setup_dir = os.path.join(dpath, 'project1')
        os.makedirs(setup_dir)
        path = os.path.join(setup_dir, 'setup.py')
        with open(path, 'w') as fp:
            fp.write('from setuptools import setup')
        path = os.path.join(setup_dir, 'setup.cfg')
        with open(path, 'w') as fp:
            fp.write('''\
[metadata]
name = project1
''')
        path = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-21 13:10:11.406272
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    except Exception:
        assert False
    else:
        assert True

    try:
        SetupCfgCommandConfig(None, 'camel', 'description', ('cmd',))
    except Exception:
        assert True

    try:
        SetupCfgCommandConfig('name', None, 'description', ('cmd',))
    except Exception:
        assert True

    try:
        SetupCfgCommandConfig('name', 'camel', None, ('cmd',))
    except Exception:
        assert True

    try:
        SetupCfgCommandConfig('name', 'camel', 'description', None)
    except Exception:
        assert True


# Generated at 2022-06-21 13:10:13.232881
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('cmd', 'Cmd', 'cmd description',
                                 ('command1', 'command2'))

# Generated at 2022-06-21 13:10:15.305904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name', 'Camel', 'description', ('command',)
    )



# Generated at 2022-06-21 13:10:23.548468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _helper(
            setup_dir_arg: Optional[Union[os.PathLike, str]],
            setup_dir_path: str,
            setup_dir_expected: str,
            setup_commands_cfg_path: str,
            setup_commands_cfg_expected: str,
    ) -> None:
        def _mock_get_name(parser, setup_cfg_path):
            if setup_cfg_path == setup_cfg_path_expected:
                return name
            raise Exception('Unexpected path, %r, provided.' % setup_cfg_path)

        name = 'flutils'

        setup_cfg_path_expected = os.path.join(setup_dir_path, 'setup.cfg')

# Generated at 2022-06-21 13:10:28.557069
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            'test_name',
            'TestName',
            'Test Description',
            ('command 1', 'command 2',)
        )
    except Exception as err:
        raise AssertionError from err


# Generated at 2022-06-21 13:11:00.351116
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # no args
    try:
        config = SetupCfgCommandConfig()
    except TypeError as e:
        assert isinstance(e, TypeError)

    # Success
    config = SetupCfgCommandConfig(
        'foo',
        'Foo',
        'bar',
        (
            'baz',
            'qux',
        )
    )
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)
    assert len(config.commands) == 2


# Generated at 2022-06-21 13:11:08.124195
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import os.path as osp
    this_dir = osp.dirname(osp.dirname(__file__))
    sys.path.insert(0, this_dir)

    print("Testing: each_sub_command_config")
    from setup_commands.build_cfg import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    for i, config in enumerate(each_sub_command_config()):
        config = cast(SetupCfgCommandConfig, config)
        print("SetupCfgCommandConfig[%d]: %s = %s" % (
            i + 1,
            config.name,
            config.commands,
        ))



# Generated at 2022-06-21 13:11:15.436217
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('foo', 'bar')
    )

    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('foo', 'bar')

# Generated at 2022-06-21 13:11:26.087953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import path
    from os import mkdir, remove
    from os.path import dirname, abspath, join
    from configparser import ConfigParser

    this_module = abspath(__file__)
    this_dir = dirname(this_module)
    test_dir = join(dirname(this_dir), 'tests')

    # noinspection PyUnresolvedReferences
    parser = ConfigParser()
    # noinspection PyUnresolvedReferences
    parser.read(this_module)
    # noinspection PyUnresolvedReferences
    cfg_path = join(test_dir, 'setup.cfg')
    # noinspection PyUnresolvedReferences
    parser.add_section('setup.command.test_module')
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 13:11:33.335875
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import subprocess
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from nose.tools import eq_ as eq

    with TemporaryDirectory() as d:
        Path(d, 'setup.py').touch()
        Path(d, 'setup.cfg').touch()
        Path(d, 'setup_commands.cfg').touch()

        configs = list(each_sub_command_config(d))
        eq(len(configs), 0)

        configs = list(each_sub_command_config(d))
        eq(len(configs), 0)


# Generated at 2022-06-21 13:11:40.540955
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    config = SetupCfgCommandConfig(
        "some.name",
        "SomeName",
        "Some description.",
        ("some command", "some other command")
    )
    assert repr(config) == "SetupCfgCommandConfig" \
                           "(name='some.name', camel='SomeName', " \
                           "description='Some description.', " \
                           "commands=('some command', 'some other command'))"

# Generated at 2022-06-21 13:11:45.593398
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print('Testing constructor of class SetupCfgCommandConfig')
    config = SetupCfgCommandConfig(
        'foo_bar',
        'FooBar',
        'do something',
        ('cmd1', 'cmd2')
    )
    assert config.name == 'foo_bar'
    assert config.camel == 'FooBar'
    assert config.description == 'do something'
    assert config.commands == ('cmd1', 'cmd2')



# Generated at 2022-06-21 13:11:49.611225
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for scc in each_sub_command_config():
        assert isinstance(scc, SetupCfgCommandConfig)
        print(scc)
        print()


# Generated at 2022-06-21 13:11:55.096687
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = 'config.py'
    desc = 'test description'
    c = SetupCfgCommandConfig('name', 'Camel', desc, (cmd,))
    assert c.name == 'name'
    assert c.camel == 'Camel'
    assert c.description == desc
    assert c.commands == (cmd,)


# Generated at 2022-06-21 13:12:02.236796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_file = os.path.realpath(__file__)
    this_dir = os.path.dirname(this_file)
    test_dir = os.path.join(this_dir, 'tests')
    test_dir = os.path.join(test_dir, 'test_files', 'project')
    test_dir = os.path.realpath(test_dir)
    for config in each_sub_command_config(test_dir):
        print('name:', config.name)
        print('camel:', config.camel)
        print('description:', config.description)
        print('commands:', config.commands)
        print()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:13:03.310364
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from datetime import datetime

    from flutils.pyutils import decode_path

    from . import dirutils

    # This function needs to be called first in order for the test cases to
    # work, because the ``each_sub_command_config()`` function will ask the
    # user to configure the ``setup.cfg`` file and will use the path to this
    # file, which will change the test cases below.

# Generated at 2022-06-21 13:13:16.540369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import chdir, getcwd
    from tempfile import TemporaryDirectory
    from flutils.pathutils import write_file_content

    # Make a temp directory for testing and switch to it.
    with TemporaryDirectory() as tmpdir:
        cwd = getcwd()
        chdir(tmpdir)

        # Setup a config file and change the content of said file.
        config_file = 'setup.cfg'

# Generated at 2022-06-21 13:13:17.508552
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig)



# Generated at 2022-06-21 13:13:21.035749
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name','camel','description',('command',))
    assert setup_cfg_command_config is not None


# Generated at 2022-06-21 13:13:22.687768
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("cmd", "Cmd", "desc", ("a", "b"))



# Generated at 2022-06-21 13:13:26.329284
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='_',
        camel='_',
        description='_',
        commands=('_',)
    )
    assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:13:36.259814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test for each_sub_command_config."""
    this_dir = os.path.abspath(os.path.dirname(__file__))
    commands = tuple(each_sub_command_config(this_dir))
    assert len(commands) == 2
    cmd = commands[0]
    assert cmd.name == 'sub-command-1'
    assert cmd.camel == 'SubCommand1'
    assert cmd.description == 'This is sub-command-1.'
    assert len(cmd.commands) == 2
    cmd = commands[1]
    assert cmd.name == 'sub-command-2'
    assert cmd.camel == 'SubCommand2'
    assert cmd.description == 'This is sub-command-2.'
    assert len(cmd.commands) == 1

# Generated at 2022-06-21 13:13:48.630796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import change_dir
    import subprocess
    from sys import executable
    from tempfile import mkdtemp
    
    with change_dir(os.path.dirname(__file__)):
        tempdir = mkdtemp()
        try:
            _, stderr = subprocess.Popen(
                [
                    executable,
                    'setup.py',
                    'sdist',
                    '--dist-dir', tempdir
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=os.environ.copy()
            ).communicate()
            assert len(list(each_sub_command_config(os.path.dirname(__file__))))
        finally:
            os.rmdir(tempdir)
    
    

# Generated at 2022-06-21 13:13:54.192806
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Arrange
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = ('commands',)

    # Act
    actual = SetupCfgCommandConfig(name, camel, description, commands)

    # Assert
    assert actual.name == name
    assert actual.camel == camel
    assert actual.description == description
    assert actual.commands == commands

# Generated at 2022-06-21 13:13:56.053485
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'b', 'c', ('a', 'b'))