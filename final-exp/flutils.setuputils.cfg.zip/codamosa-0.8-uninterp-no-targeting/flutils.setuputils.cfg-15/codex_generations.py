

# Generated at 2022-06-21 13:06:04.374468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg,'\n')



# Generated at 2022-06-21 13:06:13.341037
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock
    args = Mock()
    args.setup_dir = 'setup.py'
    actual = list(each_sub_command_config(args.setup_dir))
    config = SetupCfgCommandConfig(
        'ci',
        'Ci',
        '',
        ('python3 -m tox -v -n 3 -- -n', 'python3 -m flake8 --count')
    )
    assert actual == [config]
    args.setup_dir = 'setup.py'
    actual = list(each_sub_command_config())
    config = SetupCfgCommandConfig(
        'ci',
        'Ci',
        '',
        ('python3 -m tox -v -n 3 -- -n', 'python3 -m flake8 --count')
    )

# Generated at 2022-06-21 13:06:13.934391
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:06:19.646963
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.setuputils import SetupCfgCommandConfig

    setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd',))
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'desc'
    assert setup_cfg_command_config.commands == ('cmd',)



# Generated at 2022-06-21 13:06:30.661860
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from pprint import pprint

    with tempfile.NamedTemporaryFile() as temp:
        temp.write("""[metadata]
name = project1""".encode('utf-8'))
        temp.flush()
        for conf in each_sub_command_config(temp.name):
            pprint(conf)

    with tempfile.TemporaryDirectory() as temp:
        temp = str(temp)
        with open(os.path.join(temp, 'setup.py'), 'w'):
            pass
        with open(os.path.join(temp, 'setup.cfg'), 'w') as config:
            config.write("""[metadata]
name = project1""")
            config.flush()

# Generated at 2022-06-21 13:06:40.643452
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    setup_cfg = '''\
[metadata]
name = flutils_test
'''
    setup_commands_cfg = '''\
[setup.command.test]
command = test command
commands =
    test command 1
    test command 2
'''
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('setup.cfg', 'w') as fp:
            fp.write(setup_cfg)
        with open('setup_commands.cfg', 'w') as fp:
            fp.write(setup_commands_cfg)
        for config in each_sub_command_config():
            assert config.name == 'test'
            assert config.camel == 'Test'
            assert config.comm

# Generated at 2022-06-21 13:06:50.873581
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_cfg = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-21 13:07:00.494882
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pkg_resources import (
        working_set,
        require
    )
    base_dir = working_set.find(require('flutils')[0]).location
    base_dir = os.path.join(base_dir, 'flutils')
    for config in each_sub_command_config(base_dir):
        config = cast(SetupCfgCommandConfig, config)
        assert config.name is not None
        assert config.name

        assert config.camel is not None
        assert config.camel

        assert config.description is not None
        assert config.description

        assert config.commands is not None
        assert config.commands
        for cmd in config.commands:
            assert cmd is not None
            assert cmd

# Generated at 2022-06-21 13:07:12.385708
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    command_list = [
        SetupCfgCommandConfig('command_one', 'CommandOne',
                              'The command one description.',
                              ('Command One',)),
        SetupCfgCommandConfig('command_two', 'CommandTwo',
                              'The command two description.',
                              ('Command Two',)),
    ]
    with tempfile.TemporaryDirectory() as tempdir:
        setup_cfg_path = os.path.join(tempdir, 'setup.cfg')

# Generated at 2022-06-21 13:07:22.749071
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_dir = os.path.dirname(
        os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )
    )
    root_dir = os.path.join(root_dir, 'tests')
    root_dir = os.path.join(root_dir, 'test_contributing')
    root_dir = os.path.join(root_dir, 'pkg_1')
    for value in each_sub_command_config(root_dir):
        print(value)
    print('-' * 90)

    from flutils.testutils import random_string
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        setup_cfg_path = os.path.join(td, 'setup.cfg')
       

# Generated at 2022-06-21 13:07:48.703696
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    from os.path import dirname, join

    from flutils.pathutils import each_parent_dir

    for parent in each_parent_dir(dirname(sys.argv[0])):
        path = join(parent, 'setup.py')
        if os.path.isfile(path):
            break
    else:
        raise FileNotFoundError(
            'Unable to find the directory containing the setup.py file.'
        )

    path = join(parent, 'setup.cfg')
    if os.path.isfile(path) is False:
        raise FileNotFoundError(
            'Unable to find the setup.cfg file in %r.' % dirname(path)
        )

    parser = ConfigParser()

# Generated at 2022-06-21 13:07:59.950598
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='Description',
        commands=('command1', 'command2'),
    )
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'Camel'
    assert setup_cfg_command_config.description == 'Description'
    assert len(setup_cfg_command_config.commands) == 2
    assert setup_cfg_command_config.commands[0] == 'command1'
    assert setup_cfg_command_config.commands[1] == 'command2'


# Generated at 2022-06-21 13:08:01.933040
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('a', 'b')
    ) is not None



# Generated at 2022-06-21 13:08:03.191827
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig)

    

# Generated at 2022-06-21 13:08:07.236028
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        cmd_config = SetupCfgCommandConfig('lala', 'lala', '', (''))
    except Exception as err:
        raise AssertionError(err)


# Generated at 2022-06-21 13:08:11.896205
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_path = os.path.abspath('.')
    for x in each_sub_command_config(setup_path):
        assert x.name
        assert x.camel
        assert x.description
        assert len(x.commands) > 0
    assert True

# Generated at 2022-06-21 13:08:15.927252
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils import logutils
    logutils.init_logger(logging.DEBUG)
    for config in each_sub_command_config('/Users/Jason/do/code/python/pypi-publish'):
        pass

# Generated at 2022-06-21 13:08:18.067180
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    pprint(list(each_sub_command_config()))



# Generated at 2022-06-21 13:08:22.932077
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    config = SetupCfgCommandConfig(
        name = _get_name(parser, 'setup.cfg'),
        camel = _get_name(parser, 'setup.cfg'),
        description = 'description',
        commands = ('a', 'b', 'c')
    )
    assert config.name == 'sqlemt'
    assert config.camel == 'sqlemt'
    assert config.description == 'description'
    assert config.commands == ('a', 'b', 'c')


# Generated at 2022-06-21 13:08:24.384109
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('setup.command.test', 'Test', 'Test setup command.', ('python setup.py test',))

# Generated at 2022-06-21 13:08:49.243411
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _environ = os.environ.copy()
    os.environ.clear()

# Generated at 2022-06-21 13:08:53.252043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config(
        os.path.dirname(os.path.dirname(__file__))
    ))
    assert len(cmds) == 1
    assert cmds[0].name == 'test'

# Generated at 2022-06-21 13:08:55.420798
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for idx, config in enumerate(each_sub_command_config()):
        print(idx, config)

# Generated at 2022-06-21 13:08:59.007691
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('cmd',)
    )



# Generated at 2022-06-21 13:09:00.348759
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class SetupConfigCommandConfig(SetupCfgCommandConfig):
        pass



# Generated at 2022-06-21 13:09:08.548343
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup_commands.cfg')
    setup_dir = os.path.expanduser('~')
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': setup_dir
    }
    format_kwargs['name'] = _get_name(parser, 'setup_commands.cfg')
    for config in _each_setup_cfg_command(parser, format_kwargs):
        print(config)



# Generated at 2022-06-21 13:09:10.170703
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    pprint.pprint(list(each_sub_command_config()))



# Generated at 2022-06-21 13:09:15.531591
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'my_command'
    camel = 'MyCommand'
    description = 'A description of my command'
    commands = ['the command']
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-21 13:09:25.528825
# Unit test for function each_sub_command_config

# Generated at 2022-06-21 13:09:30.250424
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(name='str', camel='str', description='str', commands=tuple(str))
    assert cfg.name == 'str'
    assert cfg.camel == 'str'
    assert cfg.description == 'str'
    assert type(cfg.commands) == type(tuple())

# Generated at 2022-06-21 13:09:57.839631
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name='mycommand', camel='MyCommand', description='', commands=())

    assert config.name == 'mycommand'
    assert config.camel == 'MyCommand'
    assert config.description == ''
    assert config.commands == ()



# Generated at 2022-06-21 13:10:01.392903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for out in each_sub_command_config(setup_dir='./tests/fixtures/setup_cfg'):
        print(out)

# Generated at 2022-06-21 13:10:11.980462
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            1,
            'camelcased',
            'command description',
            (
                 'command string',
            )
        )
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            'command_name',
            1,
            'command description',
            (
                 'command string',
            )
        )
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            'command_name',
            'camelcased',
            1,
            (
                 'command string',
            )
        )

# Generated at 2022-06-21 13:10:21.092184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(arg: str, expect: Tuple[str, ...]):
        gen = each_sub_command_config(arg)
        got: Tuple[str, ...] = tuple(map(lambda x: x.name, gen))
        assert got == expect

    with tempfile.TemporaryDirectory() as temp_dir:
        name = 'test_each_sub_command_config_name_'
        setup_cfg = '''[metadata]
name = {name}
'''

# Generated at 2022-06-21 13:10:34.015656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib
    import pytest
    from flutils.pathutils import dirname_of_file

    dir1 = os.path.join(dirname_of_file(__file__), 'data', 'setup1')
    dir2 = os.path.join(dirname_of_file(__file__), 'data', 'setup2')
    dir3 = os.path.join(dirname_of_file(__file__), 'data', 'setup3')
    dir4 = os.path.join(dirname_of_file(__file__), 'data', 'setup4')

    assert dir1 == os.path.realpath(dir1)
    assert dir2 == os.path.realpath(dir2)

    for d in dir1, dir2:
        assert os.path.isdir(d)

# Generated at 2022-06-21 13:10:41.673525
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c1 = SetupCfgCommandConfig('name', 'camel', 'description', ('commmands',))
    c2 = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commmands',)
    )
    c3 = SetupCfgCommandConfig('name1', 'camel', 'description', ('commmands',))
    eq_(c1, c2)
    eq_(c2, c3)
    assert c1.name == 'name'
    assert c1.camel == 'camel'
    assert c1.description == 'description'
    assert c1.commands == ('commmands',)
    assert hash(c1) == hash(c2)
    assert hash(c1) == hash(c3)
    assert repr(c1) == repr(c2)

# Generated at 2022-06-21 13:10:46.221729
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import temp_dir

    cwd = os.getcwd()
    with temp_dir(prefix='', suffix='') as temp_path:
        os.chdir(temp_path)

        # Create the setup.py file
        with open('setup.py', 'w') as fl:
            fl.write("""
from setuptools import setup

setup(
    name='package'
)
""")

        # Create the setup.cfg file
        with open('setup.cfg', 'w') as fl:
            fl.write("""
[metadata]
name = project
""")

        # Create the setup_commands.cfg file

# Generated at 2022-06-21 13:10:54.312300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=protected-access
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, 'testdata', 'setup-dir')
    items = list(each_sub_command_config(test_dir))
    assert len(items) == 3, items
    assert items[0] == SetupCfgCommandConfig(
        'compilemessages',
        'Compilemessages',
        'Compiles all message catalogs.',
        ('python setup.py compilemessages',)
    )

# Generated at 2022-06-21 13:11:01.093241
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig(): # noqa: WPS231
    name = 'foo'
    camel = 'Foo'
    description = 'Foo description'
    commands = ['foo', 'bar']

    setupCfgCommandConfig = SetupCfgCommandConfig(  # noqa: WPS211
        name, camel, description, commands)
    assert setupCfgCommandConfig.name == name
    assert setupCfgCommandConfig.camel == camel
    assert setupCfgCommandConfig.description == description
    assert setupCfgCommandConfig.commands == tuple(commands)

# Generated at 2022-06-21 13:11:08.923833
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _validate_config(
            path: str,
            command_name: str,
            command_camel_name: str,
            entry_point: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        config = list(each_sub_command_config(path))[0]
        assert config.name == command_name
        assert config.camel == command_camel_name
        assert config.description == description
        assert config.commands == commands

    this_dir = os.path.dirname(__file__)
    setup_config_dir = os.path.join(this_dir, 'setup_config')
    pytest_setup_config_dir = os.path.join(this_dir, 'pytest_setup_config')
    with_setup_

# Generated at 2022-06-21 13:11:59.724674
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'a', 'b', 'c', ('d', 'e')
    )
    assert command.name == 'a'
    assert command.camel == 'b'
    assert command.description == 'c'
    assert command.commands == ('d', 'e')

# Generated at 2022-06-21 13:12:07.685648
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import json
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        _setup_cfg = """
        [metadata]
        name = test

        [setup.command.my_command]
        command =
        {name} {name} {name}

        [setup.command.another_command]
        command =
        {name} {name} {name}

        [setup.command.third_command]
        command =
        {name} {name} {name}
        """


# Generated at 2022-06-21 13:12:13.978279
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class Util:
        @classmethod
        def each_sub_command_config(cls, *args, **kwargs):
            return []
    old = each_sub_command_config
    each_sub_command_config = Util.each_sub_command_config
    try:
        output_list = [x for x in each_sub_command_config()]
    finally:
        each_sub_command_config = old
    assert output_list == []



# Generated at 2022-06-21 13:12:20.975155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config(
        os.path.join(os.path.dirname(__file__), '../..')
    ))
    assert len(cmds) == 3
    assert len(cmds[0].commands) == 1
    assert '-m pipenv.cli' in cmds[0].commands[0]
    assert len(cmds[1].commands) == 1
    assert 'pytest' in cmds[1].commands[0]
    assert len(cmds[2].commands) == 1
    assert 'pytest' in cmds[2].commands[0]

# vim:set ts=8 sw=4 sts=4 tw=78 et:

# Generated at 2022-06-21 13:12:29.385610
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.pathutils import abs_path
    from os.path import join, sep
    setup_dir = abs_path(join('tests', 'unit', 'sample_project'))
    for config in each_sub_command_config(setup_dir):
        if config.name == 'clean.build':
            assert config.camel == 'CleanBuild'
            assert config.description == ''
            assert config.commands \
                == ("rm -rf build{sep}".format(sep=sep),
                    "rm -rf dist{sep}".format(sep=sep))
        if config.name == 'clean.dist':
            assert config.camel == 'CleanDist'
            assert config.description == ''

# Generated at 2022-06-21 13:12:39.613177
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory

    from flutils.datautils import random_str

    # Setup files ------------------------------------------------------------
    with TemporaryDirectory(prefix='temp_setup_dir_') as td:
        setup_dir = os.path.abspath(td)
        os.makedirs(os.path.join(setup_dir, 'docs'))
        setup_py = os.path.join(setup_dir, 'setup.py')
        with open(setup_py, 'w') as fh:
            fh.write('import setuptools\n\n')
            fh.write('setuptools.setup(\n')
            fh.write('    name="sample",\n')
            fh.write('    version="0.1.0",\n')

# Generated at 2022-06-21 13:12:42.558966
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    try:
        os.chdir(cur_dir)
        list(each_sub_command_config())
    finally:
        os.chdir(cwd)

# Generated at 2022-06-21 13:12:54.126036
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_cfg_contents = """
[metadata]
name = tmpdir
"""
        open(os.path.join(tmpdir, 'setup.py'), 'w').close()
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)
        list(each_sub_command_config(tmpdir))
        setup_cfg_contents += """
[setup.command.build]
command = python setup.py build

[setup.command.test]
command = pytest
"""
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)

# Generated at 2022-06-21 13:12:55.369585
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig

# Generated at 2022-06-21 13:12:58.603165
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('a', 'b', 'c', ('d',))
    except Exception as e:
        print(f'An error occurred when instantiating '
              f'SetupCfgCommandConfig: {e}')