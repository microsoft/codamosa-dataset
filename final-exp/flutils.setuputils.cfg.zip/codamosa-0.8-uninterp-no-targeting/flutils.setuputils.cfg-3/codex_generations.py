

# Generated at 2022-06-21 13:06:09.735551
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    command = SetupCfgCommandConfig("UnitTest", "UnitTest", "UnitTest Description", ("UnitTest", ))
    assert command.name == "UnitTest"
    assert command.camel == "UnitTest"
    assert command.description == "UnitTest Description"
    assert command.commands == ("UnitTest",)

test_counter = 0


# Generated at 2022-06-21 13:06:14.275227
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'Test Description'
    commands = (
        'echo "hello world!"',
        'echo "testing!!!"',
        'echo "testing again!!!"',
    )

    cfg = SetupCfgCommandConfig(name, camel, description, commands)
    assert cfg.name == name
    assert cfg.camel == camel
    assert cfg.description == description
    assert cfg.commands == commands



# Generated at 2022-06-21 13:06:24.789659
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import shutil
    import tempfile

    # Test Setup Cfg
    setup_cfg = """
[metadata]
name = My Test Project

[setup.command.test]
command = make test

[setup.command.check]
command = make check

[setup.command.check]
command = make dist

[setup.command.check]
commands =
    make check
    make dist

[setup.command.check]
name = test
description = Test command
commands =
    make check
    make dist
    make test
"""

    # Test Setup Cfg

# Generated at 2022-06-21 13:06:30.149410
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('',)) == \
           SetupCfgCommandConfig._make(['name', 'Camel', 'description', ('',)])
    assert SetupCfgCommandConfig._make(('name', 'Camel', 'description', ('',))) == \
           SetupCfgCommandConfig._make(('name', 'Camel', 'description', ('',)))

# Generated at 2022-06-21 13:06:40.216513
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Can handle missing section.
    parser = ConfigParser()
    parser.read('setup.cfg')
    kwargs = {}
    kwargs['setup_dir'] = _prep_setup_dir(_prep_setup_dir())
    kwargs['name'] = _get_name(parser, 'setup.cfg')
    assert list(_each_setup_cfg_command(parser, kwargs)) == []

    # Can handle missing options.
    parser = ConfigParser()
    parser.add_section('setup.command.version')
    assert list(_each_setup_cfg_command(parser, kwargs)) == []

    # Can handle unknown option.
    parser = ConfigParser()
    parser.add_section('setup.command.version')
    parser.set('setup.command.version', 'foo', 'bar')

# Generated at 2022-06-21 13:06:41.691118
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        print(sub_command)


"""DisabledContent
"""

# Generated at 2022-06-21 13:06:46.268609
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'name',
        'camel',
        'desc',
        ('a', 'b')
    )
    assert command.name == 'name'
    assert command.camel == 'camel'
    assert command.description == 'desc'
    assert command.commands == ('a', 'b')

# Generated at 2022-06-21 13:06:56.821331
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit testing for the function each_sub_command_config."""
    import sys
    import unittest

    class SetupCfgCommandConfigTests(unittest.TestCase):
        def test_setup_cfg_command_config(self):
            setup_dir = os.path.dirname(
                os.path.dirname(os.path.dirname(__file__))
            )
            for config in each_sub_command_config(setup_dir):
                self.assertTrue(isinstance(config.name, str))
                self.assertTrue(isinstance(config.camel, str))
                self.assertTrue(isinstance(config.description, str))
                self.assertTrue(isinstance(config.commands, tuple))

# Generated at 2022-06-21 13:07:04.207211
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_type in ('overridden', 'common'):
        out = list(each_sub_command_config(setup_dir='test/{}'.format(setup_type)))
        assert out == [
            SetupCfgCommandConfig(
                'build',
                'Build',
                'Builds the project',
                ('python setup.py build',)
            ),
            SetupCfgCommandConfig(
                'develop',
                'Develop',
                'Installs the project in development mode.',
                ('python setup.py develop',)
            ),
            SetupCfgCommandConfig(
                'install',
                'Install',
                'Installs the project.',
                ('python setup.py install',)
            ),
        ]



# Generated at 2022-06-21 13:07:08.214627
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for scc in each_sub_command_config():
        assert scc.name is not None
        assert scc.camel is not None
        assert scc.description is not None
        assert scc.commands is not None

# Generated at 2022-06-21 13:07:31.165993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    from contextlib import ExitStack
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from textwrap import dedent

    from flutils.functional import extend_iter

    from pytest import raises

    def _create_minimal_setup_cfg(
            temp_dir: Path,
            name: str = 'foobar'
    ):
        with open(temp_dir / 'setup.cfg', 'w') as fp:
            fp.write(dedent("""\
            [metadata]
            name = {name}\
            """).format(name=name))

    def _create_sub_commands_cfg(
            temp_dir: Path,
            commands: List[Tuple[
                Tuple[str, ...], Optional[str], Optional[str]
            ]],
    ):
        lines: List[str]

# Generated at 2022-06-21 13:07:38.109657
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='test_name',
        camel='test_Camel',
        description='test_Description',
        commands=('test_Command1', 'test_Command2')
    )
    assert obj.name == 'test_name'
    assert obj.camel == 'TestCamel'
    assert obj.description == 'test_Description'
    assert obj.commands == ('test_Command1', 'test_Command2')

# Generated at 2022-06-21 13:07:47.407319
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def get_configs(setup_path):
        return tuple(each_sub_command_config(setup_path))

    assert get_configs(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fixtures', 'sub_command'
    )) == (
        SetupCfgCommandConfig('sub_command.bad', 'SubCommandBad',
                              'Bad Sub-Command', ('cmd1', 'cmd2')),
        SetupCfgCommandConfig('sub_command.good', 'SubCommandGood',
                              'Good Sub-Command', ('cmd1', 'cmd2')),
    )

# Generated at 2022-06-21 13:07:54.357492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testingutils import unit_test_module
    from flutils.pathutils import temp_dir

    with temp_dir() as tdir:
        tdir = str(tdir)
        with open(os.path.join(tdir, 'setup_commands.cfg'), 'w') as fp:
            fp.write(
                '\n'.join((
                    '[setup.command.my_command]',
                    'commands=',
                    '      echo "hello {setup_dir} {home}"',
                    '      echo "goodbye {setup_dir} {home}"',
                ))
            )

# Generated at 2022-06-21 13:07:58.766861
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert(SetupCfgCommandConfig(
        'rename',
        'Rename',
        'Renames the setup.py file.',
        ('mv {setup_dir}/setup.py {setup_dir}/setup.py.bak',)
    ) is not None)



# Generated at 2022-06-21 13:08:03.762740
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cmd = SetupCfgCommandConfig(
        name='foo.bar',
        camel='FooBar',
        description='foo bar',
        commands=('echo foo', 'echo bar')
    )
    assert setup_cmd.name == 'foo.bar'
    assert setup_cmd.camel == 'FooBar'
    assert setup_cmd.description == 'foo bar'
    assert setup_cmd.commands == ('echo foo', 'echo bar')



# Generated at 2022-06-21 13:08:16.586558
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase

    class SetupCfgCommandConfigTest(TestCase):
        """Unit test for constructor of class SetupCfgCommandConfig."""

        def setUp(self):
            self._test_dir = os.path.dirname(__file__)
            self._fixtures_dir = os.path.join(self._test_dir, 'fixtures')

        def test_setup_command_in_setup_cfg(self):
            """Unit test SetupCfgCommandConfig with 'setup.command'
            in 'setup.cfg'.
            """
            scc = SetupCfgCommandConfig('do_this', 'DoThis', '', ('',))
            self.assertEqual(scc.name, 'do_this')
            self.assertEqual(scc.camel, 'DoThis')
            self.assertE

# Generated at 2022-06-21 13:08:18.317254
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'camel', 'desc', ('a', 'b'))

# Generated at 2022-06-21 13:08:19.705890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for e in each_sub_command_config('../../bin/templates'):
        print(e)

# Generated at 2022-06-21 13:08:22.837245
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    import contextlib
    with contextlib.suppress(FileNotFoundError):
        for config in each_sub_command_config():
            pass

# Generated at 2022-06-21 13:08:41.661601
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test', 'Test', '', ('test command',))
    assert isinstance(config, SetupCfgCommandConfig)


# Generated at 2022-06-21 13:08:43.536769
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    count = 0
    for _ in each_sub_command_config():
        count += 1
    assert count > 0

# Generated at 2022-06-21 13:08:51.564199
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pathlib
    from flutils.pyutils import modify_path
    from tempfile import (
        TemporaryDirectory,
        gettempdir
    )
    from unittest import TestCase

    class TestSetupCfgCommandConfig(TestCase):

        def setUp(self):
            self.tempdir = TemporaryDirectory()
            self.addCleanup(self.tempdir.cleanup)

        def test__format_kwargs(self):
            tempdir = self.tempdir
            with modify_path():
                os.environ['HOME'] = gettempdir()
                setup_dir = os.path.join(tempdir.name, 'test_pkg')
                path = os.path.join(setup_dir, 'setup.cfg')
                os.mkdir(setup_dir)

# Generated at 2022-06-21 13:09:02.713628
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import json
    import flutils.setuputils

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 13:09:07.047942
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import patch

    with patch.object(SysUtils, 'is_main', return_value=True):
        for _ in each_sub_command_config(os.path.realpath(
                os.path.join(os.path.dirname(__file__), '..', '..'))
        ):
            pass

# Generated at 2022-06-21 13:09:12.698477
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    name = 'test'
    camel = 'Test'
    description = 'test description'
    commands = ('test 1', 'test 2', 'test 3')
    conf = SetupCfgCommandConfig(name, camel, description, commands)
    assert(conf.name == name)
    assert(conf.camel == camel)
    assert(conf.description == description)
    assert(conf.commands == commands)

# Generated at 2022-06-21 13:09:14.532675
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    desc = 'Description'
    commands = ('command1', 'command2')
    args = [name, camel, desc, commands]
    cfg = SetupCfgCommandConfig(*args)
    assert tuple(cfg) == args

# Generated at 2022-06-21 13:09:18.032672
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(
        os.path.join(os.path.dirname(__file__), '..', '..')
    ):
        print(config)

# Generated at 2022-06-21 13:09:19.576193
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig.__doc__



# Generated at 2022-06-21 13:09:21.839030
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(name='test', camel='test', description='test', commands=())


# Generated at 2022-06-21 13:09:50.336683
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(name="hello", camel="Hello", description="Hello World", commands=("Hello", "goodbye"))

# Generated at 2022-06-21 13:09:54.190895
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert(isinstance(out, list))
    assert(len(out))
    assert(isinstance(out[0], SetupCfgCommandConfig))
    assert(isinstance(out[0].commands, tuple))
    assert(isinstance(out[0].commands[0], str))

# Generated at 2022-06-21 13:10:05.820952
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import pprint

    d = tempfile.mkdtemp()
    with open(os.path.join(d, 'setup.py'), 'w') as f:
        f.write('''\
#!/usr/bin/env python
"""This is a fake setup.py file for testing."""
from setuptools import setup

setup()
''')
    setup_cfg = os.path.join(d, 'setup.cfg')
    with open(setup_cfg, 'w') as f:
        f.write('''\
[metadata]
name = foo

[setup.command.foo]
commands =
    echo {name}

[setup.command.bar]
commands =
    echo {name}
''')

# Generated at 2022-06-21 13:10:08.090755
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    o = SetupCfgCommandConfig(
        "command_name",
        "CommandName",
        "This is a command description.",
        ("cmd1", "cmd2")
    )
    assert o.name == "command_name"
    assert o.camel == "CommandName"
    assert o.description == "This is a command description."
    assert o.commands == ("cmd1", "cmd2")

# Generated at 2022-06-21 13:10:18.132464
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    from flutils.setuputils import (
        each_sub_command_config,
        setup_command_config_section,
    )

    class SubCommandConfigTest(unittest.TestCase):

        def test_each_sub_command_config(self):
            file_path = os.path.realpath(__file__)
            self.assertIsNotNone(file_path)
            test_dir = os.path.dirname(file_path)
            self.assertIsNotNone(test_dir)
            setup_cfg_path = os.path.join(test_dir, 'setup.cfg')
            self.assertIsNotNone(setup_cfg_path)
            self.assertTrue(os.path.isfile(setup_cfg_path))


# Generated at 2022-06-21 13:10:21.385781
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sub_cmd = SetupCfgCommandConfig('name', 'camel',
                                    'description', ('commands',))
    assert sub_cmd.name == 'name'
    assert sub_cmd.camel == 'camel'
    assert sub_cmd.description == 'description'
    assert sub_cmd.commands == ('commands',)


# Generated at 2022-06-21 13:10:34.296883
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    my_setup_dir = os.path.dirname(__file__)
    assert os.path.isdir(my_setup_dir) is True
    assert os.path.isfile(os.path.join(my_setup_dir, 'setup.py')) is True
    assert os.path.isfile(os.path.join(my_setup_dir, 'setup.cfg')) is True
    my_setup_dir = os.path.realpath(my_setup_dir)
    for cfg in each_sub_command_config(my_setup_dir):
        assert isinstance(cfg, SetupCfgCommandConfig)
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)

# Generated at 2022-06-21 13:10:36.631258
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='dir_name',
        camel='DirName',
        description='description',
        commands=('touch file1', 'touch file2')
    )

# Generated at 2022-06-21 13:10:48.864651
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.pathutils import each_parent_dir
    for p in each_parent_dir(Path(__file__)):
        if (p / 'setup.py').exists() and (p / 'setup.cfg').exists():
            break
    else:
        raise FileNotFoundError("Unable to find setup.py or setup.cfg.")

    configs = list(
        each_sub_command_config(
            p.as_posix()
        )
    )
    assert len(configs) == 3
    assert configs[0].name == 'test'
    assert configs[0].camel == 'Test'
    assert configs[0].description == 'Runs all the unit tests.'

# Generated at 2022-06-21 13:11:00.199938
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import textwrap
    setup_cfg = textwrap.dedent(
        """
        [metadata]
        name = pkgname
        description = description
        
        [setup.command.command]
        name = command
        description = description
        command = command
        
        [setup.command.commands]
        description = description
        commands =
          command1
          command2
        
        [setup.command.command.nested]
        description = description
        commands =
          command1
          command2
        """
    )
    setup_cfg_path = os.path.join('.', 'setup.cfg')
    with open(setup_cfg_path, 'w') as f:
        f.write(setup_cfg)

# Generated at 2022-06-21 13:11:31.445237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    from flutils.projectutils import (
        each_sub_command_config,
        get_project_name,
    )

    setup_dir = os.path.dirname(os.path.realpath(__file__))
    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) == 3
    assert configs[0].name == 'projectutils.sub'
    assert configs[0].camel == 'Sub'
    assert configs[0].description == 'sub command'
    assert configs[0].commands == ('echo hi',)
    assert configs[1].name == 'projectutils.sub2'
    assert configs[1].camel == 'Sub2'
    assert configs[1].description == 'sub command 2'
    assert configs

# Generated at 2022-06-21 13:11:42.620819
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    lst: List[str] = []
    for cc in each_sub_command_config():
        lst.append(cc.camel)
    lst.sort()
    assert lst == [
        'BuildDocs',
        'Check',
        'Dev',
        'Dist',
        'Egg',
        'Install',
        'RPM',
        'Sdist',
        'Test',
        'TestCoverage',
        'TestDocs',
        'TestPyLint',
        'TestPyLintExtras',
        'TestPyLintExtras',
        'TestPyLintExtras',
        'TestReadme',
        'TestSetupPy',
        'TestUser',
        'TestUser2',
        'Wheel'
    ]

# Generated at 2022-06-21 13:11:44.378087
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', ))

# Generated at 2022-06-21 13:11:52.047103
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sc_cc = SetupCfgCommandConfig(
        name='hello_world',
        camel='HelloWorld',
        description='Hello World!',
        commands=('python -m hello_world',)
    )
    assert sc_cc.name == 'hello_world'
    assert sc_cc.camel == 'HelloWorld'
    assert sc_cc.description == 'Hello World!'
    assert sc_cc.commands[0] == 'python -m hello_world'

# Generated at 2022-06-21 13:11:54.569342
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _ = SetupCfgCommandConfig(name="foo", camel="Foo", description="bar", commands=('baz',))

# Generated at 2022-06-21 13:12:00.148339
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        "setup.command.command_name",
        "CommandName",
        "A command description.",
        ("sub_command1",)
    )
    assert config.name == "setup.command.command_name"
    assert config.camel == "CommandName"
    assert config.description == "A command description."
    assert config.commands == ("sub_command1",)

# Unit tests for _each_setup_cfg_command_section()

# Generated at 2022-06-21 13:12:03.256891
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'example'
    description = 'Example description'
    commands = ('echo "example command",',)
    actual = SetupCfgCommandConfig(name, name.title(), description, commands)
    expected = (name, name.title(), description, commands)
    assert actual == expected

# Generated at 2022-06-21 13:12:07.667386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the ``each_sub_command_config`` function."""
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(setup_dir, '..', '..', '..')
    for ss in each_sub_command_config(setup_dir):
        ss

# Generated at 2022-06-21 13:12:12.611066
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    out = next(each_sub_command_config(cwd))
    assert type(out) is SetupCfgCommandConfig

if __name__ == '__main__':
    print('Testing setup_commands...')
    test_each_sub_command_config()
    print('setup_commands is working.')

# Generated at 2022-06-21 13:12:16.632973
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    lines = set()
    for sub_command in each_sub_command_config():
        if sub_command.camel is None:
            continue
        lines.add(sub_command.camel)
    assert 'Package' in lines
    assert 'Test' in lines
    assert 'Clean' in lines
    assert 'Lint' in lines

# Generated at 2022-06-21 13:13:22.434140
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    CALLER_DIR = os.path.dirname(__file__)
    UNIT_TEST_DIR = os.path.join(
        CALLER_DIR,
        'setupcfgfrompython',
        'tests',
        'unit_tests'
    )
    FUNCTION_DIR = os.path.join(UNIT_TEST_DIR, 'unit_test_each_sub_command_config')
    PATH_TO_SETUP_CFG_1 = os.path.join(FUNCTION_DIR, '1', 'setup.cfg')
    PATH_TO_SETUP_CFG_2 = os.path.join(FUNCTION_DIR, '2', 'setup.cfg')

# Generated at 2022-06-21 13:13:32.098098
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import path
    from os import getcwd
    from os.path import dirname
    dir_ = dirname(dirname(__file__))
    if dir_ not in path:
        path.append(dir_)
    cwd = getcwd()
    os.chdir(dir_)
    try:
        configs = list(each_sub_command_config())
    finally:
        os.chdir(cwd)
    assert configs
    config = configs[0]
    assert config.name
    assert config.camel
    assert config.description
    assert config.commands

# Generated at 2022-06-21 13:13:42.813003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_path = os.path.abspath(os.path.dirname(__file__))
    setup_path = os.path.join(base_path, '..')

    def _test_each_sub_command_config(project_id: str):
        project_path = os.path.join(setup_path, project_id)

        results: List[Tuple[str, str]] = [
            (config.name, config.commands[0])
            for config in each_sub_command_config(project_path)
        ]
        expected = [
            ('spam', 'echo spam'),
            ('eggs', 'echo spam spam spam'),
        ]
        assert results == expected

    _test_each_sub_command_config('flutils')

# Generated at 2022-06-21 13:13:50.328491
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert sum(
        1 for _ in each_sub_command_config('test')
    ) == 1
    assert sum(
        1 for _ in each_sub_command_config('test/data/test_service')
    ) == 3
    assert sum(
        1 for _ in each_sub_command_config('test/data/test_package')
    ) == 4
    assert sum(
        1 for _ in each_sub_command_config('test/data/test_package_setup_commands_cfg')
    ) == 4

# Generated at 2022-06-21 13:13:52.269855
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # noinspection PyTypeChecker
    SetupCfgCommandConfig('', '', '', ())

# Generated at 2022-06-21 13:14:00.413120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.config import setup_cfg

    g = each_sub_command_config(setup_cfg)
    sub_cmd = next(g)
    assert isinstance(sub_cmd, SetupCfgCommandConfig)
    assert sub_cmd.name == 'mycmd'
    assert sub_cmd.camel == 'Mycmd'
    assert sub_cmd.description == ''
    assert sub_cmd.commands == ('echo "Hello"',)

    sub_cmd = next(g)
    assert isinstance(sub_cmd, SetupCfgCommandConfig)
    assert sub_cmd.name == 'mycmd2'
    assert sub_cmd.camel == 'Mycmd2'
    assert sub_cmd.description == 'Description for mycmd2.'
    assert sub_cmd.commands == ('echo "Hello again"',)

    sub_cmd

# Generated at 2022-06-21 13:14:02.452719
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('', '', '', ()) == SetupCfgCommandConfig('', '', '', ())

# Generated at 2022-06-21 13:14:04.891461
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for each_sub_command_config."""
    for i in each_sub_command_config():
        print(i)

# Generated at 2022-06-21 13:14:09.740322
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    print(configs)
    assert configs
    assert configs[0].name == 'test_cmd'
    assert configs[0].description == 'A test command'
    assert configs[0].commands == ('helpers --test-arg=bar',)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:14:20.725737
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from pathlib import Path
    configs = list(each_sub_command_config(
        setup_dir=str(Path(__file__).parent.parent.parent)
    ))
    assert configs[0].name == 'integration_test'
    assert configs[0].camel == 'IntegrationTest'
    assert configs[0].commands == ('pytest tests/integration',)

    def _get_name(parser: ConfigParser, setup_cfg_path: str) -> str:
        assert (setup_cfg_path ==
                str(Path(__file__).parent.parent.parent / 'setup.cfg'))
        return 'unittest'


# Generated at 2022-06-21 13:15:26.711615
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('name', 'camel', 'description', ('command1',))
    assert cfg.name == 'name'
    assert cfg.camel == 'camel'
    assert cfg.description == 'description'
    assert cfg.commands == ('command1',)

# Generated at 2022-06-21 13:15:33.687433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from typing import Tuple

    from flutils.pathutils import find_paths_in_dir
    from flutils.setuputils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    def _expect_results(
            paths: Tuple[str, ...],
            setup_cfg_path: str
    ) -> None:
        for path in paths:
            basename = os.path.basename(path)
            if basename == 'setup.py':
                setup_dir = os.path.dirname(path)
                break
        else:
            raise ValueError(
                "Unable to find the directory that contains the 'setup.py' "
                "file."
            )

# Generated at 2022-06-21 13:15:36.053490
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    record = SetupCfgCommandConfig(
        "name",
        "Camel",
        "description",
        ("value1", "value2")
    )
    assert record.name == "name"
    assert record.camel == "Camel"
    assert record.description == "description"
    assert record.commands == ("value1", "value2")

# Generated at 2022-06-21 13:15:46.651823
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import BytesIO
    from textwrap import dedent

    out = BytesIO()
    p = ConfigParser()
    p.add_section('metadata')
    p.set('metadata', 'name', 'flutils')

    p.add_section('setup.command.test')
    p.set('setup.command.test', 'description', 'Test command')
    p.set('setup.command.test', 'commands',
          dedent('''
                pytest --cov={name} --cov-report=term-missing
                ''').strip()
          )

    p.add_section('setup.command.build_sphinx')
    p.set('setup.command.build_sphinx', 'description', 'Build sphinx docs')