

# Generated at 2022-06-21 13:06:12.057166
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=tuple(),
    ).name == ''
    assert SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=tuple(),
    ).camel == ''
    assert SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=tuple(),
    ).description == ''
    assert SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=tuple(),
    ).commands == tuple()

# Generated at 2022-06-21 13:06:21.987067
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    SetupCfgCommandConfig('test', 'Test', 'test', ('test',))
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(1, 'Test', 'test', ('test',))
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('test', 1, 'test', ('test',))
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('test', 'Test', 1, ('test',))
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            'test', 'Test', 'test', ['test'])

# Generated at 2022-06-21 13:06:26.856974
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig("name1", "camel1", "desc1", ("command1","command2"))
    assert command.name == "name1"
    assert command.camel == "camel1"
    assert command.description == "desc1"
    assert command.commands == ("command1","command2")

# Generated at 2022-06-21 13:06:31.094448
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        each_sub_command_config('.')
    except FileNotFoundError:
        pass  # Success
    try:
        each_sub_command_config('')
    except FileNotFoundError:
        pass  # Success
    try:
        each_sub_command_config(None)
    except FileNotFoundError:
        pass  # Success

# Generated at 2022-06-21 13:06:41.071211
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test_get_name(parser, setup_cfg_path: str) -> str:
        return parser.get('metadata', 'name')

    # Setup test
    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'flutils')

    setup_cfg_path = ''
    assert 'flutils' == _get_name(parser, setup_cfg_path)
    assert 'flutils' == test_get_name(parser, setup_cfg_path)

    parser = ConfigParser()
    parser.add_section('metadata')

    setup_cfg_path = ''
    with pytest.raises(LookupError):
        _get_name(parser, setup_cfg_path)

# Generated at 2022-06-21 13:06:50.347236
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'command name', 'CommandName',
        'Command Description', ('cmd1', 'cmd2')
    )
    assert (setup_cfg_command_config.name,
            setup_cfg_command_config.camel,
            setup_cfg_command_config.description,
            setup_cfg_command_config.commands) == (
               'command name', 'CommandName',
               'Command Description', ('cmd1', 'cmd2'))
    assert setup_cfg_command_config == SetupCfgCommandConfig(
        'command name', 'CommandName',
        'Command Description', ('cmd1', 'cmd2')
    )

# Generated at 2022-06-21 13:07:00.768822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.testutils
    import flutils.testutils.fileutils

    with flutils.testutils.fileutils.tempdir() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'mypackage')
        os.mkdir(setup_dir)

        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as fh:
            fh.write('[metadata]\nname=mypackage\n')
            fh.write('[setup.command.lint]\ncommand=echo linting\n')
            fh.write('[setup.command.format]\ncommand=echo formatting\n')
            fh.write('[setup.command.document]\ncommands=\n')
            fh.write('    echo documenting\n')
           

# Generated at 2022-06-21 13:07:07.338729
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'setuptools',
        'setuptools',
        'Setuptools command',
        ('python setup.py develop',)
    )
    assert config.name == 'setuptools'
    assert config.camel == 'setuptools'
    assert config.description == 'Setuptools command'
    assert config.commands == ('python setup.py develop',)



# Generated at 2022-06-21 13:07:18.391886
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('name', 'camel', 'description', ('command', ))
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('command', )
    assert c == ('name', 'camel', 'description', ('command', ))
    assert c[0] == 'name'
    assert c[1] == 'camel'
    assert c[2] == 'description'
    assert c[3] == ('command', )
    assert repr(c) == (
        "SetupCfgCommandConfig(name='name', camel='camel', "
        "description='description', commands=('command',))"
    )

# Generated at 2022-06-21 13:07:26.242752
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from os.path import (
        expanduser,
        join
    )
    from typing import List
    from shutil import rmtree
    from tempfile import mkdtemp

# Generated at 2022-06-21 13:07:49.032181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = os.path.abspath(tmpdir)
        shutil.copy(
            os.path.join('tests', 'example_setup.py'),
            os.path.join(tmpdir, 'setup.py')
        )
        shutil.copy(
            os.path.join('tests', 'example_setup.cfg'),
            os.path.join(tmpdir, 'setup.cfg')
        )
        shutil.copy(
            os.path.join('tests', 'example_setup_commands.cfg'),
            os.path.join(tmpdir, 'setup_commands.cfg')
        )

# Generated at 2022-06-21 13:07:50.378928
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass



# Generated at 2022-06-21 13:07:55.010469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(__file__)
    for i in each_sub_command_config(this_dir):
        print(i)

# Generated at 2022-06-21 13:07:59.993201
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        'name', 'Camel', 'desc', ('cmd', )
    )
    assert command_config.name == 'name'
    assert command_config.camel == 'Camel'
    assert command_config.description == 'desc'
    assert command_config.commands == ('cmd', )


# Generated at 2022-06-21 13:08:11.114492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import join
    from sys import stdout
    from unittest.mock import patch
    from .testdata import pkgbase
    from .testdata import pkgname
    from .testdata import root
    from .testdata import test_data_root

    def _print(config: SetupCfgCommandConfig) -> None:
        stdout.write('%r\n' % config)

# Generated at 2022-06-21 13:08:17.704560
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # This is NOT a perfect test. It only tests that we get back
    # some commands.
    #
    # The commands MUST be tested by hand.
    for config in each_sub_command_config():
        assert config.description
        assert config.name
        assert config.camel
        assert config.commands


if __name__ == '__main__':
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-21 13:08:25.978003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import realpath
    from io import StringIO

    config = StringIO(
        "\n".join([
            "[metadata]",
            "name = demo_util",
            "",
            "[setup.command.install.develop.build_ext]",
            "commands =",
            "    echo Build demo_util's extension modules",
            "",
            "[setup.command.install.develop.build_static]",
            "commands =",
            "    echo Build demo_util's static files",
            "",
            "[setup.command.install.develop.build_all]",
            "commands =",
            "    echo Build all of demo_util's files",
            "",
        ])
    )
    parser = ConfigParser()
    parser.read_file(config)
    config = list

# Generated at 2022-06-21 13:08:34.516415
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    def _test(
            name: Optional[str] = 'name',
            camel: Optional[str] = 'Camel',
            description: Optional[str] = 'description',
            commands: Optional[Tuple[str, ...]] = ('command',)
    ) -> None:
        sccc = SetupCfgCommandConfig(name, camel, description, commands)
        assert sccc.name == name
        assert sccc.camel == camel
        assert sccc.description == description
        assert sccc.commands == commands

    _test()


# Generated at 2022-06-21 13:08:40.429272
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_config = SetupCfgCommandConfig("foobar", "Foobar", "Foobar", ("file.py", "file2.py"))
    assert cmd_config.name == "foobar"
    assert cmd_config.camel == "Foobar"
    assert cmd_config.description == "Foobar"
    assert cmd_config.commands[0] == "file.py"
    assert cmd_config.commands[1] == "file2.py"

# Generated at 2022-06-21 13:08:44.619121
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',),
    )
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'Camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('commands',)


# Generated at 2022-06-21 13:09:13.284777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    setup_dir = os.path.join(pkg_path, 'tests', 'data', 'setup_command')
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:09:16.444768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = each_sub_command_config('.')
    config = list(config)
    assert len(config) > 0

# Generated at 2022-06-21 13:09:26.102291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re
    import pathlib
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()

    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        if re.search(r'(setup_commands\.py|test_setup_commands\.py)',
                     os.path.basename(fs.filename)):
            setup_dir = str(pathlib.Path(fs.filename).parent)
            break

    os.makedirs(os.path.join(temp_dir.name, 'src'), exist_ok=True)
    setup_file_py = os.path.join(temp_dir.name, 'setup.py')
    setup_file_cfg = os.path.join(temp_dir.name, 'setup.cfg')
    commands_file_cfg = os.path

# Generated at 2022-06-21 13:09:32.642200
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()

# Generated at 2022-06-21 13:09:34.140863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Type check
    configs = list(each_sub_command_config())
    assert configs



# Generated at 2022-06-21 13:09:35.337675
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # REVIEW: Should there be a test for this?
    pass

# Generated at 2022-06-21 13:09:39.273734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'samples')
    for sub_cmd in each_sub_command_config(setup_dir):
        print(sub_cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:09:44.230481
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    for cfg in each_sub_command_config('/Users/brandon/Documents/flutils'):
        pprint(cfg)


# Command-line entry point for function each_sub_command_config

# Generated at 2022-06-21 13:09:54.265683
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(
            config: SetupCfgCommandConfig,
            name_camel_description_commands: Tuple[str, str, str, str]
    ) -> None:
        """A function to test the each_sub_command_config function."""
        name, camel, description, commands = name_camel_description_commands
        assert config.name == name
        assert config.camel == camel
        assert config.description == description
        assert tuple(config.commands) == tuple(commands.split())

    _test_each_sub_command_config(
        next(each_sub_command_config(__file__)),
        ('commit', 'Commit', '', 'git add . && git commit -a')
    )

# Generated at 2022-06-21 13:10:01.180075
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig(name='foo',
                              camel='Bar',
                              description='This is a test.',
                              commands=('echo test',),
    )
    assert a.name == 'foo'
    assert a.camel == 'Bar'
    assert a.description == 'This is a test.'
    assert a.commands == ('echo test',)


# Generated at 2022-06-21 13:10:22.553337
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock as mock
    import sys
    import os

    from . import test_configs

    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '../..')
    )

    def _mock_input_yes():
        yield 'y'

    def _mock_input_no():
        yield 'n'

    def _test_yes(test_case, setup_dir=setup_dir):
        test_case.assertEqual(len(list(test_configs.each_config(setup_dir))), 1)

# Generated at 2022-06-21 13:10:28.417940
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'a',
        'b',
        'c',
        ('d', 'e', 'f'),
    )
    assert config.name == 'a'
    assert config.camel == 'b'
    assert config.description == 'c'
    assert config.commands == ('d', 'e', 'f')

# Generated at 2022-06-21 13:10:34.840838
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=()
    )
    assert isinstance(obj, NamedTuple)
    assert isinstance(obj, tuple)
    assert obj.name == 'test'
    assert obj.camel == 'Test'
    assert obj.description == 'test'
    assert obj.commands == ()


# Generated at 2022-06-21 13:10:38.433614
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))
    assert test.name == 'name'
    assert test.camel == 'camel'
    assert test.description == 'description'
    assert test.commands == ('command1', 'command2')

# Generated at 2022-06-21 13:10:45.501755
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'metadata'
    name = 'foo'
    camel = 'Foo'
    description = 'foo description'
    commands = ('do foo', 'do bar')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-21 13:10:53.508265
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test():
        path = os.path.dirname(os.path.realpath(__file__))
        path = os.path.dirname(path)
        path = os.path.join(path, 'tests')
        path = os.path.join(path, 'test_project')
        path = os.path.join(path, 'setup.py')
        for sc in each_sub_command_config(setup_dir=path):
            assert sc.name == 'test_project.test'
            assert sc.camel == 'TestProjectTest'
            assert sc.description == 'Runs the tests.'
            assert len(sc.commands) == 1
            assert sc.commands[0] == 'echo "hello world"'
            break
        else:
            raise RuntimeError('Did not get a sub command configuration.')

# Generated at 2022-06-21 13:10:58.112709
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    arguments = ('a', 'b', 'c', ('d', ))
    config = SetupCfgCommandConfig(*arguments)
    for idx, value in enumerate(arguments):
        if idx == 3:
            assert config.commands == value
        else:
            assert getattr(config, arguments[idx]) == value



# Generated at 2022-06-21 13:11:07.297286
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from io import StringIO
    from pprint import pprint
    from configparser import ConfigParser

    text = """
    [metadata]
    name=flutils

    [setup.command.clean]
    commands=
        rm -rf dist
        rm -rf build
        rm -rf flutils.egg-info
        find . -iname '*.pyc' -delete

    [setup.command.fmt]
    commands=
        python -c "import flutils; flutils.setup_commands.fmt.main()"

    [setup.command.test]
    commands=
        python -m unittest discover
        python -m unittest
    """

    parser = ConfigParser()
    parser.read_file(StringIO(text))

# Generated at 2022-06-21 13:11:09.879911
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command_1', 'command_2'),
    )
    return 0

# Generated at 2022-06-21 13:11:16.426545
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import str_to_path
    for config in each_sub_command_config(
        str_to_path(os.path.dirname(__file__))
    ):
        print(config.name)
        print(config.camel)
        print(config.description)
        print(config.commands)


# Generated at 2022-06-21 13:11:47.445195
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import zipfile
    with tempfile.TemporaryDirectory() as td:
        setup_dir = os.path.join(td, 'flutils')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('# nothing here')
        os.mkdir(os.path.join(setup_dir, 'test'))
        src_path = os.path.join(setup_dir, 'test', 'test_each_sub_command_config.py')

# Generated at 2022-06-21 13:11:53.796551
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    Output = SetupCfgCommandConfig
    name = 'long_name'
    camel = 'LongName'
    description = 'This is the long name.'
    commands = tuple(['This is a command', 'This is another command'])
    assert Output(name, camel, description, commands) == Output(name, camel, description, commands)


# Generated at 2022-06-21 13:11:57.661242
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    tupleSetupCfgCommandConfig = namedtuple("SetupCfgCommandConfig", ['name', 'camel', 'description', 'commands'])
    assert isinstance(tupleSetupCfgCommandConfig("test", "test", "test", ("test", "test")), SetupCfgCommandConfig)


# Generated at 2022-06-21 13:12:06.522013
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo', 'Foo', 'This is foo.', ('bar', 'baz')
    ) == SetupCfgCommandConfig(
        'foo', 'Foo', 'This is foo.', ('bar', 'baz')
    )
    assert SetupCfgCommandConfig(
        'foo', 'Foo', 'This is foo.', ('bar', 'baz')
    ) != SetupCfgCommandConfig(
        'foo', 'Foo', 'This is foo.', ('bar', 'baz',)
    )
    assert SetupCfgCommandConfig(
        'foo', 'Foo', 'This is foo.', ('bar', 'baz')
    ) != SetupCfgCommandConfig(
        'bar', 'Foo', 'This is foo.', ('bar', 'baz')
    )


# Generated at 2022-06-21 13:12:07.788197
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))

# Generated at 2022-06-21 13:12:17.199467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as path:
        path = os.path.join(path, 'flutils')
        os.makedirs(path)

# Generated at 2022-06-21 13:12:24.173779
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO

    setup_cfg_data = '''
[metadata]
name = foo

[setup.command.some_command]
description = run some command
command = python -c "print('hello world')"
'''

    setup_cfg_io = StringIO(setup_cfg_data)
    parser = ConfigParser()
    parser.read_file(setup_cfg_io)
    assert len(parser.sections()) == 2

    config = next(iter(_each_setup_cfg_command(parser, {'name': 'foo'})))
    assert config.name == 'some_command'
    assert config.camel == 'SomeCommand'
    assert config.description == 'run some command'
    assert config.commands == ('python -c "print(\'hello world\')"', )



# Generated at 2022-06-21 13:12:25.212734
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig()



# Generated at 2022-06-21 13:12:25.795589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:12:32.374983
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name='newegg.test',
                                   camel='NeweggTest',
                                   description='cmd to run test',
                                   commands=('ls', 'pwd'))
    assert config.name == 'newegg.test'
    assert config.camel == 'NeweggTest'
    assert config.description == 'cmd to run test'
    assert config.commands == ('ls', 'pwd')



# Generated at 2022-06-21 13:13:28.382855
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('cmd', 'Cmd', 'desc', ('a', 'b'))

# Generated at 2022-06-21 13:13:32.879978
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test_name', 'TestName', 'Test description', ('test command',))
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'Test description'
    assert config.commands == ('test command',)

# Generated at 2022-06-21 13:13:33.327586
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:13:34.436015
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-21 13:13:40.669301
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(
        os.path.dirname(os.path.dirname(__file__))
    )
    curr = os.path.abspath(os.path.dirname(__file__))
    print('Parent: ', here)
    print('Child: ', curr)
    print(list(each_sub_command_config()))



# Generated at 2022-06-21 13:13:52.002764
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import platform
    from tempfile import mkdtemp
    import shutil
    from flutils.pathutils import (
        ensure_parent_directory,  # pylint: disable=unused-variable
        write_text_file,  # pylint: disable=unused-variable
    )
    from flutils.timeutils import sleep_timer
    from flutils.sysutils import is_windows
    from iocingestor.autosetup import (
        _get_script_directory_path,  # pylint: disable=unused-variable
    )
    from iocingestor.utils import create_ioc_ingestor_dirs
    from iocingestor.scripts.iocingestor import main
    script_name: str = ''

# Generated at 2022-06-21 13:13:57.980540
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('command_name', 'CommandName', 'Description', ('cmd',))
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'command_name'
    assert cmd.camel == 'CommandName'
    assert cmd.description == 'Description'
    assert isinstance(cmd.commands, tuple)
    commands = cmd.commands
    assert len(commands) == 1
    assert commands[0] == 'cmd'


# Generated at 2022-06-21 13:14:09.559168
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # noqa: D103
    from flutils.project.setup_cfg import each_sub_command_config
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirpath:
        tmpdirpath = Path(tmpdirpath)
        setup_py = tmpdirpath / 'setup.py'
        setup_py.touch()

        setup_cfg = tmpdirpath / 'setup.cfg'
        setup_cfg.write_text(
            "[metadata]\n"
            "name = blah"
        )

        setup_commands_cfg = tmpdirpath / 'setup_commands.cfg'


# Generated at 2022-06-21 13:14:13.939975
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig('a', 'B', 'd', ('e', 'f'))

    assert a.name == 'a'
    assert a.camel == 'B'
    assert a.description == 'd'
    assert a.commands == ('e', 'f')



# Generated at 2022-06-21 13:14:25.550315
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_bad_setup_dir(setup_dir: str) -> None:
        with pytest.raises(FileNotFoundError):
            for _ in each_sub_command_config(setup_dir=setup_dir):
                pass

    _test_bad_setup_dir('/nix')
    _test_bad_setup_dir(__file__)
    _test_bad_setup_dir(os.path.join(os.path.dirname(__file__), '..'))

    for config in each_sub_command_config(setup_dir=os.path.dirname(__file__)):
        assert isinstance(config.name, str)
        assert config.camel.isidentifier() is True
        assert isinstance(config.description, str)

# Generated at 2022-06-21 13:15:38.369406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile
    d = tempfile.TemporaryDirectory()
    d.cleanup()
    d.name = os.path.join('/tmp', d.name)
    print(d.name)
    os.makedirs(d.name, exist_ok=True)
    with open(os.path.join(d.name, 'setup.py'), 'w') as f:
        f.write('\n')
    with open(os.path.join(d.name, 'setup.cfg'), 'w') as f:
        f.write('\n')

# Generated at 2022-06-21 13:15:42.881295
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print('\n\nrunning test_SetupCfgCommandConfig')
    config = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='Runs foo.',
        commands=('echo "foo"',)
    )
    print(config)



# Generated at 2022-06-21 13:15:51.709118
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """There is a 'setup_commands.cfg' that contains:
    [setup.command.test]
    command=bash -c "echo {name} {setup_dir} {home}"
    """
    import pytest
    import tempfile
    import shlex
    import contextlib
    from pathlib import Path
    from flutils.assertutils import assert_sequence_equal

    @contextlib.contextmanager
    def save_cwd(tempdir: str) -> Generator:
        cwd = Path.cwd()
        try:
            Path.chdir(tempdir)
            yield
        finally:
            Path.chdir(cwd)
