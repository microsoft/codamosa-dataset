

# Generated at 2022-06-21 13:06:10.372652
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dirname = os.path.dirname(__file__)
    dirname = os.path.dirname(dirname)
    dirname = os.path.dirname(dirname)
    dirname = os.path.dirname(dirname)
    dirname = os.path.join(dirname, 'tests', 'resources', 'project')

    print(dirname)
    for x in each_sub_command_config(dirname):
        print(x)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-21 13:06:19.607828
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Success
    _ = SetupCfgCommandConfig(
        name='cmd',
        camel='Cmd',
        description='description',
        commands=('a', 'b')
    )
    # Failure
    try:
        _ = SetupCfgCommandConfig(
            name='',
            camel='Cmd',
            description='description',
            commands=('a', 'b')
        )
        success = True
    except:
        success = False
    assert success is False
    try:
        _ = SetupCfgCommandConfig(
            name='cmd',
            camel='',
            description='description',
            commands=('a', 'b')
        )
        success = True
    except:
        success = False
    assert success is False

# Generated at 2022-06-21 13:06:27.240433
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    config = SetupCfgCommandConfig(
        name='name1',
        camel='Camel',
        description='description 1',
        commands=('commands', '1')
    )
    assert config.name == 'name1'
    assert config.camel == 'Camel'
    assert config.description == 'description 1'
    assert config.commands == ('commands', '1')



# Generated at 2022-06-21 13:06:37.276950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def get_sub_cmd_configs() -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(
            os.path.join(setup_dir.name, 'setup.py')
        )

    here = os.path.dirname(os.path.realpath(__file__))
    with tempfile.TemporaryDirectory(dir=here) as setup_dir:
        script_name = os.path.join(setup_dir, 'setup.py')
        with open(script_name, 'w') as fp:
            fp.write("# setup.py\n")

        sub_cmd_configs = list(get_sub_cmd_configs())
        assert len(sub_cmd_configs) == 0


# Generated at 2022-06-21 13:06:39.193162
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('test_name', 'TestName', 'test_description',
                                 ('test_1', 'test_2')) is not None

# Generated at 2022-06-21 13:06:48.709162
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import MagicMock
    from typing import Any
    assert issubclass(SetupCfgCommandConfig, NamedTuple)
    assert SetupCfgCommandConfig.__doc__ is not None
    assert SetupCfgCommandConfig.__module__ == __name__

    assert SetupCfgCommandConfig.__slots__ == tuple()
    assert SetupCfgCommandConfig._fields == (
        'name',
        'camel',
        'description',
        'commands',
    )

    mock = MagicMock(spec=SetupCfgCommandConfig)
    assert SetupCfgCommandConfig.name.fget(mock) == mock._asdict()['name']
    assert SetupCfgCommandConfig.camel.fget(mock) == mock._asdict()['camel']
    assert SetupCfgCommandConfig.description

# Generated at 2022-06-21 13:06:50.656023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    conf = list(each_sub_command_config())
    assert len(conf) == 9

# Generated at 2022-06-21 13:07:01.077183
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check(
            commands_list: List[Tuple[str, str, Tuple[str, ...]]],
            func=each_sub_command_config
    ) -> None:
        out: List[SetupCfgCommandConfig] = list(func())
        assert len(out) == len(commands_list)
        ctrl_map: Dict[str, SetupCfgCommandConfig] = {}
        for i in range(len(out)):
            ctrl_map[out[i].name] = out[i]
        for name, camel, commands in commands_list:
            cfg = ctrl_map[name]
            assert cfg.camel == camel
            assert cfg.commands == commands

    # noinspection PyUnresolvedReferences
    from .test_data.setup_commands import *

    #

# Generated at 2022-06-21 13:07:02.859093
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', tuple('commands'))



# Generated at 2022-06-21 13:07:05.669961
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    each_sub_command_config(__file__)



# Generated at 2022-06-21 13:07:17.641022
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', tuple())
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == tuple()



# Generated at 2022-06-21 13:07:22.603044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import sys
    out: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    pprint.pprint(out, width=sys.maxsize)


__all__ = (
    'each_sub_command_config',
    'SetupCfgCommandConfig',
    'test_each_sub_command_config',
)

# Generated at 2022-06-21 13:07:25.911725
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ())
    assert 'name' == config.name
    assert 'camel' == config.camel
    assert 'description' == config.description
    assert () == config.commands


# Generated at 2022-06-21 13:07:27.486888
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config('tests/data/setup_config'):
        pass

# Generated at 2022-06-21 13:07:33.965528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    class TestEachSubCommandConfig(TestCase):

        def setUp(self) -> None:
            self.module_dir = get_module_dir()

        def test_each_sub_command_config(self) -> None:
            with TemporaryDirectory() as td:
                td = Path(td)
                setup_dir = td / 'setup_dir'
                setup_dir.mkdir()
                setup_cfg_path = setup_dir / 'setup.cfg'
                setup_cfg_path.touch()
                setup_cfg_path.write_text(
                    """[metadata]
name = 'flutils'
"""
                )

# Generated at 2022-06-21 13:07:38.468761
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        "test command", "testCommand", "test command description", ()
    )
    assert config.name == "test command"
    assert config.camel == "testCommand"
    assert config.description == "test command description"
    assert config.commands == ()


# Generated at 2022-06-21 13:07:41.009936
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = [
        x.name for x in each_sub_command_config(setup_dir='.')
    ]
    assert 'tests' in cmds

# Generated at 2022-06-21 13:07:51.389735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import pathlib
    from itertools import count
    from flutils.setuputils import each_sub_command_config
    from flutils.strutils import underscore_to_camel

    def get_next_file_path() -> str:
        return 'tmp_test_%d.cfg' % next(count_test_files)
    count_test_files = count(1)


# Generated at 2022-06-21 13:07:54.443498
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        os.path.pardir,
        os.path.pardir
    )
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands
        for command in config.commands:
            assert command

# Generated at 2022-06-21 13:08:03.651120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.dirname(setup_dir)
    commands = list(each_sub_command_config(setup_dir))
    assert commands[0].name == 'coveralls'
    assert commands[0].camel == 'Coveralls'
    assert commands[0].description == """
Posts a coverage report to the <https://coveralls.io/> website.

Note: Will check for the existence of the file,
``~/.no_coveralls_%(name)s``, and if it exists then Coveralls is skipped.
""" % {'name': 'test_util_command'}

# Generated at 2022-06-21 13:08:20.951157
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        cmd = 'echo Hello World'
        with open(os.path.join(tmp, 'setup.py'), 'w'):
            pass
        with open(os.path.join(tmp, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = test\n')
        with open(os.path.join(tmp, 'setup_commands.cfg'), 'w') as f:
            f.write('[setup.command.test]\n')
            f.write(f'command = {cmd}\n')
        gen = each_sub_command_config(tmp)
        conf = next(gen)
        assert conf.name == 'test'

# Generated at 2022-06-21 13:08:25.115968
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '.'
    for obj in each_sub_command_config(setup_dir):
        print(obj)
    print()

    for obj in each_sub_command_config():
        print(obj)


if __name__ == '__main__':
    # test_each_sub_command_config()
    print(__file__)

# Generated at 2022-06-21 13:08:36.113907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    from string import Template

    def format_config(name, tpl):
        return Template(tpl).substitute(
            setup_dir=tmp_dir,
            name=name,
            home=os.path.expanduser('~')
        )

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 13:08:41.181456
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='foo',
        camel='Bar',
        description='Desc for Bar',
        commands=('echo 123',)
    )
    assert config.name == 'foo'
    assert config.camel == 'Bar'
    assert config.description == 'Desc for Bar'
    assert config.commands == ('echo 123',)

# Generated at 2022-06-21 13:08:49.305814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    unit_tests_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(unit_tests_dir)
    project_dir = os.path.dirname(project_dir)
    setup_dir = os.path.join(project_dir, 'setup')

    print(setup_dir)
    print(os.path.isfile(setup_dir))
    print(os.path.isfile(os.path.join(setup_dir, 'setup.cfg')))

    for cfg in each_sub_command_config(setup_dir):
        print(cfg)


# Generated at 2022-06-21 13:08:50.361084
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:09:01.757704
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tests = [
        {
            'path': 'tests/sub-command'
        },
        {
            'path': 'tests/sub-commands'
        },
    ]
    for test in tests:
        setup_dir = test.get('path')
        if setup_dir is None:
            continue
        setup_dir = os.path.realpath(setup_dir)
        sub_command_configs = tuple(each_sub_command_config(setup_dir))
        assert sub_command_configs, (
            "Unable find sub-commands for %r" % setup_dir
        )
        for sub_command_config in sub_command_configs:
            assert sub_command_config.camel, (
                "%r: camel is not set"
                % sub_command_config.name
            )

# Generated at 2022-06-21 13:09:11.780997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import tempfile
    from pathlib import Path

    dirpath = tempfile.mkdtemp()

# Generated at 2022-06-21 13:09:14.151461
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('commands',)
    )


# Generated at 2022-06-21 13:09:25.056887
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from inspect import getsource, getsourcelines
    from textwrap import dedent
    from unittest import TestCase

    from flutils.configutils import (
        generate_setup_cfg,
        generate_setup_commands_cfg,
    )

    class TestEachSubCommandConfig(TestCase):
        """Unit test for the ``each_sub_command_config`` function."""

        def test_setup_dir_does_not_exist(self):
            """The given ``setup_dir`` does NOT exist."""
            setup_dir = '/tmp/setup_dir'
            with self.assertRaises(FileNotFoundError) as err:
                list(each_sub_command_config(setup_dir))
            self.assertTrue(
                setup_dir in str(err.exception)
            )


# Generated at 2022-06-21 13:09:48.435436
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils import iterutils
    from flutils.pathutils import get_project_root
    from pathlib import Path
    from typing import Generator
    from unittest import TestCase
    from . import is_travis

    class Test_SetupCfgCommandConfig(TestCase):
        def test__SetupCfgCommandConfig(self):
            setup_cfg_command_configs = tuple(
                iterutils.each_unique(
                    each_sub_command_config(
                        str(Path(get_project_root(), 'setup.py').parent)
                    )
                )
            )
            self.assertGreater(len(setup_cfg_command_configs), 0)


# Generated at 2022-06-21 13:09:50.655618
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import patch
    from sys import stderr
    with patch('sys.stderr', new=stderr):
        for sccc in each_sub_command_config():
            assert sccc.name
            assert sccc.camel
            assert sccc.description
            assert sccc.commands


# Generated at 2022-06-21 13:09:57.409799
# Unit test for function each_sub_command_config

# Generated at 2022-06-21 13:10:03.765732
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test_name', 'TestName', 'Test Description', ('foo', 'bar')
    )
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'Test Description'
    assert config.commands == ('foo', 'bar')


# Generated at 2022-06-21 13:10:10.046405
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig.__doc__)
    config = SetupCfgCommandConfig(
        name='abc',
        camel='Abc',
        description='a long, long time ago...',
        commands=('cmd 1', 'cmd 2')
    )
    assert config.name == 'abc'
    assert config.camel == 'Abc'
    assert config.description == 'a long, long time ago...'
    assert config.commands == ('cmd 1', 'cmd 2')

# Generated at 2022-06-21 13:10:15.169524
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('one', 'two')
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('one', 'two')

# Generated at 2022-06-21 13:10:23.462389
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test str when first arg, name, is None
    try:
        SetupCfgCommandConfig(None, 'Camel', 'foo', ('run', ))
    except TypeError as exc:
        assert str(exc) == "'name' must be a string."

    # Test str when first arg, name, is an empty str
    try:
        SetupCfgCommandConfig('', 'Camel', 'foo', ('run', ))
    except ValueError as exc:
        assert str(exc) == "The 'name' must be a non-empty string."

    # Test str w/ valid args
    assert str(
        SetupCfgCommandConfig(
            'foo.bar', 'Camel', 'foo', ('run', )
        )
    ) == "foo.bar"

    # Test repr w/ valid args

# Generated at 2022-06-21 13:10:28.962780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config('tests/setup_dir'):
        assert sc.name == 'build'
        assert sc.camel == 'Build'
        assert sc.description == 'Build the packages.'
        assert sc.commands == ('python setup.py build',)
        break

# Generated at 2022-06-21 13:10:39.201074
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from pathlib import Path
    from flutils.pathutils import temp_directory
    from flutils.iterutils import unique

    with temp_directory() as tmp_dir:
        p = Path(tmp_dir)
        setup_py = p / 'setup.py'
        setup_cfg = p / 'setup.cfg'
        setup_commands = p / 'setup_commands.cfg'
        assert setup_py.exists() is False
        assert setup_cfg.exists() is False
        assert setup_commands.exists() is False
        setup_py.write_text('')
        setup_cfg.write_text('')
        setup_commands.write_text('')


# Generated at 2022-06-21 13:10:46.397819
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    sc = list(each_sub_command_config())
    assert len(sc) > 0
    for i in sc:
        assert isinstance(i.name, str)
        assert isinstance(i.camel, str)
        assert isinstance(i.description, str)
        assert isinstance(i.commands, tuple)
        for j in i.commands:
            assert isinstance(j, str)

# Generated at 2022-06-21 13:11:13.686496
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for setup_cfg_command_config in each_sub_command_config():
        assert isinstance(setup_cfg_command_config.name, str)
        assert isinstance(setup_cfg_command_config.camel, str)
        assert isinstance(setup_cfg_command_config.commands, tuple)
        assert all([isinstance(x, str) for x in setup_cfg_command_config.commands])
        assert setup_cfg_command_config.commands

# Generated at 2022-06-21 13:11:15.810587
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('1', '2'))



# Generated at 2022-06-21 13:11:21.295876
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Validates the functionality of the ``each_sub_command_config``
    function.
    """
    setup_dir = os.path.dirname(__file__)
    for cmd in each_sub_command_config(setup_dir):
        print(cmd)
    for sub_command in each_sub_command_config():
        print(sub_command)

# Generated at 2022-06-21 13:11:30.570359
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test string'
    camel = 'test string'
    description = 'test string'
    commands = ('test',)
    test = SetupCfgCommandConfig(
        name, camel, description, commands
    )
    assert test.__getnewargs__() == ()
    assert test.name == name
    assert test.camel == camel
    assert test.description == description
    assert test.commands == commands
    assert str(test) == (
        'SetupCfgCommandConfig'
        '(name=%r, camel=%r, description=%r, commands=%r)' % (
            name, camel, description, commands
        )
    )

# Generated at 2022-06-21 13:11:37.744987
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig(
        'my.command',
        'MyCommand',
        'Description of my.command',
        ('ls -la', 'echo hi')
    )
    expected = SetupCfgCommandConfig(
        'my.command',
        'MyCommand',
        'Description of my.command',
        ('ls -la', 'echo hi')
    )
    assert actual == expected

# Generated at 2022-06-21 13:11:46.352700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import mkdtemp
    from flutils.fileutils import create_dirs_safe

    test_dir = Path(mkdtemp())
    setup_dir = test_dir / 'foo' / 'bar' / 'baz'
    create_dirs_safe(setup_dir)
    setup_py = setup_dir / 'setup.py'
    setup_cfg = setup_dir / 'setup.cfg'
    setup_commands_cfg = setup_dir / 'setup_commands.cfg'

    setup_py.write_text('# Some setup file that has the name "setup.py".')

# Generated at 2022-06-21 13:11:54.288617
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'dummy_config'
    camel = 'DummyConfig'
    description = 'description of #{name}'
    commands = (
        'cmd1',
        'cmd2',
    )

    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-21 13:12:00.463620
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test name',
        'test camel',
        'test description',
        ('test command',)
    )
    assert config.name == 'test name'
    assert config.camel == 'test camel'
    assert config.description == 'test description'
    assert config.commands == ('test command',)
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)
    

# Generated at 2022-06-21 13:12:03.899992
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test', 'Test', 'test', ['cmd1', 'cmd2'])
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:12:13.848166
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_cli_parent_dir,
        get_cli_root_dir,
    )
    from flutils.bunch import Bunch

    cli_parent_dir = get_cli_parent_dir(__file__)
    cli_root_dir = get_cli_root_dir(__file__)

    # The following should NOT raise an error
    for b in each_sub_command_config(cli_parent_dir):
        b = cast(SetupCfgCommandConfig, b)
        assert isinstance(b, Bunch)
        assert isinstance(b, SetupCfgCommandConfig)
        assert isinstance(b.name, str)
        assert isinstance(b.description, str)
        assert isinstance(b.camel, str)

# Generated at 2022-06-21 13:13:11.702381
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.abspath(os.path.dirname(__file__))
    to_test = os.path.join(cwd, 'configs')
    for command in each_sub_command_config(to_test):
        assert command is not None

# Generated at 2022-06-21 13:13:21.172616
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(name=str, camel=str, description=str, commands=Tuple[str, ...])
    assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
    assert isinstance(setup_cfg_command_config.name, str)
    assert isinstance(setup_cfg_command_config.camel, str)
    assert isinstance(setup_cfg_command_config.description, str)
    assert isinstance(setup_cfg_command_config.commands, tuple)


# Generated at 2022-06-21 13:13:25.698901
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_config = SetupCfgCommandConfig('test.name', 'TestName', 'A test', ('ls', 'ls -l'))
    assert cmd_config.name == 'test.name'
    assert cmd_config.camel == 'TestName'
    assert cmd_config.description == 'A test'
    assert cmd_config.commands == ('ls', 'ls -l')


# Generated at 2022-06-21 13:13:32.188072
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit testing of SetupCfgCommandConfig. Should always pass."""
    assert SetupCfgCommandConfig(
        "name1", "camel1", "desc1", ("cmd1", "cmd2")
    ) == ("name1", "camel1", "desc1", ("cmd1", "cmd2"))


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-21 13:13:36.283400
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig(
        'name', 'camel', 'description',
        ('test1', 'test2')
    )
    assert isinstance(instance, SetupCfgCommandConfig)
    assert instance.name == 'name'
    assert instance.camel == 'camel'
    assert instance.description == 'description'
    assert instance.commands == ('test1', 'test2')

# Generated at 2022-06-21 13:13:38.747402
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("a", "b", "c", ("d", "e", "f"))



# Generated at 2022-06-21 13:13:46.209409
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            name='run_function',
            camel='RunFunction',
            description='Run the function.',
            commands=(
                'python -c "from flutils.scriptutils import run_function; '
                'run_function()"',
            ),
        )
    except Exception:
        assert False, \
            'Failed to instantiate SetupCfgCommandConfig'



# Generated at 2022-06-21 13:13:47.921413
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b'))

# Generated at 2022-06-21 13:13:52.362044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.chdir(os.path.dirname(__file__))
    os.chdir('../..')
    assert 'pytest' == os.path.basename(os.getcwd())
    c = 0
    for _ in each_sub_command_config():
        c += 1
    assert c == 7

# Generated at 2022-06-21 13:13:53.696321
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'Description', ('command', ))