

# Generated at 2022-06-21 13:06:13.218751
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.typelib import Path

    def _dir(dir_name: str) -> str:
        return str(Path(__file__).parent / 'data' / dir_name)

    out = list(each_sub_command_config(_dir('sub_commands_0')))
    assert len(out) == 1
    out = out[0]
    assert isinstance(out, SetupCfgCommandConfig) is True
    assert out.name == 'command_name_0'
    assert out.camel == 'CommandName0'
    assert out.description == 'Description 0'
    assert out.commands == ('pylint --rcfile=pylint.rc',)
    out = list(each_sub_command_config(_dir('sub_commands_1')))
    assert len(out) == 1
   

# Generated at 2022-06-21 13:06:18.904377
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = str(
        os.path.dirname(
            os.path.dirname(
                os.path.dirname(
                    os.path.abspath(__file__)
                )
            )
        )
    )
    for sub_cmd_cfg in each_sub_command_config(setup_dir):
        print(sub_cmd_cfg)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:06:20.066342
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-21 13:06:28.046860
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    data = [
        ('name', 'MyCommand'),
        ('camel', 'MyCommand'),
        ('description', 'My command description.'),
        ('commands', ('python manage.py migrate',)),
    ]
    config = SetupCfgCommandConfig(*data)
    assert config.name == data[0][1]
    assert config.camel == data[1][1]
    assert config.description == data[2][1]
    assert config.commands == data[3][1]



# Generated at 2022-06-21 13:06:30.148664
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args = ('name', 'Camel', 'description', ('command a', 'command b'))
    config = SetupCfgCommandConfig(*args)
    assert config == args

# Generated at 2022-06-21 13:06:40.255306
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Constructor should raise a type error if name is not a string
    name = 3
    camel = 'Testing'
    description = 'Test'
    commands = ('command', 'command')
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(name, camel, description, commands)

    # Constructor should raise a type error if camel is not a string
    name = 'test'
    camel = 3
    description = 'Test'
    commands = ('command', 'command')
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(name, camel, description, commands)

    # Constructor should raise a type error if description is not a
    # string
    name = 'test'
    camel = 'Testing'
    description = 4
    commands = ('command', 'command')

# Generated at 2022-06-21 13:06:44.877303
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig(
        name = 'test',
        camel = 'Test',
        description = 'testing setup.py command',
        commands = ('', ''),
    )
    assert test.name == 'test'
    assert test.camel == 'Test'
    assert test.description == 'testing setup.py command'
    assert test.commands == ('', '')

# Generated at 2022-06-21 13:06:55.243563
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test using setup.cfg and setup_commands.cfg in tests/data/fakedir1
    with pytest.warns(None) as record:
        itr1 = each_sub_command_config(setup_dir=os.path.join(path_dir, 'tests', 'data', 'fakedir1'))
        lst1 = list(itr1)

# Generated at 2022-06-21 13:07:01.077223
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'valid.name',
        'ValidName',
        'Example description',
        ('echo "Example command"',)
    )
    assert isinstance(config, SetupCfgCommandConfig)
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)



# Generated at 2022-06-21 13:07:06.348077
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    
    set_up = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert set_up.name == 'name'
    assert set_up.camel == 'camel'
    assert set_up.description == 'description'
    assert set_up.commands == ('commands',)

# Generated at 2022-06-21 13:07:37.259282
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO

    config = """[metadata]
name={project}

[setup.command.sub-cmd-1]
commands={project}
{project}
  --version

[setup.command.sub-cmd-2]
name={project}
command={project}
{project}
--version

[setup.command.sub-cmd-3]
name={project}
command=python -m {project} --version

[setup.command.sub-cmd-4]
name={project}
name={project}
commands=python -m {project} --version

[setup.command.sub-cmd-5]
name={project}
name={project}
commands=
    python -m {project} --version
"""


# Generated at 2022-06-21 13:07:39.980865
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'build', 'Build',
        'Build package.',
        ('python setup.py sdist bdist_wheel',)
    )

# Generated at 2022-06-21 13:07:50.670023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    import sys
    import tempfile

    td = tempfile.TemporaryDirectory()
    td.cleanup = False

# Generated at 2022-06-21 13:07:55.981604
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config())
    assert configs
    print('Num Configs: %i' % len(configs))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:04.372408
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.configutils import extract_command_name
    from flutils.pathutils import to_class_name
    from flutils.strutils import (
        underscore_to_camel,
        to_title
    )
    from flutils.testutils.subcommands import SubCommands
    from flutils.testutils.subcommands import (
        SubCommands as Parent
    )

    sc = SubCommands()
    parent = Parent()
    sc_config = sc.cmd_config
    parent_config = parent.cmd_config
    scc = SetupCfgCommandConfig(*(
        sc_config.name,
        sc_config.camel,
        sc_config.description,
        sc_config.commands
    ))
    assert scc.name == sc_config.name
    assert scc.camel

# Generated at 2022-06-21 13:08:09.828190
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    f = SetupCfgCommandConfig('a','b','c',('d','e'))
    assert f.name == 'a'
    assert f.camel == 'b'
    assert f.description == 'c'
    assert f.commands == ('d','e')

# Generated at 2022-06-21 13:08:18.819075
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.realpath(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)), os.pardir, os.pardir
        )
    )
    for cmd in each_sub_command_config(path):
        if cmd.name == 'install':
            assert cmd.description == 'Install the project'
            assert len(cmd.commands) == 2
            assert cmd.commands[0] == 'pip install .'
            assert cmd.commands[1] == 'pip install -e .'
            return
    assert False, "Missing install sub command"


# Generated at 2022-06-21 13:08:22.312682
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'spam'
    camel = 'Spam'
    description = 'Spam!'
    commands = ['a', 'b', 'c']
    c = SetupCfgCommandConfig(
        name, camel, description, tuple(commands)
    )
    assert c.name == name
    assert c.camel == camel
    assert c.description == description
    assert c.commands == tuple(commands)

# Generated at 2022-06-21 13:08:25.779379
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    ans = SetupCfgCommandConfig('name',
                                'camel',
                                'description',
                                ('command', ))
    assert ans.name == 'name'
    assert ans.camel == 'camel'
    assert ans.description == 'description'
    assert ans.commands == ('command', )

# Generated at 2022-06-21 13:08:29.669368
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'flutils.build_commands.setup_commands.test'
    camel = 'Test'
    description = 'Just a test'
    commands = ['echo test']
    SetupCfgCommandConfig(name, camel, description, commands)



# Generated at 2022-06-21 13:09:06.983152
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Test for function each_sub_command_config
    """
    import sys
    import pathlib
    from flutils.debugutils import get_debug_data
    from flutils.textutils import extract_zip_comments

    setup_dir = None
    setup_cfg_path = 'setup.cfg'
    setup_cfg = extract_zip_comments(sys.argv[0]).get(setup_cfg_path, '')
    setup_cfg = setup_cfg.strip()
    if setup_cfg:
        setup_dir = pathlib.Path(setup_cfg_path)
        setup_dir.parent.mkdir(parents=True, exist_ok=True)
        with setup_dir.open('w') as f:
            f.write(setup_cfg)
        setup_dir = str(setup_dir)


# Generated at 2022-06-21 13:09:08.597158
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig
    return



# Generated at 2022-06-21 13:09:14.461345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=no-member
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b')).name == 'name'
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b')).camel == 'Camel'
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b')).description == 'description'
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b')).commands == ('a', 'b')

# Generated at 2022-06-21 13:09:16.389311
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass


# Generated at 2022-06-21 13:09:19.977341
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'a', 'b', 'c', ('d',)
    )
    assert config.name == 'a'
    assert config.camel == 'b'
    assert config.description == 'c'
    assert config.commands == ('d',)

# Generated at 2022-06-21 13:09:27.849805
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = str(os.path.dirname(__file__))

    gen = each_sub_command_config(path)
    assert list(gen) == [
        SetupCfgCommandConfig('configure', 'Configure', '', ()),
        SetupCfgCommandConfig('test', 'Test', '', ()),
    ]

    path = os.path.join(path, '..', '..')
    gen = each_sub_command_config(path)
    assert list(gen) == [
        SetupCfgCommandConfig('configure', 'Configure', '', ()),
        SetupCfgCommandConfig('test', 'Test', '', ()),
    ]

    path = os.path.join(path, '..', '..')
    gen = each_sub_command_config(path)

# Generated at 2022-06-21 13:09:33.678741
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import join, realpath
    import sys

    def _prep_temp_setup_dir(
            real_setup_dir: str,
            temp_setup_dir: str
    ) -> str:
        for fn in ('setup.py', 'setup_commands.cfg', 'setup.cfg'):
            path = join(temp_setup_dir, fn)
            if os.path.isfile(path):
                os.unlink(path)
        copy(os.path.join(real_setup_dir, 'setup.py'), temp_setup_dir)
        copy(os.path.join(real_setup_dir, 'setup.cfg'), temp_setup_dir)

# Generated at 2022-06-21 13:09:35.299666
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig("name", "camel", "description", ("command1", "command2",))

# Generated at 2022-06-21 13:09:38.417131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(
        setup_dir=os.path.join(
            os.path.dirname(__file__), '..', '..'
        )
    ):
        print(cfg)

# Generated at 2022-06-21 13:09:46.883991
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    msg = "Objects of type 'SetupCfgCommandConfig' cannot be instantiated " \
          "using a constructor. Eliminate this error message by removing " \
          "the '__init__' method from the class definition."
    try:
        SetupCfgCommandConfig()
        assert False, msg
    except TypeError:
        pass
    assert SetupCfgCommandConfig(
        'test', 'Test', 'Test', ('test',)
    )


# Generated at 2022-06-21 13:10:10.542584
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Import here to avoid circular imports
    from flutils.pathutils import is_venv
    # Test the function in a virtual environment
    if is_venv():
        out = list(each_sub_command_config())
        assert isinstance(out, list)
        assert out != []
        assert all(isinstance(x, SetupCfgCommandConfig) for x in out)
    else:
        # Test the function in a test directory
        from pathlib import Path
        from flutils.pathutils import is_venv
        if is_venv() is False:
            cwd = os.getcwd()
        else:
            cwd = os.path.expanduser('~')
        out = Path(__file__).parent
        out = Path(out, 'test_setup_py_dir')

# Generated at 2022-06-21 13:10:20.254481
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd, desc, commands_text in (
            ('each_sub_command_config', '', ''),
            ('setup.command.foo', 'command foo', 'cmd1'),
            ('setup.command.foo.bar', 'command foo bar', 'cmd2'),
            ('setup.command.foo.bar.baz', 'command baz', 'cmd3'),
    ):
        setup_commands_cfg = dedent(f"""\
            [{cmd}]
            name = {desc}
            commands = {commands_text}
        """)
        with mock.patch.object(
                builtins,
                'open',
                new_callable=mock.mock_open
        ) as m_open:
            m_open.return_value.readline.return_value = ''
            m_open.return_

# Generated at 2022-06-21 13:10:24.897553
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyProtectedMember
    for command_config in each_sub_command_config():
        assert isinstance(command_config.name, str)
        assert isinstance(command_config.camel, str)
        assert isinstance(command_config.commands, tuple)
        assert isinstance(command_config.description, str)

# Generated at 2022-06-21 13:10:36.885472
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import subprocess

# Generated at 2022-06-21 13:10:43.977911
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc: SetupCfgCommandConfig = SetupCfgCommandConfig("name", "camel", "desc", ("cmd1", "cmd2"))
    assert sccc.name == 'name'
    assert sccc.camel == 'Camel'
    assert sccc.description == 'desc'
    assert sccc.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:10:46.863399
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-21 13:10:49.208278
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        tuple('commands')
    )

# Generated at 2022-06-21 13:10:57.067897
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Construct a command with a name and a command
    # Test name, camel, and commands
    s = SetupCfgCommandConfig("name", "Camel", "description", ("./command1.sh", "./command2.sh"))
    assert s.name == "name"
    assert s.camel == "Camel"
    assert s.description == "description"
    assert s.commands[0] == "./command1.sh"
    assert s.commands[1] == "./command2.sh"


# Generated at 2022-06-21 13:11:05.242084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit-test the function each_sub_command_config."""
    path = os.path.realpath(os.path.dirname(__file__))
    path = os.path.join(path, '..', '..')
    for config in each_sub_command_config(path):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)
        print(config)



# Generated at 2022-06-21 13:11:12.501305
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_command'
    camel = 'TestCommand'
    description = 'This is the test command.'
    commands = ('test_one', 'test_two')
    setup_cfg_command_config = SetupCfgCommandConfig(
        name,
        camel,
        description,
        commands
    )
    assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
    assert setup_cfg_command_config.name == name
    assert setup_cfg_command_config.camel == camel
    assert setup_cfg_command_config.description == description
    assert setup_cfg_command_config.commands == commands

# Generated at 2022-06-21 13:11:32.608351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Note: This tests the order of the returned sub-command configs.
    # If the order changes, then this will start failing.
    #
    # This may be an acceptable failure since this is an edge case and it
    # seems a bit brittle.
    from flutils.testutils import CmdResult, run_cmd


# Generated at 2022-06-21 13:11:43.656324
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )
    output: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(setup_dir=project_path)
    )

# Generated at 2022-06-21 13:11:47.411829
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.setuputils import each_sub_command_config
    for sub in each_sub_command_config():
        assert issubclass(type(sub), SetupCfgCommandConfig)



# Generated at 2022-06-21 13:11:54.910716
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
            'test_name', 'TestName',
            'the test_name', ('pytest', '-vs setup.py test')
          )
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'the test_name'
    assert config.commands == ('pytest', '-vs setup.py test')

# Generated at 2022-06-21 13:11:57.662816
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert [] == [
        x.name
        for x in each_sub_command_config()
    ]


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:12:00.894158
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='add_metadata',
        camel='AddMetadata',
        description='Add metadata to setup_commands.cfg',
        commands=()
    )



# Generated at 2022-06-21 13:12:03.752652
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    print(list(each_sub_command_config(cwd)))


if __name__ == '__main__':
    import sys
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-21 13:12:07.095265
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig.__doc__)
    sub_cmd = SetupCfgCommandConfig(name = '', camel = 'Test', description = 'Command description', commands = ())
    print(sub_cmd)


# Generated at 2022-06-21 13:12:12.356562
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(__file__):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    print('main')

# Generated at 2022-06-21 13:12:19.512943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert any(x == 'test.cmd' for x in each_sub_command_config('./tests'))
    assert any(x == 'test.cmd' for x in each_sub_command_config('tests'))
    assert any(x == 'test.cmd' for x in each_sub_command_config('tests/'))
    assert any(x == 'test.cmd' for x in each_sub_command_config('./tests/'))
    assert any(x == 'test.cmd' for x in each_sub_command_config('.'))
    assert any(x == 'test.cmd' for x in each_sub_command_config('./'))


# Generated at 2022-06-21 13:12:39.446385
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(__file__)
    rootdir = os.path.join(dir_path, os.path.pardir)
    rootdir = os.path.abspath(rootdir)
    setup_dir = os.path.join(rootdir, 'setup_commands')
    for command_config in each_sub_command_config(setup_dir):
        assert command_config.name != 'zz_test'
    assert command_config.description == 'description'

# Generated at 2022-06-21 13:12:45.728362
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup test data
    tmp = tempfile.mkdtemp()
    cfg_path = os.path.join(tmp, 'setup.cfg')

# Generated at 2022-06-21 13:12:52.616705
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='Foo command',
        commands=('foo', 'bar')
    )
    assert command_config.name == 'foo'
    assert command_config.camel == 'Foo'
    assert command_config.description == 'Foo command'
    assert command_config.commands == ('foo', 'bar')



# Generated at 2022-06-21 13:13:01.948943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from textwrap import dedent
    from unittest import TestCase
    from unittest.mock import patch, mock_open

    class EachSubCommandConfigTests(TestCase):

        def test_bad_setup_dir(self):
            with patch(
                    'pathlib.Path.__fspath__',
                    return_value=os.getcwd()
            ):
                with self.assertRaises(FileNotFoundError) as cm:
                    list(each_sub_command_config())
                self.assertEqual(
                    str(cm.exception),
                    "The given 'setup_dir' of %r does NOT contain a setup.py "
                    "file." % os.getcwd()
                )


# Generated at 2022-06-21 13:13:12.870874
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    ).name == 'name'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    ).camel == 'camel'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    ).description == 'description'
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    ).commands == ('commands',)

# Generated at 2022-06-21 13:13:24.574427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test that the commands have been generated correctly."""
    test_commands = (
        'echo "hello world"',
        'echo "goodbye world"',
        'echo "go to sleep"',
    )
    with tempfile.TemporaryDirectory() as setup_dir:
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-21 13:13:35.225989
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    test_dir = os.path.dirname(__file__)

    def create_config_file(name: str, contents: str, directory: str) -> str:
        out = os.path.join(directory, name)
        with open(out, 'w') as f:
            f.write(contents)
        return out

    def get_config_file_path(name: str, directory: str) -> str:
        return create_config_file(name, '', directory)

    def assert_config(
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...],
            config: SetupCfgCommandConfig
    ) -> None:
        assert name == config.name
        assert camel == config.camel


# Generated at 2022-06-21 13:13:47.338460
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from flutils.strutils import (
        multi_replace,
        underscore_to_camel,
    )
    from flutils.objutils import (
        object_to_dict,
    )
    from flutils.textutils.formatting import (
        snake_to_camel,
    )

    package_name = 'some_package'
    project_name = 'Some Project'
    project_description = 'This is a test.'

    # Command options.
    setup_command_name = snake_to_camel(package_name, lower_first=False)
    setup_command_name = underscore_to_camel(setup_command_name, lower_first=False)
    setup_command_description = 'Some description.'

# Generated at 2022-06-21 13:13:56.667962
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd1', 'cmd2'))
    assert a.name == 'name'
    assert a.camel == 'camel'
    assert a.description == 'desc'
    assert a.commands == ('cmd1', 'cmd2')

# setup_dir is not set in test case
# def test_each_sub_command_config():
#     gen = each_sub_command_config()
#     next(gen)
#     next(gen)
#     next(gen)
#     next(gen)
#     next(gen)
#     next(gen)
#     next(gen)

# setup_dir is set in test case

# Generated at 2022-06-21 13:14:01.291089
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('n', 'cn', 'd', ('c',))
    assert obj.name == 'n'
    assert obj.camel == 'Cn'
    assert obj.description == 'd'
    assert obj.commands == ('c',)



# Generated at 2022-06-21 13:14:28.529538
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('hi', 'Hi', 'bye', ('foo', 'bar'))

# Generated at 2022-06-21 13:14:40.418100
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_data = ('name', 'camel', 'description', 'commands')
    from dataclasses import fields
    from dataclasses import make_dataclass
    from flutils.dotdict import dotdict
    from itertools import permutations
    from types import MappingProxyType

    def _test_each_name(
            name: str,
            value: Union[int, str, List[str]],
            f: Callable[[Any], Any]
    ) -> None:
        setup_cfg_command: SetupCfgCommandConfig = f(dotdict(
            {x[0]: i if x[0] == name else '' for i, x in enumerate(test_data)}
        ))
        assert getattr(setup_cfg_command, name) == value


# Generated at 2022-06-21 13:14:43.343956
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pprint import pprint
    from sys import stdout
    from flutils.pyutils import class_from_name
    pprint(list(each_sub_command_config()), stdout)

# Generated at 2022-06-21 13:14:52.906460
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import redirect_stdout
    from io import StringIO
    from pathlib import Path
    from tempfile import mkdtemp

    from flutils.pathutils import path_to_str
    from flutils.strutils import block_string

    from setuputils.entrypoints import (
        _get_script_names,
        _get_scripts_dir,
        _prep_scripts_dir,
    )

    setup_dir = Path(mkdtemp())

# Generated at 2022-06-21 13:14:57.355636
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig('a','b','c','d')
    assert a.name == 'a'
    assert a.camel == 'b'
    assert a.description == 'c'
    assert a.commands == ('d',)


# Generated at 2022-06-21 13:15:01.793896
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        "description",
        "name",
        "camel",
        ["command"]
    )
    assert command.description == "description"
    assert command.name == "name"
    assert command.camel == "camel"
    assert command.commands == ("command",)

# Generated at 2022-06-21 13:15:04.135723
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name="test name",
                                   camel="TestName",
                                   description="test description",
                                   commands=("test command",))
    assert config.name == "test name" and config.camel == "TestName" \
        and config.description == "test description" \
        and config.commands == ("test command",)



# Generated at 2022-06-21 13:15:11.373408
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    import pkg_resources

    from contextlib import suppress

    from typing import Generator  # noqa

    from flutils.shell import which

    from flutils.setuputils.setup_utils import (
        InstallCfg,
        each_install_cfg,
        each_sub_command_config,
        get_install_configs,
        get_install_requirements,
        get_setup_commands,
        get_setup_dir,
        test_each_install_cfg,
        test_get_install_configs,
        test_get_install_requirements,
        test_get_setup_commands,
        test_get_setup_dir,
    )

    # The following sets up the environment for the unit tests.

# Generated at 2022-06-21 13:15:12.601356
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass


# Generated at 2022-06-21 13:15:23.544725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function each_sub_command_config."""
    def _each_cfg(expected: List[SetupCfgCommandConfig]):
        actual = list(each_sub_command_config())
        assert expected == actual

    #
    # Project with no setup_commands.cfg file.
    #
    with mock.patch.object(each_sub_command_config, '_get_name',
                           return_value='simple-package'):
        with mock.patch.object(each_sub_command_config,
                               '_each_setup_cfg_command_section',
                               return_value=[('a', 'b')]):
            with mock.patch.object(each_sub_command_config,
                                   '_each_setup_cfg_command',
                                   return_value=[]):
                _each