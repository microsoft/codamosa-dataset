

# Generated at 2022-06-21 13:06:14.045569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.join(path, 'flutils')
    path = os.path.join(path, 'tests')
    path = os.path.join(path, 'test_proj')
    path = os.path.join(path, 'test_proj')
    path = os.path.join(path, 'setup.py')
    out = each_sub_command_config(str(path))
    out = list(out)
    assert len(out) == 6
    assert out[0].name == 'test_proj.test_proj_cmd1'

# Generated at 2022-06-21 13:06:24.567219
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.pathutils import find_root_dir
    from flutils.sysutils import get_python_exe

    root_dir = find_root_dir()
    python_exe = get_python_exe()
    for c in each_sub_command_config(root_dir):
        assert isinstance(c.name, str)
        if c.name == 'test':
            assert c.camel
            assert c.description
            assert c.commands
            assert len(c.commands) == 4
            commands = c.commands
            assert commands[0] == python_exe + ' -m pytest'
            assert commands[1] == python_exe + ' -m flutils.test_command'
            assert commands[2] == 'npm test'
            assert commands[3].endsw

# Generated at 2022-06-21 13:06:29.079694
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    assert configs
    configs = list(each_sub_command_config('.'))
    assert configs
    configs = list(each_sub_command_config(os.path.expanduser('~')))
    assert configs

# Generated at 2022-06-21 13:06:30.619617
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))

# Generated at 2022-06-21 13:06:40.606603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io

    handle = io.StringIO()
    handle.write(
        """[metadata]
name = <name>

[setup.command.test.test]
name = test.test
description = testing this out

[setup.command.test.test.test]
name = test.test.test
description = <name>
commands =
    <setup_dir>/bin/console
    <setup_dir>/bin/console test
"""
    )
    handle.seek(0)
    parser = ConfigParser()
    parser.read(handle)

    format_kwargs: Dict[str, str] = {
        'setup_dir': '/Users/flc/Projects/flc/tmp/flutils',
        'home': os.path.expanduser('~')
    }
    format_kwargs

# Generated at 2022-06-21 13:06:42.891879
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(
            os.path.expanduser('~/repos/tstuff/python/flutils')
    ):
        print(config)

# Generated at 2022-06-21 13:06:53.751747
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import argparse
    import pathlib

    here = pathlib.Path(__file__).parent
    setup_dir = here.joinpath('setup_cfg_test')

    parser = argparse.ArgumentParser(
        description="Test each_sub_command_config"
    )
    parser.add_argument(
        '-n', '--name', dest='name', action='store', required=True,
        help='The project name to use in "setup.cfg" and the output '
             'file name.'
    )

    args = parser.parse_args()
    format_kwargs = {
        'name': args.name,
        'setup_dir': str(setup_dir),
        'home': str(pathlib.Path.home())
    }


# Generated at 2022-06-21 13:06:56.398177
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:07:04.382600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import mkdtemp
    from shutil import rmtree
    from flutils.pathutils import temporary_dir as td
    from flutils.pathutils import write_text_file
    from flutils.strutils import underscore_to_camel

    def _test_each_sub_command_config(
            *,
            test_name: str,
            test_strval: str,
            temp_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[Tuple[str, Tuple[str, ...]], None, None]:
        with td(temp_dir=temp_dir, prefix=test_name) as td_obj:
            setup_cfg_path = os.path.join(td_obj.temp_dir, 'setup.cfg')

# Generated at 2022-06-21 13:07:06.567823
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('', '', '', ())
    assert c

# Generated at 2022-06-21 13:07:19.946442
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'A Foo command.'
    commands = ('ls',)
    obj = SetupCfgCommandConfig(name, camel, description, commands)
    assert obj.name == name
    assert obj.camel == camel
    assert obj.description == description
    assert obj.commands == commands



# Generated at 2022-06-21 13:07:24.997246
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_name = os.path.dirname(__file__)
    path = os.path.join(dir_name, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {'name': 'project'}
    results = _each_setup_cfg_command(parser, format_kwargs)
    from pprint import pprint
    pprint(list(results))

# Generated at 2022-06-21 13:07:32.443917
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import exists, join, dirname
    from shutil import (
        copyfile,
        rmtree,
    )
    from tempfile import mkdtemp
    from textwrap import dedent

    from .test import get_testdata_path

    path = get_testdata_path(__file__, 'test_each_sub_command_config')

    def _test(
            setup_cfg_path: str,
            setup_commands_cfg_path: str,
            setup_dir: Optional[str] = None,
            expected: int = 0
    ) -> None:
        if setup_dir:
            setup_dir = join(mkdtemp(), setup_dir)
            if exists(setup_dir) is False:
                makedirs(setup_dir)

# Generated at 2022-06-21 13:07:36.490823
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('cmd',)

# Generated at 2022-06-21 13:07:43.369775
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = '/home/jkreiman/dev/flutils'
    for x in each_sub_command_config(path):
        print(x)


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        test_each_sub_command_config()
    else:
        for x in each_sub_command_config(sys.argv[1]):
            print(x)

# Generated at 2022-06-21 13:07:52.411365
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import sys
    from contextlib import redirect_stdout, redirect_stderr
    from tempfile import TemporaryDirectory


# Generated at 2022-06-21 13:07:55.674742
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # See the README.md in the test dir for details about the
    # setup_dir directory structure and content.
    for config in each_sub_command_config('test/setup_dir'):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        assert isinstance(config.commands, tuple)

# Generated at 2022-06-21 13:08:00.757217
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig(
        name='foo.bar',
        camel='FooBar',
        description='My Foo Bar',
        commands=('foo', 'bar')
    )
    assert c.name == 'foo.bar'
    assert c.camel == 'FooBar'
    assert c.description == 'My Foo Bar'
    assert c.commands == ('foo', 'bar')

# Generated at 2022-06-21 13:08:07.184757
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_config = SetupCfgCommandConfig(
        'cmd_name',
        'CmdName',
        'Description',
        tuple(('cmd1', 'cmd2'))
    )
    assert cmd_config.name == 'cmd_name'
    assert cmd_config.camel == 'CmdName'
    assert cmd_config.description == 'Description'
    assert cmd_config.commands == ('cmd1', 'cmd2')



# Generated at 2022-06-21 13:08:18.669600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import create_temp_dir
    from flutils.pathutils import rmtree
    from pprint import pformat
    from . import get_repo_root
    from .each_sub_command_config import each_sub_command_config

    root = get_repo_root()
    filepath = os.path.join(root, 'setup.cfg')
    setup_dir = create_temp_dir(prefix='setup-')
    try:
        copy(filepath, setup_dir)
        filepath = os.path.join(root, 'setup_commands.cfg')
        copy(filepath, setup_dir)
        each_sub_command_config(setup_dir)
    finally:
        rmtree(setup_dir)

    # TODO/FIXME/IDEA: Add an actual

# Generated at 2022-06-21 13:08:38.639549
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        c = SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=('command1', 'command2'))
    except:
        print('Failed to create SetupCfgCommandConfig')

# Generated at 2022-06-21 13:08:45.866772
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        "test_name",
        "TestName",
        "This is my test",
        ()
    )
    assert setup_cfg_command_config.name == "test_name"
    assert setup_cfg_command_config.camel == "TestName"
    assert setup_cfg_command_config.description == "This is my test"
    assert setup_cfg_command_config.commands == ()

# Generated at 2022-06-21 13:08:47.440126
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))

# Generated at 2022-06-21 13:08:48.736413
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub in each_sub_command_config():
        print(sub)



# Generated at 2022-06-21 13:09:00.824979
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = '/tmp/setup_dir'
    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'hello')
    parser.add_section('setup.command.hi')
    parser.set('setup.command.hi', 'name', 'Say Hi')
    parser.set('setup.command.hi', 'commands', 'echo "Hi!"')
    parser.add_section('setup.command.bye')
    parser.set('setup.command.bye', 'name', 'Say Bye')
    parser.set('setup.command.bye', 'commands', 'echo "Bye!"')

    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~'),
        'name': 'hello'
    }

# Generated at 2022-06-21 13:09:09.706290
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        SetupCfgCommandConfig()
    with pytest.raises(TypeError):
        SetupCfgCommandConfig("one")
    with pytest.raises(TypeError):
        SetupCfgCommandConfig("one", "two")
    with pytest.raises(TypeError):
        SetupCfgCommandConfig("one", "two", "three")
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(1, 2, 3, 4)
    SetupCfgCommandConfig("one", "two", "three", ("four",))


# Generated at 2022-06-21 13:09:16.396959
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import commands_utils
    import pathlib

    parent = os.path.realpath(os.path.dirname(__file__))
    parent = os.path.dirname(parent)
    parent = os.path.dirname(parent)
    parent = os.path.dirname(parent)

    path = pathlib.Path(parent)
    path = path.joinpath('commands_utils', 'tests')
    path = path.joinpath('testdata', 'test_pkg')
    path = path.resolve()

    for cfg in commands_utils.each_sub_command_config(path):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:09:21.563599
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("test", "Test", "test", ("test",))
    assert config.name == "test"
    assert config.camel == "Test"
    assert config.description == "test"
    assert config.commands == ("test",)

# Generated at 2022-06-21 13:09:23.388803
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    ret = SetupCfgCommandConfig("name", "camel", "description", tuple())
    print(ret)



# Generated at 2022-06-21 13:09:27.769569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.abspath(__file__))
    for each in each_sub_command_config(setup_dir):
        print(each)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:10:05.061900
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig('name', 'camel', 'description', ('command', 'commands'))
    assert result.name == 'name'
    assert result.camel == 'camel'
    assert result.description == 'description'
    assert result.commands == ('command', 'commands')


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-21 13:10:07.405040
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    home_dir = pathlib.Path.home()
    for config in each_sub_command_config():
        assert config



# Generated at 2022-06-21 13:10:17.479091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint as pp  # noqa: F401
    root_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    root_dir = os.path.dirname(root_dir)
    setup_dir = os.path.join(root_dir, 'setup')
    setup_dir = os.path.realpath(setup_dir)
    test_root_dir = os.path.dirname(__file__)
    test_setup_dir = os.path.join(test_root_dir, 'test_setup')
    for setup_dir in (setup_dir, test_setup_dir):
        for cfg in each_sub_command_config(setup_dir):
            print(cfg.name, cfg.description)

# Generated at 2022-06-21 13:10:20.332444
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'tests', 'pyproject.toml')
    out = list(each_sub_command_config(os.path.dirname(path)))
    print(out)

# Generated at 2022-06-21 13:10:28.136211
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    parent_path = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    for config in each_sub_command_config(parent_path):
        print(f'{config.name}:')
        print(f'\t{config.description}')
        print(f'\t{config.camel}')
        for command in config.commands:
            print(f'\t\t{command}')



# Generated at 2022-06-21 13:10:34.573822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print()
    print("Testing each_sub_command_config()...")
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        '..',
        '..'
    )
    for config in each_sub_command_config(setup_dir):
        print(config)
    print('Success.')

# Generated at 2022-06-21 13:10:38.944814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import doctest
    import sys
    import io
    import os

    class TestCase(unittest.TestCase):

        @staticmethod
        def test_each_sub_command_config_doctest():
            original_stdout = sys.stdout
            sys.stdout = io.StringIO()
            try:
                doctest.testmod(
                    name='each_sub_command_config',
                    globs={'each_sub_command_config': each_sub_command_config},
                    verbose=False,
                    optionflags=doctest.ELLIPSIS,
                )
            finally:
                sys.stdout.seek(0)
                v = sys.stdout.read()
                sys.stdout.close()
                sys.stdout = original_stdout
            return v

# Generated at 2022-06-21 13:10:46.936229
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_config = SetupCfgCommandConfig(
        name='my_name',
        camel='MyName',
        description='my_description',
        commands=tuple(['my_command'])
    )
    assert cmd_config.name == 'my_name'
    assert cmd_config.camel == 'MyName'
    assert cmd_config.description == 'my_description'
    assert cmd_config.commands == ('my_command',)


# Generated at 2022-06-21 13:10:52.796152
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="description",
        commands=("command1", "command2")
    )

    assert config.name == "name"
    assert config.camel == "Camel"
    assert config.description == "description"
    assert config.commands == ("command1", "command2")

# Generated at 2022-06-21 13:11:03.089476
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import skip_on_travis_ci
    from flutils.testutils import is_unit_test

    if is_unit_test is False:
        skip_on_travis_ci()

    setup_cfg_dir = os.path.join('tests', 'assets', 'setup_cfg_files')

    def _do_test(**kwargs):
        for config in each_sub_command_config(**kwargs):
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            assert all(isinstance(x, str) for x in config.commands)


# Generated at 2022-06-21 13:12:16.067238
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_path = os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
    setup_cfg = os.path.join(pkg_path, 'setup.cfg')
    setup_commands = os.path.join(pkg_path, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg)
    name = _get_name(parser, setup_cfg)

    parser = ConfigParser()
    parser.read(setup_commands)
    out = list(_each_setup_cfg_command(parser, {
        'name': name,
        'setup_dir': pkg_path,
        'home': os.path.expanduser('~')
    }))
    assert len(out) == 2
   

# Generated at 2022-06-21 13:12:26.886414
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert all([
        SetupCfgCommandConfig('a', 'b', 'c', ('d',)),
        SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e')),
        SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e', 'f')),
        SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e', 'f', 'g')),
    ])

    try:
        SetupCfgCommandConfig('a', 'b', 'c', ())
    except:
        pass
    else:
        assert False, 'Expected an Exception to be raised.'

    try:
        SetupCfgCommandConfig('a', 'b', 'c', ('d', '', 'f'))
    except:
        pass

# Generated at 2022-06-21 13:12:37.807030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function, each_sub_command_config."""

    def _each_setup_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[str, None, None]:
        for config in each_sub_command_config(
                setup_dir=setup_dir
        ):
            for cmd in config.commands:
                yield cmd

    assert (
        ''.join(_each_setup_command_config())
    ).strip() == ''.join([
        'python setup.py develop',
        'python setup.py egg_info',
        'python setup.py sdist',
    ]).strip()


# Generated at 2022-06-21 13:12:38.433151
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:12:39.983016
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('n', 'N', 'd', ('a',))


# Generated at 2022-06-21 13:12:48.381147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_sub_command_config(
            sub_cmd: SetupCfgCommandConfig
    ) -> None:
        assert isinstance(sub_cmd, SetupCfgCommandConfig)
        assert sub_cmd.name
        assert sub_cmd.camel
        assert sub_cmd.description
        assert sub_cmd.commands

    for sub_cmd in each_sub_command_config(
        '/Users/justin/Projects/deploy-tools/flutils'
    ):
        _test_sub_command_config(sub_cmd)

# Generated at 2022-06-21 13:12:50.866337
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('test', 'Test', 'test', ('python', 'test'))


# Generated at 2022-06-21 13:13:00.438348
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # read current config
    configs = list(each_sub_command_config())

    # save backup
    pth = os.path.join(os.path.dirname(_prep_setup_dir()), 'setup.cfg')
    backup_pth = os.path.join(os.path.dirname(_prep_setup_dir()), 'setup.cfg.bak')
    with open(pth, 'rt') as fin:
        with open(backup_pth, 'wt') as fout:
            fout.write(fin.read())


# Generated at 2022-06-21 13:13:12.605550
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config('./test/test_setup_corral'))

# Generated at 2022-06-21 13:13:24.348491
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    def _test(the_temp_dir: str, setup_dir: Optional[str]) -> None:
        the_setup_cfg: List[str] = [
            '[metadata]',
            'name = foo',
            '[setup.command.foo]',
            'commands =',
            '    python setup.py foo',
            '[setup.command.bar]',
            'commands =',
            '    python setup.py bar'
        ]
        setup_cfg_path = os.path.join(the_temp_dir, 'setup.cfg')
        with open(setup_cfg_path, 'wb') as fp:
            fp.write(b'\n'.join(map(lambda x: cast(bytes, x), the_setup_cfg)))

        setup_commands_cfg