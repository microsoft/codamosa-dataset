

# Generated at 2022-06-21 13:06:13.219199
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(setup_dir, 'test_data', 'setup_commands')

# Generated at 2022-06-21 13:06:19.608061
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    value = SetupCfgCommandConfig("command_name", "_CommandName_", "Command Description",
                                  ("command1", "command2"))
    assert value.name == "command_name"
    assert value.camel == "_CommandName_"
    assert value.description == "Command Description"
    assert value.commands == ("command1", "command2")


if __name__ == '__main__':
    print("Running doctests...")
    import doctest
    doctest.testmod()
    print("Completed doctests.")

# Generated at 2022-06-21 13:06:26.559015
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='hello',
        camel='Hello',
        description='Hello world',
        commands=('echo Hello World', 'echo Hello World')
    )
    assert config.name == 'hello'
    assert config.camel == 'Hello'
    assert config.description == 'Hello world'
    assert config.commands == ('echo Hello World', 'echo Hello World')

# Generated at 2022-06-21 13:06:29.793932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(
            setup_dir=os.path.join(
                os.path.dirname(__file__),
                '..',
                '..'
            )
    ):
        print(cfg)



# Generated at 2022-06-21 13:06:35.925985
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'a.b.c'
    camel = 'ABC'
    description = 'D E F'
    commands = ('g', 'h', 'i')
    sccc = SetupCfgCommandConfig(name, camel, description, commands)
    assert sccc.name == name
    assert sccc.camel == camel
    assert sccc.description == description
    assert sccc.commands == commands



# Generated at 2022-06-21 13:06:39.393826
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    e = 'test'
    k = SetupCfgCommandConfig(e, e, e, (e,))
    assert k.name == e
    assert k.camel == e
    assert k.description == e
    assert k.commands == (e,)


# Generated at 2022-06-21 13:06:43.223435
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command', ))
# pylint: enable=C0103,C0111,W0212
# VSCode settings for Python unit testing using unittest:
#   "python.testing.unittestArgs": [
#      "-v",
#      "-s=test.test_stats.test_package_stats",
#      "-p=test*.py"
#   ],

# Generated at 2022-06-21 13:06:54.081849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    from sys import modules
    from pathlib import Path
    from types import ModuleType
    from unittest import TestCase, main

    from importlib.util import spec_from_loader, module_from_spec
    from importlib.machinery import SourceFileLoader

    module_name = 'flutils.test_setup_cfg'
    module_path = Path(modules[module_name].__file__).resolve()
    module_dir = module_path.parent
    module_name_path = module_dir / '%s.py' % module_name
    module_name_path = module_name_path.resolve()

    loader = SourceFileLoader(module_name, str(module_name_path))

# Generated at 2022-06-21 13:07:00.138402
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    sccc = SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.description == 'description'
    assert sccc.commands == ('command1', 'command2')


# Generated at 2022-06-21 13:07:10.460751
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected_name = 'build.subsubsubsubsubsubsubsubsubsub'
    expected_camel = 'BuildSubsubsubsubsubsubsubsubsubsub'
    expected_description = 'this is a test'
    expected_commands = [
        'echo | echo | echo',
        'echo | echo | echo',
        'echo | echo | echo',
    ]
    s = SetupCfgCommandConfig(
        expected_name,
        expected_camel,
        expected_description,
        tuple(expected_commands)
    )
    assert s.name == expected_name
    assert s.camel == expected_camel
    assert s.description == expected_description
    assert s.commands == expected_commands

# Generated at 2022-06-21 13:07:42.695789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    end = 'flutils.tests'
    base_path = os.path.abspath(os.path.dirname(__file__))
    idx = base_path.rfind(end)
    if idx < 0:
        raise RuntimeError("This unit test must run from inside '%s'." % end)
    base_path = base_path[:idx + len(end)]
    base_path = os.path.join(base_path, 'data', 'setup_cfg_reader')
    for name in ('root', 'child'):
        for config in each_sub_command_config(
                os.path.join(base_path, name)
        ):
            assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:07:44.536324
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo', 'Foo', 'foo', ('foo', 'bar')
    ) == ('foo', 'Foo', 'foo', ('foo', 'bar'))

# Unit tests for private methods

# Generated at 2022-06-21 13:07:46.787566
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b', 'c'))

# Generated at 2022-06-21 13:07:54.019831
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import Mock
    from flutils.testutils import UnitTestBase
    from setup_commands.setup_commands import (
        each_sub_command_config,
        SetupCfgCommandConfig
    )

    class TestSetupCfgCommandConfig(UnitTestBase):
        def test_constructor(self):
            mock_setup_cfg_command_section = Mock()
            mock_setup_cfg_command_section.name = 'section name'
            mock_setup_cfg_command_section.camel = 'Section Name'
            mock_setup_cfg_command_section.description = 'Description'
            mock_setup_cfg_command_section.commands = ('command',)

# Generated at 2022-06-21 13:07:59.595114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'test_pkg')
    for config in each_sub_command_config(path):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)

# Generated at 2022-06-21 13:08:10.107880
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from itertools import islice
    from pathlib import Path

    project_dir = str(Path(__file__).parent.parent)
    sc = tuple(each_sub_command_config(project_dir))

# Generated at 2022-06-21 13:08:16.439024
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    actual = [_ for _ in each_sub_command_config('../setup_commands')]
    expected = [
        SetupCfgCommandConfig(
            'command.hello.world',
            'CommandHelloWorld',
            'Hello world by the setup commands extension.',
            ('echo "setup_commands.examples.hello_world.HelloWorld()"',)
        )
    ]
    assert actual == expected



# Generated at 2022-06-21 13:08:25.780575
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.abspath(os.path.dirname(__file__))
    setup_dir = os.path.join(test_dir, '../../..')
    out = list(each_sub_command_config(setup_dir))
    assert out
    assert len(out) == 3
    assert out[0].name == 'build'
    assert out[0].camel == 'Build'
    assert out[0].description
    assert out[0].commands
    assert len(out[0].commands) == 1
    assert out[0].commands[0]
    assert out[0].commands[0].startswith('python setup.py sdist')
    assert out[1].name == 'clean'
    assert out[1].camel == 'Clean'

# Generated at 2022-06-21 13:08:36.665238
# Unit test for function each_sub_command_config

# Generated at 2022-06-21 13:08:38.515703
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='This is my description.',
        commands=('echo "Hello, world!"',)
    )



# Generated at 2022-06-21 13:09:05.224235
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    from flutils.testing import run_doctest

    dir_path = tempfile.mkdtemp()
    path = os.path.join(dir_path, 'setup.py')
    with open(path, 'w') as f:
        f.write("""\
import os
from setuptools import setup
setup(name='foo')
""")

    path = os.path.join(dir_path, 'setup.cfg')

# Generated at 2022-06-21 13:09:06.799667
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('foo', 'foo', 'bar', ('baz', 'quux'))

# Generated at 2022-06-21 13:09:15.174081
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for section, name in _each_setup_cfg_command_section(parser):
        commands: List[str] = []
        options: List[str] = parser.options(section)
        for option in ('command', 'commands'):
            if option in options:
                val: str = parser.get(section, option)
                val = val.format(**format_kwargs)
                commands += list(
                    filter(len, map(lambda x: x.strip(), val.splitlines()))
                )
        if commands:
            cmd_name = ''
            if 'name' in options:
                cmd_name = parser.get(section, 'name')
            cmd_name = cmd_name or name
            cmd_name = cmd_name.format(name=format_kwargs['name'])

# Generated at 2022-06-21 13:09:23.653622
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        SetupCfgCommandConfig()
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('name')
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('name', 'camel')
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description')

    config = SetupCfgCommandConfig('name', 'camel', 'description', ())
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ()



# Generated at 2022-06-21 13:09:32.723766
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    commands = SetupCfgCommandConfig(
        name='compile_catalog',
        camel='CompileCatalog',
        description='Compile the catalog of message translations.',
        commands=('python setup.py compile_catalog -l en -f',
                  'python setup.py compile_catalog -l de -f'),
    )
    assert commands.name == 'compile_catalog'
    assert commands.camel == 'CompileCatalog'
    assert commands.description == 'Compile the catalog of message translations.'
    assert commands.commands == (
        'python setup.py compile_catalog -l en -f',
        'python setup.py compile_catalog -l de -f',
    )
    assert commands.comma

# Generated at 2022-06-21 13:09:37.436112
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel', 'description', 'commands')
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == 'commands'


# Generated at 2022-06-21 13:09:49.981434
# Unit test for function each_sub_command_config

# Generated at 2022-06-21 13:09:56.748427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def one(setup_dir) -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(setup_dir)
    out = tuple(one(os.path.join(os.path.dirname(__file__), 'testdata', 'test1')))
    assert(len(out) == 1)
    assert(out[0].name == 'test1')
    assert(out[0].camel == 'Test1')
    assert(out[0].description == '')
    expected = (
        'echo "this is the test1 command. setup_dir = %(setup_dir)s"'
    )
    assert(out[0].commands[0].strip() == expected.strip())

# Generated at 2022-06-21 13:09:59.087578
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("name", "camel", "description", ("command", "test",))

# Generated at 2022-06-21 13:10:05.061253
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sec = [
        SetupCfgCommandConfig('foo', 'Foo', 'Foo Command', ('cmd',)),
        SetupCfgCommandConfig('bar', 'Bar', 'Bar Command', ('cmd',)),
        SetupCfgCommandConfig('baz', 'Baz', 'Baz Command', ('cmd',)),
    ]
    assert each_sub_command_config() == sec

# Generated at 2022-06-21 13:10:32.138745
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig.__doc__
    assert SetupCfgCommandConfig.name.__doc__
    assert SetupCfgCommandConfig.camel.__doc__
    assert SetupCfgCommandConfig.description.__doc__
    assert SetupCfgCommandConfig.commands.__doc__

# Generated at 2022-06-21 13:10:40.561689
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import MagicMock
    cfg_mock = MagicMock()
    cfg_mock.sections.return_value = ['setup.command.test', 'test', 'skip']
    cfg_mock.options.return_value = ('command',)
    cfg_mock.get.return_value = 'test'
    cfg_mock.read = MagicMock()
    assert list(
        _each_setup_cfg_command(cfg_mock, {'name': 'test', 'setup_dir': 'test'})
    ) == [SetupCfgCommandConfig(
        'test',
        'Test',
        '',
        ('test',)
    )]


if __name__ == '__main__':  # pragma: no cover
    import argparse

# Generated at 2022-06-21 13:10:46.036717
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test', 'Test', 'test', ('cmd1', 'cmd2'))
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-21 13:10:51.124366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands = list(each_sub_command_config())
    assert len(commands) > 0
    command = commands[0]
    assert command.name
    assert command.camel
    assert command.description
    assert len(command.commands) > 0
    for command in commands:
        for c in ('name', 'camel', 'description', 'commands'):
            v = getattr(command, c)
            assert isinstance(v, str) or isinstance(v, tuple)

# Generated at 2022-06-21 13:11:01.691480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    path = os.path.join(here, 'command', 'setup_commands.cfg')
    setup_dir = os.path.dirname(here)
    assert os.path.isfile(path) is True
    assert os.path.isdir(setup_dir) is True

    out = list(each_sub_command_config(setup_dir))
    assert len(out) == 2
    assert isinstance(out, list) is True
    assert isinstance(out[0], SetupCfgCommandConfig) is True
    assert out[0].name == 'setup-command-1'
    assert out[0].camel == 'SetupCommand1'
    assert out[0].description == 'A one.'

# Generated at 2022-06-21 13:11:07.781645
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for scc in each_sub_command_config(os.path.dirname(__file__)):
        assert isinstance(scc, SetupCfgCommandConfig)
        assert isinstance(scc.name, str)
        assert isinstance(scc.camel, str)
        assert isinstance(scc.description, str)
        assert isinstance(scc.commands, tuple)
        assert all(isinstance(x, str) for x in scc.commands)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:11:14.746181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with make_test_repo() as repo_path:
        commands: List[SetupCfgCommandConfig] = []
        for config in each_sub_command_config(repo_path):
            config = cast(SetupCfgCommandConfig, config)
            commands.append(config)
        assert len(commands) == 2

        config = commands[0]
        assert config.name == 'test_setup.foo'
        assert config.camel == 'TestSetupFoo'
        assert config.description == 'Foo!.'
        assert config.commands == ('pytest', )

        config = commands[1]
        assert config.name == 'test_setup.bar'
        assert config.camel == 'TestSetupBar'
        assert config.description == 'Bar!.'
        assert config.commands == ('make test', )

# Generated at 2022-06-21 13:11:22.388344
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_command'
    camel = 'TestCommand'
    description = 'command description'
    commands = ('Command 1', 'Command 2')
    cmd_config = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(cmd_config, SetupCfgCommandConfig)
    assert name == cmd_config.name
    assert camel == cmd_config.camel
    assert description == cmd_config.description
    for i, cmd in enumerate(cmd_config.commands):
        assert cmd == commands[i]


# Generated at 2022-06-21 13:11:31.300658
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.join(here, 'resources', 'test_project')
    for config in each_sub_command_config(setup_dir):
        cmd_name = config.name
        cmd_camel = config.camel
        description = config.description
        commands = config.commands
        if cmd_name == 'build.sdist':
            assert cmd_name in ('build.sdist', 'build.bdist_wheel')
            assert cmd_camel == 'BuildSdist'
            assert description == 'Generate a source distribution of the proj'
            assert commands == ('python setup.py sdist', )

# Generated at 2022-06-21 13:11:36.728291
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('Name', 'Camel', 'Desc', ('cmd1', 'cmd2'))
    assert config.name == 'Name'
    assert config.camel == 'Camel'
    assert config.description == 'Desc'
    assert config.commands == ('cmd1', 'cmd2')



# Generated at 2022-06-21 13:12:08.171458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        itr = each_sub_command_config(setup_dir)
        cmds: List[SetupCfgCommandConfig] = list(itr)
        assert cmds

    _test(os.path.dirname(os.path.dirname(__file__)))


# Generated at 2022-06-21 13:12:17.406702
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock

    from pkg_resources import Distribution
    from pkg_resources import get_distribution

    get_distribution = Mock(wraps=get_distribution)

    def _each_entry_point(*args, **kwargs
                          ) -> Generator[Distribution, None, None]:
        for k, v in (
                ('flutils_entry_point_1', '1'),
                ('flutils_entry_point_2', '2'),
                ('flutils_entry_point_3', '3'),
        ):
            yield Distribution(k, k, k, k, k, k, k), v

    get_distribution.return_value.get_entry_map.return_value = {
        'console_scripts': dict(_each_entry_point())
    }


# Generated at 2022-06-21 13:12:24.621070
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'some.name'
    camel = 'SomeName'
    description = 'Some description'
    commands = ('one', 'two', 'three')

    expected = SetupCfgCommandConfig(name, camel, description, commands)
    inst = SetupCfgCommandConfig(name, camel, description, commands)

    assert inst.name == expected.name
    assert inst.camel == expected.camel
    assert inst.description == expected.description
    assert inst.commands == expected.commands

# Generated at 2022-06-21 13:12:27.265956
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name="a",
        camel="a",
        description="b",
        commands=("c", "d"),
    )



# Generated at 2022-06-21 13:12:38.216928
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    if sys.platform.startswith('win'):
        home = os.environ['HOMEDRIVE'] + os.environ['HOMEPATH']
    else:
        home = os.environ['HOME']
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.abspath(os.path.join(setup_dir, '..'))
    out = []
    for config in each_sub_command_config(setup_dir):
        config = cast(SetupCfgCommandConfig, config)
        out.append((
            config.name, config.camel, config.description, config.commands
        ))
    out = tuple(out)

# Generated at 2022-06-21 13:12:42.282859
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected = [
        SetupCfgCommandConfig(
            'test.test_project.test',
            'TestTestProjectTest',
            'Run the test project test',
            ('pipenv run pytest {setup_dir}',)
        )
    ]
    assert list(each_sub_command_config(
        os.path.join(os.path.dirname(__file__), '..')
    )) == expected

# Generated at 2022-06-21 13:12:53.849707
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import textwrap
    import tempfile
    from flutils.testutils.base_utils import all_of_type

    with tempfile.TemporaryDirectory() as tmp:
        # tmp is the path to the temporary directory
        project_name = 'myproj'

# Generated at 2022-06-21 13:12:56.429818
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test',
        'Test',
        'test',
        ('ls', 'pwd', 'echo Test')
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('ls', 'pwd', 'echo Test')

# Generated at 2022-06-21 13:13:03.649190
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(__file__):
        print(config)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)
            if cmd:
                assert cmd.startswith('python -m ')
        assert isinstance(config.camel, str)
        assert isinstance(config.name, str)
        assert config.name.isidentifier() is True
        assert isinstance(config.description, str)
        assert config.description.endswith('.')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:13:07.603436
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        # name
        'test_name',
        # camel
        'TestName',
        # description
        'test_description',
        # commands
        ('command',)
    )

# Generated at 2022-06-21 13:14:07.332012
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the SetupCfgCommandConfig constructor."""
    name = 'test_name'
    camel = 'TestName'
    desc = 'This is a test of the constructor.'
    cmd1 = 'python setup.py test'
    cmd2 = 'python setup.py pylint'
    cmds = (cmd1, cmd2)
    scc = SetupCfgCommandConfig(name, camel, desc, cmds)
    assert scc.name == name
    assert scc.camel == camel
    assert scc.description == desc
    assert scc.commands == cmds


# Generated at 2022-06-21 13:14:07.854116
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:14:12.335658
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected = [
        ('git.commit', 'git commit', 'Git commit.', ('git commit',)),
        ('git.status', 'git status', 'Git status.', ('git status',)),
    ]

    actual = list(
        each_sub_command_config(
            '/Users/david/PycharmProjects/setup-command'
        )
    )

    assert expected == actual

# Generated at 2022-06-21 13:14:23.687818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config()."""
    import inspect
    import os
    import tempfile
    import textwrap
    from io import StringIO
    from pathlib import Path
    from shutil import rmtree

    from flutils.osutils import temp_dir
    from flutils.strutils import camel_to_snake

    from . import setuputils as tut

    def _write_setup_cfg(filepath: Union[Path, str], name: str) -> None:
        filepath = Path(filepath)

# Generated at 2022-06-21 13:14:30.998681
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'setup.command.test'
    parser = ConfigParser()
    parser.add_section(section)
    parser.set(section, 'description', 'Test command')
    parser.set(section, 'commands', 'echo')
    c = _each_setup_cfg_command(parser, {'name': 'foo'})
    assert c[0].name == 'test'
    assert c[0].camel == 'Test'
    assert c[0].description == 'Test command'
    assert c[0].commands == ('echo',)


# Generated at 2022-06-21 13:14:42.234070
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import unittest.mock as mock

    class TestEachSubCommandConfig(unittest.TestCase):
        @mock.patch('flutils.pathutils.setuputils.extract_stack')
        def test_each_sub_command_config_with_setup_dir_given(
                self,
                mock_extract_stack
        ):
            mock_extract_stack.return_value = [[
                '', '', 'setup.py', 1, '', 0
            ]]
            with mock.patch('os.path.isdir') as mock_isdir:
                mock_isdir.return_value = True
                with mock.patch('os.path.isfile') as mock_isfile:
                    mock_isfile.side_effect = [False, False, True]

# Generated at 2022-06-21 13:14:43.834046
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel_name', 'description', ('command',))

# Generated at 2022-06-21 13:14:49.250904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'my_cmd'
    camel = 'MyCmd'
    description = "This is my command."
    commands = 'ls -latr', 'pwd'
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-21 13:14:53.219881
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(name='name',
                                 camel='Camel',
                                 description='description',
                                 commands=[])
    assert sccc.name == 'name'
    assert sccc.camel == 'Camel'
    assert sccc.description == 'description'
    assert sccc.commands == ()

# Generated at 2022-06-21 13:14:58.091537
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a: SetupCfgCommandConfig = SetupCfgCommandConfig('c', 'C', 'D', ('e', 'f'))
    assert a.name == 'c'
    assert a.camel == 'C'
    assert a.description == 'D'
    assert a.commands == ('e', 'f')