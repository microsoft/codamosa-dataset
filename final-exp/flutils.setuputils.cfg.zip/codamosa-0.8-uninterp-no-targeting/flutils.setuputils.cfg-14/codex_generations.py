

# Generated at 2022-06-21 13:06:02.024236
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-21 13:06:08.925447
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/home/todd/dev/flutils/flutils'
    for config in each_sub_command_config(setup_dir):
        print(config)
        assert len(config) == 4
        assert isinstance(config[0], str)
        assert isinstance(config[1], str)
        assert isinstance(config[2], str)
        assert isinstance(config[3], tuple)
        for cmd in config[3]:
            assert isinstance(cmd, str)



# Generated at 2022-06-21 13:06:15.661631
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        setup_cfg_command_config = SetupCfgCommandConfig(
            "test_name",
            "Test_name",
            "test description",
            ("test command1",)
        )
    except Exception as e:
        raise AssertionError("test_name should not generate an exception: " + str(e))

    if setup_cfg_command_config.name != "test_name":
        raise AssertionError("name is wrong")
    if setup_cfg_command_config.camel != "Test_name":
        raise AssertionError("camel is wrong")
    if setup_cfg_command_config.description != "test description":
        raise AssertionError("description is wrong")

# Generated at 2022-06-21 13:06:19.220155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
    for config in each_sub_command_config(os.path.expanduser('~')):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:06:24.482480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(os.path.dirname(__file__))
    setup_dir = os.path.join(here, os.path.pardir)
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.commands



# Generated at 2022-06-21 13:06:28.046805
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'name', 'description',
                                 ('commands',)) == (
        'name', 'name', 'description', ('commands',)
    )



# Generated at 2022-06-21 13:06:31.383727
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    directory = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', '..', 'tests', 'project'
    )
    assert os.path.isdir(directory) is True
    commands = tuple(
        map(lambda x: x.commands, each_sub_command_config(directory))
    )
    assert commands == (
        ('echo -n "Hello, World!"',),
        ('bash <(curl -s https://codecov.io/bash) -f coverage.xml',),
        ('python coverage.py',),
        tuple(),
        ('coverage erase',),
    )

# Generated at 2022-06-21 13:06:38.551597
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from msb_coverage_badge import __file__ as proj_path
    proj_path = os.path.dirname(proj_path)
    import pytest

    @pytest.mark.parametrize('setup_dir', [None, proj_path])
    def test(setup_dir):
        gen = each_sub_command_config(setup_dir)
        assert next(gen) is not None

    test()


if __name__ == '__main__':
    raise SystemExit(pytest.main(__file__))

# Generated at 2022-06-21 13:06:40.682017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    each_sub_command_config(os.path.expanduser('~/dev/flutils/src'))

# Generated at 2022-06-21 13:06:47.955289
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected_name = 'foo'
    expected_camel = 'Foo'
    expected_description = 'bar'
    expected_commands = ('baz', 'qux')
    output = SetupCfgCommandConfig(
        expected_name,
        expected_camel,
        expected_description,
        expected_commands
    )
    assert output.name == expected_name
    assert output.camel == expected_camel
    assert output.description == expected_description
    assert output.commands == expected_commands



# Generated at 2022-06-21 13:07:12.149778
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from random import shuffle
    from flutils.pyutils import test_dir
    from flutils.logutils import _logging
    from flutils.setuputils import _setup_commands_config

    setup_dir = test_dir()
    config_file = os.path.join(setup_dir, 'setup_commands.cfg')
    with open(config_file, 'w') as fp:
        fp.write("[setup.command.test]\n")
        fp.write("command = {my_py_version}\n")
        fp.write("name = my_py_version\n")
        fp.write("description = This tests the version of Python.\n")
        fp.write("[setup.command.foo.bar]\n")

# Generated at 2022-06-21 13:07:12.851936
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:07:22.029193
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for sub_command, data in (
        ('sub', ('sub', 'Sub', 'sub description', ('sub command', ))),
        ('sub.sub_sub', ('sub.sub_sub', 'SubSub',
                         'sub sub description', ('sub sub command', ))),
        ('sub-sub-sub', ('sub-sub-sub', 'SubSubSub',
                         'sub sub sub description', ('sub sub sub command', )))
    ):
        sc = SetupCfgCommandConfig(sub_command, data[0], data[1], data[2])
        assert sc.name == sub_command
        assert sc.camel == data[1]
        assert sc.description == data[2]
        assert sc.commands == data[3]

# Generated at 2022-06-21 13:07:30.475924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile
    from textwrap import dedent

    #
    # setup.cfg contents
    #

# Generated at 2022-06-21 13:07:41.800170
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.split(os.path.realpath(__file__))[0]
    path = os.path.join(path, 'setup.cfg')
    if os.path.isfile(path) is False:
        raise FileNotFoundError(
            "The file of %r does NOT exist." % path
        )

    import unittest
    class EachSubCommandConfigTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.setup_dir = os.path.dirname(path)
            assert os.path.isfile(path)
            cls.parser = ConfigParser()
            cls.parser.read(path)

# Generated at 2022-06-21 13:07:51.769557
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import inspect
    import os
    import tempfile
    from configparser import ConfigParser
    from flutils.miscutils import get_free_port
    from shutil import rmtree
    from os.path import join

    from flutils.fileutils import (
        atomic_symlink,
        atomic_write,
        rm_symlink,
        write_to_temp_dir
    )
    from flutils.testutils import suppress_stdout_stderr

    with suppress_stdout_stderr():
        temp_dir = tempfile.mkdtemp()
        name = 'setup_commands_test'
        setup_cfg = '[metadata]\nname={name}\n'.format(name=name)

# Generated at 2022-06-21 13:07:55.606480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config():
        print(sub_cmd.name)
        for cmd in sub_cmd.commands:
            print('  %s' % cmd)
    print('-'*79)
    for sub_cmd in each_sub_command_config(
            setup_dir=os.path.expanduser('~/dev/flutils')
    ):
        print(sub_cmd.name)
        for cmd in sub_cmd.commands:
            print('  %s' % cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:08:04.184654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> List[SetupCfgCommandConfig]:
        out = list(each_sub_command_config(setup_dir))
        assert len(out) > 0
        return out

    try:
        _test_each_sub_command_config('/tmp')
    except FileNotFoundError:
        pass

    try:
        _test_each_sub_command_config('/dev')
    except FileNotFoundError:
        pass

    try:
        _test_each_sub_command_config('/dev/null')
    except FileNotFoundError:
        pass


# Generated at 2022-06-21 13:08:17.064578
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch, MagicMock

    class MockNameTuple(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]


# Generated at 2022-06-21 13:08:25.201689
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from contextlib import closing
    from io import StringIO
    from flutils.sysutils import _path_is_installable
    from flutils.testutils import (IterateTestValues, UnitTestRunner)

    class TestCaseData(NamedTuple):
        name: str
        description: str
        expected: List[Tuple[str, ...]]


# Generated at 2022-06-21 13:09:05.152637
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    os.environ['PYTHONPATH'] = ''

    def write_setup_file(temp_dir: str, setup_py_name: str) -> str:
        with open(os.path.join(temp_dir, 'setup_commands.cfg'),
                  'wt') as f:
            f.write(
                '[setup.command.foo]\n'
                'name: Foo\n'
                'commands: '
                'python {setup_dir}/foo.py\n'
                '[setup.command.bar]\n'
                'name: Bar\n'
                'commands: '
                'python {setup_dir}/bar.py\n'
                .format(setup_dir=temp_dir)
            )


# Generated at 2022-06-21 13:09:13.953399
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import unittest.mock as mock

    SC = SetupCfgCommandConfig

    with mock.patch('flutils.configutils.os') as mo:
        class Obj:
            def __init__(self, name: str, camel: str, desc: str, cmds: Tuple[str, ...]):
                self.name = name
                self.camel = camel
                self.description = desc
                self.commands = cmds

            def __eq__(self, other):
                return (
                    self.name == other.name and
                    self.camel == other.camel and
                    self.description == other.description and
                    self.commands == other.commands
                )


# Generated at 2022-06-21 13:09:18.963014
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class_name = "SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=('command1', 'command2'))"
    assert str(SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))) == class_name

# Generated at 2022-06-21 13:09:27.079801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.projectutils import each_sub_command_config, get_version

    for sub_config in each_sub_command_config():
        print('sub_config: %s' % sub_config)

    print('sub_config: %s' % next(each_sub_command_config(None)))
    print('sub_config: %s' % next(each_sub_command_config()))
    print('sub_config: %s' % next(each_sub_command_config(
        'tests/test_functional/test_project')))
    print('get_version: %s' % get_version('tests/test_functional/test_project'))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:09:32.326265
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'dummy_name',
        'DummyName',
        'Dummy description.',
        ('command1', 'command2')
    )
    # Test config attributes
    assert config.name == 'dummy_name'
    assert config.camel == 'DummyName'
    assert config.description == 'Dummy description.'
    assert config.commands == ('command1', 'command2')



# Generated at 2022-06-21 13:09:38.375686
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        "frozen-flask",
        "FrozenFlask",
        "Freezes a Flask Web Application",
        ("echo cmd1", "echo cmd2",)
    )
    assert setup_cfg_command_config
    assert setup_cfg_command_config.name == "frozen-flask"
    assert setup_cfg_command_config.camel == "FrozenFlask"
    assert setup_cfg_command_config.description == "Freezes a Flask Web Application"
    assert setup_cfg_command_config.commands == ("echo cmd1", "echo cmd2",)



# Generated at 2022-06-21 13:09:50.816326
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """This tests each_sub_command_config."""

    def _expect_no_commands(setup_dir: os.PathLike) -> Generator[None, None, None]:
        with pytest.raises(FileNotFoundError):
            list(each_sub_command_config(setup_dir))

    with tempfile.TemporaryDirectory(prefix='test_each_sub_command_config_') as setup_dir:
        _expect_no_commands(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        with open(setup_py_path, 'w') as output:
            output.write('')
        _expect_no_commands(setup_dir)

# Generated at 2022-06-21 13:09:57.150189
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # os.chdir(os.path.join(os.path.dirname(__file__), 'testdata'))
    out = list(each_sub_command_config())
    assert isinstance(out, list)
    assert len(out) == 2
    assert isinstance(out[0], SetupCfgCommandConfig)
    assert out[0].name == 'test.one'
    assert out[0].description == 'description one'
    assert len(out[0].commands) == 3
    assert out[0].commands[0] == 'echo -n "1"'
    assert out[0].commands[1] == 'echo -n "2"'
    assert out[0].commands[2] == 'echo -n "3"'

# Generated at 2022-06-21 13:10:08.650188
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # One command config
    cmds = ["ls dir -la"]
    c = SetupCfgCommandConfig("list.dirs", "ListDirs", "Lists all dirs", cmds)

    # Multiple command config
    cmds = ["ls dir -la", "mkdir result.tmp"]
    c = SetupCfgCommandConfig("list.dirs", "ListDirs", "Lists all dirs", cmds)

    # Test setters
    c.name = "newname"
    c.camel = "NewName"
    c.description = "New Description"
    c.commands = ("ls dir -la", "mkdir result.tmp")

    # Test getters
    assert c.name == "newname"
    assert c.camel == "NewName"
    assert c.description == "New Description"
   

# Generated at 2022-06-21 13:10:18.683620
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from .config import SetupCfgCommandConfig
    from .test_utils import (
        project_dir,
        sub_command_dir
    )

    class SetupCfgCommandConfigTests(TestCase):

        def test_each_sub_command_config(self):
            for config in each_sub_command_config(project_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config[0], str)
                self.assertIsInstance(config[1], str)
                self.assertIsInstance(config[2], str)
                self.assertIsInstance(config[3], tuple)

        def test_each_sub_command_config_with_custom_filename(self):
            _sub_command_dir = sub_command_dir
           

# Generated at 2022-06-21 13:10:41.942227
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from os.path import expanduser

    class Test_each_sub_command_config(unittest.TestCase):
        """Unit test for function each_sub_command_config."""

        def test__each_sub_command_config(self):
            """Test function each_sub_command_config."""

# Generated at 2022-06-21 13:10:48.005304
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'Description'
    commands = tuple(['commands'])
    test = SetupCfgCommandConfig(name, camel, description, commands)
    assert test.name == name
    assert test.camel == camel
    assert test.description == description
    assert test.commands == commands


# Generated at 2022-06-21 13:10:50.125965
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))

# Generated at 2022-06-21 13:11:00.802062
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.sysutils import FormatTuple
    from pytest import raises

    class Test(SetupCfgCommandConfig):
        def __new__(
                cls,
                name: str,
                camel: str,
                description: str,
                commands: Tuple[str, ...]
        ) -> 'SetupCfgCommandConfig':
            if isinstance(name, str) is False:
                raise TypeError(
                    "The 'name' attribute is NOT a str; type=%r; value=%r"
                    % (type(name), name)
                )
            if isinstance(camel, str) is False:
                raise TypeError(
                    "The 'camel' attribute is NOT a str; type=%r; value=%r"
                    % (type(camel), camel)
                )

# Generated at 2022-06-21 13:11:03.975264
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config():
        print(sub_cmd)
        print(sub_cmd.commands)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:11:13.604145
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import random
    import copy

    def test_sub_command(
            name: str,
            command: Optional[str],
            commands: Optional[str]
    ) -> SetupCfgCommandConfig:
        return SetupCfgCommandConfig(
            name=name,
            camel=underscore_to_camel(name.replace(' ', '_'), lower_first=False),
            description='',
            commands=tuple(
                filter(len, command.splitlines())
                if command is not None else
                filter(len, commands.splitlines())
            )
        )

    def test_all():
        tmp_dir = tempfile.mkdtemp(prefix='test_each_sub_command_config_')

# Generated at 2022-06-21 13:11:17.345151
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """run 'python -m flutils.setup_cfg_command.each\
        _sub_command_config' to test function each_sub_command_config
    """
    for item in each_sub_command_config():
        print(item)

# Generated at 2022-06-21 13:11:27.827502
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config(os.path.dirname(__file__)))
    assert len(cmds) == 2
    assert cmds[0].name == 'setup.command.build_docs'
    assert cmds[0].camel == 'BuildDocs'
    assert cmds[0].description == 'Builds the Sphinx docs.'
    assert cmds[0].commands == ('sphinx-apidoc -o ./docs/source ./',
                                'sphinx-build -b html ./docs/source ./docs/build')
    assert cmds[1].name == 'setup.command.clean'
    assert cmds[1].camel == 'Clean'
    assert cmds[1].description == 'Cleans up the project.'

# Generated at 2022-06-21 13:11:34.006195
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    foo = SetupCfgCommandConfig(
        'foo',
        'Foo',
        'Description of foo commands.',
        ('doit foo', 'doit foo 2')
    )
    assert foo.name == 'foo'
    assert foo.camel == 'Foo'
    assert foo.description == 'Description of foo commands.'
    assert foo.commands == ('doit foo', 'doit foo 2')

# Generated at 2022-06-21 13:11:35.489389
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        pass

# Generated at 2022-06-21 13:12:11.069287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.pathutils

    setup_dir = flutils.pathutils.get_parent_dir(__file__)
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# -------------------------------

if __name__ == '__main__':
    from flutils.logutils import dprint

    dprint(test_each_sub_command_config())

# Generated at 2022-06-21 13:12:15.245750
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function "each_sub_command_config"')
    for config in each_sub_command_config():
        print(config)
    print('Done testing.')


# Only run the unit tests if run from command line
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:12:16.708349
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'B', 'c', ('d', 'e'))

# Generated at 2022-06-21 13:12:23.821277
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test setup.cfg file used for testing
    setup_cfg_content = """\
[metadata]
name = testing
version = 0.0.0

[options]
packages = find:

[options.extras_require]
testing =
    pytest
    py
"""
    import io
    import sys
    import tempfile
    import pytest

    with tempfile.TemporaryDirectory() as tmpdir:
        setup_py_path = os.path.join(tmpdir, 'setup.py')
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(
            tmpdir, 'setup_commands.cfg'
        )

        with open(setup_py_path, 'w') as f:
            stream = io

# Generated at 2022-06-21 13:12:30.823054
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from pathlib import Path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        (temp_dir / 'setup.py').touch()

        # Test with no option set
        assert tuple(each_sub_command_config()) == ()

        # Test with an invalid directory
        with pytest.raises(FileNotFoundError):
            tuple(each_sub_command_config('/fake/path'))

        # Test with a real setup.py in the given directory
        assert tuple(each_sub_command_config(temp_dir)) == ()

        # Test with a setup.cfg
        cfg = temp_dir / 'setup.cfg'

# Generated at 2022-06-21 13:12:36.526964
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='name', camel='Camel', description='desc', commands=('a', 'b')
    )
    assert obj.name == 'name'
    assert obj.camel == 'Camel'
    assert obj.description == 'desc'
    assert obj.commands == ('a', 'b')


# Unit tests for function _each_setup_cfg_command_section

# Generated at 2022-06-21 13:12:44.066528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(dir_path, '../test-project-setup')
    sub_commands = each_sub_command_config(setup_dir)
    assert next(sub_commands) == \
           SetupCfgCommandConfig('echo_it', 'EchoIt', '', ('echo',))
    assert next(sub_commands) == \
           SetupCfgCommandConfig('echo_it_2', 'EchoIt2', '', ('echo 2nd',))
    assert next(sub_commands) == \
           SetupCfgCommandConfig('echo_it_3', 'EchoIt3', '', ('echo 3rd',))
    assert next(sub_commands) == \
           SetupCfgCommand

# Generated at 2022-06-21 13:12:51.568199
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        '..',
        'src'
    )
    for config in each_sub_command_config(setup_dir):
        assert config.name


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:12:52.891179
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _ = SetupCfgCommandConfig('', '', '', ())


# Generated at 2022-06-21 13:13:02.174063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from pathlib import Path

    from flutils.templating import render_template_file

    with TemporaryDirectory() as tmp_dir:

        path = Path(tmp_dir) / 'setup.cfg'
        assert path.is_file() is False
        with open(str(path), 'w') as fp:
            fp.write(
                render_template_file(
                    'setup_cfg',
                    name='flutils'
                )
            )

        path = Path(tmp_dir) / 'setup_commands.cfg'
        assert path.is_file() is False
        with open(str(path), 'w') as fp:
            fp.write(
                render_template_file(
                    'setup_commands_cfg'
                )
            )


# Generated at 2022-06-21 13:13:46.741801
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        name = 'test',
        camel = 'Test',
        description = 'test',
        commands = ('com', 'coms')
    )
    assert sccc.name == 'test'
    assert sccc.camel == 'Test'
    assert sccc.description == 'test'
    assert sccc.commands == ('com', 'coms')


# Generated at 2022-06-21 13:13:56.787120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import path
    cwd = os.getcwd()
    path.append(os.path.join(cwd, 'tests', 'examples', 'sub_command_1', 'src'))
    from tests.examples.sub_command_1 import console
    for i in console.each_sub_command_config():
        print(i)
    path.remove(os.path.join(cwd, 'tests', 'examples', 'sub_command_1', 'src'))
    del console
    from tests.examples.sub_command_2 import console
    for i in console.each_sub_command_config():
        print(i)
    path.remove(os.path.join(cwd, 'tests', 'examples', 'sub_command_2', 'src'))
    del console

# Generated at 2022-06-21 13:14:02.356525
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(1, 2, 3, 4)
    assert setup_cfg_command_config.name == 1
    assert setup_cfg_command_config.camel == 2
    assert setup_cfg_command_config.description == 3
    assert setup_cfg_command_config.commands == 4

# Generated at 2022-06-21 13:14:11.883632
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(os.path.dirname(__file__))
    import inspect
    import pytest
    from textwrap import dedent

    config_path = os.path.join(here, '__pycache__', 'setup_commands.cfg')
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, 'w') as fp:
        fp.write(dedent("""
        [setup.command.bdist_wheel]
        name = bdist_wheel
        description = Builds a wheel binary package.
        commands =
            pip wheel -w {home}/.wheelhouse -r requirements.txt
            python setup.py bdist_wheel
        """))

    from flutils._setup_commands import each_sub

# Generated at 2022-06-21 13:14:14.738397
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('/Users/user/Projects/django-flutils/'):
        print(config)

# Generated at 2022-06-21 13:14:26.734300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_root_dir_from_path
    from flutils.pathutils import PRETTY_ROOT_DIR
    root_dir = get_root_dir_from_path(__file__)
    if root_dir.endswith(PRETTY_ROOT_DIR):
        root_dir = os.path.dirname(root_dir)
    assert root_dir.endswith('flutils')
    root_dir = os.path.dirname(root_dir)
    assert root_dir.endswith('tests')
    root_dir = os.path.dirname(root_dir)

# Generated at 2022-06-21 13:14:30.016418
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('A', 'B', 'C', ('D', ))
    assert c.name == 'A'
    assert c.camel == 'B'
    assert c.description == 'C'
    assert c.commands == ('D', )


# Generated at 2022-06-21 13:14:35.574835
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # given
    name = "name"
    description = "description"
    commands = ["command1", "command2"]

    # when
    config = SetupCfgCommandConfig(name, description, commands)

    # then
    assert config.name == name
    assert config.camel == "Name"
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-21 13:14:39.664371
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('Test', 'Test', '', tuple())
    assert config.name == 'Test'
    assert config.camel == 'Test'
    assert config.description == ''
    assert config.commands == tuple()



# Generated at 2022-06-21 13:14:49.582230
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""

    # NOTE: The following line must be called to enable the unit tests to
    # run in a command line environment.
    setup_dir = os.path.dirname(os.path.dirname(__file__))

    results = list(each_sub_command_config(setup_dir))