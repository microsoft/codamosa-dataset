

# Generated at 2022-06-21 13:06:07.058130
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args = ('name', 'camel', 'description', ('command 1', 'command 2'))
    sccc = SetupCfgCommandConfig(*args)
    assert sccc.name == args[0]
    assert sccc.camel == args[1]
    assert sccc.description == args[2]
    assert sccc.commands == args[3]



# Generated at 2022-06-21 13:06:10.485390
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert a.name == 'name'
    assert a.camel == 'camel'
    assert a.description == 'description'
    assert a.commands == ('commands',)



# Generated at 2022-06-21 13:06:19.645623
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from unittest.mock import patch, Mock, mock_open

    class TestEachSubCommandConfig(TestCase):

        def test_no_setup_py(self):
            """Test when the ``setup.py`` file is not found."""
            with patch('flutils.setupcfg.os.path.expanduser') as m_expand:
                m_expand.return_value = '/home/user'
                with patch('flutils.setupcfg.os.path.dirname') as m_dirname:
                    m_dirname.return_value = '/home/user'
                    with patch(
                        'flutils.setupcfg.os.path.isfile'
                    ) as m_isfile:
                        m_isfile.return_value = False

# Generated at 2022-06-21 13:06:23.608306
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for cfg in each_sub_command_config(root):
        print(cfg)

# Generated at 2022-06-21 13:06:26.467058
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',),
    )

# Generated at 2022-06-21 13:06:36.308575
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import unittest

    class SetupCfgTest(unittest.TestCase):
        def test_each_sub_command_config(self):
            with open('setup.cfg', 'w') as f:
                f.write('[metadata]\nname = flutils\n')
            with open('setup_commands.cfg', 'w') as f:
                f.write('''
                    [setup.command.test]
                    name = test_module
                    commands =
                        pytest {setup_dir}
                        pytest --cov={setup_dir}
                    ''')
            path = os.path.abspath(__file__)
            setup_dir = os.path.dirname(path)
            mod = 'flutils.setup_cfg.each_sub_command_config'

# Generated at 2022-06-21 13:06:38.071077
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig("foo", "Bar", "baz", ("x", "y"))


# Generated at 2022-06-21 13:06:40.604135
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    v: SetupCfgCommandConfig = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=('baz',)
    )


# Generated at 2022-06-21 13:06:50.829213
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import (
        get_first_result,
        get_one_result,
    )
    from flutils.textutils import (
        cut_from,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    print('Testing function: each_sub_command_config')
    _setup_cfg = '''\
[metadata]
name = flutils
version = 0.0.7

[options]
packages = find:
package_dir =
    =src
'''

# Generated at 2022-06-21 13:06:54.338518
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            name='BAR',
            camel='Bar',
            description='Foobar',
            commands=('foo', 'bar')
        )
        assert True
    except NameError:
        assert False

# Generated at 2022-06-21 13:07:10.174620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.abspath(os.path.join(path, '..', '..'))
    path = cast(str, path)
    for config in each_sub_command_config(path):
        print(config)


# Generated at 2022-06-21 13:07:17.042757
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'Foo',
        'Bar',
        'Foo and bar',
        ('one', 'two', 'three')
    )
    assert config.name == 'Foo'
    assert config.camel == 'Bar'
    assert config.description == 'Foo and bar'
    assert config.commands == ('one', 'two', 'three')



# Generated at 2022-06-21 13:07:19.596790
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the constructor of SetupCfgCommandConfig class."""
    yay = SetupCfgCommandConfig(
        name='hello',
        camel='Hello',
        description='this is a test',
        commands=tuple(['a', 'b', 'c']))
    assert yay.name == 'hello'
    assert yay.camel == 'Hello'
    assert yay.description == 'this is a test'
    assert yay.commands == tuple(['a', 'b', 'c'])



# Generated at 2022-06-21 13:07:22.622618
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\nUnit testing function each_sub_command_config()')
    setup_dir = _prep_setup_dir()
    config = list(each_sub_command_config(setup_dir))
    assert config
    print('Success!')

# Generated at 2022-06-21 13:07:30.954322
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import Dummy

    with Dummy() as dummy:
        dummy.add_file('setup.py', b'')

# Generated at 2022-06-21 13:07:34.336213
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('./tests/data/setup_cfg_test'):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-21 13:07:45.603599
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    data = []
    for i in each_sub_command_config('test_project'):
        data.append(i)

# Generated at 2022-06-21 13:07:50.934878
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        'test_cmd',
        'TestCmd',
        'Testing a CommandConfig object',
        ('test', )
    )
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'test_cmd'
    assert cmd.camel == 'TestCmd'
    assert cmd.description == 'Testing a CommandConfig object'
    assert cmd.commands[0] == 'test'

# Generated at 2022-06-21 13:08:02.252936
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(curr_dir, 'flasky')
    config = None
    for setup_cfg_command_config in each_sub_command_config(setup_dir):
        assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
        assert isinstance(setup_cfg_command_config.name, str)
        assert isinstance(setup_cfg_command_config.camel, str)
        assert isinstance(setup_cfg_command_config.description, str)
        assert isinstance(setup_cfg_command_config.commands, Tuple)
        config = setup_cfg_command_config
    assert config.name == 'develop'

# Generated at 2022-06-21 13:08:14.800969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    from textwrap import dedent

    setup_cfg = dedent(
        """\
        [metadata]
        name = flutils

        [setup.command.a]
        name = long command a name
        command = this is a test
        command = this is a test, too

        [setup.command.b]
        name = long command b name
        command = this is a test
        command = this is a test, too

        [setup.command.c]
        name = long command c name
        command = this is a test
        command = this is a test, too
        """
    ).encode()


# Generated at 2022-06-21 13:08:32.016819
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_command'
    camel = 'TestCommand'
    description = 'test description'
    commands = ()
    test = SetupCfgCommandConfig(name, camel, description, commands)
    assert test.name == name
    assert test.camel == camel
    assert test.description == description
    assert test.commands == commands


# Generated at 2022-06-21 13:08:34.093528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pwd = os.path.dirname(__file__)
    for x in each_sub_command_config(pwd):
        print(x)

# Generated at 2022-06-21 13:08:43.661554
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    # Test when setup.cfg is missing.
    with tempfile.TemporaryDirectory() as td:
        td = str(td)
        with open(os.path.join(td, 'setup.py'), 'w') as f:
            f.write(
                "#!/usr/bin/env python\n"
                "# -*- coding: utf-8 -*-\n"
                "import setuptools\n"
                "setuptools.setup()\n"
            )
        with open(os.path.join(td, 'setup_commands.cfg'), 'w') as f:
            f.write(
                "[setup.command.foo]\n"
                "name = Foo\n"
                "command = echo 'Hello, World!'\n"
            )
       

# Generated at 2022-06-21 13:08:49.208388
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name: str = 'Name'
    camel: str = 'Camel'
    description: str = 'description'
    commands: Tuple[str, ...] = ('cmd1', 'cmd2')
    c = SetupCfgCommandConfig(name, camel, description, commands)
    assert c.name == name
    assert c.camel == camel
    assert c.description == description
    assert c.commands == commands



# Generated at 2022-06-21 13:08:52.464641
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(1, 2, 3, 4)
    assert config.name == 1
    assert config.camel == 2
    assert config.description == 3
    assert config.commands == 4

# Generated at 2022-06-21 13:09:03.444010
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, abspath, join
    import re
    import sys
    parent = abspath(join(dirname(__file__)))
    sys.path.insert(0, parent)
    sys.path.insert(0, join(parent, 'tests'))
    del parent
    try:
        import test_each_sub_command_config as test
    finally:
        del sys.path[0]
        del sys.path[0]
    setup_dir = abspath(join(dirname(__file__), '../..'))
    for cmd in each_sub_command_config(setup_dir):
        expected = getattr(test, 'expected_' + cmd.name.replace('-', '_'))
        assert expected == cmd

# Generated at 2022-06-21 13:09:08.345794
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel', 'description', ('commands', ))
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('commands', )

# Generated at 2022-06-21 13:09:15.995169
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    from sys import version_info

    from flutils import get_version

    get_version.__name__ = 'test_version'
    get_version.__qualname__ = 'test_version'

    foo = SetupCfgCommandConfig(get_version, 'TestVersion', '', ('cmd1',))
    assert foo.name == 'test_version'
    assert foo.camel == 'TestVersion'
    assert foo.description == ''

    bar = SetupCfgCommandConfig('foo-bar', 'BarFoo', '', ('cmd1', 'cmd2'))
    assert bar.name == 'foo-bar'
    assert bar.camel == 'BarFoo'
    assert bar.description == ''


# Generated at 2022-06-21 13:09:25.748283
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = os.path.realpath(temp_dir)
        _setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        _setup_py_path = os.path.join(temp_dir, 'setup.py')
        _setup_commands_cfg_path = os.path.join(temp_dir, 'setup_commands.cfg')

        shutil.copyfile(
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'setup.cfg'
            ),
            _setup_cfg_path
        )

# Generated at 2022-06-21 13:09:34.978268
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each():
        yield SetupCfgCommandConfig(
            'flake8',
            'Flake8',
            'Runs flake8 on the source code',
            ('flake8',)
        )
        yield SetupCfgCommandConfig(
            'pytest',
            'PyTest',
            'Runs the tests',
            ('pytest',)
        )
        yield SetupCfgCommandConfig(
            'docs',
            'Docs',
            'Builds the documentation',
            ('sphinx-build -b html docs docs/_build/html',)
        )
    gen = each_sub_command_config('tests/fixtures/setup_dir/project')
    for out, exp in zip(_each(), gen):
        assert out == exp


# Generated at 2022-06-21 13:10:02.570349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    lines = []
    try:
        each_sub_command_config()
    except FileNotFoundError as e:
        lines.append(str(e))

    assert len(lines) == 1
    assert lines[0].strip() == (
        "Unable to find the directory that contains the 'setup.py' file.")



# Generated at 2022-06-21 13:10:08.382463
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        a = SetupCfgCommandConfig('name', 'camel', 'description', ('hello', 'world'))
        assert (a.name == 'name')
        assert (a.camel == 'camel')
        assert (a.description == 'description')
        assert (a.commands == ('hello', 'world'))
    except Exception:
        assert (False)
    else:
        assert (True)



# Generated at 2022-06-21 13:10:11.312630
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'b', 'c', ('d',)) == ('a', 'b', 'c', ('d',))



# Generated at 2022-06-21 13:10:20.623191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from random import randint
    from tempfile import (
        TemporaryDirectory,
        NamedTemporaryFile,
    )
    from textwrap import dedent
    from unittest import TestCase
    from unittest.mock import call, patch

    class EachSubCommandConfigTests(TestCase):
        def setUp(self):
            self.tempdir = TemporaryDirectory(prefix='temp_package-')
            self.addCleanup(self.tempdir.cleanup)
            self.tempdir.name = os.path.realpath(self.tempdir.name)
            self.setup_file = os.path.join(self.tempdir.name, 'setup.py')

# Generated at 2022-06-21 13:10:33.303053
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=invalid-name, unused-argument
    def each_test_scenario(
            tests: List[Tuple[str, str, List[str]]],
            cwd: os.PathLike
    ) -> Generator[Tuple[str, ...], None, None]:
        for name, description, args in tests:
            yield (
                name,
                description,
                *args,
                'each_sub_command_config',
                cast(str, os.path.dirname(cwd)),
                'python',
                'setup.py'
            )


# Generated at 2022-06-21 13:10:41.291589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
    except FileNotFoundError as err:
        raise err
    # Make sure that the setup_commands.cfg file is parsed correctly.
    gen = each_sub_command_config(os.path.dirname(__file__))
    config = next(gen)
    assert config.name == 'setup-command.test'
    assert config.camel == 'Test'
    assert config.commands == ('echo "hello testing"', )
    config = next(gen)
    assert config.name == 'setup.command.test-two'
    assert config.camel == 'TestTwo'
    assert config.commands == ('echo "hello testing two commands"', )
    config = next(gen)
    assert config.name == 'setup.command.test-three'
    assert config

# Generated at 2022-06-21 13:10:51.158647
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    configs = tuple(each_sub_command_config(dir_path))
    assert len(configs) == 1
    assert configs[0].name == 'test.cmd'
    assert configs[0].camel == 'TestCmd'
    assert configs[0].description == 'A test command for setup_commands.cfg'
    assert len(configs[0].commands) == 2
    assert configs[0].commands[0] == 'echo "Hello, world!"'
    assert configs[0].commands[1] == 'echo "Goodbye, world!"'


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:10:55.325556
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands[0] == 'cmd'

# Generated at 2022-06-21 13:11:05.083542
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def get_sub_command_config(
            setup_dir: Union[os.PathLike, str]
    ) -> List[SetupCfgCommandConfig]:
        return list(each_sub_command_config(setup_dir))

    import os
    import sys
    import tempfile

    from functools import partial

    from flutils.pathutils import safe_makedirs
    from flutils.strutils import underscore_to_camel

    from .testutils import TestCase

    class TestSubCommandConfig(TestCase):
        def setUp(self) -> None:
            self.tmpdir = tempfile.TemporaryDirectory(prefix='setup_command')
            self.tmpdirname = self.tmpdir.name
            self.setup_dir = os.path.join(self.tmpdirname, 'test_setup')
            safe_m

# Generated at 2022-06-21 13:11:13.453287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.pathutils

    import mypackage
    package_dir = flutils.pathutils.package_dir(mypackage)
    configs = list(each_sub_command_config(package_dir))
    assert type(configs) is list
    assert len(configs) == 1
    assert type(configs[0]) is SetupCfgCommandConfig
    config = configs[0]
    assert config.name == 'mypackage.command1'
    assert config.camel == 'MypackageCommand1'
    expected = 'Command 1'
    assert config.description == expected
    assert type(config.commands) is tuple
    assert len(config.commands) == 1
    expected = 'command 1'
    assert config.commands[0] == expected

# Generated at 2022-06-21 13:11:33.900085
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('commands',))

    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)


# Generated at 2022-06-21 13:11:44.127166
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    class SetupCfgSubCommandTest(unittest.TestCase):
        def test_setup_cfg_has_multiple_sub_commands(self):
            from tempfile import TemporaryDirectory

            with TemporaryDirectory() as temp_dir:
                setup_py = os.path.join(temp_dir, 'setup.py')
                setup_cfg = os.path.join(temp_dir, 'setup.cfg')
                txt = (
                    '[metadata]\n'
                    'name = test\n'
                )

# Generated at 2022-06-21 13:11:56.473074
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.debugutils import prep_test
    import os
    import shutil
    import tempfile

    # Test failed conditions

    with prep_test(each_sub_command_config, "setup_dir", tempfile.gettempdir()):
        raise FileNotFoundError(
            "The given 'setup_dir' of %r does NOT contain a setup.py "
            "file." % tempfile.gettempdir()
        )

    with prep_test(each_sub_command_config, "setup_dir", tempfile.gettempdir()):
        raise FileNotFoundError(
            "The given 'setup_dir' of %r does NOT contain a setup.cfg "
            "file." % tempfile.gettempdir()
        )


# Generated at 2022-06-21 13:12:00.813359
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'Camel', 'description', ('command1',))
    assert obj.name == 'name'
    assert obj.camel == 'Camel'
    assert obj.description == 'description'
    assert obj.commands == ('command1',)

# Generated at 2022-06-21 13:12:08.519937
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '__project__')
    out = tuple(each_sub_command_config(setup_dir=path))

# Generated at 2022-06-21 13:12:12.651384
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test', 'Test', 'test command', ('test', )
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test command'
    assert config.commands == ('test', )


# Generated at 2022-06-21 13:12:19.296540
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'one', 'ONE', 'foo', ('up', 'down')
    ) == SetupCfgCommandConfig(
        'one', 'ONE', 'foo', ('up', 'down')
    )
    assert SetupCfgCommandConfig(
        'one', 'ONE', 'foo', ()
    ) != SetupCfgCommandConfig(
        'one', 'ONE', 'foo', ('up', 'down')
    )
    assert SetupCfgCommandConfig(
        'two', 'ONE', 'foo', ('up', 'down')
    ) != SetupCfgCommandConfig(
        'one', 'ONE', 'foo', ('up', 'down')
    )

# Generated at 2022-06-21 13:12:25.219143
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils
    for config in each_sub_command_config(flutils.__path__[0]):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        assert config.commands and all(isinstance(x, str) for x in config.commands)



# Generated at 2022-06-21 13:12:36.240046
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock

    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(setup_dir, 'example')
    read_list = []

# Generated at 2022-06-21 13:12:41.267424
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig(
        name = 'test',
        camel = 'Test',
        description = 'This is test',
        commands = ('cmd1', 'cmd2')
    )
    
    assert test.name == 'test'
    assert test.camel == 'Test'
    assert test.description == 'This is test'
    assert test.commands == ('cmd1', 'cmd2')


# Generated at 2022-06-21 13:13:15.237912
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-21 13:13:17.486724
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config."""
    for data in each_sub_command_config(os.path.dirname(__file__)):
        out = data.camel.lower()
        assert out.startswith('c_')


if __name__ == '__main__':
    for sub_command_config in each_sub_command_config(os.path.dirname(__file__)):
        print(sub_command_config)

# Generated at 2022-06-21 13:13:27.209107
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        from unittest import mock, TestCase
    except ImportError:
        from unittest.mock import mock, TestCase

    class MockConfig(ConfigParser):
        OPTIONS = {
            'setup.command.test': {
                'commands': (
                    'echo "This is a test."',
                ),
                'description': (
                    "This command is for testing."
                ),
                'name': (
                    "Test"
                )
            }
        }

        def has_section(self, section):
            return section in self.OPTIONS

        def options(self, section):
            return self.OPTIONS[section].keys()

        def get(self, section, option):
            return self.OPTIONS[section][option]


# Generated at 2022-06-21 13:13:36.492440
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.testutils import (
        is_namedtuple_instance,
    )

    def test_setup_dir(setup_cfg_commands: str) -> None:
        with TemporaryDirectory() as temp_dir:
            cfg_path = Path(temp_dir) / 'setup.cfg'
            cfg_path.write_text(setup_cfg_commands)
            for scc in each_sub_command_config(temp_dir):
                assert is_namedtuple_instance(scc, SetupCfgCommandConfig)


# Generated at 2022-06-21 13:13:47.654808
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert isinstance(out, list)
    assert isinstance(out[0], SetupCfgCommandConfig)
    # The following unit tests have different results depending on the
    # directory from which they are invoked.
    options = {
        'name': out[0].name,
        'camel': out[0].camel,
        'description': out[0].description,
        'commands': out[0].commands
    }
    assert options == {
        'name': 'r',
        'camel': 'R',
        'description': '',
        'commands': ("rm '{setup_dir}/dist/*'",)
    }



# Generated at 2022-06-21 13:13:50.753574
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    list(each_sub_command_config(os.path.dirname(sys.argv[0])))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-21 13:13:59.616403
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import exists
    from tempfile import mkdtemp

    project_dir = mkdtemp(dir=os.path.expanduser('~/tmp'))
    assert exists(project_dir) is True

    def touch(path):
        path = os.path.join(project_dir, path)
        dirname = os.path.dirname(path)
        if not exists(dirname):
            makedirs(dirname)
        with open(path, 'w'):
            pass

    touch('setup.cfg')
    touch('setup.py')
    touch('setup_commands.cfg')

    for sc in each_sub_command_config(project_dir):
        print(sc)

    for sc in each_sub_command_config():
        print(sc)



# Generated at 2022-06-21 13:14:10.264010
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock, patch

    with patch(
            'builtins.open', new_callable=Mock, create=True
    ) as mock_open:
        mock_open.return_value = '''[metadata]
name = project
version = 0.1.0

[setup.commands]
command = test command
commands =
    test command 1
    test command 2

[setup.command.test]
commands = test command 2
description = Test command

[setup.command.test.command]
command = test command 3
'''
        cfg = next(each_sub_command_config())
        assert cfg.name == 'test'
        assert cfg.camel == 'Test'
        assert cfg.commands == ('test command 3',)

# Generated at 2022-06-21 13:14:21.411818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import create_test_files_dir
    from tempfile import mkdtemp
    from shutil import rmtree
    from textwrap import dedent
    temp_dir = mkdtemp(prefix='flutils-')

# Generated at 2022-06-21 13:14:22.367289
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ()).name == 'name'

# Generated at 2022-06-21 13:15:45.475714
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    import tempfile
    import shutil
    import pathlib
    import importlib
    import flutils

    # dir_path = os.path.dirname(os.path.realpath(__file__))
    dir_path = os.path.dirname(flutils.__file__)
    dir_path = os.path.dirname(dir_path)
