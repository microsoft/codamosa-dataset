

# Generated at 2022-06-23 18:27:10.606149
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from unittest.mock import patch

    class EachSubCommandTest(TestCase):

        class ConfigParserMock:
            def read(self, filename):
                if filename.endswith('setup.cfg'):
                    self.sections = (
                        'metadata',
                        'setup.command.test',
                        'setup.command.no_name',
                    )
                    self.options = {
                        'metadata': ('name',),
                        'setup.command.test': (
                            'name',
                            'description',
                            'command',
                        ),
                        'setup.command.no_name': (
                            'description',
                            'commands',
                        ),
                    }

# Generated at 2022-06-23 18:27:20.836789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def print_setup_cfg_command_config(
            scfg: SetupCfgCommandConfig
    ) -> None:
        print(
            "name:", scfg.name,
            "\ncamel:", scfg.camel,
            "\ndescription:", scfg.description,
            "\ncommands:", *scfg.commands,
            "\n"
        )

    for scfg in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), 'tests', 'setupcfg')
    ):
        print_setup_cfg_command_config(scfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:27.390017
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test_name',
        'TestName',
        'This is the test.',
        ('test1', 'test2')
    )
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'This is the test.'
    assert config.commands == ('test1', 'test2')



# Generated at 2022-06-23 18:27:29.343933
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('test', 'Test', 'Test description', ('test',))


# Generated at 2022-06-23 18:27:32.272749
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig == SetupCfgCommandConfig(
        "name_tests",
        "NameTests",
        "description_tests",
        ("command_tests", )
    )


# Generated at 2022-06-23 18:27:36.345411
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('', '', '', ('',)) == \
        SetupCfgCommandConfig(name='', camel='', description='', commands = ('',))

# Generated at 2022-06-23 18:27:42.188953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap
    dir_ = tempfile.mkdtemp()
    with open(os.path.join(dir_, 'setup.py'), 'w') as ofh:
        ofh.write('# setup.py')
    with open(os.path.join(dir_, 'setup.cfg'), 'w') as ofh:
        ofh.write(textwrap.dedent('''\
            [metadata]
            name = foo

            [setup.command.foo.bar]
            name = Foo Bar
            description = My foo bar command.
            command =
                echo foo bar
                echo foo bar
        '''))

# Generated at 2022-06-23 18:27:52.653538
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            root_path: os.PathLike,
            expected: Optional[Tuple[SetupCfgCommandConfig, ...]] = None
    ) -> None:
        actual: Tuple[SetupCfgCommandConfig, ...] = tuple(
            each_sub_command_config(root_path)
        )
        if actual != expected:
            raise ValueError(
                "The given 'root_path' of %r does NOT match the expected "
                "output, %r." % (root_path, expected)
            )
        print('PASSED %r' % root_path)

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        for command in (
                'clean',
                'completion',
                'doc',
        ):
            if command not in ('clean',):
                tmp

# Generated at 2022-06-23 18:27:55.160500
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        print(cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:02.113017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_dir = os.path.dirname(__file__)
    pkg_dir = os.path.dirname(pkg_dir)
    pkg_dir = os.path.dirname(pkg_dir)
    pkg_dir = os.path.dirname(pkg_dir)
    pkg_dir = os.path.realpath(pkg_dir)
    myitr = each_sub_command_config(pkg_dir)
    expected = (
        'package',
        'Package',
        'Configuration of the package command.',
        (
            'python setup.py package',
        )
    )
    for i, r in enumerate(myitr):
        assert expected[i] == r[i]

# vim: set ts=4 sw=4 tw=72 expandtab:

# Generated at 2022-06-23 18:28:06.589598
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        name = "test",
        camel = "Test",
        description = "test",
        commands = ("echo test",)
    )
    assert command.name == "test"
    assert command.camel == "Test"
    assert command.description == "test"
    assert command.commands == ("echo test",)

# Generated at 2022-06-23 18:28:10.371085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        next(each_sub_command_config())
    except Exception as e:
        assert isinstance(e, FileNotFoundError)
    else:
        assert False



# Generated at 2022-06-23 18:28:12.766222
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        "testname", "Testname", "testdesc", ('test.a', 'test.b')
    )

# Generated at 2022-06-23 18:28:14.299574
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))

# Generated at 2022-06-23 18:28:18.808120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    thisfile = os.path.abspath(__file__)
    setup_dir = os.path.abspath(os.path.join(thisfile, '..'))
    for config in each_sub_command_config(setup_dir=setup_dir):
        print(config)

# Generated at 2022-06-23 18:28:27.261923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import (
        __file__ as this_module_file,
        __name__ as this_module_name,
    )
    this_module_dir = os.path.dirname(this_module_file)
    setup_dir = os.path.join(this_module_dir, '..')
    for sub_cmd in each_sub_command_config(setup_dir):
        print("sub_cmd: %s" % sub_cmd)


__all__ = (
    'SetupCfgCommandConfig',
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:28:37.658425
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import tempfile
    import os
    import shutil
    import os.path
    import sys

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:28:39.464244
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('setup.command.a.b', 'A B', '', tuple())



# Generated at 2022-06-23 18:28:51.971031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config(
        setup_dir='/home/user/path/to/project/'
    ))
    assert isinstance(out[0], SetupCfgCommandConfig)
    assert out[0].name == 'build-project'
    expected = """
    python setup.py clean --all
    python setup.py build
    """
    assert out[0].commands == tuple(
        filter(len, map(lambda x: x.strip(), expected.splitlines()))
    )

    out = list(each_sub_command_config(
        setup_dir='/home/user/path/to/project/setup_commands.cfg'
    ))
    assert isinstance(out[0], SetupCfgCommandConfig)
    assert out[0].name == 'build-project'

# Generated at 2022-06-23 18:29:02.380083
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print()
    working_path = os.getcwd()
    print('path:', working_path)
    path = os.path.dirname(__file__)
    if os.path.exists(path) and os.path.isdir(path):
        os.chdir(path)

    for s in each_sub_command_config():
        print(
            'section: %s, name: %s, commands: %s'
            % (s.name, s.camel, s.commands)
        )
    print('commands:', [s.commands for s in each_sub_command_config()])

    os.chdir(working_path)



# Generated at 2022-06-23 18:29:07.340511
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fixtures',
        'setup_commands_fixture'
    )
    path = os.path.realpath(path)
    assert each_sub_command_config(path)

# Generated at 2022-06-23 18:29:08.975395
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))

# Generated at 2022-06-23 18:29:14.951324
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        tuple(['command1', 'command2'])
    )
    assert scfgcc.name == 'name'
    assert scfgcc.camel == 'camel'
    assert scfgcc.description == 'description'
    assert scfgcc.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:29:26.797831
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    import pprint
    import unittest

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    log_format = (
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    formatter = logging.Formatter(log_format)
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger(
                'script_extensions.tests.'
                'test_setup_cfg_sub_commands.TestEachSubCommandConfig'
            )



# Generated at 2022-06-23 18:29:32.563335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Ran on the command line by executing:

    python -m flutils.setup_commands /path/to/flutils
    """
    setup_dir = sys.argv[1] if len(sys.argv) > 1 else None
    for config in each_sub_command_config(setup_dir):
        print(config)

# Generated at 2022-06-23 18:29:41.800011
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig(name='foo', camel='Bar',
        description='Bar Description',
        commands=('python -m bar', 'curl -b baz'))
    assert repr(instance) == \
        "SetupCfgCommandConfig(name='foo', camel='Bar', " \
        "description='Bar Description', commands=('python -m bar', " \
        "'curl -b baz'))"
    assert str(instance) == \
        "name='foo', camel='Bar', description='Bar Description', " \
        "commands=('python -m bar', 'curl -b baz')"
    instance = SetupCfgCommandConfig(name='foo', camel='Bar',
        description='Bar Description', commands=())

# Generated at 2022-06-23 18:29:47.996732
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # noqa:D101
    test_config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Test Description',
        commands=('command', )
    )
    assert test_config.name == 'test'
    assert test_config.camel == 'Test'
    assert test_config.description == 'Test Description'
    assert test_config.commands == ('command', )

# Generated at 2022-06-23 18:29:55.154468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import subprocess

    out = []
    for i in each_sub_command_config(setup_dir=sys.argv[1]):
        out.append('%s:%s' % (i.name, i.description))

    if out:
        out = sorted(out)
        out = '\n'.join(out)
        out = out.encode()
    else:
        out = b''

    if out.strip() != sys.stdin.buffer.read():
        args = list(sys.argv)
        args.append('--test')
        subprocess.check_call(args)
        raise SystemExit(1)
    sys.stdout.buffer.write(out)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:01.490006
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_cmd_cfg  = SetupCfgCommandConfig('name','camel','desc',('commands',))

    assert(setup_cfg_cmd_cfg.name == 'name')
    assert(setup_cfg_cmd_cfg.camel == 'camel')
    assert(setup_cfg_cmd_cfg.description == 'desc')
    assert(setup_cfg_cmd_cfg.commands == ('commands',))


# Generated at 2022-06-23 18:30:05.048588
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert len(out) == 6
    assert out[0] is not None


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:11.071400
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    strs = [
        "name = my_custom_command",
        "camel = MyCustomCommand",
        "description = A description of my custom command.",
        "commands = \\\n    echo hi",
    ]
    config = SetupCfgCommandConfig(*strs)
    assert config.name == strs[0].split('=')[1].strip()
    assert config.camel == strs[1].split('=')[1].strip()
    assert config.description == strs[2].split('=')[1].strip()
    assert config.commands == tuple(strs[3].split('=', 1)[1].strip(),)



# Generated at 2022-06-23 18:30:16.705037
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    for cfg in each_sub_command_config(setup_dir):
        assert cfg.name == 'development'
        assert cfg.commands == ('echo test',)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:18.841397
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """todo"""
    SetupCfgCommandConfig('test_name', 'TestName', 'description',
                          ('commands',))



# Generated at 2022-06-23 18:30:20.423500
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))

# Generated at 2022-06-23 18:30:31.758034
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils import pathutils
    from flutils.testingutils import TempDirMixin

    class SetupCfgFileMixin(TempDirMixin):
        def _get_setup_cfg_path(self) -> str:
            return os.path.join(self._temp_dir, 'setup.cfg')

        def _get_setup_cfg_content(self) -> str:
            return '[metadata]\nname = flutils'

        def write_setup_cfg(
                self,
                content: Optional[str] = None
        ) -> None:
            path = self._get_setup_cfg_path()
            if content is None:
                content = self._get_setup_cfg_content()
            with open(path, 'w') as fp:
                fp.write(content)

   

# Generated at 2022-06-23 18:30:34.346455
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    out = list(each_sub_command_config(here))
    assert len(out) == 2

# Generated at 2022-06-23 18:30:43.815406
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'setup.command.test'
    command_name = 'test'

    parser = ConfigParser()
    parser.add_section(section)
    parser.set(section, 'command', 'command_test')

    format_kwargs = {
        'setup_dir': 'test/test_dir',
        'home': os.path.expanduser('~')
    }

    parser = ConfigParser()
    parser.read(os.path.join(format_kwargs['setup_dir'], 'setup.cfg'))
    format_kwargs['name'] = _get_name(parser,
                                      os.path.join(format_kwargs['setup_dir'], 'setup.cfg'))

    commands = _each_setup_cfg_command(parser, format_kwargs)


# Generated at 2022-06-23 18:30:56.137900
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        setup_py_path = os.path.join(tmp, 'setup.py')
        setup_cfg_path = os.path.join(tmp, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(tmp, 'setup_commands.cfg')

        with open(setup_py_path, 'w') as fp:
            fp.write("# setup.py example file\n")
            fp.write("#\n")
            fp.write("import setuptools\n")
            fp.write("\n")
            fp.write("with open('README.md') as f:\n")
            fp.write("   long_description = f.read()\n")


# Generated at 2022-06-23 18:31:07.886979
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class MockedConfigParser:
        def sections(self) -> list:
            return [
                'metadata',
                'setup.command.a',
                'setup.command.b',
                'setup.command.ab'
            ]

        def options(self, name: str) -> List[str]:
            return [
                'name',
                'description',
                'command',
                'commands'
            ]

        def get(self, section: str, option: str) -> str:
            from flutils.miscutils import _unknown
            if section == 'metadata':
                if option == 'name':
                    return 'test_pkg'
                return _unknown
            elif section == 'setup.command.a':
                if option in ('name', 'description'):
                    return 'A'

# Generated at 2022-06-23 18:31:19.149402
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from contextlib import contextmanager

    def make_dirs() -> Tuple[str, str]:
        with tempfile.TemporaryDirectory() as temp_dir:
            setup_dir = os.path.join(temp_dir, 'project_dir')
            os.mkdir(setup_dir)
            return temp_dir, setup_dir

    def make_file(path: str, contents: str):
        with open(path, 'w') as fout:
            fout.write(contents)

    @contextmanager
    def make_setup_cfg(setup_dir: str):
        fname = 'setup.cfg'
        path = os.path.join(setup_dir, fname)
        yield path
        if os.path.isfile(path) is True:
            os.unlink(path)

# Generated at 2022-06-23 18:31:21.697736
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('cmd1', 'cmd2')
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:31:27.691241
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name = 'dummy_name',
        camel = 'DummyName',
        description = 'dummy description',
        commands = ('dummy command',)
    )
    assert config.name == 'dummy_name'
    assert config.camel == 'DummyName'
    assert config.description == 'dummy description'
    assert config.commands == ('dummy command',)


# Generated at 2022-06-23 18:31:30.353993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = str(os.path.dirname(__file__))
    for out in each_sub_command_config(setup_dir):
        print(out)

# Generated at 2022-06-23 18:31:41.797210
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Get the current path, in case it is relative
    current_path = os.getcwd()
    print()
    print(current_path)
    print()
    print(current_path, end='')
    for i in range(5):
        print('.', end='', flush=True)
        time.sleep(.5)
    print()
    for i in range(5):
        print('.', end='', flush=True)
        time.sleep(.5)
    print()
    print()
    for sub_command_config in each_sub_command_config():
        print(sub_command_config)
    print()


# Main
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:45.739081
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        from flutils.setuputils import (
            SetupCfgCommandConfig,
        )
    except Exception as ex:
        raise ex

    SetupCfgCommandConfig('name', 'Camel', 'Description.', ('a', 'b'))

# Generated at 2022-06-23 18:31:47.898997
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig("a", "b", "c", ("d", "e"))



# Generated at 2022-06-23 18:31:57.449347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function :any:`each_sub_command_config`."""
    commands = tuple(each_sub_command_config(os.path.join(
        os.path.expanduser('~'), 'git/flutils'
    )))


# Generated at 2022-06-23 18:32:02.628137
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'abc', 'Abc', 'This is a command', ('a', 'b')
    )
    assert config.name == 'abc'
    assert config.camel == 'Abc'
    assert config.description == 'This is a command'
    assert config.commands == ('a', 'b')



# Generated at 2022-06-23 18:32:09.030428
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sc = SetupCfgCommandConfig(name='name', camel='Camel', description='description', commands=('commands',))
    assert isinstance(sc.name, str)
    assert sc.name == 'name'
    assert isinstance(sc.camel, str)
    assert sc.camel == 'Camel'
    assert isinstance(sc.description, str)
    assert sc.description == 'description'
    assert isinstance(sc.commands, tuple)
    assert sc.commands == ('commands',)

# Generated at 2022-06-23 18:32:17.283768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setuputils
    import pprint
    pprint.pprint(
        list(
            each_sub_command_config(
                # flutils.setuputils.__file__.split('.')[0]
                os.path.join(os.path.dirname(__file__), '..', '..', '..')
            )
        )
    )


if __name__ == '__main__':
    from flutils.loggingutils import set_log_level
    set_log_level()

    test_each_sub_command_config()

# Generated at 2022-06-23 18:32:27.253287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.testutils import temp_change_dir

    with temp_change_dir() as (temp_dir, temp_add, temp_get):
        # Setup the temp directory
        temp_add('setup_commands.cfg', """\
[setup.command.foo.foobar]
command = FOOBAR
""")
        temp_add('setup.cfg', """\
[metadata]
name = A Foo
""")
        temp_add('setup.py')

        # Run the test
        with temp_change_dir(temp_dir):
            each_sub_command_config()


# Generated at 2022-06-23 18:32:38.560106
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.conftest import TEST_TEMPLATES_DIR
    from flutils.files import each_file

    for setup_cfg_path in each_file(TEST_TEMPLATES_DIR, file_type='file'):
        if os.path.basename(setup_cfg_path) != 'setup.cfg':
            continue
        for sub_cmd_config in each_sub_command_config(
                str(os.path.dirname(setup_cfg_path))
        ):
            assert sub_cmd_config.name


if __name__ == '__main__':
    from flutils.files import each_path

# Generated at 2022-06-23 18:32:46.489906
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        "name", "camel", "description", ["command"]
    )

    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == ("command",)


# Generated at 2022-06-23 18:32:54.680907
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Tests the constructor of the ``SetupCfgCommandConfig`` class."""
    from importlib import resources as pkg_resources  # type: ignore
    from flutils.docutils import read_rst_text

    with pkg_resources.path('tests', 'data') as data_dir:
        data_dir = str(data_dir)
        setup_dir = os.path.join(data_dir, 'setup_cfg')
        for config in each_sub_command_config(setup_dir):
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            for command in config.commands:
                assert isinstance

# Generated at 2022-06-23 18:33:03.242210
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/home/bob/projects/flutils/flutils'
    actual = ''
    for config in each_sub_command_config(setup_dir):
        actual += f'{config.name}:{config.camel}:{config.description}:{config.commands}'

# Generated at 2022-06-23 18:33:13.069151
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    o = SetupCfgCommandConfig('name', 'camel', 'description', ('a', ))
    assert o[0] == 'name'
    assert o[1] == 'camel'
    assert o[2] == 'description'
    assert o[3] == ('a', )
    assert o.name == 'name'
    assert o.camel == 'camel'
    assert o.description == 'description'
    assert o.commands == ('a', )

if __name__ == '__main__':
    # Unit test for `each_sub_command_config`.
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-23 18:33:20.239940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Begin test...')
    print('Testing: each_sub_command_config')
    try:
        gen = each_sub_command_config()
        try:
            while 1:
                print(next(gen))
        except StopIteration:
            pass
        print('End of test...')
    except:
        print('End of test...')
        raise


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:23.070129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    this_dir = Path(__file__).parent
    project_dir = this_dir.parent
    print(project_dir)
    cmds = tuple(each_sub_command_config(project_dir))
    print(cmds)

# Generated at 2022-06-23 18:33:33.739750
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_root_dir = os.path.dirname(__file__)
    assert pkg_root_dir
    assert os.path.isdir(pkg_root_dir)
    pkg_dir = os.path.dirname(pkg_root_dir)
    assert pkg_dir
    assert os.path.isdir(pkg_dir)
    setup_dir = pkg_dir
    gen = each_sub_command_config(setup_dir)
    assert isinstance(gen, Generator)
    conf, = gen
    assert conf == SetupCfgCommandConfig(
        'project_name',
        'ProjectName',
        'Print the name of the project',
        ('echo %(name)s',)
    )

# Generated at 2022-06-23 18:33:44.656592
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test that the constructor raises an error when given None or empty
    # strings and so on.
    good_values = (
        (
            'my-setup-command',
            'MySetupCommand',
            'My Setup Command',
            ('My command', 'My other command'),
        )
    )
    bad_values = (
        (
            None,
            '',
            '',
            None,
        )
    )
    for good_value in good_values:
        mobj = SetupCfgCommandConfig(*good_value)
        assert mobj.name == good_value[0]
        assert mobj.camel == good_value[1]
        assert mobj.description == good_value[2]
        assert mobj.commands == good_value[3]

# Generated at 2022-06-23 18:33:55.503907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(setup_dir, '_data')
    setup_dir = os.path.join(setup_dir, 'setup_cfg')
    commands = list(each_sub_command_config(setup_dir))
    assert len(commands) == 2
    assert commands[0].name == 'bump_release'
    assert commands[0].camel == 'BumpRelease'
    assert commands[0].description == 'Bumps the Python release number.'

# Generated at 2022-06-23 18:33:57.078915
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(sc)

# Generated at 2022-06-23 18:34:09.003397
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Create a mock config file
    config_file = """
[metadata]
name = setup_test
    """
    # Create a mock command section
    command_section = """
[setup.command.test]
name = test_command
description = A test command section.
command = This is a test command.
    """
    # Create a mock command file
    command_file = """
[setup.command.test2]
name = test_command2
description = A test command section.
command = This is a test command.
    """
    # Create a mock setup.cfg file
    setup_cfg = config_file + command_section
    # Create a mock setup_commands.cfg file
    setup_commands_cfg = command_file

    # Create a mock setup.py file

# Generated at 2022-06-23 18:34:17.825896
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tests = (
        ('/home/cjones/code/flutils/src/flutils', 'flutils'),
        ('~/code/flutils/src/flutils', 'flutils'),
    )
    for setup_dir, name in tests:
        sub_cmds = tuple(each_sub_command_config(setup_dir))
        camel = underscore_to_camel(name, lower_first=False)
        path = os.path.join(setup_dir, 'README.md')
        with open(path, 'r') as file_obj:
            lines = file_obj.readlines()
            description = ''.join(lines[15:28])

# Generated at 2022-06-23 18:34:22.339821
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('c',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('c',)


# Generated at 2022-06-23 18:34:26.904574
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    commandconfig = SetupCfgCommandConfig('name','camel','description','commands')
    assert commandconfig.name == 'name'
    assert commandconfig.camel == 'camel'
    assert commandconfig.description == 'description'
    assert commandconfig.commands == 'commands'


# Generated at 2022-06-23 18:34:37.426417
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # -------------------------------------------------------------------------
    # Basic tests
    # -------------------------------------------------------------------------
    x = SetupCfgCommandConfig(
        name='x',
        camel='X',
        description='This is a test.',
        commands=('x', )
    )
    x.name
    x.camel
    x.description
    x.commands
    x.name = x.name
    x.camel = x.camel
    x.description = x.description
    x.commands = x.commands
    print(x)
    repr(x)
    # -------------------------------------------------------------------------
    # Test __slots__
    # -------------------------------------------------------------------------
    try:
        x.__dict__
    except Exception:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 18:34:47.331311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function, each_sub_command_config()."""
    from pprint import pprint
    from logging import basicConfig, DEBUG
    from sys import stderr
    from tempfile import TemporaryDirectory

    basicConfig(
        level=DEBUG,
        format='%(asctime)s.%(msecs)03d %(levelname)s %(name)s: %(message)s',
        datefmt='%Y-%m-%dT%H:%M:%S',
        stream=stderr
    )


# Generated at 2022-06-23 18:34:56.503216
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert issubclass(SetupCfgCommandConfig, NamedTuple)
    assert SetupCfgCommandConfig.__slots__ is None

    name, camel, desc, cmds = 'name', 'Camel', 'description', ()
    config = SetupCfgCommandConfig(name, camel, desc, cmds)
    assert config.name == name
    assert config.camel == camel
    assert config.description == desc
    assert config.commands == cmds

    name, camel, desc, cmds = 'name', 'Camel', 'description', ('command',)
    config = SetupCfgCommandConfig(name, camel, desc, cmds)
    assert config.name == name
    assert config.camel == camel
    assert config.description == desc
    assert config.commands == cmds


# Generated at 2022-06-23 18:35:07.159100
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with tempfile.TemporaryDirectory() as tmp:
        setup_py_path = os.path.join(tmp, 'setup.py')
        with open(setup_py_path, 'w') as fp:
            fp.write(
                "from setuptools import setup\n\n"
                "setup(\n"
                "    name='foobar',\n"
                "    packages=['foobar'],\n"
                "    entry_points={\n"
                "        'console_scripts': [\n"
                "            'foobar = foobar:main'\n"
                "        ]\n"
                "    }\n"
                ")\n"
            )
        setup_cfg_path = os.path.join(tmp, 'setup.cfg')

# Generated at 2022-06-23 18:35:15.242810
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function each_sub_command_config."""
    _test_setup_cfg_path = os.path.join(
        os.path.dirname(__file__),
        'test_setup_cfg.ini'
    )
    _test_setup_commands_cfg_path = os.path.join(
        os.path.dirname(__file__),
        'test_setup_commands.cfg'
    )
    _test_setup_dir = os.path.dirname(_test_setup_cfg_path)

    def test_exists(path: str) -> None:
        if os.path.isfile(path) is False:
            raise FileNotFoundError(path)


# Generated at 2022-06-23 18:35:28.017995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile

    class Test_each_sub_command_config(unittest.TestCase):

        def test_no_setup_cfg(self):
            with self.assertRaises(FileNotFoundError):
                with tempfile.TemporaryDirectory() as temp:
                    setup_dir = os.path.join(temp, 'dir')
                    os.mkdir(setup_dir)
                    each_sub_command_config(setup_dir)

        def test_no_setup_py(self):
            with self.assertRaises(FileNotFoundError):
                with tempfile.TemporaryDirectory() as temp:
                    setup_dir = os.path.join(temp, 'dir')
                    os.mkdir(setup_dir)

# Generated at 2022-06-23 18:35:33.788786
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'Description', ('commands',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'Description'
    assert config.commands == ('commands',)


# Generated at 2022-06-23 18:35:43.438080
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock, call

    setup_py_path = 'setup.py'
    setup_cfg_path = 'setup.cfg'
    setup_commands_cfg_path = 'setup_commands.cfg'

    setup_py_exists = Mock(return_value=True)
    setup_cfg_exists = Mock(return_value=True)
    setup_commands_cfg_exists = Mock(return_value=True)
    mock_exists = Mock(side_effect=[
        setup_py_exists.return_value,
        setup_cfg_exists.return_value,
        setup_commands_cfg_exists.return_value,
    ])
    mock_dirname = Mock(return_value='setup_dir')


# Generated at 2022-06-23 18:35:48.992540
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.cmdutils.setup_cfg import \
        each_sub_command_config, \
        SetupCfgCommandConfig

    for config in each_sub_command_config(".."):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# Generated at 2022-06-23 18:35:54.388073
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _list = list(each_sub_command_config('/Users/travisdiederich/'
                                         'Documents/Python/'
                                         'flutils'))
    assert len(_list) > 0
    assert _list[0].name == 'lint'
    assert _list[0].camel == 'Lint'
    assert _list[0].description == 'Lints all of the Python code.'
    assert _list[0].commands == ('/Users/travisdiederich/.pyenv/shims/'
                                 'flake8 .',)

# Generated at 2022-06-23 18:36:02.733841
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('data/sub_command_config'))
    assert len(configs) == 2

    assert configs[0].name == 'mkdocs.serve'
    assert configs[0].camel == 'MkDocsServe'
    assert configs[0].description == 'Serve a MkDocs documentation website.'
    assert configs[0].commands == (
        'mkdocs serve',
    )

    assert configs[1].name == 'run_tests'
    assert configs[1].camel == 'RunTests'
    assert configs[1].description == 'Run the test suite.'

# Generated at 2022-06-23 18:36:14.294460
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out: List[SetupCfgCommandConfig] = []
    for cmd_out in each_sub_command_config():
        out.append(cmd_out)
    assert len(out) == 3
    assert out[0].name == 'info'
    assert out[0].camel == 'Info'
    assert out[0].description == (
        "Displays information about this Python project and its "
        "'setup.cfg' file."
    )
    assert out[0].commands == (
        'python -c "import this"',
    )
    assert out[1].name == 'sdist'
    assert out[1].camel == 'Sdist'
    assert out[1].description == (
        "Builds the project's source distribution."
    )

# Generated at 2022-06-23 18:36:22.824911
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from io import StringIO
    from tempfile import TemporaryDirectory
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout() -> Generator[StringIO, None, None]:
        out, sys.stdout = sys.stdout, StringIO()
        try:
            yield cast(StringIO, sys.stdout)
        finally:
            sys.stdout = out

    with TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, 'setup.py'), 'w') as fout:
            fout.write('#!/usr/bin/env python\n')
            fout.write('from setuptools import setup\n')
            fout.write('setup(name="foo")\n')


# Generated at 2022-06-23 18:36:35.103335
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    t = SetupCfgCommandConfig(
        'my_cmd', 'MyCmd', 'My command', ('help', 'me')
    )
    assert t.name == 'my_cmd'
    assert t.camel == 'MyCmd'
    assert t.description == 'My command'
    assert t.commands == ('help', 'me')
    assert repr(t) == (
        "SetupCfgCommandConfig(name='my_cmd', camel='MyCmd', "
        "description='My command', commands=('help', 'me'))"
    )
    assert str(t) == (
        "SetupCfgCommandConfig(name='my_cmd', camel='MyCmd', "
        "description='My command', commands=('help', 'me'))"
    )

# Generated at 2022-06-23 18:36:44.436596
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config.
    """
    def check(setup_dir: str, expected: List[SetupCfgCommandConfig]):
        out = list(each_sub_command_config(setup_dir))
        assert len(out) == len(expected), out
        for idx, exp in enumerate(expected):
            got = out[idx]
            assert got.name == exp.name, out
            assert got.camel == exp.camel, out
            assert got.description == exp.description, out
            assert got.commands == exp.commands, out


# Generated at 2022-06-23 18:36:49.188537
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import os
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()
    setup_dir = os.path.join(test_dir, 'my_project')
    os.mkdir(setup_dir)
    shutil.copy(os.path.join('tests', 'data', 'setup.cfg'), setup_dir)
    for command in each_sub_command_config(setup_dir):
        assert command.command.camel == 'SomeTestCommand'
        assert command.command.name == 'some_test'
        assert command.command.description == 'Some test description.'
        assert command.command.commands == (
            'echo "This is a test command."',
            'echo "This is another test command."'
        )

# Generated at 2022-06-23 18:36:56.900786
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    import unittest
    from unittest.mock import patch
    from typing import Generator
    import os
    import shutil
    import tempfile
    from flutils.configutils import each_sub_command_config
    from flutils.temp import TempDir


# Generated at 2022-06-23 18:37:01.427041
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ())
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ()
