

# Generated at 2022-06-23 18:27:06.023792
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _json = {}
    for config in each_sub_command_config():
        _json[config.name] = {
            'description': config.description,
            'camel': config.camel,
            'commands': list(config.commands)
        }
    _json = json.dumps(_json, sort_keys=True, indent=4)
    with open('setup_commands.json', 'w', newline='\n') as f:
        f.write(_json)


__all__ = (
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:27:13.094200
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    print(__file__)
    print(__name__)
    print(os.path.dirname(os.path.realpath(__file__)))
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:18.232014
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig(
        'name', 'camel', 'description',
        tuple(["command1", "command2"])
    )
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:27:29.658705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import re
    import sys
    import unittest

    from flutils.dictutils import make_dict

    # Basic Setup.cfg
    setup_cfg = """
        [metadata]
        name = demo

        [console_scripts]
        demo = demo.__main__:main

        [gui_scripts]
        demo = demo.__main__:main
    """

    # Custom commands
    setup_commands = """
        [setup.command.tox]
        commands =
            tox
            .
    """

    # Custom commands with options
    setup_commands = """
        [setup.command.tox]
        name = tox
        commands =
            tox
            .
    """

    # Custom commands with options

# Generated at 2022-06-23 18:27:36.401120
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('first', 'second')
    )
    assert scfgcc.name == 'name'
    assert scfgcc.camel == 'Camel'
    assert scfgcc.description == 'description'
    assert scfgcc.commands == ('first', 'second')

# Generated at 2022-06-23 18:27:47.838774
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import (
        Mock,
        patch,
    )
    from sys import modules
    from tempfile import mkdtemp

    # Setup
    tmpdir = mkdtemp(prefix='tmp_flutils_utils_')
    modules['__main__'] = Mock(__file__=tmpdir)
    os.makedirs(os.path.join(tmpdir, 'src', 'app_name'))
    open(os.path.join(tmpdir, 'setup.cfg'), 'a').close()
    open(os.path.join(tmpdir, 'setup.py'), 'a').close()
    open(os.path.join(tmpdir, 'README.rst'), 'a').close()
    open(os.path.join(tmpdir, 'setup_commands.cfg'), 'a').close

# Generated at 2022-06-23 18:27:59.079448
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="foo",
        camel="Foo",
        description="This is the description of foo.",
        commands=("cmd --foo bar", )
    )
    assert config.name == "foo"
    assert config.camel == "Foo"
    assert config.description == "This is the description of foo."
    assert config.commands == ("cmd --foo bar", )
    config = SetupCfgCommandConfig(
        name="foo",
        camel="Foo",
        description="This is the description of foo.",
        commands=("cmd --foo bar", "cmd2 --foo2 bar2")
    )
    assert config.name == "foo"
    assert config.camel == "Foo"
    assert config.description == "This is the description of foo."
    assert config.commands

# Generated at 2022-06-23 18:28:08.554756
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'setup.command.my_special_command'
    parser = ConfigParser()
    parser.read('setup.cfg')
    format_kwargs = {
        'setup_dir': _prep_setup_dir(),
        'name': _get_name(parser, 'setup.cfg'),
        'home': os.path.expanduser('~')
    }
    commands = [
        'echo "Hello World!"',
        'echo "Hello {}!".format(format_kwargs["name"])',
        'echo {name}'.format(**format_kwargs)
    ]
    parser.add_section(section)
    parser.set(section, 'name', 'my_special_command')
    parser.set(section, 'description', 'This is my special command.')

# Generated at 2022-06-23 18:28:14.441314
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Testing basic functionality
    # Arrange
    # Act
    actual = SetupCfgCommandConfig(
        'foo',
        'Foo',
        'Description for Foo',
        ('foo',)
    )

    # Assert
    assert actual.name == 'foo'
    assert actual.camel == 'Foo'
    assert actual.description == 'Description for Foo'
    assert actual.commands == ('foo',)

# Generated at 2022-06-23 18:28:20.859079
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name="test name",
        camel="TestName",
        description="test description",
        commands=('test command 1', 'test command 2')
    )
    assert setup_cfg_command_config.name == "test name"
    assert setup_cfg_command_config.camel == "TestName"
    assert setup_cfg_command_config.description == "test description"
    assert setup_cfg_command_config.commands == ('test command 1', 'test command 2')



# Generated at 2022-06-23 18:28:28.717364
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    def _try_each_sub_command_config() -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = tmpdir.replace(os.path.sep, '/')
            setup_file = os.path.join(tmpdir, 'setup.py')
            with open(setup_file, 'w') as fd:
                fd.write(
                    'import setuptools\n'
                    'if __name__ == \'__main__\':\n'
                    '    setuptools.setup()\n'
                )
            setup_cfg_file = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-23 18:28:30.525630
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b'))



# Generated at 2022-06-23 18:28:37.554596
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'a', 'B', 'c', ('d', 'e')
    ) == SetupCfgCommandConfig(
        'a',
        'B',
        'c',
        ('d', 'e')
    )
    assert SetupCfgCommandConfig(
        'a', 'B', 'c', ('d', 'e')
    ) != SetupCfgCommandConfig(
        'b',
        'B',
        'c',
        ('d', 'e')
    )
    assert SetupCfgCommandConfig(
        'a', 'B', 'c', ('d', 'e')
    ) != SetupCfgCommandConfig(
        'a',
        'C',
        'c',
        ('d', 'e')
    )

# Generated at 2022-06-23 18:28:39.371994
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _each = list(each_sub_command_config())
    assert _each
    assert len(_each) > 0

# Generated at 2022-06-23 18:28:51.970933
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    # Set up a temporary directory

# Generated at 2022-06-23 18:29:03.704746
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    params = {
        'name': 'test',
        'camel': 'Test',
        'description': 'test',
        'commands': ('test', )
    }
    command = SetupCfgCommandConfig(**params)
    assert command.name == params['name']
    assert command.camel == params['camel']
    assert command.description == params['description']
    assert command.commands == params['commands']
    command = SetupCfgCommandConfig(**{k: v for k, v in params.items()
                                       if k != 'name'})
    assert command.name == params['name']
    command = SetupCfgCommandConfig(**{k: v for k, v in params.items()
                                       if k != 'camel'})
    assert command.camel == params['camel']
    command

# Generated at 2022-06-23 18:29:15.585795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # pragma: no cover
    from pprint import pformat
    from sys import path as sys_path
    from os import pathsep, getcwd
    from os.path import exists, abspath, dirname, join

    sys_path.insert(1, dirname(__file__))

    assert exists(__file__)
    print(f'__file__: {__file__}')

    assert exists(sys_path[1])
    print(f'sys_path[1]: {sys_path[1]}')
    print(f'sys_path: {pformat(sys_path)}')

    cwd = getcwd()
    print(f'cwd: {cwd}')

    here = dirname(abspath(__file__))
    print(f'here: {here}')

    parent = abs

# Generated at 2022-06-23 18:29:24.229250
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd',)
    for name in config._fields:
        assert getattr(config, name)
        if name == 'commands':
            assert isinstance(getattr(config, name), tuple)
        else:
            assert isinstance(getattr(config, name), str)



# Generated at 2022-06-23 18:29:29.441114
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    title = 'lint'
    name = 'lint'
    camel = 'Lint'
    description = 'Run the linter.'
    commands = ('flake8',)
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands
    config.name = title
    assert config.name == title

# Generated at 2022-06-23 18:29:36.141335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    import sys
    import tempfile
    import shutil
    import unittest
    setup_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(setup_dir, 'mypkg'))
    setup_py = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-23 18:29:43.002611
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    assert s.name == 'a'
    assert s.camel == 'b'
    assert s.description == 'c'
    assert s.commands == ('d', 'e')
    s2 = SetupCfgCommandConfig(s.name, s.camel, s.description, s.commands)
    assert s == s2

# Generated at 2022-06-23 18:29:47.677251
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function each_sub_command_config."""
    from flutils.debugutils import set_trace
    set_trace(globals())


if __name__ == '__main__':  # pragma: no cover
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:55.738849
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "test_name"
    camel = "TestName"
    description = "test_description"
    commands = ("test_command", "test_command")
    config = SetupCfgCommandConfig(
        name=name,
        camel=camel,
        description=description,
        commands=commands
    )
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:30:00.416294
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    data = SetupCfgCommandConfig('name', 'Camel', 'description', ())
    assert data == data
    assert data.name == 'name'
    assert data.camel == 'Camel'
    assert data.description == 'description'
    assert data.commands == ()


# Generated at 2022-06-23 18:30:09.215222
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.normpath(os.path.join(script_dir, '..', '..', '..'))
    project_dir = os.path.realpath(project_dir)
    assert os.path.isdir(project_dir)
    configs = list(each_sub_command_config(project_dir))
    assert configs
    for cfg in configs:
        assert isinstance(cfg, SetupCfgCommandConfig)
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)
        assert isinstance(cfg.commands, tuple)

# Generated at 2022-06-23 18:30:20.033801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, 'package')

    def check_sub_command(
            setup_cfg_command_config: SetupCfgCommandConfig,
            expected: str
    ) -> None:
        assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
        assert isinstance(setup_cfg_command_config.name, str)
        assert isinstance(setup_cfg_command_config.camel, str)
        assert isinstance(setup_cfg_command_config.description, str)
        assert isinstance(setup_cfg_command_config.commands, tuple)
        if expected and setup_cfg_command_config.name != expected:
            raise ValueError

# Generated at 2022-06-23 18:30:22.611040
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig('test1', 'test2', 'test3', tuple()))

# Generated at 2022-06-23 18:30:27.449433
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo.bar',
        'FooBar',
        'description',
        ('cmd',)
    ) == SetupCfgCommandConfig(
        name='foo.bar',
        camel='FooBar',
        description='description',
        commands=('cmd',)
    )

# Generated at 2022-06-23 18:30:37.407368
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    path = os.path.expanduser('~/git/flutils')
    path = os.path.join(path, 'setup_commands.cfg')
    if os.path.isfile(path):
        os.remove(path)
    for _, _ in each_sub_command_config(path):
        pass
    with open(path, 'w') as f:
        f.write(trim("""\
            [setup.command.test_command]

            # The name of the sub command.
            name = {name} test command

            # The description of the command.
            description = This is the description for the test command.

            # The command to be run.
            commands = 
                pipenv run python -m pytest
        """))


# Generated at 2022-06-23 18:30:43.422606
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name="start",
        camel="Start",
        description="Start the app.",
        commands=("echo 'hello'",),
    )
    assert setup_cfg_command_config.name == "start"
    assert setup_cfg_command_config.camel == "Start"
    assert setup_cfg_command_config.description == "Start the app."
    assert setup_cfg_command_config.commands == ("echo 'hello'",)


# Generated at 2022-06-23 18:30:45.339552
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo', 'Foo', 'a foo command', ('',))

# Generated at 2022-06-23 18:30:55.465396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def each_config(setup_dir: Optional[Union[os.PathLike, str]] = None) -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(setup_dir)

    path = os.path.dirname(os.path.realpath(__file__))
    path = os.path.dirname(path)
    for item in each_config(path):
        assert isinstance(item, SetupCfgCommandConfig)
        assert isinstance(item.name, str)
        assert isinstance(item.camel, str)
        assert isinstance(item.description, str)
        assert isinstance(item.commands, tuple)

# Generated at 2022-06-23 18:31:03.663345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import unittest

    class TestSetupCfgCommandConfig(unittest.TestCase):
        """Test constructor for class SetupCfgCommandConfig."""

        def test___init__(self):
            """Test constructor for class SetupCfgCommandConfig."""
            name = 'custom_setup.command'
            camel = 'CustomSetupCommand'
            description = 'my custom setup command'
            commands = ('raw command 1', 'raw command 2')
            x = SetupCfgCommandConfig(
                name, camel, description, commands
            )
            self.assertEqual(x.name, name)
            self.assertEqual(x.camel, camel)
            self.assertEqual(x.description, description)
            self.assertEqual(x.commands, commands)

# Generated at 2022-06-23 18:31:11.156523
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        "name",
        "camel",
        "description",
        ("one", "two")
    ) == SetupCfgCommandConfig(
        "name",
        "camel",
        "description",
        ("one", "two")
    )
    assert SetupCfgCommandConfig(
        "a",
        "b",
        "c",
        ("d", "e")
    ) == SetupCfgCommandConfig(
        "a",
        "b",
        "c",
        ("d", "e")
    )

# Generated at 2022-06-23 18:31:16.355442
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # use the 'setup.cfg' file in this project, flutils
    setup_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../'))
    expected_name = 'flutils'
    for config in each_sub_command_config(setup_dir):
        assert config.name == expected_name



# Generated at 2022-06-23 18:31:28.146492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    results = list(each_sub_command_config())
    assert len(results) == 3
    assert results[0].name == 'show_info'
    assert results[0].commands == (
        'flutils.cmdutils.show_info -d',
        'flutils.cmdutils.show_info -s'
    )
    assert results[0].camel == 'ShowInfo'
    assert results[0].description == 'Shows info about the package.'
    assert results[1].name == 'check'
    assert results[1].commands == (
        'python -m flutils.cmdutils.check_setup_cfg'
    )
    assert results[1].camel == 'Check'
    assert results[1].description == 'Checks the setup.cfg file.'

# Generated at 2022-06-23 18:31:39.893656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import shutil
    import tempfile
    import logging
    import unittest
    import unittest.mock

    logger = logging.getLogger(__name__)
    old_path = sys.path[:]
    old_cwd = os.path.realpath(os.getcwd())


# Generated at 2022-06-23 18:31:43.965920
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(sc)
    print('-' * 30)
    for sc in each_sub_command_config('/home/patrick/.py/git/flutils'):
        print(sc)
    print('-' * 30)
    import flutils
    for sc in each_sub_command_config(flutils.__path__[0]):
        print(sc)
    print('-' * 30)
    import flutils.tests
    for sc in each_sub_command_config(flutils.tests.__path__[0]):
        print(sc)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:45.965397
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    out = SetupCfgCommandConfig('f', 'Fs', 'd', ('c',))
    assert 'f' == out.name
    assert 'Fs' == out.camel
    assert 'd' == out.description
    assert ('c',) == out.commands

# Generated at 2022-06-23 18:31:53.402574
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from tempfile import TemporaryDirectory
    from pathlib import Path

    # TODO: Figure out how to setup python package for testing so
    #   the test is more meaningful.

    class TestEachSubCommandConfig(TestCase):

        def test_each_sub_command_config_no_setup(self):
            with TemporaryDirectory() as td:
                td = Path(td)
                path = td / 'setup_commands.cfg'
                path.write_text(
                    """
[setup.command.test]
name: run-tests
description: {setup_dir}
command= py.test --basetemp={home}/.pytest
                """
                )

# Generated at 2022-06-23 18:32:00.583542
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class Commands:
        def __init__(self):
            self.setup_dir = os.path.abspath('tests/test_project_a')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.parser = ConfigParser()
            self.parser.read(self.setup_cfg_path)
            self.format_kwargs = {
                'setup_dir': self.setup_dir,
                'home': os.path.expanduser('~')
            }

        def commands(self):
            format_kwargs = {
                'setup_dir': self.setup_dir,
                'home': os.path.expanduser('~')
            }
            name = _get_name(self.parser, self.setup_cfg_path)
           

# Generated at 2022-06-23 18:32:10.842050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests ``each_sub_command_config()``."""
    from sys import exc_info
    from traceback import format_exception

    setup_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', '..'
    ))
    for e in each_sub_command_config(setup_dir):
        print(e)

    for e in each_sub_command_config():
        print(e)

    print()
    for e in each_sub_command_config(os.path.join(setup_dir, 'setup.py')):
        print(e)

    print()
    try:
        next(each_sub_command_config(''))
    except Exception:
        typ, val, tb = exc_info()
       

# Generated at 2022-06-23 18:32:15.701472
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('Foo_command', 'FooCommand', 'a foo', ('foo',))
    assert config.name == 'Foo_command'
    assert config.camel == 'FooCommand'
    assert config.description == 'a foo'
    assert config.commands == ('foo',)

# Generated at 2022-06-23 18:32:21.051295
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SC_NAME = 'my_command_name'
    SC_CNAME = 'MyCommandName'
    SC_DESC = 'My command description'
    SC_COMMANDS = ('a', 'b', 'c')
    sc = SetupCfgCommandConfig(
        SC_NAME, SC_CNAME, SC_DESC, SC_COMMANDS
    )
    assert sc.name == SC_NAME
    assert sc.camel == SC_CNAME
    assert sc.description == SC_DESC
    assert sc.commands == SC_COMMANDS

# Generated at 2022-06-23 18:32:33.242177
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        next(each_sub_command_config())
    except FileNotFoundError as e:
        traceback.print_exc()
        assert not e, e

    cmds = list(each_sub_command_config(os.path.dirname(__file__)))
    assert 1 == len(cmds)
    assert 'build_wheel' == cmds[0].name
    assert 'BuildWheel' == cmds[0].camel
    assert 'Builds a wheel, and pushes it to PyPI.' == cmds[0].description
    assert (
        'python -m pip install --upgrade pip setuptools wheel twine',
        'python setup.py -q bdist_wheel',
    ) == cmds[0].commands


# Generated at 2022-06-23 18:32:40.504247
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig("name", "camel", "description", ("commands"))
    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == ("commands")
    assert setup_cfg_command_config == SetupCfgCommandConfig("name", "camel", "description", ("commands"))


# Generated at 2022-06-23 18:32:44.172467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.config.common import HERE

    for sub in each_sub_command_config(setup_dir=HERE):
        assert sub
        assert sub.camel
        assert sub.name
        assert sub.description
        assert sub.commands

# Generated at 2022-06-23 18:32:53.640605
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(_path):
        paths = []
        for config in each_sub_command_config(setup_dir=_path):
            paths.append(config.name)
        return paths

    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, 'sub_cmds')
    out = _test_each_sub_command_config(path)
    assert out == ['sub_cmd_1', 'sub_cmd_2', 'sub_cmd_3', 'sub_cmd_4']

    path = os.path.join(path, 'sub_sub_cmds')
    out = _test_each_sub_command_config(path)

# Generated at 2022-06-23 18:33:02.788316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 18:33:09.447517
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="test",
        camel="Test2",
        description="Test description",
        commands=tuple()
    )
    assert config.name == "test"
    assert config.camel == "Test2"
    assert config.description == "Test description"
    assert config.commands == tuple()


# Generated at 2022-06-23 18:33:20.745436
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    actuals = list(each_sub_command_config(
        os.path.join(os.path.dirname(__file__), 'good_setup')
    ))

# Generated at 2022-06-23 18:33:23.595313
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', "Description", ("Command", "Command2")
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'Description'
    assert config.commands == ("Command", "Command2")


# Generated at 2022-06-23 18:33:27.120867
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig('ab', 'AAB', 'description', ('c',))
    assert a.name == 'ab'
    assert a.camel == 'AAB'
    assert a.description == 'description'
    assert a.commands == ('c',)

# Generated at 2022-06-23 18:33:34.871340
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config()"""
    for sc_config in each_sub_command_config('tests/data/project_one'):
        assert isinstance(sc_config, SetupCfgCommandConfig)
        assert sc_config.name
        assert sc_config.camel
        assert sc_config.description
        assert isinstance(sc_config.commands, tuple)
        assert sc_config.commands

# Generated at 2022-06-23 18:33:45.625489
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config_name: str
    config_camel: str
    config_description: str
    config_commands: Tuple[str, ...]

    setup_dir = os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        'flpk',
    )
    for config in each_sub_command_config(setup_dir):
        config: SetupCfgCommandConfig
        config_name = config.name
        config_camel = config.camel
        config_description = config.description
        config_commands = config.commands
    assert config_name == 'flpk.create_pk'
    assert config_camel == 'CreatePk'
    assert config_description == 'Create a missing ``__pk__.py`` file.'
    assert config_

# Generated at 2022-06-23 18:33:49.906023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'tests/project'
    ret = list(each_sub_command_config(setup_dir))
    assert ret == [
        SetupCfgCommandConfig(
            'hello',
            'Hello',
            'Says hello',
            (
                'echo hello world',
            )
        )
    ]

# Generated at 2022-06-23 18:33:57.128367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(setup_dir, '../..')
    setup_dir = os.path.realpath(setup_dir)

    configs = [config for config in each_sub_command_config(setup_dir)]
    assert configs
    for config in configs:
        assert config.name
        assert isinstance(config.name, str)
        assert config.camel
        assert isinstance(config.camel, str)
        assert config.description
        assert isinstance(config.description, str)
        assert config.commands
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:09.003190
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import io
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-23 18:34:17.732001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .helpers import temp_dir

    with temp_dir() as td:
        td = os.path.realpath(td)
        setup_py_ctnt = '''
from setuptools import setup
setup(
    name='Test-1-2-3',
    version='1.2.3'
)
'''
        with open(os.path.join(td, 'setup.py'), 'w') as fh:
            fh.write(setup_py_ctnt)

        setup_cfg_ctnt = '''[metadata]
name = {name}

[setup.command.test]
command = python setup.py test
[setup.command.sdist]
command = python setup.py sdist
'''

# Generated at 2022-06-23 18:34:22.185721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import assert_generator_equal
    from textwrap import dedent
    from tempfile import TemporaryDirectory

    def get_setup_cfg_contents(setup_cfg_lines: Optional[str] = None) -> str:
        if setup_cfg_lines is None:
            setup_cfg_lines = []
        else:
            setup_cfg_lines = setup_cfg_lines.splitlines()
        setup_cfg_lines.insert(0, '[metadata]')
        setup_cfg_lines.insert(1, 'name = testproject')

# Generated at 2022-06-23 18:34:33.324272
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    # create setup.py
    setup_dir = tempfile.mkdtemp()
    setup_py = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-23 18:34:44.472235
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from tempfile import TemporaryDirectory as tmpdir
    from tests.test_setupcfg import _test_setup_cfg

    class _TestSetupCfgCommandConfig(TestCase):
        def test_setup_cfg_command_config(self):
            with tmpdir() as tmp:
                setup_cfg = os.path.join(tmp, 'setup.cfg')
                _test_setup_cfg(setup_cfg)
                for config in each_sub_command_config(setup_cfg):
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-23 18:34:46.798833
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', tuple())
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-23 18:34:52.797067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = next(each_sub_command_config('test/test_project'))
    assert config.name == 'test_project'
    assert config.camel == 'TestProject'
    assert config.description == 'Description from the config file.'
    assert config.commands == (
        'echo test_project.__name__',
        'echo test_project.__version__'
    )

# Generated at 2022-06-23 18:34:55.010897
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ['commands'])

# Generated at 2022-06-23 18:34:59.785904
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir_path = os.path.dirname(os.path.abspath(__file__))
    assert each_sub_command_config(test_dir_path) is not None


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:35:04.486816
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    t = SetupCfgCommandConfig(name='././..',
                              camel='FileNotFoundError',
                              description='',
                              commands=('commands',))
    assert t.name == '././..'
    assert t.camel == 'FileNotFoundError'
    assert t.description == ''
    assert t.commands == ('commands',)

# Generated at 2022-06-23 18:35:08.821345
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    item: bool = False
    for command_config in each_sub_command_config(setup_dir):
        command_config is not None
        item = True

    assert item is True


__all__ = (
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:35:15.819374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the ``each_sub_command_config()`` function."""
    this_dir = os.path.dirname(__file__)
    setup_dir = os.path.dirname(this_dir)
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs: Dict[str, str] = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')

# Generated at 2022-06-23 18:35:19.617116
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testingutils import compare_class_repr
    assert compare_class_repr(
        SetupCfgCommandConfig, 'name', 'camel', 'description', 'commands'
    ) is True



# Generated at 2022-06-23 18:35:28.425374
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('flutils.setup_commands.each_sub_command_config',
        'EachSubCommandConfig', 'This command does something',
        ('./setup.py each_sub_command_config',))
    assert config.name == 'flutils.setup_commands.each_sub_command_config'
    assert config.camel == 'EachSubCommandConfig'
    assert config.description == 'This command does something'
    assert config.commands == ('./setup.py each_sub_command_config',)



# Generated at 2022-06-23 18:35:38.894986
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        _prep_setup_dir(__file__), 'setup_commands.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    for sub_command_config in each_sub_command_config(__file__):
        assert sub_command_config.name is not None
        assert sub_command_config.camel is not None
        assert sub_command_config.description is not None
        assert sub_command_config.commands is not None


__all__ = [
    'SetupCfgCommandConfig',
    'each_sub_command_config',
]

# Generated at 2022-06-23 18:35:45.694274
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test.command',
        camel='TestCommand',
        description='Test command.',
        commands=('test',)
    )
    assert config.name == 'test.command'
    assert config.camel == 'TestCommand'
    assert config.description == 'Test command.'
    assert config.commands == ('test',)



# Generated at 2022-06-23 18:35:55.926507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    expected = [
        SetupCfgCommandConfig(
            "create-tags",
            "CreateTags",
            "Creates a new Git tag on origin.",
            ("git tag {tag} -m '{tag}'", "git push origin {tag}")
        ),
        SetupCfgCommandConfig(
            "upload",
            "Upload",
            "Upload the package to PyPI.",
            ("python setup.py sdist", "twine upload dist/*")
        )
    ]
    out = list(each_sub_command_config(os.path.dirname(__file__)))
    print(out)
    assert out == expected, (
        f'\n\
            Expected: {expected}\n\
            Actual: {out}'
    )

# Generated at 2022-06-23 18:35:59.398548
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = ('command1', 'command2')
    SetupCfgCommandConfig(name, camel, description, commands)



# Generated at 2022-06-23 18:36:02.350712
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'Description', ('',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'Description'
    assert config.commands == ('',)



# Generated at 2022-06-23 18:36:10.141993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config('/Users/reidc/workspace/fltools'))
    assert len(out) == 5
    assert out[0] == SetupCfgCommandConfig(
        'poetry_install',
        'PoetryInstall',
        'Install the project\'s dependencies using Poetry.',
        ('$(poetry config virtualenvs.in-project true --local)',
         '$(poetry install -v)')
    )
    assert out[1] == SetupCfgCommandConfig(
        'yapf',
        'Yapf',
        'Format the sources using YAPF.',
        ('$(source .env)', '$(yapf -i --recursive flutils)')
    )

# Generated at 2022-06-23 18:36:16.181940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each_cmd() -> None:
        count = 0
        for cmd in each_sub_command_config():
            count += 1
            assert isinstance(cmd.name, str)
            assert isinstance(cmd.camel, str)
            assert isinstance(cmd.description, str)
            assert isinstance(cmd.commands, tuple)
        assert count == 5

    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()
    _each_cmd()



# Generated at 2022-06-23 18:36:24.186670
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import io
    import tempfile
    from shutil import rmtree

    retval = SetupCfgCommandConfig('name', 'camel', 'description',
                                   tuple())
    assert retval.name == 'name'
    assert retval.camel == 'camel'
    assert retval.description == 'description'
    assert retval.commands == tuple()

    # given that only 'setup.cfg' exists
    fd, path = tempfile.mkstemp(suffix='.cfg', text=True)

# Generated at 2022-06-23 18:36:31.187800
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # verify instance created successfully
    config = SetupCfgCommandConfig(
        'test_name',
        'TestName',
        'Test description',
        ('help', '--help', '-h')
    )
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'Test description'
    assert config.commands == ('help', '--help', '-h')



# Generated at 2022-06-23 18:36:36.473897
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """This tests that each_sub_command_config produces the expected output
    when it is invoked.
    """
    first = True
    for config in each_sub_command_config():
        if first:
            assert config.description == ''
            assert config.name == 'test_pkg'
            assert config.camel == 'TestPkg'
            assert config.commands == (
                'echo hello there',
                'echo "This is from the test_pkg sub-command."'
            )
            first = False
        else:
            assert config.description == 'Print out a message.'
            assert config.name == 'test_pkg.sub_sub_sub_sub.sub_sub_sub.sub_sub.sub'
            assert config.camel == 'TestPkgSubSubSubSubSubSubSubSubSubSub'
            assert config

# Generated at 2022-06-23 18:36:40.721777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    module_path = os.path.dirname(os.path.abspath(__file__))
    for arg in {'', '.', module_path}:
        print(arg)
        for x in each_sub_command_config(arg):
            print(x)



# Generated at 2022-06-23 18:36:45.946678
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('commands',)

# Generated at 2022-06-23 18:36:51.261734
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class_name = 'SetupCfgCommandConfig'
    instance = SetupCfgCommandConfig('', '', '', ())
    assert type(instance).__name__ == class_name
    assert isinstance(instance, SetupCfgCommandConfig)
    assert isinstance(instance, NamedTuple)
    assert isinstance(instance, tuple)

# Generated at 2022-06-23 18:37:02.956807
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pathlib

    class _():
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    class FakeModule():
        sys = _()
        pathlib = _()

        @staticmethod
        def listdir(path):
            return ('a', 'b', 'c', 'd')

    sys.modules['sys'] = FakeModule()
    sys.modules['pathlib'] = FakeModule()
    pathlib.Path = _()

    class FakeFile():
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self
