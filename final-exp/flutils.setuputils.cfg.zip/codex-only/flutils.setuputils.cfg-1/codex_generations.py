

# Generated at 2022-06-23 18:27:03.342273
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='cmd_name',
        camel='CmdName',
        description='A short description of the command',
        commands=('command 1', 'command 2')
    )
    assert config.name == 'cmd_name'
    assert config.camel == 'CmdName'
    assert config.description == 'A short description of the command'
    assert config.commands == ('command 1', 'command 2')



# Generated at 2022-06-23 18:27:04.637605
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'b', 'c', ('d',))

# Generated at 2022-06-23 18:27:05.836245
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    return SetupCfgCommandConfig

# Generated at 2022-06-23 18:27:12.433032
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    config = SetupCfgCommandConfig(
        'name',
        'nameCamel',
        'description',
        ('cmd1', )
    )
    assert config.name == 'name'
    assert config.camel == 'nameCamel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', )


# Generated at 2022-06-23 18:27:22.481933
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name: str = 'name'
    camel: str = 'Name'
    description: str = 'description'
    commands: List[str] = ['command_1', 'command_2']
    expected: SetupCfgCommandConfig = SetupCfgCommandConfig(
        name, camel, description, tuple(commands)
    )

    assert SetupCfgCommandConfig(
        name, camel, description, commands
    ) == expected
    assert expected.name == name
    assert expected.camel == camel
    assert expected.description == description
    assert expected.commands == tuple(commands)
    assert repr(expected) == "SetupCfgCommandConfig(name='name', camel='Name', description='description', commands=('command_1', 'command_2'))"

# Generated at 2022-06-23 18:27:25.686281
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'cmd name', 'CommandName', 'cmd help', ('cmd', 'arg')
    )
    assert config.name == 'cmd name'
    assert config.camel == 'CommandName'
    assert config.description == 'cmd help'
    assert config.commands == ('cmd', 'arg')

# Generated at 2022-06-23 18:27:28.426161
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    # If there are no errors, the test passes
    pass

# Generated at 2022-06-23 18:27:30.395097
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('command_name', 'CommandName', 'A description', ())



# Generated at 2022-06-23 18:27:41.652280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import unittest
    import contextlib
    import tempfile
    import textwrap

    class EachSubCommandConfigTest(unittest.TestCase):
        def test_setup_cfg_commands(self):
            @contextlib.contextmanager
            def temp_setup_dir():
                with tempfile.TemporaryDirectory() as tmpdir:
                    tmpdir = os.path.join(tmpdir, 'project')
                    setup_dir = os.path.join(tmpdir, 'setup.py')
                    setup_cfg = os.path.join(tmpdir, 'setup.cfg')
                    setup_commands = os.path.join(tmpdir,
                                                  'setup_commands.cfg')
                    os.mkdir(tmpdir)

# Generated at 2022-06-23 18:27:52.838005
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        '../../../flutils'
    )
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)
    assert name == 'flutils', repr(name)
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~'),
        'name': name
    }
    commands = list(_each_setup_cfg_command(parser, format_kwargs))
    assert commands, repr(commands)


# Generated at 2022-06-23 18:28:02.751432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # function _get_name
    cfg_path = os.path.join(_prep_setup_dir(), 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(cfg_path)
    out = _get_name(parser, cfg_path)
    assert out == 'setup_command_test'
    # function _each_setup_cfg_command
    parser = ConfigParser()
    parser.read(cfg_path)
    out = list(_each_setup_cfg_command(parser, {}))
    assert out


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:06.796999
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.sysutils import (
        get_data_dir,
    )
    test_dir = os.path.join(get_data_dir(), 'jsonschema', 'tests', 'fixtures')
    for config in each_sub_command_config(test_dir):
        str(config)



# Generated at 2022-06-23 18:28:13.960677
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        scfgcc = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
        assert scfgcc.name == 'name'
        assert scfgcc.camel == 'camel'
        assert scfgcc.description == 'description'
        assert scfgcc.commands == ('command',)
    except AssertionError:
        raise AssertionError('test_SetupCfgCommandConfig failed.')

# Generated at 2022-06-23 18:28:22.292622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import join, abspath
    from pathlib import Path
    from tempfile import gettempdir

    from flutils.configutils import ensure_section

    tmpdir = gettempdir()
    setup_dir = Path(join(tmpdir, 'tmp-setup-dir'))
    setup_dir.mkdir(parents=True)
    setup_dir = setup_dir.resolve()
    setup_dir = abspath(setup_dir)

    setup_py_path = setup_dir.joinpath('setup.py')
    setup_py_path.write_text('')
    setup_cfg_path = setup_dir.joinpath('setup.cfg')
    parser = ConfigParser()
    ensure_section(parser, 'metadata')
    parser.set('metadata', 'name', 'foo')

# Generated at 2022-06-23 18:28:27.261716
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="description",
        commands=("commands",)
    )
    assert config.name == "name"
    assert config.camel == "Camel"
    assert config.description == "description"
    assert config.commands == ("commands",)

# Generated at 2022-06-23 18:28:35.270316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO

    output = StringIO()
    for config in each_sub_command_config(
            setup_dir=os.path.dirname(__file__)
    ):
        output.write(
            '\n%s\n'
            % repr(
                dict(
                    name=config.name,
                    camel=config.camel,
                    description=config.description,
                    commands=config.commands,
                )
            )
        )
    output = output.getvalue()

# Generated at 2022-06-23 18:28:44.154124
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Basic setup
    expected_name = 'command_name'
    expected_camel = 'CommandName'
    expected_description = 'This is a command.'
    expected_commands = ('command1', 'command2')
    assert isinstance(expected_name, str)
    assert isinstance(expected_camel, str)
    assert isinstance(expected_description, str)
    assert isinstance(expected_commands, tuple)
    # Constructor
    try:
        config = SetupCfgCommandConfig(
            expected_name,
            expected_camel,
            expected_description,
            expected_commands,
        )
    except:
        assert False
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == expected_name
    assert config.camel == expected_camel
    assert config

# Generated at 2022-06-23 18:28:47.979377
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    try:
        next(gen)
    except StopIteration:
        assert True
    else:
        assert False

# Generated at 2022-06-23 18:28:51.870860
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Initializes a SetupCfgCommandConfig object."""
    assert SetupCfgCommandConfig('', '', '', ()).name == ''
    assert SetupCfgCommandConfig('', '', '', ()).camel == ''
    assert SetupCfgCommandConfig('', '', '', ()).description == ''
    assert SetupCfgCommandConfig('', '', '', ()).commands == ()
    assert SetupCfgCommandConfig('foo', '', '', ()).camel == 'Foo'


# Generated at 2022-06-23 18:28:55.096911
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from pprint import pprint
    pprint(list(each_sub_command_config()))

# Generated at 2022-06-23 18:28:58.372231
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'Camel', 'desc', ('a', 'b'))
    assert obj.name == 'name'
    assert obj.camel == 'Camel'
    assert obj.description == 'desc'
    assert obj.commands == ('a', 'b')


# Generated at 2022-06-23 18:28:59.968819
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('test', 'Test', 'A test', tuple())

# Generated at 2022-06-23 18:29:11.624939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td = os.path.join(td, 'setupdir')
        os.mkdir(td)
        path = os.path.join(td, 'setup.cfg')
        with open(path, 'w') as fp:
            fp.write("""[metadata]
name = tester

[setup.command.test]
name = test
description = desc
commands = test
""")
        expected = """Command: test

Description:
  desc

Commands:
  test
"""
        got = ''

# Generated at 2022-06-23 18:29:24.335072
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the ``each_sub_command_config`` function."""
    from pytest import raises

    kls = SetupCfgCommandConfig
    results = None

    def _check_results(expected):
        nonlocal results
        if results is None:
            raise Exception("No results to check.")
        if expected != results:
            raise Exception(
                "The expected results do not match the actual results."
            )
        results = None

    results = tuple(each_sub_command_config('etc'))

# Generated at 2022-06-23 18:29:25.224543
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Name', 'description', ('do --it',))

# Generated at 2022-06-23 18:29:28.626709
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('one', 'two')
    )



# Generated at 2022-06-23 18:29:33.914562
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig("name", "camel", "description", ("commands",))
    assert cmd.name == "name"
    assert cmd.camel == "camel"
    assert cmd.description == "description"
    assert cmd.commands == ("commands",)

# Generated at 2022-06-23 18:29:39.092980
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name, camel, description, commands = 'test', 'TestName', 'test description', ('echo test', )
    sub_command_config = SetupCfgCommandConfig(name, camel, description, commands)
    print(sub_command_config.name)
    print(sub_command_config.camel)
    print(sub_command_config.description)
    print(sub_command_config.commands)



# Generated at 2022-06-23 18:29:44.552888
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.commands, tuple)
        assert all(map(lambda x: isinstance(x, str), config.commands))
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)

# Generated at 2022-06-23 18:29:48.808174
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join('tests', 'testutils', 'setup_dir')
    for c in each_sub_command_config(setup_dir):
        print(c)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:56.766760
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_config in each_sub_command_config('setup_dir'):
        # print("%s" % cmd_config)
        assert isinstance(cmd_config, SetupCfgCommandConfig)
        assert isinstance(cmd_config.name, str)
        assert isinstance(cmd_config.camel, str)
        assert isinstance(cmd_config.description, str)
        assert isinstance(cmd_config.commands, tuple)


__all__ = ('each_sub_command_config',)

# Generated at 2022-06-23 18:30:01.849708
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig(
        name='name',
        camel='camel',
        description='description',
        commands=('one', 'two')
    )
    assert instance.name == 'name'
    assert instance.camel == 'camel'
    assert instance.description == 'description'
    assert instance.commands == ('one', 'two')

# Generated at 2022-06-23 18:30:10.145060
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    from flutils.test.testutils import (
        capture_output,
        cd,
    )

# Generated at 2022-06-23 18:30:15.513896
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('setup_commands'):
        # print(config)
        assert hasattr(config, 'name')
        assert hasattr(config, 'camel')
        assert hasattr(config, 'description')
        assert hasattr(config, 'commands')
        for command in config.commands:
            assert command

# Generated at 2022-06-23 18:30:24.797671
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    f = each_sub_command_config
    get_path = os.path.normpath
    pkg_path = os.path.normcase(os.path.abspath(__file__))
    pkg_path = os.path.dirname(pkg_path)
    pkg_path = os.path.dirname(pkg_path)
    pkg_path = os.path.dirname(pkg_path)
    pkg_path = os.path.dirname(pkg_path)
    test_path = os.path.join(pkg_path, 'test')
    for i in os.walk(test_path):
        setup_dir = i[0]
        setup_path = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-23 18:30:31.670662
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = 'command'
    camel = 'Command'
    description = 'description'
    commands = ('c1', 'c2')

    config = SetupCfgCommandConfig(command, camel, description, commands)

    # Test `name` property
    assert config.name == command

    # Test `camel` property
    assert config.camel == camel

    # Test `description` property
    assert config.description == description

    # Test `commands` property
    assert config.commands == commands



# Generated at 2022-06-23 18:30:36.134730
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cc = SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd1', 'cmd2'))
    assert cc.name == 'name'
    assert cc.camel == 'camel'
    assert cc.description == 'desc'
    assert cc.commands == ('cmd1', 'cmd2')



# Generated at 2022-06-23 18:30:41.055854
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    for cmd in each_sub_command_config(setup_dir):
        assert cmd.name
        assert cmd.camel
        assert cmd.description
        assert cmd.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:41.639980
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:30:54.327145
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td = str(td)
        with open(os.path.join(td, 'setup.py'), 'w') as fh:
            fh.write('#! /usr/bin/env python\n')
            fh.write('\n')
            fh.write('import setuptools')

        with open(os.path.join(td, 'setup.cfg'), 'w') as fh:
            fh.write('[metadata]\n')
            fh.write('name = flutils\n')

        with open(os.path.join(td, 'setup_commands.cfg'), 'w') as fh:
            fh.write("[setup.command.foo]\n")

# Generated at 2022-06-23 18:30:59.815461
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: This only tests that the function doesn't raise exceptions.
    #       It doesn't test the contents of the returned generator.
    # :FUTURE
    from pathlib import Path

    setup_dir = Path(__file__).parent.parent
    for each in each_sub_command_config(setup_dir):
        print(each)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:08.077437
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    arg_name = 'name'
    arg_camel = 'camel'
    arg_description = 'description'
    arg_commands = ('commands',)
    sec_config = SetupCfgCommandConfig(
        arg_name,
        arg_camel,
        arg_description,
        arg_commands,
    )
    assert sec_config.name == arg_name
    assert sec_config.camel == arg_camel
    assert sec_config.description == arg_description
    assert sec_config.commands == arg_commands

# Generated at 2022-06-23 18:31:11.343954
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        print(sub_command_config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:14.274251
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'hello', 'Hello', 'A description of Hello.', ('echo 1',)
    )


# Unit tests for each_sub_command_config function

# Generated at 2022-06-23 18:31:19.032920
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(setup_dir=os.getcwd()):
        print(config)
        break


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:29.429413
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function, each_sub_command_config()."""
    tests: List[
        Tuple[
            SetupCfgCommandConfig,
            SetupCfgCommandConfig
        ]
    ] = [
        (
            SetupCfgCommandConfig(
                'spam',
                'Spam',
                'Sends spam to specified target(s).',
                (
                    'echo Spam to target: {target}',
                )
            ),
            SetupCfgCommandConfig(
                'hello.world',
                'HelloWorld',
                'Says Hello to the World.',
                (
                    'echo Hello World',
                )
            ),
        ),
    ]
    for expected, actual in tests:
        setup_dir = 'setup.command.{name}'.format(name=expected.name)

# Generated at 2022-06-23 18:31:31.410104
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('test_test', 'TestTest', 'description', ())



# Generated at 2022-06-23 18:31:36.524590
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('one', 'two'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('one', 'two')

# Generated at 2022-06-23 18:31:37.297143
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ())

# Generated at 2022-06-23 18:31:48.831916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.join(this_dir, os.pardir, os.pardir)
    commands = tuple(each_sub_command_config(setup_dir))
    assert len(commands) == 2
    assert commands[0].name == 'build'
    assert commands[0].commands == (
        'python setup.py sdist bdist_wheel',
        'twine check dist/*',
        'twine upload dist/*',
    )
    assert commands[1].name == 'build.clean'
    assert commands[1].commands == (
        'rm -rf build dist *.egg-info',
        'find -name "*.pyc" -type f -delete',
    )

# Generated at 2022-06-23 18:31:58.469406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config(
        '~/git/flutils/flutils/test/test_project'
    ))
    assert len(out) == 3
    assert out[0].name == 'cmd1'
    assert out[0].camel == 'Cmd1'
    assert out[0].description == 'cmd1 description'
    assert out[0].commands == (
        'echo "cmd1"'
    )
    assert out[1].name == 'name2'
    assert out[1].camel == 'Name2'
    assert out[1].description == 'description2'
    assert out[1].commands == (
        'echo "cmd2"'
    )
    assert out[2].name == 'test.name3-with-multiple-commands'
    assert out[2].c

# Generated at 2022-06-23 18:32:06.519867
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    out = SetupCfgCommandConfig(
        description='description',
        name='name',
        camel='Camel',
        commands=('command1', 'command2')
    )
    assert isinstance(out, SetupCfgCommandConfig)
    assert isinstance(out.description, str)
    assert isinstance(out.name, str)
    assert isinstance(out.camel, str)
    assert isinstance(out.commands, tuple)
    assert len(out.commands) == 2
    assert out.commands == ('command1', 'command2')
    assert out.description == 'description'
    assert out.name == 'name'
    assert out.camel == 'Camel'



# Generated at 2022-06-23 18:32:17.981722
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    values = (
        'name',
        'camel',
        'description',
        'commands',
    )
    values = values + tuple(map(lambda x: x.upper(), values))
    cfg = SetupCfgCommandConfig(*values)
    assert cfg.name == values[0]
    assert cfg.camel == values[1]
    assert cfg.description == values[2]
    assert cfg.commands == values[3:]
    assert cfg.name == getattr(cfg, 'name')  # noqa
    assert cfg.camel == getattr(cfg, 'camel')  # noqa
    assert cfg.description == getattr(cfg, 'description')  # noqa
    assert cfg.commands == getattr(cfg, 'commands')  # noqa
    assert cf

# Generated at 2022-06-23 18:32:27.555844
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile
    import shutil

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            # Write the file
            dirpath = tempfile.mkdtemp(prefix='flutils_test_')

# Generated at 2022-06-23 18:32:35.850339
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join, realpath
    from sys import argv
    from sys import path as sys_path

    package_root = dirname(realpath(__file__))
    sys_path.insert(0, join(package_root, '../'))
    assert argv == ['setup_commands.py', 'test']
    args = argv[1:]
    assert args == ['test']

    from setup_commands import each_sub_command_config

    for cmd_cfg in each_sub_command_config(package_root):
        pass

# Generated at 2022-06-23 18:32:44.220590
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each_sub_command_config(
            setup_cfg_path: Optional[Union[os.PathLike, str]] = None,
            **kwargs
    ) -> Generator[Tuple[str, str, str, Tuple[str, ...]], None, None]:
        for config in each_sub_command_config(
                setup_cfg_path, **kwargs
        ):
            yield config.name, config.camel, config.description, config.commands

    here = os.path.dirname(os.path.abspath(__file__))

    # Invalid setup dir
    try:
        list(_each_sub_command_config('/tmp'))
    except FileNotFoundError:
        pass
    else:
        raise Exception("Did NOT fail.")

    # Invalid config file

# Generated at 2022-06-23 18:32:49.304544
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfg = SetupCfgCommandConfig('foo', 'Foo', 'desc', ('1', '2'))
    assert scfg.name == 'foo'
    assert scfg.camel == 'Foo'
    assert scfg.description == 'desc'
    assert scfg.commands == ('1', '2')



# Generated at 2022-06-23 18:32:56.567558
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'travis-deploy'
    camel = 'TravisDeploy'
    description = 'Deploys the package to PyPI.'
    commands = ('python setup.py sdist bdist_wheel',)
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert name == config.name
    assert camel == config.camel
    assert description == config.description
    assert commands == config.commands


# Generated at 2022-06-23 18:32:58.900022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    out = list(each_sub_command_config())
    os.chdir(cwd)
    return out

# Generated at 2022-06-23 18:33:10.299932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setup_helpers as sh
    path = str(os.path.dirname(sh.__file__))
    path = os.path.join(path, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)

    name = parser.get('metadata', 'name').strip()
    for i, cmd in enumerate(_each_setup_cfg_command(parser, {'name': name})):
        print(i, cmd)
        assert isinstance(cmd.commands, (list, tuple))
        assert isinstance(cmd.commands[0], str)
        assert len(cmd.name) > 0
        assert len(cmd.camel) > 0
        assert len(cmd.description) > 0

# Generated at 2022-06-23 18:33:15.653827
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_resources')
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:33:25.951267
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.dirname(path)
    path = os.path.join(path, 'tests')
    path = os.path.join(path, 'data')
    path = os.path.join(path, 'setup_commands')
    path = os.path.join(path, 'temp_project')
    assert os.path.exists(path)
    assert os.path.isdir(path)
    result = tuple(
        x for x in each_sub_command_config(path)
    )
    assert len(result) == 1

    cfg = result[0]
    assert cfg.name == 'name.foo'
    assert cfg.description == 'description'

# Generated at 2022-06-23 18:33:31.949598
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='desc',
        commands='cmd'
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'desc'
    assert config.commands == ('cmd',)

# Generated at 2022-06-23 18:33:37.540866
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        "abc",
        "abc",
        "abc",
        ("def", ),
    )
    assert config.name == "abc"
    assert config.camel == "abc"
    assert config.description == "abc"
    assert config.commands == ("def", )



# Generated at 2022-06-23 18:33:47.680108
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from textwrap import dedent

    root_dir = os.path.dirname(__file__)
    root_dir = os.path.dirname(root_dir)
    setup_dir = os.path.join(root_dir, 'flutils', 'tests')

    # noinspection PyShadowingNames
    def _test(
            name: str,
            sub_commands: str,
            expected: int
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'wt') as f:
            f.write(dedent('''\
            [metadata]
            name = flutils

            [setup.command.test_each_sub_command_config]
            commands = {sub_commands}
            ''').format(sub_commands=sub_commands))

# Generated at 2022-06-23 18:33:57.118739
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Run tests
    # - each_sub_command_config()
    # - each_sub_command_config(str)
    # - each_sub_command_config(os.PathLike)
    import sys
    import pathlib
    this_file = sys.modules[__name__].__file__
    this_dir = os.path.realpath(os.path.dirname(this_file))
    for _ in each_sub_command_config():
        pass
    for _ in each_sub_command_config(this_dir):
        pass
    for _ in each_sub_command_config(pathlib.Path(this_dir)):
        pass



# Generated at 2022-06-23 18:33:58.761805
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-23 18:34:10.212966
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:34:14.225540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    results_list = []
    for result in each_sub_command_config():
        results_list.append(result)
    pprint.pprint(results_list)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:16.074971
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name', 'camel', 'description', ('ls', '-l')
    )



# Generated at 2022-06-23 18:34:22.363013
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config(
            os.path.dirname(
                os.path.dirname(
                    os.path.abspath(__file__)
                )
            )
    ):
        assert isinstance(x, SetupCfgCommandConfig)
        assert isinstance(x.name, str)
        assert isinstance(x.camel, str)
        assert isinstance(x.description, str)

# Generated at 2022-06-23 18:34:30.447769
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        setup_dir = os.path.join(tempdir, 'test')
        os.mkdir(setup_dir)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                # noqa: E501
                """[metadata]
name = test
""")
        setup_dir = os.path.join(tempdir, 'test')
        os.mkdir(setup_dir)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-23 18:34:39.031490
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pprint import pprint
    from collections import OrderedDict

    class SetupCfgCommandConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    expected = OrderedDict()
    for cmd_cfg in each_sub_command_config():
        pprint(cmd_cfg)
        assert cmd_cfg.name not in expected
        expected[cmd_cfg.name] = cmd_cfg


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:34:45.945904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg: SetupCfgCommandConfig = SetupCfgCommandConfig(
        "my_command",
        "MyCommand",
        "My description",
        (
            'echo "a"',
            'echo "b"',
        )
    )
    assert cfg.name == "my_command"
    assert cfg.camel == "MyCommand"
    assert cfg.description == "My description"
    assert cfg.commands == (
        'echo "a"',
        'echo "b"',
    )



# Generated at 2022-06-23 18:34:48.064350
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'desc', ('one', 'two'))



# Generated at 2022-06-23 18:34:53.921504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)

# Generated at 2022-06-23 18:35:04.572346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config."""
    path = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
    ))
    for command in each_sub_command_config(path):
        assert command.name
        assert command.camel
        assert command.description
        for cmd in command.commands:
            assert cmd
    for command in each_sub_command_config():
        assert command.name
        assert command.camel
        assert command.description
        for cmd in command.commands:
            assert cmd



# Generated at 2022-06-23 18:35:05.783726
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('command', 'Command', 'description', ())


# Generated at 2022-06-23 18:35:14.623633
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re

    import pytest

    from . import data

    def _test_each_sub_command_config(
            command_name: str,
            command_description: str,
            *expected_commands: str
    ) -> None:
        for config in each_sub_command_config(data.setup_dir):
            if command_name != config.name:
                continue
            assert config.description == command_description
            assert len(config.commands) == len(expected_commands)
            for cmd, expected_cmd in zip(config.commands, expected_commands):
                expected_cmd = re.sub(r'\\(.)', r'\1', expected_cmd)
                assert cmd == expected_cmd
            break

# Generated at 2022-06-23 18:35:27.485725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '../../src/flutils'
    setup_cfg = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg)
    name = _get_name(parser, setup_cfg)
    
    setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(setup_commands_cfg)
    format_kwargs = {'name': name, 'setup_dir': '', 'home': ''}
    for cfg in _each_setup_cfg_command(parser, format_kwargs):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:38.135704
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read(r'.\setup.cfg')

# Generated at 2022-06-23 18:35:49.723970
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_config(**kwargs: str) -> None:
        assert kwargs['name'] == 'project'
        setup_dir = os.path.join(os.path.dirname(__file__), 'files')
        assert kwargs['setup_dir'] == setup_dir
        assert kwargs['home'] == os.path.expanduser('~')

    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name in ('test', 'tox', 'tox-test')
        cmd_names = (
            'test',
            'tox',
            'tox-test',
        )
        assert config.name in cmd_names

# Generated at 2022-06-23 18:35:52.260182
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name='name', camel='Name',
                                   description='description',
                                   commands=('command 1', 'command 2'))
    assert config.name == 'name'
    assert config.camel == 'Name'
    assert config.description == 'description'
    assert config.commands == ('command 1', 'command 2')


# Generated at 2022-06-23 18:36:02.498657
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    class TestSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            import tempfile

            with tempfile.TemporaryDirectory() as td:
                setup_cfg = os.path.join(td, 'setup.cfg')
                setup_py = os.path.join(td, 'setup.py')
                setup_commands_cfg = os.path.join(td, 'setup_commands.cfg')

                with open(setup_py, 'w') as fh:
                    fh.write('#!/bin/env python3\n')

                with open(setup_cfg, 'w') as fh:
                    fh.write(
                        '[metadata]\n'
                        'name = test\n'
                    )


# Generated at 2022-06-23 18:36:07.125525
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        tuple(['a', 'b', 'c'])
    )
    print(command_config)


if __name__ == '__main__':
    command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        tuple(['a', 'b', 'c'])
    )
    print(command_config)

# Generated at 2022-06-23 18:36:08.612098
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd',))

# Generated at 2022-06-23 18:36:12.704825
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    bloc = SetupCfgCommandConfig("name", "camel", "desc", ("cmd",))
    assert bloc.name == "name"
    assert bloc.camel == "camel"
    assert bloc.description == "desc"
    assert bloc.commands == ("cmd",)


# Generated at 2022-06-23 18:36:18.239510
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test_data',
        'test_project',
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(path)
    for sub_command in each_sub_command_config():
        assert parser.has_section('setup.command.' + sub_command.name)

# Generated at 2022-06-23 18:36:21.660772
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))
    assert x.name == 'name'
    assert x.camel == 'camel'
    assert x.description == 'description'
    assert x.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:36:23.443045
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("name", "camel", "description", ("command", ))



# Generated at 2022-06-23 18:36:35.769316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _make_expected(
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...],
            *,
            setup_dir: str = ''
    ) -> SetupCfgCommandConfig:
        if not setup_dir:
            setup_dir = os.path.dirname(__file__)
        return SetupCfgCommandConfig(
            name,
            camel,
            description.format(setup_dir=setup_dir),
            commands
        )
    cfg_data = """
[metadata]
name = {name}

[setup.command.example]
name = example
description = An example command for '{name}'
command = this is a test
          this will get wrapped in a function
"""
    rd, wd = os.pipe()

# Generated at 2022-06-23 18:36:38.854841
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        name='test',
        camel='test',
        description='test desc',
        commands=('test command',),
    )


# Generated at 2022-06-23 18:36:42.517570
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sc = SetupCfgCommandConfig("hello", "goodbye", "Salutations", ("foo", "bar"))
    assert sc.name == "hello"
    assert sc.camel == "goodbye"
    assert sc.description == "Salutations"
    assert sc.commands == ("foo", "bar")

# Generated at 2022-06-23 18:36:54.212417
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    # Use the development version if available
    sys.path.insert(
        0,
        os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                '..',
                '..',
                '..',
                'src',
                'flutils',
                'cli_utils'
            )
        )
    )

    from cli_utils import each_sub_command_config

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            self.maxDiff = None
            here = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-23 18:37:04.618366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _make(
            name: Optional[str] = None,
            camel: Optional[str] = None,
            description: Optional[str] = None,
            commands: Tuple[str, ...] = (),
    ) -> SetupCfgCommandConfig:
        return SetupCfgCommandConfig(name, camel, description, commands)
