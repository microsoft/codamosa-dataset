

# Generated at 2022-06-23 18:27:03.343085
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase, mock
    from typing import NamedTuple, Optional, Tuple
    from configparser import ConfigParser

    class Namespace(NamedTuple):
        args: Tuple[str, str]

    class MockConfigParser(ConfigParser):
        @property
        def sections(self):
            return self._sections

        @sections.setter
        def sections(self, value):
            self._sections = value

    def _get_args(
            setup_dir: str
    ) -> Generator[Tuple[str, str], None, None]:
        setup_dir = os.path.realpath(setup_dir)
        # setup_dir = os.path.dirname(os.path.dirname(__file__))

# Generated at 2022-06-23 18:27:14.546863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase

    with TestCase().subTest(name='no_setup_dir'):
        out = list(each_sub_command_config())
        assert isinstance(out, list)
        assert out

    test_setup_dir = os.path.join(
        os.path.dirname(__file__),
        '_test_assets',
        'setup_cfg_project'
    )
    with TestCase().subTest(name='with_setup_dir'):
        out = list(each_sub_command_config(test_setup_dir))
        assert isinstance(out, list)
        assert out


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:24.883003
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig("name", "camel", "description", ("commands",))

    assert setup_cfg_command_config.description == "description"
    assert type(setup_cfg_command_config.description) == str

    assert setup_cfg_command_config.commands == ("commands",)
    assert type(setup_cfg_command_config.commands) == tuple

    assert setup_cfg_command_config.name == "name"
    assert type(setup_cfg_command_config.name) == str

    assert setup_cfg_command_config.camel == "camel"
    assert type(setup_cfg_command_config.camel) == str



# Generated at 2022-06-23 18:27:28.531011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pprint

    out: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(sys.modules[__name__].__file__)
    )
    pprint.pprint(out)

# Generated at 2022-06-23 18:27:37.368284
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        # noinspection PyProtectedMember
        each_sub_command_config._validate_setup_dir(
            '/path/to/this/package'
        )
    except Exception:
        # Failed as expected
        pass
    else:
        # DID NOT fail as expected
        raise AssertionError(
            "This 'test_each_sub_command_config' unit test is broken."
        )

    out = list(each_sub_command_config('/path/to/here'))
    assert len(out) == 3
    # noinspection PyUnresolvedReferences
    assert out[0].name == 'setup.command.test'
    # noinspection PyUnresolvedReferences
    assert out[0].camel == 'Test'
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-23 18:27:48.937264
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:27:59.490327
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from io import StringIO
    from textwrap import dedent

    config = dedent("""
    [metadata]
    name = flutils

    [setup.command.foo]
    name = foo command
    description = Foo command description
    command = echo {name} foo command

    [setup.command.bar]
    name = bar command
    description = Bar command description
    command = echo {name} bar command

    [setup.command.baz]
    name = baz command
    description = Bar command description
    command = echo {name} baz command
    """)
    parser = ConfigParser()
    parser.read_file(StringIO(config))
    format_kwargs = {
        'name': 'flutils'
    }
    out = list(_each_setup_cfg_command(parser, format_kwargs))
   

# Generated at 2022-06-23 18:28:08.882098
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import unittest
    import argparse
    import io
    from io import StringIO
    import sys

    _orig_stdout = sys.stdout
    _orig_stderr = sys.stderr

    from contextlib import contextmanager
    @contextmanager
    def _redirect_output(stdout: IO[str], stderr: IO[str]) -> Generator[None, None, None]:
        @contextmanager
        def _redirect(write_attr: str, text_attr: str, stream: IO[str]) -> Generator[None, None, None]:
            orig_value = getattr(sys, text_attr)
            tmp_file = StringIO()
            setattr(sys, write_attr, tmp_file.write)

# Generated at 2022-06-23 18:28:11.398827
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        _ = SetupCfgCommandConfig(
            name='', camel='', description='', commands=()
        )

# Generated at 2022-06-23 18:28:15.054680
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import run_doctests
    run_doctests(vars(), __file__)


if __name__ == '__main__':
    test_each_sub_command_config()



# Generated at 2022-06-23 18:28:21.752576
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import Path
    from logging import basicConfig, DEBUG

    basicConfig(level=DEBUG, format='%(message)s')

    for config in each_sub_command_config(Path(__file__).parent.parent.parent):
        print(repr(config))

    for config in each_sub_command_config(Path(__file__).parent.parent):
        print(repr(config))



# Generated at 2022-06-23 18:28:31.354026
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-23 18:28:34.882997
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='',
        commands=('foo',)
    )
    assert isinstance(command.commands, tuple)
    assert isinstance(command.commands[0], str)
    assert command.commands[0] == 'foo'


# Generated at 2022-06-23 18:28:38.677480
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'Test description'
    commands = ('test1', 'test2')
    cls = SetupCfgCommandConfig(name, camel, description, commands)
    assert cls.name == name
    assert cls.camel == camel
    assert cls.description == description
    assert cls.commands == commands



# Generated at 2022-06-23 18:28:43.180927
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=tuple(),
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == tuple()


# Unit tests for function _each_setup_cfg_command_section()

# Generated at 2022-06-23 18:28:44.563897
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))

# Generated at 2022-06-23 18:28:55.097546
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert type(config) == SetupCfgCommandConfig
        assert config.commands
        assert config.name.startswith(config.camel)

    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(os.path.expanduser('~')))

    with pytest.raises(FileNotFoundError):
        # This test should pass as 'setup.py' should be found in this package.
        list(each_sub_command_config())

if __name__ == '__main__':
    print(list(each_sub_command_config()))

# Generated at 2022-06-23 18:28:58.216902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=missing-function-docstring
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:58.775426
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-23 18:29:08.301241
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    crawler_name = 'FooCrawler'
    crawler_description = 'FooCrawler, A Web Crawler.'
    crawler = SetupCfgCommandConfig(
        crawler_name,
        crawler_name,
        crawler_description,
        (
            'scrapy crawl {name}',
        )
    )
    assert crawler.name == crawler_name
    assert crawler.camel == crawler_name
    assert crawler.description == crawler_description
    assert crawler.commands == (
        'scrapy crawl {name}',
    )



# Generated at 2022-06-23 18:29:13.321388
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = ('commands',)
    cmd = SetupCfgCommandConfig(name, camel, description, commands)
    assert cmd.name == name
    assert cmd.camel == camel
    assert cmd.description == description
    assert cmd.commands == commands

# Generated at 2022-06-23 18:29:25.515971
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib

    # Setup
    setup_dir = pathlib.Path(__file__).parent.parent
    parser = ConfigParser()
    # Test
    for config in each_sub_command_config(setup_dir):
        parser[config.name] = {
            'name': config.name,
            'camel': config.camel,
            'description': config.description,
            'command': '\n'.join(config.commands)
        }
    # Verify
    assert parser.sections() == [
        'test',
        'test.sample',
        'test.test',
        'test_sample'
    ]
    assert parser['test_sample']['name'] == 'test_sample'
    assert parser['test_sample']['camel'] == 'TestSample'

# Generated at 2022-06-23 18:29:34.126526
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig(
        'my.command',
        'MyCommand',
        'My description of the command',
        ('command 1', 'command 2')
    )
    expected = 'SetupCfgCommandConfig(name=\'my.command\', ' \
               'camel=\'MyCommand\', ' \
               'description=\'My description of the command\', ' \
               'commands=(\'command 1\', \'command 2\'))'
    assert repr(actual) == expected

# Generated at 2022-06-23 18:29:38.933767
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command',)
    )
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.commands == ('command',)
    assert sccc.description == 'description'

# Generated at 2022-06-23 18:29:40.301499
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig)

# Generated at 2022-06-23 18:29:44.021527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir=test_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:51.438800
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'cmd_name'
    camel = 'CmdName'
    description = 'A Command'
    commands = ('sleep', '10')
    obj = SetupCfgCommandConfig(name, camel, description, commands)
    assert obj[0] == name
    assert obj.name == name
    assert obj[1] == camel
    assert obj.camel == camel
    assert obj[2] == description
    assert obj.description == description
    assert obj[3] == commands
    assert obj.commands == commands

    assert repr(obj) == repr((name, camel, description, commands))
    assert str(obj) == str((name, camel, description, commands))

# Generated at 2022-06-23 18:30:02.552347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def get_setup_dir(test: str) -> str:
        here = os.path.abspath(os.path.dirname(__file__))
        return os.path.join(here, 'test_files', 'setup_cfg', test)

    def _validate(test: str) -> None:
        setup_dir = get_setup_dir(test)
        for cfg in each_sub_command_config(setup_dir):
            if cfg.name == 'test_one':
                assert cfg.camel == 'TestOne'
                assert cfg.description == 'Test One'
                assert cfg.commands[0] == 'echo "Test One!"'
            elif cfg.name == 'test_two':
                assert cfg.camel == 'TestTwo'

# Generated at 2022-06-23 18:30:03.842822
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("name", "camel", "desc", ())

# Generated at 2022-06-23 18:30:11.152569
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    from flutils.setuputils import SetupCfgCommandConfig

    setup_cfg_command_config = SetupCfgCommandConfig(
        name='My Project',
        camel='MyProject',
        description='An amazing project.',
        commands=('echo "Hello World!"',)
    )
    assert isinstance(setup_cfg_command_config.name, str)
    assert setup_cfg_command_config.name == 'My Project'
    assert setup_cfg_command_config.camel == 'MyProject'
    assert setup_cfg_command_config.description == 'An amazing project.'
    assert isinstance(setup_cfg_command_config.commands, tuple)
    assert len(setup_cfg_command_config.commands) == 1

# Generated at 2022-06-23 18:30:16.360088
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        name='name',
        camel='Name',
        description='description',
        commands=('commands',)
    )
    assert cmd.name == 'name'
    assert cmd.camel == 'Name'
    assert cmd.description == 'description'
    assert cmd.commands == ('commands',)

# Generated at 2022-06-23 18:30:23.972474
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from os import makedirs
    from os.path import realpath

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = realpath(tmp_dir)
        makedirs(os.path.join(tmp_dir, 'src'))
        with open(os.path.join(tmp_dir, 'setup.py'), mode='w') as f:
            f.write(
                "from distutils.core import setup\n"
                "setup(name='hello-world')\n"
            )
        with open(os.path.join(tmp_dir, 'setup.cfg'), mode='w') as f:
            f.write(
                "[metadata]\n"
                "name = hello-world\n"
            )


# Generated at 2022-06-23 18:30:34.414320
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    def get_configs():
        for config in each_sub_command_config():
            yield (
                config.name,
                config.camel,
                config.description,
                config.commands
            )

    def is_config(
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...],
            configs: List[Tuple[str, str, str, Tuple[str, ...]]]
    ) -> bool:
        for config in configs:
            if (
                    config[0] == name
                    and config[1] == camel
                    and config[2] == description
            ):
                if list(config[3]) == list(commands):
                    return True
        return False


# Generated at 2022-06-23 18:30:42.255003
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test without option values
    assert SetupCfgCommandConfig(
        'my_command',
        'MyCommand',
        '',
        ()
    ) == SetupCfgCommandConfig('my_command', 'MyCommand', '', ())

    # Test with option values
    assert SetupCfgCommandConfig(
        'my_command',
        'MyCommand',
        'Runs the my_command',
        ('yes', 'no', 'maybe')
    ) == SetupCfgCommandConfig(
        'my_command',
        'MyCommand',
        'Runs the my_command',
        ('yes', 'no', 'maybe')
    )

# Generated at 2022-06-23 18:30:54.568330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .__about__ import __version__
    from .__about__ import __description__
    from .utils import (
        Config,
        DEFAULT_CONFIG,
    )
    found_inits: int = 0
    found_version: int = 0
    found_description: int = 0
    config: Config
    for config in each_sub_command_config():
        if config.name == 'init':
            found_inits += 1
            assert config.description == DEFAULT_CONFIG.description

# Generated at 2022-06-23 18:31:00.594552
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config_tuple = SetupCfgCommandConfig(
        name="my_name",
        camel="MyName",
        description="This is my description",
        commands=("command1", "command2")
    )
    assert config_tuple.name == "my_name"
    assert config_tuple.camel == "MyName"
    assert config_tuple.description == "This is my description"
    assert config_tuple.commands == ("command1", "command2")



# Generated at 2022-06-23 18:31:03.290096
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        "name",
        "camel",
        "description",
        ("command", )
    )



# Generated at 2022-06-23 18:31:13.812010
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import inspect
    import io
    import contextlib
    import tempfile

    module_name = __name__
    this_module = sys.modules[module_name]

    temp_dir = tempfile.mkdtemp(prefix='%s-' % module_name)
    temp_dir = os.path.realpath(temp_dir)

    # Test empty case
    with contextlib.redirect_stderr(io.StringIO()):
        assert tuple(each_sub_command_config(temp_dir)) == tuple()

    # Test dir with setup.cfg but no [setup.command] sections

# Generated at 2022-06-23 18:31:14.888146
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()

# Generated at 2022-06-23 18:31:27.077540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(__file__)
    path = os.path.dirname(path)
    path = os.path.join(path, '..', '..', '..', 'flutils')
    path = os.path.realpath(path)
    configs = tuple(each_sub_command_config(path))
    assert isinstance(configs, tuple)
    assert len(configs) == 10
    configs = dict((c.name, c) for c in configs)
    assert configs['clean'].description == 'Clean up the build artifacts.'
    assert configs['bdist_wheel.universal'].description == (
        'Build a universal binary distribution.'
    )

# Generated at 2022-06-23 18:31:33.646045
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), '../../../setup.cfg')
    parser = ConfigParser()
    parser.read(path)
    name = _get_name(parser, path)
    format_kwargs: Dict[str, str] = {
        'name': name,
        'setup_dir': os.path.dirname(path),
        'home': os.path.expanduser('~')
    }
    yie

# Generated at 2022-06-23 18:31:41.457207
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command_1', 'command_2')
    )
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('command_1', 'command_2')


# Generated at 2022-06-23 18:31:45.245973
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from dataclasses import fields

    config = SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=()
    )
    assert len(fields(config)) == 4



# Generated at 2022-06-23 18:31:51.504157
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=()
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert isinstance(config.commands, tuple)
    assert len(config.commands) == 0



# Generated at 2022-06-23 18:31:53.940794
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    """
    sub_command = SetupCfgCommandConfig(
        'sub_command', 'sub_command', 'A sub command', ('sub_command',)
    )

# Generated at 2022-06-23 18:32:05.059686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""

    from tempfile import TemporaryDirectory
    from flutils.configutils import get_settings
    from flutils.pathutils import abs_path
    from flutils.mkdir import (
        mkdir,
        mkfile,
    )
    from shutil import which

    def get_entry_points(category: str) -> List[str]:
        """Get the list of entry points for the given ``category``."""
        out = []
        if category == 'console_scripts':
            dirs = os.environ.get('PATH', '').split(os.pathsep)
            for cmd in ('pip', 'pip3'):
                for dir_ in dirs:
                    path = os.path.join(dir_, cmd)

# Generated at 2022-06-23 18:32:15.654642
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_setup_dir(setup_dir: Union[os.PathLike, str]):
        for result in each_sub_command_config(setup_dir):
            print(result)

    # There is no setup_commands.cfg file.
    _test_setup_dir(os.path.join(
        os.path.dirname(__file__), 'res', 'flutils', 'cmdutils'
    ))

    # There is a setup_commands.cfg file.
    _test_setup_dir(os.path.join(
        os.path.dirname(__file__), 'res', 'flutils'
    ))


__all__ = (
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:32:21.416019
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config1 = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Test',
        commands=('a', 'b')
    )
    config2 = SetupCfgCommandConfig(
        'test',
        'Test',
        'Test',
        ('a', 'b')
    )
    assert config1 == config2



# Generated at 2022-06-23 18:32:23.542135
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b'))


# Generated at 2022-06-23 18:32:35.797223
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from random import randint
    from string import ascii_letters
    from string import digits

    name = ''.join([
        ascii_letters[randint(0, len(ascii_letters) - 1)]
        for x in range(0, randint(1, 9))
    ])
    camel = ''.join([
        ascii_letters[randint(0, len(ascii_letters) - 1)]
        for x in range(0, randint(1, 9))
    ])
    description = ''.join([
        ascii_letters[randint(0, len(ascii_letters) - 1)]
        for x in range(0, randint(1, 9))
    ])


# Generated at 2022-06-23 18:32:37.362979
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('Test', 'test', '', ())



# Generated at 2022-06-23 18:32:43.640108
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Check each_sub_command_config
    for sub_command_config in each_sub_command_config():
        print(sub_command_config)
    # Call constructor
    sub_command_config = SetupCfgCommandConfig(
        "name_value",
        "camel_value",
        "description_value",
        ("command_value",)
    )
    print(sub_command_config)
    print(sub_command_config.__repr__())
    print(sub_command_config.name)
    print(sub_command_config.camel)
    print(sub_command_config.description)
    print(sub_command_config.commands)



# Generated at 2022-06-23 18:32:47.967460
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd1',))
    assert x.name == 'name'
    assert x.camel == 'Camel'
    assert x.description == 'description'
    assert x.commands == ('cmd1',)

# Generated at 2022-06-23 18:32:52.284329
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'myname'
    camel = 'MyName'
    description = 'My Description'
    commands = ('python setup.py',)

    config = SetupCfgCommandConfig(name, camel, description, commands)

    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:32:57.715413
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'my_name'
    camel = 'MyName'
    description = 'My Description'
    commands = ('echo my-command', '++', '--')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-23 18:33:10.086322
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from pathlib import Path
    from shutil import copyfile

    from .testing_utils import TESTING_RESOURCES

    def run_test(path: Union[os.PathLike, str]) -> None:
        with patch.object(sys, 'argv', ['setup.py']) as mock:
            with patch(
                    'sys.stdout', new_callable=io.StringIO
            ) as mock_stdout:
                path = Path(path)
                setup_dir: Optional[str] = None
                if path.name != 'setup.cfg':
                    setup_dir = str(path.parent)
                if setup_dir:
                    actual = list(each_sub_command_config(setup_dir))

# Generated at 2022-06-23 18:33:11.594249
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('cmds',))

# Generated at 2022-06-23 18:33:23.191924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pkg_resources

    with pkg_resources.working_set() as working_set:
        dist = next(iter(working_set))
        if dist:
            setup_dir = os.path.join(cast(str, dist.location), '..')
            for cfg in each_sub_command_config(setup_dir):
                if cfg.camel == 'AddPackage':
                    for c in cfg.commands:
                        assert 'python' in c
                        assert 'add_package.py' in c
                    assert cfg.name == 'add_package'
                    assert cfg.description == (
                        "Adds the current project to the '%s' project."
                        % working_set.entry_keys('setuptools.project')[0]
                    )
                    sys.exit(0)
               

# Generated at 2022-06-23 18:33:34.871843
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from unittest import TestCase

    from flutils.testutils import temp_file
    from flutils.testutils import temp_path

    class T(TestCase):
        def test_each_sub_command_config(self):
            temp_path('setup.cfg', 'metadata:\n name=flutils')
            temp_path('setup_commands.cfg', '[setup.command.build]\ncommand='
                      'echo building\n'
                      '[setup.command.test]\nname=Run Tests\ncommands=\n'
                      ' echo testing\n')
            with temp_path():
                out = list(each_sub_command_config())
                self.assertEqual(len(out), 2)
                self.assertEqual(out[0].name, 'build')
                self

# Generated at 2022-06-23 18:33:36.267916
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('', '', '', ())

# Generated at 2022-06-23 18:33:37.899754
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))

# Generated at 2022-06-23 18:33:48.394444
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = str(Path(__file__).resolve().parent.parent)
    class_name = 'SetupCfgCommandConfig'

    # Test arguments
    path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(path)
    name = _get_name(parser, path)
    format_kwargs = {
        'home': '/home/someuser',
        'name': name,
        'setup_dir': setup_dir,
    }

# Generated at 2022-06-23 18:33:54.525336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Returns a generator of config settings
    assert isinstance(each_sub_command_config(), Generator)
    # Doesn't raise an exception on a bad setup directory
    try:
        each_sub_command_config(setup_dir='there-is-no-spoon')
    except FileNotFoundError:
        pass
    else:
        assert False, 'There is no spoon.'

# Generated at 2022-06-23 18:34:02.547938
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _run(setup_dir: Optional[str] = None) -> None:
        import sys
        import subprocess
        import shlex
        import unittest.mock

        configs = list(each_sub_command_config(setup_dir=setup_dir))

        if configs:
            run = subprocess.run

            def mock_run(
                    args: Union[List[str], str],
                    *args_,
                    **kwargs
            ) -> 'subprocess.CompletedProcess':
                nonlocal args
                if isinstance(args, list) is False:
                    args = shlex.split(args)
                return unittest.mock.Mock(returncode=0, args=args)
            run.side_effect = mock_run


# Generated at 2022-06-23 18:34:13.102909
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert config.camel.startswith('_') is False
        assert config.camel[0].isupper() is True
        assert config.camel.isidentifier() is True
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)
            if config.name == 'build_all':
                assert command == 'python setup.py egg_info -e .'

# Generated at 2022-06-23 18:34:20.419524
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    assert setup_dir == os.path.dirname(__file__)
    config_list = list(each_sub_command_config(setup_dir))
    assert len(config_list) == 2
    assert config_list[0].name == 'get.ci.info'
    assert config_list[0].camel == 'GetCiInfo'
    assert config_list[0].description == 'Gets the CI info.'
    assert config_list[0].commands == ('py.test --version', )

    assert config_list[1].name == 'get.env.info'
    assert config_list[1].camel == 'ListEnvVars'
    assert config_list[1].description == 'Lists the environment vars.'
    assert config

# Generated at 2022-06-23 18:34:23.262654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple([config for config in each_sub_command_config()])
    assert configs

# Generated at 2022-06-23 18:34:34.556405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path

    from flutils.miscutils import read_file
    from pyfakefs.fake_filesystem_unittest import TestCase
    from pyfakefs.fake_pathlib import FakePath

    class TestSetupCfgProcessor(TestCase):

        def setUp(self):
            self.setUpPyfakefs()
            self.cwd = os.getcwd()

        def tearDown(self):
            os.chdir(self.cwd)

        def test_each_sub_command_config_path(self):
            os.chdir(self.fs.path)
            path = Path('setup.cfg')
            path.write_text(
                ''
                '\n[metadata]'
                '\nname = test_project'
                '\n'
            )

# Generated at 2022-06-23 18:34:38.647001
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert repr(SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd',))) ==\
        'SetupCfgCommandConfig(name="name", camel="camel", ' \
        'description="desc", commands=("cmd",))'

# Generated at 2022-06-23 18:34:42.002086
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    pprint(tuple(each_sub_command_config()))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:48.121923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, realpath, join

    setup_dir: str = realpath(join(dirname(__file__), '..', '..'))
    assert setup_dir.endswith('flutils')
    assert setup_dir.endswith('setup.py') is False
    assert setup_dir.endswith('setup.cfg') is False

    for cmd in each_sub_command_config(setup_dir):
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.commands, tuple)
        assert isinstance(cmd.description, str)

# Generated at 2022-06-23 18:34:56.878312
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    #
    # Declare a temporary directory, which will be deleted
    #   when the current process ends.
    #
    dirpath = tempfile.TemporaryDirectory()
    filepath = os.path.join(dirpath.name, 'setup.cfg')
    #
    # Create a fake setup.cfg file
    #
    with open(filepath, 'w') as fh:
        fh.writelines(
            (
                '[metadata]\n',
                'name = flutils\n',
                '[setup.command.tests]\n',
                'description = run the tests\n',
                'commands = \n',
            )
        )
    #
    # Add the fake directory to the module search path so
    #   the flutils.setupcfg.each_sub_

# Generated at 2022-06-23 18:35:00.981079
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig('test', 'Test', 'test description', ('test', ))
    assert command.name == 'test'
    assert command.camel == 'Test'
    assert command.description == 'test description'
    assert command.commands == ('test', )

# Generated at 2022-06-23 18:35:08.251318
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    path = os.path.join(cwd, 'setup.py')
    if os.path.isfile(path) is True:
        sub = each_sub_command_config(cwd)
        assert isinstance(sub, Generator)
        assert next(sub, None)

        path = os.path.join(cwd, 'test')
        sub = each_sub_command_config(path)
        raise StopIteration
    else:
        sub = each_sub_command_config()
        raise StopIteration

# Generated at 2022-06-23 18:35:11.180743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from ._project_setup import this_project_path
    from .commands.setup import Setup

    for sc in each_sub_command_config(this_project_path):
        print(sc)
        Setup(sc.commands)

# Generated at 2022-06-23 18:35:23.134526
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import difflib
    import sys
    from tempfile import (
        TemporaryDirectory,
    )
    from textwrap import (
        dedent,
    )

    tmpdir = TemporaryDirectory()
    setup_name = 'e' * 16
    setup_cfg = dedent("""\
    [metadata]
    name = {setup_name}
    [setup.command.foo]
    command = echo foo
    commands = echo bar
    """).format(setup_name=setup_name)
    setup_cfg_path = os.path.join(tmpdir.name, 'setup.cfg')
    with open(setup_cfg_path, 'w') as f:
        f.write(setup_cfg)

# Generated at 2022-06-23 18:35:24.409539
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()



# Generated at 2022-06-23 18:35:29.171269
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('cmd',)



# Generated at 2022-06-23 18:35:40.856167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    def assert_is_not_empty(tup: Tuple[str, ...]):
        msg = "Expected one or more items, but got an empty sequence."
        assert tup, msg

    assert sys.executable
    assert sys.exec_prefix

    env_vars = ('PYTHONHOME', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE')

    for name, value in os.environ.items():
        if name in env_vars:
            yield assert_is_not_empty, value

    def assert_is_configured(func):
        for config in each_sub_command_config():
            yield assert_is_not_empty, config.commands
            yield assert_is_not_empty, config.name
            yield func

# Generated at 2022-06-23 18:35:48.137800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import stderr
    from pprint import pprint
    import logging

    logging.basicConfig(stream=stderr, level=logging.DEBUG)

    for out in each_sub_command_config('/home/ken/devel/flutils'):
        print(type(out))
        print(type(out.commands))
        pprint(out)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:51.060327
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e')) ==\
           SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))



# Generated at 2022-06-23 18:35:56.446100
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "my_name"
    camel = "My_name"
    description = "My description"
    commands = ("MyCommand 1","MyCommand 2")
    command_config = SetupCfgCommandConfig(name, camel, description, commands)
    assert command_config.name == name
    assert command_config.camel == camel
    assert command_config.description == description
    assert command_config.commands == commands

# Generated at 2022-06-23 18:36:01.434681
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        name='foobar',
        camel='FooBar',
        description='Foo bar',
        commands=('foo', 'bar')
    )
    assert isinstance(cfg.name, str) \
        and isinstance(cfg.camel, str) \
        and isinstance(cfg.description, str) \
        and isinstance(cfg.commands, tuple)


# Generated at 2022-06-23 18:36:13.081358
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with open('setup.cfg', 'w') as f:
        f.write('[metadata]\nname = testing\n')
    if os.path.isfile('setup_commands.cfg'):
        os.remove('setup_commands.cfg')
    with open('setup_commands.cfg', 'w') as f:
        f.write(
            "[setup.command.foo.bar]\n"
            "name = foo baz\n"
            "description = A test command.\n"
            "command = \n"
            "# Remove the line below to stop the test command.\n"
            "commands = \n"
            "    echo 'Hello, World!'\n"
        )

# Generated at 2022-06-23 18:36:15.065042
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("name", "camel", "description", ("cmd1", "cdm2"))

# Generated at 2022-06-23 18:36:17.992628
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    vals = list(each_sub_command_config())
    assert len(vals) > 0
    for val in vals:
        for _name in (val.name, val.camel):
            assert _name.isidentifier() is True

# Generated at 2022-06-23 18:36:25.273661
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        name = 'this.is.fun'
        camel = 'ThisIsFun'
        description = 'Tests a namedtuple subclass.'
        commands = ('make test', 'make cov')
        config = SetupCfgCommandConfig(name, camel, description, commands)
    except Exception as e:
        raise type(e)(
            "Test of class SetupCfgCommandConfig failed: %s" % str(e)
        ) from None
    if config.name != name:
        raise AssertionError("Expected %r, but got %r." % (name, config.name))
    if config.camel != camel:
        raise AssertionError("Expected %r, but got %r." % (camel, config.camel))

# Generated at 2022-06-23 18:36:32.692685
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    fmt = '{}/samples/setup/%s'.format(current_dir)
    for fn in '', '_dev':
        setup_dir = fmt.format(fn)
        for sc in each_sub_command_config(setup_dir):
            assert sc.name.startswith(fn)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:36:38.535421
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig('command_name', 'CommandName', 'command description', ())
    assert command_config.name == 'command_name'
    assert command_config.camel == 'CommandName'
    assert command_config.description == 'command description'
    assert command_config.commands == ()



# Generated at 2022-06-23 18:36:46.096541
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_name_implicit(
            parser: ConfigParser,
            setup_cfg_path: str
    ) -> str:
        return _get_name(parser, setup_cfg_path)
    def _each_setup_cfg_command_implicit(
            parser: ConfigParser,
            format_kwargs: Dict[str, str]
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        return _each_setup_cfg_command(parser, format_kwargs)
    #
    # We want to test the function, each_sub_command_config,
    # but we need to mock the parser.
    # So, we'll monkey-patching the modules that it calls.
    configparser._get_name = _get_name_implicit
    configparser._each_setup_cfg_command = _each

# Generated at 2022-06-23 18:36:55.845930
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    from flutils.testutils import capture_stdout

    def test(
            contents_setup_cfg: Optional[str] = None,
            contents_setup_commands_cfg: Optional[str] = None
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)

            # Setup the setup.cfg file.
            path = os.path.join(tmpdir, 'setup.cfg')
            os.mkdir(os.path.join(tmpdir, 'tests'))
            with open(path, 'w') as fh:
                fh.write(contents_setup_cfg)

            # Setup the setup_commands.cfg file.