

# Generated at 2022-06-23 18:27:11.082586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import sys
    import tempfile

    def setup():
        if shutil.which('poetry') is None:
            print('This test requires the "poetry" package manager to be '
                  'installed.'
                  'For more info visit: https://python-poetry.org/docs/')
            sys.exit(1)

    def tear_down():
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        if os.path.exists(temp_file):
            os.remove(temp_file)

    setup()
    temp_dir = tempfile.mkdtemp()
    temp_file = ''


# Generated at 2022-06-23 18:27:19.437140
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert hasattr(each_sub_command_config, '__call__')
    assert hasattr(each_sub_command_config, '__iter__')
    assert hasattr(each_sub_command_config(), '__iter__')
    assert hasattr(each_sub_command_config(), '__next__')
    for cmd in each_sub_command_config():
        assert hasattr(cmd, 'name')
        assert hasattr(cmd, 'camel')
        assert hasattr(cmd, 'description')
        assert hasattr(cmd, 'commands')

# Generated at 2022-06-23 18:27:25.944440
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_command = SetupCfgCommandConfig(
        'x',
        'y',
        'z',
        ('1', '2')
    )
    assert setup_command.name == 'x'
    assert setup_command.camel == 'Y'
    assert setup_command.description == 'z'
    assert setup_command.commands == ('1', '2')



# Generated at 2022-06-23 18:27:29.135412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out: List[str] = []
    for sub_command_config in each_sub_command_config():
        out.append(sub_command_config.name)
    assert 'init' in out

# Generated at 2022-06-23 18:27:34.239705
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "Lorem ipsum"
    camel = 'LoremIpsum'
    description = "Desc..."
    commands = ('cmd1', 'cmd2')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-23 18:27:40.895986
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_name = 'foo'
    cmd_camel = 'Foo'
    cmd_description = 'The foo command'
    cmd_command = 'bar'
    obj = SetupCfgCommandConfig(
        cmd_name,
        cmd_camel,
        cmd_description,
        (cmd_command,))
    assert cmd_name == obj.name
    assert cmd_camel == obj.camel
    assert cmd_description == obj.description
    assert (cmd_command,) == obj.commands



# Generated at 2022-06-23 18:27:45.223561
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    configs = _each_setup_cfg_command(
        parser, {'name': _get_name(parser, 'setup.cfg')}
    )
    list(configs)

# Generated at 2022-06-23 18:27:49.969109
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test_get_command_name(setup_dir: str) -> None:
        opts = each_sub_command_config(setup_dir)
        cmd1 = next(opts)
        assert cmd1.name == 'hello_world'
    test_get_command_name('tests/data/example_project')

# Generated at 2022-06-23 18:27:58.832780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test that the function each_sub_command_config works as expected."""
    from pathlib import Path
    from flutils.pathutils import each_dir
    from flutils.pyutils import (
        is_main,
        py_to_pyi,
    )
    from flutils.shellutils import (
        clean_local_pyc,
        get_file_mod_time,
        run_cmd,
    )
    from flutils.textutils import compare_text

    pyi_files = []
    for d in each_dir('flutils', 'tests'):
        for f in d.glob('*.pyi'):
            dn = d.as_posix()
            fn = f.as_posix()

# Generated at 2022-06-23 18:28:05.604624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = list(each_sub_command_config('.'))
    assert len(result) > 0
    first = result[0]
    assert isinstance(first, SetupCfgCommandConfig)
    assert isinstance(first.name, str)
    assert isinstance(first.description, str)
    assert isinstance(first.commands, tuple)
    assert len(first.commands) > 0
    assert len(first.name) > 0
    assert len(first.description) > 0


if __name__ == "__main__":
    assert test_each_sub_command_config()

# Generated at 2022-06-23 18:28:12.267058
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    n = 'mmm'
    c = 'Mmm'
    d = 'Test'
    cmd = ['-h', '--help']
    s = SetupCfgCommandConfig(n, c, d, cmd)
    assert s.name == n
    assert s.camel == c
    assert s.description == d
    assert s.commands == tuple(cmd)

# Generated at 2022-06-23 18:28:21.583580
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.chdir(os.getcwd())
    for sub_command_config in each_sub_command_config():
        pass


if __name__ == '__main__':
    from sys import stdout

    def print_sub_command_config(
            sub_command_config: SetupCfgCommandConfig
    ) -> None:
        r"""Prints a sub command config."""
        print(sub_command_config.name)
        print(sub_command_config.camel)
        print(sub_command_config.description)
        print('-' * len(sub_command_config.description))
        print(*sub_command_config.commands, sep='\n')
        print('-' * len(sub_command_config.description))
        print()


# Generated at 2022-06-23 18:28:31.243187
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', ())
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass

    try:
        SetupCfgCommandConfig('$$$', '$$$', '$$$', ())
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass

    try:
        SetupCfgCommandConfig('', '$$$', '$$$', ())
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass

    try:
        SetupCfgCommandConfig('$$$', '', '$$$', ())
        assert False, 'Should have raised ValueError'
    except ValueError:
        pass


# Generated at 2022-06-23 18:28:32.737733
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd1', 'cmd2'))

# Generated at 2022-06-23 18:28:38.397271
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_up
    config: SetupCfgCommandConfig

    for setup_dir in each_up('.', 'setup.py', True):
        break
    else:
        assert False, "Unable to find the directory that contains the " \
                      "setup.py file."

    count = 0
    for config in each_sub_command_config(setup_dir):
        count += 1
        assert config.name is not None
        assert config.camel is not None
        assert config.description is not None
        assert config.commands is not None
    assert count > 0


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:42.747706
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command',))


if __name__ == "__main__":
    import sys
    from flutils.debugutils import pp
    pp(list(each_sub_command_config(sys.argv[1])))

# Generated at 2022-06-23 18:28:55.143695
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:29:02.593583
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from abc import ABCMeta
    from inspect import (
        isclass as isclass_,
        isfunction as isfunction_,
        ismethod as ismethod_,
        isroutine as isroutine_,
    )
    from unittest import TestCase

    from flutils.enumutils import EnumDict

    class ABCMetaABC(ABCMeta, EnumDict):
        pass

    class ABCABC(metaclass=ABCMetaABC):
        pass

    class ABCABCItem(ABCABC):
        pass

    class A(ABCABCItem):
        pass

    class B(ABCABCItem):
        pass

    class C(ABCABCItem):
        pass


# Generated at 2022-06-23 18:29:14.217029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import tempfile
    import traceback

    expected_commands = [
        'echo',
        'build',
        'clean',
        'prep',
        'build_egg',
        'build_sphinx',
        'build_py',
        'check',
        'egg_info',
        'install',
        'install_egg_info',
        'install_lib',
        'install_scripts',
        'register',
        'sdist',
        'upload',
        'upload_sphinx',
        'test',
        'upload_docs'
    ]


# Generated at 2022-06-23 18:29:26.240092
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_path = os.path.join(
        os.path.realpath(os.path.dirname(__file__)),
        '..',
        'resources',
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)

    expected = 'flutils'
    actual = _get_name(parser, setup_cfg_path)
    assert expected == actual

    setup_dir = os.path.realpath(os.path.dirname(__file__))

# Generated at 2022-06-23 18:29:38.210845
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            name='mock_command',
            camel='MockCommand',
            description='Run the Mock command.',
            commands=('echo "mock_command"',)
        )
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            name=None,
            camel=None,
            description=None,
            commands=('echo "mock_command"',)
        )
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(
            name='mock_command',
            camel='MockCommand',
            description='Run the Mock command.',
            commands=('echo "mock_command"',)
        )

# Generated at 2022-06-23 18:29:44.836948
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config(os.path.dirname(__file__)):
        print('command.name', command.name)
        print('command.commands', command.commands)
        print('command.description', command.description)
        print('command.camel', command.camel)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:53.685119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fileutils import mk_temp_dir
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from io import StringIO

    class MkTempDir(TemporaryDirectory):
        def __init__(self) -> None:
            self.path = None
            super().__init__()

        def __enter__(self):
            self.path = super().__enter__()
            self.path = Path(self.path)
            return self.path

    with MkTempDir() as temp_dir:
        temp_dir = Path(temp_dir)
        setup_py = temp_dir / 'setup.py'
        setup_py.write_text('')

        setup_cfg = temp_dir / 'setup.cfg'

# Generated at 2022-06-23 18:29:59.303139
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None
    for config in each_sub_command_config(setup_dir=setup_dir):
        if config.name == 'sdist':
            print(config)
            break


if __name__ == '__main__':
    # Unit test this module.
    import sys
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-23 18:30:09.020222
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    for section, command_name in _each_setup_cfg_command_section(parser):
        commands: List[str] = []
        options: List[str] = parser.options(section)
        for option in ('command', 'commands'):
            if option in options:
                val: str = parser.get(section, option)
                commands += list(
                    filter(len, map(lambda x: x.strip(), val.splitlines()))
                )
        if commands:
            cmd_name = ''
            if 'name' in options:
                cmd_name = parser.get(section, 'name')
            cmd_name = cmd_name or command_name
            cmd_name = cmd_name.format(name='flutils')

            description = ''


# Generated at 2022-06-23 18:30:15.673391
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.textutils import indent_block

    for cfg in each_sub_command_config():
        print('Name:', cfg.name)
        print('Camel:', cfg.camel)
        print('Description:', cfg.description)
        print('Commands:')
        for cmd in cfg.commands:
            print(indent_block(cmd, indent_width=2))
        break



# Generated at 2022-06-23 18:30:23.618716
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )

    generator = each_sub_command_config(path)
    config = next(generator)
    assert config.name == 'init'
    assert config.camel == 'Init'
    assert config.description == ''
    assert config.commands == ('flutils init',)

    config = next(generator)
    assert config.name == 'git.init'
    assert config.camel == 'GitInit'
    assert config.description == 'Initializes a Git repository.'
    assert config.commands == ('git init',)

    assert next(generator).name == 'update_sub_modules'
    assert next(generator).name == 'test'

# Generated at 2022-06-23 18:30:33.635127
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    section = 'setup.command.mycmd'
    parser.add_section(section)
    parser.set(section, 'command', 'echo $setup_dir')
    setup_cfg_path = 'setup.cfg'

    name = _get_name(parser, setup_cfg_path)
    format_kwargs = {
        'name': name,
        'setup_dir': '.',
        'home': '/home/test'
    }

    config = _each_setup_cfg_command(parser, format_kwargs).__next__()
    assert config.name == 'mycmd'
    assert config.camel == 'Mycmd'
    assert config.description == ''
    assert config.commands == ('echo .',)


# Generated at 2022-06-23 18:30:43.307977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import json
    from flutils.handleutils import to_file_handle
    from tempfile import TemporaryDirectory
    from os.path import isdir, join
    from shutil import copy
    from pathlib import Path
    from textwrap import dedent

    from_dir = Path(__file__).parent
    with TemporaryDirectory() as tmpdir:
        to_dir = Path(tmpdir)
        copy(str(from_dir / 'setup_commands.cfg'), str(to_dir))
        copy(str(from_dir / 'setup.cfg'), str(to_dir))
        assert isdir(tmpdir) is True
        each = list(each_sub_command_config(tmpdir))
        assert len(each) == 2

# Generated at 2022-06-23 18:30:44.031221
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-23 18:30:50.334574
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccfg = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('cmd',)
    )
    assert sccfg.name == 'name'
    assert sccfg.camel == 'camel'
    assert sccfg.description == 'description'
    assert sccfg.commands == ('cmd',)


# Generated at 2022-06-23 18:31:00.519202
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_data_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'data',
        'test_each_sub_command_config'
    )
    setup_dir = os.path.join(test_data_dir, 'setup_dir')

# Generated at 2022-06-23 18:31:03.966031
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name', 'Camel', 'desc', ('c',))
    assert setup_cfg_command_config is not None

# Generated at 2022-06-23 18:31:09.566177
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commands1', 'commands2'),
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('commands1', 'commands2')



# Generated at 2022-06-23 18:31:12.784845
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'test description'
    commands = ('test command',)
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:31:25.157179
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import glob
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        if fs.filename.endswith('__init__.py'):
            setup_cfg_dir = str(os.path.dirname(fs.filename))
            break
    else:
        raise RuntimeError('Unable to find setup_cfg_dir.')
    setup_cfg_dir = os.path.dirname(setup_cfg_dir)
    setup_cfg_dir = os.path.dirname(setup_cfg_dir)
    setup_cfg_dir = os.path.dirname(setup_cfg_dir)
    setup_cfg_dir = os.path.dirname(setup_cfg_dir)
    setup_cfg_dir = os.path.join(setup_cfg_dir, 'tests')
    setup_cfg_

# Generated at 2022-06-23 18:31:36.046395
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_to_desc: Dict[str, str] = {
        'clean': 'Clean all intermediate and cached files from the project.',
        'collect': 'Collects all configuration and templates for the project.',
        'git': 'Initializes a new git repository for the project.',
    }

# Generated at 2022-06-23 18:31:42.724417
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Test to ensure that the function, each_sub_command_config, works
    as intended.

    This function cannot test actually build any of the commands, but
    it can test that they are generated properly.
    """
    out = list(each_sub_command_config(setup_dir=__file__))
    assert out

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:54.030690
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re
    import flutils.logutils as lu
    _log = lu.Logger.make_logger(__name__)

    def _each_config(setup_dir: Optional[str]) -> Generator[
            str, None, None
    ]:
        for config in each_sub_command_config(setup_dir):
            yield '%s - %s' % (config.camel, config.description)

    _log.debug('Setup dir for this project is %r.', _prep_setup_dir())

# Generated at 2022-06-23 18:32:00.940345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from . import __file__ as module_file
    dirname, filename = os.path.split(module_file)
    os.chdir(dirname)

# Generated at 2022-06-23 18:32:08.921298
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.case import TestCase
    from unittest.mock import Mock
    from unittest.mock import mock_open
    from unittest.mock import patch

    class _Test(TestCase):

        def _test(
                self,
                setup_cfg_content: str,
                setup_commands_cfg_content: str = None,
                expected_commands: List[Tuple[str, str]] = None
        ) -> None:
            setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            with patch('os.path.isfile', return_value=True):
                with patch(
                        'builtins.open',
                        mock_open(read_data=setup_cfg_content)
                ) as mk:
                    yield from each_sub_

# Generated at 2022-06-23 18:32:11.566684
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test',
        'Test',
        'A test',
        ('test command',)
    )

# Generated at 2022-06-23 18:32:20.799471
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import system
    from pathlib import Path
    from tempfile import mkstemp, gettempdir
    from flutils.regex import (
        re_escape,
    )
    from flutils.strutils import (
        slugify,
    )
    from flutils.sysutils import is_darwin, is_linux

    # Create a temp file
    fd, filename = mkstemp(suffix='.cfg')
    os.close(fd)


# Generated at 2022-06-23 18:32:33.187345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    name = 'test_command_name'
    camel = 'TestCommandName'
    description = 'test command description'
    commands = (
        '/bin/ls {setup_dir}',
        'ls -l /bin'
    )

    # test constructor
    assert SetupCfgCommandConfig(name, camel, description, commands)

    # test constructor with invalid name argument
    with pytest.raises(ValueError):
        assert SetupCfgCommandConfig('', camel, description, commands)

    with pytest.raises(ValueError):
        assert SetupCfgCommandConfig('[]', camel, description, commands)

    # test constructor with invalid camel argument
    with pytest.raises(ValueError):
        assert SetupCfgCommandConfig(name, '&%^&', description, commands)

    # test constructor with invalid description argument

# Generated at 2022-06-23 18:32:38.883628
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'Foo description'
    commands = ('echo first', 'echo second')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:32:46.936639
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit testing the constructor of the :class:`SetupCfgCommandConfig`
    named tuple.
    """
    name = 'name'
    camel = 'Camel'
    desc = 'Description'
    commands = ('cmd1', 'cmd2')
    res = SetupCfgCommandConfig(name, camel, desc, commands)

    assert res.name == name
    assert res.camel == camel
    assert res.description == desc
    assert res.commands == commands


# Generated at 2022-06-23 18:32:51.776848
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='echo',
        camel='Echo',
        description='hello',
        commands=('echo hello', 'echo world')
    )
    assert obj.name == 'echo'
    assert obj.camel == 'Echo'
    assert obj.description == 'hello'
    assert obj.commands == ('echo hello', 'echo world')


# Generated at 2022-06-23 18:32:53.409610
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # noqa: D103
    for config in each_sub_command_config():
        assert len(config.commands) > 0



# Generated at 2022-06-23 18:33:02.611756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    def _assert(
            cfg: SetupCfgCommandConfig,
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        assert cfg.name == name
        assert cfg.camel == camel
        assert cfg.description == description
        assert cfg.commands == commands

    with tempfile.TemporaryDirectory() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'foo')
        os.makedirs(setup_dir)
        path = os.path.join(setup_dir, 'setup.cfg')
        with open(path, 'w') as f:
            f.write(SETUP_CFG1)

# Generated at 2022-06-23 18:33:09.252371
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(setup_dir: str) -> None:
        for config in each_sub_command_config(setup_dir):
            print(config)
    _test_each_sub_command_config(
        os.path.join(os.path.dirname(__file__), '../../pypkgs/flutils/setup')
    )

# Generated at 2022-06-23 18:33:17.348308
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig(
        name = 'name',
        camel = 'Camel',
        description = 'Description',
        commands = ('command1', 'command2')
    )

    assert isinstance(instance, SetupCfgCommandConfig)
    assert isinstance(instance.name, str)
    assert isinstance(instance.camel, str)
    assert isinstance(instance.description, str)
    assert isinstance(instance.commands, tuple)

    assert instance.name == 'name'
    assert instance.camel == 'Camel'
    assert instance.description == 'Description'
    assert instance.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:33:19.172916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) >= 0



# Generated at 2022-06-23 18:33:27.961645
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import deep_glob
    from flutils.testutils import UnitTestBase, TempDirMixin

    class TestCase(UnitTestBase, TempDirMixin):
        def test_it(self):
            configs = list(each_sub_command_config(self.temp_dir))
            self.assertEqual(configs, [])

# Generated at 2022-06-23 18:33:40.622439
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    setup_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:33:50.137274
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    curr_dir = os.path.abspath(os.path.dirname(__file__))
    setup_cfg_path = os.path.join(curr_dir, 'setup.cfg')

    name = _get_name(ConfigParser(), setup_cfg_path)

    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'name': name,
        'setup_dir': str(curr_dir),
        'home': os.path.expanduser('~'),
    }

    # Test
    out = each_sub_command_config(setup_dir=curr_dir)
    out = tuple(out)

    # Verify
    assert out == _each_setup_cfg_command(parser, format_kwargs)



# Generated at 2022-06-23 18:33:56.502709
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='my-cmd',
        camel='MyCmd',
        description='This is my cmd.',
        commands=('echo hello',),
    )
    assert str(config) == "SetupCfgCommandConfig(name='my-cmd', camel='MyCmd', " \
                          "description='This is my cmd.', commands=('echo hello',))"



# Generated at 2022-06-23 18:34:01.242821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.join(
        os.path.dirname(__file__),
        'test_setup_commands.cfg'
    )
    path = os.path.realpath(test_dir)
    yield from each_sub_command_config(path)

# Generated at 2022-06-23 18:34:03.221210
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ['command'])


# Generated at 2022-06-23 18:34:05.383899
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config('~/Projects/flutils'):
        print(i)

# Generated at 2022-06-23 18:34:10.726106
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        'my_command',
        'MyCommand',
        'This is my command.',
        ('foo', 'bar', 'baz')
    )
    assert obj.name == 'my_command'
    assert obj.camel == 'MyCommand'
    assert obj.description == 'This is my command.'
    assert obj.commands == ('foo', 'bar', 'baz')


# Generated at 2022-06-23 18:34:14.610275
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print(SetupCfgCommandConfig.__name__)

    for config in each_sub_command_config():
        print(config.name, config.description, config.commands)


# -- MAIN
if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:34:25.315893
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(setup_dir: str):
        try:
            yield from each_sub_command_config(setup_dir)
        except Exception as e:
            raise Exception(
                'Unable to retrieve configs for each sub command. %s'
                % e
            ) from e
    empty_dir = tempfile.mkdtemp()
    for t in _test(empty_dir):
        assert False, 'setup_dir contains no setup.py'
    setup_dir = tempfile.mkdtemp()
    with open(os.path.join(setup_dir, 'setup.py'), 'w'):
        pass
    for t in _test(setup_dir):
        assert False, 'setup_dir contains no setup.cfg'
    setup_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:34:36.654697
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import get_location
    from flutils.sysutils import get_python_executable

    loc = get_location('flutils', 'deep_eq_test.py')
    setup_dir = os.path.dirname(loc)
    python_cmd = get_python_executable()
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)


# Generated at 2022-06-23 18:34:37.810564
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass


# Generated at 2022-06-23 18:34:47.002666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    logger = logging.getLogger()
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    # python -m unittest -v flutils.scripts.create_setup_command_script
    from unittest import TestCase

    class Test(TestCase):
        def test_each_sub_command_config(self):
            for e in each_sub_command_config(
                    setup_dir='/usr/lib/python3.7/site-packages/numpy'
            ):
                logger.debug(e)

    test = Test()
    test.test_each_sub_command_config()



# Generated at 2022-06-23 18:34:53.301262
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read(os.path.join(os.path.dirname(__file__), 'setup.cfg'))
    setup_dir = os.path.dirname(__file__)
    for config in _each_setup_cfg_command(parser,):
        print(config)


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:35:04.275869
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    type(SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    ))
    type(SetupCfgCommandConfig(
        name='name',
        camel='camel',
        description='description',
        commands=('command',)
    ))
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    ).name
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    ).camel
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    ).description
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    ).commands

# Generated at 2022-06-23 18:35:09.335017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.environ.get('SETUP_DIR')
    if setup_dir:
        # noinspection PyBroadException
        try:
            actual = list(each_sub_command_config(setup_dir=setup_dir))
            print(actual)
        except Exception:
            traceback.print_exc()


each_sub_command_config()

# Generated at 2022-06-23 18:35:17.469302
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test ``each_sub_command_config`` function."""
    import pytest
    cur_dir = os.path.dirname(__file__)
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(cur_dir))

    path = os.path.dirname(cur_dir)
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(path))

    path = os.path.dirname(path)
    out = list(each_sub_command_config(path))
    assert out

# Generated at 2022-06-23 18:35:18.150999
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('default', 'Default', '', ('',))

# Generated at 2022-06-23 18:35:29.793625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from importlib import resources
    from flutils.testutils import TempDir

    def _validate_config(
            commands: List[SetupCfgCommandConfig]
    ) -> None:
        assert len(commands) == 2
        assert commands[0].name == 'test'
        assert commands[0].description == ''
        assert commands[0].camel == 'Test'
        assert commands[0].commands == (
            'pytest',
            '{setup_dir}/tests/',
            '-v',
            '--cov-report term-missing --cov {name}',
            '--nocapture',
        )
        assert commands[1].name == 'build'
        assert commands[1].description == ''
        assert commands[1].camel == 'Build'

# Generated at 2022-06-23 18:35:41.283222
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    data = [
        {'name': 'a', 'camel': 'A', 'description': 'x', 'commands': ['b', 'c']},
        {'name': 'a', 'camel': 'B', 'description': 'x', 'commands': ['b', 'c']},
        {'name': 'a', 'camel': 'A', 'description': 'y', 'commands': ['b', 'c']},
        {'name': 'a', 'camel': 'A', 'description': 'x', 'commands': ['d', 'c']},
    ]
    config = SetupCfgCommandConfig(**data[0])
    assert(config.name == data[0]['name'])
    assert(config.camel == data[0]['camel'])

# Generated at 2022-06-23 18:35:47.343344
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    x = list(each_sub_command_config())
    y = ''.join(x[0])
    assert x[0].camel == 'CmdOne'
    assert x[1].camel == 'CmdThree'
    assert x[2].camel == 'CmdTwo'
    assert y.startswith('CmdOne')
    assert y.endswith('CmdThree')

# Generated at 2022-06-23 18:35:48.650491
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands'))

# Generated at 2022-06-23 18:35:53.655703
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import assert_has_attrs

    for sub_cmd_cfg in each_sub_command_config():
        expected_attrs = ('name', 'camel', 'description', 'commands')
        assert_has_attrs(sub_cmd_cfg, *expected_attrs)
        assert sub_cmd_cfg.name
        assert sub_cmd_cfg.camel
        assert sub_cmd_cfg.description
        assert sub_cmd_cfg.commands
        assert len(sub_cmd_cfg.commands)

# Generated at 2022-06-23 18:36:02.288355
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    from pyfakefs.fake_filesystem_unittest import Patcher

    class EachSubCommandConfigTestCase(TestCase):

        def setUp(self):
            self.base_dir = os.path.realpath(os.getcwd())
            self.temp_dir = TemporaryDirectory()
            self.temp_dir.name = os.path.realpath(self.temp_dir.name)
            self.fs_patcher = Patcher()
            self.fs_patcher.setUp()
            self.addCleanup(self.fs_patcher.tearDown)
            self.addCleanup(self.temp_dir.cleanup)


# Generated at 2022-06-23 18:36:14.204734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Build test data
    paths = {}
    # 1) Build the setup.cfg file.

# Generated at 2022-06-23 18:36:22.101125
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        # Add required files
        setup_dir = td
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
        with open(setup_py_path, 'w') as f:
            f.write('')
        with open(setup_cfg_path, 'w') as f:
            f.write('''[metadata]
name = my-package''')

# Generated at 2022-06-23 18:36:33.662163
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from itertools import chain
    from random import choice, randrange
    from string import ascii_letters, digits
    from tempfile import mkdtemp
    from unittest import TestCase
    from flutils.pathutils import save_text_file

    class Test(TestCase):
        setup_cfg = """\
[metadata]
name = {name}

[setup.command.foo]
name = {name} foo
description= Foo
command=
  foo some command

[setup.command.bar]
name = {name} bar
description= Bar
command=
  bar some command

[setup.command.baz]
name = {name} baz
description= Baz
command=
  baz some command
"""

# Generated at 2022-06-23 18:36:40.360317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import sys
    setup_dir = os.path.dirname(__file__)
    out = list(each_sub_command_config(setup_dir))
    if sys.version_info < (3, 8):
        pprint.pprint(out, indent=2, width=120)
    else:
        pprint.pprint(out, indent=2, compact=True)

# Generated at 2022-06-23 18:36:41.347343
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    return



# Generated at 2022-06-23 18:36:47.080526
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('commands'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('commands')



# Generated at 2022-06-23 18:36:56.092908
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from textwrap import dedent
    from tempfile import TemporaryDirectory
    import shutil
    import sys

    def _get_command(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> SetupCfgCommandConfig:
        return next(each_sub_command_config(setup_dir))

    with TemporaryDirectory() as dirname:
        dirname = os.path.realpath(str(dirname))
        setup_py_path = os.path.join(dirname, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write(dedent("""
                from setuptools import setup

                setup(name='mypkg')
            """))

        c = _get_command()
        assert c.name == 'mypkg'
        assert c

# Generated at 2022-06-23 18:36:59.750993
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', ('', '', ''))
    except TypeError:
        pass
    else:
        raise Exception('Failed to catch TypeError')