

# Generated at 2022-06-23 18:27:04.683117
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "my.setup.name"
    camel = "MySetupName"
    description = "My setup description"
    commands = ("asdf", "qwer")
    """This function is testing the constructor of class SetupCfgCommandConfig."""
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:27:08.104857
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'my_module'
    description = 'A description of my module.'
    commands = ('pip install .', 'npm init')
    config = SetupCfgCommandConfig(name, description, commands)
    assert config.name == name
    assert config.description == description
    assert config.commands == commands



# Generated at 2022-06-23 18:27:20.466508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, 'test_data')
    setup_dir = os.path.join(test_dir, 'test-package')

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.sccs = list(each_sub_command_config(setup_dir))

        def test_len(self):
            self.assertEqual(len(self.sccs), 2)


# Generated at 2022-06-23 18:27:22.373260
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('one', 'two'))



# Generated at 2022-06-23 18:27:31.137067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.tests.mock as mock
    import unittest.mock as mock_unittest

# Generated at 2022-06-23 18:27:38.738978
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Name'
    description = 'description'
    commands = ['command1', 'command2']
    c = SetupCfgCommandConfig(name, camel, description, commands)
    assert c.name == name
    assert c.camel == camel
    assert c.description == description
    assert c.commands == commands
    assert c == SetupCfgCommandConfig(
        name, camel, description, commands
    )



# Generated at 2022-06-23 18:27:42.226619
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Name', 'Description', ('cmd1',))
    assert config.name == 'name'
    assert config.camel == 'Name'
    assert config.description == 'Description'
    assert config.commands == ('cmd1',)

# Generated at 2022-06-23 18:27:52.684642
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    setup_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:27:56.103446
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', tuple())
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == tuple()

# Generated at 2022-06-23 18:28:07.471428
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat
    from pathlib import Path
    from flutils.pathutils import EasyPath
    from flutils.testutils.pytestutils import assert_value_from_function
    from flutils.testutils.pytestutils import (
        assert_list_from_function,
        assert_list_dict_from_function,
    )
    import sys
    import inspect

    # Test the function and the generator's output object
    exout = [
        {'camel': 'SetupPy', 'commands': (), 'description': '', 'name': ''},
        {
            'camel': 'PackageUpdate',
            'commands': (),
            'description': '',
            'name': 'update'
        }
    ]

# Generated at 2022-06-23 18:28:08.916696
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command1', ))


# Generated at 2022-06-23 18:28:14.015029
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    n = "name"
    cn = "camel"
    d = "description"
    c = ("command",)
    s = SetupCfgCommandConfig(n, cn, d, c)
    assert s.name == n
    assert s.camel == cn
    assert s.description == d
    assert s.commands == c

# Generated at 2022-06-23 18:28:16.621361
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args = object(), object(), object(), object()
    assert SetupCfgCommandConfig(*args) == SetupCfgCommandConfig(*args)



# Generated at 2022-06-23 18:28:24.031928
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig('n', 'N', 'D', ('a', 'b'))
    assert command == SetupCfgCommandConfig(*command)
    assert command == SetupCfgCommandConfig(
        name=command.name,
        camel=command.camel,
        description=command.description,
        commands=command.commands
    )
    assert command.name == 'n'
    assert command.camel == 'N'
    assert command.description == 'D'
    assert command.commands == ('a', 'b')

# Generated at 2022-06-23 18:28:24.544210
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-23 18:28:35.520754
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from tempfile import gettempdir

    def _test_scenario(
            setup_cfg: str,
            setup_commands_cfg: str,
            expected_configs: Optional[SetupCfgCommandConfig] = None,
            raises: Optional[Exception] = None
    ) -> None:
        import os

        from flutils.persistutils import write_str

        from flutils.miscutils import temp_dir

        setup_cfg = setup_cfg.strip()
        setup_commands_cfg = setup_commands_cfg.strip()

        expected_configs = expected_configs or []
        expected_configs = cast(List[SetupCfgCommandConfig], expected_configs)

        with temp_dir() as temp_dir:
            temp_dir = cast(str, temp_dir)
            write_

# Generated at 2022-06-23 18:28:40.393650
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig('test_name', 'TestName', 'Test Description', ('test command',))
    assert test.name == 'test_name'
    assert test.camel == 'TestName'
    assert test.description == 'Test Description'
    assert test.commands == ('test command',)


# Generated at 2022-06-23 18:28:43.199637
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        "test.name",
        "Test.Name",
        "Test Description",
        tuple(["Test Command"])
    )

# Generated at 2022-06-23 18:28:55.548132
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # ...
    from unittest.mock import patch

    with patch('os.path.isfile') as isfile_patch:
        isfile_patch.return_value = True
        with patch('configparser.ConfigParser') as parser_patch:
            parser_patch().sections.return_value = (
                'setup.command.sdist',
                'setup.command.sdist.foo',
                'setup.command.sdist.bar',
                'setup.command.bdist_wheel',
                'setup.command.foo',
                'setup.command',
            )

# Generated at 2022-06-23 18:28:58.216794
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "name"
    camel = "Camel"
    description = "description"
    commands = tuple(["cmd1", "cmd2"])
    SetupCfgCommandConfig(name, camel, description, commands)


# Generated at 2022-06-23 18:29:10.019346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import functools
    import inspect
    from pprint import pformat
    from unittest.mock import patch
    from unittest.mock import MagicMock

    import pytest
    from flutils.testutils import TestCase

    from setuputils.setup_cfg import (
        SetupCfgCommandConfig,
        each_sub_command_config,
        _prep_setup_dir,
    )

    config_mock = MagicMock()
    config_mock.return_value = 'config'

    parser_mock = MagicMock()
    parser_mock.return_value = 'parser'

    class UnitTester(TestCase):

        config_patcher = patch(
            'setuputils.setup_cfg.ConfigParser',
            new=config_mock
        )
        real_parser = ConfigParser

# Generated at 2022-06-23 18:29:16.298331
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.tests.data import linked_setup_commands_dir

    setup_dir = linked_setup_commands_dir
    setup_dir = setup_dir.joinpath('setup_commands')
    setup_dir = setup_dir.resolve()
    setup_dir = os.fspath(setup_dir)

    list(each_sub_command_config(setup_dir))

# Generated at 2022-06-23 18:29:21.013237
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testutils import assert_attrs_equal
    assert_attrs_equal(
        SetupCfgCommandConfig('', '', '', ()),
        SetupCfgCommandConfig(name='', camel='', description='', commands=())
    )


# Generated at 2022-06-23 18:29:29.787249
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from unittest import mock

    class Test(TestCase):
        def setUp(self):
            self.mock_setup_dir = mock.MagicMock(spec=str)
            self.mock_setup_dir.return_value = 'test_project'
            self.patch_prep_setup_dir = mock.patch(
                'flutils.setuptools.prep_setup_dir',
                new=self.mock_setup_dir
            )
            self.patch_prep_setup_dir.start()


# Generated at 2022-06-23 18:29:36.760556
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test name',
        camel='test camel',
        description='this is a test',
        commands=('a', 'b', 'c')
    )
    assert config.name == 'test name'
    assert config.camel == 'test camel'
    assert config.description == 'this is a test'
    assert config.commands == ('a', 'b', 'c')



# Generated at 2022-06-23 18:29:41.824369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for name, _, description, commands in each_sub_command_config():
        assert name
        assert description
        assert commands


__all__ = [
    'each_sub_command_config',
    'test_each_sub_command_config',
]

# Generated at 2022-06-23 18:29:51.696428
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.envutils import env_true
    test_root = os.path.dirname(__file__)
    if env_true('FLUTILS_TEST_SETUP_DIR'):
        setup_dir = os.path.join(test_root, '..', '..')
    else:
        setup_dir = os.path.join(test_root, 'testdata', 'setup_commands')
    assert os.path.isdir(setup_dir)
    with open(os.path.join(setup_dir, 'setup_commands.cfg')) as f:
        lines = f.read()
    assert lines.startswith('[setup.command.test_command1]')
    assert lines.endswith(
        'test_command4.description = {description}')

# Generated at 2022-06-23 18:29:58.119121
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '..', '..', '..')
    configs = list(each_sub_command_config(path))
    assert len(configs) == 1
    config = configs[0]
    assert config.name == 'run'
    assert config.commands == ('{setup_dir}/run.py',)

# Generated at 2022-06-23 18:30:06.792137
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from random import choice
    from string import ascii_letters

    from flutils.pathutils import mkdir, path_to_bytes, temp_directory

    def _random_string() -> str:
        return ''.join(choice(ascii_letters) for _ in range(10))


# Generated at 2022-06-23 18:30:17.680334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(
            setup_dir: str,
            exp_data: Tuple[
                str,
                str,
                str,
                Tuple[str, ...]
            ]
    ) -> None:
        """Validates that each returned value from the function
        ``each_sub_command_config`` is equal to the expected data.
        """
        exp_data = cast(Tuple[str, str, str, Tuple[str, ...]], exp_data)
        exp_intfs = ['name', 'camel', 'description', 'commands']
        exp_data = dict(zip(exp_intfs, exp_data))
        exp_data = dict(
            filter(lambda x: x[1] is not None, exp_data.items())
        )

# Generated at 2022-06-23 18:30:23.181155
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testutils import assert_attrs
    SetupCfgCommandConfig(
        'test',
        'Test',
        'test',
        ('test',)
    )
    assert_attrs(
        SetupCfgCommandConfig, 'name', 'camel', 'description', 'commands'
    )



# Generated at 2022-06-23 18:30:25.222090
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert (
        SetupCfgCommandConfig('name', 'Camel', 'desc', ('command',))
    )

# Generated at 2022-06-23 18:30:35.486695
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Tests the ``each_sub_command_config`` function.
    """
    from tests.pyunit_utils import TEST_PY_DIR # pylint: disable=C0415
    from pprint import pformat

    out = list(each_sub_command_config(TEST_PY_DIR))
    assert len(out) == 2
    assert out[0].name == 'build_wheel'
    assert out[0].camel == 'BuildWheel'
    assert out[0].description == 'Build wheel(s) for the packaged project.'
    assert out[0].commands == (
        'python setup.py bdist_wheel',
        'twine upload -r pypi dist/*',
        'twine upload -r pypitest dist/*',
    )

# Generated at 2022-06-23 18:30:44.598279
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    buf = StringIO()

# Generated at 2022-06-23 18:30:49.755727
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", ("command", "command"))
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ("command", "command")



# Generated at 2022-06-23 18:30:55.536931
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError):
        SetupCfgCommandConfig()
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('name', 'Test', '', (), )
    assert SetupCfgCommandConfig('name', 'Test', '', ())
    assert SetupCfgCommandConfig('name', 'Test', '', (), )
    assert SetupCfgCommandConfig('name', 'Test', '', (), ) == \
        SetupCfgCommandConfig('name', 'Test', '', (), )
    assert SetupCfgCommandConfig('name', 'Test', '', (), ) != \
        SetupCfgCommandConfig('name', 'Test', '', (), 'a', 'b')

# Generated at 2022-06-23 18:31:03.389994
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup_commands.cfg')
    format_kwargs = {
        'name': 'flutils',
        'setup_dir': _prep_setup_dir('.'),
        'home': os.path.expanduser('~')
    }
    for config in _each_setup_cfg_command(parser, format_kwargs):
        out = tuple(config)
        assert out
        cmd_name, camel, description, commands = out
        assert isinstan

# Generated at 2022-06-23 18:31:11.028914
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import get_config_dir
    scripts_dir = 'scripts'
    config_dir = get_config_dir('flutils', 'scripts')
    path = os.path.join(config_dir, scripts_dir)
    script_names = [os.path.join(path, x)
                    for x in os.listdir(path) if x.endswith('.py')]
    assert 'run_setup_command' in script_names


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:12.713008
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(None):
        # print(config)
        pass

# Generated at 2022-06-23 18:31:14.177968
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('0', '1', '2', ('3',))

# Generated at 2022-06-23 18:31:26.489102
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='woot',
        camel='Woot',
        description='This is a test',
        commands=('command', 'another command')
    ).name == 'woot'
    assert SetupCfgCommandConfig(
        name='woot',
        camel='Woot',
        description='This is a test',
        commands=('command', 'another command')
    ).camel == 'Woot'
    assert SetupCfgCommandConfig(
        name='woot',
        camel='Woot',
        description='This is a test',
        commands=('command', 'another command')
    ).description == 'This is a test'

# Generated at 2022-06-23 18:31:28.167457
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig(): # type: ignore
    assert SetupCfgCommandConfig('name', 'Camel', 'Description', ())

# Generated at 2022-06-23 18:31:29.081152
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig()

# Generated at 2022-06-23 18:31:35.338173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # if os.path.exists('setup_commands.cfg'):
    #     os.remove('setup_commands.cfg')
    for config in each_sub_command_config():
        print(config.name, config.camel, config.description, config.commands)
    # if os.path.exists('setup_commands.cfg'):
    #     os.remove('setup_commands.cfg')

# Generated at 2022-06-23 18:31:46.985566
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pytest import raises

    with raises(TypeError):
        SetupCfgCommandConfig()
    with raises(TypeError):
        SetupCfgCommandConfig('name',)
    with raises(TypeError):
        SetupCfgCommandConfig('name', 'camel')
    with raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description')
    with raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description', [])
    with raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description', (), 1)
    with raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description', ('a', 1))

# Generated at 2022-06-23 18:31:51.951754
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('foo', 'Bar', 'Foo', ('bar', 'baz'))
    assert obj.name == 'foo'
    assert obj.camel == 'Bar'
    assert obj.description == 'Foo'
    assert obj.commands == ('bar', 'baz')



# Generated at 2022-06-23 18:31:54.704060
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected = SetupCfgCommandConfig('hello', 'Hello', 'h', ('a', 'b'))
    assert tuple(expected) == ('hello', 'Hello', 'h', ('a', 'b'))



# Generated at 2022-06-23 18:32:01.889083
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "desc", ("cmd1", "cmd2"))
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "desc"
    assert config.commands == ("cmd1", "cmd2")
    assert str(config) == "SetupCfgCommandConfig(name='name', camel='camel', description='desc', commands=('cmd1', 'cmd2'))"

# Generated at 2022-06-23 18:32:05.588453
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'Camel', 'description', ('command1', 'command2')
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:32:17.163049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config."""
    from os import remove
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import Mock
    from re import compile

    class SetupCfgCommandConfigTest(TestCase):
        def test_each_sub_command_config(self):
            with TemporaryDirectory(prefix='tmp') as tmpdir:
                path = Path(tmpdir, 'setup.py')
                with path.open('w') as f:
                    f.write('#!/usr/bin/env python\n')
                path = Path(tmpdir, 'setup.cfg')
                with path.open('w') as f:
                    f.write(
                        '[metadata]\n'
                        'name=foobar\n'
                    )

# Generated at 2022-06-23 18:32:19.225469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _test_each_sub_command_config(
        'tests.unit.resources.setupcfg.util.test_each_sub_command_config'
    )



# Generated at 2022-06-23 18:32:20.829258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(list(each_sub_command_config()))



# Generated at 2022-06-23 18:32:24.033163
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1',))
    except Exception as err:
        raise err

# Generated at 2022-06-23 18:32:29.537577
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    try:
        os.chdir(os.path.dirname(__file__))
        configs = list(each_sub_command_config())
        assert configs[0].name == 'test_command'
    finally:
        os.chdir(cwd)

# Generated at 2022-06-23 18:32:38.876142
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pytest import raises
    from textwrap import dedent

    config = '[setup.command.bar]\n'\
             'command =\n'\
             '  $ echo "Foo" > foo.txt\n'\
             '  $ echo "Bar" > bar.txt\n'\
             'description =\n'\
             '  Blah\n'\
             '  Blah'

    parser = ConfigParser()
    parser.read_string(config)

    format_kwargs={'name': 'foo'}


# Generated at 2022-06-23 18:32:43.551041
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # pylint: disable=unused-argument
    cfg = SetupCfgCommandConfig(
        'create_foo',
        'CreateFoo',
        'Create Foo',
        ('foo', 'bar', )
    )
    assert cfg.name == 'create_foo'
    assert cfg.camel == 'CreateFoo'
    assert cfg.description == 'Create Foo'
    assert cfg.commands == ('foo', 'bar', )



# Generated at 2022-06-23 18:32:48.247940
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command', )
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command', )



# Generated at 2022-06-23 18:32:59.791769
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from flutils.toolutils import (
        info,
        setup_dir
    )
    from flutils.testingutils import (
        mkdtemp_setup_dir,
        register_tempdir
    )

    tdir = tempfile.TemporaryDirectory()
    register_tempdir(tdir)
    tdir_path = tdir.name

    # test empty config
    with mkdtemp_setup_dir(tdir_path) as d:
        assert list(each_sub_command_config(d)) == []

    # test basic config

# Generated at 2022-06-23 18:33:05.483460
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('command_name', 'CommandName', 'Command description', tuple('command_command'))
    assert config.name == 'command_name'
    assert config.camel == 'CommandName'
    assert config.description == 'Command description'
    assert config.commands == ('command_command',)

# Generated at 2022-06-23 18:33:16.526339
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from re import fullmatch
    from tempfile import TemporaryDirectory

    from flutils.fileutils import TEST_BASE_PATH

    from . import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    with TemporaryDirectory() as temp_dir:
        temp_dir = os.path.realpath(temp_dir)
        source_dir = os.path.join(TEST_BASE_PATH, 'setuputils', 'tests')
        shutil.copytree(source_dir, temp_dir)

        kwargs = {'setup_dir': temp_dir}

        # Test setup_commands.cfg

        out: List[SetupCfgCommandConfig] = list(
            each_sub_command_config(**kwargs)
        )


# Generated at 2022-06-23 18:33:19.224603
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.configutils import each_sub_command_config
    for i in each_sub_command_config():
        print(i)

# Generated at 2022-06-23 18:33:23.884865
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(__file__)
    for cfg in each_sub_command_config(test_dir):
        print(cfg)
    for cfg in each_sub_command_config():
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:27.896538
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')


# Generated at 2022-06-23 18:33:30.504821
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('hello', 'Hello', 'hello', 'command')

# Generated at 2022-06-23 18:33:41.362758
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import os.path
    import pprint
    import sys
    here = os.path.abspath(os.path.dirname(__file__))
    setup_py_path = os.path.join(here, '..', 'setup.py')
    setup_py_path = os.path.realpath(setup_py_path)
    setup_dir = os.path.dirname(setup_py_path)
    configs = tuple(
        map(lambda x: x._asdict(), each_sub_command_config(setup_dir))
    )
    configs = pprint.pformat(configs)
    sys.stdout.write('%s\n' % configs)


# Generated at 2022-06-23 18:33:50.681913
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:34:00.498716
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Executes the unit test for the ``each_sub_command_config`` function."""
    path = os.path.abspath(os.path.dirname(__file__))
    while True:
        if os.path.exists(os.path.join(path, 'setup.py')):
            break
        if path == '/':
            raise FileNotFoundError(
                "Unable to find the directory that contains the 'setup.py' file."
            )
        path = os.path.dirname(path)

    setup_cfg_commands = []
    for cmd in each_sub_command_config(path):
        setup_cfg_commands.append(cmd)
    setup_cfg_commands = tuple(setup_cfg_commands)

# Generated at 2022-06-23 18:34:11.077226
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tests = (
        '../../..',
        os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))
        )))
    )
    for test in tests:
        for i, next in enumerate(each_sub_command_config(test)):
            if i == 0:
                assert next.camel == 'FlutilsLoggingSkeleton'
                assert next.description == 'Generate a logging skeleton.'
                assert next.name == 'python_skeleton'
                assert next.commands[0] == 'python -m flutils.flutils_logging_skeleton'
            elif i == 1:
                assert next.camel == 'FlutilsSetupPySkeleton'

# Generated at 2022-06-23 18:34:17.105751
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for target in ('../flutils', '../click-flutils', '../click-tools'):
        target_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            target,
        )
        print()
        print(target_dir)
        for config in each_sub_command_config(target_dir):
            print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:26.045092
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with set_cwd('..') as cwd:
        assert cwd.startswith('..') is True
        assert len(cwd) > 2
        assert os.path.exists(cwd) is True
        assert os.path.isdir(cwd) is True
        setup_dir = str(cwd)
        assert os.path.isdir(setup_dir) is True
        assert os.path.isfile(os.path.join(setup_dir, 'setup.py')) is True
        assert os.path.isfile(os.path.join(setup_dir, 'setup.cfg')) is True
        expected = (
            'cleanup-build',
            'cleanup-dist',
            'check',
            'release',
        )

# Generated at 2022-06-23 18:34:34.939587
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(__file__)
    base_dir = os.path.dirname(test_dir)
    setup_cfg_dir = os.path.join(base_dir, 'setup_commands')
    cfg = os.path.join(setup_cfg_dir, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(cfg)
    for section, command in _each_setup_cfg_command_section(parser):
        print(section)
        for option in parser.options(section):
            print('    %s=%s' % (option, parser.get(section, option)))
    for cfg in each_sub_command_config(setup_cfg_dir):
        print(cfg)

# Generated at 2022-06-23 18:34:42.544397
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase
    from unittest.mock import Mock

    class Test(TestCase):
        def setup_method(self):
            self.t = SetupCfgCommandConfig(
                Mock(), Mock(), Mock(), Mock()
            )

        def test_config(self):
            assert self.t.name is not None
            assert self.t.camel is not None
            assert self.t.description is not None
            assert self.t.commands is not None

    Test()

# Generated at 2022-06-23 18:34:48.678958
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for the function each_sub_command_config."""
    clear_cache = True
    for config in each_sub_command_config(setup_dir=os.getcwd()):
        clear_cache = False
        print(config)
    if clear_cache:
        print('Each sub-command was not found.')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:52.124130
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        print(cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:00.373585
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command = SetupCfgCommandConfig(
        "test.test_t", "TestT",
        "This is a test command.",
        ("echo 'This is a test message.'",)
    )
    assert setup_cfg_command.name == "test.test_t"
    assert setup_cfg_command.camel == "TestT"
    assert setup_cfg_command.commands == ("echo 'This is a test message.'",)
    assert setup_cfg_command.description == "This is a test command."

# Generated at 2022-06-23 18:35:10.298575
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    a: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert len(a) == 6
    assert a[0].name == 'coverage.report'
    assert a[0].description == 'Generate testing coverage report.'
    assert len(a[0].commands) == 1
    assert (
        a[0].commands[0] ==
        'coverage report --show-missing --fail-under 90 --omit=*/tests/*'
    )
    assert a[1].name == 'coverage.html'
    assert a[1].description == 'Generate testing coverage HTML report.'
    assert len(a[1].commands) == 1
    assert (
        a[1].commands[0] ==
        'coverage html --omit=*/tests/*'
    )
   

# Generated at 2022-06-23 18:35:21.638253
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)

    for section, command_name in _each_setup_cfg_command_section(parser):
        assert command_name in (
            'test',
            'test_describe_test',
            'test_add',
            'test_sub',
            'test_mul',
            'test_div'
        )
        assert isinstance(section, str)
        assert isinstance(command_name, str)


# Generated at 2022-06-23 18:35:31.784225
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys

    base_dir: str = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test_data',
        'project'
    )
    setup_commands_cfg_path = os.path.join(base_dir, 'setup_commands.cfg')
    setup_cfg_path = os.path.join(base_dir, 'setup.cfg')
    for path in (setup_cfg_path, setup_commands_cfg_path):
        if os.path.isfile(path):
            os.remove(path)

    if sys.platform.startswith('win'):
        home = r'C:\Users\UserName'

# Generated at 2022-06-23 18:35:37.816078
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    # Create a very simple setup.cfg file
    tmpdir = tempfile.mkdtemp()
    setup_dir = os.path.join(tmpdir, 'setup.cfg')
    setup_dir = os.path.realpath(setup_dir)

# Generated at 2022-06-23 18:35:42.450319
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), 'data')):
        print(command)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:53.402639
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap
    dir = tempfile.TemporaryDirectory()

    setup_cfg = textwrap.dedent("""\
        [metadata]
        name = flutils_test
        """)
    with open(os.path.join(dir.name, 'setup.cfg'), 'w') as fp:
        fp.write(setup_cfg)

    setup_commands_cfg = textwrap.dedent("""\
        [setup.command.make_config]
        command =
            python -c "import flutils_test as m, os;m.make_config('{setup_dir}/config_template.ini')"
            """)
 

# Generated at 2022-06-23 18:36:02.165857
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        sccc = SetupCfgCommandConfig(
            'hello',
            'Hello',
            'some desc',
            ('run', )
        )
    except Exception:
        assert False, 'Test SetupCfgCommandConfig failed!'

    assert 'hello' == sccc.name
    assert 'hello' == sccc[0]
    assert 'Hello' == sccc.camel
    assert 'Hello' == sccc[1]
    assert 'some desc' == sccc.description
    assert 'some desc' == sccc[2]
    assert ('run', ) == sccc.commands
    assert ('run', ) == sccc[3]

# Generated at 2022-06-23 18:36:10.773759
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for class SetupCfgCommandConfig."""
    out = SetupCfgCommandConfig(
        'mycommand.myitem',
        'Mycommand_Myitem',
        'My command description.',
        ('echo 1', 'echo 2', 'echo 3')
    )
    assert out.name == 'mycommand.myitem'
    assert out.camel == 'Mycommand_Myitem'
    assert out.description == 'My command description.'
    assert out.commands == ('echo 1', 'echo 2', 'echo 3')

# Generated at 2022-06-23 18:36:17.875465
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_command_config = SetupCfgCommandConfig(
        'my_command_name',
        'MyCommandName',
        'Description for my command name.',
        ('echo "Hello World"', 'exit 1')
    )
    assert setup_command_config.name == 'my_command_name'
    assert setup_command_config.camel == 'MyCommandName'
    assert setup_command_config.description == 'Description for my command name.'
    assert setup_command_config.commands == ('echo "Hello World"', 'exit 1')



# Generated at 2022-06-23 18:36:25.198515
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import argv
    from types import FunctionType
    from unittest.mock import MagicMock

    # -----------------------------
    # test_each_sub_command_config
    # -----------------------------

    _run_file = argv[0]
    argv[0] = 'setup.py'
    try:
        for cfg in each_sub_command_config():
            assert isinstance(cfg, SetupCfgCommandConfig)
            assert isinstance(cfg.name, str)
            assert isinstance(cfg.camel, str)
            assert isinstance(cfg.description, str)
            assert isinstance(cfg.commands, tuple)
            for command in cfg.commands:
                assert isinstance(command, str)
    finally:
        argv[0] = _run_file

    # ------------------------
   

# Generated at 2022-06-23 18:36:28.990160
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def gen():
        for item in each_sub_command_config('./demo'):
            yield item
    out = list(gen())
    assert all(map(lambda x: isinstance(x, SetupCfgCommandConfig), out))

# Generated at 2022-06-23 18:36:36.505143
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_config = SetupCfgCommandConfig(name='meow', camel='Meow',
                    description='meow meow', commands=('meow', ))
    assert isinstance(test_config, SetupCfgCommandConfig)
    assert test_config.name == 'meow'
    assert test_config.camel == 'Meow'
    assert test_config.description == 'meow meow'
    assert test_config.commands == tuple(['meow'])

# Generated at 2022-06-23 18:36:38.854441
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    pprint.pprint(list(each_sub_command_config()))

# Generated at 2022-06-23 18:36:51.590267
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'test_proj')
    out = list(each_sub_command_config(path))
    assert len(out) == 2
    assert isinstance(out[0], SetupCfgCommandConfig)
    assert out[0].name == 'test-proj.testing_command'
    assert out[0].camel == 'TestProjTestingCommand'
    assert out[0].description == (
        "A test for the 'test_proj' project's setup.cfg and setup.py files."
    )

# Generated at 2022-06-23 18:36:59.373176
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name',
                                                     'camel', 'description', ('command1', 'command2'))
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.commands == ('command1', 'command2')
