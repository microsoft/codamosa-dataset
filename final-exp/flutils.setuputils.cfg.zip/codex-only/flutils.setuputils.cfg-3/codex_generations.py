

# Generated at 2022-06-23 18:27:03.690291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import gettempdir
    from unittest import TestCase
    from unittest.mock import patch

    class Test(TestCase):
        def test__each_setup_cfg_command_section(self):
            parser = ConfigParser()
            parser.add_section('metadata')
            parser.set('metadata', 'name', 'flutils')
            parser.add_section('setup.command.my_command')
            parser.set('setup.command.my_command', 'description', 'My Command')
            parser.set(
                'setup.command.my_command',
                'command',
                'echo "WORKS!"; echo "WORKS!"'
            )
            parser.add_section('setup.command.my_command2')

# Generated at 2022-06-23 18:27:08.075801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__), 'test_files', 'sub_command_config'
    )
    for cfg in each_sub_command_config(setup_dir):
        assert isinstance(cfg, SetupCfgCommandConfig)

# Generated at 2022-06-23 18:27:14.851522
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test case',
        commands=('test', 'case')
    )
    assert x.name == 'test'
    assert x.camel == 'Test'
    assert x.description == 'test case'
    assert x.commands == ('test', 'case')


# Generated at 2022-06-23 18:27:19.105302
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected = SetupCfgCommandConfig(
        description='Test',
        commands=('cmd',),
        name='setup.command.test',
        camel='SetupCommandTest'
    )
    assert expected == SetupCfgCommandConfig('Test', 'test', 'cmd')



# Generated at 2022-06-23 18:27:24.213242
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():   # noqa: D103
    c = SetupCfgCommandConfig("name", "camel", "description", ())
    assert c.name == "name"
    assert c.camel == "camel"
    assert c.description == "description"
    assert c.commands == ()



# Generated at 2022-06-23 18:27:27.912378
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig('testing', 'Testing', 'description', ())
    assert s.name == 'testing'
    assert s.camel == 'Testing'
    assert s.description == 'description'
    assert s.commands == ()

# Generated at 2022-06-23 18:27:37.028984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os.path as p
    import tempfile

    with tempfile.TemporaryDirectory(prefix='flutils_') as tmp_dir:
        setup_dir = p.join(tmp_dir, 'setup')
        os.mkdir(setup_dir)
        p.join(setup_dir, 'setup.py')
        setup_cfg_path = p.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-23 18:27:48.565587
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class MockParser(object):
        def __init__(self, section_map):
            self._section_map = section_map

        def sections(self):
            return self._section_map.keys()

        def options(self, section):
            return self._section_map[section].keys()

        def get(self, section, option):
            return self._section_map[section][option]

    parser = MockParser({
        'setup.command.test': {
            'command': 'run -m test.run',
            'description': 'Run the unittests.'
        },
        'setup.command.foo': {
            'command': 'run -m foo.run',
            'description': 'Dummy test.'
        }
    })
    format_kwargs = dict(name='test')

# Generated at 2022-06-23 18:27:59.409270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cur_dir = os.path.realpath(os.path.dirname(__file__))
    path = os.path.join(cur_dir, 'tests', 'fixtures', 'setup_commands')
    setup_cmd_configs = list(each_sub_command_config(path))

# Generated at 2022-06-23 18:28:02.844637
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_cfg_config = []
    for cfg_config in each_sub_command_config('/home/todd/projects/flutils/'):
        each_cfg_config.append(cfg_config)
    assert len(each_cfg_config) == 1

# Generated at 2022-06-23 18:28:11.000825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            setup_dir: Optional[Union[os.PathLike, str]],
            expected_out: List[SetupCfgCommandConfig]
    ) -> None:
        out: List[SetupCfgCommandConfig] = []
        for x in each_sub_command_config(setup_dir):
            out.append(x)
        assert out == expected_out

    setup_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 18:28:15.104775
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # initialize object
    test_object = SetupCfgCommandConfig('', '', '', ())

    # constructors test
    assert test_object

    # repr test
    assert repr(test_object)

    # str test
    assert str(test_object)



# Generated at 2022-06-23 18:28:26.571251
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.autogen import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    from pprint import pprint
    from textwrap import dedent

    def command_setup_dir(
            command: str,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        setup_dir = setup_dir or os.getcwd()
        for cmd in each_sub_command_config(setup_dir):
            if cmd.name == command:
                yield cmd

    path = os.path.join(os.path.expanduser('~'), 'flutils_test_data', 'sub_commands')
    path = os.path.abspath(path)


# Generated at 2022-06-23 18:28:28.933150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config():
        print(sub_cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:30.075025
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # TODO: Update to test this.
    assert True

# Generated at 2022-06-23 18:28:33.481131
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig('abc', 'abc', 'abc', ('abc', ))
    assert test[0] == 'abc'
    assert test[1] == 'abc'
    assert test[2] == 'abc'
    assert test[3] == ('abc', )

# Generated at 2022-06-23 18:28:39.526779
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #
    # First, verify that the function handles the error cases.
    #
    # This should raise an error because the directory does not exist.
    try:
        list(each_sub_command_config('/badpath/'))
    except (FileNotFoundError, NotADirectoryError):
        pass
    else:
        raise AssertionError('Expected an error to be raised.')

    # This should raise an error because the directory does not contain
    # a ``setup.py`` file.
    try:
        list(each_sub_command_config('/usr/'))
    except (FileNotFoundError, NotADirectoryError):
        pass
    else:
        raise AssertionError('Expected an error to be raised.')

    # This should raise an error because the directory does not contain a
    # ``

# Generated at 2022-06-23 18:28:43.930727
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    configs = each_sub_command_config()
    for config in configs:
        assert config.name is not None
        assert config.camel is not None
        assert config.description is not None
        for command in config.commands:
            assert command is not None


# Generated at 2022-06-23 18:28:56.263408
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pprint
    from tempfile import TemporaryDirectory

    from .examples import strip_str

    with TemporaryDirectory() as tmp:
        setup_cfg = strip_str("""
            [metadata]
            name = test-package

            [tool:pytest]
            addopts = --verbose
        """)
        setup_py = strip_str("""
            #!/usr/bin/env python

            from setuptools import setup

            setup()
        """)

# Generated at 2022-06-23 18:29:03.530158
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = 'setup.command.name'
    parser = ConfigParser()
    parser.add_section(section)
    parser.set(section, 'name', 'command.name')
    parser.set(section, 'description', 'Command Name')
    parser.set(section, 'command', '')
    parser.set(section, 'commands', '')
    format_kwargs = {
        'setup_dir': os.path.realpath('.'),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, 'setup.cfg')
    configs = _each_setup_cfg_command(parser, format_kwargs)
    config = tuple(configs)[0]

# Generated at 2022-06-23 18:29:09.081385
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig(
        'name',
        'camel',
        'description', 
        ('test',),
    )
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('test',)

# Generated at 2022-06-23 18:29:19.599269
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class :class:`.SetupCfgCommandConfig`."""
    import unittest.mock

    name = unittest.mock.sentinel.name
    camel = unittest.mock.sentinel.camel
    description = unittest.mock.sentinel.description
    commands = unittest.mock.sentinel.command

    results = SetupCfgCommandConfig(
        name=name, camel=camel, description=description, commands=commands
    )
    assert results.name == name
    assert results.camel == camel
    assert results.description == description
    assert results.commands == commands



# Generated at 2022-06-23 18:29:26.501023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', '..')
    )
    setup_dir = os.path.join(setup_dir, 'flutils')
    for config in each_sub_command_config(setup_dir):
        assert len(config.camel) > 1
        assert config.name
        assert config.camel
        assert config.commands
        assert len(config.commands)

# Generated at 2022-06-23 18:29:29.120030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config()."""
    for data in each_sub_command_config():
        type(data)

# Generated at 2022-06-23 18:29:36.437567
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Setup
    b = SetupCfgCommandConfig(
        'cmd-name',
        'CmdName',
        'cmd name',
        ('ls', 'pwd')
    )

    # Asserts
    assert b.name == 'cmd-name'
    assert b.camel == 'CmdName'
    assert b.description == 'cmd name'
    assert b.commands == ('ls', 'pwd')


# Generated at 2022-06-23 18:29:44.021824
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    cur_dir = os.path.dirname(__file__)
    orig_dir = os.getcwd()

# Generated at 2022-06-23 18:29:48.292534
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(
        each_sub_command_config(setup_dir='fluentcheck')
    )
    for config in configs:
        assert config.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:59.723909
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with pytest.raises(NotADirectoryError):
        each_sub_command_config(__file__)
    with pytest.raises(FileNotFoundError):
        each_sub_command_config(__name__)
    with pytest.raises(FileNotFoundError):
        setup_dir = os.path.abspath(os.path.dirname(__file__))
        _validate_setup_dir(setup_dir)

    setup_dir = os.path.dirname(os.path.dirname(__file__))
    configs = list(each_sub_command_config(setup_dir))
    assert configs

    configs = list(each_sub_command_config())
    assert configs

# Generated at 2022-06-23 18:30:09.119002
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from cmdkit.cmdkit import Config
    from cmdkit.cmdkit import Command

    class Cmd(Command):
        @property
        def config_section(self) -> str:
            return 'foo'

    cmd = Cmd(None)
    config = Config(cmd)

    name = 'bar'
    description = 'bar description'
    commands = ['echo', 'hello world']

    sccc = SetupCfgCommandConfig(
        name,
        'cmd_bar',
        description,
        commands,
    )
    assert sccc.name == name
    assert sccc.camel == 'cmd_bar'
    assert sccc.description == description
    assert sccc.commands == commands

    assert config.get('foo.name') == name
    assert config.get('foo.description') == description


# Generated at 2022-06-23 18:30:14.806559
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from sys import stderr
    from flutils.systemutils import whereis_exe

    for cmd in each_sub_command_config():
        if not cmd.commands or not whereis_exe(cmd.commands[0]):
            stderr.write(cmd.name + '\n')
            pprint(cmd)



# Generated at 2022-06-23 18:30:20.105437
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ['command'])
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ['command']

# Generated at 2022-06-23 18:30:27.302657
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = 'build'
    description = 'some description'
    setup_cfg_command_config = SetupCfgCommandConfig(
        command,
        command,
        description,
        ()
    )
    assert setup_cfg_command_config.name == command
    assert setup_cfg_command_config.camel == command
    assert setup_cfg_command_config.description == description
    assert setup_cfg_command_config.commands == ()

# Generated at 2022-06-23 18:30:34.282657
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase, TestSuite, TextTestRunner
    from unittest.mock import patch, mock_open

    mod_path = sys.modules[__name__]


# Generated at 2022-06-23 18:30:36.510196
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('foo', 'Foo', 'Do foo', ('bar.exe',))
    assert cfg.name == 'foo'
    assert cfg.camel == 'Foo'
    assert cfg.description == 'Do foo'
    assert cfg.commands == ('bar.exe',)

# Generated at 2022-06-23 18:30:37.253419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:30:41.308382
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert actual.name == 'name'
    assert actual.camel == 'camel'
    assert actual.description == 'description'
    assert actual.commands == ('commands',)

# Generated at 2022-06-23 18:30:45.730092
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test_class = SetupCfgCommandConfig(
        name='test.name',
        camel='testCamel',
        description='test.description',
        commands='test.commands'
    )
    assert test_class.name == 'test.name'
    assert test_class.camel == 'testCamel'
    assert test_class.description == 'test.description'
    assert test_class.commands == 'test.commands'



# Generated at 2022-06-23 18:30:57.185202
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from textwrap import dedent

    cur_dir = path.realpath(path.dirname(__file__))
    test_dir = path.abspath(path.join(cur_dir, '..'))
    test_cfg = path.join(test_dir, 'setup.cfg')

# Generated at 2022-06-23 18:31:09.161152
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "flutils"
    camel = "FlUtils"
    desc = "A package of useful functions and objects."
    commands = ' '.join(("python -m flutils",
                         "python -m flutils.__main__",
                         "python -m flutils.strutils.strutils",
                         "python3 -m flutils",
                         "python3 -m flutils.__main__",
                         "python3 -m flutils.strutils.strutils"))
    commands = commands.split()
    command_config = SetupCfgCommandConfig(name, camel, desc, commands)
    assert command_config.name == name
    assert command_config.camel == camel
    assert command_config.description == desc
    for command in command_config.commands:
        assert command in commands


# Generated at 2022-06-23 18:31:15.654151
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import pprint

    fmt_str = '''
    [setup.command.{command_name}]
    name = {name}
    description = {description}
    commands = {commands}
    '''

    setup_dir = tempfile.mkdtemp()
    setup_file = os.path.join(setup_dir, 'setup.py')
    setup_cfg_file = os.path.join(setup_dir, 'setup.cfg')
    setup_commands_file = os.path.join(setup_dir, 'setup_commands.cfg')

    os.mknod(setup_file)
    open(setup_cfg_file, 'w').close()
    open(setup_commands_file, 'w').close()

    setup_cfg = Config

# Generated at 2022-06-23 18:31:24.900472
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'This is a description.'
    commands = ('cat', 'test')
    setup_Cfg_Command_Config = SetupCfgCommandConfig(name, camel, description, commands)
    assert setup_Cfg_Command_Config.name == 'test_name'
    assert setup_Cfg_CommandConfig.camel == 'TestName'
    assert setup_Cfg_CommandConfig.description == 'This is a description.'
    assert setup_Cfg_CommandConfig.commands == ('cat', 'test')

# Generated at 2022-06-23 18:31:27.778636
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert isinstance(command, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:31:39.576130
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    p = os.path.dirname(__file__)
    p = os.path.dirname(p)
    p = os.path.dirname(p)
    p = os.path.dirname(p)
    p = os.path.join(p, 'tests', 'test_each_sub_command_config')
    for config in each_sub_command_config(p):
        print(config.commands)
    # ('flutils.tests.test_each_sub_command_config.func_a foo a',)
    # ('flutils.tests.test_each_sub_command_config.func_a bar a',)
    # ('flutils.tests.test_each_sub_command_config.func_a bar b',)
    # ('flutils.tests.test_each_sub_command_config

# Generated at 2022-06-23 18:31:44.731589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test():
        import os
        os.environ['HOME'] = os.environ['USERPROFILE'] = os.environ['TEMP']
        os.environ['TMP'] = os.environ['APPDATA'] = os.environ['TEMP']
        for cfg in each_sub_command_config():
            print(cfg)

    _test()

# Generated at 2022-06-23 18:31:49.935402
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig == SetupCfgCommandConfig(
        'setup.command.name',
        'SetupCommandName',
        'SetupCommandName is a setup command from setup.cfg.',
        ('cd {setup_dir} && python setup.py --setup-command-name',)
    )

# Generated at 2022-06-23 18:31:56.411208
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
    except FileNotFoundError:
        print('----')
        print('Unit test for the each_sub_command_config function FAILED.')
        print('----')
        raise
    print('Unit test for the each_sub_command_config function PASSED.')

if __name__ == '__main__':
    test_each_sub_command_config()

# Local Variables:
# compile-command: "python -m pytest -v test_setupcfg.py"
# End:

# Generated at 2022-06-23 18:32:06.028244
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import mkdir
    from os.path import dirname, join
    from pickle import loads, dumps
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from typing import List, Tuple, cast

    from flutils.pyutils import (
        check_type,
        get_func_default,
        get_func_default_name,
        get_func_full_name,
        get_func_name,
        get_func_source_code,
    )
    from flutils.setuputils import (
        SetupCfgCommandConfig, decode, encode,
    )

    source_code = get_func_source_code(each_sub_command_config)
    # print(source_code)
    source_code = source_code.replace('setup_dir', 'setup_dir_arg')


# Generated at 2022-06-23 18:32:17.533287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd_names = ['command1', 'command2']
    cmd_desc = ['Command 1', 'Command 2']
    config = '''\
[metadata]
name = test

[setup.command.command1]
command = echo {name} {setup_dir} {home}
description = {desc}

[setup.command.command2]
commands =
    echo {name} {setup_dir} {home}
    echo {name} {setup_dir} {home}
description = {desc}
    '''
    # Create a config file
    with tempfile.TemporaryDirectory() as dirpath:
        dirpath = str(dirpath)
        setup_py = os.path.join(dirpath, 'setup.py')
        with open(setup_py, 'w') as f:
            f.write('pass')

# Generated at 2022-06-23 18:32:23.526126
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=no-self-use
    test_cfg = """
[metadata]
name = foo-bar

[setup.command.foo]
command =
    {setup_dir}/baz.py --bam

[setup.command.bar]
commands =
    {setup_dir}/baz.py --bam
    {home}/bam.py --foo
"""
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.mkdir(os.path.join(tmp_dir, 'foo_bar'))
        setup_py_path = os.path.join(tmp_dir, 'foo_bar', 'setup.py')
        with open(setup_py_path, 'w') as outfile:
            outfile.write('#')
        setup_cfg_path

# Generated at 2022-06-23 18:32:29.023029
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command', )
    )

    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command', )

# Generated at 2022-06-23 18:32:33.362435
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=('test',)
    )
    assert hasattr(config, 'name')
    assert hasattr(config, 'camel')
    assert hasattr(config, 'description')
    assert hasattr(config, 'commands')



# Generated at 2022-06-23 18:32:35.019899
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-23 18:32:43.861667
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setup_commands

    def _assert_tuple(
            tup: Tuple[str, str, str, Tuple[str, ...]]
    ) -> None:
        assert isinstance(tup, tuple)
        assert len(tup) == 4
        assert isinstance(tup[0], str)
        assert tup[0]
        # assert kind of class nam
        assert isinstance(tup[1], str)
        assert tup[1]
        assert isinstance(tup[2], str)
        assert tup[2]
        assert isinstance(tup[3], tuple)
        assert len(tup[3]) >= 1
        for i in tup[3]:
            assert isinstance(i, str)
            assert i

# Generated at 2022-06-23 18:32:51.390069
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    field_names = [
        'name',
        'camel',
        'description',
        'commands',
    ]
    fields = [
        'ABC',
        'Abc',
        'HI',
        ('foo',)
    ]
    sccc = SetupCfgCommandConfig(*fields)
    assert list(sccc._fields) == field_names
    assert sccc.name == 'ABC'
    assert sccc.camel == 'Abc'
    assert sccc.description == 'HI'
    assert sccc.commands == ('foo',)

# Generated at 2022-06-23 18:33:01.310641
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    results = []
    for config in each_sub_command_config('./tests/testdata/subcmd_test_pkg'):
        results.append(config)

    assert len(results) == 1
    assert results[0] == SetupCfgCommandConfig(
        'subcmd.subsubcmd',
        'Subsubcmd',
        'This is a subcommand',
        ('echo "subsubcmd"',),
    )

    results.clear()
    for config in each_sub_command_config('./tests/testdata/subcmd_test_pkg2'):
        results.append(config)

    assert len(results) == 2

# Generated at 2022-06-23 18:33:10.565386
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    format_kwargs = {
        'setup_dir': '/Users/thebest/xlib',
        'home': os.path.expanduser('~')
    }
    name = _get_name(parser, 'setup.cfg')
    format_kwargs['name'] = name
    for command in _each_setup_cfg_command(parser, format_kwargs):
        print(command)


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:33:14.566012
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name', 'CamelName', 'description', ('command',)
    ) == (
        'name',
        'CamelName',
        'description',
        ('command',)
    )

# Generated at 2022-06-23 18:33:15.836865
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    each_sub_command_config()

# Generated at 2022-06-23 18:33:24.501412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    print('setup_dir: %s' % setup_dir)
    print()
    for sc in each_sub_command_config(setup_dir):
        print('name: %s' % sc.name)
        print('camel: %s' % sc.camel)
        print('description: %s' % sc.description)
        print('commands: %s' % sc.commands)
        print()
    return


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:33.901503
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo', 'Foo', '', ()).name == 'foo'
    assert SetupCfgCommandConfig('', 'Foo', '', ()).camel == 'Foo'
    assert SetupCfgCommandConfig('', '', '', ()).description == ''
    assert SetupCfgCommandConfig('', '', '', ()).commands == ()
    assert SetupCfgCommandConfig('', '', '', ('foo',)).commands == ('foo',)
    assert SetupCfgCommandConfig('', '', '', ('foo', 'bar')).commands == ('foo', 'bar')

# Generated at 2022-06-23 18:33:41.276781
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfg_cg = SetupCfgCommandConfig(
        name="a.b",
        camel="AB",
        description="test description",
        commands=("test_command", "testing")
    )
    assert scfg_cg.name == "a.b"
    assert scfg_cg.camel == "AB"
    assert scfg_cg.description == "test description"
    assert scfg_cg.commands == ("test_command", "testing")


# Generated at 2022-06-23 18:33:46.218516
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # type: () -> None
    try:
        SetupCfgCommandConfig(
            name='hi',
            camel='hi',
            description='hi',
            commands=()
        )
    except Exception as e:
        raise AssertionError(
            'Failed to create instance of SetupCfgCommandConfig: %s'
            % e
        )



# Generated at 2022-06-23 18:33:51.107027
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    data = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('command', )
    )
    assert data.name == 'name'
    assert data.camel == 'Camel'
    assert data.description == 'description'
    assert data.commands == ('command', )



# Generated at 2022-06-23 18:34:01.065288
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def t(
            root: Union[os.PathLike, str],
            exp_name: str,
            exp_commands: List[Tuple[str, str, str, List[str]]]
    ):
        res = list(each_sub_command_config(root))
        assert exp_name == res[0].name
        for i, _ in enumerate(res):
            assert exp_commands[i] == (
                res[i].name,
                res[i].camel,
                res[i].description,
                res[i].commands
            )

    b = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    d = os.path.join(b, 'test', 'data', 'gather_commands')


# Generated at 2022-06-23 18:34:05.639573
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig()
    except TypeError as err:
        assert f'{err}' == "__new__() missing 4 required positional arguments: 'name', 'camel', 'description', and 'commands'"
        return
    assert False


# Generated at 2022-06-23 18:34:11.228354
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'test',
        'Test',
        'test desc',
        ('echo test',)
    )
    assert cfg.name == 'test'
    assert cfg.camel == 'Test'
    assert cfg.description == 'test desc'
    assert cfg.commands == ('echo test',)


if __name__ == '__main__':
    for cfg in each_sub_command_config():
        print(cfg)

# Generated at 2022-06-23 18:34:19.550539
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    from textwrap import dedent
    config = dedent(
        """
        [metadata]
        description = test description
        name = test_name
        
        [setup.command.test]
        description = Test description
        command = Test command
        """
    )
    parser = ConfigParser()
    parser.read_string(config)
    format_kwargs = {
        'name': _get_name(parser, '/dev/null'),
        'setup_dir': '~',
        'home': os.path.expanduser('~')
    }
    name, camel, desc, cmds = next(_each_setup_cfg_command(parser, format_kwargs))
    setup_cfg_command_config = SetupCfgCommandConfig(name, camel, desc, cmds)
    assert setup_cfg_

# Generated at 2022-06-23 18:34:26.526207
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Test command',
        commands=('echo test',)
    )
    assert test.name == 'test'
    assert test.camel == 'Test'
    assert test.description == 'Test command'
    assert test.commands[0] == 'echo test'
    assert test == test
    assert test != 3



# Generated at 2022-06-23 18:34:28.419801
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('foo', 'Foo', 'This is the Foo command.', ('foo',))



# Generated at 2022-06-23 18:34:34.026836
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test1 = SetupCfgCommandConfig(
        name='test1', camel='Test1', description='test1', commands=('test1',)
    )
    assert test1.name == 'test1'
    assert test1.camel == 'Test1'
    assert test1.description == 'test1'
    assert test1.commands == ('test1',)

# Generated at 2022-06-23 18:34:39.995183
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="Test",
        camel="Test",
        description="This is the Test class.",
        commands=("",)
    )
    assert config.name == "Test"
    assert config.camel == "Test"
    assert config.description == "This is the Test class."
    assert config.commands == ("",)

# Generated at 2022-06-23 18:34:42.058215
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config('/tmp/setup_dir'):
        pass



# Generated at 2022-06-23 18:34:49.786139
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'pypi-check',
        'pypiCheck',
        'Runs the flutils pypi-checker command.',
        ('flutils pypi-checker',)
    )
    assert config.name == 'pypi-check'
    assert config.camel == 'pypiCheck'
    assert config.description == 'Runs the flutils pypi-checker command.'
    assert config.commands == ('flutils pypi-checker',)

# Generated at 2022-06-23 18:34:53.315107
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name='', camel='', commands=(), description='')
    assert config.name == ''
    assert config.camel == ''
    assert config.commands == ()
    assert config.description == ''



# Generated at 2022-06-23 18:35:01.355768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function, each_sub_command_config.
    """
    this_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(this_dir, 'resources/project_dir')

    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        camel_n = config.camel.replace('_', '')
        assert config.name.lower() == camel_n.lower()

# Generated at 2022-06-23 18:35:10.755050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _get_setup_dir() -> str:
        """Get the directory location of the unit test."""
        this_dir = os.path.dirname(__file__)
        return os.path.join(this_dir, 'setup_command_config')


# Generated at 2022-06-23 18:35:22.327442
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs: List[SetupCfgCommandConfig] = []
    for config in each_sub_command_config(setup_dir=os.path.dirname(__file__)):
        configs.append(config)
    assert configs[0].name == 'my-package.echo'
    assert configs[0].camel == 'MyPackageEcho'
    assert configs[0].description == 'Echo a message.'
    assert configs[0].commands == (
        'echo ECHOING: {{message}}',
    )
    assert configs[1].name == 'my-package.echo.foo'
    assert configs[1].camel == 'MyPackageEchoFoo'
    assert configs[1].description == 'Echo a message with foo.'

# Generated at 2022-06-23 18:35:32.055689
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock
    from flutils.configutils import (
        validate_setup_dir as _validate_setup_dir,
        prep_setup_dir as _prep_setup_dir
    )
    setup_dir = '/path/to/setup.dir'

    # Test with valid settings
    _validate_setup_dir = Mock(autospec=True)
    _validate_setup_dir.side_effect = _validate_setup_dir
    _prep_setup_dir = Mock(autospec=True)
    _prep_setup_dir.side_effect = (_prep_setup_dir, setup_dir)
    _get_name = Mock(autospec=True)
    _get_name.side_effect = _get_name

# Generated at 2022-06-23 18:35:42.555674
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig(
        'extra_command',
        'ExtraCommand',
        'This is the extra command.',
        ('command 1', 'command 2')
    )
    expected = \
        "SetupCfgCommandConfig(" \
        "name='extra_command', " \
        "camel='ExtraCommand', " \
        "description='This is the extra command.', " \
        "commands=('command 1', 'command 2')" \
        ")"
    assert str(test) == expected
    expected = \
        "SetupCfgCommandConfig(" \
        "name='extra_command', " \
        "camel='ExtraCommand', " \
        "description='This is the extra command.', " \
        "commands=('command 1', 'command 2')" \
        ")"

# Generated at 2022-06-23 18:35:53.506569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils import (
        strutils,
    )
    from flutils.pathutils import (
        each_ancestor,
    )

    for dir_path in each_ancestor(__file__, max_levels=4):
        for dir_path, subdirs, filenames in os.walk(dir_path):
            for filename in filenames:
                if filename == 'setup.cfg':
                    format_kwargs = {
                        'setup_dir': dir_path,
                        'home': os.path.expanduser('~')
                    }
                    setup_cfg_path = os.path.join(format_kwargs['setup_dir'],
                                                  'setup.cfg')
                    parser = ConfigParser()
                    parser.read(setup_cfg_path)

# Generated at 2022-06-23 18:36:03.016345
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(path, 'tests', 'resources', 'setup')
    setup_dir = os.path.abspath(path)
    count = 0
    for config in each_sub_command_config(setup_dir):
        print("config:", config)
        count += 1
        expected_name = 'fss.pyproject.file-shell-scripts'
        if config.name != expected_name:
            raise ValueError("'name' %r is NOT %r" % (config.name, expected_name))
    if count != 4:
        raise ValueError("'count' %r is NOT 4" % count)

# Generated at 2022-06-23 18:36:14.340689
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _each_sub_command_config = each_sub_command_config
    try:
        import tests
        _each_sub_command_config = tests.subcommand.each_sub_command_config
    except ImportError:
        pass
    for command in _each_sub_command_config():
        assert isinstance(command.name, str)
        assert isinstance(command.camel, str)
        assert isinstance(command.description, str)
        assert isinstance(command.commands, tuple)


if __name__ == '__main__':
    this_file = os.path.abspath(__file__)
    setup_dir = os.path.dirname(this_file)
    for command in each_sub_command_config(setup_dir=setup_dir):
        print("%r" % command)

# Generated at 2022-06-23 18:36:17.795813
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test', 'Test', 'test', ('test', ))
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('test', )



# Generated at 2022-06-23 18:36:25.145178
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from unittest import TestCase
    import sys

    here = os.path.abspath(os.path.dirname(__file__))
    setup_cfg = os.path.join(here, 'setup.cfg')
    setup_commands_cfg = os.path.join(here, 'setup_commands.cfg')

    class TestFunc(TestCase):
        def test_none(self):
            self.assertRaises(FileNotFoundError, each_sub_command_config)

        def test_file_not_found(self):
            expected = str(FileNotFoundError(
                "The given 'setup_dir' of %r does NOT exist."
                % here
            ))
            with self.assertRaises(FileNotFoundError) as exc:
                each_sub_command_

# Generated at 2022-06-23 18:36:28.103913
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test',
        'Test',
        'A test command.',
        ('echo test',)
    ) is not None

# Generated at 2022-06-23 18:36:37.961932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import capture_stdout
    with capture_stdout() as cs:
        for config in each_sub_command_config():
            if config.name == 'export_git':
                break

    assert config.name == 'export_git'
    assert len(config.commands) == 3
    assert config.commands[0] == 'git archive --prefix="Hello_World/"' \
                                 ' --format=tar HEAD | gzip > ' \
                                 'dist/Hello_World-1.0.0.tar.gz'
    assert config.description == 'Creates a GIT archive.'



# Generated at 2022-06-23 18:36:42.860816
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'flutils.scripts.setup'
    description = 'Runs the "setup.py" file.'
    commands = ('python setup.py {arguments}',)
    cfg = SetupCfgCommandConfig(name, description, commands)
    assert cfg.name == name
    assert cfg.description == description
    assert cfg.commands == commands
    assert cfg.camel == 'Setup'

# Generated at 2022-06-23 18:36:49.699721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    abs_path = os.path.abspath(__file__)
    flutils_path = os.path.dirname(os.path.dirname(abs_path))
    setup_dir = os.path.join(flutils_path, 'flutils')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-23 18:37:01.907301
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pathlib import Path
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class TestSetupCfgCommandConfig(TestCase):
        @staticmethod
        def _make_setup_cfg(content: str):
            content += "\n[metadata]\nname = MyProject"
            content = content.lstrip()
            return content

        def _test(self, *, content: str, expected_results: tuple):
            with TemporaryDirectory() as temp_dir:
                temp_dir = Path(temp_dir)
                setup_cfg_path = temp_dir / 'setup.cfg'
                with setup_cfg_path.open('w') as fh:
                    fh.write(content)
                setup_dir = str(temp_dir)