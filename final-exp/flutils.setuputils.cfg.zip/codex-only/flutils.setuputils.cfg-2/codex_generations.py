

# Generated at 2022-06-23 18:27:00.704968
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cm = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command',)
    )
    assert cm.name == 'name'
    assert cm.camel == 'camel'
    assert cm.description == 'description'
    assert cm.commands == ('command',)

# Generated at 2022-06-23 18:27:05.225120
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'one', 'One', 'command one', ('one', )
    )
    assert command.name == 'one'
    assert command.camel == 'One'
    assert command.description == 'command one'
    assert command.commands == ('one', )


# Generated at 2022-06-23 18:27:17.427634
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='command description',
        commands=('command',)
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'command description'
    assert config.commands == ('command',)
    assert len(config) == 4
    assert repr(config) == (
        "SetupCfgCommandConfig("
        "name='name', "
        "camel='Camel', "
        "description='command description', "
        "commands=('command',)"
        ")"
    )

# Generated at 2022-06-23 18:27:28.934949
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_ = os.path.dirname(__file__)
    dir_ = os.path.join(dir_, 'data', 'setup_commands')
    dir_ = os.path.realpath(dir_)
    setup_dir = os.path.join(dir_, 'flutils_utils')
    setup_dir = os.path.realpath(setup_dir)
    actual = []
    for cfg in each_sub_command_config(setup_dir):
        actual.append(cfg)
    actual = tuple(actual)


# Generated at 2022-06-23 18:27:40.672258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap

    setup_dir = tempfile.TemporaryDirectory()
    setup_dir_path = setup_dir.name
    setup_dir.cleanup()

# Generated at 2022-06-23 18:27:47.415098
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('/tmp/pytest-of-ben/pytest-0/foo'):
        assert config.name == 'foo.command'
        assert config.camel == 'FooCommand'
        assert config.description == 'My description in my config file.'
        assert config.commands == ('echo "Hello world!"', 'echo $HOME')
        return
    assert False

# Generated at 2022-06-23 18:27:56.624041
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Make sure SetupCfgCommandConfig class is hashable
    t1 = SetupCfgCommandConfig(
        'pip install -e',
        'PipInstallE',
        'Installs the project in editable mode.',
        ('pip install -e',)
    )
    t2 = SetupCfgCommandConfig(
        'pip install -e',
        'PipInstallE',
        'Installs the project in editable mode.',
        ('pip install -e',)
    )
    lst = [t1, t2]
    lst.count(t1)
    set(lst)
    # Make sure class is pickle-able
    import pickle
    pickle.dumps(t1)

# Generated at 2022-06-23 18:28:07.471849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test function."""
    configs = tuple(each_sub_command_config())
    assert configs
    assert len(configs) == 7
    assert configs[0].name == 'build'
    assert configs[0].camel == 'Build'
    assert configs[0].commands == ('pip install -e .', )
    assert configs[1].name == 'install.local'
    assert configs[1].camel == 'InstallLocal'
    assert configs[1].commands == ('pip install -e .', )
    assert configs[2].name == 'install.user'
    assert configs[2].camel == 'InstallUser'
    assert configs[2].commands == ('pip install -e . --user', )

# Generated at 2022-06-23 18:28:15.462203
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with pytest.raises(FileNotFoundError):
        for _ in each_sub_command_config():
            pass

    with pytest.raises(NotADirectoryError):
        for _ in each_sub_command_config('/path/to/nowhere'):
            pass

    here = os.path.dirname(__file__)
    setup_dir = os.path.join(here, 'test_files', 'setup.py')
    yielded = False
    for _ in each_sub_command_config(setup_dir):
        yielded = True
    assert yielded is True

    os.chdir(here)
    yielded = False
    for _ in each_sub_command_config():
        yielded = True
    assert yielded is True
    os.chdir('..')

# Generated at 2022-06-23 18:28:26.988792
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from attr import asdict
    from typing import Set
    from unittest.mock import patch
    from io import StringIO
    import tempfile

    cmds = (
        'echo "{name}"',
        'echo "Testing {name}"',
    )
    txt = '''
[setup.command.{cmd}]
description = {description}
commands =
{commands}
'''.format(
        cmd='echo',
        description='Test the command.',
        commands='\n'.join(cmds),
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'w', encoding='utf-8') as fp:
            fp.write(txt)

# Generated at 2022-06-23 18:28:35.052044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    from os.path import dirname

    from sys import _getframe
    from sys import getrefcount

    from flutils.pyutils import add_bool_arg
    from flutils.pyutils import import_from_string

    from flutils.cfgutils import _each_setup_cfg_command
    from flutils.cfgutils import _get_name
    from flutils.cfgutils import SetupCfgCommandConfig

    test_dir = dirname(_getframe(0).f_code.co_filename)
    test_dir = os.path.abspath(test_dir)

    subdir_path = os.path.join(test_dir, 'subdir')
    setup_py_path = os.path.join(subdir_path, 'setup.py')
    setup

# Generated at 2022-06-23 18:28:39.082612
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'dependency_tree',
        'DependencyTree',
        'The output of pipenv graph.',
        ('pipenv graph',)
    )
    assert config.name == 'dependency_tree'
    assert config.camel == 'DependencyTree'
    assert config.description == 'The output of pipenv graph.'
    assert config.commands == ('pipenv graph',)



# Generated at 2022-06-23 18:28:42.928721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    def _test(setup_dir: Optional[Union[os.PathLike, str]] = None) -> None:
        pprint(list(each_sub_command_config(setup_dir)))

    _test(r'..')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:50.143623
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    install_reqs = []
    for config in each_sub_command_config():
        camel = config.camel
        desc = config.description
        if camel.startswith('Install'):
            install_reqs.append(desc)
    assert sorted(install_reqs) == [
        'Install all development requirements.',
        'Install all minimum requirements.',
        'Install all test requirements.',
        'Upgrade all outdated requirements.',
    ]

# Generated at 2022-06-23 18:28:55.910192
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foo'
    camel = 'Foo'
    description = 'Foo description'
    commands = ('command1', 'command2')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:29:03.222666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import (
        TEST_CODE_DIR,
        TEST_HOME_DIR,
        TEST_ROOT,
    )
    format_kwargs = {
        'setup_dir': TEST_ROOT,
        'home': TEST_HOME_DIR
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)


# Generated at 2022-06-23 18:29:09.509159
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
            name='foo_bar',
            camel='FooBar',
            description='foo bar',
            commands=('lint', 'test', )
    )

    assert config.name == 'foo_bar'
    assert config.camel == 'FooBar'
    assert config.description == 'foo bar'
    assert config.commands == ('lint', 'test' )

# Generated at 2022-06-23 18:29:11.789231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with EnvironFixture(HOME='/home/test_user'):
        out_list = list(each_sub_command_config())
        assert out_list
        # print(out_list)

# Generated at 2022-06-23 18:29:12.955135
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass


# Generated at 2022-06-23 18:29:15.785433
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'Test command'
    commands = ('echo "hello"', 'cd', 'pwd')
    config = SetupCfgCommandConfig(
        name,
        camel,
        description,
        commands,
    )
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:29:17.396389
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        _ = config.name, config.camel, config.description, config.commands
        assert True


# Command line interface

# Generated at 2022-06-23 18:29:20.332488
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands = list(each_sub_command_config(os.path.dirname(__file__)))
    assert len(commands) == 3



# Generated at 2022-06-23 18:29:26.629886
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command',)
    )
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('command',)



# Generated at 2022-06-23 18:29:31.975286
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('foo', 'Foo', 'Foo', ('bar', ))
    assert obj.name == 'foo'
    assert obj.camel == 'Foo'
    assert obj.description == 'Foo'
    assert obj.commands == ('bar', )


# Generated at 2022-06-23 18:29:36.899708
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    item = SetupCfgCommandConfig('name', 'camel', 'description', ('1', '2'))
    assert item.name == 'name'
    assert item.camel == 'camel'
    assert item.description == 'description'
    assert item.commands == ('1', '2')



# Generated at 2022-06-23 18:29:42.780921
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup_commands.cfg')
    functions = each_sub_command_config()
    for function in functions:
        assert isinstance(function, SetupCfgCommandConfig)
        assert function.camel
        assert function.commands
        assert function.description
        assert function.name


# Generated at 2022-06-23 18:29:48.245297
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", "commands")
    assert isinstance(config, SetupCfgCommandConfig)
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)



# Generated at 2022-06-23 18:29:55.622382
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='unittest_name',
        camel='UnittestCamel',
        description='unittest description',
        commands=('unittest command', )
    )
    assert obj.name == 'unittest_name'
    assert obj.camel == 'UnittestCamel'
    assert obj.description == 'unittest description'
    assert obj.commands == ('unittest command', )

# Generated at 2022-06-23 18:30:05.284674
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path

    from flutils.pyutils import get_caller_file_dir

    cur_dir = get_caller_file_dir(1)
    exp_dir = os.path.dirname(cur_dir)
    exp_dir = Path(exp_dir).joinpath('tests', 'files', 'test_setup_cfg')

    setup_dirs = [exp_dir, None]

# Generated at 2022-06-23 18:30:11.807138
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = next(each_sub_command_config(setup_dir='../flutils'))
    assert result.name == 'update-authors'
    assert result.camel == 'UpdateAuthors'
    assert result.description == 'Updates the AUTHORS.md file with new ' \
                                 'contributors.'
    result = next(each_sub_command_config(setup_dir='../flutils'))
    assert result.name == 'update-setup-cfg'
    assert result.camel == 'UpdateSetupCfg'
    assert result.description == 'Updates the setup.cfg file based on the ' \
                                 'files in the project.'
    result = next(each_sub_command_config(setup_dir='../flutils'))
    assert result.name == 'update-version'

# Generated at 2022-06-23 18:30:20.419877
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))
    assert command.name == 'name'
    assert command.camel == 'camel'
    assert command.description == 'description'
    assert command.commands == ('command1', 'command2')


if __name__ == '__main__':
    import sys
    try:
        for command in each_sub_command_config(sys.argv[1]):
            print(command)
    except FileNotFoundError as e:
        print('%s: %s' % (type(e).__name__, e))
        sys.exit(-1)

# Generated at 2022-06-23 18:30:31.758737
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from shutil import rmtree
    from tempfile import mkdtemp
    from pathlib import Path

    class EachSubCommandConfigTestCase(TestCase):
        def setUp(self) -> None:
            self.test_dir = str(Path(mkdtemp()) / 'test_dir')
            os.makedirs(self.test_dir, exist_ok=True)

        def test_default(self):
            test_file = os.path.join(self.test_dir, 'setup_commands.cfg')

# Generated at 2022-06-23 18:30:41.639511
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.objutils import iter_attr_names, sort_namedtuple_list
    from tests._test_utils import get_test_dir
    from tests.setup_commands import common as mod
    from tests.setup_commands.common import SetupCfgCommandConfigTest

    test_dir = get_test_dir(__file__)

    commands = list(each_sub_command_config(test_dir))
    assert 1 == len(commands)
    cmd = commands[0]
    assert cmd.camel == 'RunUnitTests'
    assert cmd.description == 'Run all unit tests.'
    assert ('pytest', ) == cmd.commands

    # Test _get_name()
    tmp = _get_name(mod._parser, mod._setup_cfg_path)

# Generated at 2022-06-23 18:30:48.929105
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'test_description'
    commands = ('test_commands',)
    scc = SetupCfgCommandConfig(name, camel, description, commands)
    assert scc.name == name
    assert scc.camel == camel
    assert scc.description == description
    assert scc.commands == commands



# Generated at 2022-06-23 18:30:54.042822
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
	print('\n*** TEST SetupCfgCommandConfig')

	args = ('name', 'camel', 'description', 'commands')
	obj = SetupCfgCommandConfig(*args)
	print(args)
	print(obj)
	print(obj.name)
	print(obj.camel)
	print(obj.description)
	print(obj.commands)
	assert obj.name == 'name'
	assert obj.camel == 'Camel'
	assert obj.description == 'description'
	assert obj.commands == ('commands',)


# Generated at 2022-06-23 18:31:01.491189
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = SetupCfgCommandConfig(
        'name',
        'Camel',
        'Description',
        ('commands',)
    )
    assert isinstance(section, NamedTuple)
    assert isinstance(section.name, str)
    assert isinstance(section.camel, str)
    assert isinstance(section.description, str)
    assert isinstance(section.commands, Tuple)
    assert section.name == 'name'
    assert section.camel == 'Camel'
    assert section.description == 'Description'
    assert section.commands == ('commands',)
    assert len(section) == 4



# Generated at 2022-06-23 18:31:12.349854
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    import flutils.setuputils as setuputils

    class TestSetuputils(unittest.TestCase):

        def test_each_sub_command_config(self):
            class TestCase(NamedTuple):
                name: str
                setup_cfg_contents: str
                expect: Tuple[SetupCfgCommandConfig, ...]


# Generated at 2022-06-23 18:31:24.637941
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_command_data_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_setup_commands.cfg'
    )
    parser = ConfigParser()
    parser.read(test_setup_command_data_path)
    format_kwargs = {
        'setup_dir': 'C:/temp',
        'home': os.path.expanduser('~'),
        'name': 'foobar'
    }
    for idx, setup_cfg_command_config in enumerate(_each_setup_cfg_command(parser, format_kwargs)):
        if idx == 0:
            assert (
                isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
            )

# Generated at 2022-06-23 18:31:32.321527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_dir = os.path.dirname(os.path.dirname(__file__))
    setup_dir = os.path.join(root_dir, 'tests', 'sub_command_config')
    setup_dir = os.path.realpath(setup_dir)
    out: List[SetupCfgCommandConfig] = []
    for item in each_sub_command_config(setup_dir):
        out.append(item)
    assert len(out) == 4
    assert out[0].name == out[0].camel == out[0].description == 'fake'
    assert out[1].name == 'foo'
    assert out[1].camel == 'Foo'
    assert out[1].description == 'Fake foo.'
    assert out[2].name == 'foo bar'
    assert out[2].c

# Generated at 2022-06-23 18:31:44.407213
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from .base import (
        cd,
        verify_is_parent_dir
    )
    from .write_setup_commands import (
        write_setup_commands
    )

    with cd(verify_is_parent_dir('flutils')):
        write_setup_commands()
        out = tuple(each_sub_command_config())
        assert len(out) > 0
        for config in out:
            assert isinstance(config, SetupCfgCommandConfig)
            for attr_name in (
                    'name',
                    'camel',
                    'description',
                    'commands'
            ):
                assert hasattr(config, attr_name)
        path = os.path.join('setup_commands.cfg')
        assert os.path.isfile(path)
    os

# Generated at 2022-06-23 18:31:49.986071
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'd', ('c',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'd'
    assert config.commands == ('c',)

# Unit tests for function each_sub_command_config

# Generated at 2022-06-23 18:31:53.131570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        list(each_sub_command_config())
    except Exception as e:
        raise Exception(
            "Failed to generate the list of sub command config info for "
            "the package."
        ) from e

# Generated at 2022-06-23 18:32:00.429378
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each_setup_cfg_command_section(parser: ConfigParser):
        ...

    def _each_setup_cfg_command(parser: ConfigParser, format_kwargs: Dict[str, str]):
        ...

    def _get_name(parser: ConfigParser, setup_cfg_path: str) -> str:
        return 'unittest'

    def _validate_setup_dir(setup_dir: str) -> None:
        ...

    def _prep_setup_dir(setup_dir: Optional[Union[os.PathLike, str]] = None) -> str:
        return os.path.dirname(os.path.realpath(__file__))

    _each_setup_cfg_command_section_orig = each_sub_command_config._each_setup_cfg_command_section
    _each_setup

# Generated at 2022-06-23 18:32:04.761039
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test1 = SetupCfgCommandConfig(
        'test1',
        'Test1',
        'description',
        ('cmd1', 'cmd2')
    )
    assert test1.name == 'test1'
    assert test1.camel == 'Test1'
    assert test1.description == 'description'
    assert test1.commands == ('cmd1', 'cmd2')
    assert test1 == test1
    assert test1 != '.'
    assert test1
    assert test1 == SetupCfgCommandConfig(
        'test1',
        'Test1',
        'description',
        ('cmd1', 'cmd2')
    )

# Generated at 2022-06-23 18:32:16.259170
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from test.context import (
        SetupCfgCommandConfig
    )
    import os
    import sys

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    setup_cfg_comm_tuple = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test description',
        commands=('/bin/sh',)
    )
    assert setup_cfg_comm_tuple.name == 'test'
    assert setup_cfg_comm_tuple.camel == 'Test'
    assert setup_cfg_comm_tuple.description == 'test description'
    assert setup_cfg_comm_tuple.commands == ('/bin/sh',)

# Generated at 2022-06-23 18:32:23.232505
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_dir = os.path.dirname(__file__)
    base_dir = os.path.dirname(base_dir)
    base_dir = os.path.dirname(base_dir)
    setup_dir = os.path.join(base_dir, 'fltest')
    for sub_cmd_config in each_sub_command_config(setup_dir):
        print(sub_cmd_config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:32:35.523765
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile
    import shutil

    class EachSubCommandConfig(unittest.TestCase):
        def setUp(self) -> None:
            self.setup_dir = tempfile.mkdtemp(prefix='each_sub_command_config')
            os.mkdir(os.path.join(self.setup_dir, 'doc'))
            os.mkdir(os.path.join(self.setup_dir, 'example'))
            setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(setup_py_path, 'w') as outfile:
                outfile.write("#!/usr/bin/env python\npass\n")

# Generated at 2022-06-23 18:32:44.040151
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import random
    from flutils.setuputils import each_sub_command_config

    cb = lambda c: print(c, end='\n\n')
    try:
        each_sub_command_config()
    except FileNotFoundError:
        pass
    else:
        assert 1 == 0

    setup_cfg_path = None
    setup_py_path = None
    setup_commands_cfg_path = None

# Generated at 2022-06-23 18:32:53.002945
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import (
        each_sub_command_config,
        SetupCfgCommandConfig
    )
    setup_dir = os.path.join(
        os.path.expanduser('~'), 'flutils', 'flutils'
    )
    configs = list(each_sub_command_config(setup_dir))

    assert isinstance(configs, list)
    assert len(configs) == 2
    assert isinstance(configs, list)
    assert isinstance(configs[0], SetupCfgCommandConfig)
    assert configs[0].name == 'build_code'
    assert isinstance(configs[1], SetupCfgCommandConfig)
    assert configs[1].name == 'docs'

# Generated at 2022-06-23 18:32:57.716863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = list(each_sub_command_config())
    assert (len(config) == 1)
    config = config[0]
    assert (config.name == 'twine-upload')
    assert (config.camel == 'TwineUpload')
    assert (config.description == '')
    assert ('twine' in config.commands)

# Generated at 2022-06-23 18:33:01.583190
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scc = SetupCfgCommandConfig('test', 'Test', 'Description', ('ls'))
    assert scc.name == 'test'
    assert scc.camel == 'Test'
    assert scc.description == 'Description'
    assert scc.commands == ('ls',)

# Generated at 2022-06-23 18:33:08.862020
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        assert SetupCfgCommandConfig(
            name='sphinx.build',
            camel='SphinxBuild',
            description='Build the Sphinx documentation.',
            commands=('sphinx-build . .build/sphinx',
                      'sphinx-build . .build/sphinx-doc',),
        )
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-23 18:33:12.958162
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = os.path.dirname(__file__)
    for cfg in each_sub_command_config(setup_dir):
        assert cfg.name
        assert cfg.camel
        assert cfg.description
        assert cfg.commands

# Generated at 2022-06-23 18:33:14.729475
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        list(each_sub_command_config())
    except LookupError:  # noqa
        pass

# Generated at 2022-06-23 18:33:25.465147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_config in each_sub_command_config():
        if cmd_config.name == 'build_sphinx':
            assert cmd_config.commands == (
                '$python setup.py build_sphinx',
            )
            assert cmd_config.camel == 'BuildSphinx'
            assert cmd_config.description == 'Build documentation'
        elif cmd_config.name == 'release':
            assert cmd_config.commands == (
                '$python setup.py sdist',
                '$python setup.py bdist_wheel',
                '$python setup.py upload',
            )
            assert cmd_config.camel == 'Release'
            assert cmd_config.description == 'Make a new release'

# Generated at 2022-06-23 18:33:35.179403
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    cfg: SetupCfgCommandConfig
    with pytest.raises(FileNotFoundError, match='setup.py'):
        cfg = next(each_sub_command_config(setup_dir='foobar'))

    # with pytest.raises(FileNotFoundError, match='setup_commands.cfg'):
    #     cfg = next(each_sub_command_config())

    # cfg = next(each_sub_command_config('Tests/setup'))
    # print(cfg)
# test_each_sub_command_config()

# Generated at 2022-06-23 18:33:38.497680
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config('test_proj'):
        print(sub_command)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:42.248437
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig("name", "Camel", "Description", ["commands"])
    assert obj.name == "name"
    assert obj.camel == "Camel"
    assert obj.description == "Description"
    assert obj.commands == ("commands",)

# Generated at 2022-06-23 18:33:48.121549
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('cmd', 'cmd2')


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:33:53.087092
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    path = os.path.join(os.path.expanduser('~'), '.pypirc')
    assert SetupCfgCommandConfig(
        'check_pypi_config', 'CheckPyPiConfig',
        'Check the PyPI config file, %r.' % path,
        ('test -f %r' % path,)
    )

# Generated at 2022-06-23 18:33:58.956250
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the ``each_sub_command_config`` function."""

    import flutils.misc

    for cmd in each_sub_command_config(flutils.misc.__file__):
        print(cmd)
    for cmd in each_sub_command_config(flutils.misc.__file__):
        print(cmd)
    assert True


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:05.534717
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for command_cfg in each_sub_command_config():
        assert(isinstance(command_cfg.name, str))
        assert(isinstance(command_cfg.camel, str))
        assert(isinstance(command_cfg.description, str))
        assert(isinstance(command_cfg.commands, tuple))
        break
# End unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-23 18:34:15.099290
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            expected: Tuple[SetupCfgCommandConfig, ...],
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        actual = tuple(each_sub_command_config(setup_dir=setup_dir))
        assert actual == expected

    _test((), '/tmp/no-such-dir-asdf-123')
    _test((), '/tmp/no-such-file-asdf-123')
    _test((), '/tmp/a-file.txt')
    _test((), '/tmp/dir-with-bad-setup-cfg')

    # def _test(expected: Tuple[SetupCfgCommandConfig, ...],
    #           setup_dir: Optional[str] = None):
    #     actual = tuple(each_sub_command_config(setup

# Generated at 2022-06-23 18:34:21.713585
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'setup_cfg_project'
    )
    configs = tuple(
        SetupCfgCommandConfig(
            c.name, c.camel, c.description, c.commands
        ) for c in each_sub_command_config(setup_dir)
    )
    assert len(configs) == 4
    assert configs[0] == SetupCfgCommandConfig(
        'test_1',
        'Test_1',
        'Runs test_1 command.',
        ('echo test_1',)
    )

# Generated at 2022-06-23 18:34:29.867112
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fileutils import TemporaryDirectory
    from flutils.mockutils import cook_camel_case_name
    from flutils.sysutils import get_platform_name, get_python_version

    tmp_dir = TemporaryDirectory()
    os.chmod(tmp_dir.name, 0o700)
    os.chmod(os.path.join(tmp_dir.name, 'setup_commands.cfg'), 0o600)
    setup_dir = os.path.realpath(tmp_dir.name)

    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'flutils')


# Generated at 2022-06-23 18:34:41.554457
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    from io import StringIO
    from textwrap import dedent

    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()


# Generated at 2022-06-23 18:34:44.073143
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('flutils.test',
                          'Test',
                          'Test package.',
                          ('echo 1', 'echo 2'))



# Generated at 2022-06-23 18:34:48.729094
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    conf = SetupCfgCommandConfig('name','camel','description',('cmd1','cmd2'))
    assert conf.name == 'name'
    assert conf.camel == 'camel'
    assert conf.description == 'description'
    assert conf.commands == ('cmd1','cmd2')



# Generated at 2022-06-23 18:34:52.928652
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    _dir = os.path.dirname(__file__)
    _dir = os.path.join(_dir, '..', '..')
    pprint(list(each_sub_command_config(_dir)))

# Generated at 2022-06-23 18:35:04.079987
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    import warnings

    class Test(unittest.TestCase):
        def test(self):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')

                os.chdir(os.path.dirname(__file__))
                for sub_command in each_sub_command_config('.'):
                    sys.stdout.write(
                        "%s\t%s\t%s\t%s\n"
                        % (
                            sub_command.name,
                            sub_command.camel,
                            sub_command.description,
                            sub_command.commands,
                        )
                    )

                self.assertEqual(len(w), 0)


# Generated at 2022-06-23 18:35:13.332989
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    import sys
    path = os.path.join(os.path.dirname(__file__), '..', '..')
    sys.path.insert(0, path)
    with patch('sys.path', sys.path):
        import tests.tests

        with patch('tests.tests._each_setup_cfg_command') as mock:
            mock.return_value = iter([])

            setup_dir = os.path.dirname(tests.tests.__file__)
            command = next(each_sub_command_config(setup_dir))
            assert command.name == 'tests'
            assert command.camel == 'Tests'
            assert command.description == "Run the tests."
            assert command.commands == ('python3 -m unittest',)

# Generated at 2022-06-23 18:35:26.735101
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    assert _get_name(parser, 'setup.cfg') == 'flutils'
    format_kwargs: Dict[str, str] = {
        'setup_dir': _prep_setup_dir('.'),
        'home': os.path.expanduser('~'),
        'name': 'flutils'
    }

# Generated at 2022-06-23 18:35:27.825176
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _ = SetupCfgCommandConfig('', '', '', tuple())

# Generated at 2022-06-23 18:35:35.603983
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pytest

    # Test no setup.dir
    with pytest.raises(FileNotFoundError):
        each_sub_command_config()

    # Test with a setup.dir
    setup_dir = os.path.abspath(os.path.dirname(sys.executable))
    for config in each_sub_command_config(setup_dir):
        pass  # See if it runs without error

# Generated at 2022-06-23 18:35:41.245173
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj: SetupCfgCommandConfig = SetupCfgCommandConfig(
        'one', 'Two', 'description', ('one', 'two', 'three')
    )
    assert obj.name == 'one'
    assert obj.camel == 'Two'
    assert obj.description == 'description'
    commands: Tuple[str, ...] = ('one', 'two', 'three')
    assert obj.commands == commands



# Generated at 2022-06-23 18:35:46.851833
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # noqa: E800
    import sys
    cmds = list(each_sub_command_config())
    if len(sys.argv) > 1 and sys.argv[1] in ('-v', '--verbose', '--verbosity'):
        for cmd in cmds:
            print(cmd)
    assert cmds

# Generated at 2022-06-23 18:35:51.129819
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sub_cmd = SetupCfgCommandConfig('test_name', 'TestName', 'desc', ('a', 'b'))
    assert sub_cmd.name == 'test_name'
    assert sub_cmd.camel == 'TestName'
    assert sub_cmd.description == 'desc'
    assert sub_cmd.commands == ('a', 'b')



# Generated at 2022-06-23 18:35:58.940497
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = random_string(10)
    camel = upper_string(random_string(10))
    description = random_string(10)
    commands = (random_string(10), random_string(10))
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(config.name, str)
    assert config.name == name
    assert isinstance(config.camel, str)
    assert config.camel == camel
    assert isinstance(config.description, str)
    assert config.description == description
    assert isinstance(config.commands, tuple)
    assert config.commands == commands

# Generated at 2022-06-23 18:36:02.427829
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test', 'Test', 'test command', tuple()
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test command'
    assert config.commands == tuple()

# Generated at 2022-06-23 18:36:03.892796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config('/home/pi/Projects/flutils'):
        print(x)

# Generated at 2022-06-23 18:36:14.762827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.pyutils import clear_from_sys_modules

    with TempDir() as td:
        setup_dir = os.path.join(td, '.flutils')
        assert not os.path.exists(setup_dir)
        setup_dir = os.path.realpath(setup_dir)
        assert os.path.exists(setup_dir)
        assert os.path.isdir(setup_dir)
        td = os.path.realpath(td)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        setup_cfg_new_path = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-23 18:36:16.508256
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    root = os.path.dirname(__file__)
    for config in each_sub_command_config(root):
        pprint(config)

# Generated at 2022-06-23 18:36:20.363328
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='',
        commands=[]
    )
    assert sccc.name == 'name'
    assert sccc.camel == 'Camel'
    assert sccc.description == ''
    assert sccc.commands == ()

# Generated at 2022-06-23 18:36:25.888096
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        "cmd_name",
        "CamelCase",
        "description",
        ("cmd1", "cmd2")
    )

    assert config.name == "cmd_name"
    assert config.camel == "CamelCase"
    assert config.description == "description"
    assert config.commands == ("cmd1", "cmd2")

# Generated at 2022-06-23 18:36:38.068301
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    from unittest.mock import patch
    from . import (
        sub_command_maker,
        setup_cfg_command_config,
    )

    class EachSetupCfgCommandTest(unittest.TestCase):
        def setUp(self):
            self.parser = ConfigParser()
            self.format_kwargs = {
                'setup_dir': 'fake_setup_dir',
                'home': os.path.expanduser('~')
            }
            self.setup_cfg_path = 'fake_setup.cfg'

        def tearDown(self):
            self.parser = None
            self.format_kwargs = None
            self.setup_cfg_path = None


# Generated at 2022-06-23 18:36:42.934993
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig(
        'command', 'Command', 'This is a command.', ('echo', '1', '2', '3')
    )
    assert test.name == 'command'
    assert test.camel == 'Command'
    assert test.description == 'This is a command.'
    assert test.commands == ('echo', '1', '2', '3')



# Generated at 2022-06-23 18:36:54.536043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import shutil
    import tempfile
    import subprocess
    import flutils.pathutils as pathutils

    setup_cfg_file = """
[metadata]
name = flutils

[setup.command.command_with_description]
description = Run the unit tests for {name}.
command = {name} --version

[setup.command.command_with_description]
description = Run the unit tests for {name}.
command = {name} --version

[setup.command.command_with_description]
description = Run the unit tests for {name}.
command = {name} --version
    """


# Generated at 2022-06-23 18:37:04.799268
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    fmt_kwargs = {
        'name': 'test',
        'home': os.path.expanduser('~'),
        'setup_dir': '/Users/user/workspace/test',
    }
    parser = ConfigParser()
    parser.read('setup_commands.cfg')
    cmds = list(_each_setup_cfg_command(parser, fmt_kwargs))