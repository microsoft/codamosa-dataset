

# Generated at 2022-06-23 18:27:03.905254
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def create_test_sub_command_csv():
        sub_command_csv_path = '/tmp/sub_command.csv'
        if os.path.isfile(sub_command_csv_path):
            os.remove(sub_command_csv_path)

        with open(sub_command_csv_path, 'w') as fp:
            for sub_command_config in each_sub_command_config(
                    '/tmp/test_each_sub_command_config'
            ):
                fp.write(
                    ',"'.join([
                        sub_command_config.name,
                        sub_command_config.camel,
                        sub_command_config.description,
                        ';'.join(sub_command_config.commands)
                    ]) + '\n'
                )


# Generated at 2022-06-23 18:27:06.656176
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # test constructor
    SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))


# Unit tests for function each_sub_command_config

# Generated at 2022-06-23 18:27:19.107186
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        "Camel",
        'description',
        ('a', 'b', 'c')
    ) == SetupCfgCommandConfig(
        'name',
        "Camel",
        'description',
        ('a', 'b', 'c')
    )
    assert (
        SetupCfgCommandConfig(
            'name',
            "Camel",
            'description',
            ('a', 'b', 'c')
        ) != SetupCfgCommandConfig(
            'name2',
            "Camel",
            'description',
            ('a', 'b', 'c')
        )
    )

# Generated at 2022-06-23 18:27:19.728998
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:27:31.220097
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import Dict, Generator, Tuple
    from unittest.mock import Mock
    from unittest.mock import patch
    import os
    import sys

    import pytest

    from flutils.pathutils import relpath
    from flutils.tests._utils import patch_exists
    from flutils.tests._utils import patch_isfile
    from flutils.tests._utils import patch_isdir
    from flutils.tests._utils import patch_open

    here = os.path.dirname(__file__)
    setup_dir = os.path.dirname(here)
    assert setup_dir
    os.chdir(setup_dir)

    # -------------------------------------------------------------------
    # Test: each_sub_command_config
    # -------------------------------------------------------------------


# Generated at 2022-06-23 18:27:42.447521
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:27:44.356594
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('test_cmd', 'TestCmd', '', (''))

# Generated at 2022-06-23 18:27:51.103350
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    configs = list(each_sub_command_config(os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'support'
    )))
    assert configs[0] == SetupCfgCommandConfig(
        'tests.setup',
        'Setup',
        'Runs the script in the source directory to create an executable.',
        ('python setup.py build',)
    )

# Generated at 2022-06-23 18:28:02.185387
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory

    from flutils.pytestutils import (
        raises,
        raises_factory,
    )

    dirpath_factory = raises_factory(dirpath=True)
    FileNotFoundError_factory = raises_factory(FileNotFoundError)

    with TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        path = os.path.join(tmpdir, 'setup.py')
        with open(path, 'w') as fp:
            fp.write('')
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-23 18:28:08.220753
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import stderr
    from os import getcwd

    if not os.path.isfile('setup.py'):
        project_root = os.path.dirname(os.path.dirname(getcwd()))
    else:
        project_root = getcwd()

    for config in each_sub_command_config(project_root):
        print(config.name, file=stderr)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:18.539206
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(os.path.realpath(__file__))
    tests_dir = os.path.dirname(here)
    setup_dir = os.path.dirname(tests_dir)
    expected = [
        SetupCfgCommandConfig(
            name='test_dist',
            camel='TestDist',
            description='Install the project in-place for testing.',
            commands=('pip install -e .',),
        ),
        SetupCfgCommandConfig(
            name='test_dist',
            camel='TestDist',
            description='Install the project in-place for testing.',
            commands=('pip install -e .',),
        ),
    ]
    actual = list(each_sub_command_config(setup_dir))
    assert len(actual) == len(expected)
   

# Generated at 2022-06-23 18:28:26.988810
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test the constructor of class SetupCfgCommandConfig
    setup_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    for cmd in each_sub_command_config(setup_dir):
        if cmd.name == 'test.test':
            assert cmd.camel == 'Test'
            assert cmd.description == 'Test the commands.'
            assert cmd.commands == (
                'python -m unittest discover -v',
                'pytest -v'
            )
        else:
            raise RuntimeError(cmd.name)

# Generated at 2022-06-23 18:28:31.475080
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    this = SetupCfgCommandConfig('name', 'camel', 'descr', ('cmd1', 'cmd2'))
    assert this.name == 'name' and this.camel == 'camel'
    assert this.description == 'descr' and this.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:28:34.387172
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _ = SetupCfgCommandConfig(
        name = 'hello_world',
        camel = 'HelloWorld',
        description = 'hello',
        commands = ('echo "hello world";',)
    )

# Generated at 2022-06-23 18:28:43.580423
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.strings import truncate
    from flutils.console import (
        blue,
        cyan,
        green,
        red,
        yellow,
    )
    print('Testing the constructor of the class "SetupCfgCommandConfig":')
    for config in each_sub_command_config():
        print('... Config:')
        for attr, color in zip(
            (
                'name',
                'camel',
                'description',
                'commands'
            ), (
                cyan,
                blue,
                green,
                red,
            )
        ):
            print('... ... %s: %s' % (
                yellow(attr), color(getattr(config, attr))
            ))
    print('... Done.')



# Generated at 2022-06-23 18:28:49.589993
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command1', 'command2')
    )
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:29:00.880120
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testutils import capturestdout
    name = 'command.name'
    camel = 'SetupCommandName'
    description = 'Setup command description.'
    commands = ('command1', 'command2')
    x = SetupCfgCommandConfig(name, camel, description, commands)
    with capturestdout() as cs:
        print(x)
    assert cs.data == (
        "name=%r, camel=%r, description=%r, commands=%r"
        % (name, camel, description, commands)
    )
    assert str(x) == (
        "name=%r, camel=%r, description=%r, commands=%r"
        % (name, camel, description, commands)
    )

# Generated at 2022-06-23 18:29:08.353228
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    '''
    Unit test for constructor of class SetupCfgCommandConfig
    '''
    import argparse
    argparse.ArgumentParser()
    cmd = SetupCfgCommandConfig('abc', 'Abc', 'XYZ', ('ls', 'cd'))
    assert cmd.name == 'abc'
    assert cmd.camel == 'Abc'
    assert cmd.description == 'XYZ'
    assert cmd.commands == ('ls', 'cd')



# Generated at 2022-06-23 18:29:20.750869
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-23 18:29:25.970494
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test 1:
    info = SetupCfgCommandConfig(
        'test',
        'Test',
        'test',
        ('command',)
    )
    assert info.name == 'test'
    assert info.camel == 'Test'
    assert info.description == 'test'
    assert info.commands == ('command',)


# Generated at 2022-06-23 18:29:27.441311
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass



# Generated at 2022-06-23 18:29:28.477003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(list(each_sub_command_config()))

# Generated at 2022-06-23 18:29:38.520987
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = cast(str, os.environ.get('SETUP_DIR'))
    sub_cmds = list(each_sub_command_config(setup_dir))
    assert len(sub_cmds) == 2
    assert sub_cmds[0].name == 'build-release'
    assert sub_cmds[1].name == ''
    assert sub_cmds[1].camel == ''
    assert len(sub_cmds[1].commands) == 1
    assert sub_cmds[1].commands[0] == './setup.py build'


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:42.152166
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('cmd1', 'cmd2')
    )


# Generated at 2022-06-23 18:29:46.196820
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('commands',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)

# Generated at 2022-06-23 18:29:48.529458
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test_name', 'TestName', 'Test Description', ('test command', )
    )

# Generated at 2022-06-23 18:29:53.568877
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for cfg in each_sub_command_config(root):
        pass
    for cfg in each_sub_command_config():
        pass

# Generated at 2022-06-23 18:30:00.418019
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
    assert setup_cfg_command_config.name == 'name'
    assert setup_cfg_command_config.camel == 'camel'
    assert setup_cfg_command_config.description == 'description'
    assert setup_cfg_command_config.commands == ('command',)

if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:30:02.811106
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test_command',
        'TestCommand',
        'Test command for testing.',
        ('test_command',),
    ) is not None

# Generated at 2022-06-23 18:30:10.582758
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Valid strings:
    SetupCfgCommandConfig('command_name', 'CommandName', 'Description', ('command',))
    # Invalid strings:
    try:
        SetupCfgCommandConfig('', '', '', ('',))
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('commandname', 'commandName', 'Description', ('command',))
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('command-name', 'CommandName', 'Description', ('command',))
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('command_name', 'command_name', 'Description', ('command',))
    except ValueError:
        pass
    # Valid tuples:
    SetupCfgCommandConfig('command_name', 'CommandName', 'Description', ())


# Generated at 2022-06-23 18:30:17.786733
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_commands = list(each_sub_command_config())
    assert len(setup_cfg_commands) == 1
    config = setup_cfg_commands[0]
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'test_foo'
    assert isinstance(config.commands, tuple)
    assert len(config.commands) == 1
    assert config.commands[0] == "echo 'Foo Whiz Bang!' > /dev/null"

# Generated at 2022-06-23 18:30:29.619394
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # The setup.cfg file for test
    setup_cfg = '''[metadata]\nname=test_package\n'''

    # The setup_commands.cfg file for test

# Generated at 2022-06-23 18:30:39.515895
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testingutils import TestCase
    from unittest.mock import patch

    class TestSetupCfgCommandConfig(TestCase):
        @patch('flutils.testingutils.TestCase.assertEqual')
        def test__init__(self, mock_assertEqual):
            test_obj = SetupCfgCommandConfig(
                'test.name', 'TestName', 'Test Description',
                ('a', 'b', 'c')
            )
            mock_assertEqual.assert_called_once_with(test_obj.name, 'test.name')
            self.assertEqual(test_obj.camel, 'TestName')
            self.assertEqual(test_obj.description, 'Test Description')
            self.assertEqual(test_obj.commands, ('a', 'b', 'c'))



# Generated at 2022-06-23 18:30:41.071007
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config(setup_dir='.')
    assert len(list(gen)) > 0

# Generated at 2022-06-23 18:30:53.777781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import ensure_dir
    from testfixtures import compare
    from flutils.setuputils import setup_dir

    temp_dir = tempfile.mkdtemp()

    orig_setup_dir = setup_dir()

# Generated at 2022-06-23 18:30:59.060683
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'foo.bar',
        'Foo_bar',
        'Blah dah blah.',
        ('a', 'b', 'c',)
    ) == SetupCfgCommandConfig(
        'foo.bar',
        'Foo_bar',
        'Blah dah blah.',
        ('a', 'b', 'c',)
    )



# Generated at 2022-06-23 18:31:03.046634
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """ Tests that the constructor of the class SetupCfgCommandConfig
    doesn't raise an error.
    """
    SetupCfgCommandConfig('name', 'camel', 'description', ())



# Generated at 2022-06-23 18:31:13.629208
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import sys
    import re

    class _TestSetupCfgCommandConfig(NamedTuple):
        name: str
        description: str

    # To satisfy mypy
    # noinspection PyTypeChecker
    test_configs: List[_TestSetupCfgCommandConfig] = []
    test_configs.append(
        _TestSetupCfgCommandConfig(
            'test_name',
            'This is a test description.'
        )
    )
    test_configs.append(
        _TestSetupCfgCommandConfig(
            'test_name2',
            'This is a 2nd test description.'
        )
    )

    with tempfile.TemporaryDirectory() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')

# Generated at 2022-06-23 18:31:19.730821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import time
    _start = time.perf_counter()
    for config in each_sub_command_config('setup_dir'):
        print(config)
    print(time.perf_counter() - _start)
    assert True


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:27.342340
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='my.command',
        camel='MyCommand',
        description='My command.',
        commands=('echo "hello world"',)
    )
    assert setup_cfg_command_config.name == 'my.command'
    assert setup_cfg_command_config.camel == 'MyCommand'
    assert setup_cfg_command_config.description == 'My command.'
    assert setup_cfg_command_config.commands == ('echo "hello world"',)

# Generated at 2022-06-23 18:31:39.049633
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    from unittest.mock import (
        patch,
        mock_open,
    )
    from flutils.setuputils import each_sub_command_config

    class TestEachSubCommandConfig(unittest.TestCase):
        maxDiff = None


# Generated at 2022-06-23 18:31:49.451277
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(os.path.abspath(__file__))
    here = os.path.join(here, '..', '..', '..', '..')
    args = (here,)
    expected = [
        SetupCfgCommandConfig(
            name='test.test', camel='TestTest', description='',
            commands=('echo hi',)
        ),
        SetupCfgCommandConfig(
            name='test.test2', camel='TestTest2', description='',
            commands=('echo hi',)
        ),
    ]
    assert list(each_sub_command_config(*args)) == expected


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:55.517668
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _test(c: SetupCfgCommandConfig) -> None:
        assert isinstance(c.name, str)
        assert isinstance(c.camel, str)
        assert isinstance(c.description, str)
        for val in c.commands:
            assert isinstance(val, str)

    for c in each_sub_command_config():
        _test(c)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:59.990924
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command',)
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command',)



# Generated at 2022-06-23 18:32:08.424164
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig('python setup.py lint',
                                           'Lint',
                                           'Lint the code',
                                           ('./env/bin/python setup.py lint',
                                            './env/bin/python setup.py pylint',
                                            './env/bin/python setup.py flake8'))
    assert command_config.name == 'python setup.py lint'
    assert command_config.camel == 'Lint'
    assert command_config.description == 'Lint the code'
    assert command_config.commands == ('./env/bin/python setup.py lint',
                                       './env/bin/python setup.py pylint',
                                       './env/bin/python setup.py flake8')

# Generated at 2022-06-23 18:32:19.077021
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import modules
    from os.path import (
        basename,
        dirname,
        isfile,
        join,
        realpath,
    )
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from flutils.path import mkdir_p
    from flutils.pyutils import (
        add_if_not_none,
        merge_dicts,
    )

    _mod = modules[__name__]
    test_dir = dirname(_mod.__file__)
    test_dir = realpath(test_dir)
    test_dirs = [test_dir]
    setup_dir = join(test_dir, 'demo_project')
    if isfile(join(setup_dir, 'setup.py')):
        test_dirs.append(setup_dir)

# Generated at 2022-06-23 18:32:28.128364
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase

    class SomeTestCase(TestCase):
        @property
        def project_root(self) -> str:
            import flutils

            return os.path.dirname(flutils.__file__)

        def test_001(self):
            import flutils.subcommand
            import flutils.subcommand.subcommand

            def cmd_config(
                    cmd: flutils.subcommand.subcommand.CommandConfig
            ) -> bool:
                return cmd.name == 'ci'

            cmd_configs = tuple(
                filter(cmd_config, flutils.subcommand.each_sub_command_config(
                    self.project_root))
            )
            self.assertTrue(len(cmd_configs) == 1)

    from unittest import main

    main()



# Generated at 2022-06-23 18:32:39.258357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_dir = os.path.dirname(__file__)
    if os.path.basename(base_dir) != 'tests':
        base_dir = os.path.join(base_dir, 'tests')
    path = os.path.join(base_dir, 'data', 'setup_commands.cfg')
    assert os.path.isfile(path)
    assert os.path.basename(path) == 'setup_commands.cfg'
    assert os.path.basename(os.path.dirname(path)) == 'data'
    assert os.path.basename(os.path.dirname(os.path.dirname(path))) == 'tests'

# Generated at 2022-06-23 18:32:50.705369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def try_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> List[SetupCfgCommandConfig]:
        out = []
        for config in each_sub_command_config(setup_dir):
            out.append(config)
        return out

    # No 'setup_dir' specified.
    out = try_each_sub_command_config()
    assert len(out) > 0
    assert out[0].name == 'clean'
    assert out[0].camel == 'Clean'
    assert out[0].description == ''
    assert len(out[0].commands) > 0

    # 'setup_dir' is specified and legit.

# Generated at 2022-06-23 18:33:00.922623
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test constructor
    SetupCfgCommandConfig('test', 'Test', 'testing', ('echo testing', ))

    # Test repr
    expected = (
        "SetupCfgCommandConfig(name='test', camel='Test', "
        "description='testing', commands=('echo testing', ))"
    )
    assert repr(SetupCfgCommandConfig('test', 'Test', 'testing',
                                      ('echo testing', ))) == expected

    # Test str
    assert str(SetupCfgCommandConfig('test', 'Test', 'testing',
                                     ('echo testing', ))) == 'test'

    # Test no description
    expected = (
        "SetupCfgCommandConfig(name='test', camel='Test', "
        "description='', commands=('echo testing', ))"
    )

# Generated at 2022-06-23 18:33:07.202077
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')


# Generated at 2022-06-23 18:33:09.447728
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command',))


# Generated at 2022-06-23 18:33:20.746086
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from time import sleep
    import sys
    from tempfile import gettempdir
    from types import ModuleType
    from pathlib import Path
    from flutils.pathutils import copytree

    tempdir = gettempdir()
    testdir = Path(tempdir) / 'flutils_setupcfg_testdir'
    here = Path(__file__).parent.resolve()
    src = here / 'testdata' / 'each_sub_command_config'
    copytree(src, testdir)
    sys.path.insert(0, str(testdir))
    sys.path.pop(sys.path.index(str(here.parent)))

    sleep(.1)


# Generated at 2022-06-23 18:33:27.339897
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    configs = list(each_sub_command_config('./'))

    # Ensure the number of commands is correct
    assert len(configs) == 1

    # Ensure the command name is correct
    assert configs[0].name == 'setup.command.dev.test'

    # Ensure the command description is correct
    assert configs[0].description == 'Run the unit tests'

    # Ensure the command class name is correct
    assert configs[0].camel == 'DevTestCommand'

    # Ensure the command option name is correct
    assert configs[0].commands == ('pytest',)



# Generated at 2022-06-23 18:33:39.745882
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        out = SetupCfgCommandConfig('', '', '', ())
        assert False, 'Failure to detect an invalid value for "name".'
    except ValueError:
        pass
    try:
        out = SetupCfgCommandConfig('a', '', '', ())
        assert False, 'Failure to detect an invalid value for "camel".'
    except ValueError:
        pass
    try:
        out = SetupCfgCommandConfig('a', 'B', '', ())
        assert False, 'Failure to detect an invalid value for "description".'
    except ValueError:
        pass
    try:
        out = SetupCfgCommandConfig('a', 'B', 'C', ())
        assert False, 'Failure to detect an invalid value for "commands".'
    except ValueError:
        pass
    out = SetupCfgCommand

# Generated at 2022-06-23 18:33:50.017280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd = 'git clone https://github.com/brentpayne/python-flutils.git'
    test_dir = os.path.join(os.path.expanduser('~'), 'tmp')
    cfg_path = os.path.join(test_dir, 'setup.cfg')
    os.chdir(test_dir)
    with open(cfg_path, 'w') as fd:
        fd.write(
            '[metadata]\nname = my_awesome_lib\n[setup.command.test]\n'
            'command = %s' % cmd
        )
    actual = []
    for info in each_sub_command_config(test_dir):
        assert isinstance(info, SetupCfgCommandConfig)
        actual.append(info)
    assert len(actual) == 1


# Generated at 2022-06-23 18:33:55.156714
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    assert cfg.name == 'name'
    assert cfg.camel == 'camel'
    assert cfg.description == 'description'
    assert cfg.commands == ('cmd',)

# Generated at 2022-06-23 18:34:02.833001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import sep
    from sys import executable
    from logging import basicConfig, DEBUG
    from tempfile import mkdtemp
    from shutil import (
        rmtree,
        copyfile,
    )
    from pathlib import Path
    from tempfile import mkdtemp
    from flutils.setuputils import each_sub_command_config

    TEST_DIR = Path(__file__).parent
    from flutils.setuputils import (
        check_sub_commands,
        each_sub_command_config,
    )


# Generated at 2022-06-23 18:34:07.254539
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", ())
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ()

# Generated at 2022-06-23 18:34:13.784968
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tuples = list(each_sub_command_config(setup_dir=_prep_setup_dir()))
    assert(len(tuples)) > 1
    assert(tuples[0].name) != ''
    assert(tuples[0].camel) != ''
    assert(tuples[0].description) != ''
    assert(len(tuples[0].commands)) > 1

# Generated at 2022-06-23 18:34:16.887457
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # pragma: no cover
    # pylint: disable=useless-assertion
    assert SetupCfgCommandConfig(
        'foo.bar',
        'FooBar',
        'This is a foo bar.',
        ('do foo', 'do bar')
    )

# Generated at 2022-06-23 18:34:25.960531
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert issubclass(SetupCfgCommandConfig, NamedTuple)
    assert SetupCfgCommandConfig.__name__ == 'SetupCfgCommandConfig'

# Generated at 2022-06-23 18:34:30.149897
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        print(f'config={config}')

if __name__ == '__main__':
    _test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:34:41.853386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTest

    class TestEachSubCommandConfig(UnitTest):
        """Unit test for the each_sub_command_config function."""

        def test_each_sub_command_config(self):
            """Test the each_sub_command_config function with the
            unittest.cfg file.
            """

            def _get_expected_tuple(
                    parser: ConfigParser,
                    format_kwargs: Dict[str, str]
            ) -> SetupCfgCommandConfig:
                # NOTE: This will only get the first section in the
                # setup_commands.cfg file.
                setup_cfg_path = os.path.join(
                    format_kwargs['setup_dir'], 'setup_commands.cfg'
                )
                parser = ConfigParser()

# Generated at 2022-06-23 18:34:47.500685
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)

    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        logger.debug(config)


__all__ = (
    'SetupCfgCommandConfig',
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:34:51.223154
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for subcommand in each_sub_command_config():
        print(subcommand)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:56.602718
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('name', 'Name', 'description', ('commands',))
    assert cfg.name == 'name'
    assert cfg.camel == 'Name'
    assert cfg.description == 'description'
    assert cfg.commands == ('commands',)



# Generated at 2022-06-23 18:35:00.935755
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    t = SetupCfgCommandConfig('x', 'y', 'z', ('a', 'b', 'c'))
    assert t.name == 'x'
    assert t.camel == 'y'
    assert t.description == 'z'
    assert t.commands == ('a', 'b', 'c')

# Generated at 2022-06-23 18:35:04.775220
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    instance = SetupCfgCommandConfig("name", "camel", "description", ("cmd",))
    assert instance.name == "name"
    assert instance.camel == "camel"
    assert instance.description == "description"
    assert instance.commands == ("cmd",)


# Generated at 2022-06-23 18:35:11.464109
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib
    import tempfile
    config = """
    [setup.command.tests]
    command =  test
    """
    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        path = d / 'setup.cfg'
        with open(path, 'wt') as fh:
            fh.write(config)

        cmd = each_sub_command_config(td)
        cmd = list(cmd)
        assert cmd[0].commands[0] == 'test'


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:16.630897
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    info = SetupCfgCommandConfig(
        'name',
        'Camel',
        'Description',
        ('command',)
    )
    assert info.name == 'name'
    assert info.camel == 'Camel'
    assert info.description == 'Description'
    assert info.commands == ('command',)

# Generated at 2022-06-23 18:35:28.784061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from flutils.pathutils import write_file
    # func that uses a config file
    def _func_that_uses_a_config_file(**kwargs):
        for cfg in each_sub_command_config(**kwargs):
            pass
    # no setup.py file
    with TemporaryDirectory() as tmpdir:
        with patch.object(sys, 'stderr', new_callable=io.StringIO) as mock_stderr:
            _func_that_uses_a_config_file(setup_dir=tmpdir)
        out = mock_stderr.getvalue()
        out = out.strip()
        assert out.startswith('Traceback') is True, out
    # no setup.cfg file
   

# Generated at 2022-06-23 18:35:35.761357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    it = each_sub_command_config(setup_dir='.')
    assert isinstance(it, Generator)
    assert list(it) != []

    it = each_sub_command_config(setup_dir='.')
    commands = list(it)
    assert len(commands) > 0

    it = each_sub_command_config()
    assert list(it) != []



# Generated at 2022-06-23 18:35:40.386931
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config.name)
        print(config.camel)
        print(config.description)
        print((' '*4).join(config.commands))
        print()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:35:51.666102
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import platform

    if platform.system() == 'Windows':
        print('SKIPPED')
        return

    import pathlib
    import sys

    # Find the directory this module is in.
    setup_dir = os.path.dirname(__file__)  # type: ignore
    for _ in range(2):
        setup_dir = os.path.dirname(setup_dir)

    from flutils.testutils import capture_output

    # Make sure the expected setup.py file is NOT there.
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py')) is True
    assert os.path.isfile(os.path.join(setup_dir, 'setup.cfg')) is True
    path = os.path.join(setup_dir, 'setup_commands.cfg')


# Generated at 2022-06-23 18:35:56.318737
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'B', '', ()) == (
        SetupCfgCommandConfig('a', 'B', '', ())
    )
    assert SetupCfgCommandConfig('a', 'B', '', ()) != (
        SetupCfgCommandConfig('a', 'B', '', ('1',))
    )


# Generated at 2022-06-23 18:36:03.858513
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.configutils import config_to_dict
    format_kwargs = {
        'setup_dir': os.path.abspath(__file__),
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)

# Generated at 2022-06-23 18:36:14.763029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import json
    import sys
    import tempfile
    import textwrap

    class FakeSetupCfgCommandConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    class Fake():
        def __init__(self):
            self._setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            self._setup_commands_cfg = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )

        def _write(self, path: str, content: str) -> None:
            with open(path, 'w') as f:
                f.write(textwrap.dedent(content))


# Generated at 2022-06-23 18:36:18.930995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    base = os.path.dirname(__file__)
    # Setup.cfg with a single command
    cfg = os.path.join(base, 'cfg', 'single.cfg')
    cfg = os.path.normpath(cfg)
    out = tuple(each_sub_command_config(cfg))
    assert len(out) == 1
    item = out[0]
    assert item.name == "hello"
    assert item.camel == "Hello"
    assert item.description == "Print 'Hello, World!'"
    assert item.commands == (
        'echo "Hello, World!"',
    )
    # Setup.cfg that contains multiple commands
    cfg = os.path.join(base, 'cfg', 'multi.cfg')
    cfg = os.path.normpath(cfg)


# Generated at 2022-06-23 18:36:29.043522
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from os import path
    from os import environ
    from unittest.mock import patch
    from unittest import TestCase

    _path_append(path.dirname(__file__))

    def _get_patch(mod_path):
        return patch.dict(
            sys.modules,
            {
                mod_path: MockConfigParserModule()
            }
        )

    def _path_append(directory):
        sys.path.insert(0, directory)

    class MockConfigParserModule:
        """A mock of ``configparser`` module to use in unit tests."""
        section = 'metadata'
        name = 'package_name'
        setup_cfg = {
            'metadata': {
                'name': name
            }
        }

# Generated at 2022-06-23 18:36:32.896588
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            '',
            '',
            '',
            ('')
        )
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 18:36:33.523979
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig

# Generated at 2022-06-23 18:36:43.414560
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Given
    import sys
    import inspect
    import flutils.setuptools

    # When
    with inspect.stack() as stack:
        fs: FrameSummary = cast(FrameSummary, stack[1])
        setup_cfg_path = fs.filename
        setup_cfg_path = os.path.join(
            os.path.dirname(setup_cfg_path), 'setup.cfg'
        )

        for out in each_sub_command_config():
            assert out.name

    # Then
    assert setup_cfg_path.endswith(
        'flutils/setuptools/test/test_setuptools.py'
    )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:36:53.703450
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _dir = os.path.dirname(os.path.abspath(__file__))
    _dir = os.path.join(_dir, 'resources', 'flutils_configparser')
    _dir = os.path.join(_dir, 'sub_command_config')
    out = list(each_sub_command_config(_dir))
    assert out == [
        SetupCfgCommandConfig(
            'sub_command_config.sub_command_config',
            'SubCommandConfig',
            'Sub command config.',
            (
                'sub_cmd',
                "sub cmd",
                'sub-cmd',
            )
        )
    ]


# Generated at 2022-06-23 18:36:57.706727
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(os.path.dirname(__file__)):
        assert type(cfg) == SetupCfgCommandConfig
        assert cfg.name.startswith('setup.subcmd.flutils')