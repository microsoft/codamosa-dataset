

# Generated at 2022-06-23 18:27:03.408594
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from tempfile import mkdtemp
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.configutils import (
        pyproject_toml_writer,
        setup_cfg_writer,
        setup_commands_cfg_writer,
    )

    class EachSubCommandConfigTest(TestCase):

        @classmethod
        def setUpClass(cls) -> None:
            setup_dir = mkdtemp(prefix='each_sub_command_config_')
            cls.setup_dir = setup_dir
            setup_cfg = setup_cfg_writer('flutils-test')
            setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-23 18:27:06.895483
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        for i in each_sub_command_config():
            print(i)
    except FileNotFoundError:
        pass

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:19.341412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        '..',
        '..',
        'flsetup',
        'tests',
        'sample_setup',
        'setup.cfg'
    )
    configs = [
        config for config in each_sub_command_config(path)
    ]
    assert len(configs) == 2, \
        "There should be exactly two sub-commands."
    assert configs[0].name == 'sys.exit'
    assert configs[1].name == 'sys.exit2'

    with open(path, 'w') as f:
        f.write('[metadata]\nname = flsetup')


# Generated at 2022-06-23 18:27:22.847777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        print(dir(cmd), cmd)
        assert isinstance(cmd, SetupCfgCommandConfig)
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.camel, str)
        assert isinstance(cmd.description, str)
        assert isinstance(cmd.commands, tuple)
        for command in cmd.commands:
            assert isinstance(command, str)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:33.576323
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f')
    ) == SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f')
    )
    assert SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f')
    ) != SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f', 'g')
    )
    assert SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f')
    ) != SetupCfgCommandConfig(
        'b', 'C', 'd', ('f', 'e')
    )
    assert SetupCfgCommandConfig(
        'b', 'C', 'd', ('e', 'f')
    )

# Generated at 2022-06-23 18:27:40.438312
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

# Generated at 2022-06-23 18:27:48.045922
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase, mock
    from flutils.configutils import each_sub_command_config

    class TestCase(TestCase):
        @mock.patch.dict(os.environ, {'FLUTILS_SETUP_DIR': '.'})
        def test_setup_dir_from_env_var(self):
            for config in each_sub_command_config():
                pass

    TestCase().test_setup_dir_from_env_var()

# Generated at 2022-06-23 18:27:54.485789
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    names = ['x', 'y', 'z']
    camels = ['X', 'Y', 'Z']
    descriptions = ['x', 'y', 'z']
    commands = [['', '', ''], ['', '', ''], ['', '']]
    for name, camel, description, command in zip(names, camels, descriptions, commands):
        config = SetupCfgCommandConfig(name, camel, description, command)
        assert name == config.name
        assert camel == config.camel
        assert description == config.description
        assert command == config.commands

# Generated at 2022-06-23 18:28:00.805428
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test(setup_dir: str):
        configs = tuple(each_sub_command_config(setup_dir))
        assert configs[0] == SetupCfgCommandConfig(
            "cmd-1",
            "Cmd1",
            "",
            ("python setup.py test",)
        )
        assert configs[1] == SetupCfgCommandConfig(
            "cmd-2",
            "Cmd2",
            "",
            ("python setup.py test2",)
        )
    call_fwk_func(test)


if __name__ == '__main__':
    from sys import exit
    from flutils.testing import call_fwk_func
    exit(call_fwk_func())

# Generated at 2022-06-23 18:28:03.496858
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', ())
    except Exception:
        assert False, 'Failed to initialize SetupCfgCommandConfig'
    return


# Generated at 2022-06-23 18:28:05.377219
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='test', camel='Test', description='test', commands=('',)
    )

# Generated at 2022-06-23 18:28:10.911019
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', [])
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command1', 'command2')

# Generated at 2022-06-23 18:28:17.606620
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name="name",
        camel="camel",
        description="description",
        commands=tuple(["commands"])
    )
    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == tuple(["commands"])


# Generated at 2022-06-23 18:28:18.815706
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    each_sub_command_config()  # type: ignore[call-arg]

# Generated at 2022-06-23 18:28:24.394154
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig(
        'test_name', 'TestName', 'test description', ('cmd1', 'cmd2')
    )
    assert actual.name == 'test_name'
    assert actual.camel == 'TestName'
    assert actual.description == 'test description'
    assert actual.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:28:28.120516
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('a', 'A', 'a', ('a',))
    assert config.name == 'a'
    assert config.camel == 'A'
    assert config.description == 'a'
    assert config.commands == ('a',)


# Generated at 2022-06-23 18:28:33.277274
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'flutils'
    )
    for sub_command_config in each_sub_command_config(setup_dir):
        print(sub_command_config.camel)
        for command in sub_command_config.commands:
            print(command)
        print(sub_command_config.description)
        print('-' * 80)

test_each_sub_command_config()

# Generated at 2022-06-23 18:28:42.801578
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils
    import tempfile
    import shutil

    def _write_setup_cfg(setup_cfg: str) -> None:
        with open(setup_cfg_path, 'w') as fh:
            print(setup_cfg, file=fh)

    def _write_setup_commands_cfg(setup_commands_cfg: str) -> None:
        with open(setup_commands_cfg_path, 'w') as fh:
            print(setup_commands_cfg, file=fh)


# Generated at 2022-06-23 18:28:48.183269
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1',))
    assert cfg.name == 'name'
    assert cfg.camel == 'camel'
    assert cfg.description == 'description'
    assert cfg.commands == ('cmd1',)


# Generated at 2022-06-23 18:28:59.329907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyUnresolvedReferences
    from tests.utils.setuputils import (
        fake_setup_cfg,
        fake_setup_commands_cfg,
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = os.path.join(tmpdir, 'flutils')
        os.makedirs(tmpdir)
        os.makedirs(os.path.join(tmpdir, 'tests'))
        setup_dir = os.path.join(tmpdir, 'tests', 'utils')
        os.makedirs(setup_dir)

        with open(os.path.join(setup_dir, 'setup.py'), 'w') as wfd:
            wfd.write('import os\n')
            wfd.write('import sys\n')

# Generated at 2022-06-23 18:29:06.696051
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the ``SetupCfgCommandConfig`` class constructor."""
    actual = SetupCfgCommandConfig(
        'name',
        'Camel',
        'Description',
        ('command1', 'command2',)
    )
    assert actual.name == 'name'
    assert actual.camel == 'Camel'
    assert actual.description == 'Description'
    assert actual.commands == ('command1', 'command2',)

# Generated at 2022-06-23 18:29:11.433211
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test_name', 'TestName', 'Test description.', ('test command',))
    assert config.name == 'test_name'
    assert config.camel == 'TestName'
    assert config.description == 'Test description.'
    assert config.commands == ('test command',)


# Generated at 2022-06-23 18:29:24.129709
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest

    def setup_module():
        import os

        os.chdir(os.path.dirname(__file__))

    setup_module()

    results: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert results[0] == SetupCfgCommandConfig(
        'build_doc',
        'BuildDoc',
        'Build Sphinx documentation with autodoc and autosummary.',
        (
            'sphinx-apidoc -f -e -o build/sphinx '
            '../flutils/ .tox/docs/lib/python3.*/site-packages/flutils',
            'sphinx-build -b html build/sphinx build/sphinx/html',
        )
    )

# Generated at 2022-06-23 18:29:31.732621
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import contextlib
    import io
    from unittest.mock import patch

    class CaptureOutput:
        def __init__(self):
            self._output = None
            self._err = None

        def __enter__(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            self._out_capture = io.StringIO()
            self._err_capture = io.StringIO()
            sys.stdout = self._out_capture
            sys.stderr = self._err_capture
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self._output = self._out_capture.getvalue()
            self._err = self._err_capture.getvalue()


# Generated at 2022-06-23 18:29:41.319924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    from flutils.debugutils import (
        pprint_log,
    )
    from flutils.pathutils import (
        each_part,
        abspath,
        package_dir_from_file,
        py_ext_suffix,
    )
    from flutils.scriptutils import (
        mod_name,
    )

    this_mod = mod_name()

    this_dir = abspath(package_dir_from_file(__file__))
    this_dir = this_dir.replace(
        os.sep + this_mod,
        os.sep + 'setup'
    )
    for name in each_part(this_dir):
        if name == 'setup':
            break
    setup_dir = this_dir[:this_dir.find(name) + len(name)]
    py

# Generated at 2022-06-23 18:29:51.320969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import json
    import sys
    import textwrap

    import pytest

    from flutils.setuputils import each_sub_command_config

    def test_setup_cfg(tmp_path: os.PathLike) -> None:
        setup_cfg_path = os.path.join(tmp_path, 'setup.cfg')

# Generated at 2022-06-23 18:30:02.424477
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=C0116
    from testfixtures import compare
    from pathlib import Path

    # pylint: disable=W0212
    for path in (Path(__file__).parent.parent / 'setup.cfg',
                 'setup_commands.cfg'):
        parser = ConfigParser()
        parser.read(path)
        format_kwargs = {
            'name': 'flutils',
            'home': str(Path.home())
        }
        config = list(_each_setup_cfg_command(parser, format_kwargs))
        compare(len(config), 4)


if __name__ == '__main__':
    # pylint: disable=C0116,C0115
    import sys
    import unittest

    print('Testing the command line generator...')
    exit

# Generated at 2022-06-23 18:30:05.409765
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.setuputils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-23 18:30:06.865868
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig("name", "Camel", "description", ("command",))


# Generated at 2022-06-23 18:30:08.062732
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'description', tuple())

# Generated at 2022-06-23 18:30:17.607033
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Test values
    txt = """
    [metadata]
    name = bdist
    [setup.command.commands]
    commands = echo -e "\n\n$(python setup.py --version)\n"
    """

    parser = ConfigParser()
    parser.read_string(txt)
    cfg = next(_each_setup_cfg_command(parser, {'name': 'bdist'}))
    assert cfg.name == 'commands'
    assert cfg.camel == 'Commands'
    assert cfg.description == ''
    assert cfg.commands[0] == 'echo -e "\n\n$(python setup.py --version)\n"'


# Generated at 2022-06-23 18:30:23.706696
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig.__name__ == 'SetupCfgCommandConfig'
    c = SetupCfgCommandConfig('name', 'camel', 'description', ('command1',))
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('command1',)

# Generated at 2022-06-23 18:30:31.099009
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    assert os.path.exists(setup_dir)
    fmt = '    name: {name!r}, camel: {camel!r}, ' \
          'description: {description!r}, commands: {commands!r}'
    for config in each_sub_command_config(setup_dir):
        print(fmt.format(**config._asdict()))

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:34.833861
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Name'
    description = 'description'
    commands = None
    setupcfgcommandconfig = SetupCfgCommandConfig(name,
                                                  camel,
                                                  description,
                                                  commands)
    assert setupcfgcommandconfig.name == name
    assert setupcfgcommandconfig.camel == camel
    assert setupcfgcommandconfig.description == description
    assert setupcfgcommandconfig.commands == commands

# Generated at 2022-06-23 18:30:40.157789
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # testing that the constructor works with the defaults
    test_case = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='',
        commands=('',)
    )
    assert test_case.name == 'test'
    assert test_case.camel == 'Test'
    assert test_case.description == ''
    assert test_case.commands == ('',)

# Generated at 2022-06-23 18:30:52.646023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Test for each_sub_command_config.

    :return: ``None``
    :rtype: None
    """
    from flutils.setuputils import (
        get_base_logger,
        each_sub_command_config
    )
    from flutils.disptools import Dispatch
    from pathlib import Path

    # Test the pathlib and str inputs
    sub_commands1 = tuple(each_sub_command_config(
        Path(__file__).parent.parent
    ))
    sub_commands2 = tuple(each_sub_command_config(
        str(Path(__file__).parent.parent)
    ))
    assert sub_commands1 == sub_commands2

    # Test the no argument input
    logger = get_base_logger()

# Generated at 2022-06-23 18:30:58.063724
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='A foo',
        commands=('a', 'b')
    )
    assert config
    assert config.name == 'foo'
    assert config.camel == 'Foo'
    assert config.description == 'A foo'
    assert config.commands == ('a', 'b')



# Generated at 2022-06-23 18:31:07.933021
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig(
        name='Foo',
        camel='Foo',
        description='Yep',
        commands=('bar', 'baz', 'qux')
    )
    assert c.name == 'Foo'
    assert c.camel == 'Foo'
    assert c.description == 'Yep'
    assert c.commands == ('bar', 'baz', 'qux')
    assert c == SetupCfgCommandConfig(
        'Foo',
        'Foo',
        'Yep',
        ('bar', 'baz', 'qux')
    )

# Generated at 2022-06-23 18:31:15.319022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def assert_config(
            section: str,
            name: str,
            camel: str,
            commands: Tuple[str, ...],
            description: str = None
    ) -> SetupCfgCommandConfig:
        if description is None:
            description = name
        return SetupCfgCommandConfig(
            name,
            camel,
            description,
            commands
        )

    from flutils.testutils import TestBase
    from unittest import mock

    class EachSubCommandConfigTest(TestBase):

        def test__each_setup_cfg_command_section(self):
            parser = ConfigParser()
            parser.add_section('metadata')
            parser.add_section('setup.command.foo')
            parser.add_section('setup.command.bar')
            parser.add_section('setup.command.baz')

# Generated at 2022-06-23 18:31:23.059312
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='the_command',
        camel='TheCommand',
        description='A fake test command.',
        commands=('echo',)
    )
    assert config.name == 'the_command'
    assert config.camel == 'TheCommand'
    assert config.description == 'A fake test command.'
    assert config.commands == ('echo',)



# Generated at 2022-06-23 18:31:27.734768
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    conf = SetupCfgCommandConfig(
        name="name", camel="camel", description="description", commands=('command',)
    )
    assert conf.name == "name"
    assert conf.camel == "camel"
    assert conf.description == "description"
    assert conf.commands == ('command',)



# Generated at 2022-06-23 18:31:30.038476
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commands',)
    )


# Generated at 2022-06-23 18:31:33.380890
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config_1 = SetupCfgCommandConfig(
        '',
        '',
        '',
        ()
    )
    assert isinstance(config_1, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:31:39.996323
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'camel', 'description', ('commands'))
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('commands',)
    assert len(obj) == 4
    assert obj == ('name', 'camel', 'description', ('commands',))



# Generated at 2022-06-23 18:31:44.778943
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        # Method under test
        SetupCfgCommandConfig(
            name='name', camel='Camel', description='description',
            commands=('command_1', 'command_2')
        )
    except:
        assert False, 'Unit test failed.'
    else:
        assert True, 'Unit test succeeded.'



# Generated at 2022-06-23 18:31:55.639377
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    v = SetupCfgCommandConfig('a', 'B', 'C', ('d', 'e'))
    assert v.name == 'a'
    assert v.camel == 'B'
    assert v.description == 'C'
    assert v.commands == ('d', 'e')
    v = SetupCfgCommandConfig('a', 'B', 'C')
    assert v.name == 'a'
    assert v.camel == 'B'
    assert v.description == 'C'
    assert v.commands == ()
    assert isinstance(v, tuple) is True
    with pytest.raises(TypeError):
        SetupCfgCommandConfig(1, 2, 3, 4)
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('a', 2, 3, 4)

# Generated at 2022-06-23 18:31:58.049191
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name',
                                 'Camel',
                                 'Description',
                                 ('command1', 'command2'))

# Generated at 2022-06-23 18:32:03.769160
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = 'commands'
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == name
    assert config.camel_case_name == camel
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:32:15.451168
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-23 18:32:23.818397
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=too-few-public-methods
    class Tmp(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    assert Tmp._fields == SetupCfgCommandConfig._fields
    name = Tmp.name
    camel = Tmp.camel
    description = Tmp.description
    commands = Tmp.commands
    assert name is SetupCfgCommandConfig.name
    assert camel is SetupCfgCommandConfig.camel
    assert description is SetupCfgCommandConfig.description
    assert commands is SetupCfgCommandConfig.commands

# Generated at 2022-06-23 18:32:29.337484
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    config = SetupCfgCommandConfig('foo', 'Foo', '', ('cmd',))
    assert config.name == 'foo'
    assert config.camel == 'Foo'
    assert config.description == ''
    assert config.commands == ('cmd',)


# Generated at 2022-06-23 18:32:38.605112
# Unit test for constructor of class SetupCfgCommandConfig

# Generated at 2022-06-23 18:32:50.624710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    for fs in extract_stack():
        if os.path.basename(fs.filename) != 'setup_utils.py':
            break
    setup_dir = os.path.dirname(fs.filename)
    setup_dir = os.path.realpath(setup_dir)
    name = os.path.basename(setup_dir)
    setup_cfg = os.path.join(setup_dir, 'setup.cfg')
    with open(setup_cfg, 'w') as f:
        f.write('[metadata]\n')
        f.write('name = %s\n' % name)
    this_file_path = os.path.realpath(__file__)
    this_dir = os.path.dirname(this_file_path)

# Generated at 2022-06-23 18:33:00.888433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    import sys
    import unittest

    class EachSubcommandConfigTestCase(unittest.TestCase):

        def test_sub_command_config_list(self):
            limit = 100
            cnt = 0
            for subcmd_cfg in each_sub_command_config():
                cnt += 1
                print(subcmd_cfg)
                self.assertTrue(issubclass(
                    type(subcmd_cfg), SetupCfgCommandConfig
                ))
                self.assertTrue(isinstance(subcmd_cfg.name, str))
                self.assertTrue(isinstance(subcmd_cfg.camel, str))
                self.assertTrue(isinstance(subcmd_cfg.description, str))

# Generated at 2022-06-23 18:33:11.015887
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='hello',
        camel='Hello',
        description='hello world',
        commands=('hello.py', 'fizz-buzz/fizz_buzz.py')
    )
    assert setup_cfg_command_config.name == 'hello'
    assert setup_cfg_command_config.camel == 'Hello'
    assert setup_cfg_command_config.description == 'hello world'
    assert setup_cfg_command_config.commands == ('hello.py', 'fizz-buzz/fizz_buzz.py')



# Generated at 2022-06-23 18:33:12.778512
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'camel', 'description', ('commands', ))


# Generated at 2022-06-23 18:33:20.566884
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pathlib
    import pprint

    curr_file = os.path.realpath(__file__)
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(curr_file)))
    root_dir = pathlib.Path(root_dir).resolve()
    sys.path.insert(0, str(root_dir))

    from flutils.console import capture_stdout

    from flutils.logging import get_logger
    from flutils.system import remove_file
    from flutils.system import write_file
    from flutils.versionutils import get_version

    from setup_commands.runner import main

    from tests import assert_with_logging

    logger = get_logger(name='test_each_sub_command_config')

# Generated at 2022-06-23 18:33:24.649624
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('setup.cfg')
    format_kwargs = {
        'setup_dir': os.path.abspath('.'),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, 'setup.cfg')
    yield from _each_setup_cfg_command(parser, format_kwargs)

# Generated at 2022-06-23 18:33:36.734073
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import get_test_value
    from os.path import (
        abspath,
        join,
    )
    from os import environ
    test_dir = join(environ['HOME'], '.local', 'share', 'pytest', 'tests')
    out = list(each_sub_command_config(test_dir))
    assert out == get_test_value('setup_commands.py', 'each_sub_command_config')


if __name__ == '__main__':
    import sys
    sys.path.insert(0, os.environ['HOME'] + '/.local/share/pytest/tests')
    import test_setup_commands
    print(test_setup_commands.test_each_sub_command_config())

# Generated at 2022-06-23 18:33:45.821361
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected = SetupCfgCommandConfig(
        'test_name',
        'TestName',
        'This is the description',
        (
            'echo "This is the first command."',
            'echo "This is the second command."',
            'echo "This is the third command."'
        )
    )
    actual = SetupCfgCommandConfig(
        'test_name',
        'TestName',
        'This is the description',
        (
            'echo "This is the first command."',
            'echo "This is the second command."',
            'echo "This is the third command."'
        )
    )
    assert expected == actual


# Generated at 2022-06-23 18:33:51.295398
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='build',
        camel='Build',
        description='Build command.',
        commands=('pip install .', 'pip install .[dev]')
    )
    assert config.name == 'build'
    assert config.camel == 'Build'
    assert config.description == 'Build command.'
    assert config.commands == ('pip install .', 'pip install .[dev]')



# Generated at 2022-06-23 18:33:57.956017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = [x for x in each_sub_command_config()]
    print(out)


if __name__ == '__main__':
    import sys
    test_filename = sys.argv.pop()
    test_name = os.path.splitext(test_filename)[0]
    sys.argv.extend(['--verbose', '--tb=short', test_name])

    import pytest
    pytest.main()

# Generated at 2022-06-23 18:34:03.552641
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected = SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=()
    )
    actual = SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=()
    )
    assert expected == actual


# Generated at 2022-06-23 18:34:07.348420
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', ())
    except Exception:
        assert True
    else:
        assert False


if __name__ == '__main__':
    SetupCfgCommandConfig('', '', '', ())

# Generated at 2022-06-23 18:34:14.840025
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import itertools
    for params in itertools.product(
            tuple(range(10)),
            tuple(range(10)),
            tuple(range(10)),
            tuple(range(10)),
            tuple(range(10)),
    ):
        c = SetupCfgCommandConfig(*params)
        assert c.name == params[0]
        assert c.description == params[1]
        assert c.commands == params[2:]
# End unit test for constructor of class SetupCfgCommandConfig



# Generated at 2022-06-23 18:34:21.563599
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check(
            sub_cmd: str,
            expected_tuple: SetupCfgCommandConfig,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        setup_dir = setup_dir or os.path.dirname(os.path.realpath(__file__))
        setup_dir = os.path.realpath(setup_dir)
        for actual_tuple in each_sub_command_config(setup_dir):
            if actual_tuple.name == sub_cmd:
                assert actual_tuple == expected_tuple

    check('foo', SetupCfgCommandConfig(
        'foo',
        'Foo',
        'This is the foo command.',
        ('echo foo',)
    ))

# Generated at 2022-06-23 18:34:22.755989
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig()

# Generated at 2022-06-23 18:34:27.727318
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig("foo", "bar", "baz", ("bam",))
    assert scfgcc.name == "foo"
    assert scfgcc.camel == "bar"
    assert scfgcc.description == "baz"
    assert scfgcc.commands == ("bam",)



# Generated at 2022-06-23 18:34:39.358078
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from os import getcwd, chdir, mkdir
    base_dir = getcwd()
    with TemporaryDirectory() as d:
        chdir(d)
        mkdir('src')
        open('README.rst', 'w').close()
        open('setup.py', 'w').close()
        open('setup.cfg', 'w').close()
        assert 'setup.py' in os.listdir(d), \
            'The setup.py file was not created.'
        open('setup_commands.cfg', 'w').close()
        assert 'setup_commands.cfg' in os.listdir(d), \
            'The setup_commands.cfg file was not created.'
        open(os.path.join('src', '__init__.py'), 'w').close()

# Generated at 2022-06-23 18:34:47.894345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase, main

    type_ = SetupCfgCommandConfig
    target = type_('name', 'Camel', 'description', ('cmd',))
    assert target.name == 'name'
    assert target.camel == 'Camel'
    assert target.description == 'description'
    assert target.commands == ('cmd',)

    class This(TestCase):
        def test_introspection(self) -> None:
            self.assertEqual(target.name, 'name')
            self.assertEqual(target.camel, 'Camel')
            self.assertEqual(target.description, 'description')
            self.assertEqual(target.commands, ('cmd',))

    main()



# Generated at 2022-06-23 18:34:53.013841
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", ("commands"))
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ("commands",)


# Generated at 2022-06-23 18:35:04.069253
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import no_console_err
    
    setup_path = os.path.abspath(os.path.join(__file__, '..', '..', '..'))
    commands = tuple(each_sub_command_config(setup_path))
    assert len(commands) > 4
    names = tuple(map(lambda x: x.name, commands))
    assert 'build' in names
    assert 'diagnose' in names
    assert 'develop' in names
    assert 'install' in names
    with no_console_err():
        help_commands = tuple(
            each_sub_command_config(os.path.join(setup_path, 'docs'))
        )
        assert len(help_commands) == 1

# Generated at 2022-06-23 18:35:13.295563
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # pragma: no cover

    def _assert(
            commands: List[SetupCfgCommandConfig],
            text: Optional[str] = None
    ) -> None:
        assert len(commands) == 2
        cmd = commands[0]
        assert cmd.name == 'my_cmd'
        assert cmd.camel == 'MyCmd'
        assert cmd.description == ''

# Generated at 2022-06-23 18:35:26.679436
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from mock import patch
    from tempfile import TemporaryDirectory
    from io import StringIO
    from textwrap import dedent
    from contextlib import ExitStack  # pylint: disable=no-name-in-module
    from tempfile import TemporaryDirectory  # pylint: disable=no-name-in-module

    expect = {
        'name': 'flutils',
        'camel': 'Flutils',
        'description': 'Flutils command.',
        'commands': ('flutils', 'flutils cmd'),
    }
    with ExitStack() as stack:
        fp = stack.enter_context(StringIO())
        stack.enter_context(patch.object(
            ConfigParser, 'read', return_value=None
        ))

# Generated at 2022-06-23 18:35:27.755384
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for s in each_sub_command_config('.'):
        print(s)

# Generated at 2022-06-23 18:35:34.291033
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    o = SetupCfgCommandConfig(
        name='my_name',
        camel='MyName',
        description='description',
        commands=('one', 'two'),
    )
    assert o.name == 'my_name'
    assert o.camel == 'MyName'
    assert o.description == 'description'
    assert o.commands == ('one', 'two')

# Generated at 2022-06-23 18:35:40.853709
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args = (
        'name',
        'camel',
        'description',
        ('cmd1', 'cmd2')
    )
    c = SetupCfgCommandConfig(*args)
    assert c._fields == ('name', 'camel', 'description', 'commands')
    assert c.name == args[0]
    assert c.camel == args[1]
    assert c.description == args[2]
    assert c.commands == args[3]



# Generated at 2022-06-23 18:35:48.943687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .fixtures import setup_dir

    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        for config in each_sub_command_config(sys.argv[1]):
            print(config)
    else:
        from .fixtures import setup_dir
        for config in each_sub_command_config(setup_dir):
            print(config)

# Generated at 2022-06-23 18:35:51.128720
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    assert c.name == 'a'
    assert c.camel == 'b'
    assert c.description == 'c'
    assert c.commands == ('d', 'e')

# Generated at 2022-06-23 18:36:00.663035
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig.__new__.__annotations__ == {
        'name': str,
        'camel': str,
        'description': str,
        'commands': Tuple[str, ...],
    }
    assert SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command1', 'command2')
    ) == SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command1', 'command2')
    )

# Generated at 2022-06-23 18:36:12.242743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    setup_cfg_data = """\
[metadata]
name = {name}
version = 0.0.0

[options]
packages = find:
package_dir =
    =src
    {name} = src

[options.packages.find]
where = src

[setup.command.foo]
name = foo
commands =
    echo foo
[setup.command.bar]
name = bar
command =
    echo bar
[setup.command.baz]
name = baz
commands =
    echo baz

[build-system]
requires =
    setuptools >=38.6.0
    wheel >=0.31.0
build-backend = setuptools.build_meta
"""

# Generated at 2022-06-23 18:36:19.803934
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from operator import attrgetter

    setup_dir = '/home/vagrant/Projects/git/flutils'
    for config in each_sub_command_config(setup_dir):
        for attribute in ('name', 'camel', 'description', 'commands'):
            getattr(config, attribute)

        commands = list(config.commands)
        if commands:
            print(config.name)
            print('-' * len(config.name))
            for command in commands:
                print(command)
            print()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:36:22.086240
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    actual = next(each_sub_command_config('tests/setup_dir'), None)
    assert actual is not None
    assert actual.name == 'dev'



# Generated at 2022-06-23 18:36:27.583211
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual: SetupCfgCommandConfig = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    expect = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert actual == expect

# Generated at 2022-06-23 18:36:39.613101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from unittest.mock import Mock

    # Make sure the function works without args.
    with patch('os.path.isfile') as mock_isfile:
        mock_isfile.return_value = True
        with patch('os.path.expanduser') as mock_expanduser:
            mock_expanduser.return_value = '~'
            with patch('flutils.setuputils.ConfigParser') as mock_cfg:
                mock_cfg.return_value = cfg = Mock()
                cfg.read.return_value = None

# Generated at 2022-06-23 18:36:41.911615
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert isinstance(SetupCfgCommandConfig('name', 'camel', 'desc', ('com',)), SetupCfgCommandConfig)

# Generated at 2022-06-23 18:36:53.785167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from pathlib import Path
    from tempfile import mkdtemp

    class EachSubCommandConfigTestCase(UnitTestBase):
        def setUp(self):
            self.root_dir = mkdtemp()
            self.setup_cfg_path = Path(self.root_dir, 'setup.cfg')
            self.setup_commands_cfg_path = Path(self.root_dir,
                                                'setup_commands.cfg')
            self.setup_dir = Path(self.root_dir)

        def tearDown(self):
            super().tearDown()
            self.setup_cfg_path.unlink(missing_ok=True)
            self.setup_commands_cfg_path.unlink(missing_ok=True)

# Generated at 2022-06-23 18:36:56.291820
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'Description', ('Cmd1', 'Cmd2'))
