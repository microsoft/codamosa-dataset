

# Generated at 2022-06-23 18:27:02.097338
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'Test Description'
    commands = ('Test Commands',)
    config = SetupCfgCommandConfig(name, camel, description, tuple(commands))
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:27:07.321948
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.abspath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..'
    ))
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:08.830093
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: This unit test needs to be written.
    pass

# Generated at 2022-06-23 18:27:18.796349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '../../../../flutils'
    ))
    for scc in each_sub_command_config(path):
        assert isinstance(scc, SetupCfgCommandConfig)
        assert scc.name
        assert scc.camel
        assert scc.description
        assert scc.commands


# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-23 18:27:24.262099
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('name', 'Camel', 'description',
                                ('command1', 'command2'))
    assert cmd.name == 'name'
    assert cmd.camel == 'Camel'
    assert cmd.description == 'description'
    assert cmd.commands == ('command1', 'command2')



# Generated at 2022-06-23 18:27:34.451850
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest

    class FakeModule(object):
        def __init__(self):
            self._setup_py_file = None

        def __file__(self):
            if self._setup_py_file is None:
                raise AttributeError('FakeModule instance has no attribute __file__')
            return self._setup_py_file

        @property
        def setup_py_file(self):
            return self._setup_py_file

        @setup_py_file.setter
        def setup_py_file(self, value):
            self._setup_py_file = value

    """Test for :func:`each_sub_command_config`"""

# Generated at 2022-06-23 18:27:40.353030
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    actual = config.name
    expected = 'name'
    assert actual == expected
    actual = config.camel
    expected = 'camel'
    assert actual == expected
    actual = config.description
    expected = 'description'
    assert actual == expected
    actual = config.commands
    expected = ('commands',)
    assert actual == expected

# Generated at 2022-06-23 18:27:47.329668
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_command_name'
    camel = 'TestCommandName'
    description = 'test_command_description'
    commands = ('test_command1', 'test_command2')
    output = SetupCfgCommandConfig(name, camel, description, commands)

    assert output.name == name
    assert output.camel == camel
    assert output.description == description
    assert output.commands == commands

# Generated at 2022-06-23 18:27:56.583263
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Unit test for constructor of class SetupCfgCommandConfig with no args
    with pytest.raises(TypeError):
        SetupCfgCommandConfig()

    # Unit test for constructor of class SetupCfgCommandConfig with only args
    with pytest.raises(TypeError):
        SetupCfgCommandConfig('name', 'camel', 'description')

    # Unit test for constructor of class SetupCfgCommandConfig
    x = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('a', 'b', 'c')
    )
    assert x.name == 'name'
    assert x.camel == 'camel'
    assert x.description == 'description'
    assert x.commands == ('a', 'b', 'c')

# Generated at 2022-06-23 18:28:07.470476
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test that `each_sub_command_config` returns all of the sub-commands and
    the correct number of items.
    """
    my_dir = os.path.dirname(__file__)
    assert my_dir
    result: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(my_dir)
    )
    assert len(result) == 2
    assert result[0] == SetupCfgCommandConfig(
        name='test_setup_commands',
        camel='TestSetupCommands',
        description='',
        commands=('echo $PWD', 'echo $HOME')
    )

# Generated at 2022-06-23 18:28:12.528838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.abspath(os.path.dirname(__file__))
    dir_path = os.path.realpath(os.path.join(dir_path, '..'))
    parent_dir = os.path.dirname(dir_path)
    for config in each_sub_command_config(parent_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:15.300136
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    for sc in each_sub_command_config():
        print(sc)


if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:28:22.104347
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Constructor of SetupCfgCommandConfig
    def test_constructor():
        # Default values
        cfg = SetupCfgCommandConfig('name', 'camel', 'description', ('cmds',))
        assert cfg.name == 'name'
        assert cfg.camel == 'camel'
        assert cfg.description == 'description'
        assert cfg.commands == ('cmds',)
    test_constructor()


# Generated at 2022-06-23 18:28:27.081944
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b', 'c'))
    assert result
    assert result.name == 'name'
    assert result.description == 'description'
    assert result.camel == 'Camel'
    assert result.commands == ('a', 'b', 'c')

# Generated at 2022-06-23 18:28:31.541203
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestCamel'
    description = 'test description'
    commands = ('command1',)
    expected = SetupCfgCommandConfig(name, camel, description, commands)
    assert isinstance(expected, SetupCfgCommandConfig)
    actual = SetupCfgCommandConfig(name, camel, description, commands)
    assert expected == actual


# Generated at 2022-06-23 18:28:41.591674
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Tests that the ``setup_cfg_command_config()`` function raises an
    # exception when the given 'setup_dir' parameter is NOT a directory
    # that contains both a 'setup.py' and a 'setup.cfg' file.
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config('/invalid-path'))

    # Tests that the ``setup_cfg_command_config()`` function raises an
    # exception when the given 'setup_dir' parameter is NOT a directory
    # that contains a 'setup.py' file.
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = os.path.realpath(temp_dir)
        path = os.path.join(temp_dir, 'setup.cfg')

# Generated at 2022-06-23 18:28:54.152449
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import ensure_directory
    from shutil import copy
    from tempfile import TemporaryDirectory
    from types import ModuleType

    test_module_pth = os.path.realpath(__file__)
    test_module_d = os.path.dirname(test_module_pth)
    test_data_d = os.path.join(test_module_d, 'test_data')

    with TemporaryDirectory(prefix='flutils-') as td:
        td = os.path.realpath(td)
        # Copying over the setup.py and setup.cfg file
        src = os.path.join(test_data_d, 'setup.py')
        dst = os.path.join(td, 'setup.py')
        copy(src, dst)

# Generated at 2022-06-23 18:28:58.003929
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        assert os.path.isfile(os.path.join(setup_dir, config.name)) is True


# Generated at 2022-06-23 18:29:05.947433
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        cmd = SetupCfgCommandConfig('name', 'camel', 'description')
        assert False
    except TypeError:
        assert True
    cmd = SetupCfgCommandConfig('name', 'camel', 'description', 'cmd')
    assert isinstance(cmd.name, str)
    assert isinstance(cmd.camel, str)
    assert isinstance(cmd.description, str)
    assert isinstance(cmd.commands, tuple)
    assert cmd.commands == ('cmd',)


# Generated at 2022-06-23 18:29:11.214603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest  # type: ignore
    import sys

    sys.modules.pop('setuptools', None)
    sys.modules.pop('setuptools.command', None)
    mod = sys.modules.pop('setuptools.command.register', None)
    if mod:
        reload(mod)

    mod = sys.modules.pop('setuptools.command.sdist', None)
    if mod:
        reload(mod)

    this_dir = os.path.dirname(os.path.realpath(__file__))

    for actual in each_sub_command_config(this_dir):
        actual = actual._asdict()
        assert actual.get('name')
        assert actual.get('camel')
        assert actual.get('description')
        assert actual.get('commands')


# Generated at 2022-06-23 18:29:16.234455
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert True and SetupCfgCommandConfig(
        cmd_name='flutils.setup_commands.one.two.three',
        camel='OneTwoThree',
        description='Do One Thing',
        commands=tuple(['echo 1'])
    )


# Generated at 2022-06-23 18:29:20.960970
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'a', 'b', 'c', ('d', 'e', 'f')
    ) == SetupCfgCommandConfig(
        'a', 'b', 'c', ('d', 'e', 'f')
    )


# Generated at 2022-06-23 18:29:27.123318
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        name='foo.bar',
        camel='FooBar',
        description='foo bar baz',
        commands=('foo', 'bar', 'baz')
    )
    assert sccc.name == 'foo.bar'
    assert sccc.camel == 'FooBar'
    assert sccc.description == 'foo bar baz'
    assert sccc.commands == ('foo', 'bar', 'baz')

# Generated at 2022-06-23 18:29:38.730789
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Arrange
    parser = ConfigParser()
    setup_cfg_path = '/tmp/setup.cfg'
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'proj_name')
    format_kwargs: Dict[str, str] = {
        'setup_dir': '/tmp',
        'name': parser.get('metadata', 'name'),
        'home': os.path.expanduser('~')
    }
    parser.add_section('setup.command.foo')
    parser.set('setup.command.foo', 'command', 'echo foo')
    parser.set('setup.command.foo', 'name', 'foo_name')

# Generated at 2022-06-23 18:29:49.628235
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    def write_setup_commands_cfg(fh):
        fh.write(b'''\
[setup.command.command]

[setup.command.commands]
commands =
    {setup_dir}/foo
''')

    def write_setup_cfg(fh):
        fh.write(b'''\
[metadata]
name =
    foo.bar

[setup.command.test]
commands =
    {setup_dir}/test

[setup.command.test.test]
commands =
    {setup_dir}/test_test

[setup.command.test.test.test]
commands =
    {setup_dir}/test_test_test
''')


# Generated at 2022-06-23 18:29:51.774791
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('a', 'b', 'c', ('d',))  # noqa

# Generated at 2022-06-23 18:30:02.855671
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _name_cnt(name: str) -> int:
        return len(list(filter(None, name.splitlines())))

    kwargs: Dict[str, Optional[Union[os.PathLike, str]]] = {
        'setup_dir': None
    }
    setup_dir = _prep_setup_dir(kwargs['setup_dir'])
    parser = ConfigParser()
    parser.read(os.path.join(setup_dir, 'setup_commands.cfg'))
    format_kwargs: Dict[str, str] = {
        'setup_dir': setup_dir,
        'name': _get_name(parser, os.path.join(setup_dir, 'setup.cfg')),
        'home': os.path.expanduser('~')
    }

# Generated at 2022-06-23 18:30:08.950004
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'hey',
        'Hey',
        'This is a description',
        (
            'ls -l',
            'cd ..'
        )
    )
    assert setup_cfg_command_config.name == 'hey'
    assert setup_cfg_command_config.camel == 'Hey'
    assert setup_cfg_command_config.description == 'This is a description'
    assert setup_cfg_command_config.commands == (
        'ls -l',
        'cd ..'
    )

# Generated at 2022-06-23 18:30:16.799558
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    path = os.path.join(here, 'setup_commands.cfg')
    cfg = ConfigParser()
    cfg.read(path)
    format_kwargs = {
        'setup_dir': os.path.dirname(path),
        'home': os.path.expanduser('~'),
        'name': 'project-name',
    }
    for sc in _each_setup_cfg_command(cfg, format_kwargs):
        print(sc)

# Generated at 2022-06-23 18:30:22.611598
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: str = os.path.dirname(os.path.dirname(__file__))
    for command_cfg in each_sub_command_config(setup_dir):
        print(command_cfg.name)
        print(command_cfg.description)
        print(command_cfg.commands)
        print()

# Generated at 2022-06-23 18:30:26.207189
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config(setup_dir='setup.py'):
        assert sc.name
        assert sc.camel
        assert sc.description
        assert sc.commands

# Generated at 2022-06-23 18:30:33.512019
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    s = StringIO()
    print('test_each_sub_command_config()', file=s)
    for config in each_sub_command_config():
        print(
            f'    Name: {config.name!r}',
            f'Camel: {config.camel!r}',
            f'Description: {config.description!r}',
            f'Commands: {config.commands!r}',
            file=s
        )
    print(s.getvalue())
    s.close()
    if os.path.isfile('test.log'):
        with open('test.log', 'r') as f:
            tst = f.read()
            assert tst.strip() == s.getvalue().strip()


if __name__ == '__main__':
    test_each_

# Generated at 2022-06-23 18:30:43.189815
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    from tests.test_setup_commands import TEST_COMMANDS
    command_name = 'foo'
    command = TEST_COMMANDS[command_name]
    command_camel = 'Foo'
    command_desc = command.description
    config = SetupCfgCommandConfig(
        command_name,
        command_camel,
        command_desc,
        tuple(command.commands)
    )
    assert config.name == command_name
    assert config.camel == command_camel
    assert config.description == command_desc
    assert config.commands == tuple(command.commands)
    with pytest.raises(ValueError):
        _ = SetupCfgCommandConfig('foo', 'bar', '', tuple())

# Generated at 2022-06-23 18:30:46.910160
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig("name", "camel", "desc", ("cmd1", "cmd2"))
    assert isinstance(cmd, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:30:49.755748
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    for i in each_sub_command_config('./setup_cfg_commands'):
        pprint(i)



# Generated at 2022-06-23 18:30:53.591520
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('name', 'Camel', 'description', ('commands'))
    except:
        assert False
    else:
        assert True


if __name__ == '__main__':
    from pprint import pprint
    pprint(
        list(each_sub_command_config(
            os.path.join(os.path.dirname(__file__), '..')
        ))
    )

# Generated at 2022-06-23 18:31:02.693604
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat
    from tempfile import TemporaryDirectory

    from flutils.fileutils import write_file

    with TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        setup_cfg = '''
[metadata]
name = {name}

[options]
setup_commands =
    build
    bdist
    bdist_wheel
    develop
    install
    upload
    clean
'''

# Generated at 2022-06-23 18:31:13.398136
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'test description'
    commands = ('commands',)
    assert SetupCfgCommandConfig(name, camel, description, commands).name == name
    assert SetupCfgCommandConfig(name, camel, description, commands).camel == camel
    assert SetupCfgCommandConfig(name, camel, description, commands).description == description
    assert SetupCfgCommandConfig(name, camel, description, commands).commands == commands


if __name__ == '__main__':
    from argparse import ArgumentParser, RawTextHelpFormatter
    from pprint import pprint

    parser = ArgumentParser(
        prog='python -m flutils.setup_command_config',
        description='Generate setup command config.',
        formatter_class=RawTextHelpFormatter
    )

# Generated at 2022-06-23 18:31:25.835883
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from io import StringIO
    from flutils.fileutils import expand_file_args

    def _run(
            params: Dict[str, str],
            options: Dict[str, str],
            commands: List[str],
    ) -> Tuple[str, str]:
        out_buff = StringIO()
        option_buf = StringIO()
        cmd_buf = StringIO()

        print("SetupDir:", params['setup_dir'], file=out_buff)
        print("Home    :", params['home'], file=out_buff)
        print("Name    :", params['name'], file=out_buff)
        print("Options :", file=out_buff)

# Generated at 2022-06-23 18:31:36.955229
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    cwd = os.path.dirname(os.path.abspath(__file__))
    cwd = os.path.join(cwd, 'data')
    expected: List[SetupCfgCommandConfig] = []
    with patch('os.path.abspath', return_value=os.path.join(cwd, 'project')):
        with patch('os.path.expanduser', return_value=cwd):
            for sc in each_sub_command_config():
                expected.append(
                    SetupCfgCommandConfig(
                        sc.name,
                        sc.camel,
                        sc.description,
                        sc.commands
                    )
                )

# Generated at 2022-06-23 18:31:37.716640
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass

# Generated at 2022-06-23 18:31:49.148772
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        'tests', 'fixtures'
    )
    for cmd in each_sub_command_config(setup_dir):
        cmd_name = cmd[0]
        if cmd_name == 'build.wheel':
            assert cmd[1] == 'BuildWheel'
            assert cmd[2] == 'Builds the wheel package'
            assert cmd[3] == ('python setup.py bdist_wheel',)
        elif cmd_name == 'build.source':
            assert cmd[1] == 'BuildSource'
            assert cmd[2] == 'Builds the source package'
            assert cmd[3] == ('python setup.py sdist',)

# Generated at 2022-06-23 18:32:00.907694
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyPackageRequirements
    import pytest
    import sys

    setup_dir, = sys.path

    with pytest.raises(RuntimeError):
        for config in each_sub_command_config(setup_dir=setup_dir):
            # This should NOT iterate...
            pass

    with pytest.raises(RuntimeError):
        for config in each_sub_command_config(setup_dir=setup_dir):
            # This should NOT iterate...
            pass

    cast(str, sys.path.pop(0))
    assert sys.path[0] == setup_dir

    for config in each_sub_command_config(setup_dir=setup_dir):
        assert config.name.startswith('setup.sub_command_') is True

# Generated at 2022-06-23 18:32:11.389232
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out: List[SetupCfgCommandConfig] = list(each_sub_command_config(
        os.path.dirname(__file__)
    ))
    assert len(out) == 8
    assert str(out[0]) == """
SetupCfgCommandConfig(name='clean',
                      camel='Clean',
                      description='Cleans the repository directory.',
                      commands=('rm -rf -- build', 'rm -rf -- dist', 'rm -rf -- *.egg'))
""".strip()

# Generated at 2022-06-23 18:32:19.667690
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=protected-access
    from pytest import raises
    from setuptools.command.sdist import sdist

    setup_dir = os.path.dirname(sdist.__file__)
    for config in each_sub_command_config(setup_dir):
        cmd = str(config.commands[0])
        assert cmd.startswith('python setup.py sdist')

    with raises(FileNotFoundError):
        each_sub_command_config('/path/to/nothing/setup.py')

    with raises(NotADirectoryError):
        each_sub_command_config(os.path.join(setup_dir, 'setup.py'))

# Generated at 2022-06-23 18:32:24.516240
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='blah blah blah',
        commands=('cmd1', 'cmd2')
    )
    assert obj.name == 'name'
    assert obj.camel == 'Camel'
    assert obj.description == 'blah blah blah'
    assert obj.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:32:36.380616
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def assert_equal(
            config: SetupCfgCommandConfig,
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        assert config.name == name
        assert config.camel == camel
        assert config.description == description
        assert config.commands == commands

    def assert_raise(
            *args,
            error: Exception,
            **kwargs
    ) -> None:
        try:
            each_sub_command_config(*args, **kwargs)
            assert False
        except error:
            assert True

    setup_dir = os.path.dirname(os.path.dirname(__file__))
    assert_raise(setup_dir, error=FileNotFoundError)
    setup_dir = os.path.join

# Generated at 2022-06-23 18:32:44.511466
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        setup_cfg_path = os.path.join(tmp_dir, 'setup.cfg')
        setup_py_path = os.path.join(tmp_dir, 'setup.py')
        setup_commands_cfg_path = os.path.join(tmp_dir, 'setup_commands.cfg')
        with open(setup_cfg_path, 'w') as fh:
            fh.write("[metadata]\n")
            fh.write("name = flutils\n")
            fh.write("\n")
            fh.write("[options]\n")
            fh.write("include_package_data=True\n")

# Generated at 2022-06-23 18:32:45.915422
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('cmd1', 'cmd2')
    )

# Generated at 2022-06-23 18:32:49.531983
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command',)

# Generated at 2022-06-23 18:33:00.553928
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cp1 = ConfigParser()
    cp1.optionxform = str

# Generated at 2022-06-23 18:33:04.628435
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print('config:', cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:10.764365
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    res = list(each_sub_command_config())
    logger.debug("res: %s", res)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:14.691806
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    args = (
        'hello.world',
        'HelloWorld',
        'hello world',
        ('echo "hello world"', 'echo "hello world 2"',)
    )
    assert SetupCfgCommandConfig(*args) == args

# Generated at 2022-06-23 18:33:25.426316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = []
    for obj in each_sub_command_config():
        assert isinstance(obj, SetupCfgCommandConfig)
        config.append(obj)

    assert len(config) == 2

    assert config[0].name == 'pip'
    assert config[0].camel == 'Pip'
    assert config[0].description == ''
    env = {
        'setup_dir': os.path.abspath(os.path.dirname(__file__)),
        'home': os.path.expanduser('~'),
        'name': 'flutils'
    }
    assert config[0].commands == ('pip install -e .',)

    assert config[1].name == 'test.nosetests'
    assert config[1].camel == 'TestNosetests'
    assert config

# Generated at 2022-06-23 18:33:38.263263
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    class str4(str):
        __slots__ = ()

        @property
        def __len__(self):
            return 4

    t = SetupCfgCommandConfig
    func = t.__init__
    assert func.__code__.co_varnames == ('self', 'name', 'camel', 'description',
                                         'commands')
    assert func.__code__.co_argcount == len(func.__code__.co_varnames)
    args = (str4('name'), 'camel', ['description'], ('commands',))
    obj = t(*args)
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('commands',)

# Generated at 2022-06-23 18:33:40.358541
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo', 'Foo', 'bar', ('baz', 'quux'))

# Generated at 2022-06-23 18:33:49.969900
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from flutils.pathutils import build_zip

    with TemporaryDirectory() as td:
        build_zip(
            td,
            'setup.cfg',
            dedent(
                """\
                [metadata]
                name = test-project
                [setup.command.foobar]
                name = foobar
                command = {home}/foobar
                [setup.command.foo-bar-too]
                name = foobar2
                command = {home}/foobar2
                """
            )
        )

# Generated at 2022-06-23 18:33:58.552952
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=redundant-unittest-assert
    # noinspection PyTypeChecker
    cfg: SetupCfgCommandConfig = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('/absolute/path/to/command',)
    )
    assert cfg.name == 'name'
    assert cfg.camel == 'Camel'
    assert cfg.description == 'description'
    assert isinstance(cfg.commands, tuple)
    assert cfg.commands == ('/absolute/path/to/command',)


# Generated at 2022-06-23 18:34:09.351063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Validates that each_sub_command_config() can find the
    setup.cfg file and load it.
    """
    configs_list = list(each_sub_command_config())
    if not configs_list:
        raise Exception('Unable to load the configuration.')
    print(configs_list[0])
    assert configs_list[0].name == configs_list[0].camel


if __name__ == '__main__':
    if len(sys.argv) > 1:
        setup_dir = os.path.realpath(sys.argv[1])
    else:
        setup_dir = None
    for config in each_sub_command_config(setup_dir):
        print(config)

# Generated at 2022-06-23 18:34:10.315781
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command1', 'command2'))


# Generated at 2022-06-23 18:34:16.108546
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'hello.world',
        'HelloWorld',
        'hello world',
        ('echo hello, world',)
    )
    assert config.name == 'hello.world'
    assert config.camel == 'HelloWorld'
    assert config.description == 'hello world'
    assert config.commands == ('echo hello, world',)
    assert config.name != 'HelloWorld'


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 18:34:20.767539
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    c = list(each_sub_command_config(os.path.dirname(__file__)))
    assert len(c) > 1
    assert 'hello' in [i.name for i in c]


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:24.730933
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "name"
    camel = "Camel"
    description = "description"
    commands = ["cmd1", "cmd2"]
    SetupCfgCommandConfig(name, camel, description, commands)



# Generated at 2022-06-23 18:34:35.900417
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import textwrap
    from tempfile import TemporaryDirectory

    from flutils.confutils import SubCommandConfig

    with TemporaryDirectory() as root_d, TemporaryDirectory(dir=root_d) as d:
        setup_dir = str(d)


# Generated at 2022-06-23 18:34:43.024202
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from test.helper import check_value
    from test.test_setup_commands import gen_setup_cfg_command_config
    for config in gen_setup_cfg_command_config():
        command_config = SetupCfgCommandConfig(**config)
        check_value(command_config.name, config['name'])
        check_value(command_config.camel, config['camel'])
        check_value(command_config.description, config['description'])

# Generated at 2022-06-23 18:34:52.840514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data/setup',
    )

    for i, cmds in enumerate(each_sub_command_config(test_dir)):
        assert isinstance(cmds, SetupCfgCommandConfig)
        assert isinstance(cmds.name, str)
        assert isinstance(cmds.camel, str)
        assert isinstance(cmds.description, str)
        assert isinstance(cmds.commands, tuple)
        for c in cmds.commands:
            assert isinstance(c, str)
    assert i == 4

# Generated at 2022-06-23 18:35:04.070380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    import tempfile
    import shutil
    import flutils.setuputils

    test_name = 'test_name'
    test_root_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:35:12.328042
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest.mock import patch

    config_path = '/path/to/setup.cfg'
    parser = ConfigParser()

    with patch.object(ConfigParser, 'read', autospec=True) as read:
        assert SetupCfgCommandConfig('name', 'Camel', 'Description', ('cmd',)) == \
            SetupCfgCommandConfig('name', 'Camel', 'Description', ('cmd',))

        read.return_value = parser
        assert len(list(_each_setup_cfg_command(parser, {'name': ''}))) == 0
        parser.add_section('metadata')
        assert len(list(_each_setup_cfg_command(parser, {'name': ''}))) == 0
        parser.set('metadata', 'name', '')

# Generated at 2022-06-23 18:35:17.245546
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dirpath = os.path.dirname(__file__)
    for config in each_sub_command_config(dirpath):
        assert isinstance(config, SetupCfgCommandConfig)
        for attr in config._fields:
            assert getattr(config, attr)



# Generated at 2022-06-23 18:35:29.209806
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""

    # setup.cfg
    # config = ConfigParser()
    # config['metadata'] = {'name': 'example project'}
    # config['setup.command.sdist'] = {'command': 'python setup.py sdist'}
    # with open('setup.cfg', 'w') as f:
    #     config.write(f)

    # setup_commands.cfg
    # config['setup.command.pypi'] = {
    #     'name': 'upload',
    #     'description': 'Upload to PyPI',
    #     'command': 'python setup.py sdist upload -r pypi',
    # }
    # config['setup.command.pypi.test'] = {
    #     'name': 'upload.test',


# Generated at 2022-06-23 18:35:40.854765
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch
    from flutils.pathutils import abspath, each_parent

    class TestClass(TestCase):
        def setUp(self) -> None:
            self._tmpdir = TemporaryDirectory()
            self._dir = str(self._tmpdir.__enter__())
            setup_dir = os.path.join(self._dir, 'example_package')
            os.makedirs(setup_dir)
            with open(os.path.join(setup_dir, 'setup.py'), 'w') as file:
                pass

# Generated at 2022-06-23 18:35:51.945792
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from itertools import islice

    from pytest import raises

    with raises(FileNotFoundError):
        list(each_sub_command_config())

    # As defined by the default setup.py and setup.cfg
    expected_commands = (
        'build',
        'build_ext',
        'build_py',
        'bdist_wheel',
        'clean',
        'develop',
        'install',
        'sdist'
    )
    assert tuple(expected_commands) == tuple(
        each_sub_command_config(setup_dir='.')
    )

    actual = list(each_sub_command_config(setup_dir='testsuite/testproj1'))

# Generated at 2022-06-23 18:35:57.265870
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(name="name", camel="Camel",
                                   description="description",
                                   commands=("cmd1", "cmd2"))
    assert scfgcc.name == "name"
    assert scfgcc.camel == "Camel"
    assert scfgcc.description == "description"
    assert scfgcc.commands == ("cmd1", "cmd2")



# Generated at 2022-06-23 18:36:04.367786
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.dirname(current_dir)
    each_sub_command_config(setup_dir)
    try:
        each_sub_command_config(setup_dir + 'not_a_dir')
    except FileNotFoundError as e:
        assert str(e) == "The given 'setup_dir' of %r does NOT exist." % (
            setup_dir + 'not_a_dir')
    else:
        raise AssertionError(
            "expected %r to raise %s"
            % ('each_sub_command_config', FileNotFoundError.__name__)
        )

# Generated at 2022-06-23 18:36:08.384785
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    tt = SetupCfgCommandConfig(1, '', '', ())
    assert tt.name == 1
    assert tt.camel == ''
    assert tt.description == ''
    assert tt.commands == ()



# Generated at 2022-06-23 18:36:13.217857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pkgutils import get_parent_dir

    setup_dir = get_parent_dir(__file__, anchor=__file__)
    for config in each_sub_command_config(setup_dir):
        # pylint: disable=expression-not-assigned
        config.name
        config.camel
        config.description
        config.commands

# Generated at 2022-06-23 18:36:22.097655
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # This is the root of this project.
    setup_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    actual = list(each_sub_command_config(setup_dir))

# Generated at 2022-06-23 18:36:33.663113
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Path to the directory that contains the project's setup.py file
    setup_dir = os.path.dirname(os.path.dirname(__file__))

    for index, config in enumerate(each_sub_command_config(setup_dir)):

        if index == 0:
            assert config.name == 'flutils.test'
            assert config.camel == 'Test'
            assert config.description == ''
            assert config.commands == (
                'python -m unittest discover -s %(setup_dir)s',)
        elif index == 1:
            assert config.name == 'flutils.test.other'
            assert config.camel == 'TestOther'
            assert config.description == ''

# Generated at 2022-06-23 18:36:35.929607
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('n', 'N', 'D', ('C',))

# Generated at 2022-06-23 18:36:40.582857
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.setuputils import each_sub_command_config
    from flutils.collections import each_namedtuple

    cfg = None

    for cfg in each_namedtuple(each_sub_command_config(), SetupCfgCommandConfig):
        pass

    assert cfg.name == 'license'

# Generated at 2022-06-23 18:36:48.651526
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.normpath(
        os.path.join(
            os.path.dirname(__file__),
            '../../..',
        )
    )
    assert os.path.exists(setup_dir), setup_dir
    cnt = 0
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig), config
        cnt += 1
    assert cnt >= 2



# Generated at 2022-06-23 18:36:54.846231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    OUTPUT: List[SetupCfgCommandConfig] = []
    for cfg in each_sub_command_config('tests/data/1'):
        OUTPUT.append(cfg)
    assert len(OUTPUT) == 1
    assert OUTPUT[0] == SetupCfgCommandConfig(
        name='example.foo',
        camel='ExampleFoo',
        description='Runs the command, "foo".',
        commands=('pip install .', 'foo')
    )



# Generated at 2022-06-23 18:37:04.970903
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import sys
    import os
    import random
    import string

    test_root = os.path.dirname(sys.argv[0])
    test_data = os.path.join(test_root, 'data')

    fields = 'name', 'camel', 'description', 'commands'

    def _gen_args() -> Generator[List, None, None]:
        """Generate a list of arguments for the constructor of
        class ``SetupCfgCommandConfig``."""