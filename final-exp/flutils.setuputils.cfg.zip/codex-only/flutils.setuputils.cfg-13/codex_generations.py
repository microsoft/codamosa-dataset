

# Generated at 2022-06-23 18:26:59.160975
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig(name="", camel="", description="", commands=()),



# Generated at 2022-06-23 18:27:10.748781
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # pylint: disable=protected-access
    from unittest.mock import Mock

    config = SetupCfgCommandConfig(None, None, None, None)
    assert isinstance(config._fields, tuple)
    assert len(config._fields) == 4

    cmd_name, _, description, commands = config
    assert isinstance(cmd_name, str)
    assert isinstance(description, str)
    assert isinstance(commands, tuple)
    for command in commands:
        assert isinstance(command, str)

    # No args
    config = SetupCfgCommandConfig()
    cmd_name, _, description, commands = config
    assert cmd_name == ''
    assert description == ''
    assert commands == ()

    # Single arg
    config = SetupCfgCommandConfig(Mock())
    cmd_name, _

# Generated at 2022-06-23 18:27:14.651705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
    except FileNotFoundError:
        pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:18.489023
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    test = SetupCfgCommandConfig('', '', '', (''))
    assert len(test) == 4
    assert test.name == ''
    assert test.camel == ''
    assert test.description == ''
    assert test.commands == ('',)

# Generated at 2022-06-23 18:27:21.751773
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description',
                                   ('distutils.cmd', 'sdist'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('distutils.cmd', 'sdist')



# Generated at 2022-06-23 18:27:28.780425
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from datetime import datetime

    config = SetupCfgCommandConfig(
        name="test",
        camel="Test",
        description="This is a test",
        commands=("test", "test")
    )
    assert config.name == "test"
    assert config.camel == "Test"
    assert config.description == "This is a test"
    assert config.commands == ("test", "test")
    print(datetime.now())

# Generated at 2022-06-23 18:27:35.266951
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('a', 'b', 'c', '1')
    assert config.name == 'a', "The 'name' field of SetupCfgCommandConfig does not match"
    assert config.camel == 'b', "The 'camel' field of SetupCfgCommandConfig does not match"
    assert config.description == 'c', "The 'description' field of SetupCfgCommandConfig does not match"
    assert config.commands == ('1',), "The 'commands' field of SetupCfgCommandConfig does not match"

# Generated at 2022-06-23 18:27:41.479733
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # test for 'setup.cfg' file
    setup_cfg_command_configs = each_sub_command_config('../../..')
    for config in setup_cfg_command_configs:
        with open('./commands.txt', 'a') as f:
            f.write("'{0}', '{1}', '{2}', {3}".format(
                config.name, config.camel, config.description, config.commands
            ) + '\n')
        print("'{0}', '{1}', '{2}', {3}".format(
            config.name, config.camel, config.description, config.commands
        ))
    # test for 'setup_commands.cfg' file

# Generated at 2022-06-23 18:27:52.157187
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    setup_cfg = r"""
[metadata]
name = flutils
version = 1.0.0
author = Bruce Frederiksen
author-email = bruce@fandekasp.com
url = https://github.com/BruceFrederiksen/flutils

[options]
py_modules = flutils
"""

    with tempfile.TemporaryDirectory() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'flutils')
        os.makedirs(setup_dir)

        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python\n')


# Generated at 2022-06-23 18:28:00.161092
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def assert_setup_cfg_command_config(
            value: SetupCfgCommandConfig,
            exp_value: SetupCfgCommandConfig
    ) -> None:
        assert value.name == exp_value.name
        assert value.camel == exp_value.camel
        assert value.description == exp_value.description
        assert value.commands == exp_value.commands


# Generated at 2022-06-23 18:28:08.334508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .utils import get_tests_directory
    tests_dir = get_tests_directory()
    out = list(each_sub_command_config(tests_dir))
    assert out == [
        SetupCfgCommandConfig(
            'flutils.travis.config',
            'FlutilsTravisConfig',
            '',
            ('flutils travis config',),
        )
    ]
    out = list(each_sub_command_config())
    assert out == [
        SetupCfgCommandConfig(
            'flutils.travis.config',
            'FlutilsTravisConfig',
            '',
            ('flutils travis config',),
        )
    ]

# Generated at 2022-06-23 18:28:15.061667
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config('../flutils/'):
        cmd = item.commands[0]
        if cmd.startswith('python'):
            cmd, _, _ = cmd.partition(' ')
            cmd = cmd.strip()
        cmd = os.path.basename(cmd)
        if cmd.startswith('./'):
            cmd = cmd[2:]
        assert item.name == cmd, (item.name, cmd)



# Generated at 2022-06-23 18:28:21.752585
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert tuple(
        each_sub_command_config(setup_dir=os.path.expanduser('~/Projects/flutils'))
    )


if __name__ == '__main__':
    from os import chdir
    from pprint import pprint
    chdir(os.path.expanduser('~/Projects/flutils'))
    pprint(list(each_sub_command_config()))

# Generated at 2022-06-23 18:28:30.363800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    import tempfile

    class ExpectedResults(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    here = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-23 18:28:37.477517
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'test_data', 'mock_setup_pkg')
    configs = list(each_sub_command_config(path))
    assert len(configs) == 1
    config = configs[0]
    assert config.name == 'test.sub_command_1'
    assert config.camel == 'TestSubCommand1'
    assert config.description == 'test.sub_command_1 desc'
    assert config.commands[0] == 'echo "sub command 1"'

# Generated at 2022-06-23 18:28:45.235864
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    config = SetupCfgCommandConfig('test', 'Test', 'test command', ('test',))
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test command'
    assert config.commands == ('test',)
    with pytest.raises(ValueError):
        SetupCfgCommandConfig('name', 'Test', 'test command', ('test',))
    with pytest.raises(ValueError):
        SetupCfgCommandConfig('test', 'Camel', 'test command', ('test',))
    with pytest.raises(ValueError):
        SetupCfgCommandConfig('test', 'Test', 'test command', ('test',))

# Generated at 2022-06-23 18:28:57.746326
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    setup_dir = os.path.dirname(__file__)
    assert os.path.basename(setup_dir) == 'testing'
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.join(setup_dir, 'command_setup')
    with os.scandir(setup_dir) as it:
        for dir_entry in it:
            if dir_entry.is_dir():
                setup_dir = os.path.join(dir_entry.path, 'setup')
                os.chdir(setup_dir)

# Generated at 2022-06-23 18:29:04.600716
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from collections import namedtuple
    cmd_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command1',)
    )
    assert cmd_config.name == 'name'
    assert cmd_config.camel == 'camel'
    assert cmd_config.description == 'description'
    assert cmd_config.commands == ('command1',)
    # Check that the class can be used as a tuple.
    d = {'name': 'name', 'camel': 'camel', 'description': 'description',
         'commands': ('command1',)}
    d2 = dict(cmd_config)
    assert d == d2
    # Check that the class can be used as a namedtuple.

# Generated at 2022-06-23 18:29:16.808915
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Check setup dir
    setup_dir = _prep_setup_dir()
    assert os.path.exists(setup_dir)
    assert os.path.isdir(setup_dir)
    assert os.path.isfile(os.path.join(setup_dir, 'setup.cfg'))
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py'))

    # Check parser output
    parser = ConfigParser()
    parser.read(os.path.join(setup_dir, 'setup.cfg'))
    assert 'metadata' in parser.sections()
    assert 'name' in parser.options('metadata')

    # Check function output
    config = None
    for config in each_sub_command_config(setup_dir):
        pass
    assert config

# Generated at 2022-06-23 18:29:27.612561
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import sys

    path = os.path.abspath(__file__)
    flutils_dir = os.path.dirname(os.path.dirname(path))
    cmd = os.path.join(flutils_dir, 'setup_commands.cfg')
    with io.StringIO() as buf:
        with open(cmd, 'r') as f:
            buf.write(f.read())
        buf.write("""
[setup.command.direct]
name=dir
command=dir
 
[setup.command.direct.second]
name=dir
command=dir

[setup.command.direct.third]
description=dir
commands=dir
""")
        buf.seek(0)
        sys.stdin = buf

# Generated at 2022-06-23 18:29:39.133091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def test_each_sub_command_config(self):
            setup_dir = tempfile.TemporaryDirectory()
            setup_dir = setup_dir.name
            setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')


# Generated at 2022-06-23 18:29:43.773889
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.dirname(path)
    commands = list(each_sub_command_config(path))
    assert len(commands) > 0
    assert all([
        command.name == 'setup.py c'
        for command in commands
    ])

# Generated at 2022-06-23 18:29:47.415072
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='test',
        camel='test',
        description='test',
        commands=('test', 'test2')
    )
    assert obj.name == 'test'
    assert obj.camel == 'test'
    assert obj.description == 'test'
    assert obj.commands == ('test', 'test2')

# Generated at 2022-06-23 18:29:54.861857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    assert os.path.isdir(setup_dir)
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py'))
    assert os.path.isfile(os.path.join(setup_dir, 'setup.cfg'))
    assert os.path.isfile(os.path.join(setup_dir, 'setup_commands.cfg'))


# Generated at 2022-06-23 18:29:56.712507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert isinstance(each_sub_command_config(), Generator)



# Generated at 2022-06-23 18:30:05.885725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import CmdResult
    from flutils.pathutils import chdir

    with chdir('tests/resources/setup_commands'):
        for config in each_sub_command_config():
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            assert all(
                isinstance(x, str)
                for x in config.commands
            )

# Generated at 2022-06-23 18:30:10.171762
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    config = SetupCfgCommandConfig(
        'name',
        'camelName',
        'description',
        ['cmd1', 'cmd2'],
    )
    assert config.name == 'name'
    assert config.camel == 'camelName'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')


# Generated at 2022-06-23 18:30:17.511910
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Test description',
        commands=('test command',)
    )
    assert setup_cfg_command_config.name == 'test'
    assert setup_cfg_command_config.camel == 'Test'
    assert setup_cfg_command_config.description == 'Test description'
    assert setup_cfg_command_config.commands == ('test command',)


# Generated at 2022-06-23 18:30:21.853470
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        name="test",
        camel="test",
        description="test",
        commands=("test","test")
    )
    assert command_config.name == "test"
    assert command_config.camel == "test"
    assert command_config.description == "test"
    assert command_config.commands == ("test","test")



# Generated at 2022-06-23 18:30:24.797295
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config())


if __name__ == '__main__':
    sys.exit(pytest.main(__file__))

# Generated at 2022-06-23 18:30:26.999858
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    assert 'flpk' in {c.name for c in each_sub_command_config()}

# Generated at 2022-06-23 18:30:29.264275
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # ToDo: Setup a test repo in the current directory and write a test
    #       that ensures the each_sub_command_config works as expected.
    pass

# Generated at 2022-06-23 18:30:34.251944
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    commands = [
        './setup.py build',
        './setup.py sdist',
    ]
    command = SetupCfgCommandConfig(
        'build.sdist',
        'BuildSdist',
        'Build the source dist.',
        tuple(commands)
    )
    assert command.name == 'build.sdist'
    assert command.camel == 'BuildSdist'
    assert command.description == 'Build the source dist.'
    assert command.commands == tuple(commands)

# Generated at 2022-06-23 18:30:43.716367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from runpy import run_module

    with patch('sys.path', [
            os.path.join(os.path.dirname(__file__), 'test/test_proj')
    ]):
        mod = run_module('setup', run_name='__main__')
    original = tuple(mod['cmdclass'].keys())
    original = tuple(sorted(original, key=lambda x: len(x), reverse=True))

    tmp_dir = os.path.join(os.path.dirname(__file__), 'tmp')
    if os.path.exists(tmp_dir):
        rmtree(tmp_dir, ignore_errors=True)
    configs = tuple(each_sub_command_config(setup_dir=tmp_dir))
    assert len(configs) == 2
    assert configs

# Generated at 2022-06-23 18:30:56.047346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    root = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', '..', 'flutils', 'tests'
        )
    )
    sys.path.insert(0, str(root))
    import test_files
    import os
    import shutil
    import tempfile
    import filecmp

# Generated at 2022-06-23 18:31:05.682806
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'setup_cfg_tests')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.camel is not None
        assert config.name is not None
        assert config.description is not None
        assert config.commands is not None
        assert len(config.commands) == 2
        for cmd in config.commands:
            assert cmd is not None


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:08.840969
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig("name", "camel", "desc", ("c1", "c2", "c3"))
    assert isinstance(scfgcc, SetupCfgCommandConfig)

# Generated at 2022-06-23 18:31:13.687595
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the constructor of `SetupCfgCommandConfig`."""
    o = SetupCfgCommandConfig(
        name='spam', camel='Spam',
        description='description', commands=('command1', 'command2')
    )
    assert isinstance(o, SetupCfgCommandConfig)
    assert o.name == 'spam'
    assert o.camel == 'Spam'
    assert o.description == 'description'
    assert o.commands == ('command1', 'command2')



# Generated at 2022-06-23 18:31:20.230991
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-23 18:31:22.414221
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('cmd_name', 'CmdName', 'desc', ('cmd', ))



# Generated at 2022-06-23 18:31:31.251487
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    assert isinstance(gen, Generator)
    config = next(gen)
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'upload-dev'
    assert config.camel == 'UploadDev'
    assert config.description == 'Upload to TestPyPI'
    assert config.commands
    assert isinstance(config.commands, tuple)
    assert isinstance(config.commands, tuple)
    assert 'twine upload --repository-url https://test.pypi.org/legacy/ dist/*' in config.commands
    config = next(gen)
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'upload'
    assert config.camel == 'Upload'

# Generated at 2022-06-23 18:31:39.470399
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Verify the constructor of class ``SetupCfgCommandConfig``."""
    fields = SetupCfgCommandConfig.__fields__
    assert fields == ('name', 'camel', 'description', 'commands')
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('one',))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('one',)



# Generated at 2022-06-23 18:31:50.944906
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    def main(setup_dir: Optional[str] = None) -> None:
        """An example unit test for the function ``each_sub_command_config``.
        """
        kwargs: Dict[str, Union[str, None]] = {}
        if setup_dir is not None:
            kwargs['setup_dir'] = setup_dir
        out = []
        for sub_cfg in each_sub_command_config(**kwargs):
            sub_cfg = cast(SetupCfgCommandConfig, sub_cfg)
            out.append(sub_cfg)
        pprint(out)

    main('/Users/jeffsmith/projects/flutils')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:52.400259
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('abc', 'abc', 'abc', ('abc', 'abc'))

# Generated at 2022-06-23 18:32:03.946784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import sys

    setup_dir = os.path.abspath(os.path.dirname(__file__))
    setup_cfg = io.StringIO('''\
[metadata]
name = flutils

[setup.command.foo]
commands =
  foo
  bar

[setup.command.foo.bar]
commands =
  foo
  bar
  baz
  buz

[setup.command.foo.bar.baz]
commands =
  foo
  bar

[setup.command.foo.bar.baz.buz]
commands =
  foo
''')
    setup_cfg.seek(0)

    sys.path.append(setup_dir)

# Generated at 2022-06-23 18:32:15.655207
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', (''))
        assert False, "It should raise ValueError, but not."
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('name', '', '', (''))
        assert False, "It should raise ValueError, but not."
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('name', 'Camel', '', (''))
        assert False, "It should raise ValueError, but not."
    except ValueError:
        pass
    try:
        SetupCfgCommandConfig('name', 'Camel', 'Desc', (''))
        assert False, "It should raise ValueError, but not."
    except ValueError:
        pass

# Generated at 2022-06-23 18:32:26.339480
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import unittest
    import io
    import configparser
    class Test_SetupCfgCommandConfig(unittest.TestCase):
        def do_test_SetupCfgCommandConfig(
                self,
                s: str,
                expected: Tuple[str, ...]
        ) -> None:
            parser = configparser.ConfigParser()
            parser.read_string(s)
            for e in _each_setup_cfg_command(parser, {}):
                got = (
                    e.name,
                    e.camel,
                    e.description,
                    *e.commands
                )
                self.assertEqual(got, expected)

# Generated at 2022-06-23 18:32:37.964457
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import random
    import string
    import tempfile

    for setup_dir in [None, tempfile.gettempdir()]:
        for setup_cfg_path in list({random.choice(
                (None, 'setup.cfg', 'setup_commands.cfg'))}):
            config = next(each_sub_command_config(setup_dir), None)
            assert config is None

        setup_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 18:32:43.960872
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    path = os.path.join(here, 'setup.cfg')
    parser = ConfigParser()
    parser.read(path)
    setup_dir = os.path.dirname(path)
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)
    for config in _each_setup_cfg_command(parser, format_kwargs):
        print(config)

# Generated at 2022-06-23 18:32:51.781828
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('foo', 'Foo', '', ())
    SetupCfgCommandConfig('foo', 'Foo', '', ('',))
    SetupCfgCommandConfig('foo', 'Foo', '', ('1',))
    SetupCfgCommandConfig('foo', 'Foo', '', ('1', '2'))

    # Test to raise ValueError
    with pytest.raises(ValueError):
        SetupCfgCommandConfig('', 'Foo', '', ('1',))
    with pytest.raises(ValueError):
        SetupCfgCommandConfig('foo', '', '', ('1',))

# Generated at 2022-06-23 18:32:56.028865
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", ("a", "b"))
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ("a", "b")

# Generated at 2022-06-23 18:33:07.541006
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert issubclass(SetupCfgCommandConfig, NamedTuple)
    assert SetupCfgCommandConfig.__new__ == NamedTuple.__new__
    assert SetupCfgCommandConfig.__doc__ == NamedTuple.__doc__
    assert SetupCfgCommandConfig.__slots__ == NamedTuple.__slots__
    assert SetupCfgCommandConfig._fields == ('name', 'camel', 'description',
                                             'commands')
    assert SetupCfgCommandConfig._asdict == NamedTuple._asdict
    assert SetupCfgCommandConfig._replace == NamedTuple._replace
    assert SetupCfgCommandConfig._source == NamedTuple._source
    assert SetupCfgCommandConfig._field_defaults == dict()
    assert SetupCfgCommandConfig._fields_defaults == dict()
    assert SetupCfgCommandConfig.name

# Generated at 2022-06-23 18:33:18.248427
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the constructor of class SetupCfgCommandConfig."""
    config = SetupCfgCommandConfig(
        name='build',
        camel='Build',
        description='Executes a `./setup.py build`, which builds the '
                    'project.',
        commands=(
            'python setup.py build',
            'for F in ./*/setup.py; do (cd $(dirname $F) && python setup.py '
            'build); done'
        )
    )
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'build'
    assert config.camel == 'Build'
    assert config.description == \
        'Executes a `./setup.py build`, which builds the project.'

# Generated at 2022-06-23 18:33:27.433829
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import textwrap
    import tempfile
    from os.path import join

    with tempfile.TemporaryDirectory() as tmp_dir:
        setup_py = join(tmp_dir, 'setup.py')
        setup_cfg = join(tmp_dir, 'setup.cfg')
        setup_commands = join(tmp_dir, 'setup_commands.cfg')
        with open(setup_py, 'w', encoding='utf-8') as f:
            f.write(textwrap.dedent('''\
                def main():
                    print('hi')
                if __name__ == '__main__':
                    main()
            '''))

# Generated at 2022-06-23 18:33:34.817705
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # No setup.cfg; should raise exception
    SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('a',)
    )
    # No setup.cfg; should raise exception
    SetupCfgCommandConfig(
        name='',
        camel='Camel',
        description='description',
        commands=('a',)
    )


# Generated at 2022-06-23 18:33:38.634035
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    import pprint
    pprint.pprint(list(each_sub_command_config()))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:33:48.839532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_setup_cfg_command_configs(
            cfg: SetupCfgCommandConfig,
            name: str,
            description: str,
            camel: str,
            commands: Tuple[str, ...],
    ) -> None:
        assert cfg.name == name
        assert cfg.description == description
        assert cfg.camel == camel
        assert cfg.commands == commands

    cfg: SetupCfgCommandConfig
    cfg, = each_sub_command_config('tests/data/setup_cfg_01')
    _assert_setup_cfg_command_configs(
        cfg,
        'print_msg',
        'Prints a message.',
        'PrintMsg',
        ('echo "hi"',)
    )


# Generated at 2022-06-23 18:33:50.767465
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig('', '', '', ())
    except Exception as e:
        assert False, e

# Generated at 2022-06-23 18:33:58.775134
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '..', '..', '..', 'scripts', 'tests',
                        'example_project', 'setup.py')
    with mock.patch('os.path.realpath'):
        with mock.patch('os.path.expanduser'):
            for i in each_sub_command_config(os.path.dirname(path)):
                print(i)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:03.216061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:07.277980
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    fcc: SetupCfgCommandConfig = SetupCfgCommandConfig('abc', 'abc_cmd', 'abc description', (None,))
    assert fcc.name == 'abc'
    assert fcc.camel == 'AbcCmd'
    assert fcc.description == 'abc description'
    assert fcc.commands == (None,)


# Generated at 2022-06-23 18:34:11.533042
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        list(each_sub_command_config())
    except Exception:
        pass
    else:
        raise AssertionError("Should have raised AssertionError")
    list(each_sub_command_config(setup_dir=''))

# Generated at 2022-06-23 18:34:15.848555
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_cfg = SetupCfgCommandConfig('name', 'camel_name', 'description', ('cmd1',))
    assert cmd_cfg.name == 'name'
    assert cmd_cfg.camel == 'camel_name'
    assert cmd_cfg.description == 'description'
    assert cmd_cfg.commands == ('cmd1',)

# Generated at 2022-06-23 18:34:24.634482
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig(
        "test",
        "Test",
        "This is a test",
        ("echo 'Hello World!'",)
    )
    assert s.name == "test", \
        "The SetupCfgCommandConfig name is NOT test"
    assert s.camel == "Test", \
        "The SetupCfgCommandConfig camel name is NOT Test"
    assert s.description == "This is a test", \
        "The SetupCfgCommandConfig is NOT a test"
    assert s.commands == ("echo 'Hello World!'",), \
        "The SetupCfgCommandConfig commands are not correct"

if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:34:35.765928
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def callback0(config: SetupCfgCommandConfig) -> None:
        assert config.camel == 'Main'
        assert config.commands == ('echo "Hello, world!"', )
    def callback1(config: SetupCfgCommandConfig) -> None:
        assert config.camel == 'Foo'
        assert config.commands == ('echo "foo"', )
    def callback2(config: SetupCfgCommandConfig) -> None:
        assert config.camel == 'Bar'
        assert config.commands == ('echo "bar"', )

    def test_path(setup_dir: Optional[str]) -> None:
        for config in each_sub_command_config(setup_dir):
            if config.camel == 'Main':
                callback0(config)

# Generated at 2022-06-23 18:34:46.325320
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pyutils import _read_file
    from io import StringIO
    io = StringIO()
    io.write(
        _read_file(
            os.path.join(
                os.path.dirname(__file__),
                'setup_commands.cfg'
            )
        )
    )
    io.seek(0)
    parser = ConfigParser()
    parser.read_file(io)
    format_kwargs = {
        'setup_dir': '/foo/bar',
        'home': '~',
        'name': 'foobar',
    }
    found = []
    for cmd in _each_setup_cfg_command(parser, format_kwargs):
        found.append(cmd)
    assert len(found) == 5
    assert isinstance(found, list)
   

# Generated at 2022-06-23 18:34:51.891134
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig("name", "camel", "description", ["command"])
    assert config.name == "name"
    assert config.camel == "camel"
    assert config.description == "description"
    assert config.commands == ("command",)



# Generated at 2022-06-23 18:35:03.557063
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from datetime import date
    setup_cfg_path = os.path.join(
        'tests', 'data', 'setupcfg', 'setup_commands.cfg'
    )

    format_kwargs: Dict[str, str] = {
        'setup_dir': os.path.split(setup_cfg_path)[0],
        'home': os.path.expanduser('~')
    }
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)


# Generated at 2022-06-23 18:35:08.119137
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('command_1', 'command_2'))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command_1', 'command_2')


# Generated at 2022-06-23 18:35:14.815064
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import run_as_main

    @run_as_main
    def main_test():
        from sys import argv
        from os.path import join, dirname, realpath
        from flutils.configutils import each_sub_command_config

        setup_dir = dirname(dirname(dirname(dirname(realpath(argv[0])))))
        setup_dir = join(setup_dir, 'flutils', 'tests', 'fixtures', 'setuptools')
        print('setup_dir: %r' % setup_dir)
        for conf in each_sub_command_config(setup_dir):
            print(conf)

    main_test()

# Generated at 2022-06-23 18:35:27.686265
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    lst = list(gen)
    assert len(lst) > 0

    # Unit test for the SetupCfgCommandConfig
    def test_SetupCfgCommandConfig(sc: SetupCfgCommandConfig):
        assert len(sc.name) > 0
        assert type(sc.name) == str
        assert len(sc.camel) > 0
        assert type(sc.camel) == str
        assert len(sc.description) > 0
        assert type(sc.description) == str
        assert type(sc.commands) == tuple
        assert len(sc.commands) > 0
        for cmd in sc.commands:
            assert len(cmd) > 0
            assert type(cmd) == str


# Generated at 2022-06-23 18:35:29.530430
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Name', 'description', ('command', ))

# Generated at 2022-06-23 18:35:41.091868
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from unittest.mock import patch, mock_open

    class _Test(TestCase):
        def test(self):
            m = mock_open()
            m.readline = lambda: ''
            m.side_effect = [
                '',
                '[setup.command.foo]',
                'command=echo "Hello 1"',
                '',
                '',
                '[setup.command.foo.bar]',
                'commands=echo "Hello 2"',
                'name=fubar',
                '',
                '[setup.command.foobar]',
                'commands=echo "Hello 3"',
                'name=baz',
                'description=Hello 3',
            ]

# Generated at 2022-06-23 18:35:42.951969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert tuple(each_sub_command_config()) == tuple(())

# Generated at 2022-06-23 18:35:44.140704
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print()
    for config in each_sub_command_config('../../'):
        print(config)



# Generated at 2022-06-23 18:35:54.738586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys

    # Our __file__ name
    this_file = os.path.abspath(sys.modules[__name__].__file__)
    # The path to our directory
    this_dir = os.path.dirname(this_file)
    # The path to the parent (up one from our directory)
    parent_dir = os.path.dirname(this_dir)
    configs = list(each_sub_command_config(setup_dir=parent_dir))

# Generated at 2022-06-23 18:36:00.208288
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "mycommand"
    camel = "MyCommand"
    description = "This is my command"
    commands = ("command1", "command2")
    setupCfgCommandConfig = SetupCfgCommandConfig(name, camel, description, commands)
    assert setupCfgCommandConfig.name == name
    assert setupCfgCommandConfig.camel == camel
    assert setupCfgCommandConfig.description == description
    assert setupCfgCommandConfig.commands == commands

# Generated at 2022-06-23 18:36:04.973578
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'fizz.buzz.pop'
    camel = 'FizzBuzzPop'
    description = 'Test description'
    commands = ('cmd1', 'cmd2', 'cmd3')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:36:14.894117
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    r"""
    This is actually a unit test for the ``each_sub_command_config``
    function.

    Note:
        The ``__file__`` value can be ``None`` on some platforms.
    """
    if __file__:
        setup_dir = os.path.dirname(os.path.abspath(__file__))
        setup_dir = os.path.join(setup_dir, '..', '..', '..', '..', '..')
    else:
        setup_dir = None
    print()
    for cmd_config in each_sub_command_config(setup_dir):
        print(cmd_config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:36:22.352872
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:36:27.948531
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    lst: List[SetupCfgCommandConfig] = []
    for i in each_sub_command_config():
        lst.append(i)
    assert len(lst) > 0


if __name__ == '__main__':
    out = each_sub_command_config()
    for i in out:
        print(i)

# Generated at 2022-06-23 18:36:37.386428
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig('test', 'Test', 'test', ('a', 'b'))
    assert isinstance(sccc, SetupCfgCommandConfig)
    assert sccc.name == 'test'
    assert sccc.camel == 'Test'
    assert sccc.description == 'test'
    assert isinstance(sccc.commands, tuple)
    assert len(sccc.commands) == 2
    assert sccc.commands[0] == 'a'
    assert sccc.commands[1] == 'b'


# Generated at 2022-06-23 18:36:39.761542
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from pprint import pprint
    for sub_cmd in each_sub_command_config():
        pprint(sub_cmd)

# Generated at 2022-06-23 18:36:45.673449
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    n = 'name'
    c = 'camel'
    d = 'description'
    co = ('command',)
    scc = SetupCfgCommandConfig(n, c, d, co)
    assert scc.name == n
    assert scc.camel == c
    assert scc.description == d
    assert scc.commands == co

# Generated at 2022-06-23 18:36:49.229728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    for config in each_sub_command_config(setup_dir):
        assert config

# Generated at 2022-06-23 18:37:01.276566
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    tdef = sys._getframe().f_code.co_name

    def test_setup_cfg_command(tdef: str, setup_cfg_path: str) -> None:
        root = TestRoot(tdef)