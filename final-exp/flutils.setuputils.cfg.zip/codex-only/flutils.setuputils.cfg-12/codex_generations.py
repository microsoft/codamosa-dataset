

# Generated at 2022-06-23 18:27:10.936240
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import join
    from pathlib import Path
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        td = Path(td)
        config_path = td / 'setup.cfg'
        config_path.write_text('[metadata]\n'
                               'name = flutils\n'
                               '\n'
                               '[setup.command.hello]\n'
                               'command = echo "{name}-hello"\n'
                               'description = Prints hello to stdout.\n'
                               )
        setup_py_path = td / 'setup.py'

# Generated at 2022-06-23 18:27:18.490014
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scc = SetupCfgCommandConfig(
        'test.name',
        'TestName',
        'Test description.',
        ('test_command_1', 'test_command_2')
    )
    assert scc.name == 'test.name'
    assert scc.camel == 'TestName'
    assert scc.description == 'Test description.'
    assert scc.commands == ('test_command_1', 'test_command_2')


# Generated at 2022-06-23 18:27:23.942339
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('name', 'upper', 'desc', ('cmd',))
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'name'
    assert cmd.camel == 'upper'
    assert cmd.description == 'desc'
    assert cmd.commands == ('cmd',)


# Generated at 2022-06-23 18:27:26.418351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(setup_dir='tests/test_project'):
        assert config.name, config.camel

# Generated at 2022-06-23 18:27:31.218999
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(name='test', camel='Test',
                                   description='Test descr',
                                   commands=('test',))
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'Test descr'
    assert config.commands == ('test',)


# Generated at 2022-06-23 18:27:37.148663
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('command',)
    )
    assert result.name == 'name'
    assert result.camel == 'Camel'
    assert result.description == 'description'
    assert result.commands == ('command',)

# Generated at 2022-06-23 18:27:42.744927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=import-error
    """Unit test for function each_sub_command_config"""
    import flutils
    from flutils.strutils import dedent

    def _create_setup_cfg(name: str, commands: str) -> str:
        return dedent(
            f'''\
            [metadata]
            name = {name}

            [setup.command.check.setup.cfg]
            command =
                pylint {commands}

            [setup.command.check.setup_commands.cfg]
            command =
                pylint {commands}
            '''
        )


# Generated at 2022-06-23 18:27:49.696994
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # VERIFY simple constructor
    obj = SetupCfgCommandConfig(
        name = 'test',
        camel = 'Test',
        description = 'test',
        commands = ('command',)
    )
    assert obj.name == 'test'
    assert obj.camel == 'Test'
    assert obj.description == 'test'
    assert tuple(obj.commands) == ('command',)


# Generated at 2022-06-23 18:27:55.902480
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import os
    import pytest
    script_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
    count = 0
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.commands
        assert config.camel
        assert config.description
        count += 1
    assert count > 0



# Generated at 2022-06-23 18:28:00.288820
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config())

# Generated at 2022-06-23 18:28:06.839566
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scfgcc = SetupCfgCommandConfig(
        'a.name',
        'a_camel_name',
        'a description',
        ('a command 1', 'a command 2')
    )
    assert scfgcc.name == 'a.name'
    assert scfgcc.camel == 'a_camel_name'
    assert scfgcc.description == 'a description'
    assert scfgcc.commands == ('a command 1', 'a command 2')


# Generated at 2022-06-23 18:28:12.657265
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    try:
        os.chdir('/Users/rjanssen/Dev/src/flutils')
        out = [config for config in each_sub_command_config()]
        assert len(out) == 2
    finally:
        os.chdir(cwd)



# Generated at 2022-06-23 18:28:19.185436
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.abspath(os.path.join(setup_dir, '..', '..'))
    setup_dir = os.path.abspath(setup_dir)
    for config in each_sub_command_config(setup_dir=setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:24.952348
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        name='test',
        camel='T',
        description='T',
        commands=('T',)
    )
    assert obj.name == 'test'
    assert obj.camel == 'T'
    assert obj.description == 'T'
    assert obj.commands == ('T',)



# Generated at 2022-06-23 18:28:33.151341
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests :func:`flutils.scripts.setup_commands.each_sub_command_config`."""
    from flutils.scripts import (
        replace_package,
        replace_filename,
    )
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    cur_dir = replace_filename(cur_dir, 'test_scripts')
    sub_dir = os.path.join(cur_dir, 'test_data')
    for cmd in each_sub_command_config(sub_dir):
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.camel, str)
        assert isinstance(cmd.description, str)
        assert isinstance(cmd.commands, tuple)



# Generated at 2022-06-23 18:28:42.738555
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    from configparser import ConfigParser
    from pathlib import Path

    def _get_setup_dir(
            module_file: Path,
            raise_error: bool = False
    ) -> str:
        setup_dir = str(module_file.with_name('setup.py').parent)
        parser = ConfigParser()
        parser.read(str(module_file.with_name('setup.cfg')))
        format_kwargs: Dict[str, str] = {
            'setup_dir': setup_dir,
            'home': os.path.expanduser('~')
        }
        format_kwargs['name'] = _get_name(parser, str(module_file))
        return setup_dir, format_kwargs


# Generated at 2022-06-23 18:28:44.830217
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command', )
    )

# Generated at 2022-06-23 18:28:46.011194
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('', '', '', ())
    assert config.name == ''
    assert config.camel == ''
    assert config.description == ''
    assert config.commands == ()



# Generated at 2022-06-23 18:28:52.113155
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    commands = [
        'cmd1',
        'cmd2',
    ]

    sccc = SetupCfgCommandConfig('name', 'Camel', 'Description', commands)

    assert sccc.name == 'name'
    assert sccc.camel == 'Camel'
    assert sccc.description == 'Description'
    assert sccc.commands == commands

# Generated at 2022-06-23 18:29:03.630866
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test with an existing setup directory
    path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_setup_module',
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {
        'setup_dir': os.path.dirname(path),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, path)
    actual = list(
        _each_setup_cfg_command(parser, format_kwargs)
    )

# Generated at 2022-06-23 18:29:15.534305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import contextlib
    import sys
    class TestEachSubCommandConfig(unittest.TestCase):
        def test_basic(self):
            out = list(each_sub_command_config(
                setup_dir=os.path.join(
                    os.path.dirname(__file__), '..', '..'
                )
            ))

# Generated at 2022-06-23 18:29:17.557498
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-23 18:29:21.241338
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    print('+----------------------------------------+')
    print('| Unit test for function each_sub_command_config |')
    print('+----------------------------------------+')
    for cfg in each_sub_command_config('/home/jonathan/workspace/python/flutils'):
        pprint.pprint(cfg._asdict())



# Generated at 2022-06-23 18:29:24.533468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    for x in each_sub_command_config(os.path.dirname(__file__)):
        print(x)


# Generated at 2022-06-23 18:29:36.671446
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import unittest.mock as mock
    setup_command = SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        tuple(['commands']),
    )
    # test arguments
    assert setup_command.name == 'name'
    assert setup_command.camel == 'Camel'
    assert setup_command.description == 'description'
    assert setup_command.commands == tuple(['commands'])
    # test help
    assert setup_command.__doc__ is not None
    # test repr
    assert setup_command.__repr__() == (
        'SetupCfgCommandConfig('
        'name=name, '
        'camel=Camel, '
        'description=description, '
        'commands=commands'
        ')'
    )


# Generated at 2022-06-23 18:29:44.145017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'fixtures'
    )
    result = list(each_sub_command_config(setup_dir))
    assert len(result) == 3
    assert result[0] == SetupCfgCommandConfig(
        'name.one', 'NameOne', 'One Description',
        ('one-command-1', 'one-command-2')
    )
    assert result[1] == SetupCfgCommandConfig(
        'name.two', 'NameTwo', 'Two Description',
        ('two-command-1', 'two-command-2')
    )

# Generated at 2022-06-23 18:29:46.276325
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        assert cfg.name
        assert cfg.camel
        assert cfg.description
        assert cfg.commands

# Generated at 2022-06-23 18:29:54.322156
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test setup directory that does NOT exist.
    # noinspection PyTypeChecker,PyUnusedLocal
    try:
        for scc in each_sub_command_config('/does_not_exist'):
            pass
        assert False
    except FileNotFoundError:
        pass
    except BaseException as err:
        assert False, str(err)

    # Test setup directory that is NOT a directory.
    # noinspection PyTypeChecker,PyUnusedLocal
    try:
        for scc in each_sub_command_config('/dev/null'):
            pass
        assert False
    except NotADirectoryError:
        pass
    except BaseException as err:
        assert False, str(err)

    # Test setup directory that does NOT contain a setup.py file.
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:29:56.987516
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'description',
        'description',
        'description',
        ('description',)
    )

# Generated at 2022-06-23 18:30:03.060231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert len(out) == 2
    assert out[0].name == 'myproject.test'
    assert out[0].commands == (
        'echo $PYTHONPATH',
        'pytest'
    )
    assert out[1].name == 'myproject.secondtest'
    assert out[1].commands == (
        'echo $PYTHONPATH',
        'pytest'
    )



# Generated at 2022-06-23 18:30:10.658228
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == list(each_sub_command_config(os.path.join(os.path.split(os.path.abspath(__file__))[0], 'test_data')))

# Generated at 2022-06-23 18:30:18.614778
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=(
            'baz',
            'quz',
        )
    )
    assert isinstance(sccc, NamedTuple)
    assert sccc.name == 'foo'
    assert sccc.camel == 'Foo'
    assert sccc.description == 'bar'
    assert sccc.commands == (
        'baz',
        'quz',
    )



# Generated at 2022-06-23 18:30:25.392825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    import flutils

    pkg_root = pathlib.Path(flutils.__file__).parent.parent
    setup_dir = pkg_root / 'tests' / 'setup_cfg_tests'
    setup_cfg_path = setup_dir / 'setup.cfg'
    parser = ConfigParser()
    parser.read(str(setup_cfg_path))
    format_kwargs = {
        'setup_dir': str(setup_dir),
        'name': _get_name(parser, str(setup_cfg_path))
    }
    sub_commands = list(_each_setup_cfg_command(parser, format_kwargs))
    assert len(sub_commands) == 2
    for sub_cmd in sub_commands:
        print(sub_cmd)
    print()

    setup_

# Generated at 2022-06-23 18:30:27.185265
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test the constructor of class SetupCfgCommandConfig."""
    SetupCfgCommandConfig('name', 'camel', 'description', ('command', ))

# Generated at 2022-06-23 18:30:31.672881
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    data = SetupCfgCommandConfig(
        'foo.bar',
        'FooBar',
        'Do It!',
        tuple()
    )
    assert data.name == 'foo.bar'
    assert data.camel == 'FooBar'
    assert data.description == 'Do It!'
    assert data.commands == tuple()

# Generated at 2022-06-23 18:30:34.992333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Unit test for :func:`each_sub_command_config`
    """
    print()
    for config in each_sub_command_config():
        print(config)

test_each_sub_command_config()

# Generated at 2022-06-23 18:30:40.341298
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'test command'
    commands = ('test', 'fake test')
    sccc = SetupCfgCommandConfig(name, camel, description, commands)
    assert sccc.name == name
    assert sccc.camel == camel
    assert sccc.description == description
    assert sccc.commands == commands



# Generated at 2022-06-23 18:30:52.856131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_path = os.path.dirname(__file__)
    root_path = os.path.abspath(root_path)

    for i in range(3):
        if os.path.isdir(os.path.join(root_path, 'tests', 'fixtures')):
            root_path = os.path.join(root_path, 'tests', 'fixtures')
            break
        root_path = os.path.dirname(root_path)

    if os.path.isdir(os.path.join(root_path, 'fixtures')):
        root_path = os.path.join(root_path, 'fixtures')

    setup_dir = os.path.join(root_path, 'setup')


# Generated at 2022-06-23 18:30:57.933129
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'mycmd',
        'Mycmd',
        'My command.',
        ('echo "hello"', )
    )
    assert config.name == 'mycmd'
    assert config.camel == 'Mycmd'
    assert config.description == 'My command.'
    assert config.commands == ('echo "hello"', )



# Generated at 2022-06-23 18:31:06.567438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(
            '/Users/vader/Documents/Python/flutils'
    ):
        print(config)
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)
        assert isinstance(config.camel, str)

# Generated at 2022-06-23 18:31:12.170724
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'my_name',
        'MyName',
        'My description.',
        ('echo -n "foo"', 'echo -n "bar"')
    )
    assert config.name == 'my_name'
    assert config.camel == 'MyName'
    assert config.description == 'My description.'
    assert config.commands == ('echo -n "foo"', 'echo -n "bar"')

# Generated at 2022-06-23 18:31:19.350025
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    conf = [
        SetupCfgCommandConfig(
            'test', 'Test', 'test', ('ls', 'ls -la')
        )
    ]

    assert(conf[0][0] == 'test')
    assert(conf[0][1] == 'Test')
    assert(conf[0][2] == 'test')
    assert(conf[0][3] == ('ls', 'ls -la'))



# Generated at 2022-06-23 18:31:27.031735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.chdir(os.path.dirname(__file__))
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'setup.command.template'
    assert config.camel == 'Template'
    assert config.description == ''
    assert config.commands == ('echo',)


# Make the module executable.

if __name__ == '__main__':
    import sys
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-23 18:31:32.676904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'fizz.buzz', 'FizzBuzz', 'This is the description.', ('a', 'b', 'c')
    )
    assert config.name == 'fizz.buzz'
    assert config.camel == 'FizzBuzz'
    assert config.description == 'This is the description.'
    assert config.commands == ('a', 'b', 'c')


# Generated at 2022-06-23 18:31:44.647334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    from configparser import ConfigParser
    from flutils.paths import get_caller_dir

    setup_dir = tempfile.TemporaryDirectory()
    setup_dir = setup_dir.name
    setup_py = os.path.join(setup_dir, 'setup.py')
    setup_cfg = os.path.join(setup_dir, 'setup.cfg')
    setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')
    with open(setup_py, 'w') as fh:
        fh.write("")
    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'my_proj')

# Generated at 2022-06-23 18:31:55.558806
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO


# Generated at 2022-06-23 18:31:59.178752
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = [cmd for cmd in each_sub_command_config()]
    assert len(cmds) >= 2
    assert cmds[0].camel == 'Test'
    assert cmds[1].camel == 'UploadToPyPi'

# Generated at 2022-06-23 18:32:07.823979
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from unittest import TestCase

    class SetupCfgCommandConfigTest(TestCase):
        def test___init__(self):
            # fmt: off
            configs = [
                SetupCfgCommandConfig('name_1', 'Name_1', 'Description_1', ('Command_1_1',)),
                SetupCfgCommandConfig('name_2', 'Name_2', 'Description_2', ('Command_2_1', 'Command_2_2')),
            ]
            # fmt: on
            self.assertEqual(configs[0]['name'], 'name_1')
            self.assertEqual(configs[0]['camel'], 'Name_1')
            self.assertEqual(configs[0]['description'], 'Description_1')

# Generated at 2022-06-23 18:32:15.185594
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('', '', ''))
    assert type(config.name) is str
    assert type(config.camel) is str
    assert type(config.description) is str
    assert type(config.commands) is tuple
    assert type(config.commands[0]) is str
    assert type(config.commands[1]) is str
    assert type(config.commands[2]) is str

# Generated at 2022-06-23 18:32:22.473930
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    from flutils.pathutils import rel_to_this_file

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        # creates a script file for testing purpose
        script_file_path = os.path.join(tmpdir, 'script.py')
        open(script_file_path, 'wt').close()
        # creates setup_commands.cfg for testing purpose
        setup_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-23 18:32:28.340881
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config('tests/package'))
    assert len(configs) == 1

    config = configs[0]
    assert config.name == 'test-cmd'
    assert config.camel == 'TestCmd'
    assert config.description == 'Test Command'
    assert config.commands == ('echo test',)

# Generated at 2022-06-23 18:32:32.286345
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('test', 'Test', 'test', ('test',))
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('test',)

# Generated at 2022-06-23 18:32:38.173482
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = "name"
    camel = "Name"
    description = "description"
    commands = ("commands")
    cfg = SetupCfgCommandConfig(name, camel, description, commands)
    assert cfg.name == name
    assert cfg.camel == camel
    assert cfg.description == description
    assert cfg.commands == commands


# Generated at 2022-06-23 18:32:44.216684
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd',))
    assert len(config) == 4
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('cmd',)

# Generated at 2022-06-23 18:32:46.728274
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('cmd', 'Cmd', 'description', ('cmd1', 'cmd2'))
    assert config.name == 'cmd'
    assert config.camel == 'Cmd'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')



# Generated at 2022-06-23 18:32:52.441700
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'Camel', 'description', ('cmd1', 'cmd2'))
    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:32:55.377124
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_name():
        for config in each_sub_command_config():
            return config.name

    assert _get_name() == 'flutils'



# Generated at 2022-06-23 18:32:58.864629
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    value = SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))
    assert value.name == 'name'
    assert value.camel == 'Camel'
    assert value.description == 'description'
    assert value.commands == ('command',)

# Generated at 2022-06-23 18:33:11.120675
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_test_dir(test_dir: str) -> str:
        return os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test',
            test_dir
        )

    def _test_each_sub_command_config(test_dir: str) -> None:
        test_dir = _get_test_dir(test_dir)

        def _confirm_each_sub_command_config(
                expected: List[SetupCfgCommandConfig],
                test_dir: str
        ) -> Generator[Tuple[SetupCfgCommandConfig, SetupCfgCommandConfig],
                       None, None]:
            actual = list(each_sub_command_config(test_dir))

# Generated at 2022-06-23 18:33:19.583795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = []
    for cmd in each_sub_command_config(__file__):
        out.append(repr(cmd))

# Generated at 2022-06-23 18:33:20.233763
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # TODO
    assert True

# Generated at 2022-06-23 18:33:23.883631
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('a', 'A', 'A.', ('a',))
    assert c.name == 'a'
    assert c.camel == 'A'
    assert c.description == 'A.'
    assert c.commands == ('a',)



# Generated at 2022-06-23 18:33:35.972141
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    proj_sdir = os.path.abspath(os.path.join(__file__, '..', '..'))
    out = list(each_sub_command_config(proj_sdir))

# Generated at 2022-06-23 18:33:46.606438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tests = (
        (None, 'fluent-configparser'),
        (os.path.realpath(os.path.dirname(__file__)), 'fluent-configparser'),
    )
    for setup_dir, name in tests:
        configs = [i for i in each_sub_command_config(setup_dir)]
        assert len(configs) == 2
        assert (
                configs[0].name == 'render-config'
                and configs[0].camel == 'RenderConfig'
                and configs[0].description == 'Generate configuration files '
                                              'from templates'
                and configs[0].commands == ('python render_config.py',)
        )

# Generated at 2022-06-23 18:33:57.536061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_commands_commands(commands: List[str], expected_commands: List[str]):
        assert commands == expected_commands

    setup_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), 'data'))
    for cmd in each_sub_command_config(setup_dir):
        if cmd.name == 'sdist':
            assert cmd.description == 'Builds the source distribution.'
            assert cmd.camel == 'Sdist'
            assert cmd.name == 'sdist'
            _assert_commands_commands(cmd.commands, [
                'python setup.py sdist',
                'twine upload dist/*'
            ])

# Generated at 2022-06-23 18:34:04.378995
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    objectSetupCfgCommandConfig = SetupCfgCommandConfig('name', 'camel', 'description', ['commands'])
    assert objectSetupCfgCommandConfig.name == 'name'
    assert objectSetupCfgCommandConfig.camel == 'camel'
    assert objectSetupCfgCommandConfig.description == 'description'
    assert objectSetupCfgCommandConfig.commands == ['commands']


# Generated at 2022-06-23 18:34:08.748125
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():  # type: ignore
    config = SetupCfgCommandConfig('name', 'CamelName', 'description', ('command',))
    assert config.name == 'name'
    assert config.camel == 'CamelName'
    assert config.description == 'description'
    assert config.commands == ('command',)

# Generated at 2022-06-23 18:34:13.340214
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('foo', 'foo', 'foo', ('',))

    with pytest.raises(Exception):
        SetupCfgCommandConfig('foo', 'foo', 'foo', ('', ''))

    with pytest.raises(Exception):
        SetupCfgCommandConfig('foo', 'foo', 'foo', ())

# Generated at 2022-06-23 18:34:19.921832
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.helpers import (
        get_file_contents,
        get_file_lines,
        write_str_to_file,
    )
    from tempfile import mkdtemp
    from time import time

    # Setup
    tmp_dir = mkdtemp()
    tmp_dir = os.path.realpath(tmp_dir)
    setup_cfg_name = 'setup.cfg'
    setup_cfg_path = os.path.join(tmp_dir, setup_cfg_name)
    setup_py_name = 'setup.py'
    setup_py_path = os.path.join(tmp_dir, setup_py_name)
    tmp_file_glob = 'tmp_' + str(time()) + '_*'

# Generated at 2022-06-23 18:34:31.647745
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import unittest

    class SetupCfgCommandConfigTestCase(unittest.TestCase):
        TestConfig = SetupCfgCommandConfig
        TestConfig.__module__ = 'flutils.setuputils'

        def test_ctor(self):
            name = 'test_name'
            camel = 'TestName'
            description = 'Test Description'
            commands = ('command1', 'command2')
            config = self.TestConfig(name, camel, description, commands)
            self.assertEqual(config.name, name)
            self.assertEqual(config.camel, camel)
            self.assertEqual(config.description, description)
            self.assertEqual(config.commands, commands)

    unittest.main(SetupCfgCommandConfigTestCase, exit=False)


# Generated at 2022-06-23 18:34:38.215233
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.loggingutils as lu
    lu.setup_logging(default_level=lu.DEBUG)
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir=setup_dir):
        lu.dprint(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:46.247340
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.read('docs/samples/basic_setup.cfg')
    setup_cfg_command_config = SetupCfgCommandConfig(
        name='test-command',
        camel='TestCommand',
        description='test command',
        commands=('echo "test"',)
    )
    assert setup_cfg_command_config.name == 'test-command'
    assert setup_cfg_command_config.camel == 'TestCommand'
    assert setup_cfg_command_config.description == 'test command'
    assert setup_cfg_command_config.commands == ('echo "test"',)


# Generated at 2022-06-23 18:34:53.577111
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command_config in each_sub_command_config():
        assert isinstance(command_config, SetupCfgCommandConfig)
        assert isinstance(command_config.name, str)
        assert isinstance(command_config.camel, str)
        assert isinstance(command_config.description, str)
        assert isinstance(command_config.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:56.027250
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # boilerplate
    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-23 18:35:06.024742
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    # Test the function without a setup_dir.
    configs: List[SetupCfgCommandConfig] = list(
        each_sub_command_config()
    )
    assert len(configs) > 0
    for config in configs:
        assert config.name
        assert config.description
        assert len(config.commands) > 0

    # Test the function with a setup_dir.
    setup_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    configs = list(each_sub_command_config(setup_dir=setup_dir))
    assert len(configs) > 0
    for config in configs:
        assert config.name
        assert config.description


# Generated at 2022-06-23 18:35:13.514166
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    a = SetupCfgCommandConfig(
        "command_name",
        "CommandName",
        "command description",
        ("command",)
    )
    b = SetupCfgCommandConfig(
        "command_name",
        "CommandName",
        "command description",
        ("command",)
    )
    c = SetupCfgCommandConfig(
        "command_name",
        "CommandName",
        "a command description",
        ("command",)
    )
    d = SetupCfgCommandConfig(
        "command_name",
        "CommandName",
        "command description",
        ("command", "command 2")
    )
    e = SetupCfgCommandConfig(
        "command_name2",
        "CommandName2",
        "command description",
        ("command",)
    )

# Generated at 2022-06-23 18:35:21.263872
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'test_data')
    gen = each_sub_command_config(setup_dir=path)
    assert isinstance(gen, Generator)
    assert next(gen) == SetupCfgCommandConfig(
        name='test.sub.command',
        camel='TestSubCommand',
        description='',
        commands=('echo "test command"',)
    )
    assert next(gen) is None

# Generated at 2022-06-23 18:35:31.594106
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_database = dict()

    config_parser = ConfigParser()
    config_parser.read("setup_commands.cfg")
    setup_cfg_command_config = SetupCfgCommandConfig('alpha', 'Beta', 'gamma',
                                                     tuple(config_parser.get('setup.command.alpha', 'commands').splitlines()))
    command_database[setup_cfg_command_config.name] = setup_cfg_command_config
    assert setup_cfg_command_config.name == 'alpha'
    assert setup_cfg_command_config.camel == 'Beta'
    assert setup_cfg_command_config.description == 'gamma'
    assert setup_cfg_command_config.commands == tuple(config_parser.get('setup.command.alpha', 'commands').splitlines())



# Generated at 2022-06-23 18:35:36.475385
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ())
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ()


# Generated at 2022-06-23 18:35:42.519146
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Tests the constructor of class SetupCfgCommandConfig."""
    config = SetupCfgCommandConfig(
        'hello', 'Hello',
        'Says, "Hello world" to you.',
        ('echo "Hello world"',)
    )
    assert config.name == 'hello'
    assert config.camel == 'Hello'
    assert config.description == 'Says, "Hello world" to you.'
    assert config.commands == ('echo "Hello world"',)



# Generated at 2022-06-23 18:35:46.851842
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
            name='name',
            camel='camel',
            description='description',
            commands=tuple('commands')
    )
    assert setup_cfg_command_config.camel == 'camel'

# Generated at 2022-06-23 18:35:56.874504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    from os import getcwd, mkdir
    from os.path import join
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    from flutils.setuputils import (
        each_sub_command_config,
        write_setup_commands,
    )
    from flutils.testutils import gtb

    the_temp_dir = str(TemporaryDirectory())
    the_setup_dir = join(the_temp_dir, 'hello_world')
    mkdir(the_setup_dir)
    with open(join(the_setup_dir, 'README.rst'), 'w') as fp:
        fp.write('Hello, World!')
    with open(join(the_setup_dir, 'setup.cfg'), 'w') as fp:
        fp.write

# Generated at 2022-06-23 18:36:02.288043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    assert configs
    assert all((
        isinstance(config.name, str) and config.name,
        isinstance(config.camel, str) and config.camel,
        isinstance(config.description, str) and config.description,
        isinstance(config.commands, tuple) and config.commands and
        all((
            isinstance(cmd, str) and cmd,
            cmd.strip()
        ))
    ))

# Generated at 2022-06-23 18:36:14.205542
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.io import count
    for x in each_sub_command_config(Path(__file__).parent.parent):
        assert type(x) is SetupCfgCommandConfig
        assert len(x.name) > 0
        assert len(x.camel) > 0
        assert len(x.description) > 0
        assert type(x.commands) is tuple
        assert 0 < len(x.commands) <= len(count(x.commands))
    try:
        each_sub_command_config('/does/not/exist')
    except FileNotFoundError:
        pass
    try:
        each_sub_command_config(__file__)
    except FileNotFoundError:
        pass

# Generated at 2022-06-23 18:36:22.102036
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the ``each_sub_command_config`` function."""
    import re
    import subprocess

    # print(os.environ)

# Generated at 2022-06-23 18:36:33.707593
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from ._cli_test import parse_cli_test_config, run_cli_test

    def _run_test(
            test_name: str,
            test_config: Dict[str, str]
    ) -> None:
        print("Test name: %s" % test_name)
        commands = [c for c in each_sub_command_config(test_config['setup_dir'])]
        print("Commands:")
        print("\n".join(["- %s" % str(c) for c in commands]))
        print("")
        assert len(commands) == int(test_config['command_count'])

    tests = parse_cli_test_config('cli_test_config.yaml')
    run_cli_test(tests, _run_test)

# Generated at 2022-06-23 18:36:39.168990
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def get_config(path: str) -> SetupCfgCommandConfig:
        current_dir = os.path.abspath(os.path.dirname(__file__))
        for config in each_sub_command_config(current_dir):
            if config.name == path:
                return config
        raise LookupError(path)

    config = get_config('test')
    assert config.camel == 'Test'
    assert config.description == (
        'Runs the unit tests for the project '
        'in the %(setup_dir)s directory.'
    ) % {'setup_dir': current_dir}
    assert config.commands == (
        'python setup.py test -q',
    )

    config = get_config('test.test_each_sub_command_config')
    assert config.c

# Generated at 2022-06-23 18:36:52.040268
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.pytestutils import each_test_run

    # Expected results

# Generated at 2022-06-23 18:37:00.021512
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config: SetupCfgCommandConfig = SetupCfgCommandConfig(
        'foo.bar',
        'FooBar',
        'Some description.',
        ('ls', '-l', '--color')
    )
    assert config.name == 'foo.bar'
    assert config.camel == 'FooBar'
    assert config.description == 'Some description.'
    assert config.commands == ('ls', '-l', '--color')


# Unit tests