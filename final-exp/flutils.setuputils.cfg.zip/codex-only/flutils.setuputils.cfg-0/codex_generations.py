

# Generated at 2022-06-23 18:26:56.339601
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config('tests/test_setup_commands'):
        print(cmd)

# Generated at 2022-06-23 18:27:04.417221
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re
    import signal
    import sys
    import time

    def _signal_handler(sig: int, frame: FrameSummary):
        sys.stderr.write('\033[30D')
        sys.stderr.write('\033[K')
        sys.stderr.flush()
        raise KeyboardInterrupt('Ctrl-C')

    signal.signal(signal.SIGINT, _signal_handler)

    for obj in each_sub_command_config():
        print(obj.name)
        print(obj.description)
        for command in obj.commands:
            for out in re.split(r'\\\n', command):
                if re.match(r'\s*', out):
                    continue
                sys.stderr.write('\033[30D')
                sys

# Generated at 2022-06-23 18:27:06.417515
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('cmd_name', 'CmdName', 'Cmd Description', ('ls',))

# Generated at 2022-06-23 18:27:16.477742
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the each_sub_command_config() function."""
    for scc in each_sub_command_config():
        print("Project Name: {scc.name}".format(scc=scc))
        print("Camel Name: {scc.camel}".format(scc=scc))
        print("Desc: {scc.description}".format(scc=scc))
        print("Commands:")
        for command in scc.commands:
            print("    {command}".format(command=command))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:21.687529
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'foobar'
    camel = 'Foobar'
    description = 'foo, bar'
    commands = ('echo foo', 'echo bar')
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:27:32.949944
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.dotdict import (
        DotDict as dd
    )
    from flutils.configutils import (
        each_sub_command_config
    )
    from flutils.pathutils import (
        pwd
    )

    cwd = pwd()

    # Test an invalid setup dir
    try:
        each_sub_command_config(setup_dir='NOT_MY_PROJECT')
        assert(False)
    except FileNotFoundError:
        pass

    # Test normal
    it = each_sub_command_config()
    d = dd()
    for d in it:
        pass
    assert(d['description'] == 'Runs pylint over the project.')
    assert(d['camel'] == 'Pylint')
    assert(d['name'] == 'pylint')


# Generated at 2022-06-23 18:27:40.029784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    import contextlib
    from flutils.fileutils import each_line

    @contextlib.contextmanager
    def capture_stdout(clear: bool = False):
        out, sys.stdout = sys.stdout, io.StringIO()
        try:
            if clear:
                sys.stdout.seek(0)
            yield sys.stdout
        finally:
            sys.stdout = out

    setup_dir = os.path.dirname(__file__)
    each_setup_cfg_command_config = each_sub_command_config(setup_dir)
    with capture_stdout(clear=True) as stdout:
        for each_config in each_setup_cfg_command_config:
            print("==========")
            print("Command Name:", each_config.name)

# Generated at 2022-06-23 18:27:48.405254
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig_object = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert SetupCfgCommandConfig_object.name == 'name'
    assert SetupCfgCommandConfig_object.camel == 'camel'
    assert SetupCfgCommandConfig_object.description == 'description'
    assert SetupCfgCommandConfig_object.commands == ('commands',)
    try:
        SetupCfgCommandConfig_object.name = 'name'
        assert False
    except AttributeError:
        assert True

# Generated at 2022-06-23 18:27:57.665606
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    home = os.path.expanduser('~')

# Generated at 2022-06-23 18:28:02.006237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.tests

    os.chdir(
        os.path.join(
            os.path.dirname(flutils.tests.__file__),
            '..'
        )
    )
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-23 18:28:10.511977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Sets up the sample project ``setup.cfg`` file and tests the
    ``each_sub_command_config`` function.
    """
    # TODO: Use with
    setup_dir = os.path.dirname(__file__)
    expected_dir = os.path.join(
        os.path.dirname(
            os.path.dirname(os.path.dirname(__file__))
        ), 'sample_project'
    )
    os.symlink(expected_dir, setup_dir)

    configs = list(each_sub_command_config(setup_dir))
    assert configs[0].name == 'a_sample.command'
    assert configs[0].camel == 'ASampleCommand'
    assert configs[0].description == 'A sample command.'

# Generated at 2022-06-23 18:28:16.893665
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert tuple(
        each_sub_command_config(os.path.join(
            os.path.dirname(__file__),
            '../../../tests/resources/setupcfgcommands'
        ))
    ) == (
        SetupCfgCommandConfig(
            name='hello',
            camel='Hello',
            description='Hello world, from flutils.',
            commands=(
                '-m flutils.console hello',
            )
        ),
    )

# Generated at 2022-06-23 18:28:27.850734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    current_dir = os.path.dirname(__file__)
    test_dir = os.path.join(current_dir, 'testdir')
    current_file = os.path.basename(__file__)
    test_file = os.path.join(test_dir, current_file)

    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        if fs.filename == test_file:
            break
    else:
        raise ValueError(
            "Could not find this directory, %r, in the current stack."
            % test_dir
        )

    outer_dir = os.path.dirname(fs.filename)
    for config in each_sub_command_config(outer_dir):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-23 18:28:28.439714
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-23 18:28:38.326952
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test_it(root_dir: str) -> None:
        for section, sub_command in _each_setup_cfg_command_section(parser):
            configs = list(
                each_sub_command_config(root_dir)
            )
            assert len(configs) == 1
            config = configs[0]
            assert section == 'setup.command.%s' % sub_command
            assert config.name == sub_command
            assert config.camel == 'FooBar'
            assert config.description == 'foo_bar'
            assert config.commands == (
                'foo -b bar',
                'bar -h',
            )

    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'foobar')


# Generated at 2022-06-23 18:28:42.646588
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    ConfigVar = SetupCfgCommandConfig('name', 'camel', 'description', ())
    assert ConfigVar.name == 'name'
    assert ConfigVar.camel == 'camel'
    assert ConfigVar.description == 'description'
    assert list(ConfigVar.commands) == []

# Generated at 2022-06-23 18:28:51.654558
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # pragma: no cover
    curpath = os.path.dirname(os.path.realpath(__file__))
    curpath = os.path.join(curpath, '..', '..', 'setup_commands', 'tests')
    curpath = os.path.abspath(curpath)
    print('curpath:', curpath)
    for config in each_sub_command_config(curpath):
        print(config)


if __name__ == '__main__':  # pragma: no cover
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:59.160095
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='flutils.build.setup_commands',
        camel='PackageDistribute',
        description='Create a source distribution and wheel.',
        commands=('setup.py sdist bdist_wheel',)
    )
    assert config.name == 'flutils.build.setup_commands'
    assert config.camel == 'PackageDistribute'
    assert config.description == 'Create a source distribution and wheel.'
    assert config.commands == ('setup.py sdist bdist_wheel',)

# Generated at 2022-06-23 18:29:00.491105
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    pass



# Generated at 2022-06-23 18:29:06.747554
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'a',
        'A',
        'A',
        ('aa', 'bb')
    ) == SetupCfgCommandConfig(
        'a',
        'A',
        'A',
        ('aa', 'bb')
    )

if __name__ == '__main__':
    test_SetupCfgCommandConfig()

# Generated at 2022-06-23 18:29:19.001075
# Unit test for function each_sub_command_config

# Generated at 2022-06-23 18:29:26.714086
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    assert next(each_sub_command_config(path)) == SetupCfgCommandConfig(
        name='build_docs',
        camel='BuildDocs',
        description='Build the docs.',
        commands=('pip install -U -e ".[docs]"',
                  'sphinx-build docs docs/_build')
    )
    with pytest.raises(LookupError):
        next(each_sub_command_config(os.path.join(path, 'testdata', 'broken')))



# Generated at 2022-06-23 18:29:38.612479
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Error: Expected Method to fail
    with pytest.raises(TypeError):
        # Error: Expected Method to fail
        SetupCfgCommandConfig()

    # Error: Expected Method to fail
    with pytest.raises(TypeError):
        # Error: Expected Method to fail
        SetupCfgCommandConfig('name', 'camel', 'description')

    # Error: Expected Method to fail
    with pytest.raises(TypeError):
        # Error: Expected Method to fail
        SetupCfgCommandConfig('name', 'camel', 'description', 'commands')

    # Test: Valid
    test_obj = SetupCfgCommandConfig('name', 'camel', 'description', ('test',))
    assert test_obj.name == 'name'
    assert test_obj.camel == 'camel'


# Generated at 2022-06-23 18:29:43.721814
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    testCommandConfig = SetupCfgCommandConfig('name', 'camel', 'desc', ('cmd1', 'cmd2'))
    assert testCommandConfig.name == 'name'
    assert testCommandConfig.camel == 'camel'
    assert testCommandConfig.description == 'desc'
    assert testCommandConfig.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:29:48.762966
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        name='bootstrap',
        camel='Bootstrap',
        description='bootstrap the project',
        commands=[
            './bootstrap.sh',
            './bootstrap.bat'
        ]
    )
    assert isinstance(cmd, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:29:57.639554
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test_name'
    camel = 'TestName'
    description = 'description for test_name'
    commands = ['echo test_name', 'echo -n test_name']
    assert (
        SetupCfgCommandConfig(
            name=name,
            camel=camel,
            description=description,
            commands=tuple(commands)
        ) == SetupCfgCommandConfig(
            'test_name',
            'TestName',
            'description for test_name',
            tuple(commands)
        )
    )


# Generated at 2022-06-23 18:30:06.493173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from unittest import mock
    from flutils.fileutils import TempFile

    class MockParser(object):
        def __init__(self, text: str) -> None:
            self.buffer = StringIO(text)
            self.section: Optional[str] = None

        def read(self, *args, **kwargs) -> None:
            pass

        def sections(self) -> List[str]:
            return ['metadata', 'setup.command.sub']

        def options(self, section_name: str) -> List[str]:
            if section_name == 'metadata':
                return ['name']
            if section_name == 'setup.command.sub':
                return ['command']
            raise AttributeError(section_name)


# Generated at 2022-06-23 18:30:11.022259
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'name',
        'CamelName',
        '/tmp',
        ('a', 'b'),
    )
    assert command.name == 'name'
    assert command.camel == 'CamelName'
    assert command.description == '/tmp'
    assert command.commands == ('a', 'b')

# Generated at 2022-06-23 18:30:19.288460
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        setup_cfg_command_config = SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))
        assert setup_cfg_command_config.name == 'name'
        assert setup_cfg_command_config.camel == 'camel'
        assert setup_cfg_command_config.description == 'description'
        assert setup_cfg_command_config.commands == ('a', 'b')
    except Exception:
        print('test_SetupCfgCommandConfig: failed')
    else:
        print('test_SetupCfgCommandConfig: passed')


# Generated at 2022-06-23 18:30:22.815543
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('one', 'two')
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('one', 'two')



# Generated at 2022-06-23 18:30:30.465706
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.collectionsutils import tuple_of_tuples_str
    for cfg in each_sub_command_config():
        print(
            '\n'.join((
                "name: %s, camel: %s, description: %s, commands: %s"
                % (cfg.name, cfg.camel, cfg.description, tuple_of_tuples_str(cfg.commands)),
            ))
        )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:34.282804
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('one', )
    )
    assert x.name == 'name'
    assert x.camel == 'Camel'
    assert x.description == 'description'
    assert x.commands == ('one', )

# Unit tests for _each_setup_cfg_command_section()

# Generated at 2022-06-23 18:30:38.839963
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Execute the function each_sub_command_config.

    This is not exhaustive, but rather a 'sanity check'.
    """
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.dirname(setup_dir)

    for cfg in each_sub_command_config(setup_dir):
        assert isinstance(cfg, SetupCfgCommandConfig)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:45.039542
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(os.getcwd()):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:53.101169
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    data = list(each_sub_command_config())
    assert len(data) == 1
    assert data[0].name == 'test'
    assert data[0].camel == 'Test'
    assert data[0].description
    expected = ('echo "No commands defined!"',)
    assert data[0].commands == expected
    assert data[0] == SetupCfgCommandConfig(
        'test',
        'Test',
        'Test the subcommand and verify it runs as expected.',
        expected
    )

# Generated at 2022-06-23 18:31:02.374157
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from mock import patch
    from itertools import count

    """
    config_parser_mock_section_iter_dict = {}

    class ConfigParserMock:

        def __init__(self, **kwargs):
            pass

        def sections(self) -> list:
            out = []
            try:
                cnt = next(config_parser_mock_section_iter_dict[self])
            except KeyError:
                cnt = 0
            for x in range(cnt):
                out.append(f'section{x}')
            return out

        def options(self, *args, **kwargs) -> list:
            return [f'options{args[0]}']

        def get(self, *args, **kwargs) -> str:
            return f'{args[0]}_get'
    """

# Generated at 2022-06-23 18:31:05.791671
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        print(item)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:09.656445
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'string', 'string', 'string', (
            'string1', 'string2', 'string3',
        )
    )
    assert setup_cfg_command_config.name == 'string'



# Generated at 2022-06-23 18:31:14.397781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config."""
    my_args: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert len(my_args) == 1
    sc = my_args[0]
    assert sc.name == 'ci'
    assert sc.camel == 'CI'
    assert sc.description == 'Run the CI/CD build/tests.'
    assert sc.commands == ('tox',)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:16.513779
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))


# Generated at 2022-06-23 18:31:22.250205
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('cmd',)



# Generated at 2022-06-23 18:31:27.076673
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print('\n')
    print('*' * 30)
    print('Class SetupCfgCommandConfig:')
    args = (
        'callback',
        'Callback',
        'Runs the package setup callback.',
        (
            'callback',
        )
    )
    config = SetupCfgCommandConfig(*args)
    print(config)

# Generated at 2022-06-23 18:31:28.481658
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('test name', "TestName", 'test description', ())

# Generated at 2022-06-23 18:31:36.310482
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section = "test"
    command_name = "test"
    cmd_name = "test"
    title = "test"
    description = "test"
    commands = ("test",)
    config = SetupCfgCommandConfig(
        cmd_name, underscore_to_camel(title, lower_first=False),
        description, tuple(commands)
    )
    assert config.name == section
    assert config.camel == command_name
    assert config.description == description
    assert config.commands == commands


# Generated at 2022-06-23 18:31:42.192773
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'test',
        'Test',
        'Test the command.',
        ('test', 'test the command'),
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'Test the command.'
    assert config.commands == ('test', 'test the command')

# Generated at 2022-06-23 18:31:53.498138
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _set_up() -> Tuple[Generator[SetupCfgCommandConfig, None, None],
                           str, str, str]:
        setup_dir = None
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            if os.path.basename(fs.filename) == 'setup.py':
                setup_dir = str(os.path.dirname(fs.filename))
                try:
                    _validate_setup_dir(setup_dir)
                except (FileNotFoundError, NotADirectoryError):
                    pass
                else:
                    break
        if not setup_dir:
            raise FileNotFoundError(
                "Unable to find the directory that contains the 'setup.py' "
                "file."
            )

# Generated at 2022-06-23 18:32:04.670303
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setuputils.test
    import sys
    this_dir: str = os.path.dirname(__file__)
    this_dir = str(os.path.abspath(this_dir))
    os.chdir(this_dir)
    sys.path.insert(0, this_dir)
    import setup
    _ = setup.setup_cfg_path
    test_setup_cfg = os.path.abspath(flutils.setuputils.test.setup_cfg)
    config = each_sub_command_config(test_setup_cfg)
    section = 'setup.command.one'
    cmd_name = 'one'
    parser = setup.setup_cfg_parser
    options = parser.options(section)
    assert 'command' in options
    assert 'commands' in options

# Generated at 2022-06-23 18:32:16.532088
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: str = os.path.dirname(__file__)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    assert setup_dir.endswith('flutils') is True
    setup_dir = os.path.join(setup_dir, 'tests', 'test_package')
    setup_dir = os.path.realpath(setup_dir)
    assert setup_dir.endswith('test_package') is True
    expected = ['test_command']
    found = []
    for config in each_sub_command_config(setup_dir):
        assert config.name in expected
        found.append(config.name)
    found.sort()
    expected.sort()
    assert found == expected

# Generated at 2022-06-23 18:32:22.611540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config(os.path.join(
        os.path.dirname(__file__),
        'fixtures', 'setup-cfg'
    )))
    assert len(configs) == 1
    assert configs[0].name == 'cli_command1'
    assert configs[0].description == 'The CLI Command 1'
    assert len(configs[0].commands) == 3

# Generated at 2022-06-23 18:32:34.653797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    output: List[SetupCfgCommandConfig] = []

# Generated at 2022-06-23 18:32:43.642943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib
    import re
    from tempfile import (
        TemporaryDirectory,
    )

    def check_commands(expected: Tuple[str, ...]):
        nonlocal actual
        actual = tuple(each_sub_command_config(setup_dir=setup_dir))
        assert len(actual) == len(expected)
        for i, c in enumerate(actual):
            assert len(c.commands) == len(expected[i])
            for cmd_i, cmd in enumerate(expected[i]):
                assert re.match(cmd, c.commands[cmd_i]) is not None

    with TemporaryDirectory() as tmp_path:
        setup_file = pathlib.Path(tmp_path) / 'setup.py'

# Generated at 2022-06-23 18:32:48.403757
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('commands',)
    )
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('commands',)
    assert obj.__repr__() == (
        "SetupCfgCommandConfig(name='name', camel='camel', "
        "description='description', commands=('commands',))"
    )

# Generated at 2022-06-23 18:33:00.008687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=import-outside-toplevel,protected-access
    from tests import test_env

    def assert_stdout(
            cmd: str,
            stdout: Optional[str],
            call_func: Union[str, Callable[[str], None]] = None,
            call_args: Optional[Tuple[str, ...]] = None,
            cwd: Union[os.PathLike, str, None] = None
    ) -> None:
        cmd = cmd.split()
        proc = subprocess.run(cmd, cwd=cwd, capture_output=True)

        if call_func is not None:
            args = () if call_args is None else call_args
            call_func = getattr(proc, call_func, call_func)

# Generated at 2022-06-23 18:33:12.597234
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    path, name = os.path.split(__file__)
    path, name = os.path.split(path)
    setup_cfg_path = os.path.join(path, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)
    configs = tuple(each_sub_command_config(path))
    assert configs
    for config in configs:
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        for command in config.commands:
            assert command
            assert command.strip() == command

# Generated at 2022-06-23 18:33:16.931440
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command1', 'command2')
    )
    assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:33:24.711787
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    assert 'tests' == os.path.basename(setup_dir)
    for i in each_sub_command_config(setup_dir):
        assert i.description
        assert i.name
        assert i.camel
        for j in i.commands:
            assert j


if __name__ == '__main__':
    try:
        test_each_sub_command_config()
    except Exception:
        from traceback import format_exc
        print(format_exc())
        os._exit(1)

# Generated at 2022-06-23 18:33:28.728865
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        tuple(['command'])
    ) == SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        tuple(['command'])
    )

# Generated at 2022-06-23 18:33:40.130259
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import uuid
    name_val = 'name_val-' + str(uuid.uuid4())
    camel_val = 'camel_val-' + str(uuid.uuid4())
    description_val = 'description_val-' + str(uuid.uuid4())
    commands_val = ('commands_val-' + str(uuid.uuid4()), 'commands_val-' + str(uuid.uuid4()))

    obj = SetupCfgCommandConfig(name_val, camel_val, description_val, commands_val)

    assert obj.name == name_val
    assert obj.camel == camel_val
    assert obj.description == description_val
    assert obj.commands == commands_val

# Generated at 2022-06-23 18:33:41.183790
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:33:46.129623
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    actual = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commands',)
    )
    assert actual.name == 'name'
    assert actual.camel == 'camel'
    assert actual.description == 'description'
    assert actual.commands == ('commands',)
    assert actual == ('name', 'camel', 'description', ('commands',))

# Generated at 2022-06-23 18:33:50.090654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'flutils', 'tests', 'data'
    )
    for sc_config in each_sub_command_config(setup_dir):
        print(sc_config)

# Generated at 2022-06-23 18:33:55.653497
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig."""
    out = SetupCfgCommandConfig('test', 'Test', 'test', ('test', ))
    assert out.name == 'test'
    assert out.camel == 'Test'
    assert out.description == 'test'
    assert out.commands == ('test', )

# Generated at 2022-06-23 18:34:04.772705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dirname: str = os.path.dirname(__file__)
    dirname = os.path.join(dirname, 'setupcfg')

    for config in each_sub_command_config(dirname):
        assert config.name is not None
        assert config.camel is not None
        assert config.description is not None
        assert config.commands is not None
        assert isinstance(config.commands, tuple)



# Generated at 2022-06-23 18:34:10.961129
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    fileloc = os.path.realpath(__file__)
    dirname = os.path.dirname(fileloc)
    SetupCfgCommandConfig(
        name="testCfgCmdConfig",
        camel="CamelCase",
        description="testing",
        commands=("command1", "command2")
    )
    for config in each_sub_command_config(dirname):
        print(config)


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-23 18:34:19.345987
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        setup_py = tmpdir / 'setup.py'
        setup_py.touch()
        setup_cfg = tmpdir / 'setup.cfg'
        setup_cfg.write_text(
            """[metadata]
name = flutils

[setup.command.foo]
name = foo
commands =
    echo 'foo'
"""
        )
        setup_commands_cfg = tmpdir / 'setup_commands.cfg'

# Generated at 2022-06-23 18:34:25.416438
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='testname',
        camel='TestName',
        description='test description',
        commands=('testcommand',)
    )
    assert config.name == 'testname'
    assert config.commands == ('testcommand',)
    assert config.camel == 'TestName'
    assert config.description == 'test description'


# Generated at 2022-06-23 18:34:26.958982
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'CamelCase', 'desc', ('command',))

# Generated at 2022-06-23 18:34:34.189316
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    expected_command_config= SetupCfgCommandConfig(
        'help',
        'Help',
        "Prints this help message.",
        ("python {setup_dir}/setup.py -h",)
    )
    test_command_config= SetupCfgCommandConfig(
        'help',
        'Help',
        "Prints this help message.",
        ("python {setup_dir}/setup.py -h",)
    )

    assert expected_command_config.name == test_command_config.name
    assert expected_command_config.camel == test_command_config.camel

# Generated at 2022-06-23 18:34:39.145664
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('commands',)



# Generated at 2022-06-23 18:34:40.868904
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands'))

# Generated at 2022-06-23 18:34:45.289740
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Test for constructor of class SetupCfgCommandConfig"""
    config = SetupCfgCommandConfig(
        'test', 'Test', 'test', ('test',)
    )
    assert config.name == 'test'
    assert config.camel == 'Test'
    assert config.description == 'test'
    assert config.commands == ('test',)

# Generated at 2022-06-23 18:34:53.993840
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config())
    assert cmds[0].camel == 'Build'
    assert (
        cmds[0].commands == (
            'python setup.py build',
            'python setup.py sdist'
        )
    )
    assert len(cmds) == 9
    assert cmds[5].name == 'get-gaff'
    assert cmds[5].camel == 'Get_gaff'
    assert (
        cmds[5].commands == (
            'python -m flutils.gaff.get_gaff',
        )
    )

# Generated at 2022-06-23 18:35:04.613024
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    SetupCfgCommandConfig
    """
    expected = SetupCfgCommandConfig(
        'unicode_utils.tests.foo',
        'Foo',
        "Test the 'foo' sub-command.",
        (
            'py.test -v --cov unicode_utils.tests.foo',
            'py.test -v -s --pdb unicode_utils.tests.foo',
        )
    )
    assert expected.name == 'unicode_utils.tests.foo'
    assert expected.camel == 'Foo'
    assert expected.description == "Test the 'foo' sub-command."

# Generated at 2022-06-23 18:35:06.559823
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # type: () -> None
    for x in each_sub_command_config():
        assert isinstance(x, SetupCfgCommandConfig)



# Generated at 2022-06-23 18:35:12.761933
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """Unit test for constructor of class SetupCfgCommandConfig"""
    inst = SetupCfgCommandConfig(
        "project_name",
        "ProjectName",
        "The project's name",
        ("python", "setup.py", "some-command")
    )
    assert inst.name == "project_name"
    assert inst.camel == "ProjectName"
    assert inst.description == "The project's name"
    assert inst.commands == ("python", "setup.py", "some-command")


# Generated at 2022-06-23 18:35:25.962771
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import pathlib
    import textwrap


# Generated at 2022-06-23 18:35:30.672145
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    name = 'test'
    camel = 'Test'
    description = 'Testing'
    commands = ('echo "Hello, world!"',)

    config = SetupCfgCommandConfig(
        name, camel, description, commands
    )
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:35:37.247467
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name = 'name',
        camel = 'camel',
        description = 'description',
        commands = ('commands',)
    )

    assert config.name == 'name'
    assert config.camel == 'Camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)

# Generated at 2022-06-23 18:35:39.791817
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test of function each_sub_command_config"""
    for _i in each_sub_command_config():
        assert True

# Generated at 2022-06-23 18:35:47.189924
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    title = 'foo_bar'
    cmd_name = 'foo-bar'
    cmd_desc = 'Foo Bar'
    cmds = ('python -m this',)
    config = SetupCfgCommandConfig(
        cmd_name,
        title,
        cmd_desc,
        cmds
    )
    assert config.name == cmd_name
    assert config.camel == title
    assert config.description == cmd_desc
    assert config.commands == cmds

# Generated at 2022-06-23 18:35:50.922842
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = list(each_sub_command_config())
    assert len(config) == 1
    assert config[0].name == 'test_command'
    assert config[0].commands == (
        'python setup.py --name',
        'python setup.py --version',
    )

# Generated at 2022-06-23 18:35:53.403250
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    with pytest.raises(TypeError) as err_info:
        SetupCfgCommandConfig('', '', '', ('',))



# Generated at 2022-06-23 18:35:57.530006
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    ns = SetupCfgCommandConfig('foo', 'Foo', 'desc', ('cmd1', 'cmd2'))
    assert isinstance(ns.name, str)
    assert isinstance(ns.camel, str)
    assert isinstance(ns.description, str)
    assert isinstance(ns.commands, tuple)



# Generated at 2022-06-23 18:36:00.225939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pathlib

    setup_dir = pathlib.Path(sys.argv[0]).parent.resolve()
    for config in each_sub_command_config(setup_dir):
        print(config)

# Generated at 2022-06-23 18:36:05.007469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import join, dirname, abspath
    path = join(dirname(abspath(__file__)), '..', '..')
    for _ in each_sub_command_config(path):
        pass


if __name__ == '__main__':
    import sys
    test_each_sub_command_config()
    print(sys.argv[0], ': Test Completed.')

# Generated at 2022-06-23 18:36:15.595624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from textwrap import dedent
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from unittest import TestCase
    from .test_setup_cfg import SetupCfgTestCaseMixin

    class TestEachSubCommandConfig(SetupCfgTestCaseMixin, TestCase):

        def test_no_setup_cfg_name(self):
            """Ensures that the command-name is used if not present in
            setup.cfg."""
            with TemporaryDirectory() as td:
                td = str(Path(td).resolve())

# Generated at 2022-06-23 18:36:19.315677
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e', 'f'))
    assert c.name == 'a'
    assert c.camel == 'b'
    assert c.description == 'c'
    assert c.commands == ('d', 'e', 'f')

# Generated at 2022-06-23 18:36:23.323597
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=('baz', 'qux'),
    )
    assert SetupCfgCommandConfig(
        'foo',
        'Foo',
        'bar',
        ('baz', 'qux'),
    )



# Generated at 2022-06-23 18:36:27.477019
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig('hello', 'Hello', 'hi', ('hi',))
    assert str(command) == "<SetupCfgCommandConfig name: 'hello', camel: 'Hello', description: 'hi', commands: ('hi',)>"

# Generated at 2022-06-23 18:36:39.509795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from pathlib import Path
    from unittest.mock import patch
    from shutil import rmtree
    from flutils.pathutils import safe_mkdir

    here = Path(os.path.abspath(__file__))
    dir_name = os.path.basename(here.parent)
    dir_name = os.path.splitext(dir_name)[0]

    # create temporary project
    tmp_dir = tempfile.mkdtemp(prefix=dir_name)
    tmp_setup_dir = os.path.join(tmp_dir, 'project')
    safe_mkdir(tmp_setup_dir)

    tmp_setup_cfg_path = os.path.join(tmp_setup_dir, 'setup.cfg')

# Generated at 2022-06-23 18:36:45.562080
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        'name', 'camel', 'description', ('commands',)
    )
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.description == 'description'
    assert sccc.commands == ('commands',)

# Generated at 2022-06-23 18:36:49.542686
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    arg1 = 'a'
    arg2 = 'b'
    arg3 = 'c'
    arg4 = ('d', 'e')
    SetupCfgCommandConfig(arg1, arg2, arg3, arg4)

# Generated at 2022-06-23 18:37:01.813726
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_root = os.path.join(os.path.dirname(__file__), '..', '..')
    project_root = os.path.realpath(project_root)