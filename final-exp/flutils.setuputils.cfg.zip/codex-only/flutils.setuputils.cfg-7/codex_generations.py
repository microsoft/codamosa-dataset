

# Generated at 2022-06-23 18:27:03.678130
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    result = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=('',),
    )
    exp = SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='bar',
        commands=('',),
    )
    assert result == exp



# Generated at 2022-06-23 18:27:10.494923
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config = SetupCfgCommandConfig(
        name="foo",
        camel="Foo",
        description="example",
        commands=tuple()
    )

    assert setup_cfg_command_config.name == "foo"
    assert setup_cfg_command_config.camel == "Foo"
    assert setup_cfg_command_config.description == "example"
    assert setup_cfg_command_config.commands == tuple()

# Generated at 2022-06-23 18:27:15.570983
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_ = os.path.dirname(__file__)
    dir_ = os.path.join(dir_, '..', '..', 'tests', 'configs')
    cmd_name = next(each_sub_command_config(dir_)).name
    assert cmd_name == 'build'

# Generated at 2022-06-23 18:27:21.259587
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))


if __name__ == '__main__':
    from json import dumps
    out = list(each_sub_command_config('/tmp/setup'))
    print(dumps(out, sort_keys=False, indent=4))

# Generated at 2022-06-23 18:27:32.657992
# Unit test for function each_sub_command_config
def test_each_sub_command_config(): # noqa
    from flutils.testutils import data_dir
    from .test_utils import capture_stdout
    with capture_stdout() as result:
        for cfg in each_sub_command_config(data_dir('package1')):
            print(cfg)

# Generated at 2022-06-23 18:27:35.932015
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))



# Generated at 2022-06-23 18:27:37.395218
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('cmds', ))

# Generated at 2022-06-23 18:27:39.463969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('tests/data/dummy1'):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:50.262373
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys

    test_setup_dir = None
    sys.path.insert(0, os.path.expanduser('~/src'))
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        basename = os.path.basename(fs.filename)
        if basename == 'setup.py':
            test_setup_dir = str(os.path.dirname(fs.filename))
            break
    assert test_setup_dir is not None
    myiter = each_sub_command_config(test_setup_dir)
    for item in myiter:
        print(item)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:27:56.703115
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='fetch_latest_data',
        camel='FetchLatestData',
        description='Fetches the latest data.',
        commands=('echo Fetching latest data...', 'echo Done!')
    )
    assert config.name == 'fetch_latest_data'
    assert config.camel == 'FetchLatestData'
    assert config.description == 'Fetches the latest data.'
    assert config.commands == ('echo Fetching latest data...', 'echo Done!')



# Generated at 2022-06-23 18:28:07.160198
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        name='my_command',
        camel='MyCommand',
        description='My description',
        commands=('my_command', 'my_command2', 'my_command3')
    )
    assert cmd.name == 'my_command'
    assert cmd.camel == 'MyCommand'
    assert cmd.description == 'My description'
    assert cmd.commands == ('my_command', 'my_command2', 'my_command3')


if __name__ == '__main__':
    cmd = SetupCfgCommandConfig(
        name='my_command',
        camel='MyCommand',
        description='My description',
        commands=('my_command', 'my_command2', 'my_command3')
    )
    print(cmd)

# Generated at 2022-06-23 18:28:18.140245
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Make sure it raises a FileNotFoundError exception.
    with pytest.raises(FileNotFoundError) as excinfo:
        list(each_sub_command_config(
            setup_dir=os.path.join('tests', 'data', 'no_setup.py')
        ))

    # Load real data.
    data = {
        'name': 'flutils',
        'camel': 'Flutils',
        'description': (
            'The F. L. \"Frank\" Wagner Utility library for use in '
            'various projects.\n'
        ),
        'commands': (
            "echo 'Hello, world'",
        ),
    }
    out: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert len(out) == 1, "Invalid output."


# Generated at 2022-06-23 18:28:25.774730
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='setup.command.cleanup.build',
        camel='Setup_Command_Cleanup_Build',
        description='does something',
        commands=('command1', 'command2',)
    )

    assert config.name == 'setup.command.cleanup.build'
    assert config.camel == 'Setup_Command_Cleanup_Build'
    assert config.description == 'does something'
    assert config.commands == ('command1', 'command2',)

# Generated at 2022-06-23 18:28:33.184101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from test.test_helpers import UnitTest

    class Test(UnitTest):
        def test(self):
            mck = self.patch('flutils.dirtools.setup_dir.each_sub_command_config')
            mck.return_value = ['value']
            output = setup_dir.each_sub_command_config()
            self.assertTrue(mck.called is True)
            self.assertTrue(mck.call_args == ())
            self.assertTrue(mck.call_args == ())
            self.assertTrue(output == ['value'])

    Test().test()


if __name__ == '__main__':
    print(setup_dir.each_sub_command_config())

# Generated at 2022-06-23 18:28:39.307273
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        full_path = os.path.join(tmpdirname, 'setup.cfg')
        with open(full_path, 'w') as f:
            f.write(
                "[metadata]\n"
                "name = example_name\n"
                "\n"
                "[setup.command.no_params]\n"
            )
        current_dir = os.getcwd()

# Generated at 2022-06-23 18:28:45.363684
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from mock import patch
    from pathlib import Path
    from os.path import join
    from argparse import Namespace
    from typing import Tuple

    this_path = Path(__file__).parent
    args = Namespace(setup_dir=this_path)

    each_config = each_sub_command_config(args.setup_dir)
    config = next(each_config)

    assert config.name == 'add_egg_info'
    assert config.camel == 'AddEggInfo'
    assert config.description == 'Add Egg Info'
    assert join('.', '{setup_dir}', 'setup.cfg') in config.commands[0]



# Generated at 2022-06-23 18:28:54.819369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyUnresolvedReferences
    from test_setup_commands import _setup_cfg_path
    parser = ConfigParser()
    parser.read(_setup_cfg_path)
    setup_cfg_path = os.path.join(os.path.dirname(_setup_cfg_path),
                                  'setup_commands.cfg')
    if os.path.isfile(setup_cfg_path):
        parser = ConfigParser()
        parser.read(setup_cfg_path)
    for command in _each_setup_cfg_command(parser, {}):
        yield command

# Generated at 2022-06-23 18:28:59.053085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        assert all(map(lambda x: isinstance(x, str), config.commands))

# Generated at 2022-06-23 18:29:04.652107
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import Counter
    from pathlib import Path
    from unittest.mock import patch

    with patch.object(Path, 'home') as mock_home:
        mock_home.return_value = '/home/user'
        setup_dir = Path(__file__).parent/'setup_dir'
        configs = Counter((c.name for c in each_sub_command_config(setup_dir)))
        assert configs['foo'] == 1
        assert configs['bar'] == 1
        assert configs['baz'] == 1
        assert configs['spam'] == 1

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:16.858393
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest

    def test_setup_dir(setup_dir: str, exc: Exception):
        with pytest.raises(exc):
            try:
                list(each_sub_command_config(setup_dir))
            except FileNotFoundError as e:
                if exc is FileNotFoundError:
                    assert os.path.isdir(setup_dir) is True
                    assert os.path.exists(setup_dir) is False
                    assert os.path.exists(setup_dir + 'foo') is False
                    assert os.path.exists(setup_dir + 'foo' + 'bar') is False
                    assert str(e) == \
                        "The given 'setup_dir' of %r does NOT exist." \
                        % setup_dir
                    raise exc
                raise

# Generated at 2022-06-23 18:29:22.866001
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """
    Test constructor of class SetupCfgCommandConfig
    """
    obj = SetupCfgCommandConfig("name", "camel", "desc", ("cmd1", "cmd2"))
    assert obj.name == "name"
    assert obj.camel == "camel"
    assert obj.description == "desc"
    assert obj.commands == ("cmd1", "cmd2")

# Generated at 2022-06-23 18:29:27.197919
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        'ff',
        'Ff',
        'description',
        ('ff',)
    )
    assert command.name == 'ff'
    assert command.camel == 'Ff'
    assert command.description == 'description'
    assert command.commands == ('ff',)


# Generated at 2022-06-23 18:29:37.715150
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    _path = os.path.dirname(__file__)
    _path = os.path.abspath(os.path.join(_path, '..', '..', '..'))
    for each in each_sub_command_config(setup_dir=_path):
        assert isinstance(each, SetupCfgCommandConfig) is True
        assert isinstance(each.name, str) is True
        assert isinstance(each.camel, str) is True
        assert isinstance(each.description, str) is True
        assert isinstance(each.commands, tuple) is True
        assert len(each.commands) >= 1
        for cmd in each.commands:
            assert isinstance(cmd, str) is True

# Generated at 2022-06-23 18:29:40.751197
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint  # noqa
    pprint(list(each_sub_command_config()))

# Generated at 2022-06-23 18:29:46.414762
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import (
        every_func_prop, is_iterable, is_mapping_with_keys
    )

    for i in each_sub_command_config():
        assert is_mapping_with_keys(i)
        assert every_func_prop(i.keys(), len)


__all__ = (
    'each_sub_command_config',
)

# Generated at 2022-06-23 18:29:50.465722
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    scc = SetupCfgCommandConfig('name', 'Camel', 'description', ('command',))
    assert scc.name == 'name'
    assert scc.camel == 'Camel'
    assert scc.description == 'description'
    assert scc.commands == ('command',)

# Generated at 2022-06-23 18:29:51.921645
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'Camel', 'Description', ('command',))

# Generated at 2022-06-23 18:29:57.103981
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command',)



# Generated at 2022-06-23 18:30:06.142561
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'setup_dir': os.path.dirname(os.path.realpath(__file__)),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    for obj in _each_setup_cfg_command(parser, format_kwargs):
        assert isinstance(obj, SetupCfgCommandConfig)
        assert isinstance(obj.name, str)
        assert isinstance(obj.camel, str)

# Generated at 2022-06-23 18:30:09.915246
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    vals = 'command_name', 'CommandName', 'desc', ('cmd 1', 'cmd 2')
    config = SetupCfgCommandConfig(*vals)
    assert config.name == vals[0]
    assert config.camel == vals[1]
    assert config.description == vals[2]
    assert config.commands == vals[3]



# Generated at 2022-06-23 18:30:13.440977
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'Test'
    description = 'Testing the command.'
    commands = ('echo hello, world', )
    SetupCfgCommandConfig(name, camel, description, commands)

# Generated at 2022-06-23 18:30:22.447740
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    """."""
    import unittest

    class SetupCfgCommandConfigTestCase(unittest.TestCase):
        """."""

        def test_each_setup_cfg_command_section(self) -> None:
            """."""
            parser = ConfigParser()
            parser.add_section('setup.command.something')
            parser.add_section('setup.command.something.something')
            parser.add_section('setup.command.something.something.else')
            parser.add_section('other')
            parser.add_section('other.something')
            parser.add_section('other.something.something')
            parser.add_section('other.something.something.else')
            parser.add_section('something.else')
            parser.add_section('something.other')

# Generated at 2022-06-23 18:30:31.585934
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command',)
    ).name == 'name'
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command',)
    ).camel == 'Camel'
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command',)
    ).description == 'description'
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command',)
    ).commands == ('command',)

# Generated at 2022-06-23 18:30:35.621552
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Simple unit test for the each_sub_command_config function."""
    mydir = os.path.dirname(__file__)
    assert each_sub_command_config(mydir) is not None


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:40.204077
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'name'
    camel = 'Camel'
    description = 'description'
    commands = 'commands'

    config = SetupCfgCommandConfig(name, camel, description, commands)

    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:30:52.699126
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = [
        x for x in each_sub_command_config(
            setup_dir=os.path.dirname(__file__)
        )
    ]
    assert len(out) == 3
    assert out[0].name == 'pylint'
    assert out[0].description == 'Run pylint on the library, flutils.'
    assert out[0].camel == 'PyLint'
    assert out[0].commands[0] == (
        'pylint --rcfile=tests/pylintrc flutils tests/test_flutils.py'
    )
    assert out[1].name == 'pep8'
    assert out[1].description == 'Run pep8 on the library, flutils.'
    assert out[1].camel == 'Pep8'

# Generated at 2022-06-23 18:31:02.096270
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='test.command',
        camel='TestCommand',
        description='Test command section.',
        commands=('command1', 'command2')
    )
    assert config.name == 'test.command'
    assert config.camel == 'TestCommand'
    assert config.description == 'Test command section.'
    assert config.commands == ('command1', 'command2')


if __name__ == '__main__':
    import click
    from flutils.clickutils import verbose_option


# Generated at 2022-06-23 18:31:06.356478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config('../../setup') is not None
    assert list(each_sub_command_config('../../setup')) != []


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:31:12.712735
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='This is a test',
        commands=('echo hello world',)
    )
    assert command_config.name == 'test'
    assert command_config.camel == 'Test'
    assert command_config.description == 'This is a test'
    assert command_config.commands == ('echo hello world',)

# Unit tests for _each_setup_cfg_command_section()

# Generated at 2022-06-23 18:31:20.009230
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name="test.name",
        camel="test_name",
        description="test description",
        commands=("test command 1", "test command 2")
    )
    assert config.name == "test.name"
    assert config.camel == "test_name"
    assert config.description == "test description"
    assert config.commands == ("test command 1", "test command 2")

# Generated at 2022-06-23 18:31:29.998416
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = list(each_sub_command_config('tests/fixtures/setup_dir'))

# Generated at 2022-06-23 18:31:38.335870
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig(
        name='awesome',
        camel='Awesome',
        description='Runs awesome command.',
        commands=[
            'echo awesome',
        ]
    )
    assert isinstance(sccc, SetupCfgCommandConfig)
    assert sccc.name == 'awesome'
    assert sccc.camel == 'Awesome'
    assert sccc.description == 'Runs awesome command.'
    assert sccc.commands == ('echo awesome', )



# Generated at 2022-06-23 18:31:43.738827
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'tox', 'tox', 'tox', ('tox -e py37')
    )
    assert config.name == 'tox'
    assert config.camel == 'Tox'
    assert config.description == 'tox'
    assert config.commands == ('tox -e py37',)



# Generated at 2022-06-23 18:31:54.789998
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'setup.py')
        with open(path, 'w') as f:
            f.write('')
        path = os.path.join(temp_dir, 'setup.cfg')
        with open(path, 'w') as f:
            f.write('''\
[metadata]
name = flutils
''')
        for x in each_sub_command_config(temp_dir):
            assert False, "The setup.cfg file should not have any commands."


# Generated at 2022-06-23 18:32:00.695286
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    my_config = SetupCfgCommandConfig('My Name', 'MyCamel',
                                      'My description', ('My command',))
    assert my_config.name == 'My Name'
    assert my_config.camel == 'MyCamel'
    assert my_config.description == 'My description'
    assert my_config.commands == ('My command',)


# Generated at 2022-06-23 18:32:06.111398
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    out = SetupCfgCommandConfig(
        'a',
        'b',
        'c',
        ('d',)
    )
    x = repr(out)
    assert out.name == 'a'
    assert out.camel == 'b'
    assert out.description == 'c'
    assert out.commands == ('d',)
    assert x == "SetupCfgCommandConfig(name='a', camel='b', description='c', commands=('d',))"

# Generated at 2022-06-23 18:32:11.247516
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('commands',))
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('commands',)


# Generated at 2022-06-23 18:32:12.059789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:32:17.325192
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root = os.path.dirname(__file__)
    root = os.path.dirname(root)
    root = os.path.dirname(root)
    root = os.path.dirname(root)
    root = os.path.dirname(root)
    assert each_sub_command_config(root)


"""DisabledContent
"""

# Generated at 2022-06-23 18:32:20.923561
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command_config = SetupCfgCommandConfig("name", "camel", "description", ("command", "moo"))
    assert command_config.name == "name"
    assert command_config.camel == "camel"
    assert command_config.description == "description"
    assert command_config.commands == ("command", "moo")



# Generated at 2022-06-23 18:32:33.243241
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    def each_sub_command_config_test(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(setup_dir)

    root_dir = os.path.dirname(sys.modules['__main__'].__file__)

    setup_dir = os.path.join(root_dir, 'tests', 'fixtures', 'setup-cfg')
    result = list(each_sub_command_config_test(setup_dir))
    assert len(result) == 1
    assert result[0].name == 'test.sub'
    assert result[0].camel == 'TestSub'
    assert result[0].description == 'The TestSub command test.'

# Generated at 2022-06-23 18:32:38.222435
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e'))
    assert config.name == 'a'
    assert config.camel == 'b'
    assert config.description == 'c'
    assert config.commands == ('d', 'e')



# Generated at 2022-06-23 18:32:42.077207
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('a', 'b', 'c', ('d1', 'd2'))



# Generated at 2022-06-23 18:32:51.430391
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.pytestutils import load_test_data
    from os import path

    for setup_dir, exp in load_test_data('each_sub_command_config', True):
        pth = path.join(setup_dir, 'setup.py')
        if path.isfile(pth):
            results = [sc.name for sc in each_sub_command_config(setup_dir)]
            assert results == [sc.name for sc in exp], \
                "Invalid results for %r" % setup_dir
        else:
            try:
                each_sub_command_config(setup_dir)
            except Exception as err:
                assert isinstance(err, exp), \
                    "Invalid results for %r" % setup_dir

# Generated at 2022-06-23 18:33:01.346424
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import tempfile
    with tempfile.TemporaryDirectory() as tdir:
        folderpath = os.path.join(tdir, 'config')
        os.mkdir(folderpath)
        os.chdir(folderpath)
        with open('setup.cfg', 'w') as f:
            f.write("""[metadata]
name = test_package
[setup.command.test_cmnd]
commands = echo 'hello world'
description = Test command
""")
        configs = list(each_sub_command_config())
    assert configs[0].name == 'test_cmnd', \
        "the command name is wrong"
    assert configs[0].camel == 'TestCmnd', \
        "the command camel-case version is wrong"

# Generated at 2022-06-23 18:33:14.351841
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pytest
    from pprint import pprint

    setup_cfg_path = './setup.cfg'
    SetupCfgCommandConfig(
        'setup.command.pytest',
        'SetupCommandPytest',
        'Run pytest.',
        (
            'pytest --cov=flutils -vv --durations=5 -n auto '
            '--cov-report term-missing:skip-covered '
            '--cov-report xml:' + os.path.join('..', 'artifacts', 'cover',
                                               'coverage.xml') + ' --cov-fail-under=90'
        )
    )

    # Null setup
    null_setup = SetupCfgCommandConfig(
        '',
        '',
        '',
        ()
    )
    # Check the name
    assert null

# Generated at 2022-06-23 18:33:25.152988
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.dirname(__file__)
    cwd = os.path.dirname(cwd)
    cwd = os.path.dirname(cwd)
    for cfg in each_sub_command_config(cwd):
        if cfg.camel == 'Example':
            assert (
                cfg.name == 'example'
            )
            assert (
                cfg.description == 'Run the Example command.'
            )
            assert (
                cfg.commands == (
                    'echo `python setup.py --version`',
                    'python setup.py example',
                    'python setup.py example -h',
                    'python setup.py example --help',
                )
            )

# Generated at 2022-06-23 18:33:37.900737
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    setup_cfg_path = "./setup.cfg"
    parser.read(setup_cfg_path)
    format_kwargs: Dict[str, str] = {
        'setup_dir': os.path.realpath('.'),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    configs = _each_setup_cfg_command(parser, format_kwargs)

    assert(next(configs) == SetupCfgCommandConfig(
        "lint",
        "Lint",
        "Lint all source code using the linters specified in setup.cfg.",
        ("pylint --load-plugins=pylint_django src/",)
    ))


# Generated at 2022-06-23 18:33:43.778507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    values = {
        cmd.name: cmd
        for cmd in each_sub_command_config(os.path.dirname(__file__))
    }
    assert 'bump_pre_release' in values, \
        "'bump_pre_release' NOT in values: {values}"
    assert 'bump_post_release' in values, \
        "'bump_post_release' NOT in values: {values}"

# Generated at 2022-06-23 18:33:47.385434
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e', 'f')) == SetupCfgCommandConfig('a', 'b', 'c', ('d', 'e', 'f'))


# Generated at 2022-06-23 18:33:55.602912
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for x in each_sub_command_config(setup_dir):
            assert x is not None
    check_each_sub_command_config(setup_dir=None)
    check_each_sub_command_config(setup_dir='../../flutils')
    check_each_sub_command_config(setup_dir='./')
    check_each_sub_command_config(setup_dir='./setup.py')

# Generated at 2022-06-23 18:34:06.898195
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import abspath, dirname, join
    from sys import path

    setup_dir = join(dirname(dirname(abspath(__file__))), 'src')
    path.append(setup_dir)

    num = 0
    for cmd in each_sub_command_config(setup_dir):
        num += 1
        assert isinstance(cmd, SetupCfgCommandConfig)
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.camel, str)
        assert isinstance(cmd.commands, tuple)
        assert len(cmd.commands) > 0
        assert isinstance(cmd.description, str)
        assert len(cmd.description) > 0

    assert num > 0

# Generated at 2022-06-23 18:34:16.910008
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils.pathutils import ensure_path
    from flutils.testutils import (
        BUILD_DIR,
        PRJ_DIR,
        TEST_FILES_DIR,
    )
    from flutils.testutils.filetree import FileTree

    from flutils.setup.setup_cfg import each_sub_command_config
    from flutils.setup.setup_cfg import test_each_sub_command_config as mod

    setup_cfg_path = TEST_FILES_DIR / mod.__name__ / 'setup.cfg'
    setup_commands_cfg_path = TEST_FILES_DIR / mod.__name__ / 'setup_commands.cfg'

    setup_dir = BUILD_DIR / mod.__name__
    ensure_path(setup_dir)

    # Create

# Generated at 2022-06-23 18:34:25.960773
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import nested_dir_from_package
    from flutils.testingutils import Path

    path = nested_dir_from_package(Path(__file__), 'data')

    _path = os.path.join(path, 'each_sub_command_config')
    _path = os.path.join(_path, 'setup_commands.cfg')
    with open(_path) as fh:
        expected = fh.read()

    _path = os.path.join(path, 'each_sub_command_config')
    configs = tuple(each_sub_command_config(_path))

    from flutils.strutils import (
        camel_to_underscore,
        indent,
    )

# Generated at 2022-06-23 18:34:31.815253
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    setup_cfg_command_config: SetupCfgCommandConfig = \
        SetupCfgCommandConfig("name", "camel", "description", ())
    assert setup_cfg_command_config.name == "name"
    assert setup_cfg_command_config.camel == "camel"
    assert setup_cfg_command_config.description == "description"
    assert setup_cfg_command_config.commands == ()
    


# Generated at 2022-06-23 18:34:43.475706
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import ExitStack
    from flutils.pytestutils import (
        any_members,
        any_namedtuples,
    )
    from flutils.stringutils import get_random_string


# Generated at 2022-06-23 18:34:54.418982
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from pprint import pprint

    with TempDir() as tempdir:
        tempdir.join('setup.py').write('')
        tempdir.join('setup.cfg').write('[metadata]\nname = foo\n')
        tempdir.mkdir('setup_commands')
        tdir = tempdir.ensure('sub_command', 'sub_command.cfg')
        tdir.write(
            '[setup.command.sub_command]\ndescription = This is a sub command\n'
            'command = {setup_dir}/setup_commands/sub_command.py\n'
            '# command = {setup_dir}/setup_commands/sub_command_2.py\n'
        )
        command_names = []

# Generated at 2022-06-23 18:34:56.497516
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('blah', 'Blah', 'This is the blah command.', ())

# Generated at 2022-06-23 18:34:58.762071
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='A foo.',
        commands=('command foo', )
    )


# Generated at 2022-06-23 18:35:00.275601
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('name', 'camel', 'description', ('command',))

# Generated at 2022-06-23 18:35:04.852845
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('.'))
    assert configs is not None
    assert len(configs) == 1
    config = configs[0]
    assert config is not None
    assert config.name == "test"
    assert config.camel == "Test"
    assert config.description == ""
    assert config.commands == ("command", "other command")

# Generated at 2022-06-23 18:35:12.765772
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    working_directory = tempfile.mkdtemp()

# Generated at 2022-06-23 18:35:25.961718
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from argparse import (
        ArgumentParser,
        RawDescriptionHelpFormatter,
    )
    from io import StringIO

    parser = ArgumentParser(
        description="Unit test for function `each_sub_command_config`.",
        formatter_class=RawDescriptionHelpFormatter
    )
    args = parser.parse_args()

    out = StringIO()
    for command_cfg in each_sub_command_config():
        out.write(
            'name=%r, camel=%r, description=%r, commands=%r\n'
            % command_cfg
        )
        if command_cfg.commands:
            for cmd in command_cfg.commands:
                print(cmd)
        print()
    print(out.getvalue(), end='')



# Generated at 2022-06-23 18:35:33.130722
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    n = 'foo'
    c = 'Foo'
    d = 'A foo command.'
    cs = ('python -m foo', 'python -m bar')
    assert SetupCfgCommandConfig(n, c, d, cs).name == n
    assert SetupCfgCommandConfig(n, c, d, cs).camel == c
    assert SetupCfgCommandConfig(n, c, d, cs).description == d
    assert SetupCfgCommandConfig(n, c, d, cs).commands == cs

# Generated at 2022-06-23 18:35:43.049365
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert isinstance(
        SetupCfgCommandConfig('name', 'camel', 'description', ()),
        SetupCfgCommandConfig
    )
    with raises(ValueError):
        SetupCfgCommandConfig('', 'camel', 'description', ())
    with raises(ValueError):
        SetupCfgCommandConfig('name', '', 'description', ())
    with raises(ValueError):
        SetupCfgCommandConfig('name', 'camel', '', ())
    # pylint: disable=W0212
    Success = SetupCfgCommandConfig('name', 'camel', 'description', ())
    assert Success._fields == ('name', 'camel', 'description', 'commands')
    assert Success.name == 'name'
    assert Success.camel == 'camel'
    assert Success.description == 'description'
    assert Success.comm

# Generated at 2022-06-23 18:35:47.820458
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    c = SetupCfgCommandConfig('name', 'camel', 'description', ('commands', ))
    print(c)
    assert c.name == 'name'
    assert c.camel == 'camel'
    assert c.description == 'description'
    assert c.commands == ('commands', )

# Generated at 2022-06-23 18:35:55.244261
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    # Setup
    setup_dir = str(os.path.dirname(__file__))
    sys.argv = ['setup.py', 'build']
    out = list(each_sub_command_config(setup_dir))
    assert out == [
        SetupCfgCommandConfig(
            'build', 'Build',
            'build',
            ('python setup.py build', 'python setup.py bdist_wheel')
        )
    ]


if __name__ == '__main__':
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-23 18:36:04.812234
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from datetime import datetime
    from flutils.testutils import TestConfig
    from time import timezone

    name = datetime.now().strftime('%Y%m%d-%H%M%S')
    conf = TestConfig(
        '[' + name + ']',
        'commands:',
        '- python3 setup.py build_sphinx',
        '- python3 setup.py build_sphinx_html',
        'description:',
        '- Build the documentation.',
    )
    parser = ConfigParser()
    parser.read_file(conf)
    format_kwargs = {
        'name': name,
        'home': os.path.expanduser('~'),
        'setup_dir': os.path.dirname(__file__),
    }
    gen = _each

# Generated at 2022-06-23 18:36:15.435638
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from flutils.testutils import dummy_module_class

    dmc = dummy_module_class()

    # Test missing argument
    dmc.testCase.assertRaisesRegex(
        TypeError,
        "'description' and 'commands' argument(s) must be provided.",
        SetupCfgCommandConfig,
        'name',
        'camel',
    )
    dmc.testCase.assertRaisesRegex(
        TypeError,
        "'description' and 'commands' argument(s) must be provided.",
        SetupCfgCommandConfig,
        'name',
        'camel',
        'description',
    )

    # Test missing arguments

# Generated at 2022-06-23 18:36:22.648701
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_dir = os.path.dirname(os.path.dirname(__file__))
    setup_dir = str(pkg_dir)
    print('\nTesting each_sub_command_config()')
    print(f'Using setup_dir: {setup_dir}')
    cmd_configs = list(each_sub_command_config(setup_dir))
    print(f'cmd configs: {cmd_configs}')
    assert len(cmd_configs) == 1
    cmd_config = cmd_configs[0]
    assert cmd_config.name == 'example'
    assert cmd_config.camel == 'Example'
    assert cmd_config.description == "An example of using the 'entry_points' " \
        "section."
    assert len(cmd_config.commands) == 1


# Generated at 2022-06-23 18:36:29.189794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    conf = next(each_sub_command_config())
    assert isinstance(conf.name, str)
    assert len(conf.name) > 0
    assert isinstance(conf.camel, str)
    assert len(conf.camel) > 0
    assert isinstance(conf.description, str)
    assert len(conf.description) > 0
    assert isinstance(conf.commands, Tuple)
    assert len(conf.commands) > 0

# Generated at 2022-06-23 18:36:35.924195
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import pdb; pdb.set_trace()
    obj = SetupCfgCommandConfig(
        'name',
        'camel',
        'description',
        ('command',),
    )
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('command',)


# Generated at 2022-06-23 18:36:44.913810
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'src',
        'flutils',
        'setuputils',
        'test',
        'project'
    )
    test_setup_dir = os.path.realpath(test_setup_dir)
    results = tuple(each_sub_command_config(test_setup_dir))

# Generated at 2022-06-23 18:36:48.031927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = []
    for sc in each_sub_command_config():
        out.append(sc)
    assert len(out) == 2

# Generated at 2022-06-23 18:36:56.501083
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _write_to_disk(filename: str, body: str) -> None:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(body)

    def _load_from_disk(path: str) -> ConfigParser:
        parser = ConfigParser()
        parser.read(path)
        return parser


# Generated at 2022-06-23 18:37:05.658283
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from configparser import SafeConfigParser

    setup_dir_path = tempfile.mkdtemp()
    setup_cfg_path = os.path.join(setup_dir_path, 'setup.cfg')
    with open(setup_cfg_path, 'w') as fh:
        parser = SafeConfigParser()
        parser.add_section('metadata')
        parser.set('metadata', 'name', 'foobar')
        parser.add_section('setup.command.test')
        parser.set('setup.command.test', 'description', 'Test command')
        parser.set('setup.command.test', 'commands', 'test command')
        parser.write(fh)

    for config in each_sub_command_config(setup_dir_path):
        assert config.name == 'test'
        assert config