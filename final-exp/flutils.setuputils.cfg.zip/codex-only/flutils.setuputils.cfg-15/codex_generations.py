

# Generated at 2022-06-23 18:27:03.904659
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    my_var = SetupCfgCommandConfig('name', 'camel', 'desc', ())
    assert my_var.name == 'name'
    assert my_var.camel == 'camel'
    assert my_var.description == 'desc'
    assert my_var.commands == ()



# Generated at 2022-06-23 18:27:16.033539
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'Beagle.test', 'Test', 'Test command', ('abc', 'def')
    )
    assert config.name == 'Beagle.test'
    assert config.camel == 'Test'
    assert config.description == 'Test command'
    assert config.commands == ('abc', 'def')
    assert config == SetupCfgCommandConfig(
        'Beagle.test', 'Test', 'Test command', ('abc', 'def')
    )
    assert config != SetupCfgCommandConfig(
        'Beagle.test', 'Test', 'Test command', ('abc', 'xyz')
    )
    assert config != SetupCfgCommandConfig(
        'Beagle.test', 'Test', 'Test command', ('def', )
    )

# Generated at 2022-06-23 18:27:20.557033
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=('',)
    )
    assert config.name == ''
    assert config.camel == ''
    assert config.description == ''
    assert config.commands == ('',)


# Generated at 2022-06-23 18:27:26.310574
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = 'test'
    camel = 'test'
    description = 'test'
    commands = tuple(['test'])
    config = SetupCfgCommandConfig(name, camel, description, commands)
    assert config.name == name
    assert config.camel == camel
    assert config.description == description
    assert config.commands == commands

# Generated at 2022-06-23 18:27:28.219371
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = list(each_sub_command_config('./flutils'))
    assert len(result) == 5

# Generated at 2022-06-23 18:27:32.013155
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    s = SetupCfgCommandConfig('name', 'camel', 'description', [])
    assert s.name == 'name'
    assert s.camel == 'camel'
    assert s.description == 'description'
    assert s.commands == ()


# Generated at 2022-06-23 18:27:43.261547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""

    def _assert_config(
            config: SetupCfgCommandConfig,
            expect_camel: str,
            expect_description: str,
            expect_commands: List[str]
    ) -> None:
        assert config.name.startswith('test')
        assert config.camel == expect_camel
        assert config.description == expect_description
        assert list(config.commands) == expect_commands


# Generated at 2022-06-23 18:27:47.329922
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        SetupCfgCommandConfig(
            "name",
            "camel",
            "description",
            ("command1", "command2")
        )
    except Exception as e:
        print(e)
        raise e


# Generated at 2022-06-23 18:27:57.194824
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig('name','camel','description',())
    assert str(sccc) == "SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=())", "String representation of SetupCfgCommandConfig failed"
    assert repr(sccc) == "SetupCfgCommandConfig(name='name', camel='camel', description='description', commands=())", "String representation of SetupCfgCommandConfig failed"
    assert sccc.name == 'name', "Getter of name failed"
    assert sccc.camel == 'camel', "Getter of camel failed"
    assert sccc.description == 'description', "Getter of description failed"
    assert sccc.commands == (), "Getter of commands failed"

# Generated at 2022-06-23 18:28:03.063376
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('command 1', 'command 2')
    ) == SetupCfgCommandConfig(
        name='name',
        camel='Camel',
        description='description',
        commands=('command 1', 'command 2')
    )

# Generated at 2022-06-23 18:28:10.665574
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    mock_command_name = mock.Mock()
    mock_command_name.__iter__.return_value = ('command',)

    mock_description = mock.Mock()
    mock_description.__iter__.return_value = ('description',)

    config = SetupCfgCommandConfig(
        name='name',
        camel='camel',
        description=mock_description,
        commands=mock_command_name
    )
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('command',)

# Generated at 2022-06-23 18:28:16.341353
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'setup.sub.name', 'SetupSubName', 'Setup sub name.', ('echo 1', 'echo 2')
    )
    assert config.name == 'setup.sub.name'
    assert config.camel == 'SetupSubName'
    assert config.description == 'Setup sub name.'
    assert config.commands == ('echo 1', 'echo 2')


# Generated at 2022-06-23 18:28:18.643972
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    lst = list(each_sub_command_config(setup_dir))
    assert len(lst) == 2

# Generated at 2022-06-23 18:28:21.958729
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:28:28.387702
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cfg = SetupCfgCommandConfig(
        'pip.pack',
        'PipPack',
        'Packages the project.',
        ('pip', 'pack', './src')
    )
    assert cfg.name == 'pip.pack'
    assert cfg.camel == 'PipPack'
    assert cfg.description == 'Packages the project.'
    assert cfg.commands == ('pip', 'pack', './src')


# Generated at 2022-06-23 18:28:31.723039
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd1',))
    assert sccc.name == 'name'
    assert sccc.camel == 'camel'
    assert sccc.description == 'description'
    assert sccc.commands == ('cmd1',)

# Generated at 2022-06-23 18:28:41.668249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from unittest.mock import patch

    class EachSubCommandConfigUnitTests(TestCase):
        @classmethod
        def setUpClass(cls):
            os.environ['USERPROFILE'] = os.path.expanduser('~')

        def setUp(self):
            self.patchers = []
            mock_patcher = patch('os.environ', {'HOME': os.path.expanduser('~')})
            self.patchers.append(mock_patcher)
            mock_patcher.start()
            mock_patcher = patch(
                'flutils.pkgutils.each_sub_command_config._prep_setup_dir'
            )
            self.patchers.append(mock_patcher)
            self.mock_setup_dir

# Generated at 2022-06-23 18:28:54.252330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest

    def _test_each_sub_command_config(
            expected: List[SetupCfgCommandConfig],
            setup_dir: Optional[Union[os.PathLike, str]],
    ):
        actual = list(each_sub_command_config(setup_dir))
        assert len(expected) == len(actual), actual
        for i, cfg in enumerate(expected):
            expected_i = cast(SetupCfgCommandConfig, cfg)
            actual_i = actual[i]

# Generated at 2022-06-23 18:29:00.726899
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        '..',
        '..',
        'tests',
        'fixtures',
        'setup_commands_cfg',
    )
    for s in each_sub_command_config(setup_dir):
        print(s)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:09.132247
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.abspath(os.path.dirname(__file__))
    each_config = list(each_sub_command_config(setup_dir))
    assert len(each_config) > 0
    assert each_config[0].name == 'test'
    assert each_config[0].camel == 'Test'
    assert each_config[0].description == (
        'Execute the unit tests for flutils.'
    )
    assert len(each_config[0].commands) > 0

# Generated at 2022-06-23 18:29:21.533053
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parser = ConfigParser()
    parser.add_section('metadata')
    parser.set('metadata', 'name', 'test')
    parser.add_section('setup.command.test')
    parser.set('setup.command.test', 'command', 'test')

    setup_dir = '/tmp'
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)

    config = list(_each_setup_cfg_command(parser, format_kwargs))[0]

    #TODO: Figure out how to do this correctly.

# Generated at 2022-06-23 18:29:30.085687
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    from doctest import Example
    from textwrap import dedent

    cmd = SetupCfgCommandConfig(
        'my_custom_command',
        'MyCustomCommand',
        'This is a custom command!',
        ('echo This is a custom command!',),
    )
    assert str(cmd) == "my_custom_command"
    assert repr(cmd) == (
        "SetupCfgCommandConfig(name='my_custom_command', "
        "camel='MyCustomCommand', description='This is a custom "
        "command!', commands=('echo This is a custom command!',))"
    )
    docstring = dedent("""
    This is a custom command!
    """)

# Generated at 2022-06-23 18:29:33.667483
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    res = list(each_sub_command_config(__file__))
    assert ''.join(map(str, res)).startswith('Wibble')

# Generated at 2022-06-23 18:29:39.250789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # package: test_prj
    import test_prj.setup_commands
    setup_commands = list(each_sub_command_config('.'))
    assert len(setup_commands) == 2
    assert len(setup_commands[0].commands) == 1
    assert len(setup_commands[1].commands) == 1

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:29:47.840200
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():

    sut = SetupCfgCommandConfig('name', 'camel', 'description', ('one', 'two'))

    assert sut.name == 'name'
    assert sut.camel == 'camel'
    assert sut.description == 'description'
    assert sut.commands == ('one', 'two')

    sut = SetupCfgCommandConfig('name', 'camel', 'description', 'one')

    assert sut.name == 'name'
    assert sut.camel == 'camel'
    assert sut.description == 'description'
    assert sut.commands == ('one',)



# Generated at 2022-06-23 18:29:55.418860
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests import setup_dir
    command: SetupCfgCommandConfig
    for command in each_sub_command_config(setup_dir):
        assert isinstance(command.name, str)
        assert isinstance(command.camel, str)
        assert isinstance(command.description, str)
        assert isinstance(command.commands, tuple)
        for cmd in command.commands:
            assert isinstance(cmd, str)

# Generated at 2022-06-23 18:29:57.204533
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig("test", "Test", "test", ())
#

# Generated at 2022-06-23 18:30:05.321314
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from pprint import pprint
    from flutils.miscutils import (
        RELATIVE_PATH_RE,
        get_path_from_mod_func
    )
    import sys

    modname, _ = get_path_from_mod_func(
        func=cast(None, None),
        name=RELATIVE_PATH_RE
    )
    mod = sys.modules[modname]
    pprint(tuple(each_sub_command_config(os.path.dirname(mod.__file__))))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:30:10.860615
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    values = ["name","camel","description","commands"]
    assert SetupCfgCommandConfig(values[0],values[1],values[2],values[3]).name == "name"
    assert SetupCfgCommandConfig(values[0],values[1],values[2],values[3]).camel == "camel"
    assert SetupCfgCommandConfig(values[0],values[1],values[2],values[3]).description == "description"
    assert SetupCfgCommandConfig(values[0],values[1],values[2],values[3]).commands == ("commands",)


# Generated at 2022-06-23 18:30:21.059039
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    with TemporaryDirectory(prefix='fsetup_cfg_') as setup_dir:
        # Make sure it is OK to run the function with a non-existing 'setup_dir'
        with pytest.raises(FileNotFoundError):
            assert not list(each_sub_command_config(setup_dir))

        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('pass')

        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(dedent("""\
                [metadata]
                name = fsetup_cfg_test
                """))

        cmd_gen = each_sub_command_config(setup_dir)

# Generated at 2022-06-23 18:30:23.285009
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Camel', 'description', ('a', 'b'))


# Generated at 2022-06-23 18:30:25.989266
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig(
        'test.test',
        'TestTest',
        '',
        tuple()
    )

# Generated at 2022-06-23 18:30:29.903755
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig('test', 'Test', 'test', ())
    assert cmd.name == 'test'
    assert cmd.camel == 'Test'
    assert cmd.description == 'test'
    assert cmd.commands == ()


# Generated at 2022-06-23 18:30:35.470326
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils.pathutils import in_bin_path
    from pytest import raises

    def test_02():
        with raises(FileNotFoundError):
            cmd_config = []
            for config in each_sub_command_config():
                cmd_config.append(config)
            pprint(cmd_config)

    def test_01():
        cmd_config = []
        for config in each_sub_command_config(in_bin_path(__file__)):
            cmd_config.append(config)
        pprint(cmd_config)

    test_01()
    test_02()



# Generated at 2022-06-23 18:30:44.568184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from distutils.spawn import spawn
    from shutil import rmtree
    from sys import executable
    from os import listdir, makedirs
    from os.path import (
        exists,
        isdir,
        join,
        realpath,
    )

    cwd = realpath('.')

    with TemporaryDirectory() as tmpdirname:
        tmpdirname = str(tmpdirname)
        tmp_src_dir = join(tmpdirname, 'src')
        tmp_pkg_dir = join(tmp_src_dir, 'foo_pkg')
        makedirs(tmp_pkg_dir)
        tmp_setup_dir = join(tmp_pkg_dir, 'setup')
        makedirs(tmp_setup_dir)

# Generated at 2022-06-23 18:30:48.458129
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('foo.bar', 'FooBar', 'baz', ('cmd1',)) == \
        SetupCfgCommandConfig('foo.bar', 'FooBar', 'baz', ('cmd1',))

# Generated at 2022-06-23 18:30:54.867407
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd = SetupCfgCommandConfig(
        'sd',
        'Sd',
        'Nothing to see here',
        ('ls', '-l')
    )
    assert cmd.name == 'sd'
    assert cmd.camel == 'Sd'
    assert cmd.description == 'Nothing to see here'
    assert cmd.commands == ('ls', '-l')


# Unit tests for each_sub_command_config

# Generated at 2022-06-23 18:30:56.413697
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    SetupCfgCommandConfig('test', 'Test', 'test', ())

# Generated at 2022-06-23 18:30:56.975503
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:31:08.888381
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.conftest import PROJ_DIR
    configs = list(each_sub_command_config(PROJ_DIR))
    assert 2 == len(configs)

    assert 'setup' == configs[0].name
    assert 'Setup' == configs[0].camel
    assert 'run the setuptools setup command.' == configs[0].description
    assert ('%(setup_dir)s/setup.py build' == configs[0].commands[0])

    assert 'test' == configs[1].name
    assert 'Test' == configs[1].camel
    assert 'run the pytest setup command.' == configs[1].description
    assert ('%(setup_dir)s/setup_commands.cfg build' == configs[1].commands[0])

# Generated at 2022-06-23 18:31:13.487833
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cmd_config = SetupCfgCommandConfig(
        'test_command',
        'TestCommand',
        'This is a test command.',
        ('echo "This is a test"',)
    )
    assert cmd_config.name == 'test_command'
    assert cmd_config.camel == 'TestCommand'
    assert cmd_config.description == 'This is a test command.'
    assert cmd_config.commands == ('echo "This is a test"',)

# Generated at 2022-06-23 18:31:19.568976
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    command = SetupCfgCommandConfig(
        name="name",
        camel="Camel",
        description="test description",
        commands=()
    )
    assert command.name == "name"
    assert command.camel == "Camel"
    assert command.description == "test description"
    assert command.commands == ()

# Generated at 2022-06-23 18:31:29.777931
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.cmds.setup.runner as runner
    from flutils.testing import (
        TempDir,
        TempFile,
    )
    from flutils.utilities import (
        makedirs,
        write_bin_data,
    )
    from operator import attrgetter
    from subprocess import check_output
    from tempfile import TemporaryDirectory

    with TempFile(suffix='.zip') as zfp:
        with TemporaryDirectory() as tmpdirname:
            name = 'flutils'
            makedirs(os.path.join(tmpdirname, 'src'))

# Generated at 2022-06-23 18:31:41.653164
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import sys
    import contextlib

    from pathlib import Path

    root_path = Path(os.path.dirname(__file__))
    root_parent_path = root_path.parent
    setup_commands_path = root_parent_path / 'setup_commands.cfg'

    @contextlib.contextmanager
    def init_config(commands, **kwargs):
        setup_py_path = (
            root_parent_path / 'setup.py'
        ).relative_to(root_parent_path)
        setup_cfg_path = (
            root_parent_path / 'setup.cfg'
        ).relative_to(root_parent_path)

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

# Generated at 2022-06-23 18:31:53.089532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # NOTE: Unit test requires that the top level directory of the calling
    # project has a setup_commands.cfg file.
    out = {x.name: x for x in each_sub_command_config()}
    assert out['clear'].commands == (
        'python setup.py clean -all',
        'python setup.py sdist',
        'rm -rfv MANIFEST'
    )
    assert out['ci'].commands == (
        'python setup.py test',
        'python setup.py style',
        'python setup.py cover',
        'python setup.py report'
    )
    assert out['vendor'].commands == (
        'python setup.py clean',
        'python setup.py vendor'
    )

# Generated at 2022-06-23 18:32:00.404393
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    #
    # Valid test cases
    #
    conf = SetupCfgCommandConfig(
        name='test_cmd',
        camel='TestCmd',
        description='Test Command',
        commands=('echo test_cmd', 'echo {}'.format('TestCmd'))
    )
    assert conf.name == 'test_cmd'
    assert conf.camel == 'TestCmd'
    assert conf.description == 'Test Command'
    assert conf.commands == ('echo test_cmd', 'echo {}'.format('TestCmd'))
    #
    # Invalid test cases
    #

# Generated at 2022-06-23 18:32:08.680792
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re
    import sys
    import tempfile

    def _make_setup_cfg(setup_dir: str, name: str):
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w', encoding='utf-8') as fpr:
            fpr.write('\n[metadata]')
            fpr.write('\nname = %s\n' % name)

    def _make_setup_commands_cfg(setup_dir: str, commands_cfg: str):
        setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-23 18:32:17.779050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.scriptutils import ScriptUtils
    import contextlib2
    import pytest
    import shutil
    import tempfile

    here = os.path.abspath(os.path.dirname(__file__))
    # noinspection PyUnresolvedReferences
    pkg = cast(str, ScriptUtils.get_pkg(__file__))
    name = 'flutils'

    with contextlib2.ExitStack() as stack:
        tmp_dir = stack.enter_context(
            tempfile.TemporaryDirectory(prefix='%s_' % __name__)
        )

        setup_cfg = os.path.join(here, 'setup_commands.cfg')
        shutil.copy(setup_cfg, tmp_dir)


# Generated at 2022-06-23 18:32:27.433405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _tt(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> List[SetupCfgCommandConfig]:
        out = list(each_sub_command_config(setup_dir))
        # out = [SetupCfgCommandConfig(*repr(scc).split('(', 1)[1].rsplit(')', 1)[0].split(',')) for scc in out]
        return out

# Generated at 2022-06-23 18:32:29.337031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    list(each_sub_command_config('setup_commands/test_setup_commands'))

# Generated at 2022-06-23 18:32:40.158422
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sc: ConfigParser = ConfigParser()
    sc.add_section('metadata')
    sc.set('metadata', 'name', 'flutils')
    sc.add_section('setup.command.deploy')
    sc.set('setup.command.deploy', 'name', 'deploy')
    sc.set('setup.command.deploy', 'description', 'Deploy to PyPI.')
    sc.set(
        'setup.command.deploy', 'commands',
        "python setup.py sdist bdist_wheel\n"
        "python setup.py register -r pypi\n"
        "python setup.py upload -r pypi"
    )

    sc2: ConfigParser = ConfigParser()
    sc2.add_section('setup.command.foo')

# Generated at 2022-06-23 18:32:45.430148
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig('name', 'camel', 'description', ('a', 'b'))
    print(config)
    assert config.name == 'name'
    assert config.camel == 'camel'
    assert config.description == 'description'
    assert config.commands == ('a', 'b')

# Generated at 2022-06-23 18:32:53.836781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    SETUP_CMD_DIR = os.path.join(SCRIPT_DIR, 'fixtures', 'setup_commands')
    paths = tuple(map(
        lambda d: os.path.join(SETUP_CMD_DIR, d),
        os.listdir(SETUP_CMD_DIR)
    ))
    for path in paths:
        out = list(each_sub_command_config(path))
        # print(out)
        assert out
        assert len(out) == 1
        cfg = cast(SetupCfgCommandConfig, out[0])
        assert cfg.name
        assert cfg.camel
        assert cfg.commands

# Generated at 2022-06-23 18:33:02.933529
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    section: str = 'setup.command.install.clean'
    command_name: str = 'install.clean'
    parser: ConfigParser = ConfigParser()
    parser.add_section(section)
    parser.set(section, 'name', 'install_clean')
    parser.set(section, 'description', 'cleans and then installs')
    parser.set(section, 'command', 'rm -rf dist\npython setup.py install')
    for setup_cfg_command_config in _each_setup_cfg_command(parser, {}):
        assert isinstance(setup_cfg_command_config, SetupCfgCommandConfig)
        assert setup_cfg_command_config.name == 'install_clean'
        assert setup_cfg_command_config.camel == 'InstallClean'

# Generated at 2022-06-23 18:33:15.221056
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'testdata', 'setupcfg'
        )
    )
    assert os.path.isdir(setup_dir)

    subcmd_path = os.path.join(
        setup_dir,
        'flutils',
        'tests',
        'testdata',
        'setupcfg',
        'setup_commands.cfg'
    )
    subcmd_path = os.path.realpath(subcmd_path)
    assert os.path.isfile(subcmd_path)

    config = list(each_sub_command_config(setup_dir))
    assert len(config) == 7


# Generated at 2022-06-23 18:33:25.655196
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, realpath
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.configutils import each_sub_command_config
    from tests.configutils import get_test_config

    def _run(
            test_case: TestCase,
            config: str,
            setup_dir: str,
            expected_setup_dir: str,
            expected_name: str,
            expected_camel: str,
            expected_description: str,
            expected_commands: Tuple[str, ...]
    ) -> None:
        with patch('flutils.configutils.os.path.realpath') as m_realpath, \
                patch('flutils.configutils.os.path.expanduser') as m_expanduser:
            m_real

# Generated at 2022-06-23 18:33:38.498789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from flutils.configutils import reset_config


    class EachSubCommandConfigTestCase(TestCase):

        def setUp(self):
            self.setup_dir = TemporaryDirectory()


        def tearDown(self):
            reset_config()
            self.setup_dir.cleanup()



# Generated at 2022-06-23 18:33:48.800353
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import contextmanager
    from argparse import ArgumentParser
    from pytest import raises
    from pprint import pformat
    from io import StringIO

    @contextmanager
    def redirect_stdout(new_out: StringIO) -> Generator[None, None, None]:
        old_out = sys.stdout
        try:
            sys.stdout = cast(StringIO, new_out)
            yield
        finally:
            sys.stdout = old_out

    with redirect_stdout(StringIO()) as out:
        parser = ArgumentParser()
        subparsers = parser.add_subparsers(
            title='sub-commands',
            description='sub-commands',
            dest='sub_command'
        )

# Generated at 2022-06-23 18:33:49.873390
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-23 18:33:59.833976
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    config = SetupCfgCommandConfig(
        'command_name',
        'CommandName',
        'Description of command',
        ('Python command to run',)
    )
    assert config.name == 'command_name'
    assert config.camel == 'CommandName'
    assert config.description == 'Description of command'
    assert config.commands == ('Python command to run',)
    assert str(config) == (
        "SetupCfgCommandConfig("
        "name='command_name', "
        "camel='CommandName', "
        "description='Description of command', "
        "commands=('Python command to run',))"
    )

# Generated at 2022-06-23 18:34:02.799047
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    print("Testing SetupCfgCommandConfig...")
    test_command = SetupCfgCommandConfig("hi", "hi", "hi", ("hi",))


# Generated at 2022-06-23 18:34:13.279980
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=unused-variable
    from flutils import setup_utils as u

    for c in u.each_sub_command_config():
        if c.name == 'example.hello':
            assert c.description == (
                "Run the Python example hello console program."
            )
            assert 'python example/hello.py' in c.commands


if __name__ == '__main__':
    for c in each_sub_command_config():
        print("= "*17)
        print("Name: %s" % c.name)
        print("Camel: %s" % c.camel)
        print("Description: %s" % c.description)
        print("Commands:")

# Generated at 2022-06-23 18:34:16.733948
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    obj = SetupCfgCommandConfig('name', 'camel', 'description', ('cmd',))
    assert obj.name == 'name'
    assert obj.camel == 'camel'
    assert obj.description == 'description'
    assert obj.commands == ('cmd',)


# Generated at 2022-06-23 18:34:24.317579
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Tests the function :func:`each_sub_command_config`.
    """
    commands: List[SetupCfgCommandConfig] = list(each_sub_command_config('.'))
    assert len(commands) == 1
    print('=' * 79)
    print()
    print('Each sub-command config:')
    output = '{0.camel} {0.commands[0]}'.format(commands[0])
    print(output)
    print()
    print('=' * 79)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-23 18:34:35.393940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from importlib import reload
    import builtins

    reload(flutils)
    reload(flutils.setuputils)
    reload(builtins)

    def _mocked_configparser_sections(*args, **kwargs):
        return (
            'metadata',
            'setup.command.test',
            'setup.command.test_config',
            'setup.command.test_config.test',
            'setup.command.test_config.test.validate',
            'setup.command.test.validate',
            'setup.command.test.validate.nest',
            'setup.command.test.validate.nest.l'
        )


# Generated at 2022-06-23 18:34:40.217335
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    parameters = ["name", "camel", "description", "commands"]
    setup_cfg_command_config = SetupCfgCommandConfig(
        "name", "camel", "description", "commands")
    assert len(parameters) == len(setup_cfg_command_config)

    for i, parameter in enumerate(parameters):
        assert getattr(setup_cfg_command_config, parameter) == setup_cfg_command_config[i]


# Generated at 2022-06-23 18:34:48.797613
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os.path
    import sys
    import shutil
    import tempfile


# Generated at 2022-06-23 18:34:54.450020
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    # Given
    command_config = SetupCfgCommandConfig(
        'name',
        'Camel',
        'description',
        ('a', 'b'),
    )

    # When / Then
    assert command_config.name == 'name'
    assert command_config.camel == 'Camel'
    assert command_config.description == 'description'
    assert command_config.commands == ('a', 'b')

# Generated at 2022-06-23 18:35:04.815242
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import path

    from os import chdir
    from os.path import dirname, realpath, join

    try:
        root = realpath(__file__)
        for i in range(4):
            root = dirname(root)
        chdir(root)
        from flutils.setup_utils import each_sub_command_config
    except Exception:
        path.insert(0, join(dirname(__file__), '..'))
        path.insert(0, join(dirname(__file__), '..', '..'))

    if 'tests' not in root:
        root = realpath(__file__)
        for i in range(5):
            root = dirname(root)
        assert 'tests' in root
        chdir(root)


# Generated at 2022-06-23 18:35:13.943948
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from test.test_setup_cfg import test_setup_cfg_dir

    configs: List[SetupCfgCommandConfig] = []
    for config in each_sub_command_config(setup_dir=test_setup_cfg_dir):
        configs += [config]

# Generated at 2022-06-23 18:35:19.196582
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sccc = SetupCfgCommandConfig('1', '2', '3', ('4',))
    assert(sccc.name == '1')
    assert(sccc.camel == '2')
    assert(sccc.description == '3')
    assert(sccc.commands == ('4',))

# Generated at 2022-06-23 18:35:20.840724
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    assert SetupCfgCommandConfig('name', 'Name', 'description', (), )

# Generated at 2022-06-23 18:35:25.961459
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(
            '/home/derek/github/flutils'
    ):
        print(config)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 18:35:29.953592
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    cc = SetupCfgCommandConfig('test_name', 'TestName', 'test description', ('cmd1', 'cmd2'))
    assert cc.name == 'test_name'
    assert cc.camel == 'TestName'
    assert cc.description == 'test description'
    assert cc.commands == ('cmd1', 'cmd2')

# Generated at 2022-06-23 18:35:41.394679
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import sys

    def show_Test(msg: str, obj: object) -> None:
        print(('%s: %s' % (msg, repr(obj))))
        print(('  %s.__class__: %s' % (msg, repr(obj.__class__))))
        print(('  %s.__name__: %s' % (msg, repr(obj.__name__))))

    if __name__ == '__main__':
        show_Test('sys', sys)
        show_Test('sys.modules[__name__]', sys.modules[__name__])
        show_Test('SetupCfgCommandConfig', SetupCfgCommandConfig)

    assert sys.modules[__name__] == SetupCfgCommandConfig
    assert SetupCfgCommandConfig.__name__ == 'SetupCfgCommandConfig'


# Generated at 2022-06-23 18:35:45.743174
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import setup_commands
    for config in each_sub_command_config(setup_commands.__path__[0]):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands



# Generated at 2022-06-23 18:35:50.783554
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    x = SetupCfgCommandConfig(
        name='test_command',
        camel='TestCommand',
        description='run tests',
        commands=('echo', 'test')
    )
    x = SetupCfgCommandConfig(
        name='test_command2',
        camel='TestCommand2',
        description='run tests2',
        commands=('echo2', 'test2')
    )

# Generated at 2022-06-23 18:36:00.355150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    setup_dir = os.path.dirname(__file__)
    assert setup_dir.endswith('test')
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.join(setup_dir, 'setup_commands')
    setup_dir = os.path.expanduser(setup_dir)
    expected = (
        'setup.command.test',
        'Test command not associated with a module.'
    )
    for config in each_sub_command_config(setup_dir):
        assert config.name == expected[0]
        assert config.commands[0].find(expected[1]) > -1
        break

# Generated at 2022-06-23 18:36:01.961395
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    name = SetupCfgCommandConfig("name", "camel", "description", ("command"))

# Generated at 2022-06-23 18:36:07.891919
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    sc = SetupCfgCommandConfig('name', 'camel', 'description', ('command',))
    assert sc.name == 'name'
    assert sc.camel == 'camel'
    assert sc.description == 'description'
    assert sc.commands == ('command',)


# Generated at 2022-06-23 18:36:17.715421
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os.path
    import tempfile
    import shutil
    import unittest
    import random

    curr = os.path.abspath(os.path.dirname(__file__))
    pkg_dir = os.path.join(curr, '..', '..')
    pkg_dir = os.path.abspath(pkg_dir)

    class TestEachSubCommandConfig(unittest.TestCase):

        def _prep_dir(self, tmpdir, name='setup.py'):
            """Creates the ``setup.py`` file."""
            val = """#!%s -u

from setuptools import setup

setup()
"""
            val %= sys.executable
            path = os.path.join(tmpdir, 'setup.py')

# Generated at 2022-06-23 18:36:25.090020
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    import tempfile
    from itertools import islice


# Generated at 2022-06-23 18:36:37.281966
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        home_dir = os.path.expanduser('~')
        setup_py_text = '''"""A setup.py file."""\n'''
        with open(os.path.join(tempdir, 'setup.py'), 'wt') as f:
            f.write(setup_py_text)
        setup_cfg_text = '''[metadata]
name={{ name }}

[setup.command.hello]
name={{ name }}-hello
description=Hello
command=ls {home}\n'''
        with open(os.path.join(tempdir, 'setup.cfg'), 'wt') as f:
            f.write(setup_cfg_text)

# Generated at 2022-06-23 18:36:41.736778
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    try:
        # pylint: disable=expression-not-assigned
        SetupCfgCommandConfig(
            name='',
            camel='',
            description='',
            commands=tuple(),
        )
    except:  # noqa: E722
        assert "Incorrect instantiation of class SetupCfgCommandConfig"

# Generated at 2022-06-23 18:36:53.625548
# Unit test for constructor of class SetupCfgCommandConfig
def test_SetupCfgCommandConfig():
    path = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(path, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {
        'setup_dir': path,
        'name': 'myproj',
        'home': os.path.expanduser('~')
    }

    sc = _each_setup_cfg_command(parser, format_kwargs)
    cfg_list = list(sc)
    assert len(cfg_list) == 2
    assert cfg_list[0].name == 'myproj'
    assert cfg_list[0].camel == 'Myproj'
    assert cfg_list[0].description == 'My Project'
    assert cfg

# Generated at 2022-06-23 18:37:04.240724
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pyutils import get_func_name
    from os import (
        makedirs,
        remove,
    )
    from os.path import (
        dirname,
        exists,
        isdir,
        isfile,
    )
    from tempfile import TemporaryDirectory

    # Check when no setup.cfg exists
    curr_dir = dirname(__file__)