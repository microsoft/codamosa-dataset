

# Generated at 2022-06-11 22:36:20.553930
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    for config in each_sub_command_config(here):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:30.501518
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, os.pardir)
    path = os.path.abspath(path)
    results = list(each_sub_command_config(path))
    _results = list(results)
    commands = (
        'python -m pytest', 'python setup.py test', 'pip install .'
    )
    assert _results[0] == SetupCfgCommandConfig(
        'install',
        'Install',
        'Installs the library',
        commands
    )
    assert results[1] == _results[1]

# Generated at 2022-06-11 22:36:42.575181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import join, dirname, realpath
    from os import getenv
    from sys import path

    from flutils.pathutils import add_to_sys_path
    from flutils.sysutils import safe_getenv
    from flutils.sysutils import where_am_i, get_func_caller_module

    caller_mod_name = get_func_caller_module(0, __name__)
    caller_mod_name = caller_mod_name if caller_mod_name else __name__
    caller_mod_path = where_am_i(1, __name__)
    caller_mod_path = caller_mod_path if caller_mod_path else __name__
    caller_mod_path = dirname(realpath(caller_mod_path))

# Generated at 2022-06-11 22:36:53.476662
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as setup_dir:
        setup_dir = os.path.join(setup_dir, 'project1')
        os.makedirs(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        setup_commands_path = os.path.join(setup_dir, 'setup_commands.cfg')


# Generated at 2022-06-11 22:37:06.545049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import textwrap

    from flutils.setup_utils import (
        each_sub_command_config,
        get_setup_command_name,
    )
    from utils import (
        this_package_path,
        this_package_src_path,
    )

    get_setup_command_name()  # Just to create the current dir entry

    out = list(
        each_sub_command_config(
            setup_dir=this_package_path('setup_utils')
        )
    )
    assert len(out) == 12
    assert out[0].name == 'flutils.test.test_setup_utils.test_each_sub_command_config'
    assert out[0].camel == 'FlutilsTestTestSetupUtilsTestEachSubCommandConfig'
    assert out[0].description

# Generated at 2022-06-11 22:37:14.299094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'data', 'setup_cb')
    out = list(each_sub_command_config(setup_dir))
    expected = [
        SetupCfgCommandConfig(
            'test.command',
            'TestCommand',
            'Test sub-command.',
            (
                'python -m flutils.testing.setup_helpers.test_helper '
                'test_command',
                'pytest',
                'python -m pdb flutils.testing.setup_helpers.test_helper '
                'test_command',
            )
        )
    ]
    assert out == expected

# Generated at 2022-06-11 22:37:25.683268
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import shutil
    import tempfile
    import unittest
    import itertools
    from pathlib import Path
    class TestEachSubCommandConfig(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

# Generated at 2022-06-11 22:37:35.009782
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from pprint import pprint
    from flutils.fllogging import StreamOnlyLogHandler

    logger = getLogger('each_sub_command_config')
    handler = StreamOnlyLogHandler()
    logger.addHandler(handler)
    base = os.path.dirname(os.path.realpath(__file__))
    base = os.path.realpath(
        os.path.join(base, '..', '..', '..', '..', '..', '..', '..')
    )
    path = os.path.join(
        base, 'setup.py'
    )
    assert os.path.isfile(path)

    gen = each_sub_command_config(base)
    try:
        pprint(next(gen))
    except StopIteration:
        logger.debug

# Generated at 2022-06-11 22:37:45.292885
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    from flutils.pathutils import realpath
    from sys import executable
    from tempfile import TemporaryDirectory

    def _create_setup_cfg(setup_dir: str) -> None:
        path = os.path.join(setup_dir, 'setup.cfg')
        with open(path, 'w') as fp:
            fp.write(
                '\n'.join((
                    '[metadata]',
                    'name = {name}'
                ))
            )
        path = os.path.join(setup_dir, 'setup.py')
        with open(path, 'w') as fp:
            fp.write(
                '\n'.join((
                    'import setuptools',
                    'setup()'
                ))
            )

# Generated at 2022-06-11 22:37:53.474682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io

    saved_sys_stdout = sys.stdout
    saved_sys_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    try:
        for setup_cfg_command in each_sub_command_config():
            print(setup_cfg_command.name)
    finally:
        print(sys.stdout.getvalue())
        print(sys.stderr.getvalue(), file=sys.stdout)
        sys.stdout = saved_sys_stdout
        sys.stderr = saved_sys_stderr

# Generated at 2022-06-11 22:38:08.375723
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.tests.runner
    setup_dir = os.path.dirname(
        os.path.dirname(flutils.tests.runner.__file__)
    )
    each_sub_command_config(setup_dir)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:17.219595
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Verify the function returns a generator.
    assert hasattr(each_sub_command_config(), '__next__') is True
    # Verify the example program directory works.
    dir_ = os.path.dirname(os.path.dirname(__file__))
    dir_ = os.path.join(dir_, 'example')
    commands: Dict[str, Tuple[str, str]] = {}
    for cmd in each_sub_command_config(dir_):
        commands[cmd.name] = (cmd.description, cmd.camel)

    assert commands['pre_commit.install'] == (
        'Install the pre-commit hooks.', 'PreCommitInstall'
    )
    assert commands['pre_commit.update'] == (
        'Update the pre-commit hooks.', 'PreCommitUpdate'
    )

# Generated at 2022-06-11 22:38:17.969572
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-11 22:38:29.378347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from shutil import copy2

    with TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        setup_py_path = os.path.join(tmpdir, 'setup.py')
        os.mknod(setup_py_path)

        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        os.mknod(setup_cfg_path)

        setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')


# Generated at 2022-06-11 22:38:38.305783
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _assert_each_sub_command_config(
            path_to_setup_dir: str,
            *,
            setup_cfg: Dict[str, str] = {},
            setup_commands_cfg: Dict[str, str] = {},
            expected: Tuple[Dict[str, str], ...]
    ) -> None:
        os.chdir(os.path.dirname(__file__))
        path = os.path.abspath(path_to_setup_dir)
        if os.path.exists(path) is False:
            os.mkdir(path, mode=0o700)
        with open(os.path.join(path, 'setup.py'), 'w') as fp:
            fp.write("# dummy setup.py file\n")


# Generated at 2022-06-11 22:38:48.497344
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import sys
    import shutil
    import os


    class _TestCfg:
        def __init__(self):
            if hasattr(tempfile, 'TemporaryDirectory'):
                self.setup_dir = tempfile.TemporaryDirectory()
            else:
                self.setup_dir = tempfile.mkdtemp()

            self.setup_cfg_path = os.path.join(self.setup_dir.name,
                                               'setup.cfg')

            self.setup_commands_cfg_path = \
                os.path.join(self.setup_dir.name, 'setup_commands.cfg')
            self.setup_py_path = os.path.join(self.setup_dir.name, 'setup.py')
            self.cleanup = False

            self.parser = Config

# Generated at 2022-06-11 22:38:59.001319
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root = os.path.abspath(os.path.dirname(__file__))
    root = os.path.dirname(root)
    root = os.path.dirname(root)
    out = list(each_sub_command_config(root))

# Generated at 2022-06-11 22:39:04.697598
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.config import app_cmd_config_file, update_default_config
    # Forces the defaults
    update_default_config(app_cmd_config_file)
    for i in each_sub_command_config():
        print(i)

# Generated at 2022-06-11 22:39:13.340858
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    assert list(each_sub_command_config()) == [
        SetupCfgCommandConfig(
            'coverage3',
            'Coverage3',
            'Run the test suite with coverage3',
            ('coverage3 run -m unittest discover',),
        ),
        SetupCfgCommandConfig(
            'coverage',
            'Coverage',
            'Run the test suite with coverage',
            ('coverage run -m unittest discover',),
        ),
        SetupCfgCommandConfig(
            'test',
            'Test',
            'Run the test suite',
            ('python3 -m unittest discover',),
        ),
        SetupCfgCommandConfig(
            'test2', 'Test2', 'Run the test suite again', ('python -m unittest',)
        )
    ]


# Generated at 2022-06-11 22:39:19.246496
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands = tuple(
        each_sub_command_config(
            os.path.expanduser('~/Projects/flutils')
        )
    )
    # print(*map(lambda x: x.name, commands), sep='\n')
    assert len(commands) >= 1

# Generated at 2022-06-11 22:39:47.788434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.systemutils import cwd
    with cwd('tests'):
        for scc in each_sub_command_config():
            print(scc)


__all__ = (
    'SetupCfgCommandConfig',
    'each_sub_command_config',
    'test_each_sub_command_config'
)

# Generated at 2022-06-11 22:39:55.554464
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import click
    import click.testing
    import sys
    import unittest

    testdir = os.path.dirname(os.path.realpath(__file__))
    testdir = os.path.join(testdir, 'testdata', 'python')

    class TestClickUtils(unittest.TestCase):
        def test_each_sub_command(self):
            commands: List[str] = []
            for config in each_sub_command_config(testdir):
                commands.append(config.name)
            self.assertListEqual(
                sorted(commands),
                [
                    'cleanup',
                    'cov',
                    'deps',
                    'sdist',
                    'test',
                ]
            )


# Generated at 2022-06-11 22:40:07.591119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fileutils import get_path
    from unittest import TestCase
    from unittest.mock import patch

    class EachSubCommandConfigTest(TestCase):
        def setUp(self):
            self.setup_dir = get_path(__file__, '..')
            return

        def test_each_sub_command_config(self) -> None:
            out = None
            with patch('builtins.print') as mocked:
                out = list(each_sub_command_config(self.setup_dir))
            self.assertEqual(len(out), 2)
            print_out = '\n'.join(
                line
                for line in mocked.call_args[0] if line.startswith('    ')
            )
            print_out = print_out.strip()
            self

# Generated at 2022-06-11 22:40:10.335030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(__file__):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:21.055204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_filename(s: List[str]) -> str:
        s = s[0]
        return ':'.join(s.split(':')[1:]).strip()

    for scc in each_sub_command_config('/Users/dskoda/proj/flutils'):
        print('camel: %s' % scc.camel)
        print('name: %s' % scc.name)
        print('description: %s' % scc.description)
        print('commands:')
        for cmd in scc.commands:
            print('  %s' % cmd)
    print('Done')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:31.311999
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def lines(path: str) -> List[str]:
        with open(path, mode='rt', encoding='utf-8') as f:
            lines = f.readlines()
        return [
            line.strip() for line in lines
            if line.strip() and not line.strip().startswith('#')
        ]

    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        setup_cfg = os.path.join(tempdir, 'setup.cfg')

# Generated at 2022-06-11 22:40:43.382122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def _make_dirs(dirpath: Path) -> None:
        if dirpath.exists():
            return
        os.makedirs(dirpath)
        return

    def _setup(dirpath: Path):
        setup_dir = dirpath / 'mypkg'
        _make_dirs(setup_dir)
        setup0 = setup_dir / 'setup.py'
        setup0.touch()
        setup_cfg = setup_dir / 'setup.cfg'

# Generated at 2022-06-11 22:40:56.018269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import sys

    here = os.path.dirname(__file__)
    if not here:
        here = '.'
    sys.path.insert(0, here)
    try:
        import test_each_sub_command_config
    finally:
        sys.path.pop(0)

    test_dir = os.path.join(here, 'test_data', 'test_each_sub_command_config')
    pprint.pprint(
        list(each_sub_command_config(test_dir)),
        width=80,
        indent=4
    )


if __name__ == '__main__':
    from argparse import ArgumentParser


# Generated at 2022-06-11 22:41:03.368816
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    parser = ConfigParser()
    with open('setup_commands.cfg', 'r') as f:
        parser.read_file(f)
    for section, command_name in _each_setup_cfg_command_section(parser):
        commands: List[str] = []
        options: List[str] = parser.options(section)
        for option in ('command', 'commands'):
            if option in options:
                val: str = parser.get(section, option)
                commands += list(
                    filter(len, map(lambda x: x.strip(), val.splitlines()))
                )
        if commands:
            cmd_name = ''
            if 'name' in options:
                cmd_name = parser.get(section, 'name')
            cmd_name = cmd_name or command_name
            cmd_name

# Generated at 2022-06-11 22:41:10.706382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io

    def _clean_stack(
            out: Union[io.StringIO, io.TextIOBase]
    ) -> Tuple[str, List[FrameSummary]]:
        stack = extract_stack()
        lines = []
        for fs in stack:
            fs = cast(FrameSummary, fs)
            filename = os.path.basename(fs.filename)
            lineno = fs.lineno
            name = fs.name
            line = 'File %s, line %s, in %s' % (filename, lineno, name)
            lines.append(line)
        lines = sorted(lines)
        out = out.getvalue().strip().splitlines()
        out = sorted(out)
        return tuple(out), lines

    sys.stdout = out = io.StringIO()

# Generated at 2022-06-11 22:42:09.794113
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _check(
            setup_dir: Union[str, None],
            expected_cmd_name: str,
            expected_cmd_camel: str,
            expected_cmd_description: str,
            expected_cmd_commands: Tuple[str, ...]
    ) -> None:
        count = 0
        for setup_cfg_config in each_sub_command_config(setup_dir):
            count += 1
            assert isinstance(setup_cfg_config, SetupCfgCommandConfig)
            assert setup_cfg_config.name == expected_cmd_name
            assert setup_cfg_config.camel == expected_cmd_camel
            assert setup_cfg_config.description == expected_cmd_description
            assert setup_cfg_config.commands == expected_cmd_commands
        assert count == 1


# Generated at 2022-06-11 22:42:17.446888
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.tmp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = os.path.realpath(self.tmp_dir.name)
            self.path = os.path.join(self.setup_dir, 'setup.cfg')


# Generated at 2022-06-11 22:42:19.378165
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    assert configs

# Generated at 2022-06-11 22:42:30.394818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from itertools import chain

    def _expect_eq(expected, actual):
        if set(expected) != set(actual):
            msg = "Expected %r, but got %r."
            raise AssertionError(msg % (expected, actual))

    expected = [
        'build_sphinx',
        'check_setup',
        'clean_all',
        'coverage',
        'coverage_html',
        'test',
        'test_all',
        'test_clean_all',
        'test_coverage',
        'test_coverage_html',
        'test_run',
        'test_run_all',
        'test_run_tox',
        'upload',
    ]

# Generated at 2022-06-11 22:42:36.838084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # When the setup.cfg file is found
    for cfg in each_sub_command_config():
        pass

    # When
    for cfg in each_sub_command_config('/tmp'):
        pass

    # When an exception is expected.
    #   FileNotFoundError
    try:
        for _ in each_sub_command_config('/tmp/doesnotexist'):
            pass
    except FileNotFoundError:
        pass
    try:
        for _ in each_sub_command_config('/etc/hosts'):
            pass
    except FileNotFoundError:
        pass
    try:
        for _ in each_sub_command_config():
            break
    except FileNotFoundError:
        pass

# Generated at 2022-06-11 22:42:39.341932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:40.800690
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for c in each_sub_command_config():
        pass



# Generated at 2022-06-11 22:42:42.930032
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_cfg in each_sub_command_config():
        assert cmd_cfg is not None

# Generated at 2022-06-11 22:42:52.507058
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    from pprint import pprint
    from flutils.pathutils import (
        get_data_directory,
        sys_data_directory,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    for config in each_sub_command_config(
            sys_data_directory('unittest_each_sub_command_config/')
    ):
        pprint(config)

    for config in each_sub_command_config(
            get_data_directory('unittest_each_sub_command_config/')
    ):
        pprint(config)

# Generated at 2022-06-11 22:42:54.003165
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for scc in each_sub_command_config():
        pass

# Generated at 2022-06-11 22:44:34.021043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import subprocess
    import sys
    base = os.path.dirname(os.path.abspath(__file__))
    base = os.path.join(base, 'testdata')
    tests = (
        'basic1',
        'basic2',
        'basic3',
    )
    for test in tests:
        test = os.path.join(base, test)
        cmd = ['python', 'setup.py', '--help-commands']
        if sys.platform == 'win32':
            cmd = ['cmd', '/c'] + cmd
        stdout = subprocess.check_output(cmd, cwd=test)
        stdout = stdout.decode('utf-8')
        config = list(each_sub_command_config(test))
        assert len(config) == len

# Generated at 2022-06-11 22:44:44.223305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with cd_test_dir():
        out = list(each_sub_command_config(test_dir))

# Generated at 2022-06-11 22:44:49.599590
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        setup_cfg_path = temp_dir / 'setup.cfg'
        setup_cfg_path.write_text('''
[metadata]
name: foo

[setup.command.bar]
command = bar

[setup.command.baz]
commands =
    cd {setup_dir}
    python -c "import os; cur_dir = os.path.abspath(os.curdir); print(cur_dir)"

[setup.command.qux]
description = Hello, world!
name = {name}.qux
commands =
    cd {setup_dir}
    python -c "print('qux')"
''')

# Generated at 2022-06-11 22:45:02.538918
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import cd
    from flutils import create_test_file
    from tempfile import TemporaryDirectory
    from .setup_commands import setup_commands

    def _list_commands(uwsgi_commands: bool = False) -> List[str]:
        out: List[str] = []
        for scc in each_sub_command_config():
            commands = scc.commands
            if uwsgi_commands is True and commands[0].startswith('uwsgi'):
                commands = commands[1:]
            out += commands
        return out

    def _assert_commands(commands: List[str]) -> None:
        assert len(commands) == 10
        assert commands[0] == 'python setup.py clean --all'

# Generated at 2022-06-11 22:45:10.235614
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function setup_cfg.each_sub_command_config."""
    from . import setup_cfg
    from flutils.pathutils import Path

    TESTS_DIR = Path(__file__).parent
    setup_dir = TESTS_DIR.joinpath('setup.py').parent
    with setup_dir.joinpath('setup_commands.cfg').open() as fh:
        data = fh.read()
    with setup_dir.joinpath('setup_commands.cfg').open('w') as fh:
        fh.write(data.replace('command = ', 'commands = '))

# Generated at 2022-06-11 22:45:16.388305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    pprint.pprint(
        list(each_sub_command_config(setup_dir='/Users/kevinlawler/workspace'))
    )


if __name__ == '__main__':
    import sys
    test_name = sys.argv[1]
    locals()[test_name]()

# Generated at 2022-06-11 22:45:24.946669
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from flutils.pyutils import get_func_name
    from pprint import pformat
    from tempfile import TemporaryDirectory

    tdir = TemporaryDirectory()
    tdirname = tdir.name
    home = os.path.expanduser('~')
    setup_dir = os.path.join(tdirname, 'project')
    os.mkdir(setup_dir)

# Generated at 2022-06-11 22:45:29.225963
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .test_utils import CUR_DIR
    import pprint

    pprint.pprint(
        tuple(each_sub_command_config(setup_dir=CUR_DIR)),
        width=1
    )

# Generated at 2022-06-11 22:45:30.767045
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(__file__)
    dir_name = os.path.dirname(path)
    dir_name = os.path.dirname(dir_name)
    assert each_sub_command_config(dir_name) is not None

# Generated at 2022-06-11 22:45:38.358403
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # type: () -> None
    def check(
            cmds: Union[List[SetupCfgCommandConfig], None],
            setup_dir: Optional[str] = None
    ) -> None:
        # type: (...) -> None
        if setup_dir is not None:
            setup_dir = os.path.join(
                os.path.dirname(__file__), 'data', setup_dir
            )
        objs = list(each_sub_command_config(setup_dir=setup_dir))
        if cmds is None:
            assert not objs
        else:
            assert objs == cmds
