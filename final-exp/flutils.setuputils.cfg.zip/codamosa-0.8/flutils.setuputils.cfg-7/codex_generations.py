

# Generated at 2022-06-11 22:36:26.351526
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import namedtuple
    from pathlib import Path
    import textwrap

    test_setup_cfg_content = textwrap.dedent(
        '''
        [metadata]
        name = test_project
        '''
    )
    test_setup_commands_cfg_content = textwrap.dedent(
        '''
        [setup.command.my_sub_command]
        command =
            {name} my_sub_command.py --setup-dir {setup_dir} --home {home}
        name = sub command name
        '''
    )
    with tempfile.TemporaryDirectory() as working_dir:
        with open(os.path.join(working_dir, 'setup.cfg'), 'w') as fp:
            fp.write(test_setup_cfg_content)

# Generated at 2022-06-11 22:36:38.482698
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test with no setup_dir param
    # Also, tests with setup_dir of the directory that contains this file
    #   Also, tests with the setup.cfg file in a sub-directory,
    #   tests/etc
    #   Also, tests with the setup_commands.cfg file in a sub-directory,
    #   tests/etc/subdir
    configs = list(each_sub_command_config())
    assert len(configs) == 2

    configs.sort(key=lambda x: x.name)

    config = configs[0]
    assert config.name == 'subcmd1'
    assert config.camel == 'Subcmd1'
    assert config.description == 'My sub command 1'

# Generated at 2022-06-11 22:36:49.689972
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_dir = os.path.expanduser('~/github/ey-projects/cookiecutter-flutils')
    gen = each_sub_command_config(root_dir)

    out = list(gen)
    assert out
    assert len(out) == 1
    out = out[0]
    assert isinstance(out, SetupCfgCommandConfig)
    assert out.name == 'build_sphinx'
    assert out.camel == 'BuildSphinx'
    assert out.description
    assert len(out.commands) == 2
    assert out.commands[0].startswith('python -m ')
    assert out.commands[1].startswith('sphinx-build -b coverage')

# Generated at 2022-06-11 22:36:51.001559
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        # print(config)
        pass

# Generated at 2022-06-11 22:36:53.851119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    with pytest.raises(FileNotFoundError):
        next(each_sub_command_config())

if __name__ == '__main__':
    print(each_sub_command_config())

# Generated at 2022-06-11 22:37:06.880084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.systemutils import temp_cwd
    from flutils.textutils import indent

    with temp_cwd() as temp_cwd:
        setup_py_path = os.path.join(temp_cwd, 'setup.py')
        setup_cfg_path = os.path.join(temp_cwd, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(
            temp_cwd,
            'setup_commands.cfg'
        )

        with open(setup_py_path, 'w') as fout:
            fout.write('from setuptools import setup\n')
            fout.write('setup(name="test")\n')


# Generated at 2022-06-11 22:37:15.461045
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .unittest import unittest
    from .unittest import unittest_setup_cfg

    class EachSubCommandConfigTestCase(unittest.TestCase):
        """Tests for each_sub_command_config function."""

        def test_each_sub_command_config(self):
            """Test each_sub_command_config function."""

# Generated at 2022-06-11 22:37:19.216077
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import sub_commands
    from . import tests
    from . import flutils
    from . import utils
    from . import cli_tests


# Generated at 2022-06-11 22:37:28.226787
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test for the case where no custom commands are defined.
    configs = list(each_sub_command_config('setup-cfg-cmd-app'))
    assert len(configs) == 0

    # Test for the case where custom commands are defined.
    configs = list(each_sub_command_config('setup-cfg-cmd-app-with-commands'))
    assert len(configs) == 1
    assert configs[0] == SetupCfgCommandConfig(
        'my-command',
        'MyCommand',
        'My custom command.',
        (
            r'echo "Hello world!"',
        )
    )

# Generated at 2022-06-11 22:37:34.701198
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.tests

    gen = each_sub_command_config(
        setup_dir=os.path.join(
            os.path.dirname(flutils.tests.__file__),
            'test_data'
        )
    )
    cfg = next(gen)

    assert cfg.name == 'test.test_command'
    assert cfg.camel == 'Test_test_command'
    assert cfg.description == 'A test sub command.'
    assert cfg.commands == ('ls',)

    with pytest.raises(StopIteration):
        next(gen)

# Generated at 2022-06-11 22:37:55.139638
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_name = os.path.realpath(os.path.dirname(__file__))
    cfg_path = os.path.join(dir_name, 'setup_commands.cfg')
    assert each_sub_command_config(dir_name) is not None
    assert each_sub_command_config(dir_name) != []
    cfgs = list(each_sub_command_config(dir_name))
    assert len(cfgs) == 2

    cfg = cfgs[0]

    assert cfg.name == 'test.config'
    assert cfg.camel == 'TestConfig'
    assert cfg.description == 'Test the config'

# Generated at 2022-06-11 22:38:01.047818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    test_setup_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test_setup')
    )
    #for cfg in each_sub_command_config(test_setup_dir):
    #    print(cfg)

# Generated at 2022-06-11 22:38:13.020248
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:38:25.245852
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.strutils import underscore_to_camel
    from pathlib import Path
    import sys
    import tempfile
    tmpdir = Path(tempfile.mkdtemp())
    os.chdir(tmpdir)
    conf = tmpdir.joinpath('setup.cfg')
    conf.write_text("""
[metadata]
name = example-pkg

[setup.command.test]
command =
    pytest -vv
    touch {setup_dir}/test-completed

[setup.command.ascii_art]
name = ascii-art
description = Some ASCII art.
command =
    echo 'ASCII Art!'
""")


# Generated at 2022-06-11 22:38:35.866410
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # This can be run as a pytest unit test.

    root_dir = os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )

    # yapf: disable

# Generated at 2022-06-11 22:38:42.864128
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for scc in each_sub_command_config('/Users/brentg/devel/flutils/tests/fixtures/test_project'):
        assert isinstance(scc.name, str)
        assert isinstance(scc.camel, str)
        assert isinstance(scc.description, str)
        assert isinstance(scc.commands, tuple)
        for cmd in scc.commands:
            assert isinstance(cmd, str)



# Generated at 2022-06-11 22:38:47.397285
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Create a unit test that validates the output
    #       of each_sub_command_config.
    return


__all__ = (
    'test_each_sub_command_config',
    'each_sub_command_config',
)

# Generated at 2022-06-11 22:38:58.409161
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import sys
    import unittest

    _each_setup_cfg_command_section: Callable[
        [ConfigParser], Generator[Tuple[str, str], None, None]] = \
        globals()['_each_setup_cfg_command_section']
    _each_setup_cfg_command: Callable[
        [ConfigParser, Dict[str, str]],
        Generator[SetupCfgCommandConfig, None, None]] = \
        globals()['_each_setup_cfg_command']

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config_no_commands(self):
            """Test for function each_sub_command_config when there are no
            commands defined in the setup.cfg file.
            """
            out = io

# Generated at 2022-06-11 22:39:07.742055
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        setup_dir,
    )
    from flutils.sysutils import (
        test_file_path,
    )
    cmd_path = test_file_path(
        'test_configutils',
        'test_setup_commands.cfg'
    )
    cwd = setup_dir(cmd_path)
    for sub_cmd in each_sub_command_config(cwd):
        assert sub_cmd.name
        assert sub_cmd.camel
        assert sub_cmd.description
        assert sub_cmd.commands

# Generated at 2022-06-11 22:39:13.131000
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for name, camel, description, commands in each_sub_command_config():
        if name == 'flutils.tests.build_commands.setup_commands.unit_tests':
            assert camel == "UnitTests"
            assert description == "Unit tests."
            assert commands == (
                'pytest -m "not integration and not end_to_end"',
                'pytest -m "integration and not end_to_end"',
                'pytest -m "end_to_end"'
            )
            return
    assert False

# Generated at 2022-06-11 22:39:40.196022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit-test for the function each_sub_command_config."""
    from flutils.pathutils import each_sub_dir
    this_dir = os.path.dirname(os.path.dirname(__file__))
    for dir_ in each_sub_dir(this_dir):
        print(dir_)
        for config in each_sub_command_config(dir_):
            print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:51.899255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if sys.argv[-1] != 'test':
        return
    test_dir = os.path.dirname(__file__)
    cwd = os.getcwd()
    os.chdir(test_dir)
    try:
        for cmd in each_sub_command_config():
            print(cmd)
    finally:
        os.chdir(cwd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:04.259204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from json import dumps

    from flutils.fileutils import temporary_file_ctx

    build_commands = (
        'echo 1',
        'echo 2',
        'echo 3',
        'echo 4',
        'echo 5',
    )
    install_commands = (
        'echo 6',
        'echo 7',
        'echo 8',
        'echo 9',
        'echo 10',
    )
    setup_cfg_fh = StringIO()

# Generated at 2022-06-11 22:40:12.416858
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import List, Tuple

    from flutils.configutils import (
        get_project_setup_commands,
        _get_name,
        parse_config,
    )
    _test_file_name = os.path.basename(__file__)

    def _yield_test_values():
        class _TestValues(NamedTuple):
            setup_dir: str
            ex_msg: Optional[str]
            sc_cmd_cfg: Optional[List[SetupCfgCommandConfig]]


# Generated at 2022-06-11 22:40:25.044057
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import os
    import sys
    import textwrap

    print(textwrap.dedent('''\
        ---> def test_each_sub_command_config():
    '''))
    print('\t>>> test_each_sub_command_config()')

# Generated at 2022-06-11 22:40:33.276567
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'sub')
    for sub_command in each_sub_command_config(setup_dir=path):
        assert sub_command.name == 'sub_1'
        assert sub_command.camel == 'Sub_1'
        assert sub_command.description == 'Subcommands for subproject.'
        assert tuple(sub_command.commands) == (
            'sub sub_1 do_something',
            'sub sub_1 do_something else'
        )
    path = os.path.join(path, 'sub_1')

# Generated at 2022-06-11 22:40:43.773733
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase

    class TestData(NamedTuple):
        name: str
        commands: Tuple[str, ...]
        description: str


# Generated at 2022-06-11 22:40:56.341165
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    import sys
    import unittest.mock as mock

    logger = logging.getLogger()

    class MockLoggingFilter:
        """A stand-in for the :meth:`~logger.add_filter` method."""
        def __init__(self, filter_: 'logging.Filter') -> None:
            """
            Args:
                filter_: The filter_ to :py:meth:`~__call__` the given
                    ``record`` against.
            """
            self.filter = filter_


# Generated at 2022-06-11 22:41:07.362995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    import shutil

    import pytest

    from flutils.testutils import (
        make_directory,
        make_file,
        make_file_contents,
    )

    # Create a temp directory and the fake sub-commands config file.
    tmp_dir = pathlib.Path(make_directory())
    setup_cfg_path = tmp_dir / 'setup.cfg'
    setup_cfg_path.touch()
    setup_commands_path = tmp_dir / 'setup_commands.cfg'
    setup_commands_path.touch()

    # Make sure the 'name' option is required.
    with pytest.raises(LookupError):
        list(each_sub_command_config(tmp_dir))

    # Make sure the 'name' option must be set.

# Generated at 2022-06-11 22:41:09.130901
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:09.792524
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import pkg_resources

    ect = io.StringIO()
    xt = io.StringIO()
    test_config = pkg_resources.resource_string(
        'flutils',
        os.path.join('tests', 'each_sub_command_config.cfg'))
    test_config = cast(bytes, test_config)
    test_config = test_config.decode('utf-8')
    parser = ConfigParser()
    parser.read_string(test_config)

    def _print_config(
            parser: ConfigParser,
            stream: io.TextIOBase
    ) -> None:
        for section, command_name in _each_setup_cfg_command_section(parser):
            stream.write('%r:\n' % section)

# Generated at 2022-06-11 22:42:17.446205
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from os.path import join

    from shutil import copyfile
    from pathlib import Path

    home_dir = Path.home()
    with TemporaryDirectory() as tmp_dir:
        package_name = 'pypackage'
        setup_dir = join(tmp_dir, package_name)
        os.mkdir(setup_dir)

        package_dir = join(tmp_dir, 'packages')
        os.mkdir(package_dir)

        setup_file = join(home_dir, '.setup_commands.cfg')
        if not os.path.isfile(setup_file):
            with open(setup_file, 'w') as fp:
                fp.write('')

        setup_file = join(setup_dir, 'setup.py')

# Generated at 2022-06-11 22:42:21.693699
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config(os.path.dirname(__file__)):
        assert str(sc)
        assert sc.name
        assert sc.commands
        assert sc.camel
        assert sc.description

# Generated at 2022-06-11 22:42:31.906889
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _validate(setup_cfg_command_configs):
        assert setup_cfg_command_configs
        for setup_cfg_command_config in setup_cfg_command_configs:
            assert setup_cfg_command_config.name != ''
            assert setup_cfg_command_config.commands != ''
            assert setup_cfg_command_config.description != ''

    setup_dir = os.path.abspath(
        os.path.join(__file__, os.pardir, os.pardir, os.pardir)
    )
    setup_cfg_command_configs = list(
        each_sub_command_config(setup_dir=setup_dir)
    )
    _validate(setup_cfg_command_configs)

# Generated at 2022-06-11 22:42:36.389572
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    out = list(each_sub_command_config(setup_dir))
    assert len(out) == 6
    commands = [
        cmd.commands for cmd in out
        if cmd.name == 'setup_commands.extract_sub_commands'
    ]
    assert len(commands) == 2
    assert commands == [['python setup.py extract_sub_commands']] * 2

# Generated at 2022-06-11 22:42:39.768432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config(os.path.dirname(__file__)):
        assert isinstance(sub_command, SetupCfgCommandConfig)

# Generated at 2022-06-11 22:42:45.676837
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfg = each_sub_command_config()
    cfg = list(cfg)
    assert cfg[0].commands[0] == 'echo "No Setup Dir!"'
    cfg = each_sub_command_config(os.path.dirname(__file__))
    cfg = list(cfg)
    assert cfg[0].commands[0] == 'echo "Setup Dir"'

# Generated at 2022-06-11 22:42:56.363713
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        setup_py_path = os.path.join(tmp_dir, 'setup.py')
        with open(setup_py_path, 'w') as fp:
            fp.write('# -*- coding: utf-8 -*-')

        setup_cfg_path = os.path.join(tmp_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                "[metadata]\nname = flutils\n"
            )

        setup_commands_cfg_path = os.path.join(tmp_dir, 'setup_commands.cfg')

# Generated at 2022-06-11 22:43:01.329968
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    results = [x for x in each_sub_command_config()]
    assert isinstance(results, list) is True
    assert len(results) >= 1
    assert isinstance(results[0], SetupCfgCommandConfig) is True

# Generated at 2022-06-11 22:43:08.849949
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.expanduser('~')
    path = os.path.join(path, 'Projects', 'flutils')
    path = os.path.join(path, 'flutils', 'tests', 'data', 'project_for_setup')
    path = os.path.abspath(path)
    for config in each_sub_command_config(setup_dir=path):
        assert config is not None
        for pstr in (config.name, config.camel, config.description):
            assert pstr is not None
        for cmd in config.commands:
            assert cmd is not None
            assert len(cmd) > 0
        break



# Generated at 2022-06-11 22:44:47.912858
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    root = os.path.abspath(os.path.join(here, '..', '..'))
    root = os.path.abspath(os.path.join(root, '..', '..'))
    root = os.path.abspath(os.path.join(root, '..'))
    for config in each_sub_command_config(root):
        assert config.name, config.name
        assert config.camel, config.camel
        assert config.description, config.description
        assert config.commands, config.commands

# Generated at 2022-06-11 22:45:00.398607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import unittest
    import os

    class TestEachSubCommandConfig(unittest.TestCase):
        """Test class for function each_sub_command_config."""

        def setUp(self):
            self.cp = ConfigParser()
            self.cp.optionxform = str
            self.cp.add_section('metadata')
            self.cp.set('metadata', 'name', 'flutils')

            self.cp.add_section('setup.command.test_option_1')
            self.cp.set('setup.command.test_option_1', 'name', 'test-option-1')
            self.cp.set('setup.command.test_option_1', 'description',
                        'Test Command Option #1')

            self.cp.add

# Generated at 2022-06-11 22:45:09.006609
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import assert_each_item
    from flutils.testutils import set_cwd_to_tmp_dir
    from pathlib import (
        Path,
        PurePath
    )

    # Set up the test directory
    with set_cwd_to_tmp_dir():
        (Path('setup_commands.cfg')
            .write_text('''
                [metadata]
                name = {name}

                [setup.command.foo]
                name = foo
                description = This is the foo command

                [setup.command.bar]
                name = bar
                description = This is the bar command

                [setup.command.two]
                commands =
                    {setup_dir}/two_first.sh
                    {setup_dir}/two_second.sh
                '''))
        Path

# Generated at 2022-06-11 22:45:19.347055
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import PurePath
    from functools import reduce

    def _get_name_length(x: SetupCfgCommandConfig) -> int:
        return len(x.name)

    lst = list(each_sub_command_config())
    assert lst
    max_name_len = reduce(max, map(_get_name_length, lst))
    for elem in lst:
        print(
            '{:<{}s}: {}'.format(
                elem.name,
                max_name_len,
                PurePath(elem.description).name
            )
        )

# Generated at 2022-06-11 22:45:32.952074
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        td = os.path.join(td, 'project')
        os.mkdir(td)
        os.mkdir(os.path.join(td, 'src'))
        setup_cfg_path = os.path.join(td, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')
        with open(setup_cfg_path, 'wt') as fp:
            fp.write('''\
[metadata]
name = project
''')
        with pytest.raises(FileNotFoundError):
            list(each_sub_command_config(td))


# Generated at 2022-06-11 22:45:41.124583
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import getcwd
    from warnings import simplefilter, catch_warnings
    from unittest import mock

    setup_cfg_path = os.path.join(os.path.dirname(__file__), 'setup.cfg')
    setup_cfg = ConfigParser()
    setup_cfg.read(setup_cfg_path)
    base_name = os.path.basename(setup_cfg_path)
    setup_commands_path = os.path.join(os.path.dirname(__file__), 'setup_commands.cfg')
    setup_commands = ConfigParser()
    if os.path.isfile(setup_commands_path):
        setup_commands.read(setup_commands_path)

    curr_dir = getcwd()

# Generated at 2022-06-11 22:45:48.002270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i, config in enumerate(each_sub_command_config(os.path.dirname(__file__))):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:54.383450
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '..', '..', 'src', 'main', 'python')
    path = os.path.abspath(path)
    for cmd in each_sub_command_config(path):
        print(cmd)

# Generated at 2022-06-11 22:46:03.999136
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.testutils as tu

    sub_cmd_fmt = '%(camel)s%(suffix)sCommand'
    with tu.temp_dir() as dirpath:
        with open(os.path.join(dirpath, 'setup.py'), 'w') as fp:
            fp.write('# An empty setup.py file.')
        with open(os.path.join(dirpath, 'setup.cfg'), 'w') as fp:
            fp.write("""
[metadata]
name = flutils
version = 1.0.0

[options]
setup_commands = setupcommands

[setupcommands]
name = flutils-test-command
description = My test command
command =
    echo "It worked!"
""")