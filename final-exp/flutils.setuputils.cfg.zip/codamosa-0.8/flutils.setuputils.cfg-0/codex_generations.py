

# Generated at 2022-06-11 22:36:27.746983
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    import sys

    setup_dir = pathlib.Path(__file__).parent.parent.parent
    for command_config in each_sub_command_config(setup_dir):
        command_name = command_config.name
        camel_name = command_config.camel
        description = command_config.description
        commands = command_config.commands
        assert command_name
        assert camel_name
        assert description
        assert commands
        print(f'{command_name}')
        print(f'    camel_name = {camel_name}')
        print(f'    description = {description}')
        print(f'    commands = {commands}')



# Generated at 2022-06-11 22:36:33.308009
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '..'))
    for cmd in each_sub_command_config(setup_dir):
        assert isinstance(cmd, SetupCfgCommandConfig)
        assert cmd.commands
        assert cmd.name
        assert cmd.camel
        assert cmd.description



# Generated at 2022-06-11 22:36:44.147586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.pathutils import home_path
    from flutils.strutils import _encode_lines
    from flutils.files import write_bom_lines

    # The coding style currently requires this.
    # noinspection PyUnusedLocal
    flutils_path = str(Path(__file__).parent)

    name = 'test_' + __name__
    with TemporaryDirectory() as setup_dir:
        setup_py_path = Path(setup_dir) / 'setup.py'
        setup_cfg_path = Path(setup_dir) / 'setup.cfg'
        cmd_cfg_path = Path(setup_dir) / 'setup_commands.cfg'

# Generated at 2022-06-11 22:36:54.134007
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    _TEST_DIR = os.path.dirname(os.path.realpath(__file__))
    _SETUP_CFG = _TEST_DIR + '''/test_setup_cfg.ini'''
    _SETUP_COMMANDS_CFG = _TEST_DIR + '''/test_setup_commands.ini'''

    class EachSubCommandConfigTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir: Optional[str] = None

        def tearDown(self):
            if self.tmpdir:
                os.remove(self.tmpdir)

        def _prepare_config_files(self) -> None:
            tmpdir = tempfile.mkdtemp()
            self.tmpdir = tmp

# Generated at 2022-06-11 22:37:01.011504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    for cmd in each_sub_command_config(os.path.dirname(__file__)):
        print(cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:09.910984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import sys

    import flutils.setuputils.tests

    this_file = inspect.getfile(sys.modules[__name__])
    this_file = os.path.realpath(this_file)
    dirname = os.path.dirname(this_file)
    setup_dir = os.path.dirname(dirname)

    test_dir = os.path.join(setup_dir, 'test')
    test_setup = os.path.join(test_dir, 'setup.cfg')

# Generated at 2022-06-11 22:37:22.946953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    def _gen(
            *,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[Tuple[str, str, Tuple[str, ...]], None, None]:
        for cmd in each_sub_command_config(setup_dir):
            yield (cmd.name, cmd.description, cmd.commands)

    name = 'test'
    commands: List[Tuple[str, str, Tuple[str, ...]]] = [
        ('test', 'Test description.', ('test command',)),
        ('test.args', 'Test description and args.', ('test command', 'arg1')),
    ]

# Generated at 2022-06-11 22:37:32.348614
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import modules
    from inspect import getsourcefile
    from pathlib import Path
    from pip import __file__
    from pip._internal.commands import (
        __all__,
        _create_command_dict,
        list,
        uninstall,
    )
    from typing import Set
    from unittest import TestCase

    from flutils.pkgutils import (
        __version__,
        _get_pip_command_docstr_map,
    )

    cmd_dict = cast(Dict[str, object], _create_command_dict())

    pip_pkg_path = Path(__file__).parent
    cmd_pkg_path = Path(pip_pkg_path, 'commands')


# Generated at 2022-06-11 22:37:34.815113
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config.name)

# Generated at 2022-06-11 22:37:43.593836
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import namedtuple

    SubCommandConfig = namedtuple(
        'SubCommandConfig', 'name commands'
    )

    configs = list(each_sub_command_config())
    assert len(configs) > 0

    name = configs[0].name
    assert name == 'my_setup_command', name

    commands = configs[0].commands
    assert len(commands) > 0
    expected = SubCommandConfig(
        name='my_setup_command',
        commands=('echo {setup_dir}', 'echo {home}')
    )
    assert commands == expected.commands

# Generated at 2022-06-11 22:38:06.032647
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from os.path import dirname, realpath
    from types import GeneratorType

    from flutils.pathutils import (
        change_dir,
        path_from_this_file
    )
    from flutils.strutils import contains_any

    def _assert_is_generator(gen: GeneratorType, msg: str) -> None:
        if isinstance(gen, GeneratorType) is False:
            raise AssertionError(msg)

    # ----
    # Case 1: None
    # ----
    with change_dir(path_from_this_file()):
        with change_dir(realpath('../../../')):
            gen = each_sub_command_config(setup_dir=None)
            _assert_is_generator(gen, "It should be a generator.")
            config = next

# Generated at 2022-06-11 22:38:09.355026
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import sys
    test_each_sub_command_config()
    sys.exit()

# Generated at 2022-06-11 22:38:22.093269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import Counter
    from os import getcwd
    from setuptools import Command

    from pytest import raises

    def test_setup_cfg_file(
            base_name: str,
            setup_cfg_contents: str
    ) -> Tuple[bool, ...]:
        from flutils.pathutils import mk_temp_dir, rm_rf

        temp_dir = mk_temp_dir(prefix='test_setup_config_command', )
        setup_py_path = os.path.join(temp_dir, 'setup.py')
        setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        setup_ext_cfg_path = os.path.join(temp_dir, 'setup_commands.cfg')


# Generated at 2022-06-11 22:38:24.586031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    from pathlib import Path

    from hypothesis import given

# Generated at 2022-06-11 22:38:35.262859
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the each_sub_command_config function."""
    import pathlib

    with pathlib.Path(__file__).parent.resolve() as here:
        # :lib: is ignored in this package's MANIFEST.in
        if here == here.joinpath('tests'):
            here = here.parent.resolve()

        for config in each_sub_command_config(str(here)):
            name = config.camel
            if name == 'Base':
                assert 'Base' == config.name
                assert "" == config.description
            else:
                # Example of using a custom name
                assert 'Example of using a custom name' == config.description

            assert name in ('Base', 'Example', 'ExampleNested')

            cmd = cast(SetupCfgCommandConfig, config)

# Generated at 2022-06-11 22:38:41.363778
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _item_each_sub_command_config(
            setup_dir: str,
            expected_configs: List[SetupCfgCommandConfig],
    ) -> None:
        actual_configs: List[SetupCfgCommandConfig] = []
        for act in each_sub_command_config(setup_dir):
            act = cast(SetupCfgCommandConfig, act)
            actual_configs.append(act)
        assert expected_configs == actual_configs


# Generated at 2022-06-11 22:38:51.863105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    def check_return(test_case: unittest.TestCase,
                     expected: SetupCfgCommandConfig,
                     actual: SetupCfgCommandConfig) -> bool:
        test_case.assertEqual(expected.name, actual.name)
        test_case.assertEqual(expected.camel, actual.camel)
        test_case.assertEqual(expected.description, actual.description)
        test_case.assertTupleEqual(expected.commands, actual.commands)
        return True

    class Unit(unittest.TestCase):
        def setup(self) -> None:
            self.setup_dir = str(sys.modules[__name__].__file__)
            self.setup_dir = os.path.dirname(self.setup_dir)

       

# Generated at 2022-06-11 22:39:00.872115
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        assert sub_command_config.name
        assert sub_command_config.camel
        assert sub_command_config.commands
        assert sub_command_config.description
    setup_cfg_path = os.path.join('./tests/data/setup_cfg_project/setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    for sub_command_config in _each_setup_cfg_command(parser, {
        'name': _get_name(parser, setup_cfg_path),
        'home': os.path.expanduser('~'),
    }):
        assert sub_command_config.name
        assert sub_command_config.camel
        assert sub_command_config.commands
   

# Generated at 2022-06-11 22:39:10.767863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_dir = os.path.dirname(os.path.realpath(__file__))
    base_dir = os.path.join(base_dir, '..', 'test_setup_commands')
    base_dir = os.path.realpath(base_dir)
    for sc in each_sub_command_config(base_dir):
        print(
            '=name', repr(sc.name),
            '=camel', repr(sc.camel),
            '=description', repr(sc.description),
            '=commands', repr(sc.commands)
        )
    pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:11.853519
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config(r'/Users/randy/dev/cookiecutter-flutils/flutils')

# Generated at 2022-06-11 22:39:41.694184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest


# Generated at 2022-06-11 22:39:51.525155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils.pathutils import get_project_root_path

    root = get_project_root_path()
    commands = list(each_sub_command_config(root))
    pprint(commands)
    print('Commands found: %d' % len(commands))

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:56.803374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(sys.modules[__name__].__file__), '..')
    )

    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-11 22:40:08.586454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.tempdir import TempDir
    from flutils.testutils.fileutils import (
        create_file,
        write_file
    )
    with TempDir() as td:
        path = os.path.join(td, 'setup_commands.cfg')
        create_file(path)
        write_file(
            path,
            """[setup.command.commands]
command = echo
    {setup_dir}
    {home}
name = commands"""
        )
        write_file(
            os.path.join(td, 'setup.py'),
            'import setuptools'
        )
        path = os.path.abspath(td)
        for config in each_sub_command_config(path):
            assert isinstance(config, SetupCfgCommandConfig)
           

# Generated at 2022-06-11 22:40:20.788133
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    func_name = 'each_sub_command_config'
    errors: List[str] = []

    # Test that the function returns a generator object
    kwargs: Dict[str, object] = {}
    out = each_sub_command_config(**kwargs)
    if type(out) is not Generator:
        errors.append(
            f"Calling {func_name}() does NOT return a generator object."
        )

    # Test that an exception is raised if the given setup.py path does not
    # exist
    kwargs = {
        'setup_dir': 'non_existent_path',
    }
    try:
        each_sub_command_config(**kwargs)
    except Exception:
        pass

# Generated at 2022-06-11 22:40:31.165661
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '__test_fixtures__', 'sub_command')
    path = os.path.realpath(path)
    configs = list(each_sub_command_config(path))
    assert len(configs) == 4
    assert configs[0].name == 'sub1'
    assert configs[0].camel == 'Sub1'
    assert configs[0].description == 'sub1 description'
    assert configs[0].commands == (
        '/bin/bash -c "sub1cmd1 $(sub1cmd2 $(sub1cmd3))"',
        '/bin/bash -c "sub2cmd2 $(sub2cmd3) $(sub2cmd1)"'
    )
    assert configs[1].name

# Generated at 2022-06-11 22:40:43.380357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'Flutils'
    )
    configs = list(each_sub_command_config(project_dir))
    assert len(configs) == 2
    assert configs[0].name == 'docs.build'
    assert configs[0].camel == 'DocsBuild'
    assert configs[0].description == \
        'Build the documentation and move it to the site root folder.'
    assert 'python setup.py build_docs' in configs[0].commands
    assert 'mv ./build/docs ./docs' in configs[0].commands

    assert configs[1].name == 'docs.clean'
    assert configs[1].camel == 'DocsClean'


# Generated at 2022-06-11 22:40:56.011110
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    expected = [
        SetupCfgCommandConfig(
            'test.test_1',
            'TestTest1',
            'Description: Used to test the script.',
            ('echo "Hello World"',)
        ),
        SetupCfgCommandConfig(
            'test.test_2',
            'TestTest2',
            'Description: Used to test the script.',
            ('echo "Hello World"',)
        ),
    ]
    setup_dir = os.path.dirname(__file__)
    got = list(each_sub_command_config(setup_dir))
    pprint.pprint(expected)
    pprint.pprint(got)
    assert expected == got


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:41:03.415827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_sub_command_config(
            sub_command: SetupCfgCommandConfig,
            expected_sub_command: SetupCfgCommandConfig
    ) -> None:
        assert sub_command == expected_sub_command

    setup_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 22:41:14.256074
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import path
    from os import chdir
    from tempfile import TemporaryDirectory
    from shutil import copy

    # Path to the project directory
    project_dir = os.path.dirname(__file__)
    project_dir = os.path.realpath(project_dir)
    project_dir = os.path.join(project_dir, '..', '..', '..')
    project_dir = os.path.abspath(project_dir)

    # Do this so that the setup.py file has the correct directory in it.
    chdir(project_dir)

    # Path to the virtual environment directory
    venv_dir = os.path.join(project_dir, '.venv')

    # Path to the test directory
    test_dir = os.path.dirname(__file__)
    test_

# Generated at 2022-06-11 22:41:49.938402
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    d = tempfile.mkdtemp()
    s = os.path.join(d, 'setup.cfg')
    with open(s, 'w') as fh:
        fh.write('[metadata]\nname = pkgname\n')
        fh.write('[setup.command.one]\n')
        fh.write('name: one\n')
        fh.write('description: One\n')
        fh.write('commands:\n')
        fh.write('    command 1\n')
        fh.write('    command 2\n')
        fh.write('\n')
        fh.write('[setup.command.two]\n')
        fh.write('name: two\n')

# Generated at 2022-06-11 22:42:02.557303
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def _validate_sc3(sc3: SetupCfgCommandConfig) -> None:
        assert isinstance(sc3, SetupCfgCommandConfig)
        assert sc3.name
        assert sc3.camel
        assert sc3.description
        assert len(sc3.commands) > 0
        for command in sc3.commands:
            assert command
            assert '\n' not in command

    def _test_contents(sc3s: List[SetupCfgCommandConfig],
                       import_path: str,
                       prefix: str,
                       suffix: str):
        assert isinstance(sc3s, list)
        assert len(sc3s) == 3
        for sc3 in sc3s:
            _validate_sc3(sc3)
       

# Generated at 2022-06-11 22:42:11.650165
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        next(each_sub_command_config())
    except (StopIteration, FileNotFoundError, LookupError):
        pass
    else:
        raise AssertionError(
            "Expected one of these exceptions to be raised to complete this "
            "function's unit test: %r"
            % (
                (StopIteration, FileNotFoundError, LookupError),
            )
        )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:24.784493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test for function each_sub_command_config."""
    import tempfile
    import shutil
    import flutils

    tmp_dir = tempfile.mkdtemp()

    def _get_setup_cfg_content(
            name: str,
            description: str,
    ):
        return """\
[metadata]
name = %s
description = %s
""" % (name, description)

    def _get_setup_commands_cfg_content(commands: Tuple[str, ...]):
        if not commands:
            raise ValueError('commands')
        if not all(isinstance(c, str) for c in commands):
            raise ValueError('commands')

# Generated at 2022-06-11 22:42:30.313803
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_commands = {comm.name: comm for comm in each_sub_command_config()}
    assert 'dummy.entry_point' in setup_cfg_commands
    assert 'dummy.module.entry_point' in setup_cfg_commands
    assert 'dummy.module.other_entry_point' in setup_cfg_commands



# Generated at 2022-06-11 22:42:37.227472
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)

    commands: List[str] = []
    for config in each_sub_command_config(setup_dir):
        commands.append((config.name, config.camel,
                         config.description, config.commands))

# Generated at 2022-06-11 22:42:41.835717
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import textwrap
    from flutils.systemutils import get_running_python_path

    import flutils

    src_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'src')
    )
    sys.path.insert(0, src_path)
    import flutils.setup_commands.commands as cmds  # noqa: F401,E402


# Generated at 2022-06-11 22:42:53.758306
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=import-outside-toplevel
    import subprocess
    import sys
    import unittest

    class EachSubCommandConfigTest(unittest.TestCase):
        """Unit test class for function ``each_sub_command_config``."""
        def test_each_sub_command_config(self):
            """Unit test method of ``each_sub_command_config``."""
            cmd = ('python', '-m', 'fluentpy.setup_commands.setup_config',
                   'tests')
            output = subprocess.check_output(cmd)
            output = output.decode(sys.stdout.encoding).strip().splitlines()

# Generated at 2022-06-11 22:43:05.352631
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class TestEachSubCmdConfig(TestCase):

        def setUp(self) -> None:
            self.indent = '    '
            self.temp_dir = TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            with open(os.path.join(self.setup_dir, 'setup.py'), 'w') as f:
                val = '# setup.py'
                f.write(val)
            val = StringIO()
            val.write('[metadata]')
            val.write(os.linesep)
            val.write(self.indent)
            val.write('name = my_package')
            val.write(os.linesep)

# Generated at 2022-06-11 22:43:16.951351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cur_dir = os.path.dirname(__file__)
    path = os.path.join(cur_dir, 'test_setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    expected = ('clean', 'sdist', 'bdist_wheel', 'install', 'upload')
    output = tuple(
        _each_setup_cfg_command(
            parser,
            {'name': 'flutils', 'setup_dir': cur_dir, 'home': os.path.expanduser('~')}
        )
    )
    for out in output:
        assert(out.commands == expected)
    output = tuple(each_sub_command_config(cur_dir))
    for out in output:
        assert(out.commands == expected)

# Generated at 2022-06-11 22:43:51.912455
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(
        each_sub_command_config(
            os.path.join(os.path.dirname(__file__), 'examples', 'project1')
        )
    ) == [
        SetupCfgCommandConfig(
            'pkg.command1', 'Command1',
            'Does command1 stuff.',
            ('python ./setup.py command1',)
        ),
        SetupCfgCommandConfig(
            'pkg.command2', 'Command2',
            'Does command2 stuff.',
            ('python ./setup.py command2',)
        ),
    ]

# Generated at 2022-06-11 22:43:56.338946
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.config import each_sub_command_config
    for scc in each_sub_command_config():
        assert isinstance(scc, SetupCfgCommandConfig)
        print(scc)

# Generated at 2022-06-11 22:44:01.169015
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils import pathutils

    from .pkgutils import get_setup_dir


    def test_func():
        for config in each_sub_command_config(get_setup_dir()):
            print(config)

    # pathutils.each_line(get_setup_dir())
    test_func()
    pathutils.each_line(get_setup_dir())

# Generated at 2022-06-11 22:44:08.275361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyUnresolvedReferences
    from tests.test_flutils import is_unit_test
    # noinspection PyUnresolvedReferences
    from tests import EXAMPLES_DIR

    if not is_unit_test():
        return

    for sub_command in each_sub_command_config(EXAMPLES_DIR):
        print(sub_command)

# Generated at 2022-06-11 22:44:08.898956
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-11 22:44:20.020814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    setup_dir = os.path.dirname(__file__)
    if sys.version >= '3.6':
        import importlib.resources as pkg_resources  # type: ignore
    else:
        import importlib_resources as pkg_resources
    setup_dir = pkg_resources.files('flutils.test')[0]

    def check_command(cmd: SetupCfgCommandConfig) -> None:
        assert isinstance(cmd, SetupCfgCommandConfig)
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.camel, str)
        assert isinstance(cmd.description, str)
        assert isinstance(cmd.commands, tuple)

    for cmd in each_sub_command_config(setup_dir):
        check_command(cmd)



# Generated at 2022-06-11 22:44:27.243622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config():
                print(config)
    unittest.main()


if __name__ == '__main__':
    # Example
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-11 22:44:33.500099
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if os.path.dirname(__file__):
        here = os.path.dirname(__file__)
    else:
        here = os.getcwd()
    configs = list(each_sub_command_config(setup_dir=here))
    assert configs[0].camel == 'SubCommand1'
    assert configs[0].commands == ("echo 'hello'", "echo 'world'")
    assert configs[0].description == 'This is the description for the sub_command1 command.'
    assert configs[1].camel == 'SubCommand2'
    assert configs[1].commands == ("echo 'hello'", "echo 'world'")
    assert configs[1].description == 'This is the description for the sub_command2 command.'

# Generated at 2022-06-11 22:44:42.640713
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'setup.cfg')
    parser = ConfigParser()
    parser.read(path)
    name = _get_name(parser, path)
    format_kwargs = {
        'setup_dir': os.path.dirname(path),
        'home': os.path.expanduser('~'),
        'name': name,
    }
    for cfg in _each_setup_cfg_command(parser, format_kwargs):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:47.126461
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _do_test() -> None:
        for sub_command_config in each_sub_command_config():
            assert sub_command_config.name is not None
            assert sub_command_config.camel is not None
            assert sub_command_config.description is not None
            assert sub_command_config.commands is not None

    _do_test()



# Generated at 2022-06-11 22:45:43.935052
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)  # type: str
    parent = os.path.dirname(here)  # type: str
    project = 'flutils'  # type: str
    setup_dir = os.path.join(parent, project)  # type: str
    for config in each_sub_command_config(setup_dir):  # type: SetupCfgCommandConfig
        print(repr(config))

# Generated at 2022-06-11 22:45:52.073434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dirname = os.path.abspath(os.path.dirname(__file__))
    filename = os.path.join(dirname, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(filename)
    format_kwargs = {
        'setup_dir': dirname,
        'home': os.path.expanduser('~'),
        'name': 'flutils'
    }
    gen = _each_setup_cfg_command(parser, format_kwargs)
    assert isinstance(gen, Generator)
    cmd = next(gen)
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'sub.sub'
    assert cmd.camel == 'SubSub'
    assert cmd.description == 'sub sub desc'
    assert cmd.commands

# Generated at 2022-06-11 22:45:59.134307
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    while os.path.basename(setup_dir) != 'setup.py':
        setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    for config in each_sub_command_config(setup_dir):
        print(config)