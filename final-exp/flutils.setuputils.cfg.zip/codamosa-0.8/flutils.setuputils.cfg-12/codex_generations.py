

# Generated at 2022-06-11 22:36:28.540630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from io import StringIO
    from flutils.pathutils import make_dirs


# Generated at 2022-06-11 22:36:41.533437
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import realpath
    from os.path import join
    from os.path import expanduser

    from flutils.pathutils import get_parent_dirs
    from flutils.strutils import underscore_to_camel

    from ._base import each_sub_command_config as each_sub_command_config_real

    setup_dir = realpath(join(__file__, '../../../'))
    setup_dir = realpath(join(setup_dir, '../../'))

    result = list(each_sub_command_config_real(setup_dir))

    for x in result:
        assert x.name == x.camel.replace(x.name.split('-')[0] + '-', '').lower()


# Generated at 2022-06-11 22:36:53.205656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    call_path = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(call_path, 'data')

    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    package_name = _get_name(parser, setup_cfg_path)

    setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
    parser.read(setup_commands_cfg_path)

# Generated at 2022-06-11 22:37:03.301219
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        'fixtures',
        'setuptools_command'
    )
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)

# Generated at 2022-06-11 22:37:05.399810
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(os.path.dirname(__file__)):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-11 22:37:07.558137
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()

# Generated at 2022-06-11 22:37:14.334666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    lst = list(each_sub_command_config(setup_dir))
    assert lst[0] == SetupCfgCommandConfig(
        'clean',
        'Clean',
        'Cleans the project.',
        ('python_setup.py clean', 'cd docs && make clean')
    )
    assert lst[1] == SetupCfgCommandConfig(
        'lint',
        'Lint',
        'Lints the project.',
        ('python_setup.py lint', 'cd docs && make lint')
    )



# Generated at 2022-06-11 22:37:18.878893
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root = os.path.dirname(os.path.abspath(__file__))
    this_dir = os.path.join(root, 'testdata/test_setup_commands')
    list(each_sub_command_config(this_dir))

# Generated at 2022-06-11 22:37:29.612004
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import click

    config_items = 0
    for config in each_sub_command_config():
        config_items += 1
        options = (
            config.name,
            config.camel,
            config.description,
            config.commands
        )
        print(options)

    assert config_items == 1, 'No sub commands found'

    # Create a new command
    @click.command()
    @click.option(
        '-d',
        '--dry-run',
        is_flag=True,
        default=False,
        show_default=True
    )
    def command(dry_run):
        """Output the current Python version."""
        import sys
        print(sys.version)

    # Add the new command to the click command group

# Generated at 2022-06-11 22:37:36.885188
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(__file__)
    dir_path = os.path.dirname(dir_path)
    dir_path = os.path.dirname(dir_path)
    dir_path = os.path.join(dir_path, 'python_packaging_utils')
    assert os.path.exists(dir_path)
    assert os.path.isdir(dir_path)
    commands = list(each_sub_command_config(dir_path))
    assert len(commands)
    assert len([c for c in commands if 'test' in c.name])
    assert len([c for c in commands if 'test' in c.commands])

# Generated at 2022-06-11 22:37:50.223457
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-11 22:37:52.808468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pytest import raises

    with raises(FileNotFoundError):
        list(each_sub_command_config())
    assert list(each_sub_command_config('.'))

# Generated at 2022-06-11 22:37:54.819528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for x in each_sub_command_config(setup_dir):
        print(x)

# Generated at 2022-06-11 22:38:05.994212
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test"""
    import sys
    import pytest
    from io import StringIO
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    def _create_setup_commands_cfg(create_setup_cfg: bool = True) -> str:
        root_dir = mkdtemp()
        setup_dir = os.path.join(root_dir, 'project')
        os.mkdir(setup_dir)
        cfg_path = os.path.join(setup_dir, 'setup.cfg')
        if create_setup_cfg is True:
            with open(cfg_path, 'w') as file:
                file.write(dedent('''\
                    [metadata]
                    name = project
                '''))

# Generated at 2022-06-11 22:38:15.464022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '../examples/setup_cfg/setup_cmds'
    )
    result = list(each_sub_command_config(test_setup_dir))
    assert len(result) == 4
    assert result[0].name == 'clean'
    assert result[0].camel == 'Clean'
    assert result[0].description == 'Remove build files'
    assert result[0].commands == ('rm -rf build dist', )
    assert result[1].name == 'test'
    assert result[1].camel == 'Test'
    assert result[1].description == 'Run all the tests'
    assert result[1].commands == ('pytest tests', )
    assert result

# Generated at 2022-06-11 22:38:22.298341
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def assertions(n: int,
                   cmd: SetupCfgCommandConfig) -> bool:
        assert cmd.name == 'test.%d' % n
        assert cmd.camel == 'Test%d' % n
        assert cmd.description == 'test %d' % n
        assert cmd.commands == ('echo %d' % n,)
        return True

    setup_cfg = """\
[metadata]
name = test

[setup.command.test.1]
commands = echo 1
[setup.command.test.2]
commands =
    echo 2
"""

    setup_cfg_path = os.path.join('tmp', 'test', 'setup.cfg')
    os.makedirs(os.path.dirname(setup_cfg_path), exist_ok=True)

# Generated at 2022-06-11 22:38:32.352745
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import pathlib
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.test_dir = pathlib.Path(tempfile.mkdtemp())
            self.test_commands_file = self.test_dir/'setup_commands.cfg'

        def tearDown(self):
            self.test_commands_file.unlink()
            self.test_dir.rmdir()

        def test_standard(self):
            setup_dir = self.test_dir
            py = setup_dir/'setup.py'
            py.write_text('""')
            cfg = setup_dir/'setup.cfg'

# Generated at 2022-06-11 22:38:43.978083
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:38:48.872870
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import (
        flutils_test_lib_tests,
        flutils_test_lib_tests_setup,
        flutils_test_lib_tests_setup_cfg,
    )
    for config in each_sub_command_config(
            flutils_test_lib_tests_setup
    ):
        yield TestEachSubCommandConfig, config



# Generated at 2022-06-11 22:38:52.084736
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(sc.name)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:27.287478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=W0613
    # pylint: disable=W0612
    def _make_project_path(d, name):
        return os.path.realpath(
            os.path.join(
                os.path.dirname(__file__),
                '..',
                '..',
                '..',
                '..',
                'make-project',
                d,
                name,
            )
        )
    projects = [
        ('basic', 'basic', ('build_dist', 'test')),
        ('inst', 'inst', ('test', 'install')),
    ]
    for proj_dir, proj_name, sub_commands in projects:
        proj_path = _make_project_path(proj_dir, proj_name)
        cnt = 0

# Generated at 2022-06-11 22:39:42.175207
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile

    def _each_setup_cfg_command_config_test(parser: ConfigParser):
        for i, config in enumerate(
                _each_setup_cfg_command(
                    parser, {
                        'setup_dir': r'/foo/bar',
                        'home': os.path.expanduser('~'),
                        'name': 'baz'
                    }
                )
        ):
            if i == 0:
                assert config.name == r'baz'
                assert config.camel == r'Baz'
                assert config.description == ''
                assert config.commands == tuple()
            elif i == 1:
                assert config.name == r'baz.build'
                assert config.camel == r'BazBuild'
                assert config.description == ''
                assert config

# Generated at 2022-06-11 22:39:55.895367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_path = os.path.realpath(os.path.join(
        os.path.abspath(__file__),
        '..',
        '..',
        '..',
        '..',
        '..',
        'tests',
        'fixtures',
        'pyproject_setup_cfg_commands',
        'src',
        'tictactoe',
        'setup.py'
    ))
    for sub_cmd_cfg in each_sub_command_config(setup_path):
        print(sub_cmd_cfg)
    for sub_cmd_cfg in each_sub_command_config():
        print(sub_cmd_cfg)


# Generated at 2022-06-11 22:40:07.858224
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):

        def test_empty(self):
            with tempfile.TemporaryDirectory() as dname:
                os.chdir(dname)
                path = pathlib.Path('setup.py').resolve()
                with open(path, 'w') as fh:
                    fh.write("\n")
                self.assertRaises(
                    FileNotFoundError,
                    each_sub_command_config
                )

        def test_bad(self):
            with tempfile.TemporaryDirectory() as dname:
                os.chdir(dname)
                path = pathlib.Path('setup.py').resolve()

# Generated at 2022-06-11 22:40:19.213629
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.display import dlist
    from flutils.pathutils import the_temp_path
    from flutils.pyutils import the_caller
    from flutils.testutils.stream import (
        get_test_std_streams,
        set_test_std_streams,
    )
    from io import StringIO
    import sys

    def reset_streams() -> None:
        _ = sys.stdout.write(std_out.getvalue())
        _ = sys.stderr.write(std_err.getvalue())
        std_out.truncate(0)
        std_out.seek(0)
        std_err.truncate(0)
        std_err.seek(0)

    # Create a temporary directory for the test
    #
    std_out, std

# Generated at 2022-06-11 22:40:30.188310
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    setup_dir = tempfile.mkdtemp()

    with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
        f.write('')
    path = os.path.join(setup_dir, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.add_section('setup.command.commands')
    parser.set('setup.command.commands', 'name', 'commands')
    parser.set('setup.command.commands', 'description', 'Show commands.')
    parser.set('setup.command.commands', 'command', 'echo "commands"')
    with open(path, 'w') as f:
        parser.write(f)

# Generated at 2022-06-11 22:40:42.567945
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import sys
    import unittest

    output = []

    class TestSubCommandConfig(unittest.TestCase):
        """Test each_sub_command_config."""

        def test_fail(self):
            """Test with a setup dir that lacks a ``setup.cfg``."""
            import tempfile
            tmp_dir = tempfile.TemporaryDirectory()
            path = os.path.join(tmp_dir.name, 'setup.py')

# Generated at 2022-06-11 22:40:46.506908
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config():
        print(x)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:57.798555
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        directory_path,
        git_clone_repository
    )

    git_url = 'https://github.com/wdbm/docks'
    project_name = 'docks'
    setup_dir = directory_path(git_clone_repository(git_url, project_name))

    results: List[str] = []
    for cmd_cfg in each_sub_command_config(setup_dir):
        results.append(cmd_cfg.name)
    assert 'user.assign-role' in results
    assert 'user.create' in results
    assert 'user.delete' in results
    assert 'user.get' in results
    assert 'user.list' in results
    assert 'user.update' in results
    assert 'user.update-password' in results

# Generated at 2022-06-11 22:41:04.721666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(setup_dir, '..', '..', '..', '..', '..')
    name = 'flutils.pkgutils'
    ret: List[SetupCfgCommandConfig] = []
    for cfg in each_sub_command_config(setup_dir):
        ret.append(cfg)
    assert len(ret) == 1

# Generated at 2022-06-11 22:41:31.728400
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import pytest
    import inspect
    from textwrap import dedent

    def _test_it(setup_dir: Optional[Union[tempfile.TemporaryDirectory, str]]):
        if isinstance(setup_dir, tempfile.TemporaryDirectory):
            setup_dir = cast(tempfile.TemporaryDirectory, setup_dir)
            setup_dir = setup_dir.name
        else:
            setup_dir = cast(str, setup_dir)
        setupcfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setupcfg_path, 'w') as fh:
            fh.write(dedent("""\
                [metadata]
                name = foobar
            """))

# Generated at 2022-06-11 22:41:37.456162
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path

    setup_dir = Path(__file__).parent.parent.parent.parent
    for cfg in each_sub_command_config(setup_dir):
        assert type(cfg) is SetupCfgCommandConfig
        assert cfg.name
        assert cfg.camel
        assert cfg.description
        assert type(cfg.commands) is tuple


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:41:47.982369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the ``each_sub_command_config`` function."""
    from flutils.pathutils import get_top_dir

    from .pytest_utils import run_pytest, run_subprocess
    from .xdist_utils import get_worker_id

    test_dir = get_top_dir()
    setup_dir = os.path.join(test_dir, 'example_project')

    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        if fs.line == 39:  # loc of the yield
            fs = cast(FrameSummary, fs)
            fs_file: str = fs.filename
            fs_file = os.path.abspath(fs_file)
            if os.path.isfile(fs_file):
                script_name = fs_file
                break

# Generated at 2022-06-11 22:42:00.237287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    start = os.path.dirname(os.path.abspath(__file__))
    start = os.path.abspath(os.path.join(start, '..'))
    start = os.path.abspath(os.path.join(start, '..'))
    start = os.path.abspath(os.path.join(start, '..'))
    start = os.path.abspath(os.path.join(start, 'python-package-template'))

# Generated at 2022-06-11 22:42:11.386961
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase
    from unittest.mock import Mock

    class EachSubCommandConfigTest(TestCase):

        def setUp(self) -> None:
            self.dir = mkdtemp()
            self.addCleanup(rmtree, self.dir)
            self.setup_cfg = os.path.join(self.dir, 'setup.cfg')
            self.setup_py = os.path.join(self.dir, 'setup.py')
            with open(self.setup_py, 'w') as tfp:
                tfp.write('# Dummy setup.py')

# Generated at 2022-06-11 22:42:15.358313
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    ret = list(each_sub_command_config())
    pprint(ret)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:28.268268
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import sys
    import pprint
    import collections

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_01(self):
            cwd = os.path.dirname(sys.modules[__name__].__file__)
            cwd = os.path.dirname(cwd)
            self.maxDiff = None
            commands = collections.OrderedDict()
            for config in each_sub_command_config(setup_dir=cwd):
                for command in config.commands:
                    commands[command] = config.description
            pprint.pprint(commands)

# Generated at 2022-06-11 22:42:35.479622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import gettempdir
    from os import makedirs, path
    from random import random
    from string import ascii_lowercase

    def random_str(length: int = 20) -> str:
        return str().join([random.choice(ascii_lowercase) for _ in range(length)])

    def write_setup_cfg(
            dir_path: str,
            name: str = 'project_name'
    ) -> None:
        with open(path.join(dir_path, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)


# Generated at 2022-06-11 22:42:43.839757
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.abspath(os.path.join(path, '..', '..', '..', '..', '..'))
    path = os.path.join(path, 'tests/fixtures/test_setup_commands/fixture')
    for cfg in each_sub_command_config(path):
        print(cfg)
    for cfg in each_sub_command_config(path):
        print(cfg)

# Generated at 2022-06-11 22:42:53.800608
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfg = list(
        each_sub_command_config('./tests/fixtures/setuptools/project')
    )
    assert len(cfg) == 2
    assert cfg[0].name == 'setup.command.one'
    assert cfg[0].camel == 'SetupCommandOne'
    assert cfg[0].description == 'Command One'
    assert len(cfg[0].commands) == 2
    assert cfg[1].name == 'setup.command.three'
    assert cfg[1].camel == 'SetupCommandThree'
    assert cfg[1].description == 'Command Three'
    assert len(cfg[1].commands) == 2

# Generated at 2022-06-11 22:43:30.623014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = str(pathlib.Path(__file__).parent.parent)
    for cfg in each_sub_command_config(setup_dir):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:43:37.872252
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from typing import Dict
    from os import chmod, makedirs, path, remove, stat as os_stat
    from stat import S_IEXEC
    from flutils.pathutils import FilePermissions

    def _create_file(
            dirname: str,
            filename: str,
            contents: str,
            mode: Optional[int] = None
    ) -> str:
        path_ = os.path.join(
            dirname,
            filename,
        )
        with FilePermissions(path_):
            with open(path_, 'w') as f:
                f.write(dedent(contents))
        if mode:
            chmod(path_, mode)
        return path_


# Generated at 2022-06-11 22:43:45.940349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            func: Callable[[], Generator[SetupCfgCommandConfig, None, None]],
            want: Tuple[SetupCfgCommandConfig, ...]
    ) -> None:
        got = tuple(func())
        assert want == got


# Generated at 2022-06-11 22:43:51.682029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None,
            expected: Optional[SetupCfgCommandConfig] = None
    ) -> None:
        if expected is None:
            with pytest.raises(Exception):
                print(
                    '\n'.join(
                        map(
                            str,
                            each_sub_command_config(setup_dir)
                        )
                    )
                )
        else:
            out = list(each_sub_command_config(setup_dir))
            assert len(out) == 1
            assert out[0] == expected

    # Raises an exception
    _test_each_sub_command_config(
        setup_dir=None
    )

    # Raises an exception
    _test_each

# Generated at 2022-06-11 22:43:55.536171
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    out = list(each_sub_command_config(path))
    print(out)

# Generated at 2022-06-11 22:44:01.365255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )
    out = list(each_sub_command_config(setup_dir))
    assert out == [
        SetupCfgCommandConfig(
            'update_config.file',
            'UpdateConfigFile',
            '',
            ('python setup.py --update-config config.ini',)
        ),
    ]

# Generated at 2022-06-11 22:44:12.420269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import collections
    import tempfile
    import shutil


# Generated at 2022-06-11 22:44:23.950975
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_config in each_sub_command_config(os.path.dirname(__file__)):
        if cmd_config.name == 'test_command_one':
            assert cmd_config.camel == 'Test_command_one'
            assert cmd_config.description == 'Test command one description.'
            assert cmd_config.commands == (
                'echo "Test command one."',
                'echo "Second command to run."'
            )
        elif cmd_config.name == 'test_command_two.sub_command':
            assert cmd_config.camel == 'Test_command_two_sub_command'
            assert cmd_config.description == (
                'Test command two sub command description.'
            )

# Generated at 2022-06-11 22:44:31.082759
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase
    from flutils.pathutils import home_dir
    from flutils.sysutils import ensure_fs_encoding, encoding_fs

    class SetupCfgTest(TempDirTestCase):

        def setUp(self: 'SetupCfgTest') -> None:
            super().setUp()
            path = os.path.join(self.temp_dir, 'setup_commands.cfg')
            with open(path, 'w', encoding=encoding_fs) as fileobj:
                fileobj.write('[setup.command.foo]\n')
                fileobj.write('command=echo hi\n')
                fileobj.write('\n')
                fileobj.write('[setup.command.bar]\n')
                fileobj.write('command=echo bye\n')
               

# Generated at 2022-06-11 22:44:42.030995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from inspect import getsourcefile

    from flutils.testutils import (
        DummyCommandsTestCase,
        DummyTestCase
    )

    for test_case in (
        DummyCommandsTestCase,
        DummyTestCase,
    ):
        path = os.path.dirname(
            getsourcefile(test_case)
        )
        path = os.path.join(path, 'setup_commands.cfg')
        assert os.path.isfile(path)
        configs = list(each_sub_command_config(path))
        assert len(configs) == 2
        assert len(configs[0]) == 4
        assert len(configs[1]) == 4



# Generated at 2022-06-11 22:45:44.928696
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    out = list(each_sub_command_config())
    assert out  # nosec

# Generated at 2022-06-11 22:45:52.560192
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.join(setup_dir, 'testdata')
    setup_dir = os.path.join(setup_dir, 'project')
    cmd_list = list(each_sub_command_config(setup_dir))
    assert len(cmd_list) == 1
    assert cmd_list[0].name == 'run'
    assert cmd_list[0].camel == 'Run'
    assert cmd_list[0].description == ''
    assert len(cmd_list[0].commands) == 2
    assert cmd_list[0].commands[0] == 'echo "Hello World!"'

# Generated at 2022-06-11 22:46:02.706328
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from io import StringIO
    try:
        old_stdout = sys.stdout
        try:
            out = StringIO()
            sys.stdout = out
            for config in each_sub_command_config():
                print(config)
            output = out.getvalue().strip()
        finally:
            sys.stdout = old_stdout
    except SystemExit as e:
        # This is OK
        del e
        output = out.getvalue().strip()
    print(output)
    count = 0
    import this

    if 'Python' in output:
        count += 1
    if 'Monty' in output:
        count += 1
    if 'Why?' in output:
        count += 1
    assert count == 3, "Expected 3 output values, got %d instead." % count