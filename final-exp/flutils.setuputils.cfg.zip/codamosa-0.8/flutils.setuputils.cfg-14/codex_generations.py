

# Generated at 2022-06-11 22:36:28.334878
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import datetime
    import sys
    import tempfile

    _tempdir = tempfile.TemporaryDirectory(prefix='test_')
    _tempdir = cast(str, _tempdir.name)

    # Find the full path to this file.
    _this_file = sys.argv[0]
    _this_file = os.path.abspath(_this_file)
    # Find the dirname of this file.
    _this_path = os.path.split(_this_file)[0]

    # Find the full path to the file we want.
    _file = os.path.join(_this_path, 'setup_commands.cfg')
    _file = os.path.abspath(_file)
    _file = os.path.realpath(_file)
    assert os.path.exists(_file), _

# Generated at 2022-06-11 22:36:40.921532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    fun = each_sub_command_config

    def _test(
            comms: Tuple[Tuple[str, str, Tuple[str, ...]], ...],
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        out: List[SetupCfgCommandConfig] = []
        for obj in fun(setup_dir):
            out.append(obj)
        for command_name, description, commands in comms:
            assert isinstance(command_name, str)
            assert isinstance(description, str)
            assert isinstance(commands, tuple)
            assert isinstance(out, list)
            for cmd in commands:
                if cmd.startswith('flutils'):
                    continue
                if cmd.startswith('pip'):
                    continue

# Generated at 2022-06-11 22:36:53.124478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.pathutils import PathIsh
    from flutils.strutils import random_string

    from . import __path__
    root = Path(__path__[0])
    setup_dir = root / 'setup_dir'
    setup_dir.mkdir(exist_ok=True)
    setup_py = setup_dir / 'setup.py'
    setup_py.write_text(
        """\
from pathlib import Path
from flutils.pathutils import PathIsh
from flutils.strutils import random_string

from flutils.tests._setup_commands import each_sub_command_config

path = PathIsh(random_string())
with path.open('wt') as f:
    f.write(random_string())
"""
    )

# Generated at 2022-06-11 22:37:06.289558
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import subprocess
    import flutils
    from flutils.fileutils import to_posix_path_sep

    this_cmd = 'flutils.setuputils.setup_cfg.each_sub_command_config'
    cmd = [sys.executable, __file__]
    cmd += [this_cmd, to_posix_path_sep(os.path.dirname(flutils.__file__))]
    out = subprocess.check_output(cmd, universal_newlines=True)

# Generated at 2022-06-11 22:37:15.378780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        setup_dir = os.path.realpath(str(setup_dir))
        print('setup_dir: %r' % setup_dir)
        format_kwargs: Dict[str, str] = {
            'setup_dir': setup_dir,
            'home': os.path.expanduser('~')
        }
        setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
        parser = ConfigParser()
        parser.read(setup_cfg_path)
        format_kwargs['name'] = _get_name(parser, setup_cfg_path)
       

# Generated at 2022-06-11 22:37:19.953007
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _dir = os.path.dirname(__file__)
    _path = os.path.join(_dir, 'test_package')
    result = tuple(each_sub_command_config(setup_dir=_path))
    assert len(result) == 5



# Generated at 2022-06-11 22:37:30.308677
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock as mock
    import tempfile

    # Setup the temporary directory
    with tempfile.TemporaryDirectory() as tmpdir:
        with mock.patch('flutils.setup_utils.os') as mocked_os:
            mocked_os.path.isdir.return_value = True
            mocked_os.path.isfile.return_value = True
            mocked_os.path.dirname.return_value = tmpdir
            mocked_os.path.realpath.return_value = tmpdir
            mocked_os.path.expanduser.side_effect = lambda *x: x[0]

            # Setup the setup.py file
            setup_py_path = os.path.join(tmpdir, 'setup.py')
            with open(setup_py_path, 'w'):
                pass

            #

# Generated at 2022-06-11 22:37:37.726426
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import textwrap
    import unittest
    from flutils.miscutils import CustomAssertions

    class EachSubCommandConfigTestCase(unittest.TestCase, CustomAssertions):
        ####################################################################
        # Setup & Teardown
        ####################################################################
        def setUp(self):
            self.orig_environ = os.environ.copy()

        def tearDown(self):
            os.environ.clear()
            os.environ.update(self.orig_environ)

        ####################################################################
        # Tests
        ####################################################################
        def test_setup_command_commands(self):
            """Confirm that commands in the setup_command section of the
            setup.cfg are found.
            """

# Generated at 2022-06-11 22:37:46.897053
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import join, realpath, split
    from tempfile import mkdtemp
    from textwrap import dedent

    def make_setup_cfg(tmpdir, content=''):
        if not isinstance(content, str):
            content = dedent(content)
        setup_cfg = join(tmpdir, 'setup.cfg')
        with open(setup_cfg, 'wt') as fp:
            fp.write(content)
        return setup_cfg

    def make_setup_py(tmpdir, content=''):
        if not isinstance(content, str):
            content = dedent(content)
        setup_py = join(tmpdir, 'setup.py')
        with open(setup_py, 'wt') as fp:
            fp.write(content)
       

# Generated at 2022-06-11 22:37:55.649534
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from shutil import copy, move

    with TemporaryDirectory() as td:
        parent = os.path.join(td, 'parent')
        os.mkdir(parent)
        with open(os.path.join(parent, 'README.txt'), 'w'):
            pass
        with open(os.path.join(parent, 'setup.py'), 'w'):
            pass
        setup_cfg = os.path.join(parent, 'setup.cfg')
        with open(setup_cfg, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )
        setup_commands_cfg = os.path.join(parent, 'setup_commands.cfg')

# Generated at 2022-06-11 22:38:09.761414
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    for cfg in each_sub_command_config():
        print(cfg)

# Generated at 2022-06-11 22:38:18.524474
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test each_sub_command_config and
    # flutils.pathutils.each_recursive_up_dir
    import flutils.pathutils
    import sys
    old_path = sys.path[:]
    try:
        import tests.commands
        sys.path.insert(0, tests.commands.__path__[0])
        setup_dir = flutils.pathutils.each_recursive_up_dir(
            __file__,
            depth=5
        )
        setup_dir = cast(str, next(setup_dir))
        for config in each_sub_command_config(setup_dir):
            __ = (config, )
    finally:
        sys.path[:] = old_path



# Generated at 2022-06-11 22:38:29.537223
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import _getframe as getframe
    from typing import get_type_hints
    from unittest.mock import patch

    from flutils.pathutils import (
        check_dir_exists,
        check_file_exists,
        touch,
    )

    from setup_commands.config import each_sub_command_config

    # Create a temp directory, and populate it with the necessary files
    # to run the unit test.

# Generated at 2022-06-11 22:38:35.058276
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import skip_if_ci
    skip_if_ci()
    from flutils.pathutils import each_parent_dir
    for path in each_parent_dir(os.getcwd()):
        try:
            return list(each_sub_command_config(path))
        except FileNotFoundError:
            pass
    raise RuntimeError("Unable to detect the project's root directory.")

# Generated at 2022-06-11 22:38:45.405766
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    In [2]: import flutils.subcommands
    In [3]: l = list(flutils.subcommands.each_sub_command_config(  # noqa
       ...:     setup_dir='/home/slott56/projects/flutils'))
    In [4]: l[0]
    Out[4]:
    SetupCfgCommandConfig(name='build_docs', camel='BuildDocs', description=''
    'Build the docs', commands=('sphinx-build -b singlehtml docs docs/_build/sin  # noqa
    glehtml',
                                'sphinx-build -b doctest docs docs/_build/doctest',  # noqa
                                'sphinx-build -b html docs docs/_build/html',))
    """
    pass

# Generated at 2022-06-11 22:38:53.330013
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def assert_list(list1, list2):
        assert len(list1) == len(list2)
        for i in range(len(list1)):
            assert list1[i] == list2[i]

    # The contents of setup_commands.cfg

# Generated at 2022-06-11 22:39:01.588967
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import LoggerMock
    logger_mock = LoggerMock()
    base_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'data',
        'setup_commands'
    )
    out: List[SetupCfgCommandConfig] = []
    for x in each_sub_command_config(setup_dir=base_path):
        out.append(x)
    out = tuple(out)
    assert out
    assert out[0].name == 'flutils'
    assert out[0].camel == 'Flutils'
    assert out[0].description == (
        'A collection of utilities that are not specific to a single '
        'package.'
    )
    assert out[0].commands

# Generated at 2022-06-11 22:39:05.359534
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    print('Test each_sub_command_config')
    print('---------------------------')
    pprint(list(each_sub_command_config()))  # noqa: S301
    print()

# Generated at 2022-06-11 22:39:16.602055
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg = {}
    setup_cfg['metadata'] = {'name': 'project'}
    setup_cfg['setup.command.test'] = {'command': 'echo hi'}
    setup_cfg['setup.command.one_two'] = {'command': 'echo one && echo two'}
    setup_cfg['setup.command.one_two_three'] = {
        'command': 'echo one\necho two\necho three',
    }

    # Setup the temporary folder and files.
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'setup.cfg')
        with open(path, 'w') as f:
            config = configparser.ConfigParser()
            config.read_dict(setup_cfg)
            config.write(f)


# Generated at 2022-06-11 22:39:28.558601
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import __init__  # type: ignore # noqa
    from .lib import BaseCommand  # type: ignore # noqa

    #
    # Test setup directory does not exist
    #
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/does/not/exist')

    #
    # Test setup directory is not a directory
    #
    with pytest.raises(NotADirectoryError):
        each_sub_command_config('/etc')

    #
    # Test setup directory does not contain a setup.py file
    #
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/home')

    #
    # Test setup directory does not contain a setup.cfg file
    #

# Generated at 2022-06-11 22:40:03.910407
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    # This function DOES NOT work if the test is run from within a venv.
    # Therefore, when running this test from a venv, it will raise an
    # exception.
    from flutils.strutils import cli_format_verify

    for sc in each_sub_command_config():
        assert isinstance(sc, SetupCfgCommandConfig)
        assert isinstance(sc.name, str)
        assert isinstance(sc.camel, str)
        assert isinstance(sc.description, str)
        assert isinstance(sc.commands, tuple)
        assert len(sc.commands) > 0
        for command in sc.commands:
            assert isinstance(command, str)
            assert len(command) > 0
            assert cli_format_ver

# Generated at 2022-06-11 22:40:12.232173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile
    import shutil

    class TestCase(unittest.TestCase):

        def _create_tmp_setup_dir(self) -> str:
            tmp_dir = tempfile.mkdtemp()
            setup_file = os.path.join(tmp_dir, 'setup.py')
            with open(setup_file, 'w') as f:
                f.write('')
            return tmp_dir

        def test_with_setup_dir(self):
            tmp_dir = self._create_tmp_setup_dir()
            setup_cfg_path = os.path.join(tmp_dir, 'setup.cfg')

# Generated at 2022-06-11 22:40:23.439258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import pprint
    data = []
    for config in each_sub_command_config():
        data.append((config.camel, config.description, config.commands))
    frame_summary = _get_test_frame_summary()
    frame_summary = frame_summary.replace(
        'tmp',
        os.path.realpath(sys.executable)
    )
    out = pprint.pformat(
        data,
        indent=4,
        width=74,
        compact=True
    )
    out = out.replace(
        'tmp',
        os.path.realpath(sys.executable)
    )
    assert out == frame_summary



# Generated at 2022-06-11 22:40:29.037993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(this_dir, '..', '..')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)

# Generated at 2022-06-11 22:40:41.274282
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import mkpath
    from shutil import rmtree
    from tempfile import mkdtemp

    temp_dir = mkdtemp()
    setup_commands_cfg_file_path = os.path.join(
        temp_dir, 'setup_commands.cfg'
    )
    setup_cfg_file_path = os.path.join(temp_dir, 'setup.cfg')
    setup_py_file_path = os.path.join(temp_dir, 'setup.py')

    with mkpath(setup_commands_cfg_file_path):
        with open(setup_commands_cfg_file_path, 'w') as fp:
            fp.write('[metadata]\nname = flutils\n\n')

# Generated at 2022-06-11 22:40:46.972682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import (
        getcwd,
        chdir,
        makedirs
    )
    from os.path import (
        exists,
        join,
    )
    from shutil import rmtree
    from sys import path
    from uuid import uuid4

    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        fp = join(tmpdir, 'setup.cfg')
        with open(fp, 'w') as f:
            f.write('''\
[metadata]
name = xyz
''')

        directory = join(tmpdir, 'sub', 'sub')
        makedirs(directory)
        path.append(directory)

        fp = join(directory, 'setup.cfg')

# Generated at 2022-06-11 22:40:56.010435
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(os.path.join(
            os.path.dirname(__file__),
            '..',
            '..')):
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)
        assert isinstance(cfg.commands, tuple)


if __name__ == '__main__':  # pragma: no cover
    # Run all unit tests, with verbose output
    test_each_sub_command_config()

# Generated at 2022-06-11 22:41:03.392188
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg_name = 'flutils'
    setup_dir = os.path.dirname(
        os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )
    )

# Generated at 2022-06-11 22:41:14.217809
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    import os
    from testfixtures import TempDirectory

    from .test_utils import (
        get_path_to_this_source_file,
        print_imports,
    )

    print_imports()

    class EachSubCommandConfigTest(unittest.TestCase):
        def setUp(self):
            self.cwd = os.getcwd()
            self.temp_dir = TempDirectory()
            self.temp_dir.makedir('project_root')

# Generated at 2022-06-11 22:41:17.037952
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config())
    assert list(each_sub_command_config('.'))


if __name__ == '__main__':
    print(list(each_sub_command_config()))

# Generated at 2022-06-11 22:42:10.957002
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest

    for scc in each_sub_command_config(__file__):
        assert isinstance(scc, SetupCfgCommandConfig)
        assert bool(len(scc.name))
        assert bool(len(scc.camel))
        assert isinstance(scc.commands, tuple)

    # Should raise FileNotFoundError
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/tmp/does/not/exist')

# Generated at 2022-06-11 22:42:21.446369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from re import compile as re_compile
    from pprint import pformat as pfmt

    out = list(each_sub_command_config())
    print(pfmt(out))

    for cmd in out:
        for i in ('name', 'camel', 'description'):
            assert getattr(cmd, i)

        i = re_compile(r'{}'.format(cmd.name))
        for j in cmd.commands:
            assert i.search(j)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:31.725903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import chdir, tmp_chdir


# Generated at 2022-06-11 22:42:38.144395
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import ExitStack as does_not_raise

    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):

        def test__each_sub_command_config(
                self,
                setup_dir: Optional[Union[os.PathLike, str]] = None
        ):
            self.assertGenerator(
                each_sub_command_config(setup_dir),
                SetupCfgCommandConfig,
                does_not_raise()
            )

        def test__each_sub_command_config_no_commands(self):
            self.assertGenerator(
                each_sub_command_config('/path/to/nothing'),
                SetupCfgCommandConfig,
                raises(FileNotFoundError)
            )

    t = Test()

# Generated at 2022-06-11 22:42:42.832874
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config(os.path.dirname(__file__)))
    assert cmds
    assert isinstance(cmds[0], SetupCfgCommandConfig)


if __name__ == '__main__':
    print(list(each_sub_command_config()))

# Generated at 2022-06-11 22:42:50.362704
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Assumes this unit test was run from the "tests" directory.
    import os
    import pprint
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    pprint.pprint(list(each_sub_command_config(parent_dir)))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:43:00.556821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.scripts.setup_utils import setup_dir
    from flutils.testutils import TempDir, assert_rebuilds

    with TempDir() as temp_dir:
        temp_dir = str(temp_dir)
        setup_cfg = os.path.join(temp_dir, 'setup.cfg')
        setup_commands = os.path.join(temp_dir, 'setup_commands.cfg')
        setup_mock = os.path.join(temp_dir, 'setup.py')

        # Setup the files
        with open(setup_cfg, 'wt') as f:
            f.write('''\
[metadata]
name = {{ project }}
''')

# Generated at 2022-06-11 22:43:06.509033
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        if config.camel == 'ListCommands':
            assert config.name == 'list-commands'
            assert config.description == \
                'Lists all available sub-commands for this project.'
            assert config.commands == (
                'python -m flutils.cli_utils.setup_commands.list_commands'
                ' --name={name}',
            )



# Generated at 2022-06-11 22:43:17.147224
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'mock_project_dir')
    out = []
    for config in each_sub_command_config(path):
        out.append(config)


# Generated at 2022-06-11 22:43:25.388881
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Get the directory that contains this test.
    curr_dir = os.path.dirname(__file__)
    curr_dir = os.path.abspath(curr_dir)
    # Change to the root of the source tree.
    old_dir = os.getcwd()
    os.chdir(curr_dir)

# Generated at 2022-06-11 22:45:06.372520
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.miscutils import TempDir
    with TempDir(prefix='test_each_sub_command_config_', suffix='.py') as td:
        setup_py = os.path.join(td, 'setup.py')
        setup_cfg = os.path.join(td, 'setup.cfg')
        setup_commands_cfg = os.path.join(td, 'setup_commands.cfg')
        with open(setup_cfg, 'w') as fh:
            fh.write('[metadata]\nname=test_use_case')

# Generated at 2022-06-11 22:45:07.194386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-11 22:45:20.293910
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from itertools import islice

    import flutils

    res = list(islice(each_sub_command_config(flutils.__path__[0]), 2))
    assert len(res) == 2
    r = res[0]
    assert r.name == 'setup.command.release'
    assert r.commands == (
        'clean',
        '-a',
        'egg_info', 'sdist', 'bdist_wheel',
        'upload'
    )
    r = res[1]
    assert r.description == 'A script to automate pip published releases'

# Generated at 2022-06-11 22:45:33.673228
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import CaptureStdout
    from flutils.sysutils import cd
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    class TestEachSubCommandConfig(TestCase):
        """Unit test for the ``each_sub_command_config`` function."""

        def test_each_sub_command_config(self):
            """Test ``each_sub_command_config()``."""
            tmp_dir = TemporaryDirectory()
            with cd(tmp_dir.name):
                name = 'flutils-test'
                self.assertFalse(Path('setup.cfg').is_file())
                self.assertFalse(Path('setup.py').is_file())
                self.assertFalse(Path('setup_commands.cfg').is_file())

# Generated at 2022-06-11 22:45:38.651388
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config(os.getcwd()):
        if x.name == 'test':
            assert x.commands == (
                'python setup.py test',
                'coverage run --include "*flutils/__init__.py" setup.py test',
                'coverage report -m',
                'coverage html'
            )
            break
    else:
        raise ValueError('test command not found')

# Generated at 2022-06-11 22:45:47.177349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def print_command_config(config: SetupCfgCommandConfig) -> None:
        print('name         :', config.name)
        print('camel        :', config.camel)
        print('description  :', repr(config.description))
        print('commands     :')
        for command in config.commands:
            print('  ', repr(command))
        print()

    for config in each_sub_command_config():
        print_command_config(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:51.749067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    x = list(each_sub_command_config())
    assert isinstance(x, list)
    for item in x:
        assert isinstance(item, SetupCfgCommandConfig)
        assert isinstance(item.name, str)
        assert isinstance(item.camel, str)
        assert isinstance(item.description, str)
        assert isinstance(item.commands, tuple)
        for subitem in item.commands:
            assert isinstance(subitem, str)

# Generated at 2022-06-11 22:46:02.640728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.toolutils import (
        get_script_dir,
    )
    from pprint import pprint
    from typing import (
        Iterable,
        List,
        Tuple,
    )
    import os
    import sys

    _curdir_orig = os.getcwd()

    for _dir in (os.getcwd(), get_script_dir()):
        os.chdir(_dir)
        print('--------------------------------------------------------------')
        print('dir: %r' % _dir)
        _gen = each_sub_command_config()
        if sys.implementation.name == 'cpython':  # pragma: no cover
            print('type(_gen): %r' % type(_gen))
            print('next(_gen): %r' % next(_gen))