

# Generated at 2022-06-11 22:36:23.641434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_config(
            config: SetupCfgCommandConfig,
            expected_name: str,
            expected_camel: str,
            expected_description: str,
            expected_commands: Tuple[str, ...]
    ) -> None:
        assert config.name == expected_name
        assert config.camel == expected_camel
        assert config.description == expected_description
        assert config.commands == expected_commands

    with open(
            'setup_commands.cfg', 'w'
    ) as f:
        f.write("[setup.command.test1]\n")
        f.write('name = Test 1\n')
        f.write('description = This is test 1\n')
        f.write('commands = \\\n')

# Generated at 2022-06-11 22:36:34.160453
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        if cfg.name == 'deploy':
            assert cfg.description == 'Deploys to PyPi.'
            assert cfg.commands == tuple(['python setup.py sdist upload'])
        elif cfg.name == 'build':
            assert cfg.description == 'Builds the project.'
            assert cfg.commands == tuple([
                'python setup.py -q clean --all',
                'python setup.py build',
            ])
        elif cfg.name == 'upload-docs':
            assert cfg.description == 'Uploads documentation to GitHub.'
            assert cfg.commands == tuple([
                './build_docs.sh',
                './upload_docs.sh',
            ])

# Generated at 2022-06-11 22:36:44.665620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Setup
    setup_cfg_path = os.path.join(__file__, '..', '..', 'setup.cfg')
    setup_cfg_path = os.path.realpath(setup_cfg_path)
    setup_cfg_path = os.path.abspath(setup_cfg_path)
    setup_commands_cfg_path = os.path.join(
        __file__, '..', '..', 'setup_commands.cfg'
    )
    setup_commands_cfg_path = os.path.realpath(setup_commands_cfg_path)
    setup_commands_cfg_path = os.path.abspath(setup_commands_cfg_path)

    try:
        os.unlink(setup_cfg_path)
    except:
        pass

# Generated at 2022-06-11 22:36:47.261083
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    each_sub_command_config()

# Generated at 2022-06-11 22:36:55.599199
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    os.chdir(os.path.dirname(__file__))
    setup_dir = os.path.join(os.getcwd(), 'data', 'setup_cfg_project-1')
    # Exercise
    out = list(each_sub_command_config(setup_dir))
    # Verify
    assert len(out) == 3

    # Setup
    setup_dir = os.path.join(os.getcwd(), 'data', 'setup_cfg_project-2')
    # Exercise
    out = list(each_sub_command_config(setup_dir))
    # Verify
    assert len(out) == 2


if __name__ == '__main__':
    import sys
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-11 22:37:07.673206
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fileutils import UniqFileName
    from pathlib import Path
    import shutil
    import sys
    cur_dir = os.getcwd()

# Generated at 2022-06-11 22:37:15.878094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    results = []
    for scfg in each_sub_command_config():
        results += [
            (
                scfg.name,
                scfg.camel,
                scfg.description,
                scfg.commands
            ),
            (
                scfg.name,
                scfg.camel,
                scfg.description,
                scfg.commands
            ),
        ]

# Generated at 2022-06-11 22:37:27.748517
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyProtectedMember
    from flutils.configutils import _each_setup_cfg_command  # type: ignore
    # noinspection PyProtectedMember
    from flutils.configutils import _get_name  # type: ignore
    # noinspection PyProtectedMember
    from flutils.configutils import _validate_setup_dir  # type: ignore
    # noinspection PyProtectedMember
    from flutils.configutils import _prep_setup_dir  # type: ignore
    import pathlib

    setup_dir = pathlib.Path(__file__).parent.resolve()
    setup_dir = setup_dir / "testdata" / "setup_dir"
    setup_cfg_path = setup_dir / "setup.cfg"

# Generated at 2022-06-11 22:37:36.216548
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import contextmanager
    from tempfile import (
        NamedTemporaryFile,
        mkdtemp,
    )
    from textwrap import dedent
    from urllib.request import pathname2url
    from urllib.parse import urlopen
    from unittest import TestCase

    class EachSubCommandConfigTestCase(TestCase):
        @contextmanager
        def _prep_setup_cfg(
                self,
                contents: str,
                use_setup_commands_cfg: bool = False
        ):
            setup_cfg_path = mkdtemp()
            setup_cfg_path = os.path.join(setup_cfg_path, 'setup.cfg')
            with open(setup_cfg_path, 'w') as wf:
                wf.write(contents)

# Generated at 2022-06-11 22:37:38.531045
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:57.541391
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import importlib
    import sys

    setup_cfg_txt = textwrap.dedent("""\
        [metadata]
        name = flutils
    """)

    setup_commands_cfg_txt = textwrap.dedent("""\
        [setup.command.commands.my_commands]
        name = my-commands
        description = run my commands
        commands = echo "hello"
                    echo "world"
    """)

    dirpath = tempfile.mkdtemp()

# Generated at 2022-06-11 22:38:07.534760
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.paths import expand
    from flutils.datautils import to_dict
    from flutils.miscutils import generate_random_name
    from pprint import pformat
    from flutils.setuputils import each_sub_command_config
    from flutils.strutils import underscore_to_camel

    for config in each_sub_command_config():
        # The following ensures the strings are valid identifiers
        title = config.name.replace('.', '_')
        title = title.replace('-', '_')
        assert title.isidentifier() is True

        # The following ensures the camel variable name is a valid
        # identifier
        assert config.camel.isidentifier() is True

        # The following ensures the camel variable name is correct

# Generated at 2022-06-11 22:38:19.073525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.pyutils import classproperty

    from ..utils import create_temp_module

    # Create a temp module

# Generated at 2022-06-11 22:38:29.963101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTester
    cmds = tuple(each_sub_command_config(cast(str, None)))

# Generated at 2022-06-11 22:38:37.383258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib

    for sub_cmd in each_sub_command_config(
            pathlib.Path(__file__).parent.parent
    ):
        print(sub_cmd)


if __name__ == '__main__':
    # Will be True if executed from the command-line.
    # Will be False if executed from the interactive shell.
    import sys
    is_main = (__name__ == '__main__') and (__package__ is None)
    if is_main and len(sys.argv) > 1 and sys.argv[1] == '--test':
        test_each_sub_command_config()

# Generated at 2022-06-11 22:38:46.764904
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pyutils import remove_namespace
    from flutils.typing import Callable, Iterable

    _setup_cmd_types = remove_namespace('SetupCfgCommandConfig')
    SetupCfgCommandConfig = _setup_cmd_types.SetupCfgCommandConfig
    CACHE: Dict[str, type] = {str(SetupCfgCommandConfig): SetupCfgCommandConfig}

    def setup_cfg_config(
            name: str,
            camel: str,
            description: str,
            commands: Iterable[str] = ()
    ) -> type:
        return cast(type, CACHE[str(SetupCfgCommandConfig)])(
            name, camel, description, tuple(commands)
        )


# Generated at 2022-06-11 22:38:50.427020
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('.'):
        assert config
        assert config.commands
        for cmd in config.commands:
            assert cmd

# Generated at 2022-06-11 22:39:00.197156
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            import os
            import tempfile

            def mktmppath(*parts):
                return os.path.join(tmpdir, *parts)

            def mktmpsrcpath(*parts):
                return mktmppath('src', 'project', *parts)

            tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 22:39:11.316613
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Call each_sub_command_config and save the results
    results = [
        c for c in each_sub_command_config(setup_dir=os.path.dirname(__file__))
    ]
    # Confirm all the results
    assert len(results) == 8
    # Assert the first item in the results
    assert (
        results[0] == SetupCfgCommandConfig(
            'create_command_module',
            'CreateCommandModule',
            'Create the command module.',
            (
                'python -m flutils.setup_commands.commands.cmd_create_command_module',  # noqa
                'python flutils/setup_commands/commands/cmd_create_command_module.py'  # noqa
            )
        )
    )
    # Assert the last item

# Generated at 2022-06-11 22:39:23.032209
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _get_cmds(
            directory: Union[os.PathLike, str]
    ) -> Dict[
        str,
        Tuple[
            str,
            str,
            Tuple[str, ...]
        ]
    ]:
        out: Dict[
            str,
            Tuple[
                str,
                str,
                Tuple[str, ...]
            ]
        ] = {}
        for cmd_config in each_sub_command_config(directory):
            out[cmd_config.name] = (cmd_config.camel, cmd_config.description,
                                    cmd_config.commands)
        return out

    # in the test directory, if the setup.cfg file is present it should
    # be ignored

# Generated at 2022-06-11 22:39:56.485964
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands: List[str] = []
    for command in each_sub_command_config('.'):
        if command.camel:
            commands.append(command.camel)
    assert commands == [
        'ArgparseCommand',
        'Configure',
        'ConfigureDev',
        'ConfigureProd',
        'Develop',
        'Discover',
        'InstallDeps',
        'RunPyTest',
        'RunTox',
        'Tox',
        'UpgradeDeps',
        'UpgradeDepsDev',
        'UpgradeDepsProd'
    ]

# Generated at 2022-06-11 22:40:00.065620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    output = []
    for config in each_sub_command_config():
        output.append(config)
    assert len(output) == 1
    assert output[0].name == 'flutils.test'
    assert output[0].camel == 'FlutilsTest'
    assert output[0].commands == (
        'python runtests.py',
    )

# Generated at 2022-06-11 22:40:02.530071
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-11 22:40:11.595311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # pylint: disable=line-too-long
    def get_it():
        yield SetupCfgCommandConfig(
            'test.test',
            'TestTest',
            '',
            (
                'pylint --rcfile={home}/.pylintrc {name} setup_commands.py',
            )
        )

    with mock.patch('flutils.setupcfg.each_setup_cfg_command') as mock_ecsc:
        mock_ecsc.return_value = get_it()
        with mock.patch('flutils.setupcfg._prep_setup_dir') as mock_psd:
            mock_psd.return_value = 'setup_dir'
            gen = each_sub_command_config()
            vals = list(gen)

# Generated at 2022-06-11 22:40:24.081990
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        'test_files',
        'each_sub_command_config_test_setup'
    )
    commands = list(each_sub_command_config(setup_dir))

# Generated at 2022-06-11 22:40:32.703615
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""

    def _test_case(
            cmd_name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...],
            setup_dir: Optional[str] = None
    ) -> None:
        config = next(
            iter(
                filter(
                    lambda x: x.name == cmd_name,
                    each_sub_command_config(setup_dir)
                )
            )
        )
        assert config.camel == camel
        assert config.description == description
        assert config.commands == commands

    _test_case(
        cmd_name='foo',
        camel='Foo',
        description='Foo command.',
        commands=('echo "Hello, world!"',)
    )

    setup_

# Generated at 2022-06-11 22:40:43.738197
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from subprocess import check_output
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as path:
        path = os.path.join(path, 'setup.cfg')
        with open(path, 'w') as fp:
            fp.write('[metadata]\n')
            fp.write('name = flutils\n')

        with TemporaryDirectory() as path2:
            path2 = os.path.join(path2, 'setup_commands.cfg')
            with open(path2, 'w') as fp:
                fp.write('[setup.command.check-docs]\n')
                fp.write('command = make docs\n')
                fp.write('\n')
                fp.write('[setup.command.check-manifest]\n')
                fp.write

# Generated at 2022-06-11 22:40:52.764532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from inspect import signature

    from flutils.testutils import run_doctest

    class Test_each_sub_command_config(TestCase):
        """Unit tests for each_sub_command_config"""

        def test_various(self):
            """
            >>> len(list(each_sub_command_config())) > 0
            True
            """

    run_doctest(Test_each_sub_command_config)


if __name__ == '__main__':
    from flutils.testutils import run_doctest
    run_doctest()

# Generated at 2022-06-11 22:40:56.464161
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config():
        print(x)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:58.436317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        print(item)



# Generated at 2022-06-11 22:41:58.484574
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _setup_dir = os.path.join(
        os.path.dirname(__file__),
        'fixtures', 'setup',
    )
    _setup_cfg_path = os.path.join(_setup_dir, 'setup.cfg')
    _setup_commands_path = os.path.join(_setup_dir, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(_setup_cfg_path)
    format_kwargs = {
        'setup_dir': os.path.realpath(_setup_dir),
        'home': os.path.expanduser('~'),
    }
    format_kwargs['name'] = _get_name(parser, _setup_cfg_path)
    parser = ConfigParser()
    parser.read(_setup_commands_path)
    out

# Generated at 2022-06-11 22:42:09.952730
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import UnitTester
    from itertools import chain

    def _each_sub_command_config(
            u: UnitTester,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for item in each_sub_command_config(setup_dir):
            name = item.name.split(' ')[0]
            u.assert_regex(item.name, f'\\b{name}\\b$')
            if item.description:
                u.assert_regex(item.description, f'\\b{name}\\b$')
            if item.name.endswith('test11_sub') is True:
                u.assert_equal(item.camel, 'Test11Sub')

# Generated at 2022-06-11 22:42:11.732078
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = [c for c in each_sub_command_config('./')]
    assert out



# Generated at 2022-06-11 22:42:24.784430
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO

    io = StringIO()
    print('', file=io)
    print('[metadata]', file=io)
    print('name = flutils', file=io)
    print('', file=io)
    print('[setup.command.flake8]', file=io)
    print('name = flake8', file=io)
    print('description = Runs the flake8 code quality tool.', file=io)
    print('command = flake8 --config={setup_dir}/setup.cfg {setup_dir}',
          file=io)
    print('', file=io)
    print('[setup.command.pytest]', file=io)
    print('name = pytest', file=io)
    print('description = Runs all the tests for the project.', file=io)
   

# Generated at 2022-06-11 22:42:34.053605
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    from flutils.testutils import UnitTestCase

    from flutils.setup_utils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    class Test_each_sub_command_config(UnitTestCase):

        @classmethod
        def tearDownClass(cls) -> None:
            os.chdir(str(cls._original_cwd))

        def assertCommandConfigEqual(
                self,
                expected: Tuple[SetupCfgCommandConfig, ...],
                actual: Generator[SetupCfgCommandConfig, None, None]
        ) -> None:
            self.assertIsInstance(expected, tuple)
            self.assertIsInstance(actual, Generator)

# Generated at 2022-06-11 22:42:39.871454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config(os.path.dirname(__file__)):
        assert isinstance(command, SetupCfgCommandConfig)
        assert isinstance(command.name, str)
        assert isinstance(command.camel, str)
        assert isinstance(command.description, str)
        assert isinstance(command.commands, tuple)

# Generated at 2022-06-11 22:42:46.546068
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Execute each_sub_command_config() function
    for config in each_sub_command_config():
        # Check that each value is as expected
        assert config.name == 'dev'
        assert config.description == 'My project.'
        assert config.camel == 'Dev'
        assert config.commands == (
            'python -m flutils.black .',
        )
        break

# Execute test
test_each_sub_command_config()

# Generated at 2022-06-11 22:42:56.770320
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .testing_utils import TestingUtils

    tu = TestingUtils()
    with tu.mkdtemp() as tupath:
        # Create a setup.cfg file
        tupath.write_file('setup.cfg', textwrap.dedent("""
        [metadata]
        name = {name}

        [setup.command.foo]
        command = echo bar
        [setup.command.foo.bar]
        command = echo baz

        [setup.command.baz]
        commands =
            echo bar
            echo baz

        [setup.command.bar]
        command = echo bar
        """))

# Generated at 2022-06-11 22:43:05.432458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert getattr(each_sub_command_config, '__annotations__', None)
    for command in each_sub_command_config(
            setup_dir=os.path.dirname(__file__)
    ):
        assert isinstance(command, SetupCfgCommandConfig)
        assert isinstance(command.name, str)
        assert isinstance(command.camel, str)
        assert isinstance(command.description, str)
        assert isinstance(command.commands, tuple)


# Generated at 2022-06-11 22:43:16.985532
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:44:53.532977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'setup_cfg_test.txt'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {'name': 'setup'}

# Generated at 2022-06-11 22:45:04.796679
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.fileutils as fu
    import flutils.pathutils as pu
    import sys

    def _tst_each_sub_command_config(path: str, expected_out: str) -> None:
        assert path
        assert expected_out
        assert os.path.isfile(path) is True
        print('*' * 79)
        print(path)
        out = fu.get_file_as_string(path)
        print(out)
        assert expected_out == out

    sys.path.append('tests/data')
    from tests.data.project.test_flutils_data_project.src import config
    for out in each_sub_command_config(pu.get_parent_dir(config.__file__)):
        print(out)
    _tst_each_sub_command_

# Generated at 2022-06-11 22:45:11.509273
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pkg_resources

    test_utils_req = pkg_resources.Requirement.parse('flutils')
    test_utils_loc = pkg_resources.working_set.find(test_utils_req).location
    test_utils_src = os.path.join(test_utils_loc, 'flutils', 'tests', 'src')
    sys.path.insert(0, test_utils_src)

    import cmd_info
    import cmd_setup

    def is_dev_env() -> bool:
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            basename = os.path.basename(fs.filename)
            if basename == 'setup.py':
                return True
        return False


# Generated at 2022-06-11 22:45:17.238422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils
    for subcmd in each_sub_command_config(flutils.__path__[0]):
        print(subcmd)
        path = os.path.join(subcmd.commands[0].split()[1], '__init__.py')
        assert os.path.isfile(path)

# Generated at 2022-06-11 22:45:25.335149
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import (
        dirname,
        join,
    )
    from flutils.files import find_file

    path = find_file(dirname(__file__), '.gitignore')
    path = dirname(path)
    for cfg in each_sub_command_config(path):
        assert isinstance(cfg, SetupCfgCommandConfig)
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)
        assert isinstance(cfg.commands, tuple)
        assert len(cfg.commands) >= 1

    path = find_file(dirname(__file__), '.gitignore')
    path = dirname(dirname(path))

# Generated at 2022-06-11 22:45:33.999112
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_path = os.path.join(os.path.dirname(__file__), 'test_package')
    results = list(each_sub_command_config(setup_dir=test_path))
    assert len(results) == 1
    result = results[0]
    assert result.name == 'test.command'
    assert result.camel == 'TestCommand'
    assert result.description == 'A sample command.'
    assert result.commands == ('ls -l', 'uname -s -r')

# Generated at 2022-06-11 22:45:39.776840
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = str(tmpdirname)

        setup_py = os.path.join(tmpdirname, 'setup.py')
        with open(setup_py, 'w') as f:
            f.write(
                "from setuptools import setup\n"
                "setup()\n"
            )

        setup_cfg = os.path.join(tmpdirname, 'setup.cfg')

# Generated at 2022-06-11 22:45:49.585995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    def _exec(command):
        print('\n>', command)
        os.system(command)

    dir = 'python/flutils/test'
    setup_cfg_path = 'setup.cfg'
    parser = ConfigParser()
    parser.read(setup_cfg_path)

    name = _get_name(parser, setup_cfg_path)

    sub_command_config: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(dir)
    )
    for cfg in sub_command_config:
        command = " ".join(cfg.commands)
        _exec(command)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:46:01.110756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import pathlib
    from pprint import pprint
    from shutilutils.paths import PathUtils
    from stat import (
        S_IRUSR,
        S_IXOTH,
    )

    for cmd in each_sub_command_config():
        pprint(cmd)

    # Test with a setup.cfg that has no [metadata] section