

# Generated at 2022-06-11 22:36:23.902657
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for cfg in each_sub_command_config(setup_dir):
            print(cfg)
    print()
    _test()
    print()
    _test('/Users/bob/PycharmProjects/flutils')
    print()
    _test('/Users/bob/PycharmProjects/flutils/flutils')
    print()
    _test('/Users/bob/PycharmProjects/flutils/flutils/faas')
    print()
    _test('/Users/bob/PycharmProjects/flutils/flutils/data')
    print()

# Generated at 2022-06-11 22:36:34.296997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    import textwrap
    import tempfile
    old_args = sys.argv
    stdout = sys.stdout
    fp = io.StringIO()

# Generated at 2022-06-11 22:36:44.750702
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, '8e7c0f5b6208d2b3')
    path = os.path.realpath(path)
    assert os.path.isdir(path) is True

    opts = tuple(each_sub_command_config(path))
    assert len(opts) == 1

    opt = next(x for x in opts if x.name == 'test')
    assert opt.camel == 'Test'
    assert opt.description == 'Runs the tests.'
    assert opt.commands == (
        'python -m unittest discover -s ./ --failfast',
        'python -m unittest discover -s ./tests/ --failfast',
    )


# Generated at 2022-06-11 22:36:53.040097
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd_config in each_sub_command_config('.'):
        name = sub_cmd_config.name
        camel = sub_cmd_config.camel
        description = sub_cmd_config.description
        commands = sub_cmd_config.commands

        print(f'\nName: {name}')
        print(f'Camel: {camel}')
        print(f'Description: {description}')
        for index, command in enumerate(commands):
            print(f'Commands[{index}] {command}')


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:58.037551
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pretty = Pretty()
    for i, x in enumerate(each_sub_command_config()):
        pretty.print(x)
        if i > 10:
            break



# Generated at 2022-06-11 22:37:08.570531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from inspect import getsource
    from io import StringIO
    from pathlib import Path

    from flutils.pathutils import TestPath

    t_path = TestPath(__file__)
    assert t_path.this_module_path
    test_path = Path(t_path.this_module_path)
    setup_cfg_path = test_path.parent.parent / 'setup.cfg'
    setup_cfg_contents = setup_cfg_path.read_text()
    setup_cfg_contents = '\n'.join(
        list(filter(len, map(lambda x: x.strip(), setup_cfg_contents.splitlines()))))

# Generated at 2022-06-11 22:37:16.326407
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.pathutils
    import tempfile

    orig_path = os.getcwd()

    with tempfile.TemporaryDirectory() as temp_path:
        os.chdir(temp_path)


# Generated at 2022-06-11 22:37:24.468715
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.dirname(__file__)

    def _testing(
            *,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for config in each_sub_command_config(setup_dir):
            yield SetupCfgCommandConfig(
                config.name,
                config.camel,
                config.description,
                config.commands
            )

    generator = _testing(setup_dir='/path/to/nowhere')
    try:
        next(generator)  # Should fail w/ FileNotFoundError
    except FileNotFoundError:
        pass
    else:
        raise Exception("Expecting FileNotFoundError")


# Generated at 2022-06-11 22:37:34.639120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    import tempfile
    from unittest import TestCase

    class Test(TestCase):
        def test_it(self):
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp)
                setup_py = path / 'setup.py'
                setup_cfg = path / 'setup.cfg'
                setup_commands_cfg = path / 'setup_commands.cfg'
                setup_py.write_text(
                    '#!/usr/bin/env python\n'
                    '# -*- coding: utf-8 -*-\n'
                )
                setup_cfg.write_text(
                    '[metadata]\n'
                    'name = foo\n'
                )

# Generated at 2022-06-11 22:37:45.176505
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.test_scripts import (
        get_setup_cfg_command_info,
        get_setup_cfg_command_config,
    )
    import json
    import os
    import sys
    import traceback
    import unittest

    class TestSubCommandConfig(unittest.TestCase):

        def test_each_vs_get_command_config(self):
            setup_cfg_path = os.path.join(
                os.path.dirname(sys.argv[0]), 'setup.cfg'
            )
            setup_dir = os.path.dirname(setup_cfg_path)
            with open(setup_cfg_path, 'rt') as fp:
                setup_cfg = fp.read()

# Generated at 2022-06-11 22:38:12.711208
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_file_path

    for path in each_file_path('tests'):
        if path.name == 'test_setup_cfg.py':
            test_dir = os.path.dirname(path)
            break

    cmds: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(test_dir)
    )
    assert len(cmds) == 10



# Generated at 2022-06-11 22:38:25.061012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each(expected: int) -> None:
        actual = 0
        for _ in each_sub_command_config():
            actual += 1
            assert isinstance(_, SetupCfgCommandConfig)
        assert actual == expected


# Generated at 2022-06-11 22:38:35.685509
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase, run_cases

    class TestEachSubCommandConfig(UnitCase):

        def test_each_sub_command_config(self):
            res = list(each_sub_command_config())
            self.assertEqual(
                len(res),
                6,
                "The length of the 'res' value, %r, is NOT %r."
                % (len(res), 6)
            )
            res = res[3]

# Generated at 2022-06-11 22:38:45.880333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile

    build_path = os.path.join(tempfile.gettempdir(), 'BUILD')
    if os.path.exists(build_path) is False:
        os.mkdir(build_path)


# Generated at 2022-06-11 22:38:53.536473
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _each_cmd(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(setup_dir)

    # Sub-command config test case
    assert list(_each_cmd(None)) == [
        SetupCfgCommandConfig(
            'init', 'Init',
            'Initialize the projects directory structure.',
            ('rm -rf build dist', 'flit install --pth-file --deps develop')
        ),
        SetupCfgCommandConfig(
            'build', 'Build',
            'Build the source code.',
            ('pip wheel -w wheelhouse .',)
        )
    ]

    # Test when a setup_commands.cfg file exists in the project's
    # directory

# Generated at 2022-06-11 22:39:01.683067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Now testing function each_sub_command_config')
    print('')

    def test(
            setup_dir: str,
            expected_commands: Tuple[str, ...]
    ) -> None:
        print("Expected commands:")
        print("\t{}".format(expected_commands))
        print("Actual commands:")
        for command in each_sub_command_config(setup_dir):
            print("\t{}".format(command.name))
        assert expected_commands == tuple(
            command.name for command in each_sub_command_config(setup_dir)
        )


# Generated at 2022-06-11 22:39:04.991842
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config():
        assert sub_cmd.name
        assert sub_cmd.camel
        assert sub_cmd.commands



# Generated at 2022-06-11 22:39:12.792991
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    r"""
    To test the function each_sub_command_config,
    ``python -m flutils.setup_utils.each_sub_command_config``
    """
    if __name__ == '__main__':
        from flutils.logutils import init_logging

        init_logging()

        for config in each_sub_command_config(_prep_setup_dir()):
            print()
            print(config.name)
            print(config.camel)
            print(config.description)
            print(config.commands)
        return 0


if __name__ == '__main__':
    import sys as _sys
    _sys.exit(test_each_sub_command_config())

# Generated at 2022-06-11 22:39:26.996270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_file_path
    from flutils.testutils import UnitTestFixture
    import unittest

    with UnitTestFixture() as fixture:
        fixtures = os.path.join(os.path.dirname(__file__), 'fixtures')
        dirs = os.listdir(fixtures)
        for dir_ in dirs:
            fixture.enter_dir(dir_)
            for path in each_parent_file_path(os.getcwd()):
                if os.path.basename(path) == 'setup.py':
                    break
            else:
                raise EnvironmentError(
                    'Unable to find the setup.py file for %r.'
                    % fixture.test_dir
                )
            for each in each_sub_command_config(path):
                print

# Generated at 2022-06-11 22:39:42.091239
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _format_kwargs: Dict[str, str] = {
        'home': os.path.expanduser('~'),
        'name': 'test-lookup-setup',
        'setup_dir': os.path.abspath(
            os.path.join(os.path.dirname(__file__), 'data')
        )
    }

# Generated at 2022-06-11 22:40:12.469337
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        cd,
        rmrf,
        TEST_DATA_PATH,
    )

    # pylint: disable=unused-argument
    def _exists(setup_dir: str, *args: str) -> bool:
        return True

    def _test_test_project(
            test_data_path: str, test_setup_dir: str,
            exists: Callable[[str, str], bool],
    ) -> None:
        test_setup_cfg_path = os.path.join(test_data_path, 'setup.cfg')
        test_setup_cfg_commands_path = os.path.join(
            test_data_path, 'setup_commands.cfg'
        )


# Generated at 2022-06-11 22:40:22.860950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfg = next(each_sub_command_config('tests/test_packages/pkg1'))
    assert cfg.name == 'test_cmd'
    assert cfg.description == 'test description'
    assert cfg.camel == 'TestCmd'
    assert cfg.commands == ('test cmd',)

    cfg = next(each_sub_command_config('tests/test_packages/pkg2'))
    assert cfg.name == 'test_cmd'
    assert cfg.description == 'test description'
    assert cfg.camel == 'TestCmd'
    assert cfg.commands == ('test cmd',)



# Generated at 2022-06-11 22:40:24.513868
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(f'{repr(sc.name)}:\n{sc.commands}\n')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:31.456237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    configs = tuple(each_sub_command_config(setup_dir))
    assert len(configs) == len(
        (
            'clean_build', 'clean_dist', 'clean_pyc', 'clean_eggs',
            'clean_all', 'build', 'dist', 'docs', 'tox', 'tox37', 'tox38',
            'tox39', 'tox310', 'tox311', 'toxlatest',
        )
    )


# Generated at 2022-06-11 22:40:39.927430
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def test_each(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for x in each_sub_command_config(setup_dir):
            print(x)
            yield x

    assert list(test_each(setup_dir='../../flux/'))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:48.962391
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    # pylint: disable=unused-argument
    def _each_setup_cfg_command_section_test(
            parser: ConfigParser
    ) -> Generator[Tuple[str, str], None, None]:
        for section in parser.sections():
            section = cast(str, section)
            section = section.strip()
            if section.startswith('setup.command.'):
                command_name = '.'.join(section.split('.')[2:])
                if command_name:
                    yield section, command_name


# Generated at 2022-06-11 22:40:55.370412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        os.chdir(
            os.path.expanduser('~/projects/flutils/.test/setup.cfg_test')
        )
        for sc in each_sub_command_config():
            print(sc)
    finally:
        os.chdir(os.path.expanduser('~/projects/flutils'))

# Generated at 2022-06-11 22:41:07.254290
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    from pprint import pprint

    here = os.path.dirname(__file__)
    project_dir = os.path.normpath(os.path.join(here, '..', '..', '..'))
    if project_dir not in sys.path:
        sys.path.insert(0, project_dir)

    class Dummy:
        pass

    sys.modules['__main__'] = Dummy()
    Dummy.__file__ = os.path.join(project_dir, 'setup.py')


# Generated at 2022-06-11 22:41:11.384682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from setup import (
        setup,
        commands,
    )
    with patch('setup.setup.each_sub_command_config') as m:
        setup(commands=commands)
        out = m.call_args_list
        assert len(out) == 1
        out = out[0]
        assert len(out) == 1
        out = out[0]
        assert len(out) == 1
        out = out[0]
        assert len(out) == 0

# Generated at 2022-06-11 22:41:20.134931
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(setup_dir: os.PathLike) -> None:
        for config in each_sub_command_config(setup_dir):
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.commands, tuple)
            for command in config.commands:
                assert isinstance(command, str)

    setup_dir = os.path.realpath(os.path.join(
        os.path.dirname(__file__), '..', '..', '..', '..',
    ))
    _test(setup_dir)
    setup_dir = os.path.realpath(os.path.join(
        os.path.dirname(__file__), '..', '..', '..', '..', '..',
    ))


# Generated at 2022-06-11 22:42:16.280274
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import List
    from flutils.pathutils import make_path
    from pathlib import Path

    from .bottle_app import app
    from .cli import main

    args: List[str]

    args = ['--setup-dir', '.']
    assert main(args) is False

    p: Path = make_path('test-conf-main')
    if p.exists():
        p.rmtree()
    p.mkdir()
    p.joinpath('setup_commands.cfg').open('w').close()
    args = ['--setup-dir', p]

    assert main(args) is False

    configs: List[SetupCfgCommandConfig] = []
    for config in each_sub_command_config(p):
        configs.append(config)

# Generated at 2022-06-11 22:42:28.538985
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the each_sub_command_config() function."""
    setup_dir = os.path.realpath(os.path.dirname(__file__))
    assert os.path.isdir(setup_dir)
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py'))

    out = list(each_sub_command_config(setup_dir))
    assert out
    name = os.path.basename(setup_dir)
    for config in out:
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.camel, str)
        assert isinstance(config.commands, tuple)
        assert isinstance(config.description, str)
        assert isinstance(config.name, str)

# Generated at 2022-06-11 22:42:35.069141
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname
    from . import PROJECT_DIR
    from .test_utils import set_module_attr

    setup_dir = dirname(dirname(dirname(dirname(dirname(dirname(__file__))))))
    if setup_dir.lower() == PROJECT_DIR.lower():
        setup_dir = dirname(dirname(dirname(dirname(dirname(dirname(
            dirname(__file__)))))))
    set_module_attr('flutils.scriptutils.PROJECT_DIR', setup_dir)
    ret = list(each_sub_command_config(setup_dir))
    assert len(ret) == 10
    assert ret[0].name == 'coverage'

# Generated at 2022-06-11 22:42:46.856919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected = {
        'clean': SetupCfgCommandConfig(
            'clean',
            'Clean',
            'Clean up directories/files.',
            (
                'rm -rf build/ dist/ *.egg-info/',
                'find . -name *.pyc -delete',
                'find . -name __pycache__ -delete',
                'find . -name *.~ -delete',
            )
        ),
        'lint': SetupCfgCommandConfig(
            'lint',
            'Lint',
            'Run flake8 and mypy on the code.',
            (
                'python3 -m flake8 src/ tests/ docs/',
                'python3 -m mypy src/ tests/ docs/',
            )
        )
    }


# Generated at 2022-06-11 22:42:51.068833
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        print(sub_command)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:58.714857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.realpath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'setup_commands.cfg'
    ))
    with open(path) as f:
        setup_cfg = f.read()
    for config in each_sub_command_config():
        cfg = config._asdict()
        for k, v in cfg.items():
            if isinstance(v, str):
                setup_cfg = setup_cfg.replace(v, '%s' % k)
            elif isinstance(v, tuple) or isinstance(v, list):
                v = list(v)
                l_len = len(v)
                while v:
                    c = v.pop()

# Generated at 2022-06-11 22:43:08.650097
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.systemutils import chdir
    from flutils.pathutils import create_dir_path
    from flutils.tool.setup_command import (
        _validate_setup_dir, _prep_setup_dir, each_sub_command_config
    )
    from tempfile import TemporaryDirectory

# Generated at 2022-06-11 22:43:12.633091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for c in each_sub_command_config(setup_dir=os.path.dirname(__file__)):
        print()
        print(c)


# Call the unit test
test_each_sub_command_config()

# Generated at 2022-06-11 22:43:23.796955
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.typeutils import UNSET
    from sys import argv, executable
    import tempfile
    import pathlib

    with tempfile.TemporaryDirectory(prefix='flutils-test-') as dirname:
        dirname = pathlib.Path(dirname)
        setup_cfg = dirname / 'setup.cfg'
        setup_cfg.write_text("[metadata]\nname = foo\n")
        setup_py = dirname / 'setup.py'
        setup_py.write_text("print('foo')\n")
        setup_commands_cfg = dirname / 'setup_commands.cfg'

# Generated at 2022-06-11 22:43:30.537361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.join(setup_dir, '..', '..', 'flutils')
    test_obj = []
    for x in each_sub_command_config(setup_dir):
        test_obj.append(x)
        print(x)
    assert len(test_obj) == 5

# Generated at 2022-06-11 22:45:04.579129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    setup_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test',
        'package'
    )
    # Exercise
    each_sub_command_config(setup_dir)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:13.047063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint

    def _print_sub_commands(setup_dir):
        print(setup_dir)
        pprint.pprint(tuple(sorted(each_sub_command_config(setup_dir))))

    _print_sub_commands('.')
    _print_sub_commands('../flutils')
    _print_sub_commands('../flutils_cli')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:23.271366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test missing file
    try:
        list(each_sub_command_config())
    except FileNotFoundError:
        pass
    else:
        raise AssertionError('Expected FileNotFoundError')

    # Test missing file
    try:
        list(each_sub_command_config(123))
    except FileNotFoundError:
        pass
    else:
        raise AssertionError('Expected FileNotFoundError')

    # Test missing file
    try:
        list(each_sub_command_config('does_not_exist'))
    except FileNotFoundError:
        pass
    else:
        raise AssertionError('Expected FileNotFoundError')

    # Test missing file

# Generated at 2022-06-11 22:45:30.141783
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for ``each_sub_command_config``."""
    from flutils.miscutils import get_caller_dir_path

    path = get_caller_dir_path()
    for cfg in each_sub_command_config(path):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:33.317519
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    try:
        next(gen)
    except (FileNotFoundError, LookupError):
        pass
    else:
        assert False

# Generated at 2022-06-11 22:45:40.706609
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # pragma: no cover
    import pprint  # noqa: F401
    setup_dir = os.path.split(__file__)[0]
    print(setup_dir)
    for config in each_sub_command_config(setup_dir):
        pprint.pprint(config)
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:43.253199
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 22:45:48.366870
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(os.path.abspath('.')):
        print(config)

if __name__ == '__main__':
    test_each_sub_command_config()

# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-11 22:46:00.885796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import unittest.mock
    import warnings

    class SetupCfgCommandTestCase(unittest.TestCase):
        def test_standard(self):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')