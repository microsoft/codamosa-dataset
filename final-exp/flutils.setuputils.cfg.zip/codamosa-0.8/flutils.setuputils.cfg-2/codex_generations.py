

# Generated at 2022-06-11 22:36:18.655760
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:28.188939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from inspect import cleandoc

    config_file = cleandoc(
        """
        [metadata]
        name = flutils-tests

        [setup.command.one]
        command =
            python setup.py one
            {home}/opt/bin/one

        [setup.command.two]
        commands =
            python setup.py two
            {home}/opt/bin/two

        [setup.command.three]
        commands =
            python setup.py three
            {home}/opt/bin/three

        [setup.command.four]
        command = python setup.py four
        name = flutils-test.four
        """
    )
    parser = ConfigParser()
    parser.read_file(StringIO(config_file))

# Generated at 2022-06-11 22:36:40.799341
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as dir_path:
        dir_path = Path(dir_path)
        py_file = dir_path / 'setup.py'

# Generated at 2022-06-11 22:36:53.123775
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if os.path.isdir('/setup/dir'):
        raise FileExistsError('Unexpected existence of /setup/dir')
    if os.path.isdir('./tests/fixtures/package-with-setup_commands.cfg'):
        raise FileExistsError(
            'Unexpected existence of ./tests/fixtures/package-with-setup_commands.cfg'
        )

    os.makedirs('/setup/dir/setup.py/with/dots/.')
    os.makedirs('/setup/dir/setup.cfg/without/dots/.')
    os.makedirs('./tests/fixtures/package-with-setup_commands.cfg/without/dots/.')

# Generated at 2022-06-11 22:37:06.289686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import Counter
    from itertools import groupby
    from flutils.testutils.fileutils import (
        TestCaseWithTemporaryDirectory,
    )

    class TestEachSubCommandConfig(TestCaseWithTemporaryDirectory):

        def test_no_setup_dir(self):
            with self.assertRaises(FileNotFoundError):
                list(each_sub_command_config(setup_dir=self.get_path('/')))

        def test_empty(self):
            self.write_file('setup.py')
            self.write_file('setup.cfg')
            out = list(each_sub_command_config(setup_dir=self.get_path()))
            self.assertEqual(len(out), 0)

        def test_one_command_name(self):
            self.write_file

# Generated at 2022-06-11 22:37:15.379264
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from collections import Counter
    from unittest import mock
    from pathlib import Path

    def _each_sub_command_config(
            setup_dir: Optional[Union[Path, str]] = None
    ) -> Generator[Tuple[str, str], None, None]:
        yield from (
            (config.name, config.camel)
            for config in each_sub_command_config(setup_dir)
        )

    def _validate_name(name: str) -> None:
        assert name.isidentifier() is True
        counter = Counter(name)
        assert 0 < len(counter) < len(name)
        assert counter['_'] == name.count('_')
        assert counter['-'] == name.count('-')


# Generated at 2022-06-11 22:37:27.297656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    def _create_fake_starting_directory() -> Tuple[str, str]:
        """Creates a temporary directory and writes a fake 'setup.py'
        file.
        """
        starting_dir = tempfile.mkdtemp()
        setup_py_path = os.path.join(starting_dir, 'setup.py')
        with open(setup_py_path, 'w') as fh:
            fh.write('#!python3\n')
            fh.write("import os\n")
            fh.write("from setuptools import setup, find_packages\n")
            fh.write("\n")
            fh.write("\n")
            fh.write("setup(\n")
            fh.write("    name='faux-package',\n")
           

# Generated at 2022-06-11 22:37:33.241434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(float.__file__)
    assert setup_dir.endswith('/test')
    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) == 1
    assert configs[0].camel == 'HelloWorld'
    assert configs[0].commands == (
        'echo "This is my project at %(setup_dir)s."',
        'echo "My home directory is at %(home)s."'
    )

# Generated at 2022-06-11 22:37:44.537549
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import io
    import configparser

    sys.path.insert(0, os.path.dirname(__file__))

    def func():
        return each_sub_command_config(setup_dir=os.path.dirname(__file__))

    def test_setup_cfg_ini(input):
        r = []
        parser = configparser.ConfigParser()

        buf = io.StringIO(input)
        parser.read_file(buf)

        for cmd in each_sub_command_config(setup_dir=None):
            r.append(cmd)
        return r

    def test_setup_commands_cfg_ini(input):
        r = []
        parser = configparser.ConfigParser()

        buf = io.StringIO(input)

# Generated at 2022-06-11 22:37:54.855986
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    import pkg_resources
    import tempfile

    pkg_info = pkg_resources.get_distribution('flutils')
    setup_dir = pkg_resources.resource_filename(
        'flutils',
        os.path.join(
            'tests',
            'data',
            'pyproject_setup'
        )
    )

    out = io.StringIO()
    err = io.StringIO()
    save_stdout = sys.stdout
    save_stderr = sys.stderr

# Generated at 2022-06-11 22:38:14.541754
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    module_dir = pathlib.Path(__file__).parent
    module_dir = str(module_dir)
    cfg_dir = os.path.join(module_dir, 'setup_commands')
    cfg_file = os.path.join(cfg_dir, 'setup_commands.cfg')

    os.environ['PYTHONPATH'] = ':'.join([
        os.environ.get('PYTHONPATH', ''),
        module_dir,
    ])
    py_path = os.environ['PYTHONPATH']

    with open(cfg_file) as f:
        for config in each_sub_command_config(cfg_dir):
            config = cast(
                SetupCfgCommandConfig, config
            )
            assert config.name == f.read

# Generated at 2022-06-11 22:38:16.955317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    yield from each_sub_command_config(setup_dir)

# Generated at 2022-06-11 22:38:19.538467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(list(each_sub_command_config()))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:29.660426
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from tests.conftest import SETUP_DIR


# Generated at 2022-06-11 22:38:38.517333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    import os
    import unittest
    import pprint
    import tempfile
    import shutil

    tdir = os.path.join(tempfile.gettempdir(), 'flutils-test')
    if os.path.exists(tdir) is False:
        os.mkdir(tdir)

    class Test(unittest.TestCase):
        def verify(self, cmd_name: str, expected: List[str]):
            if expected is None:
                with self.assertRaises(expected):
                    for command in each_sub_command_config():
                        pass
            else:
                actual = list(each_sub_command_config(os.path.join(tdir, cmd_name)))
                self.assertEqual(actual, expected)



# Generated at 2022-06-11 22:38:48.693036
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from formatcode.cli import formatcode_parser_init
    from formatcode.cli import get_default_formatcodes
    from formatcode.cli import print_formatcodes
    import argparse

    HOME = os.path.expanduser('~')
    parser = formatcode_parser_init(argparse.ArgumentParser())

    format_cmd = None
    for cmd in parser._subparsers._actions[1].choices.values():
        if cmd.dest == 'format':
            format_cmd = cmd
            break

    formatcodes = {}
    for c in each_sub_command_config():
        cmd_name = c.name
        cmd_desc = c.description
        if cmd_name in format_cmd.choices:
            cmd = format_cmd.choices[cmd_name]
            cmd.description = cmd_desc

# Generated at 2022-06-11 22:38:59.150006
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    assert gen
    assert isinstance(gen, Generator)
    assert hasattr(gen, '__next__')

    cmd = next(gen)
    assert cmd.name == 'tests'
    assert cmd.camel == 'Tests'
    assert cmd.description == 'Execute the tests.'
    assert cmd.commands == (
        'python setup.py test',
    )

    cmd = next(gen)
    assert cmd.name == 'docs.clean'
    assert cmd.camel == 'DocsClean'
    assert cmd.description == 'Clean the docs.'
    assert cmd.commands == (
        'rm -rf docs/html',
    )

    try:
        next(gen)
    except StopIteration:
        assert True

# Generated at 2022-06-11 22:39:04.414392
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    output = list(each_sub_command_config())
    print(output)
    # assert output == -
    #     [SetupCfgCommandConfig(name='test', camel='Test', description='', commands=('',))]


# Generated at 2022-06-11 22:39:08.670578
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Should find the 'setup.py' file in the current working directory
    assert sum(1 for _ in each_sub_command_config()) == 1

    # Should find the 'setup.py' file in the current directory
    assert sum(1 for _ in each_sub_command_config(os.getcwd())) == 1

# Generated at 2022-06-11 22:39:18.207078
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.pathutils

    basedir = os.path.dirname(__file__)
    basedir = flutils.pathutils.unwrap_relative(basedir)
    testdir = os.path.join(basedir, 'data')

    cmds = list(each_sub_command_config(testdir))
    assert len(cmds) == 1
    cmd = cmds[0]
    assert cmd.name == 'test.setupcfg.command'
    assert cmd.camel == 'TestSetupcfgCommand'
    assert cmd.description == 'This is just a **test**.'
    assert cmd.commands == ('echo Hello World!',)

# Generated at 2022-06-11 22:39:44.270781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        setup_dir = os.path.realpath(temp_dir)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                '[metadata]\n'
                'name = test_flutils\n'
                '\n'
                '[setup.command.test.case1]\n'
                'name = TEST NAME\n'
                'description = This is a test.\n'
                'command = echo "test"\n'
            )


# Generated at 2022-06-11 22:39:59.014353
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Validates that the each_sub_command_config function returns
    the expected output.
    """
    from json import dumps
    from pathlib import Path
    from flutils.pathutils import make_path

    file_name = make_path(__file__).parent.parent / 'setup_commands.cfg'
    setup_cfg_path = 'tests/data/setup_commands.cfg'

# Generated at 2022-06-11 22:40:10.250726
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        UnitTester,
        run_tests,
    )

    def _test_each_sub_command_config(
            name: str,
            expected: SetupCfgCommandConfig,
            setup_dir: Optional[str] = None
    ) -> None:
        actual = next(each_sub_command_config(setup_dir), None)
        assert actual == expected


# Generated at 2022-06-11 22:40:21.838235
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path

    from flutils.pathutils import ensure_dir_exists

    import tempfile

    with tempfile.TemporaryDirectory() as test_dir:
        src = Path(__file__).parent / 'test' / 'test_data' / 'configs'
        test_dir = Path(test_dir) / 'setup_commands.cfg'
        ensure_dir_exists(os.path.dirname(test_dir))
        src.copy(test_dir)
        test_dir = os.path.dirname(test_dir)

        assert 'setup_commands.cfg' in os.listdir(test_dir)
        for (
            name, camel, description, commands
        ) in each_sub_command_config(test_dir):
            assert name.startswith('test.')
           

# Generated at 2022-06-11 22:40:26.087349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils import setup_utils
    for sc in setup_utils.each_sub_command_config():
        print(sc)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:33.187380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), '..', '..', '..')

    configs = list(each_sub_command_config(path))
    assert len(configs)


if __name__ == '__main__':
    import sys
    from pprint import pprint

    if len(sys.argv) == 1:
        path = os.path.join(os.path.dirname(__file__), '..', '..', '..')
        pprint(list(each_sub_command_config(path)))
    else:
        pprint(list(each_sub_command_config(sys.argv[1])))

# Generated at 2022-06-11 22:40:39.693178
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    import sys

    ident = sys.modules[__name__].__package__
    ident = cast(str, ident)
    ident = ident.split('.')[0]
    setup_dir = os.path.realpath(os.path.join('..', ident))

    pprint(list(each_sub_command_config(setup_dir)))



# Generated at 2022-06-11 22:40:47.294777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from inspect import currentframe

    from flutils.pathutils import Path

    from pathlib_mate.pathlib2 import Path
    from pathlib_mate.pathlib2 import Path

    setup_dir = join(dirname(currentframe().f_code.co_filename), 'fixtures')
    for cfg in each_sub_command_config(setup_dir):
        print("cfg:", cfg)

    cfg = each_sub_command_config(setup_dir).next()
    print("cfg:", cfg)

    cfg = each_sub_command_config(Path(setup_dir)).next()
    print("cfg:", cfg)

# Generated at 2022-06-11 22:40:48.636258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-11 22:40:51.896346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert config.camel.startswith('SetupCmd') is True, config
        assert config.description is not None, config
        assert config.commands, config

# Generated at 2022-06-11 22:41:25.611011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    assert isinstance(each_sub_command_config(), Generator), \
        'should be a generator.'
    pprint(list(each_sub_command_config()))

# Generated at 2022-06-11 22:41:27.860652
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    items = list(each_sub_command_config(setup_dir='.'))
    assert all(isinstance(x, SetupCfgCommandConfig) for x in items)

# Generated at 2022-06-11 22:41:31.482992
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command_config in each_sub_command_config():
        print(command_config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:41:33.241683
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd_cfg in each_sub_command_config():
        print(repr(cmd_cfg))

# Generated at 2022-06-11 22:41:44.713770
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    from flutils.testutils import (
        test_equal,
        test_raise
    )

    import pytest

    # Test the _get_name() function
    test_equal(_get_name(ConfigParser(), 'setup.cfg'), 'setup')
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'setup.cfg')
        with open(path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = foo'
            )
        parser = ConfigParser()
        parser.read(path)
        test_equal(_get_name(parser, 'setup.cfg'), 'foo')

    # Test the _each_setup_cfg_command() function

# Generated at 2022-06-11 22:41:50.640434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    ):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:00.102149
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..', '..')
    cnt = 0
    for cfg in each_sub_command_config(setup_dir):
        cnt += 1
        assert cnt == 1
        assert cfg.name == 'build_sphinx'
        assert cfg.camel == 'BuildSphinx'
        assert cfg.description == ''
        assert cfg.commands[0] == 'sphinx-build doc build-sphinx'
        break
    assert cnt == 1



# Generated at 2022-06-11 22:42:11.287091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap
    setup_dir = tempfile.mkdtemp()
    setup_py_path = os.path.join(setup_dir, 'setup.py')
    with open(setup_py_path, 'w') as fh:
        fh.write(
            textwrap.dedent('''
                from setuptools import setup
                setup()
            ''')
        )
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    with open(setup_cfg_path, 'w') as fh:
        fh.write(
            textwrap.dedent('''
            [metadata]
            name = flutils
            ''')
        )

# Generated at 2022-06-11 22:42:19.539319
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:30.511739
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    def assert_cmds(
            expected_name: Optional[str],
            expected_commands: Optional[Tuple[str, ...]],
            cmd: SetupCfgCommandConfig
    ) -> None:
        """Assert that the given command matches the expected values."""
        if expected_name:
            assert expected_name == cmd.name
        if expected_commands:
            assert expected_commands == cmd.commands

    root_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    with pytest.raises(FileNotFoundError):
        next(each_sub_command_config(''))


# Generated at 2022-06-11 22:43:38.038941
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    configs = tuple(each_sub_command_config(setup_dir))
    assert len(configs) == 2

# Generated at 2022-06-11 22:43:45.994776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test 1
    import io
    import tempfile
    handle = io.StringIO()
    handle.write('''[metadata]
name = pypkg-cli


[setup.command.env]
commands = pyenv {env}

''')
    handle.seek(0)
    tmpdir = tempfile.mkdtemp()
    setup_cfg = os.path.join(tmpdir, 'setup.cfg')
    with open(setup_cfg, mode='wt', encoding='utf-8') as f:
        f.write(handle.read())

    out = list(each_sub_command_config(setup_dir=tmpdir))
    assert len(out) == 1

    actual = out[0]
    assert isinstance(actual, SetupCfgCommandConfig)
    assert actual.name == 'env'
   

# Generated at 2022-06-11 22:43:54.169294
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {
        'setup_dir': _prep_setup_dir(),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, path)
    out = list(_each_setup_cfg_command(parser, format_kwargs))

# Generated at 2022-06-11 22:44:03.329380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test_each_sub_command_config(
            name: str,
            setup_cfg_path: str,
            setup_cfg_contents: str,
            expected_name: str,
            expected_commands: Tuple[Tuple[SetupCfgCommandConfig, ...], ...]
    ):
        setup_dir = os.path.dirname(setup_cfg_path)
        with open(setup_cfg_path, 'w', encoding='utf-8') as fp:
            fp.write(setup_cfg_contents)
        try:
            out = tuple(each_sub_command_config(setup_dir))
            assert (name, out) == (name, expected_commands[0])
        finally:
            os.remove(setup_cfg_path)


# Generated at 2022-06-11 22:44:09.626205
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pprint

    pprint.pprint(
        list(
            each_sub_command_config(
                setup_dir=str(os.path.dirname(sys.argv[0]))
            )
        )
    )


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:21.015913
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile

    def make_config(
            sub_commands: List[str],
            **kwargs
    ) -> ConfigParser:
        config = ConfigParser()
        sub_commands = sorted(sub_commands)
        config.add_section('metadata')
        config.set('metadata', 'name', kwargs.get('name', 'test-pkg'))
        for command_info in sub_commands:
            section, name = command_info.split(':', 1)
            config.add_section(section)
            if section.startswith('setup.command.'):
                config.set(section, 'command', '{setup_dir}/{name}.sh')
            else:
                config.set(section, 'command', 'echo $HOME')
        return config


# Generated at 2022-06-11 22:44:28.776024
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import add_to_sys_path
    from flutils.testutils import UnitTestHelper
    from flutils.setuputils import PYPROJECT_TOML_ENTRY_POINTS_KEY

    def _call_function_under_test(*args, **kwargs):
        return tuple(each_sub_command_config(*args, **kwargs))


# Generated at 2022-06-11 22:44:40.764807
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .testing_utils import (
        with_temp_dir,
        with_temp_file,
    )
    from flutils.funcutils import raise_from

    def _do_test(
            expected: List[SetupCfgCommandConfig],
            *,
            setup_cfg: Union[os.PathLike, str],
            setup_commands_cfg: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        actual = []

# Generated at 2022-06-11 22:44:45.043409
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(
        '\n'.join(
            '%s: %s' % (x.name, x.camel)
            for x in each_sub_command_config(os.path.dirname(__file__))
        )
    )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:50.719270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    _setup_dir = os.path.dirname(os.path.dirname(__file__))

    _configs: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(setup_dir=_setup_dir)
    )
    _config0: SetupCfgCommandConfig = (
        _configs[0]
    )
    assert _config0.name == 'publish.test'
    assert _config0.camel == 'PublishTest'
    assert _config0.description == """
    Runs the tests for the project.
    """.strip()

    _cmds: Tuple[str, ...] = (
        _config0.commands
    )
    assert _cmds[0] == 'python -m pip install -e %(setup_dir)s[tests]'