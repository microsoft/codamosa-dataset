

# Generated at 2022-06-11 22:36:21.130902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        assert isinstance(cfg, SetupCfgCommandConfig)


if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-11 22:36:23.301635
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.expanduser('~/workspace/flutils')
    for setup_cfg_command_config in each_sub_command_config(path):
        pass

# Generated at 2022-06-11 22:36:34.062532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    flutils_dir = os.path.dirname(os.path.abspath(__file__))
    flutils_dir = os.path.dirname(flutils_dir)
    flutils_dir = os.path.dirname(flutils_dir)
    setup_dir = os.path.join(flutils_dir, 'tests', 'sample_project')

# Generated at 2022-06-11 22:36:42.004589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', '..', '..', '..', '..', '..', 'flutils'
        )
    )
    for cfg in each_sub_command_config(setup_dir):
        print(cfg)
    assert True is True


if __name__ == '__main__':
    raise SystemExit(test_each_sub_command_config())

# Generated at 2022-06-11 22:36:45.406613
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    list(each_sub_command_config())


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:54.884352
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfg = list(each_sub_command_config())
    assert cfg
    assert cfg[0].name == 'hello'
    assert cfg[0].camel == 'Hello'
    assert cfg[0].commands == ('echo "Hello World!"', )
    assert cfg[0].description == 'A Hello World example.'
    assert cfg[1].name == 'hello.aliens'
    assert cfg[1].camel == 'HelloAliens'
    assert cfg[1].commands == ('echo "Hello Aliens!"', )
    assert cfg[1].description == 'A Hello Aliens example.'
    assert cfg[2].name == 'hello.aliens.from.mars'
    assert cfg[2].camel == 'HelloAliensFromMars'

# Generated at 2022-06-11 22:37:07.596217
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock
    import sys
    import subprocess
    import tempfile


# Generated at 2022-06-11 22:37:15.854612
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:37:27.748607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if os.path.exists('/opt/flutils/_tests/each_sub_command_config/setup_commands.cfg'):  # pragma: no cover
        path = '/opt/flutils/_tests/each_sub_command_config/setup_commands.cfg'
        os.remove(path)
    out = os.path.exists('/opt/flutils/_tests/each_sub_command_config/setup_commands.cfg')
    assert out is False
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'each_sub_command_config')
    setup_dir = '/opt/flutils/_tests/each_sub_command_config'
    out = os.path.realpath(path)
    assert setup_dir == out

    out = os

# Generated at 2022-06-11 22:37:36.245670
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    import unittest
    import flutils.setup_utils

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            project_dir = os.path.dirname(flutils.setup_utils.__file__)
            setup_dir = os.path.join(project_dir, '..')
            configs = list(each_sub_command_config(setup_dir))
            self.assertIsInstance(configs, list)
            self.assertGreater(len(configs), 0)
            for config in configs:
                self.assertIsInstance(config, SetupCfgCommandConfig)

    sys.argv = [sys.argv[0]]
    sys.exit

# Generated at 2022-06-11 22:37:56.432145
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.objutils import (
        assert_obj_equal,
        obj_to_dict,
    )
    from flutils.pathutils import (
        fix_seps,
    )
    from flutils.testutils import (
        UnitTest,
        skip_reason,
    )
    from pathlib import Path

    class Test(UnitTest):
        def test_each_sub_command_config(self):
            """Test the function each_sub_command_config."""
            if self.is_travisci is True:
                self.skip_test(skip_reason('self.is_travisci'))  # pragma: no cover
            setup_dir = Path(__file__)
            setup_dir = Path(setup_dir.parent, 'test_project')

# Generated at 2022-06-11 22:38:06.725618
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 22:38:15.733686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(os.path.dirname(__file__))
    here += '/tests/config_files'
    setup_dir = os.path.realpath(os.path.join(here, 'setup.cfg'))

# Generated at 2022-06-11 22:38:27.532580
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'setup_dir')
    sub_command_cfgs = []
    for sub_command_cfg in each_sub_command_config(setup_dir):
        sub_command_cfgs.append(sub_command_cfg)

# Generated at 2022-06-11 22:38:32.074278
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config('/home/kirbyfan64/devel/flutils'):
        print(i)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:42.373131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.printutils import shprint
    for config in each_sub_command_config(
            '/Users/davea/Workspaces/PycharmProjects/django-pytest-template'):
        kwargs = {
            'name': config.name,
            'description': config.description,
            'commands': '\n'.join(config.commands)
        }
        shprint('{name}: {description}'.format(**kwargs))
        for command in config.commands:
            shprint(command)

# For testing in PyCharm
if __name__ == '__main__':
    test_each_sub_command_config()
    pass

# Generated at 2022-06-11 22:38:45.932832
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        assert cfg.name
        assert cfg.camel
        assert cfg.description
        assert cfg.commands

# Generated at 2022-06-11 22:38:52.982250
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('tests/data/setup_commands'))
    assert len(configs) == 1
    config = configs[0]
    assert config.name == 'nonsense-command'
    assert config.camel == 'NonsenseCommand'
    assert config.description == \
        'This is a nonsense sub-command.'
    assert config.commands == (
        'echo "This is a nonsense sub-command."'
        ' && exit 8',
        'echo "This is a nonsense sub-command, too."'
        ' && exit 8',
    )


__all__ = ('each_sub_command_config', 'test_each_sub_command_config')

# Generated at 2022-06-11 22:38:55.173423
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    pprint.pprint(list(each_sub_command_config()))

# Generated at 2022-06-11 22:39:05.496354
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.logutils import logit
    loglevel = logit.getEffectiveLevel()
    logit.setLevel('DEBUG')
    logit.debug("Starting test_each_sub_command_config...")

# Generated at 2022-06-11 22:39:40.795763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _do_test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for command in each_sub_command_config(setup_dir):
            print(command)
    _do_test_each_sub_command_config()
    import flutils.cliutils
    _do_test_each_sub_command_config(
        os.path.dirname(os.path.dirname(flutils.cliutils.__file__))
    )


if __name__ == '__main__':
    import sys
    test_each_sub_command_config()
    sys.exit(0)

# Generated at 2022-06-11 22:39:56.921357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat

    each_test_cmd_cfg = each_sub_command_config(
        './test/data/test_project/test_package'
    )

# Generated at 2022-06-11 22:40:03.526504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.debugutils import ipdb_break
    from . import __name__ as this_package_name

    sys.modules.pop(this_package_name, None)
    ipdb_break()
    import flscripts

    # noinspection PyPackageRequirements,PyUnresolvedReferences
    return tuple(flscripts.each_sub_command_config())



# Generated at 2022-06-11 22:40:08.207761
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test(setup_dir: Optional[Union[os.PathLike, str]] = None):
        for config in each_sub_command_config(setup_dir=setup_dir):
            print(config.name, config.commands)

    test()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:19.913342
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('../../setup/'))
    assert configs[0].name == 'build'
    assert configs[0].description == 'Build the package.'
    assert configs[0].commands == ('python3 setup.py sdist bdist_wheel',)

    assert configs[1].name == 'clean'
    assert configs[1].description == 'Remove Python file and build artifacts.'

# Generated at 2022-06-11 22:40:30.825903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )

    sub_cmds = list(each_sub_command_config(setup_dir))
    assert len(sub_cmds) == 1
    assert sub_cmds[0].name == 'setup.command.foo'
    assert sub_cmds[0].camel == 'SetupCommandFoo'
    assert sub_cmds[0].description == 'Test description'
    assert len(sub_cmds[0].commands) == 1
    assert sub_cmds[0].commands[0] == 'echo "Foo"'


# Generated at 2022-06-11 22:40:40.066569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(setup_dir: Optional[Union[os.PathLike, str]] = None) -> None:
        if setup_dir is None:
            setup_dir = os.path.dirname(
                os.path.dirname(
                    os.path.dirname(os.path.abspath(__file__))
                )
            )
        for x in each_sub_command_config(setup_dir):
            print(x)
        # assert False
    _test()



# Generated at 2022-06-11 22:40:46.505960
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), 'test_data')
    )
    assert test_dir
    configs = list(each_sub_command_config(test_dir))
    assert configs and isinstance(configs, list)
    assert len(configs) == 1
    config = configs[0]
    assert config
    assert isinstance(config, SetupCfgCommandConfig)
    assert config.name == 'my_package.my_command'
    assert config.camel == 'MyCommand'
    assert config.description == 'A sub-command for test purposes.'
    assert config.commands == (
        'echo "Testing MyCommand."',
        'echo "Testing MyCommand: 2."',
    )



# Generated at 2022-06-11 22:40:57.799188
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from sys import version

    def foo(setup_dir: Optional[Union[os.PathLike, str]] = None) -> None:
        print('=' * len(title_fmt))
        for config in each_sub_command_config(setup_dir=setup_dir):
            print(title_fmt.format(name=config.name))
            print(desc_fmt.format(description=config.description))
            for cmd in config.commands:
                print(cmd_fmt.format(command=cmd))
        print('=' * len(title_fmt))

    title_fmt = '=====[{name}]====='
    desc_fmt = '=====[{description}]====='
    cmd_fmt = '{command}'

    # ################################
    # no arguments

# Generated at 2022-06-11 22:41:07.894021
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(__file__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.join(path, 'setup.py')
    setups = list(each_sub_command_config(path))
    assert len(setups) == 3
    for idx, setup_cfg_config in enumerate(setups):
        assert setup_cfg_config.name == (
            'test', 'development', 'development.test'
        )[idx]
        commands = setup_cfg_config.commands
        assert len(commands) == 2
        assert commands[0] == 'python3 -m pytest'

# Generated at 2022-06-11 22:42:00.459919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import configparser
    import pathlib

    def _test():
        dir = os.path.dirname(__file__)
        dir = os.path.dirname(dir)
        dir = os.path.dirname(dir)
        dir = os.path.join(dir, 'src', 'tests', 'files')
        dir = pathlib.Path(dir)
        for config in each_sub_command_config(dir):
            yield config

    sys.modules['configparser'] = configparser
    out = tuple(_test())
    sys.modules.pop('configparser')

# Generated at 2022-06-11 22:42:11.480711
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .test_data import each_sub_command_config_test_data
    from unittest import TestCase
    from unittest.mock import patch
    from types import GeneratorType

    def _test_each_sub_command_config(test_data: Dict[str, str], tc: TestCase):
        result = each_sub_command_config(test_data['setup_dir'])
        tc.assertIsInstance(result, GeneratorType)
        result_list = list(result)
        tc.assertEqual(len(result_list), test_data['expected_num_results'])
        for item, expected in zip(result_list, test_data['expected_results']):
            tc.assertEqual(item.name, expected.name)

# Generated at 2022-06-11 22:42:24.742482
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest

    from flutils.files.filesystem import (
        FileSystem,
        make_path_safely,
    )

    from flutils.testutils import make_temp_directory

    class Test(unittest.TestCase):

        def test_args(self):
            with self.assertRaises(FileNotFoundError):
                next(each_sub_command_config())

            with make_temp_directory() as tmp:
                path1 = os.path.join(tmp, 'setup.py')
                with open(path1, 'w') as f:
                    f.write('spam')

                with self.assertRaises(FileNotFoundError):
                    next(each_sub_command_config(tmp))

                path2 = os.path.join(tmp, 'setup.cfg')

# Generated at 2022-06-11 22:42:33.229994
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils
    def get_value(key: str) -> str:
        for sc in flutils.setup_commands.each_sub_command_config():
            if sc.name == key:
                return sc.commands
        raise KeyError(key)

    # test if we are using the right setup commands config file
    assert get_value('test').startswith(
        'python -m pytest --cov-append --cov-config=.coveragerc '
        '--cov-report="term-missing:skip-covered"'
    )

    # test if the setup_dir value is correct
    root = os.path.dirname(os.path.dirname(flutils.__file__))
    assert get_value('test').endswith(root)

# Generated at 2022-06-11 22:42:44.569024
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config('tests/tmp/project'))
    assert len(configs) == 4
    assert configs[0].name == 'build-rpm'
    assert configs[0].camel == 'BuildRpm'
    assert configs[0].description == 'Builds RPMs of the distribution.'
    assert configs[0].commands == (
        'python setup.py --quiet bdist_rpm',
        'python setup.py --quiet bdist_rpm --dist-dir dist/'
    )
    assert configs[1].name == 'build-docs'
    assert configs[1].camel == 'BuildDocs'
    assert configs[1].description == 'Builds documentation for the project.'

# Generated at 2022-06-11 22:42:53.800356
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function ``each_sub_command_config``."""
    assert list(
        each_sub_command_config(
            'tests/test-data/conf-test/setup.cfg-test'
        )
    ) == [
        SetupCfgCommandConfig(
            'thd',
            'Thd',
            'Test help description.',
            ('echo "Test help description."',)
        ),
        SetupCfgCommandConfig(
            'tst',
            'Tst',
            'Test help description.',
            ('echo "Test help description."',)
        )
    ]

# Generated at 2022-06-11 22:42:56.336293
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config('/tmp/flutils'):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:43:07.660533
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    from unittest import mock
    from importlib import resources
    from pathlib import Path
    from dataclasses import dataclass
    from typing import Any, Callable

    from flutils.setuputils._setup_commands import (
        each_sub_command_config,
        _prep_setup_dir,
        _get_name,
        _each_setup_cfg_command,
    )

    class TestSetupUtilsSetupCommands(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.cmds: List[Tuple[str, Callable]] = []


# Generated at 2022-06-11 22:43:10.722438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    this_dir = os.path.abspath(os.path.dirname(__file__))
    out = list(each_sub_command_config(this_dir))
    out.clear()
    out = list(each_sub_command_config())
    assert out[0].name == 'zmq_pub_server'

# Generated at 2022-06-11 22:43:18.531023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import temporary_directory
    from flutils.testingutils.pytest import (
        assert_setup_cfg_command_configs,
        assert_setup_cfg_command_configs_have_same_data
    )
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = str(temp_dir)
        with open(os.path.join(temp_dir, 'setup.py'), 'w') as f:
            f.write('\n')
        with open(os.path.join(temp_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\nname = py.project\n')
        command_path = Path(temp_dir, 'setup_commands.cfg')
        text

# Generated at 2022-06-11 22:45:01.010268
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import cd, ProjectTestCase

    class TestEachSubCommandConfig(ProjectTestCase):
        def test_each_sub_command_config(self):
            with cd(self.src_dir()):
                called = False
                for config in each_sub_command_config():
                    called = True
                    self.assertEqual(
                        config,
                        SetupCfgCommandConfig(
                            'init', 'Init',
                            'Initialize the project\'s structure.',
                            (
                                'cd {home}',
                                'if [ ! -d "./.flutils" ]; then',
                                'mkdir ./.flutils',
                                'fi'
                            )
                        )
                    )
                self.assertTrue(called)

# Generated at 2022-06-11 22:45:08.885423
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    configs = list(each_sub_command_config(setup_dir))
    assert len(configs) == 1
    config = configs[0]
    assert config.name == 'new-project'
    assert config.camel == 'NewProject'
    assert config.description == 'Sets up new projects'
    assert config.commands == (
        'python3 -m flutils.new_project.new_project new-project',
    )


# The following code is for testing only.
# Do NOT use the following code for any other purpose.
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:11.466136
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _ = each_sub_command_config()


# Generated at 2022-06-11 22:45:22.209301
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    curr_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(curr_dir, '..', '..', '..', '..', 'flutils')
    configs = [x for x in each_sub_command_config(setup_dir)]
    assert all([isinstance(x, SetupCfgCommandConfig) for x in configs]) is True
    assert all(
        [
            isinstance(x.name, str) and
            isinstance(x.camel, str) and
            isinstance(x.description, str) and
            isinstance(x.commands, tuple) and
            all([isinstance(y, str) for y in x.commands])
            for x in configs
        ]
    ) is True



# Generated at 2022-06-11 22:45:34.796335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test 1 - basic function
    import os
    import sys
    import logging
    import tempfile
    from pathlib import Path
    from typing import Generator, NamedTuple
    from configparser import ConfigParser

    from flutils.setuputils import (
        each_sub_command_config,
    )

    tmpdir = tempfile.TemporaryDirectory()
    setup_dir = Path(tmpdir.name)
    setup_dir.joinpath('setup.py').write_text('')
    cmd_file = setup_dir.joinpath('setup_commands.cfg')
    parser = ConfigParser()
    parser.add_section('setup.command.init')
    parser.set('setup.command.init', 'command', 'echo "something"')
    parser.set('setup.command.init', 'name', 'init')
    parser

# Generated at 2022-06-11 22:45:48.087366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("Running unit test for function each_sub_command_config")

    print("Testing expected usage")
    setup_dir: Optional[Union[os.PathLike, str]] = None
    expected: Generator[SetupCfgCommandConfig, None, None] = each_sub_command_config(setup_dir)
    local_path: str = os.path.dirname(os.path.abspath(__file__))
    expected = next(expected)
    assert expected.name == 'subcommand'
    assert expected.camel == 'Subcommand'
    assert expected.description == 'A sub-command for flutils-util.'
    assert expected.commands == ('python setup.py subcommand',)

    print("Testing bad directory usage")
    setup_dir = os.path.join(local_path, 'bad_dir')

# Generated at 2022-06-11 22:45:57.272373
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config())
    config = next(iter(configs))
    assert isinstance(config.name, str)
    assert isinstance(config.camel, str)
    assert isinstance(config.description, str)
    assert isinstance(config.commands, tuple)
    assert isinstance(config.commands[0], str)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:46:04.715965
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test():
        for config in each_sub_command_config():
            print(config.name)
            print(config.commands)
            print(config.description)
            print(config.camel)
    try:
        _test()
    except Exception as err:
        import traceback
        print(traceback.format_exc())
        raise