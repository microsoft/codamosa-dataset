

# Generated at 2022-06-11 22:36:26.172406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def _each_config(
            *,
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for config in each_sub_command_config(setup_dir):
            yield config

    # NOTE: This should be the path to the 'setup.py' for the
    #       test_flutils package.  The test_flutils package is a
    #       dependency of this package and must be installed prior to
    #       running this unit test.
    setup_dir = os.path.realpath(
        '../../../../../../test_flutils/flutils/test_flutils'
    )

# Generated at 2022-06-11 22:36:38.281879
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = []
    for config in each_sub_command_config():
        out.append(config)

    path = os.path.realpath(__file__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    assert len(out) == 1
    assert out[0].name == 'install'
    assert out[0].camel == 'Install'
    assert out[0].description == 'Install the project'
    assert len(out[0].commands) == 4
    assert out[0].commands[0] == 'pip3 uninstall -y {}'.format(out[0].name)
    assert out[0].commands[1] == 'pip3 install -e {}'.format(path)

# Generated at 2022-06-11 22:36:50.168246
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap
    with tempfile.TemporaryDirectory() as td:
        td = os.path.join(td, 'fltutils')
        os.mkdir(td)
        with open(os.path.join(td, 'setup.py'), 'w') as fd:
            fd.write('def main(): pass\n')
        with open(os.path.join(td, 'setup.cfg'), 'w') as fd:
            fd.write(textwrap.dedent("""
                [metadata]
                name = flutils
            """))

# Generated at 2022-06-11 22:36:53.163288
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: Optional[str] = None
    for index, cmd_config in enumerate(each_sub_command_config(setup_dir)):
        pass
    assert (index > 2)



# Generated at 2022-06-11 22:37:03.301387
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.data.flutils_paths import flutils_paths
    setup_cfg_path = os.path.join(flutils_paths.test_data_dir,
                                  'test_setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs: Dict[str, str] = {
        'name': 'flutils'
    }
    for out in _each_setup_cfg_command(parser, format_kwargs):
        print(out)

# Generated at 2022-06-11 22:37:08.868944
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config('test/test_data/test_project_1'):
        name = cfg.name
        commands = cfg.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:16.460782
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            setup_dir: Union[os.PathLike, str],
            expected: List[str],
            *,
            func_module: str = 'flutils.setup_utils',
    ) -> None:
        func_name = 'each_sub_command_config'
        func = getattr(importlib.import_module(func_module), func_name)
        cmds = list(func(setup_dir))
        assert len(expected) == len(cmds)
        assert expected == [c.name for c in cmds]
        for cmd in cmds:
            assert func_module == cmd.module


# Generated at 2022-06-11 22:37:28.072083
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_dir = os.path.dirname(os.path.dirname(__file__))
    base_dir = os.path.join(base_dir, 'tests', 'data')
    base_dir = os.path.join(base_dir, 'sub_command_config')
    for i in range(4):
        sub_dir = os.path.join(base_dir, str(i))
        with pytest.raises(FileNotFoundError):
            each_sub_command_config(sub_dir)
    for i in range(4):
        sub_dir = os.path.join(base_dir, str(i))
        sub_dir = os.path.join(sub_dir, 'sub_dir')

# Generated at 2022-06-11 22:37:31.060508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def test_func():

        def test_func2():
            return each_sub_command_config()

        return test_func2()

    out = list(test_func())
    assert len(out) == 5

# Generated at 2022-06-11 22:37:34.700814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        name = item.name
        camel = item.camel
        description = item.description
        commands = item.commands
        print(name, camel, description, commands)


if __name__ == '__main__':
    import sys
    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-11 22:37:54.957147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from importlib import util
    from inspect import signature

    def _validate_func(func: object) -> bool:
        """Validates the given function, :data:`func`."""
        if func:
            if isinstance(func, object):
                if callable(func) is False:
                    return False
                if len(signature(func).parameters) == 0:
                    return False
            else:
                return False
        else:
            return False
        return True


# Generated at 2022-06-11 22:38:05.993996
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import os
    import sys
    import tempfile

    def _ex_setup_cfg(*a, **kw):
        raise FileNotFoundError(*a, **kw)

    def _ex_setup_dir(*a, **kw):
        raise FileNotFoundError(*a, **kw)

    dir_path = tempfile.mkdtemp()
    setup_path = os.path.join(dir_path, 'setup.py')
    setup_cfg_path = os.path.join(dir_path, 'setup.cfg')
    command_path = os.path.join(dir_path, 'setup_commands.cfg')


# Generated at 2022-06-11 22:38:15.434666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io

    import pytest

    # Capture the sys.stdout and sys.stderr output so that the function
    # under test does NOT write to stdout or stderr
    class CaptureSys(object):
        def __init__(self, out=None, err=None):
            self._out = out
            self._err = err

        def __enter__(self):
            self.old_stdout = sys.stdout
            self.old_stderr = sys.stderr
            self.old_stdout_fno = os.dup(sys.stdout.fileno())
            self.old_stderr_fno = os.dup(sys.stderr.fileno())
            sys.stdout = self._out or io.StringIO()

# Generated at 2022-06-11 22:38:27.312028
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.abspath(os.curdir)
    proj_dir = os.path.join(cwd, 'flutils')

# Generated at 2022-06-11 22:38:31.070726
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:37.329361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), 'testdata')
    path = os.path.realpath(path)
    for setup_dir in (None, path):
        for config in each_sub_command_config(setup_dir):
            print(repr(config))



# Generated at 2022-06-11 22:38:39.006976
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config():
        print(command)



# Generated at 2022-06-11 22:38:49.617420
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import json
    import os
    import sys
    import textwrap

    from flutils.pyutils import (
        get_caller_name,
        get_caller_path,
    )

    from flutils.strutils import (
        safe_eval,
    )

    from .utils import (
        make_tmp_dir,
    )

    # Test setup_dir
    with make_tmp_dir() as test_dir:
        assert os.path.isdir(test_dir) is True
        setup_dir = os.path.join(test_dir, 'Test', 'setup_dir')
        os.makedirs(setup_dir)
        setup_dir_py = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-11 22:38:59.559864
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pkgutils import get_install_path
    from flutils._testing import EACH_SUB_COMMAND_CONFIG_PATH

    format_kwargs: Dict[str, str] = {
        'setup_dir': get_install_path('flutils'),
        'home': os.path.expanduser('~')
    }
    SetupCfgCommandConfig(
        'build', 'Build',
        'Build everything needed to install',
        ('python setup.py build',)
    )
    SetupCfgCommandConfig(
        'clean', 'Clean',
        'Clean up the workspace',
        ('python setup.py clean',)
    )

# Generated at 2022-06-11 22:39:09.107516
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import sep
    from os.path import dirname
    setup_dir = dirname(dirname(dirname(__file__)))
    for cfg in each_sub_command_config(setup_dir):
        print(
            'name:', cfg.name,
            '\ncamel:', cfg.camel,
            '\ndescription:', cfg.description,
            '\ncommands:', cfg.commands,
            '\n', sep='\n    '
        )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:44.611807
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import contextlib
    from io import StringIO
    from tempfile import TemporaryDirectory

    def _each_setup_cfg_command_section(
            parser: ConfigParser
    ) -> Generator[Tuple[str, str], None, None]:
        for section in parser.sections():
            section = cast(str, section)
            section = section.strip()
            if section.startswith('setup.command.'):
                command_name = '.'.join(section.split('.')[2:])
                if command_name:
                    yield section, command_name


# Generated at 2022-06-11 22:39:47.217479
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)



# Generated at 2022-06-11 22:39:54.360354
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import temporary_directory

    with temporary_directory('path_source') as tmpdir:
        with open(os.path.join(tmpdir, 'setup.py'), 'w') as fh:
            fh.write('# Some setup.py code.')

        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as fh:
            fh.write('[metadata]\nname = path_source\n')


# Generated at 2022-06-11 22:40:00.455117
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils.pathutils import module_path

    setup_dir = os.path.abspath(os.path.join(module_path(), os.pardir))
    for config in each_sub_command_config(setup_dir):
        pprint(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:04.458069
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:12.489160
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from pprint import pprint
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_name = path.join(tmp_dir, 'setup_commands.cfg')
        with open(tmp_name, 'w') as tmp:
            tmp.write("""[metadata]
name = flutils

[setup.command.foo]
name = foo
description = Runs the foo command.
commands =
    echo 'Running the foo command.'

[setup.command.bar]
description = Runs the bar command.
commands =
    echo 'Running the bar command.'

[setup.command.baz]
name = baz
description = Runs the baz command.
command = echo 'Running the baz command.'
    """)

# Generated at 2022-06-11 22:40:16.873617
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    This unit test is NOT run automatically.

    $ flutils/codegen/setupcfg_cli.py
    """
    import sys

    for config in each_sub_command_config(sys.argv[1]):
        print(config)


# Generated at 2022-06-11 22:40:28.559384
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from unittest import TestCase
    from typing import List


# Generated at 2022-06-11 22:40:40.901936
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    mydir = os.path.dirname(__file__)
    mydir = os.path.abspath(mydir)
    mydir = os.path.join(mydir, '..', '..', 'flutils')
    mydir = os.path.normpath(mydir)
    mydir = os.path.realpath(mydir)


# Generated at 2022-06-11 22:40:49.076831
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import (
        abspath,
        expanduser,
        join,
        realpath,
    )
    sub_command_configs = list(each_sub_command_config())
    setup_dir = _prep_setup_dir()
    for config in sub_command_configs:
        assert config.name.format(name='flutils-testing') == 'testing'

# Generated at 2022-06-11 22:41:48.562357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest
    from flutils import setuptools_utils

    class EachSubCommandConfigTestCase(unittest.TestCase):
        """Tests for flutils.setuptools_utils.each_sub_command_config."""

        def test_no_setup_dir(self):
            """Test with no 'setup_dir' arg."""
            pwd = os.getcwd()

# Generated at 2022-06-11 22:41:56.004619
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    these = os.path.abspath(__file__)
    this = os.path.dirname(these)
    here = os.path.dirname(this)
    setup_py = os.path.join(here, 'setup.py')
    with tempfile.TemporaryDirectory() as td:
        td = os.path.realpath(td)
        with open(os.path.join(td, 'setup.py'), 'w') as fp:
            fp.write(
                '#!/usr/bin/env python\n'
                '"""An auto-generated setup.py script."""\n'
                'from flutils.setuputils import setup, each_sub_command_config\n'
                'setup(each_sub_command_config())\n')

# Generated at 2022-06-11 22:42:01.138919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(path, '..', '..')
    commands = cast(
        Generator[SetupCfgCommandConfig, None, None],
        each_sub_command_config(path)
    )
    configs = list(commands)
    assert configs
    assert configs[0].name == 'bump-ver'
    assert configs[-1].name == 'run'
    assert configs[0].camel == 'BumpVer'
    assert configs[-1].camel == 'Run'
    assert configs[0].description == 'Bumps the local project version.'
    assert configs[-1].description == 'Runs the given command in a virtualenv.'

# Generated at 2022-06-11 22:42:09.227172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.dotdict import DotDict

    for command in each_sub_command_config(setup_dir='/tmp'):
        out = DotDict(
            name=command.name,
            camel=command.camel,
            description=command.description,
            commands=command.commands
        )
        print()
        print(out)
        assert out.name
        assert out.camel
        assert out.description
        assert out.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:17.171147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import sys
    import os.path
    import logging
    import traceback
    from typing import Generator

    def _test(func: callable, expected_iter_count: int) -> None:
        try:
            iter_count = 0
            for _ in func():
                iter_count += 1
            assert iter_count == expected_iter_count, (
                "The function, %r, does NOT yield the expected number of items "
                "of %d, instead found %d." % (func.__name__, expected_iter_count, iter_count)
            )
        except Exception:
            logging.error(
                "An exception was raised while calling the function, %r.\n%s",
                func.__name__,
                traceback.format_exc()
            )
            raise

    _validate

# Generated at 2022-06-11 22:42:24.696026
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from unittest import mock
    from flutils.parsers.setup_cfg import each_sub_command_config

    setup_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__),
                     '../../../tests/assets/setup_cfg_basic')
    )
    print('setup_path:', setup_path)

    assert len(list(each_sub_command_config(setup_path))) == 4

# Generated at 2022-06-11 22:42:33.478473
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # noqa: N802
    import inspect
    import sys
    import textwrap
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch

    class TestCase(TestCase):
        def setUp(self):
            self.setup_dir = TemporaryDirectory()

        def tearDown(self):
            self.setup_dir.cleanup()

        def _write_to_setup_cfg(self, setup_cfg_contents: str) -> str:
            setup_cfg_path = os.path.join(self.setup_dir.name, 'setup.cfg')
            with open(setup_cfg_path, 'w') as out:
                out.write(setup_cfg_contents)
            return setup_cfg_path


# Generated at 2022-06-11 22:42:41.479444
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    root = pathlib.Path(__file__).parent.parent.parent
    setup_dir = root.joinpath('tests', 'fixtures', 'setup_cfg_project')
    out = list(each_sub_command_config(setup_dir))
    assert len(out) == 1
    assert out[0].name == 'the_name'
    assert out[0].camel == 'TheName'
    assert out[0].description == 'The description.'
    assert out[0].commands == ('command', 'commands')

# Generated at 2022-06-11 22:42:46.094102
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(__file__):
        print(config.name)
        for command in config.commands:
            print('\t', command, sep='')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:51.023969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert tuple(
        each_sub_command_config(setup_dir=__file__)
    ) == (
        SetupCfgCommandConfig(
            'name', 'Name', '', ()
        ),
    )

# Generated at 2022-06-11 22:44:26.284744
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config(os.path.dirname(__file__)):
        print(i)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:38.266085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pytest

    if sys.version_info > (3, 6):
        path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'setup_py_template.py'
        )

        cfg = list(each_sub_command_config(os.path.dirname(path)))
        assert len(cfg) == 1

        cfg = cfg[0]
        assert cfg.name == 'sub_command_name'
        assert cfg.camel == 'SubCommandName'
        assert cfg.description == 'SUB-COMMAND DESCRIPTION.'
        assert cfg.commands == ('sub-command-name', )


# Generated at 2022-06-11 22:44:44.360423
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test(setup_dir: str):
        commands = list(each_sub_command_config(setup_dir))
        assert len(commands) > 0
        assert all(isinstance(x, SetupCfgCommandConfig) for x in commands)

    test(os.path.dirname(__file__))
    test(os.path.dirname(__file__) + '../../../..')


if __name__ == '__main__':
    test_each_sub_command_config()

# EOF

# Generated at 2022-06-11 22:44:49.688105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from textwrap import dedent

    with open('setup_commands.cfg', 'w') as f:
        f.write(
            dedent(
                """\
                [setup.command.foo]
                commands =
                    do_foo -v
                """
            )
        )


# Generated at 2022-06-11 22:44:56.459086
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(
        os.path.dirname(__file__),
        'test_project',
    )
    for config in each_sub_command_config(path):
        assert config.name != ''
        assert config.camel != ''
        assert config.description != ''
        assert len(config.commands) > 0

# Generated at 2022-06-11 22:44:58.268925
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result = list(each_sub_command_config())
    assert len(result) == 0



# Generated at 2022-06-11 22:45:01.788686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    kwargs = dict(setup_dir=os.path.realpath('../../'))
    config = list(each_sub_command_config(**kwargs))
    assert len(config) == 12

# Generated at 2022-06-11 22:45:12.317728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import os
    import shutil
    import toml
    import pathlib

    cfg_content = """
[metadata]
name = 'test_project'

[setup.command.sdist]
name = 'sdist'
commands = """
    cfg_content += '''
        echo sdist
        python setup.py <sdist>
'''

    cfg_content += """
[setup.command.init]
name = 'init'
commands = """
    cfg_content += '''
        echo init
        python setup.py <init>
'''

    cfg_content += """
[setup.command.install]
name = 'install'
commands = """
    cfg_content += '''
        echo install
        python setup.py <install>
'''

    cf

# Generated at 2022-06-11 22:45:22.886438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import Generator
    from os.path import exists, join

    from flutils.pathutils import mkdtemp_tmpdir
    from flutils.iosys import save_as_file

    def _tst_each_sub_command_config(
            setup_cfg: Union[str, bytes, int, bool],
            setup_commands_cfg: Optional[Union[str, bytes, int, bool]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        with mkdtemp_tmpdir() as td:
            setup_cfg_path = join(td, 'setup.cfg')
            setup_commands_cfg_path = join(td, 'setup_commands.cfg')
            save_as_file(setup_cfg, setup_cfg_path)

# Generated at 2022-06-11 22:45:28.932836
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = [config for config in each_sub_command_config()]
    assert configs
    cmds = [c.name for c in configs]