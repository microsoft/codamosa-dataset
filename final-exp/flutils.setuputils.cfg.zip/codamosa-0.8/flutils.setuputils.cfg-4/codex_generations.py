

# Generated at 2022-06-11 22:36:26.885139
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import sys


# Generated at 2022-06-11 22:36:31.019918
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    for out in each_sub_command_config():
        pprint(out)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:33.788984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
    except FileNotFoundError:
        pass
    except Exception as e:
        raise e



# Generated at 2022-06-11 22:36:38.664903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        assert sub_command.name and sub_command.camel
        assert sub_command.description
        assert sub_command.commands
    each_sub_command_config('flutils')  # This should NOT raise an error



# Generated at 2022-06-11 22:36:50.585366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from unittest.mock import MagicMock, patch


# Generated at 2022-06-11 22:36:55.875050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    for cfg in each_sub_command_config(here):
        assert isinstance(cfg, SetupCfgCommandConfig)
        print(cfg)
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)
        assert isinstance(cfg.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:04.590300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    here = pathlib.Path(__file__).parent.resolve()
    out = list(each_sub_command_config(str(here)))
    assert len(out) == 1
    assert out[0].name == 'my-package-name'
    assert out[0].camel == 'MyPackageName'
    assert isinstance(out[0].description, str)
    assert len(out[0].commands) == 1
    assert out[0].commands[0].startswith('echo')

# Generated at 2022-06-11 22:37:10.546475
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .tests import PROJECT_ROOT

    for config in each_sub_command_config(PROJECT_ROOT):
        print('config:', config)
        for attr in ('name', 'camel', 'description', 'commands'):
            print('    %r: %r' % (attr, getattr(config, attr)))

# Generated at 2022-06-11 22:37:23.735607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import Mock, patch

    setup_dir = './setup_dir'
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    setup_cfg_commands_path = os.path.join(setup_dir, 'setup_commands.cfg')

    parser1 = Mock()
    parser1.sections.return_value = [
        'metadata',
        'setup.commands.foo',
        'setup.commands.bar'
    ]
    parser1.options.side_effect = lambda section: {
        'metadata': ['name'],
        'setup.commands.foo': [],
        'setup.commands.bar': ['name', 'description', 'command']
    }[section]

# Generated at 2022-06-11 22:37:30.410800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.scripts.setup import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    for config in each_sub_command_config('.'):
        assert isinstance(config, SetupCfgCommandConfig)

__all__ = (
    'each_sub_command_config',
    'SetupCfgCommandConfig',
    'test_each_sub_command_config',
)

# Generated at 2022-06-11 22:37:53.272242
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        config_attr_to_dict,
        config_to_dict,
    )
    from pprint import pformat
    from functools import partial

    for scc in each_sub_command_config():
        scc = cast(SetupCfgCommandConfig, scc)

# Generated at 2022-06-11 22:38:04.793308
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'testpkg'))
        with open(os.path.join(tmpdir, 'testpkg/setup.py'), 'w') as fd:
            fd.write('pass\n')
        with open(os.path.join(tmpdir, 'testpkg/setup.cfg'), 'w') as fd:
            fd.write('[metadata]\n')
            fd.write('name = testpkg\n')

        with open(os.path.join(tmpdir, 'testpkg/setup_commands.cfg'), 'w') as fd:
            fd.write('[setup.command.test]\n')

# Generated at 2022-06-11 22:38:14.672607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Tests bad args
    with pytest.raises(FileNotFoundError):
        for _ in each_sub_command_config('dir/missing'):
            pass
    with pytest.raises(NotADirectoryError):
        for _ in each_sub_command_config('test/test_setup_cfg.py'):
            pass
    with pytest.raises(FileNotFoundError):
        for _ in each_sub_command_config('test/dir_with_setup_cfg'):
            pass
    with pytest.raises(FileNotFoundError):
        for _ in each_sub_command_config('test/dir_with_setup'):
            pass

    # Tests good args

# Generated at 2022-06-11 22:38:17.857556
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    sys.path.append('tests')
    import test_each_sub_command_config
    assert(test_each_sub_command_config.test_each_sub_command_config())

# Generated at 2022-06-11 22:38:29.297623
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    from .envutils import _create_file

    with TemporaryDirectory() as temp_dir:
        temp_dir = str(temp_dir)
        setup_cfg = os.path.join(temp_dir, 'setup.cfg')
        setup_commands_cfg = os.path.join(temp_dir, 'setup_commands.cfg')
        setup_py = os.path.join(temp_dir, 'setup.py')


# Generated at 2022-06-11 22:38:31.913890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config(__file__), None) is not None

# Generated at 2022-06-11 22:38:43.647368
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfg = next(each_sub_command_config())
    assert cfg.name == 'check'
    assert cfg.camel == 'Check'
    assert cfg.description.startswith('Perform pre-push checks')
    assert len(cfg.commands) >= 2
    assert cfg.commands[0].strip().startswith('poetry run')
    assert cfg.commands[1].strip().startswith('poetry run')


if __name__ == '__main__':
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def test_each_sub_command_config(self):
            cfg = next(each_sub_command_config())
            self.assertEqual(cfg.name, 'check')
            self.assertE

# Generated at 2022-06-11 22:38:45.399354
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert isinstance(out, list)

# Generated at 2022-06-11 22:38:47.397288
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    pprint(list(each_sub_command_config()))

# Generated at 2022-06-11 22:38:55.358954
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from os import getcwd
    from sys import path
    path.append(Path(getcwd()).parent)

    def _test_each_sub_command_config(
        setup_dir: Optional[str] = None
    ) -> None:
        for config in each_sub_command_config(setup_dir):
            print(config)

    _test_each_sub_command_config()
    _test_each_sub_command_config('dummypkg/')

# Generated at 2022-06-11 22:39:28.728223
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    fullpath = os.path.realpath(__file__)
    dirname = os.path.dirname(fullpath)
    dirparent = os.path.dirname(dirname)


# Generated at 2022-06-11 22:39:42.996185
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def myfmt(cfg: SetupCfgCommandConfig):
        return '%s\n  %s' % (cfg.camel, '\n  '.join(cfg.commands))
    output = '\n\n'.join(
        myfmt(cfg) for cfg in each_sub_command_config(setup_dir='test_data')
    )

# Generated at 2022-06-11 22:39:56.052407
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), os.path.pardir))
    assert os.path.isfile(setup_dir) is False
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py')) is True
    assert os.path.isdir(setup_dir) is True
    yield from each_sub_command_config(setup_dir)


if __name__ == '__main__':
    import sys
    for config in each_sub_command_config(sys.argv[1]):
        print(config)

# Generated at 2022-06-11 22:40:07.995278
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #pylint: disable=too-many-locals
    import sys
    import unittest.mock

    class MockGcis(object):
        """Mock class for the :attr:`gcis` module.
        """

        class Config(object):
            """Mock class for the :class:`gcis.config` class.
            """

            @classmethod
            def write(cls, *_args, **_kwargs):
                """No-op"""

        def __getattr__(self, _attr):
            """No-op"""

    sys.modules['gcis'] = MockGcis
    sys.modules['gcis.config'] = MockGcis.Config


# Generated at 2022-06-11 22:40:13.818352
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert os.path.basename(__file__) == 'setup_cfg_utils.py'
    d = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', '..')
    )
    for cfg in each_sub_command_config(setup_dir=d):
        assert isinstance(cfg, SetupCfgCommandConfig)
        assert cfg.name

# Generated at 2022-06-11 22:40:26.587960
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Fake setup configuration
    setup_cfg = """\
[metadata]
name = project-name

[setup.command.sub1.sub2]
description = This is sub command sub1.sub2
commands = cmd1

[setup.command.sub1.sub3]
description = This is sub command sub1.sub3
commands =
cmd2
"""
    with tempfile.TemporaryDirectory() as tmp_dir:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg)


# Generated at 2022-06-11 22:40:33.932861
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cur_dir = os.path.dirname(__file__)
    proj_dir = os.path.abspath(os.path.join(cur_dir, os.pardir))
    flutils_setup_dir = os.path.join(proj_dir, 'flutils')

    for setup_cfg_command in each_sub_command_config(flutils_setup_dir):
        assert setup_cfg_command, type(setup_cfg_command)
        assert isinstance(setup_cfg_command.name, str)
        assert isinstance(setup_cfg_command.camel, str)
        assert isinstance(setup_cfg_command.description, str)
        for cmd in setup_cfg_command.commands:
            assert isinstance(cmd, str)



# Generated at 2022-06-11 22:40:38.262473
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for klass in each_sub_command_config(
        setup_dir=os.path.expanduser('~/git/flutils')
    ):
        print(klass)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:44.275291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'data', 'setup_commands.cfg')
    setup_dir = os.path.dirname(path)

    lst = list(each_sub_command_config(setup_dir))
    assert lst


if __name__ == '__main__':
    import sys
    for item in each_sub_command_config():
        print(item, file=sys.stderr)
    sys.exit(0)

# Generated at 2022-06-11 22:40:56.664864
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:41:56.839455
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cfgs = list(each_sub_command_config(os.path.join(os.path.dirname(__file__), '..')))
    assert len(cfgs) == 2
    cfg = cfgs[0]
    assert cfg.name == 'build'
    assert cfg.camel == 'Build'
    assert cfg.description == "Builds the project."
    assert cfg.commands == ('python setup.py sdist bdist_wheel',)
    cfg = cfgs[1]
    assert cfg.name == 'pkg'
    assert cfg.camel == 'Pkg'
    assert cfg.description == "Builds and publishes the package."
    assert cfg.commands == ('python setup.py sdist bdist_wheel', 'twine upload dist/*')

# Generated at 2022-06-11 22:42:08.450665
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        UnitTest,
        run_with_coverage,
    )
    from tempfile import (
        TemporaryDirectory,
    )

    class TestEachSubCommandConfig(UnitTest):
        def test_simple(self):
            with TemporaryDirectory() as td:
                setup_path = os.path.join(td, 'setup.py')

# Generated at 2022-06-11 22:42:16.738191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    from flutils.pathutils import each_directory
    from unittest.mock import mock_open, patch
    from shutil import rmtree
    from os import path
    from typing import Iterable

    def _fileobj_from_mockfile(
            mock_file,
            mock_file_name: str = '<mock-file>',
            **kwargs
    ) -> Iterable[str]:
        mock_file_name = mock_file_name.format(**kwargs)
        mock_file.name = mock_file_name
        return mock_file

    def _test_setup_dir(tmpdir: str, **kwargs) -> str:
        setup_dir = str(tmpdir)

# Generated at 2022-06-11 22:42:28.585413
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from tempfile import mkdtemp

    def check(config: SetupCfgCommandConfig):
        os.system(
            ' '.join([
                'cd',
                config.setup_dir,
                '&&',
                'python -m flutils.setupcommands --help',
                '|',
                'grep',
                '"%s - %s"' % (config.name, config.description),
                '|',
                'wc -l'
            ])
        )

    def check_test(config: SetupCfgCommandConfig):
        cmds = [
            'cd %s' % config.setup_dir,
            '&&',
            'python -m flutils.setupcommands %s' % config.name,
        ]
        os.system(' '.join(cmds))

    # Temp

# Generated at 2022-06-11 22:42:36.734787
# Unit test for function each_sub_command_config

# Generated at 2022-06-11 22:42:39.238362
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    pprint(tuple(each_sub_command_config()))

# Generated at 2022-06-11 22:42:41.166572
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        print(sub_command_config)

# Generated at 2022-06-11 22:42:53.230768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import dirname, join
    from tempfile import mkdtemp
    from flutils.configutils import create_setup_cfg
    from flutils.io import read_file

    temp_dir = mkdtemp()
    sub_dir = join(temp_dir, 'tmp')
    makedirs(sub_dir)
    create_setup_cfg(None, sub_dir)
    create_setup_cfg(None, sub_dir, 'setup_commands.cfg')

    commands = list(each_sub_command_config(sub_dir))
    assert len(commands) == 1
    assert commands[0].name == 'tmp'


# Generated at 2022-06-11 22:42:59.778438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import (
        Dict,
    )
    from tempfile import mkdtemp
    from shutil import (
        rmtree,
    )
    import os

    _s = '''
[metadata]
name = name_var

[setup.command.name_var.snake-case]
description = "This is a description."
command = "echo {name}"

[setup.command.name_var.CamelCase]
name = camel-case
commands =
    echo {name}
    echo {setup_dir}
    echo {home}
'''

    cfg_file_name = 'setup.cfg'
    cfg_file_path = os.path.join(mkdtemp(), cfg_file_name)


# Generated at 2022-06-11 22:43:08.850979
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import os.path
    import tempfile

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-11 22:44:51.294699
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    import sys
    import unittest
    import unittest.mock

    class EachSubCommandConfigUnitTests(unittest.TestCase):
        @unittest.mock.patch(
            'os.path.isfile',
            unittest.mock.Mock(return_value=False)
        )
        def test_no_setup_commands_cfg(self):
            out = list(each_sub_command_config())
            self.assertEqual(len(out), 0)


# Generated at 2022-06-11 22:44:59.358638
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from sys import stdout
    from tests import test_root_dir
    path = os.path.join(test_root_dir, 'setup_commands.cfg')
    for config in each_sub_command_config(test_root_dir):
        print(
            config.name,
            config.camel,
            config.description,
            config.commands,
            sep='\n',
            file=stdout
        )


__all__ = ('SetupCfgCommandConfig', 'each_sub_command_config',)

# Generated at 2022-06-11 22:45:08.837427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.getcwd()
    path = os.path.join(os.path.dirname(__file__), '..')
    os.chdir(path)
    setup_dir = os.path.dirname(__file__)
    with open(os.path.join(setup_dir, 'setup_commands.cfg'), 'w') as cfg:
        cfg.write("""[setup.command.mysub1]
name=mysub1
command=echo "mysub1"

[setup.command.mysub2]
name=mysub2
command=echo "mysub2"
""")
    print(path)
    for cfg in each_sub_command_config(setup_dir):
        print(cfg)

# Generated at 2022-06-11 22:45:21.251740
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            try:
                path = os.path.dirname(__file__)
                path = os.path.join(path, 'test_files')
                self.test_files_dir = path
            except NameError:
                self.test_files_dir = os.getcwd()

        def test_minimal(self):
            """Tests the minimal 'setup.cfg' file.
            This test is for the 'sdist' and 'wheel' sub-commands.
            """
            sys.stderr.write(
                "Testing the minimal 'setup.cfg' file.\n"
            )

            setup_dir

# Generated at 2022-06-11 22:45:32.381051
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    proj_dir = os.path.dirname(os.path.abspath(__file__))
    proj_dir = os.path.dirname(proj_dir)
    proj_dir = os.path.dirname(proj_dir)
    proj_dir = os.path.dirname(proj_dir)
    print(proj_dir)
    for sub_command in each_sub_command_config(setup_dir=proj_dir):
        print(sub_command)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:37.698834
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dp = os.path.dirname
    package_dir = dp(dp(dp(__file__)))
    setup_dir = os.path.join(package_dir, '..')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-11 22:45:49.300628
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io

    from flutils.testutils import (
        copy_test_files_to_test_dir,
        remove_test_files_from_test_dir
    )

    with io.StringIO() as stream:
        template_files, auto_files = copy_test_files_to_test_dir(stream)
        try:
            config = next(each_sub_command_config())
        except FileNotFoundError as err:
            stream.write(str(err) + '\n')
            raise
        else:
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
        finally:
            remove

# Generated at 2022-06-11 22:46:00.983698
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.abspath(os.path.dirname(__file__))
    setup_dir = os.path.abspath(os.path.join(this_dir, '..', '..'))
    for scc in each_sub_command_config(setup_dir):
        assert scc.name
        assert scc.camel
        assert scc.description
        assert scc.commands
        assert isinstance(scc.commands, tuple)

    for scc in each_sub_command_config():
        assert scc.name
        assert scc.camel
        assert scc.description
        assert scc.commands
        assert isinstance(scc.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()