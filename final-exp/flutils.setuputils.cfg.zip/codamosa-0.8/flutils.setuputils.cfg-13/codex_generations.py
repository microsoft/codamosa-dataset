

# Generated at 2022-06-11 22:36:26.352198
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fldateutils import (
        now_micros,
        now_millis,
        now_secs,
        utcnow_millis,
    )

    for config in each_sub_command_config():
        if config.name == 'get.now':
            print('get.now')
            print(config)
            print(now_millis())
            print(now_secs())
            print(now_micros())
            print(utcnow_millis())
            assert True
            break
        else:
            assert False
    else:
        assert False


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:30.788789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    import sys
    import pathlib

    root = pathlib.Path(__file__).parent.parent.parent
    sys.path.insert(0, str(root))
    import flutils

    pprint(list(flutils.each_sub_command_config()))

# Generated at 2022-06-11 22:36:37.459842
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    expected_output: List[SetupCfgCommandConfig] = []
    output: List[SetupCfgCommandConfig] = []
    for item in each_sub_command_config('example_project'):
        output.append(item)
    if output != expected_output:
        raise Exception(output)

# Generated at 2022-06-11 22:36:49.303417
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = {}
    for cfg in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), '../data')
    ):
        out[cfg.name] = cfg
    assert out['sys.exit'].camel == 'SysExit'
    assert out['sys.exit'].description == ''
    assert out['sys.exit'].commands == ('exit 0',)
    assert out['selftest'].camel == 'SelfTest'
    assert (
        out['selftest'].description ==
        "Run the self tests for the project. The self tests will be "
        "run in a virtual environment."
    )

# Generated at 2022-06-11 22:36:57.097705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_file = os.path.abspath(__file__)
    this_dir = os.path.dirname(this_file)
    setup_commands_cfg_file = os.path.join(this_dir, 'setup_commands.cfg')

    for sub_command in each_sub_command_config(setup_dir=this_dir):
        assert sub_command.name, "Each sub command must have a name."
        assert (
            cast(str, sub_command.name) in
            f"{os.path.basename(setup_commands_cfg_file)}:[run_tests]"
        ), "Each sub command name must be in the setup_commands.cfg file."
        assert sub_command.camel, "Each sub command must have a camel name."

# Generated at 2022-06-11 22:37:08.049449
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.testutils import TempDir

    def _assert(expected, actual):
        assert expected == actual, \
            '\nExpected:\n{}\nActual:\n{}'.format(expected, actual)
    with TempDir(prefix='flutils_') as tmp_path:
        tmp_path = str(tmp_path)
        sys.path.insert(0, tmp_path)
        setup_path = os.path.join(tmp_path, 'setup.py')
        with open(setup_path, 'w') as fh:
            fh.write(
                '\n'.join((
                    'import setuptools',
                    'if __name__ == "__main__":',
                    '    setuptools.setup()',
                ))
            )

# Generated at 2022-06-11 22:37:10.586246
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd_list = list(each_sub_command_config())
    assert isinstance(cmd_list, list)
    assert all(isinstance(x, SetupCfgCommandConfig) for x in cmd_list)

# Generated at 2022-06-11 22:37:16.852347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for fs in each_sub_command_config('./sample_pkg'):
        assert fs.name
        assert fs.camel
        assert fs.description
        assert fs.commands

# Run tests
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:28.342183
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: This doesn't test `_each_setup_cfg_command` only `each_sub_command_config`
    import tempfile
    from unittest.mock import patch

    with patch('{}.os.path.expanduser'.format(__name__)) as mock_expanduser:
        mock_expanduser.return_value = '/home/user'
        with tempfile.TemporaryDirectory() as setup_cfg_dir:
            base_setup_cfg_path = os.path.join(setup_cfg_dir, 'setup.cfg')
            setup_cfg_path = os.path.join(setup_cfg_dir, 'setup_sub_commands.cfg')
            setup_py_path = os.path.join(setup_cfg_dir, 'setup.py')


# Generated at 2022-06-11 22:37:32.101982
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from sys import path

    setup_dir = os.path.dirname(path[0])
    config: SetupCfgCommandConfig
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:54.649833
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        setuppy = os.path.join(tmp, 'setup.py')
        setupcfg = os.path.join(tmp, 'setup.cfg')
        with open(setuppy, 'w') as f:
            f.write('#!/usr/bin/env python\n')
            f.write('from setuptools import setup\n')
            f.write('setup()\n')
        with open(setupcfg, 'w') as f:
            f.write(
                """[metadata]
name = test_pkg
"""
            )

# Generated at 2022-06-11 22:37:57.646490
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config()."""
    for _config in each_sub_command_config():
        assert _config is not None

# Generated at 2022-06-11 22:38:02.312821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    setup_dir = os.path.join(os.path.dirname(__file__), '..')

    each_sub_command_config(setup_dir)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:13.019909
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the ``each_sub_command_config`` function."""
    import flutils.setuputils.base
    package_dir = os.path.dirname(flutils.setuputils.base.__file__)
    package_dir = os.path.join(package_dir, '..', '..', '..')
    count = 0
    for value in each_sub_command_config(setup_dir=package_dir):
        assert isinstance(value, SetupCfgCommandConfig)
        assert value.name
        assert value.camel
        assert value.description
        assert value.commands
        count += 1
    assert count > 0, 'No sub-commands found.'



# Generated at 2022-06-11 22:38:25.245547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import redirect_stderr
    from io import StringIO
    from pathlib import Path
    from unittest.mock import patch

    from pytest import raises

    mock_home = Path('/Users/username')
    mock_setup_dir = mock_home / 'project'
    mock_setup_dir.mkdir(parents=True)
    # Create the fake setup.py file
    with open(str(mock_setup_dir / 'setup.py'), 'w') as fp:
        print(fp.write('print("hello world")'))
    # Create the fake setup.cfg file

# Generated at 2022-06-11 22:38:33.994705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat
    from sys import version_info

    from . import TEST_DIR

    check_num = 0
    for check_num, out in enumerate(
            each_sub_command_config(setup_dir=TEST_DIR),
            start=1
    ):
        print(
            "check_num = %d\nout = %r\n\ttype(out) = %r\n%s"
            % (
                check_num,
                out,
                type(out),
                pformat(out._asdict()) if version_info[:2] >= (3, 7)
                else pformat(out._asdict())
            )
        )

    assert check_num == 4

# Generated at 2022-06-11 22:38:38.489421
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import List

    from flutils.pyutils import isiterable

    rets: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert rets
    assert isiterable(rets)



# Generated at 2022-06-11 22:38:42.053641
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    for config in each_sub_command_config():
        pprint(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:51.954685
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def check(
            expected: Tuple[SetupCfgCommandConfig, ...],
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        """Checks the test function, using the given ``expected``
        tuple.

        Args:
            expected: The expected configs as a tuple.

        Raises:
            Unittest.TestCase.failureException: If it fails.
        """
        import unittest
        expected = tuple(map(SetupCfgCommandConfig._make, expected))
        actual = tuple(each_sub_command_config(setup_dir))
        if actual != expected:
            raise unittest.TestCase.failureException(
                'The returned configs are NOT what we expected.'
            )


# Generated at 2022-06-11 22:39:00.928708
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys

    from flutils._common_lib._setup_commands import (
        each_sub_command_config,
        TestSetupCommand,
    )
    from flutils.testutils import TestCase

    test_dir = os.path.abspath(os.path.dirname(__file__))
    if os.path.basename(test_dir) != 'tests':
        raise RuntimeError("Expected the test directory to have 'tests' as "
                           "the name.")
    project_dir = str(os.path.dirname(test_dir))

    if os.path.basename(project_dir) != 'flutils':
        raise RuntimeError("Expected the project directory to have 'flutils' "
                           "as the name.")

# Generated at 2022-06-11 22:39:29.232162
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pformat
    top_path: str = os.path.dirname(os.path.abspath(__file__))
    top_path = os.path.join(top_path, 'test_setup_commands')
    c = list(each_sub_command_config(top_path))
    print(pformat(c))

# Generated at 2022-06-11 22:39:37.914734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        name = 'flutils'
        setup_py_path = os.path.join(tmpdir, 'setup.py')

# Generated at 2022-06-11 22:39:45.938166
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = os.path.realpath(tmp_dir)
        tmp_setup_cfg = os.path.join(tmp_dir, 'setup.cfg')
        with open(tmp_setup_cfg, 'w') as f:
            f.write("""\
[metadata]
name = my_project

[setup.command.bar]
name = setup.command.foo
command = echo 1
commands =
  echo 2
[setup.command.foo]
name = setup.command.foo
command = echo 1
commands =
  echo 2
""")

        name: str
        command: SetupCfgCommandConfig

# Generated at 2022-06-11 22:40:00.126736
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def get_all_commands(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> List[Tuple[str, str, str]]:
        return [(c.name, c.camel, c.description)
                for c in each_sub_command_config(setup_dir)]

    setup_dir = os.path.dirname(os.path.abspath(__file__))
    assert get_all_commands(setup_dir) == [
        ('install', 'Install', ''),
        ('run', 'Run', 'run is an alias for run_app.'),
        ('run_app', 'RunApp', 'Run application.'),
        ('run_app_dev', 'RunAppDev', 'Run application in development.')
    ]

# Generated at 2022-06-11 22:40:10.875903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap

    def _test(filename: str, expected: str) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            path = os.path.join(tmp_dir, filename)
            os.makedirs(os.path.join(tmp_dir, 'src', 'pkg'))
            with open(path, 'w') as f:
                f.write(textwrap.dedent(expected))
            out = list(each_sub_command_config(setup_dir=tmp_dir))
            assert out

    _test('setup_commands.cfg',
          """
          [setup.commands]
          description=Makes the package
          commands=
              python setup.py sdist
              python setup.py bdist_wheel
          """)


# Generated at 2022-06-11 22:40:19.394291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    for sub_cmd_cfg in each_sub_command_config(project_dir):
        assert isinstance(sub_cmd_cfg, SetupCfgCommandConfig)
        commands = sub_cmd_cfg.commands
        if commands:
            cmd = commands[0]
            assert cmd.startswith('python')
            assert cmd.endswith('setup.py')
        else:
            assert sub_cmd_cfg.name in ('help', '--help')

# Generated at 2022-06-11 22:40:30.268978
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import tempfile

    # Setup
    setup_cfg_path = tempfile.NamedTemporaryFile(mode='wt', delete=False)
    setup_cfg_path.close()

    # Test Error
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(setup_cfg_path.name))

    # Setup
    f = open(setup_cfg_path.name, 'wt')
    f.write(
        '[metadata]\n'
        'name = mypackage\n'
    )
    f.close()
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(setup_cfg_path.name))

    # Setup
    f = open(setup_cfg_path.name, 'at')

# Generated at 2022-06-11 22:40:42.606207
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    from subprocess import Popen, PIPE
    from os import path
    from logging import basicConfig, DEBUG
    from time import sleep
    from os.path import exists
    from contextlib import ExitStack, contextmanager
    from typing import Generator
    from flutils.envutils import env_bool, env_int
    from flutils.sysutils import path2url

    basicConfig(level=DEBUG)

    TEST_ROOT = path.dirname(path.abspath(__file__))
    TEST_SETUP_DIR = path.join(TEST_ROOT, 'data', 'setupdir')
    TEST_SETUP_FILE = path.join(TEST_SETUP_DIR, 'setup.py')

# Generated at 2022-06-11 22:40:55.837728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from conftest import (  # pylint: disable=import-outside-toplevel
        TEST_DIR,
        TEST_SUB_COMMANDS_DIR,
        TEST_SUB_COMMANDS_BASE_DIR,
    )
    from typing import (  # pylint: disable=import-outside-toplevel
        List,
    )
    from flutils.pathutils import (  # pylint: disable=import-outside-toplevel
        each_file,
    )
    from flutils.strutils import (  # pylint: disable=import-outside-toplevel
        underscore_to_camel,
    )
    from flutils.setup_commands import (  # pylint: disable=import-outside-toplevel
        SetupCfgCommandConfig,
    )
   

# Generated at 2022-06-11 22:41:07.363636
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """The function each_sub_command_config is tested."""
    import os
    import sys
    import tempfile
    import unittest
    import shutil

    class EachSubCommandConfigTest(unittest.TestCase):
        """Test the function each_sub_command_config."""

        def setUp(self) -> None:
            self._tempdir = tempfile.mkdtemp()

            # Create a setup.cfg file.
            setup_cfg = os.path.join(self._tempdir, 'setup.cfg')
            with open(setup_cfg, 'w') as file:
                file.write('[metadata]\n')
                file.write('name = pkg_name\n')

        def tearDown(self) -> None:
            shutil.rmtree(self._tempdir)


# Generated at 2022-06-11 22:42:07.138281
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import find_parent_dir
    from pprint import pprint
    from sys import executable
    from tempfile import TemporaryDirectory

    td = TemporaryDirectory()

# Generated at 2022-06-11 22:42:15.964793
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config())

    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config('/tmp'))

    assert [] == list(each_sub_command_config('.'))

    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config('../test/resources'))

    g = each_sub_command_config('../test/resources/test_setup_cfg')

# Generated at 2022-06-11 22:42:28.544186
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_example_project_path,
        get_test_example_pypi_project_path,
    )
    from flutils.projectutils import (
        get_setup_cfg_description,
        get_setup_cfg_name,
    )

    def test(setup_dir: str, has_commands: bool = True) -> None:
        setup_dir = os.path.realpath(setup_dir)
        name = get_setup_cfg_name(setup_dir)
        description = get_setup_cfg_description(setup_dir)
        sub_commands = tuple(each_sub_command_config(setup_dir))
        if has_commands is True:
            assert sub_commands
            for sub_command in sub_commands:
                assert sub

# Generated at 2022-06-11 22:42:36.708643
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    d = os.path.join(__location__, 'test_data')
    d = os.path.join(d, 'setup_cfg_command_config')

    for d in filter(lambda e: e.startswith('test_case_'), os.listdir(d)):
        d = os.path.join(d, 'setup.py')
        if os.path.isfile(d):
            expected = []
            with open(d) as fh:
                for line in fh.readlines():
                    line = line.strip()
                    if line.startswith('# =='):
                        break
                    expected.append(line)

            d = os.path.join(os.path.dirname(d), 'setup.cfg')
            actual = list(each_sub_command_config(d))


# Generated at 2022-06-11 22:42:38.775614
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-11 22:42:43.565052
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print('{0.name:20} | {0.camel:20} | {0.commands}'.format(sc))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:44.899514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg)

# Generated at 2022-06-11 22:42:49.371989
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    if setup_dir:
        setup_dir = os.path.realpath(setup_dir)
    each_sub_command_config(setup_dir)

# Generated at 2022-06-11 22:42:51.681663
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test for function each_sub_command_config"""
    for sub_cmd in each_sub_command_config():
        assert sub_cmd.name
        assert sub_cmd.commands

# Generated at 2022-06-11 22:42:58.985443
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def setup_dir_from_caller() -> str:
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            if 'test_' not in fs.function:
                return os.path.dirname(fs.filename)
        raise FileNotFoundError
    import inspect
    from pprint import pformat
    from flutils.testutils import capture_stdout
    from flutils.envutils import get_project_root
    from flutils.pathutils import win_path_to_posix_path

    project_dir = get_project_root()
    home_dir = os.path.expanduser('~')

    with capture_stdout() as out:
        import sys
        print('Project directory: %r' % project_dir, file=sys.stderr)

# Generated at 2022-06-11 22:44:28.775360
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for ``each_sub_command_config`` funtion."""
    pass

# Generated at 2022-06-11 22:44:40.763000
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.sysutils import tempdir

    with tempdir(prefix='test_each_sub_command_config') as temp_dir:
        home = os.path.expanduser('~')
        setup_cfg = '''
[metadata]
name = test_project

[setup.command.test_1]
name = test
description = Some test {name}.
command = echo hello world

[setup.command.test_2]
description = Another test {name}.
command = echo bye bye world
        '''

# Generated at 2022-06-11 22:44:44.030352
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for sc in each_sub_command_config(setup_dir):
        # print(sc)
        pass


if __name__ == '__main__':
    pass

# Generated at 2022-06-11 22:44:46.674306
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config.commands, tuple)
        assert isinstance(config.commands[0], str)
        assert isinstance(config.description, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.name, str)
        break



# Generated at 2022-06-11 22:44:58.316360
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from flutils.miscutils import write_file
    from flutils.mkdirs import mkdirs

    class EachSubCommandConfigTest(TestCase):

        def setUp(self):
            self.maxDiff = None
            self.setup_dir = TemporaryDirectory()

        def tearDown(self):
            self.setup_dir.cleanup()

        def test_each_sub_command_config_simple(self):
            os.chdir(self.setup_dir.name)
            mkdirs(self.setup_dir.name)

            with StringIO() as f:
                f.write(
                    '[metadata]\n'
                    'name = flutils'
                )
                f.seek(0)
                write_file

# Generated at 2022-06-11 22:45:07.988386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    test_path = os.path.join(tempfile.gettempdir(), 'test_each_sub_command_config_setup_commands.cfg')
    test_setup_cfg = os.path.join(tempfile.gettempdir(), 'test_each_sub_command_config_setup.cfg')
    test_setup_py = os.path.join(tempfile.gettempdir(), 'test_each_sub_command_config_setup.py')

# Generated at 2022-06-11 22:45:18.362390
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    output = list(each_sub_command_config())
    assert len(output) == 6
    assert output[0] == SetupCfgCommandConfig(
        '1',
        '1',
        'No description.',
        ('echo Success!',)
    )
    assert output[5] == SetupCfgCommandConfig(
        '5',
        '5',
        'This is the description for the 5 section.',
        ('echo Success!',)
    )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:31.664993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    proj = os.path.join(here, 'setup_command_proj')
    assert os.path.isdir(proj)
    expected = [
        SetupCfgCommandConfig(
            'test_setup_command',
            'TestSetupCommand',
            'Foo bar.',
            (
                'python {setup_dir}/setup.py build_py',
                'python {setup_dir}/setup.py install',
                'echo success.'
            )
        ),
        SetupCfgCommandConfig(
            'foo.bar',
            'FooBar',
            'Baz qux.',
            (
                'python {setup_dir}/setup.py test',
                'echo {name}',
            )
        ),
    ]


# Generated at 2022-06-11 22:45:33.317419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test that the package setup file is found
    list(each_sub_command_config())

# Generated at 2022-06-11 22:45:41.148878
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import create_dir_tree
    from flutils.globals import read_file
    from sys import platform

    env_key = 'FLUTILS_PATH_TO_TEST_EACH_SUB_COMMAND_CONFIG'
    env_val = os.getenv(env_key)

    with TemporaryDirectory(suffix='test_each_sub_command_config') as tmpdir:
        tmpdir = str(tmpdir)

        path = os.path.join(tmpdir, 'setup.py')
        with open(path, 'w') as f:
            f.write('\n')

        path = os.path.join(tmpdir, 'setup_commands.cfg')