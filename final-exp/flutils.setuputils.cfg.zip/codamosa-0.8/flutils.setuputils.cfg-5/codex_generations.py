

# Generated at 2022-06-11 22:36:21.580216
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config('../../'):
        assert isinstance(cfg.name, str)
        assert isinstance(cfg.camel, str)
        assert isinstance(cfg.description, str)
        assert isinstance(cfg.commands, tuple)
        for cmd in cfg.commands:
            assert isinstance(cmd, str)
    try:
        each_sub_command_config('.')
    except FileNotFoundError:
        pass
    else:
        assert False

# Generated at 2022-06-11 22:36:27.111454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected = (
        SetupCfgCommandConfig(
            'test.cli.discover',
            'TestCliDiscover',
            'Run unit tests for package',
            (
                'python3 -m unittest discover {setup_dir}',
            )
        ),
    )
    for count, out in enumerate(each_sub_command_config(), start=1):
        assert out == expected
    assert count == 1


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-11 22:36:33.643225
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .test_config import get_test_dir
    for sub_command_config in each_sub_command_config(get_test_dir()):
        print(sub_command_config.name)
        print(sub_command_config.camel)
        print(sub_command_config.description)
        print(sub_command_config.commands)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:44.335261
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import tempfile

    def _create_setup_command_cfg(
            name: str,
            commands: Tuple[str, ...],
            description: str = '',
            setup_commands_path: Optional[str] = None
    ) -> SetupCfgCommandConfig:
        setup_commands_path: str = setup_commands_path or 'setup_commands.cfg'
        name = name.strip('.').replace('.', '_')
        title = underscore_to_camel(name, lower_first=False)
        section = 'setup.command.%s' % name
        parser = ConfigParser()
        parser.add_section(section)
        parser.set(section, 'name', name)

# Generated at 2022-06-11 22:36:54.235079
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    p = get_test_data_path('setup_commands', 'setup_commands.cfg')
    assert os.path.isfile(p)
    p = os.path.dirname(p)
    assert os.path.isdir(p)
    gen = each_sub_command_config(p)
    commands = []
    for cmd_cfg in gen:
        assert isinstance(cmd_cfg, SetupCfgCommandConfig)
        assert isinstance(cmd_cfg.name, str)
        assert isinstance(cmd_cfg.camel, str)
        assert isinstance(cmd_cfg.description, str)
        assert isinstance(cmd_cfg.commands, tuple)

# Generated at 2022-06-11 22:37:07.164255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function :func:`each_sub_command_config`."""
    import os
    from pathlib import Path
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from testfixtures import should_raise

    from flutils.pathutils import expand_home

    def run():
        for config in each_sub_command_config():
            # print(config)
            assert isinstance(config.name, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            assert len(config.commands) > 0
            assert all(map(lambda x: isinstance(x, str), config.commands))
            assert '{setup_dir}' not in config.commands[0]
            assert '{home}' not in config.commands

# Generated at 2022-06-11 22:37:15.621067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # This is a minimal setup.py
    from setuptools import Command
    from setuptools import setup

    class MyCommand(Command):
        user_options = ()

        def initialize_options(self):
            pass

        def finalize_options(self):
            pass

        def run(self):
            pass


# Generated at 2022-06-11 22:37:22.759188
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Called from the command-line to execute the unit test."""
    from pathlib import Path
    from pprint import pprint
    module_name = 'my_project'
    module_path = Path(module_name, 'setup_commands.cfg')
    if module_path.is_file():
        module_path.unlink()
    for k, v in each_sub_command_config(Path(module_name)):
        pprint(vars(k))

# Generated at 2022-06-11 22:37:33.457237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import pytest
    from io import StringIO
    from tempfile import TemporaryDirectory
    from typing import (
        Iterable,
        List,
        Optional,
        Tuple,
    )
    from configparser import (
        ConfigParser,
        DuplicateSectionError,
        MissingSectionHeaderError,
        NoOptionError,
        NoSectionError,
        ParsingError,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )

    from . import setupcfg

    test_dir = os.path.dirname(__file__)

    def get_default_config() -> Iterable[str]:
        yield '[metadata]'
        yield 'name = test_package'


# Generated at 2022-06-11 22:37:37.526878
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config(
        os.path.join(os.path.dirname(__file__), 'example_project')
    ):
        print(sc)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:57.091338
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import os

    def content_lines(lines: List[str], comment: str = '#') -> str:
        return os.linesep.join(
            line if ''.join(line.split()) else comment + line
            for line in lines
        ) + os.linesep


# Generated at 2022-06-11 22:38:07.268159
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as dirpath:
        setup_cfg = os.path.join(dirpath, 'setup.cfg')
        setup_py = os.path.join(dirpath, 'setup.py')
        setup_commands_cfg = os.path.join(dirpath, 'setup_commands.cfg')
        with open(setup_cfg, 'w') as f:
            f.write("""\
[metadata]
name = flutils
""")
        with open(setup_py, 'w') as f:
            f.write("""\
#!/usr/bin/env python3

import setuptools

setuptools.setup()
""")

# Generated at 2022-06-11 22:38:15.432310
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import re

    valid_name = re.compile(r'^(\w|\.)+$')

    def get_names(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[str, None, None]:
        for config in each_sub_command_config(setup_dir):
            if not valid_name.match(config.name):
                raise ValueError('Invalid name of %r' % config.name)
            yield config.name

    names = set(get_names())
    assert names == {'install', 'uninstall'}

    names = set(get_names('.tox/py36'))
    assert names == {'install', 'uninstall'}

# Generated at 2022-06-11 22:38:21.677090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'setup_dir')
    test_cases = {
        'install': 'pip install .',
        'format': 'black --check setup.py setup_commands.cfg',
        'type_check': 'mypy --ignore-missing-imports setup.py setup_commands.cfg',
        'test': 'python -m unittest discover -s . -p "*_test.py"',
    }
    for config in each_sub_command_config(setup_dir):
        assert config.name in test_cases
        assert config.commands[0] == test_cases[config.name]


# Generated at 2022-06-11 22:38:24.586815
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:29.578131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    for config in configs:
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:38.457059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import inspect
    import subprocess
    import tempfile
    import shutil
    import textwrap
    from pathlib import Path

    # Create a temporary directory in which to place a package with
    # a setup.py and a setup.cfg file that contains a entry to call
    # ``./setup.py flutils_setup_command``.
    tmpdir = Path(tempfile.mkdtemp())

    (tmpdir / 'setup_commands.cfg').write_text(textwrap.dedent("""\
        [setup.command.foo]
        description = foo!
        command = {setup_dir}/foo.sh {setup_dir} {home}
        """))


# Generated at 2022-06-11 22:38:45.838391
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config('tests/fixtures/test-setup.py')) == [
        SetupCfgCommandConfig(
            name='test.subcmd', camel='TestSubcmd', description='Test subcmd',
            commands=('echo "test.subcmd"',)
        ),
        SetupCfgCommandConfig(
            name='test.subcmd2', camel='TestSubcmd2',
            description='Test subcmd2',
            commands=('echo "test.subcmd2"',)
        )
    ]
    assert list(each_sub_command_config('setup.py')) == []

# Generated at 2022-06-11 22:38:53.515061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .utils import write_contents
    from . import mkdtemp
    from . import test_dir
    from . import test_path

    proj_name = 'proj0'
    root_dir = test_dir(__file__)

    def _get_command_name(command: str) -> str:
        return 'setup.command.' + command.replace('.', '_')

    def _get_command_config(
            commands: List[str],
            command: str
    ) -> SetupCfgCommandConfig:
        config = commands[0]
        assert config.name == command
        assert config.camel == command.replace('.', '_').upper()
        assert config.description == ''
        assert config.commands == ('echo "Running command: %s"' % command,)
        return config


# Generated at 2022-06-11 22:38:57.935693
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname
    from pprint import pprint
    this_file = __file__  # type: ignore
    if not this_file.endswith('.py'):
        this_file = f'{this_file}.py'
    pprint(list(each_sub_command_config(dirname(this_file))))

# Generated at 2022-06-11 22:39:29.623237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config via a unit test."""
    from flutils.debugutils import assert_raises

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]],
            exception: Optional[Exception],
            count: Optional[int]
    ):
        if exception:
            assert_raises(exception, each_sub_command_config, setup_dir)
        else:
            actual = list(each_sub_command_config(setup_dir))
            assert len(actual) == count

    def _test_setup_dir(setup_dir: Optional[Union[os.PathLike, str]]):
        _test_each_sub_command_config(setup_dir, None, 9)

    _test_setup_dir(None)


# Generated at 2022-06-11 22:39:43.592131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import temporary_directory
    from flutils.strutils import to_literal

    def _to_literal_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> str:
        out_lines: List[str] = []
        for cfg in each_sub_command_config(setup_dir):
            out_lines.append(
                "[{name}] [{camel}] [{description}]".format_map({
                    'name': cfg.name,
                    'camel': cfg.camel,
                    'description': cfg.description,
                })
            )
            if cfg.commands:
                cmds = ','.join(cfg.commands)

# Generated at 2022-06-11 22:39:51.695672
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    setup_dir = None
    for cmd in each_sub_command_config(setup_dir):
        print(cmd)
        assert isinstance(cmd, SetupCfgCommandConfig)


if __name__ == "__main__":
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-11 22:39:57.718825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert len(config) == 1
    cfg: SetupCfgCommandConfig = config[0]
    assert cfg.name == 'build_docker'
    assert cfg.camel == 'BuildDocker'
    assert len(cfg.commands) == 1
    assert cfg.commands[0] == 'build-docker'

# Generated at 2022-06-11 22:40:06.624648
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('each_sub_command_config')
    setup_dir = os.path.realpath(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            '..',
            '..',
            '..',
            '..',
            '..'
        )
    )
    for x in each_sub_command_config(setup_dir=setup_dir):
        print(x)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:16.146815
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        master_noop = '''
            "This is the noop command, it does nothing and can be used
            as a template for creating new commands."
            '''
        name = config.name.lower()
        camel = config.camel
        description = config.description.strip()
        if name == 'noop':
            assert description == master_noop
            assert camel == 'Noop'
        else:
            assert 'This is the noop command' not in description
            assert camel != 'Noop'
        commands = config.commands
        assert isinstance(commands, tuple)
        assert len(commands) > 0


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:28.081703
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from textwrap import dedent

    from . import BaseTest

    class Test(BaseTest):

        def test_each_sub_command_config_without_directory(self):
            with self.assertRaises(FileNotFoundError):
                list(each_sub_command_config())

        def test_each_sub_command_config_empty(self):
            with Path.tempdir() as tmp_dir:
                with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
                    f.write('')
                with open(os.path.join(tmp_dir, 'setup.py'), 'w') as f:
                    f.write(dedent("""\
                        import setuptools

                        setuptools.setup()
                        """))

# Generated at 2022-06-11 22:40:31.352758
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    sys.path.insert(0, '../test/test_extras')
    import test_setup_cfg_commands
    sys.path.pop(0)
    assert test_setup_cfg_commands.test_each_sub_command_config()



# Generated at 2022-06-11 22:40:40.718661
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.dirname(os.path.realpath(__file__))
    for sub in each_sub_command_config(cwd):
        assert sub.description
        assert sub.camel
        assert sub.name
        assert sub.commands
    for sub in each_sub_command_config():
        assert sub.description
        assert sub.camel
        assert sub.name
        assert sub.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:40:49.056666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_commands() -> Tuple[Tuple[str, ...], ...]:
        out = []
        for config in each_sub_command_config(
                'tests/data/setup_travis_ci_test'
        ):
            if config.name != 'setup.command.setup_travis_ci_test':
                continue
            out.append(config.commands)
        return tuple(out)


# Generated at 2022-06-11 22:41:46.668816
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase as UnitTest

    from flutils.testutils import TestCaseMixin

    class TestCase(TestCaseMixin, UnitTest):
        def setUp(self):
            d = self.set_up(__file__, each_sub_command_config)
            if os.path.exists(d) is False:
                os.mkdir(d)
            path = os.path.join(d, 'setup.py')
            with open(path, 'w') as f:
                f.write('import sys\n\n')

        def tearDown(self):
            self.tear_down()

        def test_setup_dir_is_none(self):
            rc = each_sub_command_config()
            self.assertIsInstance(rc, Generator)

# Generated at 2022-06-11 22:41:58.969018
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Testing setup.cfg with setup.command.clean
    setup_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'resources',
        'setup_cfg_with_setup_command_clean',
    )
    for scc in each_sub_command_config(setup_dir=setup_dir):
        assert scc.commands == ('rm -rf *.pyc .tox .coverage',)
        assert scc.description == 'Cleans up the project.'
        assert scc.name == 'clean'

    # Testing setup.cfg with no setup.command.* section

# Generated at 2022-06-11 22:42:10.408412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    from flutils.pathutils import mod_abspath_to_mod_relpath

    from flutils.packutils import get_module_path

    flutils_mod_path = get_module_path('flutils')

    with TemporaryDirectory(prefix='flutils_') as tmp_dir:
        orig_setup_py = f"""\
            from setuptools import setup

            setup()
            """


# Generated at 2022-06-11 22:42:17.367891
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    d = os.path.dirname(__file__)
    for config in each_sub_command_config(d):
        print(config)


if __name__ == '__main__':
    from flutils.stdutils import format_exc
    try:
        test_each_sub_command_config()
    except Exception as err:
        print(format_exc())

# Generated at 2022-06-11 22:42:22.677392
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for name in ('test_setup_dir', 'test_setup_dir_1'):
        for sc_cfg in each_sub_command_config(name):
            sc_cfg  # type: ignore
    for sc_cfg in each_sub_command_config():
        sc_cfg  # type: ignore

# Generated at 2022-06-11 22:42:26.705343
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.join(path, 'test_data')
    path = os.path.join(path, 'package')
    out = list(each_sub_command_config(path))
    assert out
    out = list(each_sub_command_config())
    assert out

# Generated at 2022-06-11 22:42:31.011600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(__file__)
    this_dir = os.path.abspath(this_dir)
    for x in each_sub_command_config(this_dir):
        print(x)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:37.726552
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    env = os.environ['VIRTUAL_ENV']
    out = list(each_sub_command_config(env))
    assert len(out) == 3
    assert out[0].name == 'env.sys'
    assert out[0].camel == 'Env_Sys'
    assert out[0].description.startswith('Runs the flutils.sysutils.sysinfo')
    assert not out[0].description.endswith('.')
    assert out[0].commands == (
        'flutils sysinfo',
    )
    assert out[1].name == 'env.test'
    assert out[1].camel == 'Env_Test'
    assert out[1].description.startswith('Runs the tests for this project')

# Generated at 2022-06-11 22:42:50.023688
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import (
        assert_iter_items,
        parse_pytest_args,
    )

    args = parse_pytest_args(sys.argv[1:])

# Generated at 2022-06-11 22:42:52.109836
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:29.460243
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.parsing.cli.setupcfg import SetupCfgCommandConfig
    from flutils.parsing.cli.setupcfg import each_sub_command_config
    from pprint import pprint
    from sys import argv
    from tempfile import TemporaryDirectory

    temp_dir = TemporaryDirectory()

# Generated at 2022-06-11 22:44:41.876722
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class Test(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.setup_dir = os.path.dirname(os.path.abspath(__file__))
            sys.path.append(cls.setup_dir)
            import setup_commands
            cls.setup_commands = setup_commands

        def test(self):
            for i, sc in enumerate(each_sub_command_config(self.setup_dir)):
                attr = 'sub_command_%d' % (i + 1)
                if hasattr(self.setup_commands, attr) is False:
                    break

                sc_a = getattr(self.setup_commands, attr)
                self.assertEqual

# Generated at 2022-06-11 22:44:47.598916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in cast(
            Generator[SetupCfgCommandConfig, None, None],
            each_sub_command_config(os.path.dirname(__file__))
    ):
        assert isinstance(sub_cmd, SetupCfgCommandConfig)
        assert isinstance(sub_cmd.name, str)
        assert isinstance(sub_cmd.camel, str)
        assert isinstance(sub_cmd.description, str)
        assert isinstance(sub_cmd.commands, tuple)

# Generated at 2022-06-11 22:44:59.863317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Unit test for function each_sub_command_config
    """
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..')
    )

# Generated at 2022-06-11 22:45:08.729374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from contextlib import ExitStack
    from tempfile import TemporaryDirectory
    from flutils.testutils import (
        auto_namedtuple,
        auto_namedtuple_values,
        mk_random_str,
    )
    from pathlib import Path

    Config = auto_namedtuple(
        'Config',
        'name camel description commands'
    )
    sub = auto_namedtuple_values(
        'sub',
        'setup_dir command_name camel_case_command_name description commands'
    )

# Generated at 2022-06-11 22:45:21.178840
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')
    )
    setup_cfg_path = os.path.join(root_path, 'setup.cfg')

    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'setup_dir': root_path,
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)


# Generated at 2022-06-11 22:45:23.484063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        print(item)

# Generated at 2022-06-11 22:45:26.690366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config())
    assert configs
    assert len(configs) > 0



# Generated at 2022-06-11 22:45:32.812993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fixtures')
    for x in each_sub_command_config(setup_dir=path):
        print(x)


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:39.303048
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    count = 0
    for sub_cmd in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), 'example')
    ):
        count += 1
        assert isinstance(sub_cmd, SetupCfgCommandConfig)
        assert isinstance(sub_cmd.name, str)
        assert isinstance(sub_cmd.camel, str)
        assert isinstance(sub_cmd.description, str)
        assert isinstance(sub_cmd.commands, tuple)
    assert count == 3