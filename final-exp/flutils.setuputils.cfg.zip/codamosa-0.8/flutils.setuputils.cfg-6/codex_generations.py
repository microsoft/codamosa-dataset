

# Generated at 2022-06-11 22:36:25.993768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_str(
            expected: str,
            actual: str
    ) -> bool:
        """Asserts that the given ``expected`` and ``actual`` strings are
        equivalent.
        """
        if expected != actual:
            raise AssertionError(
                'The "%s" does NOT equal the expected, "%s".'
                % (actual, expected)
            )
        return True
    for config in each_sub_command_config():
        _assert_str('test', config.name)
        _assert_str('Test', config.camel)
        _assert_str('Test the "test" command.', config.description)
        _assert_str(
            'coverage run --source "${setup_dir}" setup.py test',
            config.commands[0]
        )
        _assert_str

# Generated at 2022-06-11 22:36:27.395269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    pprint(list(each_sub_command_config()))

# Generated at 2022-06-11 22:36:35.749056
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect, os, shutil, sys
    from tempfile import mkdtemp
    from unittest import TestCase
    from pathlib import Path

    class SetupCommandConfigTest(TestCase):
        def setUp(self):
            self.tempdir = mkdtemp()
            p = Path(self.tempdir)
            p.joinpath('setup.py').touch()

        def tearDown(self):
            if self.tempdir:
                shutil.rmtree(self.tempdir)

        def read_cfg_file(self, filename: str, string: str) -> List[str]:
            p = Path(self.tempdir)
            p = p.joinpath(filename)
            p.write_text(string)
            out = []

# Generated at 2022-06-11 22:36:45.460380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import tempfile
    from pathlib import Path

    def func(
            setup_cfg_path: str,
            setup_commands_cfg_path: str = '',
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        setup_cfg_path = str(setup_cfg_path)
        setup_commands_cfg_path = str(setup_commands_cfg_path)
        configs = []
        for config in each_sub_command_config(setup_dir):
            configs.append(config)
        pprint.pprint(configs)
    print('---- Test #1 ----')
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        setup_cfg_path = tmp_

# Generated at 2022-06-11 22:36:52.568656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    file_path = os.path.abspath(__file__)
    file_dir = os.path.dirname(file_path)

    assert str(each_sub_command_config(file_dir)) == (
        "SetupCfgCommandConfig(name='test', camel='Test', "
        "description='Test description', commands=('test1', 'test2'))"
    )
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/nonexistent/path')



# Generated at 2022-06-11 22:36:54.032564
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)



# Generated at 2022-06-11 22:37:00.853884
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '../..')
    )
    for sub_command in each_sub_command_config(project_dir):
        pass



# Generated at 2022-06-11 22:37:09.784209
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import getcwd
    from flutils.iterutils import each_dict_value

    def each_expected(
            name: str,
            camel: str,
            description: str,
            commands: str
    ) -> Generator[Tuple[str, str], None, None]:
        keys = ('name', 'camel', 'description', 'commands')
        for key, val in zip(keys, (name, camel, description, commands)):
            if val:
                val = val.strip()
                yield key, val


# Generated at 2022-06-11 22:37:22.807310
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from os import (
        chmod,
        mkdir,
    )
    from os.path import (
        join as pathjoin,
        exists as pathexists
    )

    # Setup
    main_dir = TemporaryDirectory()
    setup_py = pathjoin(main_dir.name, 'setup.py')
    with open(setup_py, 'w') as fout:
        fout.write('import os\n')
        fout.write('import sys\n')
        fout.write('import distutils.core\n')
        fout.write('import setuptools\n')
        fout.write('\n')
        fout.write('\n')
        fout.write('\n')

# Generated at 2022-06-11 22:37:27.789549
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint as pp
    for i, x in enumerate(each_sub_command_config()):
        print(i)
        print(pp.pformat(x))
    print('end')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:45.923714
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    for config in gen:
        pass


if __name__ == "__main__":
    from flutils.logutils import setup_logger
    from flutils.typesutils import get_type_name

    setup_logger()

    logger = logging.getLogger(__name__)

    logger.info("Starting...")

    gen = each_sub_command_config()
    for config in gen:
        logger.info(config)

    logger.info("...Done!")

# Generated at 2022-06-11 22:37:50.007418
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .__setup__ import setup_dir
    from .__setup__ import get_example_data

    def _assert(cmd_config: SetupCfgCommandConfig) -> None:
        assert cmd_config.name
        assert cmd_config.camel
        assert cmd_config.description
        assert cmd_config.commands

    for cmd_config in each_sub_command_config(setup_dir):
        _assert(cmd_config)

    get_example_data('setup.cfg')
    path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-11 22:37:57.457004
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import io
    import logging

    import psycopg2

    from flutils.setuputils import each_sub_command_config

    # Create an in-memory buffer
    stream = io.StringIO()

    # Create a logger
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)

    # Create a handler for the logger
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)

    # Create a formatter for the log records
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Get the current

# Generated at 2022-06-11 22:38:07.502619
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock as mock

    class MockParser(object):
        def __init__(self, sections: List[Tuple[str, ...]]):
            self.sections_iter = iter(sections)
            self.sections_copy: List[Tuple[str, ...]] = list(self.sections_iter)

        def options(self, section: str) -> Tuple[str, ...]:
            for section_, options_ in self.sections_copy:
                if section == section_:
                    return options_

            raise KeyError(
                "Cannot find the given 'section', %r, in the sections "
                "that are defined in the parser, %r."
                % (section, self.sections_copy)
            )


# Generated at 2022-06-11 22:38:19.011967
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import logging
    import unittest  # type: ignore
    from flutils.runutils import clean_traceback_string

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    class SetupCfgTest(unittest.TestCase):
        def setUp(self):
            self.abs_path = os.path.abspath(os.path.dirname(__file__))
            self.name = 'setup_commands_test'
            self.setup_dir = os.path.join(self.abs_path, self.name)
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-11 22:38:29.926632
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        with tempfile.TemporaryDirectory() as tmpdir2:
            setup_dir = os.path.join(tmpdir, 'foo_bar')
            os.mkdir(setup_dir)
            setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as fp:
                fp.write('[metadata]\n'
                         'name = foo-bar\n')

            setup_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-11 22:38:32.467394
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('setup_example'):
        print(config)

# Generated at 2022-06-11 22:38:40.871639
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for cmd in each_sub_command_config(setup_dir=setup_dir):
            print(cmd)

    _test()
    _test(
        os.path.realpath(
            os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                'tests',
                'setup_commands'
            )
        )
    )

# Generated at 2022-06-11 22:38:49.429721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import (
        getcwd,
        chdir,
    )
    from os.path import (
        dirname,
        abspath,
    )
    from contextlib import (
        suppress,
    )
    dir_path = dirname(abspath(__file__))
    with suppress(FileNotFoundError):
        chdir(dir_path)
        yield each_sub_command_config
    with suppress(FileNotFoundError):
        chdir(getcwd())
        yield each_sub_command_config


# Generated at 2022-06-11 22:38:59.410583
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _assert_list_cmd(
            lst_config: List[SetupCfgCommandConfig],
            cmd_name: str
    ) -> None:
        # Asserts named command is in the list
        assert cmd_name in list(map(lambda x: x.name, lst_config))

    # 1st assert
    fn = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'setup.py')
    )
    dir_path = os.path.dirname(fn)
    lst_config = list(each_sub_command_config(dir_path))
    assert len(lst_config) > 0
    _assert_list_cmd(lst_config, 'flake8')

# Generated at 2022-06-11 22:39:23.753280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        assert '{' not in item.name
        assert '{' not in item.description
        for command in item.commands:
            assert '{' not in command


if __name__ == "__main__":
    print(each_sub_command_config())

# Generated at 2022-06-11 22:39:31.638181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('WARNING: Unit tests require the flutils test package to be '
          'installed.')
    from flutils.testutils.fileutils import mkdtemp_context
    import sys
    import tempfile
    with mkdtemp_context(prefix='flutils_test_') as d:
        setup_py_path = os.path.join(d, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('\n')
        setup_cfg_path = os.path.join(d, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\nname = foo')
        setup_commands_path = os.path.join(d, 'setup_commands.cfg')

# Generated at 2022-06-11 22:39:42.616854
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen: Generator[SetupCfgCommandConfig, None, None]
    gen = each_sub_command_config(os.path.abspath('..'))
    assert next(gen).name == 'makefile'
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    try:
        next(gen)
    except StopIteration as e:
        assert e is StopIteration

# Generated at 2022-06-11 22:39:44.397616
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) >= 3

# Generated at 2022-06-11 22:39:52.598418
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.pytest_plugin import (
        assert_setup_cfg_command_config,
        assert_setup_dir_kwargs,
    )
    for sc in each_sub_command_config(**assert_setup_dir_kwargs()):
        assert_setup_cfg_command_config(sc)

# Generated at 2022-06-11 22:40:00.347530
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands: List[SetupCfgCommandConfig] = list(each_sub_command_config())
    assert len(commands) == 3
    assert commands[0].name == 'setup.command.one'
    assert commands[0].commands == ('echo one',)
    assert commands[1].name == 'setup.command.two'
    assert commands[1].commands == ('echo two',)
    assert commands[2].name == 'setup.command.three'
    assert commands[2].commands == ('echo three',)



# Generated at 2022-06-11 22:40:10.991882
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    dir_path = os.path.join(dir_path, 'test_data')

# Generated at 2022-06-11 22:40:23.125283
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Setup
    setup_dir, expected_setup_dir = 'setup_dir_01', os.getcwd()
    format_kwargs = {
        'setup_dir': _prep_setup_dir(setup_dir),
        'home': os.path.expanduser('~')
    }

    # Exercise
    parser = ConfigParser()
    parser.read(os.path.join(format_kwargs['setup_dir'], 'setup.cfg'))
    format_kwargs['name'] = _get_name(parser, 'setup.cfg')
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)

# Generated at 2022-06-11 22:40:29.360661
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        '..',
        '..',
        'flutils-test-command-setup'
    )
    assert os.path.isdir(setup_dir) is True
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig) is True
        assert isinstance(config.name, str) is True
        assert isinstance(config.camel, str) is True
        assert isinstance(config.description, str) is True
        assert isinstance(config.commands, tuple) is True
        assert len(config.commands) > 0

if __name__ == '__main__':
    test_each_sub_command

# Generated at 2022-06-11 22:40:34.727843
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.context import TEST_DIR
    setup_dir = os.path.join(TEST_DIR, 'resources', 'demo_setup_commands')
    for config in each_sub_command_config(setup_dir):
        print(config)

# Generated at 2022-06-11 22:41:22.082622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd_cfg in each_sub_command_config('/Users/sboven/Development/flutils'):
        assert isinstance(sub_cmd_cfg, SetupCfgCommandConfig)

# Generated at 2022-06-11 22:41:30.813808
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.pathutils
    import os
    import pathlib
    import shutil
    import tempfile
    import unittest

    class EachSubCommandConfigTests(unittest.TestCase):

        def cleanUp(self):
            # TODO: run tests as a non-administrator / non-root
            if os.path.isdir(self.temp_dir):
                shutil.rmtree(self.temp_dir)

        def setUp(self):
            self.addCleanup(self.cleanUp)
            self.temp_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')

# Generated at 2022-06-11 22:41:36.769221
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import re
    from pathlib import Path
    sys.path.append(re.sub(
        r'(flutils|\.egg-info|pip-wheel-metadata)$',
        '',
        str(Path(__file__).resolve().parent)
    ))

    setup_dir = Path(__file__).resolve().parent
    for x in each_sub_command_config(setup_dir=setup_dir):
        assert x.name.startswith('setup_commands.')

# Generated at 2022-06-11 22:41:45.317795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    here = Path(__file__).parent
    for out in each_sub_command_config(here):
        print(out)
    for out in each_sub_command_config():
        print(out)
    import sys
    print('=' * 40)
    print(sys.argv[0])
    print('=' * 40)
    print(sys.argv[1])


if __name__ == '__main__':
    import sys
    test_each_sub_command_config()

# Generated at 2022-06-11 22:41:55.933919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    from flutils.pathutils import relpath
    from flutils.testutils import UnitTestBase

    class EachSubCommandConfigTest(UnitTestBase):
        def setUp(self):
            super().setUp()
            self.count = 0

        def test_each_sub_command_config(self):
            for config in each_sub_command_config(relpath(__file__)):
                print('\nconfig:')
                pprint(config)
                self.count += 1

    test = EachSubCommandConfigTest()

    test.run()

    if test.count == 0:
        raise AssertionError("The number of configurations is ZERO!")

# Generated at 2022-06-11 22:42:07.001082
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_each_sub_command_config.__test__ = False

    import pathlib
    # Path to the project's setup.cfg file.
    setup_dirname = os.path.dirname(__file__)
    setup_dirname = pathlib.Path(setup_dirname).parent
    setup_dirname = setup_dirname.parent
    setup_dirname = setup_dirname.parent
    setup_cfg_path = setup_dirname / 'setup.cfg'
    # Path to the project's setup_commands.cfg file.
    setup_commands_cfg_path = setup_dirname / 'setup_commands.cfg'

    # Read contents of the setup_commands.cfg file.
    text = setup_commands_cfg_path.read_text()
    # Get the name of the project.
    name

# Generated at 2022-06-11 22:42:10.528754
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test ``each_sub_command_config``."""
    for cc in each_sub_command_config():
        assert cc is not None  # noqa: S101



# Generated at 2022-06-11 22:42:13.343897
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # noinspection PyTypeChecker
    for cmd in each_sub_command_config('example/python/setup_commands'):
        pass

# Generated at 2022-06-11 22:42:21.446184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.join(path, 'setup.py')
    assert os.path.isfile(path) is True
    path = os.path.dirname(path)
    for i in each_sub_command_config(path):
        print(i)

# Generated at 2022-06-11 22:42:27.101526
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    d = inspect.getfile(each_sub_command_config)
    d = os.path.dirname(d)
    d = os.path.dirname(d)
    for i in each_sub_command_config(d):
        print(i)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:42.456184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'flutils',
        'examples',
        'setup.cfg'
    )
    path = os.path.realpath(path)
    setup_dir = os.path.dirname(path)
    for sc in each_sub_command_config(setup_dir=setup_dir):
        print(
            f"Name: {sc.name!r}\n"
            f"Description: {sc.description!r}\n"
            f"Commands: {sc.commands!r}\n"
            f"Camel: {sc.camel!r}\n"
        )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:50.898350
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'tests'
    )
    configs = []
    for config in each_sub_command_config(setup_dir):
        configs.append(config)

# Generated at 2022-06-11 22:44:54.294483
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config(os.path.dirname(__file__)))
    assert len(cmds) > 0
    assert cmds[0].name == 'flutils.tests.runtests'
    assert cmds[0].camel == 'Runtests'
    assert cmds[0].description
    assert cmds[0].commands

# Generated at 2022-06-11 22:45:05.246487
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from __main__ import __file__

    def test_setup_cfg_template() -> str:
        """Generates a simple ``setup.cfg`` configuration file."""
        out = (
            "[metadata]\n"
            "name={name}\n"
            "version={version}\n"
            "description={description}\n"
            "\n"
            "[console_scripts]\n"
            "onecli=onecli.__main__:{name!s}_main\n"
        )
        return out

    def test_setup_commands_cfg_template() -> str:
        """Generates a simple ``setup_commands.cfg`` configuration file."""

# Generated at 2022-06-11 22:45:10.810022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tests_dir = os.path.dirname(__file__)
    for sub_command in each_sub_command_config(tests_dir):
        assert sub_command.name
        assert sub_command.camel
        assert sub_command.description
        assert sub_command.commands


# Generated at 2022-06-11 22:45:21.789140
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from flutils.pathutils import __file__ as pathutils_file
    from unittest.mock import patch

    from flutils.configutils import each_sub_command_config as escc
    escc_module_path = dirname(escc.__file__)
    test_setup_cfg_path = (
        join(escc_module_path, 'test', 'setup.cfg')
    )
    test_setup_cfg_path = os.path.realpath(test_setup_cfg_path)

    module_path = dirname(pathutils_file)
    test_cfg_path = join(module_path, 'test', 'setup_commands.cfg')
    test_cfg_path = os.path.realpath(test_cfg_path)


# Generated at 2022-06-11 22:45:34.698054
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .example_setup import test_each_sub_command_config as f
    from .example_setup.setup_commands import test_each_sub_command_config as g


# Generated at 2022-06-11 22:45:48.087226
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testing import UnitTest
    from copy import copy
    from pathlib import Path

    setup_cfg = """
[metadata]
name = myname
"""
    setup_cmd_cfg = """
[setup.command.cmd1]
name = new-name
description = new-description
command = {setup_dir}
command = {home}
command = {name}

[setup.command.cmd2]
name = {name}
description = {name}
commands = {setup_dir}
commands = {home}
commands = {name}

[setup.command.cmd3]
command = {setup_dir}

[setup.command.cmd4]
command = {home}
"""

# Generated at 2022-06-11 22:45:54.021114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)
    for config in each_sub_command_config('../'):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:46:03.827690
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase

    class TestEachSubCommandConfig(TempDirTestCase):
        """Unit test for function each_sub_command_config."""

        def _each_sub_command_config(self, setup_cfg_str: str,
                                     setup_cfg_path: str = 'setup.cfg',
                                     do_write_setup_cfg: bool = True):
            if do_write_setup_cfg:
                path = os.path.join(self.temp_dir, setup_cfg_path)
                with open(path, 'w') as fp:
                    fp.write(setup_cfg_str)
            else:
                path = os.path.join(self.temp_dir, setup_cfg_path)