

# Generated at 2022-06-11 22:36:21.744273
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config('/Users/mike/Projects/flutils'):
        print(sub_command)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:23.864258
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config():
        print(i)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:36:32.283524
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _get_path() -> str:
        return os.path.dirname(os.path.abspath(__file__))

    assert list(each_sub_command_config(_get_path())) == [
        SetupCfgCommandConfig(
            'clean',
            'Clean',
            'Cleans out the project builds and distributions.',
            ('rm -rf dist/', 'rm -rf build/')
        ),
        SetupCfgCommandConfig(
            'build',
            'Build',
            'Builds the project sdist and bdist_wheel.',
            ('python setup.py sdist bdist_wheel',)
        )
    ]

# Generated at 2022-06-11 22:36:43.691105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = []
    for cmd in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), 'pyproject')
    ):
        out.append(cmd)
    assert len(out) == 2
    assert out[0].name == 'tests.echo'
    assert out[0].camel == 'TestsEcho'
    assert out[0].description == 'Echo'
    assert out[0].commands == ('echo -n "Hello..."', 'echo "World!"')
    assert out[1].name == 'tests.echo2'
    assert out[1].camel == 'TestsEcho2'
    assert out[1].description == 'Echo 2'
    assert out[1].commands == ('echo "World 2!", "Test 2"',)

# Generated at 2022-06-11 22:36:53.814091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import cd, get_rel_path
    from tempfile import TemporaryDirectory


# Generated at 2022-06-11 22:37:06.839110
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import makedirs
    from flutils.strutils import touch
    from flutils.sysutils import remove_all

    from ._base_test import BaseTest
    from ._base_test import each_valid_setup_dirs

    for setup_dir in each_valid_setup_dirs():
        with BaseTest.mock() as mock:
            mock.patch('os.path.expanduser', return_value=r'~')
            mock.patch('os.path.isfile', return_value=True)
            mock.patch('os.path.exists', return_value=True)
            mock.patch('os.path.dirname', return_value=str(setup_dir))
            mock.patch('os.path.basename', return_value='setup.py')

# Generated at 2022-06-11 22:37:09.567851
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the function each_sub_command_config."""

    from flutils import setup_utils

    for config in setup_utils.each_sub_command_config():
        print(config)

# Generated at 2022-06-11 22:37:15.222049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config())
    assert cmds


if __name__ == '__main__':
    print('pprint.pprint(each_sub_command_config()):')
    pprint.pprint(list(each_sub_command_config()))

# Generated at 2022-06-11 22:37:24.584309
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = list(each_sub_command_config())
    assert len(cmds) > 0
    cmd = cmds[0]
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert isinstance(cmd.name, str)
    assert isinstance(cmd.camel, str)
    assert isinstance(cmd.description, str)
    assert isinstance(cmd.commands, tuple)
    assert len(cmd.commands) > 0
    assert isinstance(cmd.commands[0], str)

if __name__ == '__main__':
    print(list(each_sub_command_config()))

# Generated at 2022-06-11 22:37:27.376579
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config():
        print(command)



# Generated at 2022-06-11 22:37:47.189301
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from flutils.misc import touch
    from flutils.pathutils import safe_touch
    with TemporaryDirectory() as tmp:
        base_path = os.path.join(tmp, 'flutils_setup_cfg')
        os.mkdir(base_path)
        path = os.path.join(base_path, 'setup.py')
        touch(path)
        path = os.path.join(base_path, 'setup.cfg')

# Generated at 2022-06-11 22:37:55.849625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = '/home/user/project'
    configs: List[SetupCfgCommandConfig] = []
    for config in each_sub_command_config(path):
        paths: List[str] = []
        for source in config.commands:
            path = source.replace('{setup_dir}', path)
            path = path.replace('{home}', os.path.expanduser('~'))
            paths.append(path)
        configs.append(config._replace(commands=tuple(paths)))

# Generated at 2022-06-11 22:38:01.728941
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../../')
    )
    for cfg in each_sub_command_config(path):
        print(cfg.camel)
        print(cfg.name)
        print(cfg.description)
        print(cfg.commands)
        print()

# Generated at 2022-06-11 22:38:11.384801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        next(each_sub_command_config())
    except FileNotFoundError:
        # We're running in unit test mode
        fn = os.path.join(os.path.dirname(__file__), '..', 'setup.cfg')
        yield from each_sub_command_config(fn)
    else:
        raise
        # We're running in run mode
        yield from each_sub_command_config()


if __name__ == '__main__':
    for config in test_each_sub_command_config():  # type: ignore
        print(config)

# Generated at 2022-06-11 22:38:23.839841
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.test_setupcfg import (
        PROJECT_PATH,
        FIXTURE_CONF_PATH
    )
    print(PROJECT_PATH)
    print(FIXTURE_CONF_PATH)
    for sub_command in each_sub_command_config(PROJECT_PATH):
        print(sub_command)


if __name__ == '__main__':
    import pprint
    config = ConfigParser()
    config.read('setup.cfg')
    # print(config.sections())
    # print(config.options('metadata'))
    pprint.pprint(dict(config.items('metadata')))
    print(_get_name(config, 'setup.cfg'))

    # for sub_command in each_sub_command_config():
    #     print(sub_command)

# Generated at 2022-06-11 22:38:27.619570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    for i, c in enumerate(each_sub_command_config()):
        print('c%d' % i)
        pprint(c)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:38:29.977935
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(setup_dir='tests/test_data/test-project'):
        print(cfg)

# Generated at 2022-06-11 22:38:38.666793
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests', 'fixtures', 'demo_project',
        'setup.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)
    format_kwargs = {
        'name': name
    }
    path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests', 'fixtures', 'demo_project',
        'setup_commands.cfg'
    )
    parser = ConfigParser()
    parser.read(path)

# Generated at 2022-06-11 22:38:44.563135
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    _dir = os.path.join(_dir, 'test')
    _dir = os.path.join(_dir, 'fixtures')
    _dir = os.path.join(_dir, 'no_cli')
    for config in each_sub_command_config(setup_dir=_dir):
        print(config)

# Generated at 2022-06-11 22:38:52.901438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import flutils.setup_utils as setup_utils
    this_dir = os.path.dirname(os.path.realpath(__file__))

    num_cmds = 0
    for config in setup_utils.each_sub_command_config(this_dir):
        num_cmds += 1
        assert config.camel == 'SphinxBuild'
        assert config.name == 'sphinx.build'

# Generated at 2022-06-11 22:39:27.254777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pathlib
    from tempfile import NamedTemporaryFile

    fd = None

# Generated at 2022-06-11 22:39:42.135278
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    class EachSubCommandConfigTest(unittest.TestCase):
        def test_sub_command_config(self):
            path = os.path.join(os.path.dirname(__file__), '..', '..')
            path = os.path.realpath(path)
            path = os.path.dirname(path)
            configs = list(each_sub_command_config(path))
            self.assertNotEqual(configs, [])
            for config in configs:
                self.assertNotEqual(config.camel, '')
                self.assertNotEqual(config.commands, ())
                self.assertNotEqual(config.description, '')
    return unittest.main(verbosity=2)


# Generated at 2022-06-11 22:39:53.815232
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import sys

    sys.path.append(os.path.dirname(__file__))
    dirname = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    assert os.path.isdir(dirname)
    for sub_command in each_sub_command_config(dirname):
        assert isinstance(sub_command, SetupCfgCommandConfig)
        assert sub_command.name == 'chi'


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:39:56.486399
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    # TODO: Add unit tests.
    pass



# Generated at 2022-06-11 22:40:08.339924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        assert sub_command.name
        assert sub_command.camel
        assert sub_command.description
        assert sub_command.commands
    # Create a new config file with the following content:
    #
    #     [setup.command.test]
    #     command = echo "testing..."
    #
    # Then, invoke the function again, which should yield the expected
    # sub command config.
    with open('setup_commands.cfg', 'w') as fd:
        fd.write('[setup.command.test]\n')
        fd.write('command = echo "testing..."\n')

# Generated at 2022-06-11 22:40:20.294412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        'setup_cfg_fixtures',
        'setup_cfg',
        'setup_cfg_no_command'
    )
    cfg_dir = os.path.dirname(setup_dir)

    def _assert(setup_dir, expected):
        itr = each_sub_command_config(setup_dir)
        out = list(itr)
        assert out == expected

    setup_dir = os.path.join(
        os.path.dirname(__file__),
        'setup_cfg_fixtures',
        'setup_cfg',
        'setup_cfg_no_command'
    )

# Generated at 2022-06-11 22:40:27.016600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config(__file__))
    assert len(configs) == 1
    config = configs[0]
    assert config.camel == 'MyPkg'
    assert config.name == 'mypkg'
    assert config.description == 'The "mypkg" package!'
    assert len(config.commands) == 1
    assert config.commands[0] == 'mypkg'



# Generated at 2022-06-11 22:40:34.380383
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock

    configs = [
        SetupCfgCommandConfig('command01', 'Command01', '', ()),
        SetupCfgCommandConfig('command02', 'Command02', '', ()),
        SetupCfgCommandConfig('command03', 'Command03', '', ())
    ]

    with unittest.mock.patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        with unittest.mock.patch('os.path.isfile') as mock_isfile:
            mock_isfile.side_effect = [True] * 2
            with unittest.mock.patch('flutils.setuputils.each_setup_cfg_command') as mock_each_setup_cfg_command:
                mock_each_setup_cfg_command

# Generated at 2022-06-11 22:40:44.091011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmds = [
        (
            ("setup.command.hello", "hello"),
            (
                "name = {name}"
                "\ncommand = echo \"Hello from {name}!\""
            )
        ),
        (
            ("setup.command.foo.bar", "foo.bar"),
            (
                "description = foo bar"
                "\ncommands = "
                "\n    echo foo bar first"
                "\n    echo foo bar second"
                "\n    echo foo bar third"
            )
        ),
        (
            ("setup.command.foo.baz", "foo.baz"),
            "name = foo.baz"
        ),
    ]
    test_dir = os.path.join(os.path.dirname(__file__), 'setup_config_test')
    setup_cfg

# Generated at 2022-06-11 22:40:56.546760
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import temp_directory
    from flutils.pathutils import relpath

    # Setup the temp directory
    with temp_directory() as temp_dir:
        # Create a setup.cfg file
        setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        setup_cfg_contents = '''
            [metadata]
            name = flutils
        '''.strip()
        with open(setup_cfg_path, 'w') as f:
            f.write(setup_cfg_contents)

        # Create a setup_commands.cfg file
        sub_cfg_path = os.path.join(temp_dir, 'setup_commands.cfg')

# Generated at 2022-06-11 22:41:57.204833
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # This unit test's directory
    setup_dir = os.path.abspath(os.path.dirname(__file__))
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
    for config in each_sub_command_config(setup_dir=setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert len(config) == 4
        if config.name == 'defaults':
            assert config.camel == 'Defaults'
            assert config.description == (
                'Lists the default commands from setup.cfg.'
            )
            assert len(config.commands) == 2

# Generated at 2022-06-11 22:42:08.881112
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    results = list(each_sub_command_config(setup_dir))
    assert len(results) == 2

# Generated at 2022-06-11 22:42:14.273477
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    dir = os.path.abspath(os.path.dirname(__file__))
    test_dir = os.path.join(dir, 'res', 'test_pkg')

    assert list(each_sub_command_config(test_dir)) == [
        SetupCfgCommandConfig('test', 'Test', 'hello world!', ('foo',)),
        SetupCfgCommandConfig('bar.test', 'BarTest', 'bye world!', ('bar',))
    ]

# Generated at 2022-06-11 22:42:24.605412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.environ['FLUTILS_TEST'] = '1'
    import flutils.pythonsetup
    from flutils.unittestutil import _generate_test_cases

    path = os.path.dirname(flutils.pythonsetup.__file__)
    path = os.path.realpath(path)
    for test_case in _generate_test_cases(each_sub_command_config,
                                          [path],
                                          SetupCfgCommandConfig):
        yield test_case
    del os.environ['FLUTILS_TEST']


# Generated at 2022-06-11 22:42:28.927800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = list(each_sub_command_config(setup_dir='./tests/examples/django-app'))
    assert len(config) == 1
    idx = 0
    cfg = config[idx]
    assert cfg.name == 'nm.update_requirements'
    assert cfg.description == 'Update the requirements.txt file.'
    assert tuple(cfg.commands) == ('pip-compile',)

# Generated at 2022-06-11 22:42:36.990776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = list(each_sub_command_config())
    assert len(out) == 2
    assert out[0].name == 'setup.commands.build_sphinx'
    assert out[0].camel == 'SetupCommandsBuildSphinx'
    assert out[0].description == 'Build Sphinx documentation.'
    assert out[0].commands == (
        "python -m sphinx -M html \"docs\" \"{home}/build/docs\"",
    )
    assert out[1].name == 'setup.commands.check_docs'
    assert out[1].camel == 'SetupCommandsCheckDocs'
    assert out[1].description == 'Check for errors in the docs.'

# Generated at 2022-06-11 22:42:49.840915
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    good_dir = os.path.dirname(os.path.abspath(__file__))
    good_dir = os.path.dirname(good_dir)
    good_dir = os.path.dirname(good_dir)
    bad_dir = '/bogus'
    bad_dir2 = os.path.join(good_dir, 'bogus')
    setup_dir = os.path.join(good_dir, '..')

    for func in (
            each_sub_command_config,
            lambda: list(each_sub_command_config(setup_dir))
    ):
        configs = list(func())
        assert configs
        assert 'test' in (c.name for c in configs)
        assert 'tests' in (c.name for c in configs)
        assert 1

# Generated at 2022-06-11 22:43:00.211100
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _there_and_back_again(
            setup_dir: str,
            path: os.PathLike,
    ) -> None:
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        parser = ConfigParser()
        parser.read(setup_cfg_path)
        name = _get_name(parser, setup_cfg_path)


# Generated at 2022-06-11 22:43:05.270862
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pyutils import get_module_dir
    from flutils.pathutils import each_dir_up

    path = get_module_dir()
    yield from each_dir_up(
        path,
        lambda path: os.path.isfile(os.path.join(path, 'setup.py'))
    )



# Generated at 2022-06-11 22:43:16.952630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkg = 'flutils.tests.setup'
    out = list(
        each_sub_command_config(os.path.dirname(pkg.__file__))
    )

# Generated at 2022-06-11 22:44:52.989837
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for num, config in enumerate(each_sub_command_config()):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name
        assert config.camel
        assert config.description
        assert isinstance(config.commands, tuple)
        assert config.commands
        assert config.commands[0]
    assert num > 0

# Generated at 2022-06-11 22:44:54.707794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass


__all__ = ('each_sub_command_config',)

# Generated at 2022-06-11 22:44:56.559191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Create a test case
    pass

# Generated at 2022-06-11 22:45:06.609184
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    actual = [i for i in each_sub_command_config()]
    expected = [
        SetupCfgCommandConfig(
            'setup.command.my_cmd',
            'SetupCommandMyCmd',
            'My custom command to do a thing.',
            ('echo "hello, world!"',)
        ),
        SetupCfgCommandConfig(
            'setup.command.my_other_cmd',
            'SetupCommandMyOtherCmd',
            'My other custom command to do a thing.',
            ('echo "goodbye, world!"',)
        ),
        SetupCfgCommandConfig(
            'setup.command.my_nested.cmd',
            'SetupCommandMyNestedCmd',
            'My nested custom command to do a thing.',
            ('echo "hello from nested, world!"',)
        )
    ]
   

# Generated at 2022-06-11 22:45:19.653542
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def count_commands(iterable):
        return sum(1 for _ in _each_setup_cfg_command_section(iterable))

    fpath = os.path.join(os.path.dirname(__file__), 'setup.cfg')
    parser = ConfigParser()
    parser.read(fpath)
    assert count_commands(parser) == 1

    parser = ConfigParser()
    fpath = os.path.join(os.path.dirname(__file__), 'setup_commands.cfg')
    parser.read(fpath)
    assert count_commands(parser) == 5

    fpath = os.path.join(os.path.dirname(__file__), 'empty_setup.cfg')
    parser = ConfigParser()
    parser.read(fpath)

# Generated at 2022-06-11 22:45:33.046743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def test_file(path: str) -> None:
        assert os.path.isfile(path)

    def test_dir(path: str) -> None:
        assert os.path.isdir(path)

    def test_setup_dir(path: str) -> None:
        test_dir(path)
        test_file(os.path.join(path, 'setup.py'))
        test_file(os.path.join(path, 'setup.cfg'))

    def test_setup_commands_file(setup_dir: str) -> None:
        path = os.path.join(setup_dir, 'setup_commands.cfg')
        test_file(path)
        parser = ConfigParser()
        parser.read(path)
        assert parser.sections()

    test_setup_dir('.')



# Generated at 2022-06-11 22:45:34.524124
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-11 22:45:43.423094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # setup_dir = '/home/ericvsmith/PycharmProjects/flutils'
    setup_dir = '/home/ericvsmith/PycharmProjects/flutils/flutils'
    for config in each_sub_command_config(setup_dir):
        print(config)
    return 0


if __name__ == '__main__':
    exit(test_each_sub_command_config())

# Generated at 2022-06-11 22:45:51.749417
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        td = os.path.join(td, 'setup_commands.cfg')
        with open(td, 'w+') as fh:
            fh.write(
                """
[setup.command.clean]
command = rm -rf build
command = rm -rf dist
command = rm -rf *.egg-info
                """.strip()
            )
        commands = tuple(each_sub_command_config(os.path.dirname(td)))
        assert len(commands) == 1
        command = commands[0]
        assert command.name == 'clean'
        assert command.commands == (
            'rm -rf build',
            'rm -rf dist',
            'rm -rf *.egg-info'
        )

# Generated at 2022-06-11 22:46:01.667808
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config(os.path.realpath(__file__)):
        print(config)
    print()

    setup_dir = os.path.realpath(__file__)
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.join(setup_dir, '../fixtures/setup_commands_test')
    setup_dir = os.path.realpath(setup_dir)
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()