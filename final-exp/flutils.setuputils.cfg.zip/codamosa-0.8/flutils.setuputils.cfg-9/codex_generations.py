

# Generated at 2022-06-11 22:36:22.337361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    parser = ConfigParser()
    parser.read('tests/setup.cfg')
    name = _get_name(parser, 'tests/setup.cfg')
    format_kwargs = {
        'setup_dir': 'tests',
        'home': os.path.expanduser('~'),
        'name': name
    }
    yield from _each_setup_cfg_command(parser, format_kwargs)



# Generated at 2022-06-11 22:36:30.639612
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import (
        PytestUtils,
    )

    utils = PytestUtils(__file__)
    proj_dir = utils.get_proj_dir('flutils')
    for cmd_cfg in each_sub_command_config(setup_dir=proj_dir):
        assert cmd_cfg.name
        assert cmd_cfg.camel
        assert cmd_cfg.commands
        assert cmd_cfg.description


if __name__ == '__main__':
    print('Testing', __file__)
    test_each_sub_command_config()
    print('Test Completed', __file__)

# Generated at 2022-06-11 22:36:42.680101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from sys import executable  # nosec
    from os import path

    from flutils.setuputils import each_sub_command_config

    path.join(
        path.dirname(path.abspath(executable)),
        'setup_commands.cfg'
    )
    test_dir = path.join(
        path.dirname(path.abspath(executable)),
        '..',
        '..',
        'setup'
    )
    gen = each_sub_command_config(test_dir)


# Generated at 2022-06-11 22:36:51.009776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with (os.path.join(_get_pwd(), 'setup.cfg')).open(mode='rt') as f:
        print("\n\n'%s'\n%s\n" % (cast(str, _get_pwd()), f.read()))
    os.chdir(_get_pwd())
    print("\n\n'%s'\n%s" % ('each_sub_command_config()',
                            list(each_sub_command_config())))

# Generated at 2022-06-11 22:36:52.612429
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd in each_sub_command_config('.'):
        assert sub_cmd

# Generated at 2022-06-11 22:37:05.845823
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import abspath, exists
    from .. __init__ import __version__

    this_file = os.path.abspath(__file__)
    this_file = os.path.normpath(this_file)
    setup_py_path = os.path.realpath(os.path.join(
        os.path.dirname(this_file), '..', '..', '..', 'setup.py'
    ))
    assert exists(setup_py_path)

    this_dir = os.path.dirname(this_file)
    setup_cfg_path = os.path.realpath(os.path.join(
        this_dir, '..', 'setup.cfg'
    ))

# Generated at 2022-06-11 22:37:15.350495
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(os.path.dirname(__file__))
    setup_cfg_path = os.path.join(here, 'setup.cfg')
    setup_commands_cfg_path = os.path.join(here, 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)
    format_kwargs = {
        'setup_dir': here,
        'home': os.path.expanduser('~'),
        'name': name
    }
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    parser.read(setup_commands_cfg_path)

# Generated at 2022-06-11 22:37:27.298505
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import textwrap
    root = tempfile.mkdtemp()
    sub_dir = os.path.join(root, 'foo')
    os.mkdir(sub_dir)
    setup_cfg_path = os.path.join(sub_dir, 'setup.cfg')
    setup_py_path = os.path.join(sub_dir, 'setup.py')
    with open(setup_cfg_path, 'w') as fd:
        fd.write(textwrap.dedent('''\
            [metadata]
            name = test_package
        '''))

# Generated at 2022-06-11 22:37:30.377587
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(list(each_sub_command_config()))
    import os
    print(list(each_sub_command_config(os.path.dirname(__file__))))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:37:37.748002
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import textwrap
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        basename = os.path.basename(__file__)
        setup_file = os.path.join(tmpdir, 'setup.py')
        setup_cfg_file = os.path.join(tmpdir, 'setup.cfg')
        setup_cmd_file = os.path.join(tmpdir, 'setup_commands.cfg')
        with open(setup_file, 'w') as fp:
            fp.write("#!/usr/bin/env python\n")
            fp.write("\n")
            fp.write("# -*- coding: utf-8 -*-\n")
            fp.write("\n")

# Generated at 2022-06-11 22:37:57.236904
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    from io import StringIO
    import sys

    test_path = os.path.dirname(__file__)
    test_dir = os.path.join(test_path, '..', 'test')
    test_dir = os.path.abspath(test_dir)

    sys.stdout = StringIO()

    def _with_patch(patch_path: str, args: List[str]):
        patch_path = os.path.join(test_dir, patch_path)
        patch_path = os.path.realpath(patch_path)

# Generated at 2022-06-11 22:38:07.334977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import (
        SubCommandConfig,
        each_sub_command_config,
    )
    from os.path import abspath, dirname
    from sys import executable

    path = abspath(__file__)
    path = dirname(path)
    setup_dir = dirname(path)

    sub_command_configs: Dict[str, SubCommandConfig] = {}
    for config in each_sub_command_config(setup_dir):
        config = cast(SetupCfgCommandConfig, config)
        sub_command_config = SubCommandConfig(
            config.name,
            config.camel,
            config.description,
            config.commands,
        )
        sub_command_configs[config.name] = sub_command_config

# Generated at 2022-06-11 22:38:11.928832
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    assert isinstance(gen, Generator)
    config = next(gen)
    assert isinstance(config, SetupCfgCommandConfig)
    line = ' '.join([config.camel] + list(config.commands))
    print(f'    {line}')

# Generated at 2022-06-11 22:38:24.183603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from tempfile import TemporaryDirectory
    from flutils.testutils import delete_dirs
    from flutils.fileutils import write_to_file
    from flutils.textutils import normalize_text

    # Test with no configuration file
    with TemporaryDirectory() as tempdir:
        tdir = os.path.join(tempdir, 'test_package')
        rdir = os.path.join(
            os.path.dirname(__file__), '..', '..', 'tests', 'data'
        )
        delete_dirs(tdir)
        shutil.copytree(rdir, tdir)
        with pytest.raises(FileNotFoundError):
            assert tuple(each_sub_command_config(tdir)) == ()

    # Test with minimal setup_commands.cfg file
   

# Generated at 2022-06-11 22:38:34.222300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """unit test for function each_sub_command_config"""
    with open('setup_commands.cfg', 'w') as f:
        f.write(
        """
[metadata]
name = {name}

[setup.command.deploy]
description = Build the source and deploy it to PyPI
commands =
    rm -rf build/
    rm -rf dist/
    python setup.py sdist bdist_wheel
    twine upload dist/*
        """
        )
    test_dir = os.path.abspath(os.curdir)
    setup_dir = os.path.join(test_dir, 'test_setup_dir')
    os.makedirs(setup_dir, exist_ok=True)
    os.chdir(setup_dir)

# Generated at 2022-06-11 22:38:40.871800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    from os import getcwd
    from sys import argv

    if len(argv) > 1:
        test_each_sub_command_config()
    else:
        print(each_sub_command_config(getcwd()))

# Generated at 2022-06-11 22:38:50.972607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    val = list(each_sub_command_config('.'))
    assert len(val) == 2
    assert val[0].name == 'my.custom.cmd.1'
    assert val[0].camel == 'MyCustomCmd1'
    assert val[0].description
    assert len(val[0].commands) == 1
    assert val[0].commands[0]

    assert val[1].name == 'my.custom.cmd.2'
    assert val[1].camel == 'MyCustomCmd2'
    assert val[1].description
    assert len(val[1].commands) == 2
    assert val[1].commands[0]
    assert val[1].commands[1]

# Generated at 2022-06-11 22:39:00.478010
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import join

    from flutils.pathutils import _in_tmp_dir

    from flutils.scripts import (
        _get_sub_command_config_names,
        _get_sub_command_config_dataclass_str,
    )

    orig_dir = join(os.path.dirname(__file__), '..')
    with _in_tmp_dir() as tmp_dir:
        setup_cfg_path = join(tmp_dir, 'setup.cfg')
        shutil.copy(join(orig_dir, 'setup.cfg'), setup_cfg_path)
        names = list(_get_sub_command_config_names(tmp_dir))
        configs = list(each_sub_command_config(setup_dir=tmp_dir))

# Generated at 2022-06-11 22:39:08.178489
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    curr_dir = os.path.abspath(os.path.dirname(__file__))
    sub_command_configs = list(each_sub_command_config(curr_dir))
    assert len(sub_command_configs) == 2
    assert sub_command_configs[0].name == "test_1"
    assert sub_command_configs[1].name == "test_2"

# Generated at 2022-06-11 22:39:09.768570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test 1
    subcommands = tuple(each_sub_command_config())
    assert(subcommands)

# Generated at 2022-06-11 22:39:34.698942
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for command_config in each_sub_command_config(setup_dir):
        break

# Generated at 2022-06-11 22:39:45.842905
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .tests import _get_tmp_path

    def _test(setup_dir: os.PathLike) -> None:
        commands: List[List[str]] = [
            ['cmd1', 'cmd2', 'cmd3'],
            ['cmd4', 'cmd5', 'cmd6']
        ]
        for i, lst in enumerate(commands, 1):
            assert tuple(lst) == SetupCfgCommandConfig(
                'c%s' % i,
                'C%s' % i,
                '',
                tuple(lst)
            ).commands

        failed: bool = False
        try:
            next(each_sub_command_config(setup_dir))
        except Exception:
            failed = True
        assert failed is True


# Generated at 2022-06-11 22:40:00.127155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    isfile = os.path.isfile
    join = os.path.join
    dirname = os.path.dirname
    name = '{{name}}'
    script_path = os.path.realpath(__file__)
    setup_dir = dirname(script_path)
    setup_py_path = join(setup_dir, 'setup.py')
    setup_cfg_path = join(setup_dir, 'setup.cfg')
    setup_cmds_cfg_path = join(setup_dir, 'setup_commands.cfg')
    assert isfile(setup_py_path)
    assert isfile(setup_cfg_path)
    assert isfile(setup_cmds_cfg_path)
    assert setup_py_path.endswith('setup.py')
    assert setup_cfg_path.endsw

# Generated at 2022-06-11 22:40:10.875600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile
    import shutil
    import os
    import os.path as osp

    class TestSetup(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.setup_dir = osp.join(self.dir, 'test_setup')
            os.makedirs(self.setup_dir)
            os.chdir(self.setup_dir)

        def tearDown(self):
            if self.dir:
                os.chdir(self.dir)
                shutil.rmtree(self.dir)
                self.dir = None

        def test_empty(self):
            """Empty directory."""
            with self.assertRaises(FileNotFoundError):
                each_sub_command_config()

       

# Generated at 2022-06-11 22:40:22.967123
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.join(
        os.path.dirname(__file__),
        'tests',
        'test_setup_cfg',
    )
    assert each_sub_command_config(test_setup_dir) == (
        SetupCfgCommandConfig(
            'add-date-file',
            'AddDateFile',
            'Adds the current date and time to a file.',
            ('date >> {home}/setup_cmds_add_date.txt', )
        ),
        SetupCfgCommandConfig(
            'no-args',
            'NoArgs',
            'This command does not have any arguments.',
            ('echo No args.', 'date >> {home}/setup_cmds_no_args.txt')
        )
    )

# Generated at 2022-06-11 22:40:29.092868
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n\nUnit test for function each_sub_command_config\n')
    from flutils.systemutils import (
        get_temp_dir,
        remove_tree,
    )
    from flutils.pathutils import (
        Path,
        each_p,
    )
    from flutils.strutils import (
        indent,
    )
    from flutils.pyutils import (
        dump_dir,
    )

    name = 'test_each_sub_command_config'
    tmpdir = Path(get_temp_dir(name))
    remove_tree(tmpdir)
    dump_dir(__file__, tmpdir)

# Generated at 2022-06-11 22:40:41.359039
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    def do_test(
            fn: Callable,
            expected: Tuple[SetupCfgCommandConfig, ...]
    ) -> None:
        configs = list(fn())
        out = pprint.pformat(configs, width=1)
        assert configs == expected, out

# Generated at 2022-06-11 22:40:49.096197
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config('../')
    assert isinstance(gen, Generator)
    assert next(gen) == SetupCfgCommandConfig(
        'build',
        'BuildPackage',
        'Build source and wheel package.',
        (
            'python setup.py sdist bdist_wheel',
        )
    )
    assert next(gen) == SetupCfgCommandConfig(
        'build.install',
        'BuildAndInstallPackage',
        'Build source and wheel package, then install the package.',
        (
            'python setup.py sdist bdist_wheel',
            'twine upload dist/*',
            'pip install -U {name}',
        )
    )

# Generated at 2022-06-11 22:41:00.108595
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #
    # Test a project's setup.cfg file with a [setup.command.foo] section
    #
    # Note that the following code is unit testing a function which can
    # unit test itself.
    test_dir = os.path.dirname(__file__)
    out = list(each_sub_command_config(os.path.join(test_dir, 'fixture')))
    assert out[0] == SetupCfgCommandConfig(
        name='foo',
        camel='Foo',
        description='Foo Action',
        commands=(
            'echo "Foo: %(name)s"',
            'echo "Foo Command: %(command_name)s"',
            'echo "Foo Setup Dir: %(setup_dir)s"',
        )
    )

# Generated at 2022-06-11 22:41:09.037845
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .utils import (
        iter_to_list,
    )
    from flutils.strutils import (
        iter_to_str
    )

    setup_dir = os.path.dirname(__file__)
    commands = iter_to_list(each_sub_command_config(setup_dir))

    with open(os.path.join(setup_dir, 'tests', 'expected',
                           'sub_commands.txt'), 'r') as f:
        expected = f.read() + '\n'
        expected = expected.format(setup_dir=setup_dir)
        expected = expected.splitlines()
        expected = list(filter(len, expected))

    actual = iter_to_str(commands,
                         '{camel}:{description}\n\t{commands}'.format)
   

# Generated at 2022-06-11 22:42:04.851606
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    script_path = pathlib.Path(__file__).parent
    for setup_cfg_command in each_sub_command_config(script_path):
        print(repr(setup_cfg_command))
        assert isinstance(setup_cfg_command, SetupCfgCommandConfig)
        assert isinstance(setup_cfg_command.name, str)
        assert isinstance(setup_cfg_command.camel, str)
        assert isinstance(setup_cfg_command.description, str)
        assert isinstance(setup_cfg_command.commands, tuple)
        assert len(setup_cfg_command.commands) >= 1


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:42:15.316700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = tempfile.TemporaryDirectory()
    setup_dir_name = setup_dir.name

    with open(os.path.join(setup_dir_name, 'setup.py'), 'w') as fd:
        fd.write('import setuptools\n'
                 'setuptools.setup()\n')

    with open(os.path.join(setup_dir_name, 'setup.cfg'), 'w') as fd:
        fd.write('[metadata]\n'
                 'name = test_each_sub_command_config\n'
                 '\n'
                 '[options]\n'
                 'packages = find:')

    with open(os.path.join(setup_dir_name, 'setup_commands.cfg'), 'w') as fd:
        fd.write

# Generated at 2022-06-11 22:42:21.061301
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config(setup_dir=__file__):
        assert isinstance(cfg, SetupCfgCommandConfig)
    assert True


if __name__ == '__main__':
    exit(test_each_sub_command_config())

# Generated at 2022-06-11 22:42:27.152376
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    g = each_sub_command_config(
        os.path.join(os.path.dirname(__file__), 'data', 'setup_dir')
    )
    assert next(g) == SetupCfgCommandConfig(
        'setup.commands.test',
        'Test',
        'Lorem ipsum dolor',
        ('this is a command', 'this is another command')
    )

# Generated at 2022-06-11 22:42:34.995810
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    import setup_commands as mod

    def mock_validate_setup_dir(setup_dir: str) -> None:
        if os.path.exists(setup_dir) is False:
            raise FileNotFoundError(
                "The given 'setup_dir' of %r does NOT exist."
                % setup_dir
            )
        if os.path.isdir(setup_dir) is False:
            raise NotADirectoryError(
                "The given 'setup_dir' of %r is NOT a directory."
                % setup_dir
            )
        path = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-11 22:42:46.770160
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    start_dir = os.getcwd()
    from os import chdir, pardir, makedirs
    from os.path import join
    from tempfile import TemporaryDirectory
    from unittest.mock import patch

    from flutils.pathutils import find_up

    with TemporaryDirectory() as td:
        cur_dir = os.path.join(td, 'flutils')
        makedirs(cur_dir)
        chdir(cur_dir)
        with patch('os.path.expanduser') as mock_expanduser:
            mock_expanduser.return_value = os.path.join(td, 'flutils_home')
            with open('setup.py', 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-11 22:42:51.346390
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock
    with unittest.mock.patch('configparser.ConfigParser.read') as mock:
        mock.side_effect = lambda x: print(x)
        each_sub_command_config()

# Generated at 2022-06-11 22:42:55.956427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'setup'
    )
    print()
    for sub_cmd in each_sub_command_config(setup_dir=setup_dir):
        print(sub_cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:43:07.311458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import os.path
    import sys
    import tempfile

    from flutils.pathsutils import ensure_dir
    from flutils.strutils import comma_join

    path = os.path.dirname(inspect.getfile(sys.modules[__name__]))
    path = os.path.join(path, 'test')
    path = os.path.join(path, 'data')
    path = os.path.join(path, 'each_setup_cfg_section')

    wd = tempfile.mkdtemp()
    for p in (
            'setup.cfg',
            'setup_commands.cfg',
            'setup.py',
            'setup_commands.py',
    ):
        path2 = os.path.join(path, p)

# Generated at 2022-06-11 22:43:13.873844
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_commands = set()
    for cmd in each_sub_command_config(setup_dir='../..'):
        setup_commands.add(cmd.camel)
    assert setup_commands == {
        'Check',
        'Clean',
        'Coverage',
        'Docs',
        'Install',
        'Lint',
        'Packages',
        'Requirements',
        'Test',
        'Upgrade',
    }

# Generated at 2022-06-11 22:44:20.466487
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""

    def _each_sub_command_config_test(setup_dir: str) -> None:
        print('============================================')
        print('setup_dir: %s' % setup_dir)
        print('------------------------')
        for config in each_sub_command_config(setup_dir):
            print(config)
        print('------------------------')
        print('setup_dir: %s' % setup_dir)
        print('============================================')

    print('Testing each_sub_command_config using:')
    print('    examples/flutils/setup.py')
    print('    examples/flutils/setup_commands.cfg')
    _each_sub_command_config_test('examples/flutils')
    print('')


# Generated at 2022-06-11 22:44:23.555406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing each_sub_command_config...')
    import pprint
    pprint.pprint(list(each_sub_command_config()))
    print('...done.')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:27.286664
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    sys.stdout = io.StringIO()

    for setup_cfg_command in each_sub_command_config(
        setup_dir='.'
    ):
        print(setup_cfg_command)

    sys.stdout = sys.__stdout__


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:44:33.520289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        pyfile = os.path.join(tmpdirname, 'setup.py')
        shutil.copy(
            os.path.join(os.path.dirname(__file__), 'setup.py'),
            pyfile
        )
        cfgfile = os.path.join(tmpdirname, 'setup.cfg')
        with open(cfgfile, 'w') as fh:
            fh.write('[metadata]\n')
            fh.write('name=test-project\n')
            fh.write('\n')
            fh.write('[setup.command.1st]\n')
            fh.write('name=C\n')
            fh.write('description=D\n')
            fh

# Generated at 2022-06-11 22:44:43.953518
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    scc = {}
    for item in each_sub_command_config():
        scc[item.name] = {
            'name': item.name,
            'camel': item.camel,
            'description': item.description,
            'commands': '\n'.join(item.commands)
        }

    assert 'cigarbox.setup.aliases' in scc
    assert 'cigarbox.setup.api' in scc
    assert 'cigarbox.setup.clean' in scc
    cigarglass = scc['cigarbox.setup.clean']

# Generated at 2022-06-11 22:44:48.700644
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(
        "function each_sub_command_config()"
    )
    # noinspection PyProtectedMember
    setup_cfg_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_cfg_dir):
        print(config.name)
        print('\t%s\n' % config.description)


test_each_sub_command_config()

# Generated at 2022-06-11 22:44:57.728297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.realpath(os.path.join(path, '..'))
    path = os.path.join(path, 'setup.py')
    path = os.path.realpath(path)
    path = os.path.dirname(path)
    it = each_sub_command_config(path)
    for i in it:
        print(i)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-11 22:45:07.596541
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # create a config file
    with tempfile.TemporaryDirectory() as tmpdirname:
        setup_dir = tmpdirname
        setup_dir = os.path.join(setup_dir, 'setup.py')
        with open(setup_dir, 'w') as fd:
            fd.write('')

        setup_dir = os.path.dirname(setup_dir)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fd:
            fd.write('''
[metadata]
name = flutils_testing
            ''')

        setup_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-11 22:45:11.257426
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def run():
        for sub_command_config in each_sub_command_config():
            print(sub_command_config)
    run()



# Generated at 2022-06-11 22:45:22.083247
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils
