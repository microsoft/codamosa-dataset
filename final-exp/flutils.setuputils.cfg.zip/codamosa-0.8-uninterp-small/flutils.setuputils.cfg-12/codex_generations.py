

# Generated at 2022-06-25 17:41:47.449927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)

    setup_cfg_command_configs = each_sub_command_config(setup_dir)
    assert list(setup_cfg_command_configs) == []

# Generated at 2022-06-25 17:41:48.503554
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config():
        pass

# Generated at 2022-06-25 17:41:50.479603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config('/Users/dcklein/repos/flutils3-venv'):
        print(setup_cfg_command_config)

# Generated at 2022-06-25 17:41:54.719005
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '.\\test_flutils\\setup_dir'
    result = each_sub_command_config(setup_dir)
    assert next(result).name == "foo.bar"
    assert next(result).name == "bar.foo"
    assert next(result).name == "foo-bar"

# Generated at 2022-06-25 17:42:04.795374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    import sys
    import unittest

    sys.path.insert(0, os.path.abspath('..'))

    from flutils import setupcfg

    class TestCase(unittest.TestCase):
        """Each test method represents a use case.
        """
        @classmethod
        def setUpClass(cls):
            cls.config_path = os.path.abspath(
                os.path.join(os.path.dirname(__file__), 'flutils.cfg')
            )
            cls.config_dir = os.path.abspath('../flutils')
            cls.config_package = 'flutils'


# Generated at 2022-06-25 17:42:12.349539
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n[+] Unit test for each_sub_command_config')
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def test_each_sub_command_config(self):
            cnt = 0
            for _ in each_sub_command_config():
                cnt += 1
            self.assertGreater(cnt, 0)

    suite = unittest.TestSuite()
    suite.addTest(TestEachSubCommandConfig('test_each_sub_command_config'))
    unittest.TextTestRunner().run(suite)



# Generated at 2022-06-25 17:42:21.847190
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import setup_commands

    def _test(
        setup_dir: str
    ) -> List[SetupCfgCommandConfig]:
        lst = []
        for cfg in each_sub_command_config(setup_dir):
            lst.append(cfg)
        return lst

    setup_dir = None
    actual = _test(setup_dir)
    assert len(actual) == 3
    # with open(os.path.join(setup_dir, 'setup.cfg')) as fp:
    #     expected = fp.read()
    # assert actual == """
    # """.strip()
    assert actual[0].name == 'cmd_0'
    assert actual[0].camel == 'Cmd0'
    assert actual[0].description == 'test cmd_0'

# Generated at 2022-06-25 17:42:27.065035
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    '''
    :return:
    '''
    for config in each_sub_command_config():
        print("  Name:", config.name)
        print("  Camel:", config.camel)
        print("  Description:", config.description)
        for command in config.commands:
            print("  Command:", command)
        print("")

# Generated at 2022-06-25 17:42:31.192348
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.test_project.test_module import test_module_0
    setup_cfg_command_config_0 = SetupCfgCommandConfig(
        name='',
        camel='',
        description='',
        commands=tuple()
    )
    test_module_0.test_case_0()

# Generated at 2022-06-25 17:42:38.775004
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    g = each_sub_command_config()
    sub_commands: List[SetupCfgCommandConfig] = list(g)
    assert len(sub_commands) == 2
    sub_command: SetupCfgCommandConfig = sub_commands[0]
    assert sub_command.name == 'sync.extras'
    assert sub_command.camel == 'SyncExtras'
    assert sub_command.description == \
        'synchronizes the project\'s list of extra requirements (req)'
    assert sub_command.commands == \
        ('sync-extras', 'sync-req')


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:46.194121
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:42:51.442448
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Unit test for each_sub_command_config
    """
    # Test case 0
    # test_case_0()

    # Test case 1
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = len(var_0)
    int_0 = -10
    var_2 = var_0[int_0]



# Generated at 2022-06-25 17:42:52.221849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config.

    Intentionally blank.
    """
    pass

# Generated at 2022-06-25 17:43:03.763902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    # assert isinstance(var_0, list)
    var_1 = len(var_0)
    int_0 = -18
    var_2 = var_0[int_0]
    # assert isinstance(var_2, SetupCfgCommandConfig)
    bool_0 = hasattr(var_2, 'commands')
    # assert bool_0
    bool_1 = isinstance(var_2.commands, tuple)
    # assert bool_1
    var_3 = var_2.commands
    int_1 = len(var_3)
    # assert int_1
    int_2 = var_1 + int_0
    # assert int_2
    str_0 = var_2

# Generated at 2022-06-25 17:43:04.779713
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:10.859559
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None
    # Test for an exception
    try:
        each_sub_command_config(
            setup_dir = setup_dir,
        )
    except FileNotFoundError as exception_0:
        var_3 = exception_0
    setup_dir = 'C:\\Users\\jbuhler\\git\\flutils\\setup_dir'
    assert each_sub_command_config(
        setup_dir = setup_dir,
    ) is not None


# Generated at 2022-06-25 17:43:14.735846
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config()."""
    from pytest import raises
    from sys import exc_info

    with raises(FileNotFoundError):
        test_case_0()
    test_case_0()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-25 17:43:24.298601
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test with correct input
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)

    if len(var_0) != 1:
        return False

    if var_0[0].camel != 'Test':
        return False

    if var_0[0].description != 'Runs unit tests.':
        return False

    if var_0[0].name != 'test':
        return False

    if var_0[0].commands != ('python -m unittest discover',):
        return False

    # Test with invalid input
    generator_1 = each_sub_command_config('/')
    var_1 = list(generator_1)



# Generated at 2022-06-25 17:43:32.521687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    var_1 = next(var_0)
    import inspect
    var_2 = inspect.getsource(var_1.__class__)
    var_3 = var_1.name
    var_4 = var_1.camel
    var_5 = var_1.description
    var_6 = var_1.commands
    # START: Call the function under test.
    # var_7 = each_sub_command_config(setup_dir='C:\\dev\\flutils')
    var_7 = each_sub_command_config()
    # END: Call the function under test.
    var_8 = type(var_7)
    var_9 = next(var_7)
    var_10 = var_9.name
    var_11 = var

# Generated at 2022-06-25 17:43:39.727799
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)


if __name__ == '__main__':
    print(
        'Running unit tests for '
        'the "py_setup_commands.setup_commands" module:'
    )
    print('    each_sub_command_config:', end='')
    test_each_sub_command_config()
    print(' OK')
    print('    test_case_0:', end='')
    test_case_0()
    print(' OK')
    print('Tests passed.')

# Generated at 2022-06-25 17:43:50.615824
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/'
    generator_0 = each_sub_command_config(setup_dir)
    if __name__ == "__main__":
        for i in generator_0:
            print(i)


if __name__ == "__main__":
    print("Running test cases for each_sub_command_config")
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:02.899875
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'test_case_setup')
    results = list(each_sub_command_config(setup_dir))
    assert len(results) == 3
    assert results[0].name == 'deploy'
    assert results[0].camel == 'Deploy'
    assert results[0].description == 'Package and upload to PyPi.'
    assert len(results[0].commands) == 5
    assert results[1].name == 'install'
    assert results[1].camel == 'Install'
    assert results[1].description == 'Install the project.'
    assert len(results[1].commands) == 2
    assert results[2].name == 'publish'
    assert results[2].camel == 'Publish'

# Generated at 2022-06-25 17:44:04.622422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:05.417105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:44:11.640102
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import os.path
    import shutil
    import stat
    import tempfile

    # Setup
    dir_0 = tempfile.mkdtemp('flutils-test-each_sub_command_config')

    dir_1 = os.path.join(dir_0, 'flutils')
    dir_2 = os.path.join(dir_1, '__pycache__')

    os.mkdir(dir_1)
    os.mkdir(dir_2)

    path_0 = os.path.join(dir_0, 'setup.cfg')
    path_1 = os.path.join(dir_0, 'setup.py')
    path_2 = os.path.join(dir_0, '__pycache__')


# Generated at 2022-06-25 17:44:20.679949
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError as e:
        msg = str(e)

# Generated at 2022-06-25 17:44:24.010700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        var_0 = None
    else:
        var_0 = True
    assert var_0


if __name__ == "__main__":
    print(test_each_sub_command_config())

# Generated at 2022-06-25 17:44:30.296419
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:44:31.572644
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) >= 1



# Generated at 2022-06-25 17:44:37.929229
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    root_dir = os.path.split(os.path.dirname(__file__))[0]
    generator_0 = each_sub_command_config(root_dir)
    var_0 = list(generator_0)
    obj_0 = SetupCfgCommandConfig(
        'custom',
        'Custom',
        'Runs custom commands.',
        ('env',)
    )
    assert var_0[0] == obj_0

# Generated at 2022-06-25 17:44:45.517477
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:44:47.616538
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = _prep_setup_dir()
    for cmd in each_sub_command_config(setup_dir):
        print(cmd)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:52.482105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError as err:
        print(err)
    else:
        assert True, '(failed) test_case_0.py'


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:57.074675
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    # print(os.curdir)
    # print(os.path.dirname(__file__))
    # print(os.path.dirname(os.path.dirname(__file__)))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:05.685132
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    str_0 = '/'
    generator_0 = each_sub_command_config(str_0)
    var_0 = list(generator_0)
    var_1 = 'each_sub_command_config'
    var_2 = 'each_sub_command_config'
    var_3 = 'each_sub_command_config'
    var_4 = 'each_sub_command_config'
    var_5 = 'each_sub_command_config'
    var_6 = 'each_sub_command_config'
    var_7 = 'each_sub_command_config'
    var_8 = 'each_sub_command_config'
    var_9 = 'each_sub_command_config'
    var_10 = 'each_sub_command_config'

# Generated at 2022-06-25 17:45:06.960487
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:07.858974
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:12.014641
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__' and __package__ is None:
    from os import sys, path
    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from unit_tester import test_each_sub_command_config
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:12.777609
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True

# Generated at 2022-06-25 17:45:14.861681
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for _ in range(20):
        test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:31.619436
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected_0 = [SetupCfgCommandConfig(name='test-sub-command', camel='TestSubCommand', description='Run pytest', commands=("pytest -svv --cov . . . . . . . . . . . . . . . . . . . . . .",))]
    test_case_0()
    assert var_0 == expected_0

# Generated at 2022-06-25 17:45:36.360919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_functions = {
        'test_case_0': test_case_0,
    }
    for test_func_name, test_func in test_functions.items():
        print(test_func_name)
        test_func()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:37.329404
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:42.198372
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # type: () -> None
    try:
        test_case_0()
    except LookupError as e:
        print('Expected exception: %r' % e)
    except Exception as e:
        print('Unexpected exception: %r' % e)
    else:
        print('Expected exception was NOT raised')
    # Assert each_sub_command_config is called: /


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:45.410865
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    # AssertionError: The given 'setup_dir' of '/' does NOT contain a setup.py
    # file.

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:50.182615
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os

    # Change the directory and get the initial directory.
    initial_dir = os.getcwd()
    os.chdir('..')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

    # Change the directory back to the initial directory.
    os.chdir(initial_dir)


# Generated at 2022-06-25 17:45:51.957755
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Set test values for each test case
    test_case_0()


# Generated at 2022-06-25 17:45:53.110383
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_1 = test_case_0()
    return var_1



# Generated at 2022-06-25 17:45:55.595061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    # Setup
    # Setup
    # Setup
    # Setup
    # Setup
    str_0 = '/'
    generator_0 = each_sub_command_config(str_0)
    var_0 = list(generator_0)
    # Verify
    assert var_0 == []


# Generated at 2022-06-25 17:46:05.415023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in range(1000):
        test_case_0()


if __name__ == '__main__':
    from sys import argv
    from timeit import repeat
    from flutils.pathutils import rel_to_file
    from flutils.tests.pathutils import rel_to_file_test_0, rel_to_file_test_1
    from flutils.tests.pathutils import rel_to_file_test_2, rel_to_file_test_3
    from flutils.tests.pathutils import rel_to_file_test_4, rel_to_file_test_5
    from flutils.tests.pathutils import rel_to_file_test_6, rel_to_file_test_7
    from flutils.tests.pathutils import rel_to_file_test_8, rel_

# Generated at 2022-06-25 17:46:37.538099
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:46:41.567491
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Tests for docstring example.
    import tempfile
    import sys
    import os
    import shutil
    d = tempfile.mkdtemp()
    os.chdir(d)

# Generated at 2022-06-25 17:46:49.276027
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test the invalid ``setup_dir`` value
    try:
        cast(List[SetupCfgCommandConfig],
             list(each_sub_command_config('/not_a_valid_setup_dir')))
        raise AssertionError('Should have raised ``FileNotFoundError``.')
    except FileNotFoundError:
        pass

    # Test the valid ``setup_dir`` value
    setup_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'app_test_modules'
    )
    if not os.path.isdir(setup_dir):
        raise RuntimeError('This test is not meant to be run.')
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()

# Generated at 2022-06-25 17:46:56.254913
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import subprocess
    str_0 = '/home/travis/build/KarrLab/wc_utils/wc_utils'
    generator_0 = each_sub_command_config(str_0)
    var_0 = list(generator_0)
    bool_0 = bool(var_0)
    str_1 = 'pip install -e .[all]'
    bool_1 = str_1 in var_0[0].commands
    str_2 = 'pytest'
    bool_2 = str_2 not in var_0[0].commands
    str_3 = 'git submodule update --init --recursive'
    bool_3 = str_3 in var_0[0].commands
    str_4 = '. --cov=wc_utils --cov-report=term-missing'


# Generated at 2022-06-25 17:47:02.324594
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config')

    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

    print('\nUnit test of function each_sub_command_config()')

    print('\tPass\n')

if __name__ == '__main__':

    # Unit test of function each_sub_command_config()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:04.999248
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
        print('test case 0 passed')
    except Exception as e:
        print(e)
        print('test case 0 failed')



# Generated at 2022-06-25 17:47:06.042756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True;

# Interface for invoking test cases

# Generated at 2022-06-25 17:47:14.781617
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = '/'

    generator_0 = each_sub_command_config(var_0)

    assert(isinstance(generator_0, Generator))
    value_0 = next(generator_0)
    assert(value_0 == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='',
        commands=(
            'echo "Testing command."',
        ),
    ))
    value_1 = next(generator_0)
    assert(value_1 == SetupCfgCommandConfig(
        name='test_2',
        camel='Test2',
        description='',
        commands=(
            'echo "A command with a different name, test 2."',
        ),
    ))
    value_2 = next(generator_0)

# Generated at 2022-06-25 17:47:24.205681
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    option_0 = ['/']
    option_1 = ['/home/tim/dev/git/flutils/tutorial']
    option_2 = ['/home/tim/dev/git/flutils/tutorial/tests']
    arr_0 = [option_0, option_1, option_2]
    str_0 = '/'
    str_1 = '/tmp'
    arr_1 = [str_0, str_1]
    int_0 = 0
    int_1 = 1
    int_2 = 2
    for x in range(4):
        for y in range(4):
            for option_3 in arr_0:
                for str_2 in arr_1:
                    generator_0 = each_sub_command_config(str_2)
                    var_0 = list(generator_0)



# Generated at 2022-06-25 17:47:27.307525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Each sub-command config: ')
    for key in each_sub_command_config():
        print(key)


# Generated at 2022-06-25 17:48:03.021126
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import os.path
    import shutil
    import tempfile
    import unittest
    import uuid

    import _flutils_config as config

    class FunctionTestCase(unittest.TestCase):

        def test_case_0(self):
            with tempfile.TemporaryDirectory() as tmp:
                tmp = str(tmp)
                name = uuid.uuid4().hex
                setup_cfg = os.path.join(tmp, 'setup.cfg')
                with open(setup_cfg, 'w') as fp:
                    fp.write(
                        config.SETUP_CFG_0.format(**{'name': name})
                    )
                generator_0 = config.each_sub_command_config(str(tmp))
                var_0 = list(generator_0)
               

# Generated at 2022-06-25 17:48:12.643049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    str_0 = '/'
    with pytest.raises(FileNotFoundError):
        each_sub_command_config(str_0)
    str_1 = '/Desktop/flutils/flutils'
    generator_0 = each_sub_command_config(str_1)
    str_2 = ''
    str_3 = 'flutils'
    str_4 = 'flutils is a Python library for various tools used in ' +\
            'the development of applications in Python.'
    tuple_0 = ('echo "hello"', )
    tuple_1 = ('echo "world"', )
    tuple_2 = (tuple_0, tuple_1)
    str_5 = 'FlutilsCommand'
    str_6 = 'Test'

# Generated at 2022-06-25 17:48:16.213984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.helpers.runners import (
        GenericRunner
    )
    from flutils.pathutils import (
        start_path
    )

    with GenericRunner(
        each_sub_command_config(start_path),
        setup_dir=start_path
    ) as gr:
        for i, _ in enumerate(gr):
            print(i, _)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:48:18.304373
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:48:19.131122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:19.897229
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:48:21.584215
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:48:23.518788
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    str_0 = '/'
    generator_0 = each_sub_command_config(str_0)
    var_0 = list(generator_0)



# Generated at 2022-06-25 17:48:24.779434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Define main function

# Generated at 2022-06-25 17:48:25.916700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError:
        pass

# Generated at 2022-06-25 17:49:39.910943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)



# Generated at 2022-06-25 17:49:41.385940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config())


if __name__ == '__main__':
    test_each_sub_command_config()
    test_case_0()

# Generated at 2022-06-25 17:49:49.435280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_function_name: str = \
        cast(str, sys._getframe().f_code.co_name)
    print('Unit test for function %s' % this_function_name)

    test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_case_9()
    # test_case_10()
    # test_case_11()
    # test_case_12()
    # test_case_13()
    # test_case_14()
    # test_case_15()
    # test_case_16()

# Generated at 2022-06-25 17:49:51.709413
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Running `{}`'.format(__file__))
    print('Function `{}`'.format('each_sub_command_config'))
    test_case_0()



# Generated at 2022-06-25 17:49:55.561274
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    str_0 = '/Users/jason/PycharmProjects/dask-utils'
    generator_0 = each_sub_command_config(str_0)
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:49:56.438903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:04.891117
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        str_0 = '/'
        generator_0 = each_sub_command_config(str_0)
        var_0 = list(generator_0)
    except FileNotFoundError:
        pass
    # AssertionError: [SetupCfgCommandConfig(name='script', camel='Script', description='Generates the project\'s script.', commands=('python setup.py script',))] != [SetupCfgCommandConfig(name='script', camel='Script', description='Generates the project\'s script.', commands=('python setup.py script',)), SetupCfgCommandConfig(name='release', camel='Release', description='Generates a new release.', commands=('python setup.py release',)), SetupCfgCommandConfig(name='all', camel='All', description='Shortcut to run all commands.', commands=('python setup.py

# Generated at 2022-06-25 17:50:14.167604
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)
    # Nothing is done to the 'setup_dir' argument
    # The 'setup_dir' is NOT validated
    # The default 'setup_dir' is determined by the 'extract_stack'
    # function
    # The default setup directory is found
    # The default setup directory is found
    assert isinstance(each_sub_command_config(), Generator)
    # The 'setup.cfg' file is read
    # The 'metadata' section is NOT found
    # ValueError should be raised for the missing, 'metadata' section
    # The 'metadata' section is found
    # The 'name' option is NOT found
    # ValueError should be raised for the missing 'name' option
    # The 'name' option is found
    # The 'name' option is not set
    # ValueError should

# Generated at 2022-06-25 17:50:20.828977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup args
    test_000_setup_py_dir = os.path.join(os.path.dirname(__file__), 'tests', 'test_000_setup_py')
    generator_0 = each_sub_command_config(test_000_setup_py_dir)
    var_0 = list(generator_0)
    assert var_0 == []


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:50:21.772654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()