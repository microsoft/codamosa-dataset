

# Generated at 2022-06-25 17:41:55.098792
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    value_0 = next(generator_0)
    assert isinstance(value_0, SetupCfgCommandConfig)
    assert isinstance(value_0.name, str)
    assert isinstance(value_0.camel, str)
    assert isinstance(value_0.description, str)
    assert isinstance(value_0.commands, tuple)
    value_1 = next(generator_0)
    assert isinstance(value_1, SetupCfgCommandConfig)
    assert isinstance(value_1.name, str)
    assert isinstance(value_1.camel, str)
    assert isinstance(value_1.description, str)

# Generated at 2022-06-25 17:42:05.112863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, 'testdata')
    test_dir = os.path.abspath(test_dir)
    generator_1 = each_sub_command_config(test_dir)
    expected_commands = (
        'echo "Hello World!"  # test setup.cfg setup.command.[1,2].*',
        'echo "Hello Again!"  # test setup.cfg setup.command.3.*',
        'echo "Hello Again!"  # test setup.cfg setup.command.3.*',
    )

# Generated at 2022-06-25 17:42:14.363470
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.tests.testutils import (
        std_test_header,
        get_test_config_info
    )

    std_test_header('test_each_sub_command_config')
    test_setup_dir, (
        test_setup_cfg_path,
        test_setup_commands_cfg_path,
        test_pyproject_toml_path
    ) = get_test_config_info()

    print('** test_sub_command_config_1 (setup_dir=None)')
    generator_0 = each_sub_command_config()
    count = 0
    for item in generator_0:
        count += 1
        print(item)
    assert count > 0


# Generated at 2022-06-25 17:42:17.050093
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
    except Exception as err:
        assert(False), str(err)



# Generated at 2022-06-25 17:42:17.643626
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:42:19.090289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:42:29.077030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _run_test(setup_dir: Optional[Union[os.PathLike, str]] = None):
        print('---')
        print(f'setup_dir: {setup_dir}')
        print(f'project name: {_get_name(parser, setup_cfg_path)}')
        for cfg in _each_setup_cfg_command(parser, format_kwargs):
            print('    %s :: %s :: %s' % (
                cfg.camel, cfg.description, '\n\t'.join(cfg.commands)
            ))

    format_kwargs: Dict[str, str] = {
        'setup_dir': _prep_setup_dir(),
        'home': os.path.expanduser('~')
    }

# Generated at 2022-06-25 17:42:34.576740
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_1 = each_sub_command_config()
    generator_2 = each_sub_command_config(setup_dir='~/workspace/flutils')

    import pprint

    pprint.pprint(list(generator_1))
    pprint.pprint(list(generator_2))

if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:40.824343
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit tests for function each_sub_command_config.
    """
    # Test if function returns a generator
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    # Test if generator returns a SetupCfgCommandConfig
    setup_cfg = next(generator_0)
    assert isinstance(setup_cfg, SetupCfgCommandConfig)
    # Test if the SetupCfgComandConfig.name returned is correct
    assert setup_cfg.name == 'stt.setup_cfg.setup_cfg.test-case-0'
    # Test if the SetupCfgComandConfig.camel returned is correct
    assert setup_cfg.camel == 'SttsetupCfgSetupCfgTestCase0'
    # Test if the SetupCfgComandConfig.description is correct
   

# Generated at 2022-06-25 17:42:44.842307
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    generator_1 = _each_setup_cfg_command_section(ConfigParser())
    generator_2 = _each_setup_cfg_command(ConfigParser(), {})
    assert True



# Generated at 2022-06-25 17:43:04.035940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case 0: test_case_0
    var_0 = each_sub_command_config()
    generator_0 = var_0
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:43:05.004620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:43:14.087609
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _setup_dir = os.path.dirname(__file__)
    _setup_dir = os.path.join(_setup_dir, 'tests')
    _setup_dir = os.path.join(_setup_dir, 'test_fixtures')
    _setup_dir = os.path.join(_setup_dir, 'setup_commands')

    generator_0 = each_sub_command_config(_setup_dir)
    var_0 = list(generator_0)
    var_1 = len(var_0)
    assert var_1 == 2

    var_2 = var_0[0]
    assert var_2.name == 'hello'

    var_3 = var_2.camel
    assert var_3 == 'Hello'

    var_4 = var_2.description

# Generated at 2022-06-25 17:43:19.614707
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    generator_0 = each_sub_command_config(setup_dir=setup_dir)
    list_0 = list(generator_0)
    assert list_0
    assert len(list_0) == 2
    assert len(list_0[0].commands) == 1
    assert len(list_0[1].commands) == 2

# Generated at 2022-06-25 17:43:22.679683
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        var_0 = True
        assert (var_0)
    else:
        var_0 = False
        assert (var_0)

# Generated at 2022-06-25 17:43:23.426529
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()

# Generated at 2022-06-25 17:43:30.989061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def t0_setup_dir(setup_dir: Optional[Union[os.PathLike, str]] = None) -> Generator[SetupCfgCommandConfig, None, None]:
        return each_sub_command_config(setup_dir)

    t0_setup_dir_0 = t0_setup_dir()
    t0_setup_dir_0_var_0 = list(t0_setup_dir_0)
    print('t0_setup_dir_0_var_0', t0_setup_dir_0_var_0)

    t0_setup_dir_1 = t0_setup_dir(__file__)
    t0_setup_dir_1_var_0 = list(t0_setup_dir_1)

# Generated at 2022-06-25 17:43:36.451246
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        # "Set up" the test case
        generator_0 = each_sub_command_config()
        var_0 = list(generator_0)
        # "Test the test case"
        print(var_0)
    except Exception as err:
        print(err)
        raise
    finally:
        # "Tear down" the test case
        pass

# Unit tests for module setuputils

# Generated at 2022-06-25 17:43:37.875666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:43:38.897088
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None

# Generated at 2022-06-25 17:43:53.541785
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == []
    test_case_0()



# Generated at 2022-06-25 17:43:55.310302
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None, "Failed on test case 0."

# Generated at 2022-06-25 17:43:56.626365
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:06.153256
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    '''
    This function tests each_sub_command_config()
    '''
    import tempfile
    from os.path import dirname, join, realpath
    from shutil import rmtree

    base_path = dirname(realpath(__file__))
    setup_dir = join(base_path, '..')
    temp_dir = tempfile.TemporaryDirectory(prefix='test_sub_commands_')
    test_dir = temp_dir.name
    test_setup_file_name = join(test_dir, 'setup.py')
    file_path = join(base_path, 'test_files', 'setup.py')

# Generated at 2022-06-25 17:44:12.356361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    sub_cmds = each_sub_command_config()
    _ = list(sub_cmds)
    assert True is True


if __name__ == '__main__':
    import json

    _ = json.dumps(
        [
            {
                'name': x.name,
                'camel': x.camel,
                'description': x.description,
                'commands': x.commands,
            }
            for x in each_sub_command_config(os.path.dirname(__file__))
        ],
        indent=2
    )

# Generated at 2022-06-25 17:44:14.656234
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function "each_sub_command_config"')
    print('"each_sub_command_config" tested successfully')



# Generated at 2022-06-25 17:44:17.350012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("\nTesting function each_sub_command_config")
    print("\nThis is testing the test case 0")
    test_case_0()



# Generated at 2022-06-25 17:44:20.292627
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True
    return

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-25 17:44:26.532159
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for each_sub_command_config_config in each_sub_command_config():
        pass


if __name__ == '__main__':
    sub_commands = {}
    for setup_cfg_command_config in each_sub_command_config():
        print('#', '-' * 79)
        print(setup_cfg_command_config.description)
        print()
        for cmd in setup_cfg_command_config.commands:
            print('$', cmd, sep='\n')

        sub_commands[setup_cfg_command_config.name] = setup_cfg_command_config

# Generated at 2022-06-25 17:44:38.060902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 17:45:03.522715
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 15

# Generated at 2022-06-25 17:45:12.087427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest.mock import patch
    import sys

    setup_dir: Optional[str] = None
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        basename = os.path.basename(fs.filename)
        if basename == 'setup.py':
            setup_dir = str(os.path.dirname(fs.filename))
            break
    if setup_dir is None:
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )


# Generated at 2022-06-25 17:45:13.732454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:22.254174
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config), \
        'each_sub_command_config is not callable.'

    with pytest.raises(FileNotFoundError):
        _ = each_sub_command_config('/tmp')
    with pytest.raises(FileNotFoundError):
        _ = each_sub_command_config('')
    with pytest.raises(FileNotFoundError):
        _ = each_sub_command_config('setup_commands.cfg')
    with pytest.raises(FileNotFoundError):
        _ = each_sub_command_config('./setup_commands.cfg')
    with pytest.raises(FileNotFoundError):
        _ = each_sub_command_config('./tests/invalid_setup_dir')

    generator_0 = each_

# Generated at 2022-06-25 17:45:31.803482
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Verifies that the function returns a generator that yeilds named
    tuples.
    """
    # Sanity check
    assert list is not tuple
    assert bool is not list
    assert bool is not tuple
    assert tuple is not list
    assert isinstance(each_sub_command_config(), Generator)
    for out in each_sub_command_config():
        assert out.__class__.__name__ == 'SetupCfgCommandConfig'
    for out in each_sub_command_config():
        assert out.__class__ is SetupCfgCommandConfig
        assert isinstance(out, SetupCfgCommandConfig)
        assert isinstance(out, tuple)
        assert hasattr(out, 'name')
        assert hasattr(out, 'camel')
        assert hasattr(out, 'description')

# Generated at 2022-06-25 17:45:41.285580
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    format_kwargs: Dict[str, str] = {
        'setup_dir': _prep_setup_dir('setuptools-command-package-template'),
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')
    if os.path.isfile(path):
        parser = ConfigParser()
        parser.read(path)

# Generated at 2022-06-25 17:45:42.951991
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:45.868839
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except:
        raise AssertionError('Test case 0 failed.')

# calls the main function
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 17:45:48.127179
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:  # pylint: disable=W0703
        from traceback import print_exc
        print_exc()



# Generated at 2022-06-25 17:45:58.120576
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from importlib import import_module

    from flutils.configutils import (
        each_sub_command_config,
    )
    from flutils.fileutils import (
        each_sub_directory_path,
    )
    PROJECTS_DIR = os.path.realpath(os.path.join(
        os.path.dirname(__file__),
        os.path.pardir,
        os.path.pardir,
        'projects'
    ))
    for i, path in enumerate(each_sub_directory_path(PROJECTS_DIR)):
        generator = each_sub_command_config(path)
        for config in list(generator):
            print(config.name)

# Generated at 2022-06-25 17:47:04.228167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import re

    # Build the `tests` directory.
    cur_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(cur_dir, 'data', 'tests', 'setup_dir')
    sys.path.append(setup_dir)
    try:
        import setup
        setup.build(setup_dir, 'tests')
    except:
        raise

    # Execute the `tests` directory's setup.py file to build the
    # `setuptools` sub commands.
    os.chdir(os.path.join(setup_dir, 'tests'))
    cur_dir = os.getcwd()
    try:
        import setup
        setup.build(cur_dir, 'setuptools')
    except:
        raise

   

# Generated at 2022-06-25 17:47:05.719094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass # do nothing, just let the test succeed

# Generated at 2022-06-25 17:47:06.567317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:15.171073
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # No setup_dir
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 1
    assert var_0[0].name == 'python_package'
    assert var_0[0].description == 'Python package (Default Command) '
    assert var_0[0].camel == 'PythonPackage'
    assert var_0[0].commands == (
        'python setup.py bdist_wheel',
        'python setup.py sdist',
        'python setup.py register || true',
        'python setup.py bdist_wheel upload || true',
        'python setup.py sdist upload || true',
    )

    # No setup_dir (other name)

# Generated at 2022-06-25 17:47:23.676659
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pytest import raises
    import sys

    from flutils.configutils import each_sub_command_config

    # each_sub_command_config(setup_dir=None)
    # 1. setup_dir is None.
    generator_1 = each_sub_command_config(setup_dir=None)
    var_1 = list(generator_1)
    # 2. setup_dir is a directory that contains the project's
    #    ``setup.py`` file.
    generator_2 = each_sub_command_config(setup_dir='.')
    var_2 = list(generator_2)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:24.833113
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert __doc__ is not None
    test_case_0()

# Generated at 2022-06-25 17:47:33.490156
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test Case #0
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert var_0[0].name == 'build'
    assert var_0[1].name == 'clean'
    assert var_0[2].name == 'docs'
    assert var_0[3].name == 'install'
    assert var_0[4].name == 'register'
    assert var_0[5].name == 'sdist'
    assert var_0[6].name == 'test'
    assert var_0[7].name == 'upload'
    assert var_0[8].name == 'test1'

# Generated at 2022-06-25 17:47:36.593694
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        raise AssertionError(
            "Failure running test_case_0."
        )


if __name__ == '__main__':
    import sys
    print("This is a module for import by other programs.")
    sys.exit(0)

# Generated at 2022-06-25 17:47:39.518212
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise AssertionError("Unit test for function each_sub_command_config failed")
    else:
        pass

# Generated at 2022-06-25 17:47:45.038707
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.packageutils import each_sub_command_config, get_package_dir
    package_dir = get_package_dir('flutils')
    generator_0 = each_sub_command_config(package_dir)
    var_0 = list(generator_0)
    assert len(var_0) == 0



# Generated at 2022-06-25 17:50:28.508477
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_0 = "test_each_sub_command_config"
    assert test_case_0(), test_0
    # assert test_case_1(), test_0
    # assert test_case_2(), test_0
    # assert test_case_3(), test_0
    # assert test_case_4(), test_0
    # assert test_case_5(), test_0
    # assert test_case_6(), test_0
    # assert test_case_7(), test_0
    # assert test_case_8(), test_0
    # assert test_case_9(), test_0
    # assert test_case_10(), test_0
    # assert test_case_11(), test_0
    # assert test_case_12(), test_0

# Generated at 2022-06-25 17:50:35.547114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    setup_dir = 'C:\\home\\consonance\\src\\flutils\\test\\test_register_project\\test_0'

# Generated at 2022-06-25 17:50:36.370147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:43.788326
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Current working directory
    _cwd = os.path.realpath(os.getcwd())
    # Empty setup directory
    _path = os.path.join(os.path.dirname(__file__), '..', '..', 'setup_dirs')
    _path = os.path.realpath(_path)
    assert _cwd != _path

    generator_0 = each_sub_command_config(setup_dir=_path)
    var_0 = list(generator_0)
    assert len(var_0) == 2
    assert var_0[0].name == 'build_sphinx'
    assert var_0[0].camel == 'BuildSphinx'
    assert var_0[0].description == 'Build Sphinx documentation'

# Generated at 2022-06-25 17:50:46.425396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Call test_case_0()
    test_case_0()


if __name__ == "__main__":
    # Run test for each_sub_command_config()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:48.368738
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    __test_case_0()
    pass

if __name__ == '__main__':
    try:
        test_each_sub_command_config()
    except:
        pass

# Generated at 2022-06-25 17:50:49.385537
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:50:53.672834
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setuputils.setupcfg as m

    m.test_case_0()
    generator_0 = m.each_sub_command_config()
    var_0 = list(generator_0)


if __name__ == '__main__':
    import flutils.setuputils.setupcfg as m

    m.test_each_sub_command_config()

# Generated at 2022-06-25 17:50:55.426254
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:51:04.333354
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Part A. Define the test data and the expected results.
    setup_dir = None
    expected_setup_dir = 'C:\\Users\\dave\\OneDrive - ' \
                         'Arcadia University\\Code\\Python\\flutils'
    expected_name = 'flutils'
    expected_0 = SetupCfgCommandConfig(
        cmd_name='cmd.test',
        camel='Test',
        description='Run the unit tests for the %(name)s project.',
        commands=('python -m unittest',)
    )