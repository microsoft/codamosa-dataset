

# Generated at 2022-06-25 17:41:56.268693
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    generator_0 = each_sub_command_config(setup_dir)

# Generated at 2022-06-25 17:41:58.100553
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config


if __name__ == '__main__':
    print(__doc__)

# Generated at 2022-06-25 17:42:02.731043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    try:
        _ = next(generator_0)
    except StopIteration:
        pass

    generator_1 = each_sub_command_config(setup_dir=__file__)
    try:
        _ = next(generator_1)
    except StopIteration:
        pass

# Generated at 2022-06-25 17:42:05.354320
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    estr = 'setup_dir/setup.py'
    path = os.path.realpath(estr)
    each_sub_command_config(path)



# Generated at 2022-06-25 17:42:09.046919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    test_case_0()
    # No further setup is needed.

    # Exercise
    # No exercise to perform.

    # Verify
    # No verify to perform.

    # Cleanup
    # No cleanup to perform.
    pass

# Generated at 2022-06-25 17:42:13.990843
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    assert isinstance(next(generator_0), SetupCfgCommandConfig)



# Generated at 2022-06-25 17:42:20.017404
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(
        os.path.dirname(__file__)
    )
    config_list_0: List[SetupCfgCommandConfig] = list(generator_0)
    assert len(config_list_0) == 2


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:25.463591
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config, end='\n\n')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:42:27.659445
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        print(f"{sub_command.name} - {sub_command.description}")
        for command in sub_command.commands:
            print(f"    {command}")
    return


test_case_0()

# Generated at 2022-06-25 17:42:36.632032
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        ConfigSection,
        ConfigSectionType,
    )
    from flutils.setuputils import (
        SetupCfgCommandConfig,
        each_sub_command_config,
    )
    from flutils.strutils import to_lines, to_str
    from flutils.terminalutils import eprint

    generator_0 = each_sub_command_config()
    output = '\n'.join(map(str, list(generator_0)))
    eprint(output)
    return

    # generator_1 = each_sub_command_config()
    # generator_2 = each_sub_command_config()
    # generator_3 = each_sub_command_config(setup_dir='~/git/flutils/tests/data/pkg1')
    # generator_4 = each_

# Generated at 2022-06-25 17:42:46.266306
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:42:52.130201
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils.setupcfg import (
        each_sub_command_config,
        test_case_0,
    )

    test_case_0()

    with pytest.raises(
            LookupError,
            match="The config file, %r, is missing the 'metadata' section."):
        setup_dir = os.path.dirname(__file__)
        each_sub_command_config(setup_dir)



# Generated at 2022-06-25 17:42:57.153662
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test case for function each_sub_command_config"""

    def assert_equal_iter(actual_iter, func):
        var_0 = next(actual_iter)
        assert var_0 == func()

    assert_equal_iter(each_sub_command_config(), test_case_0)



# Generated at 2022-06-25 17:43:00.087585
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('Unit test OK.')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:02.806049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .test_each_sub_command_config import (
        each_sub_command_config as test_function
    )

    test_function()


test_case_0()

# Generated at 2022-06-25 17:43:06.556178
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('test_each_sub_command_config')
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:12.469974
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '~/workspace/flutils/flutils'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    assert var_0 == (
        'develop',
        'Develop',
        '',
        ('python3 setup.py develop',)
    )


if __name__ == '__main__':
    import pytest
    pytest.main(['--color=yes', '-s', __file__])

# Generated at 2022-06-25 17:43:22.600242
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:43:29.350300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'c:\\users\\borisf\\source\\flutils\\tests\\testpkg'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    cfg = SetupCfgCommandConfig(
        name='build_sphinx', camel='BuildSphinx', description='',
        commands=('sphinx-build -b html docs build_sphinx', )
    )
    assert var_0 == cfg
    var_1 = next(generator_0)
    cfg = SetupCfgCommandConfig(
        name='build_sphinx', camel='BuildSphinx', description='',
        commands=('sphinx-build -b html docs build_sphinx', )
    )
    assert var_1 == cfg
    var

# Generated at 2022-06-25 17:43:32.614162
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Imports
    # Setup

    # Exercise
    generator = each_sub_command_config()
    # Verify
    first = next(generator)
    assert first.name == 'check'



# Generated at 2022-06-25 17:43:48.089447
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from test.test_setup_commands import (
        EACH_SUB_COMMAND_CONFIG_FUNCTION,
        EACH_SUB_COMMAND_CONFIG_RETURN_VALUE,
        each_sub_command_config as target
    )

    arg_0 = EACH_SUB_COMMAND_CONFIG_FUNCTION[1].get(
        'setup_dir', 'test/test_setup_commands',
    )

    var_0 = EACH_SUB_COMMAND_CONFIG_RETURN_VALUE[0]
    var_1 = EACH_SUB_COMMAND_CONFIG_RETURN_VALUE[1]

    rets = target(arg_0)
    assert type(rets) is type(var_0)
    assert next(rets) == var_

# Generated at 2022-06-25 17:43:49.237016
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except StopIteration:
        pass

# Generated at 2022-06-25 17:43:51.098292
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config()) == SetupCfgCommandConfig('name', 'Name', '', ('echo {setup_dir}',))

# Generated at 2022-06-25 17:43:56.044104
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    cwd: str = os.getcwd()
    test_dir: str = os.path.join(cwd, 'tests')
    setup_dir: str = os.path.join(test_dir, 'test_data', 'setup_cfg')

# Generated at 2022-06-25 17:44:05.744717
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)
        if fs.filename == 'setup.py':
            setup_dir = str(os.path.dirname(fs.filename))
            setup_dir = os.path.realpath(setup_dir)
            break
    else:
        setup_dir = os.getcwd()

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    var_1 = next(generator_0)
    var_2 = next(generator_0)
    var_3 = next(generator_0)
    var_4 = next(generator_0)
    var_5 = next(generator_0)
    var_6 = next(generator_0)
    var_

# Generated at 2022-06-25 17:44:08.300982
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)

    assert var_0
    assert type(var_0) == SetupCfgCommandConfig


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:44:08.975363
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:19.480861
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), 'data', 'test_case_0')
    itr = each_sub_command_config(setup_dir)
    config = next(itr)
    assert config.name == 'lint'
    assert config.camel == 'Lint'
    assert config.description == 'Runs the project\'s linters.'

# Generated at 2022-06-25 17:44:27.674900
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0 == SetupCfgCommandConfig(
        name='pip',
        camel='Pip',
        description='Install the project\'s dependencies with Pip.',
        commands=('pip install -e .[develop]',)
    )
    var_1 = next(generator_0)
    assert var_1 == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Run the project\'s unit tests.',
        commands=('python -m unittest discover',)
    )
    var_2 = next(generator_0)

# Generated at 2022-06-25 17:44:30.793493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as err:
        print('ERROR: %s\n' % str(err))

# Generated at 2022-06-25 17:44:48.071191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    setup_dir = pathlib.Path(__file__).parent / '..' / '..'

    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:53.352173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Calling function each_sub_command_config with simple types for arguments.
    var_1 = each_sub_command_config()
    # Calling function each_sub_command_config with complex types for arguments.
    var_2 = each_sub_command_config()

test_case_0()
test_each_sub_command_config()

# Generated at 2022-06-25 17:45:02.980445
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert var_0.name == 'build_sphinx'
    assert var_0.camel == 'BuildSphinx'
    assert var_0.description == 'Build Sphinx documentation.'
    assert var_0.commands == (
        'sphinx-build -b html -d _build/doctrees . _build/html',)
    var_1 = next(generator_0)
    assert isinstance(var_1, SetupCfgCommandConfig)
    assert var_1.name == 'clean'
    assert var_1.camel == 'Clean'
    assert var_1.description == 'Clean up the project.'
    assert var

# Generated at 2022-06-25 17:45:04.692214
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:05.616336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:45:07.893336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case #0
    try:
        test_case_0()
    except StopIteration:
        pass



# Generated at 2022-06-25 17:45:08.958199
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:16.661085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_function_name = inspect.currentframe().f_code.co_name
    print('\n\nUnit Test of Function "{}"'.format(this_function_name))
    print('=' * (len(this_function_name) + 8))

    root = os.path.join(
        os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))),
        'data',
    )

    dir_path = os.path.join(root, '')
    for sc in each_sub_command_config(dir_path):
        print(sc.name)
        print(sc.camel)
        print(sc.description)
        for cmd in sc.commands:
            print(cmd)
        print()


# Generated at 2022-06-25 17:45:23.424289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    from . import (
        each_sub_command_config,
    )

    with pathlib.Path.cwd() as previous_working_dir:
        current_dir = os.path.dirname(os.path.realpath(__file__))
        os.chdir(os.path.join(current_dir, '..', '..'))
        test_case_0()


if __name__ == '__main__':
    import sys
    import unittest

    unittest.main(exit=bool(unittest.main(argv=sys.argv[:1])))

# Generated at 2022-06-25 17:45:25.955992
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for x in each_sub_command_config():
        print(x)
# vim: set ts=4 sts=4 sw=4 tw=100 et:

# Generated at 2022-06-25 17:45:56.580167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    print(var_0.name, var_0.camel, var_0.description, var_0.commands)
    # var_1 = next(generator_0)
    # print(var_1.name, var_1.camel, var_1.description, var_1.commands)

if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:58.235602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    assert each_sub_command_config() is not None


# Prove that module can be imported

# Generated at 2022-06-25 17:46:04.625960
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    next(generator)
    # var = next(generator)
    # assert var.description == 'Runs the flutils-helper script.'
    # assert var.name == '.'
    # assert var.camel == '_'
    # assert len(var.commands) == 1
    # assert var.commands[0] == 'python ./flutils/helper.py'
    assert True is True

# Generated at 2022-06-25 17:46:12.986697
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Ensures that the ``each_sub_command_config`` function works as expected.
    """
    @wrap_sub_command
    def cmd_0():
        pass

    @wrap_sub_command
    def cmd_1():
        pass

    @wrap_sub_command
    def cmd_2():
        pass

    generator_0 = each_sub_command_config()

    var_0 = next(generator_0)
    assert 'cmd_1' == var_0.name
    assert 'Cmd1' == var_0.camel
    assert '' == var_0.description
    assert (
        '{name} cmd_1'.format(name=var_0.name),
        '{name} Cmd1'.format(name=var_0.camel)
    ) == var_0.commands


# Generated at 2022-06-25 17:46:15.621871
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        print(item.camel)
        print(item.commands)
        print(item.description)
        print(item.name)
        print()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:17.656529
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    commands = list(each_sub_command_config())
    assert len(commands) != 0


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:20.042676
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests each_sub_command_config."""
    # Setting up test
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 17:46:20.841676
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()



# Generated at 2022-06-25 17:46:26.918899
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(__file__)
    generator_1 = each_sub_command_config(test_dir)
    assert next(generator_1) == SetupCfgCommandConfig(
        name='build',
        camel='Build',
        description='Builds the Python package.',
        commands=(
            'python setup.py sdist bdist_wheel',
        )
    )
    assert next(generator_1) == SetupCfgCommandConfig(
        name='build_install',
        camel='BuildInstall',
        description='Builds the Python package and installs it.',
        commands=(
            'python setup.py sdist bdist_wheel install',
        )
    )

# Generated at 2022-06-25 17:46:27.897058
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:33.832499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config()) == SetupCfgCommandConfig(
        'build',
        'SetupCommandBuild',
        'Run the build process.',
        (
            'python setup.py build',
        ),
    )


if __name__ == '__main__':
    print(next(each_sub_command_config()))
    import pytest
    pytest.main([
        '--show-capture', 'stdout',  # or 'stderr'
        '--color', 'yes',
        __file__
    ])

# Generated at 2022-06-25 17:47:34.832012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Add tests
    pass


# Generated at 2022-06-25 17:47:45.356473
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    assert next(each_sub_command_config()) == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='Runs the test suite.',
        commands=('pytest',)
    )

    assert next(each_sub_command_config()) == SetupCfgCommandConfig(
        name='test.cov',
        camel='Test_Cov',
        description='Runs the tests with coverage.',
        commands=(
            'pytest --cov=flutils --cov=test --cov-config=setup.cfg',
            'coverage xml -i --include="*flutils*" --omit="*test*"'
        )
    )


# Generated at 2022-06-25 17:47:52.222071
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config_0 = next(each_sub_command_config())
    config_1 = next(each_sub_command_config())
    config_2 = next(each_sub_command_config())
    config_3 = next(each_sub_command_config())
    config_4 = next(each_sub_command_config())
    config_5 = next(each_sub_command_config())
    config_6 = next(each_sub_command_config())
    config_7 = next(each_sub_command_config())
    config_8 = next(each_sub_command_config())
    config_9 = next(each_sub_command_config())
    config_10 = next(each_sub_command_config())
    config_11 = next(each_sub_command_config())

# Generated at 2022-06-25 17:47:56.870297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    from pytest_mock import MockerFixture

    from flutils.configutils import each_sub_command_config as func

    sys.argv = [ '', '--test_case=0' ]
    mocker: MockerFixture
    with mocker.patch('builtins.print', create=True) as mock_print:
        test_case_0()
        mock_print.assert_not_called()
    print('Done!')



# Generated at 2022-06-25 17:47:58.407172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:48:08.896415
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Assert that the generator works
    assert next(each_sub_command_config())

    # Test no setup dir
    with pytest.raises(FileNotFoundError):
        each_sub_command_config(setup_dir='/not/a/real/dir')

    # Test real directory
    real_dir = os.path.dirname(__file__)
    assert next(each_sub_command_config(setup_dir=real_dir))

    # Test file, not dir
    with pytest.raises(NotADirectoryError):
        each_sub_command_config(setup_dir=__file__)

    # Test missing setup.py
    with pytest.raises(FileNotFoundError):
        each_sub_command_config(setup_dir=os.path.dirname(real_dir))

   

# Generated at 2022-06-25 17:48:09.851932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config():
        print(i)

# Generated at 2022-06-25 17:48:13.243137
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #######################
    # Arrange
    #######################

    #######################
    # Act
    #######################
    var = next(each_sub_command_config())

    #######################
    # Assert
    #######################
    assert var is not None


if __name__ == '__main__':
    each_sub_command_config()

# Generated at 2022-06-25 17:48:13.860042
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()


# Generated at 2022-06-25 17:50:38.146039
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert isinstance(next(each_sub_command_config()), SetupCfgCommandConfig)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:38.943031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    assert True

# Generated at 2022-06-25 17:50:42.195890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    for var_1 in var_0:
        var_0 = isinstance(var_1, SetupCfgCommandConfig)
        assert var_0 is True


if __name__ == '__main__':
    test_case_0()

    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:50.287333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _list_0 = list(each_sub_command_config())
    _list_1 = list(each_sub_command_config(
        setup_dir=_prep_setup_dir(
            setup_dir=os.path.dirname(__file__)
        )
    ))

    _list_2 = list(each_sub_command_config(
        setup_dir=_prep_setup_dir(
            setup_dir=os.path.dirname(__file__)
        )
    ))

    _list_2 += list(each_sub_command_config(
        setup_dir=_prep_setup_dir(
            setup_dir=os.path.dirname(__file__)
        )
    ))

# Generated at 2022-06-25 17:50:59.880936
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_0(self):
            self.assertRaises(
                FileNotFoundError,
                each_sub_command_config,
                './tests/sub_commands/does_not_exist'
            )

        def test_1(self):
            generator_0 = each_sub_command_config(
                './tests/sub_commands/project_0'
            )
            var_0 = next(generator_0)
            self.assertEqual(
                var_0,
                SetupCfgCommandConfig(
                    'sub_command',
                    'SubCommand',
                    'Sub command description.',
                    ('./sub_command.py',),
                )
            )

    main()

# Generated at 2022-06-25 17:51:06.527505
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    setup_dir = os.path.expanduser('~/gpath/github.com/smoqadam/flutils/tests/')

    # Exercise
    generator = each_sub_command_config(setup_dir)

    # Verify
    results = tuple(generator)
    assert len(results) == 1
    result = results[0]
    assert result.name == 'doc'
    assert result.camel == 'Doc'
    assert result.description == 'Builds the docs.'
    assert len(result.commands) == 1
    assert result.commands[0] == 'python setup.py build_sphinx'

    # Cleanup



# Generated at 2022-06-25 17:51:10.205611
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0 == SetupCfgCommandConfig(name='', camel='', description='', commands=())


if __name__ == '__main__':
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-25 17:51:20.980939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.split(os.path.abspath(__file__))[0]
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    assert var_0.name == 'init'
    var_1 = next(generator_0)
    assert var_1.name == 'install'
    var_2 = next(generator_0)
    assert var_2.name == 'dev'
    var_3 = next(generator_0)
    assert var_3.name == 'dev.reformat'
    var_4 = next(generator_0)
    assert var_4.name == 'dev.reformat.autopep8'
    var_5 = next(generator_0)
    assert var_5

# Generated at 2022-06-25 17:51:30.175679
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'test'
    assert var_0.camel == 'Test'
    assert var_0.description == 'Run the test suite.'
    assert var_0.commands == ('python -m unittest discover -v -t test/', )
    var_1 = next(generator_0)
    assert var_1.name == 'pipfile_install'
    assert var_1.camel == 'PipfileInstall'
    assert var_1.description == 'Install dependencies.'
    assert var_1.commands == (
        'pipenv install --deploy --skip-lock',
        'pipenv run python setup.py develop'
    )
    var_2 = next