

# Generated at 2022-06-25 17:41:48.410885
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # setup_dir
    summary = each_sub_command_config()
    print(list(summary))



# Generated at 2022-06-25 17:41:57.422529
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import List, Optional
    import os
    import pprint
    from flutils.pathutils import each_file_in_dir
    import tempfile
    import pathlib
    import sys

    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = pathlib.Path(tmpdirname)
        print('created temporary directory', tmpdirname)

        # Within the temporary directory, create some folders and files
        print('creating temporary sub-directory and files...', end='')

        os.mkdir(tmpdirname / 'one')
        p = tmpdirname / 'setup.cfg'

# Generated at 2022-06-25 17:42:06.824730
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(_each_setup_cfg_command_section(ConfigParser())) == []

    assert list(
        _each_setup_cfg_command(
            ConfigParser(), {'name': 'foobar'}
        )
    ) == []

    setup_cfg_path = './setup.cfg'
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)

    assert list(
        _each_setup_cfg_command_section(
            ConfigParser()
        )
    ) == []

    assert list(
        _each_setup_cfg_command(
            ConfigParser(), {'name': name}
        )
    ) == []

    assert list(each_sub_command_config()) == []

# Generated at 2022-06-25 17:42:07.682684
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:42:12.450376
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.join(
        os.path.dirname(__file__),
        'helpers',
        'test_package',
        'src'
    )
    for sub_command in each_sub_command_config(test_setup_dir):
        print(sub_command)



# Generated at 2022-06-25 17:42:13.850446
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .context import setup_commands

    from setup_commands import each_sub_command_config


# Generated at 2022-06-25 17:42:21.283433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_cases = (
        (None, None),  # setup_dir
    )
    for args, expected in test_cases:
        actual = each_sub_command_config(*args)
        try:
            assert expected == actual
        except AssertionError:
            print("args:", args)
            print("expected:", expected)
            print("actual:", actual)
            raise


if __name__ == '__main__':
    import sys
    print(sys.version)
    print("====")
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:30.549319
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import inspect
    import sys

    # Arrange
    generator_0 = each_sub_command_config()

    # Act
    out = next(generator_0)

    # Assert
    assert out == SetupCfgCommandConfig(
        name='run',
        camel='Run',
        description='Runs the package.',
        commands=('python -m {{ name }}',)
    )
    assert inspect.getmodule(next(sys.getframes(generator_0.gi_frame)).f_code) \
        is inspect.getmodule(inspect.getmodule(each_sub_command_config))



# Generated at 2022-06-25 17:42:38.854245
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests :func:`flutils.scriptrunner.each_sub_command_config` function."""

    # Call function whose docstring is being tested
    generator_0 = each_sub_command_config()


# Command-line entry point
if __name__ == '__main__':
    import inspect
    import sys
    import unittest

    try:
        import coverage
    except ImportError:
        coverage = None

    for _, cls in inspect.getmembers(sys.modules['__main__'], inspect.isclass):
        if issubclass(cls, unittest.TestCase):
            modules = [sys.modules['__main__']]
            suite = unittest.TestLoader().loadTestsFromTestCase(cls)
            result = unittest.TextTestRunner().run(suite)


# Generated at 2022-06-25 17:42:48.539470
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert generator_0


# Validate the path to the setup.cfg file.
path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'setup.cfg')
assert os.path.exists(path)

# Validate all command sections of the setup.cfg file.
parser = ConfigParser()
parser.read(path)
for section in parser.sections():
    section = cast(str, section)
    section = section.strip()
    if section.startswith('setup.command.'):
        command_name = '.'.join(section.split('.')[2:])

# Generated at 2022-06-25 17:43:02.237513
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = setup_commands.each_sub_command_config('.')
    var_1 = iter(var_0)
    var_2 = type(var_1)
    while True:
        try:
            var_3 = next(var_1)
        except StopIteration:
            break
        var_4 = type(var_3)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:43:07.307382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/home/j15e/dev/pypi/flutils'
    generator = each_sub_command_config(setup_dir)
    assert len(list(generator)) == 2
    generator = each_sub_command_config()
    assert len(list(generator)) == 2

# Generated at 2022-06-25 17:43:08.224715
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:08.794984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True

# Generated at 2022-06-25 17:43:12.588433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    func: callable = each_sub_command_config
    assert func(setup_dir=".")
    assert func(setup_dir="..")
    assert func(setup_dir="../..")
    assert func(setup_dir="../../..")
    assert func(setup_dir="../../../..")

# Generated at 2022-06-25 17:43:18.435719
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None
    setup_dir = './setup_dir'
    setup_dir = './setup_dir/src/project'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)


if __name__ == '__main__':
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    print(var_0)

# Generated at 2022-06-25 17:43:20.790514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:43:21.653595
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:22.481528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == []

# Generated at 2022-06-25 17:43:24.265330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        pass
    else:
        raise Exception


if __name__ == '__main__':
    raise Exception

# Generated at 2022-06-25 17:43:39.771567
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print(__name__ + ".test_each_sub_command_config")
    test_case_0()


if __name__ == '__main__':
    import sys

    try:
        import coverage
        co = coverage.coverage(branch=True, config_file=True)
        co.start()
        result = unittest.main(module="test_setup_cfg_command_config",
                               argv=[sys.argv[0]],
                               exit=False)
        co.stop()
        co.save()
        sys.exit(not result.result.wasSuccessful())
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-25 17:43:40.995698
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 17:43:49.247717
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:44:00.791037
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.testutils.setup_py_dir
    generator_0 = each_sub_command_config(
        flutils.testutils.setup_py_dir.setup_dir
    )
    var_0 = list(generator_0)
    assert len(var_0) == 3
    var_1 = var_0[0]
    assert var_1.name == 'create_release'
    assert var_1.camel == 'CreateRelease'
    assert var_1.description == (
        'Creates a new release for all of the packages in the '
        'project from a given changelog.'
    )

# Generated at 2022-06-25 17:44:01.252288
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:44:04.393923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) == 5
    assert len(list(each_sub_command_config('tests/setup_dir'))) == 0
    assert len(list(each_sub_command_config('tests/setup_dir_with_setup_cfg_only'))) == 5

# Generated at 2022-06-25 17:44:07.093115
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cases = [
        test_case_0,
    ]

    for case in cases:
        try:
            case()
        except Exception as err:
            print(
                str(err),
                '-'*80,
                file=sys.stderr
            )
            raise err

# Generated at 2022-06-25 17:44:11.011955
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import flutils

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_case_0(self):
            generator_0 = flutils.each_sub_command_config()
            var_0 = list(generator_0)
            self.assertIsNotNone(var_0)

    unittest.main()

# Generated at 2022-06-25 17:44:20.293794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    generator_0_list = [entry for entry in generator_0]
    assert generator_0_list[0] == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='test',
        commands=('echo test')
    )
    assert generator_0_list[1] == SetupCfgCommandConfig(
        name='test2',
        camel='Test2',
        description='test2',
        commands=('python setup.py test2',)
    )


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:44:21.176359
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:44:34.113761
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:35.628262
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:44:39.774883
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == [
        SetupCfgCommandConfig('echo0', 'Echo0', '', ('echo 0',)),
        SetupCfgCommandConfig(
            'cmd', 'Cmd', '', ('python -m xdoctest -m flutils.setup_utils',)
        ),
    ]

# Generated at 2022-06-25 17:44:43.535968
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests that the basic functionality of the each_sub_command_config is
    working as expected.
    """
    assert True is True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:44:44.435334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:44:51.009538
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    import sys

    _each_setup_cfg_command_section = each_sub_command_config.__globals__[
        '_each_setup_cfg_command_section'
    ]
    _each_setup_cfg_command = each_sub_command_config.__globals__[
        '_each_setup_cfg_command'
    ]
    _validate_setup_dir = each_sub_command_config.__globals__[
        '_validate_setup_dir'
    ]
    _prep_setup_dir = each_sub_command_config.__globals__[
        '_prep_setup_dir'
    ]

    TestCase = collections.namedtuple(
        'TestCase',
        'setup_dir setup_dir_type exception'
    )

# Generated at 2022-06-25 17:44:54.422105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Simple example of each_sub_command_config
    try:
        test_case_0()
    except:
        print('Exception raised:')
        print(traceback.format_exc())
        return False



# Generated at 2022-06-25 17:45:04.081017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert next(generator_0) == SetupCfgCommandConfig(
        name='build',
        camel='Build',
        description='Build the package.',
        commands=('python setup.py build',)
    ), \
        "Unable to determine the next value from the generator returned by " \
        "function each_sub_command_config"
    assert next(generator_0) == SetupCfgCommandConfig(
        name='build_sphinx',
        camel='BuildSphinx',
        description='Build the Sphinx documentation.',
        commands=('python setup.py build_sphinx',)
    ), \
        "Unable to determine the next value from the generator returned by " \
        "function each_sub_command_config"

# Generated at 2022-06-25 17:45:09.727778
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Place the functionality you want to test below this line
    #########################################################

    # The first test case

    # The second test case

    # The third test case

    # The fourth test case

    # The fifth test case

    # The sixth test case

    #########################################################
    # Place the functionality you want to test above this line

    # Write your own test cases here
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:12.225406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError:
        pass


if __name__ == '__main__':
    print(list(each_sub_command_config()))

# Generated at 2022-06-25 17:45:37.677090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        generator_0 = each_sub_command_config()
    except:
        generator_0 = None
    assert isinstance(generator_0, Generator)
    assert isinstance(generator_0, Generator)


# Generated at 2022-06-25 17:45:38.346625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:39.318788
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:48.127408
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    class SetupCfgCommandConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]
    class SetupCfgCommandInfo(NamedTuple):
        format_kwargs: Dict[str, str]
        config: SetupCfgCommandConfig

    cfg_path = 'setup_commands.cfg'
    class ConfigParser:
        '''Stub for ConfigParser class'''
        class NoSectionError: '''Stub for NoSectionError class'''
        class NoOptionError: '''Stub for NoOptionError class'''
        def __init__(self):
            self.sections = []  # type: List[str]
            # Stub method takes args and returns value
            raise NotImplementedError()

# Generated at 2022-06-25 17:45:51.050362
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
        print('[PASS]')
    except Exception as e:
        print('[FAIL]')
        print(e.args)

# Main entry point

# Generated at 2022-06-25 17:45:52.044209
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:59.050353
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    generator_1 = each_sub_command_config()
    generator_2 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = next(generator_1)
    var_2 = next(generator_2)
    var_3 = next(generator_2)
    var_4 = next(generator_2)
    var_5 = next(generator_1)


if __name__ == '__main__':
    test()

# Generated at 2022-06-25 17:46:01.167969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    return None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:46:03.004679
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '../../demo'
    test_case_0()

# Generated at 2022-06-25 17:46:11.675660
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Mocking the setup.cfg, setup_commands.cfg and setup.py files in
    ./testcase/setup_dir_0.
    """
    generator_0 = each_sub_command_config('./testcase/setup_dir_0')
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:47:26.992421
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    if len(var_0) != 7:
        raise AssertionError(
            "The length of 'each_sub_command_config()' is %d and not %d."
            % (len(var_0), 7)
        )
    if var_0[0].name != 'package':
        raise AssertionError(
            "The 0th element of 'each_sub_command_config()' is %r and not %r."
            % (var_0[0].name, 'package')
        )

# Generated at 2022-06-25 17:47:29.363700
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Run unit tests if invoked directly
if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:34.887619
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Testing that None is returned
    generator_0 = each_sub_command_config()
    assert next(generator_0, None) is not None

    # Testing that each_sub_command_config returns an iterator
    generator_1 = each_sub_command_config()
    assert isinstance(generator_1, Generator)

    # Testing that the iterator returned by each_sub_command_config returns
    # a tuple
    generator_2 = each_sub_command_config()
    assert isinstance(next(generator_2), SetupCfgCommandConfig)

# Generated at 2022-06-25 17:47:37.674584
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config')
    test_case_0()
    print('Function each_sub_command_config completed')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:41.943334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _func_0():
        global generator_0
        generator_0 = each_sub_command_config()
        var_0 = list(generator_0)
        assert len(var_0) == 0
    test_case_0()

# Generated at 2022-06-25 17:47:43.877365
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pytest.deprecated_call(test_case_0())

# Generated at 2022-06-25 17:47:47.277458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None


if __name__ == '__main__':
    print('Running unit tests for each_sub_command_config')
    print('test_each_sub_command_config: ', end='')
    test_each_sub_command_config()
    print('PASSED')

# Generated at 2022-06-25 17:47:53.484194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # setup.py is missing
    setup_dir = str(os.path.join(os.path.dirname(__file__), 'test_data_0'))
    with pytest.raises(FileNotFoundError) as ex:
        each_sub_command_config(setup_dir)
    assert str(ex.value) == (
        "The given 'setup_dir' of %r does NOT contain a setup.py file."
        % setup_dir
    )

    # Invalid setup.dir (does not exist)
    setup_dir = str(os.path.join(os.path.dirname(__file__), 'test_data_0'))
    with pytest.raises(FileNotFoundError) as ex:
        each_sub_command_config(setup_dir)

# Generated at 2022-06-25 17:47:59.886975
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0, None)
    assert var_0
    var_1 = var_0.name
    assert var_1 == 'subcommand-test'
    assert var_0.camel == 'Subcommand_test'
    assert var_0.description == 'subcommand-test sub cmd.'
    assert var_0.commands == ('echo subcommand-test',)
    var_0 = next(generator_0, None)
    assert var_0 is None


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:48:10.008194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    testing_tools.set_style(testing_tools.Style.GOOGLE_DOCSTRING)
    g = each_sub_command_config('test/test_sub_command_config')

# Generated at 2022-06-25 17:50:29.053791
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)

# Generated at 2022-06-25 17:50:29.536966
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:50:36.236274
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    setup_dir = os.path.join(os.path.dirname(__file__), '..')

# Generated at 2022-06-25 17:50:37.059249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:44.728358
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    func_0 = each_sub_command_config
    try:
        func_0()
        assert False
    except FileNotFoundError:
        pass
    except:
        assert False
    try:
        func_0('/foo')
        assert False
    except FileNotFoundError:
        pass
    except:
        assert False
    try:
        func_0('/foo')
        assert False
    except FileNotFoundError:
        pass
    except:
        assert False
    import sys
    old_sys_path = sys.path
    sys.path.append(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'pkgs',
        'pkg0'
    ))
    import setup_pkg
    var_0 = setup_pkg
    var

# Generated at 2022-06-25 17:50:52.936721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .setup_commands import each_sub_command_config
    from flutils.configutils import (
        ConfigDict,
    )
    from typing import Dict, Tuple
    import textwrap

# Generated at 2022-06-25 17:50:55.031440
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #
    # Call the function under test
    #
    test_case_0()

# Generated at 2022-06-25 17:51:01.059820
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config."""
    # Arrange
    setup_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            os.pardir
        )
    )
    # Configure
    # Act
    results = list(each_sub_command_config(setup_dir))
    print(results)
    # Assert
    assert len(results) > 0

# Generated at 2022-06-25 17:51:04.111502
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in range(2):
        try:
            test_case_0()
        except:
            print('Exception: %s' % sys.exc_info()[0])
            print(sys.exc_info()[1])
            traceback.print_tb(sys.exc_info()[2])

# Generated at 2022-06-25 17:51:04.869721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()