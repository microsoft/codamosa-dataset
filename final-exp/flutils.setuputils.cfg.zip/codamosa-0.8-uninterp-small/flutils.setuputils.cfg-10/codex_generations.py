

# Generated at 2022-06-25 17:41:51.148730
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert generator_0
    assert next(generator_0).name == 'sdist'
    assert next(generator_0).name == 'bdist_wheel'
    assert next(generator_0).name == 'bdist_wheel_pure'
    assert next(generator_0).name == 'develop'
    assert next(generator_0).name == 'install'
    assert next(generator_0).name == 'clean'
    assert next(generator_0).name == 'test'
    assert next(generator_0).name == 'release'
    assert next(generator_0).name == 'pypi_check'
    assert next(generator_0).name == 'publish_docs'

# Generated at 2022-06-25 17:42:00.018096
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    name = 'flutils'
    camel = 'Flutils'
    description = (
        'Lists each of the setup commands and their description.'
    )
    command = (
        'python setup.py list_commands'
    )
    commands = (command,)

    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert config.name == name
        assert config.camel == camel
        assert config.description == description
        assert config.commands == commands


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:01.611493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """TODO"""
    pass

# Generated at 2022-06-25 17:42:04.754059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    for i in range(0, 1):
        cmd_config = next(generator)
        # assert ...
    with pytest.raises(StopIteration):
        next(generator)

# Generated at 2022-06-25 17:42:07.682916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO:
    #  1. Write the test case
    #  2. Generate output for the test case
    #  3. Add assertions for the test case to assert that each_sub_command_config
    #     returns the expected result.
    pass

# Generated at 2022-06-25 17:42:09.334289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    pass



# Generated at 2022-06-25 17:42:10.579668
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        pass


# Generated at 2022-06-25 17:42:14.062236
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result_0 = list(each_sub_command_config())
    print('result_0:')
    print(result_0)

test_case_0()
test_each_sub_command_config()

# Generated at 2022-06-25 17:42:20.088186
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_config in each_sub_command_config():
        assert isinstance(sub_config.name, str)
        assert isinstance(sub_config.camel, str)
        assert isinstance(sub_config.description, str)
        assert isinstance(sub_config.commands, tuple)
        for command in sub_config.commands:
            assert isinstance(command, str)



# Generated at 2022-06-25 17:42:26.598323
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config('/home/jm/src/flutils/tests/fake_project')
    x_0 = next(generator_0)
    assert x_0 == SetupCfgCommandConfig(
        'myproject.myproject_version',
        'MyprojectVersion',
        'Displays the version of the project.',
        ('python3 setup.py --version',)
    )
    x_1 = next(generator_0)
    assert x_1 == SetupCfgCommandConfig(
        'myproject.myproject_help',
        'MyprojectHelp',
        'Displays help for the project.',
        ('python3 setup.py --help',)
    )
    x_2 = next(generator_0)

# Generated at 2022-06-25 17:42:36.162171
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    pass


# Prevent the test script from running when the module is being imported.
if __name__ == '__main__':
    test_each_sub_command_config()
    pass

# Generated at 2022-06-25 17:42:36.997799
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:42:40.226382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as err:
        print('Exception raised: {0}'.format(err))
    else:
        print('No exception raised.')

# Test code

# Generated at 2022-06-25 17:42:50.526034
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        each_sub_command_config,
        test_each_sub_command_config,
    )
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = test_case_0()
    var_2 = list(each_sub_command_config(None))
    var_3 = list(each_sub_command_config('flutils'))
    var_4 = list(each_sub_command_config(__file__))
    var_5 = test_each_sub_command_config()
    var_6 = list(each_sub_command_config(__file__))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:42:53.470145
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 17:42:57.207059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

if __name__ == '__main__':
    import sys
    import doctest

    doctest.testmod()

    sys.exit(test_each_sub_command_config())

# Generated at 2022-06-25 17:43:06.958777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    import sys
    prog_name = os.path.basename(sys.argv[0])
    prog_version = '0.0.1'
    if len(sys.argv) != 1:
        print('%s version %s' % (prog_name, prog_version), file=sys.stderr)
        print('usage: %s' % prog_name, file=sys.stderr)
        sys.exit(1)
    else:
        print('%s version %s' % (prog_name, prog_version))
        test_each_sub_command_config()
        sys.exit(0)

# Generated at 2022-06-25 17:43:15.607291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """ Test that it can identify each sub command from the project's
        setup.cfg file.
    """
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 2
    assert var_0[0] == SetupCfgCommandConfig(
        'flutils.make_sub_commands',
        'MakeSubCommands',
        'Make Sub Commands',
        (
            'python -c "from %(setup_dir)s.flutils.make_sub_commands import '
            'MakeSubCommands; MakeSubCommands.main()"',
        )
    )

# Generated at 2022-06-25 17:43:25.246172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    os.chdir(os.path.dirname(__file__))
    os.chdir('..')
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = assertEqual(var_0, [])
    os.chdir('test')
    os.chdir('setupcfg_test')
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = assertEqual(var_0, [])
    os.chdir('..')
    os.chdir('test_data')
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = assertEqual(var_0, [])

# Generated at 2022-06-25 17:43:26.547156
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit tests for function 'each_sub_command_config'."""
    test_case_0()



# Generated at 2022-06-25 17:43:45.241976
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config')
    try:
        test_case_0()
        print('PASSED: test_case_0')
    except StopIteration:
        print('FAILED: test_case_0')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:45.729784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True

# Generated at 2022-06-25 17:43:46.480780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:48.886331
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config('/Users/michaelherman/projects/flutils')


# Unit test
if __name__ == "__main__":
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:00.404048
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setup_utils as setup_utils
    import tedutil.test.test_utils as test_utils

    # Case #0
    test_utils.case_helper(
        case_0,
        (
            'setup_dir',
            {
                'expected': setup_utils.SetupCfgCommandConfig,
                'value': None
            }
        ),
    )
    # Case #1
    test_utils.case_helper(
        case_1,
        (
            'setup_dir',
            {
                'expected': setup_utils.SetupCfgCommandConfig,
                'value': '/home/ted/sandbox/flutils'
            }
        ),
    )
    # Case #2

# Generated at 2022-06-25 17:44:07.585477
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = r'C:\Users\druck\AppData\Local\Programs\Python\Python36-32\Lib\site-packages\flutils'
    cmds = each_sub_command_config(setup_dir)
    assert next(cmds) == SetupCfgCommandConfig(name='build', camel='Build',
                                               description='Build flutils.',
                                               commands=('python3 setup.py bdist_wheel',))
    assert next(cmds) == SetupCfgCommandConfig(name='build-all', camel='BuildAll',
                                               description='Build flutils for all supported versions of Python.',
                                               commands=('python3 setup.py bdist_wheel',))

# Generated at 2022-06-25 17:44:15.972013
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    test_dir = tempfile.TemporaryDirectory()
    try:
        test_dir_path = test_dir.name
        with open(os.path.join(test_dir_path, 'setup.py'), 'w') as f:
            f.write("\n")
        with open(os.path.join(test_dir_path, 'setup.cfg'), 'w') as f:
            f.write("[metadata]")
            f.write("\n")
            f.write("name = MyTestPackage")
            f.write("\n")
        test_case_0()
    finally:
        test_dir.cleanup()
    import flutils.configutils
    reload(flutils.configutils)

# Generated at 2022-06-25 17:44:25.980472
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setup_utils
    import tempfile
    import shutil
    import pathlib
    import os
    import os.path

    tmp_dir = tempfile.mkdtemp()
    scripts_dir = os.path.join(tmp_dir, 'scripts')
    os.makedirs(scripts_dir)
    os.mkdir(os.path.join(tmp_dir, 'tests'))
    setup_dir = os.path.join(tmp_dir, 'src', 'foo')
    os.makedirs(setup_dir)
    setup_cfg = pathlib.Path(setup_dir) / 'setup.cfg'
    setup_cfg.touch()
    (setup_cfg.parent / 'setup_commands.cfg').touch()

# Generated at 2022-06-25 17:44:28.617951
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    generator_0 = each_sub_command_config()



# Generated at 2022-06-25 17:44:39.347088
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from unittest.mock import patch
    from io import StringIO
    from pathlib import Path

    class TSetupCfgCommandConfig(NamedTuple):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]

    class MockConfigParser:

        def __init__(self):
            self.init_setup_cfg()

        def read(self, filepath: str) -> None:
            if filepath == 'setup.cfg':
                return self.init_setup_cfg()
            if filepath == 'setup_commands.cfg':
                return self.init_setup_commands_cfg()
            raise FileNotFoundError(filepath)

        def sections(self) -> List[str]:
            return self.data.keys()

       

# Generated at 2022-06-25 17:45:06.614403
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from .test_utils import (
        get_function_name,
        run_function_unit_tests
    )

    tests = (
        test_case_0,
    )

    run_function_unit_tests(
        tests=tests,
        func=get_function_name(
            os.path.abspath(__file__),
            each_sub_command_config.__name__
        )
    )

# Generated at 2022-06-25 17:45:14.898035
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # The following call to funtion each_sub_command_config raises
    # FileNotFoundError
    # each_sub_command_config()

    generator_0 = each_sub_command_config('..')
    var_0 = next(generator_0)
    assert var_0.name == 'clean'
    assert var_0.camel == 'Clean'
    assert var_0.description == 'Removes all generated files.'
    assert var_0.commands == (
        'rm -rf build dist flutils.egg-info',
        'rm -rf __pycache__',
    )

    generator_1 = each_sub_command_config('..')
    var_1 = next(generator_1)
    assert var_1.name == 'clean.docs'

# Generated at 2022-06-25 17:45:23.311009
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_1 = SetupCfgCommandConfig(
        'clean',
        'Clean',
        'Cleans up the generated artifacts.',
        (
            'rm -rf .tox/ .coverage .coverage.* coverage.xml htmlcov/ .lgoti'
            ' .pytest_cache/ .pylint.d/ build/ dist/ docs/_build/'
            ' docs/_themes/.doctrees/ docs/_themes/.buildinfo/',
            'find -name "*.pyc" -delete',
            'find -name "*.pyo" -delete',
            'find -name "__pycache__" -delete',
            'rm -rf .eggs/ .eggs-info/'
        )
    )

# Generated at 2022-06-25 17:45:33.004859
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test of function each_sub_command_config where
    #   setup_dir is not given.
    assert test_each_sub_command_config.__name__ == 'test_each_sub_command_config'
    try:
        test_case_0()
        test_each_sub_command_config.result = False
    except:
        test_each_sub_command_config.result = True
    finally:
        if test_each_sub_command_config.result is False:
            print("Test Cases")
            print("==========")
            print("Case: 0")
            print("=======")
            print("Input: ")
            print("  setup_dir")
            print("Output:")
            print("  Exception was not thrown")
        else:
            print("Test Cases")

# Generated at 2022-06-25 17:45:42.063050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config ...')

    def _test_case(kwargs: dict) -> Tuple[str, str]:
        generator_0 = each_sub_command_config(**kwargs)
        value_0 = cast(Tuple[str, str], next(generator_0))[1]
        return value_0

    tb = "setup.cfg is missing the [metadata] section."
    tb = tb.replace('setup.cfg', 'setup_commands.cfg')
    tb = tb.replace('[metadata]', '[setup.command.example]')
    exp_0 = 'setup.cfg is missing the [setup.command.example] section.'
    try:
        _test_case({})
    except FileNotFoundError as exc:
        assert exp_0 == tb


# Generated at 2022-06-25 17:45:44.628231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('sucess')
# Execute main
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:48.831591
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    res = list(each_sub_command_config(os.path.dirname(os.path.abspath(__file__))))
    assert res == [
        SetupCfgCommandConfig(
            name='app.main',
            camel='AppMain',
            description='The application\'s main entry point.',
            commands=('python -m app',)
        )
    ]

# Generated at 2022-06-25 17:45:52.798593
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test raise FileNotFoundError
    try:
        each_sub_command_config(setup_dir='/tmp/')
        assert False
    except FileNotFoundError:
        pass


# Execute the test case
test_case_0()
test_each_sub_command_config()

# Generated at 2022-06-25 17:46:03.297202
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'tests/testdata/setupcfg_test'
    generator_0 = each_sub_command_config(setup_dir)

    var_0 = next(generator_0)
    assert var_0.name == 'flutils.test'
    assert var_0.camel == 'FlutilsTest'
    assert var_0.description == 'Runs a series of tests'
    assert var_0.commands == ('pytest',)

    var_1 = next(generator_0)
    assert var_1.name == 'flutils.autopep'
    assert var_1.camel == 'FlutilsAutopep'
    assert var_1.description == 'Runs autopep8 on the code'
    assert var_1.commands == ('autopep8',)

    var_2 = next

# Generated at 2022-06-25 17:46:09.362517
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    var_0 = str(var_0)
    assert var_0 == "SetupCfgCommandConfig(name='deploy', camel='Deploy', description='Preps and deploys the package', commands=('python setup.py sdist bdist_wheel', 'twine upload --skip-existing dist/*'))"

# vim:set ts=8 sw=4 sts=4 tw=78 et:

# Generated at 2022-06-25 17:46:52.987093
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Get current path
    import os
    import sys
    current_path = os.path.dirname(os.path.abspath(__file__))

    cont = True
    while cont:
        cont = False
        try:
            generator_0 = each_sub_command_config(current_path)
            var_0 = next(generator_0)
        except StopIteration:
            pass
        except Exception as e:
            print(e)
            print("Caught exception while calling each_sub_command_config with arguments:")
            print("    setup_dir = {}".format(current_path))
            raise


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:59.773781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test 1
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    # Test 2
    setup_dir = ''
    generator_1 = each_sub_command_config(setup_dir)
    var_1 = next(generator_1)
    # Test 3
    setup_dir = ''
    generator_2 = each_sub_command_config(setup_dir)
    var_2 = next(generator_2)
    # Test 4
    generator_3 = each_sub_command_config()
    var_3 = next(generator_3)
    # Test 5
    setup_dir = ''
    generator_4 = each_sub_command_config(setup_dir)
    var_4 = next(generator_4)
    # Test 6
   

# Generated at 2022-06-25 17:47:09.253900
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    path = os.path.realpath(path)
    path = os.path.join(path, '..', 'setup_commands')
    path = os.path.realpath(path)
    generator_0 = each_sub_command_config(path)
    assert isinstance(generator_0, Generator)
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert isinstance(var_0.name, str)
    assert var_0.name == 'test'
    assert isinstance(var_0.camel, str)
    assert var_0.camel == 'Test'
    assert isinstance(var_0.description, str)

# Generated at 2022-06-25 17:47:13.807773
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    import pprint

    os.chdir(os.path.dirname(__file__))

    for var_0 in each_sub_command_config():
        assert type(var_0) is SetupCfgCommandConfig
        pprint.pprint(var_0)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:20.148450
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    # each_sub_command_config():
    """
    print('::: TEST: test_each_sub_command_config()')

    from pprint import pprint
    from flutils.dirdiff import list_dirs
    # from flutils.pathutils import list_files

    TEST_SETUPS = [f for f in list_dirs() if f.name == 'setup.py']

    for setup in TEST_SETUPS:
        setup_dir = setup.dir
        print('setup_dir:', setup_dir)

        for config in each_sub_command_config(setup_dir):
            print('config:', config)



# Generated at 2022-06-25 17:47:22.713464
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except TypeError:
        pass

# Generated at 2022-06-25 17:47:32.896361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    _setup_dir: str
    _setup_cfg_path: str
    _parser: ConfigParser
    _format_kwargs: Dict[str, str]
    _generator_0: Generator[SetupCfgCommandConfig, None, None]
