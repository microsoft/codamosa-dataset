

# Generated at 2022-06-25 17:41:51.444122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from os import remove
    from tempfile import mkdtemp
    from configparser import ConfigParser

    def _create_test_setup_cfg(tmp_dir: str) -> None:
        with open(join(tmp_dir, 'setup_commands.cfg'), 'w') as out_file:
            print('[setup.command.bump]', file=out_file)
            print('name=bump_{name}', file=out_file)
            print('description=Bumps the version of the "{name}" package',
                  file=out_file)
            print('commands=', file=out_file)
            print('    bumpver patch', file=out_file)
            print('    python setup.py sdist', file=out_file)

# Generated at 2022-06-25 17:41:53.856942
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('passed')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:03.943309
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    dir_path = os.path.dirname(os.path.abspath(__file__))
    setup_cfg_path = os.path.join(dir_path, 'test_setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    assert len(tuple(parser.sections())) == 3

    generator_0 = each_sub_command_config(dir_path)
    assert len(tuple(generator_0)) == 6

    generator_1 = each_sub_command_config(
        os.path.join(dir_path, 'test_pkg')
    )
    assert len(tuple(generator_1)) == 6


if __name__ == '__main__':
    test_case_0()

    test_each_sub_command_config()

   

# Generated at 2022-06-25 17:42:04.834334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:42:07.770534
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    print("generator_0 =", generator_0)


if __name__ == '__main__':
    test_case_0()
    # test_each_sub_command_config()

# Generated at 2022-06-25 17:42:14.165855
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    for cmd in each_sub_command_config():
        print("%s:\n    {%s}\n" % (cmd.name, '\n    '.join(cmd.commands)))


# Run the unit tests
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:21.554844
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(
            '%(name)30s %(camel)20s %(description)s'
            % vars(sc)
        )
        print('\t%s' % '\n\t'.join(map(repr, sc.commands)))
    print('Test Success!')


if __name__ == '__main__':
    test_case_0()  # Test func each_sub_command_config
    test_each_sub_command_config()  # Test func each_sub_command_config

# Generated at 2022-06-25 17:42:26.230400
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def f_0():
        generator_0 = each_sub_command_config()
        for item in generator_0:
            print(item)
    f_0()

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:34.588128
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import each_sub_command_config
    from flutils.testutils import run_function_unit_test

    def err_handler(exc_type, exc_value, exc_traceback):
        from traceback import format_exception
        from flutils.logutils import echo
        msg = ''.join(format_exception(exc_type, exc_value, exc_traceback))
        echo(msg, file=sys.stdout)

    def set_up():
        pass

    def tear_down():
        pass

    def test_case_0():
        generator_0 = each_sub_command_config()
        for config_0 in generator_0:
            assert isinstance(config_0, SetupCfgCommandConfig)
            assert isinstance(config_0.camel, str)

# Generated at 2022-06-25 17:42:36.663913
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert(generator_0.__class__.__name__ == 'generator')
    assert(len(list(generator_0)) == 0)

# Generated at 2022-06-25 17:42:54.350520
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_1 = (
        'tests',
        {
            'name': 'pyutils',
            'commands': (
                'python setup.py test --\\',
                '    addopts "--cov=src/pyutils --cov-branch '
                '--cov-report=html --cov-report=term --verbose"'
            ),
            'description': 'Run the unit tests of the package.',
            'camel': 'Pyutils'
        }
    )
    generator_1 = each_sub_command_config(var_1[0])
    result_1 = None
    for i_1 in generator_1:
        result_1 = i_1
    assert result_1 == var_1[1]

# Generated at 2022-06-25 17:43:05.555312
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(setup_dir='/home/my_home/github_dev/flutils')
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:43:06.640666
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:43:08.970547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    runner = CliRunner()
    result = runner.invoke(build_sub_commands, catch_exceptions=False)
    assert result.exit_code == 0

# Generated at 2022-06-25 17:43:10.391285
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: add unit test
    test_case_0()



# Generated at 2022-06-25 17:43:18.009645
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import logging
    from io import StringIO
    from flutils.testutils import capture_output
    from flutils.testutils import capture_logger

    test_logger = logging.getLogger(__name__)

    logging.basicConfig(level=logging.DEBUG)

    var_1 = next(each_sub_command_config())
    assert var_1.name == 'check'
    assert var_1.camel == 'Check'
    assert var_1.description == 'Runs check command.'
    assert var_1.commands == (
        '{setup_dir}/make check && '
        '{setup_dir}/make test',
    )

    with capture_logger(test_logger) as captured:
        var_1 = next(each_sub_command_config())
        assert var_1

# Generated at 2022-06-25 17:43:20.790610
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert var_0 is not None


# Generated at 2022-06-25 17:43:23.347043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Arrange
    generator_0 = each_sub_command_config()

    # Act
    var_0 = list(generator_0)

    # Assert
    assert len(var_0) == 1

# Generated at 2022-06-25 17:43:24.624751
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)



# Generated at 2022-06-25 17:43:31.262862
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        os.path.dirname(__file__),
        'setup_commands.cfg'
    )
    format_kwargs = {
        'setup_dir': os.path.dirname(setup_cfg_path),
        'home': os.path.expanduser('~'),
        'name': 'test'
    }
    parser = ConfigParser()
    parser.read(setup_cfg_path)

# Generated at 2022-06-25 17:43:38.699338
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:41.238493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setup_utils import each_sub_command_config
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    return

# Generated at 2022-06-25 17:43:49.466688
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:43:50.655152
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config() == list(each_sub_command_config())

# Generated at 2022-06-25 17:44:02.900643
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os

    def _get_dir_name(dir_path: str) -> str:
        """
        Given a directory path, return the directory name.
        """
        return os.path.basename(os.path.normpath(dir_path))

    dir_0 = os.path.dirname(__file__)
    if _get_dir_name(dir_0).lower() != 'test':
        dir_0 = os.path.join(dir_0, '..', 'test')

    dir_1 = os.path.join(dir_0, 'test_cases')

    var_0 = os.listdir(dir_1)
    var_1 = os.path.join(dir_1, 'case_0')
    var_2 = _get_dir_name(var_1)



# Generated at 2022-06-25 17:44:05.789791
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test cases to execute.
    test_cases = (
        # Test case 0
        tuple(),
    )
    for test_case in test_cases:
        if test_case:
            print(test_case[0])
        test_case_0(*test_case)



# Generated at 2022-06-25 17:44:14.696594
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        next(each_sub_command_config())
        assert False
    except FileNotFoundError:
        assert True
    try:
        next(each_sub_command_config(''))
        assert False
    except FileNotFoundError:
        assert True
    try:
        next(each_sub_command_config('tests'))
        assert False
    except FileNotFoundError:
        assert True
    try:
        next(each_sub_command_config(__file__))
        assert False
    except FileNotFoundError:
        assert True
    try:
        next(each_sub_command_config(__file__ + '.py'))
        assert False
    except FileNotFoundError:
        assert True

# Generated at 2022-06-25 17:44:25.124017
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    item_0 = next(each_sub_command_config())
    assert type(item_0) is SetupCfgCommandConfig
    assert item_0.name == 'load-config'
    assert item_0.camel == 'LoadConfig'
    assert item_0.description == ''
    assert type(item_0.commands) is tuple
    item_1 = next(each_sub_command_config())
    assert type(item_1) is SetupCfgCommandConfig
    assert item_1.name == 'save-config'
    assert item_1.camel == 'SaveConfig'
    assert item_1.description == ''
    assert type(item_1.commands) is tuple
    item_2 = next(each_sub_command_config())
    assert type(item_2) is SetupCfgCommandConfig

# Generated at 2022-06-25 17:44:30.963845
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function ``each_sub_command_config``."""
    from .utils import (
        SetupCfgCommandConfig,
        each_sub_command_config,
        test_dir,
    )

    # Test case 0

# Generated at 2022-06-25 17:44:41.056161
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import abspath, dirname
    base_path = dirname(abspath(__file__))
    actual = sorted(
        each_sub_command_config(
            os.path.join(base_path, 'etc', 'project_with_commands')
        ),
        key=lambda x: x.name
    )

    assert actual[0].description == 'Creates the docs.'
    assert actual[0].camel == 'BuildDocs'
    assert actual[0].name == 'build_docs'
    assert actual[0].commands == (
        'python -m build_commands.build_docs --help',
        'python -m build_commands.build_docs --help-all',
    )

    assert actual[1].description == 'Builds the package.'

# Generated at 2022-06-25 17:44:58.714450
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert var_0.name == "test.test"
    assert var_0.camel == "TestTest"
    assert var_0.description == ""
    assert var_0.commands == ()
    assert_raises(StopIteration, next, generator_0)


# Generated at 2022-06-25 17:45:00.248640
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Function each_sub_command_config"""
    # TODO: Somehow test this...

# Generated at 2022-06-25 17:45:07.163564
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def test_case_0(self):
            generator_0 = each_sub_command_config()
            var_0 = list(generator_0)

    suite = unittest.TestSuite()
    suite.addTest(TestCase('test_case_0'))
    result = unittest.TestResult()
    suite.run(result)
    if result.wasSuccessful():
        exit_code = 0
    else:
        exit_code = 1
    sys.exit(exit_code)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:15.242102
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the each_sub_command_config function."""
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:45:23.052060
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, 'test_data')
    config = list(each_sub_command_config(setup_dir=test_dir))
    assert len(config) == 1
    assert config[0].name == 'test-package.test-command'
    assert config[0].camel == 'TestPackageTestCommand'
    assert config[0].description == (
        'Runs the test for test-package'
    )
    assert len(config[0].commands) == 2
    assert config[0].commands[0] == 'echo hi'
    assert config[0].commands[1] == 'echo bye'

# Generated at 2022-06-25 17:45:24.467904
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert 'test_case_0' in globals()
    test_case_0()

# Generated at 2022-06-25 17:45:34.648248
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    try:
        next(generator_0)
        assert False, "The 'each_sub_command_config' generator was not consumed."
    except StopIteration:
        pass
    assert len(var_0) == 1, (
        "The 'each_sub_command_config' generator did NOT have 1 item.  "
        "Instead, it had: %s"
        % (len(var_0))
    )
    var_1 = var_0[0]

# Generated at 2022-06-25 17:45:37.077904
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    import pytest

    pytest.main(args=[__file__])

# Generated at 2022-06-25 17:45:38.949167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test simple types
    try:
        test_case_0()
    except:
        print("Test case 0 failed")


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:40.227398
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case 0
    assert test_case_0() is True

# Generated at 2022-06-25 17:46:30.109693
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:33.871933
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0()

if __name__ == '__main__':
    try:
        test_each_sub_command_config()
    except Exception as exc:
        print('Exception:', exc)
    else:
        print('No Exception.')

# Generated at 2022-06-25 17:46:38.765014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    d = os.path.dirname
    c = os.path.join(d(__file__), '..', '..', '..', '..', 'flutils', 'tests')
    config = list(each_sub_command_config(c))
    assert len(config)
    assert isinstance(config[0], SetupCfgCommandConfig)
    print('\n'.join(map(str, config)))

# Generated at 2022-06-25 17:46:40.432305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:44.919461
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Command line functions are tested within the project itself."""
    pass



# Generated at 2022-06-25 17:46:47.830612
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    TESTS = {
        'test_case_0': test_case_0,
    }
    test_start(__name__, TESTS)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 17:46:49.040191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:54.300349
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    import sys
    import unittest

    _unittest_main = unittest.main

    def unittest_main(argv: Optional[Union[List[str], Tuple[str]]] = None) -> None:
        if argv is None:
            argv = sys.argv[1:]
        return _unittest_main(
            module=__name__,
            exit=False,
            argv=argv
        )

    sys.exit(unittest_main())

# Generated at 2022-06-25 17:46:56.024084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.cfgutils import each_sub_command_config

    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:47:01.075935
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_dir in (
            None,
            '~/flutils/flutils',
            '~/flutils/tests/fixture/test_cmd_0',
            '~/flutils/tests/fixture/test_cmd_1',
            '~/flutils/tests/fixture/test_cmd_2',
            ):
        print('\nsub-command(s) for %r:' % setup_dir)
        for sub_command in each_sub_command_config(setup_dir):
            assert isinstance(sub_command, SetupCfgCommandConfig)
            print('    ', sub_command)

# Generated at 2022-06-25 17:48:04.980218
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from nose.tools import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_true,
        assert_false,
        assert_regexp_matches,
    )
    from flutils.setupcfg import (
        SetupCfgCommandConfig,
        each_sub_command_config,
    )

    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert_is_instance(var_0, list)

    length_0 = len(var_0)
    assert_is_instance(length_0, int)
    assert_equal(length_0, 1)

    var_1 = var_0[0]
    assert_is_instance(var_1, SetupCfgCommandConfig)

   

# Generated at 2022-06-25 17:48:14.219517
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    out_0 = next(generator_0)
    out_1 = next(generator_0)
    out_2 = next(generator_0)
    out_3 = next(generator_0)
    out_4 = next(generator_0)
    out_5 = next(generator_0)
    out_6 = next(generator_0)
    out_7 = next(generator_0)
    out_8 = next(generator_0)
    out_9 = next(generator_0)


if __name__ == '__main__':
    import os
    import sys
    from flutils.testing import (
        run_doctests,
        run_unittests,
    )


# Generated at 2022-06-25 17:48:19.034175
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    from unittest import main

    main()

# Generated at 2022-06-25 17:48:19.794316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:20.559333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:22.536574
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Should not raise any exceptions
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:48:29.003896
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config()) == \
        SetupCfgCommandConfig(
            name='create_instance',
            camel='CreateInstance',
            description='',
            commands=(
                'cd {setup_dir} && '
                'python setup.py create_instance --help',
            )
        )
    assert next(each_sub_command_config()) == \
        SetupCfgCommandConfig(
            name='flask',
            camel='Flask',
            description='',
            commands=(
                'cd {setup_dir} && '
                'python setup.py flask --help',
            )
        )

# Generated at 2022-06-25 17:48:35.623849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    generator_1 = each_sub_command_config()
    generator_2 = each_sub_command_config('.')

    var_0 = list(generator_0)
    var_1 = list(generator_1)
    var_2 = list(generator_2)

    assert var_0 == var_1
    assert var_0 == var_2


if __name__ == '__main__':
    import pytest
    pytest.cmdline.main(args=[__file__])

# Generated at 2022-06-25 17:48:41.912910
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os

    # Get a project with a setup.py
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, test_dir)

# Generated at 2022-06-25 17:48:44.181112
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['--capture=no', '--strict', __file__])

# Generated at 2022-06-25 17:51:01.136925
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError:
        pass

# Generated at 2022-06-25 17:51:03.877231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    for var_1 in var_0:
        test_case = each_sub_command_config()
        var = list(test_case)


# Generated at 2022-06-25 17:51:08.181177
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory
    from shutil import copytree

    d = TemporaryDirectory()
    d_path = os.path.join(d.name, 'flutils')
    copytree('tests/data', d_path)
    assert os.path.exists(d_path) is True
    var_0 = each_sub_command_config(d_path)
    var_1 = list(var_0)
    assert len(var_1) == 4
    d.cleanup()
    return True

# Generated at 2022-06-25 17:51:11.459046
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = len(var_0)
    assert var_1 == 0


if __name__ == "__main__":
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:51:21.996708
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert next(each_sub_command_config()) == SetupCfgCommandConfig(
        name='.',
        camel='_',
        description='''\
Ensures that the source code meets the standard.

This command, for example, runs all of the formatters, type
checkers, and linting tools.
''',
        commands=(
            '# Ensure that the source code meets the standard.',
            'python -W error -m flutils.format.run '
            '--vebosity=5 --auto-fix --output-file setup.cfg',
            'python -m flutils.typecheck.main --verbosity=1',
            'python -m flutils.lint.main --verbosity=1 --error-only',
        )
    )

# Generated at 2022-06-25 17:51:25.559151
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_gen = each_sub_command_config(os.path.dirname(__file__))
    for t in test_gen:
        print(t)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:51:33.291341
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from test_each_sub_command_config_0 import test_case_0

    frame = sys._getframe(1)
    caller_frame = frame
    test_cases = [
        test_case_0,
    ]
    for test_case in test_cases:
        caller_frame.f_globals.clear()
        caller_frame.f_globals.update(locals())
        with open(__file__) as f:
            while True:
                line = f.readline()
                if line.startswith('# Unit test for function each_sub_command_config'):
                    break
            while True:
                line = f.readline()
                if not line:
                    break
                caller_frame.f_globals.setdefault('__doc__', '')
               