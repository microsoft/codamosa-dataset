

# Generated at 2022-06-25 17:41:49.745963
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config():
        print(setup_cfg_command_config)

# Generated at 2022-06-25 17:41:59.388967
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:42:01.006731
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    output = list(each_sub_command_config())
    assert len(output) > 0

# Generated at 2022-06-25 17:42:11.040682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import textwrap

    with tempfile.TemporaryDirectory(dir='/tmp') as tmpdir:
        with open(os.path.join(tmpdir, 'setup.py'), 'w') as fout:
            print("""\
                import setuptools

                setuptools.setup(
                    name='proj_name',
                    version='1.2.3',
                )
                """, file=fout)
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as fout:
            print("""\
                [metadata]
                name = proj_name


                [setup.command.x]
                name = x_cmd
                command =
                    echo 'command'
                    echo 'command'
                """, file=fout)
        count_0 = 0

# Generated at 2022-06-25 17:42:13.814306
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Add test for each_sub_command_config
    raise NotImplementedError(
        "Test for function `each_sub_command_config` not implemented.")



# Generated at 2022-06-25 17:42:14.592587
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    list(each_sub_command_config())



# Generated at 2022-06-25 17:42:22.709593
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    out = list(each_sub_command_config(setup_dir))
    assert out[0].name == "commands_info"
    assert out[1].name == "dev.docs"
    assert out[2].name == "dev.test"
    assert out[3].name == "dev.test.type"
    assert out[4].name == "dev.test.coverage"
    assert out[5].name == "dev.test.coverage.report"
    assert out[6].name == "req.lint"
    assert out[7].name == "req.lint.type"

# Generated at 2022-06-25 17:42:32.652160
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    setup_cfg_command_config_1 = next(each_sub_command_config())
    assert setup_cfg_command_config_1.name == 'fluent_py'
    assert setup_cfg_command_config_1.camel == 'Clean'
    assert setup_cfg_command_config_1.description == 'Clean build artifacts'
    assert setup_cfg_command_config_1.commands == (
        'rm -rf build dist .eggs',
        'find . -regex ".*[.]py[co]$" -delete',
        'find . -name __pycache__ -delete'
    )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:34.030587
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        pass

# Generated at 2022-06-25 17:42:36.998287
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pkgs = {}
    result = each_sub_command_config()
    for cmd in result:
        pkgs[cmd.name] = cmd
    for pkg in ('a', 'b', 'c'):
        assert pkg in pkgs


# Generated at 2022-06-25 17:42:47.831544
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Call the function.
    generator = each_sub_command_config()
    assert isinstance(generator, Generator)
    # Fetch a value.
    try:
        next(generator)
    except StopIteration:
        pass
    else:
        raise Exception('Test #0 failed.')



# Generated at 2022-06-25 17:42:53.871521
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join('flutils', 'setup_commands', 'test')
    generator = each_sub_command_config(setup_dir)
    result = list(generator)
    assert result == [
        SetupCfgCommandConfig(
            'test.0',
            'Test0',
            'The test command 0',
            ('echo test command 0',)
        ),
        SetupCfgCommandConfig(
            'test.1',
            'Test1',
            'The test command 1',
            ('echo test command 1',)
        )
    ]

# Generated at 2022-06-25 17:42:56.723684
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:59.026679
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:00.195218
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:00.823335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:43:09.888251
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'C:/Users/Chris/Documents/GitHub/pyproject'
    generator_0 = each_sub_command_config(setup_dir=setup_dir)
    var_0 = list(generator_0)
    assert len(var_0) == 3
    assert var_0[0] == SetupCfgCommandConfig(
        'pre-install.win',
        'PreInstallWin',
        'Runs the pre-install.win.bat file.',
        (r'win10toast -t \'Flask-SSO-SAML\' -m '
         r'"The pre-install.win.bat script is being run."',
         r'powershell -ExecutionPolicy Bypass -File pre-install.win.bat',)
    )

# Generated at 2022-06-25 17:43:15.250501
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Testing function each_sub_command_config')
    try:
        test_case_0()
    except Exception:
        print('test_case_0 failed', file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
    else:
        print('test_case_0 passed')
    print('done')


# Run unit tests if executed from command-line
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:24.264938
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # test setup_dir
    generator_1 = each_sub_command_config(setup_dir='/tmp')
    var_1 = list(generator_1)
    assert len(var_1) == 1
    assert var_1[0].camel == 'Install'
    generator_2 = each_sub_command_config(setup_dir='/tmp/flutils')
    var_2 = list(generator_2)
    assert len(var_2) == 4
    assert var_2[0].camel == 'Install'
    assert var_2[1].camel == 'Lint'
    assert var_2[2].camel == 'Test'
    assert var_2[3].camel == 'Upload'

# Generated at 2022-06-25 17:43:25.049063
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:40.352135
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils._setup_utils import each_sub_command_config
    from flutils.strings import camel_to_snake

    for config in each_sub_command_config():
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for c in config.commands:
            assert isinstance(c, str)

        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

        assert config.camel == camel_to_snake(config.camel, lower=False)

# Generated at 2022-06-25 17:43:42.446936
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except BaseException:
        pass  # Unit test has failed
    else:
        pass  # Unit test has passed

# Generated at 2022-06-25 17:43:51.139838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Load the required config vars
    # Instantiate the main class and call the function under test.
    # Create a new instance of the test template class.
    var_0 = each_sub_command_config()
    try:
        # Assert the called function returns a Generator.
        assert isinstance(var_0, Generator)
        # Assert the called function returns no values on iteration.
        assert len(list(var_0)) == 0
    except AssertionError as e:
        print(e)
        # Store the error status and error message.
        var_1, var_2 = sys.exc_info()[:2]
        print(var_1, var_2)

# Generated at 2022-06-25 17:43:53.205602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    return



# Generated at 2022-06-25 17:43:57.810602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n*** Unit test for function: each_sub_command_config')
    test_case_0()
    print('Unit test complete.')


# Run the unit tests
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:01.077997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests each_sub_command_config."""
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()
    print('All test cases passed!')

# Generated at 2022-06-25 17:44:02.458944
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config."""
    test_case_0()


# Generated at 2022-06-25 17:44:06.419722
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("Test generator each_sub_command_config")

    try:
        test_case_0()

    except:
        print("Test execution failed")
        raise
    else:
        print("Test executed successfully")


# Unit test execution
if __name__ == '__main__':
    print("Start unit testing")
    test_each_sub_command_config()
    print("Stop unit testing")

# Generated at 2022-06-25 17:44:09.060476
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with CaptureOutput(relay=False):
        test_case_0()


if __name__ == '__main__':
    from flutils.testutils import AdvanceAssert

    a = AdvanceAssert()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:13.497863
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.dirname(__file__))
    ))
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    assert isinstance(var_0, list)



# Generated at 2022-06-25 17:44:36.829870
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert os.environ.get('TRAVIS_BUILD_DIR')
    generator_0 = each_sub_command_config(os.environ.get('TRAVIS_BUILD_DIR'))
    var_0 = next(generator_0, None)
    assert var_0 is not None
    assert isinstance(var_0, SetupCfgCommandConfig)
    var_1 = var_0.camel
    var_2 = var_0.commands
    var_3 = var_0.description
    var_4 = var_0.name
    assert var_1 is not None
    assert isinstance(var_1, str)
    assert isinstance(var_2, tuple)
    assert isinstance(var_3, str)
    assert isinstance(var_4, str)



# Generated at 2022-06-25 17:44:38.804397
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)



# Generated at 2022-06-25 17:44:48.115240
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test that :func:`each_sub_command_config` function works as expected."""
    generator_0 = each_sub_command_config(setup_dir='.')
    var_0 = list(generator_0)
    var_0.sort(key=lambda x: x.camel)
    var_0 = list(map(lambda x: (x.name, x.camel, x.commands), var_0))
    var_1 = [
        ('doc', 'Doc', ('sphinx-build -b html doc build/doc/html',)),
        ('lint', 'Lint', ('black --check .', 'flake8 .',)),
        ('release', 'Release', ('python setup.py sdist bdist_wheel upload',))
    ]
    assert var_0 == var_1

# Generated at 2022-06-25 17:44:53.846532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for test_case in (
            test_case_0,
    ):
        try:
            test_case()
        except Exception as err:
            print('Test failed.')
            print('Exception:')
            print(type(err).__name__, err, sep='\n', end='\n\n')
        else:
            print('Test passed.')
            print()

# Generated at 2022-06-25 17:45:03.484968
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_dir = os.path.dirname(os.path.realpath(__file__))
    project_dir = os.path.dirname(this_dir)
    generator_0 = each_sub_command_config(project_dir)
    assert next(generator_0) == SetupCfgCommandConfig(
        'run',
        'Run',
        'Run the main application.',
        (
            'python -m flutils.run \\"%(setup_dir)s\\"',
        )
    )

# Generated at 2022-06-25 17:45:06.051089
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command in each_sub_command_config():
        print(command)

if __name__ == '__main__':
    for arg in sys.argv[1:]:
        locals()['test_' + arg]()

# Generated at 2022-06-25 17:45:14.654438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests the ``each_sub_command_config`` function."""
    generator_0 = each_sub_command_config()
    if True:
        var_0 = list(generator_0)
        print(var_0)
        assert var_0 == [
            SetupCfgCommandConfig(
                name='pretest',
                camel='Pretest',
                description='Run tests before installing.',
                commands=('pytest',)
            ),
            SetupCfgCommandConfig(
                name='pretest-1',
                camel='Pretest_1',
                description='Run tests before installing.',
                commands=('pytest',)
            )
        ]

# Generated at 2022-06-25 17:45:16.561405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 17:45:25.897452
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config
    assert callable(each_sub_command_config)
    generator_0 = each_sub_command_config()
    for var_0 in generator_0:
        assert isinstance(var_0, SetupCfgCommandConfig)
        assert var_0.name
        assert isinstance(var_0.name, str)
        assert var_0.camel
        assert isinstance(var_0.camel, str)
        assert var_0.description
        assert isinstance(var_0.description, str)
        assert var_0.commands
        assert isinstance(var_0.commands, tuple)
        for var_1 in var_0.commands:
            assert var_1
            assert isinstance(var_1, str)
    generator_1 = each_sub_command

# Generated at 2022-06-25 17:45:35.651682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    gen = each_sub_command_config()
    var = []
    for gen_value in gen:
        var.append(gen_value)
    assert len(var) == 5
    assert var[0].name == 'test'
    assert var[0].camel == 'Test'
    assert var[0].description == 'Run all tests'
    assert var[0].commands == ('pytest',)
    assert var[1].name == 'test.fmt'
    assert var[1].camel == 'TestFmt'
    assert var[1].description == 'Run black formatting tests'
    assert var[1].commands == ('black --check .',)
    assert var[2].name == 'test.lint'
    assert var[2].camel == 'TestLint'

# Generated at 2022-06-25 17:45:58.172859
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import shutil
    import sys
    import tempfile
    import unittest


    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_py = os.path.join(self.temp_dir, 'setup.py')
            self.setup_command_cfg = os.path.join(self.temp_dir, 'setup_commands.cfg')
            self.test_package_directory = os.path.join(
                self.temp_dir, 'flutils_test_package')

# Generated at 2022-06-25 17:45:58.988757
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:01.360821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert var_0


# Generated at 2022-06-25 17:46:04.392745
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    x = each_sub_command_config()
    next(x)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:04.898687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:46:13.263031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from functools import partial
    from importlib import import_module
    from os import rename
    from shutil import copyfile, rmtree
    from tempfile import mkdtemp

    import flutils

    SETUP_CFG = """
[metadata]
name = flutils
version = 3.3.3

    [setup.command.clean]
    name = clean-project
    description = Clean the project's directories
    commands =
        clean
        -all:
            remove:
                - flutils.egg-info/
                - build/
                - dist/
    """


# Generated at 2022-06-25 17:46:19.974744
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test case for the function each_sub_command_config"""
    # Argument specification
    setup_dir: Optional[Union[os.PathLike, str]] = os.path.realpath(os.path.join(__file__, '..', '..', '..'))

    # Function call
    test_case_0()
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:46:20.759033
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:22.145121
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:46:25.480454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert list(each_sub_command_config()) == []


# Test the 'each_sub_command_config' function
if __name__ == '__main__':
    import sys

    try:
        each = each_sub_command_config(sys.argv[1])
        for itm in each:
            print(itm)
    except Exception as ex:
        print(ex)

# Generated at 2022-06-25 17:47:06.785690
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = SetupCfgCommandConfig(
        'setup.command.build',
        'SetupCommandBuild',
        'Build the distribution.',
        (
            'python setup.py sdist bdist_wheel',
            'twine upload -s dist/*'
        )
    )
    assert var_0[0] == var_1

# Generated at 2022-06-25 17:47:08.615527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:09.558556
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:47:16.698437
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests each_sub_command_config."""
    # Arrange
    test_dir_path = os.path.dirname(__file__)
    test_dir_path = os.path.realpath(test_dir_path)
    test_dir_path = os.path.join(test_dir_path, 'testproject-0.1')
    # Act
    generator_0 = each_sub_command_config(test_dir_path)
    var_0 = list(generator_0)
    # Assert
    assert len(var_0) == 5
    assert (
        var_0[0]
        == SetupCfgCommandConfig(
            'hello',
            'Hello',
            'Prints Hello World to the standard output',
            ('echo Hello world',)
        )
    )

# Generated at 2022-06-25 17:47:18.359994
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:29.555309
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected_0 = []
    expected_1 = [
        SetupCfgCommandConfig(
            'hello.world',
            'HelloWorld',
            '',
            ('echo hello world',),
        ),
        SetupCfgCommandConfig(
            'another-one',
            'AnotherOne',
            '',
            ('echo another one',),
        )
    ]

    import tempfile
    with tempfile.TemporaryDirectory() as cwd:
        var_0 = os.path.join(cwd, 'setup_commands.cfg')
        with open(var_0, 'w') as fd:
            fd.write('[setup.command.hello.world]\n')
            fd.write('command=echo hello world\n')
            fd.write('name=hello.world\n')
            fd

# Generated at 2022-06-25 17:47:33.526012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    assert len(var_0) == 0


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:39.902053
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cur_path = os.path.realpath(__file__)
    cwd = os.path.dirname(cur_path)
    cwd = os.path.split(cwd)[0]
    cwd = os.path.split(cwd)[0]
    cwd = os.path.join(cwd, 'example')
    generator = each_sub_command_config(setup_dir=cwd)
    configs = list(generator)

    assert configs


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:49.421402
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_1 = os.path.expanduser('~')
    var_2 = os.path.join(var_1, 'Desktop', 'flutils_dev')
    generator_1 = each_sub_command_config(var_2)
    var_3 = list(generator_1)
    var_4 = os.path.expanduser('~')
    var_5 = os.path.join(var_4, 'Desktop', 'flutils_dev')
    generator_2 = each_sub_command_config(var_5)
    var_6 = list(generator_2)

# Generated at 2022-06-25 17:47:49.912739
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:48:55.004539
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:48:55.674479
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:56.311686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # setup of test case
    test_case_0()

# Generated at 2022-06-25 17:48:57.078185
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:49:00.794272
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function ``_each_setup_cfg_command_section``."""
    var_1 = [var_0
             for var_0 in each_sub_command_config()]
    pass_test = True
    if pass_test is not True:
        assert pass_test


if __name__ == '__main__':
    from flutils.debugutils import set_tracer
    set_tracer('.stest_setup_cfg_utils.log')

    def test():
        test_case_0()
        test_each_sub_command_config()
    test()

# Generated at 2022-06-25 17:49:07.241393
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('test_each_sub_command_config:')
    import sys
    import os.path
    from flutils.sysutils import get_project_path
    project_path = cast(
        Optional[os.PathLike],
        get_project_path(__file__, 'flutils', __file__)
    )
    if project_path:
        project_path = os.path.join(project_path, 'setup_commands')
        if os.path.isdir(project_path):
            sys.path.append(os.path.dirname(project_path))
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:49:10.015227
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    # print(var_0)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:49:11.329114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    output = each_sub_command_config()
    assert next((True for _ in output), False) is True



# Generated at 2022-06-25 17:49:19.986992
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test with default args
    var_0 = each_sub_command_config()
    assert isinstance(var_0, Generator)
    assert next(
        var_0,
        SetupCfgCommandConfig(
            'build_binary_dist',
            'BuildBinaryDist',
            'Build binary distributions',
            (
                'python setup.py build_binary_dist',
            )
        )
    ) == SetupCfgCommandConfig(
        'build_binary_dist',
        'BuildBinaryDist',
        'Build binary distributions',
        (
            'python setup.py build_binary_dist',
        )
    )
    # Test with positional args
    var_1 = os.path.abspath(os.path.join(__file__, '..', '..', '..', '..'))
   

# Generated at 2022-06-25 17:49:22.190493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True


if __name__ == "__main__":
    import pytest
    argv = [__file__] + sys.argv[1:]
    ret = pytest.main(argv)
    sys.exit(ret)