

# Generated at 2022-06-25 17:41:49.174855
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:41:58.629470
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    ac_0 = next(generator_0)
    ac_1 = next(generator_0)
    ac_2 = next(generator_0)
    ac_3 = next(generator_0)
    ac_4 = next(generator_0)
    ac_5 = next(generator_0)
    ac_6 = next(generator_0)
    ac_7 = next(generator_0)
    ac_8 = next(generator_0)
    ac_9 = next(generator_0)
    ac_10 = next(generator_0)
    ac_11 = next(generator_0)
    ac_12 = next(generator_0)
    ac_13 = next(generator_0)
    ac_

# Generated at 2022-06-25 17:42:09.058890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unit_util

    unit_util.test_generator(
        each_sub_command_config,
        expected_iter=['setup.cfg', 'setup_commands.cfg'],
        expected_len=2
    )

    unit_util.test_generator(
        lambda: each_sub_command_config('docs'),
        expected_iter=[
            'pip_install_docs.cfg',
            'pip_install_docs.cfg',
            'pip_install_docs.cfg',
        ],
        expected_len=3
    )


if __name__ == '__main__':
    import unittest

    class Test(unittest.TestCase):
        def test_case_0(self):
            generator_0 = each_sub_command_config()

# Generated at 2022-06-25 17:42:19.799311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = tuple(each_sub_command_config())
    assert configs[:2] == (
        SetupCfgCommandConfig(
            'black', 'Black',
            'Runs the Black code formatter.',
            ('black -S src/flutils/',)
        ),
        SetupCfgCommandConfig(
            'black.check', 'BlackCheck',
            'Runs the Black code formatter with the "check" option.',
            ('black -S -l 79 src/flutils/',)
        ),
    )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:26.405176
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    l_sub_command_config_list: List[SetupCfgCommandConfig] = list()
    for l_sub_command_config in each_sub_command_config():
        l_sub_command_config_list.append(l_sub_command_config)
    l_expected_sub_command_config_list: List[SetupCfgCommandConfig] = list()

# Generated at 2022-06-25 17:42:29.459111
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None, (
        'Failed to run each_sub_command_config function.'
    )


if __name__ == "__main__":
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:38.166095
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Setup
    generator_0 = each_sub_command_config('/Users/proctor/git/flutils/setup')

    # Exercise
    setup_cfg_command_config_0 = next(generator_0)
    setup_cfg_command_config_1 = next(generator_0)
    setup_cfg_command_config_2 = next(generator_0)

    # Verify
    assert setup_cfg_command_config_0.name == 'build'
    assert setup_cfg_command_config_0.camel == 'Build'
    assert setup_cfg_command_config_0.description == 'Used to create the dist package.'
    assert setup_cfg_command_config_0.commands == ('python setup.py sdist',)

    assert setup_cfg_command_config_1.name == 'check'


# Generated at 2022-06-25 17:42:39.497386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) > 0

# Generated at 2022-06-25 17:42:49.959814
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, types.GeneratorType)

# Generated at 2022-06-25 17:42:56.780965
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert hasattr(config, 'name')
        assert hasattr(config, 'camel')
        assert hasattr(config, 'description')
        assert hasattr(config, 'commands')


if __name__ == '__main__':
    print(_prep_setup_dir())

# Generated at 2022-06-25 17:43:10.514152
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        each_sub_command_config,
    )
    from .cmn_cmd_cfg import (
        SubCommandConfig,
    )


# Generated at 2022-06-25 17:43:18.086929
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config."""
    from sys import (
        argv,
        exit,
        path,
    )
    from os.path import (
        join,
        isfile,
    )
    from shutil import (
        rmtree,
    )
    import tempfile

    # ORIG_PATH = path[:]
    # ORIG_ARGV = list(argv)

    # Make sure it can handle no setup.cfg file
    tmp_dir = tempfile.mkdtemp()
    try:
        assert each_sub_command_config(tmp_dir) is None
    finally:
        rmtree(tmp_dir, ignore_errors=True)

    # Make sure it can handle a corrupted setup.cfg file
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 17:43:26.637223
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import \
        assert_generator_equal
    from flutils.testutils import \
        GeneratorMatchResult
    from flutils.testutils import \
        GeneratorMatchResultConstants as GMRC
    setup_cfg_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.path.pardir,
            'flutils',
            'test',
            'extras',
            'setup.cfg'
        )
    )

# Generated at 2022-06-25 17:43:35.764454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests :func:`flutils.pathutils.each_sub_command_config`."""
    def _gen() -> Generator[SetupCfgCommandConfig, None, None]:
        yield SetupCfgCommandConfig(
            'command',
            'Command',
            'This is a description of this command.',
            ('echo "test"',)
        )
        yield SetupCfgCommandConfig(
            'command2',
            'Command2',
            'This is a description of this command.',
            ('echo "test"',)
        )

    def _test(
            setup_dir: Optional[Union[os.PathLike, str]] = None,
            *,
            count: int = 2,
            test_cases: Tuple[SetupCfgCommandConfig, ...] = Tuple(),
    ):
        gen = each_

# Generated at 2022-06-25 17:43:41.343807
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)

# Generated at 2022-06-25 17:43:49.527118
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test ``each_sub_command_config``."""
    generator = each_sub_command_config()

    config = next(generator)
    assert config.name == 'bump_release'
    assert config.camel == 'BumpRelease'
    assert config.description == 'Bump the release'
    assert config.commands == (
        'python -m flutils.project.bump_release_setup_commands',
        'python ./setup.py bdist_wheel',
    )

    config = next(generator)
    assert config.name == 'bump_release_post'
    assert config.camel == 'BumpReleasePost'
    assert config.description == 'Bump the release (post)'

# Generated at 2022-06-25 17:44:01.078547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.bootstraputils import get_bootstrap_file_path
    from flutils.pathutils import get_parent_dir


# Generated at 2022-06-25 17:44:07.021275
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import assert_generator
    from flutils.testutils import assert_not_raises

    generator_0 = each_sub_command_config()
    generator_1 = each_sub_command_config(setup_dir=__file__)
    for generator in (generator_0, generator_1):
        assert_generator(generator)
        with assert_not_raises():
            for config in generator:
                assert isinstance(config, SetupCfgCommandConfig)


if __name__ == '__main__':
    import sys
    import unittest

    sys.exit(unittest.main())

# Generated at 2022-06-25 17:44:15.971379
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.cmdutils

    generator_0 = each_sub_command_config(
        flutils.cmdutils.__file__
    )

    assert next(generator_0).name == 'setup_build'
    assert next(generator_0).name == 'setup_import_file'
    assert next(generator_0).name == 'setup_import_names'
    assert next(generator_0).name == 'setup_import_name'
    assert next(generator_0).name == 'setup_import_module'
    assert next(generator_0).name == 'setup_import_package'
    assert next(generator_0).name == 'setup_install'
    assert next(generator_0).name == 'setup_install_egg'

# Generated at 2022-06-25 17:44:23.962610
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert str(each_sub_command_config.__name__) == 'each_sub_command_config'
    assert str(each_sub_command_config.__qualname__) == 'each_sub_command_config'
    assert str(each_sub_command_config.__doc__) is not None


if __name__ == '__main__':
    try:
        test_each_sub_command_config()
        print('Test passed.')
    except AssertionError as exc:
        print(exc)
        sys.exit(1)


# EOF

# Generated at 2022-06-25 17:44:30.966873
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert 1 == 1



# Generated at 2022-06-25 17:44:35.907822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    import sys
    import unittest


    class TestCase(unittest.TestCase):
        def test_unit_test_0(self):
            test_case_0()

    unittest.main()

# Generated at 2022-06-25 17:44:37.582311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    assert type(generator) is Generator



# Generated at 2022-06-25 17:44:38.487529
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True



# Generated at 2022-06-25 17:44:40.416985
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = next(each_sub_command_config())
    assert var_0
    # assert None



# Generated at 2022-06-25 17:44:49.280453
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    var_1 = next(generator_0)
    var_2 = next(generator_0)
    var_3 = next(generator_0)
    var_4 = next(generator_0)
    var_5 = next(generator_0)
    var_6 = next(generator_0)
    var_7 = next(generator_0)
    var_8 = next(generator_0)
    var_9 = next(generator_0)
    var_10 = next(generator_0)
    var_11 = next(generator_0)
    var_12 = next(generator_0)
    var_13 = next(generator_0)
    var_

# Generated at 2022-06-25 17:44:57.214729
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    assert var_0.name == 'docs'
    assert var_0.description == ''
    assert var_0.camel == 'Docs'
    assert var_0.commands == ('cd docs; make html',)

if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:59.515693
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i in each_sub_command_config():
        print(i)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:03.162138
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir='/Users/duanhongyi/projects/flutils/flutils'
    name = 'flutils'
    for sub_command in each_sub_command_config(setup_dir):
        # print(sub_command.name)
        assert sub_command.name == name

# Generated at 2022-06-25 17:45:04.044260
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None

# Generated at 2022-06-25 17:45:26.539715
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Setup
    try:
        shutil.rmtree('/tmp/flutils')
    except OSError:
        pass
    shutil.copytree('subcommands_project1', '/tmp/flutils')

    # Exercise
    generator_0 = each_sub_command_config('/tmp/flutils')
    var_0 = next(generator_0)

    # Verify
    assert var_0.name == 'subcommands_project1'
    assert var_0.camel == 'SubcommandsProject1'
    assert var_0.description == 'subcommands_project1'
    assert var_0.commands == ('subcommands_project1', )
    var_1 = next(generator_0)
    assert var_1.name == 'subcommands_project2'
    assert var

# Generated at 2022-06-25 17:45:31.392206
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # each_sub_command_config()
    test_case_0()

if __name__ == '__main__':
    import sys
    import unittest


    class SetupCfgCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            test_each_sub_command_config()


    unittest.main()

# Generated at 2022-06-25 17:45:31.882420
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:45:41.348494
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils.setupcfg import SetupCfgCommandConfig
    
    # ConfigParser
    from configparser import ConfigParser
    
    # Dict
    from typing import Dict
    
    # Generator
    from typing import Generator
    
    # os.PathLike
    import os
    
    # str
    from typing import Final
    
    cmd_0: str = 'foo'
    desc_0: str = 'Foo sub-command.'
    desc_1: str = 'Bar sub-command.'
    
    
    
    
    
    
    class SetupCfgCommandConfig_0(SetupCfgCommandConfig):
        name: str
        camel: str
        description: str
        commands: Tuple[str, ...]
    
    
    
    
    
    
    
    
    
   

# Generated at 2022-06-25 17:45:50.401311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        generator_0 = each_sub_command_config()
        var_0 = next(generator_0)
        var_0 = each_sub_command_config('./test_data/test_package_0')
        var_0 = each_sub_command_config('test_data/test_package_0')
        var_0 = each_sub_command_config('./test_data/test_package_1')
        var_0 = each_sub_command_config('test_data/test_package_1')
        var_0 = each_sub_command_config('./test_data/test_package_2')
        var_0 = each_sub_command_config('test_data/test_package_2')
    except Exception as e:
        print(e)



# Generated at 2022-06-25 17:45:59.510822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(
        os.path.expandvars(
            '${HOME}/Projects/flutils'
        )
    )
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)
    var_0 = next(generator_0)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:01.206819
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 17:46:10.438467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # setup_dir must be a directory
    try:
        var_1 = each_sub_command_config(setup_dir='/tmp/no_file')
    except Exception as err:
        pass

    # setup_dir must be a directory
    try:
        var_2 = each_sub_command_config(setup_dir='/tmp/no_directory')
    except Exception as err:
        pass

    # setup_dir must contain a setup.py file
    try:
        var_3 = each_sub_command_config(setup_dir='/tmp')
    except Exception as err:
        pass

    # setup_dir must contain a setup.cfg file
    try:
        var_4 = each_sub_command_config(setup_dir='/tmp')
    except Exception as err:
        pass

# Generated at 2022-06-25 17:46:17.268079
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import os.path

    from tests.test_utils.test_utils import (
        print_results,
        run_test_module_with_coverage,
        run_test_module_without_coverage,
    )

    cwd = os.getcwd()
    function_name = os.path.basename(__file__).split('.')[0]
    setup_dir = os.path.dirname(os.path.dirname(cwd))
    print_file = '%s.txt' % function_name

    def run_tests():
        try:
            os.chdir(setup_dir)
            test_case_0()
            os.remove(print_file)
        finally:
            os.chdir(cwd)


# Generated at 2022-06-25 17:46:20.981913
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from _unit_test_setup_commands_cfg_setup_cfg import _test_path as test_path
    base_dir = os.path.dirname(os.path.realpath(test_path))
    for fs in each_sub_command_config(base_dir):
        print(fs)

# Generated at 2022-06-25 17:46:45.857887
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config()."""
    # Test case #0 - No setup.cfg file.
    #   - Test with no 'setup_dir'.
    #   - Expect a FileNotFoundError exception.
    with pytest.raises(FileNotFoundError):
        generator_0 = each_sub_command_config()
        var_0 = next(generator_0)
    # Test case #1 - No setup.cfg file.
    #   - Test with 'setup_dir' of the current working directory.
    #   - Expect a FileNotFoundError exception.
    with pytest.raises(FileNotFoundError):
        setup_dir = os.getcwd()
        generator_1 = each_sub_command_config(setup_dir)
        var_1 = next(generator_1)
    #

# Generated at 2022-06-25 17:46:53.994567
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'term'

    generator_1 = each_sub_command_config()
    var_1 = next(generator_1)
    assert var_1.name == 'term'
    var_2 = next(generator_1)
    assert var_2.name == 'clean'

    generator_3 = each_sub_command_config()
    var_3 = next(generator_3)
    assert var_3.camel == 'Term'

    generator_4 = each_sub_command_config()
    var_4 = next(generator_4)
    assert var_4.commands[0] == 'python setup.py term'

    generator_5 = each_sub_

# Generated at 2022-06-25 17:47:03.404385
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from logging import getLogger
    from flutils.logutils import set_logging_level
    from logging import DEBUG

    set_logging_level(DEBUG)
    logger = getLogger(__name__)

    format_kwargs: Dict[str, str] = {
        'setup_dir': _prep_setup_dir(),
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')


# Generated at 2022-06-25 17:47:13.530194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    '''
    Purpose:
        Test if each_sub_command_config() can run normally.
    '''
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'travis.encrypt-file'
    assert var_0.description == '''\
Create a ``.travis.yml`` file that has encrypted files.'''
    assert var_0.commands == (
        'travis encrypt-file --com -r '
        'ansible-galaxy-team/ansible-galaxy-resources .travis/encrypted_file_2',
    )
    var_1 = next(generator_0)
    assert var_1.name == 'travis.setup'

# Generated at 2022-06-25 17:47:22.470201
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.setuputils import each_sub_command_config

    klass = SetupCfgCommandConfig

    here = os.path.dirname(__file__)
    for path in (
        os.path.join(here, 'test_data', 'setup'),
        os.path.join(here, 'test_data', 'setup_commands'),
        os.path.join(here, 'test_data', 'setup_commands2'),
    ):
        setup_commands = dict(map(lambda x: (x.name, x), each_sub_command_config(path)))

        if path == os.path.join(here, 'test_data', 'setup'):
            assert len(setup_commands) == 2
            assert 'foo' in setup_commands

# Generated at 2022-06-25 17:47:28.811387
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None, "each_sub_command_config is failing"


if __name__ == '__main__':
    _each_setup_cfg_command_section(None)
    _each_setup_cfg_command(None, None)
    _get_name(None, None)
    _prep_setup_dir(None)

    # Test the setup command methods
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:31.228790
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    test_case_0()
    print('Test Passed.')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:37.409176
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert var_0.name == 'config_version.get'
    assert var_0.camel == 'ConfigVersionGet'
    assert var_0.description == (
        'Returns the current config version. Version is defined as '
        'the latest version in the config version history.'
    )
    assert isinstance(var_0.commands, tuple)
    assert var_0.commands == ('config_version.py get',)
    var_1 = next(generator_0)
    assert isinstance(var_1, SetupCfgCommandConfig)

# Generated at 2022-06-25 17:47:47.887316
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Test function each_sub_command_config's
    conformance to specifications
    """
    spec = inspect.getfullargspec(each_sub_command_config)
    assert len(spec.args) == 1
    assert spec.varargs is None
    assert spec.varkw is None
    assert spec.defaults is None
    assert spec.kwonlyargs == []
    assert spec.kwonlydefaults is None
    assert spec.annotations == {}
    test_case_0()


if __name__ == '__main__':
    print('Testing flutils.setuputils.each_sub_command_config')
    this_module = sys.modules[__name__]
    for test_name in dir():
        test_case = getattr(this_module, test_name)

# Generated at 2022-06-25 17:47:54.528083
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.camel == 'TestName'
    assert var_0.commands[0] == 'echo TestName'
    assert var_0.description == 'Test desc TestName'
    assert var_0.name == 'test-name'
    var_1 = next(generator_0)
    assert var_1.camel == 'TestFooBar'
    assert var_1.commands[0] == 'echo TestFooBar'
    assert var_1.description == 'Test desc TestFooBar'
    assert var_1.name == 'test-foo-bar'
    var_2 = next(generator_0)

# Generated at 2022-06-25 17:48:51.208905
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from argparse import ArgumentParser
    from flutils.scripting import each_sub_command_config
    from flutils.scripting import execute_sub_command
    parser = ArgumentParser()

    group = parser.add_subparsers(
        title='sub-commands', dest='sub_command'
    )

    for config in each_sub_command_config():
        cmd = group.add_parser(
            config.name,
            help=config.description,
        )

    args = parser.parse_args()

    if args.sub_command:
        execute_sub_command(args.sub_command, args)

# Generated at 2022-06-25 17:48:53.834797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    var_1 = var_0.name
    assert var_1 == 'my_project'
    var_2 = var_0.description
    assert var_2 == 'A package setup script.'


# Generated at 2022-06-25 17:49:02.612636
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    func_0 = each_sub_command_config

    arg_0 = None

    ret_0 = func_0(arg_0)

    ret_1 = type(ret_0)

    assert ret_1 is Generator

    var_0 = next(ret_0)

    var_1 = type(var_0)

    assert var_1 is SetupCfgCommandConfig

    var_2 = var_0.name

    assert var_2 == "flutils"

    var_3 = var_0.description

    assert var_3 == "Flutils package meta script."

    var_4 = var_0.commands

    var_5 = var_4[0]

    assert var_5 == "dev"

    var_6 = var_4[1]

    assert var_6 == "test"

    var_7 = var

# Generated at 2022-06-25 17:49:08.397004
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import argparse
    import inspect
    import textwrap

    def _wrap(value):
        return textwrap.dedent(value)

    parser = argparse.ArgumentParser(
        description='Unit test the %s function.'
        % inspect.currentframe().f_code.co_name
    )
    parser.add_argument(
        '-s',
        '--setup_dir',
        action='store',
        default='.',
        help=_wrap("""
            The path to the project's directory that contains the
            ``setup.py`` file.
            """)
    )

    args = parser.parse_args()
    if args.setup_dir:
        args.setup_dir = os.path.expanduser(args.setup_dir)


# Generated at 2022-06-25 17:49:12.443252
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import each_sub_command_config
    assert callable(each_sub_command_config)
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:49:20.324537
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    var_1 = next(generator_0)
    var_2 = next(generator_0)
    var_3 = next(generator_0)

# Generated at 2022-06-25 17:49:27.421249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    this_file = os.path.abspath(os.path.realpath(__file__))
    setup_dir = os.path.dirname(this_file)
    generator_0 = each_sub_command_config(setup_dir)
    assert isinstance(generator_0, types.GeneratorType)
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    print(var_0)
    # assert isinstance(var_0, SetupCfgCommandConfig)
    # assert var_0.name == 'datafiles'
    # assert var_0.camel == 'Datafiles'
    # assert var_0.description == "Create the data_files file."
    # assert var_0.commands == ('python setup_commands/data_files.

# Generated at 2022-06-25 17:49:32.250043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    # Exercise
    # Verify
    assert var_0.name == 'build'
    assert var_0.camel == 'Build'
    assert var_0.description == ''
    assert len(var_0.commands) == 1
    assert var_0.commands[0] == 'python setup.py build'
    # Cleanup - N/A



# Generated at 2022-06-25 17:49:33.425552
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Return a generator of ``SetupCfgCommandConfig`` objects."""
    pass



# Generated at 2022-06-25 17:49:40.648492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # tests with str
    from flutils.setupcommandsutils import each_sub_command_config
    generator_1 = each_sub_command_config(setup_dir="/flutils/setup.py")
    var_1 = next(generator_1)
    assert type(var_1).__name__ == 'SetupCfgCommandConfig'

    # tests with os.PathLike
    if hasattr(os, 'fspath'):
        from flutils.setupcommandsutils import each_sub_command_config
        generator_3 = each_sub_command_config(setup_dir=os.fspath("/flutils/setup.py"))
        var_3 = next(generator_3)
        assert type(var_3).__name__ == 'SetupCfgCommandConfig'

    # tests with None

# Generated at 2022-06-25 17:50:53.592732
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.getcwd()
    for var_0 in each_sub_command_config(setup_dir):
        pass
    return os.getcwd() == setup_dir



# Generated at 2022-06-25 17:51:03.471919
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Basic smoke test for the each_sub_command_config function."""

    # Call the function under test
    generator_0 = each_sub_command_config()

    # Assert the return value is as expected
    var_0 = next(generator_0)

    value_1 = var_0.name
    exp_1 = 'sam.deploy'
    err_msg_1 = "The 'name' value, {!r}, did not match the expected value, {!r}.".format(value_1, exp_1)
    assert value_1 == exp_1, err_msg_1

    value_2 = var_0.camel
    exp_2 = 'SamDeploy'

# Generated at 2022-06-25 17:51:09.768625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # mock
    with patch('flutils.setuputils.each_setup_cfg_command_section',
               new=CoroutineMock(),
    ):
        with patch('flutils.setuputils.each_setup_cfg_command',
                   new=CoroutineMock(),
    ):
            # execution
            with patch('flutils.setuputils.extract_stack',
                       return_value=(),
            ):
                # test
                with pytest.raises(FileNotFoundError):
                    each_sub_command_config()
    # mock

# Generated at 2022-06-25 17:51:10.665784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True, "Test case not implemented"

# Generated at 2022-06-25 17:51:16.203011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    each_sub_command_config()


if __name__ == '__main__':
    try:
        from flutils.debugutils import set_tracing
        set_tracing()
    except ImportError:
        pass
    import unittest as ut

    ut.main()

# Generated at 2022-06-25 17:51:25.321282
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Validates the ``each_sub_command_config`` function."""
    cwd = os.getcwd()
    os.chdir(os.path.abspath(os.path.dirname(__file__)))

    generator = each_sub_command_config(os.path.abspath('../..'))

    item = next(generator)
    assert item.name == 'ijson.bomu'
    assert item.description == 'Create/Update BOM & MU Files For Each Extension.'
    assert item.commands == ('bomu',)

    item = next(generator)
    assert item.name == 'ijson.clean'
    assert item.description == 'Cleanup the Python code by removing spaces, blank lines, and trailing lines.'
    assert item.commands == ('clean',)

    item = next

# Generated at 2022-06-25 17:51:32.315020
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        'Additional', 'Application', 'setup_commands.cfg'
    )
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'setup_dir': os.path.realpath(os.path.join(
            'Additional', 'Application'
        )),
        'name': _get_name(parser, setup_cfg_path),
        'home': os.path.expanduser('~')
    }
    test_case = next(_each_setup_cfg_command(parser, format_kwargs))
    assert test_case.name == 'test'

