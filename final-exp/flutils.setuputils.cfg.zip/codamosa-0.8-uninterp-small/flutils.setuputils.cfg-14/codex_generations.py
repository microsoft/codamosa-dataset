

# Generated at 2022-06-25 17:41:51.501531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.expanduser('~/src/python/emitter')
    generator = each_sub_command_config(setup_dir=setup_dir)
    _name: Dict[str, SetupCfgCommandConfig] = {}
    for scc in generator:
        _name[scc.name] = scc
    assert _name['build'].camel == 'Build'
    assert len(_name['build'].commands) == 3
    assert _name['build_man_pages'].camel == 'BuildManPages'
    assert len(_name['build_man_pages'].commands) == 1


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:01.842622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    items = tuple(each_sub_command_config())
    assert len(items) == 5
    assert items[0] == SetupCfgCommandConfig(
        name='Test.case.0',
        camel="TestCase0",
        description="Unit test for function each_sub_command_config",
        commands=()
    )
    assert items[1] == SetupCfgCommandConfig(
        name='test.case.1',
        camel="TestCase1",
        description="Test 1",
        commands=('echo "test case 1"',)
    )
    assert items[2] == SetupCfgCommandConfig(
        name='test.case.2.a',
        camel="TestCase2A",
        description="Test 2 - a",
        commands=('echo "test case 2 - a"',)
    )
    assert items

# Generated at 2022-06-25 17:42:07.370217
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    each_sub_command_config()
    each_sub_command_config('..')
    # each_sub_command_config('..\\flutils.datautils')  # TODO: raises FileNotFoundError
    each_sub_command_config('..\\')
    # each_sub_command_config('\\')  # TODO: raises FileNotFoundError



# Generated at 2022-06-25 17:42:16.040047
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    # Call function
    generator_0 = each_sub_command_config()
    # Assert type of the generator's items
    assert isinstance(next(generator_0), SetupCfgCommandConfig)
    # Call function
    generator_1 = each_sub_command_config('.')
    # Assert type of the generator's items
    assert isinstance(next(generator_1), SetupCfgCommandConfig)
    # Call function
    generator_2 = each_sub_command_config(os.path.abspath('.'))
    # Assert type of the generator's items
    assert isinstance(next(generator_2), SetupCfgCommandConfig)
    # Call function
    generator_3 = each_sub_command_config(os.getcwd())


# Generated at 2022-06-25 17:42:24.138965
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:42:25.834279
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:42:30.284149
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _chdir_to_root_dir(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            with pushd(os.path.dirname(__file__)):
                setup_dir = os.path.abspath(os.path.join(
                    '..', '..', '..', '..', '..', '..', '..'
                ))
                func(setup_dir, *args, **kwargs)

        return wrapper

    @_chdir_to_root_dir
    def test_func(setup_dir: str, name: str) -> None:
        actual = []
        for config in each_sub_command_config(setup_dir):
            actual.append((config.name, config.camel, config.description))

# Generated at 2022-06-25 17:42:38.659419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    # Assert that the first item is what is expected.
    assert next(generator_0) == SetupCfgCommandConfig(
        'isort',
        'Isort',
        'Run the isort library.',
        ('isort --recursive --skip-glob=*.egg-info .',)
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        'isort.check',
        'IsortCheck',
        'Run isort with a check flag to assert that the project is sorted.',
        ('isort --recursive --skip-glob=*.egg-info --check-only .',)
    )

# Generated at 2022-06-25 17:42:41.100600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(tuple(each_sub_command_config())) == 0
    assert len(tuple(each_sub_command_config(setup_dir='.'))) == 0

# Generated at 2022-06-25 17:42:44.766540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    for _ in generator_0:
        pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:53.656148
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert type(each_sub_command_config()) == Generator



# Generated at 2022-06-25 17:43:05.005514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config_0 = each_sub_command_config()
    assert ((config_0) is not None)
    items = [
        item
        for item in config_0
    ]
    assert ((len(items)) == 3)
    assert (items[1].name == 'my.sub-command')
    assert (items[1].camel == 'My_subcommand')
    assert (items[1].description == 'setup script test main sub-command')
    assert ((items[1].commands) == ('python setup.py sub-command', ))
    assert (items[2].name == 'my.other-sub-command')
    assert (items[2].camel == 'My_other_sub_command')
    assert (items[2].description == 'setup script test main sub-command')

# Generated at 2022-06-25 17:43:14.127033
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert next(generator_0) == SetupCfgCommandConfig(
        name='help',
        camel='Help',
        description='',
        commands=('./setup.py help -a',)
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        name='test',
        camel='Test',
        description='',
        commands=('./setup.py test --test-suite=default',)
    )

# Generated at 2022-06-25 17:43:23.795461
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.abspath(__file__))
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    generator_0_0 = each_sub_command_config(setup_dir)
    var_0_0 = next(generator_0_0)
    test_0_0 = isinstance(var_0_0, SetupCfgCommandConfig)
    assert test_0_0
    generator_0_1 = each_sub_command_config(setup_dir)
    var_0_1 = next(generator_0_1)
    test_0_1 = isinstance(var_0_1, SetupCfgCommandConfig)
    assert test_0_1



# Generated at 2022-06-25 17:43:31.743281
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.utils import FormatDict
    kwargs = {
        'name': 'flutils',
        'camel': 'Flutils',
        'description': 'A collection of utility functions.',
        'commands': (
            'echo $PWD',
            'echo $HOME',
            'echo {setup_dir}',
        )
    }
    config = SetupCfgCommandConfig(
        name=kwargs['name'],
        camel=kwargs['camel'],
        description=kwargs['description'],
        commands=tuple(kwargs['commands'])
    )
    config_list = [config]
    generator_0 = each_sub_command_config(
        os.path.join('..', 'flutils')
    )

# Generated at 2022-06-25 17:43:37.181435
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd_path = '/Users/jmf/Dev/metatools/metatools/setup.py'
    setup_path = str(os.path.dirname(cmd_path))
    generator_0 = each_sub_command_config(setup_path)
    var_0 = next(generator_0)
    var_1 = var_0.name
    var_2 = var_0.commands
    var_3 = var_0.description

# Generated at 2022-06-25 17:43:44.920009
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for i, cfg in enumerate(each_sub_command_config()):
        assert isinstance(cfg.name, str)
        assert len(cfg.name)
        assert isinstance(cfg.camel, str)
        assert len(cfg.camel)
        assert isinstance(cfg.description, str)
        assert len(cfg.description)
        assert isinstance(cfg.commands, tuple)
        assert len(cfg.commands)
    assert i > 0


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:51.501976
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.join(setup_dir, 'sample_project')
    assert os.path.isdir(setup_dir)

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    assert var_0.description == ''
    assert var_0.name == 'build_sphinx'
    assert var_0.camel == 'BuildSphinx'
    assert var_0.commands == ('python setup.py build_sphinx',)
    var_1 = next(generator_0)
    assert var_1.description == ''
    assert var_1

# Generated at 2022-06-25 17:44:03.574975
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils.tests._setup_commands import (
        tc_0_setup_commands_cfg,
        tc_0_setup_commands_py,
        tc_1_setup_commands_cfg,
        tc_1_setup_commands_py,
        tc_2_setup_commands_cfg,
        tc_2_setup_commands_py,
        tc_3_setup_commands_cfg,
        tc_3_setup_commands_py,
    )
    import shutil
    import tempfile
    from io import BytesIO


# Generated at 2022-06-25 17:44:10.301035
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    FormatKwargs = Dict[str, str]
    SetupCfgPath = str

    def mock_setup_dir(*args, **kwargs) -> str:
        return '...'

    def mock_setup_cfg_path(*args, **kwargs) -> SetupCfgPath:
        return '...'

    def mock_parser(*args, **kwargs) -> ConfigParser:
        return ConfigParser()

    def mock_get_name(*args, **kwargs) -> str:
        return '...'

    def mock_each_setup_cfg_command(
            parser: ConfigParser,
            format_kwargs: FormatKwargs
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        yield '...'
        yield '...'


# Generated at 2022-06-25 17:44:24.368725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    [Args:]
        ``setup_dir`` (:obj:`str`, :obj:`NoneType`)
            Path to the directory that contains the project's ``setup.py``
            file.
    """
    pass



# Generated at 2022-06-25 17:44:26.835632
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert_equal(
        True,
        isinstance(generator_0, Generator)
    )


if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-25 17:44:31.395339
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        for command in each_sub_command_config():
            print(command)
    except FileNotFoundError:
        pass
    except StopIteration:
        pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:32.584937
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:43.578902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs: List[SetupCfgCommandConfig] = list(
        each_sub_command_config(setup_dir=os.path.dirname(__file__))
    )
    assert len(configs) == 2
    assert configs[0].name == 'build'
    assert configs[0].description == 'Build a deployable package.'
    assert configs[0].camel == 'Build'
    assert configs[0].commands[0].startswith('python setup.py sdist')
    assert configs[1].name == 'clean'
    assert configs[1].description == 'Clean up the build and cache files.'
    assert configs[1].camel == 'Clean'
    assert configs[1].commands[0].startswith('rm -rf ./build')



# Generated at 2022-06-25 17:44:45.150753
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


print('Ran {} tests.'.format(locals().get('test_case', 0)))

# Generated at 2022-06-25 17:44:47.953966
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert next(generator_0) == SetupCfgCommandConfig('test', 'Test', 'Test.', ())
    assert next(generator_0) == SetupCfgCommandConfig('build', 'Build', 'Build.', ())

# Generated at 2022-06-25 17:44:53.737856
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)

    var_1 = next(generator_0)

    var_2 = next(generator_0)

    var_3 = next(generator_0)

    var_4 = next(generator_0)

    var_5 = next(generator_0)



# Generated at 2022-06-25 17:44:55.523001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Make sure it doesn't throw an exception
    each_sub_command_config()



# Generated at 2022-06-25 17:45:00.618014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Check docstring
    assert each_sub_command_config.__doc__

    # Check return type
    assert type(each_sub_command_config()) is Generator

    # Check return value
    assert test_case_0() is None

    # Check return value
    assert test_case_0() is None

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:30.151834
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config"""

    # Check if each_sub_command_config raises FileNotFoundError on the
    # following condition:
    # Unable to find the directory that contains the 'setup.py' file.
    with raises(FileNotFoundError):
        # Call the function here
        each_sub_command_config()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-25 17:45:32.614439
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: Optional[Union[os.PathLike, str]] = None
    print(setup_dir)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:41.927929
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config('tests/test_data/test_project_0')
    assert next(generator_0) == SetupCfgCommandConfig(
        'test_command_0', 'TestCommand0', 'Test description.',
        ('echo 1', 'echo 2', 'echo 3')
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        'test_command_1', 'TestCommand1',
        'This is a test description.', ('echo 4',)
    )

# Generated at 2022-06-25 17:45:44.792784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    with pytest.raises(StopIteration):
        test_case_0()



# Local Variables:
# compile-command: "pytest -vv tests/test_make_subcommand.py"
# End:

# Generated at 2022-06-25 17:45:45.592751
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:45:55.437756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    source = inspect.getsource(each_sub_command_config)
    if source:
        lines = source.split('\n')
        if lines and lines[0].startswith('def each_sub_command_config('):
            lines.pop(0)
        lines = list(filter(lambda x: x and not x.strip().startswith('#'), lines))
        if lines:
            lines.insert(0, 'from typing import (')
            lines.insert(1, '    Dict,')
            lines.insert(2, '    Generator,')
            lines.insert(3, '    Optional,')
            lines.insert(4, '    Union,')
            lines.insert(5, '    cast,')
            lines.insert(6, ')')
            lines.insert(7, '')

# Generated at 2022-06-25 17:46:03.173527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'test'
    assert var_0.camel == 'Test'
    assert var_0.description == 'use the built-in test runner'
    assert len(var_0.commands) > 0
    assert var_0.commands[0].startswith('python setup.py test')
    try:
        next(generator_0)
    except StopIteration:
        pass
    else:
        assert False, "Expected exception not raised."

# Generated at 2022-06-25 17:46:06.585622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    ran_tests = 0
    try:
        test_case_0()
    except:
        print('Failed test case, test_case_0.\n')
        raise
    else:
        ran_tests += 1
    print('Ran %d tests.' % ran_tests)

# Generated at 2022-06-25 17:46:14.536330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os.path import dirname, join
    from . import ProjectBase
    pb = ProjectBase(__file__)
    pb.setup_dir = join(dirname(__file__), 'setup_commands_test_case_0')

    config = each_sub_command_config(pb.setup_dir)
    assert next(config).name == 'Command No 1'
    assert next(config).name == 'Command No 2'

    pb.setup_dir = join(dirname(__file__), 'setup_commands_test_case_1')

    config = each_sub_command_config(pb.setup_dir)
    assert next(config).name == 'Command No 1'
    assert next(config).name == 'Command No 2'


# Generated at 2022-06-25 17:46:15.866563
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)



# Generated at 2022-06-25 17:47:24.636794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test each_sub_command_config."""
    import flutils.setup.setup_cfg_commands as m
    # No setup dir
    generator_0 = m.each_sub_command_config()
    var_0 = next(generator_0)
    assert isinstance(
        var_0,
        m.SetupCfgCommandConfig
    )
    assert var_0.name
    assert var_0.description
    assert var_0.camel
    assert var_0.commands
    assert isinstance(var_0.commands, tuple)
    assert isinstance(var_0.commands[0], str)

# Generated at 2022-06-25 17:47:27.494822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except StopIteration:
        pass
    return True

# Generated at 2022-06-25 17:47:28.473232
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:35.963517
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest  # type: ignore

    with pytest.raises(FileNotFoundError):
        each_sub_command_config(__file__)
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/')
    with pytest.raises(NotADirectoryError):
        each_sub_command_config('/etc/passwd')
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/usr/lib')
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/usr/lib/python2.7/')
    with pytest.raises(FileNotFoundError):
        each_sub_command_config('/etc/passwd')
    setup_dir = _prep_setup_

# Generated at 2022-06-25 17:47:41.990694
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config_path = os.path.join(os.path.dirname(__file__), 'setup.cfg')
    with open(config_path) as f:
        os.utime(config_path, None)
    for num, obj in enumerate(each_sub_command_config()):
        yield test_each_sub_command_config_0, obj, num
    os.remove(config_path)



# Generated at 2022-06-25 17:47:48.634270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_cases = (
        (0,),
    )
    for index, test_case in enumerate(test_cases):
        print('Test Case #%s:' % index)
        print(test_case)
        try:
            locals()['test_case_%s' % index]()
            print('It worked!')
        except Exception as e:
            print('It failed!')
            print(e)
            raise
        print()
    print('Done!')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:50.153038
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as ex:
        str_0 = repr(ex)
        str_1 = str(ex)

# Generated at 2022-06-25 17:47:51.684923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'tag-version'



# Generated at 2022-06-25 17:47:54.179244
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Setup
    try:
        test_case_0()
    except StopIteration:
        pass
    else:
        assert False, (
            'Expected StopIteration, but did not raise an exception.'
        )

    # Tear Down

# Generated at 2022-06-25 17:47:56.351023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0


if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(['-xrsv', __file__]))

# Generated at 2022-06-25 17:50:16.841545
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Get the path to the tests directory
    frame = extract_stack()[-2]
    file = frame.filename
    if not file:
        file = __file__
    tests_dir = os.path.split(file)[0]
    # Get the path to the setup.py file
    setup_py = os.path.join(tests_dir, '..', '..', 'setup.py')
    # Create an iterator
    itr = each_sub_command_config(os.path.split(setup_py)[0])
    # Iterate
    for item in itr:
        pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:50:27.701167
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

# Generated at 2022-06-25 17:50:34.863849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import argparse
    from docutils.parsers.rst.states import Body
    from flutils.configutils import each_sub_command_config
    from flutils.packutils import get_package_path
    from typing import Dict, Generator
    from zc.buildout import UserError

    def each_help(parser: argparse.ArgumentParser) -> Generator[str, None, None]:
        body = cast(Body, parser.format_help())
        out = body.astext()
        for help_str in out.splitlines():
            help_str = help_str.strip()
            if help_str:
                yield help_str

    setup_dir = get_package_path('flutils')

# Generated at 2022-06-25 17:50:42.418518
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.__about__ import __author__
    from flutils.__about__ import __email__
    from flutils.__about__ import __file__
    from flutils.__about__ import __package__
    from flutils.__about__ import __title__
    from flutils.__about__ import __version__

    assert isinstance(__author__, str)
    assert isinstance(__email__, str)
    assert isinstance(__file__, str)
    assert isinstance(__package__, str)
    assert isinstance(__title__, str)
    assert isinstance(__version__, str)

    examples_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'examples')

# Generated at 2022-06-25 17:50:45.099347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setup_utils import each_sub_command_config as function_0
    from flutils.setup_utils import SetupCfgCommandConfig as class_0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:50:53.348623
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Create the setup.cfg
    setup_cfg_path = os.path.join(
        os.path.dirname(__file__), 'data', 'setup.cfg'
    )
    with open(setup_cfg_path, 'wt') as fp:
        fp.write('[metadata]\n')
        fp.write('name = sample-project\n')
        fp.write('\n')
        fp.write('[setup.command.foo]\n')
        fp.write('description = This is the foo command.\n')
        fp.write('commands = \\\n')
        fp.write('    echo "{setup_dir}"\n')
        fp.write('    rm -rfv dist/\n')
        fp.write('\n')

# Generated at 2022-06-25 17:50:53.882292
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:51:03.126993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')
    )
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    var_1 = next(generator_0)
    assert isinstance(var_1, SetupCfgCommandConfig)
    var_2 = next(generator_0)
    assert isinstance(var_2, SetupCfgCommandConfig)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:51:09.535453
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import atexit
    import subprocess
    import tempfile
    import unittest

    setup_commands_cfg = '''
[setup.command.build]
command = bdist_wheel
commands = bdist_wheel
name = build
description = Build {}
    '''

    def _make_tmp_dir(tmp_base_dir: Union[os.PathLike, str]) -> str:
        if os.path.exists(tmp_base_dir) is False:
            os.mkdir(tmp_base_dir)
        if os.path.isdir(tmp_base_dir) is False:
            raise NotADirectoryError(
                f"'tmp_base_dir' of {tmp_base_dir} is NOT a directory."
            )

# Generated at 2022-06-25 17:51:20.374648
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test pre-defined config file
    cmds = list(each_sub_command_config())
    assert len(cmds) == 1
    assert cmds[0].name == 'flutils.test.test_setupcfg.test_case_0'
    assert cmds[0].camel == 'TestCase0'
    assert cmds[0].description == ''
    assert cmds[0].commands == ('python -m flutils.test.test_setupcfg',)
    cmds = list(each_sub_command_config('../../..'))
    assert len(cmds) == 5
    assert cmds[0].name == 'setup.py'
    assert cmds[0].camel == 'SetupPy'
    assert cmds[0].description == 'Run the setup.py script'