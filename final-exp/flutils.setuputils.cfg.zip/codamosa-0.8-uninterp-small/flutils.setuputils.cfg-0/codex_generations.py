

# Generated at 2022-06-25 17:41:46.154691
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfgs = list(each_sub_command_config())
    assert setup_cfgs is not None
    assert setup_cfgs


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:41:51.502321
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys

    import flutils
    import flutils.subcommand

    os.chdir(
        os.path.join(os.path.dirname(flutils.__file__), '..', '..'),
    )
    each_sub_command_config_0 = list(each_sub_command_config())
    assert len(each_sub_command_config_0) == 1
    setup_cfg_command_config_0 = each_sub_command_config_0[0]
    assert isinstance(setup_cfg_command_config_0,
                      flutils.subcommand.SetupCfgCommandConfig)
    assert setup_cfg_command_config_0.name == 'subcommand'
    assert setup_cfg_command_config_0.camel == 'Subcommand'
    commands_0 = setup_cfg_command_config

# Generated at 2022-06-25 17:41:58.413942
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from setuptools.command.develop import develop
    from setuptools.command.install import install
    from setuptools.command.sdist import sdist
    from setuptools.command.test import test

    for setup_cfg_c in each_sub_command_config():
        assert setup_cfg_c.name
        assert setup_cfg_c.camel
        assert setup_cfg_c.description
        assert setup_cfg_c.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:08.836009
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    command_names = (
        'test', 'cov', 'build', 'sdist', 'bdist_wheel', 'bdist_egg',
        'bdist_rpm', 'bdist_wininst',
    )
    command_names = tuple(sorted(command_names))

    for c in each_sub_command_config():
        c = cast(SetupCfgCommandConfig, c)
        assert isinstance(c.name, str)
        assert isinstance(c.camel, str)
        assert isinstance(c.description, str)
        assert isinstance(c.commands, tuple)
        if isinstance(c.commands[0], tuple):
            command_names += tuple(c.commands)
        else:
            command_names += c.commands

# Generated at 2022-06-25 17:42:12.182101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:42:21.655204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # No 'setup.cfg' file.
    setup_dir = os.path.dirname(__file__)
    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(setup_dir))

    # No 'metadata' section.
    setup_dir = os.path.join(setup_dir, 'dummy_setup_dir')
    with open(os.path.join(setup_dir, 'setup.cfg'), 'wt') as f:
        f.write('[setup.commands.test]\n')
        f.write('description=foo\n')
        f.write('commands=foo\n')
    with pytest.raises(LookupError):
        list(each_sub_command_config(setup_dir))

    # No 'name' option.

# Generated at 2022-06-25 17:42:26.025566
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for scc in each_sub_command_config(os.path.join('..', '..')):
        print(scc)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:29.407166
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_command_config_0 = SetupCfgCommandConfig()
    setup_cfg_command_config_0 = SetupCfgCommandConfig(name='name_0', camel='camel_0', description='description_0', commands=('commands_0', ))



# Generated at 2022-06-25 17:42:34.280244
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        pass

    # suite = unittest.TestSuite()
    # suite.addTest(unittest.makeSuite(TestEachSubCommandConfig))
    # test_result = unittest.TextTestRunner().run(suite)

    # assert test_result.wasSuccessful() is True, \
    #     'The load_settings unit test was NOT successful.'

# Command line processing

# Generated at 2022-06-25 17:42:35.333772
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _test_each_sub_command_config_0()


# Generated at 2022-06-25 17:42:51.558107
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    assert os.path.isdir(test_dir)
    cmds = list(each_sub_command_config(test_dir))
    assert cmds
    assert isinstance(cmds, list)
    for cmd in cmds:
        for attr in ('name', 'camel', 'description', 'commands'):
            val = getattr(cmd, attr)
            assert val is not None
            assert isinstance(val, (str, tuple))
    assert 'run_unit_tests' in str(cmds[0])


if __name__ == '__main__':

    pass

# Generated at 2022-06-25 17:42:52.908684
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:43:04.350668
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setup_utils import each_sub_command_config
    from flutils.setup_utils import SetupCfgCommandConfig
    from flutils.setup_utils import _get_name
    from flutils.setup_utils import _prep_setup_dir
    import os
    import types
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_0(self):
            # Test actual use of function.
            var_0 = os.path.dirname(__file__)
            var_1 = _prep_setup_dir(var_0)
            self.assertEqual(var_1, os.path.realpath(var_0))
            var_2 = os.path.join(var_1, 'setup.cfg')

# Generated at 2022-06-25 17:43:10.468030
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    parser = ConfigParser()
    parser.read('setup.cfg')
    values = {
        'setup_dir': os.path.dirname(__file__),
        'home': os.path.expanduser('~')
    }
    values['name'] = _get_name(parser, 'setup.cfg')
    generator_0 = _each_setup_cfg_command(parser, values)
    var_0 = list(generator_0)
    assert len(var_0) >= 1



# Generated at 2022-06-25 17:43:11.053024
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True



# Generated at 2022-06-25 17:43:18.395305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Asserts that the function, ``each_sub_command_config``, works as
    expected.
    """
    try:
        var_0 = each_sub_command_config()
        assert False, (
            "The expected exception was not raised. The found value = %r"
            % var_0
        )
    except FileNotFoundError:
        pass

    var_1 = each_sub_command_config(__file__)
    var_2 = list(var_1)
    assert var_2 == []

    var_3 = each_sub_command_config(os.path.dirname(__file__))
    var_4 = list(var_3)
    assert var_4 == []


# Generated at 2022-06-25 17:43:19.131618
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:43:22.303155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# ==============================

if __name__ == '__main__':
    import sys

    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 17:43:23.060021
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test function here
    test_case_0()

# Generated at 2022-06-25 17:43:30.827771
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO
    from unittest.mock import patch
    from setuptools import Command
    import sys
    import pytest

    def _get_mock_setup():
        class Setup(Command):
            def initialize_options(self):
                pass

            def finalize_options(self):
                pass

            def run(self):
                pass
        return Setup()


# Generated at 2022-06-25 17:43:55.464646
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Arguments
    cur_dir = os.getcwd()
    setup_dir = os.path.abspath(os.path.join(cur_dir, '../../flutils'))
    os.chdir(setup_dir)

    generator_1 = each_sub_command_config()
    var_1 = list(generator_1)
    assert var_1[0].name == 'hello'

    generator_2 = each_sub_command_config()
    var_2 = list(generator_2)
    assert var_2[1].name == 'hello.sub'

    generator_3 = each_sub_command_config()
    var_3 = list(generator_3)
    assert var_3[2].name == 'hello.sub.1.3'

    generator_4 = each_sub_

# Generated at 2022-06-25 17:43:56.791138
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Nothing to test, yet.
    pass

# Generated at 2022-06-25 17:44:01.036907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_py = os.path.join(os.path.dirname(__file__), 'setup.py')
    path = os.path.join(os.path.dirname(setup_py), 'setup_commands.cfg')
    if os.path.isfile(path):
        test_case_0()

# Generated at 2022-06-25 17:44:02.155875
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Unit test for this function
    pass



# Generated at 2022-06-25 17:44:04.387522
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(os.path.dirname(__file__), '..')
    commands = each_sub_command_config(setup_dir)
    assert len(list(commands)) > 0

# Generated at 2022-06-25 17:44:09.524344
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('\nPep8 test for function each_sub_command_config')
    print('\n===== pep8 check =====\n')
    pep8style = pycodestyle.StyleGuide(config_file='pep8.cfg')
    pep8style.input_dir('.')
    test_result = pep8style.check_files()
    if test_result.total_errors == 0:
        print('Everything looks good with Pep8 style.')
    else:
        print('Oh oh. Pep 8 Style Errors:\n' + test_result.get_statistics())

# Generated at 2022-06-25 17:44:10.477432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None

# Generated at 2022-06-25 17:44:21.323889
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    # Setup
    setup_dir = os.path.realpath(os.path.dirname(__file__))

    # Exercise
    generator_0 = each_sub_command_config(setup_dir)

    # Verify
    var_0 = list(generator_0)
    assert len(var_0) == 2

    sc = var_0[0]
    assert sc.name == 'setup.command.clean'
    assert sc.camel == 'Clean'
    assert sc.commands == ('rm -rf *.egg-info',)

    sc = var_0[1]
    assert sc.name == 'setup.command.build_docs'
    assert sc.camel == 'BuildDocs'

# Generated at 2022-06-25 17:44:22.475102
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:23.289640
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:50.265859
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from io import StringIO

    from flutils.pathutils import cd

    from .test_data import setup_dir

    cfg_file_path = os.path.join(setup_dir, 'setup.cfg')

    parser = ConfigParser()

# Generated at 2022-06-25 17:44:58.441219
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:45:00.629387
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from test.test_utils import call_func_with_args

    call_func_with_args(test_case_0)

# Generated at 2022-06-25 17:45:04.627358
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_1 = each_sub_command_config()
    try:
        assert(list(generator_1))
    except Exception:
        pass
    assert(None)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()
    print('Done.')

# Generated at 2022-06-25 17:45:10.598502
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    expected_0 = [
        SetupCfgCommandConfig(
            name='test-command',
            camel='TestCommand',
            description='Test an sphinx command.',
            commands=(
                "cd {setup_dir} && "
                "sphinx-build -b doctest _docs _docs/_build/doctest"
            ),
        ),
    ]
    actual_0 = list(each_sub_command_config())
    assert expected_0 == actual_0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:45:16.010923
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        each_sub_command_config()
        assert False, "Expected exception not thrown"
    except FileNotFoundError:
        pass


if __name__ == '__main__':
    import unittest


    class Test(unittest.TestCase):
        def test_each_sub_command_config(self):
            try:
                each_sub_command_config()
                assert False, "Expected exception not thrown"
            except FileNotFoundError:
                pass


    unittest.main()

# Generated at 2022-06-25 17:45:24.837115
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile


# Generated at 2022-06-25 17:45:26.159293
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:27.475607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Run test_case_0."""
    test_case_0()

# Generated at 2022-06-25 17:45:30.406907
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    # print("main") to aid debugging.
    # print("main")
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:26.248730
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()

# Generated at 2022-06-25 17:46:34.100415
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config():
        print(
            'name = %r; camel = %r; description = %r; commands = %r\n'
            % (
                setup_cfg_command_config.name,
                setup_cfg_command_config.camel,
                setup_cfg_command_config.description,
                setup_cfg_command_config.commands
            )
        )


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:34.563235
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:46:43.324861
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-25 17:46:44.410829
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Runs all unit tests for function each_sub_command_config.
    """
    test_case_0()

# Generated at 2022-06-25 17:46:52.751003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test function calls
    def each_sub_command_config_none_0():
        """No arguments"""
        return each_sub_command_config()
    def each_sub_command_config_none_1():
        """No arguments"""
        return each_sub_command_config(None)
    def each_sub_command_config_none_2():
        """No arguments"""
        return each_sub_command_config(None)
    def each_sub_command_config_none_3():
        """No arguments"""
        return each_sub_command_config("")
    def each_sub_command_config_none_4():
        """No arguments"""
        return each_sub_command_config("\"\"")
    def each_sub_command_config_none_5():
        """No arguments"""
        return each_

# Generated at 2022-06-25 17:46:59.573941
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    actual_0 = map(str, var_0)

# Generated at 2022-06-25 17:47:01.467935
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function ``each_sub_command_config``."""
    test_case_0()

# Generated at 2022-06-25 17:47:06.626555
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert next(generator_0) == SetupCfgCommandConfig(
        'clean', 'Clean', 'Clean the project.', ('rm -rf build dist',)
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        'cleanall', 'CleanAll', 'Clean the project and any possible copr builds.', (
            'rm -rf build dist',
            'rm -rf /home/matt/copr/{name}-*'
        )
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        'cleanpyc', 'CleanPyc', 'Clean the project\'s ``.pyc`` files.', (
            'find . -name *.pyc -delete',
        )
    )

# Generated at 2022-06-25 17:47:09.835568
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\nUnit test for function each_sub_command_config')
    test_case_0()
    print('Unit test is done')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:52.048460
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    for test_case in range(0, 1):
        print(f'Test Case {test_case}')
        with tempfile.TemporaryDirectory() as d:
            if test_case == 0:
                setup_file = os.path.join(d, 'setup.py')
                with open(setup_file, 'w') as fp:
                    fp.write('''
                        import setuptools
                        setuptools.setup()
                    ''')
                setup_cfg_file = os.path.join(d, 'setup.cfg')
                with open(setup_cfg_file, 'w') as fp:
                    fp.write('''
                        [metadata]
                        name = myproject
                    ''')

# Generated at 2022-06-25 17:51:02.239660
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import flutils.systemutils as su
    import flutils.pathutils as pu

    setup_dir_0 = pu.current_file_dir(__file__)
    generator_0 = each_sub_command_config(setup_dir_0)
    var_0 = list(generator_0)

    var_1 = len(var_0)
    assert var_1 == 3

    setup_cfg_command_config_0 = var_0[0]

    assert setup_cfg_command_config_0.name == 'clean'
    assert setup_cfg_command_config_0.description == 'Remove all build, and ' \
                                                     'test artifacts.'
    assert setup_cfg_command_config_0.camel == 'Clean'

    commands_0 = setup_cfg_command_config

# Generated at 2022-06-25 17:51:08.828864
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.entry_points.setup_commands_generator as tester
    from unittest.mock import patch
    import io

    with patch(
            'flutils.entry_points.setup_commands_generator.extract_stack',
            return_value=[]
    ):
        with patch('flutils.entry_points.setup_commands_generator.os') as mock_os:
            mock_os.path.exists.return_value = True
            mock_os.path.isdir.return_value = True
            mock_os.path.isfile.return_value = True
            mock_os.path.realpath.return_value = ''


# Generated at 2022-06-25 17:51:19.467528
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_raises_file_not_found_error,
        assert_raises_not_a_directory_error,
    )

    setup_dir = _prep_setup_dir()

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    assert var_0

    with pytest.raises(FileNotFoundError):
        generator_1 = each_sub_command_config('/tmp/foo/bar')
        list(generator_1)

    generator_2 = each_sub_command_config(setup_dir)
    var_1 = list(generator_2)
    assert var_0 == var_1


# Generated at 2022-06-25 17:51:21.423860
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0()

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:51:30.294385
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None

    try:
        setup_dir = _prep_setup_dir(setup_dir)
    except FileNotFoundError:
        pass
    else:
        generator_0 = each_sub_command_config()
        var_0 = bool(next(generator_0, None))
        assert var_0 == True

    format_kwargs: Dict[str, str] = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
   