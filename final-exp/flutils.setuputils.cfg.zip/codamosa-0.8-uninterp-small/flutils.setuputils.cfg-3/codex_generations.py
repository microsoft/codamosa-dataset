

# Generated at 2022-06-25 17:41:50.997124
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import os
    import pathlib

# Generated at 2022-06-25 17:41:59.170776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config('setup_sub_cmd/sub_cmd_0'):
        print(config)
    for config in each_sub_command_config('setup_sub_cmd/sub_cmd_1'):
        print(config)
    for config in each_sub_command_config('setup_sub_cmd/sub_cmd_2'):
        print(config)
    for config in each_sub_command_config('setup_sub_cmd/sub_cmd_3'):
        print(config)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:00.388357
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for each_sub_command_config in each_sub_command_config():
        pass

# Generated at 2022-06-25 17:42:05.351862
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    out = each_sub_command_config(setup_dir='.')
    for x in out:
        print(x)  # should be the config for the 'test' command in setup.cfg
    return


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:14.494953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.dirutils import each_dir_name_until

    def _validate_setup_dir(setup_dir):
        if os.path.exists(setup_dir) is False:
            raise FileNotFoundError("The given 'setup_dir' of %r does "
                                    "NOT exist." % setup_dir)
        if os.path.isdir(setup_dir) is False:
            raise NotADirectoryError("The given 'setup_dir' of %r is "
                                     "NOT a directory." % setup_dir)
        path = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-25 17:42:23.468416
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    command_0 = '{name}'
    description_0 = ''
    command_1 = 'test'
    description_1 = ''
    command_2 = 'test -k {name}'
    description_2 = 'Tests the project.'
    command_3 = 'test -k {name}\\npy.test -k {name}'
    description_3 = 'Tests the project.'

    import tempfile
    temp_dir_path = tempfile.mkdtemp()

# Generated at 2022-06-25 17:42:28.467801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('\n--- Testing function each_sub_command_config ---')
    from pprint import pprint
    for config in each_sub_command_config(None):
        print('\nconfig -->')
        pprint(vars(config))



# Generated at 2022-06-25 17:42:29.005259
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:42:31.176758
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:34.175847
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        if config.name:
            print(config.name)

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:53.665557
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    from flutils.systemutils import get_current_executable
    from flutils.pathutils import abspath
    from flutils.testutils import VerboseTestCase
    from flutils.pprintutils import fmtdict
    from flutils.objectutils import str2obj
    import os

    class main(VerboseTestCase):

        def setup_class(cls):
            cls._prev_cwd = os.getcwd()
            cls._base_path = os.path.dirname(abspath(__file__))
            os.chdir(cls._base_path)

        def teardown_class(cls):
            os.chdir(cls._prev_cwd)


# Generated at 2022-06-25 17:42:58.737202
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def assert_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None,
            expected: Tuple[SetupCfgCommandConfig, ...] = ()
    ) -> None:
        actual = tuple(each_sub_command_config(setup_dir=setup_dir))
        assert expected == actual


# Generated at 2022-06-25 17:43:04.601181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    target_dir = os.path.join(current_dir, '..', '..', 'src')
    target_dir = os.path.realpath(target_dir)

    commands = list(each_sub_command_config(target_dir))
    assert len(commands) == 1

# Generated at 2022-06-25 17:43:13.732654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest.mock
    sys.modules[__name__] = unittest.mock.Mock()
    sys.modules[__name__].__file__ = (
        os.path.abspath(os.path.join(os.path.dirname(__file__), 'setup.py'))
    )
    sys.modules[__name__].__package__ = ''
    sys.modules[__name__].__name__ = __name__
    sys.modules[__name__].__loader__ = unittest.mock.Mock()
    sys.modules[__name__].__spec__ = unittest.mock.Mock()
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read('setup_commands.cfg')
    count = 0

# Generated at 2022-06-25 17:43:23.499624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint

    print('\neach_sub_command_config:')
    pprint.pprint(tuple(each_sub_command_config()))


if __name__ == '__main__':
    import os
    import unittest

    test_dir = os.path.dirname(__file__)
    setup_dir = os.path.join(test_dir, '..', '..')
    for cmd in each_sub_command_config(setup_dir):
        print(cmd.camel)
        print('-' * len(cmd.camel))
        print()
        print(cmd.description)
        print()
        print('Commands:')
        for cmd_str in cmd.commands:
            print(cmd_str)
        print()


# Generated at 2022-06-25 17:43:30.171421
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cmd in each_sub_command_config():
        assert cmd.name
        assert cmd.camel
        assert cmd.description
        assert cmd.commands


if __name__ == '__main__':
    def print_cmd_info(cmd: SetupCfgCommandConfig):
        print(cmd.name)
        print(cmd.camel)
        print(cmd.description)
        print(cmd.commands)
        print()

    print('SetupCfgCommandConfig(s):')
    for cmd in each_sub_command_config():
        print_cmd_info(cmd)

    print('\n\nSetupCfgCommandConfig(s) (with setup_dir):')
    for cmd in each_sub_command_config('.'):
        print_cmd_info(cmd)

# Generated at 2022-06-25 17:43:34.554064
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    for sc in each_sub_command_config(setup_dir):
        print('-' * 80)
        print(repr(sc))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:44.995049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils

    result = []
    for config in each_sub_command_config(flutils.__path__[0]):
        result.append(config)

    assert len(result) == 6
    assert result[0] == SetupCfgCommandConfig(
        'commands',
        'Commands',
        'Show the list of sub-commands.',
        (
            'python setup.py --commands',
        )
    )
    assert result[1] == SetupCfgCommandConfig(
        'docs',
        'Docs',
        'Generates the project documentation.',
        (
            'python setup.py docs',
        )
    )

# Generated at 2022-06-25 17:43:55.364300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    test_dir = os.path.realpath(os.path.dirname(__file__))
    test_dir = os.path.join(test_dir, 'test_data')
    out = tuple(each_sub_command_config(test_dir))

# Generated at 2022-06-25 17:44:00.357660
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(f'{config.name} {config.camel} {config.description}')
        for cmd in config.commands:
            print(f'  {cmd}')

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:17.447053
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tests.test_setup_commands import setup_command

    abs_file_path = os.path.abspath(setup_command.__file__)
    abs_dir_path = os.path.dirname(abs_file_path)

    generator_0 = each_sub_command_config(abs_dir_path)
    var_0 = tuple(generator_0)

    assert len(var_0) == 3

    assert var_0[0].name == '3.7'
    assert var_0[0].camel == 'Three_seven'
    assert var_0[0].description == 'Test sub command for Python 3.7'

# Generated at 2022-06-25 17:44:19.253504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:21.164583
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)

# Generated at 2022-06-25 17:44:27.938354
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)
        )),
        'a', 'b', 'c'
    )

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = tuple(generator_0)

    assert var_0 == (
        SetupCfgCommandConfig(
            'sub_command',
            'SubCommand',
            'run sub command',
            ("echo 'sub command'",),
        ),
    )


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:33.847227
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        setup_dir = None
        test_case_0()
    except:
        raise
    return True


if __name__ == '__main__':
    if test_each_sub_command_config():
        print('all tests for function each_sub_command_config succeeded')
    else:
        print('one or more tests for function each_sub_command_config failed')

# Generated at 2022-06-25 17:44:37.183824
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # AssertionError: The 'metadata', section's, 'name' option is not set
    # in the config file, '/home/mvn/Source/flutils/setup.cfg'.
    test_case_0()

# Generated at 2022-06-25 17:44:46.932900
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pytest import (
        raises,
        warns
    )
    from warnings import (
        catch_warnings,
        simplefilter
    )

    # setup_dir does NOT exist
    generator_0 = None
    with raises(FileNotFoundError) as err_0:
        generator_0 = each_sub_command_config('/bad/path')
    assert str(err_0.value) == "The given 'setup_dir' of '/bad/path' does NOT" \
        " exist."
    assert generator_0 is None

    # setup_dir is NOT a directory
    generator_0 = None
    with raises(NotADirectoryError) as err_0:
        generator_0 = each_sub_command_config('/etc/hosts')

# Generated at 2022-06-25 17:44:52.656761
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_cases = [
        {
        }
    ]
    for case in test_cases:
        var_0 = each_sub_command_config()
        result_0 = tuple(var_0)
        assert result_0 == case.get('result_0')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:44:55.021552
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Assert:
    return


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:04.528514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)
    tuple_0 = var_0
    assert type(tuple_0) == tuple
    assert type(tuple_0[0]) == SetupCfgCommandConfig
    assert tuple_0[0].name == 'test'
    assert tuple_0[0].camel == 'Test'
    assert tuple_0[0].description == 'Run tests quickly with the default '\
                                      '"pytest" command.'
    tuple_0_0 = tuple_0[0].commands
    assert type(tuple_0_0) == tuple
    assert tuple_0_0[0] == 'python -m pytest {setup_dir}/tests/'
    assert type(tuple_0[1]) == SetupCfgCommandConfig

# Generated at 2022-06-25 17:45:26.435895
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """ Test each_sub_command_config, Test case 0 """
    var = test_case_0()
    assert var, 'Return value is: ' + str(var)


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(['--color', '--capture', 'no', __file__])
    sys.exit(0)

# Generated at 2022-06-25 17:45:28.670153
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:38.201508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Testing the first command in the config file
    generator_0 = each_sub_command_config()
    var_0 = generator_0.__next__()
    assert isinstance(var_0.name, str)
    assert var_0.name == 'foo'
    assert isinstance(var_0.camel, str)
    assert var_0.camel == 'Foo'
    assert isinstance(var_0.description, str)
    assert var_0.description == 'A dummy command'
    assert isinstance(var_0.commands[0], str)
    assert var_0.commands[0] == 'echo foo'

    # Testing the second command in the config file
    var_0 = generator_0.__next__()
    assert isinstance(var_0.name, str)
    assert var_

# Generated at 2022-06-25 17:45:38.918422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None

# Generated at 2022-06-25 17:45:41.133830
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("test_each_sub_command_config")
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:42.228190
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(tuple(each_sub_command_config())) > 0

# Generated at 2022-06-25 17:45:44.502732
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# vim: set fileencoding=utf-8 ts=8 sw=4 tw=0 et :

# Generated at 2022-06-25 17:45:45.031171
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:45:54.602620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator) is True
    var_0 = tuple(generator_0)
    var_1 = len(var_0)
    var_2 = isinstance(var_0, tuple)
    var_3 = (var_1 == 0)
    var_4 = isinstance(var_3, bool)
    assert var_2 and var_3 and var_4
    var_5 = isinstance(var_1, int)
    assert var_5
    generator_1 = each_sub_command_config(setup_dir='/tmp')
    var_6 = tuple(generator_1)
    var_7 = len(var_6)
    var_8 = isinstance(var_6, tuple)

# Generated at 2022-06-25 17:45:55.632480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:46:27.193444
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)

# Generated at 2022-06-25 17:46:31.872485
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(_prep_setup_dir())
    var_0 = tuple(generator_0)
    assert len(var_0) == 5

# vim: set fileencoding=utf-8 :

# Generated at 2022-06-25 17:46:36.103570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = '/Users/mg/src/flutils/flutils'

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = tuple(generator_0)
    assert isinstance(var_0, tuple)
    count = 0
    for cmd_config in var_0:
        count += 1
        print(cmd_config)
    assert count == 33



# Generated at 2022-06-25 17:46:44.144155
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests function each_sub_command_config"""

    # Example 1
    generator_1 = each_sub_command_config()
    var_1_0 = tuple(generator_1)
    var_1_1 = cast(SetupCfgCommandConfig, var_1_0[0])
    var_1_2 = cast(SetupCfgCommandConfig, var_1_0[1])
    var_1_3 = cast(SetupCfgCommandConfig, var_1_0[2])
    var_1_4 = cast(SetupCfgCommandConfig, var_1_0[3])
    var_1_5 = cast(SetupCfgCommandConfig, var_1_0[4])
    var_1_6 = cast(SetupCfgCommandConfig, var_1_0[5])

# Generated at 2022-06-25 17:46:45.514022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for var_8 in range(0, 1):
        func_0(var_8)

# Generated at 2022-06-25 17:46:46.948780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('Tests passed')

# Generated at 2022-06-25 17:46:50.371901
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()



# Generated at 2022-06-25 17:46:52.241988
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # test case #0
    try:
        test_case_0()
        success = True
    except Exception:
        success = False
    assert success is False

# Generated at 2022-06-25 17:46:54.582023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:56.990472
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        _ = each_sub_command_config()
    except FileNotFoundError:
        pass
    except Exception as e:
        raise AssertionError(e)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:30.607361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(setup_dir='/Users/michaelherman/Documents/Projects/flutils')
    var_0 = tuple(generator_0)
    assert('setup_command' not in sys.modules)

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 17:47:34.568204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import each_sub_command_config
    var_0 = each_sub_command_config()
    assert isinstance(var_0, tuple)
    var_1 = next(var_0)
    assert isinstance(var_1, tuple)
    var_2 = next(var_0)
    assert isinstance(var_2, tuple)

# Generated at 2022-06-25 17:47:36.135787
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Main entry point of script
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:41.659120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    kwargs_0: Dict[str, Union[os.PathLike, str]] = {'setup_dir': '../..'}
    generator_0 = each_sub_command_config(**kwargs_0)
    var_0 = tuple(generator_0)
    for var_1 in var_0:
        print(var_1)



# Generated at 2022-06-25 17:47:43.962916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config('/tmp')
    var_0 = tuple(generator_0)

# Generated at 2022-06-25 17:47:45.472383
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:49.480756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)
    var_1_0 = var_0[0]
    var_1_1 = var_0[1]
    var_1_2 = var_0[2]
    var_1_3 = var_0[3]
    var_1_4 = var_0[4]

# Generated at 2022-06-25 17:47:51.358600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = next(each_sub_command_config())
    assert config.name == 'test_case_0', config


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:52.615026
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:54.995325
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as exc:
        import traceback
        traceback.print_exc(file=sys.stdout)
        sys.exit(1)



# Generated at 2022-06-25 17:48:34.536143
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cmd = next(each_sub_command_config())
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'setup.command.dist.sdist'
    assert cmd.description == 'Create a source distribution (tarball)'
    assert cmd.commands == ('python setup.py sdist',)
    cmd = next(each_sub_command_config('..'))
    assert isinstance(cmd, SetupCfgCommandConfig)
    assert cmd.name == 'setup.command.dist.sdist'
    assert cmd.description == 'Create a source distribution (tarball)'
    assert cmd.commands == ('python setup.py sdist',)

# Generated at 2022-06-25 17:48:36.084231
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None, (
        "The function each_sub_command_config "
        "did NOT return None."
    )

# Generated at 2022-06-25 17:48:37.781399
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Set up test inputs
    callback = None
    # Invoke the tested function
    test_case_0()
    # Check the results
    assert True



# Generated at 2022-06-25 17:48:39.258561
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(setup_dir='.')
    var_0 = tuple(generator_0)



# Generated at 2022-06-25 17:48:40.354172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass


if __name__ == '__main__':
    test_case_0()

# EOF

# Generated at 2022-06-25 17:48:44.858634
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setup_utils
    config = flutils.setup_utils.each_sub_command_config()
    assert 'build' in config


if __name__ == '__main__':
    # Test the disconnect_python_logging_signals function.
    test_case_0()
    test_each_sub_command_config()

    print(
        "\n*** ALL TESTS PASSED.\n"
        "*** Unit testing for %r is complete."
        % __file__
    )

# Generated at 2022-06-25 17:48:51.148811
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = tuple(generator_0)
    try:
        # Test call
        generator_0 = each_sub_command_config(setup_dir='C:\\Python36\\Lib')
        var_0 = tuple(generator_0)
        assert False
    except FileNotFoundError:
        pass

if __name__ == '__main__':
    print('This command is not supported, as it is intended to be used as a '
          'module. Script support is provided as a debugging aid only.')

# Generated at 2022-06-25 17:48:52.030838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if __debug__:
        test_case_0()


# Generated at 2022-06-25 17:48:57.622013
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_1 = ()
    var_2 = type(var_1)
    var_3 = isinstance(generator_0, var_2)
    var_4 = 'lint'
    var_5 = 'Lint'
    var_6 = 'Runs the linters on the project'
    var_7 = ('flake8 --exclude=.tox,.venv',)
    var_8 = SetupCfgCommandConfig(var_4, var_5, var_6, var_7)
    var_9 = (var_8,)
    var_10 = var_9 == var_1
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:49:07.515114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    sub_command_config = list(each_sub_command_config())
    assert len(sub_command_config) == 4
    _setup_cfg = None
    _setup_commands_cfg = None
    for scc in sub_command_config:
        assert isinstance(scc.name, str)
        assert isinstance(scc.commands, tuple)
        assert len(scc.commands) > 0
        if scc.name == 'unittest':
            _setup_cfg = scc
        elif scc.name == 'test_pytests':
            _setup_commands_cfg = scc

    assert _setup_cfg
    assert _setup_commands_cfg

    assert (
        _setup_cfg.description ==
        'Run unit tests using unittest.'
    )

# Generated at 2022-06-25 17:49:50.095492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    here = os.path.dirname(__file__)
    setup_dir = here

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = tuple(generator_0)

    tup_0_1 = (
        SetupCfgCommandConfig(
            'run',
            'Run',
            'Run the command line interface',
            ('./cli-scripts/cli_run.py',)
        ),
    )
    assert var_0 == tup_0_1

    generator_1 = each_sub_command_config(setup_dir)
    var_1 = tuple(generator_1)
    assert var_1 == tup_0_1

    generator_2 = each_sub_command_config(setup_dir)
    var_2 = tuple(generator_2)

# Generated at 2022-06-25 17:49:50.715401
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:01.132620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(
        os.path.realpath(os.path.dirname(__file__)),
        '..',
        '..',
        '..',
        'setup.cfg'
    )
    setup_dir = os.path.dirname(setup_cfg_path)
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = tuple(generator_0)

# Generated at 2022-06-25 17:50:01.985603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:05.313854
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    for item in each_sub_command_config():
        assert isinstance(item.camel, str)
        assert isinstance(item.commands, tuple)
        assert isinstance(item.description, str)
        assert isinstance(item.name, str)
    assert True



# Generated at 2022-06-25 17:50:14.667119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    sub_commands = '\n'.join((
        'setup.command.check-python-version',
        'setup.command.check-style',
        'setup.command.build',
        'setup.command.test',
        'setup.command.clean',
        'setup.command.mypy'
    ))
    var_0 = sub_commands.split('\n')
    for var_1 in var_0:
        sub_command = var_1
        if not sub_command:
            continue
        for var_2 in each_sub_command_config():
            sub_command_config = var_2
            assert isinstance(sub_command_config, SetupCfgCommandConfig)
            assert isinstance(sub_command_config.name, str)

# Generated at 2022-06-25 17:50:20.832926
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    assert var_0 is not None, \
        'The function `each_sub_command_config` did not return a value.'
    var_1 = isinstance(var_0, Generator)
    assert var_1 is True, \
        'The function `each_sub_command_config` did not return a generator.'

# vim: set ts=4 sw=4 tw=79 ft=python et :

# Generated at 2022-06-25 17:50:28.344453
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
    generator = each_sub_command_config(setup_dir)
    assert tuple(generator) == (
        SetupCfgCommandConfig(
            'build',
            'Build',
            'Build an sdists and wheels.',
            (
                'python setup.py sdist',
                'python setup.py bdist_wheel',
            )
        ),
    )

# Generated at 2022-06-25 17:50:29.155159
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:50:35.999621
# Unit test for function each_sub_command_config