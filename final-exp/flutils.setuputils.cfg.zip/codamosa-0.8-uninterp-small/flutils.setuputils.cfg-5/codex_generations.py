

# Generated at 2022-06-25 17:41:50.693269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pathlib
    cwd = pathlib.Path(__file__).parent.absolute()
    setup_dir = str(cwd)

    for i, r in enumerate(each_sub_command_config(setup_dir)):
        print(i, r)


if __name__ == '__main__':
    from pytest import main
    main([__file__, '-v'])

# Generated at 2022-06-25 17:41:53.542043
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config"""
    for config in each_sub_command_config():
        assert config is not None



# Generated at 2022-06-25 17:41:57.916194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    from flutils.pathutils import current_working_directory_path

    for config in each_sub_command_config(current_working_directory_path()):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:04.187059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    configs = list(each_sub_command_config(setup_dir='.'))
    assert not configs
    configs = list(each_sub_command_config(setup_dir='tests'))
    assert configs
    for config in configs:
        assert isinstance(config.commands, tuple)
        assert isinstance(config.name, str)
        assert config.name


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:11.041330
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(os.path.dirname(__file__))
    conf = list(each_sub_command_config(setup_dir))
    assert conf[0].name == 'flutils'
    assert conf[0].camel == 'Flutils'
    assert conf[0].description == 'flamework utils'
    assert conf[0].commands[0] == 'python setup.py sdist'
    assert conf[0].commands[1] == 'python setup.py bdist_wheel'

# Generated at 2022-06-25 17:42:13.524125
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass


if __name__ == '__main__':
    for x in each_sub_command_config():
        print(x)

# Generated at 2022-06-25 17:42:14.034894
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:42:23.130145
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # import os
    # import sys
    # from pathlib import Path
    # from flutils.pathutils import (
    #     get_exe_dir,
    #     get_root_dir,
    #     is_inside_dir
    # )
    # import pytest
    #
    #
    # @pytest.fixture(params=[
    #     '.',
    #     './flutils',
    #     '../flutils',
    #     './flutils/project',
    #     '../flutils/project',
    # ])
    # def setup_dir(request):
    #     """Tests the flutils.project.each_

# Generated at 2022-06-25 17:42:28.591757
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Complete unit test for function each_sub_command_config
    count = 0
    for setup_cfg_command_config_0 in each_sub_command_config():
        print(setup_cfg_command_config_0)
        count += 1
    assert count > 0

# Generated at 2022-06-25 17:42:36.439384
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    assert setup_dir
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)
    assert setup_dir
    setup_dir = os.path.join(setup_dir, 'tests/data/sample_project')
    assert os.path.isdir(setup_dir)
    assert os.path.isfile(os.path.join(setup_dir, 'setup.py'))
    assert os.path.isfile(os.path.join(setup_dir, 'setup.cfg'))
    assert os.path.isfile(os.path.join(setup_dir, 'setup_commands.cfg'))

# Generated at 2022-06-25 17:42:52.821269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import pathlib
    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-25 17:42:59.077056
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        assert each_sub_command_config(
                os.path.realpath(
                    os.path.join(
                        os.path.dirname(os.path.realpath(__file__)),
                        os.pardir,
                        os.pardir,
                        os.pardir,
                        os.pardir,
                    )
                )
        )
    except FileNotFoundError:
        pass

# Generated at 2022-06-25 17:42:59.513255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:04.013467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert len(list(each_sub_command_config())) > 0


if __name__ == '__main__':
    import sys
    import unittest

    sys.exit(
        cast(
            Union[bool, int],
            unittest.main(verbosity=2)
        )
    )

# Generated at 2022-06-25 17:43:07.613706
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(None)
    var_0 = list(generator_0)
    assert (var_0 == [
        SetupCfgCommandConfig(
            'test',
            'Test',
            '',
            ()
        )
    ])

# Generated at 2022-06-25 17:43:16.123380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import shutil

    tmp_dir = '/tmp/flutils.test.setup_commands_config.0'
    tmp_setup_dir = os.path.join(tmp_dir, 'setup_dir')
    shutil.rmtree(tmp_dir, ignore_errors=True)
    os.makedirs(tmp_dir, exist_ok=True)
    os.makedirs(tmp_setup_dir, exist_ok=True)

    os.chdir(tmp_setup_dir)
    with open('setup.py', 'w') as f:
        f.write('import setuptools\n')
        f.write('setuptools.setup()')
    with open('setup.cfg', 'w') as f:
        f.write('[metadata]\n')

# Generated at 2022-06-25 17:43:25.659844
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 1, 'Expected 1, but received {}'.format(var_0)
    assert SetupCfgCommandConfig(name='foo', camel='Foo', description='', commands=()) in var_0, 'Expected SetupCfgCommandConfig(name=\'foo\', camel=\'Foo\', description=\'\', commands=()) in {}, but received not'.format(var_0)
    var_1 = os.path.expanduser('~')
    generator_1 = each_sub_command_config(var_1)
    var_2 = list(generator_1)
    assert len(var_2) == 1, 'Expected 1, but received {}'.format(var_2)

# Generated at 2022-06-25 17:43:26.412484
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True



# Generated at 2022-06-25 17:43:27.683237
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Tests for function each_sub_command_config
    var_0 = test_case_0()

# Generated at 2022-06-25 17:43:28.679481
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        raise

# Generated at 2022-06-25 17:43:41.648067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import each_sub_command_config



# Generated at 2022-06-25 17:43:42.447341
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:43:50.409847
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function, each_sub_command_config."""
    var_0 = each_sub_command_config()
    assert isinstance(var_0, Generator)
    var_1 = list(var_0)
    var_2 = SetupCfgCommandConfig(
        'init', 'Init',
        'Create a new project in the current directory, or change '
        'an existing project to use the given Python project template.',
        ('python -m flutils.templates.init %(setup_dir)s',)
    )
    assert var_1[0] == var_2

# Generated at 2022-06-25 17:43:53.542286
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 17:44:04.344761
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def func_0():
        setup_dir = os.path.dirname(__file__)
        setup_dir = os.path.dirname(setup_dir)
        setup_dir = os.path.dirname(setup_dir)
        setup_dir = os.path.dirname(setup_dir)
        v = each_sub_command_config(setup_dir)
        assert isinstance(v, Generator)
        v = list(v)
        assert isinstance(v, list)
        assert len(v) == 1
        assert isinstance(v[0], SetupCfgCommandConfig)
        assert v[0].name == 'tests.test_setup_cfg_reader'
        assert v[0].camel == 'TestsTestSetupCfgReader'

# Generated at 2022-06-25 17:44:10.842061
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:44:11.617774
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True



# Generated at 2022-06-25 17:44:13.596798
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    t_0 = test_case_0
    print(len(var_0))



# Generated at 2022-06-25 17:44:24.294350
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var = each_sub_command_config('/home/afruehling/dev/flutils/src/flutils')
    var_0 = list(var)

# Generated at 2022-06-25 17:44:29.719249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = str(Path(os.path.dirname(__file__)).parent)
    generator_0 = each_sub_command_config(setup_dir=setup_dir)
    var_0 = list(generator_0)
    assert len(var_0) == 1
    config = var_0[0]
    assert config.name == 'test'
    assert config.camel == 'TestSetupCommand'
    assert config.description == 'Runs tests.'
    assert len(config.commands) == 1
    assert config.commands[0].startswith('pytest')


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:57.572898
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    def test_helper_0(setup_dir: Union[os.PathLike, str]):
        generator_0 = each_sub_command_config(setup_dir)
        var_0 = list(generator_0)

    test_helper_0('/Users/michaelbukachi/Downloads/aimmo')


# Generated at 2022-06-25 17:45:06.027950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test without a setup_dir argument
    # Should raise a FileNotFoundError
    with pytest.raises(FileNotFoundError) as exception_0:
        test_case_0()
    # Test with a setup_dir argument
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_config
    # Should return the next value from the generator each_sub_command_

# Generated at 2022-06-25 17:45:10.597979
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    from coverage import Coverage

    cov = Coverage(source=['setup_cfg_utils'])
    cov.start()

    test_each_sub_command_config()

    cov.stop()
    cov.save()
    cov.html_report(directory='htmlcov')
    cov.erase()

# Generated at 2022-06-25 17:45:14.862166
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
        print(
            'Unit test for each_sub_command_config passed.'
        )
    except:
        print(
            'Unit test for each_sub_command_config failed.'
        )


if __name__ == '__main__':

    # Unit test for each_sub_command_config
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:15.387345
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:45:24.021599
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    import tempfile
    import shutil
    import os

    class TestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.tempdir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.tempdir, 'setup_dir')
            os.makedirs(self.setup_dir)
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_commands_cfg = os.path.join(self.setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-25 17:45:28.894023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        exit_code = 1
    else:
        exit_code = 0
    sys.exit(exit_code)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:37.032396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass  # TODO: Write test


if __name__ == '__main__':
    print(
        '\033[32;1m>\033[m \033[31mExecuting unit test for function '
        'each_sub_command_config ...\033[m'
    )
    print()
    test_case_0()
    print('\033[31;1m<\033[m \033[32mTest results ...\033[m')
    print()
    test_each_sub_command_config()
    print()
    print('\033[32;1m>\033[m \033[31mDone!\033[m')

# Generated at 2022-06-25 17:45:38.886839
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None


if __name__ == "__main__":
    print(test_each_sub_command_config.__doc__)
    print(test_each_sub_command_config())

# Generated at 2022-06-25 17:45:47.440433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # self defined constants
    # self defined variables

    # given,
    setup_dir = _prep_setup_dir()
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~')
    }
    setup_cfg_path = os.path.join(format_kwargs['setup_dir'], 'setup.cfg')
    expected_setup_cfg_path = setup_cfg_path
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)
    expected_setup_cfg_parser = parser
    path = os.path.join(format_kwargs['setup_dir'], 'setup_commands.cfg')

# Generated at 2022-06-25 17:46:46.636979
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    """
    test_case_0()

# Generated at 2022-06-25 17:46:47.453158
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:55.155150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    format_kwargs = {
        'setup_dir': '/Users/jason/repos/flutils/flutils',
        'home': '/Users/jason'
    }

    parser = ConfigParser()
    parser.read('/Users/jason/repos/flutils/flutils/setup.cfg')
    format_kwargs['name'] = 'flutils'

    parser = ConfigParser()
    parser.read('/Users/jason/repos/flutils/flutils/setup_commands.cfg')

    generator_0 = _each_setup_cfg_command(parser, format_kwargs)
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:47:05.142003
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:47:06.154732
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config() is not None

# Generated at 2022-06-25 17:47:06.977157
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:07.976703
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:10.826327
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('test_each_sub_command_config PASSED')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:47:17.150372
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def run_tests():
        import os
        import sys
        import pathlib

        def _tests_helper(f):
            def wrapper(
                    setup_dir: Optional[Union[pathlib.Path, os.PathLike, str]] = None
            ) -> None:
                f(setup_dir)

            return wrapper

        @_tests_helper
        def test_case_0(
                setup_dir: Optional[Union[pathlib.Path, os.PathLike, str]] = None
        ) -> None:
            generator_0 = each_sub_command_config(setup_dir)
            var_0 = list(generator_0)
            assert len(var_0) == 1
            assert var_0[0].name == 'pysetupcfg.tests.sample'
            assert var_0[0].camel

# Generated at 2022-06-25 17:47:17.956719
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0()

# Generated at 2022-06-25 17:49:30.113170
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Executing function "test_each_sub_command_config" ...')
    test_case_0()
    print('Function "test_each_sub_command_config" executed.')


# Run tests
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:49:36.565163
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    base_path = os.path.dirname(os.path.abspath(__file__))
    base_path = os.path.dirname(base_path)
    base_path = os.path.dirname(base_path)
    setup_dir = os.path.join(base_path, 'flutils')
    setup_dir = os.path.realpath(setup_dir)

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)

    assert len(var_0) == 3


# Generated at 2022-06-25 17:49:45.391087
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: Optional[str] = './flutils'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = str(list(generator_0))

# Generated at 2022-06-25 17:49:46.560780
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    ret_val = each_sub_command_config()
    ret_val

# Generated at 2022-06-25 17:49:48.449089
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config.__code__.co_varnames
    assert var_0 == ('setup_dir',)


# Generated at 2022-06-25 17:49:53.304366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """This function unit tests the each_sub_command_config function."""
    assert each_sub_command_config()
    assert each_sub_command_config(os.path.expanduser('~/code'))


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:00.105097
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config('.')
    var_0 = list(generator_0)
    var_1 = var_0[0].name
    var_2 = var_0[0].camel
    var_3 = var_0[0].description
    var_4 = var_0[0].commands
    var_5 = var_0[1].name
    var_6 = var_0[1].camel
    var_7 = var_0[1].description
    var_8 = var_0[1].commands

# Generated at 2022-06-25 17:50:02.526632
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Function that tests function each_sub_command_config."""
    # Run unit tests
    # test_case_0()
    test_case_0()
    return 0



# Generated at 2022-06-25 17:50:03.309748
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:50:07.900283
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    for arg in sys.argv[1:]:
        if arg.startswith('--'):
            arg = arg[2:]
            if arg.startswith('test-'):
                arg = arg[5:]
                if arg.isalnum() is True:
                    func = globals().get('test_' + arg, None)
                    if func:
                        func()