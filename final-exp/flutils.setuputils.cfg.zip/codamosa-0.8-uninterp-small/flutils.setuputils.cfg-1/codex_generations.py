

# Generated at 2022-06-25 17:41:55.137821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Function to test `each_sub_command_config`."""
    generator_0 = each_sub_command_config()
    generator_1 = each_sub_command_config(
        '/home/user/workspace/fl-test-package'
    )
    generator_2 = each_sub_command_config(
        '/home/user/workspace/fl-test-package/setup_commands.cfg'
    )
    for i, generator in enumerate((generator_0, generator_1, generator_2)):
        for config in generator:
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)


# Generated at 2022-06-25 17:42:05.153317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = test_case_0()
    assert isinstance(generator_0, Generator)
    assert next(generator_0).__dict__ == {'name': 'rst-doctest', 'description': 'Doctest the RST files.', 'commands': ('python -m flutils.scripts.rstdoctest',), 'camel': 'RstDoctest'}
    assert next(generator_0).__dict__ == {'name': 'coverage', 'description': 'Run the code coverage checks.', 'commands': ('py.test -vv --cov --cov-config=setup.cfg --cov-report=xml --cov-report=html .',), 'camel': 'Coverage'}

# Generated at 2022-06-25 17:42:06.353630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert isinstance(each_sub_command_config(), Generator)

# Generated at 2022-06-25 17:42:13.084393
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import Generator
    from .utils import MockedSetupCfg

    generator = each_sub_command_config(MockedSetupCfg())
    assert isinstance(generator, Generator)
    for cmd in generator:
        assert isinstance(cmd.name, str)
        assert isinstance(cmd.description, str)
        assert isinstance(cmd.camel, str)
        assert isinstance(cmd.commands, tuple)
        assert len(cmd.commands) >= 1


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:42:22.388696
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test casting
    def t(setup_dir: str) -> None:
        # pylint: disable=unused-variable
        # noinspection PyTypeChecker
        generator = each_sub_command_config(setup_dir)

    # Test with bad data
    for setup_dir in (
        None,  # type: ignore
        ['x'],
        {'x': 'x'},
        1,
    ):
        try:
            t(setup_dir)
        except TypeError:
            pass
        else:
            raise AssertionError("Failed to detect bad 'setup_dir' of %r."
                                 % setup_dir)

    # Test with a valid directory

# Generated at 2022-06-25 17:42:28.877439
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    list_0 = list(generator)
    assert list_0[0].camel == 'foo'
    assert list_0[1].camel == 'Bar'
    assert list_0[2].camel == 'Baz'
    assert list_0[3].camel == 'qux'



# Generated at 2022-06-25 17:42:36.654217
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from unittest import TestCase
    from unittest.mock import patch


# Generated at 2022-06-25 17:42:40.227227
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint
    for item in each_sub_command_config():
        pprint.pprint(item)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:42:44.105446
# Unit test for function each_sub_command_config
def test_each_sub_command_config():  # noqa: D103
    generator_0 = each_sub_command_config()
    for obj_0 in generator_0:
        SetupCfgCommandConfig = obj_0
        pass
    pass



# Generated at 2022-06-25 17:42:48.840540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    command_name_list = [
        'test', 'clean', 'dev', 'build', 'publish',
        'docs', 'check', 'install', 'dev_install'
    ]
    generator_0 = each_sub_command_config()
    for cmd_config in generator_0:
        assert cmd_config.name in command_name_list


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:10.099763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import flutils.systemutils as systemutils

    # Setup test setup.py file
    setup_dir = tempfile.mkdtemp()
    setup_file = os.path.join(setup_dir, 'setup.py')
    text = """\
import setuptools

setuptools.setup(
    name='some-name',
    version='0.1',
    description='some-description',
)
"""
    with open(setup_file, 'w') as out:
        out.write(text)

    # Setup test setup.cfg file
    setup_cfg_file = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-25 17:43:17.830176
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    This is a test to ensure the main functionality of each_sub_command_config
    is behaving as expected.
    """
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    var_1 = var_0[0]
    var_2 = var_1.camel
    var_3 = var_1.description
    var_4 = var_0[1]
    var_5 = var_4.camel
    var_6 = var_4.description
    var_7 = var_0[2]
    var_8 = var_7.camel
    var_9 = var_7.description
    var_10 = var_0[3]
    var_11 = var_10.camel
    var_12 = var_10.description


# Generated at 2022-06-25 17:43:19.082047
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:27.069828
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'test', f'Expected: <test>, but was: <{var_0.name}>.'
    var_1 = next(generator_0)
    assert var_1.name == 'test2', f'Expected: <test2>, but was: <{var_1.name}>.'
    var_2 = next(generator_0)
    assert var_2.name == 'test5', f'Expected: <test5>, but was: <{var_2.name}>.'
    var_3 = next(generator_0)

# Generated at 2022-06-25 17:43:31.799249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for var_0 in each_sub_command_config(
            os.path.dirname(os.path.dirname(__file__))
    ):
        assert isinstance(var_0.name, str)
        assert isinstance(var_0.camel, str)
        assert isinstance(var_0.description, str)
        assert isinstance(var_0.commands, tuple)

# Generated at 2022-06-25 17:43:32.443796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True

# Generated at 2022-06-25 17:43:33.860739
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    ret = test_case_0()
    assert (ret == None)

# Generated at 2022-06-25 17:43:34.666351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True


# Generated at 2022-06-25 17:43:45.068516
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.osutils as osutils
    import os

    # Create a test directory and populate it with the necessary files
    test_dir = osutils.prep_test_dir(os.path.realpath(__file__))
    os.makedirs(os.path.join(test_dir, 'tests'))
    os.chdir(test_dir)
    # Create setup.py
    with open(os.path.join(test_dir, 'setup.py'), 'w') as setup_file:
        setup_file.write(
            """
import os

from distutils.core import setup

if __name__ == '__main__':
    setup(name='test_flutils')
"""
        )
    # Create setup.cfg

# Generated at 2022-06-25 17:43:45.917059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:01.459080
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #
    tester = test_case_0

    # --------------------------------------------------------------

    results = tester()

    # --------------------------------------------------------------

    assert results is None



# Generated at 2022-06-25 17:44:03.432609
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config(setup_dir='') == ''
    assert each_sub_command_config(setup_dir=0) == 0



# Generated at 2022-06-25 17:44:05.417867
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# If the file is called directly, execute the test
if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:08.520689
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config(setup_dir='.')
    var_1 = next(var_0)
    assert var_1 == SetupCfgCommandConfig(
        name='build',
        camel='Build',
        description='Build the source distribution',
        commands=('python setup.py sdist',),
    )

# Generated at 2022-06-25 17:44:13.901389
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:44:24.433939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Load the implementation to test
    import setup_sub_commands

    def each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for config in setup_sub_commands.each_sub_command_config(setup_dir):
            yield config

    # Test the function
    def each_sub_command_config_test_0():
        from pathlib import Path
        from setup_sub_commands import SetupCfgCommandConfig
        generator = each_sub_command_config()
        for config in generator:
            assert isinstance(config, SetupCfgCommandConfig)

    def each_sub_command_config_test_1():
        from pathlib import Path
        from setup_sub_commands import Setup

# Generated at 2022-06-25 17:44:25.222657
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()

# Generated at 2022-06-25 17:44:31.054920
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Arrange
    setup_dir: Optional[str] = None
    # Act
    generator_0 = each_sub_command_config(setup_dir)
    # Assert
    assert isinstance(generator_0, Generator)
    for var_0 in generator_0:
        assert isinstance(var_0, SetupCfgCommandConfig)



# Generated at 2022-06-25 17:44:31.925785
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:41.014879
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path_0 = os.path.join(os.path.dirname(__file__), 'test_data_0')
    generator_0 = each_sub_command_config(setup_dir=path_0)
    var_0 = list(generator_0)
    assert len(var_0) == 2


if __name__ == '__main__':
    import logging
    import sys
    logging.basicConfig(
        level=logging.DEBUG,
        stream=sys.stdout,
        format='%(levelname)s:  %(name)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    logger.info("Running...")

# Generated at 2022-06-25 17:44:55.678782
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_1 = test_case_0()


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:44:57.132827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    test_case_0()

# Generated at 2022-06-25 17:45:05.712117
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from pathlib import Path
    from subprocess import CompletedProcess, run, STDOUT

    from flutils.sysutils import get_python_path

    if sys.platform == 'win32':
        return


# Generated at 2022-06-25 17:45:07.014401
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:15.104194
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 2
    var_1 = var_0[0]
    assert var_1.name == 'clean'
    assert var_1.camel == 'Clean'
    assert var_1.description == 'Cleanup generated files.'
    var_2 = var_1.commands
    assert var_2[0] == 'rm -rf build/'
    assert var_2[1] == 'rm -rf dist/'
    assert var_2[2] == 'rm -rf .eggs/'
    assert var_2[3] == 'find . -name \'*.egg-info\' -exec rm -fr {} +'

# Generated at 2022-06-25 17:45:15.908879
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:45:24.699929
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    #
    # This file is in the project's src directory, so the parent directory
    # should be that of the project
    #

    # This should succeed
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)  # type: ignore
    assert isinstance(var_0, list)
    assert len(var_0) > 0
    for val in var_0:
        assert isinstance(val, SetupCfgCommandConfig)
        assert isinstance(val.name, str)
        assert isinstance(val.camel, str)
        assert isinstance(val.description, str)
        assert isinstance(val.commands, tuple)
        for cmd in val.commands:
            assert isinstance(cmd, str)

    # This should fail
    generator_1 = each_

# Generated at 2022-06-25 17:45:26.826822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command_config in each_sub_command_config():
        print(sub_command_config)



# Generated at 2022-06-25 17:45:31.944890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import unittest
    try:
        test_case_0()
    except Exception:
        import sys
        import traceback
        error_type, error, traceback_ = sys.exc_info()
        traceback.print_exception(error_type, error, traceback_, limit=2)
        del error_type, error, traceback_


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:32.942828
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:45:57.796068
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_dir in (None, '.'):
        test_case_0()

# Generated at 2022-06-25 17:46:07.480286
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    import sys
    import timeit

    try:
        __file__
    except NameError:
        __file__ = sys.argv[0]
    print(__file__)

    print('setup_dir="~/dev/elib_run"')
    print('setup_dir=None')

    for i in range(2):
        print('-' * 80)

# Generated at 2022-06-25 17:46:09.060960
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_command in each_sub_command_config():
        print(sub_command)


# Generated at 2022-06-25 17:46:16.188107
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # For this command
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert isinstance(var_0, tuple)
    var_1, var_2, var_3, var_4 = var_0
    assert var_1 == 'run'
    assert isinstance(var_2, str)
    assert isinstance(var_3, str)
    assert isinstance(var_4, tuple)
    var_5 = next(generator_0)
    assert isinstance(var_5, tuple)
    var_6, var_7, var_8, var_9 = var_5
    assert var_6 == 'sdist'
    assert isinstance(var_7, str)
    assert isinstance(var_8, str)

# Generated at 2022-06-25 17:46:17.185986
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:46:23.530446
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    name = 'setup_commands'
    setup_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        name
    )
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    var_1 = []
    for var_2 in var_0:
        var_1 += [var_2.name]
    var_1 = sorted(var_1)
    assert var_1 == ['test.test_usages', 'test.test_usages.test_case_0']



# Generated at 2022-06-25 17:46:26.095566
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    this_file = os.path.abspath(os.path.expanduser(__file__))
    test_case_0()

# Generated at 2022-06-25 17:46:27.757570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    pass


if __name__ == '__main__':
    test()

# Generated at 2022-06-25 17:46:29.900757
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:46:35.830044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    path = os.path.dirname(__file__)
    generator_0 = each_sub_command_config(path)
    var_0 = list(generator_0)
    assert var_0 == [
        SetupCfgCommandConfig(
            'create-new-project',
            'CreateNewProject',
            '',
            (
                'new_project.py --package_name flutils --description '
                '"Flask utils project"',
            )
        ),
    ]


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:16.666001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(
        '/home/david/workspace/python/flutils/flutils'
    )
    tup_0 = (
        SetupCfgCommandConfig(
            'coverage',
            'Coverage',
            'Generate test coverage reports',
            ('coverage erase', 'coverage run -m pytest', 'coverage html')
        ),
        SetupCfgCommandConfig(
            'flakes',
            'Flakes',
            'Run pylint against module(s)',
            ('flake8',)
        ),
        SetupCfgCommandConfig(
            'tests',
            'Tests',
            'Runs the project\'s tests',
            ('python setup.py test',)
        )
    )
    tup_1 = tuple(generator_0)

# Generated at 2022-06-25 17:47:17.713468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert isinstance(each_sub_command_config(), types.GeneratorType)

# Generated at 2022-06-25 17:47:20.656170
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setuputils

    generator_0 = flutils.setuputils.each_sub_command_config()
    var_0 = list(generator_0)

    var_1 = len(var_0)
    assert var_1 == 2



# Generated at 2022-06-25 17:47:23.086544
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:26.790622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    This is a unit test for the :py:func:`each_sub_command_config`.
    """
    assert len(list(each_sub_command_config())) > 0



# Generated at 2022-06-25 17:47:35.073710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config in module flutils.sysutils
    """
    from flutils.testutils import (
        long_message,
        test_case_expected_result,
        test_case_success,
        test_value_in_list
    )
    result_0 = test_case_0()

# Generated at 2022-06-25 17:47:37.987851
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 1
    assert var_0[0].name == 'my_project'

# Generated at 2022-06-25 17:47:48.341250
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    assert isinstance(var_0, Generator)
    var_2 = next(var_0)
    assert var_2.name == 'install'
    assert var_2.camel == 'Install'
    assert var_2.description == 'Installs this package.'
    assert var_2.commands[0] == 'python setup.py install'
    var_2 = next(var_0)
    assert var_2.name == 'upload'
    assert var_2.camel == 'Upload'
    assert var_2.description == 'Uploads a distribution of this package.'
    assert var_2.commands[0] == 'python setup.py sdist upload'
    var_2 = next(var_0)

# Generated at 2022-06-25 17:47:54.968392
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Running each_sub_command_config() tests...')
    import tempfile
    from pathlib import Path

    setup_dir = tempfile.TemporaryDirectory()
    setup_dir = str(setup_dir.name)
    command_dir = Path(setup_dir)
    command_dir.mkdir()
    setup_cfg_path = command_dir / 'setup.cfg'
    setup_cfg_path.write_text(
        """
[metadata]
author = Me
author_email = me@example.com
classifiers =
    Development Status :: 5 - Production/Stable
description = some setup.cfg file
license = MIT
name = flutils
url = https://github.com/mfitzp/flutils
""".lstrip()
    )

# Generated at 2022-06-25 17:48:00.734759
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    test_setup = SetupCfgCommandConfig(
        'test', 'Test', 'Runs all of the unit tests.', (
            '{setup_dir}/setup.py test',
        )
    )
    var_1 = test_setup in var_0
    var_2 = len(var_0) >= 1
    assert var_1 == True
    assert var_2 == True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:49:09.564822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.dirname(test_dir)
    test_dir = os.path.join(test_dir, 'test_data')
    test_case_0()

# Generated at 2022-06-25 17:49:11.196977
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:49:14.129541
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # TODO: Test that the function actually works
    assert True


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:49:15.129523
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert iter(each_sub_command_config())



# Generated at 2022-06-25 17:49:16.286193
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test case 0."""
    test_case_0()

# Generated at 2022-06-25 17:49:17.019362
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test logic
    test_case_0()

# Generated at 2022-06-25 17:49:23.995269
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config function for the following cases:
    - Valid setup_cfg_path, no sub-directories
    - Valid setup_cfg_path, with sub-directories
    - Invalid setup_cfg_path
    """

    # TESTCASE #0 - Valid setup_cfg_path, no sub-directories
    test_case_0()

    # TESTCASE #1 - Valid setup_cfg_path, with sub-directories
    test_case_1()

    # TESTCASE #2 - Invalid setup_cfg_path
    test_case_2()


if __name__ == '__main__':
    import logging
    import sys
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.INFO
    )

    test_each_sub_command

# Generated at 2022-06-25 17:49:25.138630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # no setup.cfg exists at the project's root directory
    test_case_0()


# Generated at 2022-06-25 17:49:28.398054
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    r = each_sub_command_config('/home/daniel/Documents/ab.py/')
    var_0 = list(r)
    assert len(var_0) != 0

# Regression test for function each_sub_command_config

# Generated at 2022-06-25 17:49:33.703204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'tests/fixtures/test-0'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    assert var_0 == [
        SetupCfgCommandConfig(
            'test',
            'Test',
            'Run test commands.',
            ('echo test', 'echo test again')
        ),
        SetupCfgCommandConfig(
            'test.unit',
            'TestUnit',
            'Run unit tests.',
            ('echo unit', 'echo unit again')
        )
    ]

