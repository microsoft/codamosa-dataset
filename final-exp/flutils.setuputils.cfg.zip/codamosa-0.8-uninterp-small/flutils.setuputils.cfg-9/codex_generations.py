

# Generated at 2022-06-25 17:41:54.146086
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    setup_dir = os.path.split(setup_dir)[0]
    setup_dir = os.path.join(setup_dir, 'setup_commands_config_test0')
    for cfg in each_sub_command_config(setup_dir):
        print(cfg)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:03.902422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_source = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../../../../..'
        )
    )
    assert os.path.isdir(project_source)
    assert os.path.isfile(os.path.join(project_source, 'setup.py'))
    assert os.path.isfile(os.path.join(project_source, 'setup.cfg'))
    for setup_cfg_command_config in each_sub_command_config(project_source):
        print(setup_cfg_command_config.name)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:07.152068
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config_0 in each_sub_command_config():
        print(setup_cfg_command_config_0)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:12.913346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config(
        setup_dir=__file__
    ):
        print(setup_cfg_command_config.name)
        print(setup_cfg_command_config.description)
        print('\n'.join(setup_cfg_command_config.commands))
        break

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:42:14.284734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pprint

    pprint.pprint(list(each_sub_command_config(None)))

# End of code

# Generated at 2022-06-25 17:42:23.317326
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    config_list = []
    for config in each_sub_command_config(setup_dir):
        if config.name in {'test', 'pylint', 'mypy'}:
            config_list.append(config.name)
            assert not config.camel
            assert config.description
            assert config.commands
            if config.name == 'test':
                assert config.camel == config.name.capitalize()
            elif config.name == 'pylint':
                assert config.camel == 'Lint'
            elif config.name == 'mypy':
                assert config.camel == 'TypeCheck'
    assert config_list == ['test', 'pylint', 'mypy']



# Generated at 2022-06-25 17:42:29.364742
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from . import package_metadata

    from .dummy_project.version import VERSION
    from .dummy_project.package_metadata import PACKAGE_METADATA

    for config in each_sub_command_config():
        assert config.name in package_metadata.PACKAGE_METADATA[
            'console_scripts'
        ]



# Generated at 2022-06-25 17:42:33.363726
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_command_config = next(each_sub_command_config())
    assert isinstance(setup_cfg_command_config.name, str)
    assert isinstance(setup_cfg_command_config.camel, str)
    assert isinstance(setup_cfg_command_config.description, str)
    assert isinstance(setup_cfg_command_config.commands, tuple)

# Generated at 2022-06-25 17:42:40.345520
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for setup_cfg_command_config in each_sub_command_config(
            os.path.join(os.path.dirname(__file__), '..')
    ):
        if setup_cfg_command_config.name == 'makemessages':
            assert setup_cfg_command_config.name == 'makemessages'
            assert setup_cfg_command_config.camel == 'MakeMessages'
            assert setup_cfg_command_config.description == \
                'Run makemessages script to create the translation files.'

# Generated at 2022-06-25 17:42:43.891586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    config = None
    for config in each_sub_command_config(os.path.realpath('.')):
        pass
    assert(config.camel == 'RunTests')

# Generated at 2022-06-25 17:43:00.201112
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test case 0
    try:
        test_case_0()
    except Exception as err:
        print(err)
        fail_cnt += 1
    else:
        pass_cnt += 1

    print('No of tests: %d' % test_case_cnt)
    print('No of Passed: %d' % pass_cnt)
    print('No of Failed: %d' % fail_cnt)


if __name__ == '__main__':
    pass  # test_each_sub_command_config()

# Generated at 2022-06-25 17:43:09.553469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import makedirs
    from os.path import (
        abspath,
        dirname,
        join,
    )
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from flutils.pathutils import each_dir

    with TemporaryDirectory(prefix='test_each_sub_command_config-') as tmpdir:
        # 1. Test with only setup.cfg
        setup_dir = Path(tmpdir).joinpath('setup_dir')
        makedirs(setup_dir.joinpath('subdir_one').as_posix())
        makedirs(setup_dir.joinpath('subdir_two').as_posix())
        setup_cfg_path = setup_dir.joinpath('setup.cfg')

# Generated at 2022-06-25 17:43:10.121491
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:43:10.638550
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:13.570795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError:
        pass


if __name__ == '__main__':
    try:
        test_case_0()
    except FileNotFoundError:
        pass

# Generated at 2022-06-25 17:43:14.123315
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:43:15.007215
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:43:15.869228
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:17.823146
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:19.080254
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() is None

# Generated at 2022-06-25 17:43:32.795599
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:42.559953
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    project_path = os.path.abspath(os.path.dirname(__file__))
    project_path = os.path.join(project_path, '..')
    project_path = os.path.join(project_path, '..')
    project_path = os.path.realpath(project_path)

    generator_0 = each_sub_command_config(project_path)
    var_0 = list(generator_0)

    assert len(var_0) == 2
    assert var_0[0].name == 'myproject.hello'

    generator_1 = each_sub_command_config(project_path)
    var_1 = list(generator_1)

    assert len(var_1) == 2
    assert var_1[1].name == 'myproject.world'

# Generated at 2022-06-25 17:43:46.791380
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.environ.get('TEST_SETUP_DIR') or ''
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    assert len(var_0) > 0

# vim: set ts=4 sw=4 tw=79 ft=python et :

# Generated at 2022-06-25 17:43:48.364896
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:51.198763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case 0
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    # Test case 1
    generator_0 = each_sub_command_config('/Users/stevedolla/src/python/flutils')
    var_0 = list(generator_0)



# Generated at 2022-06-25 17:43:53.262270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:43:56.943345
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Case 0
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

    # Check return
    assert len(var_0) == 0



# Generated at 2022-06-25 17:43:58.059382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:44:03.612353
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    generator_0 = each_sub_command_config(
        str(os.path.join(os.path.dirname(__file__), '..'))
    )
    # Test
    var_0 = list(generator_0)
    # Validate
    assert len(var_0) == 1


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:44:10.327624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_1 = each_sub_command_config()
    list_1 = list(generator_1)
    assert(len(list_1) == 4)
    assert(list_1[0].name == 'dev')
    assert(list_1[0].camel == 'Dev')
    assert(len(list_1[0].commands) == 1)
    assert(list_1[0].commands[0] == 'envdev')
    assert(list_1[1].name == 'preprod')
    assert(list_1[1].camel == 'Preprod')
    assert(len(list_1[1].commands) == 1)
    assert(list_1[1].commands[0] == 'envpreprod')
    assert(list_1[2].name == 'prod')

# Generated at 2022-06-25 17:44:45.480023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # passing
    list(each_sub_command_config())
    # passing
    list(each_sub_command_config(os.path.dirname(__file__)))
    # passing
    list(each_sub_command_config(__file__))

    # passing
    try:
        list(each_sub_command_config(__file__))
    except LookupError:
        pass

    # passing
    try:
        list(each_sub_command_config(
            os.path.join(os.path.dirname(__file__), '..')
        ))
    except LookupError:
        pass

    # passing
    try:
        list(each_sub_command_config('/'))
    except LookupError:
        pass

    # passing

# Generated at 2022-06-25 17:44:46.541220
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:44:57.612586
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Make the function fail if the setup directory could not be
    # found.
    try:
        each_sub_command_config()
    except FileNotFoundError:
        pass
    else:
        raise RuntimeError('Failed to raise FileNotFoundError.')

    # Make the function fail if the setup.cfg file is missing.
    current_dir = os.path.realpath(os.path.dirname(__file__))
    setup_dir = os.path.join(current_dir, 'tests', 'data', 'missing_setup_cfg')
    try:
        each_sub_command_config(setup_dir)
    except FileNotFoundError:
        pass
    else:
        raise RuntimeError('Failed to raise FileNotFoundError.')

    # Test the case where setup_commands.cfg is missing.
   

# Generated at 2022-06-25 17:45:06.028581
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:45:09.660762
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    Unit tests for the function each_sub_command_config.
    """
    import sys

    if sys.platform == 'linux':
        test_case_0()
    else:
        try:
            test_case_0()
        except FileNotFoundError:
            pass

# Generated at 2022-06-25 17:45:11.422467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() == None

if __name__ == '__main__':
    print(test_each_sub_command_config())

# Generated at 2022-06-25 17:45:16.764806
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.fileutils import (
        get_setup_dir,
        each_setup_cfg_command,
    )
    setup_dir = get_setup_dir()
    if setup_dir:
        generator_0 = each_sub_command_config(setup_dir=setup_dir)
        generator_1 = each_setup_cfg_command(setup_dir=setup_dir)
        var_0 = list(generator_0)
        var_1 = list(generator_1)
        assert var_0 == var_1

# Generated at 2022-06-25 17:45:26.247205
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from typing import Generator, NamedTuple
    from test_each_sub_command_config import (
        setup_dir,
        var_1,
        var_0,
    )

    ########################################################################
    # Verification
    assert setup_dir
    assert isinstance(var_0, list)
    assert isinstance(var_1, list)

    ########################################################################
    # Validation
    # setup_dir
    assert isinstance(setup_dir, str) and setup_dir
    assert os.path.exists(setup_dir) and os.path.isdir(setup_dir)

    # var_0
    assert isinstance(var_0, list)

# Generated at 2022-06-25 17:45:26.916481
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass



# Generated at 2022-06-25 17:45:31.431240
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as err:
        print('TestCase 0', file=sys.stderr)
        print('traceback:', file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        print(err, file=sys.stderr)
        sys.exit(1)



# Generated at 2022-06-25 17:46:04.277173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    setup_dir = os.path.join(os.path.dirname(__file__), os.pardir)
    # Exercise
    generator = each_sub_command_config(setup_dir)
    command_config = list(generator)
    # Verify
    assert len(command_config) == 1
    item = command_config[0]
    assert item.name == 'test'
    assert item.camel == 'Test'
    assert item.description == 'Used for development.'
    assert item.commands == (
        'python setup.py test -a "--test_repo_dir=<home>/tmp/test"',
        'python setup.py test -a "--test_repo_dir=<home>/tmp/test --doctest-modules"',
    )

# Unit test

# Generated at 2022-06-25 17:46:05.413948
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for info in each_sub_command_config():
        print(info)

# Generated at 2022-06-25 17:46:08.426601
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    print('test_each_sub_command_config done.')


if __name__ == "__main__":
    test_each_sub_command_config()
    print('All done.')

# Generated at 2022-06-25 17:46:11.598059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    generator_0.send(None)
    var_0 = list(generator_0)
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:12.362042
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert test_case_0() == list()

# Generated at 2022-06-25 17:46:13.228721
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:46:14.681662
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert var_0



# Generated at 2022-06-25 17:46:18.027134
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()
    assert var_0
    var_1 = next(var_0)
    assert isinstance(var_1, SetupCfgCommandConfig)
    assert var_1.name
    assert var_1.camel
    assert var_1.description
    assert var_1.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:20.651796
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        assert item is not None


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:46:25.067691
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config('./')
    configs = list(generator)
    assert configs and isinstance(configs[0], SetupCfgCommandConfig)
    assert len(configs) == 1
    assert configs[0].name == 'test_run'
    assert configs[0].camel == 'TestRun'
    assert configs[0].description == 'Run the tests.'
    assert configs[0].commands == ('python -m unittest discover',)



# Generated at 2022-06-25 17:47:03.733855
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import random
    import string
    import tempfile

    from setupcfg.setupcfg import each_sub_command_config

    # Arrange
    # Generate random name with default length of 10 characters
    r_name = lambda: ''.join(random.choices(string.ascii_letters, k=10))
    r_name_0 = r_name()
    r_name_1 = r_name()
    r_name_2 = r_name()

    # Create directory and setup.cfg file
    # Get parent of temporary directory with setup.cfg
    dir_path = tempfile.mkdtemp()
    setup_cfg_path = os.path.join(dir_path, 'setup.cfg')

# Generated at 2022-06-25 17:47:05.402557
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:08.508540
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    x0 = each_sub_command_config()
    assert isinstance(x0, Generator)
    x1 = list(x0)
    assert isinstance(x1, list)
    assert len(x1) == 0



# Generated at 2022-06-25 17:47:16.155885
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the ``each_sub_command_config`` function."""
    generator_1 = each_sub_command_config()
    var_4 = list(generator_1)
    assert len(var_4) == 1
    var_5 = var_4[0]
    assert var_5.name == 'bad_cmd'
    assert var_5.camel == 'BadCmd'
    assert var_5.description == 'No good!'
    assert list(var_5.commands) == ['pip freeze']
    generator_2 = each_sub_command_config()
    var_6 = list(generator_2)
    assert len(var_6) == 1
    var_7 = var_6[0]
    assert var_7.name == 'bad_cmd'

# Generated at 2022-06-25 17:47:20.554058
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # var_0 = None  # type: Optional[Any]
    # var_1 = None  # type: Optional[List[SetupCfgCommandConfig]]
    # var_2 = None  # type: SetupCfgCommandConfig
    # setup_dir = None  # type: Optional[Union[os.PathLike, str]]
    # generator_0 = None  # type: Generator[SetupCfgCommandConfig, None, None]
    test_case_0()

# Generated at 2022-06-25 17:47:24.125723
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    assert True


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:24.988701
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:47:27.824922
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    return

# Generated at 2022-06-25 17:47:30.404940
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test Case #0
    print("\n# Test Case #0")
    test_case_0()

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:31.100090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:48:28.821503
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint

    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    pprint(var_0)


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 17:48:32.358646
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.parsing import each_sub_command_config
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)


# Generated at 2022-06-25 17:48:36.357885
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("Unit test for function each_sub_command_config")
    print("=" * 79)
    print()
    try:
        test_case_0()
    except Exception as e:
        print("Error: {0}".format(e))
        return False
    print("Function each_sub_command_config passed unit test")
    print("=" * 79)
    print()
    return True

# Generated at 2022-06-25 17:48:37.057620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:37.781495
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:38.594485
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:39.484042
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:48:40.354334
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 17:48:45.560099
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from clu.importing import (
        import_attr,
    )
    from clu.predicates import (
        islist,
        istuple,
    )
    import_attr(each_sub_command_config, 'test_case_0')()
    # assert islist(var_0)
    # assert istuple(var_0[0])
    # assert len(var_0) == 1

if __name__ == '__main__':
    each_sub_command_config()

# Generated at 2022-06-25 17:48:47.069471
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except FileNotFoundError:
        pass



# Generated at 2022-06-25 17:51:04.973402
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config.__doc__
    test_case_0()


if __name__ == '__main__':
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        '-d', '--debug',
        action='store_true',
        help=("If given, then the unit test will "
              "execute in debug mode.")
    )
    args = arg_parser.parse_args()
    if args.debug:
        from flutils.debugutils import set_trace
        set_trace()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:51:07.442422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config(
        '~/Projects/python-flutils/tests/rsc/setup_cmds'
    )
    var_0 = list(generator_0)


# vim: set ts=8 sw=4 tw=80 et:

# Generated at 2022-06-25 17:51:18.296835
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:51:19.287385
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for cfg in each_sub_command_config():
        print(cfg)

# Generated at 2022-06-25 17:51:27.430818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import (
        each_sub_command_config
    )

    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert len(var_0) == 2

    generator_1 = each_sub_command_config(
        'flutils'
    )
    var_1 = list(generator_1)
    assert len(var_1) == 2

    generator_2 = each_sub_command_config(
        'test'
    )
    var_2 = list(generator_2)
    assert len(var_2) == 2


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:51:28.953838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



test_each_sub_command_config()

# Generated at 2022-06-25 17:51:39.156991
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    var_1 = var_0.name
    assert var_1 == 'add_auth_token'
    var_2 = var_0.camel
    assert var_2 == 'AddAuthToken'
    var_3 = var_0.description
    assert var_3 == 'Generates a GitHub Personal Access Token for '
    var_4 = var_0.commands