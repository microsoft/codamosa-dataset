

# Generated at 2022-06-25 17:41:53.065539
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(os.path.dirname(__file__))
    for cmd_cfg in each_sub_command_config(setup_dir):
        print('-' * 36)
        print(cmd_cfg.name)
        print('-' * 36)
        print(cmd_cfg.description)
        print('-' * 36)
        print('\n'.join(cmd_cfg.commands))


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:41:59.533057
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd_config in each_sub_command_config():
        assert isinstance(sub_cmd_config.name, str)
        assert isinstance(sub_cmd_config.camel, str)
        assert isinstance(sub_cmd_config.description, str)
        assert isinstance(sub_cmd_config.commands, tuple)
        for command in sub_cmd_config.commands:
            assert isinstance(command, str)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:42:04.115527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("TESTING: {}".format(os.path.basename(__file__)))
    # print("\n{}".format(__file__).replace("A", "B"))
    for x in each_sub_command_config():
        print("\t{}".format(x))


# Generated at 2022-06-25 17:42:06.071069
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_command_configs = list(each_sub_command_config())
    assert setup_cfg_command_configs



# Generated at 2022-06-25 17:42:15.104705
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # The path to the directory that contains the project's `setup.py`.
    setup_dir = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.dirname(setup_dir)
    setup_dir = os.path.dirname(setup_dir)

    # For each sub-command configuration in the project's `setup.cfg`.
    for setup_cfg_command_config in each_sub_command_config(setup_dir):
        print(setup_cfg_command_config)
        assert setup_cfg_command_config_0 != setup_cfg_command_config

    # For each sub-command configuration in the project's `setup.cfg`.

# Generated at 2022-06-25 17:42:23.185911
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # test_case_1
    expected = (
        SetupCfgCommandConfig(
            'change_version',
            'ChangeVersion',
            'Change the version information.',
            (
                'git tag v{version}',
                'git push --tags'
            )
        ),
        SetupCfgCommandConfig(
            'new_release',
            'NewRelease',
            'New release.',
            (
                'python setup.py sdist bdist_wheel',
                'twine check dist/*',
                'twine upload dist/*'
            )
        )
    )
    actual = list(each_sub_command_config('samples/test_each_sub_command_config'))
    assert actual == expected



# Generated at 2022-06-25 17:42:31.921570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    _each_setup_cfg_command_section(ConfigParser())
    _each_setup_cfg_command(ConfigParser(), {})
    _get_name(ConfigParser(), '')
    return
    _validate_setup_dir('')
    _prep_setup_dir('')
    return
    list(each_sub_command_config('/Users/jbetts/code/flutils'))
    return
    assert isinstance(each_sub_command_config(), Generator)
    return


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:34.019683
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case
    test_case_0()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:38.596499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import run_unittest
    import unittest
    import sys
    sys.path.insert(0, str('tests'))
    from test_each_sub_command_config import TestEachSubCommandConfig
    TestEachSubCommandConfig.__module__ = 'test_each_sub_command_config'
    run_unittest(unittest.defaultTestLoader.loadTestsFromTestCase(
        TestEachSubCommandConfig
    ))

# Generated at 2022-06-25 17:42:48.386314
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from tempfile import TemporaryDirectory

    from flutils.filesys import path_join, touch

    with TemporaryDirectory() as tmp_dir:

        def _create_files(config_file: str) -> None:
            commands = \
                """
                [setup.commands.run_command]
                command = python setup.py run -h
                """
            commands = commands.strip()

            setup = \
                """
                import sys
                from setuptools import setup
                setup(name='Test Project', packages=['src'])
                sys.exit(0)
                """
            setup = setup.strip()

            with open(config_file, 'w') as f:
                f.write(commands)
            touch(path_join(tmp_dir, 'setup.py'), data=setup)

# Generated at 2022-06-25 17:42:57.464369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print('Test case 1')
    test_case_0()



# Generated at 2022-06-25 17:43:00.769320
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Each test case must explicitly call test_case_0()
    test_case_0()
    pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:05.566000
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.projectutils import each_sub_command_config
    import os.path as osp



# Generated at 2022-06-25 17:43:08.398767
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        # Test Case #0
        test_case_0()
    except:
        raise

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:43:16.688139
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Define test data
    setup_dir_0: Optional[str] = ''

    # Define expected call results

# Generated at 2022-06-25 17:43:25.935406
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        generator_1 = each_sub_command_config()
        var_1 = list(generator_1)
        assert var_1 == [], 'Failed at assertion #1'
    except FileNotFoundError:
        pass
    for var_2 in ('setup_dir',):
        var_1 = (
            'setuputils.config._get_name(parser, setup_cfg_path) got an unexpected'
            ' keyword argument \'setup_dir\''
        )
        try:
            each_sub_command_config(var_2)
            assert False, 'Failed at assertion #2'
        except TypeError:
            pass
        else:
            assert False, 'Failed at assertion #3'
        assert var_1 in _exc_info(), 'Failed at assertion #4'

# Generated at 2022-06-25 17:43:26.711457
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True

# Generated at 2022-06-25 17:43:35.853547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_cases = [
        (0, 1),
        (1, 2),
        (2, 3),
    ]
    for n, (test_case_id, expected_result) in enumerate(test_cases):
        with patch.object(__builtin__, 'print') as mock_print:
            with patch(
                    'flutils.setuputils.each_sub_command_config',
                    return_value=expected_result
            ) as mock_each_sub_command_config:
                with patch.object(__builtin__, 'input', return_value=3) \
                        as mock_input:
                    with pytest.raises(SystemExit) as pytest_wrapped_e:
                        setup_main()
                assert mock_each_sub_command_config.call_count == 1
                args, kw

# Generated at 2022-06-25 17:43:39.697397
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    res = each_sub_command_config()
    assert isinstance(res, Generator)
    var_0 = list(res)
    assert isinstance(var_0, list)
    assert var_0 == []

    print('Test passed!')

# Generated at 2022-06-25 17:43:41.915660
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = None
    test_case_0()
    test_each_sub_command_config_p(setup_cfg_path)



# Generated at 2022-06-25 17:43:59.100945
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the functionality of each_sub_command_config"""
    
    # Test with good inputs
    
    setup_dir = _prep_setup_dir()
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)
    
    

if __name__ == '__main__':
    import pytest

    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 17:44:06.658331
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = list(generator_0)

# Generated at 2022-06-25 17:44:09.917165
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.cfgutils import each_sub_command_config
    from flutils.setuputils import test_case_0

    for case in (test_case_0, ):
        yield case


if __name__ == '__main__':
    for case in test_each_sub_command_config():
        case()

# Generated at 2022-06-25 17:44:20.866898
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.utils import cd
    from flutils.testutils import GeneratorAssertionHelper
    with cd(os.path.join('tests', 'cmds')):
        var_0 = next(each_sub_command_config())
        assert isinstance(var_0, SetupCfgCommandConfig)
        assert isinstance(var_0, tuple)
        assert var_0[0] == 'build_docs'
        assert var_0[1] == 'BuildDocs'
        assert var_0[2] == 'Build the documentation'
        assert isinstance(var_0[3], tuple)
        assert isinstance(var_0[3][0], str)
        assert var_0[3][0] == 'make -C docs html'
        assert isinstance(var_0, SetupCfgCommandConfig)
        assert isinstance

# Generated at 2022-06-25 17:44:22.371712
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function each_sub_command_config."""
    test_case_0()

# Generated at 2022-06-25 17:44:24.398150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_cases = (
        # test_case_0
        test_case_0,
    )
    for test_case in test_cases:
        yield test_case

# Generated at 2022-06-25 17:44:30.543286
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    list_0 = [x for x in generator_0]
    assert len(list_0) == 5
    assert list_0[0].name == 'dev-clean'
    assert list_0[0].camel == 'DevClean'
    assert list_0[0].description == 'Deletes all files generated via setup commands.'
    assert list_0[0].commands == ('rm -rf dist/', 'rm -rf build/')
    assert list_0[1].name == 'clean'
    assert list_0[1].camel == 'Clean'
    assert list_0[1].description == 'Deletes all files generated via setup commands.'
    assert list_0[1].commands == ('rm -rf dist/', 'rm -rf build/')
    assert list_

# Generated at 2022-06-25 17:44:37.228735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    print("TESTING: each_sub_command_config")
    print("TEST #0: the 'setup.cfg' is missing a section.")
    test_case_0()
    print("TEST #1: the 'metadata' section is missing the 'name' "
          "option.")
    print("TEST #2: the 'metadata' section's 'name' option is missing "
          "a value.")
    print("TEST #2: the config file is missing an option.")

# Generated at 2022-06-25 17:44:40.228101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    if __name__ == '__main__':
        var_0 = os.path.join(os.path.dirname(__file__), '..', '..', '..')
        test_case_0()
        test_case_1()



# Generated at 2022-06-25 17:44:46.544948
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test 1: When there is a directory that contains a 'setup.py' file
    test_case_0()

    # Test 2: When there is a directory that contains a 'setup.py' file
    # and the directory has optional config files
    test_case_0()

    # Test 3: When there is a directory that contains a 'setup.py' file
    # and the directory has optional config files
    # and the config files use options
    test_case_0()

# Generated at 2022-06-25 17:45:26.651634
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    setup_dir = tempfile.mkdtemp()
    os.chdir(setup_dir)
    with open(os.sep.join((setup_dir, 'setup.py')), 'w') as file:
        file.write('')

# Generated at 2022-06-25 17:45:36.361085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_setup_dir = os.path.expanduser("~/projects/flutils")
    test_case_0()
    test_setup_dir = os.path.expanduser("~/projects/flutils")
    test_case_0()
    test_setup_dir = os.path.expanduser("~/projects/flutils")
    test_case_0()

if __name__ == '__main__':
    test_case_0()
    test_setup_dir = os.path.expanduser("~/projects/flutils")
    test_case_0()
    test_setup_dir = os.path.expanduser("~/projects/flutils")
    test_case_0()

# Generated at 2022-06-25 17:45:41.250817
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

if __name__ == '__main__':
    from flutils.debugutils import (
        debugger,
        debug_call,
    )
    from sys import argv

    debug_call(
        argv[0],
        func_dict={
            'test_case_0': test_case_0,
        }
    )
    debugger.break_call(argv[0], argv[1:])

# Generated at 2022-06-25 17:45:44.141843
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config() is not None


if __name__ == '__main__':
    test_each_sub_command_config()
    for val in each_sub_command_config():
        print(val)

# Generated at 2022-06-25 17:45:46.789114
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.setuputils as module_0
    import flutils.cmdlinetools as module_1
    module_0.test_case_0()
    module_1.test_case_0()

# Generated at 2022-06-25 17:45:51.835372
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    list_0 = list(generator_0)
    assert len(list_0) == 1
    assert list_0[0].name == 'build'
    assert list_0[0].camel == 'Build'
    assert list_0[0].description == 'Build the project'
    assert list_0[0].commands == ('python setup.py build',)

# Generated at 2022-06-25 17:45:53.582818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert True is True


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:56.336978
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

if __name__ == '__main__':
    test_each_sub_command_config()

"""DisabledContent
"""

# Generated at 2022-06-25 17:45:57.296297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:46:05.044454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    assert isinstance(var_0, list)
    assert isinstance(var_0[0], SetupCfgCommandConfig)
    assert var_0[0].name == 'dist'
    assert var_0[0].camel == 'Dist'
    assert var_0[0].description == 'Builds and distributes the package.'
    assert isinstance(var_0[0].commands, tuple)
    assert var_0[0].commands[0] == 'python setup.py bdist_wheel'



# Generated at 2022-06-25 17:47:57.014348
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:00.369129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = 'setup_dir_0'
    results = each_sub_command_config(setup_dir)
    assert next(results) \
        == SetupCfgCommandConfig(
            'command',
            'Command',
            'The command.',
            ('{0}', )
        )

# Generated at 2022-06-25 17:48:01.117152
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:11.195511
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = list(generator_0)
    #
    # assert var_0 == [
    #     SetupCfgCommandConfig(
    #         name='install_pkgs_macos',
    #         camel='InstallPkgsMacos',
    #         description='Install required packages using Homebrew on macOS.',
    #         commands=(
    #             'echo Installing Homebrew packages...',
    #             '/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com'
    #             '/Homebrew/install/master/install)"',
    #             'brew install python3'
    #         )
    #     ),
    #     SetupCfgCommandConfig(
    #         name='lint',
    #         camel='L

# Generated at 2022-06-25 17:48:13.273607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    '''Unit test for each_sub_command_config.'''
    print('Test each_sub_command_config')

# vim:set ts=8 sw=4 sts=4 tw=78 et:

# Generated at 2022-06-25 17:48:18.448172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except Exception as error_0:
        print("test case 0 failed:", error_0)
        assert False

# Generated at 2022-06-25 17:48:22.360825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Stub: None
    # Assertion: each_sub_command_config : call -> <type 'generator'>

    # Setup
    setup_dir = None
    generator_0 = each_sub_command_config(setup_dir)

    # Testing
    assert_0 = isinstance(generator_0, list)

    # Teardown
    del generator_0
    del setup_dir



# Generated at 2022-06-25 17:48:23.131328
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:29.024544
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Initialize test variables.
    test_variables = TestVariables(
        each_sub_command_config=each_sub_command_config,
        func_name='each_sub_command_config',
        module_globals=globals(),
        num_tests=4,
        has_yields=True,
        setup_hook=test_case_0,
        use_generator=True
    )

    # Iterate over test setup variables.
    for test_kwargs in test_variables:
        test_kwargs.update({
            'test_func': test_func
        })
        yield test_kwargs


# Unit test runner
if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 17:48:29.787168
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert list(generator_0) is not None

# Generated at 2022-06-25 17:51:20.106440
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:51:23.419474
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.installutils import each_sub_command_config as func
    return func


if __name__ == '__main__':
    import pytest  # type: ignore
    pytest.main(args=['', __file__])

# Generated at 2022-06-25 17:51:25.435407
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """
    # each_sub_command_config()
    """
    print()
    test_case_0()



# Generated at 2022-06-25 17:51:26.337202
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_1 = test_case_0()

# Generated at 2022-06-25 17:51:31.066720
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sub_cmd_config in each_sub_command_config():
        pass


if __name__ == '__main__':
    from flutils.debug import (
        fn_name,
        caller_fqdn_obj
    )
    cfg = SetupCfgCommandConfig('foo.bar', 'Baz', 'A "baz"', ('echo baz',))
    print(fn_name())
    print(caller_fqdn_obj)