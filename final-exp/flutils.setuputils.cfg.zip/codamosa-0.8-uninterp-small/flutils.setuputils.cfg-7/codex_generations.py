

# Generated at 2022-06-25 17:41:46.957961
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Testing function each_sub_command_config"""
    result = test_case_0()
    assert result is None
    return



# Generated at 2022-06-25 17:41:50.457889
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the each_sub_command_config function."""
    generator_0 = each_sub_command_config()
    for idx, obj in enumerate(generator_0):  # type: ignore
        print(idx, obj)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:41:54.388197
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    for item in generator:
        print(item)
        assert isinstance(item, SetupCfgCommandConfig)


if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:41:55.710090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for _ in each_sub_command_config():
        continue



# Generated at 2022-06-25 17:41:57.516482
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config('tests/data/test0'):
        print(item)

# Generated at 2022-06-25 17:42:07.194579
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    result_0 = next(each_sub_command_config())
    assert result_0 == SetupCfgCommandConfig(
        name='clean',
        camel='Clean',
        description='Clean the project.',
        commands=('rm -rf `find tests examples -name __pycache__`',
                  'rm -rf .eggs/ .tox/ .cache/ .coverage .coverage.* .mypy_cache/ .pytest_cache/')
    )
    result_1 = next(each_sub_command_config())

# Generated at 2022-06-25 17:42:15.890283
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Tests that the ``each_sub_command_config`` function yields
    entries the ``SetupCfgCommandConfig`` namedtuple.
    """
    import pytest

    def _raise_none():
        """Raises a ``None`` error."""
        raise None

    class NoneType(type(None)):
        """A mock ``None`` class so we can catch errors raised by the
        ``each_sub_command_config`` function.
        """
        def __init__(self, *args, **kwargs):
            super().__init__()
            self._args = args
            self._kwargs = kwargs or {}

        def __str__(self):
            return self.__repr__()


# Generated at 2022-06-25 17:42:17.262671
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for item in each_sub_command_config():
        print(item)



# Generated at 2022-06-25 17:42:20.984128
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test for correct return type
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)


if __name__ == "__main__":
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:42:26.054764
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    assert next(generator_0) is None
    assert next(generator_0) is None
    assert next(generator_0) is None
    assert next(generator_0) is None
    assert next(generator_0) is None
    with pytest.raises(StopIteration):
        next(generator_0)
    generator_1 = each_sub_command_config()

_NAME = "flutils"
_VERSION = "0.0.1"


# Generated at 2022-06-25 17:42:39.876830
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:42:50.373589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import flutils.sub_command

    out = [
        x for x in flutils.sub_command.each_sub_command_config('../sub_command')
    ]
    assert isinstance(out, list)
    assert len(out) == 2

    var_0 = out[0]
    assert isinstance(var_0, flutils.sub_command.SetupCfgCommandConfig)
    assert var_0.name == 'subcommands.one_subcommand'
    assert var_0.camel == 'OneSubcommand'
    assert var_0.description == 'This is the first subcommand.'
    assert var_0.commands == ('subcommands.one_subcommand',)

    var_1 = out[1]
    assert isinstance(var_1, flutils.sub_command.SetupCfgCommandConfig)

# Generated at 2022-06-25 17:42:53.775351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    arg_0: Optional[Union[os.PathLike, str]] = None
    generator_0 = each_sub_command_config(arg_0)

# Generated at 2022-06-25 17:42:58.913748
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: Optional[Union[os.PathLike, str]] = None
    generator_0 = each_sub_command_config(setup_dir)


if __name__ == '__main__':
    try:
        test_each_sub_command_config()
    except Exception as exc:
        print(exc)

# Generated at 2022-06-25 17:43:03.020767
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Prepare environment
    setup_dir = '.'
    os.path.dirname(test_case_0.__code__.co_filename)

    each_sub_command_config(setup_dir) == (generator_0, generator_1)



# Generated at 2022-06-25 17:43:05.594259
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        generator_0 = each_sub_command_config()
        var_0 = next(generator_0)
        generator_1 = each_sub_command_config()
        var_1 = next(generator_1)
        assert var_1.name == var_0.name
        assert var_1.camel == var_0.camel
        assert var_1.description == var_0.description
        assert var_1.commands == var_0.commands
    except StopIteration:
        pass

# Generated at 2022-06-25 17:43:14.625849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Case 0
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)
    assert isinstance(each_sub_command_config(), Generator)
    var_0 = next(generator_0)
    _assert_SetupCfgCommandConfig(var_0, 'build', 'Build', 'Build source.')
    var_0 = next(generator_0)
    _assert_SetupCfgCommandConfig(
        var_0, 'build_docs', 'BuildDocs', 'Build documentation.'
    )
    var_0 = next(generator_0)
    _assert_SetupCfgCommandConfig(
        var_0, 'build_sphinx', 'BuildSphinx', 'Build Sphinx documentation.'
    )
    var_0 = next(generator_0)


# Generated at 2022-06-25 17:43:24.231105
# Unit test for function each_sub_command_config

# Generated at 2022-06-25 17:43:26.062733
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)


if __name__ == '__main__':
    test_each_sub_command_config()
    test_case_0()

# Generated at 2022-06-25 17:43:27.086857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:43:44.124630
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'ci'
    assert var_0.camel == 'CI'
    assert var_0.description == ''
    assert var_0.commands == ('tox',)

    generator_1 = each_sub_command_config()
    var_1 = next(generator_1)
    assert var_1.name == 'ci'
    assert var_1.camel == 'CI'
    assert var_1.description == ''
    assert var_1.commands == ('tox',)

    var_2 = next(generator_1)
    assert var_2.name == 'clean'
    assert var_2.camel == 'Clean'
    assert var_2.description

# Generated at 2022-06-25 17:43:50.943300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)
    f0 = SetupCfgCommandConfig(
        'test.test_cmd',
        'TestTestCmd',
        'Short description.',
        (
            './setup.py test --help',
            'echo Short description.',
            'echo {name}',
            'echo {setup_dir}',
            'echo {home}'
        )
    )
    expected_0 = iter((f0,))
    var_0 = each_sub_command_config()
    try:
        assert iter(var_0) is var_0
    except AssertionError:
        print(type(var_0))
        print(dir(var_0))
    var_1 = next(var_0)

# Generated at 2022-06-25 17:44:00.175710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_2 = each_sub_command_config()
    config_0 = next(generator_2)
    name_0 = config_0.name
    assert name_0 == 'default'
    camel_0 = config_0.camel
    assert camel_0 == 'Default'
    description_0 = config_0.description
    assert description_0 == "this is a default command"
    commands_0 = config_0.commands
    command_0 = commands_0[0]
    assert command_0 == '$ setup.py run'


# Generated at 2022-06-25 17:44:01.311239
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except StopIteration:
        pass

# Generated at 2022-06-25 17:44:07.812382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    generator_1 = each_sub_command_config()
    var_1 = next(generator_1)
    generator_2 = each_sub_command_config()
    var_2 = next(generator_2)
    generator_3 = each_sub_command_config()
    var_3 = next(generator_3)
    #print(var_0)
    #print(var_1)
    #print(var_2)
    #print(var_3)
    assert var_0.name == 'flutils'
    assert var_1.name == 'flutils'


# Generated at 2022-06-25 17:44:08.529358
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()


# Generated at 2022-06-25 17:44:11.388036
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)


if __name__ == '__main__':
    try:
        test_each_sub_command_config()
    finally:
        pass

# Generated at 2022-06-25 17:44:22.666115
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Mock setup commands file
    path = os.path.join(
        os.path.dirname(__file__),
        'testing',
        'setup_commands.cfg_test'
    )
    shutil.copyfile(path, 'setup_commands.cfg')

    # Test that the 'each_sub_command_config' function will return
    # the same value for both generator calls.
    var_0 = None
    for var_0 in each_sub_command_config():
        break
    var_1 = None
    for var_1 in each_sub_command_config():
        break

# Generated at 2022-06-25 17:44:23.478821
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:44:26.566525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # raises LookupError
    with pytest.raises(LookupError):
        each_sub_command_config('/tmp')

    from pprint import pprint
    generator = each_sub_command_config()
    for next_value in generator:
        pprint(next_value)



# Generated at 2022-06-25 17:44:41.132808
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_setup_dir = os.path.join(os.path.dirname(__file__), '..')
    generator_0 = each_sub_command_config(test_setup_dir)
    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    expected_0 = 'init'
    assert var_0.name == expected_0
    var_1 = next(generator_0)
    assert isinstance(var_1, SetupCfgCommandConfig)
    expected_1 = 'init_package'
    assert var_1.name == expected_1



# Generated at 2022-06-25 17:44:49.802222
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    tns = 'com.example.hello.world'
    with tempfile.TemporaryDirectory() as setup_dir:
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-25 17:45:00.105200
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Setup
    generator_0 = each_sub_command_config()

    # Exercise
    var_0 = next(generator_0)

    # Verify
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert var_0.name == 'list'
    assert var_0.camel == 'List'
    assert var_0.description == 'list help'
    assert var_0.commands == ('list_help',)

    # Exercise
    var_0 = next(generator_0)

    # Verify
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert var_0.name == 'menu'
    assert var_0.camel == 'Menu'
    assert var_0.description == 'menu help'
    assert len(var_0.commands) == 1
   

# Generated at 2022-06-25 17:45:05.511799
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    cwd = os.path.dirname(os.path.realpath(__file__))
    setup_dir = os.path.join(cwd, '..')
    commands = each_sub_command_config(setup_dir)
    print('>>>>>>>>>>>>>>')
    for command in commands:
        print(command)
    print('<<<<<<<<<<<<<<')

if __name__ == '__main__':
    test_case_0()
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:11.285667
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    the_tests_dir = os.path.dirname(__file__)
    command_dir = os.path.join(the_tests_dir, 'test_command_dir')
    generator = each_sub_command_config(setup_dir=command_dir)
    # print(list(generator))
    assert next(generator).name == 'cmd_name_0'
    assert next(generator).name == 'cmd_name_1'
    assert next(generator).name == 'cmd_name_2'

# Generated at 2022-06-25 17:45:17.557118
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_1 = each_sub_command_config()
    var_1 = next(generator_1)
    assert var_1.name == 'build_docs'
    assert var_1.description == ''
    assert var_1.commands == (
        'sphinx-build -b html -d .build/doctrees -D master_doc=index .build/docs .build/html',)
    generator_1.close()
    assert hasattr(generator_1, '__iter__')


if __name__ == "__main__":
    test_each_sub_command_config()
    print("Done")

# Generated at 2022-06-25 17:45:18.329507
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass

# Generated at 2022-06-25 17:45:20.792681
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Test case 0
    #call func = each_sub_command_config()
    #return = var_0
    test_case_0()



# Generated at 2022-06-25 17:45:27.398458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # First run the test case with a None value for setup_dir
    try:
        test_case_0()
    except FileNotFoundError as e:
        assert str(e).startswith("Unable to find the directory that contains")
    # Try one more time, but this time give it a valid setup_dir
    try:
        var_0 = each_sub_command_config('setup_dir')
        assert var_0
    except FileNotFoundError as e:
        assert str(e).startswith("The given 'setup_dir' of")

# Generated at 2022-06-25 17:45:31.786190
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        setup_dir = None
        generator_0 = each_sub_command_config(setup_dir)
        var_0 = next(generator_0)
    except Exception:
        test_failed_0 = True
    else:
        test_failed_0 = False
    if test_failed_0:
        print('test_each_sub_command_config failed: ')


UnitTestList = [
    test_case_0,
]



# Generated at 2022-06-25 17:45:45.339060
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for sc in each_sub_command_config():
        print(sc)



# Generated at 2022-06-25 17:45:46.907275
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    pass


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:52.914159
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        print(config.name, config.description, config.commands)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.name, str)
        assert isinstance(config.commands, tuple)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:45:55.947346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test the function ``each_sub_command_config``."""
    generator_0 = each_sub_command_config()
    assert isinstance(generator_0, Generator)



# Generated at 2022-06-25 17:46:05.699478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Try method with just positional args
    assert next(each_sub_command_config()) == SetupCfgCommandConfig(
        name='a',
        camel='A',
        commands=tuple(),
        description=''
    )

    # Try method with positional and keyword args
    generator_0 = each_sub_command_config(
        setup_dir='/home/peterbe/dev/python/flutils/tests/data/test_project_0'
    )
    assert next(generator_0) == SetupCfgCommandConfig(
        name='test_project_0.no_here_file.a',
        camel='NoHereFileA',
        commands=tuple(),
        description=''
    )

# Generated at 2022-06-25 17:46:07.442255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert_equal(test_case_0(), 'INSERT_RETURN_VALUE_HERE')

# Generated at 2022-06-25 17:46:15.147300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert var_0.name == 'test'
    assert var_0.camel == 'Test'
    assert var_0.description == 'The test command.'
    assert var_0.commands == ('echo "Hello World!"',)
    var_1 = next(generator_0)
    assert var_1.name == 'test.again'
    assert var_1.camel == 'TestAgain'
    assert var_1.description == 'The test.again command.'
    assert var_1.commands == ('echo "Hello Again!"',)
    var_2 = next(generator_0)
    assert var_2.name == 'test.setup.command'

# Generated at 2022-06-25 17:46:24.554337
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from inspect import getfile
    from os.path import abspath
    from os.path import dirname
    from os.path import join

    from flutils.pathutils import cd

    from test.common import setup_cfg_command_section

    with setup_cfg_command_section() as (setup_cfg_path, section):
        dirname = dirname(abspath(getfile(lambda: None)))
        with cd(dirname):
            generator = each_sub_command_config('.')
            command_config = next(generator)
            assert isinstance(command_config, SetupCfgCommandConfig)
            assert (
                command_config.name ==
                'command_one'
            )
            assert (
                command_config.camel ==
                'CommandOne'
            )

# Generated at 2022-06-25 17:46:34.599148
# Unit test for function each_sub_command_config
def test_each_sub_command_config():

    # Test with setup directory path
    generator_0 = each_sub_command_config('/flutils')
    var_0 = next(generator_0)

    # Test with setup directory path - ERROR
    try:
        generator_1 = each_sub_command_config('/flutils/unknown_folder')
        var_1 = next(generator_1)
    except Exception as error:
        var_1 = error
    assert isinstance(var_1, FileNotFoundError)

    # Test with setup directory path - ERROR
    try:
        generator_2 = each_sub_command_config('/flutils/flutils/setup.py')
        var_2 = next(generator_2)
    except Exception as error:
        var_2 = error
    assert isinstance(var_2, FileNotFoundError)

   

# Generated at 2022-06-25 17:46:43.353381
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from pathlib import Path
    from flutils.configutils import each_sub_command_config

    assert path.basename(__file__) != 'test_each_sub_command_config.py'

    this_file = Path(__file__)
    this_file_py = this_file.with_suffix('.py')
    if this_file.exists() is False and this_file_py.exists() is False:
        return

    this_file = Path(__file__).resolve() if this_file.exists() else \
        this_file_py.resolve()
    setup_dir = this_file.parent

    generator_0 = each_sub_command_config(setup_dir=setup_dir)
    var_0 = next(generator_0)

# Generated at 2022-06-25 17:47:04.538901
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    from pathlib import Path
    from string import ascii_letters, digits
    from flutils.files.templates import (
        _each_template,
        _get_templates_path,
        load,
    )
    from flutils.iterutils import (
        check,
        drop_while,
    )
    import pytest

    @pytest.fixture(scope="function")
    def setup_cfg_template() -> Dict[str, str]:
        template_source = list(
            drop_while(lambda x: 'setup.cfg.template' not in x,
                       _each_template(_get_templates_path()))
        )[0]
        return load(template_source)


# Generated at 2022-06-25 17:47:14.009303
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_cfg_path = os.path.join(os.path.expanduser('~/proj/flutils'), 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    var_0 = _get_name(parser, setup_cfg_path)
    assert var_0 == 'flutils'
    generator_0 = _each_setup_cfg_command(parser, {'name': var_0})
    var_1 = list(generator_0)

# Generated at 2022-06-25 17:47:14.466855
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert False is True

# Generated at 2022-06-25 17:47:15.402424
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:47:19.183011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Uncomment the following two lines to see what the function
    # actually produces.
    # generator_0 = each_sub_command_config()
    # while True:
    #     var_0 = next(generator_0)
    #     print(var_0)
    return None


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:30.487850
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.tools import each_sub_command_config
    from typing import Generator

    name_0, camel_0, description_0, commands_0 = (
        'cover', 'Cover', '', ('coverage run --source=flutils setup.py test',)
    )

    def func_0() -> Generator[SetupCfgCommandConfig, None, None]:
        config_0 = SetupCfgCommandConfig(name_0, camel_0, description_0, commands_0)
        yield config_0

    generator_0 = each_sub_command_config()
    iter_0 = iter(func_0())
    config_0 = next(generator_0)
    config_1 = next(iter_0)
    assert config_0 == config_1



# Generated at 2022-06-25 17:47:37.130895
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    from flutils.miscutils import capture_stderr


# Generated at 2022-06-25 17:47:39.466734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

if '__main__' == __name__:
    test_each_sub_command_config()

# Generated at 2022-06-25 17:47:40.888178
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()



# Generated at 2022-06-25 17:47:49.571147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for command_config in each_sub_command_config('.'):
        print(command_config.name)
        print(command_config.camel)
        print(command_config.description)
        for command in command_config.commands:
            print('   ', command)


if __name__ == '__main__':
    import sys
    from flutils.debugutils import (
        find_caller,
        debug_trace,
        debug_trace_fmt,
        set_debug_trace,
    )
    set_debug_trace(True)
    debug_trace()
    test_case_0()
    debug_trace()
    print(find_caller())
    print(debug_trace_fmt())

    import unittest
    unittest.main()

# Generated at 2022-06-25 17:48:28.515674
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    # Create a setup directory for testing
    prev_cwd = os.getcwd()
    with tempfile.TemporaryDirectory(prefix='setup_cfg_cmd') as dpath:
        os.chdir(dpath)
        path = os.path.realpath(dpath)
        tpath = os.path.join(path, 'setup.cfg')

# Generated at 2022-06-25 17:48:30.220582
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:37.872134
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.realpath(os.path.dirname(__file__))
    setup_dir = os.path.join(setup_dir, 'mock_project_0')
    generator_0 = each_sub_command_config(setup_dir)

# Generated at 2022-06-25 17:48:40.717683
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    generator = each_sub_command_config()
    generator = cast(Generator, generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)
    assert next(generator)

# Generated at 2022-06-25 17:48:47.833062
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import pathlib

    conf_path = pathlib.Path(tempfile.mkdtemp())
    conf_path /= 'setup.cfg'
    conf_path.write_text(
        '''
[metadata]
name = foo

[setup.command.coverage]
commands =
   {setup_dir}/bin/coverage_run.sh

[setup.command.unit_tests]
commands =
   {setup_dir}/bin/unit_tests.sh
        '''
    )
    setup_dir = conf_path.parent.resolve()

    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)


# Generated at 2022-06-25 17:48:49.907020
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:48:50.723090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:48:56.253492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.join(
        os.path.dirname(__file__),
        os.path.pardir,
        'test-data',
        'setup-cfg',
    )
    dirs: List[str] = []
    cmds: List[str] = []
    for sub_cmd_cfg in each_sub_command_config(setup_dir):
        dirs.append(sub_cmd_cfg.name)
        cmds.append(sub_cmd_cfg.commands[0])
    assert dirs == ['pylint_setup', 'pylint_setup']
    assert cmds == ['pylint --version', 'pylint --rcfile=pylintrc setup']



# Generated at 2022-06-25 17:48:57.213986
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    var_0 = each_sub_command_config()


# Generated at 2022-06-25 17:48:57.797339
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:16.101806
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir: Optional[Union[os.PathLike, str]] = None
    if __name__ == '__main__':
        setup_dir = '.'
    generator_0 = each_sub_command_config(setup_dir)
    var_0 = next(generator_0)
    print(var_0)
    return True



# Generated at 2022-06-25 17:50:23.887351
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = None

    generator_0 = each_sub_command_config(setup_dir)

    var_0 = next(generator_0)
    assert isinstance(var_0, SetupCfgCommandConfig)
    assert isinstance(var_0.name, str)
    assert isinstance(var_0.camel, str)
    assert isinstance(var_0.description, str)
    assert isinstance(var_0.commands, tuple)
    for var_1 in var_0.commands:
        assert isinstance(var_1, str)



# Generated at 2022-06-25 17:50:25.575150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert callable(each_sub_command_config)



# Generated at 2022-06-25 17:50:33.381333
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function: each_sub_command_config()"""
    from flutils.configutils import get_realpath
    from flutils.configutils import each_sub_command_config

    path = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(path, 'flutils')

    generator_0 = each_sub_command_config()
    var_0 = next(generator_0)
    assert(var_0.name == 'flutils')
    assert(var_0.commands[0] == '{setup_dir}/.pypirc')
    assert(var_0.commands[1] == 'COPYRIGHT.txt')
    assert(var_0.commands[2] == 'LICENSE.txt')

# Generated at 2022-06-25 17:50:33.900924
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    assert each_sub_command_config

# Generated at 2022-06-25 17:50:34.600318
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    test_case_0()

# Generated at 2022-06-25 17:50:38.794710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
        print('Test Case #0: Pass')
    except Exception as e:
        print('Test Case #0: Fail')
        print('  Calls:')
        print('    %s' % '\n    '.join(map(str, e.__traceback__)))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:46.221286
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path as os_path
    # @type test_case_0: ((), {})
    test_case_0 = ((), {})
    test_case_0_0 = test_case_0[0]  # @type: ()
    test_case_0_1 = test_case_0[1]  # @type: {}
    # @type test_file_0: str
    test_file_0 = os_path.abspath(__file__)
    # @type test_dir_0: str
    test_dir_0 = os_path.dirname(test_file_0)
    # @type test_dir_1: str
    test_dir_1 = os_path.dirname(test_dir_0)
    # @type test_dir_2: str
    test_dir

# Generated at 2022-06-25 17:50:48.082126
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    try:
        test_case_0()
    except StopIteration:
        pass

if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-25 17:50:49.056995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    return test_case_0()