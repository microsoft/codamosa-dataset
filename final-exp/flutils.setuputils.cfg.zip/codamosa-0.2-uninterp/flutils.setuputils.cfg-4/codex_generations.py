

# Generated at 2022-06-17 19:28:42.086336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    setup_dir=get_project_root_dir()
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:28:49.929181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string
    from flutils.sysutils import get_python_executable
    from flutils.sysutils import get_python_version
    from flutils.sysutils import get_python_version_tuple
    from flutils.sysutils import get_python_version_tuple_str
    from flutils.sysutils import get_python_version_str
    from flutils.sysutils import get_python_version_info
    from flutils.sysutils import get_python_version_info_str
    from flutils.sysutils import get_python_version_info_tuple
    from flutils.sysutils import get_python_version_info_tuple_str

# Generated at 2022-06-17 19:28:58.368160
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.testutils import TempDir

    with TempDir() as td:
        td.write('setup.py', '#!/usr/bin/env python3')
        td.write('setup.cfg', '''
[metadata]
name = flutils
''')
        td.write('setup_commands.cfg', '''
[setup.command.test]
name = test
description = Run the unit tests.
command = python3 -m unittest discover -s {setup_dir}/tests
''')
        td.write('tests/__init__.py', '')

# Generated at 2022-06-17 19:29:07.578812
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    from flutils.setuputils import each_sub_command_config
    from flutils.setuputils import SetupCfgCommandConfig


# Generated at 2022-06-17 19:29:19.239089
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.testutils import (
        assert_raises_file_not_found_error,
        assert_raises_not_a_directory_error,
    )
    from flutils.testutils.testutils import (
        assert_raises_lookup_error,
    )
    from flutils.testutils.testutils import (
        assert_raises_file_not_found_error,
    )
    from flutils.testutils.testutils import (
        assert_raises_file_not_found_error,
    )
   

# Generated at 2022-06-17 19:29:28.656755
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestCase.run_tests()



# Generated at 2022-06-17 19:29:39.000481
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:49.603622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_greater,
        assert_greater_equal,
        assert_less,
        assert_less_equal,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )

# Generated at 2022-06-17 19:30:00.363766
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:30:09.493662
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(sys.path[0]):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    unittest.main()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:30:30.008687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.testutils import (
        assert_equal,
        assert_in,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_raises,
        assert_true,
    )
    from flutils.testutils.pytestutils import (
        assert_raises_regex,
        assert_raises_regexp,
    )
    from flutils.testutils.pytestutils import assert_raises_regexp

    # Test with no setup_dir
    setup_dir = None
    gen = each_sub_command_config(setup_dir)
    assert_is_instance(gen, Generator)

# Generated at 2022-06-17 19:30:38.653510
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import inspect
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTest

    class TestEachSubCommandConfig(UnitTest):
        """Unit test for function each_sub_command_config."""

        def test_each_sub_command_config(self):
            """Test function each_sub_command_config."""
            setup_dir = get_parent_dir(
                inspect.getfile(sys.modules[__name__])
            )
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:30:49.198390
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for parent_dir in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(parent_dir, 'setup.py')):
                    break
            else:
                raise FileNotFoundError(
                    "Unable to find the directory that contains the "
                    "'setup.py' file."
                )

            for config in each_sub_command_config(parent_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)


# Generated at 2022-06-17 19:31:01.280309
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_path,
        each_dir_path,
    )

    # Test with a setup.cfg file that has no 'setup.command' sections
    setup_cfg_path = get_test_data_file('setup_cfg_no_commands.cfg')
    setup_cfg_dir = os.path.dirname(setup_cfg_path)
    assert setup_cfg_dir == get_test_data_path()
    assert os.path.isfile(setup_cfg_path)
    assert os.path.isdir(setup_cfg_dir)

# Generated at 2022-06-17 19:31:13.184712
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_of_file,
    )
    from flutils.strutils import (
        is_empty,
        is_not_empty,
    )

    # Test with no setup_dir
    setup_dir = None
    for config in each_sub_command_config(setup_dir):
        assert_is_instance(config, SetupCfgCommandConfig)
        assert_is_not

# Generated at 2022-06-17 19:31:25.197634
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    setup_dir = tempfile.mkdtemp()
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
    setup_py_path = os.path.join(setup_dir, 'setup.py')

    with open(setup_cfg_path, 'w') as f:
        f.write(
            '''
[metadata]
name = flutils

[options]
packages = find:
            '''
        )


# Generated at 2022-06-17 19:31:35.824217
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    from flutils.setuputils import each_sub_command_config

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_contents)


# Generated at 2022-06-17 19:31:44.660898
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.testcase import (
        TestCase,
        TestCaseWithTempDir,
    )
    from flutils.testutils.testcase import (
        TestCase,
        TestCaseWithTempDir,
    )

    class TestEachSubCommandConfig(TestCaseWithTempDir):
        def test_each_sub_command_config(self):
            test_data_dir = get_test_data_dir(__file__)

# Generated at 2022-06-17 19:31:58.112242
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            self.assertTrue(os.path.isfile(path))
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }
            out = list(_each_setup_cfg_command(parser, format_kwargs))
            self.assertEqual(len(out), 2)

# Generated at 2022-06-17 19:32:08.052385
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = os.path.realpath(tmpdir)
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                """[metadata]
name = flutils

[setup.command.foo]
command = echo "foo"

[setup.command.bar]
command = echo "bar"

[setup.command.baz]
command = echo "baz"
"""
            )
        setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:32:43.573076
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.testcase import (
        BaseTestCase,
        TestCase,
    )
    from flutils.testutils.testcase import (
        BaseTestCase,
        TestCase,
    )

    class TestEachSubCommandConfig(BaseTestCase):
        def test_each_sub_command_config(self):
            test_data_dir = get_test_data_dir(__file__)
            test_data_dir = get_parent_dir(test_data_dir)
            test_data_dir = get_parent_dir(test_data_dir)
            test_data_dir = get_parent

# Generated at 2022-06-17 19:32:56.245804
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:04.229621
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                with patch.object(sys, 'exit') as mock_exit:
                    with self.assertRaises(SystemExit):
                        list(each_sub_command_config())
                    mock_exit.assert_called_once_with(1)

    unittest.main()

# Generated at 2022-06-17 19:33:11.477802
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_this_file()
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.join(path, 'setup.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~')
            }

# Generated at 2022-06-17 19:33:23.371684
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    import tempfile
    import shutil

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py_path, 'w') as f:
                f.write('# setup.py\n')

# Generated at 2022-06-17 19:33:30.142734
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import each_parent_dir

    def _write_setup_cfg(
            path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:33:39.877818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_true,
        assert_false,
        assert_raises,
    )
    from flutils.pathutils import (
        get_package_dir,
        get_package_name,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils.test_pathutils import (
        assert_get_package_dir,
        assert_get_package_name,
    )

    assert_get_package_dir(get_package_dir)
    assert_get_package_name(get_package_name)

    setup_dir = get_test_data_dir('setuputils')

# Generated at 2022-06-17 19:33:50.515795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from io import StringIO

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = os.path.dirname(__file__)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.parser = ConfigParser()
            self.parser.read(self.setup_cfg_path)

# Generated at 2022-06-17 19:33:59.215731
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__file__)
            path = os.path.join(path, '..', '..', '..', '..', 'tests')
            path = os.path.realpath(path)
            path = os.path.join(path, 'test_setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)

# Generated at 2022-06-17 19:34:10.898717
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.pathutils import (
        get_module_path,
        get_module_dir,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        get_text_from_stdout,
        get_text_from_stderr,
    )

    setup_dir = get_module_dir(__file__)
    setup_dir = os.path.join(setup_dir, 'test_setup_dir')

    with capture_stdout() as stdout, capture_stderr() as stderr:
        for config in each_sub_command_config(setup_dir):
            print(config)

# Generated at 2022-06-17 19:34:38.431044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.setup_dir = self.tempdir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:34:48.750850
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:35:00.040629
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_contents = (
                '#!/usr/bin/env python\n'
                'from setuptools import setup\n'
                'setup()\n'
            )

# Generated at 2022-06-17 19:35:11.604800
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_blank,
        is_not_blank,
    )

    def _assert_config(
            config: SetupCfgCommandConfig,
            name: str,
            camel: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        assert_is_not_none

# Generated at 2022-06-17 19:35:21.802080
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import each_parent_dir

    def _create_setup_cfg(
            dir_path: str,
            name: str = 'test_project',
            commands: List[str] = None
    ) -> None:
        commands = commands or []
        commands = '\n'.join(commands)
        with open(os.path.join(dir_path, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'commands = %s\n'
                % (name, commands)
            )


# Generated at 2022-06-17 19:35:34.402688
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_true,
        assert_false,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_module_dir,
    )
    from flutils.sysutils import (
        get_python_version,
    )

    setup_dir = get_parent_dir(get_module_dir(__file__))
    assert_equal(setup_dir, os.path.dirname(__file__))


# Generated at 2022-06-17 19:35:46.864049
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_this_file()
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data')
            path = os.path.join(path, 'setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }

# Generated at 2022-06-17 19:35:55.536120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

    Test().run()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:36:04.241222
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('# -*- coding: utf-8 -*-\n')
                f

# Generated at 2022-06-17 19:36:15.342839
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import random_string

    class TestEachSubCommandConfig(TestCase):

        def test_each_sub_command_config(self):
            with self.temp_dir() as temp_dir:
                setup_dir = temp_dir
                setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
                setup_commands_cfg_path = os.path.join(
                    setup_dir, 'setup_commands.cfg'
                )
                setup_py_path = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-17 19:36:56.553224
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import each_parent_dir

    for path in each_parent_dir(os.path.abspath(__file__)):
        if os.path.isfile(os.path.join(path, 'setup.py')):
            break
    else:
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )

    for config in each_sub_command_config(path):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:37:01.801347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)

# Generated at 2022-06-17 19:37:09.502502
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):

        def test_each_sub_command_config(self):
            from flutils.pathutils import each_parent_dir

            for dir_path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(dir_path, 'setup.cfg')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.cfg' file.")

            for config in each_sub_command_config(dir_path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:37:15.753395
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')

# Generated at 2022-06-17 19:37:27.780852
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _test_each_sub_command_config(
            setup_cfg_content: str,
            setup_commands_cfg_content: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_content)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:37:39.531146
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    get_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:37:44.725207
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:37:54.667780
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:38:07.147438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_raises,
    )

    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        '/tmp/flutils_test_each_sub_command_config'
    )

    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        '/tmp/flutils_test_each_sub_command_config/setup.py'
    )


# Generated at 2022-06-17 19:38:13.972041
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 3)
            for sub_command in each_sub_command_config(setup_dir):
                self.assertIsInstance(sub_command, SetupCfgCommandConfig)
                self.assertIsInstance(sub_command.name, str)
                self.assertIsInstance(sub_command.camel, str)
                self.assertIsInstance(sub_command.description, str)
                self.assertIsInstance(sub_command.commands, tuple)