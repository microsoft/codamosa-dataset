

# Generated at 2022-06-17 19:28:49.050785
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_true,
    )


# Generated at 2022-06-17 19:28:58.798289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('')


# Generated at 2022-06-17 19:29:09.847434
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_module_path,
        get_module_name,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.textutils import (
        normalize_newlines,
    )
    from flutils.configutils import (
        each_sub_command_config,
    )
    from flutils.scriptutils import (
        get_script_name,
    )

    # Test the function without a setup_dir

# Generated at 2022-06-17 19:29:20.985639
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import each_parent_dir

    from . import each_sub_command_config

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('name = %s\n' % name)
            f.write('description = %s\n' % description)

# Generated at 2022-06-17 19:29:31.868669
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:29:42.238394
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_greater,
        assert_greater_equal,
        assert_less,
        assert_less_equal,
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_not_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_sub_dirs,
    )

# Generated at 2022-06-17 19:29:53.198888
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py, 'w') as f:
                f.write('')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            with open(self.setup_cfg, 'w') as f:
                f.write('''
[metadata]
name = flutils
''')

# Generated at 2022-06-17 19:30:02.732816
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:30:11.416536
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import temp_dir
    from flutils.testutils import temp_file
    from flutils.testutils import temp_file_name
    from flutils.testutils import temp_file_path

    with temp_dir() as td:
        setup_py_path = os.path.join(td, 'setup.py')
        with open(setup_py_path, 'w') as fp:
            fp.write('')
        setup_cfg_path = os.path.join(td, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write('''\
[metadata]
name = flutils
''')
        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')
       

# Generated at 2022-06-17 19:30:19.795818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file_path,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        get_indent,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file_path,
    )

# Generated at 2022-06-17 19:30:42.163254
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path

# Generated at 2022-06-17 19:30:49.357246
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from io import StringIO
    from unittest import TestCase, main

    class EachSubCommandConfigTestCase(TestCase):
        def test_each_sub_command_config(self):
            out = StringIO()
            sys.stdout = out
            for config in each_sub_command_config():
                print(config)
            sys.stdout = sys.__stdout__
            self.assertTrue(out.getvalue())

    main()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:31:01.354794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:31:13.219260
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:31:25.249576
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import sys
    import os

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _write_setup_cfg(setup_dir: str) -> None:
        with open(_get_setup_cfg_path(setup_dir), 'w') as f:
            f.write("""\
[metadata]
name = flutils
""")


# Generated at 2022-06-17 19:31:35.911257
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__)
            out = list(each_sub_command_config(setup_dir))
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'test')
            self.assertEqual(out[0].camel, 'Test')
            self.assertEqual(out[0].description, 'Runs the unit tests.')
            self.assertEqual(out[0].commands, ('pytest',))

    TestEachSub

# Generated at 2022-06-17 19:31:44.695011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_paths,
    )
    from flutils.testutils.test_case import (
        TestCase,
        TestCaseWithTempDir,
    )

    class TestEachSubCommandConfig(TestCaseWithTempDir):
        def test_each_sub_command_config(self):
            test_dir = get_test_data_path('test_each_sub_command_config')
            self.assertTrue(os.path.isdir(test_dir))

# Generated at 2022-06-17 19:31:58.112600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:08.053253
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:32:18.435142
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data', 'setup_commands')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:52.148343
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:33:00.153010
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    from flutils.setuputils import each_sub_command_config

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('# -*- coding: utf-8 -*-\n')
                f.write('\n')
                f.write('from setuptools import setup\n')
                f.write('\n')
                f

# Generated at 2022-06-17 19:33:07.210515
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    setup_dir=get_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    test_each_sub_command_config = TestEachSubCommandConfig()

# Generated at 2022-06-17 19:33:09.235260
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# Generated at 2022-06-17 19:33:15.774058
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:33:25.007964
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file

    with TempDir() as temp_dir:
        setup_cfg = os.path.join(temp_dir, 'setup.cfg')
        setup_commands_cfg = os.path.join(temp_dir, 'setup_commands.cfg')
        with open(setup_cfg, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )
        with open(setup_commands_cfg, 'w') as f:
            f.write(
                '[setup.command.test]\n'
                'name = test\n'
                'description = Test the project.\n'
                'command = pytest\n'
            )

# Generated at 2022-06-17 19:33:34.126857
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                print(config)

    sys.exit(TestEachSubCommandConfig().run())


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:41.500572
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        temp_dir,
        temp_file,
    )

    with temp_dir() as td:
        with temp_file(td, 'setup.py') as sf:
            with temp_file(td, 'setup.cfg') as cf:
                with open(cf, 'w') as f:
                    f.write(
                        '''
                        [metadata]
                        name = flutils
                        '''
                    )
                with temp_file(td, 'setup_commands.cfg') as scf:
                    with open(scf, 'w') as f:
                        f.write(
                            '''
                            [setup.command.test]
                            command =
                                echo "test"
                            '''
                        )

# Generated at 2022-06-17 19:33:51.473163
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

# Generated at 2022-06-17 19:34:01.125984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:34:56.744776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _test_each_sub_command_config(
            setup_cfg_content: str,
            setup_commands_cfg_content: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_content)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')
            with open(setup_commands_cfg_path, 'w') as f:
                f.write(setup_commands_cfg_content)
           

# Generated at 2022-06-17 19:35:04.224443
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):

        def test_each_sub_command_config(self):
            for setup_dir in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(setup_dir, 'setup.py')):
                    break
            else:
                self.fail(
                    "Unable to find the directory that contains the "
                    "'setup.py' file."
                )
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self

# Generated at 2022-06-17 19:35:15.810525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_in,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_not_in,
        assert_not_equal,
        assert_raises,
        assert_true,
        assert_false,
    )


# Generated at 2022-06-17 19:35:23.589375
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _write_setup_cfg(
            tmp_dir: str,
            name: str,
            setup_command_cfg: Optional[str] = None
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """
                [metadata]
                name = %s
                """ % name
            ))
        if setup_command_cfg:
            with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
                f.write(setup_command_cfg)


# Generated at 2022-06-17 19:35:35.373610
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_module_path,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.textutils import (
        get_indent,
    )
    from flutils.logutils import (
        set_log_level,
    )
    from flutils.configutils import (
        get_config_value,
    )
    from flutils.configutils import (
        get_config_value,
    )
    from flutils.configutils import (
        get_config_value,
    )
    from flutils.configutils import (
        get_config_value,
    )

# Generated at 2022-06-17 19:35:45.882487
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.pathutils import get_parent_dir

            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for cmd in config.commands:
                    self.assertIsInstance(cmd, str)

    Test().run()

# Generated at 2022-06-17 19:35:58.708599
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str = 'test_project',
            description: str = 'A test project.',
            commands: List[str] = None
    ) -> None:
        commands = commands or []
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('description = %s\n' % description)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('name = test\n')
            f.write('description = Runs the unit tests.\n')

# Generated at 2022-06-17 19:36:06.437927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_project_root,
        get_project_root_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.pathutils import (
        get_test_data_dir_path,
        get_test_data_file_path,
    )

    # Test the function with a valid setup.cfg file
    setup_dir = get_test_data_dir_path('setup_cfg')
    setup_cfg_path = get_test_data_file_path('setup_cfg', 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)

# Generated at 2022-06-17 19:36:16.466258
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:36:25.593729
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        setup_dir = os.path.join(tmp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py = os.path.join(setup_dir, 'setup.py')
        with open(setup_py, 'w') as f:
            f.write('')
        setup_cfg = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg, 'w') as f:
            f.write('''\
[metadata]
name = test_package
''')
        setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:37:59.252620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from flutils.pathutils import each_file_path

    from . import each_sub_command_config

    # Setup
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        setup_py = tmpdir / 'setup.py'
        setup_cfg = tmpdir / 'setup.cfg'
        setup_commands_cfg = tmpdir / 'setup_commands.cfg'

# Generated at 2022-06-17 19:38:10.351354
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:38:22.897887
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_contents)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')