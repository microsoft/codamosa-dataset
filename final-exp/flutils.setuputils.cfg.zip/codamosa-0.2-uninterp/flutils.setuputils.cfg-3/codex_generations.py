

# Generated at 2022-06-17 19:28:46.425755
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as tmpdir:
        tmpdir.write('setup.py', '#!/usr/bin/env python3')

# Generated at 2022-06-17 19:28:55.675485
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    from flutils.configutils import each_sub_command_config

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected_output: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_contents)

# Generated at 2022-06-17 19:29:06.032725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string
    from flutils.sysutils import get_python_executable

    with TempDir() as td:
        setup_py_path = os.path.join(td, 'setup.py')
        setup_cfg_path = os.path.join(td, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')
        with open(setup_py_path, 'w') as f:
            f.write('#!/usr/bin/env python\n')
            f.write('# -*- coding: utf-8 -*-\n')
            f.write('\n')
            f.write

# Generated at 2022-06-17 19:29:16.681988
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_script_dir,
    )
    from flutils.textutils import (
        indent,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_script_dir,
    )
    from flutils.textutils import (
        indent,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )

# Generated at 2022-06-17 19:29:23.856117
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__, 'setup.py'):
                for config in each_sub_command_config(path):
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:29:32.692777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

    TestEachSubCommandConfig().run()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:29:42.353173
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from io import StringIO
    from unittest.mock import patch

    class TestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help-commands']):
                with patch('sys.stdout', new_callable=StringIO) as mock_stdout:
                    from flutils.setuputils import main
                    main()
                    out = mock_stdout.getvalue()
                    self.assertIn('test', out)
                    self.assertIn('test_all', out)
                    self.assertIn('test_all_with_coverage', out)
                    self.assertIn('test_all_with_coverage_and_report', out)

# Generated at 2022-06-17 19:29:53.291211
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module('flutils.setuputils')
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.join(path, 'tests', 'data', 'setup_commands')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
               

# Generated at 2022-06-17 19:30:02.763959
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
                f.write(setup_cfg_contents)
            with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
                f.write(setup_commands_cfg_contents)
            actual = list(each_sub_command_config(tmpdir))
            assert actual == expected


# Generated at 2022-06-17 19:30:11.446531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config
            from flutils.testutils import get_test_data_path

            path = get_test_data_path('setup_commands.cfg')
            with open(path, 'r') as f:
                expected = f.read()
            expected = expected.strip()
            expected = expected.splitlines()
            expected = list(filter(len, expected))
            expected = list(map(lambda x: x.strip(), expected))
            expected = list(filter(len, expected))
            expected = tuple(expected)

            path = get_test_data_path('setup_commands')
            actual = tuple

# Generated at 2022-06-17 19:30:30.080265
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('')

# Generated at 2022-06-17 19:30:38.690050
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python\n')
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )

# Generated at 2022-06-17 19:30:43.166681
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_dir
    test_dir = get_test_dir(__file__)
    for config in each_sub_command_config(test_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:30:57.813741
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )

    # Test setup_dir is None
    setup_dir = None
    out = each_sub_command_config(setup_dir)
    assert_is_instance(out, Generator)
    out = list(out)
    assert_is_instance(out, list)
    assert_equal(len(out), 1)
    assert_is_instance(out[0], SetupCfgCommandConfig)

# Generated at 2022-06-17 19:31:09.156614
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test_each_sub_command_config()

# Generated at 2022-06-17 19:31:18.409328
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )
    from flutils.sysutils import (
        get_current_script_dir,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.textutils import (
        get_indent,
    )

# Generated at 2022-06-17 19:31:29.646966
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.textutils import (
        get_random_string,
    )
    from flutils.testutils import (
        get_test_file_path,
    )
    from flutils.testutils import (
        get_test_dir_path,
    )
    from flutils.testutils import (
        get_test_file_path,
    )
    from flutils.testutils import (
        get_test_dir_path,
    )

# Generated at 2022-06-17 19:31:39.197574
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os
    import io
    import subprocess
    import contextlib

    @contextlib.contextmanager
    def _temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    @contextlib.contextmanager
    def _temp_file(
            content: str,
            suffix: str = '',
            prefix: str = '',
            dir: str = None
    ) -> Generator[str, None, None]:
        fd, path = tempfile.mkstemp(suffix=suffix, prefix=prefix, dir=dir)

# Generated at 2022-06-17 19:31:48.482625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.pathutils import (
        get_test_data_dir_path,
    )
    from flutils.testutils.testutils import (
        get_test_data_dir_parent_dir,
    )
    from flutils.testutils.testutils import (
        get_test_data_dir_parent_dir_name,
    )
    from flutils.testutils.testutils import (
        get_test_data_dir_parent_dir_parent_dir,
    )

# Generated at 2022-06-17 19:31:59.241695
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(TestCase):

        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
               

# Generated at 2022-06-17 19:32:18.079422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertTrue(isinstance(config, SetupCfgCommandConfig))
                self.assertTrue(isinstance(config.name, str))
                self.assertTrue(isinstance(config.camel, str))
                self.assertTrue(isinstance(config.description, str))
                self.assertTrue(isinstance(config.commands, tuple))
                for command in config.commands:
                    self.assertTrue(isinstance(command, str))


# Generated at 2022-06-17 19:32:27.329665
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import to_str

    with TempDir() as td:
        setup_py_path = os.path.join(td, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('# setup.py')

        setup_cfg_path = os.path.join(td, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )

        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')

# Generated at 2022-06-17 19:32:39.061927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:32:47.929680
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config(get_parent_dir(__file__)):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:32:58.054110
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('# -*- coding: utf-8 -*-\n')
                f.write('\n')

# Generated at 2022-06-17 19:33:09.113261
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import underscore_to_camel

    with TempDir() as td:
        td.write('setup.py', '#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:33:16.006640
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_executable


# Generated at 2022-06-17 19:33:18.646175
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:26.423949
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()


if __name__ == '__main__':
    import sys

# Generated at 2022-06-17 19:33:38.199452
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        ensure_dir,
        ensure_file,
    )

    from flutils.strutils import (
        indent,
        strip_indent,
    )

    from flutils.sysutils import (
        get_python_executable,
    )

    from flutils.testutils import (
        get_test_data_path,
    )

    from flutils.testutils.pytest import (
        assert_no_exception,
    )

    from flutils.testutils.pytest import (
        assert_exception,
    )

    from flutils.testutils.pytest import (
        assert_exception_message,
    )


# Generated at 2022-06-17 19:33:59.257257
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:34:10.934874
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )

# Generated at 2022-06-17 19:34:20.988624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
        each_file_in_dir_recursive_with_dir,
    )

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')


# Generated at 2022-06-17 19:34:30.108515
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:34:38.702281
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path

    with TempDir() as td:
        td.write_file('setup.py', '#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:34:45.295015
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:34:52.954651
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    setup_dir=get_project_root_dir()
            ):
                self.assertTrue(isinstance(config, SetupCfgCommandConfig))
                self.assertTrue(isinstance(config.name, str))
                self.assertTrue(isinstance(config.camel, str))
                self.assertTrue(isinstance(config.description, str))
                self.assertTrue(isinstance(config.commands, tuple))
                for command in config.commands:
                    self.assertTrue(isinstance(command, str))

    TestEachSubCommand

# Generated at 2022-06-17 19:34:58.243993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_dir
    from flutils.testutils import assert_each_equal
    from flutils.testutils import assert_each_not_equal
    from flutils.testutils import assert_each_type
    from flutils.testutils import assert_each_value
    from flutils.testutils import assert_each_value_not
    from flutils.testutils import assert_each_value_type
    from flutils.testutils import assert_each_value_type_not
    from flutils.testutils import assert_each_value_type_value
    from flutils.testutils import assert_each_value_type_value_not
    from flutils.testutils import assert_each_value_value
    from flutils.testutils import assert_each_value_value_not

# Generated at 2022-06-17 19:35:09.828003
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:35:20.081781
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_dir,
        each_file,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )


# Generated at 2022-06-17 19:35:51.329094
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
    )
    from flutils.testutils.pytestutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_true,
        assert_false,
    )
    from flutils.testutils.pytestutils import (
        assert_in,
        assert_not_in,
    )

# Generated at 2022-06-17 19:35:59.872467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pathlib
    import textwrap

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = '',
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent('''\
                [metadata]
                name = %s
                [setup.command.%s]
                commands =
                    %s
                description = %s
                ''' % (name, command_name, '\\n                    '.join(commands), description)))


# Generated at 2022-06-17 19:36:08.445223
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """
                [metadata]
                name = %s
                """ % name
            ))
        with open(os.path.join(setup_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """
                [setup.command.test]
                command =
                    %s
                """ % '\n                    '.join(commands)
            ))


# Generated at 2022-06-17 19:36:15.764738
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    setup_dir = os.path.dirname(get_path_to_module(__name__))
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)

# Generated at 2022-06-17 19:36:24.576654
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:36:31.431766
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path

    with TempDir() as td:
        setup_py_path = os.path.join(td, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('#!/usr/bin/env python\n')
            f.write('\n')
            f.write('import setuptools\n')
            f.write('\n')
            f.write('if __name__ == "__main__":\n')
            f.write('    setuptools.setup()\n')
        setup_cfg_path = os.path.join(td, 'setup.cfg')

# Generated at 2022-06-17 19:36:38.654216
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()




# Generated at 2022-06-17 19:36:47.286826
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
        each_file_in_zip_file,
        each_file_in_zip_file_recursive,
    )

    from flutils.setuputils import (
        each_sub_command_config,
        sub_command_config,
    )

    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )


# Generated at 2022-06-17 19:36:59.075412
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdin,
        capture_sys_exit,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_module_path,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        get_random_string,
    )
    from flutils.fileutils import (
        write_file,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.setuputils import (
        get_setup_cfg_commands,
    )

# Generated at 2022-06-17 19:37:07.532768
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root
    from flutils.testutils import UnitTestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            root = get_project_root()
            root = os.path.join(root, 'tests', 'data', 'setup_commands')
            for config in each_sub_command_config(root):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for cmd in config.commands:
                    self.assertIsInstance(cmd, str)



# Generated at 2022-06-17 19:37:59.216950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:38:10.311464
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(get_path_to_module(__file__))
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommand

# Generated at 2022-06-17 19:38:22.898302
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pytestutils import (
        assert_each_equal,
        assert_each_in,
    )
    from flutils.pathutils import (
        each_parent_directory,
        each_parent_directory_with_file,
    )
    from flutils.strutils import (
        each_line,
        each_word,
    )
    from flutils.sysutils import (
        get_module_path,
    )
    from flutils.textutils import (
        each_line_with_index,
    )
    from flutils.timeutils import (
        get_current_datetime,
    )
    from flutils.versionutils import (
        get_version,
    )

    setup_dir = None
    for fs in extract_stack():
        fs = cast(FrameSummary, fs)