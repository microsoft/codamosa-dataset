

# Generated at 2022-06-17 19:28:41.758252
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:28:52.207871
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }
            for config in _each_setup_cfg_command(parser, format_kwargs):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)

# Generated at 2022-06-17 19:29:01.787154
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout(stream: StringIO) -> Generator[None, None, None]:
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            out = StringIO()
            with capture_stdout(out):
                for config in each_sub_command_config():
                    print(config)
            out.seek(0)
            self.assertTrue(out.read())

    unittest.main()



# Generated at 2022-06-17 19:29:11.707603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('name = test\n')
            f.write('description = %s\n' % description)
            f.write('commands =\n')
            for command in commands:
                f.write('    %s\n' % command)

# Generated at 2022-06-17 19:29:22.302537
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:32.289062
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.home_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:29:42.277479
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:29:51.294716
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('name = test\n')
            f.write('description = Test command\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:30:02.962007
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_parent_dir(__file__, 'test_data')
            path = os.path.join(path, 'setup_commands')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:30:11.586079
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail('Unable to find the directory that contains '
                          'the setup.py file.')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:30:35.226204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        assert all(isinstance(x, str) for x in config.commands)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:30:42.898710
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as td:
        td = str(td)
        setup_dir = os.path.join(td, 'setup_dir')
        os.mkdir(setup_dir)
        setup_cfg = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg, 'w') as f:
            f.write(
                """
                [metadata]
                name = test_project
                """
            )
        setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:30:57.680046
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:31:05.978172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string

    with TempDir() as tmpdir:
        setup_py_path = os.path.join(tmpdir, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('')
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write('''\
[metadata]
name = {name}
'''.format(name=random_string()))
        setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:31:14.729368
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import (
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_subclass,
        assert_is_true,
        assert_is_false,
        assert_equal,
        assert_not_equal,
        assert_raises,
    )
    from flutils.testutils.assertutils import (
        assert_in,
        assert_not_in,
    )
    from flutils.testutils.fileutils import (
        assert_file_exists,
        assert_file_not_exists,
    )

# Generated at 2022-06-17 19:31:26.833101
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import inspect
    import tempfile
    import shutil
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('import setuptools\n')
                f.write('setuptools.setup()\n')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:31:37.833756
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_project_root,
    )
    from flutils.testutils import (
        TestCase,
        TestCaseWithTempDir,
    )
    from flutils.testutils.pathutils import (
        create_file,
        create_file_with_contents,
        create_files,
    )

    class TestEachSubCommandConfig(TestCaseWithTempDir):
        def setUp(self):
            super().setUp()
            self.setup_dir = self.temp_dir
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_commands_

# Generated at 2022-06-17 19:31:48.309851
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_output,
        capture_sys_exit,
        capture_sys_exit_exc_info,
    )
    from flutils.testutils.fileutils import (
        create_file,
        create_file_tree,
        remove_file_tree,
    )
    from flutils.testutils.sysutils import (
        get_sys_exit_code,
        get_sys_exit_exc_info,
    )

    # Test setup.cfg file missing
    with capture_sys_exit_exc_info() as exc_info:
        with capture_output() as out:
            each_sub_command_config()
    assert get_sys_exit_exc_info() == exc_info
    assert get_sys_exit_code() == 1
    assert out.getvalue()

# Generated at 2022-06-17 19:31:58.001348
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import underscore_to_camel

    setup_dir = get_parent_dir(__file__, 2)
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        assert underscore_to_camel(config.name.replace('.', '_')) == config.camel

# Generated at 2022-06-17 19:32:07.980682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')


# Generated at 2022-06-17 19:32:36.453964
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:32:46.333437
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from flutils.testutils import UnitTestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(sys.modules[__name__].__file__)
            setup_dir = os.path.join(setup_dir, 'test_data')
            setup_dir = os.path.join(setup_dir, 'setup_cfg_test')
            setup_dir = os.path.realpath(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
               

# Generated at 2022-06-17 19:32:57.025396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:33:08.257837
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()




# Generated at 2022-06-17 19:33:10.931241
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    def _test(setup_dir: Optional[Union[os.PathLike, str]] = None) -> None:
        for config in each_sub_command_config(setup_dir):
            print(config)
    _test()
    _test(os.path.dirname(__file__))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:22.906430
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        TestCase,
        get_test_data_path,
    )
    from flutils.pathutils import (
        each_file_in_dir,
    )

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            for path in each_file_in_dir(
                    get_test_data_path('setup_commands')):
                if path.name.startswith('setup_commands.'):
                    continue
                path = path.parent
                for config in each_sub_command_config(path):
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIs

# Generated at 2022-06-17 19:33:36.031027
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from configparser import ConfigParser

    def _write_config(
            parser: ConfigParser,
            setup_cfg_path: str,
            setup_commands_cfg_path: str
    ) -> None:
        with open(setup_cfg_path, 'w') as f:
            parser.write(f)
        with open(setup_commands_cfg_path, 'w') as f:
            parser.write(f)

    def _test_setup_cfg(
            setup_cfg_path: str,
            setup_commands_cfg_path: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        parser = ConfigParser()
        parser.read(setup_cfg_path)
        name = _get_name

# Generated at 2022-06-17 19:33:48.889504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_blank,
        is_not_blank,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils.test_case import (
        TestCase,
    )


# Generated at 2022-06-17 19:33:57.088704
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_no_setup_cfg(self):
            with self.assertRaises(FileNotFoundError):
                list(each_sub_command_config(self.temp_dir))


# Generated at 2022-06-17 19:34:02.504499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        make_temp_dir,
        remove_temp_dir,
    )
    from flutils.pathutils import (
        ensure_dir,
        ensure_file,
    )
    from flutils.strutils import (
        to_bytes,
        to_str,
    )

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig],
    ) -> None:
        with make_temp_dir() as temp_dir:
            setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')

# Generated at 2022-06-17 19:35:23.518822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_parent_dir,
    )

# Generated at 2022-06-17 19:35:35.034214
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:35:43.009621
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from contextlib import contextmanager
    from io import StringIO
    from pathlib import Path
    from typing import Generator

    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
        each_file_in_dir_recursive_with_dir,
    )

    @contextmanager
    def _temp_dir() -> Generator[str, None, None]:
        with tempfile.TemporaryDirectory() as temp_dir:
            yield temp_dir


# Generated at 2022-06-17 19:35:57.047129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__name__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:36:05.676582
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_path_to_module(__name__)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup

# Generated at 2022-06-17 19:36:16.025827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help-commands']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:36:25.207838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import is_str_type

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for config in each_sub_command_config(setup_dir):
            assert isinstance(config, SetupCfgCommandConfig)
            assert is_str_type(config.name)
            assert is_str_type(config.camel)
            assert is_str_type(config.description)
            assert isinstance(config.commands, tuple)
            for command in config.commands:
                assert is_str_type(command)

    _test_each_sub_command_config()


# Generated at 2022-06-17 19:36:32.133374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.test_case import (
        TestCase,
        TestCaseWithTempDir,
    )
    from flutils.testutils.test_case_with_temp_dir import (
        TestCaseWithTempDirBase,
    )

    class TestCaseWithTempDirSubclass(TestCaseWithTempDirBase):
        def setUp(self):
            super().setUp()
            self.setup_dir = self.temp_dir

    class TestCaseWithTempDirSubclass2(TestCaseWithTempDirBase):
        def setUp(self):
            super().setUp()
            self.setup_dir

# Generated at 2022-06-17 19:36:39.075147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_module_path,
        get_module_name,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        get_indent,
    )
    from flutils.textutils import (
        get_indent_str,
    )
    from flutils.pyutils import (
        get_class_name,
    )
    from flutils.logutils import (
        get_logger,
    )
    from flutils.configutils import (
        get_config_dir,
    )

# Generated at 2022-06-17 19:36:47.528374
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from flutils.setuputils import each_sub_command_config

    def _get_setup_cfg(
            name: str,
            commands: Tuple[str, ...],
            description: str = '',
            setup_cfg_path: Optional[Union[os.PathLike, str]] = None
    ) -> str:
        if setup_cfg_path is None:
            setup_cfg_path = 'setup.cfg'
        setup_cfg_path = str(setup_cfg_path)
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write

# Generated at 2022-06-17 19:38:03.538673
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:38:13.655687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg)
