

# Generated at 2022-06-17 19:28:46.341425
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:28:55.577405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from unittest import TestCase

    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )

    from flutils.setuputils import each_sub_command_config

    class TestEachSubCommandConfig(TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:29:05.920589
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from flutils.pathutils import each_parent_dir

# Generated at 2022-06-17 19:29:16.611841
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                self.assertGreater(len(config.commands), 0)

# Generated at 2022-06-17 19:29:25.101466
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:35.691300
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.pyutils import get_module_name
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_path_to_file,
    )
    from flutils.testutils.pytestutils import (
        assert_each_equal,
        assert_each_in,
    )
    from flutils.testutils.pytestutils import (
        assert_each_not_equal,
        assert_each_not_in,
    )
    from flutils.testutils.pytestutils import (
        assert_is_instance,
        assert_not_is_instance,
    )

# Generated at 2022-06-17 19:29:43.342838
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import normalize_line_endings
    from flutils.sysutils import get_python_version
    from flutils.textutils import (
        each_line,
        each_line_in_file,
        each_line_in_string,
        each_line_in_string_with_indent,
        indent_lines,
        indent_lines_in_string,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_string,
    )

# Generated at 2022-06-17 19:29:53.901156
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:30:02.825531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:30:11.505435
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:30:38.290084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_dir(__file__)
            setup_dir = os.path.join(setup_dir, '..', '..', '..')
            setup_dir = os.path.realpath(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:30:49.083280
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()




# Generated at 2022-06-17 19:31:01.240916
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python3\n')

# Generated at 2022-06-17 19:31:13.150076
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase
    from flutils.testutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_cfg_test')
            setup_dir = get_parent_dir(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:31:20.466779
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    from flutils.pathutils import get_parent_dir

    from flutils.setuputils import each_sub_command_config

    class TestEachSubCommandConfig(unittest.TestCase):
        """Unit test for function each_sub_command_config."""

        def test_each_sub_command_config(self):
            """Test function each_sub_command_config."""
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self

# Generated at 2022-06-17 19:31:30.662851
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.textutils import (
        get_indent,
    )

    from . import (
        get_setup_cfg_command_config,
    )

    from .test_setup_cfg_command_config import (
        test_get_setup_cfg_command_config,
    )


# Generated at 2022-06-17 19:31:39.364484
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import underscore_to_camel

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:31:46.880144
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py_path, 'w') as f:
                f.write('')

# Generated at 2022-06-17 19:31:58.672711
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os
    import os.path
    import subprocess
    import re
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    @contextlib.contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr


# Generated at 2022-06-17 19:32:06.785329
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )
    from flutils.sysutils import (
        get_python_executable,
        get_python_version,
    )
    from flutils.textutils import (
        each_line_in_file,
        each_line_in_file_recursive,
    )
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )

# Generated at 2022-06-17 19:32:41.492846
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import (
        assert_generator_equal,
        assert_generator_raises,
    )
    from flutils.testutils.test_pathutils import (
        assert_get_path_to_this_file_raises,
    )


# Generated at 2022-06-17 19:32:52.346422
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        setup_py = tmpdir / 'setup.py'
        setup_cfg = tmpdir / 'setup.cfg'
        setup_commands_cfg = tmpdir / 'setup_commands.cfg'
        setup_py.touch()
        setup_cfg.touch()
        setup_commands_cfg.touch()

# Generated at 2022-06-17 19:33:00.285292
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils.fileutils import (
        create_temp_dir,
        create_temp_file,
    )
    from flutils.testutils.miscutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )
    from flutils.testutils.pathutils import (
        assert_path_exists,
        assert_path_not_exists,
    )

    with create_temp_dir() as tmp_dir:
        setup_py_path = os.path.join(tmp_dir, 'setup.py')
        create_temp_file(setup_py_path)

# Generated at 2022-06-17 19:33:10.839293
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:22.819033
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:36.031480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.my_command]\n')
            f.write('description = My description\n')
            f.write('commands = \\\n')
            for command in commands:
                f.write('    %s\n' % command)


# Generated at 2022-06-17 19:33:48.889008
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        underscore_to_camel,
        camel_to_underscore,
    )
    from flutils.pyutils import (
        is_identifier,
    )

    # Test the function with no arguments
    setup_dir = get_parent_dir(__file__)
    setup_dir = get_parent_dir(setup_dir)
    setup_dir = get

# Generated at 2022-06-17 19:33:51.141647
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:34:00.985327
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_not_empty_generator,
        assert_is_empty_generator,
        assert_is_empty,
        assert_is_true,
        assert_is_false,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )
    from flutils.pathutils import (
        get_module_path,
        get_module_dir,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_platform,
    )

    # Test setup_

# Generated at 2022-06-17 19:34:12.014437
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')


# Generated at 2022-06-17 19:35:03.595889
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )

    class TestEachSubCommandConfig(UnitCase):

        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_cfg_test')
            out = list(each_sub_command_config(setup_dir))
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'test.command')
            self.assertEqual(out[0].camel, 'TestCommand')
            self.assertEqual(out[0].description, 'Test command.')
            self.assertEqual(out[0].commands, ('echo test',))

# Generated at 2022-06-17 19:35:14.955566
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_module_path,
        get_module_dir,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_dir,
    )
    from flutils.testutils.test_pathutils import (
        test_get_module_path,
        test_get_module_dir,
    )
    from flutils.testutils.test_testutils import (
        test_get_test_data_path,
        test_get_test_data_dir,
    )
    from flutils.testutils.test_testutils import (
        test_get_test_data_path,
        test_get_test_data_dir,
    )

# Generated at 2022-06-17 19:35:20.177922
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str

    setup_dir = os.path.dirname(get_path_to_this_file())
    for config in each_sub_command_config(setup_dir):
        print(to_str(config))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:35:32.627989
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.TemporaryDirectory()
            self.setup_dir_path = self.setup_dir.name
            self.setup_py_path = os.path.join(self.setup_dir_path, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir_path, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir_path, 'setup_commands.cfg'
            )
            with open(self.setup_py_path, 'w') as f:
                f.write('# setup.py')

# Generated at 2022-06-17 19:35:41.682432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                tmpdir = str(tmpdir)
                setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
                with open(setup_cfg_path, 'w') as f:
                    f.write(
                        '''
                        [metadata]
                        name = flutils
                        '''
                    )
                setup_commands_cfg_path = os.path.join(
                    tmpdir, 'setup_commands.cfg'
                )

# Generated at 2022-06-17 19:35:50.118147
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase
    from flutils.testutils import UnitTestSuite

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config
            from flutils.setuputils import SetupCfgCommandConfig

            setup_dir = get_module_path(__name__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:35:59.480524
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import get_parent_dir

    from flutils.setuputils import each_sub_command_config

    setup_dir = get_parent_dir(__file__)
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

    with tempfile.TemporaryDirectory() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'setup_dir')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:36:08.196762
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:36:17.457650
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)


# Generated at 2022-06-17 19:36:25.901797
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:37:56.126715
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:38:05.047448
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase
    from flutils.testutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:38:14.608386
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from flutils.pathutils import (
        ensure_dir,
        ensure_file,
    )
    from flutils.strutils import (
        dedent,
    )
    from flutils.testutils import (
        assert_in,
        assert_not_in,
        assert_raises,
        assert_regex,
        assert_true,
        assert_false,
        assert_equal,
    )

    with TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        setup_dir = os.path.join(tmpdir, 'project')
        ensure_dir(setup_dir)
        setup_py = os.path.join(setup_dir, 'setup.py')

# Generated at 2022-06-17 19:38:19.529566
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('name = foo\n')
            f.write('description = The foo command.\n')
            f.write('commands = \\\n')
            for command in commands:
                f.write('    %s\n' % command)
