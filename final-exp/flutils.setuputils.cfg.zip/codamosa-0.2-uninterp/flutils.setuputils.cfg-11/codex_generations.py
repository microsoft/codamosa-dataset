

# Generated at 2022-06-17 19:28:43.265674
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    def _test_each_sub_command_config(
            setup_cfg_content: str,
            setup_commands_cfg_content: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_content)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:28:57.005059
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_dir
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.testutils import (
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )

    test_dir = get_

# Generated at 2022-06-17 19:29:06.245452
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:29:17.661067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase
    from flutils.pathutils import get_module_path

    class TestCase(UnitCase):
        def test_each_sub_command_config(self):
            path = get_module_path(__name__)
            path = os.path.join(path, 'test_data')
            path = os.path.join(path, 'setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'test_project'
            }

# Generated at 2022-06-17 19:29:27.619607
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.cwd = os.getcwd()
            self.tmpdir = tempfile.mkdtemp()
            os.chdir(self.tmpdir)
            self.setup_py = os.path.join(self.tmpdir, 'setup.py')
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('import setuptools\n')
                f.write('setuptools.setup()\n')
            self.setup_cfg = os.path.join(self.tmpdir, 'setup.cfg')

# Generated at 2022-06-17 19:29:37.120508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):

        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:29:47.769003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_dir_in_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        each_line,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_dir_in_dir,
    )

# Generated at 2022-06-17 19:29:58.280468
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """\
                [metadata]
                name = %s

                [setup.command.foo]
                commands =
                    %s
                """ % (name, '\n'.join(commands))
            ))


# Generated at 2022-06-17 19:30:06.794061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )

    # Test with a bad setup_dir
    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        setup_dir='/tmp/does-not-exist'
    )
    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        setup_dir='/tmp/does-not-exist/setup.py'
    )

# Generated at 2022-06-17 19:30:15.803676
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file,
        each_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.textutils import (
        each_line,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )

# Generated at 2022-06-17 19:30:41.246067
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils.testcase import (
        TestCase,
    )
    from flutils.testutils.testcase import (
        get_test_case_name,
    )
    from flutils.testutils.testcase import (
        get_test_case_module_name,
    )

# Generated at 2022-06-17 19:30:50.901811
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def setUp(self):
            self.setup_dir = get_module_path(__file__)

        def test_each_sub_command_config(self):
            out = list(each_sub_command_config(self.setup_dir))

# Generated at 2022-06-17 19:30:59.104018
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir

    setup_dir = get_parent_dir(__file__, 'setup.py')
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)
            assert command


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:31:11.320581
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    test = Test()
    test.test_each_sub_

# Generated at 2022-06-17 19:31:23.673150
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_path(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:31:32.488955
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTest
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTest):

        def test_each_sub_command_config(self):
            for setup_dir in each_parent_dir(__file__, 'setup.py'):
                for config in each_sub_command_config(setup_dir):
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()




# Generated at 2022-06-17 19:31:42.501733
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.pathutils import get_project_dir

            project_dir = get_project_dir()
            for config in each_sub_command_config(project_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:31:49.906409
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import io
    import unittest
    from contextlib import redirect_stdout

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            f = io.StringIO()
            with redirect_stdout(f):
                for config in each_sub_command_config():
                    print(config)
            out = f.getvalue()
            self.assertIn('SetupCfgCommandConfig(name=\'test\', camel=\'Test\', ', out)
            self.assertIn('description=\'Runs the unit tests for this project.\', ', out)
            self.assertIn('commands=(\'python -m unittest discover -s tests\',),)', out)

# Generated at 2022-06-17 19:31:58.372285
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_root_dir
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            root_dir = get_root_dir()
            setup_dir = os.path.join(root_dir, 'tests', 'data', 'setup_dir')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:08.219433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.pytestutils import (
        assert_each_sub_command_config,
        assert_setup_cfg_command_config,
    )
    from flutils.testutils.testutils import (
        assert_exception_message,
    )
    from flutils.testutils.testutils import (
        assert_exception_message,
    )

    # Test setup_dir is None

# Generated at 2022-06-17 19:32:58.415238
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(sys.path[0]):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:33:09.400139
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module

# Generated at 2022-06-17 19:33:13.465121
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _write_setup_cfg(
            tmp_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = ''
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.%s]\n' % command_name)
            f.write('description = %s\n' % description)
            f.write('commands = \\\n')

# Generated at 2022-06-17 19:33:24.040131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    class TestEachSubCommandConfig(TestCase):
        def setUp(self):
            self.setup_dir = TemporaryDirectory()
            self.setup_dir_path = Path(self.setup_dir.name)
            self.setup_cfg_path = self.setup_dir_path / 'setup.cfg'
            self.setup_cfg_path.touch()

# Generated at 2022-06-17 19:33:36.480342
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _test_each_sub_command_config(
            setup_cfg_content: str,
            setup_commands_cfg_content: str,
            expected_name: str,
            expected_configs: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_content)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:33:49.201109
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.sysutils import get_python_executable

    with TempDir() as td:
        setup_dir = os.path.join(td, 'setup_dir')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:33:58.479900
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:34:10.200840
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, level=2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:34:20.663480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import textwrap
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def _write_setup_cfg(self, text: str) -> None:
            text = textwrap.dedent(text)
            with open(os.path.join(self.temp_dir, 'setup.cfg'), 'w') as f:
                f.write(text)

        def _write_setup_commands_cfg(self, text: str) -> None:
            text = textwrap.dedent(text)

# Generated at 2022-06-17 19:34:30.805532
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for sub_command_config in each_sub_command_config():
                self.assertIsInstance(sub_command_config,
                                      SetupCfgCommandConfig)
                self.assertIsInstance(sub_command_config.name, str)
                self.assertIsInstance(sub_command_config.camel, str)
                self.assertIsInstance(sub_command_config.description, str)
                self.assertIsInstance(sub_command_config.commands, tuple)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:35:03.325885
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()



# Generated at 2022-06-17 19:35:08.564983
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import to_str

    setup_dir = get_parent_dir(__file__, 3)
    for config in each_sub_command_config(setup_dir):
        print(to_str(config))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:35:16.919627
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    sys.exit(unittest.main())


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:35:25.241591
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase
    from flutils.testutils import (
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_empty,
        assert_is_true,
        assert_is_false,
        assert_equal,
        assert_not_equal,
        assert_raises,
    )

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_parent_dir(__file__, 'setup.py')
            assert_is_not_none(setup_dir)
            assert_is_instance(setup_dir, str)

# Generated at 2022-06-17 19:35:35.745003
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string
    from flutils.sysutils import get_python_executable

    with TempDir() as td:
        setup_dir = os.path.join(td, 'setup')
        os.mkdir(setup_dir)
        setup_py = os.path.join(setup_dir, 'setup.py')
        setup_cfg = os.path.join(setup_dir, 'setup.cfg')
        setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')
        with open(setup_py, 'w') as f:
            f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:35:43.375903
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_cfg, 'w') as f:
                f.write(
                    '[metadata]\n'
                    'name = flutils\n'
                )

# Generated at 2022-06-17 19:35:57.243830
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py_path, 'w') as f:
                f.write('')

# Generated at 2022-06-17 19:36:05.878311
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_path_to_module

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.join(path, '..', '..', '..', 'tests', 'data')
            path = os.path.realpath(path)
            path = os.path.join(path, 'setup_commands')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:36:16.131850
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            out = list(each_sub_command_config(path))
            self.assertEqual(len(out), 2)
            self.assertEqual(out[0].name, 'test.command')
            self.assertEqual(out[0].camel, 'TestCommand')
            self.assertEqual(out[0].description, 'Test command.')
            self.assertEqual(out[0].commands, ('echo test',))

# Generated at 2022-06-17 19:36:25.284945
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        chdir,
        get_cwd,
        get_env,
        set_env,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_temp_path,
    )
    from flutils.testutils.testcase import (
        BaseTestCase,
        TestCase,
    )


# Generated at 2022-06-17 19:37:20.092087
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:37:29.874073
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):

        def test_each_sub_command_config(self):
            setup_dir = get_project_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:37:41.300725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import each_parent_dir

    for parent_dir in each_parent_dir(__file__):
        setup_cfg_path = os.path.join(parent_dir, 'setup.cfg')
        if os.path.isfile(setup_cfg_path):
            break
    else:
        raise FileNotFoundError(
            "Unable to find the 'setup.cfg' file."
        )

    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)

    format_kwargs = {
        'setup_dir': os.path.dirname(setup_cfg_path),
        'home': os.path.expanduser('~'),
        'name': name
    }


# Generated at 2022-06-17 19:37:52.905361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import os.path
    import sys

    def _write_setup_cfg(
            path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:38:04.013149
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.sysutils import (
        get_script_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.textutils import (
        is_empty,
    )
    from flutils.timeutils import (
        get_current_datetime,
    )
    from pathlib import (
        Path,
    )
    from tempfile import (
        TemporaryDirectory,
    )
    from unittest import (
        TestCase,
    )


# Generated at 2022-06-17 19:38:08.160612
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_version,
        is_windows,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )

    def _get_setup_dir(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> str:
        if setup_dir:
            return setup_dir
        return get_parent_dir(get_test_data_dir())


# Generated at 2022-06-17 19:38:15.940783
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')