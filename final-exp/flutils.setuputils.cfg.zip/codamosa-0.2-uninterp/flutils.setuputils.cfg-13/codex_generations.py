

# Generated at 2022-06-17 19:28:50.277525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_cfg_path, 'w') as f:
                f.write(
                    '''
                    [metadata]
                    name = flutils
                    '''
                )

# Generated at 2022-06-17 19:28:59.914405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:29:10.432223
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    from flutils.pathutils import each_parent_dir

    def _get_setup_dir() -> str:
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            basename = os.path.basename(fs.filename)
            if basename == 'setup.py':
                return str(os.path.dirname(fs.filename))
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )

    def _get_setup_cfg_path() -> str:
        return os.path.join(_get_setup_dir(), 'setup.cfg')


# Generated at 2022-06-17 19:29:21.039950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:29:31.939277
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_not_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.sysutils import (
        get_python_executable,
    )

# Generated at 2022-06-17 19:29:41.392905
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path(__file__, '..', '..', '..', '..', '..', '..')
            path = os.path.join(path, 'setup.py')
            if os.path.isfile(path) is False:
                raise FileNotFoundError(
                    "Unable to find the 'setup.py' file for the project."
                )
            path = os.path.dirname(path)
            path = os.path.realpath(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)

# Generated at 2022-06-17 19:29:52.564447
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.exists(os.path.join(path, 'setup.py')):
                    break
            else:
                raise FileNotFoundError(
                    "Unable to find the directory that contains the "
                    "'setup.py' file."
                )
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:30:03.123826
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )

# Generated at 2022-06-17 19:30:10.955621
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.configutils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:30:19.312525
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.pathutils import (
        create_temp_dir,
        remove_tree,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        normalize_text,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.setuputils import (
        get_setup_dir,
    )
    from flutils.setuputils import (
        get_setup_name,
    )

# Generated at 2022-06-17 19:30:43.573850
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:30:58.068505
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_module_path(__file__)
            path = os.path.join(path, '..', '..', '..', '..', '..')
            path = os.path.realpath(path)
            path = os.path.join(path, 'setup.py')
            path = os.path.dirname(path)
            path = os.path.realpath(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)

# Generated at 2022-06-17 19:31:06.167041
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)
    Test().run()



# Generated at 2022-06-17 19:31:14.960380
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:31:27.067568
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(get_path_to_this_file())
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommand

# Generated at 2022-06-17 19:31:38.072289
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:31:46.818323
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.join(path, '..', '..', '..', 'tests', 'data')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:31:58.643230
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.join(
                get_parent_dir(__file__),
                'test_data',
                'setup_commands'
            )
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:08.509367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(TempDirTestCase):
        def test_each_sub_command_config(self):
            setup_dir = self.temp_dir
            setup_py = os.path.join(setup_dir, 'setup.py')
            setup_cfg = os.path.join(setup_dir, 'setup.cfg')
            setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')
            with open(setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
            with open(setup_cfg, 'w') as f:
                f.write('[metadata]\n')
                f.write

# Generated at 2022-06-17 19:32:14.581943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_is_empty,
        assert_is_not_empty,
        assert_raises,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.testutils import (
        get_test_data_dir,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )


# Generated at 2022-06-17 19:32:46.814305
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase


# Generated at 2022-06-17 19:32:57.383356
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:33:08.575950
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        TestCase,
        get_test_data_path,
    )

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }
            out = list(_each_setup_cfg_command(parser, format_kwargs))

# Generated at 2022-06-17 19:33:15.650110
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.pathutils import (
        create_temp_dir,
        remove_tree,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.textutils import (
        dedent,
    )
    from flutils.testutils import (
        assert_raises,
    )
    from flutils.testutils import (
        assert_raises_regex,
    )
    from flutils.testutils import (
        assert_raises_regexp,
    )
    from flutils.testutils import (
        assert_raises_regexp_context,
    )

# Generated at 2022-06-17 19:33:24.964815
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'command = %s\n'
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:33:37.220639
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:48.934735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    sys.exit(unittest.main())

# Generated at 2022-06-17 19:33:57.618964
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:34:09.273315
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_module_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__file__)
            setup_dir = os.path.join(setup_dir, '..', '..', '..')
            setup_dir = os.path.realpath(setup_dir)

            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:34:20.398085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import get_random_string
    from flutils.sysutils import get_temp_dir
    from flutils.sysutils import get_temp_file
    from flutils.sysutils import get_temp_file_name
    from flutils.sysutils import get_temp_file_path
    from flutils.sysutils import get_temp_file_paths
    from flutils.sysutils import get_temp_files
    from flutils.sysutils import get_temp_sub_dir
    from flutils.sysutils import get_temp_sub_dir_path
    from flutils.sysutils import get_temp_sub_dirs
    from flutils.sysutils import get_temp_sub_dirs_paths
    from flutils.sysutils import get

# Generated at 2022-06-17 19:35:14.650438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_cfg_path, 'w') as fp:
                fp.write(
                    '''
[metadata]
name = test_project
                    '''
                )

# Generated at 2022-06-17 19:35:23.963999
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )
    from flutils.pathutils import Path

    path = Path(__file__).parent.parent.parent.parent
    path = path / 'setup.py'
    assert_is_not_none(path)
    assert_true(path.exists())

    assert_raises(FileNotFoundError, each_sub_command_config)

    assert_raises(FileNotFoundError, each_sub_command_config, 'foo')


# Generated at 2022-06-17 19:35:35.373789
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_parent_dir(__file__, 'setup.py')
            for cfg in each_sub_command_config(setup_dir):
                self.assertIsInstance(cfg, SetupCfgCommandConfig)
                self.assertIsInstance(cfg.name, str)
                self.assertIsInstance(cfg.camel, str)
                self.assertIsInstance(cfg.description, str)
                self.assertIsInstance(cfg.commands, tuple)
                for cmd in cfg.commands:
                    self.assertIsInstance(cmd, str)

   

# Generated at 2022-06-17 19:35:46.902437
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def _test_each_sub_command_config(self, setup_dir: str) -> None:
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)


# Generated at 2022-06-17 19:35:57.019523
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.tmp_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.tmp_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.tmp_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:36:01.959632
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    setup_dir = os.path.dirname(get_path_to_this_file())
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for cmd in config.commands:
            assert isinstance(cmd, str)

# Generated at 2022-06-17 19:36:09.532697
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from flutils.setuputils import each_sub_command_config
    from flutils.setuputils import SetupCfgCommandConfig

    def _create_setup_cfg(
            setup_cfg_path: str,
            name: str = '',
            description: str = '',
            commands: List[str] = []
    ) -> None:
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('description = %s\n' % description)
            f.write('commands =\n')
           

# Generated at 2022-06-17 19:36:17.942678
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    sys.exit(TestEachSubCommandConfig().run())


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:36:26.711036
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file

# Generated at 2022-06-17 19:36:36.241459
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_child_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )

    setup_dir = get_parent_dir(__file__)
    setup_dir = get_child_dir(setup_dir, 'test_project')
    setup_dir = get_child_dir(setup_dir, 'setup_commands')

# Generated at 2022-06-17 19:38:11.111865
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _test(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_contents)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')
            with open(setup_commands_cfg_path, 'w') as f:
                f.write(setup_commands_cfg_contents)

# Generated at 2022-06-17 19:38:23.177289
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )