

# Generated at 2022-06-17 19:28:43.166033
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_generator_equal,
        assert_generator_raises,
    )
    from flutils.pathutils import (
        get_test_data_path,
        get_test_output_path,
    )

    # Test the setup.cfg file
    setup_cfg_path = get_test_data_path('setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    format_kwargs = {
        'setup_dir': os.path.dirname(setup_cfg_path),
        'home': os.path.expanduser('~')
    }
    format_kwargs['name'] = _get_name(parser, setup_cfg_path)

# Generated at 2022-06-17 19:28:56.949793
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )

    def _get_setup_dir() -> str:
        setup_dir = os.path.dirname(__file__)
        for parent_dir in each_parent_dir(setup_dir):
            if os.path.isfile(os.path.join(parent_dir, 'setup.py')):
                return parent_dir
        raise FileNotFoundError("Unable to find the setup.py file.")


# Generated at 2022-06-17 19:29:05.617906
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:29:16.396290
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    from flutils.pathutils import (
        create_dir,
        create_file,
    )

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        setup_py_path = tmpdir / 'setup.py'
        setup_cfg_path = tmpdir / 'setup.cfg'
        setup_commands_cfg_path = tmpdir / 'setup_commands.cfg'
        create_file(setup_py_path, '')
        create_file(
            setup_cfg_path,
            dedent('''\
                [metadata]
                name = flutils
                ''')
        )

# Generated at 2022-06-17 19:29:25.100336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")

            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:29:35.690795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:29:43.342836
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        get_file_path,
        get_parent_dir,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    from flutils.testutils import (
        TempDir,
    )

    from flutils.textutils import (
        indent,
    )

    from flutils.sysutils import (
        get_python_executable,
    )

    from flutils.testutils import (
        TempDir,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    from flutils.textutils import (
        indent,
    )


# Generated at 2022-06-17 19:29:53.900396
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_project_root_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.testcase import (
        BaseTestCase,
        TestCase,
    )
    from flutils.testutils.testcase import (
        get_test_case_name,
        get_test_case_module,
    )
    from flutils.testutils.testcase import (
        get_test_case_class,
        get_test_case_method,
    )
    from flutils.testutils.testcase import (
        get_test_case_file,
        get_test_case_line,
    )


# Generated at 2022-06-17 19:30:02.825534
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.pyutils import get_caller_module_name
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.testutils import (
        assert_raises_regex,
        assert_raises_regexp,
    )

    from flutils.setuputils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    # Test the default setup_dir
    setup

# Generated at 2022-06-17 19:30:11.504773
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('# setup.py\n')

# Generated at 2022-06-17 19:30:30.994044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import assert_each_equal

    path = get_path_to_module(__name__)
    path = os.path.join(path, 'test_data', 'setup_commands.cfg')
    parser = ConfigParser()
    parser.read(path)
    format_kwargs = {
        'name': 'flutils',
        'setup_dir': os.path.dirname(path),
        'home': os.path.expanduser('~')
    }
    actual = list(_each_setup_cfg_command(parser, format_kwargs))

# Generated at 2022-06-17 19:30:39.800445
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()




# Generated at 2022-06-17 19:30:50.029466
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_not_equal,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.testutils import (
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_not_equal,
        assert_raises,
        assert_raises_regex,
    )
   

# Generated at 2022-06-17 19:31:01.633048
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase
    from flutils.pathutils import get_parent_dir

    class TestCase(TempDirTestCase):

        def test_each_sub_command_config(self):
            setup_dir = self.temp_dir
            setup_py_path = os.path.join(setup_dir, 'setup.py')
            setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
            setup_commands_cfg_path = os.path.join(
                setup_dir, 'setup_commands.cfg'
            )
            with open(setup_py_path, 'w') as f:
                f.write('# setup.py')

# Generated at 2022-06-17 19:31:13.282452
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _create_setup_cfg(
            setup_cfg_path: str,
            name: str,
            description: str,
            commands: str
    ) -> None:
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                "[metadata]\n"
                "name = %s\n"
                "description = %s\n"
                "\n"
                "[setup.command.test]\n"
                "command = %s\n"
                % (name, description, commands)
            )


# Generated at 2022-06-17 19:31:19.136335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    get_path_to_parent_dir(__file__, 2)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig.run()

# Generated at 2022-06-17 19:31:28.091208
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:31:38.169107
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):

        def test_each_sub_command_config(self):
            root_dir = get_project_root_dir(__file__)
            for config in each_sub_command_config(root_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:31:46.964777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTest
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTest):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test

# Generated at 2022-06-17 19:31:58.702499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_python_executable,
        get_python_version,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.textutils import (
        get_text_file_contents,
    )
    from flutils.testutils import (
        get_test_data_path,
    )
    from flutils.testutils import (
        get_test_data_path,
    )
    from flutils.testutils import (
        get_test_data_path,
    )

# Generated at 2022-06-17 19:32:31.121292
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config(
                    get_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommand

# Generated at 2022-06-17 19:32:41.967492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()



# Generated at 2022-06-17 19:32:52.788417
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:03.208270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '[setup.command.%s]\n'
                'command = %s\n'
                % (name, name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:33:12.600183
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _test(
            setup_cfg_content: str,
            setup_commands_cfg_content: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_content)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')
            with open(setup_commands_cfg_path, 'w') as f:
                f.write(setup_commands_cfg_content)
            out = list

# Generated at 2022-06-17 19:33:23.812368
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config(
                    get_path_to_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:33:26.580410
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:38.299788
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_executable,
    )

# Generated at 2022-06-17 19:33:49.654291
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.TemporaryDirectory()
            self.setup_cfg_path = os.path.join(self.setup_dir.name, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir.name, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir.name, 'setup.py')
            with open(self.setup_py_path, 'w') as fp:
                fp.write('')
            self.sys_path = sys.path
            sys.path.insert

# Generated at 2022-06-17 19:33:58.412743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config(self.setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:34:50.370120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__name__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().test

# Generated at 2022-06-17 19:34:58.878760
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:35:10.634125
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config
            from flutils.setuputils import SetupCfgCommandConfig
            from flutils.setuputils import _prep_setup_dir

            setup_dir = _prep_setup_dir()
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:35:21.436660
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_text: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_text)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_text: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_text)


# Generated at 2022-06-17 19:35:33.950886
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')

# Generated at 2022-06-17 19:35:46.783014
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import cd
    from flutils.testutils import TempDir
    from flutils.testutils import assert_equal
    from flutils.testutils import assert_raises
    from flutils.testutils import assert_true
    from flutils.testutils import assert_false

    with TempDir() as temp_dir:
        with cd(temp_dir):
            with open('setup.py', 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('# -*- coding: utf-8 -*-\n')
                f.write('from setuptools import setup\n')
                f.write('setup()\n')
            with open('setup.cfg', 'w') as f:
                f.write('[metadata]\n')
                f

# Generated at 2022-06-17 19:35:48.543340
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-17 19:36:00.159603
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.sysutils import (
        get_python_version,
    )

# Generated at 2022-06-17 19:36:07.275312
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import capture_stdout
    from flutils.testutils import capture_stderr
    from flutils.testutils import capture_stdin
    from flutils.testutils import capture_stdin_stdout
    from flutils.testutils import capture_stdin_stderr
    from flutils.testutils import capture_stdin_stdout_stderr
    from flutils.testutils import capture_stdout_stderr
    from flutils.testutils import capture_stdout_stderr_exception
    from flutils.testutils import capture_stdout_exception
    from flutils.testutils import capture_stderr_exception
    from flutils.testutils import capture_stdin_stdout_exception
   

# Generated at 2022-06-17 19:36:16.622415
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                out = list(each_sub_command_config())
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'help')
            self.assertEqual(out[0].camel, 'Help')
            self.assertEqual(out[0].description, 'Show help message.')
            self.assertEqual(out[0].commands, ('python setup.py --help',))

    unittest.main()

# Generated at 2022-06-17 19:37:01.755318
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    get_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:37:09.468930
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            import os
            import sys
            from flutils.pathutils import get_path_to_module

            path = get_path_to_module(sys.modules[__name__])
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data', 'setup_commands.cfg')
            path = os.path.realpath(path)
            path = os.path.dirname(path)
            for cmd in each_sub_command_config(path):
                self.assertIsInstance(cmd, SetupCfgCommandConfig)
                self.assertIsInstance(cmd.name, str)

# Generated at 2022-06-17 19:37:15.726355
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_cfg')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:37:27.779993
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_executable

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for config in each_sub_command_config(setup_dir):
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            assert all(isinstance(c, str) for c in config.commands)

    _test_each_sub_command_config()

# Generated at 2022-06-17 19:37:39.524122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_path,
        get_python_version,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_size,
    )

# Generated at 2022-06-17 19:37:46.698016
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_this_file()
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data')
            path = os.path.join(path, 'setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }

# Generated at 2022-06-17 19:37:59.126832
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)
                    self.assertGreater(len(command), 0)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:38:10.270510
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:38:22.895764
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
           