

# Generated at 2022-06-17 19:28:40.311551
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase

    class Test(TestCase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:28:50.277508
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_executable

    this_file = get_path_to_this_file()
    this_dir = os.path.dirname(this_file)
    setup_dir = os.path.join(this_dir, 'test_setup_cfg')
    setup_dir = os.path.realpath(setup_dir)

    for config in each_sub_command_config(setup_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        assert len(config.commands) > 0

# Generated at 2022-06-17 19:28:59.159304
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import textwrap
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.setuputils import (
        each_sub_command_config,
        get_setup_dir,
    )

    # Test setup.cfg with no commands
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        setup_py = os.path.join(tmpdir, 'setup.py')
        setup_cfg = os.path.join(tmpdir, 'setup.cfg')
        setup_commands_

# Generated at 2022-06-17 19:29:09.885974
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:21.012682
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import (
        assert_equal,
        assert_in,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_not_in,
        assert_not_equal,
        assert_raises,
    )
    from flutils.testutils import assert_not_is_instance

    setup_dir = get_path_to_this_file(__file__, '..', '..', '..')
    assert_is_not_none(setup_dir)
    assert_is_instance(setup_dir, str)
    assert_is(os.path.isdir(setup_dir), True)

   

# Generated at 2022-06-17 19:29:31.903908
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
        assert_not_equal,
        assert_not_is_instance,
        assert_not_is_not_none,
        assert_not_is_none,
        assert_not_is_not,
        assert_not_is,
        assert_not_true,
        assert_not_false,
        assert_not_raises,
        assert_not_raises_regex,
    )


# Generated at 2022-06-17 19:29:42.237533
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:53.198279
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from flutils.configutils import each_sub_command_config

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
                f.write(setup_cfg_contents)
            if setup_commands_cfg_contents:
                with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
                    f.write

# Generated at 2022-06-17 19:30:03.542499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import each_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")
            out = list(each_sub_command_config(path))
            self.assertTrue(out)
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'flutils.test.test_setupcfg')
            self.assertE

# Generated at 2022-06-17 19:30:11.688125
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):

        def test_each_sub_command_config(self):
            setup_dir = get_module_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:30:37.805655
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from io import StringIO
    from unittest import TestCase

    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    class TestEachSubCommandConfig(TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:30:48.788887
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('# setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:31:01.080531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_dir('setup_cfg_test')
            out = list(each_sub_command_config(setup_dir))
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'test.command')
            self.assertEqual(out[0].camel, 'TestCommand')
            self.assertEqual(out[0].description, 'Test command.')
            self.assertEqual(out[0].commands, ('echo "Test command."',))

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:31:13.115735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from unittest.mock import patch
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            with patch('flutils.setuputils.each_sub_command_config') as mock:
                mock.return_value = [
                    SetupCfgCommandConfig(
                        'test_command',
                        'TestCommand',
                        'A test command.',
                        ('echo "Hello, World!"',)
                    )
                ]
                from flutils.setuputils import each_sub_command_config
                for config in each_sub_command_config():
                    self.assertEqual(config.name, 'test_command')
                    self.assertE

# Generated at 2022-06-17 19:31:25.149006
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py, 'w') as f:
                f.write('')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:31:30.975663
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_module_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_dir(__file__)
            setup_dir = os.path.join(setup_dir, 'test_data')
            setup_dir = os.path.join(setup_dir, 'setup_dir')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:31:41.534846
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig.run_tests()

# Generated at 2022-06-17 19:31:49.650419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_from_file,
    )

    # Test with no setup_dir
    setup_dir = None
    with assert_raises(FileNotFoundError):
        list(each_sub_command_config(setup_dir))

    # Test with a setup_dir that does not exist
    setup_dir = 'does_not_exist'

# Generated at 2022-06-17 19:31:58.300912
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_commands_cfg_2 = os.path.join(
                self.setup_dir, 'setup_commands_2.cfg'
            )

# Generated at 2022-06-17 19:32:08.186602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:33.414591
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)

# Generated at 2022-06-17 19:32:43.464975
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = str(tmpdir)
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')
        setup_py_path = os.path.join(tmpdir, 'setup.py')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )

# Generated at 2022-06-17 19:32:56.216672
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import underscore_to_camel

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')

    def _get_setup_dir(setup_dir: str) -> str:
        return os.path.realpath(setup_dir)


# Generated at 2022-06-17 19:33:07.448795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )
    from flutils.pathutils import (
        each_parent_dir,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_executable,
    )

# Generated at 2022-06-17 19:33:11.369730
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir

    setup_dir = get_parent_dir(__file__, 'setup.py')
    for config in each_sub_command_config(setup_dir):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:23.288131
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file_path,
    )
    from flutils.pathutils import (
        each_file_path,
        each_dir_path,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.sysutils import (
        get_python_version,
    )

    test_data_path = get_test_data_path()
    test_data_file_path = get_test_data_file_path()

    for setup_dir in each_dir_path(test_data_path):
        for config in each_sub_command_config(setup_dir):
            assert config.name
            assert config.camel
            assert config.description
           

# Generated at 2022-06-17 19:33:30.141317
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_directory
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_directory(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:33:39.877340
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    setup_dir=get_project_root_dir()
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:33:50.542827
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:33:59.237887
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__file__)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.join(setup_dir, 'setup')
            setup_dir = os.path.join(setup_dir, 'test_project')

# Generated at 2022-06-17 19:34:23.412105
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestCase
    from flutils.testutils.pathutils import (
        get_test_data_path,
        get_test_data_paths,
    )

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            for setup_dir in get_test_data_paths('setup_dir'):
                with self.subTest(setup_dir=setup_dir):
                    for config in each_sub_command_config(setup_dir):
                        self.assertIsInstance(config, SetupCfgCommandConfig)
                        self.assertIsInstance(config.name, str)
                        self.assertIsInstance(config.camel, str)
                        self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:34:35.163146
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:34:46.114591
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version
    from flutils.testutils import run_doctest

    path = get_path_to_this_file(__file__)
    path = os.path.dirname(path)
    path = os.path.join(path, 'test_data', 'setup_commands')
    path = os.path.realpath(path)

    for config in each_sub_command_config(path):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)

# Generated at 2022-06-17 19:34:48.467981
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:35:00.040772
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_in,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_not_in,
        assert_not_equal,
        assert_raises,
    )
    from flutils.pathutils import (
        create_temp_dir,
        create_temp_file,
    )
    from flutils.strutils import (
        random_string,
    )
    from flutils.sysutils import (
        get_temp_dir,
    )
    from flutils.textutils import (
        random_paragraph,
    )
    from flutils.testutils import (
        assert_raises,
    )

# Generated at 2022-06-17 19:35:11.605728
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_commands')
            out = list(each_sub_command_config(setup_dir))
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].name, 'test.command')
            self.assertEqual(out[0].camel, 'TestCommand')
            self.assertEqual(out[0].description, 'Test command.')
            self.assertEqual(
                out[0].commands,
                ('echo "Hello, world!"',)
            )

    TestEachSub

# Generated at 2022-06-17 19:35:21.436874
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:35:32.384649
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:35:41.484935
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import camel_to_underscore

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for config in each_sub_command_config(setup_dir):
            assert isinstance(config, SetupCfgCommandConfig)
            assert isinstance(config.name, str)
            assert isinstance(config.camel, str)
            assert isinstance(config.description, str)
            assert isinstance(config.commands, tuple)
            assert all(isinstance(x, str) for x in config.commands)

# Generated at 2022-06-17 19:35:50.015686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        is_windows,
        is_linux,
        is_mac,
    )
    from flutils.textutils import (
        is_empty,
        is_not_empty,
    )

# Generated at 2022-06-17 19:36:28.446297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        UnitTestCase,
        get_test_data_path,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path(
                'setup_cfg_command_test_data',
                'setup_cfg_command_test_data'
            )
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
               

# Generated at 2022-06-17 19:36:37.447869
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import unittest
    from flutils.pathutils import (
        ensure_dir,
        ensure_file,
    )

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            ensure_dir(self.setup_dir)
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            ensure_file(self.setup_py_path)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:36:46.579405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        each_parent_dir,
        get_project_dir,
    )
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
    )
    from flutils.testutils.pytest import (
        assert_equal,
        assert_in,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_not_equal,
        assert_not_in,
        assert_true,
    )
    from flutils.testutils.pytest import (
        assert_false,
        assert_is_not_none,
        assert_is_none,
        assert_not_equal,
        assert_not_in,
        assert_true,
    )

# Generated at 2022-06-17 19:36:58.259627
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file,
        each_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.pyutils import (
        get_module_name,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )

    test_data_path = get_test_data_path()
    setup_cfg_path = get_test_data_file('setup.cfg')
    setup_commands_cfg_path = get_test_data_file('setup_commands.cfg')
    setup_py_path = get_test_data_

# Generated at 2022-06-17 19:37:06.743984
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _write_setup_cfg(
            tmp_dir: str,
            name: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.%s]\n'
                'description = %s\n'
                'commands = %s\n'
                % (name, name, description, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:37:17.784129
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os
    import os.path

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_text: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_text)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_text: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_text)


# Generated at 2022-06-17 19:37:28.463572
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_is_none,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
    )

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config
            from flutils.setuputils import SetupCfgCommandConfig


# Generated at 2022-06-17 19:37:31.270742
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:37:42.276886
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:37:53.366203
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python\n')