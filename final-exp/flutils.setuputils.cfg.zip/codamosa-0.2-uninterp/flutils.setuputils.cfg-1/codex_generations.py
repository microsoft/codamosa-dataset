

# Generated at 2022-06-17 19:28:42.008499
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestCase.run()

# Generated at 2022-06-17 19:28:52.498040
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version
    from flutils.textutils import indent
    from flutils.textutils import unindent
    from flutils.textutils import wrap_text
    from flutils.textutils import wrap_text_lines

    from flutils.configutils import each_sub_command_config

    setup_dir = os.path.dirname(get_path_to_this_file())
    for config in each_sub_command_config(setup_dir):
        print(config.name)
        print(config.camel)
        print(config.description)
        print(config.commands)
        print()


# Generated at 2022-06-17 19:29:01.976959
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail(
                    "Unable to find the directory that contains the "
                    "'setup.py' file."
                )
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:29:10.717361
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )
    from flutils.sysutils import (
        get_python_version,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )


# Generated at 2022-06-17 19:29:19.989571
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.pathutils import get_parent_dir

    setup_dir = get_parent_dir(__file__)
    sys.path.insert(0, setup_dir)
    try:
        import setup_commands
    finally:
        sys.path.pop(0)

    for config in each_sub_command_config(setup_dir):
        assert config.name in setup_commands.__all__
        assert hasattr(setup_commands, config.camel)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:29:29.105631
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.strutils import camel_to_underscore
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )

    # Test setup_dir is None
    setup_dir = None
    assert_is_none(setup_dir)
    assert_raises(FileNotFoundError, each_sub_command_config, setup_dir)

    # Test setup_dir is not None
    setup_dir = get_module_path(__name__)


# Generated at 2022-06-17 19:29:31.993757
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    setup_dir = os.path.dirname(__file__)
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands

# Generated at 2022-06-17 19:29:41.450646
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir

# Generated at 2022-06-17 19:29:52.607055
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.TemporaryDirectory()
            self.setup_dir_path = self.setup_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir_path, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir_path, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir_path, 'setup.py')

# Generated at 2022-06-17 19:30:02.527795
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'description = Test command\n'
                'commands = %s\n'
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:30:21.839462
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import each_parent_dir

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for config in each_sub_command_config(setup_dir):
            print(config)

    # Test with a setup.cfg file that does NOT contain a 'setup.command'
    # section.
    with tempfile.TemporaryDirectory() as tmpdir:
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                "[metadata]\n"
                "name = flutils\n"
            )
        _test_each

# Generated at 2022-06-17 19:30:28.456536
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:30:32.950310
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_each_sub_command_config,
        assert_each_sub_command_config_exception,
    )
    assert_each_sub_command_config(each_sub_command_config)
    assert_each_sub_command_config_exception(each_sub_command_config)

# Generated at 2022-06-17 19:30:41.366477
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            root_dir = get_project_root_dir(__file__)
            for config in each_sub_command_config(root_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:30:50.901921
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_parent_dir(__file__, '..', '..', '..')
            path = os.path.join(path, 'setup.py')
            path = os.path.realpath(path)
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:31:00.498685
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys

    setup_cfg_path = os.path.join(
        os.path.dirname(__file__),
        'test_data',
        'setup.cfg'
    )
    setup_commands_cfg_path = os.path.join(
        os.path.dirname(__file__),
        'test_data',
        'setup_commands.cfg'
    )
    setup_py_path = os.path.join(
        os.path.dirname(__file__),
        'test_data',
        'setup.py'
    )

    with tempfile.TemporaryDirectory() as tmpdir:
        shutil.copy(setup_cfg_path, tmpdir)

# Generated at 2022-06-17 19:31:12.632459
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os

    def _get_setup_cfg(name: str, commands: str) -> str:
        return textwrap.dedent(
            """\
            [metadata]
            name = {name}

            [setup.command.test]
            commands = {commands}
            """
        ).format(name=name, commands=commands)

    def _get_setup_commands_cfg(commands: str) -> str:
        return textwrap.dedent(
            """\
            [setup.command.test]
            commands = {commands}
            """
        ).format(commands=commands)


# Generated at 2022-06-17 19:31:20.122426
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_project_root_dir()
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for cmd in config.commands:
                    self.assertIsInstance(cmd, str)

    Test().run()


if __name__ == '__main__':
    test

# Generated at 2022-06-17 19:31:30.447215
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys

    def _write_setup_cfg(
            tmpdir: str,
            setup_cfg: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg)

    def _write_setup_commands_cfg(
            tmpdir: str,
            setup_commands_cfg: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg)


# Generated at 2022-06-17 19:31:40.982090
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import TempDir

    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py = os.path.join(setup_dir, 'setup.py')
        with open(setup_py, 'w') as f:
            f.write('')
        setup_cfg = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg, 'w') as f:
            f.write('''\
[metadata]
name = flutils
''')
        setup_commands_cfg = os.path.join(setup_dir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:32:11.986648
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('commands = \\\n')
            for command in commands:
                f.write('    %s\n' % command)


# Generated at 2022-06-17 19:32:22.743656
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('')

# Generated at 2022-06-17 19:32:29.893325
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:32:41.174627
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: Tuple[str, ...]
    ) -> str:
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write("[metadata]\n")
            f.write("name = %s\n" % name)
            f.write("\n")
            f.write("[setup.command.foo]\n")
            f.write("command = %s\n" % commands[0])
            f.write("\n")
            f.write("[setup.command.bar]\n")

# Generated at 2022-06-17 19:32:52.147260
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    from flutils.strutils import underscore_to_camel

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = '',
    ) -> None:
        command_name = command_name or name
        command_name = command_name.replace('-', '_')
        command_name = underscore_to_camel(command_name, lower_first=False)
        command_name = command_name.replace(' ', '_')

# Generated at 2022-06-17 19:33:00.152659
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitCase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

    TestEachSubCommandConfig.run_tests()



# Generated at 2022-06-17 19:33:07.236181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_this_file(__file__)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup

# Generated at 2022-06-17 19:33:14.241824
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:33:24.212335
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_path(__file__)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)
            setup_dir = os.path.dirname(setup_dir)

# Generated at 2022-06-17 19:33:36.652955
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as fp:
            fp.write(textwrap.dedent(
                """\
                [metadata]
                name = %s
                """ % name
            ))
        with open(os.path.join(setup_dir, 'setup_commands.cfg'), 'w') as fp:
            fp.write(textwrap.dedent(
                """\
                [setup.command.test]
                commands =
                    %s
                """ % '\n'.join(commands)
            ))


# Generated at 2022-06-17 19:34:30.754777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.pathutils import get_path_to_this_file

            path = get_path_to_this_file()
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.join(path, 'setup.py')
            path = os.path.realpath(path)
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIs

# Generated at 2022-06-17 19:34:39.038454
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    from flutils.configutils import each_sub_command_config

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: Optional[str] = None,
            description: Optional[str] = None,
            name_override: Optional[str] = None
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            if commands:
                f.write('\n')
                f.write('[setup.command.test]\n')

# Generated at 2022-06-17 19:34:48.870791
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '[setup.command.test]\n'
                'commands = %s\n'
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:35:00.081378
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.fileutils import (
        create_dir,
        create_file,
        remove_dir,
        remove_file,
    )
    from flutils.testutils.testutils import (
        assert_raises_file_not_found_error,
        assert_raises_not_a_directory_error,
    )

    test_dir = get_test_data_dir()
    setup_dir = os.path.join(test_dir, 'setup_dir')

# Generated at 2022-06-17 19:35:11.605716
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with no setup_dir
    out = each_sub_command_config()
    assert_is_instance(out, Generator)
    out = list(out)
    assert_is_instance(out, list)
    assert_equal(len(out), 1)
    assert_is_instance(out[0], SetupCfgCommandConfig)
    assert_equal(out[0].name, 'flutils')
    assert_equal(out[0].camel, 'Flutils')

# Generated at 2022-06-17 19:35:21.835463
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_test_data_path

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }
            for config in _each_setup_cfg_command(parser, format_kwargs):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)

# Generated at 2022-06-17 19:35:34.401297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:35:46.865006
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = ''
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '[setup.command.%s]\n'
                'command = %s\n'
                'description = %s\n'
                % (name, command_name, '\n'.join(commands), description)
            )


# Generated at 2022-06-17 19:35:59.218355
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:36:06.825735
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for sub_command in each_sub_command_config(setup_dir):
                self.assertIsInstance(sub_command, SetupCfgCommandConfig)
                self.assertIsInstance(sub_command.name, str)
                self.assertIsInstance(sub_command.camel, str)
                self.assertIsInstance(sub_command.description, str)
                self.assertIsInstance(sub_command.commands, tuple)

# Generated at 2022-06-17 19:36:38.879871
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:36:47.425849
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_dir
    from flutils.strutils import camel_to_underscore
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
    )
    from flutils.testutils.fileutils import (
        assert_file_exists,
        assert_file_not_exists,
    )
    from flutils.testutils.pathutils import (
        assert_dir_exists,
        assert_dir_not_exists,
    )

    test_data_dir = get_test_data_dir()
    setup_

# Generated at 2022-06-17 19:36:59.113639
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_script_dir,
        get_script_name,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.textutils import (
        get_indent,
    )
    from flutils.logutils import (
        get_logger,
    )
    from flutils.configutils import (
        get_config,
    )

    logger = get_logger(__name__)
    config = get_config(__name__)

    script_dir = get_script_dir(__file__)
    script_name = get_script_name(__file__)

# Generated at 2022-06-17 19:37:07.574557
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('name = foo\n')
            f.write('description = foo command\n')
            f.write('commands = %s\n' % '\n'.join(commands))
            f.write('\n')

# Generated at 2022-06-17 19:37:18.150562
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:37:28.685744
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_dir_in_dir,
    )
    from flutils.strutils import (
        camel_to_snake,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        each_line,
    )
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_dir_in_dir,
    )

# Generated at 2022-06-17 19:37:40.358969
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.shellutils import (
        run_shell_command,
    )

# Generated at 2022-06-17 19:37:47.241927
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase

    class TestEachSubCommandConfig(TempDirTestCase):
        def test_each_sub_command_config(self):
            setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            with open(setup_cfg, 'w') as f:
                f.write(
                    '''\
[metadata]
name = flutils

[setup.command.test]
command =
    pytest {setup_dir}
    pytest {setup_dir}/tests
'''
                )
            with open(os.path.join(self.temp_dir, 'setup.py'), 'w') as f:
                f.write(
                    '''\
from setuptools import setup

setup()
'''
                )

# Generated at 2022-06-17 19:37:59.454382
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()



# Generated at 2022-06-17 19:38:10.186818
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()