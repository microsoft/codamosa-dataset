

# Generated at 2022-06-17 19:28:48.994553
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    from textwrap import dedent

    from flutils.pathutils import each_parent_dir

    def _write_setup_cfg(
            tmpdir: str,
            setup_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)

    def _write_setup_commands_cfg(
            tmpdir: str,
            setup_commands_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_contents)


# Generated at 2022-06-17 19:28:58.413299
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__name__)
            for config in each_sub_command_config(setup_dir):
                self.assertTrue(isinstance(config, SetupCfgCommandConfig))
                self.assertTrue(isinstance(config.name, str))
                self.assertTrue(isinstance(config.camel, str))
                self.assertTrue(isinstance(config.description, str))
                self.assertTrue(isinstance(config.commands, tuple))
                for command in config.commands:
                    self

# Generated at 2022-06-17 19:29:07.980853
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _setup_cfg(
            name: str,
            commands: Optional[str] = None,
            description: Optional[str] = None,
            setup_cfg_path: Optional[str] = None,
            setup_commands_cfg_path: Optional[str] = None
    ) -> None:
        if setup_cfg_path is None:
            setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        if setup_commands_cfg_path is None:
            setup_commands_cfg_path = os.path.join(temp_dir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:29:19.626352
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_path(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:29:28.903420
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                'description = %s\n'
                '\n'
                '[setup.command.%s]\n'
                'command = %s\n'
                % (name, description, name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:29:39.258737
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file

# Generated at 2022-06-17 19:29:49.773620
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path(__file__, '..', '..', '..', '..')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test

# Generated at 2022-06-17 19:30:00.602965
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        TempDirTestCase,
        TempFileTestCase,
    )
    from flutils.pathutils import (
        each_file,
        each_file_path,
        each_file_path_with_dir,
        each_file_with_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )

    class TestCase(TempDirTestCase, TempFileTestCase):
        def setUp(self):
            super().setUp()
            self.setup_dir = self.temp_dir.path
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:30:10.008455
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()



# Generated at 2022-06-17 19:30:19.086424
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_parent_dir(__file__)):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test_each_sub_command_config()

# Generated at 2022-06-17 19:30:43.494504
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                self.assertTrue(config.commands)

# Generated at 2022-06-17 19:30:58.026856
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.tmpdir, 'setup_dir')
            os.mkdir(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:31:06.136709
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.textutils import (
        get_text_width,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )

# Generated at 2022-06-17 19:31:11.605177
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:31:23.989577
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.setuputils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    def _write_setup_cfg(
            setup_dir: str,
            setup_cfg_content: str,
            setup_commands_cfg_content: str = ''
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_content)
        if setup_commands_cfg_content:
            with open(os.path.join(setup_dir, 'setup_commands.cfg'), 'w') as f:
                f.write(setup_commands_cfg_content)


# Generated at 2022-06-17 19:31:32.642722
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_is_none,
        assert_is_true,
        assert_is_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )


# Generated at 2022-06-17 19:31:40.281725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version

    setup_dir = os.path.dirname(get_path_to_this_file())
    for config in each_sub_command_config(setup_dir):
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)
            assert command.startswith('python')

    # Test the 'setup_commands.cfg' file.

# Generated at 2022-06-17 19:31:49.047255
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')


# Generated at 2022-06-17 19:31:57.260431
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    path = get_path_to_this_file(__file__)
    path = os.path.dirname(path)
    path = os.path.join(path, '..', '..', '..', '..', 'tests', 'data')
    path = os.path.realpath(path)
    path = os.path.join(path, 'setup_commands')
    for config in each_sub_command_config(path):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:31:58.400646
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)

# Generated at 2022-06-17 19:32:28.800493
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import camel_to_underscore
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.assertutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
    )
    from flutils.testutils.fileutils import (
        assert_file_exists,
        assert_file_not_exists,
    )

# Generated at 2022-06-17 19:32:40.472642
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected_configs: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
                f.write(setup_cfg_contents)
            with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
                f.write(setup_commands_cfg_contents)
            configs = list(each_sub_command_config(tmpdir))

# Generated at 2022-06-17 19:32:47.095448
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from pathlib import Path
    from flutils.pathutils import each_parent_dir

    for path in each_parent_dir(Path(__file__)):
        if path.name == 'tests':
            break
    else:
        raise FileNotFoundError(
            "Unable to find the 'tests' directory."
        )
    sys.path.insert(0, str(path))
    from tests.test_setup_commands import (
        test_each_sub_command_config as _test_each_sub_command_config
    )
    _test_each_sub_command_config()

# Generated at 2022-06-17 19:32:56.574791
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase
    from flutils.testutils import UnitTestSuite

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:33:07.852336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_true,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.textutils import (
        get_indent,
    )
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_true,
    )

# Generated at 2022-06-17 19:33:15.445249
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(get_path_to_this_file())
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommand

# Generated at 2022-06-17 19:33:24.813744
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import pytest
    from flutils.pathutils import get_parent_dir

    test_dir = os.path.join(get_parent_dir(__file__), 'test_data')
    test_dir = os.path.join(test_dir, 'setup_cfg_test')
    test_dir = os.path.join(test_dir, 'setup_cfg_test')
    test_dir = os.path.join(test_dir, 'setup_cfg_test')
    test_dir = os.path.join(test_dir, 'setup_cfg_test')

    with pytest.raises(FileNotFoundError):
        list(each_sub_command_config(test_dir))

    test_dir = os.path.join(test_dir, 'setup_cfg_test')

# Generated at 2022-06-17 19:33:31.459568
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    print(config)

    unittest.main()

# Generated at 2022-06-17 19:33:39.087676
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_not_raises,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.testutils import (
        get_test_data_dir,
    )

    from flutils.sysutils import (
        get_python_executable,
    )

    from flutils.textutils import (
        get_random_string,
    )

   

# Generated at 2022-06-17 19:33:50.089142
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string
    from flutils.sysutils import get_python_executable
    from flutils.sysutils import get_python_version
    from flutils.sysutils import get_python_version_tuple
    from flutils.sysutils import get_python_version_tuple_str
    from flutils.sysutils import get_python_version_str
    from flutils.sysutils import get_python_version_info
    from flutils.sysutils import get_python_version_info_str
    from flutils.sysutils import get_python_version_info_tuple
    from flutils.sysutils import get_python_version_info_tuple_str

# Generated at 2022-06-17 19:34:39.641006
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_test_data_path,
    )
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_test_data_path,
    )
    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_test_data_path,
    )

    # Test the setup_dir is None
    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        None
    )



# Generated at 2022-06-17 19:34:49.323210
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

    Test().run()


if __name__ == '__main__':
    test_

# Generated at 2022-06-17 19:35:00.550590
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from pathlib import Path
    from flutils.pathutils import each_parent_dir

    def _get_setup_dir(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> str:
        if setup_dir:
            return str(setup_dir)
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            basename = os.path.basename(fs.filename)
            if basename == 'setup.py':
                return str(os.path.dirname(fs.filename))
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )


# Generated at 2022-06-17 19:35:11.700743
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:35:21.904346
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from io import StringIO
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.out = StringIO()
            self.err = StringIO()
            self.patch_stdout = patch.object(sys, 'stdout', self.out)
            self.patch_stderr = patch.object(sys, 'stderr', self.err)
            self.patch_stdout.start()
            self.patch_stderr.start()

        def tearDown(self):
            self.patch_stdout.stop()
            self.patch_stderr.stop()

        def test_each_sub_command_config(self):
            import os

# Generated at 2022-06-17 19:35:34.494294
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            setup_dir = os.path.dirname(__file__)
            setup_dir = os.path.join(setup_dir, '..', '..')
            setup_dir = os.path.realpath(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:35:42.716085
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:35:50.610716
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdin,
        capture_sys_argv,
    )
    from flutils.sysutils import (
        get_script_dir,
        get_script_name,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_blank,
        is_not_blank,
    )

    with capture_stdout() as stdout, capture_stderr() as stderr, \
            capture_stdin() as stdin, capture_sys_argv() as sys_argv:
        sys_argv.append(__file__)
        sys_argv.append

# Generated at 2022-06-17 19:36:01.017029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            import tempfile
            import shutil
            import textwrap

            with tempfile.TemporaryDirectory() as tmpdir:
                setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-17 19:36:08.908784
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.sysutils import get_python_executable

    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('#!/usr/bin/env python\n')
            f.write('from setuptools import setup\n')
            f.write('setup()\n')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:37:41.786776
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()


if __name__ == '__main__':
    test_

# Generated at 2022-06-17 19:37:53.087890
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_cfg_test')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:38:02.969504
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:38:13.244570
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_module_path(__name__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:38:23.784462
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TestCase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            for path in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(path, 'setup.py')):
                    break
            else:
                self.fail('Unable to find the setup.py file.')

            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)