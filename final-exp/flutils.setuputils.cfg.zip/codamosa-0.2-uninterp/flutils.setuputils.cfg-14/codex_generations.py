

# Generated at 2022-06-17 19:28:46.313133
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def test_each_sub_command_config(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                tmpdir = str(tmpdir)
                setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')

# Generated at 2022-06-17 19:28:57.886996
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            self.assertTrue(os.path.isfile(path))
            path = os.path.dirname(path)
            self.assertTrue(os.path.isdir(path))
            self.assertTrue(os.path.isfile(os.path.join(path, 'setup.py')))
            self.assertTrue(os.path.isfile(os.path.join(path, 'setup.cfg')))

# Generated at 2022-06-17 19:29:01.237531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:29:11.372884
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test_each_sub_command_config()



# Generated at 2022-06-17 19:29:22.104877
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_empty,
        assert_is_true,
        assert_is_false,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_empty,
        is_not_empty,
    )

    # Test the default setup_dir
    setup_dir = None
    setup_dir = _prep_setup_dir(setup_dir)
    assert_is_not_empty(setup_dir)
    assert_is_true

# Generated at 2022-06-17 19:29:32.172675
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    from unittest.mock import patch

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        setup_py = tmpdir / 'setup.py'
        setup_cfg = tmpdir / 'setup.cfg'
        setup_commands_cfg = tmpdir / 'setup_commands.cfg'
        setup_py.write_text(dedent("""\
            from setuptools import setup
            setup()
        """))
        setup_cfg.write_text(dedent("""\
            [metadata]
            name = my_project
        """))

# Generated at 2022-06-17 19:29:42.270353
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:29:51.293713
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_is_not_empty,
        assert_is_empty,
        assert_not_equal,
        assert_raises,
        assert_not_raises,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.strutils import (
        is_not_empty,
        is_empty,
    )


# Generated at 2022-06-17 19:30:02.632037
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import TempDir
    from flutils.testutils.pytest import raises_file_not_found_error

    with raises_file_not_found_error():
        each_sub_command_config()

    with TempDir() as td:
        setup_dir = os.path.join(td, 'setup_dir')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('# setup.py')
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\nname = foo\n')

# Generated at 2022-06-17 19:30:11.356369
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import underscore_to_camel

    def _get_setup_dir() -> str:
        for fs in extract_stack():
            fs = cast(FrameSummary, fs)
            basename = os.path.basename(fs.filename)
            if basename == 'setup.py':
                return str(os.path.dirname(fs.filename))
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )

    def _get_setup_cfg_path() -> str:
        return os.path.join(_get_setup_dir(), 'setup.cfg')


# Generated at 2022-06-17 19:30:38.503532
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:30:48.661767
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.testutils.pathutils import (
        get_test_data_path,
        get_test_data_path_parts,
    )
    from flutils.testutils.testutils import (
        assert_generator_equal,
        assert_generator_raises,
    )

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)

# Generated at 2022-06-17 19:31:00.649931
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_path('setup_dir')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:31:12.746451
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        """Unit test for function each_sub_command_config."""

        def test_each_sub_command_config(self):
            """Test function each_sub_command_config."""
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self

# Generated at 2022-06-17 19:31:24.738469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_caller_dir

# Generated at 2022-06-17 19:31:32.887962
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    from flutils.pathutils import each_parent_dir

    def _get_setup_cfg_path(
            setup_dir: str
    ) -> str:
        for path in each_parent_dir(setup_dir):
            path = os.path.join(path, 'setup.cfg')
            if os.path.isfile(path):
                return path
        raise FileNotFoundError(
            "Unable to find the setup.cfg file in the given 'setup_dir' "
            "of %r." % setup_dir
        )

    def _get_setup_cfg_name(
            setup_dir: str
    ) -> str:
        parser = ConfigParser()
        parser.read(_get_setup_cfg_path(setup_dir))
        return _get

# Generated at 2022-06-17 19:31:40.354144
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.TemporaryDirectory()
            self.setup_dir_path = self.setup_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir_path, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir_path, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir_path, 'setup.py')
            self.home = os.path.expanduser('~')
            self.name = 'test_project'

# Generated at 2022-06-17 19:31:50.071550
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_file,
    )
    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )
    from flutils.testutils import (
        each_test_data_file,
        each_test_data_file_recursive,
    )
    from flutils.testutils import (
        each_test_data_dir,
        each_test_data_dir_recursive,
    )
    from flutils.testutils import (
        each_test_data_path,
        each_test_data_path_recursive,
    )

# Generated at 2022-06-17 19:32:01.783048
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:32:10.425718
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module

# Generated at 2022-06-17 19:32:46.600120
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.testutils import (
        get_test_data_path,
        get_test_data_paths,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    from flutils.setuputils.setuputils import (
        _get_name,
        _validate_setup_dir,
    )

    from flutils.setuputils.setuputils import (
        _each_setup_cfg_command,
        _each_setup_cfg_command_section,
    )

    from flutils.setuputils.setuputils import (
        _prep_setup_dir,
    )



# Generated at 2022-06-17 19:32:57.320767
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as fh:
                fh.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:33:01.320933
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_dir

    for config in each_sub_command_config(get_project_dir()):
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:33:11.719939
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )

    # Test with a setup_dir that does NOT exist
    assert_raises(
        FileNotFoundError,
        each_sub_command_config,
        setup_dir='/does/not/exist'
    )

    # Test with a setup_dir that is NOT a directory
    assert_raises(
        NotADirectoryError,
        each_sub_command_config,
        setup_dir='/etc/passwd'
    )

    # Test with a setup_dir that does NOT contain a setup

# Generated at 2022-06-17 19:33:23.533952
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
        assert_false,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_python_version,
    )
    from flutils.strutils import (
        is_empty,
    )

    # Test for no setup.cfg file
    with assert_raises(FileNotFoundError):
        list(each_sub_command_config(get_parent_dir(__file__)))

    # Test for no setup.py file

# Generated at 2022-06-17 19:33:36.168463
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('#')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\nname=test_pkg\n')
        setup_commands_cfg_

# Generated at 2022-06-17 19:33:49.011409
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_sub_dirs,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_output_dir,
    )
    from flutils.testutils.fileutils import (
        create_file,
        create_file_from_template,
    )
    from flutils.testutils.testutils import (
        assert_equal_files,
        assert_equal_paths,
        assert_equal_str,
        assert_equal_strs,
        assert_equal_tuples,
        assert_exception,
        assert_false,
        assert_true,
    )

    test_data_dir = get_test_data_dir()
    test_output_dir = get_test

# Generated at 2022-06-17 19:33:56.150763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:34:03.696953
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:34:12.833531
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from flutils.pathutils import get_path_parts

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')


# Generated at 2022-06-17 19:35:02.471836
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import TempDir
    from flutils.testutils.fileutils import (
        create_file,
        create_file_with_contents,
    )
    from flutils.testutils.testutils import (
        assert_exception,
        assert_exception_message,
        assert_generator_equal,
        assert_generator_length,
        assert_is_instance,
        assert_is_none,
        assert_is_not_none,
        assert_is_not_string,
        assert_is_string,
        assert_not_exception,
        assert_not_exception_message,
        assert_raises,
        assert_raises_message,
        assert_true,
    )


# Generated at 2022-06-17 19:35:13.992686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_dir = os.path.join(self.temp_dir, 'setup_dir')
            os.makedirs(self.setup_dir)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:35:23.575077
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.testcase import (
        BaseTestCase,
        TestCase,
    )

    class TestEachSubCommandConfig(BaseTestCase):
        def test_each_sub_command_config(self):
            test_dir = get_test_data_dir(__file__, 'test_each_sub_command_config')
            setup_dir = get_parent_dir(test_dir)
            name = get_parent_dir_name(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self

# Generated at 2022-06-17 19:35:29.818538
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import textwrap

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: Optional[List[str]] = None,
            description: Optional[str] = None
    ) -> None:
        if commands is None:
            commands = []
        if description is None:
            description = ''
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent('''\
                [metadata]
                name = %s

                [setup.command.foo]
                command = %s
                description = %s
            ''' % (name, '\n'.join(commands), description)))


# Generated at 2022-06-17 19:35:39.136181
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.join(path, '..', '..', '..', 'tests', 'data')
            path = os.path.realpath(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)

# Generated at 2022-06-17 19:35:45.146023
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_python_executable,
        get_python_version,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_spaces,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )

# Generated at 2022-06-17 19:35:55.378691
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_path
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_sub_path,
    )

# Generated at 2022-06-17 19:36:02.847602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestCase
    from flutils.testutils import UnitTestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            from flutils.configutils import each_sub_command_config
            from flutils.configutils import SetupCfgCommandConfig

            def _test_each_sub_command_config(
                    setup_dir: str,
                    expected_configs: List[SetupCfgCommandConfig]
            ) -> None:
                configs = list(each_sub_command_config(setup_dir))
                self.assertEqual(configs, expected_configs)


# Generated at 2022-06-17 19:36:14.784229
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
        assert_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_empty,
        is_not_empty,
    )
    from flutils.sysutils import (
        is_windows,
    )
    from flutils.textutils import (
        each_line,
    )

# Generated at 2022-06-17 19:36:22.257174
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase

    class TestCase(UnitCase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestCase.run()

# Generated at 2022-06-17 19:38:01.979062
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:38:11.112419
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(sys.path[0]):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:38:23.177127
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_dir_path,
        each_file_path,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )

    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )

    # Test setup.cfg file