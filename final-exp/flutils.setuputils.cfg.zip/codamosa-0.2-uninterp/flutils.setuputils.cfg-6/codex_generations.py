

# Generated at 2022-06-17 19:28:49.210801
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.strutils import (
        is_empty,
        is_not_empty,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.textutils import (
        is_blank,
        is_not_blank,
    )

# Generated at 2022-06-17 19:28:58.777942
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    get_parent_dir(__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

# Generated at 2022-06-17 19:29:08.072625
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    from pathlib import Path

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_contents)


# Generated at 2022-06-17 19:29:13.369996
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:29:22.917805
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )
    from flutils.pathutils import (
        get_module_path,
        get_module_dir,
    )

# Generated at 2022-06-17 19:29:32.607530
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    from flutils.configutils import each_sub_command_config

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """\
                [metadata]
                name = %s
                """ % name
            ))

# Generated at 2022-06-17 19:29:42.297608
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_raises_exc,
        assert_raises_msg,
        assert_raises_exc_msg,
        assert_raises_regex_msg,
        assert_raises_regex_exc,
        assert_raises_regex_exc_msg,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

# Generated at 2022-06-17 19:29:51.294974
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                self.assertGreater(len(config.commands), 0)


# Generated at 2022-06-17 19:30:01.033200
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('name = foo\n')
            f.write('description = foo command\n')
            f.write('commands = \\\n')
            for command in commands:
                f.write('    %s\n' % command)


# Generated at 2022-06-17 19:30:10.369813
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_executable

# Generated at 2022-06-17 19:30:31.012676
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class _Test(UnitTestBase):
        def test_each_sub_command_config(self):
            for setup_dir in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(setup_dir, 'setup.py')):
                    break
            else:
                self.fail('Unable to find the directory that contains '
                          'the setup.py file.')

            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:30:40.349251
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:30:50.418779
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    from flutils.pathutils import get_project_root_dir
    from flutils.strutils import camel_to_underscore
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.assertutils import (
        assert_equal,
        assert_in,
        assert_not_in,
        assert_not_none,
        assert_true,
    )

# Generated at 2022-06-17 19:31:00.450438
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_path_to_data_file

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_data_file(
                'flutils', 'test', 'data', 'setup_commands'
            )
            out = list(each_sub_command_config(setup_dir))

# Generated at 2022-06-17 19:31:12.593527
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from flutils.testutils import TestCase
    from flutils.sysutils import get_module_path

    class TestEachSubCommandConfig(TestCase):

        def test_each_sub_command_config(self):
            path = get_module_path(sys.modules[__name__])
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data')
            path = os.path.join(path, 'setup_commands')
            path = os.path.join(path, 'setup_commands_test_1')
            path = os.path.realpath(path)
            out = tuple(each_sub_command_config(path))

# Generated at 2022-06-17 19:31:24.634164
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import to_snake_case
    from flutils.sysutils import get_script_name
    from flutils.testutils import (
        get_test_data_path,
        get_test_data_path_list,
    )
    from flutils.textutils import (
        each_line,
        each_line_reversed,
        get_line_count,
    )
    from flutils.timeutils import (
        get_current_datetime,
        get_current_time,
    )
    from flutils.versionutils import get_version

    from flutils_cli.cli import (
        get_cli_parser,
        main,
    )


# Generated at 2022-06-17 19:31:30.769008
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        TestCase,
        get_test_data_path,
    )

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            parser = ConfigParser()
            parser.read(path)
            format_kwargs = {
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~'),
                'name': 'flutils'
            }
            out = list(_each_setup_cfg_command(parser, format_kwargs))

# Generated at 2022-06-17 19:31:39.391297
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 19:31:48.594284
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_not_empty_generator,
        assert_is_empty_generator,
    )
    from flutils.testutils.pathutils import (
        assert_is_not_empty_dir,
        assert_is_not_empty_file,
    )
    from flutils.testutils.strutils import assert_is_not_empty_str

    path = get_path_to_module(__name__)
    path = os.path.dirname(path)
    path = os.path.dirname(path)
    path = os.path.dirname

# Generated at 2022-06-17 19:31:57.964932
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import textwrap

    from flutils.pathutils import (
        get_parent_dir,
        get_sub_dirs,
    )

    from flutils.testutils import (
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_true,
    )

    from flutils.testutils.pytest import (
        assert_equal,
        assert_in,
        assert_not_in,
    )

    from flutils.testutils.pytest import (
        assert_is_instance,
        assert_is_none,
        assert_is_not_none,
    )


# Generated at 2022-06-17 19:32:30.326649
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import TempDir

    with TempDir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
        os.makedirs(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('# setup.py')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\nname = test_pkg\n')

# Generated at 2022-06-17 19:32:34.410529
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    from flutils.strutils import underscore_to_camel

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            expected: List[SetupCfgCommandConfig],
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_py_path = os.path.join(tmpdir, 'setup.py')

# Generated at 2022-06-17 19:32:44.452782
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('name = foo\n')
            f.write('description = foo description\n')
            f.write('commands = \\\n')
            for command in commands:
                f.write('    %s\n' % command)

# Generated at 2022-06-17 19:32:56.574416
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """\
                [metadata]
                name = %s
                [setup.command.test]
                command =
                    %s
                """ % (name, '\n                    '.join(commands))
            ))


# Generated at 2022-06-17 19:33:07.853012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:33:15.445411
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_content: str
    ) -> str:
        setup_cfg_path = os.path.join(tmp_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(setup_cfg_content)
        return setup_cfg_path

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_content: str
    ) -> str:
        setup_commands_cfg_path = os.path.join(tmp_dir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:33:24.813813
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.testutils.pytest import (
        assert_raises_regex,
        assert_raises_regexp,
    )

    setup_dir = get_parent_dir(__file__)
    assert_is_instance(setup_dir, str)
    assert_is_not_none(setup_dir)

# Generated at 2022-06-17 19:33:37.101522
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('# setup.py')

# Generated at 2022-06-17 19:33:49.452600
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):

        def test_each_sub_command_config(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                tmpdir = os.path.realpath(tmpdir)
                setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
                setup_commands_cfg_path = os.path.join(
                    tmpdir, 'setup_commands.cfg'
                )

# Generated at 2022-06-17 19:33:58.602931
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_greater,
        assert_greater_equal,
        assert_less,
        assert_less_equal,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_grandparent_dir,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )

    setup

# Generated at 2022-06-17 19:34:53.304460
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_python_executable,
        get_python_version,
    )
    from flutils.pathutils import (
        get_temp_dir,
        get_temp_file,
    )
    from flutils.strutils import (
        get_random_string,
    )
    from flutils.textutils import (
        get_random_text,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_file,
    )
    from flutils.testutils import (
        get_test_data_path,
    )
   

# Generated at 2022-06-17 19:35:03.074099
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _write_setup_cfg(
            path: str,
            name: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:35:14.568997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:35:23.873439
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestCase(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestCase.run()

# Generated at 2022-06-17 19:35:30.631004
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):

        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('# -*- coding: utf-8 -*-\n')

# Generated at 2022-06-17 19:35:39.623564
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:35:49.328537
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.sysutils import get_temp_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            with get_temp_dir() as temp_dir:
                setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')

# Generated at 2022-06-17 19:35:59.115455
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Test function each_sub_command_config."""
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:
        setup_dir = os.path.join(tmpdir, 'setup')
        os.mkdir(setup_dir)
        with open(os.path.join(setup_dir, 'setup.py'), 'w') as f:
            f.write('#!/usr/bin/env python3\n')

# Generated at 2022-06-17 19:36:07.898262
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):

        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', 'test']):
                with patch.object(os.path, 'realpath') as mock_realpath:
                    mock_realpath.return_value = '/path/to/setup.py'
                    with patch.object(os.path, 'expanduser') as mock_expanduser:
                        mock_expanduser.return_value = '/home/user'
                        with patch.object(os.path, 'isfile') as mock_isfile:
                            mock_isfile.return_value = True

# Generated at 2022-06-17 19:36:17.258228
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as td:
        td.write('setup.py', '#!/usr/bin/env python')
        td.write('setup.cfg', '''
[metadata]
name = flutils
''')
        td.write('setup_commands.cfg', '''
[setup.command.test]
name = test
description = Run the unit tests.
command = python -m unittest discover -s {setup_dir}/tests -p "*_test.py"
''')

# Generated at 2022-06-17 19:38:06.225478
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestCase
    from flutils.testutils import TestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config
            from flutils.setuputils import SetupCfgCommandConfig

            def _test_each_sub_command_config(
                    setup_dir: Optional[Union[os.PathLike, str]] = None
            ) -> None:
                out = list(each_sub_command_config(setup_dir))
                self.assertIsInstance(out, list)
                self.assertTrue(out)
                for item in out:
                    self.assertIsInstance(item, SetupCfgCommandConfig)
                    self.assertIsInstance(item.name, str)

# Generated at 2022-06-17 19:38:13.334830
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_python_executable,
        get_python_version,
    )
    from flutils.pathutils import (
        get_project_root_dir,
        get_project_src_dir,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_str,
    )
    from flutils.setuputils import (
        get_setup_dir,
        get_setup_py_path,
    )
    from flutils.setuputils import (
        get_setup_cfg_path,
        get_setup_cfg_name,
    )

# Generated at 2022-06-17 19:38:23.814072
# Unit test for function each_sub_command_config