

# Generated at 2022-06-17 19:28:45.121929
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module

# Generated at 2022-06-17 19:28:57.465763
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os

    def _write_setup_cfg(
            tmpdir: str,
            setup_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_contents)

    def _write_setup_commands_cfg(
            tmpdir: str,
            setup_commands_cfg_contents: str
    ) -> None:
        with open(os.path.join(tmpdir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_contents)


# Generated at 2022-06-17 19:29:06.561822
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(TempDirTestCase):

        def test_each_sub_command_config(self):
            setup_dir = os.path.join(self.temp_dir, 'setup')
            os.mkdir(setup_dir)
            with open(os.path.join(setup_dir, 'setup.py'), 'w') as fp:
                fp.write('# setup.py')
            with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as fp:
                fp.write('[metadata]\nname = test\n')

# Generated at 2022-06-17 19:29:18.014191
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    with tempfile.TemporaryDirectory() as tempdir:
        setup_dir = os.path.join(tempdir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('# setup.py')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(textwrap.dedent("""
                [metadata]
                name = test_pkg
            """))

# Generated at 2022-06-17 19:29:27.835979
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    import tempfile

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:29:37.270091
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_script_dir,
        get_script_name,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.textutils import (
        get_indent,
    )
    from flutils.strutils import (
        get_indent_level,
    )
    from flutils.pyutils import (
        get_caller_globals,
    )
    from flutils.iterutils import (
        get_first,
    )
    from flutils.logutils import (
        get_logger,
    )

    logger = get_logger(__name__)

    script_

# Generated at 2022-06-17 19:29:47.846303
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.sysutils import (
        get_script_dir,
    )
    from flutils.textutils import (
        indent,
    )
    from flutils.pathutils import (
        get_parent_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )

# Generated at 2022-06-17 19:29:58.378709
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_project_dir,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_output_dir,
    )
    from flutils.testutils.file import (
        create_file,
        create_file_from_template,
    )
    from flutils.testutils.file import (
        remove_file,
        remove_dir,
    )
    from flutils.testutils.file import (
        create_dir,
        create_dirs,
    )
    from flutils.testutils.file import (
        get_file_contents,
        get_file_contents_as_lines,
    )

# Generated at 2022-06-17 19:30:06.853012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()



# Generated at 2022-06-17 19:30:15.844411
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import underscore_to_camel
    from flutils.sysutils import get_python_version
    from flutils.sysutils import get_platform_info

    with TempDir() as td:
        # Create a setup.py file
        setup_py_path = os.path.join(td, 'setup.py')

# Generated at 2022-06-17 19:30:38.434622
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.foo]\n')
            f.write('command = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:30:48.661414
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import TestCase

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.dirname(path)
            path = os.path.join(path, 'tests', 'data', 'setup_commands')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance

# Generated at 2022-06-17 19:31:01.040119
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('')

        def tearDown(self):
            os.remove(self.setup_py_path)


# Generated at 2022-06-17 19:31:13.079340
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap

    def _get_setup_cfg_content(
            name: str,
            commands: Tuple[str, ...],
            description: str = '',
    ) -> str:
        return textwrap.dedent(
            """\
            [metadata]
            name = {name}

            [setup.command.{name}]
            description = {description}
            commands =
            {commands}
            """
        ).format(
            name=name,
            description=description,
            commands='\n'.join(commands)
        )


# Generated at 2022-06-17 19:31:25.098001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as temp_dir:
        setup_dir = temp_dir.path
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = flutils\n'
            )

# Generated at 2022-06-17 19:31:33.060366
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path(__file__, '..', '..', '..', '..', '..')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommand

# Generated at 2022-06-17 19:31:43.579204
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    with TempDir() as td:
        setup_cfg_path = os.path.join(td, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                """
                [metadata]
                name = test_package

                [setup.command.test_command]
                name = test_command
                description = Test command.
                command = echo "test command"
                """
            )
        setup_dir = td
        for config in each_sub_command_config(setup_dir):
            assert config.name == 'test_command'
            assert config.camel == 'TestCommand'
            assert config.description == 'Test command.'
            assert config.commands == ('echo "test command"',)



# Generated at 2022-06-17 19:31:54.470854
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import get_test_data_path
    from flutils.pathutils import each_file_in_dir

    def _each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        yield from each_sub_command_config(setup_dir)

    def _get_setup_dir() -> str:
        return get_test_data_path('setup_cfg_test')

    def _get_setup_cfg_path() -> str:
        return os.path.join(_get_setup_dir(), 'setup.cfg')


# Generated at 2022-06-17 19:32:03.727044
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )

    def _write_setup_cfg(
            setup_cfg_path: str,
            name: str,
            description: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(setup_cfg_path, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')

# Generated at 2022-06-17 19:32:15.591943
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdin,
        capture_sys_argv,
    )
    from flutils.sysutils import (
        get_script_dir,
        get_script_name,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_level,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_level,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_level,
    )
    from flutils.textutils import (
        get_indent,
        get_indent_level,
    )

# Generated at 2022-06-17 19:32:50.712211
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                tmpdir = os.path.realpath(tmpdir)
                setup_py = os.path.join(tmpdir, 'setup.py')
                with open(setup_py, 'w') as f:
                    f.write(
                        '''\
import setuptools

setuptools.setup(
    name='test_each_sub_command_config',
    version='0.0.0',
    packages=setuptools.find_packages(),
)
'''
                    )
                setup_cfg = os.path.join(tmpdir, 'setup.cfg')
               

# Generated at 2022-06-17 19:32:59.190336
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):

        def test_each_sub_command_config(self):
            root_dir = get_project_root_dir()
            for config in each_sub_command_config(root_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:33:09.968243
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.temp_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.temp_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir, 'setup_commands.cfg'
            )
            self.setup_py_content = textwrap.dedent(
                """\
                from setuptools import setup
                setup()
                """
            )
           

# Generated at 2022-06-17 19:33:16.180053
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py_path, 'w') as f:
                f.write('#!/usr/bin/env python\n')

# Generated at 2022-06-17 19:33:25.359236
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        capture_stdout,
        capture_stderr,
        capture_stdouterr,
    )
    from flutils.pathutils import get_test_dir

    with capture_stdouterr() as (stdout, stderr):
        for config in each_sub_command_config(get_test_dir()):
            print(config)
    assert stdout.getvalue() == (
        "SetupCfgCommandConfig(name='test', camel='Test', "
        "description='Test command', commands=('echo test',))\n"
        "SetupCfgCommandConfig(name='test.sub', camel='TestSub', "
        "description='Test sub command', commands=('echo test sub',))\n"
    )
    assert stderr.getvalue() == ''

# Generated at 2022-06-17 19:33:37.491863
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:49.525687
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

# Generated at 2022-06-17 19:33:53.118011
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(self.test_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:34:01.780725
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:34:12.585752
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:35:00.376367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_package_dir
    from flutils.testutils import UnitTest
    from flutils.testutils.pathutils import (
        get_test_data_dir,
        get_test_data_file,
    )

    class TestEachSubCommandConfig(UnitTest):
        def test_each_sub_command_config(self):
            setup_dir = get_test_data_dir('setup_cfg_test')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)


# Generated at 2022-06-17 19:35:11.655265
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import sys
    import os

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')

    def _get_setup_py_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.py')


# Generated at 2022-06-17 19:35:21.871480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEach

# Generated at 2022-06-17 19:35:34.447310
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_each_sub_command_config_no_setup_dir(self):
            with self.assertRaises(FileNotFoundError):
                list(each_sub_command_config())

        def test_each_sub_command_config_no_setup_cfg(self):
            with self.assertRaises(FileNotFoundError):
                list(each_sub_command_config(self.temp_dir))


# Generated at 2022-06-17 19:35:46.864654
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_path_to_data_file

    class Test(UnitTestBase):

        def test_each_sub_command_config(self):
            path = get_path_to_data_file(
                'setup_commands.cfg',
                'flutils',
                'tests',
                'data'
            )
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)


# Generated at 2022-06-17 19:35:56.983491
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _write_setup_cfg(
            tmp_dir: str,
            setup_cfg_content: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup.cfg'), 'w') as f:
            f.write(setup_cfg_content)

    def _write_setup_commands_cfg(
            tmp_dir: str,
            setup_commands_cfg_content: str
    ) -> None:
        with open(os.path.join(tmp_dir, 'setup_commands.cfg'), 'w') as f:
            f.write(setup_commands_cfg_content)


# Generated at 2022-06-17 19:36:05.585578
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_true,
        assert_is_false,
        assert_raises,
    )
    from flutils.testutils.pytestutils import (
        assert_raises_regex,
    )

    # Test with no setup_dir
    setup_dir = None
    gen = each_sub_command_config(setup_dir)
    assert_is_instance(gen, Generator)
    assert_is_not_none(next(gen))

    # Test with a valid setup_dir
    setup_dir = get_project_root_dir()
    gen = each_sub

# Generated at 2022-06-17 19:36:15.953990
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    from flutils.pathutils import get_project_root
    from flutils.testutils import UnitTest

    class TestEachSubCommandConfig(UnitTest):
        def test_each_sub_command_config(self):
            root = get_project_root()
            for config in each_sub_command_config(root):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:36:25.207610
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )
    from flutils.pathutils import (
        get_path_to_parent_dir,
        get_path_to_child_dir,
    )
    from flutils.strutils import (
        camel_to_underscore,
    )

# Generated at 2022-06-17 19:36:31.612557
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.configutils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:37:08.043041
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    with TempDir() as td:
        td.write('setup.py', '''
            from setuptools import setup
            setup(
                name='test',
                version='0.0.0',
                description='Test',
                author='Test',
                author_email='test@test.com',
                url='http://test.com',
                packages=['test'],
                entry_points={
                    'console_scripts': [
                        'test = test.__main__:main'
                    ]
                }
            )
        ''')

# Generated at 2022-06-17 19:37:11.878005
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:37:19.997158
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    import unittest
    from unittest.mock import patch

    class EachSubCommandConfigTestCase(unittest.TestCase):
        """Test case for function each_sub_command_config."""

        def test_each_sub_command_config(self):
            """Test function each_sub_command_config."""
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIs

# Generated at 2022-06-17 19:37:29.873154
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test_each_sub_command_config()



# Generated at 2022-06-17 19:37:37.653432
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:37:45.512408
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        get_data_path,
        get_data_file_path,
    )
    from flutils.setuputils import (
        each_sub_command_config,
    )

    path = get_data_path('setup_commands.cfg')
    assert_is_not_none(path)
    assert_is_instance(path, str)
    assert_is(os.path.isfile(path), True)


# Generated at 2022-06-17 19:37:55.126624
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for cmd in config.commands:
                        self.assertIsInstance(cmd, str)

    unittest.main()

# Generated at 2022-06-17 19:38:07.632019
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_file_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):

        def test_each_sub_command_config(self):
            path = get_file_path(__file__, '../../../setup.cfg')
            self.assertTrue(os.path.isfile(path))
            parser = ConfigParser()
            parser.read(path)
            name = _get_name(parser, path)
            self.assertEqual(name, 'flutils')
            format_kwargs = {
                'name': name,
                'setup_dir': os.path.dirname(path),
                'home': os.path.expanduser('~')
            }

# Generated at 2022-06-17 19:38:15.707479
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil

    def _each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> Generator[SetupCfgCommandConfig, None, None]:
        for config in each_sub_command_config(setup_dir):
            yield config

    def _test_each_sub_command_config(
            setup_dir: Optional[Union[os.PathLike, str]] = None
    ) -> None:
        for config in _each_sub_command_config(setup_dir):
            assert config.name
            assert config.camel
            assert config.description
            assert config.commands


# Generated at 2022-06-17 19:38:24.910172
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path_to_module(__file__)
            setup_dir = os.path.join(setup_dir, '..', '..')
            setup_dir = os.path.realpath(setup_dir)
            setup_dir = os.path.join(setup_dir, 'tests', 'data', 'setup_dir')
            setup_dir = os.path.realpath(setup_dir)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)