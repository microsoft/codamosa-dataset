

# Generated at 2022-06-17 19:28:41.131602
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_path(__file__, '..', '..', '..', '..', '..')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertTrue(config.name)
                self.assertTrue(config.camel)
                self.assertTrue(config.description)
                self.assertTrue(config.commands)

    TestEachSubCommandConfig().test_each_sub_command_config()

# Generated at 2022-06-17 19:28:48.769384
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import sys
    import os

    def _write_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = '',
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'commands = %s\n'
                'description = %s\n'
                'name = %s\n'
                % (name, '\n'.join(commands), description, command_name)
            )


# Generated at 2022-06-17 19:28:58.654084
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)


# Generated at 2022-06-17 19:29:08.359144
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase
    from flutils.pathutils import get_parent_dir

    class TestEachSubCommandConfig(UnitCase):

        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:29:10.991108
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    for config in each_sub_command_config():
        print(config)


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:29:21.868777
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: Tuple[str, ...]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.%s]\n' % name)
            f.write('command = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:29:31.285022
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:29:41.961420
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            sys.path.insert(0, setup_dir)
            try:
                from setup import setup_cfg_commands
            finally:
                sys.path.pop(0)
            for sub_command in each_sub_command_config(setup_dir):
                self.assertTrue(sub_command.name in setup_cfg_commands)
                self.assertTrue(sub_command.camel in setup_cfg_commands)

# Generated at 2022-06-17 19:29:52.999958
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    from flutils.setuputils import each_sub_command_config

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:30:03.389347
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import pprint
    import tempfile

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as fp:
            fp.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.foo]\n'
                'command = %s\n'
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:30:23.244157
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_subclass,
        assert_true,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_python_executable,
    )
    from flutils.testutils import (
        get_test_data_dir,
    )
    from flutils.testutils.testcase import (
        TestCase,
    )
    from flutils.testutils.testcase import (
        TestCase,
    )

# Generated at 2022-06-17 19:30:29.400001
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import each_parent_dir

    for path in each_parent_dir(__file__):
        if os.path.isfile(os.path.join(path, 'setup.py')):
            break
    else:
        raise FileNotFoundError(
            "Unable to find the directory that contains the 'setup.py' file."
        )

    for config in each_sub_command_config(path):
        assert isinstance(config, SetupCfgCommandConfig)
        assert isinstance(config.name, str)
        assert isinstance(config.camel, str)
        assert isinstance(config.description, str)
        assert isinstance(config.commands, tuple)
        for command in config.commands:
            assert isinstance(command, str)



# Generated at 2022-06-17 19:30:39.195122
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    from pathlib import Path
    from shutil import rmtree

    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )

    def _test_each_sub_command_config(
            setup_cfg: str,
            setup_commands_cfg: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            setup_cfg = tmpdir / 'setup.cfg'
            setup_cfg.write_text(setup_cfg)
            setup_commands_cfg = tmpdir / 'setup_commands.cfg'

# Generated at 2022-06-17 19:30:49.587219
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for cmd in config.commands:
                    self.assertIsInstance(cmd, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:31:01.463713
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_test_data_path
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)



# Generated at 2022-06-17 19:31:07.347028
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
            command_name: str = ''
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.%s]\n' % command_name)
            f.write('description = %s\n' % description)
            f.write('commands = \\\n')

# Generated at 2022-06-17 19:31:15.389230
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_not_empty_sequence,
        assert_is_sequence,
        assert_is_subclass,
        assert_is_true,
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_true,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.strutils import (
        is_empty,
        is_not_empty,
    )
    from flutils.sysutils import (
        is_windows,
    )

    # Test with no setup_dir

# Generated at 2022-06-17 19:31:27.388766
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import shutil

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write(
                "[metadata]\n"
                "name = %s\n"
                "\n"
                "[setup.command.foo]\n"
                "command = %s\n"
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:31:38.360810
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.testutils.pytest import (
        assert_raises_regex,
        assert_raises_regexp,
    )

    # Test that the function raises an exception when the given
    # 'setup_dir' does NOT exist.

# Generated at 2022-06-17 19:31:48.423489
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:32:22.742686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                self.assertTrue(config.commands)

# Generated at 2022-06-17 19:32:30.649518
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys
    import io
    import textwrap
    from flutils.configutils import each_sub_command_config

    def _write_setup_cfg(
            dir_path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(dir_path, 'setup.cfg'), 'w') as f:
            f.write(textwrap.dedent(
                """
                [metadata]
                name = %s
                """ % name
            ))
            for command in commands:
                f.write(textwrap.dedent(
                    """
                    [setup.command.%s]
                    command = %s
                    """ % (command, command)
                ))


# Generated at 2022-06-17 19:32:41.630805
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir

    with TempDir() as tmpdir:
        for parent in each_parent_dir(tmpdir):
            if os.path.basename(parent) == 'flutils':
                break
        else:
            raise RuntimeError("Unable to find the 'flutils' directory.")
        setup_dir = os.path.join(parent, 'tests', 'data', 'setup_dir')
        for config in each_sub_command_config(setup_dir):
            assert config.name == 'test.command'
            assert config.camel == 'TestCommand'
            assert config.description == 'Test command.'
            assert config.commands == ('echo test',)
            break

# Generated at 2022-06-17 19:32:52.387111
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-17 19:33:00.280081
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_not_empty_iter,
        assert_is_not_empty_str,
        assert_is_not_empty_tuple,
        assert_is_none,
        assert_is_true,
        assert_raises,
    )
    from flutils.testutils.pytestutils import (
        assert_raises_file_not_found_error,
        assert_raises_not_a_directory_error,
    )

    # Test with no setup_dir
    setup_dir = None
    assert_is_none(setup_dir)
   

# Generated at 2022-06-17 19:33:09.522514
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:33:13.477057
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str

    path = get_path_to_this_file(__file__)
    path = os.path.dirname(path)
    path = os.path.join(path, 'setup_commands.cfg')
    assert os.path.isfile(path) is True
    assert os.path.exists(path) is True

    out = list(each_sub_command_config(path))
    assert len(out) == 2
    assert out[0].name == 'test_command'
    assert out[0].camel == 'TestCommand'
    assert out[0].description == 'This is a test command.'

# Generated at 2022-06-17 19:33:24.072501
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:36.529125
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import temp_dir
    from flutils.pathutils import each_file_path

    with temp_dir() as td:
        with open(os.path.join(td, 'setup.py'), 'w') as f:
            f.write('')
        with open(os.path.join(td, 'setup.cfg'), 'w') as f:
            f.write('''\
[metadata]
name = flutils
''')

# Generated at 2022-06-17 19:33:49.239031
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version

    this_file = get_path_to_this_file()
    this_dir = os.path.dirname(this_file)
    setup_dir = os.path.dirname(this_dir)
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    parser = ConfigParser()
    parser.read(setup_cfg_path)
    name = _get_name(parser, setup_cfg_path)
    format_kwargs = {
        'setup_dir': setup_dir,
        'home': os.path.expanduser('~'),
        'name': name
    }

# Generated at 2022-06-17 19:34:28.831741
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile

    def _write_setup_cfg(
            fp: Union[os.PathLike, str],
            name: str,
            commands: List[str]
    ) -> None:
        with open(fp, 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)
            f.write('\n')
            f.write('[setup.command.test]\n')
            f.write('commands = %s\n' % '\n'.join(commands))


# Generated at 2022-06-17 19:34:37.929409
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil

    def _test_each_sub_command_config(
            setup_cfg_contents: str,
            setup_commands_cfg_contents: str,
            expected: List[SetupCfgCommandConfig]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = str(tmpdir)
            setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
            with open(setup_cfg_path, 'w') as f:
                f.write(setup_cfg_contents)
            setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:34:48.467794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:34:58.137807
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.configutils import each_sub_command_config
    from flutils.pathutils import get_path_to_this_file
    from flutils.strutils import underscore_to_camel
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_not_empty_sequence,
        assert_is_sequence,
        assert_is_true,
        assert_is_type,
        assert_not_equal,
        assert_not_is_instance,
        assert_not_is_none,
        assert_not_is_type,
        assert_raises,
    )

    path = get_path_to_this_file(__file__)
    path = os

# Generated at 2022-06-17 19:35:09.336547
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):

        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().run()

# Generated at 2022-06-17 19:35:19.778971
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not_empty,
        assert_is_empty,
        assert_is_none,
        assert_is_true,
        assert_is_false,
        assert_is_not,
        assert_in,
        assert_not_in,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
        get_parent_dir_path,
    )

# Generated at 2022-06-17 19:35:32.384657
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import each_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for setup_dir in each_parent_dir(__file__):
                if os.path.isfile(os.path.join(setup_dir, 'setup.py')):
                    break
            else:
                self.fail("Unable to find the directory that contains the "
                          "'setup.py' file.")
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)

# Generated at 2022-06-17 19:35:36.767270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import TestCase

    class Test(TestCase):
        def test_each_sub_command_config(self):
            path = get_path_to_this_file(__file__)
            path = os.path.dirname(path)
            path = os.path.join(path, 'test_data')
            path = os.path.join(path, 'test_setup_cfg')
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance

# Generated at 2022-06-17 19:35:45.974313
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_executable

    setup_dir = get_parent_dir(__file__)
    for config in each_sub_command_config(setup_dir):
        assert config.name
        assert config.camel
        assert config.description
        assert config.commands
        for command in config.commands:
            assert command
            command = to_str(command)
            assert command.startswith(get_python_executable())
            assert command.endswith('setup.py')

# Generated at 2022-06-17 19:35:58.786480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    """Unit test for function each_sub_command_config."""
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for command in config.commands:
                        self.assertIsInstance(command, str)

# Generated at 2022-06-17 19:36:46.970029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import textwrap
    import sys

    def _get_setup_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup.cfg')

    def _get_setup_commands_cfg_path(setup_dir: str) -> str:
        return os.path.join(setup_dir, 'setup_commands.cfg')


# Generated at 2022-06-17 19:36:59.078709
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:37:07.574480
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_is,
        assert_is_not,
        assert_raises,
        assert_raises_regex,
        assert_not_raises,
        assert_not_raises_regex,
    )

    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    from flutils.setuputils import (
        each_sub_command_config,
    )


# Generated at 2022-06-17 19:37:17.631571
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(
                    os.path.dirname(sys.modules[__name__].__file__)
            ):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:37:28.328541
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import underscore_to_camel

    with TempDir() as td:
        setup_cfg_path = os.path.join(td, 'setup.cfg')

# Generated at 2022-06-17 19:37:40.015103
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
    )


# Generated at 2022-06-17 19:37:47.023544
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 'setup.py')
            for config in each_sub_command_config(setup_dir):
                self.assert_is_instance(config.name, str)
                self.assert_is_instance(config.camel, str)
                self.assert_is_instance(config.description, str)
                self.assert_is_instance(config.commands, tuple)
                for command in config.commands:
                    self.assert_is_instance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:37:59.333674
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_project_root_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(get_project_root_dir()):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()


if __name__ == '__main__':
    test_

# Generated at 2022-06-17 19:38:10.430492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_raises,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.sysutils import (
        get_module_path,
        get_module_name,
    )
    from flutils.strutils import (
        to_str,
    )

    # Test the default setup_dir
    setup_dir = None

# Generated at 2022-06-17 19:38:22.895825
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from unittest.mock import patch

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            with patch.object(sys, 'argv', ['setup.py', '--help-commands']):
                for config in each_sub_command_config():
                    self.assertIsInstance(config, SetupCfgCommandConfig)
                    self.assertIsInstance(config.name, str)
                    self.assertIsInstance(config.camel, str)
                    self.assertIsInstance(config.description, str)
                    self.assertIsInstance(config.commands, tuple)
                    for cmd in config.commands:
                        self.assertIsInstance(cmd, str)

    unittest.main()