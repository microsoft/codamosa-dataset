

# Generated at 2022-06-17 19:28:46.397365
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest
    from flutils.configutils import (
        each_sub_command_config,
        SetupCfgCommandConfig,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = get_parent_dir(__file__)
            self.tmpdir = tempfile.TemporaryDirectory()
            self.tmpdir_path = self.tmpdir.name
            self.tmpdir_name = os.path.basename(self.tmpdir_path)
            self.tmpdir_parent_path = os.path.dirname(self.tmpdir_path)

# Generated at 2022-06-17 19:28:57.910684
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import temp_dir

    with temp_dir() as tmpdir:
        setup_cfg_path = os.path.join(tmpdir, 'setup.cfg')
        with open(setup_cfg_path, 'w') as fp:
            fp.write(
                """\
[metadata]
name = flutils

[setup.command.test]
name = test
description = Runs the unit tests.
command =
    python -m unittest discover -v -s {setup_dir}/tests
"""
            )
        setup_commands_cfg_path = os.path.join(tmpdir, 'setup_commands.cfg')

# Generated at 2022-06-17 19:29:07.698995
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            with open(self.setup_py, 'w') as fp:
                fp.write('')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            with open(self.setup_cfg, 'w') as fp:
                fp.write('''
[metadata]
name = flutils
''')

# Generated at 2022-06-17 19:29:19.339663
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_module
    from flutils.testutils import UnitTestBase
    from flutils.testutils import UnitTestSuite

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            path = get_path_to_this_module()
            path = os.path.join(path, '..', '..', '..', 'tests', 'data')
            path = os.path.realpath(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)


# Generated at 2022-06-17 19:29:28.720433
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from pprint import pprint
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    test_data_dir = get_test_data_dir(__file__)
    setup_dir = get_parent_dir(test_data_dir, 2)
    setup_cfg_path = get_test_data_file(__file__, 'setup.cfg')
    setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
    setup_cfg_path = os.path.realpath(setup_cfg_path)
    setup_commands_cfg_path = get_test_data_file(__file__, 'setup_commands.cfg')
    setup_comm

# Generated at 2022-06-17 19:29:39.075386
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:29:49.635629
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file_path
    from flutils.strutils import random_string

    with TempDir() as td:
        setup_cfg_path = os.path.join(td, 'setup.cfg')
        setup_py_path = os.path.join(td, 'setup.py')
        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                % random_string()
            )

# Generated at 2022-06-17 19:29:53.642997
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess

    def _write_setup_cfg(
            dir_path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(os.path.join(dir_path, 'setup.cfg'), 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'commands =\n'
                '    %s\n'
                % (name, '\n    '.join(commands))
            )


# Generated at 2022-06-17 19:30:01.966902
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test(self):
            for config in each_sub_command_config(get_parent_dir(__file__)):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test().test()

# Generated at 2022-06-17 19:30:10.893233
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import tempfile
    import unittest

    class EachSubCommandConfigTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.setup_dir = self.tempdir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')

# Generated at 2022-06-17 19:30:30.744875
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDirTestCase
    from flutils.pathutils import each_file_path

    class TestCase(TempDirTestCase):
        def setUp(self):
            super().setUp()
            self.setup_dir = self.temp_dir
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:30:39.430427
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_file
    from flutils.strutils import random_string

    with TempDir() as td:
        setup_py_path = os.path.join(td, 'setup.py')
        with open(setup_py_path, 'w') as f:
            f.write('# setup.py')

        setup_cfg_path = os.path.join(td, 'setup.cfg')
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n' % random_string(10)
            )

        setup_commands_cfg_path = os.path.join(td, 'setup_commands.cfg')

# Generated at 2022-06-17 19:30:49.773367
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        TestCase,
        run_test_module_with_coverage,
    )

    class TestEachSubCommandConfig(TestCase):
        def test_each_sub_command_config(self):
            from flutils.pathutils import (
                get_module_dir,
            )

            setup_dir = get_module_dir(__name__)
            setup_dir = os.path.join(setup_dir, 'testdata', 'setupcfg')
            setup_dir = os.path.realpath(setup_dir)


# Generated at 2022-06-17 19:31:01.532270
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.home = os.path.expanduser('~')
            self.name = 'flutils'

# Generated at 2022-06-17 19:31:13.282644
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.pathutils import get_test_data_dir

            test_data_dir = get_test_data_dir(__file__)
            setup_dir = os.path.join(test_data_dir, 'test_project')
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

# Generated at 2022-06-17 19:31:19.136312
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase
    from flutils.pathutils import get_parent_dir

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:31:24.471775
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess

    def _write_setup_cfg(
            setup_cfg_path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(setup_cfg_path, 'w') as f:
            f.write(
                '[metadata]\n'
                'name = %s\n'
                '\n'
                '[setup.command.test]\n'
                'command = %s\n'
                % (name, '\n'.join(commands))
            )


# Generated at 2022-06-17 19:31:32.765846
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            with open(self.setup_py, 'w') as f:
                f.write('')

# Generated at 2022-06-17 19:31:40.320804
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
    )
    from flutils.pathutils import (
        each_parent_dir,
        get_parent_dir,
    )
    from flutils.sysutils import (
        get_script_dir,
    )
    from flutils.testutils import (
        get_test_data_path,
    )
    from flutils.testutils.testutils import (
        get_test_data_dir,
    )

    # Test that the function raises an error when the setup.py file is not
    # found.


# Generated at 2022-06-17 19:31:49.012140
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().test_each_sub_command_config()

# Generated at 2022-06-17 19:32:22.521467
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _get_setup_cfg_contents(
            name: str,
            commands: Tuple[str, ...]
    ) -> str:
        return textwrap.dedent("""\
            [metadata]
            name = %s

            [setup.command.test]
            commands =
                %s
        """ % (name, '\n                '.join(commands)))

    def _get_setup_commands_cfg_contents(
            name: str,
            commands: Tuple[str, ...]
    ) -> str:
        return textwrap.dedent("""\
            [setup.command.test]
            commands =
                %s
        """ % '\n                '.join(commands))


# Generated at 2022-06-17 19:32:29.770621
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest
    from io import StringIO

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = os.path.dirname(__file__)
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )
            self.parser = ConfigParser()
            self.parser.read(self.setup_cfg_path)
            self.parser.read(self.setup_commands_cfg_path)

        def test_each_sub_command_config(self):
            out = StringIO()
            sys.stdout = out


# Generated at 2022-06-17 19:32:41.099029
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    from io import StringIO
    from unittest import TestCase

    class TestEachSubCommandConfig(TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

        def tearDown(self):
            import shutil
            shutil.rmtree(self.setup_dir)


# Generated at 2022-06-17 19:32:52.058220
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def setUp(self):
            self.setup_dir = tempfile.mkdtemp()
            self.setup_cfg = os.path.join(self.setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:33:00.083701
# Unit test for function each_sub_command_config

# Generated at 2022-06-17 19:33:07.152466
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile

    from flutils.pathutils import (
        each_file_in_dir,
        each_file_in_dir_recursive,
        each_sub_dir,
        each_sub_dir_recursive,
    )
    from flutils.strutils import (
        camel_to_underscore,
        underscore_to_camel,
    )

    def _create_setup_cfg(
            setup_dir: str,
            name: str,
            commands: List[str],
            description: str = '',
    ) -> None:
        with open(os.path.join(setup_dir, 'setup.cfg'), 'w') as f:
            f.write('[metadata]\n')
            f.write('name = %s\n' % name)


# Generated at 2022-06-17 19:33:14.625794
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestCase

    class TestEachSubCommandConfig(UnitTestCase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    test_each_sub_command_config = TestEachSubCommandConfig()
    test_each_sub_command_config.test_each_sub

# Generated at 2022-06-17 19:33:24.333874
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import TempDir

    with TempDir() as temp_dir:
        setup_dir = get_parent_dir(__file__)
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(setup_dir, 'setup_commands.cfg')
        shutil.copy(setup_cfg_path, temp_dir)
        shutil.copy(setup_commands_cfg_path, temp_dir)
        setup_cfg_path = os.path.join(temp_dir, 'setup.cfg')
        setup_commands_cfg_path = os.path.join(temp_dir, 'setup_commands.cfg')
        parser = ConfigParser()

# Generated at 2022-06-17 19:33:36.737061
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_true,
        assert_false,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.pathutils import (
        get_parent_dir,
        get_grandparent_dir,
    )
    from flutils.strutils import (
        underscore_to_camel,
    )
    from flutils.sysutils import (
        get_python_executable,
    )

    this_dir = get_parent_dir(__file__)
    root_dir = get_grandparent_dir(this_dir)
    setup_dir = os.path.join

# Generated at 2022-06-17 19:33:49.416862
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    import sys
    import tempfile
    import unittest

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.setup_dir = self.temp_dir.name
            self.setup_cfg_path = os.path.join(self.setup_dir, 'setup.cfg')
            self.setup_py_path = os.path.join(self.setup_dir, 'setup.py')
            self.setup_commands_cfg_path = os.path.join(
                self.setup_dir, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:34:50.403162
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            from flutils.setuputils import each_sub_command_config

            for config in each_sub_command_config():
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    TestEachSubCommandConfig().run()



# Generated at 2022-06-17 19:35:00.969416
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )
    from flutils.testutils import (
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )

# Generated at 2022-06-17 19:35:11.887458
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import tempfile
    import unittest
    from unittest.mock import patch

    class EachSubCommandConfigTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_dir_path = self.temp_dir.name
            self.setup_py_path = os.path.join(self.temp_dir_path, 'setup.py')
            self.setup_cfg_path = os.path.join(self.temp_dir_path, 'setup.cfg')
            self.setup_commands_cfg_path = os.path.join(
                self.temp_dir_path, 'setup_commands.cfg'
            )

# Generated at 2022-06-17 19:35:22.067492
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_path_to_this_file,
        get_parent_dir,
    )

# Generated at 2022-06-17 19:35:31.401551
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_path
    from flutils.strutils import to_str

    path = get_module_path(__name__)
    path = os.path.join(path, '..', '..', '..', '..', 'tests', 'data')
    path = os.path.realpath(path)
    for config in each_sub_command_config(path):
        print(to_str(config))


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:35:40.137815
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import TempDir
    from flutils.pathutils import each_parent_dir
    from flutils.strutils import to_str
    from flutils.sysutils import get_python_version
    from flutils.sysutils import get_system_info
    from flutils.sysutils import get_system_info_str
    from flutils.sysutils import get_system_info_str_short
    from flutils.sysutils import get_system_info_str_short_no_arch
    from flutils.sysutils import get_system_info_str_short_no_arch_no_os
    from flutils.sysutils import get_system_info_str_short_no_os
    from flutils.sysutils import get_system_info_str_short_no_os_no_arch

# Generated at 2022-06-17 19:35:45.742405
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import (
        get_parent_dir,
        get_parent_dir_name,
    )
    from flutils.testutils import (
        get_test_data_dir,
        get_test_data_file,
    )
    from flutils.testutils.test_case import (
        BaseTestCase,
        TestCase,
    )

    class TestEachSubCommandConfig(BaseTestCase):
        def test_each_sub_command_config(self):
            test_dir = get_test_data_dir(
                get_parent_dir(__file__),
                get_parent_dir_name(__file__),
                'test_setup_cfg_commands'
            )

# Generated at 2022-06-17 19:35:58.630569
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import os
    from flutils.pathutils import (
        each_parent_dir,
        get_path_to_parent_dir,
    )
    from flutils.testutils import (
        assert_generator_equal,
        assert_generator_raises,
    )
    from flutils.testutils.fileutils import (
        create_file,
        create_file_with_contents,
        create_temp_dir,
    )
    from flutils.testutils.pathutils import (
        assert_each_parent_dir_equal,
        assert_get_path_to_parent_dir_equal,
    )

    # Test setup_dir is None
    with create_temp_dir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'setup_dir')
       

# Generated at 2022-06-17 19:36:06.115012
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_module_dir
    from flutils.testutils import UnitTestBase

    class Test(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_module_dir(__file__)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)

    Test().run()


if __name__ == '__main__':
    test_each_sub_command_config()

# Generated at 2022-06-17 19:36:16.200375
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import make_temp_dir
    from flutils.testutils import remove_temp_dir
    from flutils.testutils import write_file

    with make_temp_dir() as temp_dir:
        setup_dir = os.path.join(temp_dir, 'test_pkg')
        os.mkdir(setup_dir)
        setup_py_path = os.path.join(setup_dir, 'setup.py')
        write_file(setup_py_path, '# Test setup.py file.')
        setup_cfg_path = os.path.join(setup_dir, 'setup.cfg')

# Generated at 2022-06-17 19:37:16.777769
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import UnitCase
    from flutils.pathutils import get_test_data_path

    class TestEachSubCommandConfig(UnitCase):
        def test_each_sub_command_config(self):
            path = get_test_data_path('setup_commands.cfg')
            path = os.path.dirname(path)
            for config in each_sub_command_config(path):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    Test

# Generated at 2022-06-17 19:37:28.002686
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from os import path
    from tempfile import TemporaryDirectory
    from unittest.mock import patch

    from flutils.pathutils import write_file

    with TemporaryDirectory() as tmpdir:
        setup_dir = path.join(tmpdir, 'setup_dir')
        os.mkdir(setup_dir)
        setup_py = path.join(setup_dir, 'setup.py')

# Generated at 2022-06-17 19:37:39.708469
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_this_file

# Generated at 2022-06-17 19:37:44.023307
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import sys
    import unittest

    class TestEachSubCommandConfig(unittest.TestCase):
        def test_each_sub_command_config(self):
            for config in each_sub_command_config(sys.path[0]):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)

    unittest.main()

# Generated at 2022-06-17 19:37:54.247852
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_path_to_module
    from flutils.testutils import UnitTestCase
    from flutils.testutils import get_test_data_path

    class TestEachSubCommandConfig(UnitTestCase):

        def test_each_sub_command_config(self):
            path = get_path_to_module(__name__)
            path = os.path.join(path, '..', '..', '..', '..', '..', '..')
            path = os.path.realpath(path)
            path = os.path.join(path, 'setup.cfg')
            self.assertTrue(os.path.isfile(path))
            path = os.path.join(path, '..', 'setup_commands.cfg')

# Generated at 2022-06-17 19:38:03.502951
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.testutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none,
        assert_is_none,
        assert_is_not,
        assert_is,
        assert_true,
        assert_false,
        assert_in,
        assert_not_in,
        assert_greater,
        assert_greater_equal,
        assert_less,
        assert_less_equal,
        assert_raises,
        assert_raises_regex,
        assert_regex,
        assert_not_regex,
    )
    from flutils.pathutils import (
        create_temp_dir,
        create_temp_file,
    )
    from flutils.strutils import (
        random_string,
    )


# Generated at 2022-06-17 19:38:11.065643
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    from flutils.pathutils import get_parent_dir
    from flutils.testutils import UnitTestBase

    class TestEachSubCommandConfig(UnitTestBase):
        def test_each_sub_command_config(self):
            setup_dir = get_parent_dir(__file__, 2)
            for config in each_sub_command_config(setup_dir):
                self.assertIsInstance(config, SetupCfgCommandConfig)
                self.assertIsInstance(config.name, str)
                self.assertIsInstance(config.camel, str)
                self.assertIsInstance(config.description, str)
                self.assertIsInstance(config.commands, tuple)
                for command in config.commands:
                    self.assertIsInstance(command, str)
    TestEachSubCommandConfig().run()

# Generated at 2022-06-17 19:38:23.142771
# Unit test for function each_sub_command_config
def test_each_sub_command_config():
    import tempfile
    import shutil
    import textwrap

    def _write_setup_cfg(
            setup_cfg_path: str,
            name: str,
            commands: List[str]
    ) -> None:
        with open(setup_cfg_path, 'w') as fp:
            fp.write(textwrap.dedent("""\
                [metadata]
                name = %s
                """ % name))
            for command in commands:
                fp.write(textwrap.dedent("""\
                    [setup.command.%s]
                    command = %s
                    """ % (command, command)))
