

# Generated at 2022-06-25 11:27:22.064844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new LookupModule object
    lookup_module_1 = LookupModule()

    terms = [
        [
            "a",
            "b",
            "c"
        ],
        [
            "1",
            "2",
            "3",
            "4"
        ]
    ]

    # Expected output
    expected_output_1 = [
        [
            "a",
            "1"
        ],
        [
            "b",
            "2"
        ],
        [
            "c",
            "3"
        ],
        [
            None,
            "4"
        ]
    ]

    actual_output_1 = lookup_module_1.run(terms);
    assert(expected_output_1 == actual_output_1)

# Generated at 2022-06-25 11:27:27.087013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(my_list)
    print(result)

test_LookupModule_run()

# Generated at 2022-06-25 11:27:31.258710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    lookup_module_0 = LookupModule()
    results = lookup_module_0.run(terms,variables=None)
    assert (results == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]) == True


# Generated at 2022-06-25 11:27:41.296339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #declare a new instance of LookupModule
    lookup_module_0 = LookupModule()

    #declare a valid list of list
    term_0 = [[1, 2, 3], [4, 5, 6]]

    #call the method run with valid arguments
    result_0 = lookup_module_0.run(term_0)

    #check the returned type is list
    assert isinstance(result_0, list)

    #check that the value of result_0 is not None
    assert result_0 is not None

    #check that the value of result_0[0] is not None
    assert result_0[0] is not None

    #check that the value of result_0[0] is equal to 1, 4
    assert result_0[0] == [1, 4]

    #check that the value of result_

# Generated at 2022-06-25 11:27:50.720057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[0, 1, 2], [3, 4, 5]]
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms)
    assert ret == [[0, 3], [1, 4], [2, 5]]

if __name__ == '__main__':
    test_case_0()

# pylint: disable=unused-import
from units.compat import unittest
from units.compat.mock import patch
from ansible.module_utils import basic
from ansible.module_utils._text import to_bytes

LOOKUP_PLUGIN_PATH = 'ansible.plugins.lookup.together'



# Generated at 2022-06-25 11:27:53.303672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["[\"a\", \"b\"]", "[1, 2]"]) == [['a', 1],
                                                                 ['b', 2]]

# Generated at 2022-06-25 11:27:58.227013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([[100,200],[300,400]]) == [[100, 300], [200, 400]]

# Generated at 2022-06-25 11:28:00.744488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["2","3"]
    variables = None
    kwargs = None

    response = lookup_module_0.run(terms,variables,kwargs)

# Generated at 2022-06-25 11:28:05.327259
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    arguments = [["a", "b", "c", "d"], [1, 2, 3, 4]]
    result = lookup_module_0.run(arguments, [])
    assert result == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]


# Generated at 2022-06-25 11:28:10.117480
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input parameters
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]

    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

    # Expected result
    expected_result = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

    print(type(result))
    print(type(expected_result))
    print(result)
    assert(result == expected_result)

    print("Test successful")

if __name__ == "__main__":
    test_case_0()
    exit(0)

# Generated at 2022-06-25 11:28:20.296862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list_0 = [['a', 'b'], [1, 2]]
    my_list_1 = [['b', 'c'], [3, 4]]
    my_list_2 = [['d', 'e'], [5, 6]]
    lookup_module_0 = LookupModule()
    test_result_0 = lookup_module_0.run(my_list_0)
    test_result_1 = lookup_module_0.run(my_list_1)
    test_result_2 = lookup_module_0.run(my_list_2)


# Generated at 2022-06-25 11:28:22.972705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_0 = [2, 2, 2]
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(input_0)
    assert result_0 == [2, 2, 2]


# Generated at 2022-06-25 11:28:29.146665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = [('a',), ('b',), ('c',), ('d',)]
    x = lookup_module_1.run(terms_2)
    assert x == [('a',), ('b',), ('c',), ('d',)]


# Generated at 2022-06-25 11:28:33.065550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(
        terms=['a','b','c','d','e','f'],
        variables=None) == [
            'a',
            'b',
            'c',
            'd',
            'e',
            'f'
        ]

# Generated at 2022-06-25 11:28:38.744952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [('a', 'b'), ('c', 'd')]
    results = [('a', 'c'), ('b', 'd')]

    assert lookup_module_0.run(terms_0) == results


# Generated at 2022-06-25 11:28:39.427981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:28:43.813486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lm = LookupModule()
  assert lm.run([]) == []
  assert lm.run([[1, 2], [3]]) == [[1, 3], [2, None]]
  assert lm.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]
  assert lm.run([[1, 2, 3], [4, 5, 6], [7, 8]]) == [[1, 4, 7], [2, 5, 8], [3, 6, None]]

# Generated at 2022-06-25 11:28:49.472351
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    my_list_1 = [ [['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h', 'i']] ]

    assert lookup_module_1._lookup_variables (my_list_1) == [ [['a', 'd', 'g'], ['b', 'e', 'h'], ['c', 'f', 'i']] ]

# Generated at 2022-06-25 11:28:51.530784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the run method of the LookupModuleClass
    """
    words = [["a", "b", "c"], ["1", "2", "3"]]
    lookup_module = LookupModule()
    result = lookup_module.run(terms=words)

    assert result == [(('a', 1),), (('b', 2),), (('c', 3),)]



# Generated at 2022-06-25 11:28:58.785884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_1 = [
                [ "a", "b", "c", "d" ],
                [ 1, 2, 3, 4 ]
              ]
    expected = [ ["a", 1], ["b", 2], ["c", 3], ["d", 4] ]
    results = LookupModule().run(terms_1)
    assert results == expected, "expected "+str(expected)+" results: "+str(results)


# Generated at 2022-06-25 11:29:07.993227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    # lookup_module_obj.run(terms, **kwargs)
    #self.assertRaises(self, lookup_module_obj.run, **kwargs)
    pass

# Generated at 2022-06-25 11:29:11.041910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms = [['ansible'], ['roles']]
  variables = None
  kwargs = dict()
  ret = lookup_module_0.run(terms, variables, **kwargs)
  assert isinstance(ret, list)
  assert ret == [['ansible', 'roles']]

# Generated at 2022-06-25 11:29:14.861466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['a']
    variables_1 = None
    kwargs_1 = dict()
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    result_1_dict = dict(
        _list=[['a']]
    )
    assert (result_1 == result_1_dict)


# Generated at 2022-06-25 11:29:16.763129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    ansible_0 = lookup_module_0.run(my_list_0)
    assert ansible_0 is not None


# Generated at 2022-06-25 11:29:22.732408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    parameters_0 = [['/home/bradleyyoung/ansible/ansible/lib/ansible/plugins/lookup/together.py', 'test_case_0.py'], ['/home/bradleyyoung/ansible/ansible/lib/ansible/plugins/lookup/together.py', 'test_case_0.py']]
    parameters_1 = {'password': 'redhat', 'url_username': 'admin', 'force': False, 'validate_certs': False, 'url_password': 'redhat', 'sudo_user': 'root'}
    assert lookup_module_1.run(parameters_0, parameters_1) is not None

test_LookupModule_run()

# Generated at 2022-06-25 11:29:27.934610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args = [[[1, 2, 3], [4, 5, 6]]]
    assert lookup_module_1.run(args) == [[1, 4], [2, 5], [3, 6]]



# Generated at 2022-06-25 11:29:35.811793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([[1, 2], [3]]) == [[1, 3], [2, None]]

    lookup_module_2 = LookupModule()
    assert lookup_module_2.run([[1, 2], [3], [4], [5]]) == [[1, 3, 4, 5], [2, None, None, None]]

    lookup_module_3 = LookupModule()
    assert lookup_module_3.run([[1, 2]]) == [[1], [2]]

    lookup_module_4 = Lookup

# Generated at 2022-06-25 11:29:44.426210
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = list()
    terms_0.append([
        'a',
        'b',
        'c',
        'd'
    ])
    terms_0.append([
        1,
        2,
        3,
        4
    ])

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0)

    assert result_0

    assert result_0[0] == 'a'
    assert result_0[1] == 1

    assert result_0[2] == 'b'
    assert result_0[3] == 2

    assert result_0[4] == 'c'
    assert result_0[5] == 3

    assert result_0[6] == 'd'
    assert result_0[7] == 4

# Generated at 2022-06-25 11:29:49.656294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test of run')
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run({}) == [],'Empty term'
    assert lookup_module_0.run([[1,2,3],[4,5,6]]) == [[1,4],[2,5],[3,6]],'Common case'
    assert lookup_module_0.run([[1,2],[3]]) == [[1,3],[2,None]],'Unbalanced case'

# Generated at 2022-06-25 11:29:56.425322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        {
            '_ansible_no_log': False,
            '_ansible_verbosity': 0,
            '_terms': [
                [
                    'a',
                    'b',
                    'c',
                    'd'
                ],
                [
                    1,
                    2,
                    3,
                    4
                ]
            ]
        }
    ]
    variables = {
        'test_run_variables': {
            'item': {
                '0': 'a',
                '1': 1
            }
        }
    }

# Generated at 2022-06-25 11:30:05.845639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    t = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    result = [
        [1, 4],
        [2, 5],
        [3, 6]
    ]
    assert result == lookup_module.run(t)

# Generated at 2022-06-25 11:30:08.997650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run()
    except:
        raise Exception('run method not found in LookupModule class')


# Generated at 2022-06-25 11:30:14.876139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # getattr(x, 'y') --> x.y
    # setattr(x, 'y', v) --> x.y = v
    pass # TODO: implement your test here



# Generated at 2022-06-25 11:30:17.201187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = 'templar'
    lookup_module_0._loader = 'loader'
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:30:23.272682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0.run([""])
    lookup_module_0.run([""])


# Generated at 2022-06-25 11:30:28.622193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        ['a', 'b'],
        [1, 2]
    ]
    expected = [
        [['a', 1]],
        [['b', 2]]
    ]
    assert(lookup_module.run(terms) == expected)
    terms = [
        ['a', 'b', 'c'],
        [1, 2, 3]
    ]
    expected = [
        [('a', 1), ('b', 2), ('c', 3)]
    ]
    assert(lookup_module.run(terms) == expected)


# Generated at 2022-06-25 11:30:32.856703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l=LookupModule()
    l.run([['a', 'b', 'c'],['1', '2', '3']])

# Generated at 2022-06-25 11:30:35.900744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[['a', 'b', 'c', 'd'], [1, 2, 3, 4]], variables=None, **{'wantlist': True})

# Generated at 2022-06-25 11:30:37.369919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([], None)


# Generated at 2022-06-25 11:30:39.900704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([['a', 'b', 'c'], ['1', '2', '3']])


# Generated at 2022-06-25 11:30:50.443713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[1,2,3], [4,5,6]]
    result = LookupModule.run(LookupModule, terms)
    assert result == [(1, 4), (2, 5), (3, 6)]

# Generated at 2022-06-25 11:30:57.077583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=1, variables=1) == [(1,)]
    assert lookup_module_0.run(terms=(1, 2), variables=1) == [(1, 2)]
    assert lookup_module_0.run(terms=((1, 2), (3,)), variables=1) == [(1, 3), (2, None)]


# Generated at 2022-06-25 11:31:07.268607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()

    # Test with a list of lists
    result_0 = lookup_module_0.run([['a', 'b'], ['1', '2']])
    assert result_0 == [['a','1'], ['b', '2']]

    # Test with a list of single elements
    result_1 = lookup_module_1.run(['a', 'b'])
    assert result_1 == ['a', 'b']



# Generated at 2022-06-25 11:31:09.821313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [1, 2, 3]
    my_list[1] = 4
    assert my_list == [1, 4, 3]

# Generated at 2022-06-25 11:31:11.871277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:31:17.671025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('usage: test_LookupModule_run()')
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run()
        raise Exception('expected exception')
    except AnsibleError as error:
        assert repr(error) == "with_together requires at least one element in each list"
    print('=== done')


# Generated at 2022-06-25 11:31:20.791225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [[1, 2, 3], [4, 5, 6]]
    synchronised_list = [(1, 4), (2, 5), (3, 6)]
    assert lookup_module.run(terms) == synchronised_list


# Generated at 2022-06-25 11:31:29.338827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [[1, 2, 3], [4, 5, 6]]
    t = [1, 2, 3]
    u = [4, 5, 6]

    my_list[0] = listify_lookup_plugin_terms(t, templar=None, loader=None)
    my_list[1] = listify_lookup_plugin_terms(u, templar=None, loader=None)

    r = [lookup_module_0._flatten(x) for x in zip_longest(*my_list, fillvalue=None)]

    assert result[0] == [1,4]
    assert result[1] == [2,5]
    assert result[2] == [3,6]

# Generated at 2022-06-25 11:31:38.952250
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Try and look up a key not in the dictionary
    my_terms = [ None, ['a', 'b'], ['1', '2'] ]
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=my_terms) == [['a', '1'], ['b', '2']]

    # Try and look up a key not in the dictionary
    my_terms = [ None, ['a', 'b'], ['1'] ]
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=my_terms) == [['a', '1'], ['b', None]]

    # Try and look up a key not in the dictionary
    my_terms = [ None, ['a', 'b'], [] ]
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:31:43.600351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module0 = LookupModule()
    lookup_module0.run([['a', 'b', 'c'], [1, 2]])
    lookup_module2 = LookupModule()
    lookup_module2.run([['a'], [1]])

# Generated at 2022-06-25 11:32:05.771903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #If no exception is raised, test run of method run of class LookupModule is successful.
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[1, 2, 3], [4, 5, 6]])
    lookup_module_0.run([[1, 2], [3]])
    lookup_module_0.run([[]])
    lookup_module_0.run([[], []])


# Generated at 2022-06-25 11:32:11.499621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c'], [1, 2, 3]]
    lookup_module_0 = LookupModule()
    results_0 = lookup_module_0.run(terms)
    assert results_0 == [['a', 1], ['b', 2], ['c', 3]]

    # Unit test for method _lookup_variables of class LookupModule

# Generated at 2022-06-25 11:32:19.093365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        ['a', 'b', 'c'],
        ('d', 1, True, None),
        [{'a': 'b'}, {'c': 'd'}],
        'e',
    ]
    result = lookup_module.run(terms, loader=None, variables=None)
    assert result == [
        ('a', 'd', {'a': 'b'}, 'e'),
        ('b', 1, {'c': 'd'}, None),
        ('c', True, None, None),
    ]

# Generated at 2022-06-25 11:32:19.615847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 11:32:22.175008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['a', 'b', 'c'], [1, 2, 3]]
    variables_0 = None
    kwargs_0 = {'elements': 'list'}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

test_LookupModule_run()

# Generated at 2022-06-25 11:32:26.353344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_values = []

    expected_output = []

    lookup_module_0 = LookupModule()

    result = lookup_module_0.run(input_values)

    assert result == expected_output

# Generated at 2022-06-25 11:32:27.503667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:32:34.812648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ ]
    variables_0 = None
    kwargs_0 = {"loader": "loader_1", "templar": "templar_2"}
    kwargs_0.update({"loader": "loader_3", "templar": "templar_4"})
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == []


# Generated at 2022-06-25 11:32:40.148450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    out0 = lookup_module_0.run()
    #
    lookup_module_1 = LookupModule()
    out1 = lookup_module_1.run()
    assert out0 == out1

# Generated at 2022-06-25 11:32:42.855431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

##############
# END OF FILE
##############

# Generated at 2022-06-25 11:33:10.269638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '``v'
    var_0 = lookup_module_run(str_0, lookup_module_0)
    var_1 = []
    var_1.append(var_0)
    var_2 = lookup_module_run(str_0, lookup_module_0)
    var_1.append(var_2)
    var_3 = lookup_module_run(str_0, lookup_module_0)
    var_1.append(var_3)
    var_4 = lookup_module_run(str_0, lookup_module_0)
    var_1.append(var_4)
    var_5 = lookup_module_run(str_0, lookup_module_0)
    var_1.append(var_5)


# Generated at 2022-06-25 11:33:17.105195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['e3qYsQ8WHx', '', '', 'g3hk-2Hr'])
    lookup_module_0.run(['U8;:[e', '', '', '9E@0Ki-zB'])
    lookup_module_0.run(['=^%#', '', '', 'Hk\\\\q'])
    lookup_module_0.run(['\rN`;$)G', '', '', 'G'])
    lookup_module_0.run(['n@5*Yvu5=m', '', '', '|>0y2'])
    lookup_module_0.run(['', '', '', 'B]!#8&Ck'])
    lookup

# Generated at 2022-06-25 11:33:27.255379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = ['foo', 'bar']
    str_1 = 'foo'
    str_2 = 'bar'
    str_3 = 'foo'
    str_4 = 'bar'
    list_2 = ['foo', 'bar', 'baz']
    var_1 = lookup_module_1.run(list_1, variables=None, **kwargs)
    assert var_1 == [(str_1, str_2), (str_3, str_4)]
    var_1 = lookup_module_1.run(list_2, variables=None, **kwargs)
    assert var_1 == [(str_1, str_2), (str_3, str_4), (None, None)]


# Generated at 2022-06-25 11:33:29.596535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'tXe#t'
    var_1 = lookup_run(str_1)


# Generated at 2022-06-25 11:33:32.492462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '9'
    var_0 = lookup_run(str_0)

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:33:38.122495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '../backend/miniclient/ntlmssp.h'
    list_0 = []
    list_1 = []
    var_0 = lookup_module_0.run(list_0, list_1)
    assert var_0 == list_1


# Generated at 2022-06-25 11:33:40.330524
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up mock
    lookup_module = LookupModule()
    lookup_module.run = MagicMock(return_value=['foo','bar','baz'])

    assert lookup_module.run('foo','bar','baz') == ['foo','bar','baz']


# Generated at 2022-06-25 11:33:45.281491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-4gL\\j=cf#A)!'
    var_0 = lookup_run(str_0)
    terms = lookup_module_0._lookup_variables(terms)
    assert (terms == var_0)

# Generated at 2022-06-25 11:33:50.967824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    parm_0 = 'Hgc5#'
    parm_1 = {'ZD': '', '=@L': '^!8R', 'V': '', '=v3': 'xW8)', '^D=': '}+$2', 'P': '', '7VF': 'a3vI'}
    try:
        var_0 = lookup_module_0.run(parm_0, parm_1)
        assert False
    except AnsibleError as e:
        pass


# Generated at 2022-06-25 11:33:51.574654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME
    assert False


# Generated at 2022-06-25 11:34:41.313402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = [['a', 'b'], [1,2]]
  var_1 = [('a', 1), ('b', 2)]
  lookup_module_1 = LookupModule()
  var_2 = lookup_module_1.run(terms)
  assert var_2 == var_1


# Generated at 2022-06-25 11:34:50.577313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:34:53.257806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'h#:Ng#{]~<'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:35:01.882147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '^*eCVK'
    str_1 = 'ssdjXz>'
    str_2 = '8P<,=H;'
    str_3 = '0g0xSV'
    str_4 = '7{=^B4'
    str_5 = '|a7G'

    # Retrieve an un-mockable value from the lookup
    from ansible.module_utils.six.moves import zip_longest
    zip_longest = zip_longest


# Generated at 2022-06-25 11:35:08.636362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params_0 = {}
    params_1 = {}
    terms_0 = {}
    lookup_module_run_0 = LookupModule(params_0, params_1, terms_0)
    str_0 = '[1, 2, 3], [4, 5, 6] -> [1, 4], [2, 5], [3, 6]\nReplace any empty spots in 2nd array with None:\n[1, 2], [3] -> [1, 3], [2, None]'
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 11:35:09.205595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:35:10.086482
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO
    pass


# Generated at 2022-06-25 11:35:19.419627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TestCase with 1 list of 3 items and  1 list of 3 items
    my_list_0 = [['a', 'b', 'c'], [1, 2, 3]]
    looker = LookupModule()
    result_0 = looker.run(my_list_0)
    # TestCase with 1 list of 1 items and  1 list of 1 items
    my_list_1 = [['a'], [1]]
    result_1 = looker.run(my_list_1)
    # TestCase with 1 lists of 1 items and  2 lists of 1 items
    my_list_2 = [['a'], [1], ['b']]
    result_2 = looker.run(my_list_2)
    # TestCase with 2 lists of 1 items and  1 lists of 1 items
    my_list_

# Generated at 2022-06-25 11:35:21.246274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    terms = [
        [1, 2, 3],
        [4, 5, 6]
    ]

    result = lookup_mod.run(terms)

    assert result == [(1, 4), (2, 5), (3, 6)]


# Generated at 2022-06-25 11:35:22.686668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-4gL\\j=cf#A)!'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:36:49.815177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:36:53.412589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-4gL\\j=cf#A)!'
    var_0 = lookup_run(str_0)
    assert len(var_0) == 2
    assert type(var_0) == list
    assert var_0[0][0] == 'U'
    assert var_0[1][0] == 'v'

# Generated at 2022-06-25 11:36:56.149856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(loader=None, templar=None, variables=None)
    str_0 = '/'
    list_0 = ['/']
    list_1 = lookup_module_0.run(terms=list_0, variables=None, **None)
    assert list_0 == list_1


# Generated at 2022-06-25 11:36:57.222162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# --------------------------------------------------


# Generated at 2022-06-25 11:37:04.276683
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    str_1 = "8xDrs^m&V7p"
    str_2 = "g**"
    list_1 = []
    list_1.append(str_1)
    list_1.append(str_2)

    # Actual result
    actual_result_0 = lookup_module_1.run(list_1)

    # Expected result
    expected_result_0 = [('8xDrs^m&V7p', 'g**')]
    assert expected_result_0 == actual_result_0

# Generated at 2022-06-25 11:37:07.935247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'f=dP>|l4cZm'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:37:11.815139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'a,b,c'
    var_0 = lookup_run(str_0)
    assert var_0 == [['a'], ['b'], ['c']]


# Generated at 2022-06-25 11:37:21.177784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    str_0 = '-4gL\\j=cf#A)!'
    var_0 = lookup_run(str_0)
    assert(var_0 == str_0)

    str_0 = 'z$5Q5'
    var_0 = lookup_run(str_0)
    assert(var_0 == str_0)

    str_0 = '|*+.>L-?3q!aW'
    var_0 = lookup_run(str_0)
    assert(var_0 == str_0)

    str_0 = 'yJwOHF&b'
    var_0 = lookup_run(str_0)
    assert(var_0 == str_0)
