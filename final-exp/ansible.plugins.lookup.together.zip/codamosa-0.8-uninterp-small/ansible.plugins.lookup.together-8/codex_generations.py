

# Generated at 2022-06-25 11:27:24.336241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        '_templar': None, 
        '_loader': None, 
        '_lookup_variables': {}, 
        '_flatten': {}, 
    }
    f = LookupModule(**args)
    assert f.run(terms=["terms"]) == None

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 11:27:29.181896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Run all unit tests

# Generated at 2022-06-25 11:27:34.056834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[['a', 'b', 'c'], [1, 2, 3]])


# Generated at 2022-06-25 11:27:37.354255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[["a","b","c","d"],[1,2,3,4]])



# Generated at 2022-06-25 11:27:41.035686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()

    # Setup input
    terms = [['a'], [1]]

    # Setup output
    expected_out = [['a', 1]]

    # Run test
    actual_out = lookup_module_0.run(terms)

    assert actual_out == expected_out

# Generated at 2022-06-25 11:27:42.881350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_list = [["1"], ["2"]]
    assert lookup_module.run(my_list) == [["1", "2"]]

# Generated at 2022-06-25 11:27:48.512356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = ['a', 'b', 'c', 'd']
    other_list = [1, 2, 3, 4]
    set_fixture_0 = lookup_module_0.run(terms=[my_list, other_list], variables='os')
    assert set_fixture_0 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]



# Generated at 2022-06-25 11:27:55.593905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list = [
        [u'a', u'b', u'c', u'd'],
        [1, 2, 3, 4]
    ]
    assert lookup_module_1.run(my_list) == \
    [[u'a', 1], [u'b', 2], [u'c', 3], [u'd', 4]]



# Generated at 2022-06-25 11:27:58.737230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    [test_LookupModule_run_param_0] = lookup_module_0.run('test string')

    assert isinstance(test_LookupModule_run_param_0, list)
    pass

# Generated at 2022-06-25 11:28:01.664612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [['a', 'b'], [1, 2, 3]]
    variables = None
    kwargs = {}
    returned = lookup_module_1.run(terms_1, variables, **kwargs)
    assert returned == [['a', 1], ['b', 2]]

# Generated at 2022-06-25 11:28:14.274274
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for result of method run of class LookupModule
    print("\nUnit test for method run of class LookupModule")
    print("===============================================\n")

    terms = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    lookup_module_1 = LookupModule()
    expected_result_1 = [
        (1, 4),
        (2, 5),
        (3, 6)
    ]
    print("Test Case #1\nExpected result: ", expected_result_1)

    result_1 = lookup_module_1.run(terms)
    print("Result: ", result_1)
    assert result_1 == expected_result_1

    terms = [
        [1, 2],
        [3]
    ]
    expected_result_2

# Generated at 2022-06-25 11:28:21.529163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    lookup_module_0.run(my_list)
    my_list[0] = ["test1", "test2", "test3"]
    lookup_module_0.run(my_list)
    my_list[0] = ["test4", "test5", "test6"]
    lookup_module_0.run(my_list)


# Example for test_case

# Generated at 2022-06-25 11:28:28.920980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=[['a','b','c','d'],[1,2,3,4]], variables=None) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:28:34.266089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            'a',
            'b'
        ],
        [
            '1',
            '2'
        ]
    ]
    expected = [
        [
            'a',
            '1'
        ],
        [
            'b',
            '2'
        ]
    ]
    result = LookupModule().run(terms)
    assert result == expected

# Generated at 2022-06-25 11:28:37.227727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [[1, 2, 3], [4, 5, 6]]
    result_1 = lookup_module_1.run(terms_1)
    assert result_1 == [[1, 4], [2, 5], [3, 6]]


# Generated at 2022-06-25 11:28:40.656305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [['a','b','c','d'], [1,2,3,4]]
    lookup_module_0 = LookupModule()
    list_with_together = lookup_module_0.run(terms=my_list)

# Generated at 2022-06-25 11:28:43.952836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['test', 'test1'])

# Generated at 2022-06-25 11:28:52.361075
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup a test case

    class Mock_AnsibleError:
        def __init__(self, msg):
            self.msg = msg
            return None

    # first test: expected behavior for empty list error
    my_lookup_module_1 = LookupModule()
    my_test_case_1 = []
    my_lookup_module_1._templar = None
    my_lookup_module_1._loader = None
    my_AnsibleError_1 = None
    try:
        my_result_1 = my_lookup_module_1.run(my_test_case_1, None)
    except AnsibleError as e:
        my_AnsibleError_1 = Mock_AnsibleError(e)

# Generated at 2022-06-25 11:28:59.811426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = lambda self, val: [val]
    terms_0 = [
        [
            'a',
            'b',
            'c',
            'd',
        ],
        [
            1,
            2,
            3,
            4,
        ],
    ]
    lookup_module_0._lookup_variables = lambda x: terms_0
    assert lookup_module_0.run(terms_0) == [
        ['a', 1],
        ['b', 2],
        ['c', 3],
        ['d', 4],
    ]

# Generated at 2022-06-25 11:29:08.033104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # example test case
    # static initial values
    terms = [
        [1, 2, 3], [4, 5, 6], [7, 8, 9]
    ]

    # method instance
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms)
    # expected result
    expected_result_0 = [[1, 4, 7],
                         [2, 5, 8],
                         [3, 6, 9]]

    assert result_0 == expected_result_0, "result_0 mismatch"



# Generated at 2022-06-25 11:29:13.217934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {u'packages': [u'foo', u'bar']}
    x_0 = lookup_module_0.run(terms_0, variables=variables_0)

# Generated at 2022-06-25 11:29:18.879969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("[*] Testing LookupModule.run...")
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run([])
        assert False
    except Exception:
        print("[*] Test case 1 passed!")


# Generated at 2022-06-25 11:29:20.902787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    ret = lookup_module_0.run(terms=terms, variables=variables)
    print(ret)

# Generated at 2022-06-25 11:29:24.144010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    array_arg = [['2', '3', '4', '5'], ['a', 'b', 'c', 'd', 'e']]
    var_arg = None
    ret = lookup_module_0.run(array_arg, var_arg)
    assert ret == [[2, 'a'], [3, 'b'], [4, 'c'], [5, 'd']], 'Test Failed'

# Generated at 2022-06-25 11:29:28.302804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert lookup_module_1.run([['a', 'b'], [1, 2, 3, 4]]) == [('a', 1), ('b', 2), (None, 3), (None, 4)]
    assert lookup_module_1.run([['a', 'b', 'c', 'd'], [1, 2]]) == [('a', 1), ('b', 2), (None, None), (None, None)]
    assert lookup_module_1.run([]) == []


# Generated at 2022-06-25 11:29:36.241891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # [1, 2, 3], [4, 5, 6] -> [1, 4], [2, 5], [3, 6]
    # [1, 2], [3] -> [1, 3], [2, None]
    # [] -> exception
    # [None] -> exception

    # [1, 2, 3], [4, 5, 6] -> [1, 4], [2, 5], [3, 6]
    my_list0 = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    result = lookup_module.run(terms=my_list0, variables=None, **{})
    result_expected = [
        [1, 4],
        [2, 5],
        [3, 6]
    ]
    assert result

# Generated at 2022-06-25 11:29:37.009358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:29:43.475022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    ansible_l_res_0 = []

    ansible_l_res_0 = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

    terms_0 = ['a', 'b', 'c', 'd']
    terms_1 = [1, 2, 3, 4]

    ansible_l_res_1 = lookup_module_0.run([terms_0, terms_1])

    assert ansible_l_res_0 == ansible_l_res_1


# Generated at 2022-06-25 11:29:50.714474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['a', 'b', 'c', 'd']
    terms_1 = [1, 2, 3, 4]
    terms_0.sort()
    terms_1.sort()
    results_0 = lookup_module_0.run(terms_0, terms_1)
    # AssertionError: assert list_0 == list_1
    # +  where list_0 = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    # +    and list_1 = [None, None, None, None]
    # +    and list_2 = ['a', 'b', 'c', 'd']



# Generated at 2022-06-25 11:29:56.531596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert lookup_instance.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]


# Generated at 2022-06-25 11:30:06.037596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module is not None
    assert lookup_module.run(None, None) is None
    assert lookup_module.run([[[[]]]], None) is None
    assert lookup_module.run(['a'], None) == [['a']]


# Generated at 2022-06-25 11:30:13.745555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    my_list = [{'key1': 'value1'}, {'key2': 'value2'}, {'key3': 'value3'}]
    my_list[0].update(my_list[1])
    my_list[0].update(my_list[2])
    my_list[1].update(my_list[2])
    assert([{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}, {'key2': 'value2', 'key3': 'value3'}] == test_obj._run(my_list))


# Generated at 2022-06-25 11:30:17.833695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError('test_LookupModule_run not implemented')

# Generated at 2022-06-25 11:30:22.772021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert "AnsibleError" in str(test_case_0.test_LookupModule_run())


test_case_0 = LookupModule()
assert "AnsibleError" in str(test_case_0.test_LookupModule_run())

# Generated at 2022-06-25 11:30:27.644883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test case will fail?:
    lookup_module_1 = LookupModule()
    # lookup_module_1.run()

if __name__ == '__main__':
    test_case_0()

    # test_LookupModule_run()

# Generated at 2022-06-25 11:30:32.895381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([["a", "b"], ["1", "2"]])
    assert result == [["a", "1"], ["b", "2"]]
    pass


# Generated at 2022-06-25 11:30:37.209734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # If no arguments are provided then the method raises an error
    with pytest.raises(AnsibleError):
        lookup_module_0.run()

    # The method run returns the correct output
    assert (lookup_module_0.run('[[1, 2, 3], []]', '{{ my_list[0] }}') == '1')


# Generated at 2022-06-25 11:30:41.068904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        'terms': [
            [
                '1',
                '2',
                '3'
            ],
            [
                '4',
                '5',
                '6'
            ]
        ],
        'variables': None
    }
    lookup_module = LookupModule()
    result = lookup_module.run(**args)
    assert result == [
        ['1', '4'],
        ['2', '5'],
        ['3', '6']
    ]


# Generated at 2022-06-25 11:30:42.592338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['a', 1]) == [('a', 1)]


# Generated at 2022-06-25 11:30:53.311183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()

    # execute test method
    ret_0 = lookup_module_0.run([])
    ret_1 = lookup_module_1.run([[0], [0]])
    ret_2 = lookup_module_2.run([[1, 2, 3], [0]])

# Generated at 2022-06-25 11:31:03.249929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list_0 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    my_list_1 = [None]
    lookup_module_1 = LookupModule()
    lookup_module_1.run(my_list_0, my_list_1)
    
    

# Generated at 2022-06-25 11:31:06.482715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([[1, 2, 3], [4, 5, 6]])



# Generated at 2022-06-25 11:31:09.906408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case for run of method LookupModule
    terms_0 = [[1, 2, 3], [4, 5, 6]]
    variables_0 = None
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == [(1, 4), (2, 5), (3, 6)]


# Generated at 2022-06-25 11:31:19.602549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[['a', 'b', 'c', 'd'], [1, 2, 3, 4]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=[['a', 'b', 'c', 'd'], [1, 2, 3, 4, 5]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4], [None, 5]]

# Generated at 2022-06-25 11:31:24.811370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([])
    assert 'requires at least one element in each list' in to_text(excinfo.value)

# Generated at 2022-06-25 11:31:33.359738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67],
        [
            'foo',
            'bar',
            'bar',
            'baz',
            'qux',
            'quux',
            'corge',
            'grault',
            'garply',
            'waldo',
            'fred',
            'plugh',
            'xyzzy',
            'thud',
            'foo',
            'bar',
            'bar',
            'baz',
            'qux',
            'quux'
        ]
    ]
    variables_0 = None
    result = lookup_module_0.run

# Generated at 2022-06-25 11:31:35.664202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as execinfo:
        lookup_module_0 = LookupModule()
        lookup_module_0.run([])
    assert 'with_together requires at least one element in each list' in str(execinfo.value)

# Generated at 2022-06-25 11:31:39.540589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print
    lookup_module_1 = LookupModule()
    terms=[['a','b','c','d'],[1,2,3,4]]
    result=lookup_module_1.run(terms)

# Generated at 2022-06-25 11:31:44.253883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_method(self, terms, variables=None, **kwargs):
        pass

    setattr(LookupModule, 'run', test_method)
    lookup_module_1 = LookupModule()
    lookup_module_1.run("test_term")
    

# Generated at 2022-06-25 11:31:53.859996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()

    assert lookup_module_0.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
    assert lookup_module_0.run([['a', 'b'], [1, 2, 3, 4]]) == [['a', 1], ['b', 2], [None, 3], [None, 4]]
    assert lookup_module_1.run([]) == AnsibleError("with_together requires at least one element in each list")

# Generated at 2022-06-25 11:32:05.686134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup_module = LookupModule()
    my_terms = [
        [1, 3, 5],
        [2, 4, 6]
    ]
    my_result = my_lookup_module.run(terms=my_terms)
    my_expected_result = [
        [1, 2],
        [3, 4],
        [5, 6]
    ]
    assert my_result == my_expected_result


# Generated at 2022-06-25 11:32:10.940121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #Test with _ansible_verbosity being 0.
    lookup_module_0._ansible_verbosity = 0
    terms_0 = ["abcd","1"]
    variables_0 = "abcd"
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == [('a',1),('b',None),('c',None),('d',None)]


# Generated at 2022-06-25 11:32:19.315462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    class MockedVariables0():
        def get_vars(self, loader, templar, each_item):
            return 'mocked_variables'

    mocked_variables_0 = MockedVariables0()
    mocked_templar_0 = 'mocked_templar'

    result_0 = lookup_module_0.run(terms=['terms_0'], variables=mocked_variables_0, loader=mocked_templar_0)
    assert result_0 == ['terms_0']


# Generated at 2022-06-25 11:32:25.690046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = 255
    my_test_case = 0
    print("Test Case {0}".format(my_test_case))
    lookup_module = LookupModule()
    my_list = [1, 2, 3], [4, 5, 6]
    try:
        assert(lookup_module.run(my_list) == [[1, 4], [2, 5], [3, 6]])
        print("Test Case {0} passed".format(my_test_case))
    except AssertionError as e:
        print("Test Case {0} failed".format(my_test_case))
        print(e)
        assert()
    my_test_case += 1
    print("Test Case {0}".format(my_test_case))
    lookup_module = LookupModule()
    my_list

# Generated at 2022-06-25 11:32:34.481239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Copy params to ensure the tests do not modify the original values
    terms_0 = ['a', 'b', 'c', 'd']
    parameters_0 = {'variables': None, 'terms': terms_0, 'kwargs': {}}

    with pytest.raises(AnsibleError, match="with_together requires at least one element in each list"):
        lookup_module_0.run(**parameters_0)

# Generated at 2022-06-25 11:32:39.644068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["tests.yml", "tests", "ansible-modules-hashivault"]) == ''


# Generated at 2022-06-25 11:32:45.457907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([[['A', 'B'], ['C', 'D']], [['1', '2'], ['3', '4']]])
    assert result == [['A', '1'], ['B', '2'], ['C', '3'], ['D', '4']], result


# Generated at 2022-06-25 11:32:50.489491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    source_list = \
[['1', '2', '3'], ['4', '5', '6']]
    lookup_module = LookupModule()
    expected_result = [['1', '4'], ['2', '5'], ['3', '6']]
    actual_result = lookup_module.run(source_list)
    assert actual_result == expected_result
    return


# Generated at 2022-06-25 11:32:57.459626
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Because the first argument is "self", we omit it in this function
    lookup_module_1 = LookupModule()

    result_run_1 = lookup_module_1.run()
    assert result_run_1 == [], 'Method run of class LookupModule has failed'

    result_run_2 = lookup_module_1.run(None, None, None)
    assert result_run_2 == [], 'Method run of class LookupModule has failed'

    result_run_3 = lookup_module_1.run(['1', '2', '3'], ['4', '5', '6'])
    assert result_run_3 == ['1', '4', '2', '5', '3', '6'], 'Method run of class LookupModule has failed'


# Generated at 2022-06-25 11:33:00.228497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  term_0 = {'a', 'b'}
  variables_0 = {'a', 'b'}
  test_case_0()
  test_case_1()

# Generated at 2022-06-25 11:33:16.399532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    initial_values = [
        [
            [
                'a',
                'b',
                'c',
                'd',
                'e'
            ],
            [
                '1',
                '2',
                '3',
                '4',
                '5'
            ],
            [
                'A',
                'B',
                'C',
                'D',
                'E'
            ]
        ]
    ]
    expected = [
        ('a', '1', 'A'),
        ('b', '2', 'B'),
        ('c', '3', 'C'),
        ('d', '4', 'D'),
        ('e', '5', 'E')
    ]
    result = lookup_module_0.run(initial_values)

# Generated at 2022-06-25 11:33:27.019517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = None
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = None
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == []
    lookup_module_2 = LookupModule()
    terms_2 = []
    variables_2 = None
    kwargs_2 = {}
    assert lookup_module_2.run(terms_2, variables_2, **kwargs_2) == []



# Generated at 2022-06-25 11:33:32.599570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_result_expected = [[1, 4], [2, 5], [3, 6]]
    l_result_real = LookupModule().run(
        terms=[[1, 2, 3], [4, 5, 6]],
        variables=None,
        **{}
    )
    print("DIFF: ", l_result_expected, " != ", l_result_real)
    assert l_result_expected == l_result_real

# Generated at 2022-06-25 11:33:36.968819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [[1,2]]
    result = lookup_module_0.run(terms)
    assert result == [[1], [2]]



# Generated at 2022-06-25 11:33:38.103673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run() == None)


# Generated at 2022-06-25 11:33:41.378269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    print(LookupModule().run(terms))

    terms = [['a', 'b', 'c'], [1, 2, 3], [4, 5, 6]]
    print(LookupModule().run(terms))

# Generated at 2022-06-25 11:33:46.122716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = {'terms': [['a', 'b', 'c'], [1, 2, 3, 4]]}
    expected_result = [['a', 1], ['b', 2], ['c', 3], [None, 4]]
    result = lookup_module_0.run(**args)
    if result != expected_result:
        raise AssertionError()

    args = {'terms': [['a', 'b'], [1, 3]]}
    expected_result = [['a', 1], ['b', 3]]
    result = lookup_module_0.run(**args)
    if result != expected_result:
        raise AssertionError()



# Generated at 2022-06-25 11:33:50.592582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b'], [1, 2]]
    expected = [('a', 1), ('b', 2)]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms)
    assert result == expected


# Generated at 2022-06-25 11:33:57.818207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [{u'a': u'b', u'c': u'd'}, {u'e': u'f', u'g': u'h'}]
    l0 = LookupModule().run(my_list, variables='', **{})
    assert l0[0][0] == 'b'
    assert l0[0][1] == 'f'
    assert l0[1][0] == 'd'
    assert l0[1][1] == 'h'

# Generated at 2022-06-25 11:34:08.204730
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    res_0 = lookup_module_0.run(['a', 'b', 'c', 'd'], ['1', '2', '3', '4'])

    assert res_0[0][0] == 'a'
    assert res_0[0][1] == '1'
    assert res_0[1][0] == 'b'
    assert res_0[1][1] == '2'
    assert res_0[2][0] == 'c'
    assert res_0[2][1] == '3'
    assert res_0[3][0] == 'd'
    assert res_0[3][1] == '4'

    res_1 = lookup_module_0.run([], ['1', '2', '3', '4'])

# Generated at 2022-06-25 11:34:33.423274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True == True

# Generated at 2022-06-25 11:34:37.729057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    try:
        lookup_module_0.run(terms_0)
    except AnsibleError:
        pass
    else:
        assert False  # Expected error here.


# Generated at 2022-06-25 11:34:40.527749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    _list_1 = lookup_module_1.run()
    assert _list_1 == None



# Generated at 2022-06-25 11:34:47.448900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Passing in a list of lists
    my_list = [['a', 'b', 'c'], ['d', 'e', 'f']]
    result = LookupModule().run(terms=my_list, variables=None, **{})
    assert result == [['a', 'd'], ['b', 'e'], ['c', 'f']]

    # Passing in 2 lists
    my_list = [['a', 'b', 'c'], ['d', 'e', 'f']]
    result = LookupModule().run(terms=my_list, variables=None, **{})
    assert result == [['a', 'd'], ['b', 'e'], ['c', 'f']]

    # Passing in an integer and a list
    my_list = [1, ['a', 'b', 'c']]


# Generated at 2022-06-25 11:34:54.195345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    S = lookup_module_1.run(terms = [
    [
        'a', 'b', 'c', 'd'
    ], [
        1, 2, 3, 4
    ]
    ],
    variables = None)
    assert S == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]



# Generated at 2022-06-25 11:34:57.696049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule()
        lookup_module_0.run([])


# Generated at 2022-06-25 11:35:02.511399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[1, 2, 3]]
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:35:09.022858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = lambda x: x
    lookup_module_0.run([([1, 2], [3, 4]), ([5, 6], [7, 8])])
    lookup_module_0.run([([1, 2], [3, 4]), ([5, 6], [7, 8])], variables=None)
    lookup_module_0.run([([1, 2], [3, 4]), ([5, 6], [7, 8])], variables=None, **{})
    lookup_module_0.run([([1, 2], [3, 4]), ([5, 6], [7, 8])], variables=None, **{'foo': 'bar'})


if __name__ == '__main__':
    test_case_0()
    test_Look

# Generated at 2022-06-25 11:35:13.767114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # 6 == len(zip_longest(*my_list, fillvalue=None))
    assert lookup_module_0.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4, 5, 6]], variables=None, **{}) == [['a', 1], ['b', 2], ['c', 3], ['d', 4], [None, 5], [None, 6]]
    assert lookup_module_0.run([['a', 'b', 'c', 'd', 'e', 'f'], [1, 2, 3, 4, 5, 6]], variables=None, **{}) == [['a', 1], ['b', 2], ['c', 3], ['d', 4], ['e', 5], ['f', 6]]


# Generated at 2022-06-25 11:35:17.541762
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_1.run(terms=[], variables=None , **{})

    lookup_module_2 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_2.run(terms=[['a', 'b'], ['1', '2']], variables=None , **{})


# Generated at 2022-06-25 11:36:13.157741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert [lookup_module_1.run([], {})] == [[]]
    assert [lookup_module_1.run([[1, 2, 3], [4, 5, 6]], {})] == [[[1, 4], [2, 5], [3, 6]]]
    assert [lookup_module_1.run([[1, 2], [3]], {})] == [[[1, 3], [2, None]]]
    assert [lookup_module_1.run([[1], [2]], {})] == [[[1, 2]]]
    assert [lookup_module_1.run([[1], [2], [3], [4], [5], [6]], {})] == [[[1, 2, 3, 4, 5, 6]]]

# Generated at 2022-06-25 11:36:17.137133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.run([[1, 2], [3, 4]])

# Generated at 2022-06-25 11:36:23.860984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    result = lookup_module_0.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]])

    assert result == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
#test_LookupModule_run


# Generated at 2022-06-25 11:36:28.780244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten([[1]]) == [1]
    lookup_module_0._flatten([[['a']]]) == ['a']



# Generated at 2022-06-25 11:36:31.269965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(terms=[[4, 5, 6], [1, 2, 3]])
    assert results == [
        [4, 1, None],
        [5, 2, None],
        [6, 3, None]
    ]

# Generated at 2022-06-25 11:36:36.523945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Trivial case: no list given
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([], variables=None)
    # Single list given
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([ ['a', 'b'] ], variables=None)
    # Incomplete lists given
    terms = [['a', 'b'], [1]]
    results = lookup_module_0.run(terms, variables=None)
    expected = [['a', 1], ['b', None]]
    assert results == expected
    # Complete lists given
    terms = [['a', 'b'], [1,2]]

# Generated at 2022-06-25 11:36:44.827180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    terms = [
        [
            'a',
            'b',
            'c',
            'd'
        ],
        [
            1,
            2,
            3,
            4
        ]
    ]

    expected = [
        [
            'a',
            1
        ],
        [
            'b',
            2
        ],
        [
            'c',
            3
        ],
        [
            'd',
            4
        ]
    ]

    # Act
    actual = lookup_module_0.run(terms)

    # Assert
    assert isinstance(actual, list) == True
    assert actual == expected


# Generated at 2022-06-25 11:36:47.724389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_terms = []
    my_variables = None
    my_expected = []
    my_expected = []
    assert lookup_module_0.run(my_terms, my_variables) == my_expected

# Generated at 2022-06-25 11:36:51.251845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Check if the results from method 'run' is equal to the expected result
    assert lookup_module_0.run([['a','b','c','d'], [1,2,3,4]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]], 'Test Failed'

# Generated at 2022-06-25 11:36:56.797611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments = [
        'item0',
        'item1'
    ]
    result = lookup_module_0.run(arguments)
    assert result == []
