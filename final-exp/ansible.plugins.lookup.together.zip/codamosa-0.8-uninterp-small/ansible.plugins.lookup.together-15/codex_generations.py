

# Generated at 2022-06-25 11:27:23.458059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = None
    kwargs_0 = {}

    lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)

# Generated at 2022-06-25 11:27:32.467599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initiate class to test
    lookup_module = LookupModule()

    # Test with empty list
    my_list = []
    assert lookup_module.run(my_list) == []

    # Test with list with one element
    my_list = ['a']
    assert lookup_module.run(my_list) == [('a', None)]

    # Test with list with two elements
    my_list = ['a', 'b']
    assert lookup_module.run(my_list) == [('a', 'b')]

    # Test with list with multiple element
    my_list = ['a', 'b', 'c', 'd']
    assert lookup_module.run(my_list) == [('a', 'b', 'c', 'd')]



# Generated at 2022-06-25 11:27:34.856205
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    x = 1
    if x > 2:
        assert x
    else:
        assert x

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:27:38.744637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = list(range(5))
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=my_list)
    assert len(result) == 5
    assert result[2] == 2


# Generated at 2022-06-25 11:27:41.982689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Providing a basic look up for method run
    lookup_module_0 = LookupModule()
    terms = ['random_list']
    result = lookup_module_0.run(terms)
    assert isinstance(result, list) == True
    assert isinstance(result, list) == True


# Generated at 2022-06-25 11:27:46.717398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]

# Generated at 2022-06-25 11:27:54.659078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = lambda x: x
    lookup_module_0._lookup_variables = lambda terms: terms
    lookup_module_0._templar = lambda: None
    lookup_module_0._loader = lambda: None

    my_list = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4]
    ]

    expected_result = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

    assert lookup_module_0.run(my_list) == expected_result
    print("test_LookupModule_run passed")

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:00.073287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests [[1, 2], [3]] -> [[1, 3], [2, None]]
    lookup_module_0 = LookupModule()
    results_0 = lookup_module_0.run([[1, 2], [3]])
    assert results_0 == [[1, 3], [2, None]], "List transpose"


# Generated at 2022-06-25 11:28:03.881859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()

    result_0 = lookup_module_0._lookup_variables([['a', 'b', 'c'], ['1', '2', '3']])
    # Verify the contents of the return value
    assert result_0 == [['a', 'b', 'c'], ['1', '2', '3']]


# Generated at 2022-06-25 11:28:09.316320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test_terms_0', 'test_terms_1']
    variables_0 = None
    kwargs_0 = {'test_kwargs_0': 'test_kwargs_1'}

    result_0 = lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)
    assert type(result_0) == list
    assert len(result_0) == 2
    assert result_0[0] == 'test_terms_0'
    assert result_0[1] == 'test_terms_1'

# Generated at 2022-06-25 11:28:14.863529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
# # test_case_0
#     test_case_0_0 = [
#         'x',
#         [[
#             'a',
#             'b'
#         ]],
#         {
#
#         }
#     ]
#     test_case_0_1 = [
#         'x',
#         [[
#             'a',
#             'b'
#         ]],
#         {
#
#         }
#     ]
#     test_case_0_2 = [
#         'x',
#         [[
#             'a',
#             'b'
#         ]],
#         {
#
#         }
#     ]
#     test_case_0_3 = [
#         'x',


# Generated at 2022-06-25 11:28:19.413162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_result_0 = ['a', '1']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['a', '1']) == template_result_0



# Generated at 2022-06-25 11:28:23.022956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = (list(), list())
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert len(result_0) == 0


# Generated at 2022-06-25 11:28:24.852000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['1'], {'1': '2'}), list)


# Generated at 2022-06-25 11:28:26.961234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_list = [["a", "b", "c", "d"], [1, 2, 3, 4]]
    lookup_module.run(my_list)

# Generated at 2022-06-25 11:28:30.767576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import zip_longest

    # this will not work until i have a proper mock
    lookup_module_1 = LookupModule()
    terms_1 = [[1,2,3],[4,5,6]]
    ret = [(1,4),(2,5),(3,6)]
    assert(list(zip_longest(*terms_1, fillvalue=None)) == ret)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:28:39.897790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # from ansible.plugins.lookup import LookupBase
    # from ansible.plugins.lookup import LookupModule
    # from ansible.template import Templar
    # from ansible.template import Jinja2
    # from ansible.module_utils._text import to_bytes
    # from ansible.module_utils._text import to_native
    # from ansible.module_utils.six import iteritems
    # from ansible.errors import AnsibleError
    # from ansible.utils.listify import listify_lookup_plugin_terms
    # from ansible.module_utils.six.moves import zip_longest

    # Test with parameters (self, terms, variables=None, inject=None)
    # __with_files_0 = inject.get('files', [

# Generated at 2022-06-25 11:28:51.216207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    assert lookup_module_0.run([[0.0, 1.0], [1.0, 2.0], [2.0, 3.0]]) == [[0.0, 1.0, 2.0], [1.0, 2.0, 3.0]]
    assert lookup_module_1.run([[0.0, 1.0, 2.0], [1.0, 2.0, 3.0]]) == [[0.0, 1.0], [1.0, 2.0], [2.0, 3.0]]

# Generated at 2022-06-25 11:28:58.572842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with 'terms' as null
    my_list = None
    terms = my_list
    variables = None
    kwargs = {}
    try:
        result = lookup_module_0.run(terms, variables, **kwargs)
    except Exception as e:
        error_msg = str(e)
        assert True, error_msg


# Generated at 2022-06-25 11:29:05.913107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:29:13.252345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Filter out argument variables so that the assertions don't
    # also test how we handle invalid input.
    args = dict(terms=['a', 'b', 'c'], variables={})
    # call the run() method passing in valid args
    lookup_module_0.run(variables=args['variables'], **args)



# Generated at 2022-06-25 11:29:17.325502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(), list)

# Generated at 2022-06-25 11:29:22.760383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'foo',
            'bar'
        ],
        [
            'baz',
            'qux'
        ]
    ]
    var_0 = [
        [
            'foo',
            'bar'
        ],
        [
            'baz',
            'qux'
        ]
    ]
    result_0 = lookup_module_0.run(terms=terms_0, variables=var_0)
    assert result_0 == [['foo', 'baz'], ['bar', 'qux']]
# end class LookupModule


# Generated at 2022-06-25 11:29:28.479716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    
    # Invoke
    result = lookup_module_0.run(terms, variables)
    
    # Assert
    assert_result_is_equal_to(result, default_value)



# Generated at 2022-06-25 11:29:30.460452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([[1, 2, 3], [5, 6, 7]])
    ret = lookup_module_1.run([[1, 2, 3], [5, 6, 7]])
    assert ret == [[1, 2, 3], [5, 6, 7]]
    assert ret != [[1, 5], [2, 6], [3, 7]]


# Generated at 2022-06-25 11:29:35.452582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for 'run' method of class LookupModule
    """
    lookup_module_0 = LookupModule()

    # Test case for run with expected parameter
    terms_0 = ['a', 'b']
    variables_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print("An exception of type {} occured. Arguments:\n{!r}".format(type(e).__name__, e.args));

# Generated at 2022-06-25 11:29:38.997015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [('a', 1), ('b', 2), ('c', 3), ('d', 4)] == lookup_module.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]])

# Generated at 2022-06-25 11:29:40.992821
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with argument terms
    lookup_module = LookupModule()
    result = lookup_module.run(terms=[])
    assert result == []

# Generated at 2022-06-25 11:29:48.344879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Calling with_together function on lookup_module_0 with arguments (list(list())) returns
    if lookup_module_0.run(list(list())) != (list(list())):
        raise AssertionError("AnsibleLookupModuleTest.test_LookupModule_run:1 Failed")
    # Calling with_together function on lookup_module_0 with arguments (list(list()), dict()) returns
    if lookup_module_0.run(list(list()), dict()) != (list(list()), dict()):
        raise AssertionError("AnsibleLookupModuleTest.test_LookupModule_run:2 Failed")
    # Calling with_together function on lookup_module_0 with arguments (list(list()), dict(), dict()) returns

# Generated at 2022-06-25 11:29:50.210911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(dict())


# Generated at 2022-06-25 11:29:58.858801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # print(lookup_module_0.run(
    #     ["[[ \"{{ inventory_hostname }}\" == 'oracle01' ]]", "all", "[\"{{ inventory_hostname }}\"]"],
    #     {"inventory_hostname": "oracle01"}))
    print(lookup_module_0.run(["{{ inventory_hostname }}", "all", "{{ inventory_hostname }}"], {"inventory_hostname": "oracle01"}))
    assert True

# Generated at 2022-06-25 11:30:02.087941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(["arg0", "arg1", "arg2"], "arg3")
    assert result is not None
    assert result[0] is not None
    assert result[1] is not None

# Generated at 2022-06-25 11:30:07.697885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test function signature of method run
    lookup_module_0.run(terms=[], variables={})
    # Test for exception raised
    # self.assertRaises(AnsibleError, lambda: lookup_module_0.run(, variables={}))


# Generated at 2022-06-25 11:30:08.502006
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is the test case
    assert 0

# Generated at 2022-06-25 11:30:17.034666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_list = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]
    test_list2 = [
        [1, 2, 3],
        [4, 5, 6],
    ]
    test_list3 = [
        [1, 2, 3]
    ]
    test_list4 = []
    lookup_module = LookupModule()
    assert [x for x in lookup_module.run(test_list)] == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]


# Generated at 2022-06-25 11:30:20.505460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['', '', '']
    lookup_module_0.run(terms, variables=None, **None)



# Generated at 2022-06-25 11:30:28.783045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nUNIT TEST 1: BEGIN\n")

    lookup_module_1 = LookupModule()
    my_list_1 = [[0, 1], [2, 3], [4, 5]]

    expected_result_1 = [[0, 2, 4], [1, 3, 5]]
    actual_result_1 = lookup_module_1.run(my_list_1)

    print("\nExpected Result for test_LookupModule_run 1: {0}".format(expected_result_1))
    print("Actual Result for test_LookupModule_run 1: {0}".format(actual_result_1))

    assert expected_result_1 == actual_result_1


    my_list_2 = [[0, 1], [2, 3]]


# Generated at 2022-06-25 11:30:33.672756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]



# Generated at 2022-06-25 11:30:42.174133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    yaml_0 = None
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_1 = dict()
    dict_1['foo'] = 'zzz'
    dict_1['fizz'] = 'buzz'
    dict_2 = dict()
    dict_2['fizz'] = 'buzz'
    dict_2['foo'] = 'zzz'
    list_0 = list()
    list_0.append(dict_0)
    list_0.append(dict_1)
    list_0.append(dict_2)
    dict_3 = dict()
    dict_3['fizz'] = 'buzz'
    dict_3['foo'] = 'bar'
    dict_4 = dict()
    dict_

# Generated at 2022-06-25 11:30:52.728254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n\n=======\nRunning test for `run` method for class `LookupModule`\n=======\n\n")
    lookup_module_0 = LookupModule()
    terms = ['a', 'b']
    variables = {'a': 'b'}
    kwargs = {}
    result = lookup_module_0.run(terms, variables, **kwargs)
    print("\n\n=======\nOutput of `run` method for class `LookupModule`:\n=======\n{}".format(result))
    assert result == [('a',), ('b',), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,)]


# Generated at 2022-06-25 11:31:01.215234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = ([['a', 'b'], [1, 2]])
    var_1 = lookup_module_1.run(tuple_1)
    assert var_1 == [('a', 1), ('b', 2)]


# Generated at 2022-06-25 11:31:06.579819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (('File: abc'),)
    assert lookup_module_0.run(tuple_0) == "test"


# Generated at 2022-06-25 11:31:08.290580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:31:10.793412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert True


# Generated at 2022-06-25 11:31:12.794020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_module_0.run(())
    assert var_0 is None


# Generated at 2022-06-25 11:31:15.753933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:31:25.292720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
#
# Setup variable "terms"
    terms = [
        [
            'a',
            'b',
            'c',
            'd'
        ],
        [
            1,
            2,
            3,
            4
        ]
    ]
#
# Setup variable "variables"
    variables = {}
#
# Setup variable "kwargs"
    kwargs = {}
#
# Call method run of class LookupModule
    tuple_0 = (
        terms,
        variables,
        kwargs
    )
    var_0 = lookup_module_0.run(*tuple_0)
#
# Assertion for checking the type of var_0
    assert isinstance(var_0, list)
#
# Assertion for checking the length of var_0

# Generated at 2022-06-25 11:31:31.480514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (
        [
            [
                "", "", "", ""
            ], [
                "", "", "", ""
            ]
        ], [
            "", "", "", ""
        ], [
            "", "", "", ""
        ], [
            "", "", "", ""
        ], [
            "", "", "", ""
        ], [
            "", "", "", ""
        ]
    )
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == None

# Generated at 2022-06-25 11:31:38.243399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u'a', u'b', u'c', u'd']
    var_1 = [1, 2, 3, 4]
    tuple_0 = (var_1, var_0)
    var_2 = lookup_run(tuple_0)
    var_3 = lookup_module_0.run(tuple_0)
    assert var_3 == var_2


# Generated at 2022-06-25 11:31:46.855934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (1, 2, 3)
    tuple_1 = (4, 5, 6)
    terms = (tuple_0, tuple_1)
    var_0 = lookup_module_0.run(terms)
    if var_0 != [(1, 4), (2, 5), (3, 6)]:
        print("Expected: ", (1, 4), (2, 5), (3, 6))
        print("Actual: ", var_0)
        assert False

test_LookupModule_run()

# Generated at 2022-06-25 11:31:51.348460
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    terms = dict()
    variables = dict()

    # Act
    actual_results = lookup_module_0.run(terms, variables)

    # Assert
    assert actual_results == None



# Generated at 2022-06-25 11:31:53.384756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = ("a", "b")
    lookup_module_1.run(tuple_1)


# Generated at 2022-06-25 11:31:58.249938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run()

    # Unit test for method _lookup_variables of class LookupModule
    def test_LookupModule__lookup_variables():
        lookup_module_0 = LookupModule()
        result_0 = lookup_module_0._lookup_variables(terms)

    # Unit test for method _flatten of class LookupModule
    def test_LookupModule__flatten():
        lookup_module_0 = LookupModule()
        result_0 = lookup_module_0._flatten(list_0)

# Generated at 2022-06-25 11:32:02.998935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = ()
    var_1 = lookup_run(tuple_1)
    assert var_1 == []

# Generated at 2022-06-25 11:32:05.923086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t0 = LookupModule()
    t1 = [["a","b"],[1,2]]
    t2 = [['a',1], ['b',2]]
    t3 = t0.run(t1)
    assert t2 == t3
    print("Unit test for method run of class LookupModule  success")


# Generated at 2022-06-25 11:32:16.732475
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a single list
    lookup_module_1 = LookupModule()
    tuple_1 = (['a', 'b', 'c'], )
    var_1 = lookup_run(tuple_1)
    assert var_1 == [['a'], ['b'], ['c']]

    # Test with multiple lists with the same number of elements
    lookup_module_2 = LookupModule()
    tuple_2 = (['a', 'b', 'c', 'd'], [1, 2, 3, 4])
    var_2 = lookup_run(tuple_2)
    assert var_2 == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]

    # Test with multiple lists with different numbers of elements
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:32:23.707760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)
    # test for LookupModule.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 11:32:28.179845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock a template
    template = Template()
    template.a = 'a'
    template.b = 'b'
    template.c = 'c'
    template.d = 'd'
    template.e = 'e'
    template.f = 'f'

    # prepare the arguments
    terms = [('a', 'b'), ('c', 'd'), ('e', 'f')]

    # mock the actual class
    mock_LookupModule = LookupModule()
    lookup_run(terms)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:32:33.491372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mock
    lookup_module = LookupModule()

    # Mock arguments
    terms = ["a", "b", "c", "d"]
    var = zip_longest(terms, terms)
    # Invoke method
    result = lookup_module.run(terms)
    # Check result
    assert result == var

# Generated at 2022-06-25 11:32:42.127303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == tuple_0, 'var_0 should have a value of type tuple and it does not'
    #assert var_0 == (1, 2, 3), 'var_0 should have a value of type tuple and it does not'

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:32:46.542598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test run: ")
    lookup_module_0 = LookupModule()
    tuple_0 = (['a', 'b', 'c', 'd'], [1, 2, 3, 4])
    var_0 = lookup_run(tuple_0)
    pprint.pprint(var_0)


# Generated at 2022-06-25 11:32:55.795092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (['a', 'b', 'c'], ['d', 'e', 'f'])
    var_0 = lookup_run(tuple_0)
    assert var_0 == [('a', 'd'), ('b', 'e'), ('c', 'f')]
    var_1 = lookup_run([['a'], [1, 2, 3]])
    assert var_1 == [('a', 1), (None, 2), (None, 3)]
    var_2 = lookup_run([['a'], [1]])
    assert var_2 == [('a', 1)]
    var_3 = lookup_run([['a'], []])
    assert var_3 == [('a', None)]

# Generated at 2022-06-25 11:33:00.013503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[1, 2, 3]]
    tuple_0 = (terms_0,)
    var_0 = lookup_run(tuple_0)
    assert var_0 == [[('1',), ('2',), ('3',)]]


# Generated at 2022-06-25 11:33:04.393346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = "with_together requires at least one element in each list"
    # Condition for assertEqual
    assertEqual(str_0, AnsibleError.msg)


# Generated at 2022-06-25 11:33:07.409893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run((tuple_0,), ()).__repr__() in (
            '[X, X]',  # python2
            '[X, X]'   # python3
    )

# Generated at 2022-06-25 11:33:14.842187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_0 = ('a')
    tuple_1 = ('b')
    tuple_2 = ('c')
    tuple_3 = ('d')
    tuple_4 = (1)
    tuple_5 = (2)
    tuple_6 = (3)
    tuple_7 = (4)
    tuple_8 = (tuple_0,tuple_1,tuple_2,tuple_3)
    tuple_9 = (tuple_4,tuple_5,tuple_6,tuple_7)
    tuple_10 = (tuple_8,tuple_9)
    tuple_11 = (type(tuple_4))
    var_1 = lookup_module_1.run(tuple_10)

# Generated at 2022-06-25 11:33:19.219031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ([[], ['a', 'b', 'c', 'd']], [[1, 2, 3, 4]])
    var_0 = lookup_run(tuple_0)
    assert var_0 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    tuple_1 = ([['a', 'b', 'c', 'd']], [[1, 2, 3, 4]])
    var_1 = lookup_run(tuple_1)
    assert var_1 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    tuple_2 = ([['a', 'b', 'c', 'd']], [[1, 2, 3, 4], []])
    var_2 = lookup_

# Generated at 2022-06-25 11:33:25.292658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_module_0.run(terms_0)
    var_1 = lookup_module_0.run(terms_0)
    assert var_0 == var_1



# Generated at 2022-06-25 11:33:31.027847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    if isinstance(x, LookupBase):
        # State that the LookupModule instance x is of LookupBase
        pass
    else:
        # State that the LookupModule instance x is not of LookupBase
        pass
    # Example for making an assertion
    assert x



# Generated at 2022-06-25 11:33:39.109201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ([['a', 'b', 'c', 'd'], [1, 2, 3, 4]],)
    var_0 = lookup_run(tuple_0)
    test_list_0 = []
    test_list_0.extend([('a', 1), ('b', 2), ('c', 3), ('d', 4)])
    assert var_0 == test_list_0


# Generated at 2022-06-25 11:33:49.342019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (None,)
    var_0 = lookup_run(tuple_0)
    # assert var_0 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]


# Generated at 2022-06-25 11:33:52.881522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  tuple_0 = ('a', 'b')
  var_0 = LookupModule.run(tuple_0)
  assert var_0 == None, 'returned unexpected value'

# Generated at 2022-06-25 11:34:01.261593
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    tuple_1 = (1, 81, 25)
    list_0 = []
    list_1 = [None, None, None]
    list_1.append(list_0)
    list_2 = [None, None, None]
    list_2.append(list_1)
    list_3 = [81, None, None]
    list_3.append(list_2)
    list_4 = [25, None, None]
    list_4.append(list_3)
    list_5 = [1, None, None]
    list_5.append(list_4)
    var_1 = lookup_run(tuple_1)
    assert var_1 == list_5


# Generated at 2022-06-25 11:34:06.685160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run('string')
    bool_0 = bool(str_0)
    bool_1 = bool(0)
    if bool_0 is bool_1:
        var_0 = 1
    else:
        var_0 = 0
    bool_2 = bool(var_0)
    assert bool_2 is True


# Generated at 2022-06-25 11:34:07.920725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    tuple_0 = (((), 0), (), ())
    var_0 = lookup_0.run(tuple_0)
    assert var_0 == []


# Generated at 2022-06-25 11:34:09.424661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    assert len(var_0) == 0


# Generated at 2022-06-25 11:34:19.469536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
    list_0 = [['a', 'b'], [1, 2, 3]]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [['a', 1], ['b', 2], [None, 3]]
    list_0 = [['a', 'b', 'c', 'd'], [1], [2, 3, 4]]
    var_0 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:34:29.274882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run(list)

    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)

    # LookupModule.run(list)

    lookup_module_1 = LookupModule()
    tuple_1 = ()
    var_1 = lookup_run(tuple_1)

    # LookupModule.run(list)

    lookup_module_2 = LookupModule()
    tuple_2 = ()
    var_2 = lookup_run(tuple_2)
    assert var_2 == tuple_2

    # LookupModule.run(list)

    lookup_module_3 = LookupModule()
    tuple_3 = ()
    var_3 = lookup_run(tuple_3)
    assert var_3 == tuple_3

# Generated at 2022-06-25 11:34:31.355770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    var_0 = lookup_run(tuple_0, (1,))


# Generated at 2022-06-25 11:34:42.090858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:34:57.521272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = ('some words', 'some other words')
    var_0 = lookup_module_1.run(terms_0)
    return var_0

# Generated at 2022-06-25 11:35:04.013735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = ()
    var_0 = lookup_module_0.run(tuple_0, tuple_1)
    assert type(var_0) == list


# Generated at 2022-06-25 11:35:14.113215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run_0 = lookup_run.pop
    tuple_0 = ()
    var_0 = lookup_run_0(tuple_0, 'b', 'a', None, 'a', 'ba', 'a')
    tuple_1 = ('a', 'b', 'c')
    dict_0 = dict()
    dict_0[''] = 'a'
    dict_0['a'] = None
    dict_0['b'] = None
    dict_0['c'] = None
    var_1 = lookup_run_0(tuple_1, None, 1, dict_0, 'a', 'a')
    tuple_2 = (1, 'a')
    tuple_3 = ()

# Generated at 2022-06-25 11:35:17.542765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [1, 2, 3, 4]
    var_1 = [5, 6, 7]
    tuple_0 = (var_0, var_1)
    var_2 = lookup_run(tuple_0)
    assert var_2 == [[1, 5], [2, 6], [3, 7], [4, None]]


# Generated at 2022-06-25 11:35:22.994413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  tuple_0 = ()
  var_0 = lookup_module_0.run(tuple_0)
  assert var_0 == None
  lookup_module_1 = LookupModule()
  tuple_1 = ()
  var_1 = lookup_module_1.run(tuple_1)
  assert var_1 == None
  lookup_module_2 = LookupModule()
  tuple_2 = ()
  var_2 = lookup_module_2.run(tuple_2)
  assert var_2 == None
  lookup_module_3 = LookupModule()
  tuple_3 = ()
  var_3 = lookup_module_3.run(tuple_3)
  assert var_3 == None
  lookup_module_4 = LookupModule()
  tuple_

# Generated at 2022-06-25 11:35:28.551143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = ([], )
    var_1 = lookup_run(tuple_1)
    assert type(var_1) == list
    assert len(var_1) == 0
    assert isinstance(var_1[0], str)


# Generated at 2022-06-25 11:35:31.020550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ()
    variables_0 = ()
    __tracebackhide__ = True
    try:
        lookup_module_0.run(terms_0, variables_0)
    except Exception:
        pass
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-25 11:35:39.650295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (1,)
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == [(1,)]
    tuple_0 = ()
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == []
    tuple_0 = (1, 2, 3)
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == [tuple_0]
    tuple_0 = (4, 5, 6)
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == [tuple_0]
    tuple_0 = (1, 2, 3)

# Generated at 2022-06-25 11:35:43.699194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (['a', 'b'], [1, 2])
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0[0][0] == 'a'
    assert var_0[0][1] == 1
    assert var_0[1][0] == 'b'
    assert var_0[1][1] == 2


# Generated at 2022-06-25 11:35:47.681029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = [1, 2, 3], [4, 5, 6] # Declare arguments (for demo purposes)
  lookup_module_0 = LookupModule()
  results_0 = lookup_module_0.run(terms) # Call instance method and store result
  if(len(results_0) != 1): # Evaluate and store test result
    # Unit test failure condition
    raise AssertionError()
  else:
    # Unit test success condition
    pass

# Generated at 2022-06-25 11:36:10.317001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')

    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:36:12.819462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    tuple_0 = ()
    var_0 = lookup_module.run(tuple_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:36:20.901397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n# Unit test for method run of class LookupModule")
    lookup_module_0 = LookupModule()
    tuple_0 = ('[1, 2, 3]', '[4, 5, 6]')
    var_0 = lookup_module_0.run(tuple_0)
    assert type(var_0) == list
    assert len(var_0) == 3
    assert var_0[0] == [1, 4]
    assert var_0[1] == [2, 5]
    assert var_0[2] == [3, 6]

# Generated at 2022-06-25 11:36:23.621746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = lookup_run(tuple_0)



# Generated at 2022-06-25 11:36:29.204734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    ans = var_0['_list']
    ans_exp = []
    assert ans == ans_exp, 'Expected different value for LookupModule.run'

# Generated at 2022-06-25 11:36:31.858558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_module_0._lookup_variables(list_0)
    list_1 = []
    var_1 = lookup_module_0.run(list_1, var_0)
    assert var_1 == []



# Generated at 2022-06-25 11:36:33.879328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  tuple_0 = ()
  var_0 = lookup_module_0.run(tuple_0)
  assert var_0 == None, 'return value of LookupModule.run()'


# Generated at 2022-06-25 11:36:37.745903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    assert var_0 == 'None'
    return




# Generated at 2022-06-25 11:36:43.648037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    tuple_1 = ()
    var_0 = lookup_module_2.run(tuple_1)
    assert len(var_0) == 0

    lookup_module_3 = LookupModule()
    tuple_2 = ((["", "", ""]))
    var_0 = lookup_module_3.run(tuple_2)
    assert len(var_0) == 1
    assert var_0[0][0] == 3


# Generated at 2022-06-25 11:36:46.071722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == []


# Generated at 2022-06-25 11:37:13.249565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ('a', 1, 2, 3)
    var_0 = lookup_run(tuple_0)
    try:
        assert var_0 == [
            ('a', 2, 3, 4),
            ('b', 3, 4, 5),
            ('c', 4, 5, 6),
            ('d', 5, 6, 7),
        ]
    except AssertionError as e:
        raise AssertionError(e.message)

# Generated at 2022-06-25 11:37:18.542288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    var_0 = lookup_run(tuple_0)
    assert var_0 is None
    dict_0 = {}
    var_1 = lookup_run(dict_0)
    assert var_1 is None
