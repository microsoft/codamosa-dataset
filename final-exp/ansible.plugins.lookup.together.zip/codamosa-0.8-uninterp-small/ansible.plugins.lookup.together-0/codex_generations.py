

# Generated at 2022-06-25 11:27:16.755713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [[]]
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:27:24.564827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['a', 'b', 'c', 'd'], ['1', '2', '3', '4']]
    result = lookup_module_0.run(terms_0)
    const_0 = [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')]
    assertEqual(const_0, result)


# Generated at 2022-06-25 11:27:26.609618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:27:30.304239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = {"terms": ["abc", ("def",)], "variables": None}
    assert lookup_module_0.run(**args) == [('a', 'd'), ('b', 'e'), ('c', 'f')]


# Generated at 2022-06-25 11:27:37.962435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = (("a", "b"),
               ("1", "2"))
    assert lookup_module_1.run(terms_1) == [['a', '1'], ['b', '2']]

    terms_2 = (("a", "b"),
               ("1",))
    assert lookup_module_1.run(terms_2) == [['a', '1'], ['b', None]]



# Generated at 2022-06-25 11:27:46.941683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    terms_0 = ['a','b','c','d']
    terms_1 = ['1','2','3','4']

    zip_longest_result = zip_longest(terms_0,terms_1, fillvalue=None)
    #returns tuple of (('a','1'),('b','2'),('c','3'),('d','4'))
    zip_longest_result = list(zip_longest_result)

    my_list_0 = [terms_0, terms_1]

    assert lookup_module_0.run(my_list_0) == zip_longest_result

    lookup_module_2.run(my_list_0) == []



# Generated at 2022-06-25 11:27:53.066251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = 'str'
    test_args_0 = {
        'terms': 'str',
        'variables': None,
    }
    with pytest.raises(AnsibleError) as ansible_error:
        lookup_module_0.run(**test_args_0)
    assert ansible_error.match("with_together requires at least one element in each list")

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 11:27:59.295175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  my_check_0 = LookupModule.run(
    ['a', 'b', 'c'],
    [[1, 2, 3], [4, 5, 6]]
  )
  assert my_check_0 == [ [1, 4], [2, 5], [3, 6] ]

# Generated at 2022-06-25 11:28:07.262252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._flatten([1, 2, 3])
    assert [1, 2, 3] == lookup_module_1._flatten([1, 2, 3])

    lookup_module_2 = LookupModule()
    lookup_module_2._flatten([1, [2, 3]])
    assert [1, 2, [3]] == lookup_module_2._flatten([1, [2, 3]])

    lookup_module_3 = LookupModule()
    lookup_module_3._flatten([1, [2, [3, 4]]])
    assert [1, 2, [3, 4]] == lookup_module_3._flatten([1, [2, [3, 4]]])

    lookup_module_4 = LookupModule()
    lookup_module

# Generated at 2022-06-25 11:28:09.630061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_obj = lookup_module_0.run(['a', 'b'], ['c', 'd'])
    assert len(lookup_module_0_obj) == 2



# Generated at 2022-06-25 11:28:20.386956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 875
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    var_0 = lookup_run(tuple_0)
    lookup_module_1 = LookupModule()
    lookup_module_1._flatten(var_0)
    var_1 = listify_lookup_plugin_terms(var_0, **dict_0)
    var_2 = list()
    lookup_module_2 = LookupModule(**dict_0)
    var_2 = [lookup_module_2._flatten(x) for x in zip_longest(*var_1, fillvalue=None)]
    assert var_2 is not None


# Generated at 2022-06-25 11:28:23.022909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True


# End of test cases

if __name__ == '__main__':
    run_testcase(test_case_0)
    run_testcase(test_LookupModule_run)
    print('Test cases finished, exiting.')

# Generated at 2022-06-25 11:28:29.253284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 875
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    list_0 = []
    list_1 = []
    tuple_1 = list_0, list_1
    dict_1 = {}
    var_0 = lookup_module_0.run(tuple_1, **dict_1)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:28:31.432888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    tuple_0 = (['a', 'b', 'c', 'd'], [1, 2, 3, 4])
    lookup_module_0 = LookupModule(dict_0)
    assert lookup_run(tuple_0) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:28:38.409989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 875
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    var_0 = lookup_run(tuple_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:28:41.689176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 875
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    var_0 = lookup_run(tuple_0)
    assert var_0 == var_0


# Generated at 2022-06-25 11:28:43.779202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    (tuple_0, int_0, dict_0) = (None, 875, {})
    lookup_module_0 = LookupModule(int_0, **dict_0)
    var_0 = lookup_run(tuple_0)
    lookup_var_0 = lookup_module_0.run(var_0, int_0)
    print(lookup_var_0)


# Generated at 2022-06-25 11:28:47.630621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 741
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:28:58.257278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    int_0 = 6
    dict_0 = {}
    lookup_module_0 = LookupModule(int_0, **dict_0)
    list_0 = []
    list_1 = []
    var_0 = lookup_module_0.run(list_0, list_1)
    dict_1 = {"_ansible_check_mode": True}
    list_2 = []
    var_1 = lookup_module_0.run(list_2, dict_1)
    lookup_module_1 = LookupModule()
    list_3 = []
    list_4 = [None]
    str_0 = "dW5zdHJ1Y3RlZCBkYXRhIGNvbnRhaW5lZCBpbiBkdW1w"
    var_

# Generated at 2022-06-25 11:29:05.626536
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    # Test with a single list
    my_list = ['a', 'b', 'c', 'd']
    expected = [('a',), ('b',), ('c',), ('d',)]
    result = lookup_module_0.run([my_list])
    assert result == expected, 'Single list failed'

    # Test with a list of lists
    my_list = [['a', 'b', 'c', 'd'], [1, 2, 3, 4], ['A', 'B', 'C', 'D']]
    expected = [('a', 1, 'A'), ('b', 2, 'B'), ('c', 3, 'C'), ('d', 4, 'D')]
    result = lookup_module_0.run(my_list)

# Generated at 2022-06-25 11:29:13.050992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Check method run of class LookupModule
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    lookup_module_0.run(zip_longest_0)

# Generated at 2022-06-25 11:29:22.291486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [1,2,3]
    zip_longest_0 = module_1.zip_longest()
    lookup_module_run(zip_longest_0)
    zip_longest_1 = module_1.zip_longest()
    lookup_module_run(zip_longest_1)
    zip_longest_2 = module_1.zip_longest()
    var_0 = lookup_module_run(zip_longest_2)
    var_1 = lookup_module_run(zip_longest_2)
    zip_longest_3 = module_1.zip_longest()
    var_2 = lookup_module_run(zip_longest_3)

# Generated at 2022-06-25 11:29:27.595372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0.run(zip_longest_0)
    assert var_0 == None



# Generated at 2022-06-25 11:29:28.485404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert zip_longest_0 == var_0

# Generated at 2022-06-25 11:29:31.625055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0.run(zip_longest_0)
    assert var_0 is None


# Generated at 2022-06-25 11:29:34.518369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:43.006435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0._lookup_variables('test_value') == 'test_value'
    assert lookup_module_0._templar('test_value') == 'test_value'
    assert lookup_module_0._loader('test_value') == 'test_value'

    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    assert var_0 == 'None'

    zip_longest_1 = module_1.zip_longest()
    var_1 = lookup_run(zip_longest_1)
    assert var_1 == 'None'

    zip_longest_2 = module_1.zip_longest()

# Generated at 2022-06-25 11:29:50.224020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    # Case 0
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

    # Case 1
    zip_longest_1 = module_1.zip_longest()
    var_1 = lookup_run(zip_longest_1)

    # Case 2
    zip_longest_2 = module_1.zip_longest()
    var_2 = lookup_run(zip_longest_2)

# Generated at 2022-06-25 11:29:55.871410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert var_0 == []

# Generated at 2022-06-25 11:29:59.436631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

# Generated at 2022-06-25 11:30:08.160913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = lambda arg_0: arg_0
    lookup_module_0.run(['foo'], ['bar'])


# Generated at 2022-06-25 11:30:15.033690
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = zip_longest_0.__next__()
    var_1 = lookup_module_0.run(var_0)
    assert var_1

# Generated at 2022-06-25 11:30:17.464349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    # Test if the values are equal
    assert var_0 == var_0


# Generated at 2022-06-25 11:30:25.067903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    terms_0 = ['a', 'b', 'c', None, None, 'd', 'e']
    var_1 = lookup_module_0.run(terms_0, None)
    var_2 = test_case_0()
    assert var_0 == var_1 == var_2


# Generated at 2022-06-25 11:30:28.141934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [False]
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest(["1"], ["2"], ["3"])
    var_0 = lookup_run(zip_longest_0)

    assert var_0 == (("1", "2", "3"),)

# Generated at 2022-06-25 11:30:33.019543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0.run(lookup_module_0)) is object
    if True:
        print(lookup_module_0)

# Generated at 2022-06-25 11:30:36.420589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0.run(zip_longest_0)

# Generated at 2022-06-25 11:30:40.580127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    @add_cleanup
    def cleanup_1():
        var_0 = [('a',1), ('b',2)]
    var_1 = lookup_run(zip_longest_0)
    assert var_1 == var_0


# Generated at 2022-06-25 11:30:43.068061
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # parameters
    terms = [1, 2]
    variables = list
    kwargs = lookup_module_0

    try:
        lookup_module_0.run(terms, variables, **kwargs)
    except Exception as exception:
        print(exception)
        #assert False



# Generated at 2022-06-25 11:30:50.416021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    try:
        lookup_module_0.run(zip_longest_0)
        result_0 = True
    except Exception as e_0:
        result_0 = False
    assert result_0


# Generated at 2022-06-25 11:31:03.134592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables) == [iter([None, None, None]), iter([None, None, None])]


# Generated at 2022-06-25 11:31:06.713418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    zip_longest_1 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_1)


# Generated at 2022-06-25 11:31:08.438798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tmp = LookupModule()
    tmp.run(['a', 'b'], [1, 2])

# Generated at 2022-06-25 11:31:18.918931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo = LookupModule()
    bar = ['a', 'b', 'c', 'd']
    buz = [1, 2, 3, 4]
    assert foo.run([bar, buz],[],False) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert foo.run([],['a', 'b', 'c', 'd'],[1, 2, 3, 4]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert foo.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]],[]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:31:22.606349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    lookup_module_0.run(zip_longest_0)
  except Exception as exception:
    print("Unhandled exception while running test %s" % exception.message)

# Generated at 2022-06-25 11:31:25.257136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    assert var_0 == False

# Generated at 2022-06-25 11:31:29.340637
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    arg_0 = []
    arg_1 = {}
    arg_2 = {}

    ret_0 = lookup_module.run(arg_0, arg_1, arg_2)
    assert ret_0 == None

    lookup_module.run(arg_0, arg_1, arg_2)
    assert ret_0 == None

    return


# Generated at 2022-06-25 11:31:31.063979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    zip_longest_0 = module_1.zip_longest()
    var_0 = LookupModule.run(zip_longest_0)

# Generated at 2022-06-25 11:31:35.495790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = [1,2]
    lookup_module_0.run(arg_0)

# Generated at 2022-06-25 11:31:37.453849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)


# Generated at 2022-06-25 11:32:03.759335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    lookup_module_0.run(zip_longest_0)

RunTest(test_case_0)
RunTest(test_LookupModule_run)

# Generated at 2022-06-25 11:32:09.605773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4],
    ]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(my_list)
    expected = [
        ('a', 1), ('b', 2), ('c', 3), ('d', 4)
    ]
    # assertEqual(result, expected, "Expected "+expected+", but got "+result)


# Generated at 2022-06-25 11:32:12.458288
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:32:19.085252
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    zip_longest_1 = module_1.zip_longest()
    var_1 = lookup_run(zip_longest_1)


# Generated at 2022-06-25 11:32:21.703997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    assert var_0 == [('a', 1), ('b', 2)]


# Generated at 2022-06-25 11:32:26.283191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    zip_longest_1 = module_1.zip_longest()
    lookup_module_1.run(zip_longest_1)


# Generated at 2022-06-25 11:32:28.922199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(terms)
  var_0 = lookup_module_0.run("")
  var_0 = lookup_module_0.run("", "", "", "", "", "", "", "", "", "", "", "", "")

# Mock unit test for run()

# Generated at 2022-06-25 11:32:35.335541
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # try:
    #     raise Exception()
    # except Exception:
    #     e = sys.exc_info()[0]
    #     print(e)
    # return


    # Create a new instance of LookupModule to test
    lookup_module_0 = LookupModule()

    # Invoke the method of LookupModule to test
    var_0 = lookup_module_0.run(
        terms,
        **kwargs
    )

    # Test the result of the method
    expected_0 = ...
    assert var_0 == expected_0



# Generated at 2022-06-25 11:32:48.107345
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for function _lookup_variables
    def test_case_0():
        lookup_module_0 = LookupModule()
        listify_lookup_plugin_terms_0 = listify_lookup_plugin_terms()
        var_0 = lookup_module_0._lookup_variables(listify_lookup_plugin_terms_0)
        var_1 = lookup_run(var_0)
        return var_1

    # Unit test for function run
    def test_case_1():
        lookup_module_0 = LookupModule()
        listify_lookup_plugin_terms_0 = listify_lookup_plugin_terms()
        var_0 = lookup_module_0.run(listify_lookup_plugin_terms_0)

# Generated at 2022-06-25 11:32:56.630667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    assert lookup_module_0.run(zip_longest_0)
    lookup_module_1 = LookupModule()
    zip_longest_1 = module_1.zip_longest()
    assert lookup_module_1.run(zip_longest_1)
    lookup_module_2 = LookupModule()
    zip_longest_2 = module_1.zip_longest()
    assert lookup_module_2.run(zip_longest_2)


# Generated at 2022-06-25 11:33:42.066297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = ['1', '2', '3']
    kwargs_0 = {'fillvalue': None}
    id_0 = '1'
    id_1 = '2'
    zip_longest_0 = module_1.zip_longest()
    zip_longest_1 = module_1.zip_longest(args_0, kwargs_0)
    var_0 = lookup_run(zip_longest_0)
    assert var_0 == zip_longest_1
    var_1 = lookup_run(zip_longest_1)
    assert var_1 == zip_longest_1
    var_2 = lookup_run(id_0)
    assert var_2 == zip_longest_1
    var_3 = lookup_run(id_1)
    assert var_

# Generated at 2022-06-25 11:33:48.550136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup for test_case_0
    lookup_module_0 = LookupModule()
    
    # Case 0
    terms_0 = [['a', 'b', 'c', 'd'] ['1', '2', '3', '4']]
    variables_0 = None
    kwargs_0 = {}
    
    
    
    
    # Expected result
    expected_result_0 = [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Test case 0
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == expected_result_0

# Generated at 2022-06-25 11:33:55.423467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest(['a', 'b', 'c', 'd'], [1, 2, 3, 4])
    var_0 = lookup_module_0.run(zip_longest_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 4
    assert var_0[0][0] == 'a'
    assert var_0[0][1] == 1
    assert var_0[1][0] == 'b'
    assert var_0[1][1] == 2
    assert var_0[2][0] == 'c'
    assert var_0[2][1] == 3
    assert var_0[3][0] == 'd'
    assert var_

# Generated at 2022-06-25 11:33:58.874103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0.lookup_variables(zip_longest_0)
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:34:04.863669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    assert lookup_module_0.run(zip_longest_0) == [], "Incorrect test result returned"


# Generated at 2022-06-25 11:34:09.738522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list_0 = ['a', 'b', 'c']
    # Class Name LookupModule
    lookup_module_0 = LookupModule()
    # test arg1 of run when type is list
    # listify_lookup_plugin_terms(my_list_0, templar=lookup_module_0._templar, loader=lookup_module_0._loader)
    # test return type of run when type is list
    # assert isinstance(lookup_module_0.run(my_list_0) == 'list')
    my_list_1 = ['1', '2', '3']
    # Class Name LookupModule
    lookup_module_1 = LookupModule()
    # test arg1 of run when type is list
    # listify_lookup_plugin_terms(my_list_1,

# Generated at 2022-06-25 11:34:16.303722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [('a', 1), ('b', 2)],
        [('c', 3), ('d', 4)]
    ]
    expected_result = lookup_module_0.run(terms)
    assert expected_result == [
        [('a', 'b', 'c', 'd')],
        [(1, 2, 3, 4)]
    ]

import itertools as module_1


# Generated at 2022-06-25 11:34:20.925492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of class LookupModule.

    """
    lookup_module_0 = LookupModule()
    input_0 = ['a', 'b', 'c']
    input_1 = [1, 2, 3]
    var_0 = lookup_module_0.run(input_0, input_1)
    print(var_0[0])
    print(var_0[1])
    print(var_0[2])

test_LookupModule_run()

# Generated at 2022-06-25 11:34:26.349605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

# vim: ansible-async
# vim: ansible-async
# vim: ansible-async
# vim: ansible-async

# Generated at 2022-06-25 11:34:28.170014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

# Generated at 2022-06-25 11:36:01.945890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_assign(zip_longest_0, 'zip_longest_0')
    var_0 = getattr(lookup_module_0, 'run')([var_0])


# Generated at 2022-06-25 11:36:05.117115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = my_list = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:36:07.718683
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #creation
    lookup_module_0 = LookupModule()
    #lookup
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)
    assert_equals(var_0, None)


# Generated at 2022-06-25 11:36:12.039488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

# Generated at 2022-06-25 11:36:15.398246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:36:22.805609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0._lookup_variables(zip_longest_0)

# Generated at 2022-06-25 11:36:28.157795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_run(zip_longest_0)

# Generated at 2022-06-25 11:36:36.421097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    var_0 = lookup_module_0.run(zip_longest_0)
    assert var_0 == ((),)

if 1:
    def test_run():
        temp = [1, 2, 3], [4, 5, 6]
        desired = [1, 4], [2, 5], [3, 6]
        actual = [1, 4], [2, 5], [3, 6]
        assert temp == desired, actual
        temp = [1, 2], [3]
        desired = [1, 3], [2, None]
        actual = [1, 3], [2, None]
        assert temp == desired, actual
        temp = [1, 2], []

# Generated at 2022-06-25 11:36:40.103763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    zip_longest_0 = module_1.zip_longest()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(zip_longest_0, 'a')


# Generated at 2022-06-25 11:36:44.667713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    zip_longest_0 = module_1.zip_longest()
    lookup_module_0.run(zip_longest_0)
    lookup_module_1 = LookupModule()
    terms_0 = ['IllegalArgumentException', 'IllegalAccessException', 'Ansible', 'AnsibleException', 'AnsibleUndefinedVariable']
    lookup_module_1.run(terms_0)