

# Generated at 2022-06-25 11:27:17.715888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([['a', 'b'], ['1', '2']]) == [['a', 'b'], ['1', '2']]

# Generated at 2022-06-25 11:27:24.251348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = {'a', 'b', 'c', 'd'}
    my_list = [my_list, my_list, my_list]
    assert lookup_module_0.run(my_list) == [['a', 'a', 'a'], ['b', 'b', 'b'], ['c', 'c', 'c'], ['d', 'd', 'd']]

    lookup_module_0 = LookupModule()
    my_list = [1, 2, 3]
    my_list = [my_list, my_list]
    assert lookup_module_0.run(my_list) == [(1, 1), (2, 2), (3, 3)]

# Generated at 2022-06-25 11:27:32.929349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    from ansible.module_utils.six.moves import zip_longest
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module_2 = LookupModule()

    my_list = [['a', 'b'], ['1', '2']]


    # Intentionally reordered list to test order not affecting output
    my_list = [listify_lookup_plugin_terms('1', templar=lookup_module_2._templar, loader=lookup_module_2._loader), listify_lookup_plugin_terms('a', templar=lookup_module_2._templar, loader=lookup_module_2._loader)]


# Generated at 2022-06-25 11:27:40.805468
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  lookup_module = LookupModule()

  # Not enough arguments
  terms = []
  try:
      lookup_module.run(terms)
  except AnsibleError as e:
      assert "with_together requires at least one element in each list" in str(e)

  # Normalize the Array
  terms = [[1, 2, 3], [4, 5, 6]]
  result = lookup_module.run(terms)
  assert result == [[1, 4],[2, 5],[3, 6]]

  # Normalize the Array
  terms = [[1, 2], [3]]
  result = lookup_module.run(terms)
  assert result == [[1, 3],[2, None]]

# Generated at 2022-06-25 11:27:44.373267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialization
    lookup_module = LookupModule()

    # Test with all inputs but expected type of output
    terms = ['test']
    variables = None
    kwargs = {'kwargs0' : 'kwargs_test'}
    result = lookup_module.run(terms, variables, **kwargs)
    expected = [('test', None)]
    assert result == expected


# Generated at 2022-06-25 11:27:46.883732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms = [ [10, 'a', 2], [30, 'b', 2] ], variables = 'variables')

# Generated at 2022-06-25 11:27:52.419562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
    ['a', 'b', 'c', 'd'],
    ['1', '2', '3', '4']
    ]

# Generated at 2022-06-25 11:27:56.047522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([[1], [2]])
    lookup_module_1.run([[1, 2, 3], [4, 5, 6]])
    lookup_module_1.run([[1, 2], [3]])
    lookup_module_1.run([[1, 2], [3, 4]])
    lookup_module_1.run([])


# Generated at 2022-06-25 11:27:58.482987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['a', 'b'], variables=None), list)


# Generated at 2022-06-25 11:28:02.946915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["a", "b", "c"]
    kwargs_0 = { }

    expected_0 = None
    actual_0 = lookup_module_0.run(terms_0, **kwargs_0)
    assert expected_0 == actual_0

# Generated at 2022-06-25 11:28:14.472419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Expected parameters
  terms = {
    0: "[1, 2, 3]",
    1: "[4, 5, 6]",
  }
  variables = {
    "ansible_all_ipv4_addresses": "ansible_all_ipv4_addresses",
    "ansible_all_ipv6_addresses": "ansible_all_ipv6_addresses",
  }
  kwargs = {
    "variable_start_string": "@",
    "variable_end_string": "@",
    "_original_basename": "_original_basename",
    "_templar": "_templar",
    "loader": "loader",
    "fail_on_undefined": "fail_on_undefined",
  }
  # Call method run of class LookupModule with arguments terms

# Generated at 2022-06-25 11:28:24.184390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_0_0 = None
    input_0_1 = None
    input_0_2 = {}
    lookup_module_0 = LookupModule()
    expected_result_0 = None
    actual_result_0 = lookup_module_0.run(input_0_0, input_0_1, input_0_2)
    assert actual_result_0 == expected_result_0, 'Expected: %s, but got: %s' % (expected_result_0, actual_result_0)
    input_1_0 = None
    input_1_1 = None
    input_1_2 = {}
    lookup_module_1 = LookupModule()
    expected_result_1 = None

# Generated at 2022-06-25 11:28:25.191013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 11:28:28.772451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['a', 'b', 'c', 'd']
    var_0 = None
    result = lookup_module_0._lookup_variables(terms_0, var_0)
    assert result == ['a', 'b', 'c', 'd'], 'Expected ["a","b","c","d"] got {0}'.format(result)



# Generated at 2022-06-25 11:28:33.071001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert type(lookup_module_0.run(['a', 'b'], variables={'a': 'q', 'b': 'z'}, other_item='c')) == list
    if type(lookup_module_0.run(['a', 'b'], variables={'a': 'q', 'b': 'z'}, other_item='c')) != list:
        raise AssertionError('#1')
    assert lookup_module_0.run(['a', 'b'], variables={'a': 'q', 'b': 'z'}, other_item='c') == ['q', 'z']

# Generated at 2022-06-25 11:28:39.226239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    variables = None
    result = lookup_module_0.run(terms, variables)
    assert result == [
        [1, 4],
        [2, 5],
        [3, 6]
    ]


# Generated at 2022-06-25 11:28:43.098011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_LookupModule = LookupModule()
    my_terms = [ ['a', 'b', 'c'], [1, 2, 3] ]
    my_kwargs = {}
    my_expected = [ ('a',1), ('b', 2), ('c', 3) ]
    
    my_results = my_LookupModule.run(my_terms, **my_kwargs)
    assert my_results == my_expected
    pass

# Generated at 2022-06-25 11:28:50.176658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = [1, 2, 3]
    y = [4, 5, 6]
    z = [7, 8, 9]
    lookup_module_0 = lookup_module_0()
    lookup_module_0._flatten = Mock(side_effect = lambda a,b: [a,b])
    lookup_module_0._templar = Mock()
    lookup_module_0._loader = Mock()
    result = lookup_module_0.run([x, y, z], None, [])

    assert result == [[1,4,7], [2,5,8], [3,6,9]]

# Generated at 2022-06-25 11:28:54.950896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_term_1 = ['a', 'b', 'c', 'd']
    test_term_2 = [1, 2, 3, 4]
    terms = [test_term_1, test_term_2]
    assert lookup_module_1.run(terms) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]



# Generated at 2022-06-25 11:28:57.081599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False # TODO: implement your test here


# Generated at 2022-06-25 11:29:05.769120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[1, 2], [3]]
    test_LookupModule = LookupModule()
    result = test_LookupModule.run(terms, None)
    assert result == [[1, 3], [2, None]]

test_case_0()

# Generated at 2022-06-25 11:29:07.785027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
  assert var_0 == [
      [1, 4, 7],
      [2, 5, 8],
      [3, 6, 9]
  ]


# Generated at 2022-06-25 11:29:11.273500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run == lookup_run


# Generated at 2022-06-25 11:29:11.995813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:29:21.302532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = [[1, 2, 3], [4, 5, 6]]
  variables = None
  if len(terms) == 0:
    raise AnsibleError("with_together requires at least one element in each list")
  my_list = terms[:]
  expected = [[1, 4], [2, 5], [3, 6]]
  actual = lookup_module.run(my_list, variables)
  assert actual == expected, "expected {0} got {1}".format(expected, actual)
  #assert False # TODO: implement your test here


# Generated at 2022-06-25 11:29:25.628754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert var_1 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)], "Incorrect return for run"


# Generated at 2022-06-25 11:29:28.153304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_var_1 = [1, 2, 3, 4, 2]
    lookup_var_2 = ['a', 'b', 'c', 'd', 'e']
    lookup_var_3 = [None] * 5
    lookup_module_0 = LookupModule
    lookup_result_1 = lookup_module_0.run(lookup_var_1)
    assert lookup_result_1 == '?'

# Generated at 2022-06-25 11:29:32.376863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert var_0 == []
    var_1 = lookup_module_0.run([[['a', 'b', 'c']], [[1, 2, 3]]])
    assert var_1 == [['a', 1], ['b', 2], ['c', 3]]
    var_2 = lookup_module_0.run([[['a', 'b', 'c']], [[1, 2]]])
    assert var_2 == [['a', 1], ['b', 2], ['c', None]]
    var_3 = lookup_module_0.run([[['a', 'b', 'c']], [[1]]])
    assert var_3 == [['a', 1], ['b', None], ['c', None]]
    var

# Generated at 2022-06-25 11:29:36.629966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    lookup_module_1.run(var_0)
    lookup_module_2.run(var_0)


# Generated at 2022-06-25 11:29:42.125168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term0 = []
    term1 = ['a', 'b', 'c', 'd']
    term2 = [1, 2, 3, 4]

    lookup_module = LookupModule()
    lookup_module.terms = [term0, term1, term2]

    result = lookup_module.run(lookup_module.terms)
    x = result
    assert x == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]


# Generated at 2022-06-25 11:29:50.533020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:29:54.737276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:29:58.271586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = ['a', 'b', 'c', 'd']
    var_2 = [1, 2, 3, 4]
    lookup_module_0 = LookupModule()
    var_3 = lookup_run(lookup_module_0)
    assert var_3 == var_0



# Generated at 2022-06-25 11:30:02.382904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:30:07.327172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert type(var_0) is list
    assert len(var_0) is 0


# Generated at 2022-06-25 11:30:13.350235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert_equal(lookup_module_1.run(terms), [('a', 1), ('b', 2)])
# Test case where list is empty

# Generated at 2022-06-25 11:30:15.880524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert requests.get(var_0).status_code == 200


# Generated at 2022-06-25 11:30:22.940119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_dict_0 = {}
    # AssertionError: {'a': 1, 'b': 2, 'c': 3} != (1, 2, 3)
    # assert lookup_module_0.run(arg_dict_0) == ("(1, 2, 3)")


# Generated at 2022-06-25 11:30:28.675107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[["a", "b", "c", "d"], [1, 2, 3, 4]])
    assert var_0 == [("a", 1), ("b", 2), ("c", 3), ("d", 4)]



# Generated at 2022-06-25 11:30:39.532310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0._lookup_variables(["{{ item.0 }}, {{ item.1 }}"])
    assert var_0 == [["{{ item.0 }}, {{ item.1 }}"]], "var_0[0]"
    assert var_0 is not None, "var_0 is not None"
    var_1 = lookup_module_0._lookup_variables(["]]"])
    assert var_1 == [["]]"]], "var_1[0]"
    assert var_1 is not None, "var_1 is not None"
    var_2 = lookup_module_0._lookup_variables(["["])
    assert var_1 == [["["]], "var_2[0]"
    assert var_2 is not None

# Generated at 2022-06-25 11:30:52.102916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with no parameters
    assert lookup_module_0.run() == ['None']

    # Test with first parameter
    lookup_module_0.run([])

    # Test with two parameters
    lookup_module_0.run([], {})

    # Test with kwargs
    lookup_module_0.run(arg1=0, arg2=0, arg3=0)

# Generated at 2022-06-25 11:30:55.516082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    assert isinstance(f.run('foo'), type([]))
    assert list(f.run('foo')) == ['foo']



# Generated at 2022-06-25 11:30:56.699136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    if var_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:30:58.886484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_lookup_0 = LookupModule()
    var_list_0 = []
    var_lookup_0.run(var_list_0)
    print('PASSED: test_LookupModule_run')


# Generated at 2022-06-25 11:31:02.630701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == None


# Generated at 2022-06-25 11:31:04.198604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:31:05.582049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:31:15.006015
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    # ## Make mock object
    class obj_0(object):
        def __init__(self):
            self.terms = None
            self.variables = None
        def run(self, terms, variables=None, **kwargs):
            self.terms = terms
            self.variables = variables
            return ['the', 'first', 'list']

    nested_0 = [['the', 'first', 'list'], [1, 2, 3]]

    # Execute
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(nested_0)

    # Test
    assert result_0 == [['the', 1], ['first', 2], ['list', 3]], "The result should be equal to [['the', 1], ['first', 2], ['list', 3]]"

# Generated at 2022-06-25 11:31:18.773397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_ins = LookupModule()
    terms = ["Hello", "world", "!"]
    expected_value = [["Hello", "world", "!"]]

    assert lookup_module_ins.run(terms) == expected_value

# Generated at 2022-06-25 11:31:22.124181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:31:43.039549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [['a', 'b', 'c'], ['1', '2', '3', '4']]
    var_0 = lookup_module_1.run(terms_1, )
    print(var_0)



# Generated at 2022-06-25 11:31:44.884762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)

main()

# Generated at 2022-06-25 11:31:54.396649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:31:57.703414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:32:01.736936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 11:32:04.582700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:32:07.041404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(True)



# Generated at 2022-06-25 11:32:11.625462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_LookupModule = LookupModule()
    var_0 = LookupModule
    # self, terms, variables=None, **kwargs
    var_1 = var_0("with_together",terms, variables=None, **kwargs)
    var_2 = var_1(var_0)

# Generated at 2022-06-25 11:32:15.917714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0


# Generated at 2022-06-25 11:32:17.605428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None)


# Generated at 2022-06-25 11:32:58.407209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # my_list = [ ['a', 'b'], [1, 2] , [3, 4] ]
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)

# Generated at 2022-06-25 11:33:08.428618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run(lookup_module_0)
    var_2 = lookup_run(lookup_module_0)
    var_3 = lookup_run(lookup_module_0)
    var_4 = lookup_run(lookup_module_0)
    var_5 = lookup_run(lookup_module_0)
    var_6 = lookup_run(lookup_module_0)
    var_7 = lookup_run(lookup_module_0)
    var_8 = lookup_run(lookup_module_0)
    var_9 = lookup_run(lookup_module_0)
    var_10 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:33:15.621139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # make instance of class LookupModule
    lookup_module = LookupModule()
    # make instance of class ansible.module_utils.six.moves.zip_longest
    zip_longest = ansible.module_utils.six.moves.zip_longest
    # make instance of class list
    list = list
    # make instance of class tuple
    tuple = tuple
    # make instance of class bool
    bool = bool
    # make instance of class int
    int = int
    # make instance of class dict
    dict = dict
    # make instance of class frozenset
    frozenset = frozenset

    # assign object attributes
    lookup_module.my_list = None
    lookup_module.zip_longest = zip_longest
    lookup_module.list = list

# Generated at 2022-06-25 11:33:17.403931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  lookup.run()



# Generated at 2022-06-25 11:33:27.573852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    my_list = ['a', 'b', 'c', 'd']
    my_list_0 = [1, 2, 3, 4]
    my_list_1 = ['a', 'b', 'c', 'd']
    my_list_2 = [1, 2, 3, 4]
    my_list_3 = ['a', 'b', 'c', 'd']
    my_list_4 = [1, 2, 3, 4]
    my_list_5 = ['a', 'b', 'c', 'd']
    my_list_6 = [1, 2, 3, 4]
    my_list_7 = ['a', 'b', 'c', 'd']
    my_list_8 = [1, 2, 3, 4]
    my_list

# Generated at 2022-06-25 11:33:33.827590
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Verify that the method/function is not callable/runnable
    with pytest.raises(Exception):
        lookup_module_1.run()

    terms_1 = [
        [
            "r",
            "o",
            "b",
            "i",
            "n"
        ],
        [
            "b",
            "o",
            "b",
            "b",
            "n"
        ]
    ]

    results_1 = lookup_module_1.run(terms_1)

    with pytest.raises(AnsibleError):
        results_1

# Generated at 2022-06-25 11:33:36.204213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:33:38.163103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:33:41.653706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_LookupModule = LookupModule()
    var_0 = my_LookupModule.run(terms, variables)
    var_0 = my_LookupModule.run(terms, variables)
    var_0 = my_LookupModule.run(terms, variables)
    var_0 = my_LookupModule.run(terms, variables)


# Generated at 2022-06-25 11:33:46.779924
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create object of class LookupModule
    lookup_module = LookupModule()
    # Create var_0 from list
    var_0 = ['a', 'b', 'c', 'd']
    # Create var_1 from list
    var_1 = [1, 2, 3, 4]
    # Create var_2 from list
    var_2 = [var_0, var_1]
    # Execute run method of LookupModule object
    assert lookup_module.run(var_2) == ['a', '1'], "Incorrect value returned"
    # Create var_3 from list
    var_3 = ['a', 'b', 'c', 'd']
    # Create var_4 from list
    var_4 = [1, 2, 3]
    # Create var_5 fro

# Generated at 2022-06-25 11:35:17.024899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(terms, variables=None, **kwargs)) == 0


# Generated at 2022-06-25 11:35:21.018362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        var_1 = LookupModule(self, terms)
    except Exception as e:
        var_1 = False
    try:
        var_2 = LookupModule(self, terms, variables)
    except Exception as e:
        var_2 = False
    try:
        var_3 = LookupModule(self, terms, variables, **kwargs)
    except Exception as e:
        var_3 = False
    var_3 = True
    var_2 = True
    var_1 = True


# Generated at 2022-06-25 11:35:26.056052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["[1, 2, 3]", "['a', 'b']", "['x', 'y']"]
    assert [[1, 'a', 'x'], [2, 'b', 'y']] == lookup_module.run(terms, variables=None, **kwargs)

# vim: et ts=4 sw=4

# Generated at 2022-06-25 11:35:30.635477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(LookupModule()) == [["a", 1], ["b", 2], ["c", 3], ["d", 4]]
    assert lookup_run(LookupModule()) == [["a", 1], ["b", 2], ["c", 3], ["d", 4]]
    assert lookup_run(LookupModule()) == [["a", 2], ["b", 4], ["c", 6], ["d", 8]]
    assert lookup_run(LookupModule()) == [["a", 2], ["b", 4], ["c", 6], ["d", 8]]
    assert lookup_run(LookupModule()) == [["a", "foo"], ["b", "bar"]]
    assert lookup_run(LookupModule()) == [["a", "foo"], ["b", "bar"]]

# Generated at 2022-06-25 11:35:35.784391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [ansible_0]
    var_0 = lookup_module_0.run(my_list_0)
    assert var_0 == [('a', 1), ('b', 2)]


# Generated at 2022-06-25 11:35:40.951519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	#variables = {}
	#assert lookup_module.run(terms, variables) == [
	#	[b'a', 1],
	#	[b'b', 2],
	#]
	print("hi")

# Generated at 2022-06-25 11:35:44.025826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:35:47.619250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = [ ["a", "b", "c", "d"], [1, 2, 3, 4] ]
    expected_0 = [ "a", "b", "c", "d" ]

    actual_0 = lookup_module_0.run(var_0)
    assert actual_0 == expected_0




# Testing the actual output of the method

# Generated at 2022-06-25 11:35:55.409489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_should_be_0 = [(1, 4), (2, 5), (3, 6)]
    var_0 = lookup_module_0.run([[1, 2, 3], [4, 5, 6]], variables=None, **{'_templar':None, '_loader':None})
    assert var_0 == result_should_be_0
    var_1 = lookup_module_0.run([[1, 2], [3]], variables=None, **{'_templar':None, '_loader':None})
    result_should_be_1 = [(1, 3), (2, None)]
    assert var_1 == result_should_be_1

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:35:56.783454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['a', 'b'], 'a')
