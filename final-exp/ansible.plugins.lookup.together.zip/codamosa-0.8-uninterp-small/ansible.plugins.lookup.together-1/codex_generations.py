

# Generated at 2022-06-25 11:27:17.867141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[['a', 'b', 'c', 'd'], [1, 2, 3, 4]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]


# Generated at 2022-06-25 11:27:19.570197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:27:25.100291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    value = listify_lookup_plugin_terms('test', templar=None, loader=None)
    value_1 = listify_lookup_plugin_terms(value, templar=None, loader=None)
    assert lookup_module_0.run(value_1, variables=None, **None)



# Generated at 2022-06-25 11:27:32.182609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = [
        [
            'a',
            'b',
            'c',
            'd',
        ],
        [
            1,
            2,
            3,
            4,
        ],
    ]

    assert lookup_module_0.run(args) == [
        {'1': 'a', '0': 1},
        {'1': 'b', '0': 2},
        {'1': 'c', '0': 3},
        {'1': 'd', '0': 4},
    ]


# Generated at 2022-06-25 11:27:33.559247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# vim:ft=python

# Generated at 2022-06-25 11:27:40.424357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]
    assert lookup_module_0.run([[1, 2, 3], [4, 5]]) == [[1, 4], [2, 5], [3, None]]
    assert lookup_module_0.run([[1, 2], [3]]) == [[1, 3], [2, None]]
    assert lookup_module_0.run([[1], [2]]) == [[1, 2]]

# Generated at 2022-06-25 11:27:43.140826
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_dict = dict(first=[1,2], second=[3,4])
    lookup_module_1 = LookupModule()
    assert [('1', '3'),('2', '4')] == lookup_module_1.run(my_dict, variables=None, **{})

# Generated at 2022-06-25 11:27:47.751981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[['a', 'b'], [1, 2]], variables={'a':'x', 'b':'y'})

# Generated at 2022-06-25 11:27:54.655821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            "a",
            "b",
            "c",
            "d"
        ],
        [
            1,
            2,
            3,
            4
        ]
    ]
    lookup_plugin_options = dict()
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms, lookup_plugin_options)
    except Exception as e:
        print("Expected error: {0}".format(e))



# Generated at 2022-06-25 11:27:59.445037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = []
    variables_0 = None
    kwargs_0 = {}
    assert not lookup_module_1.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:28:01.246245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:28:07.508674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_1 = [
    [
      'a',
      'b',
      'c',
      'd'
    ],
    [
      1,
      2,
      3,
      4
    ]
  ]

  assert lookup_module_0.run(terms_1, variables=None, **kwargs) == [
  ( 'a', 1 ),
  ( 'b', 2 ),
  ( 'c', 3 ),
  ( 'd', 4 )
]

# Generated at 2022-06-25 11:28:15.885130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = {}
    vars['ansible_verbosity'] = 0
    vars['ansible_playbook_python'] = '/usr/bin/python3'

# Generated at 2022-06-25 11:28:17.126474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=["1", "2"], variables=None, **kwargs) == ["1", "2"]

# Generated at 2022-06-25 11:28:19.344996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._flatten(['a', 'b', 'c', 'd'])


# Generated at 2022-06-25 11:28:20.927493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 11:28:29.153156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [
        [1, 1, 1],
        [2, 2, 2],
        [3, 3, 3]
    ]
    expected_result = [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3]
    ]
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(my_list)
    assert result == expected_result


# Generated at 2022-06-25 11:28:38.887803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = [u'a', u'b', u'c', u'd']
    y = [1, 2, 3, 4]
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([x, y]) == [
        [u'a', 1],
        [u'b', 2],
        [u'c', 3],
        [u'd', 4]
    ]
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run([y, x]) == [
        [1, u'a'],
        [2, u'b'],
        [3, u'c'],
        [4, u'd']
    ]
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:28:43.816558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([''], variables=None, c='v') == []
    assert lookup_module.run(['d'], variables=None, d='v') == []
    assert lookup_module.run(['d', 'e', 'f'], variables=None, d='v', e='v', f='v') == []
    assert lookup_module.run(['d'], variables=None, a='v', b='v', c='v') == []
    assert lookup_module.run(['d'], variables=None, d='v', b='v', c='v') == []

# Generated at 2022-06-25 11:28:48.295216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run_instance = LookupModule()
    assert LookupModule_run_instance.run([[['a','b','c','d']],[1,2,3,4]]) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]



# Generated at 2022-06-25 11:28:55.786522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [(['madhya', 'pradesh'], ['nagpur', 'agra']), (['maharashtra'], ['mumbai', 'pune'])]
    var_1 = []
    var_1 += [lookup_module_0.run(var_0) for x in range(0,2)]


# Generated at 2022-06-25 11:28:58.172389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()


# Generated at 2022-06-25 11:28:58.952049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1



# Generated at 2022-06-25 11:29:04.752765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = []
    result = lookup_module.run(var)
    assert result == []


# Generated at 2022-06-25 11:29:13.524605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:29:17.361313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = [1,2,3]
    result = lookup_module.run(term)
    assert result == term

# Generated at 2022-06-25 11:29:19.105343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [str(unichr(99))]
    var_1 = [str(unichr(99))]
    var_2 = lookup_run(var_1)


# Generated at 2022-06-25 11:29:25.098536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    list_0 = list()
    list_1 = lookup_run(list_0)
    assert list_0 == list_1



# Generated at 2022-06-25 11:29:28.373668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    def get_expected_result():
        expected_result = [["a", 'b', 'c', 'd'], [1, 4]]
        return expected_result
    def get_actual_result():
        terms = [['a', 'b', 'c', 'd'], [1, 4]]
        actual_result = lookup_module.run(terms)
        return actual_result
    assert_that(get_actual_result(), equal_to(get_expected_result()))


# Generated at 2022-06-25 11:29:30.233208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:29:37.512645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = [ [['a', 'b'], [[1, 2], 3]], [[None], [[], []]], [['c', 'd'], [[4, 5], 6]] ]
    assert lookup_module.run(var) == [['a', 1], ['b', 2], ['c', 4], ['d', 5]]


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:43.781318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var_0 = ['test_var_1', 'test_var_2', 'test_var_3']
    test_var_1 = ['test_var_4', 'test_var_5', 'test_var_6']
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(test_var_0, test_var_1)
    assert len(var_0) == 3

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:46.428334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [[1], [2, 3, 4]]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:29:55.756241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0 = []
    var_0 = LookupModule()
    var_1 = lookup_run(test_0)
    assert var_1 == [], "LookupModule::run failed: expected: [], got: {}".format(var_1)
    test_0 = [(['a', 'b', 'c'], [1, 2, 3])]
    var_2 = LookupModule()
    var_3 = lookup_run(test_0)
    assert var_3 == [['a', 1], ['b', 2], ['c', 3]], "LookupModule::run failed: expected: [['a', 1], ['b', 2], ['c', 3]], got: {}".format(var_3)
    test_0 = [(['a', 'b', 'c'], [1, 2])]
    var_4

# Generated at 2022-06-25 11:29:57.970020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert lookup_module_0.run(var_0) == var_1

# Generated at 2022-06-25 11:30:09.068375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Some XML.

# Generated at 2022-06-25 11:30:17.037591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

    var_2 = ['abc', [1, 2, 3, 4]]
    var_3 = lookup_run(var_2)

    var_4 = ['abc', {'foo': 'bar'}]
    var_5 = lookup_run(var_4)

    var_6 = [{'foo': 'bar'}]
    var_7 = lookup_run(var_6)


# Generated at 2022-06-25 11:30:26.894606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['a', 'b', 'c', 'd']
    var_1 = ['1', '2', '3', '4']

    lookup_module_0 = LookupModule()

    var_2 = lookup_module_0.run(var_0, var_1)
    assert var_2 == [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')]

    lookup_module_0_1 = LookupModule()

    var_3 = lookup_module_0_1.run(var_1, var_0)
    assert var_3 == [('1', 'a'), ('2', 'b'), ('3', 'c'), ('4', 'd')]



# Generated at 2022-06-25 11:30:28.793388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [1, 2, 3]
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 11:30:34.888781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    # var_1 should be an AnsibleError
    try:
        var_1 = lookup_module_0.run(my_list_0)
    except:
        var_1 = None


# Generated at 2022-06-25 11:30:42.017232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = ['1', '2']
  var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:30:50.056965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [["a", "b"], ["1", "2"]]
    var_3 = lookup_run(var_2)
    var_4 = [["a", "b", "c", "d"], ["1", "2", "3", "4"]]
    var_5 = lookup_run(var_4)


# Generated at 2022-06-25 11:30:56.791534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    expected_result = [['a', 1], ['b', 2], ['c', 3], ['d', 4]]

    lookup_module = LookupModule()
    result = lookup_module.run(terms)

    assert result == expected_result

# Generated at 2022-06-25 11:31:03.676609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [[1,2], [3, 4]]
    var_1 = [[]]
    var_2 = [[]]
    var_3 = [[], []]
    var_4 = [[1, 2]]
    var_5 = lookup_run(var_0)
    var_6 = lookup_run(var_1)
    var_7 = lookup_run(var_2)
    var_8 = lookup_run(var_3)
    var_9 = lookup_run(var_4)

# Generated at 2022-06-25 11:31:12.315955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_0.append(['d', 'e', 'f', 'g'])
    var_0.append([4, 5, 6])
    var_1 = lookup_module_0.run(var_0)
    var_2 = []
    var_2.append(lookup_module_0._flatten('d',4))
    var_2.append(lookup_module_0._flatten('e',5))
    var_2.append(lookup_module_0._flatten('f',6))
    var_2.append(lookup_module_0._flatten('g',None))
    print(var_2 == var_1)

# Generated at 2022-06-25 11:31:17.821776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_0.append([-1, 1, -1, 0])
    var_0.append([-1, 1, -1, 1])
    var_1 = lookup_run(var_0)
    assert len(var_1) == 4


# Generated at 2022-06-25 11:31:19.747885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == []



# Generated at 2022-06-25 11:31:20.866068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:31:26.414554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = [
        [
            'a',
            'b'
        ],
        [
            1,
            2
        ]
    ]
    var_1 = lookup_run(var_0)
    # unit test for exceptions
    try:
        var_0 = [
            [
            ]
        ]
        var_1 = lookup_run(var_0)
    except Exception:
        assert True
# -- end unit test --


# Generated at 2022-06-25 11:31:30.048740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_term_0 = ["a", "b", "c", "d"]
    var_term_1 = [1, 2, 3, 4]
    var_term_2 = []
    var_term_2.insert(0, var_term_0)
    var_term_2.insert(1, var_term_1)
    var_term_3 = []
    var_term_3.insert(0, var_term_2)
    var_0 = [var_term_3]
    var_1 = lookup_run(var_0)
    var_2 = [var_term_0, var_term_1]
    var_3 = lookup_run(var_2)
    var_4 = []
    var_5 = [var_term_0]

# Generated at 2022-06-25 11:31:37.435898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    var_0 = []
    with pytest.raises(AnsibleError):
        x.run(var_0)

# Generated at 2022-06-25 11:31:48.685454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = MagicMock()
    lookup_module_0._flatten.return_value = 's'
    lookup_module_0._templar = MagicMock()
    lookup_module_0._templar.template = MagicMock()
    lookup_module_0._templar.template.return_value = 'efg'
    lookup_module_0._loader = MagicMock()
    lookup_module_0._loader.load = MagicMock()
    lookup_module_0._loader.load.return_value = 'abc'
    lookup_module_0._lookup_variables = MagicMock()
    lookup_module_0._lookup_variables.return_value = 'xyz'

# Generated at 2022-06-25 11:31:51.388464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == []


# Generated at 2022-06-25 11:31:54.007029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = []
    var_2 = lookup_module_0.run(var_0, var_1)
    assert isinstance(var_2, list)

# Generated at 2022-06-25 11:32:02.430191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = open("/home/bradley/dev/ansible-sandbox/test/test_lookup_output/test_LookupModule_run_case_0.txt", encoding='utf-8')
    try:
        assert lookup_run(f.read().splitlines()) == [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')] and \
        lookup_run([['a', 'b', 'c', 'd'], ['1', '2', '3', '4']]) == [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')]
    finally:
        f.close()

# Generated at 2022-06-25 11:32:11.656512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4]
        ]
    var_1 = lookup_module_0.run(var_0)
    var_2 = lookup_module_0.run(var_0)
    var_3 = lookup_module_0.run(var_0)
    var_4 = lookup_module_0.run(var_0)
    var_5 = lookup_module_0.run(var_0)
    var_6 = lookup_module_0.run(var_0)
    var_7 = lookup_module_0.run(var_0)
    var_8 = lookup_module_0.run(var_0)
    var_9 = lookup_

# Generated at 2022-06-25 11:32:17.974233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    var_2 = type(var_1)
    var_3 = var_1 is None
    var_4 = var_2 is list
    var_5 = var_3 is False
    var_6 = var_4 and var_5
    assert var_6


# Generated at 2022-06-25 11:32:20.340943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:32:22.052474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()

# ------------------------
# ------------------------
# -----------------------------------------------------------------------------
# Main Program
# -----------------------------------------------------------------------------

# Generated at 2022-06-25 11:32:28.145460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == None

    lookup_module_0 = LookupModule()
    var_0 = ["a", "b", "c", "d"]
    var_2 = lookup_module_0.run(var_0)
    assert var_2 == ['a', 'b', 'c', 'd']


# Generated at 2022-06-25 11:32:49.536956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not 'ANSIBLE_SERVER_ADDRESS' in os.environ, 'ANSIBLE_SERVER_ADDRESS set in environ'
    assert not 'ANSIBLE_SERVER_PORT' in os.environ, 'ANSIBLE_SERVER_PORT set in environ'
    assert not 'ANSIBLE_SERVER_USER' in os.environ, 'ANSIBLE_SERVER_USER set in environ'
    assert not 'ANSIBLE_SERVER_PASSWORD' in os.environ, 'ANSIBLE_SERVER_PASSWORD set in environ'
    assert not 'ANSIBLE_SERVER_PRIVATE_KEY_FILE' in os.environ, 'ANSIBLE_SERVER_PRIVATE_KEY_FILE set in environ'
    assert not 'ANSIBLE_SERVER_USE_SSL' in os.environ

# Generated at 2022-06-25 11:32:53.315598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with an empty list.
    lookup_module_0 = LookupModule()
    var_2 = []
    var_3 = lookup_module_0.run()
    assert var_3 is None, 'Unable to return None from LookupModule.run().'


# Generated at 2022-06-25 11:32:59.806490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == []
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == []


# Generated at 2022-06-25 11:33:09.210847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_1 = ['a', 'b', 'c', 'd']
    var_2 = [1, 2, 3, 4]
    var_3 = (lookup_module_0, lookup_module_1)
    var_4 = lookup_module_0._lookup_variables(var_3)
    var_5 = lookup_module_0.run(var_4)
    # assert var_5 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert var_5 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

test_LookupModule_run()

# Generated at 2022-06-25 11:33:11.395160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:33:14.180971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 11:33:18.865179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    set_module_args(
        {
            "terms": [
                [
                    "a",
                    "b",
                    "c",
                    "d",
                ],
                [
                    1,
                    2,
                    3,
                    4,
                ],
            ],
        }
    )
    zip_longest_0 = ['1', '2', '3', '4']
    zip_longest_1 = ['a', 'b', 'c', 'd']
    with pytest.raises(AnsibleError, match="with_together requires at least one element in each list"):
        lookup_module_0

# Generated at 2022-06-25 11:33:23.432825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run_0.run(var_0)
    assert isinstance(var_1, list) == True



# Generated at 2022-06-25 11:33:27.435821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = DummyTemplar()
    lookup_module_0._loader = DummyLoader()
    var_0 = [
       ['a', 'b', 'c', 'd'],
       [1, 2, 3, 4]
    ]
    var_1 = lookup_module_0.run(var_0)
    #print(var_1)
    assert var_1 == [
       ['a', 1],
       ['b', 2],
       ['c', 3],
       ['d', 4]
    ]


# Generated at 2022-06-25 11:33:34.576645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words = [
        'look',
        'into',
        'my',
        'eyes',
        'look',
        'into',
        'my',
        'eyes',
        'the',
        'eyes',
        'the',
        'eyes',
        'the',
        'eyes',
        'not',
        'around',
        'the',
        'eyes',
        "don't",
        'look',
        'around',
        'the',
        'eyes',
        'look',
        'into',
        'my',
        'eyes',
        "you're",
        'under'
    ]


# Generated at 2022-06-25 11:33:58.886576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    lookup_module_0_run_0 = lookup_module_0.run(var_0)
    assert lookup_module_0_run_0 is not None


# Generated at 2022-06-25 11:34:03.078508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)



# Generated at 2022-06-25 11:34:05.703694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        ['a', 'b', 'c'],
        [1, 2, 3]
    ]
    var_1 = lookup_run(var_0)
    assert var_1 == [['a', 1], ['b', 2], ['c', 3]], "var_1: %s" % var_1



# Generated at 2022-06-25 11:34:08.381232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [0, 1, 2, 3],
        [4, 5, 6],
    ]
    expected_result = [
        [0, 4],
        [1, 5],
        [2, 6],
        [3, None],
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms=terms)
    assert result == expected_result



# Generated at 2022-06-25 11:34:16.799845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print( 'In test_LookupModule_run' )
    lookup_module0 = LookupModule()
    lookup_module1 = lookup_module0
    term0 = [ list0, list1 ]
    term1 = lookup_module0._lookup_variables(term0)
    result = lookup_module0(term1)
    assert ( result == [ ( 'a', 1 ), ( 'b', 2 ), ( 'c', 3 ), ( 'd', 4 ) ] )


# Generated at 2022-06-25 11:34:17.933686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_1 = AnsibleLookupModule()
  var_1 = []
  lookup_1.run(var_1)

# Generated at 2022-06-25 11:34:19.580323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)



# Generated at 2022-06-25 11:34:26.424859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [['a', 'b', 'c', 'd'], ['1', '2', '3', '4']]
    var_3 = lookup_module_1.run(var_2)
    var_4 = [['a', '1'], ['b', '2'], ['c', '3'], ['d', '4']]
    assert var_3 == var_4


# Generated at 2022-06-25 11:34:30.154781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("test_LookupModule_run")
  lookup_module = LookupModule()
  terms = [
    [1,2],
    ['a','b','c'],
  ]
  expected = [
    [1,'a'],
    [2,'b'],
    [None,'c'],
  ]
  assert lookup_module.run(terms) == expected

test_LookupModule_run()

# Generated at 2022-06-25 11:34:31.207592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Run test case 0
    test_case_0()

# Generated at 2022-06-25 11:35:18.358414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Basic unit test for method run of class LookupModule
    """
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert len(var_1) == 0


# Generated at 2022-06-25 11:35:19.526713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:35:24.441364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [ 'a', 'b', 'c', 'd' ]
    var_1 = [ 1, 2, 3, 4 ]
    var_2 = [ 'a', 'b', 'c', 'd' ]
    var_3 = [ 1, 2, 3 ]
    var_4 = [ 'a', 'b', 'c', 'd' ]
    var_5 = [ 1, 2 ]
    var_6 = [ 'a', 'b', 'c', 'd' ]
    var_7 = [ 1 ]
    var_8 = [ 'a', 'b', 'c', 'd' ]
    var_9 = []
    lookup_module_1 = LookupModule()
    var_10 = [ var_0, var_1 ]
    var_11 = lookup_module_1.run(var_10)

# Generated at 2022-06-25 11:35:29.730367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = dict(
        _terms=dict(
            required=True,
            description="list of lists to merge",
            type="list",
        ),
    )

    # assert lu['run'] == "test"
    # assert lu['run'] == "test"


# Generated at 2022-06-25 11:35:35.137468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms):
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms, loader=None, variables=None)



# Generated at 2022-06-25 11:35:44.690688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x1 = [1, 2, 3]
    x2 = [1, 2, 3]
    x3 = [1, 2, 3]
    x4 = [1, 2, 3]
    x5 = 1
    x6 = 10
    x7 = 0
    x8 = 0
    x9 = 0
    x10 = 0
    x11 = 0
    x12 = 0
    x13 = 0
    x14 = 0
    x15 = 0
    x16 = 0
    x17 = 0
    x18 = 0
    x19 = 0
    x20 = 0
    x21 = None
    
    inp0 = [x1, x2, x3, x4]

# Generated at 2022-06-25 11:35:46.812106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lines_0 = LookupModule()
    var_0 = ['s']
    var_1 = 's'
    var_2 = lookup_run(var_0)
    assert var_2 == var_1


# Generated at 2022-06-25 11:35:51.443264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = []
    res = lookup_module.run(var)
    print("The res is %s" % res)
    

# Generated at 2022-06-25 11:35:56.103730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = lookup_run(var_0)
    assert var_1 == None


# Generated at 2022-06-25 11:36:00.513125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('var_0') == []
