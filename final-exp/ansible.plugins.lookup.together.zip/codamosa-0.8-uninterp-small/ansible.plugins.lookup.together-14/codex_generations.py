

# Generated at 2022-06-25 11:27:18.490651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -103.23536
    lookup_module_0 = LookupModule(float_0)

    assert not lookup_module_0.run(lookup_module_0)

    lookup_module_0 = LookupModule(float_0)

    lookup_module_0.run(lookup_module_0)
    assert 1 == 1

test_case_0()

# Generated at 2022-06-25 11:27:20.512918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == (
        [('a', 1), ('b', 2), ('c', 3), ('d', 4)],
    )

# Generated at 2022-06-25 11:27:26.482820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_params_0 = ['adfadfasd']
    test_params_1 = None
    test_params_2 = {}
    test_params_3 = None
    test_params_4 = None
    test_params_5 = None
    test_params_6 = None
    test_params_7 = None
    test_params_8 = None
    test_params_9 = None
    test_params_10 = None
    test_params_11 = None
    test_params_12 = None
    test_params_13 = None
    test_params_14 = None
    test_params_15 = None
    test_params_16 = None
    test_params_17 = None
    test_params_18 = None
    test_params_19 = None
    test_params

# Generated at 2022-06-25 11:27:31.329250
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with supplied arguments
    with pytest.raises(AnsibleError):
        lookup_module_1 = LookupModule.run([])

    # Test with supplied arguments
    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule([[1,2,3], [4,5,6]])

        lookup_module_0.run([[1,2,3], [4,5,6]])

# Generated at 2022-06-25 11:27:35.226608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module_0 = LookupModule(string_0)
        lookup_module_0.templar = string_0
        result_0 = lookup_module_0.run(string_0)
        lookup_module_0.run(string_0)

# Generated at 2022-06-25 11:27:37.077046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:27:41.947586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(library_dir='/usr/bin/lib')
    lookup_module_0.set_options( variable=dict, _templar=dict, _loader=dict,
        _task_vars=dict, _variables=dict, _available_variables=dict)
    lookup_module_0.run(terms=[dict()], variables={"a": "3", "b": "3", "c": "3", "d": "3"})

# Generated at 2022-06-25 11:27:49.869480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -103.23536
    lookup_module_1 = LookupModule(float_1)
    str_1 = 'abcd'
    dict_2 = {"a":"b", "c":"d"}
    dict_3 = {1:'a', 2:'b'}
    list_1 = ['a', 'b', 'c']
    var_1 = 'foo'
    result_1 = lookup_module_1.run(str_1, dict_2)
    result_2 = lookup_module_1.run(dict_3, var_1)
    result_3 = lookup_module_1.run(list_1)

# Generated at 2022-06-25 11:27:54.642223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -103.23536
    lookup_module_0 = LookupModule(float_0)
    int_0 = 0

    assert lookup_module_0.run(int_0) is None


# Generated at 2022-06-25 11:28:02.651711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    loop_count = 0

    # test setup
    terms = [1, 2]
    variables = [1, 2]
    kwargs = {'kwarg_0': 1, 'kwarg_1': 2}
    lookup_module_0 = LookupModule(terms, variables, **kwargs)

    # test call
    results = lookup_module_0.run(terms, variables, **kwargs)

    # test validation
    assert results == [1, 2]

    # test cleanup


# Generated at 2022-06-25 11:28:14.375299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # Test empty arrays
    var_0 = lookup_run([[]])
    assert var_0 == []
    # Test empty arrays
    var_1 = lookup_run([[], []])
    assert var_1 == []
    # Test empty arrays
    var_2 = lookup_run([[], [], []])
    assert var_2 == []
    # Test first array with one element.
    var_3 = lookup_run([[1], [2]])
    assert var_3 == [[1, 2]]
    # Test for first array with only element
    var_4 = lookup_run([[1]])
    assert var_4 == [[1]]
    # Test for first array with elements

# Generated at 2022-06-25 11:28:19.928894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -103.23536
    lookup_module_1 = LookupModule(float_1)
    str_1 = 'ddsZ|0/wI\r;T='
    var_1 = lookup_run(str_1)


# Generated at 2022-06-25 11:28:22.423539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = dict()
    assert lookup_module_0.run(list_0, dict_0) == None


# Generated at 2022-06-25 11:28:24.753652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -103.23536
    lookup_module_0 = LookupModule(float_0)
    str_0 = 'ddsZ|0/wI\r;T='
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 11:28:28.452188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fname_0 = 'ansible_0.0.2.egg-info'
    int_0 = 11
    str_0 = 'V|j@[{fUYO-U6o;Ui'
    lookup_module_0 = LookupModule(fname_0)
    attr_0 = lookup_module_0.run(int_0)
    attr_1 = lookup_module_0.run(str_0)



# Generated at 2022-06-25 11:28:38.773280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_list_0 = ['str_0', 'str_1', 'str_2', 'str_6']
    lookup_module_0 = LookupModule(str_list_0)
    str_list_1 = ['str_0', 'str_1', 'str_2', 'str_6']
    lookup_module_1 = LookupModule(str_list_1)
    str_list_1 = ['str_0', 'str_1', 'str_2', 'str_6']
    lookup_module_2 = LookupModule(str_list_1)
    str_list_1 = ['str_0', 'str_1', 'str_2', 'str_6']
    lookup_module_3 = LookupModule(str_list_1)
    str_2 = 'str_4'
    lookup_module

# Generated at 2022-06-25 11:28:47.582688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0.run(terms_0, variables_0, kwargs_0)
    str_0 = 'ddsZ|0/wI\r;T='
    variables = str_0
    var_1 = lookup_run(variables)
    var_1 = lookup_run(kwargs_0)
    terms_0 = [x for x in range(4)]
    kwargs_0 = {'_terms': terms_0}
    lookup_type = 'LookupModule'
    lookup_module_1 = Object.create(type_0, args_0)
    type_0 = lookup_type
    args_0 = lookup_module_0
    variables_0 = variables

# Generated at 2022-06-25 11:28:48.114869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:28:49.911750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -103.23536
    lookup_module_0 = LookupModule(float_0)
    str_0 = 'ddsZ|0/wI\r;T='
    var_0 = lookup_run(str_0)
    assert var_0 == 0


# Generated at 2022-06-25 11:28:59.423742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -9.07426096422805
    lookup_module_0 = LookupModule(float_0)
    str_0 = 'N\'Xr'
    arr_0 = [lookup_module_0._flatten(float_0), lookup_module_0._flatten(str_0), lookup_module_0._flatten(str_0)]
    str_1 = 'A=n'
    arr_1 = [lookup_module_0._flatten(str_0), lookup_module_0._flatten(str_1)]
    dict_0 = dict()
    assert_false(lookup_module_0.run(arr_0, dict_0) == arr_1)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:06.285078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:29:07.710965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    my_list = [0,1,2,3]
    ret = x.run(my_list)
    print(ret)

# Generated at 2022-06-25 11:29:11.489156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)

# Generated at 2022-06-25 11:29:14.342284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = list()
    var_2 = dict()
    var_3 = dict()
    var_4 = lookup_run(var_1, var_2, var_3)
    assert isinstance(var_4, )


# Generated at 2022-06-25 11:29:17.434910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)

# Generated at 2022-06-25 11:29:18.647304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = dict()
    var_1 = lookup_module_0.run(terms)

# Generated at 2022-06-25 11:29:26.847174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['a', 'b', 'c', 'd']
    var_1 = [1, 2, 3, 4]
    var_2 = dict()
    var_2['_templar'] = var_0
    var_2['_loader'] = var_1
    var_3 = lookup_module_0._lookup_variables([var_0, var_1])
    var_4 = lookup_run(var_2, var_3)


# Generated at 2022-06-25 11:29:28.907890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:29:31.144646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)

    errors = False
    if len(var_1) != 0:
        errors = True
        print('Failed to execute correctly: %s != %s' % (len(var_1), 0))
    assert not errors


# Generated at 2022-06-25 11:29:32.580949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("test_LookupModule_run")
  lookup_module_obj = LookupModule()
  var_0 = dict()
  var_1 = lookup_run(var_0, var_0)

# Main method for running the tests.

# Generated at 2022-06-25 11:29:37.614938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = dict()
    var_3 = (['a', 'b'],)
    var_4 = lookup_module_0.run(var_3, var_2)

# Test %s

# Generated at 2022-06-25 11:29:39.116637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = dict()
    lookup_module.run(var, var)

# Generated at 2022-06-25 11:29:43.360077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = [lookup_module_0._flatten(x) for x in zip_longest(*var_0, fillvalue=None)]
    var_2 = lookup_run(var_0, var_0)
    assert var_1 == var_2


# Generated at 2022-06-25 11:29:49.061829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup the mock object to record the calls
    mock_lookup_module_0 = Mock()
    mock_lookup_module_0.run = MagicMock()
    mock_lookup_module_0.run.side_effect = test_LookupModule_run_test_case_0()
    # Call the method to test
    run(mock_lookup_module_0, sys.argv[1])
    # Assert the return type
    assert isinstance(mock_lookup_module_0.run(), list)
    # Assert the return value
    assert mock_lookup_module_0.run() == [(1, None)]


# Generated at 2022-06-25 11:29:53.902983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_terms': list()})
    lookup_module_0.set_context({'lookup_file': lookup_file, 'lookup_plugin': lookup_plugin, 'template': template, 'vars': vars})
    var_0 = list()
    var_0.append(list())
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:29:58.597085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = list()
    var_1.append('a')
    var_1.append('b')
    var_2 = dict()
    var_2.update(a='a')
    var_2.update(b='b')
    assert lookup_module_0.run(var_0, var_1, **var_2)


# Generated at 2022-06-25 11:30:07.453705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["e", "f"], ["a", "b"], ["c", "d"]]
    var_1 = lookup_run(var_0, var_0)
    assert(len(var_1) == 2)
    for i in range(len(var_1)):
        assert(len(var_1[i]) == 3)
        assert(var_1[i][0] == "e")
        assert(var_1[i][1] == "a")
        assert(var_1[i][2] == "c")


# Generated at 2022-06-25 11:30:13.408593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = dict()
    var_3 = [u'a', u'b', u'c', u'd']
    var_4 = [u'1', u'2', u'3', u'4']
    var_2 = [var_3, var_4]
    var_5 = lookup_module_1.run(var_2)
    # Expected output
    # [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')]



# Generated at 2022-06-25 11:30:15.957351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    # Call method run of LookupModule
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:30:27.245812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            "item.1",
            "item.0"
        ],
        [
            "msg:",
            "debug:"
        ]
    ]
    var_1 = dict()
    var_2 = dict()
    var_2["with_together"] = "debug: msg: \"{{ item.0 }} and {{ item.1 }}\""
    var_2["with_together."] = "list"
    var_2["with_together.0"] = "list"
    var_2["with_together.1"] = "list"
    var_2["with_together.0.0"] = "a"
    var_2["with_together.0.1"] = "b"

# Generated at 2022-06-25 11:30:37.522430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module__0 = LookupModule()
    var_a = dict()
    # whatever you want to test this needs to return a list
    var_b = lookup_module__0.run(var_a, var_a)
    assert type(var_b) == list


# Generated at 2022-06-25 11:30:40.067812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)
    assert var_1 == [None]



# Generated at 2022-06-25 11:30:44.060557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    var_1 = lookup_run(var_0, var_0)
    var_2 = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    eq_(var_1, var_2)


# Generated at 2022-06-25 11:30:45.842929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert()


# Generated at 2022-06-25 11:30:50.913433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({}, {})

    my_variable = dict()
    my_variable["AnsibleModule"] = module

    lookup_plugin = LookupModule()
    lookup_plugin._templar = my_variable

    lookup_plugin.run(module.params, my_variable)

    return



# Generated at 2022-06-25 11:30:59.080462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = dict()
    arguments['terms'] = dict()
    arguments['variables'] = dict()
    arguments['key'] = dict()
    arguments['wantlist'] = dict()
    arguments['wantlist'] = dict(required=True)
    arguments['variables'] = dict(required=False)
    arguments['terms'] = dict(required=True)
    arguments['key'] = dict(required=False)
    result = dict()

    # Invoke method
    # Assertion message: The first parameter must be a list
    with pytest.raises(AnsibleError) as exception:
        run(**arguments)


# Generated at 2022-06-25 11:31:05.751351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = dict()
    def test_run(self, terms, variables=None, **kwargs):
        return my_list

    var_0 = LookupModule()
    var_1 = dict()
    var_2 = test_run(var_0, var_1)
    assert var_2 == my_list


# Generated at 2022-06-25 11:31:11.059840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    param_0 = dict()
    param_0['None'] = None
    param_0['1'] = 1
    param_0['5'] = 5
    param_0['3'] = 3
    param_0['2'] = 2
    param_0['7'] = 7
    param_0['6'] = 6
    param_0['4'] = 4
    param_0['8'] = 8
    param_0['9'] = 9

    var_2 = lookup_module_0.run(param_0)
    assert var_2 == [('None', 1), ('5', 3), ('2', 7), ('6', 4), ('4', 8), ('8', 9), ('9', None)]


# Generated at 2022-06-25 11:31:14.394787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)
    var_2 = lookup_run(var_1, var_0)


# Generated at 2022-06-25 11:31:24.072475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['foo', 'bar']
    lookup_module_0._templar = get_templar()
    assert (lookup_module_0.run(var_0, None) == [['foo', 'bar']])

    lookup_module_1 = LookupModule()
    var_0 = ['foo', 'bar']
    var_1 = ['foo']
    lookup_module_1._templar = get_templar()
    assert (lookup_module_1.run(var_0, var_1) == [['foo', 'foo'], ['bar', None]])

    lookup_module_2 = LookupModule()
    var_0 = ['foo', 'bar']
    var_1 = ['foo', 'bar', 'baz']
   

# Generated at 2022-06-25 11:31:29.458085
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True

test_LookupModule_run()

# Generated at 2022-06-25 11:31:34.944539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = ['T', 'e', 's', 't', 'i', 'n', 'g']
    var_3 = ['J', 'u', 'n', 'i', 't']
    var_4 = ['P', 'y', 't', 'h', 'o', 'n']
    var_5 = [var_2, var_3, var_4]
    var_6 = lookup_module_1.run(var_5, var_5)

# Generated at 2022-06-25 11:31:38.001364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [list(),list(),list()]
    var_0 = dict()
    x_0 = lookup_run(var_0, var_0)



# Generated at 2022-06-25 11:31:49.430001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # '1' and '1' are the values of the namespaced variables 'item.0' and
    # 'item.1', respectively, in the template context.
    lookup_module_0._templar.available_variables = {'item': {'0': '1', '1': '1'}}
    # 'None', 'None', 'None', and 'None' are the values of the namespaced
    # variables 'item.0', 'item.1', 'item.2', and 'item.3', respectively, in the
    # template context.
    lookup_module_0._templar.available_variables = {'item': {'0': 'None', '1': 'None', '2': 'None', '3': 'None'}}
    # 'None', 'None',

# Generated at 2022-06-25 11:31:56.947092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0 = [ [ ['Hello'], ['World'] ], [ ['foo'], ['foobar'], ['baz'] ] ]
    assert LookupModule().run(test_0) == [('Hello', 'foo'), ('World', 'foobar'), (None, 'baz')]
    test_1 = [ [1, 2, 3], [4, 5, 6] ]
    assert LookupModule().run(test_1) == [(1, 4), (2, 5), (3, 6)]
    test_2 = [ [1, 2], [3] ]
    assert LookupModule().run(test_2) == [(1, 3), (2, None)]
    test_3 = [ ['a', 'b'], [1, 2] ]

# Generated at 2022-06-25 11:32:05.535630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = [["a", "b", "c", "d"], [1, 2, 3, 4]]
    var_2 = lookup_module_0.run(var_1, var_0, )
    var_3 = [['a', 1], ['b', 2], ['c', 3], ['d', 4]]
    assert var_2 == var_3


# Generated at 2022-06-25 11:32:09.538023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["a", "b", "c", "d"], ["1", "2", "3", "4"]) == [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')]


# Generated at 2022-06-25 11:32:15.267034
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = [
        "a",
        "b",
        "c",
        "d",
    ]
    var_1 = [
        1,
        2,
        3,
        4,
    ]
    var_2 = lookup_module_0.run([
        var_0,
        var_1,
    ])
    assert var_2 == [
        [
            "a",
            1,
        ],
        [
            "b",
            2,
        ],
        [
            "c",
            3,
        ],
        [
            "d",
            4,
        ],
    ]


# Generated at 2022-06-25 11:32:23.958131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = list()
    var_0.append('a')
    var_0.append('b')
    var_0.append('c')
    var_0.append('d')
    var_1 = list()
    var_1.append('1')
    var_1.append('2')
    var_1.append('3')
    var_1.append('4')
    var_2 = dict()
    var_3 = lookup_run(var_2, var_2)
    var_4 = list()
    var_4.append('a')
    var_4.append('b')
    var_4.append('c')
    var_4.append('d')
    var_5 = list()
    var_5.append('1')

# Generated at 2022-06-25 11:32:25.639194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sut = LookupModule()
    assert type(sut.run([1, 2]) is List)


# Generated at 2022-06-25 11:32:39.260066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['a', 'b', 'c', 'd']
    var_1 = [1, 2, 3, 4]
    test_run(lookup_module_0, var_0, var_1)


# Generated at 2022-06-25 11:32:45.072688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    var_0 = dict()
    var_0 = lookup_run(var_0, var_0)
    assert  var_0 == [ [ 'a', 1 ], [ 'b', 2 ], [ 'c', 3 ], [ 'd', 4 ] ]


# Generated at 2022-06-25 11:32:48.661470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)
    var_2 = lookup_module_0._lookup_variables


# Generated at 2022-06-25 11:32:56.650806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_0.setdefault('ansible_check_mode', None)
    var_0.setdefault('ansible_facts', None)
    var_0.setdefault('ansible_module_name', 'debug')
    var_0.setdefault('ansible_module_args', {'msg': "'x'"})
    var_1 = lookup_run(var_0, var_0)
    var_2 = ['x', None, 'x', None]
    assert var_1 == var_2

# Generated at 2022-06-25 11:33:00.411981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [[1, 2, 3], [4, 5, 6]]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == [(1, 4), (2, 5), (3, 6)]



# Generated at 2022-06-25 11:33:02.871102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #lookup_module = LookupModule()
    #something = lookup_module.run()
    assert(True)


# Generated at 2022-06-25 11:33:12.375963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # zero terms
    terms = [
        [],
    ]
    target = [
        [],
    ]
    # assert method run raises AnsibleError
    try:
        obj=LookupModule()
        obj.run(terms)
    except AnsibleError:
        assert True
    else:
        assert False
    # one term
    terms = [
        [1],
    ]
    target = [
        [1],
    ]
    obj=LookupModule()
    assert obj.run(terms) == target
    # two terms
    terms = [
        [1, 2],
        [3],
    ]
    target = [
        [1, 3],
        [2, None],
    ]
    obj=LookupModule()
    assert obj.run(terms) == target
    # three terms


# Generated at 2022-06-25 11:33:17.864259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the test variables
    var_0 = dict()
    var_1 = None
    var_0['var_1'] = var_1
    # Construct the object
    lookup_module_0 = LookupModule(var_0)
    var_2 = []
    var_3 = [var_2]
    var_4 = [1, 2]
    var_3.append(var_4)
    var_5 = [3, 4]
    var_3.append(var_5)
    var_6 = [5, 6]
    var_3.append(var_6)
    # Invoke the method
    var_7 = lookup_module_0.run(var_3, var_0)
    # Verify the results
    assert var_7[0] == var_2
    assert var_7

# Generated at 2022-06-25 11:33:25.532640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the arguments of the function run
    terms = [(1, 2)]
    var_2 = create_mock_object(terms, 'mock_terms')

    variables = 0
    kwargs = {}

    p = LookupModule()
    retval = p.run(var_2, variables, **kwargs)
    assert retval == [['a', 'b'], ['1', '2']]

# Generated at 2022-06-25 11:33:29.671247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = test_case_0()
    var_2 = lookup_module_0.run(var_0, var_1)
    assert (var_2 == var_0)


# Generated at 2022-06-25 11:33:55.620641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = dict()
    var_2['lookup_templates'] = dict()
    var_2['lookup_file'] = dict()
    var_2['lookup_templates']['lookup_dir'] = None
    var_2['lookup_templates']['loader'] = None
    var_2['lookup_file']['lookup_dir'] = None
    var_2['lookup_file']['loader'] = None
    var_2['lookup_file']['templar'] = None
    var_1 = list()
    var_1.append(['a', 'b', 'c', 'd'])
    var_1.append([1, 2, 3, 4])

# Generated at 2022-06-25 11:34:02.652724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            [
                'a',
                'b'
            ],
            [
                1,
                2
            ]
        ]
    ]
    var_1 = lookup_module_0._lookup_variables(var_0)
    assert var_1 == [['a', 'b'], [1, 2]], "Expected [('a',1), ('b', 2)], Got {0}".format(var_1)

    var_0 = [
        [
            [
                'a',
                'b',
                'c',
                'd'
            ],
            [
                1,
                2,
                3,
                4
            ]
        ]
    ]
    var_1 = lookup_module_0

# Generated at 2022-06-25 11:34:03.637869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)

# Generated at 2022-06-25 11:34:07.104494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  var = {'a': [[1,2,3],[4,5,6]]}
  var_1 = lookup_run(var)
  assert var_1 == [('1','4'), ('2','5'), ('3','6')]

# This will be used to check output of tests

# Generated at 2022-06-25 11:34:11.844339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = []
    var_1.append("a")
    var_1.append("b")
    var_1.append("c")
    var_1.append("d")
    var_2 = []
    var_2.append(1)
    var_2.append(2)
    var_2.append(3)
    var_2.append(4)
    var_3 = []
    var_3.append(var_1)
    var_3.append(var_2)
    var_4 = lookup_module_0.run(var_3, var_0)
    assert isinstance(var_4, list)
    var_5 = len(var_4)
    assert var_5 == 4


# Generated at 2022-06-25 11:34:14.962911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # var_0 is a list
    var_0 = []
    var_1 = dict()
    assert list == type(lookup_run(var_0, var_1))


# Generated at 2022-06-25 11:34:23.446996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = DictDataLoader({u'roles/common/vars/main.yml': u''}).get_basedir()
    lookup_module_0._templar = Templar(variables={u'var': u'value'})
    lookup_module_0.run([u'{{ var }}'])
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = DictDataLoader({u'roles/common/vars/main.yml': u''}).get_basedir()

# Generated at 2022-06-25 11:34:27.730262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["This is a string", "this is another string"]
    var_1 = ["This is something", "this is another thing"]
    var_2 = lookup_module_0.run(var_0, var_1)



# Generated at 2022-06-25 11:34:33.308412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = dict()
    var_1 = []
    var_2 = lookup_run(var_0, var_0)
    var_3 = assert_that(var_2, equal_to(var_1))
    var_4 = [["a"], [1]]
    var_5 = lookup_run(var_4, var_0)
    var_6 = assert_that(var_5, equal_to([["a", 1]]))
    var_7 = [["a", "b"], [1, 2]]
    var_8 = lookup_run(var_7, var_0)

# Generated at 2022-06-25 11:34:40.594786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['a', 'b', 'c', 'd']
    var_1 = [1, 2, 3, 4]
    var_2 = lookup_module_0.run(var_0, var_1, a=None, b=None)
    assert var_2 == [('a',1), ('b',2), ('c',3), ('d',4)]

# Integration test for method run of class LookupModule

# Generated at 2022-06-25 11:35:26.668653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = dict()
    args_1 = dict()

    with pytest.raises(AnsibleError):
        LookupModule(args_0, args_1).run(args_0, args_1)

# Generated at 2022-06-25 11:35:29.609960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(['a', 'b', 'c', 'd'], ['1', '2', '3', '4']), list)
    assert isinstance(lookup_module.run([], ['1', '2', '3', '4']), list)
    assert isinstance(lookup_module.run(['a', 'b', 'c', 'd'], []), list)


# Generated at 2022-06-25 11:35:37.292266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = dict()
    var_0 = dict()
    var_1 = lookup_module_0.run(terms_0, var_0)

if __name__ == "__main__":
    if __package__ is None:
        import sys
        from os import path
        sys.path.append( path.dirname( path.dirname( path.abspath(__file__) ) ) )
        from run import lookup_run
        test_case_0()
        test_LookupModule_run()

# Generated at 2022-06-25 11:35:41.052565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = var_0.run([[1, 2, 3], ["a" "b", "c"]])
    # [3,2,3]


# Generated at 2022-06-25 11:35:49.471502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [{'a': ['str', 'str', 'str']}, {'b': [1, 2, 3], 'c': [{'0': 'str', '1': 'str', '2': 'str'}]}]
    if True:
        var_0 = lookup_module_0.run(terms, {})
        var_1 = [['a', 1, {'0': 'str', '1': 'str', '2': 'str'}], ['b', {'0': 'str', '1': 'str', '2': 'str'}, 'str'], ['c', 'str', {'0': 'str', '1': 'str', '2': 'str'}]]
        assert not var_0 == var_1

# Generated at 2022-06-25 11:35:50.916489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError()


if __name__ == "__main__":
    print(test_LookupModule_run())

# Generated at 2022-06-25 11:35:55.475509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup variables
    lookup_module_1 = LookupModule()
    results_1 = [list(x) for x in zip_longest([1,2,3],[4,5,6])]
    var_1 = [[1,2,3],[4,5,6]]
    var_2 = {'vars': {'a': 'b'}}

    # apply test method
    result_1 = lookup_module_1.run(var_1, var_2)

    #assert result
    assert result_1 == results_1

    # setup variables
    lookup_module_2 = LookupModule()
    results_2 = [list(x) for x in zip_longest(['a','b','c','d'],[1,2,3])]

# Generated at 2022-06-25 11:36:00.107741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = lookup_module_0.run()


# Generated at 2022-06-25 11:36:00.622854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 11:36:06.456882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = dict()
    var_1 = lookup_run(var_0, var_0)