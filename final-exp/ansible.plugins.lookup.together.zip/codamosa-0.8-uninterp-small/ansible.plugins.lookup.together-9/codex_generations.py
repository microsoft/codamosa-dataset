

# Generated at 2022-06-25 11:27:17.278701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]])


# Generated at 2022-06-25 11:27:20.715864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_15 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=terms_15, variables=None)
    assert [None, 1] == result_0[1]



# Generated at 2022-06-25 11:27:23.805262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [
        [
            'a', 'b', 'c'
        ],
        [
            1, 2, 3
        ]
    ]
    assert lookup_module_0.run(my_list) == [('a',1), ('b',2), ('c',3)]

# Generated at 2022-06-25 11:27:29.377312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = None
    my_list_0 = lookup_module_0._lookup_variables(my_list_0)
    try:
        str = lookup_module_0.run(my_list_0)
    except AnsibleError as exception_0:
        pass



# Generated at 2022-06-25 11:27:34.519424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
        ('a', 1), ('b', 2)
    ]
    variables = None
    lookup_module_1.run(terms, variables=variables,)

# Generated at 2022-06-25 11:27:43.110188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4]
    ]
    ret = LookupModule().run(terms)
    assert ret == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

    terms = [
        ['a', 'b'],
        [1, 2, 3, 4]
    ]
    ret = LookupModule().run(terms)
    assert ret == [('a', 1), ('b', 2), (None, 3), (None, 4)]

    terms = [
        ['a', 'b', 'c', 'd'],
        [1, 2]
    ]
    ret = LookupModule().run(terms)

# Generated at 2022-06-25 11:27:49.473449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_Terms = "['a', 'b', 'c', 'd']\n[1, 2, 3, 4]"
    lookup_module_0 = LookupModule()
    my_list_0 = lookup_module_0.run(my_Terms)
    assert len(my_list_0) == 4
    assert my_list_0[0] == 'a'
    assert my_list_0[1] == 'b'
    assert my_list_0[2] == 'c'
    assert my_list_0[3] == 'd'

# Generated at 2022-06-25 11:28:00.496109
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    result_0 = lookup_module_1.run()

    lookup_module_2 = LookupModule()
    result_1 = lookup_module_2.run()

    lookup_module_3 = LookupModule()
    result_2 = lookup_module_3.run()

    lookup_module_4 = LookupModule()
    result_3 = lookup_module_4.run()

    lookup_module_5 = LookupModule()
    result_4 = lookup_module_5.run()

    lookup_module_6 = LookupModule()
    result_5 = lookup_module_6.run()

    lookup_module_7 = LookupModule()
    result_6 = lookup_module_7.run()

    lookup_module_8 = LookupModule()

# Generated at 2022-06-25 11:28:01.102269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:28:09.084615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a', 'b'], [[1, 2], [3, 4]], [], []) == [['a', 1], ['b', 2]]
    assert lookup_module.run(['a', 'b'], [[1, 2]], [], []) == [['a', 1], ['b', 2]]
    assert lookup_module.run(['a', 'b'], [[1, 2], [3, 4], [5, 6]], [], []) == [['a', 1, 5], ['b', 2, 6]]
    assert lookup_module.run([], [[1, 2], [3, 4]], [], []) == [[None, 1], [None, 2]]

# Generated at 2022-06-25 11:28:21.508546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run([['abc', 'def', 'ghi'], [1, 2, 3]])) == 3
    assert len(lookup_module_0.run([['abc', 'def', 'ghi'], [1, 2, 3, 4]])) == 3
    assert len(lookup_module_0.run([['abc', 'def'], [1, 2, 3, 4]])) == 2
    assert len(lookup_module_0.run([['abc', 'def', 'ghi']])) == 3
    assert len(lookup_module_0.run([['abc', 'def', 'ghi'], [1, 2, 3], [1, 2, 3]])) == 3

# Generated at 2022-06-25 11:28:28.868230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['[1, 2, 3]', '[4, 5, 6]'])
    assert result == [["1", "4"], ["2", "5"], ["3", "6"]]



# Generated at 2022-06-25 11:28:30.279112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1


# Generated at 2022-06-25 11:28:37.228361
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    lookup_module_1.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]])
    lookup_module_2 = LookupModule()
    lookup_module_2.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4], [0, 1, 2, 3]])
    lookup_module_3 = LookupModule()
    lookup_module_3.run([['a', 'b', 'c', 'd'], [1]])
    lookup_module_4 = LookupModule()
    lookup_module_4.run([])



# Generated at 2022-06-25 11:28:43.659467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [[ 1, 2, 3 ], [ 4, 5, 6 ]]
    result = lookup_module_1.run(terms_1)

    assert result == [[1, 4], [2, 5], [3, 6]]


# Generated at 2022-06-25 11:28:47.517302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.run()

    # Exception raised when run is called without parameter terms
    except TypeError:
        assert True

    assert False


# Generated at 2022-06-25 11:28:55.485251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test case of correct terms being passed
    assert lookup_module_0.run() == []

    # Test case of incorrect terms being passed
    try:
        lookup_module_0.run(0)
    except TypeError:
        pass
    else:
        assert False

    # Test case of missing terms being passed
    assert lookup_module_0.run() == []

    # Test case of incorrect terms being passed
    try:
        lookup_module_0.run(0)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 11:29:02.227446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({'_ansible_check_mode': False})
    assert lookup_module_1.run([['1', '2', '3'],
                                ['4', '5', '6']]) == [('1', '4'), ('2', '5'), ('3', '6')]
    assert lookup_module_1.run([['1', '2'], ['3']]) == [('1', '3'), ('2', None)]
    assert lookup_module_1.run([[], ['1']]) == [(None, '1')]


# Generated at 2022-06-25 11:29:05.445027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylist = [8, 2, 3]
    testlist = LookupModule()._lookup_variables(['2, 3', [8, 2, 3]])
    testlist = LookupModule()._lookup_variables(['2, 3, 2'])
    assert mylist == [2, 3, 2]


# Generated at 2022-06-25 11:29:12.837096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [["a","b","c"],["1","2","3"]]
    terms_2 = lookup_module_0._lookup_variables(terms_1)
    words_1 = ["a","1"]
    words_2 = ["b","2"]
    words_3 = ["c","3"]
    expected = [words_1,words_2,words_3]
    actual = lookup_module_0.run(terms_2)
    assert expected == actual

# Generated at 2022-06-25 11:29:17.737788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)
    if (len(var_0) == 0):
        raise ValueError("lookup_module_0.run did not return valid data")


# Generated at 2022-06-25 11:29:19.219934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)


# Generated at 2022-06-25 11:29:24.256720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module = LookupModule()
    lookup_module.run(tuple_0)


# Generated at 2022-06-25 11:29:26.519341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = [None]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)


# Generated at 2022-06-25 11:29:28.313591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])


# Generated at 2022-06-25 11:29:29.740531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = None
    var_0 = lookup_run(tuple_0)


test()

# Generated at 2022-06-25 11:29:32.597331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (
        [
            [
                'a', 'b', 'c', 'd'
            ], [
                1, 2, 3, 4
            ]
        ],
        None
    )
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = MockTemplar(loader=MockLoader())
    var_0 = lookup_module_0.run(terms=tuple_0[0][0], variables=tuple_0[1])
    assert var_0 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:29:35.480325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = None
    var_0 = lookup_run(tuple_0)
    assert var_0 == None


# Ansible playbook run function

# Generated at 2022-06-25 11:29:36.261038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:29:38.953019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert lookup_module.run(terms, variables) == result

# Generated at 2022-06-25 11:29:51.107495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # set up class
    #
    lookup_module_0 = LookupModule()
    #
    # set up parameters & mocks
    #
    terms = "terms"
    variables = "variables"
    kwargs = {}
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_variables = MagicMock()
    lookup_module_0._lookup_variables.return_value = "var_0"
    #
    # perform the test
    #
    ret_val_0 = lookup_module_0.run(terms, variables, **kwargs)
    #
    # perform assertions
    #
    assert ret_val_0 == "var_0", "AnsibleError not raised for x in terms: # with_together requires at least one element in each list"

# Generated at 2022-06-25 11:29:54.528411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['a', 'b', 'c', 'd']
    my_list = ['a', 'b', 'c', 'd']
    var_0 = lookup_module_0.run(terms,my_list,True)
    assert var_0 == [['a', 'b', 'c', 'd']]


# Generated at 2022-06-25 11:29:57.654343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    var_0 = lookup_module_0.run(tuple_0, tuple_1, tuple_2)


# Generated at 2022-06-25 11:30:01.366637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ("tuple_0", "tuple_1", "tuple_2")
    tuple_1 = ("tuple_0", )
    tuple_2 = ("tuple_0", "tuple_1")
    str_0 = lookup_module_0.run(tuple_0)
    str_1 = lookup_module_0.run(tuple_1)
    str_2 = lookup_module_0.run(tuple_2)

# Generated at 2022-06-25 11:30:07.736620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = [
        ['a', 'b', 'c'],
        [1, 2, 3]
    ]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0, [])
    assert var_0 == [['a', 1], ['b', 2], ['c', 3]], "Error in run"

# Generated at 2022-06-25 11:30:18.077971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  tuple_0 = None
  tuple_1 = [None]
  tuple_2 = (None,)
  tuple_3 = {None}
  tuple_4 = dict({None})
  tuple_5 = 'None'
  tuple_6 = 1
  tuple_7 = 1.0
  tuple_8 = [1, 1, 2, 3, 5, 8, 13]
  tuple_9 = {0: 13, 1: 8, 2: 5, 3: 3, 4: 2, 5: 1, 6: 1}
  tuple_10 = (1, 1, 2, 3, 5, 8, 13)
  tuple_11 = [0, 1, 3, 6, 10, 15]
  tuple_12 = (0, 1, 3, 6, 10, 15)
  tuple_

# Generated at 2022-06-25 11:30:24.831495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_0 = [ [ 'val_0', 'val_1', 'val_2', 'val_3' ], [ 'val_4', 'val_5', 'val_6', 'val_7' ] ]
    try:
        ansible_0 = lookup_module_1.run( tuple_0, dict() )
    except AnsibleError as e:
        assert False


# Generated at 2022-06-25 11:30:27.643806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:30:32.895078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_case_0()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 11:30:33.307532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 11:30:39.257807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_1 = None
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(tuple_1)


# Generated at 2022-06-25 11:30:40.257325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:30:45.467126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule with the dummy function
    lookup_obj = LookupModule({}, None, None, '')
    # Create a dummy tuple
    tuple_0 = (1, 2, 3)
    # Create a dummy value for optional argument 'variables'
    var_0 = None
    # Invoke method 'run' of object 'lookup_obj' passing the dummy tuple, 'tuple_0'
    # and the dummy value for optional argument 'variables'
    tuple_1 = lookup_obj.run(tuple_0, var_0)
    assert tuple_0 == tuple_1


# Generated at 2022-06-25 11:30:47.398475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()

# Generated at 2022-06-25 11:30:49.143608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:30:55.831139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_1 = ['a', 'b']
    tuple_2 = [1, 2]
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(tuple_1, tuple_2)



# Generated at 2022-06-25 11:30:57.678213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:31:04.099913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.together import LookupModule
    import ansible.plugins.lookup.together
    # Test case 0:
    tuple_0 = [
        [
            '"Call TransposePlugin"',
            '"Call TransposePlugin"'
        ]
    ]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)


# Generated at 2022-06-25 11:31:10.502104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import zip_longest
    # Invocation
    lookup_module_0 = LookupModule()
    tuple_0 = ['a', 'b', 'c', 'd'], [1, 2, 3, 4]
    test = lookup_module_0.run(tuple_0)
    assert test == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]

    tuple_1 = ['a', 'b', 'c', 'd'], [1, 2, 3, 4], [1, 2, 3, 4]
    test = lookup_module_0.run(tuple_1)
    assert test == [['a', 1, 1], ['b', 2, 2], ['c', 3, 3], ['d', 4, 4]]

    tuple_2

# Generated at 2022-06-25 11:31:12.528381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0, variables=None)


# Generated at 2022-06-25 11:31:23.719849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)

# Generated at 2022-06-25 11:31:31.789132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ("\x1e", "", "", lookup_module_0)
    lookup_module_0.run(tuple_0)
    lookup_module_0 = LookupModule()
    tuple_0 = ("", ";", "", lookup_module_0)
    lookup_module_0.run(tuple_0)
    lookup_module_0 = LookupModule()
    tuple_0 = ('e', 'x', 's', lookup_module_0)
    lookup_module_0.run(tuple_0)
    lookup_module_0 = LookupModule()
    tuple_0 = ('n', 'g', 's', lookup_module_0)
    lookup_module_0.run(tuple_0)



# Generated at 2022-06-25 11:31:36.004098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)

# Generated at 2022-06-25 11:31:42.675380
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    assert ((lookup_module_0.run(['[1, 2, 3]', '[4, 5, 6]'], [None, None, None])) == ['[1, 4]', '[2, 5]', '[3, 6]'])
    assert ((lookup_module_0.run(['[1, 2]', '[3]'], [None, None, None])) == ['[1, 3]', '[2, None]'])


# Generated at 2022-06-25 11:31:44.253494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assume AnsibleError is raised
    return None



# Generated at 2022-06-25 11:31:51.428336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ['']
    tuple_1 = ['a', 'b', 'c', 'd']
    tuple_2 = (1, 2, 3, 4)
    data_0 = [tuple_0, tuple_1, tuple_2]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(data_0)
    assert var_0 == None

if __name__ == "__main__":
    #test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:31:54.325606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = list([None])

# Generated at 2022-06-25 11:32:02.162174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4]
    variables = None

    lookup_module_0 = LookupModule()
    p_terms = lookup_module_0._lookup_variables(terms)
    p_variables = None

    my_list_0 = p_terms[:]
    if len(my_list_0) == 0:
        raise AnsibleError("with_together requires at least one element in each list")

    return [lookup_module_0._flatten(x) for x in zip_longest(*my_list_0, fillvalue=None)]


# Generated at 2022-06-25 11:32:10.657530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        terms_0 = None
        variables_0 = None
        kwargs_0 = {}
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except Exception as e:
        raise AssertionError("expected None, got {0}".format(repr(e)))

if __name__ == "__main__":
    import sys
    from ansible.utils.display import Display
    if sys.stdout.isatty():
        display = Display(color=True, colorize=True)
    else:
        display = Display(color=False, colorize=False)
    display.display("")

# Generated at 2022-06-25 11:32:16.484383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    var_2 = None
    lookup_module_1 = LookupModule()
    var_3 = lookup_module_1.run(var_1, var_2)
    assert var_3 == None

# Generated at 2022-06-25 11:32:48.223745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ansible_module_0 = AnsibleModule(
        argument_spec={'_terms': dict(type='list', elements='str'), 'state': dict(choices=['absent', 'present'], default='present')})

    tests_0 = [
        (['a'], (['a'],), {}),
    ]
    for test_0 in tests_0:
        try:
            assert lookup_module_0.run(test_0[0], **test_0[2]) == test_0[1]
        except AssertionError:
            ansible_module_0.fail_json(msg='Assertion error')
            ansible_module_0.exit_json(changed=False)

# Generated at 2022-06-25 11:32:55.126233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  my_list = [None, [0], None, [3, 4], None]
  tuple_0 = my_list
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_run(tuple_0)
  assert [None, None, None, [3, 4], [0]] == var_0

# Generated at 2022-06-25 11:33:06.414086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Source:
    # https://github.com/ansible/ansible/blob/devel/hacking/test-module.py
    test_item_0 = [1, 2, 3]
    test_item_1 = [4, 5, 6]
    test_item_2 = [1, 2]
    test_item_3 = [3]
    test_item_4 = []
    test_item_5 = [4, 5, 6]
    test_item_6 = [None, None]
    test_item_7 = [None]
    lookup_module_0 = LookupModule()
    le_0 = lookup_module_0.run(test_item_0)
    le_1 = lookup_module_0.run(test_item_1)

# Generated at 2022-06-25 11:33:12.210505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ['a', 'b', 'c']
    tuple_1 = ['1', '2', '3']
    var_0 = lookup_module_0.run(tuple_0, tuple_1)



# Generated at 2022-06-25 11:33:15.403251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = [('a', 1), ('b', 2)]
    tuple_1 = ([], [])
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_1)
    try:
        assert var_0 == tuple_0
    except AssertionError:
        raise AssertionError(var_0)



# Generated at 2022-06-25 11:33:18.944479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:33:29.009839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = None
    var_0 = lookup_run(tuple_0)
    var_1 = list(var_0)
    var_2 = list(var_0)
    var_3 = list(var_0)
    var_4 = list(var_0)
    var_5 = list(var_0)
    var_6 = list(var_0)
    var_7 = list(var_0)
    var_8 = list(var_0)
    lookup_module_1 = LookupModule()
    tuple_1 = None
    var_9 = lookup_run(tuple_1)
    var_10 = list(var_9)
    var_11 = list(var_9)
    var_12 = list(var_9)

# Generated at 2022-06-25 11:33:30.887821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run()


# Generated at 2022-06-25 11:33:36.202538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:33:37.893101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (None,)
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)


# Generated at 2022-06-25 11:34:27.223407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_4 = listify_lookup_plugin_terms(var_4, templar=self._templar, loader=self._loader)
    var_0 = lookup_module_0.run(var_4)
    assert var_0 == False


# Generated at 2022-06-25 11:34:28.703856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    lookup_run(tuple_0)


# Generated at 2022-06-25 11:34:30.269191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)


# Generated at 2022-06-25 11:34:35.926311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_1 = 'list', 'set'
    dict_2 = {"Add": 4, "Remove": 2, "Change": "list", "Action": "list"}
    list_2 = [dict_2]
    var_1 = lookup_module_1.run(tuple_1, variables=list_2)
    assert var_1 == [('Action', 'list', 4), ('Change', 'list', 2)]


# Generated at 2022-06-25 11:34:37.560341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = None
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 11:34:40.752069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()
    test_case_2()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:34:46.014623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (0, 1, 2, 3)
    # FIXME:
    # This needs to be re-enabled, but it fails when run as a unit test.
    # I'm not sure why it works in the actual scenarios
    try:
        #var_0 = lookup_module_0.run(tuple_0)
        assert False
    except Exception as inst:
        var_0 = inst

    # FIXME:
    # Need to assert on var_0 contents


# Generated at 2022-06-25 11:34:48.679370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = [["test", "test"], ["test", "test", "test"]]
    assert lookup_module_0.run(tuple_0) == [['test', 'test'], ['test', 'test', 'test']]



# Generated at 2022-06-25 11:34:54.885097
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:34:56.956309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == 0


# Generated at 2022-06-25 11:36:27.258229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ("a", "b", "c")  # Dangerous for mutability
    tuple_1 = [1,2,3]
    tuple_2 = [10,20,30]
    var_0 = lookup_module_0.run(tuple_0, None)
    assert isinstance(var_0, list)
    assert var_0 == [('a',1,10), ('b',2,20), ('c',3,30)]
    tuple_3 = [1]
    tuple_4 = [10]
    var_1 = lookup_module_0.run(tuple_3, None)
    assert isinstance(var_1, list)
    assert var_1 == [(1,10)]

# Generated at 2022-06-25 11:36:30.541533
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:36:32.007207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_1 = None
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms=tuple_1)


# Generated at 2022-06-25 11:36:33.367392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)

# Generated at 2022-06-25 11:36:34.976716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # 0
    tuple_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 11:36:41.508164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = '[[\'a\', \'b\'], [1, 2, 3]]'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(tuple_0)

    # Verify var_0 equals expected_var_0
    expected_var_0 = [('a', 1), ('b', 2), (None, 3)]
    assert( var_0 == expected_var_0 )





# Generated at 2022-06-25 11:36:45.939820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run() == None

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:36:47.333674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = lookup_module_0.run()


# Generated at 2022-06-25 11:36:51.382652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ilist = [['a', 'b', 'c', 'd'], ['1', '2', '3', '4']]
    obj = LookupModule()
    result = obj.run(ilist)
    for item in result:
        assert len(item) == 2


# Generated at 2022-06-25 11:36:56.455869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (None,)
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(tuple_0)
