

# Generated at 2022-06-25 11:27:26.360642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {'_templar': None, '_loader': None}
    lookup_module_1 = LookupModule(**dict_1)
    dict_2 = {'_templar': None, '_loader': None}
    lookup_module_2 = LookupModule(**dict_2)
    dict_3 = {'_templar': None, '_loader': None}
    lookup_module_3 = LookupModule(**dict_3)
    dict_4 = {'_templar': None, '_loader': None}
    lookup_module_4 = LookupModule(**dict_4)

    # test case 1

# Generated at 2022-06-25 11:27:31.211214
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:27:41.371905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'run.return_value': [[('a', 1), ('b', 2), ('c', 3), ('d', 4)],
                         [['a', 1], ['b', 2], ['c', 3], ['d', 4]]]
    }
    lookup_module_0 = LookupModule(**dict_0)

    with pytest.raises(AnsibleError) as result:
        lookup_module_0.run([], None)
    assert result.type is AnsibleError

    #assert result == [('a', 1), ('b', 2), ('c', 3), ('d', 4)], "Returned values don't match expected values"


# Generated at 2022-06-25 11:27:50.861720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(loader=None, templar=None)
    params_1 = [[['a', 'b', 'c', 'd'], [1, 2, 3, 4]]]
    ans_1 = [[('a', 1), ('b', 2), ('c', 3), ('d', 4)]]

    params_2 = [[['a', 'b', 'c', 'd'], [1, 2, 3]]]
    ans_2 = [[('a', 1), ('b', 2), ('c', 3), ('d', None)]]

    params_3 = [[['a', 'b', 'c', 'd'], ['1', '2', '3']]]
    ans_3 = [[('a', '1'), ('b', '2'), ('c', '3'), ('d', None)]]

   

# Generated at 2022-06-25 11:27:55.246568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = []
    terms_0.append("l")
    terms_0.append("t")
    terms_0.append("u")
    terms_0.append("e")
    terms_0.append("r")
    terms_0.append("s")
    variables_0 = {}
    res_0 = lookup_module_0.run(terms_0, variables_0)
    assert res_0 == [["l", "t", "u", "e", "r", "s"], None, None, None, None, None, None, None, None, None, None], res_0


# Generated at 2022-06-25 11:28:03.229171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    arguments_0 = [
        [
            [
                'a',
                'b',
                'c'
            ],
            [
                '1',
                '2',
                '3'
            ]
        ],
        dict_0
    ]
    # Call LookupModule.run
    e = None
    try:
        lookup_module_0.run(*arguments_0)
    except Exception as e:
        pass
    assert e is None


# Generated at 2022-06-25 11:28:14.307619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("test_LookupModule_run")

  terms_0 = []
  variables_0 = None
  kwargs_0 = {}

  lookup_module_0 = LookupModule(**dict_0)
  try:
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)
  except AnsibleError:
    pass

  terms_1 = [
    []
  ]
  variables_1 = None
  kwargs_1 = {}

  lookup_module_1 = LookupModule(**dict_0)
  result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
  assert result_1 == [[]]

  terms_2 = [
    []
  ]
  variables_2 = None
  kwargs_2

# Generated at 2022-06-25 11:28:21.789352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = ['a', 'b', 'c']
    list_1 = ['d', 'e', 'f']
    list_2 = []
    list_3 = []
    assert lookup_module_0.run([list_0, list_1], **dict_0) == list_2
    assert lookup_module_0.run([list_0, list_1], **dict_0) == list_3

# Generated at 2022-06-25 11:28:30.574365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # done, simple case
    my_arrays = [ ['a', 'b', 'c', 'd']
                , ['1', '2', '3', '4']
                ]
    expected = [ ('a', '1')
               , ('b', '2')
               , ('c', '3')
               , ('d', '4')
               ]

    lookup_module_1 = LookupModule()
    results = lookup_module_1.run(my_arrays)
    assert results == expected

    # with 'None' elements
    my_arrays = [ ['a', 'b', 'c', 'd']
                , ['1', '2', '3']
                ]

# Generated at 2022-06-25 11:28:39.782543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'run': LookupBase.run,
    }
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {}
    dict_2 = {}
    dict_3 = {
        '_templar': object(),
        '_loader': object(),
    }
    dict_3['_loader'] = dict_3['_templar']
    dict_2['terms'] = dict_3
    dict_1['variables'] = dict_2
    varargs = ["test_0", dict_1]
    dict_4 = dict(
        zip(["arg_0", "kwarg_0"], varargs)
    )
    dict_4.update(kwargs)
    lookup_module_0.run(**dict_4)

# Generated at 2022-06-25 11:28:48.923731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_data_0 = [('abc', 'def'), ('ghi', 'a'), ('klm',)]
    arg_data_1 = None

    result_0 = lookup_module_0.run(arg_data_0, arg_data_1)
    assert result_0 == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm'], result_0



# Generated at 2022-06-25 11:28:59.123913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inputs = [
        {
            'terms' : [
                ["I'm", 'a', 'single', 'item'],
                [1, 2, 3]
            ]
        },
        {
            'terms' : [
                ['A', 'list'],
                ['of', 'lists']
            ]
        },
        {
            'terms' : [
                ["I'm", 'a', 'single', 'item'],
                ["I'm", 'another', 'single', 'item']
            ]
        }
    ]

# Generated at 2022-06-25 11:29:06.419933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    terms = [ [ 'abc',  ],  [ 'def',  ],  ]
    lookup_module_0.run(terms=terms, variables=None)

# Generated at 2022-06-25 11:29:13.875958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'a',
            'b',
            'c',
            'd'
        ],
        [
            1,
            2,
            3,
            4
        ]
    ]
    ret = lookup_module_0.run(terms=terms_0)

    assert ret == [
        ['a', 1],
        ['b', 2],
        ['c', 3],
        ['d', 4]
    ]


# Generated at 2022-06-25 11:29:15.430452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["test"], ["test"]) == [["test"]]


# Generated at 2022-06-25 11:29:18.124945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # This test verifies that the lookup module works correctly for an empty list.
  my_test_case = []
  try:
    lookup_module_0.run(terms=my_test_case, variables=None, **kwargs)
  except AnsibleError:
    return True
  return False


# Generated at 2022-06-25 11:29:20.647535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    lookup_module = LookupModule()
    assert lookup_module.run(terms) == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]

# Generated at 2022-06-25 11:29:29.812326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_vars = {
        'a': [1, 2, 3],
        'b': [4, 5, 6]
    }

    def exec_LookupModule_run(run_args):
        lookup_module = LookupModule()
        x = lookup_module.run(run_args, variables=test_vars)
        return x

    # test common case
    x = exec_LookupModule_run([ ['a'], ['b'] ])
    assert x == [[1, 4], [2, 5], [3, 6]]

    # test unbalanced case
    x = exec_LookupModule_run([ ['a', 'b'], ['c'] ])
    assert x == [[1, 'c'], [2, None], [3, None]]

# Generated at 2022-06-25 11:29:33.307348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run([], None)
    assert var_1 != None



# Generated at 2022-06-25 11:29:37.512725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['a', 'b'], [1, 2]]
    arguments = {'variables': 'variables_0', 'kwargs': {}, 'terms': terms_0}
    #assert call(["with_together([['a', 'b'], [1, 2]])"]) == lookup_module_0.run(**arguments)


# Generated at 2022-06-25 11:29:46.446656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t1 = ['a', 'b', 'c', 'd']
    t2 = [1, 2, 3, 4]
    terms = [t1, t2]
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, None)
    assert_obj1 = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert result == assert_obj1


# Generated at 2022-06-25 11:29:50.874803
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    assert lookup_module_0.run() == None, "test_run_0: method run returned None"
    return


# Generated at 2022-06-25 11:29:58.185180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [ [1,], [4,], ]
    my_list_1 = [ [1, 1, 0], [1, 1, 0], ]
    results_0 = lookup_module_0.run(my_list_0, my_list_1)
    assert results_0 == [ [1, 1, 0], [4, 1, 0], ]

# Generated at 2022-06-25 11:30:02.984911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['a', 'b', 'c', 'd']
    term_1 = [1, 2, 3, 4]
    result = lookup_module_0.run([term_0, term_1], {})
    assert result == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:30:11.202755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.module_utils.six.moves import zip_longest
  lookup_module_0 = LookupModule()
  terms_0 = ('a', 'b', 'c', 'd')
  terms_1 = (1, 2, 3, 4)
  my_list_0 = (terms_0, terms_1)
  if len(my_list_0) == 0:
    raise AnsibleError("with_together requires at least one element in each list")
  lookup_module_0.run(terms=my_list_0)


from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-25 11:30:15.487881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    result = lookup_module_2.run(['a', 'b', 'c', 'd'], [1, 2, 3, 4])
    assert result == [('a',1), ('b', 2), ('c', 3), ('d', 4)]



# Generated at 2022-06-25 11:30:25.376178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(my_list=[], variables=None)
    assert result == []
    assert result == lookup_module_0.run(my_list=[], variables=None)
    assert result == lookup_module_0.run(my_list=[], variables=None)
    assert result == lookup_module_0.run(my_list=[], variables=None)
    assert result == lookup_module_0.run(my_list=[], variables=None)
    assert result == lookup_module_0.run(my_list=[], variables=None)

# Generated at 2022-06-25 11:30:34.692539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['a', 'b', 'c']
    list_1 = [1, 2, 3]
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], []) == []
    lookup_module_0 = LookupModule()
    lookup_module_0.run([list_0, list_1], [])
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([list_0, list_1], []) == [['a', 1], ['b', 2], ['c', 3]]


# Generated at 2022-06-25 11:30:37.993109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['a', 'b'], [1, 2]]) == [('a', 1), ('b', 2)]

# Generated at 2022-06-25 11:30:41.466692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([['a', 'b'], ['1', '2']]) == [('a', '1'), ('b', '2')])
    assert (lookup_module_0.run([]) == AnsibleError("with_together requires at least one element in each list"))
    assert (lookup_module_0.run([['a', 'b'], ['1']]) == [('a', '1'), ('b', None)])
    assert (lookup_module_0.run([['a'], ['1', '2']]) == [('a', '1'), (None, '2')])

# Generated at 2022-06-25 11:30:53.767263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[1, 2], [3, 4]])


# Generated at 2022-06-25 11:30:55.399669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert lookup_module.run([[1, 2, 3], [4, 5, 6]]) == [[1,4], [2,5], [3,6]]


# Generated at 2022-06-25 11:30:58.996829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = test_case_0()
    my_list = [1,2,3]
    my_list_0 = [4,5,6]
    result = lookup_module_0.run([my_list, my_list_0])
    assert result == [[1,4],[2,5],[3,6]]

"""
The following test cases are from the original zip module from ansible-modules-core
1. run with no params
2. run with one param
3. run with multiple params
4. run with lists with different lengths
"""


# Generated at 2022-06-25 11:31:00.113938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    assert lookup_module_0.run(my_list) == []


# Generated at 2022-06-25 11:31:07.486757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Input data
    an_str_0 = 'a'
    an_str_1 = 'b'
    an_str_2 = 'c'
    an_str_2 = 'd'

    # Unit test for method run of class LookupModule

    result = lookup_module_0.run(terms, variables=None)



# Generated at 2022-06-25 11:31:10.069500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(  None, None, None) # Example usage

# Generated at 2022-06-25 11:31:16.084873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [
            'a',
            'b',
            'c'
        ],
        [
            '1',
            '2',
            '3'
        ]
    ]
    try:
        lookup_module.run(terms)
    except AnsibleError as e:
        assert e.message == 'with_together requires at least one element in each list'
    else:
        raise AssertionError('AnsibleError was not raised')

# Generated at 2022-06-25 11:31:20.213268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [[3, 2, 1], [6, 5, 4]]
    new_list = lookup_module_0.run(my_list)
    assert(new_list == [[3, 6], [2, 5], [1, 4]])


# Generated at 2022-06-25 11:31:23.945796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    look_list = [
                    [ 'a', 'b'],
                    [ 1, 2]
                ]
    output = lookup_module.run(look_list, None, None)
    assert output == [ ('a', 1), ('b', 2)]

# Generated at 2022-06-25 11:31:31.961600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    passes = 0
    fails = 0
    lookup_module_0 = LookupModule()
# Test case 1 of LookupModule.run (Expected Result: [('a', 1), ('b', 2), ('c', 3), ('d', 4)])
    if lookup_module_0.run(terms=[[u'a', u'b', u'c', u'd'], [u'1', u'2', u'3', u'4']], variables=None, **kwargs) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]:
        passes += 1
    else:
        fails += 1
# Test case 2 of LookupModule.run (Expected Result: [('a', 1), ('b', 2), ('c', None), ('d', None)])

# Generated at 2022-06-25 11:31:44.346654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict()
    my_obj = LookupModule()
    result = my_obj.run(module_args, 'some_arg')
    assert type(result) == type([])


# Generated at 2022-06-25 11:31:53.347175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_1 = [
        [
            "a",
            "b",
            "c",
            "d"
        ],
        [
            1,
            2,
            3,
            4
        ]
    ]
    lookup_module_2 = []
    lookup_module_3 = [
        [
            "a",
            "b"
        ],
        [
            1,
            2
        ],
        [
            "c",
            "d"
        ]
    ]
    lookup_module_4 = [
        [
            "a",
            "b",
            "c",
            "d"
        ]
    ]

# Generated at 2022-06-25 11:31:55.754932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    assert lookup_module_instance.run(["a", "b", "c"], ["1", "2", "3"]) == [('a', '1'), ('b', '2'), ('c', '3')]

# Generated at 2022-06-25 11:32:00.056972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    # Invoke run() method of LookupModule instance lookup_module_0
    lookup_module_0.run(my_list_0)

# Generated at 2022-06-25 11:32:04.527195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_result = lookup_module_0.run()
    # Assign your desired results to these values below
    assert test_result == ""


# Generated at 2022-06-25 11:32:09.322817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([""], {}, {}, "", "", "") # :
    lookup_module_0.run([""], {}, {}, "", "", "") # :


# Generated at 2022-06-25 11:32:11.057735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run('', ''), list)


# Generated at 2022-06-25 11:32:20.398671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    lookup_module_0 = LookupModule()
    terms_1 = []
    terms_1_elem = []
    terms_1.append(terms_1_elem)
    try:
        lookup_module_0.run(terms_1)
    except AnsibleError:
        pass
    else:
        raise Exception('AnsibleError not raised')
    # Test 2
    lookup_module_0 = LookupModule()
    terms_1 = []
    terms_1_elem = ['a', 'b']
    terms_1.append(terms_1_elem)
    terms_1_elem = ['c', 'd']
    terms_1.append(terms_1_elem)

# Generated at 2022-06-25 11:32:21.804332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = ['d']
    assert lookup_module_0.run(my_list) == ['d']

# Generated at 2022-06-25 11:32:27.093584
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[1, 2], [3]]) == [[1, 3], [2, None]]
    assert lookup_module_0.run([[1, 2, 3]]) == [[1], [2], [3]]

# Generated at 2022-06-25 11:32:49.452989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["[('a', 1), ('b', 2)]"]) == "[('a', 1), ('b', 2)]"

# Generated at 2022-06-25 11:32:55.580259
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    args_0 = [
        [
            'a,b,c,d',
            '1,2,3,4'
        ]
    ]

    # Output of the run method
    result_0 = lookup_module_0.run(args_0)

    # Test to see if expected and actual are equal
    assert [('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')] == result_0, 'Testing result of method run of class LookupModule'


# Generated at 2022-06-25 11:32:59.840713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [
        [{'a': 1}],
        [{'b': 2}]
    ]
    assert [{'a': 1}, {'b': 2}] == lookup_module_0.run(my_list)

# Generated at 2022-06-25 11:33:09.459855
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # TEST-CASE-0:
    test_terms_0 = [
        [1, 2, 3, 4],
        ['b', 'a', 'd', 'c'],
        ['a', 'b', 'c', 'd']
    ]
    expected_result_0 = [
        [1, 'b', 'a'],
        [2, 'a', 'b'],
        [3, 'd', 'c'],
        [4, 'c', 'd']
    ]

    # TEST-CASE-1:
    test_terms_1 = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4]
    ]

# Generated at 2022-06-25 11:33:12.760467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [[1, 2, 3, 4], [1]]
    result = lookup_module_0.run(my_list)
    assert result == [[1, 1], [2, None], [3, None], [4, None]]


# Generated at 2022-06-25 11:33:14.482524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = lookup_module_0.run(my_list, variables=None, **kwargs)
    assert zip_longest(*my_list, fillvalue=None) == my_list

# Generated at 2022-06-25 11:33:22.143028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
      [
        "a",
        "b",
        "c",
        "d"
      ],
      [
        1,
        2,
        3,
        4
      ]
    ]
    ret = lookup_module_0.run(terms, variables=None)

    assert ret is not None
    assert ret == [('a',1), ('b',2), ('c',3), ('d',4)]



# Generated at 2022-06-25 11:33:25.256180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms) == [], 'Test Failed in test_LookupModule_run'


# Generated at 2022-06-25 11:33:27.064710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 11:33:32.173393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run([['a', 'b', 'c', 'd'], [1, 2, 3, 4]])
    assert results == ['a', 'b', 'c', 'd', 1, 2, 3, 4]
    assert results != ['a', 'b', 1, 'c', 'd', 2, 3, 4]


# Generated at 2022-06-25 11:33:50.906443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:33:52.445091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:33:54.862734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [['a', 1], ['b', 2], ['c', 3], ['d', 4]]


# Generated at 2022-06-25 11:33:58.357226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[1,2,3], [3,2,1]]
    var_0 = lookup_module_0.run(terms_0)
    print(var_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:33:59.878364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    meth_0 = getattr(lookup_module_0, "run")
    assert callable(meth_0)


# Generated at 2022-06-25 11:34:05.720676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True
    list_0 = ['a', 'b']
    list_1 = [1, 2, 3]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, list_1)
    assert var_0 == [('a', 1), ('b', 2)]

# Generated at 2022-06-25 11:34:07.212299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    assert lookup_module_1.run(list_1) == []
    assert lookup_module_1.run(list_1) == []

# Generated at 2022-06-25 11:34:08.324907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = []
    var = lookup_run(list)
    assert var == None


# Generated at 2022-06-25 11:34:16.551519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['', ['', ''], ['', '']]
    list_1 = ['', ['', ''], ['', '']]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)

    # Should raise an exception for the following inputs
    # var_1:
    list_2 = []
    # var_2:
    list_3 = ['', '']


# Generated at 2022-06-25 11:34:18.663971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    var_1 = lookup_module_1.run(list_1)
    assert var_1 == []



# Generated at 2022-06-25 11:35:03.049421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [1, 2, 3]
    obj = LookupModule()
    obj.run(list_0)

# Generated at 2022-06-25 11:35:07.442196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Compute the field values for each object.
    #
    # @param terms  The term list.
    # @param variables  Unused.
    # @return A list of lists.
    for obj in [LookupModule()]:
        # Test with any value for args, kwargs.
        args = set()
        kwargs = {}

# Generated at 2022-06-25 11:35:12.068175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run_0 = LookupModule()
    list_2 = [['a', 'b'], [1, 2]]
    var_1 = lookup_run_0.run(list_2, variables=None)
    assert var_1 == [['a', 1], ['b', 2]] and var_1 is not None


# Generated at 2022-06-25 11:35:15.206763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 11:35:19.135277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_1 = LookupModule()

    # Create a list and assign it to var_1
    var_1 = list_0

    # Call method run with parameters: var_1
    try:
        var_2 = lookup_module_1.run(var_1)
    except AnsibleError as e:
        print(str(e))
        assert isinstance(e, AnsibleError)
        return
    raise AssertionError()



# Generated at 2022-06-25 11:35:24.868158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_module_0._lookup_variables(list_0)
    assert var_0[0] == [list_0, list_0]



# Generated at 2022-06-25 11:35:25.813392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_run(list_0)



# Generated at 2022-06-25 11:35:30.415935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    var_1 = lookup_module_1.run(list_1)
    assert var_1 == [], "From: %s Expected: %s Received: %s" % (repr(list_1), repr([]), repr(var_1))

    lookup_module_2 = LookupModule()
    list_2 = [u'a', 1]
    var_2 = lookup_module_2.run(list_2)
    assert var_2 == [[u'a', 1]], "From: %s Expected: %s Received: %s" % (repr(list_2), repr([[u'a', 1]]), repr(var_2))

    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:35:35.389569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_module_0.run(list_0)


# Test case for method run of class LookupModule

# Generated at 2022-06-25 11:35:44.708987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (('a', 1) == LookupModule.run(['a', 'b', 'c', 'd'], [1, 2, 3, 4]))
    assert (('b', 2) == LookupModule.run(['a', 'b', 'c', 'd'], [1, 2, 3, 4]))
    assert (('c', 3) == LookupModule.run(['a', 'b', 'c', 'd'], [1, 2, 3, 4]))
    assert (('d', 4) == LookupModule.run(['a', 'b', 'c', 'd'], [1, 2, 3, 4]))
    assert (('a', 3) == LookupModule.run(['a', 'b', 'c', 'd'], [3]))

# Generated at 2022-06-25 11:37:17.531178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test exception(AnsibleError)
    try:
        var_0 = lookup_module_0.run([])
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert type(e) == AnsibleError
        assert str(e) == 'with_together requires at least one element in each list'
