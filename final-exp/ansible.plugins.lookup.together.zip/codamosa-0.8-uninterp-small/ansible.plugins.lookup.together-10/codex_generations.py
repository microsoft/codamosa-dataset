

# Generated at 2022-06-25 11:27:20.353842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['a', 'b', 'c', 'd']
    terms_1 = [1, 2, 3, 4]
    terms = [terms_0, terms_1]
    variables = {}
    res = lookup_module_0.run(terms, variables)
    res_exp = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert all(map(lambda v1, v2: v1 == v2, res, res_exp))


# Generated at 2022-06-25 11:27:25.802494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_terms = []
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(my_terms), list)
    my_terms = ['a', 'b', 'c', 'd']
    assert isinstance(lookup_module_0.run(my_terms), list)
    my_terms = [1, 2, 3, 4]
    assert isinstance(lookup_module_0.run(my_terms), list)


# Generated at 2022-06-25 11:27:32.731534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_variables(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26])


# Generated at 2022-06-25 11:27:38.782942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: the test can be performed with any string/string in input_arg,
    # any string in terms and any number in expected_num
    lookup_module_0 = LookupModule()
    input_arg = [["test1"], ["test1"]]
    terms = [["test1"], ["test1"]]
    expected_num = 1
    assert(len(lookup_module_0.run(terms=terms, variables=input_arg))==expected_num)

# Generated at 2022-06-25 11:27:48.206599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test1 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    test2 = [['a', 'b'], [1, 2, 3]]
    test3 = [['a', 'b', 'c', 'd'], [1, 2, 3]]
    test4 = [['a', 'b', 'c', 'd'], [1, 2]]
    test5 = [['a', 'b', 'c', 'd'], [1]]
    test6 = [['a', 'b'], [1]]
    test7 = [['a'], [1, 2]]
    test8 = [['a'], [1]]
    test9 = []

# Generated at 2022-06-25 11:27:54.152760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [1, 2]
    assert lookup_module_0.run(my_list) == [1, 2]

# Generated at 2022-06-25 11:28:04.713673
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # from ansible/module_utils/basic.py
  class AnsibleModule:
    def __init__(self, argument_spec, **kwargs):
      self.params = dict()
      self.params['_raw_params'] = kwargs
      self.argument_spec = dict()
      self.argument_spec = argument_spec

    def fail_json(self, **kwargs):
      pass

  class AnsibleLookupModule:
    def __init__(self, argument_spec, **kwargs):
      self.params = dict()
      self.params['_raw_params'] = kwargs
      self.argument_spec = dict()
      self.argument_spec = argument_spec

    def fail_json(self, **kwargs):
      pass


# Generated at 2022-06-25 11:28:07.464149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [['a', 'b', 'c'], ['1', '2', '3']]
    variables = None
    kwargs = {}
    assert lookup_module_1.run(terms, variables, **kwargs) == [['a', '1'], ['b', '2'], ['c', '3']]

# Generated at 2022-06-25 11:28:15.858163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        'str0',
        'str1',
        'str2',
        'str3',
    ]
    kwargs = {}
    retval = [('str0', 'str1'), ('str2', 'str3')]
    lookup_module_0 = LookupModule()
    retval_1 = lookup_module_0.run(args, **kwargs)
    assert retval == retval_1

    args = [
        'str0',
        'str1',
        'str2',
        'str3',
    ]
    kwargs = {}
    retval = [('str0', 'str1'), ('str2', 'str3')]
    lookup_module_0 = LookupModule()
    retval_1 = lookup_module_0.run(args, **kwargs)

# Generated at 2022-06-25 11:28:18.956014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    lookup_module_0.run(my_list)

# Generated at 2022-06-25 11:28:22.225008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:28:26.422172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 11:28:31.603586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1
    int_1 = 2
    list_0 = ["test"]
    dict_0 = dict()
    dict_0["test"] = list_0
    dict_1 = dict()
    dict_1[1] = int_0
    dict_1[2] = int_1
    list_1 = [1, 2]
    dict_2 = dict()
    dict_2[1] = int_0
    dict_1[2] = int_1
    list_2 = [1, 2]
    dict_3 = dict()
    dict_3["test"] = list_0
    dict_0[1] = int_0
    dict_0[2] = int_1
    list_3 = [1, 2]
    list_

# Generated at 2022-06-25 11:28:39.702471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_2 = False
    lookup_module_1 = LookupModule()
    dict_6 = dict()
    str_6 = 'abc'
    dict_6["def"] = str_6
    str_7 = 'ghi'
    dict_6["jkl"] = str_7
    var_1 = lookup_module_1.run(bool_2, dict_6)
    print(var_1)


# Generated at 2022-06-25 11:28:41.453087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('', '') == ''



# Generated at 2022-06-25 11:28:43.441256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:28:48.776139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    # Execute function 'run'
    lookup_module_0.run(terms, variables)
    # Verify the state of argument 'list'
    assert list == ['a', 'b', 'c']
    # Verify the state of argument 'dict'
    assert dict == {'a': 'b'}


# Generated at 2022-06-25 11:28:50.913332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = lookup_run()
    assert isinstance(lookup, dict)



# Generated at 2022-06-25 11:28:59.200083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case 1
    var_0 = [[1, 2, 3], [4, 5, 6]]
    var_1 = lookup_module_0.run(var_0)
    assert var_1[0][0] == 1
    # test case 2
    var_2 = [[1, 2], [3]]
    var_3 = lookup_module_0.run(var_2)
    assert var_3[1][1] is None

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:29:05.007924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[1, 2, 3], [4, 5, 6]])


# Generated at 2022-06-25 11:29:07.248826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(False)
    return var_0

# Generated at 2022-06-25 11:29:11.559179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)


# Generated at 2022-06-25 11:29:13.448985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.run(bool_0, None)


# Generated at 2022-06-25 11:29:22.131670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_0 = 'Z0XJ5'
    string_1 = '7'
    string_2 = 'vF8A'
    string_3 = 'X9n7'
    string_4 = 'A'
    string_5 = 'e8'
    dict_0 = {
        string_0: string_1,
        string_2: string_3,
        string_4: string_5,
    }
    list_0 = [
        string_0,
        string_2,
        string_4,
    ]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    return var_0 is None


# Generated at 2022-06-25 11:29:32.356607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    # Test with different inputs
    # Test with empty input
    lookup_module_0.run([])

    # Test with single input
    args = ["TEST__1568367404036"]
    expected_result = [["TEST__1568367404036"]]
    assert expected_result == lookup_module_0.run(args)


    # Test with multiple inputs
    args = ["TEST__1568367404036", "TEST__1568367404036"]
    expected_result = [["TEST__1568367404036", "TEST__1568367404036"]]
    assert expected_result == lookup_module_0.run(args)


# Generated at 2022-06-25 11:29:41.705737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    temp0 = {}
    temp0['erpc_init'] = '/lib/modules/3.10.0-327.3.1.el7.x86_64/erpc/erpc_init.ko'
    temp0['erpc_mbuf'] = '/lib/modules/3.10.0-327.3.1.el7.x86_64/erpc/erpc_mbuf.ko'
    temp0['erpc_infiniband_transport'] = '/lib/modules/3.10.0-327.3.1.el7.x86_64/erpc/erpc_infiniband_transport.ko'

# Generated at 2022-06-25 11:29:46.912495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [{'1': [{'2': [1, 2, 3]}]}]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0._lookup_variables(my_list)

    return var_0

# Generated at 2022-06-25 11:29:50.909847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_var_0 = []
    lookup_module_0.run(list_var_0)


# Generated at 2022-06-25 11:30:00.636078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    bool_1 = bool_0
    bool_2 = bool_1
    bool_3 = bool_0
    bool_4 = bool_2
    bool_5 = bool_0
    bool_6 = bool_1
    bool_7 = bool_6
    bool_8 = bool_0
    bool_9 = bool_1
    bool_10 = bool_9
    bool_11 = bool_6
    bool_12 = bool_0
    bool_13 = bool_2
    bool_14 = bool_1
    bool_15 = bool_14
    bool_16 = bool_15
    bool_17 = bool_1
    bool_18 = bool_13
    bool_19 = bool_18
    bool_20 = bool_15


# Generated at 2022-06-25 11:30:04.850578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {'a': [1, 2]}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms)
    assert var_0 == ['a', [1, 2]]


# Generated at 2022-06-25 11:30:08.957705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:30:10.921760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = LookupModule()
    var_1.run(names=None)


# Generated at 2022-06-25 11:30:13.000533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:30:18.892369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = "Test string"
    str_1 = "Test test string string"
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)
    var_1 = lookup_module_0.run(bool_1)
    var_2 = lookup_module_0.run(str_0)
    var_3 = lookup_module_0.run(str_1)
    bool_0 = False
    bool_1 = True
    str_0 = "Test string"
    str_1 = "Test test string string"
    lookup_module_1 = LookupModule()
    var_4 = lookup_module_1.run(bool_0)

# Generated at 2022-06-25 11:30:22.751910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    #assert var_0 == bool_0


# Generated at 2022-06-25 11:30:25.221309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == None, '<None> expected, but returned: ' + repr(lookup_module_0.run())


# Generated at 2022-06-25 11:30:33.140295
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up testcase variables
    # Create a new instance of the lookup module.
    lookup_module_0 = LookupModule()
    # Create a instance of the module and assign it's value to the variable
    # var_0.
    var_0 = lookup_module_0.run(['one', 'two', 'three', 'four'], ['one', 'two'])
    # var_0 should be a list object.
    print(var_0)

# Generated at 2022-06-25 11:30:37.235131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    print(var_0)

# Generated at 2022-06-25 11:30:40.470964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    # The assertEqual will fail because the method run has not been implemented yet.
    assertEqual(var_0, lookup_module_0.run(bool_0))


# Generated at 2022-06-25 11:30:41.936841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()

# Generated at 2022-06-25 11:30:47.502041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(var_0, list)
    assert (var_0 == [('a', 1), ('b', 2), ('c', 3), ('d', 4)])


# Generated at 2022-06-25 11:30:51.078814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    my_list_1 = ['a', 'b', 'c', 'd']
    my_list_2 = [1, 2, 3, 4]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(my_list_1, my_list_2)
    var_1 = lookup_module_0.run([my_list_1, my_list_2], None)
    assert len(var_1) == 4

# Generated at 2022-06-25 11:30:53.341250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    test_case_0()


# Generated at 2022-06-25 11:30:57.758562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class LookupModule
    #
    # Pass in a static list of lists for 'terms'
    #
    # Expects a list of lists as a return value
    lookup_module_0 = LookupModule()
    terms = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4]
    ]
    results = lookup_module_0.run(terms)

    assert results[0] == ['a', 1]
    assert results[1] == ['b', 2]
    assert results[2] == ['c', 3]
    assert results[3] == ['d', 4]


# Generated at 2022-06-25 11:31:02.175839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert any([(('a', 1), ('b', 2), ('c', None)) == lookup_run(False)]), \
        'AnsibleError: with_together requires at least one element in each list'



# Generated at 2022-06-25 11:31:08.115810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = []
    kwargs_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_variables = lambda terms_0, variables_0: lookup_run(terms_0, variables_0)
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:31:10.309304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #print("Test: test_LookupModule_run: test_case_0")
    test_case_0()

# Generated at 2022-06-25 11:31:11.426627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:31:21.347693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()

    # Unit test for run method of class LookupModule
    bool_0 = False
    list_0 = [ None ]
    var_0 = lookup_module_0.run(list_0, bool_0)

    # Assertion of the type and value of var_0
    assert type(var_0) == list
    assert var_0 == [ [None] ]

    # Unit test for run method of class LookupModule
    bool_0 = False
    list_0 = [ True ]
    var_0 = lookup_module_0.run(list_0, bool_0)

    # Assertion of the type and value of var_0
    assert type(var_0) == list
    assert var_0 == [ [True] ]

# Generated at 2022-06-25 11:31:22.643373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test for method run of class LookupModule")

    True #


# Generated at 2022-06-25 11:31:30.206791
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run the following command to test
    # python -m pytest tests/test_lookup_plugins/test_LookupModule.py -v -s
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:31:40.018743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_class_0 = LookupBase()
    lookup_class_1 = LookupBase()
    lookup_class_2 = LookupBase()
    lookup_class_3 = LookupBase()
    lookup_class_4 = LookupBase()
    lookup_class_5 = LookupBase()
    lookup_class_6 = LookupBase()
    lookup_class_7 = LookupBase()
    lookup_class_8 = LookupBase()
    lookup_class_9 = LookupBase()
    lookup_class_10 = LookupBase()
    lookup_class_11 = LookupBase()
    lookup_class_12 = LookupBase()
    lookup_class_13 = LookupBase()
    lookup_class_14 = LookupBase()

# Generated at 2022-06-25 11:31:44.430519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if lookup_module_0.run(['a', 'b']) == [['a', None], ['b', None]]:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-25 11:31:54.008742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    my_str_0 = "_templar"
    val_0 = []
    val_1 = []
    val_2 = []
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_0['a'] = "test_case_1"
    val_0.append(dict_0)
    val_1.append(val_0)
    val_2.append(val_1)
    val_2.append(val_1)
    result = lookup_module_0.run(val_2)

# Generated at 2022-06-25 11:31:58.808623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  bool_0 = False
  lookup_module_0 = LookupModule()
  var_0 = LookupModule.run(bool_0)
  assert var_0 == True

# Generated at 2022-06-25 11:32:05.391123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No options set
    terms = ['a', 'b', 'c', 'd']
    # No options set
    terms = ['1', '2', '3', '4']
    lookup_module = LookupModule(terms, terms)
    assert lookup_module.run(terms, terms) == [(u'a', 1), (u'b', 2), (u'c', 3), (u'd', 4)]


# Generated at 2022-06-25 11:32:09.533059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    list_0 = []
    test_0 = lookup_module_0.run(list_0)
    assert test_0 == True


# Generated at 2022-06-25 11:32:10.302717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:32:12.853478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_module_0 = LookupModule()
    var_0 = my_module_0.run()
    assert my_module_0.run() == var_0

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:32:23.246028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    str_0 = 'test'
    str_1 = 'test'
    list_1 = [str_0]
    list_2 = [str_1]
    list_0 = [str_0]
    list_0 = [str_0]
    list_0 = [str_1]
    list_0 = [str_0]
    list_0 = [str_1]
    list_0 = [list_1]
    list_0 = [list_2]
    list_0 = [list_1]
    list_0 = [list_2]
    list_0 = [list_1, list_2]
    lookup_module_0.run(list_0)



# Generated at 2022-06-25 11:32:37.841512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 11:32:48.259361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    str_0 = 'no_use'
    str_1 = 'no_use'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    class DummyException(Exception):
        def __init__(self):
            self.args = ('test',)
    some_exception_0 = DummyException()
    var_0 = lookup_run(bool_0, str_0, str_1, dict_0, dict_1, dict_2, dict_3, dict_4, dict_5, some_exception_0)
    return var_0


# Generated at 2022-06-25 11:32:57.500083
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = mock.Mock()
    lookup_module_0._loader = mock.Mock()
    lookup_module_0._flatten = mock.Mock()

    lookup_module_0._templar.side_effect = lambda term: term
    lookup_module_0._loader.get_basedir.return_value = 'v1'
    lookup_module_0._flatten.side_effect = lambda term: term

    my_list = [[1, 2, 3], [4, 5, 6]]

    # Expectations
    expected = [lookup_module_0._flatten(x) for x in zip_longest(*my_list, fillvalue=None)]

    # Test

# Generated at 2022-06-25 11:33:03.803457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    if bool_0:
        str_0 = 'unzip'
        str_1 = '-o'
        str_2 = '-d'
        str_3 = './'
        str_4 = 'samples.zip'
        lookup_module_0.run([[str_0, str_1, str_2, str_3, str_4]])


# Generated at 2022-06-25 11:33:07.285883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prerequisites
    bool_0 = True
    lookup_module_0 = LookupModule()

    # Test run
    var_0 = self.run(bool_0)

    # Postrequisites
    assert var_0 is not None


# Generated at 2022-06-25 11:33:16.166805
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("Testing start")
    
    lookup_module_0 = LookupModule()
    my_list = [1,2,3]
    result = lookup_module_0.run(my_list)

    print("Test 1 Result: ",result)


    lookup_module_1 = LookupModule()
    my_list = [[1,2,3],[4,5,6]]
    result = lookup_module_1.run(my_list)

    print("Test 2 Result: ",result)


    lookup_module_2 = LookupModule()
    my_list = [[1,2,3],[4,5,6],[7,8,9]]
    result = lookup_module_2.run(my_list)

    print("Test 3 Result: ",result)

    print("Testing end")



# Main Entry Point


# Generated at 2022-06-25 11:33:18.987321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when args[0] and args[1] are empty strings
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:33:23.570277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var = "a"
    test_var_1 = "bc"
    lookup_module = LookupModule()
    assert(lookup_module.run(test_var_1) == [test_var])


# Generated at 2022-06-25 11:33:25.397213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    assert var_0 == [["a", 1], ["b", 2], ["c", 3], ["d", 4]]

# Generated at 2022-06-25 11:33:30.432610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'http://hostname/api/apiappliance/getAPIApplianceStatus/'
    # Now, set up a template with the required arguments
    my_template = Template(lookup_module_0)

# Generated at 2022-06-25 11:33:53.575901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_2 = False
    var_2 = ['my_list']
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(var_2)


test_case_0()
#test_LookupModule_run()
#print(test_LookupModule_run())

# Generated at 2022-06-25 11:33:59.241238
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run([], {}) == [], 'Failed to run'



# Generated at 2022-06-25 11:34:05.197501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

    # test
    assert False == isinstance(var_0, dict)

    # cleanup


# Generated at 2022-06-25 11:34:06.246913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 11:34:08.748905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(bool_0)
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(bool_0)


# Generated at 2022-06-25 11:34:19.440066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_1 = False
    var_2 = False
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = False
    var_7 = False
    str_0 = ']'
    str_1 = '['
    str_2 = 'name: '
    str_3 = '\n  with_together:\n    - ['"'"'a', 'b', 'c', 'd'"'"']\n    - [1, 2, 3, 4]\n'
    var_8 = False
    var_9 = False
    var_10 = False
    var_11 = False
    str_4 = 'with_together'
    str_5 = 'description: '

# Generated at 2022-06-25 11:34:23.558558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = ['a', 'b', 'c', 'd']
    lookup_Module = LookupModule()
    result = lookup_Module.run(my_list)
    assert result == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]

# Generated at 2022-06-25 11:34:29.741188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a boolean
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    # Test with a string
    str_0 = "banana"
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(str_0)
    # Test with a integer
    int_0 = 10
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(int_0)
    # Test with a float
    float_0 = 10.0
    lookup_module_3 = LookupModule()
    var_3 = lookup_run(float_0)
    # Test with a list
    list_0 = [1,2]
    lookup_module_4 = LookupModule()
    var_4

# Generated at 2022-06-25 11:34:30.764649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(True)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:34:34.585552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  my_list_0 = []
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(my_list_0)
  assert isinstance(var_0, list)
  assert False, "example missing"


# Generated at 2022-06-25 11:34:57.907200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

      # Test 1
      obj_0 = LookupModule()
      result = obj_0.run(None)
      assert result == []



# Generated at 2022-06-25 11:35:01.182543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # these are expected
    terms = [["a", "b", "c", "d"], [1, 2, 3, 4]]
    expected = [[('a', 1), ('b', 2), ('c', 3), ('d', 4)]]

    # these are unexpected
    lookup_module_0 = LookupModule()
    actual = lookup_module_0.run(terms)
    assert expected == actual



# Generated at 2022-06-25 11:35:04.447100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = False
    lookup_module_1 = LookupModule()
    array_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    array_1 = [0, 1, 2, 3, 4]
    array_2 = [0, 1, 2, 3, 4]
    res = lookup_run(bool_1, array_0, array_1, array_2)
    print(res)


# Generated at 2022-06-25 11:35:09.178136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:35:13.830693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b'], [1, 2]]
    fillvalue = None
    # test for case: [ 'a', 'b' ] and [ 1, 2 ] turn into [ ('a',1), ('b', 2) ]
    expected = [('a', 1), ('b', 2)]
    result = LookupModule.run(terms, fillvalue)
    assert expected == result
    # test for case: [ 'a', 'b', 'c' ] and [ 1, 2 ] turn into [ ('a',1), ('b', 2), ('c', None) ]
    terms = [['a', 'b', 'c'], [1, 2]]
    expected = [('a', 1), ('b', 2), ('c', None)]
    result = LookupModule.run(terms, fillvalue)
    assert expected == result
   

# Generated at 2022-06-25 11:35:14.971835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:35:17.625543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get the class object
    lookup_module_0 = LookupModule()

    # run method to get result
    result = lookup_module_0.run('1, 2')

    # assert result
    assert result == [1, 2]
    assert result != None
    assert result != [1, 2, 3]

# Generated at 2022-06-25 11:35:18.895450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0._flatten([None, None, None]) == (None, None, None)

# Generated at 2022-06-25 11:35:20.110454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_run(lookup_module_0)


# Generated at 2022-06-25 11:35:24.186822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:36:17.257286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_2 = False
    lookup_module_1 = LookupModule()
    bool_0 = False
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    dict_1['testing'] = [dict_0]
    bool_1 = True
    dict_2 = dict()
    dict_3 = dict()
    dict_3['testing'] = [dict_2]
    list_0 = [dict_1, dict_3]
    dict_4 = dict()
    dict_5 = dict()
    dict_5['testing'] = [dict_4]
    list_1 = [dict_5]
    list_2 = [list_1, list_0]

# Generated at 2022-06-25 11:36:20.158524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run"))



# Generated at 2022-06-25 11:36:23.559583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.run(bool_0)



# Generated at 2022-06-25 11:36:32.465508
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:36:34.420376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_1 = LookupModule()
        var_1 = lookup_module_1.run(arg_1)
        assert False
    except Exception as exception_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:36:39.729146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_1.run(lookup_module_2)

# Generated at 2022-06-25 11:36:42.342349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = []
    kwargs_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0,variables_0,**kwargs_0)

# Generated at 2022-06-25 11:36:48.444540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

    lookup_run_1 = LookupModule()
    var_0 = lookup_run_1._lookup_variables(['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30'])

# Generated at 2022-06-25 11:36:50.495447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initiate an object of class LookupModule
    terms_0 = [list_0, list_1]
    lookup_module_0 = LookupModule()
    try:
        result_0 = lookup_module_0.run(terms_0)
    except:
        pass

# Generated at 2022-06-25 11:36:56.482184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list_0 = [['a', 'b'], [1, 2]]
    lookup_module_0 = LookupModule()
    result = lookup_run(my_list_0)
    assert result == [('a', 1), ('b', 2)]
