

# Generated at 2022-06-25 11:27:19.903744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_0['_loader'] = dict_0
    dict_0['_templar'] = dict_0
    term_0 = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    lookup_module_0 = LookupModule(**dict_0)
    result = lookup_module_0.run(term_0)
    assert [('a', 1), ('b', 2), ('c', 3), ('d', 4)] == result
 


# Generated at 2022-06-25 11:27:30.834566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params generation
    params = {
        'ANSIBLE_MODULE_ARGS': {
            'terms': [
                [
                    'a',
                    'b'
                ],
                [
                    1,
                    2
                ]
            ]
        }
    }
    lookup_module_0 = LookupModule(**params)
    # Expected Result
    result = [
        [
            'a',
            1
        ],
        [
            'b',
            2
        ]
    ]
    # Actual result
    actual_result = lookup_module_0.run(['a', 'b'], ['1', '2'])
    # Assertion
    assert result == actual_result


# Generated at 2022-06-25 11:27:39.664900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = AnsibleLookupModule(loader=None, templar=None, shared_loader_obj=None)
    my_list_0 = [1, 2, 3, 4, 5]
    my_list_1 = [None, None, None, None, None]
    my_list_2 = [None, None, None, None, None]
    my_list_1[0] = my_list_0
    my_list_2[0] = my_list_1
    lookup_module_0.run(my_list_1)
    lookup_module_0.run(my_list_0)

# Generated at 2022-06-25 11:27:46.387819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule(**{})

    # Test with valid parameters
    params = [
        [
            [
                'a',
                'b',
                'c'
            ],
            [
                1,
                2,
                3
            ]
        ]
    ]
    assert m.run(params) == [
        (
            'a',
            1
        ),
        (
            'b',
            2
        ),
        (
            'c',
            3
        )
    ]

    # Test with valid parameters
    params = [
        [
            'a',
            'b',
            'c'
        ],
        [
            1,
            2,
            3
        ]
    ]

# Generated at 2022-06-25 11:27:50.598667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)

    # Test the body of the run method with default arguments. This is needed to
    # actually exercise the body of the method.
    terms = [
        ['a', 'b', 'c', 'd'],
        [1, 2, 3, 4],
    ]
    print(lookup_module_0.run(terms, variables=None, **{}))


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:28:00.546919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'lookup_args': {'_terms': [['k', 'e'], ['v', 'a']]}, '_terms': [['k', 'e'], ['v', 'a']]}
    lookup_module_0 = LookupModule(**dict_0)

    assert lookup_module_0._lookup_variables(['k', 'e']) == [['k', 'e']]
    assert lookup_module_0._lookup_variables([['k', 'e']]) == [['k', 'e']]
    assert lookup_module_0._lookup_variables([]) == []
    assert lookup_module_0._lookup_variables(['k', 'e']) == [['k', 'e']]

# Generated at 2022-06-25 11:28:05.856403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError, match=r'with_together requires at least one element in each list'):
        lookup_module_0.run(['', '', '', ''])
    with pytest.raises(AnsibleError, match=r'with_together requires at least one element in each list'):
        lookup_module_0.run([])


# Generated at 2022-06-25 11:28:06.809320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run() == None


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 11:28:15.369118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        '_lookup_variables': {
            'return_value': [
                ([
                    'a',
                    'b'
                ], [
                    1,
                    2
                ]),
                ([
                    1,
                    2
                ], [
                    'a',
                    'b'
                ])
            ]
        },
        '_loader': {
            'name': '_loader'
        },
        '_templar': {
            'name': '_templar'
        }
    }
    lookup_module_0 = LookupModule(**dict_0)
    terms = [
        [
            'a',
            'b'
        ],
        [
            1,
            2
        ]
    ]

# Generated at 2022-06-25 11:28:22.401496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    # test with a two dimensional list
    test_case = [
        ['test', 'is', 'good'],
        [1, 2, 3],
        ['four', 'five', 'six']
    ]
    # the result should be a list of tuples
    result = [('test', 1, 'four'), ('is', 2, 'five'), ('good', 3, 'six')]
    assert lookup_module_0.run(**dict_0) == result


# Generated at 2022-06-25 11:28:24.629723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()

# Generated at 2022-06-25 11:28:26.735720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(['a', '1'])
    assert result_0[0].__eq__(('a', 1))

# Generated at 2022-06-25 11:28:35.471006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = ['a', 'b', 'c', 'd']
    my_list_1 = [1, 2, 3, 4]
    result_for_my_list = [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
    assert list(zip_longest(my_list, my_list_1, fillvalue=None)) == result_for_my_list
    assert lookup_module_0.run([my_list, my_list_1]) == result_for_my_list


# Generated at 2022-06-25 11:28:41.573030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([[]]) == [[]]
    assert len(lookup_module_0.run([['a'], ['b']])) == 1
    assert lookup_module_0.run([['a'], ['b']])[0][0] == 'a'
    assert lookup_module_0.run(['foo', 'bar']) == [None, None]
    assert lookup_module_0.run([['a'], ['b']]) == [['a', 'b']]

# Generated at 2022-06-25 11:28:47.999341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['a', 'b', 'c'], 'd') == [('a', 'd'), ('b', 'd'), ('c', 'd')]
    assert lookup_module_0.run(['a', 'b', 'c']) == [('a', None), ('b', None), ('c', None)]


# Generated at 2022-06-25 11:28:54.680344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {'a':'a', 'b':'b', 'c':'c', 'd':'d'}
    terms = [terms]
    expected_result = [{'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}]

    # Unit test with no variables
    lookup_module = LookupModule()
    result = lookup_module.run(terms, '', '')

    assert result == expected_result

# Generated at 2022-06-25 11:28:57.996653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test', 'test', 'test']
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:28:59.416402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert None == lookup_module_1.run()

# Generated at 2022-06-25 11:29:02.016899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Missing argument terms
  try:
    lookup_module_0.run()
    assert False
  except TypeError as e:
    assert str(e) == "run() missing 1 required positional argument: 'terms'"


# Generated at 2022-06-25 11:29:11.523990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    lookup_module_0 = LookupModule()

    # Correct parameters
    terms_0 = ['str0', ['str1', 'str2']]
    variables_0 = dict(answer=42, string='World', list=['a', 'b'], dict={'key_x': 'value_x'})
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert type(result_0) is list
    assert result_0 == ['str0', 'str1', 'str2']

    # No parameters
    result_1 = lookup_module_0.run()
    assert type(result_1) is list
    assert result_1 == []

    # Correct parameters
   

# Generated at 2022-06-25 11:29:22.507559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = list()
    # my_list builds a list of length 1, element =  [['a', 'b', 'c', 'd'], [1, 2, 3, 4]].
    my_list = [
        [
            'a', 'b', 'c', 'd'
        ],
        [
            1, 2, 3, 4
        ]
    ]
    args.append(my_list)
    # Two args:
    #  1. args[0]= my_list
    #  2. variables: not used in this test case.
    rtn = test_case_0().run(args)

# Generated at 2022-06-25 11:29:23.242278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:29:27.891532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]


# Generated at 2022-06-25 11:29:33.220166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    lookup_module_0._set_templar()
    # Test step 1 of 1: initialization
    terms = [[1, 2, 3], [1, 2, 3]]
    variables = None
    kwargs = {}
    # Test step 2 of 2: run method
    assert lookup_module_0.run(terms, variables, **kwargs) == [[[1, 1], [2, 2], [3, 3]]]

# Generated at 2022-06-25 11:29:34.777554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 11:29:39.655946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [
        [
            1,
            2,
            3
        ],
        [
            4,
            5,
            6
        ]
    ]

    result = [
        [1, 4],
        [2, 5],
        [3, 6]
    ]
    lookup_module_1 = LookupModule()
    assert result == lookup_module_1.run(my_list)


# Generated at 2022-06-25 11:29:44.030986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(lookup_module_0.run([[1, 2, 3], [4, 5, 6]])) == 3
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [('1', '4'), ('2', '5'), ('3', '6')]
    assert len(lookup_module_0.run([[1, 2], [3]])) == 2
    assert lookup_module_0.run([[1, 2], [3]]) == [('1', '3'), ('2', None)]


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:29:48.876729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    k = [1, 2, 3], [4, 5, 6]
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run(k)
    # Test for [1, 4], [2, 5], [3, 6]
    assert x == [[1, 4], [2, 5], [3, 6]]

# Test for [1, 3], [2, None]

# Generated at 2022-06-25 11:29:50.948127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = (3, 7, 12)
  lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:30:00.638290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[1, 2, 3], [4, 5, 6]]
    variables_0 = None
    kwargs_0 = {'variables': variables_0}
    kwargs_0 = dict()
    result = lookup_module_0.run(terms_0, **kwargs_0)
    assert result == [[1, 4], [2, 5], [3, 6]]
    # Test a case where the arguments are not of expected type
    terms_1 = [1, 2, 3]
    variables_1 = None
    kwargs_1 = {'variables': variables_1}
    kwargs_1 = dict()

# Generated at 2022-06-25 11:30:05.093486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:30:14.755864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError
    lookup_module_0 = LookupModule()
    terms_list_0 = ['Generated by Ansible on host foo.example.com']
    str_0 = 'foo.example.com'
    var_0 = lookup_module_0.run(terms_list_0, acc_0, str_0)

# Generated at 2022-06-25 11:30:16.676224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, float_0)

# Generated at 2022-06-25 11:30:20.103139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert_equal(lookup_module_0.run(1, 2), None)


# Generated at 2022-06-25 11:30:23.992801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    (float_0, str_0) = (0, '-1252.5978')
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0, str_0)



# Generated at 2022-06-25 11:30:27.764697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [[6, 8]]
    var_1 = lookup_module_0.run(my_list)
    assert var_1 == [[6, 8]]


# Generated at 2022-06-25 11:30:38.748668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1.0
    lookup_module_0 = LookupModule()
    #test case for 0
    var_0 = lookup_module_0.run([])
    #test case for 1
    var_1 = lookup_module_0.run([float_0])
    #test case for 2
    var_2 = lookup_module_0.run([float_0, float_0])
    #test case for 3
    var_3 = lookup_module_0.run([float_0, float_0, float_0])
    #test case for 4
    var_4 = lookup_module_0.run([float_0, float_0, float_0, float_0])
    #test case for 5

# Generated at 2022-06-25 11:30:42.585674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    l1 = ['a', 'b']
    l2 = [1, 2]
    assert lookup_module_0._templar.template(l1) == ['a', 'b']
    assert lookup_module_0._templar.template(l2) == [1, 2]

# Generated at 2022-06-25 11:30:50.383250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['a', 'b', 'c']
    variables = {'my_list': ['a', 'd', 'f']}
    kwargs = {}
    lookup_module_0 = LookupModule
    lookup_module_0.run(terms, variables, **kwargs)
    assert len(lookup_module_0.run(terms, variables, **kwargs)) == 1


# Generated at 2022-06-25 11:30:53.533067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    assert type(obj.run(None)) is list


# Generated at 2022-06-25 11:31:04.145102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -1252.5978
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(float_1)
    if var_1 is None:
        raise Exception("Unit test for method run of class LookupModule failed with exception var is None")
    if var_1 != var_1:
        raise Exception("Unit test for method run of class LookupModule failed with exception var != var")

# Generated at 2022-06-25 11:31:13.369891
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = 'rEqHl'
    # int -> list of int
    test_0 = (123456789,)
    for kwargs_0 in test_0:
        try:
            result = lookup_module_0.run(terms_0, **kwargs_0)
        except:
            pass
        else:
            assert False, "Unexpected result: %s" % result
        return

    # int -> list of int
    test_1 = (123456789, lambda c:c)
    for kwargs_1 in test_1:
        try:
            result = lookup_module_0.run(terms_0, **kwargs_1)
        except:
            pass

# Generated at 2022-06-25 11:31:13.843703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 11:31:23.674136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = []
    variables = []
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

# AssertionError: <lambda>() takes no arguments (1 given)
#     def test_run_0(self):
#         lookup_module_0 = LookupModule()
#         terms_0 = []
#         variables_0 = []
#         kwargs_0 = {}
#         lookup_module_0.run(terms_0, variables_0, **kwargs_0)
#         func_0 = lambda: lookup_module_0.run(terms_0, variables_0, **kwargs_0)
#         self.assertRaises(AssertionError, func_0)

# AssertionError: <lambda>() takes

# Generated at 2022-06-25 11:31:26.377886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 25147
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(int_0, ) == None
    assert lookup_module_0.run(int_0, ) == None


# Generated at 2022-06-25 11:31:29.608929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    # AssertionError: 1627.739240429984 != -1252.5978


# Generated at 2022-06-25 11:31:30.739196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = run_test()

# Generated at 2022-06-25 11:31:36.227429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = lookup_module_0.run(terms, variables=var_0)
    assert_equal(lookup_module_1, None)


# Generated at 2022-06-25 11:31:37.892937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:31:39.262613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert None == LookupModule().run(list_0, var_0)


# Generated at 2022-06-25 11:31:49.664357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _item = [1,2,3]
    _list = [['a']]

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(_list, _item)

    assert var_0 == [['a', None, None]]


# Generated at 2022-06-25 11:31:57.089457
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:32:03.444097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1288.7008
    lookup_module_1 = LookupModule(
        lookup_module_0
    )
    assert len(lookup_module_1.run(float_0)) == 5


# Generated at 2022-06-25 11:32:10.333327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import zip_longest

    lookup_module_0 = AnsibleLookupModule()
    lookup_module_0.run("yo","dad")
    my_list = ["yo","dad"]
    my_list_0 = my_list[:]
    lookup_module_0.run("yo","dad")
    assert len(my_list_0) == 2
    assert [x for x in zip_longest(*my_list_0,fillvalue=None)] == [('y', 'd'), ('o', 'a'), ('d', None)]

# Generated at 2022-06-25 11:32:15.982374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [ 'a', 'b', 'c', 'd']  # list element 0
    var_1 = [1,2,3,4]  # list element 1
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(var_1)

    results = [('a',1),('b',2),('c',3),('d',4) ]
    assert var_2 == results

# Generated at 2022-06-25 11:32:20.205821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['a', 'b', 'c', 1, 'd']
    terms_0 = ['a', 'b', 'c', 1, 'd']
    variables = {}
    variables_0 = {}
    var_0 = lookup_module_0.run(terms, variables=variables)
    var_1 = lookup_module_0.run(terms_0, variables=variables_0)
    assert var_0 is not var_1
    assert var_0 == var_1

# Generated at 2022-06-25 11:32:25.299760
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for LookupModule.run()
    #
    # All elements in first list missing from the second
    # Transpose a list of arrays:
    # [1, 2, 3], [4, 5, 6] -> [1, 4], [2, 5], [3, 6]
    # Replace any empty spots in 2nd array with None:
    # [1, 2], [3] -> [1, 3], [2, None]
    #

    float_0 = -1252.5978
    list_1 = ["ab", [0.0, "ab"], (-123.65, "ab")]
    list_2 = [1, "ab", float_0]
    list_3 = [1, -1252.5978, float_0]
    list_4 = [float_0, list_1]
   

# Generated at 2022-06-25 11:32:27.156505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -10.01
    lookup_module_0 = LookupModule()
    lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:32:28.625986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)


# Generated at 2022-06-25 11:32:32.582612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    assert(var_0)


# Generated at 2022-06-25 11:32:59.002039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    assert isinstance(var_0, list) == True


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:33:08.963445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['a', 'b', 'c', 'd'], [1, 2, 3, 4]]
    rv = LookupModule.run(terms)
    assert isinstance(rv, list)
    assert len(rv) == 4
    assert all([isinstance(r, list) for r in rv])
    assert all([len(r) == 2 for r in rv])
    assert rv[0] == ['a', 1]
    assert rv[1] == ['b', 2]
    assert rv[2] == ['c', 3]
    assert rv[3] == ['d', 4]
    terms = [['a', 'b', 'c', 'd'], [1]]
    rv = LookupModule.run(terms)
    assert isinstance(rv, list)

# Generated at 2022-06-25 11:33:10.518871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(float_0)
    return var_1
#   return var_1

# Generated at 2022-06-25 11:33:17.290783
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    def test_run_0(self):
        my_list_0 = export("ANSIBLE_LOOKUP_PLUGINS")
        my_list_0 = None
        var_0 = lookup_run(my_list_0)
        assert var_0 == "foo", "Expected %s, but got %s" % ("foo", var_0)

    # Unit test for method run of class LookupModule
    def test_run_1(self):
        my_list_0 = export("ANSIBLE_LOOKUP_PLUGINS")
        my_list_0 = None
        var_0 = lookup_run(my_list_0)
        assert var_0 == "foo", "Expected %s, but got %s" % ("foo", var_0)

   

# Generated at 2022-06-25 11:33:21.836257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978

    # test_case_0
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0._flatten(float_0)

# Generated at 2022-06-25 11:33:29.670691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [ 'a', 'b', 'c', 'd' ]
    var_2 = [ 1, 2, 3, 4 ]
    terms = [ var_1, var_2 ]
    var_0 = lookup_module_0._run(terms)
    return var_0


# Generated at 2022-06-25 11:33:33.322475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    float_1 = -2086.4022
    float_2 = 1668.5978
    float_3 = -1835.5978
    var_0 = lookup_module_0.run(float_0)
    var_1 = lookup_module_0.run(float_1, float_2, float_3)

# Generated at 2022-06-25 11:33:37.714910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run() should return a synchronized list

    # Test case 1
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)



# Generated at 2022-06-25 11:33:39.022131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)



# Generated at 2022-06-25 11:33:43.533635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=3, variables=None)


# Generated at 2022-06-25 11:34:29.484275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test of run method
    results = lookup_module_0.run(terms, variables)
    assert not results


# Generated at 2022-06-25 11:34:32.999702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -1252.5978
    float_2 = 4.4801e-05
    int_0 = 0x7b
    lookup_module_0 = LookupModule()
    # Test using float_1
    var_1 = lookup_run(float_1)

    # Test using float_2
    var_2 = lookup_run(float_2)

    # Test using int_0
    var_3 = lookup_run(int_0)

# Test case for lookup module

# Generated at 2022-06-25 11:34:39.542427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    float_6 = -1252.5978
    float_7 = 870.00328
    int_4 = -265
    assert lookup_module_1.run([float_6, float_7, int_4]) == [int(float_6), int(float_7), int(int_4)]


# Generated at 2022-06-25 11:34:41.081179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:34:46.746587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [lookup_module_0.run([None])]
    del var_1


# Generated at 2022-06-25 11:34:51.581610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -1130.7606
    var_1 = LookupModule()
    var_2 = var_1.run(float_1)



# Generated at 2022-06-25 11:34:57.844321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    int_0 = 13
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    print(var_0)
    print('')
    var_1 = lookup_run(int_0)
    print(var_1)
    print('')

# Generated at 2022-06-25 11:34:59.447717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -114.6251
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:35:04.862636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get the function to look at
    function_0 = LookupModule.run

    # Get the parameters
    argspec_0 = inspect.getargspec(function_0)
    # print("-- {0}".format(argspec_0))

    # Get the number of parameters
    num_parameters_0 = len(argspec_0[0])
    # print("Number of parameters: {0}".format(num_parameters_0))

    # Get the number of defaults
    num_defaults_0 = len(argspec_0[3]) if argspec_0[3] else 0
    # print("Number of default values: {0}".format(num_defaults_0))

    # Get the names of parameters
    parameter_names_0 = argspec_0[0][1:]
    # print("Parameter names:

# Generated at 2022-06-25 11:35:12.137675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookups = [2, 3]
    terms = [4, 5]

    lookup_module_0 = LookupModule()
    lookup_module_0._flatten = lambda x: lookups
    assert lookup_module_0.run(terms) == lookups

    lookup_module_1 = LookupModule()
    lookup_module_1._flatten = lambda x: lookups
    assert lookup_module_1.run(terms) == lookups


# Generated at 2022-06-25 11:36:49.117222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test of parameter terms
    # Commented: 
    # Uncommented: 
    """
    [1, 2, 3], [4, 5, 6] -> [1, 4], [2, 5], [3, 6]
    Replace any empty spots in 2nd array with None:
    [1, 2], [3] -> [1, 3], [2, None]
    """
    # assert isinstance(lookup_module_0.run(), FOO_BAR_BAZ_QUX_QUUX) == True
    # assert lookup_module_0.run(terms) == ""


# Generated at 2022-06-25 11:36:51.557944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 11:36:56.648408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1252.5978
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)

test_LookupModule_run()

# Generated at 2022-06-25 11:37:05.660576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    func = lookup_module.run
    # Test with int argument
    result = func(1234)
    assert result == 1234
    # Test with float argument
    result = func(1.23)
    assert result == 1.23
    # Test with str argument
    result = func("1234")
    assert result == "1234"
    # Test with list argument
    result = func(["foo", "bar"])
    assert result == ["foo", "bar"]
    # Test with dict argument
    result = func({"foo": "bar"})
    assert result == {"foo": "bar"}
    # Test with bool argument
    result = func(True)
    result = func(False)
    # Test with None argument
    result = func(None)

# Generated at 2022-06-25 11:37:10.567784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_var_0 = lookup_create_var(float)
    lookup_var_0 = -1252.5978
    lookup_result_0 = lookup_module_0.run(lookup_var_0)
    assert lookup_result_0 == 'input_value_1'