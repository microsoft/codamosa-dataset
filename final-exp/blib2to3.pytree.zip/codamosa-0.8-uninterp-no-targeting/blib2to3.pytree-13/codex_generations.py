

# Generated at 2022-06-21 10:32:57.206247
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    assert Leaf(0, "1") == Leaf(0, "1")
    assert Leaf(0, "1") != Leaf(0, "2")
    assert Leaf(0, "1") != Leaf(1, "1")
    assert Leaf(0, "1") != Leaf(1, "2")

    x = Leaf(0, "1")
    y = x.clone()
    assert x == y
    assert x is not y
    assert x.prefix == y.prefix
    assert x.prefix is not y.prefix

    x.prefix = "2"
    assert x.prefix != y.prefix
    assert x.prefix == "2"
    assert y.prefix == ""

# Generated at 2022-06-21 10:33:02.117091
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    from mypy.test.testutil import assert_string_arrays_equal
    # Test some simple expressions
    e = Leaf(token.NAME, 'a', 1)
    dots = [NodePattern(content=[], min=1, max=1)]
    assert WildcardPattern(dots).match(e)
    assert WildcardPattern([[e]]).match([e])
    assert not WildcardPattern([[e]]).match([Leaf(token.NAME, 'z', 1)])
    assert WildcardPattern([[e]]).match_seq([e])
    assert not WildcardPattern([[e]]).match_seq([Leaf(token.NAME, 'z', 1)])
    assert not WildcardPattern([[e], [Leaf(token.NAME, 'z', 1)]]).match_seq([e])

# Generated at 2022-06-21 10:33:07.563146
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # pylint: disable=unnecessary-lambda
    def test(pattern, nodes, expected):
        """Test the given pattern against nodes with the expected results"""
        pat = WildcardPattern([[pattern]])
        iter = ("%r %r" % (c, r) for (c, r) in pat.generate_matches(nodes))
        result = ", ".join(iter)
        assert result == expected, "expected %r; got %r" % (expected, result)

    test(
        NodePattern(type=NAME, name="bare_name"),
        [Leaf(NAME, "abc"), Leaf(NAME, "def")],
        "2 {'bare_name': [%Leaf(NAME, 'abc'), %Leaf(NAME, 'def')]}",
    )

# Generated at 2022-06-21 10:33:11.207274
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    np = NegatedPattern()
    assert not np.content

    p = NodePattern(type=1)
    np = NegatedPattern(p)
    assert np.content == p


# Generated at 2022-06-21 10:33:14.930764
# Unit test for method set_child of class Node
def test_Node_set_child():
    expected = "int x = 10;"
    tree = parse(expected, mode="exec")
    tree.set_child(0, Leaf(1, "float ", (1, 0)))

    result = str(tree)
    print("Result:", result)

    assert result == "float x = 10;"


# Generated at 2022-06-21 10:33:25.752770
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from collections import namedtuple

    Node = namedtuple("Node", "type value children")
    w = WildcardPattern([[WildcardPattern()]])
    print("w=%s" % w)
    t1 = Node(1, "", [])
    t2 = Node(2, "", [])
    t3 = Node(3, "", [])
    s = [t1, t2, t3]
    print("s=%s" % s)
    print("generate_matches(s)=%s" % list(w.generate_matches(s)))



# Generated at 2022-06-21 10:33:36.902573
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    # L1
    L1 = Leaf(1, "test_L1_prefix")
    # N2
    #    L1
    N2 = Node(2, None, [L1])
    L1.parent = N2
    # N1
    #    N2
    #       L1
    N1 = Node(1, "test_N1_prefix", [N2])
    N2.parent = N1
    # test_N1_prefix
    assert isinstance(N1.get_suffix(), str)
    assert N1.get_suffix() == ""
    # test_L1_prefix
    assert isinstance(L1.get_suffix(), str)
    assert L1.get_suffix() == ""



# Generated at 2022-06-21 10:33:39.130711
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class C(BasePattern):
        type = 0
    assert C().optimize() is C()


# Generated at 2022-06-21 10:33:44.205583
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    leaf_content = "leaf"
    # make the leaf
    leaf = LeafPattern(leaf_content)
    # make the negation of the leaf
    negation = NegatedPattern(leaf)

    # we expect no matches because the leaf pattern matches the leaf content
    assert list(negation.generate_matches([leaf_content])) == []



# Generated at 2022-06-21 10:33:47.028080
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.test) == "test"

T = TypeVar("T")



# Generated at 2022-06-21 10:34:31.811618
# Unit test for method match_seq of class WildcardPattern

# Generated at 2022-06-21 10:34:42.422695
# Unit test for method post_order of class Node
def test_Node_post_order():
  import blib2to3.pytree as pytree
  from StringIO import StringIO
  S = StringIO("node.post_order()")
  _0_0_0 = pytree.Leaf(4, 'node')
  _0_0_1 = pytree.Leaf(11, '.')
  _0_0_2 = pytree.Leaf(4, 'post_order')
  _0_0_3 = pytree.Leaf(10, '(')
  _0_0_4 = pytree.Leaf(10, ')')
  _0_0 = pytree.Node(1, [_0_0_0, _0_0_1, _0_0_2, _0_0_3, _0_0_4])
  _0_1 = pytree.Leaf

# Generated at 2022-06-21 10:34:45.816810
# Unit test for method generate_matches of class NegatedPattern
def test_NegatedPattern_generate_matches():
    pat = NegatedPattern(WildcardPattern(None, min=1, max=1))
    assert list(pat.generate_matches([])) == [(0, {})]



# Generated at 2022-06-21 10:34:51.461852
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    leaf = Leaf(0, "testvalue", ("testprefix", (1, 2)), ["testfixer"])
    clone = leaf.clone()
    assert leaf.type == clone.type
    assert leaf.value == clone.value
    assert leaf.prefix == clone.prefix
    assert leaf.lineno == clone.lineno
    assert leaf.column == clone.column
    assert leaf.fixers_applied == clone.fixers_applied

# Generated at 2022-06-21 10:34:52.803842
# Unit test for method __str__ of class Node
def test_Node___str__():
    n=Node()
    n.__str__()


# Generated at 2022-06-21 10:34:53.405876
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()



# Generated at 2022-06-21 10:34:59.663044
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # define a class node
    class node:
        def __init__(self, value):
            self.value = value
            self.children = []
    a = node('a')
    b = node('b')
    c = node('c')
    ab = node('ab')
    ab.children.append(a)
    ab.children.append(b)
    abc = node('abc')
    abc.children.append(ab)
    abc.children.append(c)
    abc_pat = NodePattern(None, [NodePattern(None, [LeafPattern(None, 'a'), LeafPattern(None, 'b')]), LeafPattern(None, 'c')])
    assert abc_pat.match_seq([a,b,c])

# Generated at 2022-06-21 10:35:04.409587
# Unit test for method post_order of class Base
def test_Base_post_order():
    # Default values for instance variables
    type: int  # int: token number (< 256) or symbol number (>= 256)
    parent: Optional["Node"] = None  # Parent node pointer, or None
    children: List[NL]  # List of subnodes
    was_changed: bool = False
    was_checked: bool = False
    def post_order(self) -> Iterator[NL]:
        """
        Return a post-order iterator for the tree.

        This must be implemented by the concrete subclass.
        """
        raise NotImplementedError
    assert post_order is not None

# Generated at 2022-06-21 10:35:08.319784
# Unit test for method __new__ of class Base
def test_Base___new__():
    that8 = Base()
    __DSA16 = that8.__class__
    Base.__new__(__DSA16, )
test_Base___new__()

# Generated at 2022-06-21 10:35:09.763007
# Unit test for method set_child of class Node
def test_Node_set_child():
    # XXX: This is a stub test.
    pass

# Generated at 2022-06-21 10:35:25.935992
# Unit test for method __new__ of class Base
def test_Base___new__():
    assert Base.__new__ != Base.__init__
    assert Base().__new__ != Base.__new__
    assert Base.__new__(Base, 1) == 1



# Generated at 2022-06-21 10:35:31.031613
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    data = "abc\ndef\nghi\n"
    gram = Grammar()
    gram.parse(data)
    try:
        a = gram.tree.get_suffix()
        assert a == "def\n"
    except AssertionError:
        raise AssertionError("Base.get_suffix() failed")



# Generated at 2022-06-21 10:35:33.312640
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    assert_raises(AssertionError, BasePattern)

# Unit tests for method __repr__ of class BasePattern

# Generated at 2022-06-21 10:35:35.128043
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import libcst as cst
    n = cst.Pass()
    t = cst.parse_statement("foo()")
    n.insert_child(0, t)



# Generated at 2022-06-21 10:35:37.521563
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    # create node and children
    node = Leaf(token.NAME, "test")

    # attach children to node
    node.children = []

    # test pre_order
    assert [node] == list(node.pre_order())
    assert str(node) == "test"


# Generated at 2022-06-21 10:35:47.636061
# Unit test for method remove of class Base
def test_Base_remove():
    from .pytree import Leaf
    from .pygram import python_symbols
    from . import pygram
    from . import python_tree

    a = Leaf(1, "A")
    b = Leaf(2, "B")
    c = Leaf(3, "C")
    d = Leaf(4, "D")
    e = Leaf(5, "E")

    x = python_tree.Node(python_symbols.factor, [a,b,c,d,e])

    r = x.remove(a)
    assert r, x
    assert x.children == [b,c,d,e], x.children
    r = x.remove(c)
    assert r, x
    assert x.children == [b,d,e], x.children
    r = x.remove(e)

# Generated at 2022-06-21 10:35:52.729267
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    bp = BasePattern()
    assert_raises(NotImplementedError, bp._submatch, 0, {})
    assert_raises(NotImplementedError, bp.match, 0, {})
    assert_raises(NotImplementedError, bp.match_seq, 0, {})
    assert_raises(NotImplementedError, bp.generate_matches, 0)



# Generated at 2022-06-21 10:35:55.990139
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l_0 = Leaf(1, "hi")
    assert list(l_0.post_order()) == [l_0]
    assert list(l_0.leaves()) == [l_0]
    assert list(l_0.pre_order()) == [l_0]



# Generated at 2022-06-21 10:36:06.605971
# Unit test for method replace of class Base
def test_Base_replace():
    """Unit test for method replace of class Base"""
    import lib2to3.pgen2.pgen

    # TODO: Maybe this should use a real grammar!
    kw = lib2to3.pgen2.pgen.Keyword("kw")
    money = lib2to3.pgen2.pgen.Literal("$")
    nodes = [Leaf("1"), kw, money, Leaf("2")]
    parent = Node("parent", nodes)
    assert parent.children == nodes
    assert all([kw.parent is parent, money.parent is parent])
    parent.replace(money, [Leaf("4"), Leaf("5")])
    assert parent.children == [Leaf("1"), Leaf("4"), Leaf("5"), Leaf("2")]

# Generated at 2022-06-21 10:36:13.910909
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Test that it recognizes valid nodes
    assert NegatedPattern().match('a') == False
    assert NegatedPattern().match(('a', 'b')) == False
    assert NegatedPattern().match(('a',)) == False
    # Test that it recognizes invalid nodes
    assert NegatedPattern().match(()) == False
    # Test that it recognizes valid node sequences
    assert NegatedPattern().match_seq([]) == True
    assert NegatedPattern().match_seq(['a']) == False
    assert NegatedPattern().match_seq(['a', 'b']) == False
    # Test that it recognizes invalid node sequences
    assert NegatedPattern().match_seq(['a', 'b', 'c']) == False


# Generated at 2022-06-21 10:36:31.681607
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    # Test with default argument values
    n = Node(0, [])
    r = n.__repr__()
    assert r == "Node(0, [])", r
    # Test with short prefix
    n = Node(0, [token(1, prefix=" ")])
    r = n.__repr__()
    assert r == "Node(0, [Leaf(1, ' ')])", r
    # Test with long prefix
    n = Node(0, [token(1, prefix=" " * 40)])
    r = n.__repr__()
    assert r == "Node(0, [Leaf(1, '                    ')])", r
    # Test with children
    n = Node(0, [token(1, prefix=" "), token(2)])
    r = n.__repr__

# Generated at 2022-06-21 10:36:44.650504
# Unit test for method post_order of class Node
def test_Node_post_order():
    import unittest
    import lib2to3
    from lib2to3.pgen2.token import NUMBER, NAME, STRING
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.driver import Driver
    from lib2to3.pgen2.convert import convert_from_grammar
    from lib2to3.pytree import pytree
    from test_all import driver, parse_string
    from lib2to3 import fixer_base
    from lib2to3.pgen2.pgen import _generate_all_grammar_conversions
    from lib2to3.fixes.fix_print import FixPrint

    class TestNode(unittest.TestCase):

        def test_method_post_order(self):
            a = pytree.Node

# Generated at 2022-06-21 10:36:53.301468
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.driver import Driver
    from .pgen2.parse import parse
    from .pgen2.pgen import Grammar
    from .pgen2.tokenize import generate_tokens

    g = Grammar()
    d = Driver(g, convert)
    g.symbol2number['x'] = 256
    # The following tests are for a node pattern and leaf pattern respectively
    for input, pattern, expected in (
        ("x", NodePattern(256), [((True,), 1)]),
        ("*", LeafPattern(42), [((True,), 1)]),
    ):
        tree = parse(input, d)
        t: Tuple[NL, ...] = tuple(tree.pre_order())
        matches = list(pattern.generate_matches(t))
        assert matches == expected, matches


# Generated at 2022-06-21 10:36:56.502615
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(10) == "NAME"
    assert type_repr(42) == 42


T = TypeVar("T")



# Generated at 2022-06-21 10:37:06.165902
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from . import pytree

    from .pythonparser import python_grammar

    def assert_preorder(source: Text, names: Iterable[Text]) -> None:
        tree = compile(source, "<test>", "exec", flags=0, dont_inherit=True)
        assert [node.name for node in tree.pre_order()] == list(names)

    assert_preorder(
        "foo(42, bar={})",
        ["file_input", "stmt", "simple_stmt", "expr_stmt", "testlist", "test", "atom"],
    )
    assert_preorder(
        "class C: pass",
        ["file_input", "stmt", "classdef"],
    )

# Generated at 2022-06-21 10:37:11.701095
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    for cls in (LeafPattern, NodePattern):
        p = cls(1)
        assert list(p.generate_matches([])) == []
        assert list(p.generate_matches([Leaf(1, "foo")])) == [(1, {})]
        assert list(p.generate_matches([Leaf(2, "bar")])) == []
        assert list(p.generate_matches([Leaf(2, "bar"), Leaf(1, "foo")])) == []



# Generated at 2022-06-21 10:37:17.209099
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    import libfuturize.fixes.fix_print
    import lib2to3.pgen2.tokenize
    import lib2to3.pytree
    import lib2to3.pgen2.parse
    import io
    source = """for i in xrange(10):
    print >> sys.stderr, i
"""
    pytree = lib2to3.pgen2.parse.parse_string(source, '<string>')
    print("Pre-order iterator")
    for n, n2 in zip(pytree.pre_order(), pre_order(pytree)):
        if n != n2:
            print("Mismatch at node %s" % (n,))
            break
    print("Post-order iterator")

# Generated at 2022-06-21 10:37:26.928098
# Unit test for function generate_matches
def test_generate_matches():
    p0 = NodePattern(0)
    p1 = NodePattern(1)
    assert list(generate_matches([p0], [])) == [(0, {})]
    assert list(generate_matches([p0], [Node(0)])) == [(1, {})]
    assert list(generate_matches([p0], [Node(1)])) == []
    assert list(generate_matches([p0, p0], [Node(0), Node(0)])) == [(2, {})]
    assert list(generate_matches([p0, p1], [Node(0), Node(0)])) == []
    assert list(generate_matches([p0, p1], [Node(0), Node(1)])) == [(2, {})]

# Generated at 2022-06-21 10:37:36.207558
# Unit test for function convert
def test_convert():
    class MockGrammar(object):

        def __init__(self):
            self.number2symbol = {256: "foo"}

    gr = MockGrammar()

    node = convert(gr, (258, "bar", None, [Leaf(1, "baz")]))
    assert isinstance(node, Leaf), node

    node = convert(gr, (259, "bar", None, [Leaf(1, "baz")]))
    assert isinstance(node, Node), node

    node = convert(
        gr, (258, "bar", None, [Leaf(1, "baz"), Leaf(2, "qux")])
    )
    assert isinstance(node, Node), node
# Make sure conversion works with a simple tree structure
#
# a = b + c
#
# where a, b

# Generated at 2022-06-21 10:37:40.567031
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf
    tree = Leaf(0, "")
    assert tree.leaves() == [tree]
    tree.type = 1
    assert tree.leaves() == [tree]
    tree.type = 0
    assert tree.leaves() == [tree]



# Generated at 2022-06-21 10:38:26.096819
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import textwrap
    from .pgen2.driver import Driver
    from .pgen2.parse import ParseError
    from .pgen2.tokenize import generate_tokens
    from .pgen2.token import tok_name
    driver=Driver(convert, "graminit.txt", None, None)
    def test_generate_matches(p):
        program=textwrap.dedent(p)
        g=driver.grammar
        try:
            tokens=list(generate_tokens(StringIO(program).readline))
        except TokenError as e:
            print("Tokenizing %r gave %s" % (program, e))
            return

# Generated at 2022-06-21 10:38:27.694887
# Unit test for method __new__ of class BasePattern
def test_BasePattern___new__():
    bp = BasePattern()
    assert False, "unreachable code"


# Generated at 2022-06-21 10:38:33.317651
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():  # unit test for Node.update_sibling_maps
    from .pygram import python_grammar

    # TODO: Make sure there are test cases for every statement and definition.

# Generated at 2022-06-21 10:38:35.414282
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Node, Leaf

    tree = Node(1, [Leaf(1, 1), Node(1, [Node(1, [Leaf(1, 2)]), Leaf(1, 3)])])
    assert list(tree.leaves()) == [Leaf(1, 1), Leaf(1, 2), Leaf(1, 3)]



# Generated at 2022-06-21 10:38:36.584057
# Unit test for constructor of class BasePattern
def test_BasePattern():
    bp = BasePattern()
    assert bp.type is None
    assert bp.content is None
    assert bp.name is None



# Generated at 2022-06-21 10:38:40.738501
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    # test: WildcardPattern().generate_matches(nodes)
    nodes = [
        Node(0, [Leaf(0, )]),
        Node(0, [Leaf(0, "a"), Leaf(0, "b")]),
        Node(0, [Leaf(0, "a"), Leaf(0, "b"), Leaf(0, "c")]),
    ]

# Generated at 2022-06-21 10:38:49.116788
# Unit test for method post_order of class Base
def test_Base_post_order():
    """Unit test for method post_order of class Base"""

    g = Grammar()  # type: Grammar
    g.parse_file("tests/testgrammar.txt")

    out = StringIO()
    n = g.parse_string(
        textwrap.dedent(
            """
            if 1:
                pass
        """
        ),
        "single_input",
    )  # type: LeafNode
    for node in n.post_order():
        if isinstance(node, Leaf):
            out.write(str(node))
        else:
            out.write(node.symbol)
        out.write(' ')
    assert out.getvalue() == "if : pass 1 NEWLINE EOF "

    out = StringIO()

# Generated at 2022-06-21 10:38:59.499929
# Unit test for method remove of class Base
def test_Base_remove():
    from .pgen2.tokenize import generate_tokens
    from . import pytree

    def make_tree(code: Text) -> pytree.Node:
        tokens = generate_tokens(StringIO(code).readline)
        return pytree.from_tokens(tokens, "nocode")

    # This test assumes that `code` is not a module (e.g. no leading `from ...
    # import ...`).
    def check_remove(code: Text, to_remove: Text, expected: Text) -> None:
        tree = make_tree(code)
        found = tree.find(lambda node: node.value == to_remove)
        assert len(found) == 1
        node = found[0]
        index = node.remove()
        flat = pytree.flatten(tree)

# Generated at 2022-06-21 10:39:01.769728
# Unit test for function type_repr
def test_type_repr():
    for key in _type_reprs:
        assert _type_reprs[key] == type_repr(key)



# Generated at 2022-06-21 10:39:05.197924
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Verify that Base() throws an exception
    with pytest.raises(AssertionError) as excinfo:
        Base()
    assert "Cannot instantiate Base" in str(excinfo.value)


# Generated at 2022-06-21 10:40:32.973302
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from . import token
    leaf = Leaf(token.NAME, 'test', prefix='    ')
    assert leaf.__repr__() == \
        "Leaf(NAME, 'test')"



# Generated at 2022-06-21 10:40:42.781318
# Unit test for function generate_matches
def test_generate_matches():
    """Test function generate_matches."""
    assert list(generate_matches([], [])) == [(0, {})]
    assert list(generate_matches([], [NL(0)])) == []
    assert list(generate_matches([WildcardPattern()], [])) == [(0, {})]
    assert list(generate_matches([WildcardPattern()], [NL(0)])) == [(1, {})]
    assert list(generate_matches([NodePattern()], [])) == []
    assert list(generate_matches([NodePattern()], [NL(0)])) == [(1, {})]
    assert list(generate_matches([NodePattern(0)], [])) == []
    assert list(generate_matches([NodePattern(0)], [NL(0)])) == [(1, {})]


# Generated at 2022-06-21 10:40:44.918359
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(1, "test")
    leaves = leaf.leaves()
    assert len(list(leaves)) == 1
    assert next(leaves) == leaf


# Generated at 2022-06-21 10:40:48.813915
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    from .pgen2.parse import parse

    t = parse('[1, 2]')
    nodes = [
        'LBRACK', 'NUMBER', 'COMMA', 'NUMBER', 'RBRACK',
        'ENDMARKER', 'DEDENT', 'DEDENT', 'DEDENT'
    ]
    for leaf, node in zip(leaf_gen(t), nodes):
        assert leaf.type == node



# Generated at 2022-06-21 10:40:49.828165
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    class NewPattern(BasePattern):
        type = 100
    assert repr(NewPattern()) == "NewPattern(100)"



# Generated at 2022-06-21 10:40:59.569722
# Unit test for constructor of class NodePattern
def test_NodePattern():
    try:
        NodePattern(42)
    except AssertionError:
        pass
    else:
        assert 0, "Didn't catch missing type"
    try:
        NodePattern(42, [1, 2, 3])
    except AssertionError:
        pass
    else:
        print("Didn't catch missing type")
        assert 0
    try:
        NodePattern(257)
    except AssertionError:
        pass
    else:
        print("Didn't catch bad token type")
        assert 0
    try:
        NodePattern(257, ["blah"])
    except AssertionError:
        pass
    else:
        print("Didn't catch bad token type")
        assert 0

# Generated at 2022-06-21 10:41:11.169148
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import parse
    from .pgen2 import token


# Generated at 2022-06-21 10:41:14.180016
# Unit test for method __str__ of class Node
def test_Node___str__():
    expected_str = ""
    n = Node(python_symbols.comp_for, [])
    assert str(n) == expected_str, str(n)



# Generated at 2022-06-21 10:41:21.406243
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    from .pgen2.token import Token

    x = LeafPattern()
    assert x.match(Leaf(Token.EQUAL, "=="))
    assert not x.match(Node(0))
    #
    x = LeafPattern(Token.EQUAL)
    assert x.match(Leaf(Token.EQUAL, "=="))
    assert not x.match(Leaf(Token.EQUAL, "!="))
    assert not x.match(Node(0))
    #
    x = LeafPattern(Token.EQUAL, "==")
    assert x.match(Leaf(Token.EQUAL, "=="))
    assert not x.match(Leaf(Token.EQUAL, "!="))
    assert not x.match(Node(0))
    #

# Generated at 2022-06-21 10:41:24.308976
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():

    class P(BasePattern):
        pass

    p = P()
    assert p is p.optimize()

