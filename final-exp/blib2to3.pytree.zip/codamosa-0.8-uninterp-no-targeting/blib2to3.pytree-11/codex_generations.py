

# Generated at 2022-06-21 10:33:05.359499
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    n = Node(syms.a, [])
    for i, r in BasePattern(type=syms.a).generate_matches([n]):
        assert i == 1
        assert r == {}
    for i, r in BasePattern(type=syms.b).generate_matches([n]):
        assert False, "This must not be reached"
    assert list(BasePattern(type=syms.b).generate_matches([])) == []



# Generated at 2022-06-21 10:33:15.320340
# Unit test for method get_lineno of class Base
def test_Base_get_lineno():
    from .pytree import Leaf, StandardLeaf, Base, Node
    from .pygram import python_symbols as syms
    b = Base()
    assert b.get_lineno() is None

    b.parent = Node(syms.file_input, [])
    assert b.get_lineno() is None

    b.parent.children = [Leaf(0, "")]
    assert b.get_lineno() is None

    b.parent.children = [Leaf(0, "")]
    assert b.get_lineno() is None

    b.parent.children[0].type = syms.stmt
    b.parent.children[0].lineno = 10
    assert b.get_lineno() == 10


# Generated at 2022-06-21 10:33:27.982683
# Unit test for method depth of class Base
def test_Base_depth():
    """
    Check that Base.depth() works.

    It's hard to unit test this method of Base, because Base
    doesn't have any children.  This test uses a concrete subclass.
    """

    class Dummy(Leaf):
        def __init__(self):
            super(Dummy, self).__init__(0, "dummy")

    assert Dummy().depth() == 0
    assert Dummy().clone().depth() == 0

    a = Dummy()
    b = Dummy()
    assert a.depth() == 0
    assert b.depth() == 0
    assert a.depth() == 0

    a.replace(b)
    assert a.depth() == 0
    assert b.depth() == 1

    a.replace(None)
    assert a.depth() == 0
    assert b.depth() == 1



# Generated at 2022-06-21 10:33:39.074246
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from .compiler import compile

    assert not NegatedPattern().match(compile("1"))
    assert not NegatedPattern(WildcardPattern()).match(compile("1"))
    assert NegatedPattern(WildcardPattern((NodePattern(NUMBER),))).match(
        compile("1")
    )
    assert NegatedPattern(WildcardPattern((NodePattern(NUMBER),))).match(
        compile("1 2")
    )
    assert not NegatedPattern(WildcardPattern((NodePattern(NUMBER),))).match(
        compile("1 2 3")
    )
    assert NegatedPattern(WildcardPattern((NodePattern(DOT),))).match(
        compile("1 2 3")
    )



# Generated at 2022-06-21 10:33:49.829668
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    stmts = Stmts([
        Leaf(token.NUMBER, '1', (1, 0)),
        Newline(),
        Leaf(token.NUMBER, '2', (2, 0)),
        Newline(),
        Leaf(token.NUMBER, '3', (3, 0)),
    ])
    assert stmts == copy(stmts)

    stmts = Stmts([
        Leaf(token.NUMBER, '1', (1, 0)),
        Newline(),
        Leaf(token.NAME, 'x', (2, 0)),
        Newline(),
        Leaf(token.NUMBER, '3', (3, 0)),
    ])
    assert stmts != copy(stmts)


# Generated at 2022-06-21 10:33:52.956037
# Unit test for method changed of class Base
def test_Base_changed():
    c = Leaf(1, "")
    n = Node(2, [c])
    assert n.was_changed == False
    assert c.was_changed == False
    c.changed()
    assert n.was_changed == True
    assert c.was_changed == True


# Generated at 2022-06-21 10:34:03.017577
# Unit test for function generate_matches
def test_generate_matches():
    # generate_matches is defined in this module
    from abc2ps.fundamentals import Node, Leaf, NodePattern, WildcardPattern

    #  node[0] = Node(1, [Node(2, [Leaf(1), Leaf(100), Leaf(2)]), Leaf(3)])
    #  node[1] = Node(1, [Node(2, [Leaf(4), Leaf(5), Leaf(6)]), Leaf(3)])
    #  node[2] = Node(1, [Node(2, [Leaf(1), Leaf(2), Leaf(3)]), Leaf(3)])
    #  node[3] = Node(1, [Leaf(1), Leaf(2), Leaf(3)])

    node = [None] * 4

# Generated at 2022-06-21 10:34:07.542256
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    n = Node(0, [Leaf(0, ""), Leaf(1, "")])
    assert list(n.pre_order()) == [n, n.children[0], n.children[1]]



# Generated at 2022-06-21 10:34:08.947581
# Unit test for constructor of class Base
def test_Base():
    node = Base()



# Generated at 2022-06-21 10:34:11.227347
# Unit test for method __new__ of class Base
def test_Base___new__():
    # AssertionError -> AssertionError
    Base()
    # Exception raised successfully


# Generated at 2022-06-21 10:34:30.410967
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import re
    from .pgen2.parse import _generate_matches

    _generate_matches()



# Generated at 2022-06-21 10:34:41.642452
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    w = WildcardPattern(content=None, min=1, max=1)
    assert w.content is None, repr(w.content)
    assert w.min == 1, repr(w.min)
    assert w.max == 1, repr(w.max)
    assert w.name is None, repr(w.name)

    w = WildcardPattern([[]])
    assert len(w.content) == 1, repr(w.content)
    assert len(w.content[0]) == 1, repr(w.content)
    assert w.min == 1, repr(w.min)
    assert w.max == 1, repr(w.max)
    assert w.name is None, repr(w.name)

    w = WildcardPattern(content=[[]])
    assert len(w.content) == 1, repr

# Generated at 2022-06-21 10:34:50.767503
# Unit test for method remove of class Base
def test_Base_remove():  # noqa
    class dummy_Leaf:  # noqa
        def __init__(self):
            pass

    class dummy_Node:  # noqa
        def __init__(self):
            self.children = []
            self.parent = None

    dummy_node = dummy_Node()
    dummy_child = dummy_Node()
    dummy_child.parent = dummy_node
    dummy_node.children = [dummy_child]

    assert dummy_child.remove() == 0
    assert dummy_child.parent is None
    assert dummy_child not in dummy_node.children



# Generated at 2022-06-21 10:34:54.997823
# Unit test for method leaves of class Base
def test_Base_leaves():
    from .pytree import Leaf, Node
    from .pygram import python_symbols

    node = Node(python_symbols.simple_stmt, [Leaf(1, ""), Leaf(1, ""), Leaf(1, "")])

    # Class method leaves of class Base
    leaves = node.leaves()
    assert len(list(leaves)) == 3



# Generated at 2022-06-21 10:35:05.135860
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    from .pgen2.parse import ParseError
    from .pgen2 import token

    class Pattern(BasePattern):
        ...

    pattern = Pattern(token.NAME, "x", "y")
    assert repr(pattern) == "Pattern(NAME, 'x', 'y')"
    pattern = Pattern(token.NAME, "x")
    assert repr(pattern) == "Pattern(NAME, 'x')"
    pattern = Pattern(token.NAME)
    assert repr(pattern) == "Pattern(NAME)"
    with pytest.raises(AttributeError):
        pattern = Pattern('ast')
    with pytest.raises(ParseError):
        pattern = Pattern(token.OP)



# Generated at 2022-06-21 10:35:08.423674
# Unit test for method changed of class Base
def test_Base_changed():
    test_leaf = Leaf(1, "")
    test_leaf.changed()
    assert test_leaf.was_changed


# Generated at 2022-06-21 10:35:10.111326
# Unit test for method __new__ of class Base
def test_Base___new__():
    Base()
    assert False  # Didn't raise exception

# Generated at 2022-06-21 10:35:12.184681
# Unit test for constructor of class Node
def test_Node():
    n = Node(0, [])
    assert isinstance(n, Node) and n.type == 0 and not n.children



# Generated at 2022-06-21 10:35:20.733015
# Unit test for method append_child of class Node
def test_Node_append_child():
    test=Node(0,[])
    test.append_child(0)
    assert (test.children==[0] and test.children[0].parent==None)
    test.append_child(1)
    assert (test.children==[0,1] and test.children[1].parent==None)
    test.append_child(2)
    assert (test.children==[0,1,2] and test.children[2].parent==None)
    test.append_child(3)
    assert (test.children==[0,1,2,3] and test.children[3].parent==None)




# Generated at 2022-06-21 10:35:31.711138
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():

    def _test(expr, expected):
        leaf = Leaf(1, expr, (None, (0,0)), None)
        assert str(leaf) == expected, str(leaf)

    _test('"a"', '"a"')
    _test(1, '1')
    _test(False, 'False')
    _test(None, 'None')
    _test(1.1, '1.1')
    _test([], '[]')
    _test({}, '{}')
    _test('+', '+')
    _test('-', '-')
    _test('*', '*')
    _test('/', '/')
    _test('//', '//')
    _test('%', '%')
    _test('==', '==')

# Generated at 2022-06-21 10:35:52.562873
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    import unittest

    class TestWildcardPattern(unittest.TestCase):
        """
        Tests to ensure constructor of WildcardPattern fails in expected ways
        """

        def test_bad_min_max(self):
            """
            Tests that constructor fails when min and max are not in the
            correct range
            """
            with self.assertRaises(AssertionError):
                WildcardPattern(min=-1, max=HUGE)

            with self.assertRaises(AssertionError):
                WildcardPattern(min=0, max=-1)

            with self.assertRaises(AssertionError):
                WildcardPattern(min=2, max=1)

        def test_bad_content(self):
            """
            Tests that constructor fails when content is not of the correct type
            """

# Generated at 2022-06-21 10:35:54.500525
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    from .token import token

    leaf = Leaf(token.NAME, "foo")
    assert str(leaf) == "Leaf(NAME, 'foo')"



# Generated at 2022-06-21 10:36:05.626039
# Unit test for method post_order of class Base
def test_Base_post_order():
    #    (x  (y .c .d) .e .f)
    x = Node(1, [Node(2, [Leaf(3, "c"), Leaf(4, "d")]), Leaf(5, "e"), Leaf(6, "f")])
    #    01234567890123456789
    assert list(x.post_order()) == [Leaf(3, "c"), Leaf(4, "d"), Node(2, [Leaf(3, "c"), Leaf(4, "d")]), Leaf(5, "e"), Leaf(6, "f"), Node(1, [Node(2, [Leaf(3, "c"), Leaf(4, "d")]), Leaf(5, "e"), Leaf(6, "f")])]



# Generated at 2022-06-21 10:36:07.404624
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    p = BasePattern()
    result = p.optimize()
    assert result is p

# Generated at 2022-06-21 10:36:14.949819
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    assert WildcardPattern()
    assert WildcardPattern(min=1)
    assert WildcardPattern(max=1)
    assert WildcardPattern(max=3)
    assert WildcardPattern(max=3)
    assert WildcardPattern(min=2, max=3)
    assert WildcardPattern(min=2, max=3).content is None
    assert WildcardPattern(content=[]).content == ()
    assert WildcardPattern(content=[[]]).content == ((),)
    assert WildcardPattern(content=[["abc"]]).content == ((LeafPattern(content="abc"),),)
    assert WildcardPattern(content=[[NodePattern(type=NEWLINE)]]).content == (
        (NodePattern(type=NEWLINE),),
    )

# Generated at 2022-06-21 10:36:18.934558
# Unit test for method __repr__ of class Leaf
def test_Leaf___repr__():
    import ast
    import pprint
    repr_obj = ast.Leaf(1,'value')
    assert repr_obj.__repr__() == "%s(%s, %r)" % ('Leaf', 'NONE', 'value')

# Test for method __repr__ of class Leaf

# Generated at 2022-06-21 10:36:21.641058
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    class Test(BasePattern):
        def _submatch(self, node, results=None): pass
    assert Test(None, None, None) is Test(None, None, None).optimize()



# Generated at 2022-06-21 10:36:28.531980
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(3, "abc")
    assert l.type == 3
    assert l.value == "abc"
    assert l.children == []
    assert str(l) == "abc"
    assert repr(l) == "Leaf(3, 'abc')"

    l = Leaf(3, "abc", fixers_applied=[1, 2])
    assert l.fixers_applied == [1, 2]
    l1 = l.clone()
    assert l1.type == 3
    assert l1.value == "abc"
    assert l1.children == []
    assert str(l1) == "abc"
    assert repr(l1) == "Leaf(3, 'abc')"
    assert l1.fixers_applied == [1, 2]



# Generated at 2022-06-21 10:36:30.879996
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    node = Node(256,[])
    node.update_sibling_maps()
    assert True
test_Node_update_sibling_maps()


# Generated at 2022-06-21 10:36:43.992795
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pygram import python_symbols as syms, python_grammar as grammar

    # Create a dummy grammar.
    grammar: Optional[Grammar] = grammar.Grammar(grammar.python_grammar_no_print_statement)

    # Create a new node with these kids.
    n = Node(syms.atom, [Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")], None, None)

    # Set one of the kids.
    n.set_child(1, Leaf(4, "d"))

    # We shouldn't have had to update all the sibling maps.
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None

    # But the child's map should be set.
    assert n.children[1].prev

# Generated at 2022-06-21 10:37:00.318887
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    from . import pytree
    
    node = pytree.Node(type=257, children=[pytree.Leaf(type=1, value='spam'), pytree.Leaf(type=2, value='ham')])
    assert repr(node) == 'Node(NAME, [Leaf(1, \'spam\'), Leaf(2, \'ham\')])'


# Generated at 2022-06-21 10:37:05.209224
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert NodePattern(type=syms.testlist, content=()).content == ()
    assert NodePattern(type=syms.testlist, content=[LeafPattern(1)]).content == [
        LeafPattern(1)
    ]



# Generated at 2022-06-21 10:37:09.776079
# Unit test for method append_child of class Node
def test_Node_append_child():
    a= Node(1, [])
    a.append_child(Leaf(12, "child1"))
    assert a.children == [Leaf(12, "child1")]
    assert a.children[0].parent == a
    assert a.prev_sibling_map == None
    assert a.next_sibling_map == None


# Generated at 2022-06-21 10:37:10.944244
# Unit test for constructor of class Node
def test_Node():
    class TestNode(Node):
        pass

    t = TestNode(1, [])
    assert t.type == 1



# Generated at 2022-06-21 10:37:19.828191
# Unit test for function convert
def test_convert():
    from .pgen2 import driver

    def convert_test(s: Text) -> Tuple[NL, Text]:
        from .pgen2 import driver

        g = driver.load_grammar("Grammar/Grammar")

        parser = g.parser("file_input")
        tree = parser.parse_string(s)
        assert isinstance(tree, Node)
        assert len(tree.children) == 1
        file_input: Node = tree.children[0]
        return file_input, tree.get_suffix()

    def test_simple(s: Text, expected: Text) -> None:
        n, suffix = convert_test(s)
        assert str(n) == expected, s
        assert suffix == "", str(suffix)

    test_simple('1+1', '1+1')
    s

# Generated at 2022-06-21 10:37:25.277295
# Unit test for constructor of class NodePattern
def test_NodePattern():
    def _test(a1, *args, **kwds):
        pattern = NodePattern(a1, *args, **kwds)
        assert pattern.type == a1
        assert pattern.content is None
        assert pattern.name is None
        return pattern
    assert _test(257)
    assert _test(257, None)
    assert _test(257, [])
    assert _test(257, [LeafPattern()])



# Generated at 2022-06-21 10:37:33.280215
# Unit test for method insert_child of class Node
def test_Node_insert_child():
    import sys
    import re
    import copy
    def replaceRuleTrue(match):
        for i in range(len(match.group(0))):
            match.group(0)[i] = replaceRuleTrue(match.group(0)[i])
        return match.group(0)
    def replaceRuleFalse(match):
        for i in range(len(match.group(0))):
            match.group(0)[i] = replaceRuleFalse(match.group(0)[i])
        return match.group(0)
    Node.insert_child(self, i, child)

    # Constructor

# Generated at 2022-06-21 10:37:42.139726
# Unit test for method match_seq of class BasePattern
def test_BasePattern_match_seq():
    def assert_match_seq(pattern, nodes):
        r = {'key': None}
        expected = (1, r)
        actual = pattern.match_seq(nodes, r)
        assert actual == expected, actual
    pattern = LeafPattern(token.NAME)
    nodes = [Leaf(token.NAME, "my_name", prefix="")]
    assert_match_seq(pattern, nodes)
# Method match_seq of class BasePattern

# Generated at 2022-06-21 10:37:51.661526
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Node, Leaf
    n = Node(1, [Leaf(1, 'foo'), Node(2, [Leaf(3, 'bar')]), Leaf(4, 'baz')])
    # post-order is DLR
    assert list(n.post_order()) == [
        Leaf(3, 'bar'),
        Node(2, [Leaf(3, 'bar')]),
        Leaf(1, 'foo'),
        Leaf(4, 'baz'),
        Node(1, [Leaf(1, 'foo'), Node(2, [Leaf(3, 'bar')]), Leaf(4, 'baz')]),
    ]


# Generated at 2022-06-21 10:37:55.254303
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """
    Call a method of Node to make sure that it works as expected.
    """
    n = Node(0, [])
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None



# Generated at 2022-06-21 10:38:28.980197
# Unit test for constructor of class WildcardPattern
def test_WildcardPattern():
    #
    # Check that exception is raised when min > max.
    #
    try:
        p = WildcardPattern(min=2, max=1)
    except:
        pass
    else:
        assert False, "WildcardPattern.__init__() didn't raise exception with min > max"
    #
    # Check that exception is raised when content is not None and min < 0
    #
    try:
        p = WildcardPattern(content=[['.']], min=-1)
    except:
        pass
    else:
        assert False, "WildcardPattern.__init__() didn't raise exception with content not None and min < 0"
    #
    # Check that exception is raised when content is None and min < 0
    #

# Generated at 2022-06-21 10:38:29.419253
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    pass



# Generated at 2022-06-21 10:38:30.174724
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    n = Node(256, [])



# Generated at 2022-06-21 10:38:32.068870
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    bp = BasePattern()
    bp.type = 1
    bp.content = "1"
    bp.name = "1"
    repr(bp) == "<BasePattern>"




# Generated at 2022-06-21 10:38:33.306838
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(token.NAME, "a", (1, 2))
    assert list(l.post_order()) == [l]


# Generated at 2022-06-21 10:38:34.230236
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(0, 0)
    assert list(leaf.pre_order()) == [leaf]


# Generated at 2022-06-21 10:38:42.965361
# Unit test for method set_child of class Node
def test_Node_set_child():
  from . import pytree
  import unittest

  # Base class
  class NodeTest(unittest.TestCase):
    def assertNodesEqual(self, node, expected_node):
      self.assertEqual(repr(node), repr(expected_node))

  class SetChildTest(NodeTest):
    def test_simple(self):
      node = pytree.Node(0, [pytree.Leaf(0, "hello")])
      node.set_child(0, pytree.Leaf(0, "goodbye"))
      expected_node = pytree.Node(0, [pytree.Leaf(0, "goodbye")])
      self.assertNodesEqual(node, expected_node)

  class AppendChildTest(NodeTest):
    def test_simple(self):
      node = py

# Generated at 2022-06-21 10:38:50.631013
# Unit test for method post_order of class Base
def test_Base_post_order():
    from . import pytree
    from .pygram import python_symbols
    from .pgen2.tokenize import generate_tokens

    g = Grammar()
    st = g.parse(StringIO("x = 1 + 2"))
    st.was_checked = True
    # type: ignore
    x = st.leaves()[1]

# Generated at 2022-06-21 10:38:52.864140
# Unit test for constructor of class Node
def test_Node():
    n = Node(type=3, children=[])
    assert n.type == 3
    assert n.children == []
    assert n.parent is None



# Generated at 2022-06-21 10:39:03.547614
# Unit test for constructor of class Leaf
def test_Leaf():
    import sys,os
    import unittest
    from .pgen2.token import tok_name
    this_dir = os.path.dirname(os.path.abspath(__file__))

    try:
        # python 3.4 or above
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "test_Leaf", this_dir+os.sep+"test_Leaf.py")
        # get the python module from the file
        test_Leaf_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(test_Leaf_module)
        sys.modules["test_Leaf"] = test_Leaf_module
    except:
        # python below 3.4
        import imp
        test_

# Generated at 2022-06-21 10:39:32.471097
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    leaf = Leaf(0, "")
    assert list(leaf.leaves()) == [leaf]



# Generated at 2022-06-21 10:39:40.793635
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    import conftest
    import pytree
    import pgen2
    import pickle
    import tempfile

    grammar = pgen2.driver.load_grammar("Grammar.txt")
    grammar.grammar = conftest.get_grammar()
    s = "x += 1"
    t = next(pytree.convert(grammar.parse(s), "stmts"))
    assert list(t.pre_order()) == [t, t.children[0], t.children[1], t.children[2]]


# Generated at 2022-06-21 10:39:51.808149
# Unit test for method pre_order of class Base
def test_Base_pre_order():
    from .pytree import Node, Leaf

    n = Leaf(0, "prefix", (1, 1), context=("test", (1, 1)))
    n.children = [Leaf(0, "prefix", (1, 1), context=("test", (1, 1)))]
    n.children[0].children = [Leaf(0, "prefix", (1, 1), context=("test", (1, 1)))]
    assert list(n.pre_order()) == [
        n,
        n.children[0],
        n.children[0].children[0]
    ]
    n = Node(0, [Leaf(0, "prefix", (1, 1), context=("test", (1, 1))), Leaf(0, "prefix", (1, 1), context=("test", (1, 1)))])
   

# Generated at 2022-06-21 10:39:55.009274
# Unit test for method post_order of class Node
def test_Node_post_order():
    node=test1()
    for x in node.post_order():
        x
    for x in node.post_order():
        print(x)

# Generated at 2022-06-21 10:40:03.797893
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.parse import ParseError, parse_grammar
    from .pgen2.tokenize import generate_tokens

    def test(s: Text) -> None:
        g = parse_grammar(s, debug=True)
    with pytest.raises(ParseError):
        test("a -> b\nc -> A")
    with pytest.raises(ParseError):
        test("""
            x
            a -> x b
            b -> "b"
            c -> A
            """)
    test("a -> b\nb -> 'b'")
    test("a -> b\nb -> 'b'\nc -> A")
    # test a baseclass instance
    assert BasePattern().match(None) is False
    assert BasePattern(token.NAME).match(None) is False

# Generated at 2022-06-21 10:40:14.439088
# Unit test for method clone of class Base
def test_Base_clone():
    import unittest
    import textwrap
    import warnings
    from ..pgen2.tokenize import untokenize
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.parse import ParseError

    class TestCase(unittest.TestCase):
        """Test case subclass that keeps track of the original source."""

        def __init__(self, source, methodName):
            self.source = source
            unittest.TestCase.__init__(self, methodName)

        def check_node(self, node, repr):
            """Check a node against a description in a string."""
            r = eval(repr, {}, {'Node': Node, 'Leaf': Leaf})

# Generated at 2022-06-21 10:40:21.915343
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    from .pgen2.token import tok_name
    from .pgen2.parse import ParseError, parse_string
    from .pgen2.driver import Driver
    from .pgen2 import tokenize
    from .pgen2 import pgen
    from .pgen2.pgen import Grammar, Loader, load_grammar
    grammar = load_grammar(pgen, 'Grammar.txt')
    grammar._Driver_new = grammar.Driver_new

    def Driver_new(self, **kwds):
        return self._Driver_new(**kwds)

    grammar.Driver_new = Driver_new
    gr = grammar
    def driver(s):
        return Driver(gr, convert=convert).parse_string(s, 'file_input')

    # Test default case

# Generated at 2022-06-21 10:40:31.850619
# Unit test for method __str__ of class Node
def test_Node___str__():
    program = FileInput([])
    assert repr(program) == "FileInput([],)"
    program.append_child(Leaf(1, "a"))
    assert repr(program) == "FileInput([1, 'a'],)"
    program.append_child(Leaf(1, "b"))
    assert repr(program) == "FileInput([1, 'a', 1, 'b'],)"
    program.append_child(
        Node(
            256, [
                Leaf(1, "c"),
                Node(
                    257, [
                        Leaf(1, "d"),
                    ],
                ),
            ],
        ),
    )

# Generated at 2022-06-21 10:40:41.935120
# Unit test for constructor of class LeafPattern
def test_LeafPattern():
    from .pgen2.token import tok_name

    assert LeafPattern().match(Leaf(1, "1"))
    assert LeafPattern().match(Leaf(1, "1", prefix=" "))
    assert not LeafPattern().match(Leaf(1, "2"))
    assert not LeafPattern().match(Node(1, []))
    assert LeafPattern(1).match(Leaf(1, "1"))
    assert LeafPattern(1).match(Leaf(1, "1", prefix=" "))
    assert not LeafPattern(1).match(Leaf(1, "2"))
    assert not LeafPattern(1).match(Node(1, []))
    assert not LeafPattern(2).match(Leaf(1, "1"))
    assert not LeafPattern(2).match(Leaf(1, "1", prefix=" "))

# Generated at 2022-06-21 10:40:49.217205
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import unittest.mock as mock

    def mock_submatch(subpattern, node, *args, **kwargs):
        if subpattern.content == "left_hand" and node.value == "L":
            return True
        if subpattern.content == "right_hand" and node.value == "R":
            return True
        return False

    p = WildcardPattern(None, min=1, max=3, name="name")
    p.content = [
        [
            LeafPattern("left_hand"),
            LeafPattern("right_hand"),
            LeafPattern("left_hand"),
        ]
    ]
    p._submatch = mock.Mock(side_effect=mock_submatch)

# Generated at 2022-06-21 10:41:17.921147
# Unit test for method post_order of class Node
def test_Node_post_order():
    global grammar
    from .pygram import python_grammar

    grammar = python_grammar
    from .pytree import convert

    grammar = grammar
    t = convert("a + b + c")
    assert t.type == grammar.syms.testlist_comp_3b
    assert list(t.post_order()) == [
        t.children[1],
        t.children[0],
        t.children[2],
        t.children[3],
        t,
    ]

    t = convert("for x in foo: bar(x)")
    assert t.type == grammar.syms.comp_for

# Generated at 2022-06-21 10:41:26.323585
# Unit test for method leaves of class Base
def test_Base_leaves():
    node1 = Leaf(1, "foo")
    node2 = Leaf(1, "bar")
    node3 = Node(1)
    node3.append_child(node1)
    node3.append_child(node2)
    node4 = Node(1)
    node4.append_child(node3)
    node4.append_child(Leaf(1, "baz"))
    result = list(node4.leaves())
    assert result == [node1, node2, Leaf(1, "baz")]

