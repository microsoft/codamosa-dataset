

# Generated at 2022-06-21 10:33:00.216925
# Unit test for method changed of class Base
def test_Base_changed():
    assert True

# Generated at 2022-06-21 10:33:04.628164
# Unit test for method clone of class Node
def test_Node_clone():
    n = Node(1, [Leaf(1, ""), Leaf(2, "")])
    assert str(n) == "", str(n)
    assert len(n.children) == 2, len(n.children)
    assert n.parent is None, n.parent
    n1 = n.clone()
    assert str(n1) == "", str(n1)
    assert len(n1.children) == 2, len(n1.children)
    assert n1.parent is None, n1.parent
    assert n1.children[0] != n.children[0], n1.children



# Generated at 2022-06-21 10:33:15.353732
# Unit test for method remove of class Base
def test_Base_remove():
    code = "if True:\n    print('hello')\n    print('world')\n"
    grammar = Grammar()
    from .pygram import python_grammar
    from .pgen2 import tokenize

    tree = grammar.parse_string(code, "exec", python_grammar)
    tokens: Dict[Any, Any] = {}
    for t in tokenize.generate_tokens(StringIO(code).readline):
        tokens[t[2]] = t

    children = tree.children
    assert len(children) == 1
    if_stmt = children[0]
    assert if_stmt.type == python_grammar.syms.compound_stmt

    children = if_stmt.children
    assert len(children) == 3

# Generated at 2022-06-21 10:33:27.982061
# Unit test for method leaves of class Base
def test_Base_leaves():
    tree = Node(1, [])
    assert list(tree.leaves()) == []

    tree = Node(1, [Leaf(1, "")])
    assert list(tree.leaves()) == [Leaf(1, "")]

    tree = Node(1, [Node(1, [Leaf(1, "")])])
    assert list(tree.leaves()) == [Leaf(1, "")]

    tree = Node(1, [Node(1, [Node(1, [Leaf(1, "")])])])
    assert list(tree.leaves()) == [Leaf(1, "")]

    tree = Node(1, [Node(1, [Node(1, [Leaf(1, ""), Leaf(1, "")])])])

# Generated at 2022-06-21 10:33:40.864179
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    pattern = NegatedPattern(None)
    assert pattern.match([])
    assert not pattern.match([Symbol(0)])
    pattern = NegatedPattern(LeafPattern(1))
    assert not pattern.match([Symbol(0)])
    assert not pattern.match([Symbol(1)])
    pattern = NegatedPattern(LeafPattern(0))
    assert pattern.match([Symbol(1)])
    pattern = NegatedPattern(LeafPattern(1))
    assert pattern.match_seq([Symbol(0)])
    assert not pattern.match_seq([Symbol(1)])
    assert pattern.match_seq([Symbol(0), Symbol(1)])
    assert not pattern.match_seq([Symbol(1), Symbol(1)])

# Generated at 2022-06-21 10:33:50.766797
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    from .pytree import Leaf, Node

    # simple cases
    p = WildcardPattern()
    assert p.match_seq([])
    assert not p.match_seq([Leaf(1, "foo"), Leaf(1, "bar")])
    assert p.match_seq([Leaf(1, "foo")])
    assert p.match_seq([Leaf(1, "foo"), Leaf(1, "bar")])
    assert p.match_seq([Leaf(1, "foo"), Leaf(1, "bar"), Leaf(1, "baz")])
    p = WildcardPattern(min=1)
    assert not p.match_seq([])
    assert p.match_seq([Leaf(1, "foo")])

# Generated at 2022-06-21 10:33:58.098718
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pgen2.token import NAME
    l = Leaf(NAME, "foo")
    assert l.leaves() is not None
    assert list(l.leaves()) == [l]
    # sanity
    assert list(l.pre_order()) == [l]
    assert list(l.post_order()) == [l]


# Generated at 2022-06-21 10:34:00.004921
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    """Test method __repr__ of class BasePattern."""
    BasePattern()



# Generated at 2022-06-21 10:34:09.277177
# Unit test for constructor of class NodePattern
def test_NodePattern():
    """
    >>> NodePattern()
    NodePattern(None, None, None)
    >>> NodePattern(None, [], None)
    NodePattern(None, None, None)
    >>> NodePattern(None, "foo")
    Traceback (most recent call last):
      ...
    AssertionError: "foo"
    >>> NodePattern(None, [object()])
    Traceback (most recent call last):
      ...
    AssertionError: 0, <object object at 0x...>
    """



# Generated at 2022-06-21 10:34:13.632879
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    stmts = [
        Node(syms.stmt, [Leaf(token.NAME, "1")]),
        Node(syms.stmt, [Leaf(token.NAME, "2")]),
        Node(syms.stmt, [Leaf(token.NAME, "3")]),
        Node(syms.stmt, [Leaf(token.NAME, "4")]),
        Node(syms.stmt, [Leaf(token.NAME, "5")]),
    ]
    root = Node(syms.file_input, stmts)
    for i in range(len(stmts)):
        current = stmts[i]
        assert root.prev_sibling_map[id(current)] == (
            None if i == 0 else stmts[i-1]
        )
       

# Generated at 2022-06-21 10:34:40.494722
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    leaf = Leaf(1, "2", None, fixers_applied=[])
    assert str(leaf) == "2"


# Generated at 2022-06-21 10:34:48.210005
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from .pytree import Leaf
    # Test a match
    n1 = Leaf(1, "foo")
    n2 = Leaf(1, "foo")
    assert n1 == n2
    assert n1 == n1

    # Test a non-match
    n1 = Leaf(1, "foo")
    n2 = Leaf(2, "foo")
    assert not n1 == n2

    # Test different classes
    assert not n1 == "foo"



# Generated at 2022-06-21 10:34:50.316832
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    n = NodePattern(type=1)
    # n.match_seq([Leaf(1, "a"), Leaf(1, "b")])
    assert n.match_seq([Leaf(1, "a"), Leaf(1, "b")]) == False


# Generated at 2022-06-21 10:34:55.023568
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """
    Test invalidate_sibling_maps method of Node class.
    """
    import unittest
    import sys
    import os
    from io import StringIO
    from . import pytree
    from .pygram import python_symbols
    from .pgen2 import driver

    def test_vars():
        node = Node(python_symbols.file_input, [])
        assert node.prev_sibling_map is None
        assert node.next_sibling_map is None
        node.invalidate_sibling_maps()
        assert node.prev_sibling_map is None
        assert node.next_sibling_map is None

    def test_next_sibling():
        node = Node(python_symbols.file_input, [])
        node.invalidate_sibling_

# Generated at 2022-06-21 10:35:04.207134
# Unit test for method match of class LeafPattern
def test_LeafPattern_match():
    def setUp(self):
        self.p = LeafPattern()

    def test_match_leaf(self):
        l = Leaf(1, "text", (None, None))
        self.assertTrue(self.p.match(l))

    def test_match_node(self):
        n = Node(257, None, (None, None))
        self.assertFalse(self.p.match(n))

    def test_match_content(self):
        l = Leaf(1, "text", (None, None))
        self.p.content = "tex"
        self.assertTrue(self.p.match(l))



# Generated at 2022-06-21 10:35:15.571794
# Unit test for method remove of class Base
def test_Base_remove():
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.driver as driver
    pgen = driver.Driver()
    m = pgen.parse_string("print('')", '<string>')
    assert m is not None
    assert m.remove() is None # the root node cannot be removed

    name = m.children[0].children[0]
    assert isinstance(name, Leaf)
    assert name.remove() == 0
    assert name.parent is None
    assert m.children[0].children == []
    m.children[0].children.append(name)

    printCall = m.children[0].children[0] # the call node

    # test the remove method on a node with children - the call node


# Generated at 2022-06-21 10:35:24.325584
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    input = """
        if x:
            pass
    """  # noqa
    from lib2to3 import pytree

    tree = pytree.nb_parse(input)
    expected = [
        (1, "if"),
        (1, "x"),
        (1, ":"),
        (1, "pass"),
        (1, ""),
        (0, ""),
        (0, ""),
        (0, ""),
        (0, ""),
        (0, ""),
    ]
    result = [
        (node.type, node.value) for node in tree.pre_order()
    ]  # noqa
    assert result == expected
    assert node in result


_L = TypeVar("_L", bound="Leaf")



# Generated at 2022-06-21 10:35:33.134437
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf, Node
    from .pygram import python_grammar

    grammar = python_grammar
    parse_string = grammar.parse_string
    tokens = grammar.tokens

    root = parse_string('def f(x):\n    return x*2\n')
    result = root.post_order()
    assert next(result).type == tokens.NAME
    assert next(result).type == tokens.NUMBER
    assert next(result).type == tokens.STAR
    assert next(result).type == tokens.RPAR
    assert next(result).type == tokens.NAME
    assert next(result).type == tokens.LPAR
    assert next(result).type == tokens.NAME
    assert next(result).type == tokens.COLON
    assert next(result).type == tokens.INDENT

# Generated at 2022-06-21 10:35:38.647881
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    negated = NegatedPattern()
    assert negated.match_seq([])
    assert not negated.match_seq([Leaf(1, "")])
    subpattern = SequencePattern([LeafPattern(""), LeafPattern("")])
    negated2 = NegatedPattern(subpattern)
    assert negated2.match_seq([])
    assert not negated2.match_seq([Leaf(1, "")])
    assert not negated2.match_seq([Leaf(1, ""), Leaf(1, "")])



# Generated at 2022-06-21 10:35:42.549726
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    assert type_repr(python_symbols.testlist_gexp) == "testlist_gexp"
    assert type_repr(-2) == -2
test_type_repr()



# Generated at 2022-06-21 10:36:02.502451
# Unit test for constructor of class Node
def test_Node():
    # Build a small tree for testing
    n = Node(python_symbols.file_input, [])
    n = Node(python_symbols.stmt, [n])
    n = Node(python_symbols.simple_stmt, [n])
    n = Node(python_symbols.small_stmt, [n])

    # Make sure that the parent pointers are correct
    assert n.parent is None and n.children[0].parent is n
    assert n.children[0].children[0].parent is n.children[0]

    # Make sure that n prints as a simple_stmt node
    # With a trailing newline
    assert str(n) == ": None"



# Generated at 2022-06-21 10:36:06.485667
# Unit test for method __str__ of class Node
def test_Node___str__():
    line = "print 1"
    input_src = StringIO(line)
    grammar = Grammar()
    parser = grammar.parser
    tree = parser.parse_stream(input_src)
    print(tree.__str__())
    assert isinstance(tree, Node)
    assert tree.__str__() == line
# test_Node___str__()


# Generated at 2022-06-21 10:36:14.470192
# Unit test for method remove of class Base
def test_Base_remove():
    class TestNode(Node):
        def __init__(self, children=None, parent=None):
            self.children = children
            self.parent = parent
    class TestLeaf(Leaf):
        def __init__(self, value, prefix="", parent=None):
            self.value = value
            self.prefix = prefix
            self.parent = parent
    child1 = TestLeaf("leaf1")
    child2 = TestLeaf("leaf2")
    child3 = TestLeaf("leaf3")
    children = [child1, child2, child3]
    node = TestNode(children=children)
    assert [child.value for child in node.children] == ["leaf1", "leaf2", "leaf3"]
    assert node.remove() == 0

# Generated at 2022-06-21 10:36:16.288776
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(symbol.test, [LeafPattern(token.NAME, "baz"),
                                 NodePattern(symbol.comp_for)])



# Generated at 2022-06-21 10:36:20.040610
# Unit test for function type_repr
def test_type_repr():
    from .pygram import python_symbols
    for e in dir(python_symbols):
        if type(getattr(python_symbols, e)) == int:
            assert type_repr(getattr(python_symbols, e)) == e
# End of unit test



# Generated at 2022-06-21 10:36:27.434584
# Unit test for method generate_matches of class BasePattern
def test_BasePattern_generate_matches():
    import ast
    from .pgen2 import token, driver
    import sys
    import os

    def iter_matches(pat, tree):
        for i, r in pat.generate_matches(tree.leaves()):
            if len(tree.leaves()) == i:
                yield r

    file_input = driver.Driver(
        ast, parseinfo=False, convert=ast.convert, debug=False
    ).parse_file
    pat = NodePattern(ast.Lambda, [LeafPattern(token.COLON)])
    lambda_ = pat.get_match_list(file_input(sys.executable))[0]
    assert isinstance(lambda_, ast.Lambda)
    assert lambda_.col_offset == 6


# Generated at 2022-06-21 10:36:37.866975
# Unit test for function convert
def test_convert():
    from .pgen2 import driver
    from . import pytree

    gr = driver.load_grammar("Grammar.txt")
    assert convert(gr, (1, 5, b"", [convert(gr, (2, 6, b"", []))])) == pytree.Leaf(6, 5)
    assert convert(gr, (1, 5, b"", [convert(gr, (2, 6, b"", [])), convert(gr, (2, 7, b"", []))])) == pytree.Node(1, [pytree.Leaf(6, 5), pytree.Leaf(7, 5)])



# Generated at 2022-06-21 10:36:39.532881
# Unit test for method set_child of class Node
def test_Node_set_child():
    print('In test_Node_set_child')


# Generated at 2022-06-21 10:36:46.627617
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    x = True or None
    x = True is None
    x = True is not None
    x = True and None
    x = True not in None
    x = True not in None
    # x = 1 if False elif True else 2
    x = 1 if False else 2
    # x = [1, 2, 3] if False elif True else [1, 2, 3]
    x = [1, 2, 3] if False else [1, 2, 3]

# Generated at 2022-06-21 10:36:51.792819
# Unit test for constructor of class Node
def test_Node():
    n = Node(1, [])
    assert n.type == 1
    assert n.children == []
    n = Node(1, [Node(2, []), Leaf(2, "X")])
    assert n.type == 1
    assert n.children == [Node(2, []), Leaf(2, "X")]
    assert n.children[0].parent is n
    assert n.children[1].parent is n



# Generated at 2022-06-21 10:37:34.180552
# Unit test for function convert
def test_convert():
    from .pgen2.grammar import Grammar
    from .pgen2.parse import Driver

    gr = Grammar(_TEST_GRAMMAR_1)
    drv = Driver(gr, convert)

    result = drv.parse("a", debug=None)
    assert result == Leaf(0, "a")

    result = drv.parse("ab", debug=None)
    assert result == Node(1, [Leaf(0, "a"), Leaf(0, "b")])


# TODO: _DEBUG_GRAMMAR is not a good name, since it's not supposed to be
# a grammar, only a collection of grammar fragments.

# Generated at 2022-06-21 10:37:44.895778
# Unit test for method match_seq of class NegatedPattern

# Generated at 2022-06-21 10:37:55.159583
# Unit test for method post_order of class Node
def test_Node_post_order():
    from .pytree import Leaf
    def test_rec(node, index):
        r = list(node.post_order())
        assert r[index].type, node.type
        for i, ch in enumerate(node.children):
            test_rec(ch, index + i + 1)
    test_rec(Node(1, [Node(2, [Leaf(3, "foo"), Leaf(4, "bar")]), Leaf(5, "spam")], ""), 0)
    test_rec(Node(1, [Node(2, [Leaf(3, "foo"), Leaf(4, "bar")]), Leaf(5, "spam")], ""), 0)

# Generated at 2022-06-21 10:38:07.295510
# Unit test for method depth of class Base
def test_Base_depth():
    # Test for method depth (Base) of class Base
    # Tests the depth function of the base parser.
    from .pytree import Leaf, Node
    import random

    # Test 0 - function must return 0 for a root node
    root = Node(0, [Leaf(1, "", (0, 0)),
                    Leaf(1, "123456789", (0, 0)),
                    Leaf(2, "", (0, 0))])
    assert root.depth() == 0

    # Test 1 - function must return 1 for a first level node
    assert root[0].depth() == 1
    assert root[1].depth() == 1
    assert root[2].depth() == 1

    # Test 2 - function must return 2 for a second level node

# Generated at 2022-06-21 10:38:13.885795
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    p = WildcardPattern([[], []], min=0, max=HUGE)
    assert list(p.generate_matches([Leaf(1, 'bla')])) == []
    p = NodePattern(type='K')
    assert list(p.generate_matches([Leaf(1, 'bla')])) == []
    assert list(p.generate_matches([Node('K')])) == [(1, {})]



# Generated at 2022-06-21 10:38:16.231768
# Unit test for method optimize of class BasePattern
def test_BasePattern_optimize():
    """Test case for method optimize of class BasePattern."""
    o = BasePattern()
    o_opt = o.optimize()
    assert o is o_opt



# Generated at 2022-06-21 10:38:20.894850
# Unit test for method __str__ of class Node
def test_Node___str__():
    n = Node(0, [Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")])
    assert str(n) == "abc"


# Generated at 2022-06-21 10:38:23.437009
# Unit test for method append_child of class Node
def test_Node_append_child():
    node = Node(1, [])
    node.append_child(2)
    assert node.children == [2]


# Generated at 2022-06-21 10:38:31.448794
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """
    Unit test for method invalidate_sibling_maps of class Node

    Tests method invalidate_sibling_maps of class Node and the properties
    prev_sibling_map and next_sibling_map of class Node
    """
    from .pytree import Leaf

    l = Leaf(0, "")
    n = Node(0, [l])
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None
    n.invalidate_sibling_maps()
    assert n.prev_sibling_map is None
    assert n.next_sibling_map is None


# Generated at 2022-06-21 10:38:33.725036
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    from .pgen2.token import DOUBLE_STAR

    p = BasePattern()
    assert p.match(Node(DOUBLE_STAR, []))
    assert not p.match(Leaf(DOUBLE_STAR, ""))



# Generated at 2022-06-21 10:41:28.246344
# Unit test for method append_child of class Node
def test_Node_append_child():
    # TODO(jtolio): We don't yet have a way to properly create a Leaf/Node and
    # assert that the class has been created correctly, so this test will just
    # check to make sure we can instantiate the class, call some methods, and
    # they don't raise errors.
    #from tree_grammar import PythonGrammar
    #grammar = Grammar(PythonGrammar)
    #test_node = Node(1, [Leaf(1, "")], prefix="", grammar=grammar)
    #test_node.append_child(Leaf(1, ""))
    pass