

# Generated at 2022-06-21 10:33:25.853177
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    try:
        grammar = Grammar(open("Python.asdl"))
        tree = grammar.parse(open("Lib/test/badsyntax_3154.py").read())
        tree.update_sibling_maps()
        assert True, "Test successful"
    except:
        assert False, "Test failed"
#test_Node_update_sibling_maps()


# Generated at 2022-06-21 10:33:27.530665
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    l = Leaf(0, "foo")
    assert list(l.post_order()) == [l]


# Generated at 2022-06-21 10:33:40.150739
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # Test code
    # pylint: disable=too-many-locals
    class TestPattern(BasePattern):
        def match(self, node, results=None):
            return False
        def match_seq(self, nodes, results=None):
            if nodes == [1, 2]:
                return True
            elif nodes == [3, 4]:
                return True
            else:
                return False
    # Test setup
    base_pattern = BasePattern()
    n_p = NegatedPattern()
    n_p_content = NegatedPattern(TestPattern())
    t_p = TestPattern()
    # Test function
    assert n_p.match_seq([], None) is True
    assert n_p.match_seq([1], None) is False

# Generated at 2022-06-21 10:33:50.297313
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    p = LeafPattern(token.NUMBER)
    assert not isinstance(p, BasePattern)
    assert repr(p) == "LeafPattern(NUMBER)"
    p = LeafPattern(token.NUMBER, 42)
    assert repr(p) == "LeafPattern(NUMBER, 42)"
    p = LeafPattern(token.NUMBER, 42, "n")
    assert repr(p) == "LeafPattern(NUMBER, 42, 'n')"
    p = NodePattern(syms.power)
    assert not isinstance(p, BasePattern)
    assert repr(p) == "NodePattern(power)"
    p = NodePattern(syms.power, "r")
    assert repr(p) == "NodePattern(power, 'r')"
    p = NodePattern(syms.power, "r", 42)


# Generated at 2022-06-21 10:34:02.489467
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    import textwrap
    import sys
    import io
    # Variables
    saved_stdout = sys.stdout
    outfile = io.StringIO()
    sys.stdout = outfile
    name = "Node_set_child"
    # Test
    n = Node(1, [Leaf(3, ""), Node(4, [Leaf(5, ""), Node(6, [Leaf(8, "")])])])
    node_to_set = Node(2, [Leaf(9, "")])
    n.set_child(1, node_to_set)
    print(n.children[1] is node_to_set)
    n.changed()
    n.insert_child(2, n.children[0])

# Generated at 2022-06-21 10:34:14.909043
# Unit test for method __eq__ of class Base
def test_Base___eq__():
    from . import pytree_test_lib
    
    class Base(object):
        def __eq(self, other):
            raise NotImplementedError
        def __eq__(self, other):
            return self.__eq(other)
        def post_order(self):
            if self.children:
                for ch in self.children:
                    yield ch
            yield self
    
    class Test(Base):
        def __init__(self, type):
            self.type = type
            self.children = []
        def clone(self):
            return self
        def _eq(self, other):
            return self.type == other.type
    
    tree1 = Test(1)
    tree2 = Test(2)
    
    assert tree1 == tree1
    assert tree1 != tree2

# Generated at 2022-06-21 10:34:20.681578
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    test_s = """
    def test():
        a = 1
        return a
    """
    grammar = Grammar()
    mod = python_parse(test_s, grammar)
    a = mod.children[1].children[1].children[1]
    # value of a.next_sibling.prefix should be "return "
    try:
        assert (a.next_sibling.prefix == "return ")
    except AttributeError:
        print("The attribute node.next_sibling.prefix does not exist.")
        sys.exit()
    assert (a.get_suffix() == "return ")



# Generated at 2022-06-21 10:34:25.702919
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    import pgen2.parse
    assert Leaf(1, "a").post_order() == Leaf(1, "a").pre_order()
    assert Leaf(1, "a").post_order() == Node(257, [Leaf(1, "a")]).post_order()
    file1 = open("tests/inputs/test_Leaf_post_order.py")
    t = pgen2.parse.parse(file1, 'exec')
    a = list(t.post_order())
    assert a == [t, t.children[0], t.children[0].children[0]]

# Generated at 2022-06-21 10:34:35.205043
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    import tokenize
    from lib2to3.pgen2.token import *
    with open('test/test_Base_get_suffix.py') as f:
        for type, value, start, end, line in tokenize.generate_tokens(f.readline):
            if type == NEWLINE:
                # Last token(NEWLINE) doesn't have next sibling
                return
            tail = line[end[1] : ]
            leaf = Leaf(type, value, (start, end), prefix=line[ : start[1]])
            assert leaf.get_suffix() == tail
            return


# Generated at 2022-06-21 10:34:44.408130
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    from patterns import Pattern as P
    assert not P("~(foo|foobar)").match("f")
    assert not P("~(foo|foobar)").match("fo")
    assert P("~(foo|foobar)").match("foo")
    assert not P("~(foo|foobar)").match("foob")
    assert P("~(foo|foobar)").match("fooba")
    assert P("~(foo|foobar)").match("foobar")
    assert not P("~(foo|foobar)").match("foobarb")
    assert P("~(foo|foobar)").match("foobarba")
    assert not P("~(foo|foobar)").match("foobarbar")
    assert P("~(foo|foobar)").match("foobarbarr")

# Generated at 2022-06-21 10:35:12.170661
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    assert not NegatedPattern().match(test_nodes[0])
    assert not NegatedPattern().match(test_nodes[1])
    assert not NegatedPattern().match(test_nodes[2])
    assert not NegatedPattern().match(test_nodes[3])
    assert NegatedPattern().match(test_nodes[4])
    assert NegatedPattern().match(test_nodes[5])
    assert NegatedPattern().match(test_nodes[6])
    assert NegatedPattern().match(test_nodes[7])

    pattern = NegatedPattern(LeafPattern(3, 'b'))
    assert pattern.match(test_nodes[0])
    assert pattern.match(test_nodes[1])
    assert pattern.match(test_nodes[2])

# Generated at 2022-06-21 10:35:22.329821
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import unittest
    from collections import namedtuple
    from io import StringIO
    import token

    def tokenize(text):
        file = StringIO(text)
        return list(tokenize_chunks([file]))

    def match(t, p):
        return (t, p, list(p.generate_matches(t)))

    def check(expected, actual, message=""):
        if expected != actual:
            if message:
                message += ": "
            raise unittest.TestCase.failureException(
                message + "expected %s, got %s" % (expected, actual)
            )

    # ============================================================
    # Test the NodePattern.match() method in the test_NodePattern class below.

    t = tokenize('print "hello, world"')
    print(t)


# Generated at 2022-06-21 10:35:26.785729
# Unit test for constructor of class Base
def test_Base():
    tree = Node(1, [Node(2, []), Leaf(3)])
    assert tree.type == 1
    assert tree.children == [Node(2, []), Leaf(3)]
    assert tree.children[0] is not tree.children[1]



# Generated at 2022-06-21 10:35:33.665652
# Unit test for method update_sibling_maps of class Node
def test_Node_update_sibling_maps():
    l_ = lambda x: Leaf(1, x)
    n_ = lambda *x: Node(1, x)
    p = n_(l_('a'), l_('b'), l_('c'))
    assert p.children[0].next_sibling == p.children[1]
    assert p.children[1].next_sibling == p.children[2]
    assert p.children[2].next_sibling == None
    assert p.children[2].prev_sibling == p.children[1]
    assert p.children[1].prev_sibling == p.children[0]
    assert p.children[0].prev_sibling == None



# Generated at 2022-06-21 10:35:34.774641
# Unit test for function type_repr
def test_type_repr(): assert type_repr(1) == 1


# TODO: consider using a symbol table to make type checking faster at runtime



# Generated at 2022-06-21 10:35:40.027805
# Unit test for method __str__ of class Node
def test_Node___str__():
    from .pytree import Leaf, Node
    assert Node(258, [Leaf(1, "def"), Leaf(1, " "), Leaf(1, "f")]).__str__() == "def f"
    assert Node(258, [Leaf(1, "def"), Leaf(1, " "), Node(267, [Leaf(1, "f")])]).__str__() == "def f"



# Generated at 2022-06-21 10:35:43.537798
# Unit test for method remove of class Base
def test_Base_remove():
    n = Node(type=0, children=[])
    m = Node(type=1, parent=n, children=[])
    print(m.remove())
    print(m.parent)
    print(n.children)


# Generated at 2022-06-21 10:35:53.215203
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    import ast
    from cfg import CFG, Nonterminal
    from ast2python import Ast2PythonTransformer

    p = PatternTransformer()
    pycfg = CFG()
    pycfg.add_rule(Nonterminal("file_input"), [Nonterminal("stmt"), Star(Nonterminal("stmt"))])
    pycfg.add_rule(Nonterminal("stmt"), [Nonterminal("simple_stmt")])
    pycfg.add_rule(Nonterminal("simple_stmt"), [Nonterminal("small_stmt"), ";"])
    pycfg.add_rule(Nonterminal("small_stmt"), [Nonterminal("expr_stmt")])
    pycfg.add_rule(Nonterminal("expr_stmt"), [Nonterminal("testlist_star_expr")])
   

# Generated at 2022-06-21 10:36:05.255845
# Unit test for method match of class WildcardPattern
def test_WildcardPattern_match():
    pat = WildcardPattern([[Leaf(TOK.NAME, "a")], [Leaf(TOK.NAME, "b"), Leaf(TOK.NAME, "c")]])
    assert pat.match_seq([
        Leaf(TOK.NAME, "a"),
        Leaf(TOK.NAME, "a"),
        Leaf(TOK.NAME, "a"),
    ])
    assert pat.match_seq([
        Leaf(TOK.NAME, "b"),
        Leaf(TOK.NAME, "c"),
        Leaf(TOK.NAME, "b"),
        Leaf(TOK.NAME, "c"),
        Leaf(TOK.NAME, "b"),
        Leaf(TOK.NAME, "c"),
    ])

# Generated at 2022-06-21 10:36:13.766567
# Unit test for function generate_matches
def test_generate_matches():
    import re
    c = compile
    # The basic idea is to take a regular expression and tokenize it
    # and to create a pattern from the tokenized version, then test
    # it exhaustively against a set of cases

# Generated at 2022-06-21 10:36:31.024114
# Unit test for method depth of class Base
def test_Base_depth():
    from .pytree import Node, Leaf
    assert Base().depth() == 0
    a = Node(1, [Leaf(1, "a")])
    assert a.depth() == 0
    b = Node(1, [a])
    assert a.depth() == 1
    assert b.depth() == 0


# Generated at 2022-06-21 10:36:33.798909
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    lf = Leaf(0, "0")
    assert list(lf.pre_order()) == [lf]

# Generated at 2022-06-21 10:36:35.643510
# Unit test for constructor of class NodePattern
def test_NodePattern():
    p = NodePattern(None)
    assert isinstance(p, NodePattern)



# Generated at 2022-06-21 10:36:43.751068
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    np = NegatedPattern()
    assert np.type == None
    assert np.content == None
    assert np.wildcards == False
    assert np.min == 0
    assert np.max == HUGE
    assert np.name == None
    np = NegatedPattern(WildcardPattern())
    assert np.type == None
    assert np.content != None
    assert np.wildcards == True
    assert np.min == 0
    assert np.max == HUGE
    assert np.name == None


# Generated at 2022-06-21 10:36:46.818478
# Unit test for method post_order of class Leaf
def test_Leaf_post_order():
    s = "a = 1 + 2"
    parse_tree = parse(s)
    l = [leaf.value for leaf in parse_tree.post_order()]
    print(l)

# Generated at 2022-06-21 10:36:54.379745
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    (
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h,
        i,
        j,
        k,
        l,
        m,
        n,
        o,
        p,
        q,
    ) = map(NodePattern, "abcdefghijklmnopq")
    results = {}
    assert list(generate_matches([a], [a])) == [(1, {})]
    assert list(generate_matches([a], [a, b])) == []
    assert list(generate_matches([a], [b, a])) == []
    assert list(generate_matches([a], [a, b, c])) == []

# Generated at 2022-06-21 10:37:04.870314
# Unit test for constructor of class NegatedPattern
def test_NegatedPattern():
    def no_match(nodes):
        p = NegatedPattern(NodePattern())
        return [r for c, r in p.generate_matches(nodes)]
    assert no_match([]) == [{}]
    assert no_match([1]) == []
    def no_match(nodes):
        p = NegatedPattern(NodePattern(type=TOK.NAME))
        return [r for c, r in p.generate_matches(nodes)]
    assert no_match([]) == [{}]
    assert no_match([1]) == []
    assert no_match([Token(TOK.NAME, "x")]) == []
    assert no_match([1, Token(TOK.NAME, "x")]) == []

# Generated at 2022-06-21 10:37:07.996822
# Unit test for constructor of class NodePattern
def test_NodePattern():
    # Test that a short sequence raises an exception
    assert_raises(AssertionError, NodePattern, type=257, content=[WildcardPattern()])
    # Test that a long sequence doesn't raise an exception
    NodePattern(type=257, content=[WildcardPattern()] * 10)



# Generated at 2022-06-21 10:37:09.699398
# Unit test for constructor of class Leaf
def test_Leaf():
    l = Leaf(0, "foo", (" bar", (1, 2)))
    assert l.prefix == " bar"
    assert l.lineno == 1
    assert l.column == 2
    assert str(l) == " barfoo"



# Generated at 2022-06-21 10:37:15.747538
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert isinstance(NodePattern(), NodePattern)
    assert isinstance(NodePattern(None), NodePattern)
    assert isinstance(NodePattern(256), NodePattern)
    assert isinstance(NodePattern(type=257), NodePattern)
    assert isinstance(NodePattern(content=[]), NodePattern)
    assert isinstance(NodePattern(content=[LeafPattern()]), NodePattern)
    assert isinstance(NodePattern(name="a"), NodePattern)
    assert isinstance(NodePattern(256, [LeafPattern()]), NodePattern)
    assert isinstance(NodePattern(type=257, content=[]), NodePattern)
    assert isinstance(NodePattern(type=257, content=[LeafPattern()]), NodePattern)
    assert isinstance(NodePattern(content=[WildcardPattern()]), NodePattern)



# Generated at 2022-06-21 10:37:34.843894
# Unit test for method invalidate_sibling_maps of class Node
def test_Node_invalidate_sibling_maps():
    """
    Unit tests for method invalidate_sibling_maps of class Node
    """
    symbol = 257  # example symbol number
    children = []  # example children
    # node is a Node object with type equal to symbol, children and no parent
    node = Node(symbol, children)
    # Test that the Node object node has attribute prev_sibling_map equal
    # to None
    assert node.prev_sibling_map is None
    # Test that the Node object node has attribute next_sibling_map equal
    # to None
    assert node.next_sibling_map is None
    # Test that method invalidate_sibling_maps of node does not raise an
    # exception
    node.invalidate_sibling_maps()



# Generated at 2022-06-21 10:37:39.807348
# Unit test for method __str__ of class Leaf
def test_Leaf___str__():
    l = Leaf(0, "foo")
    assert l.prefix == ""
    assert str(l) == "foo"
    l.prefix = " "
    assert str(l) == " foo"
    l.prefix = " "
    assert str(l) == " foo"


# Generated at 2022-06-21 10:37:43.942760
# Unit test for method get_suffix of class Base
def test_Base_get_suffix():
    """
    class Base:
        def get_suffix(self):
            """

# Generated at 2022-06-21 10:37:54.593252
# Unit test for function generate_matches
def test_generate_matches():
    def gm(patterns, nodes):
        def show(c, r):
            return c, dict(r)

        return ", ".join(map(show, generate_matches(patterns, nodes)))

    # pylint: disable=bad-whitespace
    p1, p2, p3, p4, w01, w12, w123, w1234, w4 = \
        NodePattern('p1'), NodePattern('p2'), \
        NodePattern('p3'), NodePattern('p4'), \
        WildcardPattern(min=0, max=1), \
        WildcardPattern(min=1, max=2), \
        WildcardPattern(min=1, max=3), \
        WildcardPattern(min=1, max=4), \
        WildcardPattern(min=4, max=4)


# Generated at 2022-06-21 10:37:59.292772
# Unit test for constructor of class NodePattern
def test_NodePattern():
    assert NodePattern()
    assert NodePattern(257)
    assert NodePattern(257, [LeafPattern(257)])
    assert NodePattern(257, [LeafPattern(257), LeafPattern(258)])
    assert NodePattern(257, [LeafPattern(257), LeafPattern(258)], name="a")


# Generated at 2022-06-21 10:38:11.883200
# Unit test for method match_seq of class NegatedPattern
def test_NegatedPattern_match_seq():
    # This example is from the article about parsing expression grammars
    # by Ford in the Python section of comp.lang.python, June 2003.
    import spanish_utils

    p = spanish_utils.compile_string("'a' 'b' 'c' -'d'")
    assert p.match_seq(
        [
            spanish_utils.Leaf(spanish_utils.NAME, "a", 0),
            spanish_utils.Leaf(spanish_utils.NAME, "b", 0),
            spanish_utils.Leaf(spanish_utils.NAME, "c", 0),
        ]
    )

# Generated at 2022-06-21 10:38:19.410227
# Unit test for method match_seq of class WildcardPattern
def test_WildcardPattern_match_seq():
    pattern = WildcardPattern(min=2, max=3, name="seq")
    assert not pattern.match_seq([])
    assert not pattern.match_seq(["a"])
    assert pattern.match_seq(["a", "b"])
    assert pattern.match_seq(["a", "b", "c"])
    assert pattern.match_seq(["a", "b", "c", "d"])
    assert not pattern.match_seq(["a", "b", "c", "d", "e"])
    pattern = WildcardPattern(content=(("a",), ("b",), ("c",)), name="seq")
    assert not pattern.match_seq([])
    assert not pattern.match_seq(["a"])
    assert pattern.match_seq(["b"])
    assert pattern.match_seq

# Generated at 2022-06-21 10:38:29.123140
# Unit test for method replace of class Base
def test_Base_replace():
    from .pygram import python_symbols as symbols
    from .pgen2 import token

    grammar = Grammar(StringIO(test_grammar_grammar))
    symbol_map = grammar.symbol2number

    def check(t, new, result):
        if not isinstance(t, str):
            t = type_repr(t)
        if not isinstance(new, str):
            new = type_repr(new)
        print("Testing", t, "->", new)
        print("Original tree:", test_tree(t))
        print("New tree:", test_tree(new))
        node = test_tree(t)
        node = node.children[0]
        new = test_tree(new)
        new = new.children[0]
        node.replace(new)
        print

# Generated at 2022-06-21 10:38:33.813917
# Unit test for constructor of class NodePattern
def test_NodePattern():
    node = NodePattern(type=256)
    assert node.type == 256
    assert node.content is None
    assert node.name is None
    with pytest.raises(AssertionError):
        assert node.type < 256, node.type
    with pytest.raises(AssertionError):
        assert 0 <= node.type < 256, node.type
    node = NodePattern(type=257, content=[])
    assert node.type == 257
    assert node.content == []
    assert node.name is None
    with pytest.raises(AssertionError):
        assert 0 <= node.type < 256, node.type


# Generated at 2022-06-21 10:38:35.093047
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    """
    Unit test for method pre_order of class Node
    """
    # No tests
    pass

# Generated at 2022-06-21 10:38:51.404827
# Unit test for method clone of class Node
def test_Node_clone():
    n = Node(0, [])
    n.children.append(Leaf(0, "a"))
    n.children.append(Leaf(0, "b"))
    m = n.clone()
    assert m.children[0].parent == m
    assert m.children[1].parent == m



# Generated at 2022-06-21 10:38:53.974036
# Unit test for method __repr__ of class Node
def test_Node___repr__():
    # [ ] = Node(type, [ ])
    node = Node(256, [])
    r = repr(node)
    assert r == "Node(256, [])"
    

# Generated at 2022-06-21 10:38:56.977658
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    from .pytree import Leaf
    assert list(Leaf(1, "abc").leaves()) == [Leaf(1, "abc")]



# Generated at 2022-06-21 10:39:01.920613
# Unit test for method clone of class Leaf
def test_Leaf_clone():
    text = "this is a string"
    new_text = "this is a new string"
    leaf = Leaf(1,text)
    new_leaf = leaf.clone()
    new_leaf.value = new_text
    assert leaf.value == text
    assert new_leaf.value == new_text
    
    
# Testing method leaf.post_order()


# Generated at 2022-06-21 10:39:11.026382
# Unit test for method depth of class Base
def test_Base_depth():
    n = Node(0, children=[])
    assert n.depth() == 0

    n2 = Node(0, children=[])
    n.replace(n2)
    assert n2.depth() == 1
    assert n.parent is None

    n3 = Node(0, children=[])
    n2.replace(n3)
    assert n3.depth() == 2
    assert n2.parent is None

    n3.replace(None)
    assert n3.parent is None
    assert n2.next_sibling is None
    assert n2.prev_sibling is None


# Generated at 2022-06-21 10:39:20.925339
# Unit test for method __repr__ of class BasePattern
def test_BasePattern___repr__():
    bp = BasePattern(symbol.atom, 'a')
    bp

    assert BasePattern(symbol.atom, 'a', 'a_') == BasePattern(symbol.atom, 'a', 'a_')
    assert BasePattern(symbol.atom, 'a', 'a_') != BasePattern(symbol.atom, 'a', 'ab_')
    assert BasePattern(symbol.atom, 'a', 'a_') != BasePattern(symbol.atom, 'a_', 'a')
    assert BasePattern(symbol.atom, 'a') != BasePattern(symbol.atom, 'a_')
    assert BasePattern(symbol.atom, 'a') != BasePattern(symbol.atom, 'b')

# Generated at 2022-06-21 10:39:25.399837
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    for cls in BasePattern.__subclasses__():
        pattern = cls(1)
        node = Node(pattern.type, [])
        assert pattern.match(node)
        node.type = 2
        assert not pattern.match(node)



# Generated at 2022-06-21 10:39:38.021494
# Unit test for method replace of class Base
def test_Base_replace():
    class Node(Base):
        def __init__(self, children):
            self.children = children

        def clone(self):
            return Node([child.clone() for child in self.children])

        def post_order(self):
            for child in self.children:
                yield from child.post_order()
            yield self

        def pre_order(self):
            yield self
            for child in self.children:
                yield from child.pre_order()

        def _eq(self, other):
            if len(self.children) != len(other.children):
                return False
            for x, y in zip(self.children, other.children):
                if x != y:
                    return False
            return True

        def __repr__(self):
            return "Node(%s)" % (self.children,)



# Generated at 2022-06-21 10:39:44.170833
# Unit test for method set_child of class Node
def test_Node_set_child():
    child = Node(0, [], prefix="")
    node = Node(0, [child], prefix="")
    child2 = Node(0, [], prefix="")

    node.set_child(0, child2)
    assert node.children == [child2]
    assert node.children[0].parent is node
    assert child.parent is None



# Generated at 2022-06-21 10:39:51.768093
# Unit test for method set_child of class Node
def test_Node_set_child():
    from .pytree import Leaf, Node
    from . import pygram

    s = "from . import pygram"
    t = pytree_from_string(s)
    new_leaf = Leaf(1, ".", (1, 8))
    t.set_child(1, new_leaf)
    assert t.children == [Leaf(1, "from", (1, 0)), new_leaf, Leaf(1, "import", (1, 9)), Leaf(1, "pygram", (1, 16))]
    assert new_leaf.parent == t


# Generated at 2022-06-21 10:40:21.033864
# Unit test for method append_child of class Node
def test_Node_append_child():
    import blib2to3.pytree as pytree
    node = pytree.Node(0, [])
    child = pytree.Leaf(0, "")
    node.append_child(child)
    assert node.children == [child]
    assert child.parent == node



# Generated at 2022-06-21 10:40:31.458569
# Unit test for method match of class BasePattern
def test_BasePattern_match():
    class LeafPattern(BasePattern):

        def __init__(self, type, content=None, name=None):
            self.type, self.content, self.name = type, content, name

        def _submatch(self, node, results=None):
            if self.content is not None:
                assert isinstance(node, Leaf)
                return self.content == node.value
            return True

    class NodePattern(BasePattern):

        def __init__(self, type, content=None, name=None):
            self.type, self.content, self.name = type, content, name

        def _submatch(self, node, results=None):
            if self.content is not None:
                assert isinstance(node, Node)
                return self.content == node.children
            return True


# Generated at 2022-06-21 10:40:41.455623
# Unit test for method pre_order of class Node
def test_Node_pre_order():
    from .pygram import python_symbols
    from .pgen2 import token

    class Name:
        def __init__(self, name: str) -> None:
            self.name = name

        def __str__(self) -> str:
            return self.name

    def expect(node: Node, ex: List[str]) -> None:
        stuff = [str(x) for x in node.pre_order()]
        assert stuff == ex, stuff

    # 1 + 2 * 3 -> 1 + (2 * 3)

# Generated at 2022-06-21 10:40:48.714068
# Unit test for method match of class NegatedPattern
def test_NegatedPattern_match():
    p = NodePattern()
    q = NegatedPattern(p)
    assert q.match(p) == False
    assert q.match(q) == False
    assert q.match(None) == False
    assert q.match(WildcardPattern()) == False
    assert q.match(LeafPattern()) == False
    from . import pytree

# Generated at 2022-06-21 10:40:54.063330
# Unit test for method generate_matches of class WildcardPattern
def test_WildcardPattern_generate_matches():
    from .nodes import Leaf

    def test(content, nodes, expect):
        w = WildcardPattern(content)
        a = list(w.generate_matches(nodes))
        b = expect
        if a != b:
            print(w.content, w.min, w.max)
            print("in:", list(map(type, nodes)))
            print("out:", a)
            print("expect:", b)
            raise ValueError()

    test(None, [], [(0, {})])
    test(None, [Leaf(token.NAME, "a")], [(1, {})])
    test(None, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")], [(1, {}), (2, {})])


# Generated at 2022-06-21 10:40:54.983682
# Unit test for method __new__ of class Base
def test_Base___new__():
    assert Base is not Base()



# Generated at 2022-06-21 10:40:56.565124
# Unit test for function type_repr
def test_type_repr():
    assert type_repr(1) == 1
    assert type_repr(python_symbols.or_test) == "or_test"



# Generated at 2022-06-21 10:41:06.068345
# Unit test for method clone of class Base
def test_Base_clone():
    import random
    import string
    import pegen
    from .pgen2 import token
    from .pygram import python_grammar

    grammar = python_grammar
    g = pegen.Generator(grammar, token)
    for t in range(256):
        if t not in grammar.symbol2number:
            continue
        print("Trying symbol", t)
        try:
            tree1 = g.generate(t)
        except ValueError:
            continue
        tree2 = tree1.clone()
        if not pegen.tree_compare(tree1, tree2):
            print("FAILED")
        else:
            print("SUCCEEDED")



# Generated at 2022-06-21 10:41:07.956157
# Unit test for method __new__ of class Base
def test_Base___new__():
    # Testing with Base
    assert Base()



# Generated at 2022-06-21 10:41:10.945255
# Unit test for method leaves of class Leaf
def test_Leaf_leaves():
    a = Leaf(0,"a") # type: Leaf
    assert [x for x in a.leaves()] == [a]
    assert a.leaves() == []


# Generated at 2022-06-21 10:41:25.075487
# Unit test for method pre_order of class Leaf
def test_Leaf_pre_order():
    leaf = Leaf(1, "leaf")
    assert [leaf] == [node for node in leaf.pre_order()]